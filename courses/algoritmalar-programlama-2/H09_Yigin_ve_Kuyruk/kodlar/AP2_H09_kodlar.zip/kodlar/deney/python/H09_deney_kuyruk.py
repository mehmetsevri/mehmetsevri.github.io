"""H09_deney_kuyruk.py — AP-2 Hafta 9 · Haftanın Deneyi (Python)
Amaç    : (a) Kayıt gişesi simülasyonu (Örnek 10'un modeli): gişe sayısı k
          ve yük oranı ρ'ya göre ortalama bekleme; deterministik CSV.
          (b) Kuyruk gerçekleştirimleri: kaydırmalı dizi (her çıkarmada
          kaydırma, O(n)) ve dairesel tampon (O(1)) elle; ETİKETLİ
          KÜTÜPHANE serileri: list.pop(0) ve collections.deque.popleft().
Kullanım: python3 H09_deney_kuyruk.py izgara|sabit SURE TOHUM_SAYISI
          python3 H09_deney_kuyruk.py tek K RHO_BINDE TOHUM SURE
          python3 H09_deney_kuyruk.py kuyruk TUR N TEKRAR
          (TUR: kaydirmali | dairesel | pop0 | deque); sonuç stdout'a,
          süreler (ms) stderr'e
Eşleri  : ../c/H09_deney_kuyruk.c · ../cpp/H09_deney_kuyruk.cpp
"""
import sys
from collections import deque  # yalnızca etiketli kütüphane serisi

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

HIZMET_EN_AZ = 60
HIZMET_EN_COK = 180  # E[S] = 120 s
KUYRUK_KAPASITE = 65536
RHO_BINDE = (100, 300, 500, 600, 700, 800, 850, 900, 950, 980)
LAMBDA_SAAT_ONDA = (120, 180, 240, 270, 288, 360, 480)


# ---------------- (a) gişe simülasyonu ----------------
class Kuyruk:
    __slots__ = ("veri", "kapasite", "bas", "son", "sayac")


def kuyruk_olustur(kapasite):
    q = Kuyruk()
    q.veri = [0] * kapasite
    q.kapasite = kapasite
    q.bas = q.son = q.sayac = 0
    return q


def kuyruk_ekle(q, x):
    if q.sayac == q.kapasite:
        return False
    q.veri[q.son] = x
    q.son = (q.son + 1) % q.kapasite
    q.sayac += 1
    return True


def kuyruk_cikar(q):
    if q.sayac == 0:
        return False, 0
    x = q.veri[q.bas]
    q.bas = (q.bas + 1) % q.kapasite
    q.sayac -= 1
    return True, x


def gise_benzet(k, gelis_milyonda, sure):
    """Örnek 10'daki gise_benzet ile aynı adımlar (olay yazdırmasız)"""
    q = kuyruk_olustur(KUYRUK_KAPASITE)
    kalan = [0] * k
    gelen = reddedilen = hizmet_alan = toplam_bekleme = mesgul = 0
    toplam_kuyruk = en_uzun_bekleme = en_uzun_kuyruk = 0
    for t in range(sure):
        if rastgele_aralik(0, 999999) < gelis_milyonda:
            gelen += 1
            if not kuyruk_ekle(q, t):
                reddedilen += 1
        for g in range(k):
            if kalan[g] == 0:
                tamam, gelis = kuyruk_cikar(q)
                if tamam:
                    bekleme = t - gelis
                    hizmet_alan += 1
                    toplam_bekleme += bekleme
                    if bekleme > en_uzun_bekleme:
                        en_uzun_bekleme = bekleme
                    kalan[g] = rastgele_aralik(HIZMET_EN_AZ, HIZMET_EN_COK)
        for g in range(k):
            if kalan[g] > 0:
                kalan[g] -= 1
                mesgul += 1
        toplam_kuyruk += q.sayac
        if q.sayac > en_uzun_kuyruk:
            en_uzun_kuyruk = q.sayac
    return (gelen, hizmet_alan, reddedilen, q.sayac, toplam_bekleme,
            en_uzun_bekleme, toplam_kuyruk, en_uzun_kuyruk, mesgul)


def csv_basligi():
    print("k;rho;gelis_milyonda;tohum;sure_s;gelen;hizmet_alan;reddedilen;"
          "kuyrukta_kalan;ort_bekleme_s;en_uzun_bekleme_s;ort_kuyruk;"
          "en_uzun_kuyruk;doluluk_yuzde")


def satir(k, p, tohum, sure):
    rastgele_tohum(tohum)
    (gelen, hizmet, red, kalan, top_bek, en_bek, top_kuy, en_kuy,
     mesgul) = gise_benzet(k, p, sure)
    rho = p * 120.0 / (1000000.0 * k)
    ort = top_bek / hizmet if hizmet > 0 else 0.0
    print(f"{k};{rho:.4f};{p};{tohum};{sure};{gelen};{hizmet};{red};"
          f"{kalan};{ort:.3f};{en_bek};{top_kuy / sure:.4f};{en_kuy};"
          f"{100.0 * mesgul / (k * sure):.3f}")


# ---------------- (b) kuyruk gerçekleştirimleri ----------------
class KaydirmaliKuyruk:
    """veri[0..boyut-1]; baştan çıkarmada herkes bir sola kayar"""
    __slots__ = ("veri", "kapasite", "boyut")


def kk_ekle(q, x):
    if q.boyut == q.kapasite:
        return False
    q.veri[q.boyut] = x
    q.boyut += 1
    return True


def kk_cikar(q):
    if q.boyut == 0:
        return False, 0
    x = q.veri[0]
    veri = q.veri
    for i in range(1, q.boyut):
        veri[i - 1] = veri[i]  # O(n): kalanların hepsi kayar
    q.boyut -= 1
    return True, x


def gorev_calistir(tur, n):
    """n ekle, n çıkar; (sıra doğru mu, çıkanların toplamı)"""
    dogru, toplam = True, 0
    if tur == "kaydirmali":
        q = KaydirmaliKuyruk()
        q.veri, q.kapasite, q.boyut = [0] * n, n, 0
        for i in range(n):
            kk_ekle(q, i)
        for i in range(n):
            x = kk_cikar(q)[1]
            dogru = dogru and x == i
            toplam += x
    elif tur == "dairesel":
        q = kuyruk_olustur(n)
        for i in range(n):
            kuyruk_ekle(q, i)
        for i in range(n):
            x = kuyruk_cikar(q)[1]
            dogru = dogru and x == i
            toplam += x
    elif tur == "pop0":  # KÜTÜPHANE: list.pop(0) her çıkarmada kaydırır
        q = []
        for i in range(n):
            q.append(i)
        for i in range(n):
            x = q.pop(0)
            dogru = dogru and x == i
            toplam += x
    else:  # KÜTÜPHANE: collections.deque, popleft O(1)
        q = deque()
        for i in range(n):
            q.append(i)
        for i in range(n):
            x = q.popleft()
            dogru = dogru and x == i
            toplam += x
    return dogru, toplam


def kuyruk_olc(tur, n, tekrar):
    if tekrar < 1:
        tekrar = 5
    gorev_calistir(tur, n)  # ısınma
    duvar, islemci = [], []
    dogru, toplam = False, 0
    for _ in range(tekrar):
        t0, c0 = zaman_sn(), islemci_sn()
        dogru, toplam = gorev_calistir(tur, n)
        duvar.append((zaman_sn() - t0) * 1000.0)
        islemci.append((islemci_sn() - c0) * 1000.0)
    print(f"kuyruk;{tur};{n};" + ("evet" if dogru else "HAYIR")
          + f";{toplam}")
    print(f"SURE;{ortanca(duvar):.4f};{ortanca(islemci):.4f};"
          f"{min(duvar):.4f};{max(duvar):.4f};{tekrar}", file=sys.stderr)


def sayi_oku(s):
    if s.isascii() and s.isdigit() and int(s) <= 100000000:
        return int(s)
    print(f"geçersiz sayı: {s}", file=sys.stderr)
    sys.exit(2)


def main():
    a = sys.argv
    kip = a[1] if len(a) > 1 else ""
    if len(a) == 4 and kip in ("izgara", "sabit"):
        sure, tohumlar = sayi_oku(a[2]), sayi_oku(a[3])
        csv_basligi()
        for k in range(1, 5):
            if kip == "izgara":
                hizlar = [(r * k * 1000 + 60) // 120 for r in RHO_BINDE]
            else:
                hizlar = [(lam * 100000 + 1800) // 3600
                          for lam in LAMBDA_SAAT_ONDA]
            for p in hizlar:
                for t in range(1, tohumlar + 1):
                    satir(k, p, t, sure)
    elif len(a) == 6 and kip == "tek":
        k = sayi_oku(a[2])
        p = (sayi_oku(a[3]) * k * 1000 + 60) // 120
        csv_basligi()
        satir(k, p, sayi_oku(a[4]), sayi_oku(a[5]))
    elif len(a) == 5 and kip == "kuyruk":
        if a[2] not in ("kaydirmali", "dairesel", "pop0", "deque"):
            print("TUR: kaydirmali | dairesel | pop0 | deque",
                  file=sys.stderr)
            return 2
        kuyruk_olc(a[2], sayi_oku(a[3]), sayi_oku(a[4]))
    else:
        print("kullanım: bkz. dosya başlığı", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())

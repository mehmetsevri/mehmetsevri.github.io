"""zamanlayici.py — AP-2 ortak zaman ölçüm modülü (Python 3.10+)

Amaç   : Algoritma deneylerinde süre ölçümü. Süreler stderr'e yazılır;
         stdout'a yalnızca deterministik sonuçlar yazılır.
Kaynak : time.perf_counter (yüksek çözünürlüklü monotonik saat) ve
         time.process_time (işlemci zamanı).
Eşleri : zamanlayici.h/.c (C), zamanlayici.hpp (C++)
"""

import time


def zaman_sn():
    """Monotonik saat zamanı (saniye)."""
    return time.perf_counter()


def islemci_sn():
    """Bu sürecin kullandığı işlemci zamanı (saniye)."""
    return time.process_time()


def ortanca(x):
    """x değerlerinin ortancasını döndürür (x değiştirilmez)."""
    x = list(x)
    # Küçük n için araya ekleme sıralaması (yardımcı; ders konusu H5)
    for i in range(1, len(x)):
        anahtar = x[i]
        j = i - 1
        while j >= 0 and x[j] > anahtar:
            x[j + 1] = x[j]
            j -= 1
        x[j + 1] = anahtar
    n = len(x)
    if n % 2 == 1:
        return x[n // 2]
    return (x[n // 2 - 1] + x[n // 2]) / 2.0


def olc_ortanca(gorev, tekrar):
    """gorev() çağrısını 1 kez ısınma + tekrar kez çalıştırır; ortanca süre."""
    tekrar = max(1, tekrar)
    gorev()  # ısınma
    sureler = []
    for _ in range(tekrar):
        t0 = zaman_sn()
        gorev()
        sureler.append(zaman_sn() - t0)
    return ortanca(sureler)

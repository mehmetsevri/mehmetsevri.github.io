"""ortak_rastgele.py — AP-2 ortak rastgele sayı modülü (Python 3.10+)

Amaç   : C, C++ ve Python'da BİREBİR AYNI sözde rastgele diziyi üreten
         64 bitlik doğrusal eşlik üreteci (LCG). random modülü (Mersenne
         Twister) C/C++ ile aynı diziyi vermediğinden ders örneklerinde bu
         modül kullanılır.
Formül : durum = (durum * 6364136223846793005 + 1442695040888963407) mod 2^64
         çıktı = durum >> 33   (31 bit: 0 .. 2^31 - 1)
Not    : Python tamsayıları sınırsızdır; C'deki uint64_t sarmasını taklit
         etmek için sonuç 2^64 - 1 maskesiyle (& _MASKE64) kırpılır.
Eşleri : ortak_rastgele.h/.c (C), ortak_rastgele.hpp (C++)
"""

_MASKE64 = (1 << 64) - 1
_durum = 2027  # varsayılan tohum


def rastgele_tohum(tohum):
    """Üretecin durumunu verilen tohumla başlatır."""
    global _durum
    _durum = tohum & _MASKE64


def rastgele_sayi():
    """Bir sonraki sayıyı döndürür: 0 .. 2^31 - 1 (dahil)."""
    global _durum
    _durum = (_durum * 6364136223846793005 + 1442695040888963407) & _MASKE64
    return _durum >> 33


def rastgele_aralik(alt, ust):
    """[alt, ust] kapalı aralığında tamsayı döndürür (alt <= ust olmalı)."""
    genislik = ust - alt + 1
    return alt + rastgele_sayi() % genislik


def rastgele_kesir():
    """[0, 1) aralığında ondalık sayı döndürür."""
    return rastgele_sayi() / 2147483648.0  # 2^31


def rastgele_dizi(n, alt, ust):
    """n elemanlı, [alt, ust] aralığındaki sayılardan oluşan liste döndürür."""
    a = [0] * n
    for i in range(n):
        a[i] = rastgele_aralik(alt, ust)
    return a


def rastgele_karistir(a):
    """a listesini Fisher–Yates yöntemiyle yerinde karıştırır."""
    for i in range(len(a) - 1, 0, -1):
        j = rastgele_aralik(0, i)
        a[i], a[j] = a[j], a[i]

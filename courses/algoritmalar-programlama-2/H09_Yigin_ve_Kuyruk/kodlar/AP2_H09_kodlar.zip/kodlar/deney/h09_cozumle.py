#!/usr/bin/env python3
"""h09_cozumle.py — AP-2 Hafta 9 · Haftanın Deneyi çözümlemesi

Girdi : sonuclar/h09_deney_gise.csv, h09_deney_gise_sabit.csv,
        h09_deney_kuyruk.csv (h09_olcum_calistir.py üretir)
Çıktı : sonuclar/h09_ozet_gise.csv      (k × ρ: tohumlar üzerinden ortalama;
                                         k = 1 için M/M/1 ve M/G/1 formülleri)
        sonuclar/h09_ozet_gise_sabit.csv (k × λ)
        sonuclar/h09_ozet_kuyruk.csv    (ölçülen + işaretli kestirim)
        sonuclar/h09_ozet_kat.csv       (kaydırmalı/dairesel, pop0/deque ...)
        sonuclar/h09_ozet_egim.csv      (log–log eğimleri)
        sonuclar/h09_ozet_sayim.json    (belge için anahtar sayılar)
Süre ölçütü: İŞLEMCİ zamanı ortancası (paylaşımlı makinede duvar saati
bekleme süresini de içerir; bkz. OLCUM_ORTAMI.txt). Kestirim modeli: kare
seriler (kaydırmalı, pop0) için t = c·n², c en büyük ölçülen n'den.
Tüm oranlar bu betikte CSV'den hesaplanır.
"""
import csv
import json
import math
import os

SONUC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sonuclar")
HIZMET = range(60, 181)  # hizmet süresi dağılımı: {60, ..., 180} düzgün
ES = sum(HIZMET) / len(HIZMET)                   # E[S] = 120
ES2 = sum(s * s for s in HIZMET) / len(HIZMET)   # E[S²]
NLER = [1000, 2000, 5000, 10000, 20000, 50000, 100000]


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def yaz(ad, alanlar, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8",
              newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(alanlar)
        for s in satirlar:
            w.writerow([s[a] for a in alanlar])


def gise_ozet(ad, anahtar):
    gruplar = {}
    for r in oku(ad):
        gruplar.setdefault((int(r["k"]), int(r["gelis_milyonda"])),
                           []).append(r)
    satirlar = []
    for (k, p), rs in sorted(gruplar.items()):
        lam = p / 1e6
        rho = lam * ES / k
        w = [float(r["ort_bekleme_s"]) for r in rs]
        lq = [float(r["ort_kuyruk"]) for r in rs]
        kabul = [int(r["gelen"]) - int(r["reddedilen"]) for r in rs]
        sure = [int(r["sure_s"]) for r in rs]
        little = [kabul[i] / sure[i] * w[i] for i in range(len(rs))]
        s = {"k": k, "gelis_milyonda": p,
             "saatte_ogrenci": round(lam * 3600, 2),
             "rho": round(rho, 4), "tohum_sayisi": len(rs),
             "ort_bekleme_s": round(sum(w) / len(w), 2),
             "en_az_bekleme_s": round(min(w), 2),
             "en_cok_bekleme_s": round(max(w), 2),
             "ort_kuyruk": round(sum(lq) / len(lq), 3),
             "little_lambda_w": round(sum(little) / len(little), 3),
             "doluluk_yuzde": round(sum(float(r["doluluk_yuzde"])
                                        for r in rs) / len(rs), 2),
             "kuyrukta_kalan_ort": round(sum(int(r["kuyrukta_kalan"])
                                             for r in rs) / len(rs), 1),
             "reddedilen_toplam": sum(int(r["reddedilen"]) for r in rs),
             "en_uzun_bekleme_s": max(int(r["en_uzun_bekleme_s"])
                                      for r in rs)}
        if k == 1 and rho < 1:
            s["mm1_bekleme_s"] = round(rho / (1 - rho) * ES, 2)
            s["mg1_pk_bekleme_s"] = round(lam * ES2 / (2 * (1 - rho)), 2)
            s["oran_sim_mm1"] = round(s["ort_bekleme_s"] /
                                      s["mm1_bekleme_s"], 3)
            s["oran_sim_mg1"] = round(s["ort_bekleme_s"] /
                                      s["mg1_pk_bekleme_s"], 3)
        else:
            s["mm1_bekleme_s"] = s["mg1_pk_bekleme_s"] = ""
            s["oran_sim_mm1"] = s["oran_sim_mg1"] = ""
        s["kararli"] = "evet" if rho < 1 else "HAYIR (ρ >= 1)"
        satirlar.append(s)
    alanlar = ["k", "gelis_milyonda", "saatte_ogrenci", "rho", "tohum_sayisi",
               "ort_bekleme_s", "en_az_bekleme_s", "en_cok_bekleme_s",
               "ort_kuyruk", "little_lambda_w", "doluluk_yuzde",
               "kuyrukta_kalan_ort", "reddedilen_toplam", "en_uzun_bekleme_s",
               "mm1_bekleme_s", "mg1_pk_bekleme_s", "oran_sim_mm1",
               "oran_sim_mg1", "kararli"]
    yaz(anahtar, alanlar, satirlar)
    return satirlar


def egim(noktalar):
    """log10 t'nin log10 n'ye en küçük kareler eğimi"""
    xs = [math.log10(n) for n, _ in noktalar]
    ys = [math.log10(t) for _, t in noktalar]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    pay = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    payda = sum((x - mx) ** 2 for x in xs)
    return pay / payda


def kuyruk_ozet():
    olcum = oku("h09_deney_kuyruk.csv")
    seriler = {}
    for r in olcum:
        seriler.setdefault((r["dil"], r["derleme"], r["uygulama"]),
                           {})[int(r["n"])] = r
    tum = []
    for (dil, derleme, tur), d in seriler.items():
        en_buyuk = max(d)
        c = float(d[en_buyuk]["islemci_ortanca_ms"]) / en_buyuk ** 2
        for n in NLER:
            if n in d:
                r = d[n]
                tum.append({"dil": dil, "derleme": derleme, "uygulama": tur,
                            "n": n,
                            "islemci_ms": float(r["islemci_ortanca_ms"]),
                            "duvar_ms": float(r["ortanca_ms"]),
                            "kestirim": "hayır", "model": ""})
            elif tur in ("kaydirmali", "pop0"):
                tum.append({"dil": dil, "derleme": derleme, "uygulama": tur,
                            "n": n, "islemci_ms": round(c * n * n, 3),
                            "duvar_ms": "", "kestirim": "evet",
                            "model": f"t = c·n², c n = {en_buyuk} ölçümünden"})
    yaz("h09_ozet_kuyruk.csv", ["dil", "derleme", "uygulama", "n",
                                "islemci_ms", "duvar_ms", "kestirim",
                                "model"], tum)

    def t(dil, derleme, tur, n):
        for s in tum:
            if (s["dil"], s["derleme"], s["uygulama"], s["n"]) == \
                    (dil, derleme, tur, n):
                return s["islemci_ms"], s["kestirim"] == "evet"
        return None, None

    katlar = []
    tanimlar = [("C", "-O2", "kaydirmali", "C", "-O2", "dairesel"),
                ("C", "-O0", "kaydirmali", "C", "-O0", "dairesel"),
                ("C++", "-O2", "kaydirmali", "C++", "-O2", "dairesel"),
                ("Python", "-", "kaydirmali", "Python", "-", "dairesel"),
                ("Python", "-", "pop0", "Python", "-", "deque"),
                ("Python", "-", "kaydirmali", "Python", "-", "pop0"),
                ("Python", "-", "dairesel", "Python", "-", "deque"),
                ("C", "-O0", "kaydirmali", "C", "-O2", "kaydirmali"),
                ("Python", "-", "dairesel", "C", "-O2", "dairesel")]
    for d1, o1, u1, d2, o2, u2 in tanimlar:
        for n in NLER:
            a, ka = t(d1, o1, u1, n)
            b, kb = t(d2, o2, u2, n)
            if a is None or b is None:
                continue
            katlar.append({"pay": f"{d1} {o1} {u1}",
                           "payda": f"{d2} {o2} {u2}",
                           "n": n, "kat": round(a / b, 2),
                           "kestirim": "evet" if (ka or kb) else "hayır"})
    yaz("h09_ozet_kat.csv", ["pay", "payda", "n", "kat", "kestirim"], katlar)

    egimler = []
    for (dil, derleme, tur), d in sorted(seriler.items()):
        nokta = [(n, float(d[n]["islemci_ortanca_ms"])) for n in sorted(d)
                 if float(d[n]["islemci_ortanca_ms"]) >= 0.05]
        ust = [x for x in nokta if x[0] >= 10000]
        egimler.append({"dil": dil, "derleme": derleme, "uygulama": tur,
                        "nokta": len(nokta),
                        "egim_tum": round(egim(nokta), 3) if len(nokta) > 1
                        else "",
                        "egim_n_10e4_ustu": round(egim(ust), 3)
                        if len(ust) > 1 else "",
                        "beklenen": 2 if tur in ("kaydirmali", "pop0") else 1})
    yaz("h09_ozet_egim.csv", ["dil", "derleme", "uygulama", "nokta",
                              "egim_tum", "egim_n_10e4_ustu", "beklenen"],
        egimler)

    # Model sınaması: C -O2 kaydırmalıda n = 2·10^4'ten 10^5 kestirimi
    c20 = seriler[("C", "-O2", "kaydirmali")]
    tahmin = float(c20[20000]["islemci_ortanca_ms"]) * 25
    olculen = float(c20[100000]["islemci_ortanca_ms"])
    sinama = {"tahmin_ms": round(tahmin, 2), "olculen_ms": round(olculen, 2),
              "oran": round(olculen / tahmin, 3)}
    return tum, katlar, egimler, sinama


def main():
    izgara = gise_ozet("h09_deney_gise.csv", "h09_ozet_gise.csv")
    sabit = gise_ozet("h09_deney_gise_sabit.csv", "h09_ozet_gise_sabit.csv")
    tum, katlar, egimler, sinama = kuyruk_ozet()

    def w(k, rho):
        return next(s["ort_bekleme_s"] for s in izgara
                    if s["k"] == k and abs(s["rho"] - rho) < 0.002)

    sayim = {
        "ES": ES, "ES2": ES2,
        "gise_rho_k": {f"{s['k']}|{s['rho']:.2f}": s["ort_bekleme_s"]
                       for s in izgara},
        "gise_k1_buyume": {r: w(1, r) for r in (0.5, 0.8, 0.9, 0.95, 0.98)},
        "gise_k1_kat_09_05": round(w(1, 0.9) / w(1, 0.5), 2),
        "gise_k1_kat_098_09": round(w(1, 0.98) / w(1, 0.9), 2),
        "gise_rho09_k": {k: w(k, 0.9) for k in (1, 2, 3, 4)},
        "gise_rho09_kat_k1_k4": round(w(1, 0.9) / w(4, 0.9), 2),
        "oran_sim_mm1_k1": {f"{s['rho']:.2f}": s["oran_sim_mm1"]
                            for s in izgara if s["k"] == 1},
        "oran_sim_mg1_k1": {f"{s['rho']:.2f}": s["oran_sim_mg1"]
                            for s in izgara if s["k"] == 1},
        "little_en_buyuk_bagil_fark": round(max(
            abs(s["little_lambda_w"] - s["ort_kuyruk"]) / s["ort_kuyruk"]
            for s in izgara if s["ort_kuyruk"] > 0.05), 4),
        "reddedilen_toplam": sum(s["reddedilen_toplam"] for s in izgara),
        "sabit": {f"{s['k']}|{s['saatte_ogrenci']}":
                  [s["ort_bekleme_s"], s["rho"]] for s in sabit},
        "kat_100000": {f"{k['pay']} / {k['payda']}":
                       [k["kat"], k["kestirim"]]
                       for k in katlar if k["n"] == 100000},
        "kat_1000": {f"{k['pay']} / {k['payda']}": [k["kat"], k["kestirim"]]
                     for k in katlar if k["n"] == 1000},
        "egim": {f"{e['dil']} {e['derleme']} {e['uygulama']}":
                 [e["egim_tum"], e["egim_n_10e4_ustu"]] for e in egimler},
        "model_sinamasi_c_O2_kaydirmali": sinama,
        "kestirim_sayisi": sum(1 for s in tum if s["kestirim"] == "evet"),
    }
    with open(os.path.join(SONUC, "h09_ozet_sayim.json"), "w",
              encoding="utf-8") as f:
        json.dump(sayim, f, ensure_ascii=False, indent=1)
    print(json.dumps(sayim, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()

/* H09_deney_kuyruk.cpp — AP-2 Hafta 9 · Haftanın Deneyi (C++)
 * Amaç    : (a) Kayıt gişesi simülasyonu (Örnek 10'un modeli): gişe sayısı
 *           k ve yük oranı ρ'ya göre ortalama bekleme; deterministik CSV.
 *           (b) Kuyruk gerçekleştirimleri: kaydırmalı dizi (her çıkarmada
 *           kaydırma, O(n)) ve dairesel tampon (O(1)); n ekle + n çıkar.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H09_deney_kuyruk.cpp \
 *           -o H09_deney_kuyruk
 * Kullanım: C sürümüyle aynı (izgara | sabit | tek | kuyruk); sonuç
 *           stdout'a, süreler (ms) stderr'e
 * Eşleri  : ../c/H09_deney_kuyruk.c · ../python/H09_deney_kuyruk.py
 */
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

const int HIZMET_EN_AZ = 60;
const int HIZMET_EN_COK = 180;  // E[S] = 120 s
const int KUYRUK_KAPASITE = 65536;

// ---------------- (a) gişe simülasyonu ----------------
struct Kuyruk {
    std::vector<int> veri;
    int kapasite = 0, bas = 0, son = 0, sayac = 0;
};

struct Sonuc {
    long long gelen = 0, reddedilen = 0, hizmet_alan = 0;
    long long toplam_bekleme = 0, mesgul = 0, toplam_kuyruk = 0;
    int en_uzun_bekleme = 0, en_uzun_kuyruk = 0, kuyrukta_kalan = 0;
};

static bool kuyruk_ekle(Kuyruk& q, int x)
{
    if (q.sayac == q.kapasite) {
        return false;
    }
    q.veri[q.son] = x;
    q.son = (q.son + 1) % q.kapasite;
    q.sayac++;
    return true;
}

static bool kuyruk_cikar(Kuyruk& q, int& x)
{
    if (q.sayac == 0) {
        return false;
    }
    x = q.veri[q.bas];
    q.bas = (q.bas + 1) % q.kapasite;
    q.sayac--;
    return true;
}

// Örnek 10'daki gise_benzet ile aynı adımlar (olay yazdırmasız)
static Sonuc gise_benzet(int k, int gelis_milyonda, int sure)
{
    Sonuc s;
    Kuyruk q;
    q.veri.assign(KUYRUK_KAPASITE, 0);
    q.kapasite = KUYRUK_KAPASITE;
    std::vector<int> kalan(k, 0);
    for (int t = 0; t < sure; t++) {
        if (rastgele_aralik(0, 999999) < gelis_milyonda) {
            s.gelen++;
            s.reddedilen += !kuyruk_ekle(q, t);
        }
        for (int g = 0; g < k; g++) {
            int gelis;
            if (kalan[g] == 0 && kuyruk_cikar(q, gelis)) {
                int bekleme = t - gelis;
                s.hizmet_alan++;
                s.toplam_bekleme += bekleme;
                if (bekleme > s.en_uzun_bekleme) {
                    s.en_uzun_bekleme = bekleme;
                }
                kalan[g] = rastgele_aralik(HIZMET_EN_AZ, HIZMET_EN_COK);
            }
        }
        for (int g = 0; g < k; g++) {
            if (kalan[g] > 0) {
                kalan[g]--;
                s.mesgul++;
            }
        }
        s.toplam_kuyruk += q.sayac;
        if (q.sayac > s.en_uzun_kuyruk) {
            s.en_uzun_kuyruk = q.sayac;
        }
    }
    s.kuyrukta_kalan = q.sayac;
    return s;
}

static void csv_basligi()
{
    std::printf("k;rho;gelis_milyonda;tohum;sure_s;gelen;hizmet_alan;"
                "reddedilen;kuyrukta_kalan;ort_bekleme_s;en_uzun_bekleme_s;"
                "ort_kuyruk;en_uzun_kuyruk;doluluk_yuzde\n");
}

static void satir(int k, int p, int tohum, int sure)
{
    rastgele_tohum(static_cast<std::uint64_t>(tohum));
    Sonuc s = gise_benzet(k, p, sure);
    double rho = p * 120.0 / (1000000.0 * k);
    double ort = s.hizmet_alan > 0
                     ? static_cast<double>(s.toplam_bekleme) / s.hizmet_alan
                     : 0.0;
    std::printf("%d;%.4f;%d;%d;%d;%lld;%lld;%lld;%d;%.3f;%d;%.4f;%d;%.3f\n",
                k, rho, p, tohum, sure, s.gelen, s.hizmet_alan,
                s.reddedilen, s.kuyrukta_kalan, ort, s.en_uzun_bekleme,
                static_cast<double>(s.toplam_kuyruk) / sure, s.en_uzun_kuyruk,
                100.0 * s.mesgul / (static_cast<double>(k) * sure));
}

static const int RHO_BINDE[] = {100, 300, 500, 600, 700, 800, 850, 900, 950,
                                980};
static const int LAMBDA_SAAT_ONDA[] = {120, 180, 240, 270, 288, 360, 480};

// ---------------- (b) kuyruk gerçekleştirimleri ----------------
// Kaydırmalı: veri[0..boyut-1]; baştan çıkarmada herkes bir sola kayar
struct KaydirmaliKuyruk {
    std::vector<int> veri;
    int kapasite = 0, boyut = 0;
};

static bool kk_ekle(KaydirmaliKuyruk& q, int x)
{
    if (q.boyut == q.kapasite) {
        return false;
    }
    q.veri[q.boyut++] = x;
    return true;
}

static bool kk_cikar(KaydirmaliKuyruk& q, int& x)
{
    if (q.boyut == 0) {
        return false;
    }
    x = q.veri[0];
    for (int i = 1; i < q.boyut; i++) {
        q.veri[i - 1] = q.veri[i];  // O(n): kalanların hepsi kayar
    }
    q.boyut--;
    return true;
}

static bool gorev_calistir(int tur, int n, long long& toplam)
{
    int x = 0;
    bool dogru = true;
    toplam = 0;
    if (tur == 0) {
        KaydirmaliKuyruk q;
        q.veri.assign(n, 0);
        q.kapasite = n;
        for (int i = 0; i < n; i++) {
            kk_ekle(q, i);
        }
        for (int i = 0; i < n; i++) {
            kk_cikar(q, x);
            dogru = dogru && x == i;
            toplam += x;
        }
    } else {
        Kuyruk q;
        q.veri.assign(n, 0);
        q.kapasite = n;
        for (int i = 0; i < n; i++) {
            kuyruk_ekle(q, i);
        }
        for (int i = 0; i < n; i++) {
            kuyruk_cikar(q, x);
            dogru = dogru && x == i;
            toplam += x;
        }
    }
    return dogru;
}

static void kuyruk_olc(int tur, int n, int tekrar)
{
    long long toplam = 0;
    bool dogru = false;
    std::vector<double> duvar, islemci;
    if (tekrar < 1) {
        tekrar = 5;
    }
    gorev_calistir(tur, n, toplam);  // ısınma
    for (int r = 0; r < tekrar; r++) {
        double t0 = zaman_sn(), c0 = islemci_sn();
        dogru = gorev_calistir(tur, n, toplam);
        duvar.push_back((zaman_sn() - t0) * 1000.0);
        islemci.push_back((islemci_sn() - c0) * 1000.0);
    }
    double en_az = duvar[0], en_cok = duvar[0];
    for (double d : duvar) {
        en_az = d < en_az ? d : en_az;
        en_cok = d > en_cok ? d : en_cok;
    }
    std::printf("kuyruk;%s;%d;%s;%lld\n",
                tur == 0 ? "kaydirmali" : "dairesel", n,
                dogru ? "evet" : "HAYIR", toplam);
    std::fprintf(stderr, "SURE;%.4f;%.4f;%.4f;%.4f;%d\n", ortanca(duvar),
                 ortanca(islemci), en_az, en_cok, tekrar);
}

static int sayi_oku(const char *s)
{
    try {
        std::size_t son = 0;
        long v = std::stol(s, &son);
        if (son == std::strlen(s) && v >= 0 && v <= 100000000) {
            return static_cast<int>(v);
        }
    } catch (...) {
    }
    std::fprintf(stderr, "geçersiz sayı: %s\n", s);
    std::exit(2);
}

int main(int argc, char *argv[])
{
    std::string kip = argc > 1 ? argv[1] : "";
    if (argc == 4 && kip == "izgara") {
        int sure = sayi_oku(argv[2]), tohumlar = sayi_oku(argv[3]);
        csv_basligi();
        for (int k = 1; k <= 4; k++) {
            for (int r : RHO_BINDE) {
                int p = (r * k * 1000 + 60) / 120;
                for (int t = 1; t <= tohumlar; t++) {
                    satir(k, p, t, sure);
                }
            }
        }
    } else if (argc == 4 && kip == "sabit") {
        int sure = sayi_oku(argv[2]), tohumlar = sayi_oku(argv[3]);
        csv_basligi();
        for (int k = 1; k <= 4; k++) {
            for (int l : LAMBDA_SAAT_ONDA) {
                int p = (l * 100000 + 1800) / 3600;
                for (int t = 1; t <= tohumlar; t++) {
                    satir(k, p, t, sure);
                }
            }
        }
    } else if (argc == 6 && kip == "tek") {
        int k = sayi_oku(argv[2]);
        int p = (sayi_oku(argv[3]) * k * 1000 + 60) / 120;
        csv_basligi();
        satir(k, p, sayi_oku(argv[4]), sayi_oku(argv[5]));
    } else if (argc == 5 && kip == "kuyruk") {
        std::string tur = argv[2];
        if (tur != "kaydirmali" && tur != "dairesel") {
            std::fprintf(stderr, "TUR: kaydirmali | dairesel\n");
            return 2;
        }
        kuyruk_olc(tur == "kaydirmali" ? 0 : 1, sayi_oku(argv[3]),
                   sayi_oku(argv[4]));
    } else {
        std::fprintf(stderr, "kullanım: bkz. dosya başlığı\n");
        return 2;
    }
    return 0;
}

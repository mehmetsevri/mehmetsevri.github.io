/* H09_deney_kuyruk.c — AP-2 Hafta 9 · Haftanın Deneyi (C)
 * Amaç    : (a) Kayıt gişesi simülasyonu (Örnek 10'un modeli): gişe sayısı
 *           k ve yük oranı ρ'ya göre ortalama bekleme; deterministik CSV.
 *           (b) Kuyruk gerçekleştirimleri: kaydırmalı dizi (her çıkarmada
 *           kaydırma, O(n)) ve dairesel tampon (O(1)); n ekle + n çıkar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_deney_kuyruk.c \
 *           ortak_rastgele.c zamanlayici.c -o H09_deney_kuyruk
 * Kullanım: ./H09_deney_kuyruk izgara SURE TOHUM_SAYISI   (k=1..4 × ρ)
 *           ./H09_deney_kuyruk sabit SURE TOHUM_SAYISI    (k=1..4 × λ)
 *           ./H09_deney_kuyruk tek K RHO_BINDE TOHUM SURE  (doğrulama)
 *           ./H09_deney_kuyruk kuyruk TUR N TEKRAR  (TUR: kaydirmali |
 *           dairesel); sonuç stdout'a, süreler (ms) stderr'e
 * Eşleri  : ../cpp/H09_deney_kuyruk.cpp · ../python/H09_deney_kuyruk.py
 */
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define HIZMET_EN_AZ 60
#define HIZMET_EN_COK 180  /* E[S] = 120 s */
#define KUYRUK_KAPASITE 65536

/* ---------------- (a) gişe simülasyonu ---------------- */
typedef struct {
    int *veri;
    int kapasite, bas, son, sayac;
} Kuyruk;

typedef struct {
    long long gelen, reddedilen, hizmet_alan, toplam_bekleme, mesgul;
    long long toplam_kuyruk;
    int en_uzun_bekleme, en_uzun_kuyruk, kuyrukta_kalan;
} Sonuc;

static bool kuyruk_ekle(Kuyruk *q, int x)
{
    if (q->sayac == q->kapasite) {
        return false;
    }
    q->veri[q->son] = x;
    q->son = (q->son + 1) % q->kapasite;
    q->sayac++;
    return true;
}

static bool kuyruk_cikar(Kuyruk *q, int *x)
{
    if (q->sayac == 0) {
        return false;
    }
    *x = q->veri[q->bas];
    q->bas = (q->bas + 1) % q->kapasite;
    q->sayac--;
    return true;
}

/* Örnek 10'daki gise_benzet ile aynı adımlar (olay yazdırmasız) */
static Sonuc gise_benzet(int k, int gelis_milyonda, int sure)
{
    Sonuc s = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    Kuyruk q = {malloc(KUYRUK_KAPASITE * sizeof(int)), KUYRUK_KAPASITE, 0,
                0, 0};
    int kalan[8] = {0};
    if (q.veri == NULL) {
        exit(1);
    }
    for (int t = 0; t < sure; t++) {
        if (rastgele_aralik(0, 999999) < gelis_milyonda) {
            s.gelen++;
            s.reddedilen += !kuyruk_ekle(&q, t);
        }
        for (int g = 0; g < k; g++) {
            int gelis;
            if (kalan[g] == 0 && kuyruk_cikar(&q, &gelis)) {
                int bekleme = t - gelis;
                s.hizmet_alan++;
                s.toplam_bekleme += bekleme;
                if (bekleme > s.en_uzun_bekleme) {
                    s.en_uzun_bekleme = bekleme;
                }
                kalan[g] = rastgele_aralik(HIZMET_EN_AZ, HIZMET_EN_COK);
            }
        }
        for (int g = 0; g < k; g++) {
            if (kalan[g] > 0) {
                kalan[g]--;
                s.mesgul++;
            }
        }
        s.toplam_kuyruk += q.sayac;
        if (q.sayac > s.en_uzun_kuyruk) {
            s.en_uzun_kuyruk = q.sayac;
        }
    }
    s.kuyrukta_kalan = q.sayac;
    free(q.veri);
    return s;
}

static void csv_basligi(void)
{
    printf("k;rho;gelis_milyonda;tohum;sure_s;gelen;hizmet_alan;reddedilen;"
           "kuyrukta_kalan;ort_bekleme_s;en_uzun_bekleme_s;ort_kuyruk;"
           "en_uzun_kuyruk;doluluk_yuzde\n");
}

static void satir(int k, int p, int tohum, int sure)
{
    rastgele_tohum((uint64_t)tohum);
    Sonuc s = gise_benzet(k, p, sure);
    double rho = p * 120.0 / (1000000.0 * k);
    double ort = s.hizmet_alan > 0
                     ? (double)s.toplam_bekleme / s.hizmet_alan : 0.0;
    printf("%d;%.4f;%d;%d;%d;%lld;%lld;%lld;%d;%.3f;%d;%.4f;%d;%.3f\n", k,
           rho, p, tohum, sure, s.gelen, s.hizmet_alan, s.reddedilen,
           s.kuyrukta_kalan, ort, s.en_uzun_bekleme,
           (double)s.toplam_kuyruk / sure, s.en_uzun_kuyruk,
           100.0 * s.mesgul / ((double)k * sure));
}

static const int RHO_BINDE[] = {100, 300, 500, 600, 700, 800, 850, 900, 950,
                                980};
static const int LAMBDA_SAAT_ONDA[] = {120, 180, 240, 270, 288, 360, 480};

/* ---------------- (b) kuyruk gerçekleştirimleri ---------------- */
/* Kaydırmalı: veri[0..boyut-1]; baştan çıkarmada herkes bir sola kayar */
typedef struct {
    int *veri;
    int kapasite, boyut;
} KaydirmaliKuyruk;

static bool kk_ekle(KaydirmaliKuyruk *q, int x)
{
    if (q->boyut == q->kapasite) {
        return false;
    }
    q->veri[q->boyut++] = x;
    return true;
}

static bool kk_cikar(KaydirmaliKuyruk *q, int *x)
{
    if (q->boyut == 0) {
        return false;
    }
    *x = q->veri[0];
    for (int i = 1; i < q->boyut; i++) {
        q->veri[i - 1] = q->veri[i];  /* O(n): kalanların hepsi kayar */
    }
    q->boyut--;
    return true;
}

typedef struct {
    int tur;  /* 0: kaydırmalı, 1: dairesel */
    int n;
    long long toplam;
    bool dogru;
} Gorev;

static void gorev_calistir(void *v)
{
    Gorev *g = v;
    int *veri = malloc((size_t)g->n * sizeof *veri);
    int x = 0;
    if (veri == NULL) {
        exit(1);
    }
    g->toplam = 0;
    g->dogru = true;
    if (g->tur == 0) {
        KaydirmaliKuyruk q = {veri, g->n, 0};
        for (int i = 0; i < g->n; i++) {
            kk_ekle(&q, i);
        }
        for (int i = 0; i < g->n; i++) {
            kk_cikar(&q, &x);
            g->dogru = g->dogru && x == i;
            g->toplam += x;
        }
    } else {
        Kuyruk q = {veri, g->n, 0, 0, 0};
        for (int i = 0; i < g->n; i++) {
            kuyruk_ekle(&q, i);
        }
        for (int i = 0; i < g->n; i++) {
            kuyruk_cikar(&q, &x);
            g->dogru = g->dogru && x == i;
            g->toplam += x;
        }
    }
    free(veri);
}

static void kuyruk_olc(int tur, int n, int tekrar)
{
    Gorev g = {tur, n, 0, false};
    double duvar[101], islemci[101];
    if (tekrar < 1 || tekrar > 101) {
        tekrar = 5;
    }
    gorev_calistir(&g);  /* ısınma */
    for (int r = 0; r < tekrar; r++) {
        double t0 = zaman_sn(), c0 = islemci_sn();
        gorev_calistir(&g);
        duvar[r] = (zaman_sn() - t0) * 1000.0;
        islemci[r] = (islemci_sn() - c0) * 1000.0;
    }
    double en_az = duvar[0], en_cok = duvar[0];
    for (int r = 1; r < tekrar; r++) {
        en_az = duvar[r] < en_az ? duvar[r] : en_az;
        en_cok = duvar[r] > en_cok ? duvar[r] : en_cok;
    }
    printf("kuyruk;%s;%d;%s;%lld\n", tur == 0 ? "kaydirmali" : "dairesel", n,
           g.dogru ? "evet" : "HAYIR", g.toplam);
    fprintf(stderr, "SURE;%.4f;%.4f;%.4f;%.4f;%d\n", ortanca(duvar, tekrar),
            ortanca(islemci, tekrar), en_az, en_cok, tekrar);
}

static int sayi_oku(const char *s)
{
    char *son;
    errno = 0;
    long v = strtol(s, &son, 10);
    if (son == s || *son != '\0' || errno != 0 || v < 0 || v > 100000000) {
        fprintf(stderr, "geçersiz sayı: %s\n", s);
        exit(2);
    }
    return (int)v;
}

int main(int argc, char *argv[])
{
    if (argc == 4 && strcmp(argv[1], "izgara") == 0) {
        int sure = sayi_oku(argv[2]), tohumlar = sayi_oku(argv[3]);
        csv_basligi();
        for (int k = 1; k <= 4; k++) {
            for (int i = 0; i < 10; i++) {
                int p = (RHO_BINDE[i] * k * 1000 + 60) / 120;
                for (int t = 1; t <= tohumlar; t++) {
                    satir(k, p, t, sure);
                }
            }
        }
    } else if (argc == 4 && strcmp(argv[1], "sabit") == 0) {
        int sure = sayi_oku(argv[2]), tohumlar = sayi_oku(argv[3]);
        csv_basligi();
        for (int k = 1; k <= 4; k++) {
            for (int i = 0; i < 7; i++) {
                /* saatte λ öğrenci (onda bir) → saniyede milyonda */
                int p = (LAMBDA_SAAT_ONDA[i] * 100000 + 1800) / 3600;
                for (int t = 1; t <= tohumlar; t++) {
                    satir(k, p, t, sure);
                }
            }
        }
    } else if (argc == 6 && strcmp(argv[1], "tek") == 0) {
        int k = sayi_oku(argv[2]);
        int p = (sayi_oku(argv[3]) * k * 1000 + 60) / 120;
        csv_basligi();
        satir(k, p, sayi_oku(argv[4]), sayi_oku(argv[5]));
    } else if (argc == 5 && strcmp(argv[1], "kuyruk") == 0) {
        int tur = strcmp(argv[2], "kaydirmali") == 0 ? 0
                  : strcmp(argv[2], "dairesel") == 0 ? 1 : -1;
        if (tur < 0) {
            fprintf(stderr, "TUR: kaydirmali | dairesel\n");
            return 2;
        }
        kuyruk_olc(tur, sayi_oku(argv[3]), sayi_oku(argv[4]));
    } else {
        fprintf(stderr, "kullanım: bkz. dosya başlığı\n");
        return 2;
    }
    return 0;
}

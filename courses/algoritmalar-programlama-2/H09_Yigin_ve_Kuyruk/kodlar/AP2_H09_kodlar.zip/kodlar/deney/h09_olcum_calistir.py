#!/usr/bin/env python3
"""h09_olcum_calistir.py — AP-2 Hafta 9 · Haftanın Deneyi sürücüsü

(a) Gişe simülasyonu: C ve C++ programları aynı ızgarayı (k = 1..4 ×
    ρ ∈ {0,10 … 0,98} × 5 tohum, SURE saniye) ve sabit geliş hızı serisini
    üretir; iki dilin CSV'si bayt bayt karşılaştırılır. Python aynı
    satırların bir alt kümesini (k = 1..4, ρ = 0,90, tohum 1) üretir ve
    C satırlarıyla karşılaştırılır (süre bütçesi).
(b) Kuyruk gerçekleştirimleri: n = 10^3 … 10^5; C (-O2, -O0), C++ (-O2):
    kaydırmalı ve dairesel; Python: kaydırmalı, dairesel ve ETİKETLİ
    kütüphane serileri pop0 (list.pop(0)) ve deque (popleft). Her ölçüm:
    1 ısınma + 5 tekrar, ortanca (program içinde); duvar saati en_cok/en_az
    > 1,5 ise en çok 2 kez yinelenir ve işlemci zamanı ortancası en küçük
    deneme alınır. Tahmini süresi bütçeyi (BUTCE_S) aşan büyüklükler
    ÖLÇÜLMEZ; çözümleme betiği n² modeliyle işaretli kestirim yapar.
Kullanım: python3 h09_olcum_calistir.py [--devam] [--hizli]
          python3 h09_olcum_calistir.py --ikinci-oturum   (yalnız (b)'yi
          yeniden ölçer; CSV'ye her nokta için işlemci zamanı ortancası
          küçük olan oturum yazılır — başka süreçler süreyi yalnız artırır)
Çıktılar: sonuclar/h09_deney_gise.csv, h09_deney_gise_sabit.csv,
          h09_deney_gise_dogrulama.csv, h09_deney_kuyruk.csv, h09_ham.jsonl,
          ../deney/OLCUM_ORTAMI.txt
"""
import csv
import datetime
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
HAM = os.path.join(SONUC, "h09_ham.jsonl")
SURE = 2000000          # gişe benzetim süresi (s) ≈ 23 gün
TOHUM = 5
NLER = [1000, 2000, 5000, 10000, 20000, 50000, 100000]
TEKRAR = 5
BUTCE_S = 15.0          # bir ölçümün (ısınma + tekrar) tahmini üst sınırı
C_BAYRAK = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP_BAYRAK = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]


def komut_ciktisi(komut):
    try:
        return subprocess.run(komut, capture_output=True, text=True
                              ).stdout.strip()
    except OSError:
        return "?"


def derle(gecici):
    ikililer = {}
    c = os.path.join(KOK, "c")
    for ad, bayrak in (("c_O2", "-O2"), ("c_O0", "-O0")):
        hedef = os.path.join(gecici, f"h09ikili_{ad}")
        subprocess.run(C_BAYRAK + [bayrak,
                                   os.path.join(c, "H09_deney_kuyruk.c"),
                                   os.path.join(c, "ortak_rastgele.c"),
                                   os.path.join(c, "zamanlayici.c"),
                                   "-o", hedef], check=True)
        ikililer[ad] = [hedef]
    hedef = os.path.join(gecici, "h09ikili_cpp_O2")
    subprocess.run(CPP_BAYRAK + ["-O2", os.path.join(KOK, "cpp",
                                                     "H09_deney_kuyruk.cpp"),
                                 "-o", hedef], check=True)
    ikililer["cpp_O2"] = [hedef]
    ikililer["py"] = [sys.executable,
                      os.path.join(KOK, "python", "H09_deney_kuyruk.py")]
    return ikililer


def calistir(komut):
    ortam = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", LC_ALL="C.UTF-8")
    p = subprocess.run(komut, capture_output=True, text=True, env=ortam,
                       cwd=KOK)
    if p.returncode != 0:
        sys.exit(f"HATA: {' '.join(komut)}\n{p.stderr}")
    return p.stdout, p.stderr


def ham_oku():
    kayitlar = {}
    if os.path.exists(HAM):
        with open(HAM, encoding="utf-8") as f:
            for satir in f:
                k = json.loads(satir)
                kayitlar[k["anahtar"]] = k
    return kayitlar


def ham_yaz(kayit):
    with open(HAM, "a", encoding="utf-8") as f:
        f.write(json.dumps(kayit, ensure_ascii=False) + "\n")


def kuyruk_olc(ikili, dil, derleme, tur, n):
    """Bir ölçüm: gerekirse yinelenir; en iyi denemeyi döndürür"""
    en_iyi, deneme = None, 0
    for deneme in range(1, 4):
        out, err = calistir(ikili + ["kuyruk", tur, str(n), str(TEKRAR)])
        alan = out.strip().split(";")
        s = [x for x in err.splitlines() if x.startswith("SURE;")][0]
        _, duvar, islemci, en_az, en_cok, tekrar = s.split(";")
        k = {"n": n, "dil": dil, "derleme": derleme, "uygulama": tur,
             "tekrar": int(tekrar), "ortanca_ms": float(duvar),
             "islemci_ortanca_ms": float(islemci), "en_az_ms": float(en_az),
             "en_cok_ms": float(en_cok), "dogru": alan[3],
             "toplam": int(alan[4]), "deneme": deneme}
        if en_iyi is None or k["islemci_ortanca_ms"] < \
                en_iyi["islemci_ortanca_ms"]:
            en_iyi = dict(k)
        if k["en_cok_ms"] <= 1.5 * k["en_az_ms"]:
            break
    en_iyi["deneme"] = deneme
    return en_iyi


def gise_bolumu(ikililer, kayitlar, devam, sure, tohum):
    sonuc = {}
    for kip in ("izgara", "sabit"):
        ciktilar = {}
        for dil in ("c_O2", "cpp_O2"):
            anahtar = f"gise|{kip}|{dil}|{sure}|{tohum}"
            if devam and anahtar in kayitlar:
                ciktilar[dil] = kayitlar[anahtar]["cikti"]
                continue
            t0 = time.time()
            out, _ = calistir(ikililer[dil] + [kip, str(sure), str(tohum)])
            ciktilar[dil] = out
            ham_yaz({"anahtar": anahtar, "cikti": out,
                     "sure_s": round(time.time() - t0, 2)})
            print(f"  gişe {kip} {dil}: {time.time() - t0:.1f} s",
                  flush=True)
        ayni = ciktilar["c_O2"] == ciktilar["cpp_O2"]
        ad = "h09_deney_gise.csv" if kip == "izgara" else \
            "h09_deney_gise_sabit.csv"
        with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
            f.write(ciktilar["c_O2"])
        sonuc[kip] = ayni
        print(f"  {ad}: C ve C++ çıktıları aynı mı? "
              f"{'evet' if ayni else 'HAYIR'}", flush=True)
    # Python doğrulaması: ızgaradaki k = 1..4, ρ = 0,90, tohum 1 satırları
    c_satirlar = {}
    with open(os.path.join(SONUC, "h09_deney_gise.csv"), encoding="utf-8") \
            as f:
        for r in csv.DictReader(f, delimiter=";"):
            c_satirlar[(r["k"], r["gelis_milyonda"], r["tohum"])] = r
    dogrulama = []
    for k in (1, 2, 3, 4):
        anahtar = f"gise|tek|py|{k}|900|1|{sure}"
        if devam and anahtar in kayitlar:
            out = kayitlar[anahtar]["cikti"]
        else:
            t0 = time.time()
            out, _ = calistir(ikililer["py"] + ["tek", str(k), "900", "1",
                                                str(sure)])
            ham_yaz({"anahtar": anahtar, "cikti": out,
                     "sure_s": round(time.time() - t0, 2)})
            print(f"  gişe tek py k={k}: {time.time() - t0:.1f} s",
                  flush=True)
        satir = out.strip().split("\n")[1]
        alan = satir.split(";")
        c = c_satirlar[(alan[0], alan[2], alan[3])]
        c_satir = ";".join(c[x] for x in c)
        dogrulama.append((k, satir, c_satir == satir))
    with open(os.path.join(SONUC, "h09_deney_gise_dogrulama.csv"), "w",
              encoding="utf-8") as f:
        f.write("k;rho_binde;tohum;sure_s;python_satiri;c_ile_ayni\n")
        for k, satir, ayni in dogrulama:
            f.write(f"{k};900;1;{sure};{satir};{'evet' if ayni else 'HAYIR'}"
                    "\n")
    sonuc["py_dogrulama"] = all(a for _, _, a in dogrulama)
    print(f"  Python doğrulaması (4 satır): "
          f"{'aynı' if sonuc['py_dogrulama'] else 'FARKLI'}", flush=True)
    return sonuc


def kuyruk_bolumu(ikililer, kayitlar, devam, nler, oturum=1):
    seriler = [("c_O2", "C", "-O2", "kaydirmali"),
               ("c_O2", "C", "-O2", "dairesel"),
               ("c_O0", "C", "-O0", "kaydirmali"),
               ("c_O0", "C", "-O0", "dairesel"),
               ("cpp_O2", "C++", "-O2", "kaydirmali"),
               ("cpp_O2", "C++", "-O2", "dairesel"),
               ("py", "Python", "-", "kaydirmali"),
               ("py", "Python", "-", "dairesel"),
               ("py", "Python", "-", "pop0"), ("py", "Python", "-", "deque")]
    satirlar = []
    for ikili, dil, derleme, tur in seriler:
        onceki = None
        for n in nler:
            anahtar = f"kuyruk|{dil}|{derleme}|{tur}|{n}|o{oturum}"
            if onceki is not None and tur in ("kaydirmali", "pop0"):
                tahmin = onceki["islemci_ortanca_ms"] / 1000 * \
                    (n / onceki["n"]) ** 2 * (TEKRAR + 1)
                if tahmin > BUTCE_S:
                    print(f"  {dil} {derleme} {tur} n={n}: tahmini "
                          f"{tahmin:.0f} s > bütçe {BUTCE_S:.0f} s — "
                          "ölçülmedi (kestirim)", flush=True)
                    break
            if devam and anahtar in kayitlar:
                k = kayitlar[anahtar]
            else:
                t0 = time.time()
                k = kuyruk_olc(ikililer[ikili], dil, derleme, tur, n)
                k["anahtar"] = anahtar
                k["oturum"] = oturum
                k["toplam_sure_s"] = round(time.time() - t0, 2)
                ham_yaz(k)
                print(f"  {dil:6s} {derleme:3s} {tur:10s} n={n:6d}: "
                      f"{k['islemci_ortanca_ms']:10.3f} ms (işlemci), "
                      f"deneme {k['deneme']}, {k['dogru']}", flush=True)
            satirlar.append(k)
            onceki = k
    return satirlar


ALANLAR = ["n", "dil", "derleme", "uygulama", "tekrar", "ortanca_ms",
           "islemci_ortanca_ms", "en_az_ms", "en_cok_ms", "dogru", "toplam",
           "deneme", "oturum"]


def kuyruk_csv_yaz():
    """Ham kayıtlardan CSV: her nokta için işlemci ortancası en küçük
    oturum (başka süreçlerin etkisi süreyi yalnızca artırabilir)"""
    secilen = {}
    for k in ham_oku().values():
        if not k["anahtar"].startswith("kuyruk|"):
            continue
        nokta = (k["dil"], k["derleme"], k["uygulama"], k["n"])
        if nokta not in secilen or k["islemci_ortanca_ms"] < \
                secilen[nokta]["islemci_ortanca_ms"]:
            secilen[nokta] = k
    sira = {("C", "-O2"): 0, ("C", "-O0"): 1, ("C++", "-O2"): 2,
            ("Python", "-"): 3}
    tur_sira = {"kaydirmali": 0, "dairesel": 1, "pop0": 2, "deque": 3}
    satirlar = sorted(secilen.values(), key=lambda k: (
        sira[(k["dil"], k["derleme"])], tur_sira[k["uygulama"]], k["n"]))
    with open(os.path.join(SONUC, "h09_deney_kuyruk.csv"), "w",
              encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(ALANLAR)
        for k in satirlar:
            w.writerow([k.get(a, 1) for a in ALANLAR])
    return satirlar


def main():
    devam = "--devam" in sys.argv or "--ikinci-oturum" in sys.argv
    hizli = "--hizli" in sys.argv
    ikinci = "--ikinci-oturum" in sys.argv
    os.makedirs(SONUC, exist_ok=True)
    if not devam and os.path.exists(HAM) and not hizli:
        os.remove(HAM)
    kayitlar = ham_oku()
    yuk_once = open("/proc/loadavg").read().split()[:3]
    t_bas = time.time()
    gecici = tempfile.mkdtemp(prefix="h09x_")
    try:
        ikililer = derle(gecici)
        sure, tohum, nler = (SURE, TOHUM, NLER) if not hizli else \
            (100000, 1, NLER[:3])
        print("(a) gişe simülasyonu", flush=True)
        gise = gise_bolumu(ikililer, kayitlar, devam, sure, tohum)
        print("(b) kuyruk gerçekleştirimleri", flush=True)
        oturum = 2 if ikinci else 1
        if not ikinci:
            kuyruk_bolumu(ikililer, kayitlar, devam, nler)
        else:
            print("(b) ikinci oturum", flush=True)
            kuyruk_bolumu(ikililer, kayitlar, False, nler, oturum=2)
        ham_yaz({"anahtar": f"oturum|{oturum}", "yuk_once": yuk_once,
                 "yuk_sonra": open("/proc/loadavg").read().split()[:3],
                 "sure_s": round(time.time() - t_bas, 1)})
        satirlar = kuyruk_csv_yaz()
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    toplam = time.time() - t_bas
    if hizli:
        print(f"hızlı kip bitti: {toplam:.1f} s")
        return
    model = [x.split(":", 1)[1].strip() for x in
             komut_ciktisi(["lscpu"]).splitlines()
             if x.startswith("Model name")]
    ham = ham_oku().values()
    olcum_suresi = sum(k["toplam_sure_s"] for k in ham
                       if "toplam_sure_s" in k)
    gise_suresi = sum(k["sure_s"] for k in ham
                      if k["anahtar"].startswith("gise|"))
    oturumlar = sorted((k for k in ham if k["anahtar"].startswith("oturum|")),
                       key=lambda k: k["anahtar"])
    yuk_metni = " · ".join(
        f"{k['anahtar'].split('|')[1]}. oturum önce {' '.join(k['yuk_once'])}"
        f", sonra {' '.join(k['yuk_sonra'])} ({k['sure_s']:.0f} s)"
        for k in oturumlar)
    ikinciden = sum(1 for k in satirlar if k.get("oturum", 1) == 2)
    oturum_metni = ("2 (her nokta için işlemci ortancası küçük olan; CSV'de "
                    f"ikinci oturumdan alınan: {ikinciden})" if ikinci
                    else "1")
    metin = f"""AP-2 Hafta 9 · Haftanın Deneyi — ölçüm ortamı
Tarih          : {datetime.date.today().isoformat()}
İşlemci        : {model[0] if model else '?'}
Çekirdek sayısı: {os.cpu_count()} (sanal makine; ölçüm sırasında başka süreçler de çalışıyor olabilir)
Yük ortalaması : {yuk_metni} (/proc/loadavg: 1, 5, 15 dk)
İşletim sistemi: {platform.system()} {platform.release()} ({platform.machine()})
C derleyicisi  : {komut_ciktisi(['gcc', '--version']).splitlines()[0]}
C++ derleyicisi: {komut_ciktisi(['g++', '--version']).splitlines()[0]}
Python         : Python {platform.python_version()}
Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra -pedantic -O2 (C ayrıca -O0)
(a) Gişe       : k = 1..4 × ρ ∈ {{0,10 0,30 0,50 0,60 0,70 0,80 0,85 0,90 0,95 0,98}} × tohum 1..{TOHUM}; sabit λ serisi (saatte 12 … 48 öğrenci) × tohum 1..{TOHUM}; süre {SURE} s (≈ {SURE / 86400:.1f} gün); C ve C++ CSV'si bayt bayt aynı mı: ızgara {'evet' if gise['izgara'] else 'HAYIR'}, sabit {'evet' if gise['sabit'] else 'HAYIR'}; Python (k = 1..4, ρ = 0,90, tohum 1) C ile aynı mı: {'evet' if gise['py_dogrulama'] else 'HAYIR'}
(b) Kuyruk     : n ekle + n çıkar, n = {', '.join(str(n) for n in NLER)}; 1 ısınma + {TEKRAR} tekrar, ortanca (program içinde); duvar saati en_cok/en_az > 1,5 ise en çok 2 kez yineleme, en küçük işlemci ortancalı deneme; bütçe: tahmini ölçüm süresi > {BUTCE_S:.0f} s olan büyüklük ölçülmedi (kestirim)
Saat           : duvar saati C timespec_get, C++ steady_clock, Python time.perf_counter; işlemci zamanı C/C++ clock(), Python time.process_time
Ölçüm sayısı   : {len(satirlar)} nokta (CSV'de; yinelenen: {sum(1 for k in satirlar if k['deneme'] > 1)}; doğruluk "evet": {sum(1 for k in satirlar if k['dogru'] == 'evet')}); oturum: {oturum_metni}
Toplam süre    : bu çalıştırma {toplam:.1f} s (derleme dahil); ham kayıtlardan (tüm oturumlar) gişe {gise_suresi:.1f} s, kuyruk ölçümleri {olcum_suresi:.1f} s
"""
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)
    print(metin)


if __name__ == "__main__":
    main()

/* H09_HA2_bas_esit_son_duzeltilmis.c — AP-2 Hafta 9 · Hata Avcısı 2
 * Düzeltilmiş: eleman sayacı tutulur (Örnek 8, yöntem A): boş ⇔ sayac == 0,
 * dolu ⇔ sayac == KAPASITE; dolu kuyruğa ekleme reddedilir (false). Diğer
 * çözüm: bir hücreyi hep boş bırakmak (yöntem B: dolu ⇔
 * (son + 1) % KAPASITE == bas; kapasite 3'e düşer).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_HA2_bas_esit_son_duzeltilmis.c \
 *           -o H09_HA2_bas_esit_son_duzeltilmis
 * Hatalı  : H09_HA2_bas_esit_son.c
 */
#include <stdbool.h>
#include <stdio.h>

#define KAPASITE 4

typedef struct {
    int veri[KAPASITE];
    int bas;    /* ilk elemanın indisi */
    int son;    /* sıradaki yazma indisi */
    int sayac;  /* DÜZELTME: eleman sayısı dolu/boş ayrımını yapar */
} Kuyruk;

bool kuyruk_bos_mu(const Kuyruk *q) { return q->sayac == 0; }

bool kuyruk_dolu_mu(const Kuyruk *q) { return q->sayac == KAPASITE; }

bool kuyruk_ekle(Kuyruk *q, int x)
{
    if (kuyruk_dolu_mu(q)) {
        return false;  /* taşma politikası: reddet */
    }
    q->veri[q->son] = x;
    q->son = (q->son + 1) % KAPASITE;
    q->sayac++;
    return true;
}

bool kuyruk_cikar(Kuyruk *q, int *x)
{
    if (kuyruk_bos_mu(q)) {
        return false;
    }
    *x = q->veri[q->bas];
    q->bas = (q->bas + 1) % KAPASITE;
    q->sayac--;
    return true;
}

static void durum(const Kuyruk *q, const char *olay)
{
    printf("  %s -> bas = %d, son = %d, boyut = %d, boş mu? %s\n", olay,
           q->bas, q->son, q->sayac, kuyruk_bos_mu(q) ? "evet" : "hayır");
}

int main(void)
{
    Kuyruk q = {{0}, 0, 0, 0};
    int x;
    durum(&q, "başlangıç");
    for (int k = 1; k <= 4; k++) {
        kuyruk_ekle(&q, 10 * k);
        char olay[16];
        snprintf(olay, sizeof olay, "ekle %d", 10 * k);
        durum(&q, olay);
    }
    printf("  ekle 50 -> %s\n", kuyruk_ekle(&q, 50) ? "evet"
                                                    : "reddedildi (dolu)");
    printf("  çıkarılanlar:");
    while (kuyruk_cikar(&q, &x)) {
        printf(" %d", x);
    }
    printf("\n");
    kuyruk_ekle(&q, 50);
    durum(&q, "ekle 50");
    printf("  çıkarılanlar:");
    while (kuyruk_cikar(&q, &x)) {
        printf(" %d", x);
    }
    printf("\n");
    return 0;
}

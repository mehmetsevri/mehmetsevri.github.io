/* H09_HA1_bos_yigindan_cikar_duzeltilmis.c — AP-2 Hafta 9 · Hata Avcısı 1
 * Düzeltilmiş: yigin_cikar önce boş mu diye bakar; alt taşmayı dönüş
 * koduyla (false) bildirir ve yığını değiştirmez (Örnek 1'in sözleşmesi).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_HA1_bos_yigindan_cikar_duzeltilmis.c \
 *           -o H09_HA1_bos_yigindan_cikar_duzeltilmis
 * Hatalı  : H09_HA1_bos_yigindan_cikar.c
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *veri;
    int kapasite;
    int boyut;
} Yigin;

bool yigin_it(Yigin *y, int x)
{
    if (y->boyut == y->kapasite) {
        return false;
    }
    y->veri[y->boyut++] = x;
    return true;
}

bool yigin_cikar(Yigin *y, int *x)
{
    if (y->boyut == 0) {
        return false;          /* DÜZELTME: alt taşma bildirilir */
    }
    y->boyut--;
    *x = y->veri[y->boyut];
    return true;
}

int main(void)
{
    Yigin y = {malloc(4 * sizeof(int)), 4, 0};
    int x;
    if (y.veri == NULL) {
        return 1;
    }
    for (int k = 1; k <= 4; k++) {
        yigin_it(&y, 10 * k);
    }
    printf("4 eleman itildi; 5 kez çıkarılıyor:");
    for (int k = 0; k < 5; k++) {
        if (yigin_cikar(&y, &x)) {
            printf(" %d", x);
        } else {
            printf(" [alt taşma: yığın boş]");
        }
    }
    printf("\nboyut = %d\n", y.boyut);
    yigin_it(&y, 50);
    printf("50 itildi; boyut = %d\n", y.boyut);
    if (yigin_cikar(&y, &x)) {
        printf("tepe çıkarıldı: %d; boyut = %d\n", x, y.boyut);
    }
    free(y.veri);
    printf("program sona erdi\n");
    return 0;
}

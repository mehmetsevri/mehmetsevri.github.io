/* H09_HA6_kapasite_asimi.c — AP-2 Hafta 9 · Hata Avcısı 6
 * BU DOSYA KASITLI HATA İÇERİR: dizi tabanlı yığında yigin_it kapasiteyi
 * denetlemiyor. 4 yuvalık diziye 10 eleman itilince veri[4..9] dizinin
 * SONUNDAN dışarı yazılır: sınır dışı yazma, tanımsız davranış; yazılan
 * yer başka bir bloğun (komsu) bilgisi ya da içeriği olabilir.
 * Program bir süre "doğru" çalışıyor gibi görünebilir; bozulan öbek (heap)
 * bilgisi çoğu zaman ancak free sırasında fark edilir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_HA6_kapasite_asimi.c -o H09_HA6_kapasite_asimi
 * ASan    : ... -O1 -g -fsanitize=address -fno-omit-frame-pointer
 * Düzeltme: H09_HA6_kapasite_asimi_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *veri;
    int kapasite;
    int boyut;
} Yigin;

void yigin_it(Yigin *y, int x)
{
    y->veri[y->boyut] = x;    /* HATA: boyut == kapasite denetlenmiyor */
    y->boyut++;
}

int yigin_cikar(Yigin *y)
{
    if (y->boyut == 0) {
        return -1;
    }
    y->boyut--;
    return y->veri[y->boyut];
}

int main(void)
{
    Yigin y = {malloc(4 * sizeof(int)), 4, 0};
    if (y.veri == NULL) {
        return 1;
    }
    char *komsu = malloc(16);  /* hemen ardından ayrılan başka bir blok */
    if (komsu == NULL) {
        return 1;
    }
    snprintf(komsu, 16, "komşu veri");
    for (int k = 1; k <= 10; k++) {
        yigin_it(&y, 10 * k);
    }
    printf("10 eleman itildi (kapasite 4); boyut = %d\n", y.boyut);
    printf("çıkarılanlar:");
    while (y.boyut > 0) {
        printf(" %d", yigin_cikar(&y));
    }
    printf("\nkomşu blok: \"%s\"\n", komsu);
    free(komsu);
    free(y.veri);
    printf("program sona erdi\n");
    return 0;
}

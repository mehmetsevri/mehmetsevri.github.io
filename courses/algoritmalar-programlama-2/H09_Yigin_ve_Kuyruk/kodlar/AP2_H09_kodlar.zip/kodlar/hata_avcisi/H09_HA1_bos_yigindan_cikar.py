"""H09_HA1_bos_yigindan_cikar.py — AP-2 Hafta 9 · Hata Avcısı 1 (Python)
BU DOSYA KASITLI HATA İÇERİR: yigin_cikar boş yığını denetlemiyor. Python
listesi sınır dışı erişimde IndexError verir ama NEGATİF indis sondan sayar:
boyut -1 olunca veri[-1] dizinin SON yuvasıdır — eski bir değer sessizce
"çıkar" (hayalet değer). Hiçbir hata iletisi görülmez.
Çalıştır: python3 H09_HA1_bos_yigindan_cikar.py
Düzeltme: H09_HA1_bos_yigindan_cikar_duzeltilmis.py
"""


class Yigin:
    __slots__ = ("veri", "kapasite", "boyut")


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [0] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, x):
    if y.boyut < y.kapasite:
        y.veri[y.boyut] = x
        y.boyut += 1


def yigin_cikar(y):
    y.boyut -= 1  # HATA: boş yığın denetlenmiyor
    return y.veri[y.boyut]


def main():
    y = yigin_olustur(4)
    for k in range(1, 5):
        yigin_it(y, 10 * k)
    print("4 eleman itildi; 5 kez çıkarılıyor:",
          " ".join(str(yigin_cikar(y)) for _ in range(5)))
    print(f"boyut = {y.boyut} (boş yığında 0 olmalıydı)")
    yigin_it(y, 50)  # boyut -1 < 4: veri[-1] = son yuvaya yazar
    print(f"50 itildi; boyut = {y.boyut}")
    print(f"iki kez çıkar: {yigin_cikar(y)} {yigin_cikar(y)}; "
          f"boyut = {y.boyut}")
    print("program sona erdi")


if __name__ == "__main__":
    main()

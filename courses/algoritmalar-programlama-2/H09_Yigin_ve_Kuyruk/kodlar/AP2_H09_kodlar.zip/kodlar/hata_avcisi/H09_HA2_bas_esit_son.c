/* H09_HA2_bas_esit_son.c — AP-2 Hafta 9 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR: dairesel kuyruk 4 hücrenin hepsini
 * kullanıyor ve yalnızca bas ile son indislerini tutuyor. Boş kuyrukta da
 * DOLU kuyrukta da bas == son olur: iki durum ayırt edilemez. Dördüncü
 * eklemeden sonra kuyruk "boş" görünür ve elemanlar kaybolur; beşinci ekleme
 * en eski elemanın üzerine yazar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_HA2_bas_esit_son.c \
 *           -o H09_HA2_bas_esit_son
 * Düzeltme: H09_HA2_bas_esit_son_duzeltilmis.c
 */
#include <stdbool.h>
#include <stdio.h>

#define KAPASITE 4

typedef struct {
    int veri[KAPASITE];
    int bas;  /* ilk elemanın indisi */
    int son;  /* sıradaki yazma indisi */
} Kuyruk;

bool kuyruk_bos_mu(const Kuyruk *q) { return q->bas == q->son; }

int kuyruk_boyut(const Kuyruk *q)
{
    return (q->son - q->bas + KAPASITE) % KAPASITE;
}

void kuyruk_ekle(Kuyruk *q, int x)  /* HATA: dolu durumu ayırt edilemiyor */
{
    q->veri[q->son] = x;
    q->son = (q->son + 1) % KAPASITE;
}

bool kuyruk_cikar(Kuyruk *q, int *x)
{
    if (kuyruk_bos_mu(q)) {
        return false;
    }
    *x = q->veri[q->bas];
    q->bas = (q->bas + 1) % KAPASITE;
    return true;
}

static void durum(const Kuyruk *q, const char *olay)
{
    printf("  %s -> bas = %d, son = %d, boyut = %d, boş mu? %s\n", olay,
           q->bas, q->son, kuyruk_boyut(q),
           kuyruk_bos_mu(q) ? "evet" : "hayır");
}

int main(void)
{
    Kuyruk q = {{0}, 0, 0};
    int x;
    durum(&q, "başlangıç");
    for (int k = 1; k <= 4; k++) {
        kuyruk_ekle(&q, 10 * k);
        char olay[16];
        snprintf(olay, sizeof olay, "ekle %d", 10 * k);
        durum(&q, olay);
    }
    printf("  4 eleman eklendi; çıkarılanlar:");
    while (kuyruk_cikar(&q, &x)) {
        printf(" %d", x);
    }
    printf(" (hiçbiri)\n");
    kuyruk_ekle(&q, 50);
    durum(&q, "ekle 50");
    printf("  çıkarılanlar:");
    while (kuyruk_cikar(&q, &x)) {
        printf(" %d", x);
    }
    printf("   (10, 20, 30, 40, 50 bekleniyordu)\n");
    return 0;
}

/* H09_HA6_kapasite_asimi_duzeltilmis.c — AP-2 Hafta 9 · Hata Avcısı 6
 * Düzeltilmiş: yigin_it önce dolu mu diye bakar; taşmayı dönüş koduyla
 * (false) bildirir ve yığını değiştirmez (Örnek 1). Diğer politika: dolunca
 * diziyi iki katına büyütmek (H8 dinamik dizi; amortize O(1)).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_HA6_kapasite_asimi_duzeltilmis.c \
 *           -o H09_HA6_kapasite_asimi_duzeltilmis
 * Hatalı  : H09_HA6_kapasite_asimi.c
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *veri;
    int kapasite;
    int boyut;
} Yigin;

bool yigin_it(Yigin *y, int x)
{
    if (y->boyut == y->kapasite) {
        return false;         /* DÜZELTME: taşma bildirilir */
    }
    y->veri[y->boyut] = x;
    y->boyut++;
    return true;
}

int yigin_cikar(Yigin *y)
{
    if (y->boyut == 0) {
        return -1;
    }
    y->boyut--;
    return y->veri[y->boyut];
}

int main(void)
{
    Yigin y = {malloc(4 * sizeof(int)), 4, 0};
    if (y.veri == NULL) {
        return 1;
    }
    char *komsu = malloc(16);
    if (komsu == NULL) {
        return 1;
    }
    snprintf(komsu, 16, "komşu veri");
    for (int k = 1; k <= 10; k++) {
        if (!yigin_it(&y, 10 * k)) {
            printf("it %d -> reddedildi (taşma: yığın dolu)\n", 10 * k);
        }
    }
    printf("boyut = %d\n", y.boyut);
    printf("çıkarılanlar:");
    while (y.boyut > 0) {
        printf(" %d", yigin_cikar(&y));
    }
    printf("\nkomşu blok: \"%s\"\n", komsu);
    free(komsu);
    free(y.veri);
    printf("program sona erdi\n");
    return 0;
}

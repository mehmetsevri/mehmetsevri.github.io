"""H09_HA5_pop0_kuyruk.py — AP-2 Hafta 9 · Hata Avcısı 5 (Python)
BU DOSYA KASITLI HATA İÇERİR: kuyruk Python listesiyle yazılmış ve
çıkarma list.pop(0) ile yapılıyor. pop(0) baştaki elemanı aldıktan sonra
kalan TÜM başvuruları bir sola kaydırır: her çıkarma O(n), n ekleme + n
çıkarma Θ(n²). Sonuç doğrudur; hata yalnızca süreyle görünür (n iki katına
çıkınca süre ≈ 4 katı). Süreler bu makinede, bu çalıştırmada ölçülmüştür.
Çalıştır: python3 H09_HA5_pop0_kuyruk.py
Düzeltme: H09_HA5_pop0_kuyruk_duzeltilmis.py
"""
import time


def kuyruk_deneyi(n):
    """n ekle, sonra n çıkar; çıkış sırası doğru mu?"""
    kuyruk = []
    for i in range(n):
        kuyruk.append(i)       # sona ekleme: O(1) amortize
    dogru = True
    for i in range(n):
        x = kuyruk.pop(0)      # HATA: baştan çıkarma O(n) — hepsi kayar
        dogru = dogru and x == i
    return dogru


def olc(n, tekrar=5):
    """1 ısınma + tekrar ölçüm; ortanca süre (ms)"""
    kuyruk_deneyi(n)
    sureler = []
    for _ in range(tekrar):
        t0 = time.perf_counter()
        dogru = kuyruk_deneyi(n)
        sureler.append((time.perf_counter() - t0) * 1000)
    sureler.sort()
    return sureler[len(sureler) // 2], dogru


def main():
    print("list.pop(0) ile kuyruk: n ekle + n çıkar")
    print("        n   süre (ms)  önceki n'e göre kat  kaydırılan başvuru")
    onceki = None
    n = 10000
    while n <= 80000:
        ms, dogru = olc(n)
        kat = f"{ms / onceki:8.2f}" if onceki else "       -"
        print(f"  {n:7d} {ms:11.2f} {kat:>21} {n * (n - 1) // 2:19d}"
              + ("" if dogru else "  SIRA YANLIŞ"))
        onceki = ms
        n *= 2


if __name__ == "__main__":
    main()

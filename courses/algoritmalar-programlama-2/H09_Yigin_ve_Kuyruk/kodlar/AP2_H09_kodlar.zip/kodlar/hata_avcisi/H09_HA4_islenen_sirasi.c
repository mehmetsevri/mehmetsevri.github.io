/* H09_HA4_islenen_sirasi.c — AP-2 Hafta 9 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR: sonek değerlendirmede işlenenler ters
 * sırada alınıyor: önce çıkan TEPE değeri a sanılıyor (a = çıkar; b = çıkar;
 * a op b). Değişmeli + ve * doğru sonuç verdiği için hata gizlenir; - / ^
 * yanlış çıkar. Belirteçler boşlukla ayrılmış, negatif olmayan tamsayılar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_HA4_islenen_sirasi.c \
 *           -o H09_HA4_islenen_sirasi
 * Düzeltme: H09_HA4_islenen_sirasi_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static long long yigin[64];  /* işlenen yığını: dizi + tepe indisi */
static int ust = 0;

static long long uygula(char op, long long a, long long b)
{
    long long r = 1;
    if (op == '+') {
        r = a + b;
    } else if (op == '-') {
        r = a - b;
    } else if (op == '*') {
        r = a * b;
    } else if (op == '/') {
        r = a / b;
    } else {
        for (long long k = 0; k < b; k++) {
            r *= a;
        }
    }
    return r;
}

static long long degerlendir(const char *ifade)
{
    char tampon[128];
    strcpy(tampon, ifade);
    ust = 0;
    for (char *bt = strtok(tampon, " "); bt != NULL;
         bt = strtok(NULL, " ")) {
        if (strchr("+-*/^", bt[0]) != NULL && bt[1] == '\0') {
            long long a = yigin[--ust];   /* HATA: tepe a değil, b'dir */
            long long b = yigin[--ust];
            yigin[ust++] = uygula(bt[0], a, b);
        } else {
            yigin[ust++] = strtoll(bt, NULL, 10);
        }
    }
    return yigin[0];
}

int main(void)
{
    const char *ifadeler[] = {"3 4 +", "3 4 *", "10 3 -", "20 4 /",
                              "2 3 ^", "5 1 2 + 4 * + 3 -"};
    const long long beklenen[] = {7, 12, 7, 5, 8, 14};
    for (int k = 0; k < 6; k++) {
        long long r = degerlendir(ifadeler[k]);
        printf("  %-18s = %-4lld (beklenen %lld)%s\n", ifadeler[k], r,
               beklenen[k], r == beklenen[k] ? "" : "   <-- YANLIŞ");
    }
    return 0;
}

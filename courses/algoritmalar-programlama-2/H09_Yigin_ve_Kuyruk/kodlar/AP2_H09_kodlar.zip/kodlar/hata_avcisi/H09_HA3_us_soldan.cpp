/* H09_HA3_us_soldan.cpp — AP-2 Hafta 9 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR: Shunting-yard'da ^ işleci de soldan
 * birleşmeli sayılıyor (eşit öncelikte yığındaki işleç HER ZAMAN önce
 * çıkarılıyor). 2 ^ 3 ^ 2 = 2 ^ (3 ^ 2) = 512 olmalıyken (2 ^ 3) ^ 2 = 64
 * hesaplanır. Basit tutmak için belirteçler tek karakterdir (0-9).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H09_HA3_us_soldan.cpp \
 *           -o H09_HA3_us_soldan
 * Düzeltme: H09_HA3_us_soldan_duzeltilmis.cpp
 */
#include <iostream>
#include <string>

static int oncelik(char op)
{
    if (op == '+' || op == '-') {
        return 1;
    }
    return (op == '*' || op == '/') ? 2 : 3;  // ^ en yüksek
}

// HATA: birleşme yönüne bakılmıyor; ^ için de >= ile çıkarılıyor
static bool once_cikar_mi(char ust, char gelen)
{
    return oncelik(ust) >= oncelik(gelen);
}

static void yaz(std::string& cikti, char c)
{
    cikti += (cikti.empty() ? "" : " ") + std::string(1, c);
}

static std::string sonege_cevir(const std::string& s)
{
    std::string cikti;
    char yigin[64];  // işleç yığını (elle: dizi + tepe indisi)
    int ust = 0;
    for (char c : s) {
        if (c >= '0' && c <= '9') {
            yaz(cikti, c);
        } else if (c == '(') {
            yigin[ust++] = c;
        } else if (c == ')') {
            while (yigin[ust - 1] != '(') {
                yaz(cikti, yigin[--ust]);
            }
            ust--;  // '(' atılır
        } else if (c != ' ') {
            while (ust > 0 && yigin[ust - 1] != '(' &&
                   once_cikar_mi(yigin[ust - 1], c)) {
                yaz(cikti, yigin[--ust]);
            }
            yigin[ust++] = c;
        }
    }
    while (ust > 0) {
        yaz(cikti, yigin[--ust]);
    }
    return cikti;
}

static long long hesapla(const std::string& sonek)
{
    long long y[64];  // işlenen yığını
    int ust = 0;
    for (char c : sonek) {
        if (c == ' ') {
            continue;
        }
        if (c >= '0' && c <= '9') {
            y[ust++] = c - '0';
            continue;
        }
        long long b = y[--ust];
        long long a = y[--ust];
        long long r = 1;
        if (c == '+') {
            r = a + b;
        } else if (c == '-') {
            r = a - b;
        } else if (c == '*') {
            r = a * b;
        } else if (c == '/') {
            r = a / b;
        } else {
            for (long long k = 0; k < b; k++) {
                r *= a;
            }
        }
        y[ust++] = r;
    }
    return y[0];
}

int main()
{
    const char *ifadeler[] = {"2 ^ 3 ^ 2", "2 ^ 2 ^ 3", "4 ^ 3 ^ 2",
                              "2 * 3 ^ 2", "8 - 4 - 2", "(2 ^ 3) ^ 2"};
    for (const char *s : ifadeler) {
        std::string sonek = sonege_cevir(s);
        std::cout << "  " << s << "  ->  sonek " << sonek << "  =  "
                  << hesapla(sonek) << "\n";
    }
    return 0;
}

"""H09_HA1_bos_yigindan_cikar_duzeltilmis.py — AP-2 Hafta 9 · Hata Avcısı 1
Düzeltilmiş: yigin_cikar önce boş mu diye bakar; alt taşmayı (False, 0)
dönüşüyle bildirir (Örnek 1'in sözleşmesi). Python'a özgü seçenek:
IndexError istisnası atmak (yerleşik list.pop() böyle yapar).
Çalıştır: python3 H09_HA1_bos_yigindan_cikar_duzeltilmis.py
Hatalı  : H09_HA1_bos_yigindan_cikar.py
"""


class Yigin:
    __slots__ = ("veri", "kapasite", "boyut")


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [0] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, x):
    if y.boyut == y.kapasite:
        return False
    y.veri[y.boyut] = x
    y.boyut += 1
    return True


def yigin_cikar(y):
    if y.boyut == 0:
        return False, 0  # DÜZELTME: alt taşma bildirilir
    y.boyut -= 1
    return True, y.veri[y.boyut]


def main():
    y = yigin_olustur(4)
    for k in range(1, 5):
        yigin_it(y, 10 * k)
    parcalar = []
    for _ in range(5):
        tamam, x = yigin_cikar(y)
        parcalar.append(str(x) if tamam else "[alt taşma: yığın boş]")
    print("4 eleman itildi; 5 kez çıkarılıyor:", " ".join(parcalar))
    print(f"boyut = {y.boyut}")
    yigin_it(y, 50)
    print(f"50 itildi; boyut = {y.boyut}")
    _, x1 = yigin_cikar(y)
    tamam2, _ = yigin_cikar(y)
    print(f"iki kez çıkar: {x1} "
          + ("?" if tamam2 else "[alt taşma: yığın boş]")
          + f"; boyut = {y.boyut}")
    try:
        [].pop()
    except IndexError as e:
        print(f"yerleşik list.pop() boş listede: IndexError: {e}")
    print("program sona erdi")


if __name__ == "__main__":
    main()

"""H09_HA5_pop0_kuyruk_duzeltilmis.py — AP-2 Hafta 9 · Hata Avcısı 5
Düzeltilmiş: (1) elle yazılmış dairesel tampon kuyruk (Örnek 8): ekleme ve
çıkarma O(1), hiçbir eleman kaydırılmaz; (2) kütüphane karşılığı
collections.deque.popleft() — O(1). n iki katına çıkınca süre ≈ 2 katı.
Süreler bu makinede, bu çalıştırmada ölçülmüştür.
Çalıştır: python3 H09_HA5_pop0_kuyruk_duzeltilmis.py
Hatalı  : H09_HA5_pop0_kuyruk.py
"""
import time
from collections import deque


class Kuyruk:
    __slots__ = ("veri", "kapasite", "bas", "son", "sayac")


def kuyruk_olustur(kapasite):
    q = Kuyruk()
    q.veri = [0] * kapasite
    q.kapasite = kapasite
    q.bas = q.son = q.sayac = 0
    return q


def kuyruk_ekle(q, x):
    if q.sayac == q.kapasite:
        return False
    q.veri[q.son] = x
    q.son = (q.son + 1) % q.kapasite
    q.sayac += 1
    return True


def kuyruk_cikar(q):
    if q.sayac == 0:
        return False, 0
    x = q.veri[q.bas]
    q.bas = (q.bas + 1) % q.kapasite  # DÜZELTME: kaydırma yok, indis ilerler
    q.sayac -= 1
    return True, x


def dairesel_deneyi(n):
    q = kuyruk_olustur(n)
    for i in range(n):
        kuyruk_ekle(q, i)
    dogru = True
    for i in range(n):
        dogru = dogru and kuyruk_cikar(q)[1] == i
    return dogru


def deque_deneyi(n):
    q = deque()
    for i in range(n):
        q.append(i)
    dogru = True
    for i in range(n):
        dogru = dogru and q.popleft() == i  # O(1)
    return dogru


def olc(gorev, n, tekrar=5):
    """1 ısınma + tekrar ölçüm; ortanca süre (ms)"""
    gorev(n)
    sureler = []
    for _ in range(tekrar):
        t0 = time.perf_counter()
        dogru = gorev(n)
        sureler.append((time.perf_counter() - t0) * 1000)
    sureler.sort()
    return sureler[len(sureler) // 2], dogru


def main():
    for ad, gorev in (("elle dairesel tampon", dairesel_deneyi),
                      ("collections.deque (kütüphane)", deque_deneyi)):
        print(f"{ad}: n ekle + n çıkar")
        print("        n   süre (ms)  önceki n'e göre kat")
        onceki = None
        n = 10000
        while n <= 80000:
            ms, dogru = olc(gorev, n)
            kat = f"{ms / onceki:8.2f}" if onceki else "       -"
            print(f"  {n:7d} {ms:11.2f} {kat:>21}"
                  + ("" if dogru else "  SIRA YANLIŞ"))
            onceki = ms
            n *= 2


if __name__ == "__main__":
    main()

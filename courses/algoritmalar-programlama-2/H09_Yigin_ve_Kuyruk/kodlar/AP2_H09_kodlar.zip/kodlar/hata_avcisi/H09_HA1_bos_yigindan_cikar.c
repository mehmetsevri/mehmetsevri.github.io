/* H09_HA1_bos_yigindan_cikar.c — AP-2 Hafta 9 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR: yigin_cikar boş yığını denetlemiyor
 * (alt taşma). boyut -1 olur ve veri[-1] okunur: dizinin ÖNÜNDEN sınır dışı
 * okuma, tanımsız davranış. Ardından gelen it veri[-1]'e YAZAR.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_HA1_bos_yigindan_cikar.c -o H09_HA1_bos_yigindan_cikar
 * ASan    : ... -O1 -g -fsanitize=address -fno-omit-frame-pointer
 * Düzeltme: H09_HA1_bos_yigindan_cikar_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *veri;
    int kapasite;
    int boyut;
} Yigin;

void yigin_it(Yigin *y, int x)
{
    if (y->boyut < y->kapasite) {
        y->veri[y->boyut++] = x;
    }
}

int yigin_cikar(Yigin *y)
{
    y->boyut--;               /* HATA: boş yığın denetlenmiyor */
    return y->veri[y->boyut];
}

int main(void)
{
    Yigin y = {malloc(4 * sizeof(int)), 4, 0};
    if (y.veri == NULL) {
        return 1;
    }
    for (int k = 1; k <= 4; k++) {
        yigin_it(&y, 10 * k);
    }
    printf("4 eleman itildi; 5 kez çıkarılıyor:");
    for (int k = 0; k < 5; k++) {
        printf(" %d", yigin_cikar(&y));
    }
    printf("\nboyut = %d (boş yığında 0 olmalıydı)\n", y.boyut);
    yigin_it(&y, 50);         /* boyut -1 < 4: veri[-1]'e yazar! */
    printf("50 itildi; boyut = %d\n", y.boyut);
    int x = yigin_cikar(&y);
    printf("tepe çıkarıldı: %d; boyut = %d\n", x, y.boyut);
    free(y.veri);
    printf("program sona erdi\n");
    return 0;
}

/*
 * zamanlayici.hpp — AP-2 ortak zaman ölçüm modülü (C++17, yalnız başlık)
 *
 * Amaç   : Algoritma deneylerinde süre ölçümü. Süreler stderr'e yazılır;
 *          stdout'a yalnızca deterministik sonuçlar yazılır.
 * Kaynak : std::chrono::steady_clock (monotonik saat) ve std::clock().
 * Eşleri : zamanlayici.h/.c (C), zamanlayici.py (Python)
 */
#ifndef ZAMANLAYICI_HPP
#define ZAMANLAYICI_HPP

#include <chrono>
#include <cstddef>
#include <ctime>
#include <vector>

// Monotonik saat zamanı (saniye). İki çağrının farkı geçen süreyi verir.
inline double zaman_sn()
{
    auto simdi = std::chrono::steady_clock::now().time_since_epoch();
    return std::chrono::duration<double>(simdi).count();
}

// Bu sürecin kullandığı işlemci zamanı (saniye).
inline double islemci_sn()
{
    return static_cast<double>(std::clock()) / CLOCKS_PER_SEC;
}

// x değerlerinin ortancasını döndürür (x kopya olarak alınır).
inline double ortanca(std::vector<double> x)
{
    // Küçük n için araya ekleme sıralaması (yardımcı; ders konusu H5)
    for (std::size_t i = 1; i < x.size(); i++) {
        double anahtar = x[i];
        std::size_t j = i;
        while (j > 0 && x[j - 1] > anahtar) {
            x[j] = x[j - 1];
            j--;
        }
        x[j] = anahtar;
    }
    std::size_t n = x.size();
    if (n % 2 == 1) {
        return x[n / 2];
    }
    return (x[n / 2 - 1] + x[n / 2]) / 2.0;
}

// gorev() çağrısını önce 1 kez ısınma, sonra tekrar kez çalıştırır;
// ölçülen sürelerin ortancasını (saniye) döndürür.
template <class Gorev>
double olc_ortanca(Gorev gorev, int tekrar)
{
    if (tekrar < 1) {
        tekrar = 1;
    }
    std::vector<double> sureler;
    gorev(); // ısınma
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn();
        gorev();
        sureler.push_back(zaman_sn() - t0);
    }
    return ortanca(sureler);
}

#endif // ZAMANLAYICI_HPP

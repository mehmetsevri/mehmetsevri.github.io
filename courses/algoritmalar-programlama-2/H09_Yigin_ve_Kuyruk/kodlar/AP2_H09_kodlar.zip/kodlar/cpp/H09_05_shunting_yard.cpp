/* H09_05_shunting_yard.cpp — AP-2 Hafta 9 · Örnek 5 (★★★)
 * Amaç    : Dijkstra'nın manevra sahası (Shunting-yard) algoritmasıyla araek
 *           (infix) → sonek (postfix) dönüşümü: öncelik ve birleşme yönü
 *           tablosu (^ sağdan birleşmeli), tekli eksi ayrı işleç (~),
 *           sözdizimi ve parantez hataları
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_05_shunting_yard.cpp -o H09_05_shunting_yard
 * Çalıştır: ./H09_05_shunting_yard < ../girdiler/H09_05_shunting_yard.txt
 * Eşleri  : c/H09_05_shunting_yard.c · python/H09_05_shunting_yard.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

static const char *const IZ_BASLIK =
    "    belirteç işleç yığını   çıktı                eylem";

enum { SAYI, AD, ISLEC, SOL_PAR, SAG_PAR };
enum { HATA_YOK, GECERSIZ_KARAKTER, ISLENEN_BEKLENIYOR, ISLEC_BEKLENIYOR,
       ESLESMEYEN_KAPANIS, ACIK_PARANTEZ, BOS_IFADE };

static const char *const HATA_ILETISI[] = {
    "yok", "geçersiz karakter", "işlenen bekleniyordu",
    "işleç bekleniyordu", "eşleşmeyen ')'", "kapanmamış '('",
    "boş ifade"};

struct Belirtec {
    int tur;
    int bas, uz;  // girdideki yeri: s[bas .. bas+uz-1]
    char islec;   // + - * / ^ ve tekli eksi için ~
};

struct Yigin {
    std::vector<int> veri;  // işleç yığını belirteç indislerini tutar
    int kapasite = 0;
    int boyut = 0;
};

static long long it_sayisi = 0, cikar_sayisi = 0;
static int en_buyuk_derinlik = 0;

static bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite, 0);
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;
}

static bool yigin_it(Yigin& y, int x)
{
    if (y.boyut == y.kapasite) {
        return false;
    }
    y.veri[y.boyut++] = x;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
    return true;
}

static bool yigin_cikar(Yigin& y, int& x)
{
    if (y.boyut == 0) {
        return false;
    }
    x = y.veri[--y.boyut];
    cikar_sayisi++;
    return true;
}

static bool yigin_tepe(const Yigin& y, int& x)
{
    if (y.boyut == 0) {
        return false;
    }
    x = y.veri[y.boyut - 1];
    return true;
}

// Öncelik ve birleşme yönü tablosu
static int oncelik(char op)
{
    if (op == '+' || op == '-') {
        return 1;
    }
    if (op == '*' || op == '/') {
        return 2;
    }
    return op == '~' ? 3 : 4;  // ~ tekli eksi, ^ üs
}

static bool sag_birlesmeli(char op) { return op == '^' || op == '~'; }

// Yığının tepesindeki ust, gelen işleçten önce çıktıya gitmeli mi?
static bool once_cikar_mi(char ust, char gelen)
{
    return oncelik(ust) > oncelik(gelen) ||
           (oncelik(ust) == oncelik(gelen) && !sag_birlesmeli(gelen));
}

// s belirteçlere ayrılır; işlenen/işleç sırası denetlenir
static int belirtecle(const std::string& s, std::vector<Belirtec>& b,
                      int& sutun)
{
    int n = static_cast<int>(s.size());
    bool islenen_bekleniyor = true;
    int i = 0;
    b.clear();
    while (i < n) {
        char c = s[i];
        if (c == ' ' || c == '\t') {
            i++;
            continue;
        }
        Belirtec t{SAYI, i, 1, c};
        if (c >= '0' && c <= '9') {
            while (i + t.uz < n && s[i + t.uz] >= '0' && s[i + t.uz] <= '9') {
                t.uz++;
            }
        } else if (c >= 'a' && c <= 'z') {
            t.tur = AD;
        } else if (c == '(' || c == ')') {
            t.tur = (c == '(') ? SOL_PAR : SAG_PAR;
        } else if (std::string("+-*/^").find(c) != std::string::npos) {
            t.tur = ISLEC;
            if (c == '-' && islenen_bekleniyor) {
                t.islec = '~';  // başta, '(' ya da işleçten sonra: tekli
            }
        } else {
            sutun = i + 1;
            return GECERSIZ_KARAKTER;
        }
        sutun = i + 1;
        if (islenen_bekleniyor) {
            if (t.tur == SAG_PAR || (t.tur == ISLEC && t.islec != '~')) {
                return ISLENEN_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == SOL_PAR || t.tur == ISLEC);
        } else {
            if (t.tur == SAYI || t.tur == AD || t.tur == SOL_PAR) {
                return ISLEC_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == ISLEC);
        }
        b.push_back(t);
        i += t.uz;
    }
    sutun = n + 1;
    if (islenen_bekleniyor) {
        return b.empty() ? BOS_IFADE : ISLENEN_BEKLENIYOR;
    }
    return HATA_YOK;
}

// Belirtecin metni: sayı ve adlar girdiden, işleçler tek karakter
static std::string metin(const std::string& s, const Belirtec& t)
{
    if (t.tur == SAYI || t.tur == AD) {
        return s.substr(t.bas, t.uz);
    }
    return std::string(1, t.islec);
}

static void iz_satiri(const std::string& bt, const Yigin& y,
                      const std::vector<Belirtec>& b,
                      const std::vector<int>& cikti, const std::string& s,
                      const std::string& eylem)
{
    std::string yg = "[", ck;
    for (int j = 0; j < y.boyut; j++) {
        yg += (j > 0 ? " " : "") + metin(s, b[y.veri[j]]);
    }
    yg += "]";
    for (std::size_t j = 0; j < cikti.size(); j++) {
        ck += (j > 0 ? " " : "") + metin(s, b[cikti[j]]);
    }
    std::cout << "    " << std::left << std::setw(8) << bt << " "
              << std::setw(14) << yg << " " << std::setw(20) << ck
              << std::right << " " << eylem << "\n";
}

// Shunting-yard: b → cikti (belirteç indisleri)
int sonege_cevir(const std::vector<Belirtec>& b, std::vector<int>& cikti,
                 int& sutun, const std::string& s, bool iz)
{
    int m = static_cast<int>(b.size());
    Yigin y;
    int hata = HATA_YOK, j;
    yigin_olustur(y, m + 1);
    cikti.clear();
    for (int i = 0; i < m && hata == HATA_YOK; i++) {
        const Belirtec& t = b[i];
        std::string eylem;
        if (t.tur == SAYI || t.tur == AD) {
            cikti.push_back(i);
            eylem = "çıktıya yaz";
        } else if (t.tur == SOL_PAR) {
            yigin_it(y, i);
            eylem = "it (";
        } else if (t.tur == SAG_PAR) {
            eylem = "çıkar:";
            while (yigin_tepe(y, j) && b[j].tur != SOL_PAR) {
                yigin_cikar(y, j);
                cikti.push_back(j);
                eylem += " " + metin(s, b[j]);
            }
            if (!yigin_cikar(y, j)) {
                hata = ESLESMEYEN_KAPANIS;
                sutun = t.bas + 1;
            }
            eylem += (hata == HATA_YOK) ? "; ( atılır" : "; ( yok!";
        } else if (t.islec == '~') {
            yigin_it(y, i);  // önek işleç: hiçbir şeyi çıkarmaz
            eylem = "it ~ (tekli eksi)";
        } else {
            while (yigin_tepe(y, j) && b[j].tur == ISLEC &&
                   once_cikar_mi(b[j].islec, t.islec)) {
                yigin_cikar(y, j);
                cikti.push_back(j);
                eylem += (eylem.empty() ? "çıkar: " : " ") + metin(s, b[j]);
            }
            eylem += (eylem.empty() ? "it " : "; it ") + metin(s, t);
            yigin_it(y, i);
        }
        if (iz) {
            iz_satiri(metin(s, t), y, b, cikti, s, eylem);
        }
    }
    if (hata == HATA_YOK) {
        std::string eylem = "boşalt:";
        while (yigin_cikar(y, j)) {
            if (b[j].tur == SOL_PAR) {
                hata = ACIK_PARANTEZ;
                sutun = b[j].bas + 1;
                eylem += " ( kapanmamış!";
                break;
            }
            cikti.push_back(j);
            eylem += " " + metin(s, b[j]);
        }
        if (iz) {
            iz_satiri("(son)", y, b, cikti, s, eylem);
        }
    }
    return hata;
}

static bool satir_isle(const std::string& s, bool iz)
{
    std::vector<Belirtec> b;
    std::vector<int> cikti;
    int sutun = 0;
    it_sayisi = cikar_sayisi = 0;
    en_buyuk_derinlik = 0;
    if (iz) {
        std::cout << "  " << s << "\n" << IZ_BASLIK << "\n";
    }
    int hata = belirtecle(s, b, sutun);
    if (hata == HATA_YOK) {
        hata = sonege_cevir(b, cikti, sutun, s, iz);
    }
    if (iz) {
        std::cout << "    sonuç: ";
    } else {
        std::cout << "  " << std::left << std::setw(22) << s << std::right
                  << " ";
    }
    if (hata != HATA_YOK) {
        std::cout << "-> HATA sütun " << sutun << ": " << HATA_ILETISI[hata]
                  << "\n";
        return false;
    }
    std::string ck;
    for (std::size_t j = 0; j < cikti.size(); j++) {
        ck += (j > 0 ? " " : "") + metin(s, b[cikti[j]]);
    }
    std::cout << "-> " << ck << "   [belirteç " << b.size() << ", it "
              << it_sayisi << ", çıkar " << cikar_sayisi << ", derinlik "
              << en_buyuk_derinlik << "]\n";
    return true;
}

int main()
{
    std::string satir;
    int gecerli = 0, toplam = 0;
    std::cout << "1) Öncelik ve birleşme yönü tablosu\n";
    std::cout << "  işleç  öncelik  birleşme\n";
    for (char op : std::string("+-*/~^")) {
        std::cout << "    " << op << "       " << oncelik(op) << "     "
                  << (sag_birlesmeli(op) ? "sağdan" : "soldan") << "\n";
    }
    std::cout << "  (~ tekli eksidir: başta, '(' ya da işleçten sonra gelen "
                 "'-')\n";

    std::cout << "\n2) Adım adım dönüşüm (her belirteçten sonra yığın ve "
                 "çıktı)\n";
    satir_isle("3 + 4 * 2", true);
    satir_isle("(1 + 2) * 3", true);
    satir_isle("2 ^ 3 ^ 2", true);
    satir_isle("a - b - c", true);

    std::cout << "\n3) Girdi dosyasındaki ifadeler\n";
    while (std::getline(std::cin, satir)) {
        gecerli += satir_isle(satir, false);
        toplam++;
    }
    std::cout << "  toplam " << toplam << " ifade: dönüştürülen " << gecerli
              << ", hatalı " << toplam - gecerli << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack yalnızca
 * işleç yığınını sağlar); Python — yok (ast modülü ifadeyi ayrıştırır ama
 * sonek üretmez). Derleyicilerin ayrıştırıcıları aynı öncelik/birleşme
 * kurallarını uygular. */

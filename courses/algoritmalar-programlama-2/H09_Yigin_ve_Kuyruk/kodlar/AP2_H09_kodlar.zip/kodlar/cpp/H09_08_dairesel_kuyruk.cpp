/* H09_08_dairesel_kuyruk.cpp — AP-2 Hafta 9 · Örnek 8 (★★)
 * Amaç    : Dairesel tampon (circular buffer) kuyruk: bas/son indisleri ve
 *           mod aritmetiği; dolu/boş ayrımı iki yöntemle: (A) eleman sayacı,
 *           (B) bir hücre boş bırakılır. Kapasite 2'nin kuvvetiyse mod
 *           yerine bit maskesi. Rastgele işlem dizisiyle kâhinli sınama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_08_dairesel_kuyruk.cpp -o H09_08_dairesel_kuyruk
 * Çalıştır: ./H09_08_dairesel_kuyruk
 * Eşleri  : c/H09_08_dairesel_kuyruk.c · python/H09_08_dairesel_kuyruk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

// (A) Sayaçlı: veri[bas], ..., veri[son - 1] (mod kapasite) doludur
struct Kuyruk {
    std::vector<int> veri;  // sabit uzunluk: kapasite
    int kapasite = 0;
    int bas = 0;           // ilk (en eski) elemanın indisi
    int son = 0;           // sıradaki yazma indisi
    int sayac = 0;         // eleman sayısı: dolu/boş ayrımını bu yapar
    bool maskeli = false;  // kapasite 2'nin kuvveti: & (kapasite - 1)
};

// (B) Bir boş hücreli: hucre = kapasite + 1; bas == son ise boş
struct KuyrukBH {
    std::vector<int> veri;
    int hucre = 0;
    int bas = 0;
    int son = 0;
};

static long long ekle_sayisi = 0, cikar_sayisi = 0, sarma_sayisi = 0;

bool kuyruk_olustur(Kuyruk& q, int kapasite)
{
    q.veri.assign(kapasite, 0);
    q.kapasite = kapasite;
    q.bas = q.son = q.sayac = 0;
    q.maskeli = (kapasite & (kapasite - 1)) == 0;
    return true;
}

bool kuyruk_bos_mu(const Kuyruk& q) { return q.sayac == 0; }

bool kuyruk_dolu_mu(const Kuyruk& q) { return q.sayac == q.kapasite; }

// Sonraki indis: son hücreden sonra 0'a sarar
static int ilerle(const Kuyruk& q, int i)
{
    if (i + 1 == q.kapasite) {
        sarma_sayisi++;
    }
    if (q.maskeli) {
        return (i + 1) & (q.kapasite - 1);
    }
    return (i + 1) % q.kapasite;
}

// Dolu kuyrukta false döner (taşma politikası: reddet)
bool kuyruk_ekle(Kuyruk& q, int x)
{
    if (kuyruk_dolu_mu(q)) {
        return false;
    }
    q.veri[q.son] = x;
    q.son = ilerle(q, q.son);
    q.sayac++;
    ekle_sayisi++;
    return true;
}

// Boş kuyrukta false döner; x değişmez
bool kuyruk_cikar(Kuyruk& q, int& x)
{
    if (kuyruk_bos_mu(q)) {
        return false;
    }
    x = q.veri[q.bas];
    q.bas = ilerle(q, q.bas);
    q.sayac--;
    cikar_sayisi++;
    return true;
}

// ---- (B) bir boş hücre: sayaç yok; dolu iken bir hücre kullanılmaz ----
bool bh_olustur(KuyrukBH& q, int kapasite)
{
    q.veri.assign(kapasite + 1, 0);
    q.hucre = kapasite + 1;
    q.bas = q.son = 0;
    return true;
}

bool bh_bos_mu(const KuyrukBH& q) { return q.bas == q.son; }

bool bh_dolu_mu(const KuyrukBH& q) { return (q.son + 1) % q.hucre == q.bas; }

int bh_boyut(const KuyrukBH& q) { return (q.son - q.bas + q.hucre) % q.hucre; }

bool bh_ekle(KuyrukBH& q, int x)
{
    if (bh_dolu_mu(q)) {
        return false;
    }
    q.veri[q.son] = x;
    q.son = (q.son + 1) % q.hucre;
    return true;
}

bool bh_cikar(KuyrukBH& q, int& x)
{
    if (bh_bos_mu(q)) {
        return false;
    }
    x = q.veri[q.bas];
    q.bas = (q.bas + 1) % q.hucre;
    return true;
}

// Fiziksel diziyi yazar: dolu hücre değeriyle, boş hücre '.' ile
static std::string dizi_metni(const std::vector<int>& veri, int hucre,
                              int bas, int boyut)
{
    std::string m = "[";
    for (int i = 0; i < hucre; i++) {
        m += (i > 0 ? " " : "");
        if ((i - bas + hucre) % hucre < boyut) {
            m += std::to_string(veri[i]);
        } else {
            m += ".";
        }
    }
    return m + "]";
}

static void satir_yaz(int bas, int son, int boyut, const std::string& dizi,
                      const std::string& islem)
{
    std::cout << "    " << std::setw(3) << bas << " " << std::setw(3) << son
              << " " << std::setw(5) << boyut << "   " << std::left
              << std::setw(16) << dizi << std::right << " " << islem << "\n";
}

static void izle_sayacli()
{
    const int adim[] = {10, 20, 30, 40, 50, 0, 0, 50, 60, 70, 0, 0, 0, 0, 0};
    Kuyruk q;
    kuyruk_olustur(q, 4);
    std::cout << "  (A) sayaçlı, kapasite 4 (2'nin kuvveti: & 3 ile "
                 "ilerler)\n";
    std::cout << "    bas son sayaç   fiziksel dizi    işlem\n";
    satir_yaz(q.bas, q.son, q.sayac, dizi_metni(q.veri, 4, q.bas, q.sayac),
              "(başlangıç: bas == son, boş)");
    for (int k = 0; k < 15; k++) {
        long long sarma0 = sarma_sayisi;
        int x;
        std::string islem;
        if (adim[k] > 0) {
            bool tamam = kuyruk_ekle(q, adim[k]);
            islem = "ekle " + std::to_string(adim[k]) +
                    (tamam ? "" : " -> dolu, reddedildi");
        } else if (kuyruk_cikar(q, x)) {
            islem = "çıkar -> " + std::to_string(x);
        } else {
            islem = "çıkar -> boş, reddedildi";
        }
        if (sarma_sayisi > sarma0) {
            islem += "  (sarma)";
        }
        if (q.bas == q.son) {
            islem += q.sayac == 0 ? "  [bas == son, sayaç 0: boş]"
                                  : "  [bas == son, sayaç 4: dolu]";
        }
        satir_yaz(q.bas, q.son, q.sayac,
                  dizi_metni(q.veri, 4, q.bas, q.sayac), islem);
    }
}

static void izle_bos_hucreli()
{
    const int adim[] = {10, 20, 30, 40, 50, 0, 0, 50, 60, 0, 0, 0, 0, 0};
    KuyrukBH q;
    bh_olustur(q, 4);
    std::cout << "  (B) bir boş hücreli, kapasite 4 (5 hücre, % 5 ile "
                 "ilerler)\n";
    std::cout << "    bas son boyut   fiziksel dizi    işlem\n";
    for (int k = 0; k < 14; k++) {
        int x;
        std::string islem;
        if (adim[k] > 0) {
            bool tamam = bh_ekle(q, adim[k]);
            islem = "ekle " + std::to_string(adim[k]) +
                    (tamam ? "" : " -> dolu, reddedildi");
        } else if (bh_cikar(q, x)) {
            islem = "çıkar -> " + std::to_string(x);
        } else {
            islem = "çıkar -> boş, reddedildi";
        }
        if (bh_dolu_mu(q)) {
            islem += "  [(son + 1) % 5 == bas: dolu]";
        }
        satir_yaz(q.bas, q.son, bh_boyut(q),
                  dizi_metni(q.veri, 5, q.bas, bh_boyut(q)), islem);
    }
}

// Kâhin: std::queue<int> (kapasite sınırı elle uygulanır)
static void rastgele_sinama(int islem, int kapasite)
{
    Kuyruk q;
    KuyrukBH b;
    std::queue<int> kahin;
    kuyruk_olustur(q, kapasite);
    bh_olustur(b, kapasite);
    int uyusmazlik = 0, dolu = 0, bos = 0;
    long long sarma0 = sarma_sayisi;
    rastgele_tohum(42);
    for (int t = 0; t < islem; t++) {
        if (rastgele_aralik(0, 99) < 55) {
            int v = rastgele_aralik(0, 999);
            bool ra = kuyruk_ekle(q, v), rb = bh_ekle(b, v);
            bool rk = static_cast<int>(kahin.size()) < kapasite;
            if (rk) {
                kahin.push(v);
            }
            dolu += !rk;
            uyusmazlik += (ra != rk) || (rb != rk);
        } else {
            int xa = -1, xb = -1, xk = -1;
            bool ra = kuyruk_cikar(q, xa), rb = bh_cikar(b, xb);
            bool rk = !kahin.empty();
            if (rk) {
                xk = kahin.front();
                kahin.pop();
            }
            bos += !rk;
            uyusmazlik += (ra != rk) || (rb != rk) || xa != xk || xb != xk;
        }
    }
    std::cout << "  kapasite " << std::setw(4) << kapasite << " ("
              << (q.maskeli ? "maske" : "mod  ") << "): dolu reddi "
              << std::setw(5) << dolu << ", boş reddi " << std::setw(5)
              << bos << ", sarma " << std::setw(6) << sarma_sayisi - sarma0
              << ", uyuşmazlık " << uyusmazlik << "\n";
}

int main()
{
    std::cout << "1) Adım adım: bas, son ve dolu/boş ayrımı\n";
    izle_sayacli();
    std::cout << "\n";
    izle_bos_hucreli();

    std::cout << "\n2) Rastgele 100000 işlem (%55 ekle, tohum 42): (A) ve "
                 "(B) kâhinle\n";
    rastgele_sinama(100000, 4);
    rastgele_sinama(100000, 6);
    rastgele_sinama(100000, 8);
    rastgele_sinama(100000, 1024);
    std::cout << "  toplam (A): ekle = " << ekle_sayisi << ", çıkar = "
              << cikar_sayisi << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int> (kap
 * uyarlayıcısı; varsayılan alttaki kap std::deque, kapasite sınırı yok);
 * Python — collections.deque (maxlen verilirse dolunca EN ESKİ eleman
 * sessizce atılır: taşma politikası "üzerine yaz"). */

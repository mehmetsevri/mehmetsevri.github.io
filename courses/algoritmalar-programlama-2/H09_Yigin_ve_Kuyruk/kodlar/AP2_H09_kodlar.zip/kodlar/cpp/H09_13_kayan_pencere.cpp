/* H09_13_kayan_pencere.cpp — AP-2 Hafta 9 · Örnek 13 (★★★)
 * Amaç    : İki uçlu kuyruk (deque) ile kayan pencere en büyüğü: deque'da
 *           penceredeki indisler değerleri azalan sırada tutulur (monotonik
 *           deque); önde pencereden çıkan indis, arkada yeni elemandan küçük
 *           ya da eşit olanlar atılır → Θ(n), ek bellek O(k). Deque elle,
 *           dairesel tamponla (kapasite k); O(nk) kaba kuvvet kâhinle sınama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_13_kayan_pencere.cpp -o H09_13_kayan_pencere
 * Çalıştır: ./H09_13_kayan_pencere
 * Eşleri  : c/H09_13_kayan_pencere.c · python/H09_13_kayan_pencere.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

// İki uçlu kuyruk: veri[bas], veri[bas+1], ... (mod kapasite), sayac eleman
struct Deque {
    std::vector<int> veri;  // sabit uzunluk: kapasite
    int kapasite = 0;
    int bas = 0;
    int sayac = 0;
};

static long long ekle_sayisi = 0, cikar_sayisi = 0, karsilastirma = 0;
static long long kaba_karsilastirma = 0;
static int en_buyuk_boyut = 0;

static void sayaclari_sifirla()
{
    ekle_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0;
    en_buyuk_boyut = 0;
}

bool deque_olustur(Deque& d, int kapasite)
{
    d.veri.assign(kapasite, 0);
    d.kapasite = kapasite;
    d.bas = d.sayac = 0;
    return true;
}

bool deque_bos_mu(const Deque& d) { return d.sayac == 0; }

static void boyut_guncelle(const Deque& d)
{
    ekle_sayisi++;
    if (d.sayac > en_buyuk_boyut) {
        en_buyuk_boyut = d.sayac;
    }
}

bool arkaya_ekle(Deque& d, int x)
{
    if (d.sayac == d.kapasite) {
        return false;
    }
    d.veri[(d.bas + d.sayac) % d.kapasite] = x;
    d.sayac++;
    boyut_guncelle(d);
    return true;
}

bool one_ekle(Deque& d, int x)
{
    if (d.sayac == d.kapasite) {
        return false;
    }
    d.bas = (d.bas - 1 + d.kapasite) % d.kapasite;  // geriye sarma
    d.veri[d.bas] = x;
    d.sayac++;
    boyut_guncelle(d);
    return true;
}

bool arkadan_cikar(Deque& d, int& x)
{
    if (d.sayac == 0) {
        return false;
    }
    d.sayac--;
    x = d.veri[(d.bas + d.sayac) % d.kapasite];
    cikar_sayisi++;
    return true;
}

bool onden_cikar(Deque& d, int& x)
{
    if (d.sayac == 0) {
        return false;
    }
    x = d.veri[d.bas];
    d.bas = (d.bas + 1) % d.kapasite;
    d.sayac--;
    cikar_sayisi++;
    return true;
}

int deque_on(const Deque& d) { return d.veri[d.bas]; }

int deque_arka(const Deque& d)
{
    return d.veri[(d.bas + d.sayac - 1) % d.kapasite];
}

static bool kucuk_esit_mi(int x, int y)
{
    karsilastirma++;
    return x <= y;
}

// en_buyuk[i] = max(a[i..i+k-1]), i = 0..n-k (1 <= k <= n)
void kayan_en_buyuk(const std::vector<int>& a, int k,
                    std::vector<int>& en_buyuk, bool iz)
{
    int n = static_cast<int>(a.size());
    Deque d;
    int x;
    deque_olustur(d, k);
    en_buyuk.assign(n - k + 1, 0);
    for (int i = 0; i < n; i++) {
        std::string atilan;
        if (!deque_bos_mu(d) && deque_on(d) == i - k) {
            onden_cikar(d, x);  // pencereden çıkan indis
            atilan = "önden " + std::to_string(a[x]);
        }
        while (!deque_bos_mu(d) && kucuk_esit_mi(a[deque_arka(d)], a[i])) {
            arkadan_cikar(d, x);  // bundan sonra hiç en büyük olamaz
            atilan += (atilan.empty() ? "" : ", ") + std::string("arkadan ") +
                      std::to_string(a[x]);
        }
        arkaya_ekle(d, i);
        if (i >= k - 1) {
            en_buyuk[i - k + 1] = a[deque_on(d)];
        }
        if (iz) {
            std::string ic = "[", eb = "-";
            for (int q = 0; q < d.sayac; q++) {
                ic += (q > 0 ? " " : "") +
                      std::to_string(a[d.veri[(d.bas + q) % k]]);
            }
            ic += "]";
            if (i >= k - 1) {
                eb = std::to_string(en_buyuk[i - k + 1]);
            }
            std::cout << "  " << std::setw(2) << i << " " << std::setw(4)
                      << a[i] << "   " << std::left << std::setw(12) << ic
                      << std::right << " " << std::setw(5) << eb << "   "
                      << (atilan.empty() ? "-" : atilan) << "\n";
        }
    }
}

// Kâhin: her pencereyi baştan tara, O(nk)
static void kaba_kuvvet(const std::vector<int>& a, int k,
                        std::vector<int>& en_buyuk)
{
    int n = static_cast<int>(a.size());
    en_buyuk.assign(n - k + 1, 0);
    for (int i = 0; i + k <= n; i++) {
        int m = a[i];
        for (int j = i + 1; j < i + k; j++) {
            kaba_karsilastirma++;
            if (a[j] > m) {
                m = a[j];
            }
        }
        en_buyuk[i] = m;
    }
}

static void deque_gosterimi()
{
    Deque d;
    int x;
    deque_olustur(d, 4);
    std::cout << "1) İki uçlu kuyruk (kapasite 4): iki uçtan ekleme ve "
                 "çıkarma\n";
    arkaya_ekle(d, 10);
    arkaya_ekle(d, 20);
    one_ekle(d, 5);
    std::cout << "  arkaya 10, arkaya 20, öne 5   -> bas = " << d.bas
              << ", sayaç = " << d.sayac
              << " (öne ekleme bas'ı geriye sardı)\n";
    std::cout << "  sırası: ";
    for (int q = 0; q < d.sayac; q++) {
        std::cout << d.veri[(d.bas + q) % 4] << " ";
    }
    std::cout << "| ön = " << deque_on(d) << ", arka = " << deque_arka(d)
              << "\n";
    bool e1 = one_ekle(d, 1), e0 = one_ekle(d, 0);
    std::cout << "  öne 1 -> " << (e1 ? "evet" : "HAYIR") << "; öne 0 -> "
              << (e0 ? "evet" : "HAYIR") << " (kapasite 4)\n";
    arkadan_cikar(d, x);
    std::cout << "  arkadan çıkar -> " << x << "; ";
    onden_cikar(d, x);
    std::cout << "önden çıkar -> " << x << "; kalan sayaç = " << d.sayac
              << "\n";
}

int main()
{
    deque_gosterimi();

    const std::vector<int> a = {4, 2, 12, 3, 8, 1, 5, 7, 6, 2};
    std::vector<int> sonuc, r1, r2;
    std::cout << "\n2) İzleme: a = [4 2 12 3 8 1 5 7 6 2], k = 3 (deque'da "
                 "indisler; değerleri yazılı)\n";
    std::cout << "   i a[i]   deque        en büyük  atılanlar\n";
    sayaclari_sifirla();
    kayan_en_buyuk(a, 3, sonuc, true);
    std::cout << "  pencere en büyükleri:";
    for (int v : sonuc) {
        std::cout << " " << v;
    }
    std::cout << "\n  ekle = " << ekle_sayisi << ", çıkar = " << cikar_sayisi
              << ", karşılaştırma = " << karsilastirma
              << ", en büyük deque boyu = " << en_buyuk_boyut << " (k = 3)\n";

    std::cout << "\n3) Rastgele 2000 girdi (n = 1..80, k = 1..n, tohum 42) ve "
                 "kâhin\n";
    int uyusmazlik = 0, ihlal = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 2000; t++) {
        int n = rastgele_aralik(1, 80);
        int k = rastgele_aralik(1, n);
        std::vector<int> dizi(n);
        for (int i = 0; i < n; i++) {
            dizi[i] = rastgele_aralik(0, 50);
        }
        sayaclari_sifirla();
        kayan_en_buyuk(dizi, k, r1, false);
        kaba_kuvvet(dizi, k, r2);
        uyusmazlik += (r1 != r2);
        ihlal += (ekle_sayisi + cikar_sayisi > 2LL * n) ||
                 (en_buyuk_boyut > k);
    }
    std::cout << "  kâhinle uyuşmazlık = " << uyusmazlik
              << ", ekle + çıkar > 2n ya da boy > k = " << ihlal << "\n";

    std::cout << "\n4) n = 100000 rastgele: deque Θ(n), kaba kuvvet "
                 "(n - k + 1)(k - 1) karşılaştırma\n";
    std::cout << "       k  ekle + çıkar  karş./n  en büyük boy   kaba "
                 "karş.\n";
    int n = 100000;
    rastgele_tohum(42);
    std::vector<int> b(n), s;
    for (int i = 0; i < n; i++) {
        b[i] = rastgele_aralik(0, 1000000);
    }
    for (int k = 10; k <= 10000; k *= 10) {
        sayaclari_sifirla();
        kayan_en_buyuk(b, k, s, false);
        std::cout << "  " << std::setw(6) << k << " " << std::setw(13)
                  << ekle_sayisi + cikar_sayisi << " " << std::fixed
                  << std::setprecision(3) << std::setw(8)
                  << static_cast<double>(karsilastirma) / n << " "
                  << std::setw(13) << en_buyuk_boyut << " " << std::setw(12)
                  << static_cast<long long>(n - k + 1) * (k - 1) << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::deque<int> (push_back,
 * pop_back, pop_front, front, back); Python — collections.deque (append,
 * pop, popleft, d[0], d[-1]). */

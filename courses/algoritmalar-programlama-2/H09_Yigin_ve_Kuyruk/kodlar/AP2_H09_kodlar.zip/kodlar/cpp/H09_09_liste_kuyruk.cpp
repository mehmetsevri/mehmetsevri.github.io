/* H09_09_liste_kuyruk.cpp — AP-2 Hafta 9 · Örnek 9 (★)
 * Amaç    : Bağlı liste tabanlı kuyruk: baş (çıkarma) ve son (ekleme)
 *           işaretçileriyle iki işlem de O(1); son düğüm çıkarılınca son
 *           da nullptr yapılır. Uygulamalar: katman katman işleme (BFS'ye
 *           köprü) ve sıcak patates (Josephus) sırası
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_09_liste_kuyruk.cpp -o H09_09_liste_kuyruk
 * Çalıştır: ./H09_09_liste_kuyruk
 * Eşleri  : c/H09_09_liste_kuyruk.c · python/H09_09_liste_kuyruk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <queue>

#include "ortak_rastgele.hpp"

struct Dugum {
    int deger;
    Dugum *sonraki;  // baştan sona doğru
};

static long long ekle_sayisi = 0, cikar_sayisi = 0;
static long long ayrilan_dugum = 0, serbest_dugum = 0;

struct Kuyruk;
void kuyruk_yok_et(Kuyruk& q);

// Kuyruk: bas en eski, son en yeni düğüm; boşken ikisi de nullptr.
// RAII: yıkıcı kalan düğümleri döngüyle siler; kopyalama yasak.
struct Kuyruk {
    Dugum *bas = nullptr;
    Dugum *son = nullptr;
    int boyut = 0;
    Kuyruk() = default;
    Kuyruk(const Kuyruk&) = delete;
    Kuyruk& operator=(const Kuyruk&) = delete;
    ~Kuyruk() { kuyruk_yok_et(*this); }
};

void kuyruk_olustur(Kuyruk& q)
{
    q.bas = q.son = nullptr;
    q.boyut = 0;
}

// Sahiplik: düğümler kuyruğundur; kalanlar burada serbest bırakılır
void kuyruk_yok_et(Kuyruk& q)
{
    while (q.bas != nullptr) {
        Dugum *d = q.bas;
        q.bas = d->sonraki;
        delete d;
        serbest_dugum++;
    }
    q.son = nullptr;
    q.boyut = 0;
}

bool kuyruk_bos_mu(const Kuyruk& q) { return q.bas == nullptr; }

// Sona ekler; bellek yetmezse new std::bad_alloc atar
bool kuyruk_ekle(Kuyruk& q, int x)
{
    Dugum *d = new Dugum{x, nullptr};
    ayrilan_dugum++;
    if (q.son == nullptr) {
        q.bas = d;          // boş kuyruk: ilk düğüm hem baş hem son
    } else {
        q.son->sonraki = d;  // eski sonun arkasına bağla
    }
    q.son = d;
    q.boyut++;
    ekle_sayisi++;
    return true;
}

// Baştan çıkarır; boş kuyrukta false döner
bool kuyruk_cikar(Kuyruk& q, int& x)
{
    if (kuyruk_bos_mu(q)) {
        return false;
    }
    Dugum *d = q.bas;
    x = d->deger;
    q.bas = d->sonraki;
    if (q.bas == nullptr) {
        q.son = nullptr;  // boşaldı: son da nullptr olmalı
    }
    delete d;
    serbest_dugum++;
    q.boyut--;
    cikar_sayisi++;
    return true;
}

static void kuyruk_yaz(const Kuyruk& q)
{
    std::cout << "baş [";
    for (const Dugum *d = q.bas; d != nullptr; d = d->sonraki) {
        std::cout << (d != q.bas ? " " : "") << d->deger;
    }
    std::cout << "] son";
    if (q.son == nullptr) {
        std::cout << "   (bas = son = NULL)";
    } else {
        std::cout << "   (bas -> " << q.bas->deger << ", son -> "
                  << q.son->deger << ")";
    }
    std::cout << "\n";
}

// Tam ikili ağacın düzey sırası: x'in çocukları 2x ve 2x + 1
static void katman_katman(int n)
{
    Kuyruk q;
    kuyruk_olustur(q);
    kuyruk_ekle(q, 1);
    int duzey = 0;
    while (!kuyruk_bos_mu(q)) {
        int katman = q.boyut;  // bu katmanda işlenecek eleman sayısı
        std::cout << "  düzey " << duzey << ":";
        for (int k = 0; k < katman; k++) {
            int x;
            kuyruk_cikar(q, x);
            std::cout << " " << x;
            if (2 * x <= n) {
                kuyruk_ekle(q, 2 * x);
            }
            if (2 * x + 1 <= n) {
                kuyruk_ekle(q, 2 * x + 1);
            }
        }
        std::cout << "   (sırada bekleyen: " << q.boyut << ")\n";
        duzey++;
    }
    kuyruk_yok_et(q);
}

// n kişi dairede; her k'ıncı kişi çıkar (kuyruğu döndürerek)
static void sicak_patates(int n, int k)
{
    Kuyruk q;
    int x;
    kuyruk_olustur(q);
    for (int i = 1; i <= n; i++) {
        kuyruk_ekle(q, i);
    }
    std::cout << "  n = " << n << ", k = " << k << ": çıkış sırası";
    while (q.boyut > 1) {
        for (int s = 1; s < k; s++) {
            kuyruk_cikar(q, x);  // baştakini sona aktar
            kuyruk_ekle(q, x);
        }
        kuyruk_cikar(q, x);
        std::cout << " " << x;
    }
    kuyruk_cikar(q, x);
    std::cout << "; kalan " << x << "\n";
    kuyruk_yok_et(q);
}

// Kâhin: std::queue<int> (yalnızca karşılaştırma için)
static void rastgele_sinama(int islem)
{
    Kuyruk q;
    kuyruk_olustur(q);
    std::queue<int> kahin;
    int uyusmazlik = 0, bos = 0, en_buyuk = 0;
    rastgele_tohum(42);
    for (int t = 0; t < islem; t++) {
        if (rastgele_aralik(0, 99) < 52) {
            int v = rastgele_aralik(0, 999);
            kuyruk_ekle(q, v);
            kahin.push(v);
        } else {
            int x = -1, xk = -1;
            bool tamam = kuyruk_cikar(q, x);
            bool rk = !kahin.empty();
            if (rk) {
                xk = kahin.front();
                kahin.pop();
            }
            bos += !rk;
            uyusmazlik += (tamam != rk) || x != xk;
        }
        uyusmazlik += (q.boyut != static_cast<int>(kahin.size())) ||
                      ((q.boyut == 0) != (q.son == nullptr));
        if (q.boyut > en_buyuk) {
            en_buyuk = q.boyut;
        }
    }
    std::cout << "  " << islem << " işlem: boş reddi " << bos
              << ", en büyük boyut " << en_buyuk << ", son boyut " << q.boyut
              << ", kâhinle uyuşmazlık " << uyusmazlik << "\n";
    kuyruk_yok_et(q);
}

int main()
{
    Kuyruk q;
    int x;
    kuyruk_olustur(q);
    std::cout << "1) Ekle 10, 20, 30; çıkar; ekle 40; tümünü çıkar; yeniden "
                 "ekle\n  ";
    kuyruk_yaz(q);
    for (int k = 1; k <= 3; k++) {
        kuyruk_ekle(q, 10 * k);
        std::cout << "  ekle " << 10 * k << "   -> ";
        kuyruk_yaz(q);
    }
    kuyruk_cikar(q, x);
    std::cout << "  çıkar " << x << "  -> ";
    kuyruk_yaz(q);
    kuyruk_ekle(q, 40);
    std::cout << "  ekle 40   -> ";
    kuyruk_yaz(q);
    while (kuyruk_cikar(q, x)) {
        std::cout << "  çıkar " << x << "  -> ";
        kuyruk_yaz(q);
    }
    std::cout << "  çıkar     -> "
              << (kuyruk_cikar(q, x) ? "?" : "HAYIR (boş kuyruk)") << "\n";
    kuyruk_ekle(q, 50);
    std::cout << "  ekle 50   -> ";
    kuyruk_yaz(q);
    kuyruk_yok_et(q);

    std::cout << "\n2) Katman katman işleme: 1'den başla, x'in ardılları 2x "
                 "ve 2x + 1 (<= 15)\n";
    katman_katman(15);

    std::cout << "\n3) Sıcak patates (Josephus): kuyruğu döndürerek eleme\n";
    sicak_patates(7, 3);
    sicak_patates(10, 2);

    std::cout << "\n4) Rastgele 100000 işlem (%52 ekle, tohum 42) ve kâhin\n";
    rastgele_sinama(100000);
    std::cout << "  toplam: ekle = " << ekle_sayisi << ", çıkar = "
              << cikar_sayisi << "; düğüm ayrılan = " << ayrilan_dugum
              << ", serbest = " << serbest_dugum << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int,
 * std::list<int>> ya da varsayılan std::queue<int> (alttaki kap std::deque);
 * Python — collections.deque (append/popleft) ya da iş parçacığı güvenli
 * queue.Queue. */

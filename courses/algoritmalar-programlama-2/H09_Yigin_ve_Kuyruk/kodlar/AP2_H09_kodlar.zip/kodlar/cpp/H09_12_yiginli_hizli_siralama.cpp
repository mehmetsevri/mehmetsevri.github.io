/* H09_12_yiginli_hizli_siralama.cpp — AP-2 Hafta 9 · Örnek 12 (★★★)
 * Amaç    : Özyinelemesiz hızlı sıralama: çağrı yığını yerine açık yığın
 *           (lo, hi) aralıkları. BÜYÜK parça yığına itilir, KÜÇÜK parça hemen
 *           işlenir → yığın derinliği <= ⌊log2 n⌋ + 1 (kapasite tam bu kadar
 *           ayrılır). Lomuto bölümleme (H6 Örnek 4); özyinelemeli sürümün
 *           derinliğiyle karşılaştırma; kâhin: kütüphane sıralaması
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_12_yiginli_hizli_siralama.cpp -o H09_12_yiginli_hizli_siralama
 * Çalıştır: ./H09_12_yiginli_hizli_siralama
 * Eşleri  : c/H09_12_yiginli_hizli_siralama.c ·
 *           python/H09_12_yiginli_hizli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

struct Aralik {
    int lo, hi;  // sıralanmayı bekleyen a[lo..hi]
};

struct Yigin {
    std::vector<Aralik> veri;  // sabit uzunluk: kapasite
    int kapasite = 0;
    int boyut = 0;
};

static long long karsilastirma = 0, takas_sayisi = 0;
static long long it_sayisi = 0, cikar_sayisi = 0, tasma = 0;
static int en_buyuk_derinlik = 0, ozy_derinlik = 0;

static void sayaclari_sifirla()
{
    karsilastirma = takas_sayisi = it_sayisi = cikar_sayisi = tasma = 0;
    en_buyuk_derinlik = ozy_derinlik = 0;
}

static bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite, Aralik{0, 0});
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;
}

static void yigin_it(Yigin& y, Aralik r)
{
    if (y.boyut == y.kapasite) {
        tasma++;  // ⌊log2 n⌋ + 1 sınırı aşılsaydı burada görülürdü
        return;
    }
    y.veri[y.boyut++] = r;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
}

static bool yigin_cikar(Yigin& y, Aralik& r)
{
    if (y.boyut == 0) {
        return false;
    }
    r = y.veri[--y.boyut];
    cikar_sayisi++;
    return true;
}

static int taban_log2(int n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

static void takas(std::vector<int>& a, int i, int j)
{
    std::swap(a[i], a[j]);
    takas_sayisi++;
}

// Lomuto: pivot a[hi]; değişmez a[lo..i] < pivot <= a[i+1..j-1]
static int bolumle(std::vector<int>& a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

static void yigin_yaz(const Yigin& y)
{
    std::cout << "[";
    for (int k = 0; k < y.boyut; k++) {
        std::cout << (k > 0 ? " " : "") << y.veri[k].lo << ".."
                  << y.veri[k].hi;
    }
    std::cout << "]";
}

static void izle(const std::vector<int>& a, const Yigin& y, int pivot, int p,
                 Aralik buyuk, int lo, int hi)
{
    std::cout << "    pivot " << pivot << " -> p = " << p << "; ";
    if (buyuk.lo < buyuk.hi) {
        std::cout << "it " << buyuk.lo << ".." << buyuk.hi;
    } else {
        std::cout << "büyük parça < 2 eleman";
    }
    if (lo < hi) {
        std::cout << ", sırada " << lo << ".." << hi;
    }
    std::cout << "; yığın ";
    yigin_yaz(y);
    std::cout << "\n      dizi";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

// Açık yığınlı hızlı sıralama: büyük parçayı it, küçüğü hemen işle
void yiginli_hizli_sirala(std::vector<int>& a, bool iz)
{
    int n = static_cast<int>(a.size());
    Yigin y;
    Aralik r;
    yigin_olustur(y, taban_log2(n > 0 ? n : 1) + 1);
    if (n > 1) {
        yigin_it(y, Aralik{0, n - 1});
    }
    while (yigin_cikar(y, r)) {
        int lo = r.lo, hi = r.hi;
        if (iz) {
            std::cout << "  çıkar " << lo << ".." << hi << "\n";
        }
        while (lo < hi) {
            int pivot = a[hi];
            int p = bolumle(a, lo, hi);
            Aralik buyuk;
            if (p - lo < hi - p) {  // sol küçük: sağı it
                buyuk = Aralik{p + 1, hi};
                hi = p - 1;
            } else {                // sağ küçük: solu it
                buyuk = Aralik{lo, p - 1};
                lo = p + 1;
            }
            if (buyuk.lo < buyuk.hi) {
                yigin_it(y, buyuk);
            }
            if (iz) {
                izle(a, y, pivot, p, buyuk, lo, hi);
            }
        }
    }
}

// Karşılaştırma için iki çağrılı özyinelemeli sürüm (d: çağrı derinliği)
void hizli_ozyinelemeli(std::vector<int>& a, int lo, int hi, int d)
{
    if (d > ozy_derinlik) {
        ozy_derinlik = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = bolumle(a, lo, hi);
    hizli_ozyinelemeli(a, lo, p - 1, d + 1);
    hizli_ozyinelemeli(a, p + 1, hi, d + 1);
}

static std::vector<int> girdi_uret(int n, int tur)
{
    std::vector<int> a(n);
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = rastgele_aralik(0, 1000000);
        } else if (tur == 1) {
            a[i] = i;
        } else if (tur == 2) {
            a[i] = n - i;
        } else {
            a[i] = 5;
        }
    }
    return a;
}

// İki sürümü aynı girdide çalıştırır, kâhinle karşılaştırır
static void satir(const char *ad, int n, int tur)
{
    rastgele_tohum(42);
    std::vector<int> a = girdi_uret(n, tur);
    std::vector<int> b = a, k = a;
    std::sort(k.begin(), k.end());  // kâhin
    sayaclari_sifirla();
    hizli_ozyinelemeli(b, 0, n - 1, 1);
    int ozy = ozy_derinlik;
    sayaclari_sifirla();
    yiginli_hizli_sirala(a, false);
    bool dogru = (a == k) && (b == k);
    std::cout << "  " << ad << " " << std::setw(7) << n << " "
              << std::setw(11) << karsilastirma << " " << std::setw(8)
              << en_buyuk_derinlik << " " << std::setw(6)
              << taban_log2(n) + 1 << " " << std::setw(10) << ozy << " "
              << std::setw(6) << tasma << "  " << (dogru ? "evet" : "HAYIR")
              << "\n";
}

int main()
{
    std::vector<int> a = {7, 3, 5, 9, 2, 4, 1, 8, 6};
    std::cout << "1) İzleme: a = [7 3 5 9 2 4 1 8 6], pivot = a[hi] "
                 "(Lomuto)\n";
    sayaclari_sifirla();
    yiginli_hizli_sirala(a, true);
    std::cout << "  karşılaştırma = " << karsilastirma << ", takas = "
              << takas_sayisi << ", it = " << it_sayisi << ", çıkar = "
              << cikar_sayisi << ", en büyük derinlik = " << en_buyuk_derinlik
              << " (sınır " << taban_log2(9) + 1 << ")\n";

    std::cout << "\n2) Yığın derinliği: açık yığın (kapasite ⌊log2 n⌋ + 1) "
                 "ve özyinelemeli sürüm\n";
    std::cout << "  girdi          n  karşılaşt.  yığın   sınır  özyineli  "
                 "taşma  kâhin\n";
    satir("rastgele", 500, 0);
    satir("sıralı  ", 500, 1);
    satir("ters    ", 500, 2);
    satir("aynı    ", 500, 3);
    satir("rastgele", 1000, 0);
    satir("rastgele", 10000, 0);
    satir("rastgele", 100000, 0);
    std::cout << "  (sıralı/ters/aynı girdide Lomuto en kötü durumdadır: "
                 "özyinelemeli derinlik n'e çıkar)\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritmayı standart belirtmez);
 * C++ — std::sort (libstdc++: introsort; derinlik 2⌊log2 n⌋ aşılınca öbek
 * sıralamasına geçer);
 * Python — list.sort / sorted (Timsort). Kütüphaneler yalnızca kâhin. */

/* H09_03_parantez_denetimi.cpp — AP-2 Hafta 9 · Örnek 3 (★★)
 * Amaç    : ( ) [ ] { } dengesinin yığınla denetimi; ilk hatanın konumu
 *           ve türü: eşleşmeyen kapanış, tür uyuşmazlığı, açık kalan
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_03_parantez_denetimi.cpp -o H09_03_parantez_denetimi
 * Çalıştır: ./H09_03_parantez_denetimi \
 *           < ../girdiler/H09_03_parantez_denetimi.txt
 * Eşleri  : c/H09_03_parantez_denetimi.c ·
 *           python/H09_03_parantez_denetimi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

enum { DENGELI, ESLESMEYEN_KAPANIS, TUR_UYUSMAZLIGI, ACIK_KALAN };

struct Acilis {
    char tur;   // '(' '[' '{'
    int sutun;  // 1 tabanlı konum
};

struct Yigin {
    std::vector<Acilis> veri;  // sabit uzunluk: kapasite
    int kapasite = 0;
    int boyut = 0;
};

struct Sonuc {
    int durum;
    int sutun;         // hatanın bulunduğu sütun
    char bulunan;      // hatalı kapanış ya da açık kalan açılış
    char beklenen;     // tür uyuşmazlığında beklenen kapanış
    int acilis_sutun;  // ilgili açılışın sütunu
    int acik_sayisi;   // açık kalan parantez sayısı
};

static long long it_sayisi = 0, cikar_sayisi = 0, islenen = 0;
static int en_buyuk_derinlik = 0;

static void sayaclari_sifirla()
{
    it_sayisi = cikar_sayisi = islenen = 0;
    en_buyuk_derinlik = 0;
}

// Sahiplik: veri vektörü Yigin'indir; yıkıcısı belleği kendisi bırakır.
static bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite, Acilis{0, 0});
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;
}

static bool yigin_it(Yigin& y, Acilis a)
{
    if (y.boyut == y.kapasite) {
        return false;
    }
    y.veri[y.boyut++] = a;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
    return true;
}

static bool yigin_cikar(Yigin& y, Acilis& a)
{
    if (y.boyut == 0) {
        return false;
    }
    a = y.veri[--y.boyut];
    cikar_sayisi++;
    return true;
}

static char acilis_karsiligi(char kapanis)
{
    if (kapanis == ')') {
        return '(';
    }
    return kapanis == ']' ? '[' : '{';
}

static char kapanis_karsiligi(char acilis)
{
    if (acilis == '(') {
        return ')';
    }
    return acilis == '[' ? ']' : '}';
}

// s taranır; ilk hatada durulur (erken çıkış)
Sonuc parantez_denetle(const std::string& s, bool iz)
{
    int n = static_cast<int>(s.size());
    Sonuc r{DENGELI, 0, 0, 0, 0, 0};
    Yigin y;
    yigin_olustur(y, n > 0 ? n : 1);
    for (int i = 0; i < n && r.durum == DENGELI; i++) {
        char c = s[i];
        islenen++;
        if (c == '(' || c == '[' || c == '{') {
            yigin_it(y, Acilis{c, i + 1});
        } else if (c == ')' || c == ']' || c == '}') {
            Acilis a;
            if (!yigin_cikar(y, a)) {
                r = Sonuc{ESLESMEYEN_KAPANIS, i + 1, c, 0, 0, 0};
            } else if (a.tur != acilis_karsiligi(c)) {
                r = Sonuc{TUR_UYUSMAZLIGI, i + 1, c,
                          kapanis_karsiligi(a.tur), a.sutun, 0};
            }
        } else {
            continue;  // parantez olmayan karakterler atlanır
        }
        if (iz) {
            std::cout << "    sütun " << std::setw(2) << i + 1 << " '" << c
                      << "' -> yığın: ";
            for (int k = 0; k < y.boyut; k++) {
                std::cout << y.veri[k].tur;
            }
            std::cout << (y.boyut == 0 ? "(boş)" : "") << "\n";
        }
    }
    if (r.durum == DENGELI && y.boyut > 0) {
        Acilis a = y.veri[y.boyut - 1];  // en içteki açık parantez
        r = Sonuc{ACIK_KALAN, n + 1, a.tur, 0, a.sutun, y.boyut};
    }
    return r;
}

static void sonuc_yaz(const Sonuc& r)
{
    switch (r.durum) {
    case DENGELI:
        std::cout << "dengeli";
        break;
    case ESLESMEYEN_KAPANIS:
        std::cout << "HATA sütun " << r.sutun << ": eşleşmeyen kapanış '"
                  << r.bulunan << "' (yığın boş)";
        break;
    case TUR_UYUSMAZLIGI:
        std::cout << "HATA sütun " << r.sutun << ": tür uyuşmazlığı: '"
                  << r.bulunan << "' bulundu, '" << r.beklenen
                  << "' bekleniyordu (açılış sütun " << r.acilis_sutun
                  << ")";
        break;
    default:
        std::cout << "HATA satır sonu: açık kalan " << r.acik_sayisi
                  << " parantez; en içteki '" << r.bulunan << "' (sütun "
                  << r.acilis_sutun << ")";
    }
}

// n uzunluğunda (çift) rastgele dengeli dizgi; üretici de yığın kullanır
static std::string rastgele_dengeli(int n)
{
    std::string s(n, ' ');
    Yigin y;
    const char *turler = "([{";
    yigin_olustur(y, n / 2 + 1);
    for (int i = 0; i < n; i++) {
        bool ac;
        if (y.boyut == 0) {
            ac = true;
        } else if (y.boyut == n - i) {
            ac = false;
        } else {
            ac = rastgele_aralik(0, 1) == 0;
        }
        if (ac) {
            char t = turler[rastgele_aralik(0, 2)];
            yigin_it(y, Acilis{t, i + 1});
            s[i] = t;
        } else {
            Acilis a;
            yigin_cikar(y, a);
            s[i] = kapanis_karsiligi(a.tur);
        }
    }
    return s;
}

static void buyuk_satir(const std::string& ad, const std::string& s)
{
    sayaclari_sifirla();
    Sonuc r = parantez_denetle(s, false);
    std::cout << "  " << std::left << std::setw(22) << ad << std::right
              << ": ";
    sonuc_yaz(r);
    std::cout << "\n  " << std::string(22, ' ')
              << "  işlenen karakter = " << islenen << ", it = " << it_sayisi
              << ", çıkar = " << cikar_sayisi << ", en büyük derinlik = "
              << en_buyuk_derinlik << "\n";
}

int main()
{
    std::string satir;
    int no = 0, dengeli = 0;
    std::cout << "1) Girdi dosyasındaki satırlar\n";
    while (std::getline(std::cin, satir)) {
        no++;
        sayaclari_sifirla();
        Sonuc r = parantez_denetle(satir, false);
        std::cout << "  satır " << std::setw(2) << no << ": " << satir
                  << "\n    -> ";
        sonuc_yaz(r);
        std::cout << "; it = " << it_sayisi << ", çıkar = " << cikar_sayisi
                  << ", en büyük derinlik = " << en_buyuk_derinlik << "\n";
        dengeli += (r.durum == DENGELI);
    }
    std::cout << "  toplam " << no << " satır: dengeli " << dengeli
              << ", hatalı " << no - dengeli << "\n";

    std::cout << "\n2) Yığın izi: her parantezden sonra yığının içeriği "
                 "(taban solda)\n";
    const std::vector<std::string> izler = {"{[()()]}", "[(a + b])", "((a)"};
    for (const std::string& iz : izler) {
        std::cout << "  " << iz << "\n";
        Sonuc r = parantez_denetle(iz, true);
        std::cout << "    sonuç: ";
        sonuc_yaz(r);
        std::cout << "\n";
    }

    std::cout << "\n3) Büyük girdi (n = 100000, tohum 42): Θ(n) tarama ve "
                 "erken çıkış\n";
    int n = 100000;
    rastgele_tohum(42);
    std::string s = rastgele_dengeli(n);
    buyuk_satir("rastgele dengeli", s);
    char son = s[n - 1];
    s[n - 1] = (son == ')') ? ']' : ')';
    buyuk_satir("son karakter bozuk", s);
    s[n - 1] = son;
    s[0] = ')';
    buyuk_satir("ilk karakter ')'", s);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::stack<char>;
 * Python — list (append/pop). Hazır "parantez denetimi" fonksiyonu yoktur;
 * derleyiciler ve düzenleyiciler bu algoritmayı kendileri gerçekler. */

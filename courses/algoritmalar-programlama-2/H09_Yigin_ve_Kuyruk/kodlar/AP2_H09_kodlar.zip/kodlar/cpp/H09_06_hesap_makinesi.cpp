/* H09_06_hesap_makinesi.cpp — AP-2 Hafta 9 · Örnek 6 (★★★)
 * Amaç    : Basit hesap makinesi: araek ifade → Shunting-yard (Örnek 5) →
 *           sonek değerlendirme (Örnek 4); + - * / ^, parantez, tekli eksi;
 *           hata iletileri ve çıkış kodları üç dilde aynı; rastgele ifade
 *           ağaçlarıyla kâhinli sınama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_06_hesap_makinesi.cpp -o H09_06_hesap_makinesi
 * Çalıştır: ./H09_06_hesap_makinesi < ../girdiler/H09_06_hesap_makinesi.txt
 *           ./H09_06_hesap_makinesi "3 + 4 * 2"     (tek ifade)
 *           çıkış kodu: 0 geçerli · 1 hatalı ifade · 2 hatalı kullanım
 * Eşleri  : c/H09_06_hesap_makinesi.c · python/H09_06_hesap_makinesi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <climits>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

enum { SAYI, ISLEC, SOL_PAR, SAG_PAR };
enum { HATA_YOK, GECERSIZ_KARAKTER, ISLENEN_BEKLENIYOR, ISLEC_BEKLENIYOR,
       ESLESMEYEN_KAPANIS, ACIK_PARANTEZ, BOS_IFADE, SIFIRA_BOLME, TASMA,
       NEGATIF_US };

static const char *const HATA_ILETISI[] = {
    "yok", "geçersiz karakter", "işlenen bekleniyordu",
    "işleç bekleniyordu", "eşleşmeyen ')'", "kapanmamış '('", "boş ifade",
    "sıfıra bölme", "taşma (int aralığı dışında)", "negatif üs"};

struct Belirtec {
    int tur;
    int sutun;   // 1 tabanlı konum
    char islec;  // + - * / ^ ve tekli eksi için ~
    int deger;   // SAYI için
};

struct Yigin {
    std::vector<int> veri;  // sabit uzunluk: kapasite
    int kapasite = 0;
    int boyut = 0;
};

static long long it_sayisi = 0, cikar_sayisi = 0;

static bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite, 0);
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;
}

static bool yigin_it(Yigin& y, int x)
{
    if (y.boyut == y.kapasite) {
        return false;
    }
    y.veri[y.boyut++] = x;
    it_sayisi++;
    return true;
}

static bool yigin_cikar(Yigin& y, int& x)
{
    if (y.boyut == 0) {
        return false;
    }
    x = y.veri[--y.boyut];
    cikar_sayisi++;
    return true;
}

static bool yigin_tepe(const Yigin& y, int& x)
{
    if (y.boyut == 0) {
        return false;
    }
    x = y.veri[y.boyut - 1];
    return true;
}

// ---- Aritmetik (Örnek 4): int aralığı denetimli ----
static int us_al(int a, int b, int& sonuc)
{
    if (a == 0 || a == 1) {
        sonuc = (b == 0) ? 1 : a;
        return HATA_YOK;
    }
    if (a == -1) {
        sonuc = (b % 2 == 0) ? 1 : -1;
        return HATA_YOK;
    }
    long long r = 1;
    for (int k = 0; k < b; k++) {
        r *= a;
        if (r < INT_MIN || r > INT_MAX) {
            return TASMA;
        }
    }
    sonuc = static_cast<int>(r);
    return HATA_YOK;
}

static int islem_uygula(char op, int a, int b, int& sonuc)
{
    long long r;
    if (op == '+') {
        r = static_cast<long long>(a) + b;
    } else if (op == '-') {
        r = static_cast<long long>(a) - b;
    } else if (op == '*') {
        r = static_cast<long long>(a) * b;
    } else if (op == '/') {
        if (b == 0) {
            return SIFIRA_BOLME;
        }
        r = static_cast<long long>(a) / b;  // C++: sıfıra doğru kesme
    } else {
        if (b < 0) {
            return NEGATIF_US;
        }
        return us_al(a, b, sonuc);
    }
    if (r < INT_MIN || r > INT_MAX) {
        return TASMA;
    }
    sonuc = static_cast<int>(r);
    return HATA_YOK;
}

// ---- Belirteçleme ve Shunting-yard (Örnek 5) ----
static int oncelik(char op)
{
    if (op == '+' || op == '-') {
        return 1;
    }
    if (op == '*' || op == '/') {
        return 2;
    }
    return op == '~' ? 3 : 4;
}

static bool sag_birlesmeli(char op) { return op == '^' || op == '~'; }

static bool once_cikar_mi(char ust, char gelen)
{
    return oncelik(ust) > oncelik(gelen) ||
           (oncelik(ust) == oncelik(gelen) && !sag_birlesmeli(gelen));
}

static int belirtecle(const std::string& s, std::vector<Belirtec>& b,
                      int& sutun)
{
    int n = static_cast<int>(s.size()), i = 0;
    bool islenen_bekleniyor = true;
    b.clear();
    while (i < n) {
        char c = s[i];
        if (c == ' ' || c == '\t') {
            i++;
            continue;
        }
        Belirtec t{SAYI, i + 1, c, 0};
        sutun = i + 1;
        if (c >= '0' && c <= '9') {
            long long v = 0;
            while (i < n && s[i] >= '0' && s[i] <= '9') {
                v = 10 * v + (s[i++] - '0');
                if (v > INT_MAX) {
                    return TASMA;
                }
            }
            t.deger = static_cast<int>(v);
        } else if (c == '(' || c == ')') {
            t.tur = (c == '(') ? SOL_PAR : SAG_PAR;
            i++;
        } else if (std::string("+-*/^").find(c) != std::string::npos) {
            t.tur = ISLEC;
            if (c == '-' && islenen_bekleniyor) {
                t.islec = '~';
            }
            i++;
        } else {
            return GECERSIZ_KARAKTER;
        }
        if (islenen_bekleniyor) {
            if (t.tur == SAG_PAR || (t.tur == ISLEC && t.islec != '~')) {
                return ISLENEN_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == SOL_PAR || t.tur == ISLEC);
        } else {
            if (t.tur == SAYI || t.tur == SOL_PAR) {
                return ISLEC_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == ISLEC);
        }
        b.push_back(t);
    }
    sutun = n + 1;
    if (islenen_bekleniyor) {
        return b.empty() ? BOS_IFADE : ISLENEN_BEKLENIYOR;
    }
    return HATA_YOK;
}

static int sonege_cevir(const std::vector<Belirtec>& b,
                        std::vector<int>& cikti, int& sutun)
{
    int m = static_cast<int>(b.size());
    Yigin y;
    int hata = HATA_YOK, j;
    yigin_olustur(y, m + 1);
    cikti.clear();
    for (int i = 0; i < m && hata == HATA_YOK; i++) {
        if (b[i].tur == SAYI) {
            cikti.push_back(i);
        } else if (b[i].tur == SOL_PAR || b[i].islec == '~') {
            yigin_it(y, i);
        } else if (b[i].tur == SAG_PAR) {
            while (yigin_tepe(y, j) && b[j].tur != SOL_PAR) {
                yigin_cikar(y, j);
                cikti.push_back(j);
            }
            if (!yigin_cikar(y, j)) {
                hata = ESLESMEYEN_KAPANIS;
                sutun = b[i].sutun;
            }
        } else {
            while (yigin_tepe(y, j) && b[j].tur == ISLEC &&
                   once_cikar_mi(b[j].islec, b[i].islec)) {
                yigin_cikar(y, j);
                cikti.push_back(j);
            }
            yigin_it(y, i);
        }
    }
    while (hata == HATA_YOK && yigin_cikar(y, j)) {
        if (b[j].tur == SOL_PAR) {
            hata = ACIK_PARANTEZ;
            sutun = b[j].sutun;
        } else {
            cikti.push_back(j);
        }
    }
    return hata;
}

// ---- Sonek değerlendirme (Örnek 4), belirteç dizisi üzerinde ----
static int sonek_hesapla(const std::vector<Belirtec>& b,
                         const std::vector<int>& cikti, int& sonuc,
                         int& sutun, bool iz)
{
    int k = static_cast<int>(cikti.size());
    Yigin y;
    int hata = HATA_YOK, a = 0, x = 0;
    yigin_olustur(y, k + 1);
    for (int i = 0; i < k && hata == HATA_YOK; i++) {
        const Belirtec& t = b[cikti[i]];
        if (t.tur == SAYI) {
            yigin_it(y, t.deger);
        } else if (t.islec == '~') {
            yigin_cikar(y, a);  // sözdizimi denetimi işleneni garantiler
            if (a == INT_MIN) {
                hata = TASMA;
            } else {
                yigin_it(y, -a);
            }
        } else {
            int bb = 0, r = 0;
            yigin_cikar(y, bb);  // önce b (tepe), sonra a
            yigin_cikar(y, a);
            hata = islem_uygula(t.islec, a, bb, r);
            if (hata == HATA_YOK) {
                yigin_it(y, r);
            }
        }
        if (hata != HATA_YOK) {
            sutun = t.sutun;
        }
        if (iz) {
            std::cout << "    " << std::left << std::setw(4);
            if (t.tur == SAYI) {
                std::cout << t.deger;
            } else {
                std::cout << t.islec;
            }
            std::cout << std::right << " ->";
            for (int q = 0; q < y.boyut; q++) {
                std::cout << " " << y.veri[q];
            }
            std::cout << "\n";
        }
    }
    yigin_tepe(y, x);
    sonuc = x;
    return hata;
}

// Bir ifadeyi hesaplar; hata kodu döner. sonek: sonek gösterimi metni
int hesapla(const std::string& s, int& sonuc, int& sutun, std::string& sonek,
            bool iz)
{
    std::vector<Belirtec> b;
    std::vector<int> cikti;
    sonek.clear();
    int hata = belirtecle(s, b, sutun);
    if (hata == HATA_YOK) {
        hata = sonege_cevir(b, cikti, sutun);
    }
    if (hata != HATA_YOK) {
        return hata;
    }
    for (std::size_t i = 0; i < cikti.size(); i++) {
        const Belirtec& t = b[cikti[i]];
        sonek += (i > 0 ? " " : "") + (t.tur == SAYI
                                           ? std::to_string(t.deger)
                                           : std::string(1, t.islec));
    }
    return sonek_hesapla(b, cikti, sonuc, sutun, iz);
}

static bool satir_isle(const std::string& s)
{
    std::string sonek;
    int sonuc = 0, sutun = 0;
    int hata = hesapla(s, sonuc, sutun, sonek, false);
    std::cout << "  " << std::left << std::setw(32) << s << std::right;
    if (hata == HATA_YOK) {
        std::cout << " = " << sonuc << "   (sonek: " << sonek << ")\n";
    } else {
        std::cout << " -> HATA sütun " << sutun << ": " << HATA_ILETISI[hata]
                  << "\n";
    }
    return hata == HATA_YOK;
}

// ---- Kâhin: rastgele ifade ağacı; değer üretilirken hesaplanır ----
static int rastgele_ifade(int derinlik, std::string& s, int& deger,
                          int& hata)
{
    int r = (derinlik == 0) ? 0 : rastgele_aralik(0, 4);
    if (r == 0) {
        deger = rastgele_aralik(-9, 9);
        s = std::to_string(deger);
        return 9;  // yaprak: hiç parantez gerektirmez
    }
    char op = "+-*/"[r - 1];
    std::string sol, sag;
    int a, b, ha = HATA_YOK, hb = HATA_YOK;
    int os = rastgele_ifade(derinlik - 1, sol, a, ha);
    int og = rastgele_ifade(derinlik - 1, sag, b, hb);
    int p = oncelik(op);
    s = (os < p ? "(" + sol + ")" : sol) + " " + op + " " +
        (og <= p ? "(" + sag + ")" : sag);
    hata = (ha != HATA_YOK) ? ha : hb;
    deger = 0;
    if (hata == HATA_YOK) {
        hata = islem_uygula(op, a, b, deger);
    }
    return p;
}

static void kahinli_sinama(int adet)
{
    std::string s, sonek;
    int uyusmazlik = 0, hatali = 0;
    rastgele_tohum(42);
    for (int t = 0; t < adet; t++) {
        int beklenen = 0, beklenen_hata = HATA_YOK, sonuc = 0, sutun = 0;
        rastgele_ifade(3, s, beklenen, beklenen_hata);
        int hata = hesapla(s, sonuc, sutun, sonek, false);
        if (hata != beklenen_hata ||
            (hata == HATA_YOK && sonuc != beklenen)) {
            uyusmazlik++;
        }
        hatali += (hata == SIFIRA_BOLME);
        if (t < 4) {
            std::cout << "  " << std::left << std::setw(40) << s << std::right
                      << " -> ";
            if (hata == HATA_YOK) {
                std::cout << sonuc << " (kâhin " << beklenen << ")\n";
            } else {
                std::cout << "HATA: " << HATA_ILETISI[hata] << " (kâhin: "
                          << HATA_ILETISI[beklenen_hata] << ")\n";
            }
        }
    }
    std::cout << "  " << adet << " ifade: sıfıra bölmeli " << hatali
              << ", kâhinle uyuşmazlık " << uyusmazlik << "\n";
}

int main(int argc, char *argv[])
{
    if (argc > 2) {
        std::cerr << "kullanım: H09_06_hesap_makinesi [\"ifade\"]  "
                     "(ifade yoksa stdin)\n";
        return 2;
    }
    if (argc == 2) {
        return satir_isle(argv[1]) ? 0 : 1;
    }
    std::string satir, sonek;
    int sonuc = 0, sutun = 0, gecerli = 0, toplam = 0;
    std::cout << "1) 3 + 4 * 2: önce sonek gösterimine, sonra yığınla "
                 "hesap\n";
    hesapla("3 + 4 * 2", sonuc, sutun, sonek, true);
    std::cout << "  sonek: " << sonek << "  ->  sonuç " << sonuc << "\n";

    std::cout << "\n2) Rastgele ifade ağaçları (derinlik <= 3, tohum 42) ve "
                 "kâhin\n";
    kahinli_sinama(2000);

    std::cout << "\n3) Girdi dosyasındaki ifadeler\n";
    while (std::getline(std::cin, satir)) {
        gecerli += satir_isle(satir);
        toplam++;
    }
    std::cout << "  toplam " << toplam << " ifade: geçerli " << gecerli
              << ", hatalı " << toplam - gecerli << " (yığın işlemleri: it "
              << it_sayisi << ", çıkar " << cikar_sayisi << ")\n";
    return gecerli == toplam ? 0 : 1;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok; Python — eval()
 * (ifadeyi Python kurallarıyla hesaplar: / gerçek bölme, // aşağı yuvarlar,
 * ^ XOR'dur — bu yüzden kâhin olarak bile kullanılmadı; güvensiz girdide
 * eval kullanılmaz). */

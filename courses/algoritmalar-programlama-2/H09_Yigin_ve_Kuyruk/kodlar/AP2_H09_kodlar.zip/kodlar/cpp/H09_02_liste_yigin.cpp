/* H09_02_liste_yigin.cpp — AP-2 Hafta 9 · Örnek 2 (★)
 * Amaç    : Bağlı liste tabanlı yığın (sınırsız): Örnek 1 ile AYNI arayüz,
 *           farklı gerçekleştirim; tepe = listenin başı, it/çıkar O(1)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_02_liste_yigin.cpp -o H09_02_liste_yigin
 * Çalıştır: ./H09_02_liste_yigin
 * Eşleri  : c/H09_02_liste_yigin.c · python/H09_02_liste_yigin.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <stack>

#include "ortak_rastgele.hpp"

struct Dugum {
    int deger;
    Dugum *sonraki;  // tepeden tabana doğru
};

static long long it_sayisi = 0, cikar_sayisi = 0;
static int en_buyuk_derinlik = 0;
static long long ayrilan_dugum = 0, serbest_dugum = 0;

struct Yigin;
void yigin_yok_et(Yigin& y);

// Yığın: tepe listenin ilk düğümü; boş yığında tepe == nullptr.
// RAII: yıkıcı kalan düğümleri DÖNGÜYLE siler; kopyalama yasak (çift silme
// olmasın diye).
struct Yigin {
    Dugum *tepe = nullptr;
    int boyut = 0;
    Yigin() = default;
    Yigin(const Yigin&) = delete;
    Yigin& operator=(const Yigin&) = delete;
    ~Yigin() { yigin_yok_et(*this); }
};

void yigin_olustur(Yigin& y)
{
    y.tepe = nullptr;
    y.boyut = 0;
}

// Sahiplik: düğümler yığınındır; kalan düğümler burada serbest bırakılır
void yigin_yok_et(Yigin& y)
{
    Dugum *d = y.tepe;
    while (d != nullptr) {
        Dugum *sonraki = d->sonraki;
        delete d;
        serbest_dugum++;
        d = sonraki;
    }
    y.tepe = nullptr;
    y.boyut = 0;
}

bool yigin_bos_mu(const Yigin& y) { return y.tepe == nullptr; }

// Kapasite sınırı yok: bellek yetmezse new std::bad_alloc atar
bool yigin_it(Yigin& y, int x)
{
    Dugum *d = new Dugum{x, y.tepe};  // yeni düğüm eski tepenin önüne
    ayrilan_dugum++;
    y.tepe = d;
    y.boyut++;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
    return true;
}

// Alt taşma: yığın boşsa false döner; x değişmez
bool yigin_cikar(Yigin& y, int& x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    Dugum *d = y.tepe;
    x = d->deger;
    y.tepe = d->sonraki;
    delete d;
    serbest_dugum++;
    y.boyut--;
    cikar_sayisi++;
    return true;
}

// Tepedeki elemanı çıkarmadan okur
bool yigin_tepe(const Yigin& y, int& x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    x = y.tepe->deger;
    return true;
}

// Tabandan tepeye yazmak için liste ters sırada dolaşılır (özyinelemeli)
static void tabandan_yaz(const Dugum *d)
{
    if (d == nullptr) {
        return;
    }
    tabandan_yaz(d->sonraki);
    std::cout << (d->sonraki != nullptr ? " " : "") << d->deger;
}

static void yigin_yaz(const Yigin& y)
{
    std::cout << "taban [";
    tabandan_yaz(y.tepe);
    std::cout << "] tepe";
}

// Kâhin: std::stack<int> (yalnızca karşılaştırma için)
static void rastgele_sinama(int islem)
{
    Yigin y;
    yigin_olustur(y);
    std::stack<int> ayna;
    int uyusmazlik = 0, alt_tasma = 0, x;
    long long it0 = it_sayisi, cikar0 = cikar_sayisi;
    rastgele_tohum(42);
    for (int k = 0; k < islem; k++) {
        if (rastgele_aralik(0, 1) == 0) {
            int v = rastgele_aralik(0, 999);
            yigin_it(y, v);
            ayna.push(v);
        } else if (yigin_cikar(y, x)) {
            if (ayna.empty() || ayna.top() != x) {
                uyusmazlik++;
            }
            if (!ayna.empty()) {
                ayna.pop();
            }
        } else {
            alt_tasma++;
            uyusmazlik += !ayna.empty();
        }
    }
    std::cout << "  " << islem << " işlem: başarılı = "
              << (it_sayisi - it0) + (cikar_sayisi - cikar0)
              << ", alt taşma = " << alt_tasma << ", son boyut = " << y.boyut
              << "\n";
    std::cout << "  kâhinle uyuşmazlık = " << uyusmazlik << "\n";
    yigin_yok_et(y);
}

int main()
{
    Yigin y;
    int x = 0;
    yigin_olustur(y);
    std::cout << "1) Liste tabanlı yığına 10, 20, 30, 40, 50 itilir "
                 "(kapasite yok)\n";
    for (int k = 1; k <= 5; k++) {
        bool tamam = yigin_it(y, 10 * k);
        std::cout << "  it " << 10 * k << " -> " << (tamam ? "evet" : "HAYIR")
                  << "  ";
        yigin_yaz(y);
        std::cout << "  boyut = " << y.boyut << "\n";
    }

    std::cout << "\n2) Tepeye bakma ve çıkarma: Örnek 1 ile aynı sözleşme\n";
    if (yigin_tepe(y, x)) {
        std::cout << "  tepe -> " << x << " (çıkarılmadı)\n";
    }
    for (int k = 0; k < 6; k++) {
        if (yigin_cikar(y, x)) {
            std::cout << "  çıkar -> " << x << "  ";
        } else {
            std::cout << "  çıkar -> HAYIR (alt taşma: yığın boş)  ";
        }
        yigin_yaz(y);
        std::cout << "\n";
    }
    std::cout << "  sayaçlar: it = " << it_sayisi << ", çıkar = "
              << cikar_sayisi << ", en büyük derinlik = "
              << en_buyuk_derinlik << "\n";

    std::cout << "\n3) Sınırsızlık ve bellek: 100000 it, ardından yok et\n";
    for (int k = 0; k < 100000; k++) {
        yigin_it(y, k);
    }
    yigin_tepe(y, x);
    std::cout << "  boyut = " << y.boyut << ", tepe = " << x
              << ", ayrılan düğüm = " << ayrilan_dugum << "\n";
    yigin_yok_et(y);
    std::cout << "  yok et sonrası: boş mu? "
              << (yigin_bos_mu(y) ? "evet" : "HAYIR")
              << "; serbest bırakılan = " << serbest_dugum
              << "; fark = " << ayrilan_dugum - serbest_dugum << "\n";

    std::cout << "\n4) Rastgele it/çıkar dizisi (tohum 42) ve kâhin\n";
    rastgele_sinama(100000);
    std::cout << "  toplam: ayrılan = " << ayrilan_dugum << ", serbest = "
              << serbest_dugum << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int,
 * std::list<int>> (kap uyarlayıcısı, alttaki kap değiştirilebilir);
 * Python — list (append/pop) ya da collections.deque. */

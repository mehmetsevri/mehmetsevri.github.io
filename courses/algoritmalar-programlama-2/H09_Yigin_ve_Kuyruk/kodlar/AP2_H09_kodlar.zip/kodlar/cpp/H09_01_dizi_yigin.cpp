/* H09_01_dizi_yigin.cpp — AP-2 Hafta 9 · Örnek 1 (★)
 * Amaç    : Dizi tabanlı yığın ADT'si (sabit kapasite): it, çıkar, tepe,
 *           boş mu; taşma ve alt taşma dönüş koduyla (bool) bildirilir
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_01_dizi_yigin.cpp -o H09_01_dizi_yigin
 * Çalıştır: ./H09_01_dizi_yigin
 * Eşleri  : c/H09_01_dizi_yigin.c · python/H09_01_dizi_yigin.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

// Yığın: veri[0..boyut-1] dolu; tepe veri[boyut-1]; boyut <= kapasite
struct Yigin {
    std::vector<int> veri;  // sabit uzunluk: kapasite (büyümez)
    int kapasite = 0;
    int boyut = 0;
};

static long long it_sayisi = 0, cikar_sayisi = 0;
static int en_buyuk_derinlik = 0;

// Sahiplik: veri vektörü Yigin'indir; yıkıcısı belleği kendisi bırakır.
bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite, 0);
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;  // bellek yetmezse std::bad_alloc istisnası atılır
}

bool yigin_bos_mu(const Yigin& y) { return y.boyut == 0; }

bool yigin_dolu_mu(const Yigin& y) { return y.boyut == y.kapasite; }

// Taşma: yığın doluysa false döner ve yığın değişmez
bool yigin_it(Yigin& y, int x)
{
    if (yigin_dolu_mu(y)) {
        return false;
    }
    y.veri[y.boyut] = x;
    y.boyut++;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
    return true;
}

// Alt taşma: yığın boşsa false döner; x değişmez
bool yigin_cikar(Yigin& y, int& x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    y.boyut--;
    x = y.veri[y.boyut];
    cikar_sayisi++;
    return true;
}

// Tepedeki elemanı çıkarmadan okur
bool yigin_tepe(const Yigin& y, int& x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    x = y.veri[y.boyut - 1];
    return true;
}

static void yigin_yaz(const Yigin& y)
{
    std::cout << "taban [";
    for (int i = 0; i < y.boyut; i++) {
        std::cout << (i > 0 ? " " : "") << y.veri[i];
    }
    std::cout << "] tepe";
}

// Ondalık sayıyı ikiliye çevirir: kalanlar yığına, sonra ters sırada
static void ikiliye_cevir(int sayi)
{
    Yigin y;
    yigin_olustur(y, 32);
    std::cout << "  " << sayi << " ->";
    for (int n = sayi; n > 0; n /= 2) {
        yigin_it(y, n % 2);
        std::cout << " " << n % 2;
    }
    std::cout << "  (kalanlar üretildiği sırada)\n  ikili: ";
    int b;
    while (yigin_cikar(y, b)) {
        std::cout << b;
    }
    std::cout << "  (yığından çıkış sırası)\n";
}

static void rastgele_sinama(int islem, int kapasite)
{
    Yigin y;
    yigin_olustur(y, kapasite);
    long long it0 = it_sayisi, cikar0 = cikar_sayisi;
    int tasma = 0, alt_tasma = 0, x;
    rastgele_tohum(42);
    for (int k = 0; k < islem; k++) {
        if (rastgele_aralik(0, 1) == 0) {
            if (!yigin_it(y, rastgele_aralik(0, 999))) {
                tasma++;
            }
        } else if (!yigin_cikar(y, x)) {
            alt_tasma++;
        }
    }
    long long basarili = (it_sayisi - it0) + (cikar_sayisi - cikar0);
    long long fark = (it_sayisi - it0) - (cikar_sayisi - cikar0);
    std::cout << "  " << islem << " işlem, kapasite " << kapasite
              << ": başarılı = " << basarili << ", taşma = " << tasma
              << ", alt taşma = " << alt_tasma << "\n";
    std::cout << "  son boyut = " << y.boyut << "; it - çıkar = " << fark
              << "; tutarlı mı? " << (y.boyut == fark ? "evet" : "HAYIR")
              << "\n";
}

int main()
{
    Yigin y;
    int x;
    yigin_olustur(y, 4);
    std::cout << "1) Kapasitesi 4 olan yığına 10, 20, 30, 40, 50 itilir\n";
    for (int k = 1; k <= 5; k++) {
        bool tamam = yigin_it(y, 10 * k);
        std::cout << "  it " << 10 * k << " -> "
                  << (tamam ? "evet" : "HAYIR (taşma: yığın dolu)") << "  ";
        yigin_yaz(y);
        std::cout << "  boyut = " << y.boyut << "\n";
    }

    std::cout << "\n2) Tepeye bakma ve çıkarma (LIFO: son giren ilk çıkar)\n";
    if (yigin_tepe(y, x)) {
        std::cout << "  tepe -> " << x << " (çıkarılmadı)\n";
    }
    for (int k = 0; k < 5; k++) {
        if (yigin_cikar(y, x)) {
            std::cout << "  çıkar -> " << x << "  ";
        } else {
            std::cout << "  çıkar -> HAYIR (alt taşma: yığın boş)  ";
        }
        yigin_yaz(y);
        std::cout << "\n";
    }
    std::cout << "  tepe -> "
              << (yigin_tepe(y, x) ? "?" : "HAYIR (boş yığın)") << "\n";
    std::cout << "  sayaçlar: it = " << it_sayisi << ", çıkar = "
              << cikar_sayisi << ", en büyük derinlik = "
              << en_buyuk_derinlik << "\n";

    std::cout << "\n3) Uygulama: ondalıktan ikiliye (kalanlar yığına)\n";
    ikiliye_cevir(2026);
    ikiliye_cevir(37);

    std::cout << "\n4) Rastgele it/çıkar dizisi (tohum 42): sözleşme "
                 "denetimi\n";
    rastgele_sinama(100000, 8);
    rastgele_sinama(100000, 1000);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int> (push, pop,
 * top, empty; boş yığında pop/top tanımsız davranış); Python — list
 * (append, pop, a[-1]; boş listede pop IndexError verir). */

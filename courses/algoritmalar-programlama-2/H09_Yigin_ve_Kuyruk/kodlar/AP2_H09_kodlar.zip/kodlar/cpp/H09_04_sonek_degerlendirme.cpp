/* H09_04_sonek_degerlendirme.cpp — AP-2 Hafta 9 · Örnek 4 (★★)
 * Amaç    : Sonek (postfix, RPN) ifade değerlendirme: işlenen yığını;
 *           çok basamaklı tamsayılar, + - * / ^ ve tekli eksi ~; işlenen
 *           sırası a − b (önce b çıkar); sıfıra bölme, eksik/fazla işlenen,
 *           taşma hataları; bölme sıfıra doğru keser (C kuralı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_04_sonek_degerlendirme.cpp -o H09_04_sonek_degerlendirme
 * Çalıştır: ./H09_04_sonek_degerlendirme \
 *           < ../girdiler/H09_04_sonek_degerlendirme.txt
 * Eşleri  : c/H09_04_sonek_degerlendirme.c ·
 *           python/H09_04_sonek_degerlendirme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <climits>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

enum { HATA_YOK, SIFIRA_BOLME, EKSIK_ISLENEN, FAZLA_ISLENEN,
       GECERSIZ_BELIRTEC, TASMA, NEGATIF_US, BOS_IFADE };

static const char *const HATA_ILETISI[] = {
    "yok", "sıfıra bölme", "eksik işlenen", "fazla işlenen",
    "geçersiz belirteç", "taşma (int aralığı dışında)", "negatif üs",
    "boş ifade"};

struct Yigin {
    std::vector<int> veri;  // sabit uzunluk: kapasite
    int kapasite = 0;
    int boyut = 0;
};

static long long it_sayisi = 0, cikar_sayisi = 0;
static int en_buyuk_derinlik = 0;

static bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite, 0);
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;
}

static bool yigin_it(Yigin& y, int x)
{
    if (y.boyut == y.kapasite) {
        return false;
    }
    y.veri[y.boyut++] = x;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
    return true;
}

static bool yigin_cikar(Yigin& y, int& x)
{
    if (y.boyut == 0) {
        return false;
    }
    x = y.veri[--y.boyut];
    cikar_sayisi++;
    return true;
}

// a^b (b >= 0); |a| >= 2 için en çok 31 adımda taşma yakalanır
static int us_al(int a, int b, int& sonuc)
{
    if (a == 0 || a == 1) {
        sonuc = (b == 0) ? 1 : a;
        return HATA_YOK;
    }
    if (a == -1) {
        sonuc = (b % 2 == 0) ? 1 : -1;
        return HATA_YOK;
    }
    long long r = 1;
    for (int k = 0; k < b; k++) {
        r *= a;
        if (r < INT_MIN || r > INT_MAX) {
            return TASMA;
        }
    }
    sonuc = static_cast<int>(r);
    return HATA_YOK;
}

// a op b: sonuç long long'da hesaplanır, int aralığı denetlenir
static int islem_uygula(char op, int a, int b, int& sonuc)
{
    long long r;
    if (op == '+') {
        r = static_cast<long long>(a) + b;
    } else if (op == '-') {
        r = static_cast<long long>(a) - b;
    } else if (op == '*') {
        r = static_cast<long long>(a) * b;
    } else if (op == '/') {
        if (b == 0) {
            return SIFIRA_BOLME;
        }
        r = static_cast<long long>(a) / b;  // C++: sıfıra doğru kesme
    } else {
        if (b < 0) {
            return NEGATIF_US;
        }
        return us_al(a, b, sonuc);
    }
    if (r < INT_MIN || r > INT_MAX) {
        return TASMA;
    }
    sonuc = static_cast<int>(r);
    return HATA_YOK;
}

static void yigin_yaz(const Yigin& y)
{
    std::cout << "[";
    for (int i = 0; i < y.boyut; i++) {
        std::cout << (i > 0 ? " " : "") << y.veri[i];
    }
    std::cout << "]";
}

// s: boşlukla ayrılmış belirteçler. Hata kodu döner; sutun hatalı belirtecin
// 1 tabanlı konumu, kalan ifade sonunda yığındaki değer sayısı
int sonek_degerlendir(const std::string& s, int& sonuc, int& sutun,
                      int& kalan, bool iz)
{
    int n = static_cast<int>(s.size());
    Yigin y;
    int hata = HATA_YOK;
    yigin_olustur(y, n / 2 + 1);
    int i = 0;
    while (hata == HATA_YOK) {
        while (i < n && (s[i] == ' ' || s[i] == '\t')) {
            i++;
        }
        if (i == n) {
            break;
        }
        int bas = i;
        while (i < n && s[i] != ' ' && s[i] != '\t') {
            i++;
        }
        std::string belirtec = s.substr(bas, i - bas);
        sutun = bas + 1;
        char c = s[bas];
        int a, b, r;
        if (c >= '0' && c <= '9') {
            long long v = 0;
            for (int k = bas; k < i && hata == HATA_YOK; k++) {
                if (s[k] < '0' || s[k] > '9') {
                    hata = GECERSIZ_BELIRTEC;
                } else {
                    v = 10 * v + (s[k] - '0');
                    hata = (v > INT_MAX) ? TASMA : HATA_YOK;
                }
            }
            if (hata == HATA_YOK) {
                yigin_it(y, static_cast<int>(v));
            }
        } else if (belirtec == "~") {
            if (!yigin_cikar(y, a)) {
                hata = EKSIK_ISLENEN;
            } else if (a == INT_MIN) {
                hata = TASMA;
            } else {
                yigin_it(y, -a);
            }
        } else if (belirtec.size() == 1 &&
                   std::string("+-*/^").find(c) != std::string::npos) {
            if (!yigin_cikar(y, b) || !yigin_cikar(y, a)) {
                hata = EKSIK_ISLENEN;  // önce b (tepe), sonra a
            } else {
                hata = islem_uygula(c, a, b, r);
                if (hata == HATA_YOK) {
                    yigin_it(y, r);
                }
            }
        } else {
            hata = GECERSIZ_BELIRTEC;
        }
        if (iz) {
            std::cout << "    " << std::left << std::setw(11) << belirtec
                      << std::right << " -> yığın: ";
            yigin_yaz(y);
            std::cout << "\n";
        }
    }
    kalan = y.boyut;
    if (hata == HATA_YOK) {
        sutun = n + 1;
        if (y.boyut == 0) {
            hata = BOS_IFADE;
        } else if (y.boyut > 1) {
            hata = FAZLA_ISLENEN;
        } else {
            sonuc = y.veri[0];
        }
    }
    return hata;
}

static void satir_isle(const std::string& s, bool iz, int& gecerli)
{
    int sonuc = 0, sutun = 0, kalan = 0;
    it_sayisi = cikar_sayisi = 0;
    en_buyuk_derinlik = 0;
    if (iz) {
        std::cout << "  " << s << "\n";
    }
    int hata = sonek_degerlendir(s, sonuc, sutun, kalan, iz);
    if (iz) {
        std::cout << "    sonuç: ";
    } else {
        std::cout << "  " << std::left << std::setw(22) << s << std::right
                  << " ";
    }
    if (hata == HATA_YOK) {
        std::cout << "= " << sonuc;
        gecerli++;
    } else if (hata == FAZLA_ISLENEN) {
        std::cout << "-> HATA ifade sonu: " << HATA_ILETISI[hata]
                  << " (yığında " << kalan << " değer kaldı)";
    } else if (hata == BOS_IFADE) {
        std::cout << "-> HATA: " << HATA_ILETISI[hata];
    } else {
        std::cout << "-> HATA sütun " << sutun << ": " << HATA_ILETISI[hata];
    }
    std::cout << "   [it " << it_sayisi << ", çıkar " << cikar_sayisi
              << ", derinlik " << en_buyuk_derinlik << "]\n";
}

int main()
{
    std::string satir;
    int gecerli = 0, toplam = 0;
    std::cout << "1) Yığın izi: her belirteçten sonra işlenen yığını "
                 "(taban solda)\n";
    satir_isle("5 1 2 + 4 * + 3 -", true, gecerli);
    satir_isle("10 3 -", true, gecerli);
    satir_isle("2 3 2 ^ ^", true, gecerli);

    std::cout << "\n2) Girdi dosyasındaki ifadeler\n";
    gecerli = 0;
    while (std::getline(std::cin, satir)) {
        satir_isle(satir, false, gecerli);
        toplam++;
    }
    std::cout << "  toplam " << toplam << " ifade: geçerli " << gecerli
              << ", hatalı " << toplam - gecerli << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int> ile aynı
 * algoritma; Python — list (append/pop). Hazır sonek değerlendirici
 * standart kütüphanelerde yoktur (HP-35 gibi RPN hesap makineleri ve
 * PostScript, JVM, CPython yığın makineleri bu ilkeyle çalışır). */

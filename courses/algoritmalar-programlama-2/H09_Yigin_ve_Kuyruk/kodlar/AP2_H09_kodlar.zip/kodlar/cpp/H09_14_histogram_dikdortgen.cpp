/* H09_14_histogram_dikdortgen.cpp — AP-2 Hafta 9 · Örnek 14 (★★★)
 * Amaç    : (Meydan okuma) Histogramdaki en büyük dikdörtgen: yükseklikleri
 *           artan sırada tutan monotonik yığın; bir çubuk çıkarıldığında
 *           solundaki ilk kısa çubuk yığında altındaki, sağındaki ilk kısa
 *           çubuk o anki i'dir → genişlik = i - sol - 1. Θ(n); O(n^2)
 *           kâhinle sınanır
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_14_histogram_dikdortgen.cpp -o H09_14_histogram_dikdortgen
 * Çalıştır: ./H09_14_histogram_dikdortgen
 * Eşleri  : c/H09_14_histogram_dikdortgen.c ·
 *           python/H09_14_histogram_dikdortgen.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Yigin {
    std::vector<int> veri;  // çubuk indisleri; yükseklikleri tabandan artar
    int kapasite = 0;
    int boyut = 0;
};

static long long it_sayisi = 0, cikar_sayisi = 0, karsilastirma = 0;
static int en_buyuk_derinlik = 0;

static void sayaclari_sifirla()
{
    it_sayisi = cikar_sayisi = karsilastirma = 0;
    en_buyuk_derinlik = 0;
}

static bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite > 0 ? kapasite : 1, 0);
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;
}

static void yigin_it(Yigin& y, int i)
{
    y.veri[y.boyut++] = i;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
}

static int yigin_cikar(Yigin& y)
{
    cikar_sayisi++;
    return y.veri[--y.boyut];
}

static bool buyuk_esit_mi(int x, int y)
{
    karsilastirma++;
    return x >= y;
}

// h histogramındaki en büyük dikdörtgenin alanı
long long en_buyuk_dikdortgen(const std::vector<int>& h, bool iz)
{
    int n = static_cast<int>(h.size());
    Yigin y;
    long long en_iyi = 0;
    yigin_olustur(y, n);
    for (int i = 0; i <= n; i++) {
        int yuk = (i == n) ? 0 : h[i];  // i == n: tüm yığını boşaltan bekçi
        std::string cikan;
        while (y.boyut > 0 && buyuk_esit_mi(h[y.veri[y.boyut - 1]], yuk)) {
            int t = yigin_cikar(y);
            int sol = (y.boyut > 0) ? y.veri[y.boyut - 1] : -1;
            long long alan = static_cast<long long>(h[t]) * (i - sol - 1);
            if (alan > en_iyi) {
                en_iyi = alan;
            }
            cikan += (cikan.empty() ? "" : " ") + std::to_string(h[t]) + "x" +
                     std::to_string(i - sol - 1) + "=" + std::to_string(alan);
        }
        if (i < n) {
            yigin_it(y, i);
        }
        if (iz) {
            std::string ic = "[";
            for (int q = 0; q < y.boyut; q++) {
                ic += (q > 0 ? " " : "") + std::to_string(h[y.veri[q]]);
            }
            ic += "]";
            if (i < n) {
                std::cout << "  " << std::setw(2) << i << " " << std::setw(4)
                          << yuk << "   ";
            } else {
                std::cout << "  son  (0)  ";
            }
            std::cout << std::left << std::setw(14) << ic << std::right << " "
                      << std::setw(4) << en_iyi << "   "
                      << (cikan.empty() && i < n ? "-" : cikan) << "\n";
        }
    }
    return en_iyi;
}

// Kâhin: her sol uç için en kısa çubuğu taşıyarak sağa genişlet, O(n^2)
static long long kaba_kuvvet(const std::vector<int>& h)
{
    int n = static_cast<int>(h.size());
    long long en_iyi = 0;
    for (int i = 0; i < n; i++) {
        int en_kisa = h[i];
        for (int j = i; j < n; j++) {
            if (h[j] < en_kisa) {
                en_kisa = h[j];
            }
            long long alan = static_cast<long long>(en_kisa) * (j - i + 1);
            if (alan > en_iyi) {
                en_iyi = alan;
            }
        }
    }
    return en_iyi;
}

int main()
{
    const std::vector<int> h = {2, 4, 3, 5, 1, 4, 4, 2};
    std::cout << "1) İzleme: h = [2 4 3 5 1 4 4 2] (çıkan çubuk: yükseklik x "
                 "genişlik = alan)\n";
    std::cout << "   i    h   yığın (yük.)   en iyi  çıkanlar\n";
    sayaclari_sifirla();
    long long alan = en_buyuk_dikdortgen(h, true);
    std::cout << "  en büyük alan = " << alan << " (kâhin " << kaba_kuvvet(h)
              << "); it = " << it_sayisi << ", çıkar = " << cikar_sayisi
              << ", karşılaştırma = " << karsilastirma << "\n";

    std::cout << "\n2) Rastgele 2000 histogram (n = 0..60, yükseklik 0..30, "
                 "tohum 42) ve kâhin\n";
    int uyusmazlik = 0, ihlal = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 2000; t++) {
        int n = rastgele_aralik(0, 60);
        std::vector<int> dizi(n);
        for (int i = 0; i < n; i++) {
            dizi[i] = rastgele_aralik(0, 30);
        }
        sayaclari_sifirla();
        uyusmazlik += en_buyuk_dikdortgen(dizi, false) != kaba_kuvvet(dizi);
        ihlal += (it_sayisi + cikar_sayisi > 2LL * n);
    }
    std::cout << "  kâhinle uyuşmazlık = " << uyusmazlik
              << ", it + çıkar > 2n = " << ihlal << "\n";

    std::cout << "\n3) Büyük girdiler (n = 100000): karşılaştırma <= 2n\n";
    std::cout << "  girdi           en büyük alan  karş./n  derinlik\n";
    int n = 100000;
    std::vector<int> b(n);
    const char *ad[] = {"rastgele 0..10^4", "artan           ",
                        "azalan          ", "sabit 7         "};
    rastgele_tohum(42);
    for (int tur = 0; tur < 4; tur++) {
        for (int i = 0; i < n; i++) {
            if (tur == 0) {
                b[i] = rastgele_aralik(0, 10000);
            } else {
                b[i] = (tur == 1) ? i + 1 : (tur == 2) ? n - i : 7;
            }
        }
        sayaclari_sifirla();
        alan = en_buyuk_dikdortgen(b, false);
        std::cout << "  " << ad[tur] << " " << std::setw(14) << alan << " "
                  << std::fixed << std::setprecision(3) << std::setw(8)
                  << static_cast<double>(karsilastirma) / n << " "
                  << std::setw(9) << en_buyuk_derinlik << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack<int> ile
 * aynı algoritma); Python — yok (list yığın olarak). İki boyutlu sürüm
 * (0/1 matriste en büyük dolu dikdörtgen) her satırı bir histogram sayar. */

/*
 * ortak_rastgele.hpp — AP-2 ortak rastgele sayı modülü (C++17, yalnız başlık)
 *
 * Amaç   : C, C++ ve Python'da BİREBİR AYNI sözde rastgele diziyi üreten
 *          64 bitlik doğrusal eşlik üreteci (LCG). std::mt19937 ve
 *          std::uniform_int_distribution gerçekleştirimlere göre farklı
 *          sayılar verebildiğinden ders örneklerinde bu modül kullanılır.
 * Formül : durum = (durum * 6364136223846793005 + 1442695040888963407)
 *          mod 2^64
 *          çıktı = durum >> 33   (31 bit: 0 .. 2^31 - 1)
 * Kullanım:
 *   g++ -std=c++17 -Wall -Wextra -pedantic -O2 ornek.cpp -o ornek
 * Eşleri : ortak_rastgele.h/.c (C), ortak_rastgele.py (Python)
 */
#ifndef ORTAK_RASTGELE_HPP
#define ORTAK_RASTGELE_HPP

#include <cstddef>
#include <cstdint>
#include <vector>

// Varsayılan tohum (C++17 inline değişken: tüm çeviri birimlerinde tek kopya)
inline std::uint64_t rastgele_durum = 2027u;

// Üretecin durumunu verilen tohumla başlatır.
inline void rastgele_tohum(std::uint64_t tohum)
{
    rastgele_durum = tohum;
}

// Bir sonraki sayıyı döndürür: 0 .. 2^31 - 1 (dahil).
inline std::uint32_t rastgele_sayi()
{
    rastgele_durum = rastgele_durum * 6364136223846793005u
                     + 1442695040888963407u;
    return static_cast<std::uint32_t>(rastgele_durum >> 33);
}

// [alt, ust] kapalı aralığında tamsayı döndürür (alt <= ust olmalı).
inline int rastgele_aralik(int alt, int ust)
{
    std::int64_t fark = static_cast<std::int64_t>(ust) - alt + 1;
    std::uint64_t genislik = static_cast<std::uint64_t>(fark);
    std::uint64_t kayma = rastgele_sayi() % genislik;
    return static_cast<int>(alt + static_cast<std::int64_t>(kayma));
}

// [0, 1) aralığında ondalık sayı döndürür.
inline double rastgele_kesir()
{
    return rastgele_sayi() / 2147483648.0; // 2^31
}

// n elemanlı, [alt, ust] aralığındaki sayılardan oluşan vektör döndürür.
inline std::vector<int> rastgele_dizi(std::size_t n, int alt, int ust)
{
    std::vector<int> a(n);
    for (std::size_t i = 0; i < n; i++) {
        a[i] = rastgele_aralik(alt, ust);
    }
    return a;
}

// a vektörünü Fisher–Yates yöntemiyle yerinde karıştırır.
inline void rastgele_karistir(std::vector<int>& a)
{
    if (a.size() < 2) {
        return;
    }
    for (std::size_t i = a.size() - 1; i > 0; i--) {
        int ust = static_cast<int>(i);
        std::size_t j = static_cast<std::size_t>(rastgele_aralik(0, ust));
        int gecici = a[i];
        a[i] = a[j];
        a[j] = gecici;
    }
}

#endif // ORTAK_RASTGELE_HPP

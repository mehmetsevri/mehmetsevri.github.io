/* H09_11_sonraki_buyuk.cpp — AP-2 Hafta 9 · Örnek 11 (★★★)
 * Amaç    : Monotonik yığınla "sonraki büyük eleman" (next greater element):
 *           yığında cevabı henüz bulunmamış indisler azalan değer sırasında
 *           tutulur; her indis bir kez itilir, en çok bir kez çıkarılır →
 *           it + çıkar <= 2n, O(n). O(n^2) kaba kuvvet kâhinle sınanır
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_11_sonraki_buyuk.cpp -o H09_11_sonraki_buyuk
 * Çalıştır: ./H09_11_sonraki_buyuk
 * Eşleri  : c/H09_11_sonraki_buyuk.c · python/H09_11_sonraki_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Yigin {
    std::vector<int> veri;  // a'nın indisleri; değerleri tabandan azalmaz
    int kapasite = 0;
    int boyut = 0;
};

static long long it_sayisi = 0, cikar_sayisi = 0, karsilastirma = 0;
static long long kaba_karsilastirma = 0;
static int en_buyuk_derinlik = 0;

static void sayaclari_sifirla()
{
    it_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0;
    en_buyuk_derinlik = 0;
}

static bool yigin_olustur(Yigin& y, int kapasite)
{
    y.veri.assign(kapasite > 0 ? kapasite : 1, 0);
    y.kapasite = kapasite;
    y.boyut = 0;
    return true;
}

static void yigin_it(Yigin& y, int i)
{
    y.veri[y.boyut++] = i;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
}

static int yigin_cikar(Yigin& y)
{
    cikar_sayisi++;
    return y.veri[--y.boyut];
}

static bool kucuk_mu(int x, int y)
{
    karsilastirma++;
    return x < y;
}

// sonuc[i] = a[i]'nin sağındaki ilk büyük değer; yoksa -1 (a[i] >= 0).
// iz: her adımda cevabı bulunanları (çıkarılanları) ve yığını yazar
void sonraki_buyuk(const std::vector<int>& a, std::vector<int>& sonuc,
                   bool iz)
{
    int n = static_cast<int>(a.size());
    Yigin y;
    yigin_olustur(y, n);
    sonuc.assign(n, 0);
    for (int i = 0; i < n; i++) {
        std::string coz;
        while (y.boyut > 0 && kucuk_mu(a[y.veri[y.boyut - 1]], a[i])) {
            int j = yigin_cikar(y);
            sonuc[j] = a[i];  // a[j]'nin cevabı bulundu
            coz += (coz.empty() ? "" : " ") + std::to_string(a[j]);
        }
        yigin_it(y, i);
        if (iz) {
            std::cout << "  " << std::setw(2) << i << " " << std::setw(5)
                      << a[i] << "   " << std::left << std::setw(13)
                      << (coz.empty() ? "-" : coz) << std::right << " [";
            for (int k = 0; k < y.boyut; k++) {
                std::cout << (k > 0 ? " " : "") << a[y.veri[k]];
            }
            std::cout << "]\n";
        }
    }
    while (y.boyut > 0) {
        sonuc[yigin_cikar(y)] = -1;  // sağda büyüğü olmayanlar
    }
}

// Kâhin: her i için sağa doğru tarama, O(n^2)
static void kaba_kuvvet(const std::vector<int>& a, std::vector<int>& sonuc)
{
    int n = static_cast<int>(a.size());
    sonuc.assign(n, -1);
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            kaba_karsilastirma++;
            if (a[j] > a[i]) {
                sonuc[i] = a[j];
                break;
            }
        }
    }
}

static std::vector<int> girdi_uret(int n, int tur)
{
    std::vector<int> a(n);
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = i;           // artan
        } else if (tur == 1) {
            a[i] = n - i;       // azalan
        } else if (tur == 2) {
            a[i] = 7;           // sabit
        } else {
            a[i] = rastgele_aralik(0, 1000000);
        }
    }
    return a;
}

int main()
{
    const std::vector<int> a = {3, 8, 4, 1, 2, 6, 5, 9, 7};
    std::vector<int> sonuc, s1, s2;
    std::cout << "1) İzleme: a = [3 8 4 1 2 6 5 9 7]\n";
    std::cout << "   i  a[i]   çıkarılanlar  yığın (taban -> tepe, değer)\n";
    sayaclari_sifirla();
    sonraki_buyuk(a, sonuc, true);
    std::cout << "  sonraki büyük:";
    for (int x : sonuc) {
        std::cout << " " << x;
    }
    std::cout << "\n  it = " << it_sayisi << ", çıkar = " << cikar_sayisi
              << ", karşılaştırma = " << karsilastirma
              << ", en büyük derinlik = " << en_buyuk_derinlik << "\n";

    std::cout << "\n2) Girdi türüne göre (n = 1000): yığın O(n), kaba kuvvet "
                 "O(n^2)\n";
    std::cout << "  girdi      it  çıkar  karş.  derinlik   kaba karş.  "
                 "aynı mı\n";
    const char *ad[] = {"artan   ", "azalan  ", "sabit   ", "rastgele"};
    rastgele_tohum(42);
    for (int tur = 0; tur < 4; tur++) {
        std::vector<int> b = girdi_uret(1000, tur);
        sayaclari_sifirla();
        sonraki_buyuk(b, s1, false);
        kaba_kuvvet(b, s2);
        std::cout << "  " << ad[tur] << " " << std::setw(5) << it_sayisi
                  << " " << std::setw(6) << cikar_sayisi << " "
                  << std::setw(6) << karsilastirma << " " << std::setw(9)
                  << en_buyuk_derinlik << " " << std::setw(12)
                  << kaba_karsilastirma << "  "
                  << (s1 == s2 ? "evet" : "HAYIR") << "\n";
    }

    std::cout << "\n3) Rastgele 2000 dizi (n = 0..60, değerler 0..20, tohum "
                 "42) ve kâhin\n";
    int uyusmazlik = 0, sinir_ihlali = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 2000; t++) {
        int k = rastgele_aralik(0, 60);
        std::vector<int> dizi(k);
        for (int i = 0; i < k; i++) {
            dizi[i] = rastgele_aralik(0, 20);
        }
        sayaclari_sifirla();
        sonraki_buyuk(dizi, s1, false);
        kaba_kuvvet(dizi, s2);
        uyusmazlik += (s1 != s2);
        sinir_ihlali += (it_sayisi + cikar_sayisi > 2LL * k);
    }
    std::cout << "  kâhinle uyuşmazlık = " << uyusmazlik
              << ", it + çıkar > 2n olan dizi = " << sinir_ihlali << "\n";

    std::cout << "\n4) Büyüme: rastgele girdi, değerler 0..10^6\n";
    std::cout << "        n     it + çıkar    2n   karş./n\n";
    for (int k = 1000; k <= 100000; k *= 10) {
        rastgele_tohum(42);
        std::vector<int> c = girdi_uret(k, 3);
        sayaclari_sifirla();
        sonraki_buyuk(c, s1, false);
        std::cout << "  " << std::setw(7) << k << " " << std::setw(14)
                  << it_sayisi + cikar_sayisi << " " << std::setw(7) << 2 * k
                  << " " << std::fixed << std::setprecision(3)
                  << std::setw(9) << static_cast<double>(karsilastirma) / k
                  << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack<int> ile
 * aynı algoritma); Python — yok (list yığın olarak). Monotonik yığın;
 * histogramdaki en büyük dikdörtgen (Örnek 14), stok açıklığı (stock span)
 * ve sonraki küçük eleman problemlerinde de kullanılır. */

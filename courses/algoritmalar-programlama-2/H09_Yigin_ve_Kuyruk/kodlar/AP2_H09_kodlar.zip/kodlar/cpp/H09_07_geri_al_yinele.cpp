/* H09_07_geri_al_yinele.cpp — AP-2 Hafta 9 · Örnek 7 (★★)
 * Amaç    : Geri al / yinele (undo/redo) iki yığınla: her işlem geri
 *           yığınına itilir; geri al onu yinele yığınına taşır; YENİ bir
 *           işlem yinele yığınını boşaltır. Komutlar girdi dosyasından;
 *           rastgele komut dizisi durum geçmişi kâhiniyle sınanır
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_07_geri_al_yinele.cpp -o H09_07_geri_al_yinele
 * Çalıştır: ./H09_07_geri_al_yinele < ../girdiler/H09_07_geri_al_yinele.txt
 * Eşleri  : c/H09_07_geri_al_yinele.c · python/H09_07_geri_al_yinele.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const int MAKS_BELGE = 256;

struct Islem {
    char tur;           // '+': yaz (sona ekle), '-': sil (sondan)
    std::string metin;  // eklenen ya da silinen metin
};

struct Dugum {
    Islem islem;
    Dugum *sonraki;
};

static long long it_sayisi = 0, cikar_sayisi = 0, temizlenen = 0;
static long long ayrilan_dugum = 0, serbest_dugum = 0;
static int en_buyuk_derinlik = 0;

struct Yigin;
long long yigin_yok_et(Yigin& y);

// RAII: yıkıcı kalan düğümleri döngüyle siler; kopyalama yasak
struct Yigin {
    Dugum *tepe = nullptr;
    int boyut = 0;
    Yigin() = default;
    Yigin(const Yigin&) = delete;
    Yigin& operator=(const Yigin&) = delete;
    ~Yigin() { yigin_yok_et(*this); }
};

struct Duzenleyici {
    std::string belge;
    Yigin geri;    // yapılan işlemler (tepe: en son)
    Yigin yinele;  // geri alınan işlemler (tepe: en son geri alınan)
};

static void yigin_olustur(Yigin& y)
{
    y.tepe = nullptr;
    y.boyut = 0;
}

// Sahiplik: düğümler yığınındır; kalanlar burada serbest bırakılır
long long yigin_yok_et(Yigin& y)
{
    long long adet = 0;
    while (y.tepe != nullptr) {
        Dugum *d = y.tepe;
        y.tepe = d->sonraki;
        delete d;
        serbest_dugum++;
        adet++;
    }
    y.boyut = 0;
    return adet;
}

static bool yigin_it(Yigin& y, const Islem& i)
{
    Dugum *d = new Dugum{i, y.tepe};  // Islem kopyalanır (metin dahil)
    ayrilan_dugum++;
    y.tepe = d;
    y.boyut++;
    it_sayisi++;
    if (y.boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y.boyut;
    }
    return true;
}

static bool yigin_cikar(Yigin& y, Islem& i)
{
    if (y.tepe == nullptr) {
        return false;
    }
    Dugum *d = y.tepe;
    i = d->islem;
    y.tepe = d->sonraki;
    delete d;
    serbest_dugum++;
    y.boyut--;
    cikar_sayisi++;
    return true;
}

// İşlemi belgeye uygular: yaz → sona ekle, sil → sondan çıkar
static void uygula(std::string& b, const Islem& i)
{
    if (i.tur == '+') {
        b += i.metin;
    } else {
        b.erase(b.size() - i.metin.size());
    }
}

// İşlemin tersini uygular (geri al)
static void ters_uygula(std::string& b, const Islem& i)
{
    Islem ters = i;
    ters.tur = (i.tur == '+') ? '-' : '+';
    uygula(b, ters);
}

// Yeni işlem: uygula, geri yığınına it, yinele yığınını boşalt
static void yeni_islem(Duzenleyici& e, const Islem& i)
{
    uygula(e.belge, i);
    yigin_it(e.geri, i);
    temizlenen += yigin_yok_et(e.yinele);
}

static bool duzenle_yaz(Duzenleyici& e, const std::string& metin)
{
    int u = static_cast<int>(metin.size());
    if (u == 0 || static_cast<int>(e.belge.size()) + u >= MAKS_BELGE) {
        return false;  // boş metin ya da belge dolu
    }
    yeni_islem(e, Islem{'+', metin});
    return true;
}

static bool duzenle_sil(Duzenleyici& e, int k)
{
    int n = static_cast<int>(e.belge.size());
    if (k > n) {
        k = n;
    }
    if (k <= 0) {
        return false;  // silinecek karakter yok
    }
    yeni_islem(e, Islem{'-', e.belge.substr(n - k)});
    return true;
}

static bool geri_al(Duzenleyici& e)
{
    Islem i;
    if (!yigin_cikar(e.geri, i)) {
        return false;
    }
    ters_uygula(e.belge, i);
    yigin_it(e.yinele, i);
    return true;
}

static bool yinele(Duzenleyici& e)
{
    Islem i;
    if (!yigin_cikar(e.yinele, i)) {
        return false;
    }
    uygula(e.belge, i);
    yigin_it(e.geri, i);
    return true;
}

static void duzenleyici_olustur(Duzenleyici& e)
{
    e.belge.clear();
    yigin_olustur(e.geri);
    yigin_olustur(e.yinele);
}

static void duzenleyici_yok_et(Duzenleyici& e)
{
    yigin_yok_et(e.geri);
    yigin_yok_et(e.yinele);
}

// Yığını tabandan tepeye yazar (liste ters sırada: özyinelemeli)
static void tabandan_yaz(const Dugum *d)
{
    if (d == nullptr) {
        return;
    }
    tabandan_yaz(d->sonraki);
    std::cout << (d->sonraki != nullptr ? " " : "") << d->islem.tur << '"'
              << d->islem.metin << '"';
}

static void durum_yaz(const Duzenleyici& e)
{
    std::cout << "    belge: \"" << e.belge << "\"\n    geri  : [";
    tabandan_yaz(e.geri.tepe);
    std::cout << "]\n    yinele: [";
    tabandan_yaz(e.yinele.tepe);
    std::cout << "]\n";
}

static void komut_isle(Duzenleyici& e, const std::string& k)
{
    std::cout << "  > " << k << "\n";
    if (k.compare(0, 4, "yaz ") == 0) {
        if (!duzenle_yaz(e, k.substr(4))) {
            std::cout << "    (reddedildi: boş metin ya da belge dolu)\n";
        }
    } else if (k.compare(0, 4, "sil ") == 0) {
        long n = 0;
        std::size_t son = 0;
        try {
            n = std::stol(k.substr(4), &son);
        } catch (...) {
            son = 0;
        }
        if (son == 0 || son != k.size() - 4 || n < 0) {
            std::cout << "    (hata: geçersiz sayı)\n";
            return;
        }
        if (!duzenle_sil(e, n > MAKS_BELGE ? MAKS_BELGE
                                           : static_cast<int>(n))) {
            std::cout << "    (reddedildi: silinecek karakter yok)\n";
        }
    } else if (k == "geri") {
        if (!geri_al(e)) {
            std::cout << "    (geri alınacak işlem yok)\n";
        }
    } else if (k == "yinele") {
        if (!yinele(e)) {
            std::cout << "    (yinelenecek işlem yok)\n";
        }
    } else {
        std::cout << "    (hata: bilinmeyen komut)\n";
        return;
    }
    durum_yaz(e);
}

// Kâhin: belge durumlarının dizisi + etkin indis (geri al = indis - 1)
static void rastgele_sinama(int adim)
{
    Duzenleyici e;
    duzenleyici_olustur(e);
    std::vector<std::string> durum(adim + 1);
    int etkin = 0, son = 0, uyusmazlik = 0, sayac[4] = {0, 0, 0, 0};
    rastgele_tohum(42);
    for (int t = 0; t < adim; t++) {
        int r = rastgele_aralik(0, 3);
        bool tamam;
        if (r == 0) {
            std::string m;
            int u = rastgele_aralik(1, 5);
            for (int q = 0; q < u; q++) {
                m += static_cast<char>('a' + rastgele_aralik(0, 25));
            }
            tamam = duzenle_yaz(e, m);
        } else if (r == 1) {
            tamam = duzenle_sil(e, rastgele_aralik(1, 6));
        } else if (r == 2) {
            tamam = geri_al(e);
            uyusmazlik += (tamam != (etkin > 0));
            etkin -= tamam;
        } else {
            tamam = yinele(e);
            uyusmazlik += (tamam != (etkin < son));
            etkin += tamam;
        }
        if (r <= 1 && tamam) {
            etkin++;
            son = etkin;  // yeni işlem: ileri geçmiş silinir
            durum[etkin] = e.belge;
        }
        sayac[r] += tamam;
        uyusmazlik += (e.belge != durum[etkin]);
    }
    std::cout << "  " << adim << " adım: başarılı yaz " << sayac[0]
              << ", sil " << sayac[1] << ", geri " << sayac[2]
              << ", yinele " << sayac[3] << "\n";
    std::cout << "  son belge uzunluğu " << e.belge.size() << "; geri yığını "
              << e.geri.boyut << ", yinele yığını " << e.yinele.boyut << "\n";
    std::cout << "  durum geçmişi kâhiniyle uyuşmazlık = " << uyusmazlik
              << "\n";
    duzenleyici_yok_et(e);
}

int main()
{
    Duzenleyici e;
    std::string satir;
    duzenleyici_olustur(e);
    std::cout << "1) Komutlar (girdi dosyasından); yığınlar tabandan tepeye, "
                 "+ yaz, - sil\n";
    while (std::getline(std::cin, satir)) {
        komut_isle(e, satir);
    }
    std::cout << "  sayaçlar: it = " << it_sayisi << ", çıkar = "
              << cikar_sayisi << ", yeni işlemle temizlenen yinele kaydı = "
              << temizlenen << ", en büyük derinlik = " << en_buyuk_derinlik
              << "\n";
    duzenleyici_yok_et(e);

    std::cout << "\n2) Rastgele 20000 komut (tohum 42) ve kâhin\n";
    rastgele_sinama(20000);
    std::cout << "  düğüm: ayrılan = " << ayrilan_dugum << ", serbest = "
              << serbest_dugum << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — iki std::stack<Islem>;
 * Python — iki list (append/pop). Gerçek düzenleyiciler geri alma geçmişini
 * çoğunlukla sınırlar (en eski kayıt atılır: dairesel tampon ya da iki uçlu
 * kuyruk). */

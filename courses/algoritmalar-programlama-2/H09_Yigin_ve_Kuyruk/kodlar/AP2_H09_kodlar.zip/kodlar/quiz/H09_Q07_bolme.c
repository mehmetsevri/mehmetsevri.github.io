/* H09_Q07_bolme.c — AP-2 Hafta 9 · Quiz S7 (diller arası okuma)
 * Amaç    : H09_Q07_bolme.py'nin C karşılığı: -7 / 2 ve -7 % 2
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_Q07_bolme.c \
 *           -o H09_Q07_bolme
 * Çalıştır: ./H09_Q07_bolme
 */
#include <stdio.h>

int main(void)
{
    int a = -7, b = 2;
    printf("%d %d\n", a / b, a % b);
    return 0;
}

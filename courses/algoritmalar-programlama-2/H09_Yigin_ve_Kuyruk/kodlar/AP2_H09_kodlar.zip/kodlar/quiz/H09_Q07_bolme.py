"""H09_Q07_bolme.py — AP-2 Hafta 9 · Quiz S7 (diller arası okuma)
Amaç    : H09_Q07_bolme.c'nin Python karşılığı: -7 // 2 ve -7 % 2
Çalıştır: python3 H09_Q07_bolme.py
"""


def main():
    a, b = -7, 2
    print(a // b, a % b)


if __name__ == "__main__":
    main()

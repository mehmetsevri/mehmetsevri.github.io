"""H09_Q08_pop0.py — AP-2 Hafta 9 · Quiz S8 (karmaşıklık)
Amaç    : Python listesini kuyruk gibi kullanan döngünün maliyeti
Çalıştır: python3 H09_Q08_pop0.py
"""


def kuyrugu_bosalt(q):
    toplam = 0
    while q:
        toplam += q.pop(0)
    return toplam


def main():
    print(kuyrugu_bosalt(list(range(1, 11))))


if __name__ == "__main__":
    main()

/* H09_Q01_yigin_izleme.c — AP-2 Hafta 9 · Quiz S1 (izleme)
 * Amaç    : Dizi tabanlı yığında it (y[n++] = x) ve çıkar (y[--n])
 *           işlemlerinin izlenmesi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_Q01_yigin_izleme.c \
 *           -o H09_Q01_yigin_izleme
 * Çalıştır: ./H09_Q01_yigin_izleme
 */
#include <stdio.h>

int main(void)
{
    int y[8], n = 0;
    y[n++] = 1;
    y[n++] = 2;
    y[n++] = 3;
    printf("%d ", y[--n]);
    y[n++] = 4;
    printf("%d ", y[--n]);
    printf("%d\n", y[--n]);
    return 0;
}

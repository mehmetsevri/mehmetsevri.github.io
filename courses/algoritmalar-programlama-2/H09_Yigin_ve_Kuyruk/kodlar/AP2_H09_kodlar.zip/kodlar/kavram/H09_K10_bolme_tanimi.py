"""H09_K10_bolme_tanimi.py — AP-2 Hafta 9 · Kavram K10 (Dil Penceresi)
Amaç    : Python'da // aşağı yuvarlar (7 // -2 = -4) ve % bölenin
          işaretini alır; C'nin kesmesi kesik_bol ile elle kurulur (Örnek
          4 ve 6 bu fonksiyonu kullanır). int(a / b) kayan noktaya gider
          ve büyük sayılarda yanlış sonuç verebilir
Çalıştır: python3 H09_K10_bolme_tanimi.py
Eşleri  : kavram/H09_K10_bolme_tanimi.c
"""


def kesik_bol(a, b):
    """C'deki gibi sıfıra doğru kesen bölme (// aşağı yuvarlar)"""
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q


def main():
    print("   a    b  a // b   a % b  kesik_bol(a, b)")
    for a, b in ((7, 2), (-7, 2), (7, -2), (-7, -2)):
        print(f"{a:4d} {b:4d} {a // b:7d} {a % b:7d} {kesik_bol(a, b):16d}")
    x = 10 ** 17 + 1
    print(f"x = 10**17 + 1: kesik_bol(x, 1) = {kesik_bol(x, 1)}, "
          f"int(x / 1) = {int(x / 1)}")
    print("Python: // aşağı yuvarlar; % bölenin işaretini alır")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: divmod(a, b) == (a // b, a % b) (taban bölmesi);
# C'nin div() ve C++'ın std::div'i sıfıra doğru keser.

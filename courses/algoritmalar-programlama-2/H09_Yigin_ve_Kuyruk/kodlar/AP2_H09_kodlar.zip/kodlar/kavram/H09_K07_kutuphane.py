"""H09_K07_kutuphane.py — AP-2 Hafta 9 · Kavram K07 (Dil Penceresi)
Amaç    : Kütüphane karşılıkları (merdivende yalnızca kâhin ve dosya sonu
          notunda geçenler): list yığın olarak (append/pop, sona O(1)),
          collections.deque (iki uçtan O(1); maxlen ile sınırlı tampon:
          dolunca EN ESKİ eleman sessizce atılır) ve iş parçacığı güvenli
          queue.Queue / queue.LifoQueue. Boş listede pop() IndexError verir.
Çalıştır: python3 H09_K07_kutuphane.py
"""
import queue
from collections import deque


def main():
    y = []
    for k in (10, 20, 30):
        y.append(k)
    print(f"list yığın: tepe = {y[-1]}, çıkış sırası: "
          f"{y.pop()} {y.pop()} {y.pop()}")
    try:
        y.pop()
    except IndexError as e:
        print(f"boş listede pop() -> IndexError: {e}")

    d = deque([2, 3])
    d.appendleft(1)
    d.append(4)
    print(f"deque: ön = {d[0]}, arka = {d[-1]}; popleft = {d.popleft()}, "
          f"pop = {d.pop()}; kalan {list(d)}")
    tampon = deque(maxlen=3)
    for k in range(1, 6):
        tampon.append(k)
    print(f"deque(maxlen=3) içine 1..5 eklenince: {list(tampon)} "
          "(taşma politikası: en eskinin üzerine yaz)")

    q = queue.Queue()
    ly = queue.LifoQueue()
    for k in (1, 2, 3):
        q.put(k)
        ly.put(k)
    print(f"queue.Queue (FIFO): {q.get()} {q.get()} {q.get()}; "
          f"queue.LifoQueue (LIFO): {ly.get()} {ly.get()} {ly.get()}")
    try:
        q.get_nowait()
    except queue.Empty:
        print("boş Queue'da get_nowait() -> queue.Empty (get() ise bekler)")


if __name__ == "__main__":
    main()

/* yigin_liste.c — AP-2 Hafta 9 · Kavram K01: yigin.h'nin LİSTE gerçekleştirimi
 * Tek bağlı liste: tepe = listenin başı; it ve çıkar O(1) (her it bir
 * malloc). struct Yigin'in alanları yalnızca bu dosyada görünür.
 */
#include <stdlib.h>

#include "yigin.h"

typedef struct Dugum {
    int deger;
    struct Dugum *sonraki;
} Dugum;

struct Yigin {
    Dugum *tepe;
    int boyut;
};

Yigin *yigin_olustur(void)
{
    Yigin *y = malloc(sizeof *y);
    if (y != NULL) {
        y->tepe = NULL;
        y->boyut = 0;
    }
    return y;
}

void yigin_yok_et(Yigin *y)
{
    if (y == NULL) {
        return;
    }
    while (y->tepe != NULL) {
        Dugum *d = y->tepe;
        y->tepe = d->sonraki;
        free(d);
    }
    free(y);
}

bool yigin_it(Yigin *y, int x)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return false;
    }
    d->deger = x;
    d->sonraki = y->tepe;
    y->tepe = d;
    y->boyut++;
    return true;
}

bool yigin_cikar(Yigin *y, int *x)
{
    if (y->tepe == NULL) {
        return false;
    }
    Dugum *d = y->tepe;
    *x = d->deger;
    y->tepe = d->sonraki;
    free(d);
    y->boyut--;
    return true;
}

bool yigin_tepe(const Yigin *y, int *x)
{
    if (y->tepe == NULL) {
        return false;
    }
    *x = y->tepe->deger;
    return true;
}

bool yigin_bos_mu(const Yigin *y) { return y->tepe == NULL; }

int yigin_boyut(const Yigin *y) { return y->boyut; }

const char *yigin_gerceklestirim(void)
{
    return "tek bağlı liste (her it bir düğüm)";
}

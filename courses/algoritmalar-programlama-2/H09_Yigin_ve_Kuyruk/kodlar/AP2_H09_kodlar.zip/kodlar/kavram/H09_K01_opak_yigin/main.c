/* main.c — AP-2 Hafta 9 · Kavram K01: opak yığını kullanan program
 * Yalnızca yigin.h'yi bilir; AYNI main.c iki gerçekleştirimle de derlenir
 * ve stdout'a AYNI çıktıyı yazar (arayüz–gerçekleştirim ayrımı). Hangi
 * gerçekleştirimin bağlandığı stderr'e yazılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 main.c yigin_dizi.c \
 *           -o yigin_dizi
 *           gcc -std=c17 -Wall -Wextra -pedantic -O2 main.c yigin_liste.c \
 *           -o yigin_liste
 * Çalıştır: ./yigin_dizi > dizi.txt ; ./yigin_liste > liste.txt ;
 *           cmp dizi.txt liste.txt      (fark yok)
 */
#include <stdio.h>

#include "yigin.h"

int main(void)
{
    Yigin *y = yigin_olustur();
    int x;
    if (y == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    fprintf(stderr, "gerçekleştirim: %s\n", yigin_gerceklestirim());
    for (int k = 1; k <= 10; k++) {
        yigin_it(y, k * k);
    }
    yigin_tepe(y, &x);
    printf("10 kare itildi: boyut = %d, tepe = %d\n", yigin_boyut(y), x);
    printf("3 kez çıkar:");
    for (int k = 0; k < 3; k++) {
        if (yigin_cikar(y, &x)) {
            printf(" %d", x);
        }
    }
    printf("; boyut = %d\n", yigin_boyut(y));

    long long toplam = 0;
    for (int k = 0; k < 100000; k++) {
        yigin_it(y, k);
    }
    while (yigin_cikar(y, &x)) {
        toplam += x;
    }
    printf("100000 it + hepsini çıkar: toplam = %lld, boş mu? %s\n", toplam,
           yigin_bos_mu(y) ? "evet" : "hayır");
    printf("boş yığından çıkar: %s\n",
           yigin_cikar(y, &x) ? "?" : "false (alt taşma bildirildi)");
    /* printf("%d\n", y->boyut);   derlenmez: struct Yigin burada eksik
     *                              tiptir (bkz. opak_ihlal.c) */
    yigin_yok_et(y);
    return 0;
}

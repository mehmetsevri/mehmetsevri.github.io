/* yigin.h — AP-2 Hafta 9 · Kavram K01: opak tip ile yığın ADT'si (arayüz)
 * Kullanıcı yalnızca bu dosyayı görür: struct Yigin'in alanları burada
 * YOKTUR (eksik tip, incomplete type). Gerçekleştirim yigin_dizi.c ya da
 * yigin_liste.c'dedir; ikisi de AYNI sözleşmeyi sağlar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 main.c yigin_dizi.c \
 *           -o yigin_dizi
 *           gcc -std=c17 -Wall -Wextra -pedantic -O2 main.c yigin_liste.c \
 *           -o yigin_liste
 */
#ifndef YIGIN_H
#define YIGIN_H

#include <stdbool.h>

typedef struct Yigin Yigin;  /* opak tip: yalnızca işaretçisi kullanılır */

/* Boş yığın oluşturur; bellek yetmezse NULL döner.
 * Sahiplik: dönen yığın çağıranındır; yigin_yok_et ile serbest bırakılır. */
Yigin *yigin_olustur(void);

/* Yığını ve tuttuğu bütün belleği serbest bırakır (NULL güvenlidir). */
void yigin_yok_et(Yigin *y);

/* x'i tepeye iter; yalnızca bellek yetmezse false döner (sınırsız). */
bool yigin_it(Yigin *y, int x);

/* Tepeyi çıkarıp *x'e yazar; yığın boşsa false döner, *x değişmez. */
bool yigin_cikar(Yigin *y, int *x);

/* Tepeyi çıkarmadan *x'e yazar; yığın boşsa false döner. */
bool yigin_tepe(const Yigin *y, int *x);

bool yigin_bos_mu(const Yigin *y);
int yigin_boyut(const Yigin *y);

/* Hangi gerçekleştirimin bağlandığını söyler (yalnızca bilgi amaçlı). */
const char *yigin_gerceklestirim(void);

#endif /* YIGIN_H */

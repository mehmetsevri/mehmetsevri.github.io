/* opak_ihlal.c — AP-2 Hafta 9 · Kavram K01: opak tipin korunması
 * KASITLI DERLEME HATASI İÇERİR — bu hâliyle derlenmez. Kullanıcı kodu
 * struct Yigin'in alanlarına erişmeye ya da boyutunu almaya çalışınca
 * derleyici durdurur: alanlar yalnızca yigin_dizi.c / yigin_liste.c'de
 * tanımlıdır. Derleyici iletisi: ../ciktilar/H09_K01_opak_ihlal.txt
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -c opak_ihlal.c
 */
#include <stdio.h>

#include "yigin.h"

int main(void)
{
    Yigin *y = yigin_olustur();
    printf("boyut = %d\n", y->boyut);          /* HATA: alan görünmez */
    printf("sizeof = %zu\n", sizeof(Yigin));   /* HATA: boyut bilinmez */
    yigin_yok_et(y);
    return 0;
}

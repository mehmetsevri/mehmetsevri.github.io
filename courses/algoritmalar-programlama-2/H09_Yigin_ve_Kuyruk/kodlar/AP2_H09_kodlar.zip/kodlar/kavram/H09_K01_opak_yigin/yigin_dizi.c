/* yigin_dizi.c — AP-2 Hafta 9 · Kavram K01: yigin.h'nin DİZİ gerçekleştirimi
 * Dinamik dizi (H8): dolunca kapasite iki katına çıkar → it amortize O(1).
 * struct Yigin'in alanları yalnızca bu dosyada görünür.
 */
#include <stdlib.h>

#include "yigin.h"

struct Yigin {
    int *veri;     /* veri[0..boyut-1]; tepe veri[boyut-1] */
    int kapasite;
    int boyut;
};

Yigin *yigin_olustur(void)
{
    Yigin *y = malloc(sizeof *y);
    if (y == NULL) {
        return NULL;
    }
    y->kapasite = 4;
    y->boyut = 0;
    y->veri = malloc((size_t)y->kapasite * sizeof *y->veri);
    if (y->veri == NULL) {
        free(y);
        return NULL;
    }
    return y;
}

void yigin_yok_et(Yigin *y)
{
    if (y != NULL) {
        free(y->veri);
        free(y);
    }
}

bool yigin_it(Yigin *y, int x)
{
    if (y->boyut == y->kapasite) {
        int *yeni = realloc(y->veri, 2 * (size_t)y->kapasite * sizeof *yeni);
        if (yeni == NULL) {
            return false;  /* eski dizi geçerli kalır */
        }
        y->veri = yeni;
        y->kapasite *= 2;
    }
    y->veri[y->boyut++] = x;
    return true;
}

bool yigin_cikar(Yigin *y, int *x)
{
    if (y->boyut == 0) {
        return false;
    }
    *x = y->veri[--y->boyut];
    return true;
}

bool yigin_tepe(const Yigin *y, int *x)
{
    if (y->boyut == 0) {
        return false;
    }
    *x = y->veri[y->boyut - 1];
    return true;
}

bool yigin_bos_mu(const Yigin *y) { return y->boyut == 0; }

int yigin_boyut(const Yigin *y) { return y->boyut; }

const char *yigin_gerceklestirim(void)
{
    return "dinamik dizi (kapasite iki katına çıkar)";
}

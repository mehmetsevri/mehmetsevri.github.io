"""H09_K02_dis_bayt_kodu.py — AP-2 Hafta 9 · Kavram K02 (Kaputun Altında)
Amaç    : CPython bir YIĞIN MAKİNESİdir: a + b * c ifadesinin bayt kodu
          (dis modülü) ve her komuttan sonra işlenen yığınının içeriği;
          sabit ifade 3 + 4 * 2 derleme anında 11'e katlanır.
          Çıktı Python sürümüne bağlıdır (3.10'da BINARY_MULTIPLY/BINARY_ADD,
          3.11'de BINARY_OP); kavram/ciktilar/ altındaki dosyalar sürüm
          adıyla etiketlidir.
Çalıştır: python3 H09_K02_dis_bayt_kodu.py
"""
import dis
import sys


def f(a, b, c):
    return a + b * c


def yigin_izle(kod):
    """Komutları sembolik olarak yürütür; her adımda yığını yazar"""
    yigin = []
    for k in dis.get_instructions(kod):
        if k.opname in ("RESUME", "NOP"):
            continue
        if k.opname in ("LOAD_FAST", "LOAD_CONST", "LOAD_NAME"):
            yigin.append(str(k.argval))
        elif k.opname == "BINARY_OP" or k.opname in ("BINARY_ADD",
                                                     "BINARY_MULTIPLY"):
            sag = yigin.pop()
            sol = yigin.pop()
            op = k.argrepr if k.opname == "BINARY_OP" else \
                {"BINARY_ADD": "+", "BINARY_MULTIPLY": "*"}[k.opname]
            yigin.append(f"({sol} {op} {sag})")
        elif k.opname in ("RETURN_VALUE", "STORE_NAME", "POP_TOP"):
            yigin.pop()
        icerik = " | ".join(yigin) if yigin else "(boş)"
        print(f"  {k.opname:<16} {k.argrepr:<6} yığın (taban → tepe): "
              f"{icerik}")


def main():
    s = sys.version_info
    print(f"Python {s.major}.{s.minor}.{s.micro} bayt kodu "
          "(çıktı sürüme bağlıdır)")
    print("\n1) def f(a, b, c): return a + b * c")
    dis.dis(f)
    print("\n2) İşlenen yığını adım adım (önce b * c, sonra a + ...)")
    yigin_izle(f)
    print("\n3) Sabit katlama: x = 3 + 4 * 2")
    kod = compile("x = 3 + 4 * 2", "<ifade>", "exec")
    dis.dis(kod)
    sabitler = [c for c in kod.co_consts if isinstance(c, int)]
    print(f"  co_consts içindeki tamsayılar: {sabitler} "
          "(3, 4 ve 2 ayrı ayrı saklanmaz)")


if __name__ == "__main__":
    main()

/* H09_K04_izgara_dolasma.c — AP-2 Hafta 9 · Kavram K04 (H11'e köprü)
 * Amaç    : Izgarada bölge doldurma (flood fill) üç biçimde: özyinelemeli
 *           (örtük çağrı yığını), açık yığınla (derinlik öncelikli) ve
 *           kuyrukla (genişlik öncelikli: katman katman uzaklık). Aynı
 *           bölgeler bulunur; ziyaret SIRASI ve bellek kullanımı farklıdır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_K04_izgara_dolasma.c -o H09_K04_izgara_dolasma
 * Çalıştır: ./H09_K04_izgara_dolasma            (8 x 12 harita)
 *           ./H09_K04_izgara_dolasma buyuk 2000 (2000 x 2000 boş ızgara:
 *           açık yığın ve kuyruk çalışır; ardından özyinelemeli sürüm
 *           BİLEREK çağrı yığınını taşırır — "Segmentation fault")
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *HARITA[] = {
    "..#.......#.", "..#..###..#.", "###..#.#..##", "....##.#....",
    ".#...#.####.", ".#.#.#......", "...#...#.##.", "####.###.#..",
};

static int S, Y;           /* satır ve sütun sayısı */
static char *izgara;       /* '.' açık, '#' duvar */
static int *isaret;        /* -1: ziyaret edilmedi */
static long en_derin = 0;  /* özyinelemeli sürümün en büyük derinliği */
static const int DS[4] = {1, 0, -1, 0}, DY[4] = {0, 1, 0, -1};

static int acik_mi(int s, int y)
{
    return s >= 0 && s < S && y >= 0 && y < Y && izgara[s * Y + y] == '.' &&
           isaret[s * Y + y] < 0;
}

/* Örtük yığın: her komşu için bir çağrı (derinlik yol uzunluğu kadar) */
static long ozyinelemeli(int s, int y, int etiket, long derinlik)
{
    long sayi = 1;
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    isaret[s * Y + y] = etiket;
    for (int d = 0; d < 4; d++) {
        if (acik_mi(s + DS[d], y + DY[d])) {
            sayi += ozyinelemeli(s + DS[d], y + DY[d], etiket, derinlik + 1);
        }
    }
    return sayi;
}

/* Açık yığın (hücre indisi s*Y + y): itilirken işaretlenir, her hücre
 * en çok bir kez itilir. Sahiplik: yığın burada ayrılır ve bırakılır. */
static long yiginla(int s0, int y0, int etiket, long *en_buyuk)
{
    int *yigin = malloc((size_t)S * Y * sizeof *yigin);
    long boyut = 0, sayi = 0;
    if (yigin == NULL) {
        exit(1);
    }
    isaret[s0 * Y + y0] = etiket;
    yigin[boyut++] = s0 * Y + y0;
    *en_buyuk = 1;
    while (boyut > 0) {
        int h = yigin[--boyut];
        sayi++;
        for (int d = 0; d < 4; d++) {
            int s = h / Y + DS[d], y = h % Y + DY[d];
            if (acik_mi(s, y)) {
                isaret[s * Y + y] = etiket;
                yigin[boyut++] = s * Y + y;
                if (boyut > *en_buyuk) {
                    *en_buyuk = boyut;
                }
            }
        }
    }
    free(yigin);
    return sayi;
}

/* Kuyruk (dairesel tampon): uzaklık katman katman artar; isaret = uzaklık */
static long kuyrukla(int s0, int y0, long *en_buyuk, int *en_uzak)
{
    int kap = S * Y;
    int *q = malloc((size_t)kap * sizeof *q);
    long bas = 0, sayac = 0, sayi = 0;
    if (q == NULL) {
        exit(1);
    }
    isaret[s0 * Y + y0] = 0;
    q[0] = s0 * Y + y0;
    sayac = 1;
    *en_buyuk = 1;
    *en_uzak = 0;
    while (sayac > 0) {
        int h = q[bas];
        bas = (bas + 1) % kap;
        sayac--;
        sayi++;
        if (isaret[h] > *en_uzak) {
            *en_uzak = isaret[h];
        }
        for (int d = 0; d < 4; d++) {
            int s = h / Y + DS[d], y = h % Y + DY[d];
            if (acik_mi(s, y)) {
                isaret[s * Y + y] = isaret[h] + 1;
                q[(bas + sayac) % kap] = s * Y + y;
                sayac++;
                if (sayac > *en_buyuk) {
                    *en_buyuk = sayac;
                }
            }
        }
    }
    free(q);
    return sayi;
}

static void sifirla(void)
{
    for (int i = 0; i < S * Y; i++) {
        isaret[i] = -1;
    }
}

static void bolgeler(int yontem)
{
    int etiket = 0;
    long en_buyuk = 0, toplam_en_buyuk = 0;
    sifirla();
    en_derin = 0;
    for (int i = 0; i < S * Y; i++) {
        if (acik_mi(i / Y, i % Y)) {
            long sayi = yontem == 0
                            ? ozyinelemeli(i / Y, i % Y, etiket, 1)
                            : yiginla(i / Y, i % Y, etiket, &en_buyuk);
            if (en_buyuk > toplam_en_buyuk) {
                toplam_en_buyuk = en_buyuk;
            }
            printf("  bölge %c: %ld hücre\n", 'A' + etiket, sayi);
            etiket++;
        }
    }
    printf("  %s: %d bölge; en büyük %s = %ld\n",
           yontem == 0 ? "özyinelemeli" : "açık yığınla", etiket,
           yontem == 0 ? "çağrı derinliği" : "yığın boyu",
           yontem == 0 ? en_derin : toplam_en_buyuk);
    for (int s = 0; s < S; s++) {
        printf("    ");
        for (int y = 0; y < Y; y++) {
            int e = isaret[s * Y + y];
            printf("%c", e < 0 ? '#' : 'A' + e);
        }
        printf("\n");
    }
}

static int kur(int s, int y, int bos)
{
    S = s;
    Y = y;
    izgara = malloc((size_t)S * Y);
    isaret = malloc((size_t)S * Y * sizeof *isaret);
    if (izgara == NULL || isaret == NULL) {
        return 0;
    }
    for (int i = 0; i < S; i++) {
        for (int j = 0; j < Y; j++) {
            izgara[i * Y + j] = bos ? '.' : HARITA[i][j];
        }
    }
    return 1;
}

int main(int argc, char *argv[])
{
    long en_buyuk;
    int en_uzak;
    if (argc == 3 && strcmp(argv[1], "buyuk") == 0) {
        char *son;
        errno = 0;
        long n = strtol(argv[2], &son, 10);
        if (*son != '\0' || errno != 0 || n < 1 || n > 5000 ||
            !kur((int)n, (int)n, 1)) {
            return 2;
        }
        sifirla();
        long sayi = yiginla(0, 0, 0, &en_buyuk);
        printf("%ld x %ld boş ızgara, açık yığın: %ld hücre, en büyük yığın "
               "%ld\n", n, n, sayi, en_buyuk);
        sifirla();
        sayi = kuyrukla(0, 0, &en_buyuk, &en_uzak);
        printf("kuyruk: %ld hücre, en büyük kuyruk %ld, en uzak %d adım\n",
               sayi, en_buyuk, en_uzak);
        printf("özyinelemeli sürüm deneniyor (derinlik ~%ld olabilir)...\n",
               n * n);
        fflush(stdout);  /* çökme olursa yukarıdaki satırlar kaybolmasın */
        sifirla();
        sayi = ozyinelemeli(0, 0, 0, 1);
        printf("özyinelemeli: %ld hücre, derinlik %ld\n", sayi, en_derin);
    } else {
        kur(8, 12, 0);
        printf("1) Bölgeler: özyinelemeli doldurma (örtük çağrı yığını)\n");
        bolgeler(0);
        printf("\n2) Bölgeler: açık yığınla doldurma (aynı sonuç)\n");
        bolgeler(1);
        printf("\n3) Kuyrukla (3, 0)'dan uzaklık: katman katman "
               "(H11'deki BFS)\n");
        sifirla();
        long sayi = kuyrukla(3, 0, &en_buyuk, &en_uzak);
        for (int s = 0; s < S; s++) {
            printf("    ");
            for (int y = 0; y < Y; y++) {
                int e = isaret[s * Y + y];
                if (e < 0) {
                    printf(izgara[s * Y + y] == '#' ? "  #" : "  .");
                } else {
                    printf("%3d", e);
                }
            }
            printf("\n");
        }
        printf("  ulaşılan %ld hücre, en uzak %d adım, en büyük kuyruk "
               "%ld\n", sayi, en_uzak, en_buyuk);
    }
    free(izgara);
    free(isaret);
    return 0;
}

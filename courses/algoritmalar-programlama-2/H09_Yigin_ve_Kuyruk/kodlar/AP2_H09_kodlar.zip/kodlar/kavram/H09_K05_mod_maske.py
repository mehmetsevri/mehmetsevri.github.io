"""H09_K05_mod_maske.py — AP-2 Hafta 9 · Kavram K05 (Kaputun Altında)
Amaç    : Kapasite 2'nin kuvvetiyse (i + 1) % kapasite ile
          (i + 1) & (kapasite - 1) aynıdır. Python'da % taban bölmesinin
          kalanıdır: -1 % 8 == 7 (C'de -1); Python tamsayıları sonsuz
          ikiye tümleyen gibi davrandığından -1 & 7 de 7'dir.
Çalıştır: python3 H09_K05_mod_maske.py
"""


def iki_kuvveti_mi(k):
    return k != 0 and (k & (k - 1)) == 0


def main():
    print("kapasite  2^k?  k-1 (ikilik)  i=0..999999 içinde i % k != "
          "i & (k-1)")
    for k in (8, 16, 1024, 6, 10, 1000):
        farkli = sum(1 for i in range(1000000) if i % k != i & (k - 1))
        print(f"  {k:6d}  {'evet' if iki_kuvveti_mi(k) else 'hayır':>5}   "
              f"{k - 1:011b}  {farkli:8d}")
    print(f"\nörnek: 13 % 8 = {13 % 8}, 13 & 7 = {13 & 7};  13 % 6 = "
          f"{13 % 6}, 13 & 5 = {13 & 5}")
    print(f"negatif: Python'da -1 % 8 = {-1 % 8} (taban bölmesi), "
          f"-1 & 7 = {-1 & 7}; C'de -1 % 8 = -1 olduğu için C kodunda "
          "(i - 1 + k) % k yazılır")


if __name__ == "__main__":
    main()

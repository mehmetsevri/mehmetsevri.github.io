"""H09_K04_izgara_dolasma.py — AP-2 Hafta 9 · Kavram K04 (H11'e köprü)
Amaç    : Izgarada bölge doldurma (flood fill) üç biçimde: özyinelemeli
          (örtük çağrı yığını), açık yığınla (derinlik öncelikli) ve
          kuyrukla (genişlik öncelikli: katman katman uzaklık). C
          sürümüyle aynı çıktı.
Çalıştır: python3 H09_K04_izgara_dolasma.py           (8 x 12 harita)
          python3 H09_K04_izgara_dolasma.py buyuk 300 (300 x 300 boş
          ızgara: açık yığın ve kuyruk çalışır; özyinelemeli sürüm
          RecursionError verir, program bunu yakalayıp yazar)
"""
import sys

HARITA = ["..#.......#.", "..#..###..#.", "###..#.#..##", "....##.#....",
          ".#...#.####.", ".#.#.#......", "...#...#.##.", "####.###.#.."]
DS, DY = (1, 0, -1, 0), (0, 1, 0, -1)


class Izgara:
    __slots__ = ("S", "Y", "hucre", "isaret", "en_derin")


def kur(s, y, bos):
    g = Izgara()
    g.S, g.Y = s, y
    g.hucre = ["." if bos else HARITA[i][j] for i in range(s)
               for j in range(y)]
    g.isaret = [-1] * (s * y)
    g.en_derin = 0
    return g


def acik_mi(g, s, y):
    return (0 <= s < g.S and 0 <= y < g.Y and g.hucre[s * g.Y + y] == "."
            and g.isaret[s * g.Y + y] < 0)


def ozyinelemeli(g, s, y, etiket, derinlik):
    """Örtük yığın: her komşu için bir çağrı"""
    sayi = 1
    g.en_derin = max(g.en_derin, derinlik)
    g.isaret[s * g.Y + y] = etiket
    for d in range(4):
        if acik_mi(g, s + DS[d], y + DY[d]):
            sayi += ozyinelemeli(g, s + DS[d], y + DY[d], etiket,
                                 derinlik + 1)
    return sayi


def yiginla(g, s0, y0, etiket):
    """Açık yığın (hücre indisi): itilirken işaretlenir; (sayı, en büyük)"""
    yigin = [0] * (g.S * g.Y)  # sabit uzunluk + boyut (elle yığın)
    boyut, sayi = 0, 0
    g.isaret[s0 * g.Y + y0] = etiket
    yigin[boyut] = s0 * g.Y + y0
    boyut += 1
    en_buyuk = 1
    while boyut > 0:
        boyut -= 1
        h = yigin[boyut]
        sayi += 1
        for d in range(4):
            s, y = h // g.Y + DS[d], h % g.Y + DY[d]
            if acik_mi(g, s, y):
                g.isaret[s * g.Y + y] = etiket
                yigin[boyut] = s * g.Y + y
                boyut += 1
                en_buyuk = max(en_buyuk, boyut)
    return sayi, en_buyuk


def kuyrukla(g, s0, y0):
    """Dairesel tampon kuyruk; isaret = uzaklık. (sayı, en büyük, en uzak)"""
    kap = g.S * g.Y
    q = [0] * kap
    bas, sayac, sayi = 0, 1, 0
    g.isaret[s0 * g.Y + y0] = 0
    q[0] = s0 * g.Y + y0
    en_buyuk, en_uzak = 1, 0
    while sayac > 0:
        h = q[bas]
        bas = (bas + 1) % kap
        sayac -= 1
        sayi += 1
        en_uzak = max(en_uzak, g.isaret[h])
        for d in range(4):
            s, y = h // g.Y + DS[d], h % g.Y + DY[d]
            if acik_mi(g, s, y):
                g.isaret[s * g.Y + y] = g.isaret[h] + 1
                q[(bas + sayac) % kap] = s * g.Y + y
                sayac += 1
                en_buyuk = max(en_buyuk, sayac)
    return sayi, en_buyuk, en_uzak


def sifirla(g):
    g.isaret = [-1] * (g.S * g.Y)


def bolgeler(g, yontem):
    etiket = 0
    toplam_en_buyuk = 0
    sifirla(g)
    g.en_derin = 0
    for i in range(g.S * g.Y):
        if acik_mi(g, i // g.Y, i % g.Y):
            if yontem == 0:
                sayi = ozyinelemeli(g, i // g.Y, i % g.Y, etiket, 1)
            else:
                sayi, en_buyuk = yiginla(g, i // g.Y, i % g.Y, etiket)
                toplam_en_buyuk = max(toplam_en_buyuk, en_buyuk)
            print(f"  bölge {chr(ord('A') + etiket)}: {sayi} hücre")
            etiket += 1
    if yontem == 0:
        print(f"  özyinelemeli: {etiket} bölge; en büyük çağrı derinliği = "
              f"{g.en_derin}")
    else:
        print(f"  açık yığınla: {etiket} bölge; en büyük yığın boyu = "
              f"{toplam_en_buyuk}")
    for s in range(g.S):
        print("    " + "".join("#" if g.isaret[s * g.Y + y] < 0
                               else chr(ord("A") + g.isaret[s * g.Y + y])
                               for y in range(g.Y)))


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "buyuk":
        if not sys.argv[2].isdigit() or not 1 <= int(sys.argv[2]) <= 5000:
            return 2
        n = int(sys.argv[2])
        g = kur(n, n, True)
        sayi, en_buyuk = yiginla(g, 0, 0, 0)
        print(f"{n} x {n} boş ızgara, açık yığın: {sayi} hücre, en büyük "
              f"yığın {en_buyuk}")
        sifirla(g)
        sayi, en_buyuk, en_uzak = kuyrukla(g, 0, 0)
        print(f"kuyruk: {sayi} hücre, en büyük kuyruk {en_buyuk}, en uzak "
              f"{en_uzak} adım")
        print(f"özyinelemeli sürüm deneniyor (derinlik ~{n * n} olabilir)...")
        sifirla(g)
        try:
            sayi = ozyinelemeli(g, 0, 0, 0, 1)
            print(f"özyinelemeli: {sayi} hücre, derinlik {g.en_derin}")
        except RecursionError as e:
            print(f"özyinelemeli: RecursionError: {e} (ulaşılan derinlik "
                  f"{g.en_derin}; sınır {sys.getrecursionlimit()})")
        return 0
    g = kur(8, 12, False)
    print("1) Bölgeler: özyinelemeli doldurma (örtük çağrı yığını)")
    bolgeler(g, 0)
    print("\n2) Bölgeler: açık yığınla doldurma (aynı sonuç)")
    bolgeler(g, 1)
    print("\n3) Kuyrukla (3, 0)'dan uzaklık: katman katman (H11'deki BFS)")
    sifirla(g)
    sayi, en_buyuk, en_uzak = kuyrukla(g, 3, 0)
    for s in range(g.S):
        satir = ""
        for y in range(g.Y):
            e = g.isaret[s * g.Y + y]
            if e < 0:
                satir += "  #" if g.hucre[s * g.Y + y] == "#" else "  ."
            else:
                satir += f"{e:3d}"
        print("    " + satir)
    print(f"  ulaşılan {sayi} hücre, en uzak {en_uzak} adım, en büyük kuyruk "
          f"{en_buyuk}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

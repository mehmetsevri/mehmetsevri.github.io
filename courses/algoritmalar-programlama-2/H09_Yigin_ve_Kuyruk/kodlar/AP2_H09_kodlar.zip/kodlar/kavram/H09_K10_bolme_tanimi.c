/* H09_K10_bolme_tanimi.c — AP-2 Hafta 9 · Kavram K10 (Dil Penceresi)
 * Amaç    : Tamsayı bölmesi ve kalan: C bölümü sıfıra doğru keser
 *           (7 / -2 = -3), kalanın işareti bölünenin işaretidir; Örnek 4 ve
 *           6'daki hesap makinesi üç dilde bu tanımı kullanır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_K10_bolme_tanimi.c \
 *           -o H09_K10_bolme_tanimi
 * Çalıştır: ./H09_K10_bolme_tanimi
 * Eşleri  : kavram/H09_K10_bolme_tanimi.py
 */
#include <stdio.h>

int main(void)
{
    const int a[] = {7, -7, 7, -7};
    const int b[] = {2, 2, -2, -2};
    printf("   a    b   a / b   a %% b  (a / b) * b + a %% b\n");
    for (int i = 0; i < 4; i++) {
        printf("%4d %4d %7d %7d %20d\n", a[i], b[i], a[i] / b[i],
               a[i] % b[i], (a[i] / b[i]) * b[i] + a[i] % b[i]);
    }
    printf("C: bölüm sıfıra doğru kesilir; kalanın işareti a'nınkidir\n");
    return 0;
}

/* Kütüphane karşılığı: C — div() aynı tanımı verir (div_t: quot, rem);
 * C++ — std::div; Python — divmod(a, b) TABAN bölmesidir (C'den farklı). */

/* H09_K03_cagri_yigini.c — AP-2 Hafta 9 · Kavram K03 (Kaputun Altında)
 * Amaç    : Özyineleme örtük bir yığındır: toplam(n) = n + toplam(n - 1)
 *           her çağrıda çağrı yığınına bir çerçeve iter. Aynı hesap açık
 *           yığınla (öbekte ayrılan dizi) derinlik sınırına takılmadan yapılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 -g \
 *           H09_K03_cagri_yigini.c -o H09_K03_cagri_yigini
 * Çalıştır: ./H09_K03_cagri_yigini            (n = 1000: ikisi de çalışır)
 *           ./H09_K03_cagri_yigini 10000000   (BİLEREK: özyinelemeli sürüm
 *           çağrı yığınını taşırır ve çöker — "Segmentation fault"; -O2'de
 *           derleyici bu özyinelemeyi döngüye çevirebilir)
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

static long en_derin = 0;

/* Her çağrı bir çerçeve: n, dönüş adresi, kaydedilen yazmaçlar */
long long toplam_ozyinelemeli(long n, long derinlik)
{
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (n == 0) {
        return 0;
    }
    return n + toplam_ozyinelemeli(n - 1, derinlik + 1);
}

/* Açık yığın: önce "çağrıları" it (n, n-1, ..., 1), sonra çıkarıp topla.
 * Sahiplik: yığın dizisi burada ayrılır ve burada serbest bırakılır. */
long long toplam_yiginla(long n, long *en_buyuk)
{
    long *yigin = malloc((size_t)(n > 0 ? n : 1) * sizeof *yigin);
    long boyut = 0;
    long long sonuc = 0;
    if (yigin == NULL) {
        return -1;
    }
    for (long k = n; k > 0; k--) {
        yigin[boyut++] = k;      /* çağrı yerine: çerçeveyi it */
    }
    *en_buyuk = boyut;
    while (boyut > 0) {
        sonuc += yigin[--boyut]; /* dönüş yerine: çerçeveyi çıkar */
    }
    free(yigin);
    return sonuc;
}

int main(int argc, char *argv[])
{
    long n = 1000;
    if (argc > 1) {
        char *son;
        errno = 0;
        n = strtol(argv[1], &son, 10);
        if (*son != '\0' || errno != 0 || n < 0) {
            fprintf(stderr, "kullanım: %s [n >= 0]\n", argv[0]);
            return 2;
        }
    }
    long en_buyuk = 0;
    printf("n = %ld\n", n);
    long long t = toplam_yiginla(n, &en_buyuk);  /* önce çağır: argüman
                                                     sırası belirsizdir */
    printf("açık yığınla   : toplam = %lld, en büyük yığın = %ld eleman "
           "(öbekte)\n", t, en_buyuk);
    fflush(stdout);  /* çökme olursa bu satırlar kaybolmasın */
    long long s = toplam_ozyinelemeli(n, 1);
    printf("özyinelemeyle  : toplam = %lld, en büyük derinlik = %ld çağrı\n",
           s, en_derin);
    printf("kapalı form    : n(n+1)/2 = %lld\n", (long long)n * (n + 1) / 2);
    return 0;
}

/* H09_K03_cagri_yigini.cpp — AP-2 Hafta 9 · Kavram K03 (Kaputun Altında)
 * Amaç    : C sürümünün C++ karşılığı: özyinelemeli toplam(n) çağrı
 *           yığınını kullanır; açık yığın std::vector'deki (öbekte) bir
 *           dizidir. C++ de derinlik sınırı koymaz: taşma yığın boyutuna
 *           (ulimit -s) bağlıdır ve istisna değil çökmedir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O0 -g \
 *           H09_K03_cagri_yigini.cpp -o H09_K03_cagri_yigini
 * Çalıştır: ./H09_K03_cagri_yigini            (n = 1000)
 *           ./H09_K03_cagri_yigini 10000000   (BİLEREK: çöker)
 */
#include <iostream>
#include <string>
#include <vector>

static long en_derin = 0;

long long toplam_ozyinelemeli(long n, long derinlik)
{
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (n == 0) {
        return 0;
    }
    return n + toplam_ozyinelemeli(n - 1, derinlik + 1);
}

// Açık yığın: önce "çağrıları" it, sonra çıkarıp topla
long long toplam_yiginla(long n, long& en_buyuk)
{
    std::vector<long> yigin(n > 0 ? n : 1);  // elle yığın: dizi + boyut
    long boyut = 0;
    long long sonuc = 0;
    for (long k = n; k > 0; k--) {
        yigin[boyut++] = k;       // çağrı yerine: çerçeveyi it
    }
    en_buyuk = boyut;
    while (boyut > 0) {
        sonuc += yigin[--boyut];  // dönüş yerine: çerçeveyi çıkar
    }
    return sonuc;
}

int main(int argc, char *argv[])
{
    long n = 1000;
    if (argc > 1) {
        try {
            std::size_t son = 0;
            n = std::stol(argv[1], &son);
            if (son != std::string(argv[1]).size() || n < 0) {
                throw 0;
            }
        } catch (...) {
            std::cerr << "kullanım: H09_K03_cagri_yigini [n >= 0]\n";
            return 2;
        }
    }
    long en_buyuk = 0;
    std::cout << "n = " << n << "\n";
    long long s = toplam_yiginla(n, en_buyuk);
    std::cout << "açık yığınla   : toplam = " << s << ", en büyük yığın = "
              << en_buyuk << " eleman (öbekte)" << std::endl;
    s = toplam_ozyinelemeli(n, 1);
    std::cout << "özyinelemeyle  : toplam = " << s << ", en büyük derinlik = "
              << en_derin << " çağrı\n";
    std::cout << "kapalı form    : n(n+1)/2 = "
              << static_cast<long long>(n) * (n + 1) / 2 << "\n";
    return 0;
}

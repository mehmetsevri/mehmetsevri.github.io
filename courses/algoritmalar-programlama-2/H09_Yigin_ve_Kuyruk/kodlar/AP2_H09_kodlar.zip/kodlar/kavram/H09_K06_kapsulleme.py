"""H09_K06_kapsulleme.py — AP-2 Hafta 9 · Kavram K06 (Dil Penceresi)
Amaç    : Python'da erişim denetimi yoktur; "gizli" alanlar adlandırma
          geleneğiyle belirtilir: _alan ("dokunma" anlamında bir uyarı),
          __alan (ad bozma, name mangling: _Sinif__alan olur). Hata
          bildirimi istisnayla (IndexError).
Çalıştır: python3 H09_K06_kapsulleme.py
"""


class Yigin:
    __slots__ = ("_veri", "__boyut")

    def __init__(self, kapasite):
        self._veri = [0] * kapasite  # tek alt çizgi: iç ayrıntı (gelenek)
        self.__boyut = 0             # çift alt çizgi: ad bozma

    def it(self, x):
        """Taşma: False (dönüş değeri)"""
        if self.__boyut == len(self._veri):
            return False
        self._veri[self.__boyut] = x
        self.__boyut += 1
        return True

    def cikar(self):
        """Alt taşma: IndexError istisnası (yerleşik list.pop gibi)"""
        if self.__boyut == 0:
            raise IndexError("boş yığından çıkarma")
        self.__boyut -= 1
        return self._veri[self.__boyut]

    def boyut(self):
        return self.__boyut


def main():
    y = Yigin(2)
    print(f"it 1: {y.it(1)}, it 2: {y.it(2)}, it 3: {y.it(3)} "
          "(False = taşma)")
    print(f"boyut = {y.boyut()}")
    print(f"_veri dışarıdan okunabilir (yalnızca gelenek): {y._veri}")
    try:
        print(y.__boyut)
    except AttributeError as e:
        print(f"y.__boyut -> AttributeError: {e}")
    print(f"ama bozulmuş adla erişilebilir: y._Yigin__boyut = "
          f"{y._Yigin__boyut}")
    print(f"çıkar: {y.cikar()}, çıkar: {y.cikar()}")
    try:
        y.cikar()
    except IndexError as e:
        print(f"istisna yakalandı: IndexError: {e}")


if __name__ == "__main__":
    main()

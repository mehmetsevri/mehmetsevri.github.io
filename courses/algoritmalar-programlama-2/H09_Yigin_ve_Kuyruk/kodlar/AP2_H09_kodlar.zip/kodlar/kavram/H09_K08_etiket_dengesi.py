"""H09_K08_etiket_dengesi.py — AP-2 Hafta 9 · Kavram K08
Amaç    : Parantez denetiminin (Örnek 3) etiketlere genellenmesi: <ad>
          açılış, </ad> kapanış, <ad/> kendini kapatan etiket (yığına
          girmez). C sürümüyle aynı çıktı; yığın elle (sabit liste + boyut).
Çalıştır: python3 H09_K08_etiket_dengesi.py
"""
EN_COK, AD_UZ = 32, 16


def etiket_denetle(s):
    """(dengeli mi, ileti) döner"""
    yigin = [""] * EN_COK
    boyut = 0
    p = s.find("<")
    while p >= 0:
        son = s.find(">", p)
        if son < 0:
            return False, "'>' eksik"
        kapanis = s[p + 1] == "/"
        kendi = s[son - 1] == "/"
        ad = s[p + 1 + kapanis:son - kendi]
        if not 0 < len(ad) < AD_UZ:
            return False, "geçersiz etiket"
        if not kendi:
            if not kapanis:
                if boyut == EN_COK:
                    return False, "çok derin"
                yigin[boyut] = ad
                boyut += 1
            elif boyut == 0:
                return False, f"eşleşmeyen kapanış </{ad}>"
            elif yigin[boyut - 1] != ad:
                return False, (f"</{ad}> bulundu, </{yigin[boyut - 1]}> "
                               "bekleniyordu")
            else:
                boyut -= 1
        p = s.find("<", p + 1)
    if boyut > 0:
        return False, (f"{boyut} etiket açık kaldı; en içteki "
                       f"<{yigin[boyut - 1]}>")
    return True, "dengeli"


def main():
    for s in ("<p><b>kalın</b> ve <i>eğik</i></p>",
              "<div><br/><img/>metin</div>",
              "<ul><li>bir</li><li>iki</ul>",
              "<b><i>yanlış</b></i>",
              "metin</p>",
              "<html><body><h1>başlık</h1>"):
        print(f"  {s}\n    -> {etiket_denetle(s)[1]}")


if __name__ == "__main__":
    main()

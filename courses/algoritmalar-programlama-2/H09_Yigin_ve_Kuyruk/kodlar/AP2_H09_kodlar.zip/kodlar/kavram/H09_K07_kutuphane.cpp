/* H09_K07_kutuphane.cpp — AP-2 Hafta 9 · Kavram K07 (Dil Penceresi)
 * Amaç    : Kütüphane karşılıkları (merdivende yalnızca kâhin ve dosya sonu
 *           notunda geçenler): std::stack ve std::queue KAP UYARLAYICILARIdır
 *           (alttaki kap varsayılan olarak std::deque; değiştirilebilir);
 *           std::deque iki uçtan O(1) ekleme/çıkarma sağlar. Boş std::stack
 *           üzerinde pop()/top() TANIMSIZ DAVRANIŞTIR (denetim yok) — bu
 *           yüzden önce empty() sorulur; deque::at() ise std::out_of_range
 *           atar.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_K07_kutuphane.cpp -o H09_K07_kutuphane
 */
#include <deque>
#include <iostream>
#include <list>
#include <queue>
#include <stack>
#include <stdexcept>
#include <vector>

int main()
{
    std::stack<int> y;                         // alttaki kap: std::deque
    std::stack<int, std::vector<int>> yv;      // alttaki kap: std::vector
    std::queue<int, std::list<int>> ql;        // alttaki kap: std::list
    for (int k = 1; k <= 3; k++) {
        y.push(10 * k);
        yv.push(10 * k);
        ql.push(10 * k);
    }
    std::cout << "std::stack tepe = " << y.top() << ", boyut = " << y.size()
              << "\n";
    std::cout << "std::stack<int, std::vector<int>> çıkış sırası:";
    while (!yv.empty()) {           // boşken pop() çağırmak tanımsız
        std::cout << " " << yv.top();
        yv.pop();
    }
    std::cout << "\nstd::queue<int, std::list<int>> çıkış sırası:";
    while (!ql.empty()) {
        std::cout << " " << ql.front();
        ql.pop();
    }
    std::deque<int> d = {2, 3};
    d.push_front(1);
    d.push_back(4);
    std::cout << "\nstd::deque: ön = " << d.front() << ", arka = " << d.back()
              << ", d[2] = " << d[2];
    d.pop_front();
    d.pop_back();
    std::cout << "; iki uçtan çıkarınca boyut = " << d.size() << "\n";
    try {
        std::cout << d.at(5) << "\n";
    } catch (const std::out_of_range&) {
        std::cout << "d.at(5) -> std::out_of_range istisnası (d[5] ise "
                     "denetimsizdir)\n";
    }
    return 0;
}

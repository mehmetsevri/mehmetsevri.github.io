/* H09_K05_mod_maske.c — AP-2 Hafta 9 · Kavram K05 (Kaputun Altında)
 * Amaç    : Kapasite 2'nin kuvvetiyse dairesel tamponda (i + 1) % kapasite
 *           ile (i + 1) & (kapasite - 1) aynıdır (negatif olmayan i için):
 *           kapasite - 1'in ikilik yazımı ...0111'dir ve & yalnızca alt
 *           bitleri bırakır. 2'nin kuvveti olmayan kapasitede eşdeğerlik
 *           bozulur. Negatif sayıda C'nin % işleci negatif kalan verir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_K05_mod_maske.c \
 *           -o H09_K05_mod_maske
 */
#include <stdbool.h>
#include <stdio.h>

static bool iki_kuvveti_mi(unsigned k)
{
    return k != 0 && (k & (k - 1)) == 0;  /* parantezler şart: == önce */
}

static void ikilik_yaz(unsigned x, int bit)
{
    for (int b = bit - 1; b >= 0; b--) {
        putchar((x >> b) & 1u ? '1' : '0');
    }
}

int main(void)
{
    const unsigned kapasiteler[] = {8, 16, 1024, 6, 10, 1000};
    printf("kapasite  2^k?  k-1 (ikilik)  i=0..999999 içinde i %% k != "
           "i & (k-1)\n");
    for (int t = 0; t < 6; t++) {
        unsigned k = kapasiteler[t];
        long farkli = 0;
        for (unsigned i = 0; i < 1000000u; i++) {
            farkli += (i % k) != (i & (k - 1));
        }
        printf("  %6u  %5s   ", k, iki_kuvveti_mi(k) ? "evet" : "hayır");
        ikilik_yaz(k - 1, 11);
        printf("  %8ld\n", farkli);
    }
    printf("\nörnek: 13 %% 8 = %u, 13 & 7 = %u;  13 %% 6 = %u, 13 & 5 = %u\n",
           13u % 8u, 13u & 7u, 13u % 6u, 13u & 5u);
    printf("negatif: C'de -1 %% 8 = %d (sıfıra doğru kesme); geriye sarmada "
           "(i - 1 + k) %% k yazılır: (0 - 1 + 8) %% 8 = %d\n", -1 % 8,
           (0 - 1 + 8) % 8);
    return 0;
}

/* H09_K06_kapsulleme.cpp — AP-2 Hafta 9 · Kavram K06 (Dil Penceresi)
 * Amaç    : C'deki opak struct'ın (K01) C++ karşılığı: sınıf ve private
 *           üyeler. Arayüz (public üye fonksiyonlar) sabit kalırken
 *           gerçekleştirim gizlenir; private alana dışarıdan erişim
 *           DERLEME HATASIDIR (aşağıdaki yorumlu satır). Hata bildirimi:
 *           bool dönüş kodu ya da istisna (std::out_of_range).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_K06_kapsulleme.cpp -o H09_K06_kapsulleme
 */
#include <iostream>
#include <stdexcept>
#include <vector>

class Yigin {
public:
    explicit Yigin(int kapasite) : veri_(kapasite), boyut_(0) {}

    bool it(int x)  // taşma: false (dönüş kodu, C'deki gibi)
    {
        if (boyut_ == static_cast<int>(veri_.size())) {
            return false;
        }
        veri_[boyut_++] = x;
        return true;
    }

    int cikar()  // alt taşma: istisna (C++'a özgü seçenek)
    {
        if (boyut_ == 0) {
            throw std::out_of_range("boş yığından çıkarma");
        }
        return veri_[--boyut_];
    }

    int boyut() const { return boyut_; }

private:  // gerçekleştirim: yalnızca üye fonksiyonlar erişebilir
    std::vector<int> veri_;
    int boyut_;
};

int main()
{
    Yigin y(2);
    std::cout << std::boolalpha << "it 1: " << y.it(1) << ", it 2: "
              << y.it(2) << ", it 3: " << y.it(3) << " (false = taşma)\n";
    std::cout << "boyut = " << y.boyut() << "\n";
    // y.boyut_ = 0;   // derlenmez: 'int Yigin::boyut_' is private
    std::cout << "çıkar: " << y.cikar();
    std::cout << ", çıkar: " << y.cikar() << "\n";
    try {
        y.cikar();
    } catch (const std::out_of_range& e) {
        std::cout << "istisna yakalandı: std::out_of_range: " << e.what()
                  << "\n";
    }
    return 0;
}

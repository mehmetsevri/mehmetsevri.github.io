/* H09_K08_etiket_dengesi.c — AP-2 Hafta 9 · Kavram K08
 * Amaç    : Parantez denetiminin (Örnek 3) etiketlere genellenmesi: <ad>
 *           açılış, </ad> kapanış, <ad/> kendini kapatan etiket (yığına
 *           girmez). Yığında etiket adları tutulur; kapanış tepedeki adla
 *           aynı olmalıdır. (HTML'in gerçek kuralları daha karmaşıktır: bazı
 *           etiketler kapanış gerektirmez.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_K08_etiket_dengesi.c -o H09_K08_etiket_dengesi
 */
#include <stdio.h>
#include <string.h>

#define EN_COK 32
#define AD_UZ 16

typedef struct {
    char ad[EN_COK][AD_UZ];  /* etiket adları; tepe ad[boyut-1] */
    int boyut;
} AdYigini;

/* s'yi denetler; hata iletisini ileti'ye yazar. Dengeliyse 1 döner. */
static int etiket_denetle(const char *s, char *ileti, size_t uz)
{
    AdYigini y = {.boyut = 0};
    for (const char *p = strchr(s, '<'); p != NULL; p = strchr(p + 1, '<')) {
        const char *son = strchr(p, '>');
        if (son == NULL) {
            snprintf(ileti, uz, "'>' eksik");
            return 0;
        }
        int kapanis = (p[1] == '/');
        int kendi = (son[-1] == '/');
        const char *bas = p + 1 + kapanis;
        int n = (int)(son - bas) - kendi;
        if (n <= 0 || n >= AD_UZ) {
            snprintf(ileti, uz, "geçersiz etiket");
            return 0;
        }
        char ad[AD_UZ];
        memcpy(ad, bas, (size_t)n);
        ad[n] = '\0';
        if (kendi) {
            continue;  /* <br/>: açılış + kapanış birlikte */
        }
        if (!kapanis) {
            if (y.boyut == EN_COK) {
                snprintf(ileti, uz, "çok derin");
                return 0;
            }
            strcpy(y.ad[y.boyut++], ad);
        } else if (y.boyut == 0) {
            snprintf(ileti, uz, "eşleşmeyen kapanış </%s>", ad);
            return 0;
        } else if (strcmp(y.ad[y.boyut - 1], ad) != 0) {
            snprintf(ileti, uz, "</%s> bulundu, </%s> bekleniyordu", ad,
                     y.ad[y.boyut - 1]);
            return 0;
        } else {
            y.boyut--;
        }
    }
    if (y.boyut > 0) {
        snprintf(ileti, uz, "%d etiket açık kaldı; en içteki <%s>", y.boyut,
                 y.ad[y.boyut - 1]);
        return 0;
    }
    snprintf(ileti, uz, "dengeli");
    return 1;
}

int main(void)
{
    const char *ornekler[] = {
        "<p><b>kalın</b> ve <i>eğik</i></p>",
        "<div><br/><img/>metin</div>",
        "<ul><li>bir</li><li>iki</ul>",
        "<b><i>yanlış</b></i>",
        "metin</p>",
        "<html><body><h1>başlık</h1>",
    };
    char ileti[96];
    for (int k = 0; k < 6; k++) {
        etiket_denetle(ornekler[k], ileti, sizeof ileti);
        printf("  %s\n    -> %s\n", ornekler[k], ileti);
    }
    return 0;
}

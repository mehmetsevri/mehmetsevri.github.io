/* H09_K09_tarayici_gecmisi.c — AP-2 Hafta 9 · Kavram K09
 * Amaç    : Tarayıcının geri/ileri düğmeleri iki yığındır (Örnek 7'deki
 *           geri al/yinele ile aynı desen): yeni sayfaya gidince eski sayfa
 *           geri yığınına itilir ve ileri yığını boşaltılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_K09_tarayici_gecmisi.c -o H09_K09_tarayici_gecmisi
 */
#include <stdio.h>
#include <string.h>

#define EN_COK 16
#define UZ 24

typedef struct {
    char sayfa[EN_COK][UZ];
    int boyut;
} SayfaYigini;

static void it(SayfaYigini *y, const char *s)
{
    if (y->boyut < EN_COK) {   /* dolunca en yeni sayfa eklenmez */
        strcpy(y->sayfa[y->boyut++], s);
    }
}

static int cikar(SayfaYigini *y, char *s)
{
    if (y->boyut == 0) {
        return 0;
    }
    strcpy(s, y->sayfa[--y->boyut]);
    return 1;
}

static void yaz(const SayfaYigini *y)
{
    printf("[");
    for (int k = 0; k < y->boyut; k++) {
        printf("%s%s", k > 0 ? " " : "", y->sayfa[k]);
    }
    printf("]");
}

int main(void)
{
    const char *komutlar[] = {"git a.com", "git b.com", "git c.com", "geri",
                              "geri", "ileri", "git d.com", "ileri", "geri",
                              "geri", "geri", "geri"};
    SayfaYigini geri = {.boyut = 0}, ileri = {.boyut = 0};
    char simdiki[UZ] = "ana.sayfa", s[UZ];
    for (int k = 0; k < 12; k++) {
        const char *c = komutlar[k];
        const char *not = "";
        if (strncmp(c, "git ", 4) == 0) {
            it(&geri, simdiki);
            strcpy(simdiki, c + 4);
            ileri.boyut = 0;  /* yeni sayfa: ileri geçmiş silinir */
        } else if (strcmp(c, "geri") == 0) {
            if (cikar(&geri, s)) {
                it(&ileri, simdiki);
                strcpy(simdiki, s);
            } else {
                not = "  (geri gidilecek sayfa yok)";
            }
        } else if (cikar(&ileri, s)) {
            it(&geri, simdiki);
            strcpy(simdiki, s);
        } else {
            not = "  (ileri gidilecek sayfa yok)";
        }
        printf("  %-10s şimdiki: %-9s geri: ", c, simdiki);
        yaz(&geri);
        printf("  ileri: ");
        yaz(&ileri);
        printf("%s\n", not);
    }
    return 0;
}

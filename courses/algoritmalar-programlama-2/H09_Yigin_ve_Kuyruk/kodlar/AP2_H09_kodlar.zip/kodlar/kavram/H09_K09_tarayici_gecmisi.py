"""H09_K09_tarayici_gecmisi.py — AP-2 Hafta 9 · Kavram K09
Amaç    : Tarayıcının geri/ileri düğmeleri iki yığındır (Örnek 7 ile aynı
          desen): yeni sayfaya gidince eski sayfa geri yığınına itilir ve
          ileri yığını boşaltılır. C sürümüyle aynı çıktı.
Çalıştır: python3 H09_K09_tarayici_gecmisi.py
"""
EN_COK = 16


class SayfaYigini:
    __slots__ = ("sayfa", "boyut")

    def __init__(self):
        self.sayfa = [""] * EN_COK  # sabit uzunluk + boyut (elle yığın)
        self.boyut = 0


def it(y, s):
    if y.boyut < EN_COK:  # dolunca en yeni sayfa eklenmez
        y.sayfa[y.boyut] = s
        y.boyut += 1


def cikar(y):
    if y.boyut == 0:
        return False, ""
    y.boyut -= 1
    return True, y.sayfa[y.boyut]


def yaz(y):
    return "[" + " ".join(y.sayfa[k] for k in range(y.boyut)) + "]"


def main():
    komutlar = ["git a.com", "git b.com", "git c.com", "geri", "geri",
                "ileri", "git d.com", "ileri", "geri", "geri", "geri",
                "geri"]
    geri, ileri = SayfaYigini(), SayfaYigini()
    simdiki = "ana.sayfa"
    for c in komutlar:
        not_ = ""
        if c.startswith("git "):
            it(geri, simdiki)
            simdiki = c[4:]
            ileri.boyut = 0  # yeni sayfa: ileri geçmiş silinir
        elif c == "geri":
            tamam, s = cikar(geri)
            if tamam:
                it(ileri, simdiki)
                simdiki = s
            else:
                not_ = "  (geri gidilecek sayfa yok)"
        else:
            tamam, s = cikar(ileri)
            if tamam:
                it(geri, simdiki)
                simdiki = s
            else:
                not_ = "  (ileri gidilecek sayfa yok)"
        print(f"  {c:<10} şimdiki: {simdiki:<9} geri: {yaz(geri)}  "
              f"ileri: {yaz(ileri)}{not_}")


if __name__ == "__main__":
    main()

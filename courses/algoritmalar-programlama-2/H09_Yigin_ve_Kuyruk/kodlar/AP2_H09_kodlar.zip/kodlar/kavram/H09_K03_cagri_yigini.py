"""H09_K03_cagri_yigini.py — AP-2 Hafta 9 · Kavram K03 (Kaputun Altında)
Amaç    : Özyineleme örtük bir yığındır: toplam(n) = n + toplam(n - 1)
          her çağrıda bir çerçeve iter. CPython çerçeve sayısını
          sys.getrecursionlimit() (varsayılan 1000) ile sınırlar ve
          aşılınca RecursionError verir; açık yığınla aynı hesap sınırsızdır.
Çalıştır: python3 H09_K03_cagri_yigini.py          (n = 900: ikisi de çalışır)
          python3 H09_K03_cagri_yigini.py 5000     (özyinelemeli sürüm
          RecursionError verir; program bunu yakalayıp yazar)
"""
import sys

en_derin = 0


def toplam_ozyinelemeli(n, derinlik):
    """Her çağrı bir çerçeve"""
    global en_derin
    if derinlik > en_derin:
        en_derin = derinlik
    if n == 0:
        return 0
    return n + toplam_ozyinelemeli(n - 1, derinlik + 1)


def toplam_yiginla(n):
    """Açık yığın: önce 'çağrıları' it, sonra çıkarıp topla"""
    yigin = [0] * n  # sabit uzunluklu dizi + boyut (elle yığın)
    boyut = 0
    for k in range(n, 0, -1):
        yigin[boyut] = k        # çağrı yerine: çerçeveyi it
        boyut += 1
    en_buyuk = boyut
    sonuc = 0
    while boyut > 0:
        boyut -= 1
        sonuc += yigin[boyut]   # dönüş yerine: çerçeveyi çıkar
    return sonuc, en_buyuk


def main():
    n = 900
    if len(sys.argv) > 1:
        if not sys.argv[1].isdigit():
            print("kullanım: H09_K03_cagri_yigini.py [n >= 0]",
                  file=sys.stderr)
            return 2
        n = int(sys.argv[1])
    print(f"n = {n}; özyineleme sınırı sys.getrecursionlimit() = "
          f"{sys.getrecursionlimit()}")
    s, en_buyuk = toplam_yiginla(n)
    print(f"açık yığınla   : toplam = {s}, en büyük yığın = {en_buyuk} "
          "eleman")
    try:
        s = toplam_ozyinelemeli(n, 1)
        print(f"özyinelemeyle  : toplam = {s}, en büyük derinlik = "
              f"{en_derin} çağrı")
    except RecursionError as e:
        print(f"özyinelemeyle  : RecursionError: {e} (ulaşılan derinlik "
              f"{en_derin})")
    print(f"kapalı form    : n(n+1)/2 = {n * (n + 1) // 2}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

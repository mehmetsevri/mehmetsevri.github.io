#!/usr/bin/env python3
"""esdeger_test.py — AP-2 üç dilli çıktı eşdeğerliği denetimi

Bir haftanın kodlar/ klasöründeki her örneğin C, C++ ve Python sürümlerini
derler/çalıştırır ve standart çıktılarını ciktilar/ klasöründeki beklenen
çıktılarla BAYT DÜZEYİNDE karşılaştırır (AP-2 Yol Haritası, Bölüm 6.5.4).

Klasör düzeni (kodlar/):
    c/        H01_04_dogrusal_arama.c   (+ ortak_rastgele.h/.c, zamanlayici.h/.c)
    cpp/      H01_04_dogrusal_arama.cpp (+ ortak_rastgele.hpp, zamanlayici.hpp)
    python/   H01_04_dogrusal_arama.py  (+ ortak_rastgele.py, zamanlayici.py)
    girdiler/ H01_04_dogrusal_arama.txt (varsa; stdin olarak verilir)
    ciktilar/ H01_04_dogrusal_arama.txt ("=" örnekleri: üç dilin ortak çıktısı)
              H01_06_bolme_kalan_c.txt / _cpp.txt / _py.txt ("Δ" örnekleri)

Örnek üst verisi (önerilen): kodlar/ornekler.json
    {"hafta": 1, "ornekler": {"H01_06_bolme_kalan": {"baslik": "...", "duzey": 2,
        "tur": "Δ", "arguman": "", "bayrak": "", "cikis": 0, "zaman_asimi": 60,
        "farklar": {"cpp": [7], "py": [5]}, "dil_notu": "..."}}}
    "tur": "=" (üç dilde aynı çıktı) ya da "Δ" (bilinçli dil farkı).

Alternatif olarak dosya başındaki yorumlarda yönergeler (ilk 40 satır):
    @delta                 Dil farkını gösteren örnek; her dilin ayrı çıktısı vardır
    @bayrak -O0            C/C++ derlemesine eklenecek bayraklar (o dosya için)
    @arguman 1000 {girdiler}/veri.txt
                           Komut satırı argümanları ({girdiler} klasör yoluyla değişir)
    @cikis 1               Beklenen çıkış kodu (varsayılan 0)
    @zaman_asimi 120       Saniye cinsinden süre sınırı (varsayılan 60)

Kullanım:
    python3 esdeger_test.py KODLAR_KLASORU            # denetle
    python3 esdeger_test.py KODLAR_KLASORU --uret     # beklenen çıktıları üret/yenile
    python3 esdeger_test.py KODLAR_KLASORU --yalniz H01_06 H01_07
    python3 esdeger_test.py KODLAR_KLASORU --asan     # C/C++: -fsanitize=address,undefined
    python3 esdeger_test.py KODLAR_KLASORU --json rapor.json

Çıkış kodu: 0 = tüm örnekler geçti; 1 = en az bir hata; 2 = hatalı kullanım.
Gereksinim: gcc, g++ (C17/C++17) ve python3 (3.10+); yalnızca standart kütüphane.
"""

import argparse
import concurrent.futures as cf
import difflib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

KOK_DESEN = re.compile(r"^(H\d\d_\d\d_[a-z0-9_]+)\.(c|cpp|py)$")
YONERGE = re.compile(r"@(delta|bayrak|arguman|cikis|zaman_asimi)\b[ \t:]*([^\n]*)")
DILLER = (("c", "c", "c"), ("cpp", "cpp", "cpp"), ("py", "python", "py"))
C_DERLE = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic", "-O2", "-g"]
CPP_DERLE = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic", "-O2", "-g"]
SANITIZE = ["-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
SUTUN = {"c": 80, "cpp": 80, "py": 79}


def yonergeleri_oku(yol):
    """Dosyanın ilk 40 satırındaki @yönergeleri sözlük olarak döndürür."""
    y = {}
    with open(yol, encoding="utf-8") as f:
        for _, satir in zip(range(40), f):
            for m in YONERGE.finditer(satir):
                ad, deger = m.group(1), m.group(2).strip()
                deger = re.sub(r"\s*(\*/|-->)\s*$", "", deger).strip()
                y[ad] = deger if deger else True
    return y


def yerel_basliklar(kaynak, klasor, uzanti):
    """#include "x.h" ile eklenen ve klasörde x.c karşılığı olan dosyalar."""
    ekler = []
    with open(kaynak, encoding="utf-8") as f:
        for m in re.finditer(r'#\s*include\s+"([^"]+)\.h"', f.read()):
            aday = os.path.join(klasor, m.group(1) + uzanti)
            if os.path.exists(aday) and aday not in ekler:
                ekler.append(aday)
    return ekler


def calistir(komut, girdi, cwd, sure):
    try:
        p = subprocess.run(komut, input=girdi, cwd=cwd, capture_output=True,
                           timeout=sure,
                           env=dict(os.environ, PYTHONUTF8="1", PYTHONHASHSEED="0",
                                    PYTHONDONTWRITEBYTECODE="1", LC_ALL="C.UTF-8"))
        return p.returncode, p.stdout, p.stderr, False
    except subprocess.TimeoutExpired as e:
        return None, e.stdout or b"", e.stderr or b"", True


def ornek_isle(kok, kodlar, gecici, secenek):
    """Bir örneğin üç dil sürümünü derleyip çalıştırır; sonuç sözlüğü döndürür."""
    sonuc = {"ornek": kok, "diller": {}, "durum": "GEÇTİ", "notlar": []}
    girdiler = os.path.join(kodlar, "girdiler")
    girdi_yolu = os.path.join(girdiler, kok + ".txt")
    girdi = open(girdi_yolu, "rb").read() if os.path.exists(girdi_yolu) else b""
    yon = {}
    ust = secenek.ust_veri.get(kok)
    if ust is not None:
        if str(ust.get("tur", "=")) in ("Δ", "delta", "D"):
            yon["delta"] = True
        for k in ("bayrak", "arguman"):
            if ust.get(k):
                yon[k] = str(ust[k])
        for k in ("cikis", "zaman_asimi"):
            if ust.get(k) not in (None, ""):
                yon[k] = str(ust[k])
    elif secenek.ust_veri:
        sonuc["notlar"].append("UYARI: ornekler.json içinde kaydı yok")
    yollar = {}
    for dil, klasor, uz in DILLER:
        yol = os.path.join(kodlar, klasor, f"{kok}.{uz}")
        if os.path.exists(yol):
            yollar[dil] = yol
            for k, v in yonergeleri_oku(yol).items():
                yon.setdefault(k, v)
        else:
            sonuc["notlar"].append(f"{dil}: dosya EKSİK ({klasor}/{kok}.{uz})")
            sonuc["durum"] = "HATA"
    delta = "delta" in yon
    sonuc["delta"] = delta
    sure = int(yon.get("zaman_asimi", 60)) if yon.get("zaman_asimi") is not True else 60
    beklenen_kod = int(yon["cikis"]) if isinstance(yon.get("cikis"), str) else 0
    argumanlar = []
    if isinstance(yon.get("arguman"), str):
        argumanlar = shlex.split(yon["arguman"].replace("{girdiler}", girdiler))
    bayrak = shlex.split(yon["bayrak"]) if isinstance(yon.get("bayrak"), str) else []
    calisma = os.path.join(gecici, kok)
    os.makedirs(calisma, exist_ok=True)

    for dil, klasor, uz in DILLER:
        if dil not in yollar:
            continue
        yol = yollar[dil]
        d = {"derleme": "", "kod": None, "cikti": b"", "stderr": b""}
        sonuc["diller"][dil] = d
        # Satır uzunluğu (uyarı düzeyinde)
        with open(yol, encoding="utf-8") as f:
            uzun = [i + 1 for i, s in enumerate(f.read().split("\n")) if len(s) > SUTUN[dil]]
        if uzun:
            sonuc["notlar"].append(f"{dil}: {len(uzun)} satır {SUTUN[dil]} sütunu aşıyor "
                                   f"(ilk: {uzun[0]})")
        if dil in ("c", "cpp"):
            ikili = os.path.join(calisma, f"{kok}_{dil}")
            derleyici = list(C_DERLE if dil == "c" else CPP_DERLE)
            ekler = yerel_basliklar(yol, os.path.dirname(yol), ".c") if dil == "c" else []
            komut = derleyici + bayrak + (SANITIZE if secenek.asan else []) + \
                [yol] + ekler + ["-o", ikili] + (["-lm"] if dil == "c" else [])
            p = subprocess.run(komut, capture_output=True)
            d["derleme"] = p.stderr.decode("utf-8", "replace")
            if p.returncode != 0:
                sonuc["durum"] = "HATA"
                sonuc["notlar"].append(f"{dil}: DERLENMEDİ")
                continue
            if d["derleme"].strip():
                sonuc["durum"] = "HATA"
                sonuc["notlar"].append(f"{dil}: derleyici UYARISI var")
            komut = [ikili] + argumanlar
        else:
            p = subprocess.run([sys.executable, "-m", "py_compile", yol], capture_output=True,
                               env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1",
                                        PYTHONPYCACHEPREFIX=os.path.join(gecici, "pyc")))
            if p.returncode != 0:
                sonuc["durum"] = "HATA"
                sonuc["notlar"].append("py: SÖZDİZİMİ HATASI")
                d["derleme"] = p.stderr.decode("utf-8", "replace")
                continue
            komut = [sys.executable, yol] + argumanlar
        kod, out, err, asim = calistir(komut, girdi, calisma, sure)
        d["kod"], d["cikti"], d["stderr"] = kod, out, err
        if secenek.asan and dil in ("c", "cpp"):
            # UBSan varsayılan olarak çıkış kodunu değiştirmez: raporu stderr'de ara
            hata = re.search(rb"runtime error:|ERROR: (Address|Leak)Sanitizer"
                             rb"|SUMMARY: (Address|Leak|UndefinedBehavior)Sanitizer",
                             err or b"")
            if hata:
                sonuc["durum"] = "HATA"
                sonuc["notlar"].append(f"{dil}: SANITIZER RAPORU: "
                                       f"{hata.group(0).decode()}")
        if asim:
            sonuc["durum"] = "HATA"
            sonuc["notlar"].append(f"{dil}: ZAMAN AŞIMI ({sure} s)")
        elif kod != beklenen_kod:
            sonuc["durum"] = "HATA"
            sonuc["notlar"].append(f"{dil}: çıkış kodu {kod} (beklenen {beklenen_kod})")
    return sonuc


def karsilastir(sonuc, kodlar, uret):
    kok = sonuc["ornek"]
    cikti_kl = os.path.join(kodlar, "ciktilar")
    os.makedirs(cikti_kl, exist_ok=True)
    diller = sonuc["diller"]
    if sonuc["delta"]:
        for dil, d in diller.items():
            hedef = os.path.join(cikti_kl, f"{kok}_{dil}.txt")
            if uret:
                if d["kod"] is not None:
                    open(hedef, "wb").write(d["cikti"])
            elif not os.path.exists(hedef):
                sonuc["durum"] = "HATA"
                sonuc["notlar"].append(f"{dil}: beklenen çıktı yok ({os.path.basename(hedef)})")
            elif open(hedef, "rb").read() != d["cikti"]:
                sonuc["durum"] = "HATA"
                sonuc["notlar"].append(f"{dil}: ÇIKTI FARKLI")
                sonuc.setdefault("fark", {})[dil] = fark_ozeti(open(hedef, "rb").read(), d["cikti"])
        ciktilar = [d["cikti"] for d in diller.values()]
        if len(ciktilar) == 3 and len(set(ciktilar)) == 1:
            sonuc["notlar"].append("UYARI: @delta işaretli ama üç çıktı aynı")
        if os.path.exists(os.path.join(cikti_kl, kok + ".txt")):
            sonuc["notlar"].append("UYARI: Δ örneğinde ortak çıktı dosyası da var")
        return
    hedef = os.path.join(cikti_kl, kok + ".txt")
    ciktilar = {dil: d["cikti"] for dil, d in diller.items() if d["kod"] is not None}
    if uret:
        if len(set(ciktilar.values())) > 1:
            sonuc["durum"] = "HATA"
            sonuc["notlar"].append("“=” örneğinde diller FARKLI çıktı üretti; yazılmadı")
            ref = ciktilar.get("c", b"")
            sonuc["fark"] = {dil: fark_ozeti(ref, c) for dil, c in ciktilar.items() if c != ref}
        elif ciktilar:
            open(hedef, "wb").write(next(iter(ciktilar.values())))
        return
    if not os.path.exists(hedef):
        sonuc["durum"] = "HATA"
        sonuc["notlar"].append(f"beklenen çıktı yok ({os.path.basename(hedef)})")
        return
    beklenen = open(hedef, "rb").read()
    for dil, c in ciktilar.items():
        if c != beklenen:
            sonuc["durum"] = "HATA"
            sonuc["notlar"].append(f"{dil}: ÇIKTI FARKLI")
            sonuc.setdefault("fark", {})[dil] = fark_ozeti(beklenen, c)
    for dil in ("c", "cpp", "py"):
        if os.path.exists(os.path.join(cikti_kl, f"{kok}_{dil}.txt")):
            sonuc["notlar"].append(f"UYARI: “=” örneğinde {kok}_{dil}.txt fazlalık")


def fark_ozeti(beklenen, gercek, satir=8):
    a = beklenen.decode("utf-8", "replace").splitlines()
    b = gercek.decode("utf-8", "replace").splitlines()
    return "\n".join(list(difflib.unified_diff(a, b, "beklenen", "gercek", lineterm="", n=1))[:satir + 3])


def main():
    ap = argparse.ArgumentParser(description="AP-2 üç dilli çıktı eşdeğerliği denetimi")
    ap.add_argument("kodlar", help="haftanın kodlar/ klasörü")
    ap.add_argument("--uret", action="store_true", help="beklenen çıktıları üret/yenile")
    ap.add_argument("--yalniz", nargs="*", default=None, help="yalnız bu önekle başlayan örnekler")
    ap.add_argument("--asan", action="store_true", help="C/C++: AddressSanitizer + UBSan")
    ap.add_argument("--json", help="sonuçları JSON dosyasına yaz")
    ap.add_argument("--paralel", type=int, default=os.cpu_count() or 2)
    a = ap.parse_args()
    kodlar = os.path.abspath(a.kodlar)
    if not os.path.isdir(kodlar):
        print(f"Klasör bulunamadı: {kodlar}", file=sys.stderr)
        return 2
    a.ust_veri = {}
    uv = os.path.join(kodlar, "ornekler.json")
    if os.path.exists(uv):
        try:
            with open(uv, encoding="utf-8") as f:
                a.ust_veri = json.load(f).get("ornekler", {})
        except (ValueError, OSError) as e:
            print(f"ornekler.json okunamadı: {e}", file=sys.stderr)
            return 2
    for arac in ("gcc", "g++"):
        if not shutil.which(arac):
            print(f"{arac} bulunamadı (PATH).", file=sys.stderr)
            return 2
    kokler = set()
    for _, klasor, uz in DILLER:
        kl = os.path.join(kodlar, klasor)
        if os.path.isdir(kl):
            for ad in os.listdir(kl):
                m = KOK_DESEN.match(ad)
                if m and m.group(2) == uz:
                    kokler.add(m.group(1))
    fazla = sorted(set(a.ust_veri) - kokler)
    if a.yalniz:
        kokler = {k for k in kokler if any(k.startswith(p) for p in a.yalniz)}
        fazla = [k for k in fazla if any(k.startswith(p) for p in a.yalniz)]
    if not kokler:
        print("Örnek bulunamadı.", file=sys.stderr)
        return 2
    gecici = tempfile.mkdtemp(prefix="esdeger_")
    try:
        with cf.ThreadPoolExecutor(max_workers=a.paralel) as ex:
            sonuclar = list(ex.map(lambda k: ornek_isle(k, kodlar, gecici, a), sorted(kokler)))
        for s in sonuclar:
            karsilastir(s, kodlar, a.uret)
    finally:
        shutil.rmtree(gecici, ignore_errors=True)

    print(f"{'Örnek':<34} {'Tür':<4} {'C':<6} {'C++':<6} {'Py':<6} Durum")
    print("-" * 70)
    hata = 0
    for s in sonuclar:
        def k(dil):
            d = s["diller"].get(dil)
            if d is None:
                return "yok"
            return "—" if d["kod"] is None else str(d["kod"])
        tur = "Δ" if s["delta"] else "="
        print(f"{s['ornek']:<34} {tur:<4} {k('c'):<6} {k('cpp'):<6} {k('py'):<6} {s['durum']}")
        for n in s["notlar"]:
            print(f"    · {n}")
        for dil, f in s.get("fark", {}).items():
            print(f"    [{dil}] fark:\n" + "\n".join("      " + x for x in f.splitlines()))
        for dil, d in s["diller"].items():
            if d["derleme"].strip():
                print(f"    [{dil}] derleyici iletisi:\n" +
                      "\n".join("      " + x for x in d["derleme"].strip().splitlines()[:12]))
        if s["durum"] != "GEÇTİ":
            hata += 1
    for k in fazla:
        print(f"{k:<34} {'?':<4} {'yok':<6} {'yok':<6} {'yok':<6} HATA")
        print("    · ornekler.json'da var ama hiçbir dilde dosyası yok")
        hata += 1
    print("-" * 70)
    toplam = len(sonuclar) + len(fazla)
    print(f"Toplam {toplam} örnek · geçen {toplam - hata} · hatalı {hata}"
          + (" · (beklenen çıktılar üretildi)" if a.uret else ""))
    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump([{"ornek": s["ornek"], "delta": s["delta"], "durum": s["durum"],
                        "notlar": s["notlar"]} for s in sonuclar], f, ensure_ascii=False, indent=1)
    return 0 if hata == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

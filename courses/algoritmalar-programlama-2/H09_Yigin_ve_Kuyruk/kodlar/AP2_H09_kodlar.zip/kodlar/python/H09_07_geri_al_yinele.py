"""H09_07_geri_al_yinele.py — AP-2 Hafta 9 · Örnek 7 (★★)
Amaç    : Geri al / yinele (undo/redo) iki yığınla: her işlem geri
          yığınına itilir; geri al onu yinele yığınına taşır; YENİ bir
          işlem yinele yığınını boşaltır. Komutlar girdi dosyasından;
          rastgele komut dizisi durum geçmişi kâhiniyle sınanır
Çalıştır: python3 H09_07_geri_al_yinele.py \\
          < ../girdiler/H09_07_geri_al_yinele.txt
Eşleri  : c/H09_07_geri_al_yinele.c · cpp/H09_07_geri_al_yinele.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum

MAKS_BELGE = 256


class Islem:
    __slots__ = ("tur", "metin")  # tur '+': yaz, '-': sil

    def __init__(self, tur, metin):
        self.tur = tur
        self.metin = metin  # eklenen ya da silinen metin


class Dugum:
    __slots__ = ("islem", "sonraki")

    def __init__(self, islem, sonraki):
        self.islem = islem
        self.sonraki = sonraki


class Yigin:
    __slots__ = ("tepe", "boyut")


class Duzenleyici:
    __slots__ = ("belge", "geri", "yinele")


it_sayisi = cikar_sayisi = temizlenen = 0
ayrilan_dugum = serbest_dugum = 0
en_buyuk_derinlik = 0


def yigin_olustur():
    y = Yigin()
    y.tepe = None
    y.boyut = 0
    return y


def yigin_yok_et(y):
    """Kalan düğümler bırakılır (C'deki free döngüsü); adedi döner"""
    global serbest_dugum
    adet = 0
    while y.tepe is not None:
        d = y.tepe
        y.tepe = d.sonraki
        serbest_dugum += 1
        adet += 1
    y.boyut = 0
    return adet


def yigin_it(y, i):
    global ayrilan_dugum, it_sayisi, en_buyuk_derinlik
    y.tepe = Dugum(Islem(i.tur, i.metin), y.tepe)  # C'deki yapı kopyası
    ayrilan_dugum += 1
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut
    return True


def yigin_cikar(y):
    global serbest_dugum, cikar_sayisi
    if y.tepe is None:
        return False, None
    d = y.tepe
    y.tepe = d.sonraki
    serbest_dugum += 1
    y.boyut -= 1
    cikar_sayisi += 1
    return True, d.islem


def uygula(belge, i):
    """İşlemi uygular, yeni belgeyi döner: yaz → sona ekle, sil → sondan"""
    if i.tur == "+":
        return belge + i.metin
    return belge[:len(belge) - len(i.metin)]


def ters_uygula(belge, i):
    """İşlemin tersini uygular (geri al)"""
    return uygula(belge, Islem("-" if i.tur == "+" else "+", i.metin))


def yeni_islem(e, i):
    """Yeni işlem: uygula, geri yığınına it, yinele yığınını boşalt"""
    global temizlenen
    e.belge = uygula(e.belge, i)
    yigin_it(e.geri, i)
    temizlenen += yigin_yok_et(e.yinele)


def duzenle_yaz(e, metin):
    if len(metin) == 0 or len(e.belge) + len(metin) >= MAKS_BELGE:
        return False  # boş metin ya da belge dolu
    yeni_islem(e, Islem("+", metin))
    return True


def duzenle_sil(e, k):
    n = len(e.belge)
    if k > n:
        k = n
    if k <= 0:
        return False  # silinecek karakter yok
    yeni_islem(e, Islem("-", e.belge[n - k:]))
    return True


def geri_al(e):
    tamam, i = yigin_cikar(e.geri)
    if not tamam:
        return False
    e.belge = ters_uygula(e.belge, i)
    yigin_it(e.yinele, i)
    return True


def yinele(e):
    tamam, i = yigin_cikar(e.yinele)
    if not tamam:
        return False
    e.belge = uygula(e.belge, i)
    yigin_it(e.geri, i)
    return True


def duzenleyici_olustur():
    e = Duzenleyici()
    e.belge = ""
    e.geri = yigin_olustur()
    e.yinele = yigin_olustur()
    return e


def duzenleyici_yok_et(e):
    yigin_yok_et(e.geri)
    yigin_yok_et(e.yinele)


def tabandan_yaz(d):
    """Yığını tabandan tepeye yazar (liste ters sırada: özyinelemeli)"""
    if d is None:
        return ""
    return (tabandan_yaz(d.sonraki) + (" " if d.sonraki is not None else "")
            + f'{d.islem.tur}"{d.islem.metin}"')


def durum_yaz(e):
    print(f'    belge: "{e.belge}"')
    print("    geri  : [" + tabandan_yaz(e.geri.tepe) + "]")
    print("    yinele: [" + tabandan_yaz(e.yinele.tepe) + "]")


def tamsayi_oku(s):
    """C'deki strtol + 'sonuna kadar' denetimi (int() boşluk ve _ kabul
    eder; C ile aynı davranış için elle)"""
    i = 0
    while i < len(s) and s[i] in " \t\n\v\f\r":
        i += 1
    j = i + 1 if i < len(s) and s[i] in "+-" else i
    k = j
    while k < len(s) and "0" <= s[k] <= "9":
        k += 1
    if k == j or k != len(s):
        return False, 0
    n = int(s[i:k])
    return -2 ** 63 <= n < 2 ** 63, n  # C'deki long sınırı (ERANGE)


def komut_isle(e, k):
    print("  > " + k)
    if k.startswith("yaz "):
        if not duzenle_yaz(e, k[4:]):
            print("    (reddedildi: boş metin ya da belge dolu)")
    elif k.startswith("sil "):
        tamam, n = tamsayi_oku(k[4:])
        if not tamam or n < 0:
            print("    (hata: geçersiz sayı)")
            return
        if not duzenle_sil(e, MAKS_BELGE if n > MAKS_BELGE else n):
            print("    (reddedildi: silinecek karakter yok)")
    elif k == "geri":
        if not geri_al(e):
            print("    (geri alınacak işlem yok)")
    elif k == "yinele":
        if not yinele(e):
            print("    (yinelenecek işlem yok)")
    else:
        print("    (hata: bilinmeyen komut)")
        return
    durum_yaz(e)


def rastgele_sinama(adim):
    """Kâhin: belge durumlarının listesi + etkin indis"""
    e = duzenleyici_olustur()
    durum = [""] * (adim + 1)
    etkin = son = uyusmazlik = 0
    sayac = [0, 0, 0, 0]
    rastgele_tohum(42)
    for _ in range(adim):
        r = rastgele_aralik(0, 3)
        if r == 0:
            u = rastgele_aralik(1, 5)
            m = "".join(chr(ord("a") + rastgele_aralik(0, 25))
                        for _ in range(u))
            tamam = duzenle_yaz(e, m)
        elif r == 1:
            tamam = duzenle_sil(e, rastgele_aralik(1, 6))
        elif r == 2:
            tamam = geri_al(e)
            uyusmazlik += 1 if tamam != (etkin > 0) else 0
            etkin -= 1 if tamam else 0
        else:
            tamam = yinele(e)
            uyusmazlik += 1 if tamam != (etkin < son) else 0
            etkin += 1 if tamam else 0
        if r <= 1 and tamam:
            etkin += 1
            son = etkin  # yeni işlem: ileri geçmiş silinir
            durum[etkin] = e.belge
        sayac[r] += 1 if tamam else 0
        uyusmazlik += 1 if e.belge != durum[etkin] else 0
    print(f"  {adim} adım: başarılı yaz {sayac[0]}, sil {sayac[1]}, "
          f"geri {sayac[2]}, yinele {sayac[3]}")
    print(f"  son belge uzunluğu {len(e.belge)}; geri yığını "
          f"{e.geri.boyut}, yinele yığını {e.yinele.boyut}")
    print(f"  durum geçmişi kâhiniyle uyuşmazlık = {uyusmazlik}")
    duzenleyici_yok_et(e)


def main():
    e = duzenleyici_olustur()
    print("1) Komutlar (girdi dosyasından); yığınlar tabandan tepeye, "
          "+ yaz, - sil")
    satirlar = sys.stdin.buffer.read().decode("utf-8").split("\n")
    if satirlar and satirlar[-1] == "":
        satirlar.pop()  # dosya sonundaki satır sonu (C'deki fgets gibi)
    for satir in satirlar:
        komut_isle(e, satir)
    print(f"  sayaçlar: it = {it_sayisi}, çıkar = {cikar_sayisi}, yeni "
          f"işlemle temizlenen yinele kaydı = {temizlenen}, en büyük "
          f"derinlik = {en_buyuk_derinlik}")
    duzenleyici_yok_et(e)

    print("\n2) Rastgele 20000 komut (tohum 42) ve kâhin")
    rastgele_sinama(20000)
    print(f"  düğüm: ayrılan = {ayrilan_dugum}, serbest = {serbest_dugum}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — iki std::stack<Islem>;
# Python — iki list (append/pop). Gerçek düzenleyiciler geri alma geçmişini
# çoğunlukla sınırlar (en eski kayıt atılır: dairesel tampon ya da iki uçlu
# kuyruk).

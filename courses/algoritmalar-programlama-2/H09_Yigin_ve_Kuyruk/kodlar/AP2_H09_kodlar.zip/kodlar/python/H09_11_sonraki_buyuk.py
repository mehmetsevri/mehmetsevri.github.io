"""H09_11_sonraki_buyuk.py — AP-2 Hafta 9 · Örnek 11 (★★★)
Amaç    : Monotonik yığınla "sonraki büyük eleman" (next greater element):
          yığında cevabı henüz bulunmamış indisler azalan değer sırasında
          tutulur; her indis bir kez itilir, en çok bir kez çıkarılır →
          it + çıkar <= 2n, O(n). O(n^2) kaba kuvvet kâhinle sınanır
Çalıştır: python3 H09_11_sonraki_buyuk.py
Eşleri  : c/H09_11_sonraki_buyuk.c · cpp/H09_11_sonraki_buyuk.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Yigin:
    """a'nın indisleri; değerleri tabandan tepeye azalmaz"""
    __slots__ = ("veri", "kapasite", "boyut")


it_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0
en_buyuk_derinlik = 0


def sayaclari_sifirla():
    global it_sayisi, cikar_sayisi, karsilastirma, kaba_karsilastirma
    global en_buyuk_derinlik
    it_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0
    en_buyuk_derinlik = 0


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [0] * (kapasite if kapasite > 0 else 1)
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, i):
    global it_sayisi, en_buyuk_derinlik
    y.veri[y.boyut] = i
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut


def yigin_cikar(y):
    global cikar_sayisi
    cikar_sayisi += 1
    y.boyut -= 1
    return y.veri[y.boyut]


def kucuk_mu(x, y):
    global karsilastirma
    karsilastirma += 1
    return x < y


def sonraki_buyuk(a, iz):
    """sonuc[i] = a[i]'nin sağındaki ilk büyük değer; yoksa -1 (a[i] >= 0).
    iz: her adımda cevabı bulunanları (çıkarılanları) ve yığını yazar"""
    n = len(a)
    y = yigin_olustur(n)
    sonuc = [0] * n
    for i in range(n):
        coz = []
        while y.boyut > 0 and kucuk_mu(a[y.veri[y.boyut - 1]], a[i]):
            j = yigin_cikar(y)
            sonuc[j] = a[i]  # a[j]'nin cevabı bulundu
            coz.append(str(a[j]))
        yigin_it(y, i)
        if iz:
            icerik = " ".join(str(a[y.veri[k]]) for k in range(y.boyut))
            print(f"  {i:2d} {a[i]:5d}   {' '.join(coz) or '-':<13} "
                  f"[{icerik}]")
    while y.boyut > 0:
        sonuc[yigin_cikar(y)] = -1  # sağda büyüğü olmayanlar
    return sonuc


def kaba_kuvvet(a):
    """Kâhin: her i için sağa doğru tarama, O(n^2)"""
    global kaba_karsilastirma
    n = len(a)
    sonuc = [-1] * n
    for i in range(n):
        for j in range(i + 1, n):
            kaba_karsilastirma += 1
            if a[j] > a[i]:
                sonuc[i] = a[j]
                break
    return sonuc


def girdi_uret(n, tur):
    if tur == 0:
        return list(range(n))            # artan
    if tur == 1:
        return [n - i for i in range(n)]  # azalan
    if tur == 2:
        return [7] * n                    # sabit
    return [rastgele_aralik(0, 1000000) for _ in range(n)]


def main():
    a = [3, 8, 4, 1, 2, 6, 5, 9, 7]
    print("1) İzleme: a = [3 8 4 1 2 6 5 9 7]")
    print("   i  a[i]   çıkarılanlar  yığın (taban -> tepe, değer)")
    sayaclari_sifirla()
    sonuc = sonraki_buyuk(a, True)
    print("  sonraki büyük: " + " ".join(str(x) for x in sonuc))
    print(f"  it = {it_sayisi}, çıkar = {cikar_sayisi}, karşılaştırma = "
          f"{karsilastirma}, en büyük derinlik = {en_buyuk_derinlik}")

    print("\n2) Girdi türüne göre (n = 1000): yığın O(n), kaba kuvvet "
          "O(n^2)")
    print("  girdi      it  çıkar  karş.  derinlik   kaba karş.  aynı mı")
    ad = ["artan   ", "azalan  ", "sabit   ", "rastgele"]
    rastgele_tohum(42)
    for tur in range(4):
        b = girdi_uret(1000, tur)
        sayaclari_sifirla()
        s1 = sonraki_buyuk(b, False)
        s2 = kaba_kuvvet(b)
        print(f"  {ad[tur]} {it_sayisi:5d} {cikar_sayisi:6d} "
              f"{karsilastirma:6d} {en_buyuk_derinlik:9d} "
              f"{kaba_karsilastirma:12d}  "
              + ("evet" if s1 == s2 else "HAYIR"))

    print("\n3) Rastgele 2000 dizi (n = 0..60, değerler 0..20, tohum 42) "
          "ve kâhin")
    uyusmazlik = sinir_ihlali = 0
    rastgele_tohum(42)
    for _ in range(2000):
        k = rastgele_aralik(0, 60)
        dizi = [rastgele_aralik(0, 20) for _ in range(k)]
        sayaclari_sifirla()
        s1 = sonraki_buyuk(dizi, False)
        s2 = kaba_kuvvet(dizi)
        uyusmazlik += 1 if s1 != s2 else 0
        sinir_ihlali += 1 if it_sayisi + cikar_sayisi > 2 * k else 0
    print(f"  kâhinle uyuşmazlık = {uyusmazlik}, it + çıkar > 2n olan "
          f"dizi = {sinir_ihlali}")

    print("\n4) Büyüme: rastgele girdi, değerler 0..10^6")
    print("        n     it + çıkar    2n   karş./n")
    k = 1000
    while k <= 100000:
        rastgele_tohum(42)
        c = girdi_uret(k, 3)
        sayaclari_sifirla()
        sonraki_buyuk(c, False)
        print(f"  {k:7d} {it_sayisi + cikar_sayisi:14d} {2 * k:7d} "
              f"{karsilastirma / k:9.3f}")
        k *= 10


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack<int> ile
# aynı algoritma); Python — yok (list yığın olarak). Monotonik yığın;
# histogramdaki en büyük dikdörtgen (Örnek 14), stok açıklığı (stock span)
# ve sonraki küçük eleman problemlerinde de kullanılır.

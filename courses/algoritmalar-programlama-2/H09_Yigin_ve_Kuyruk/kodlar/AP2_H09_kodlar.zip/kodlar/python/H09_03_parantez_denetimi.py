"""H09_03_parantez_denetimi.py — AP-2 Hafta 9 · Örnek 3 (★★)
Amaç    : ( ) [ ] { } dengesinin yığınla denetimi; ilk hatanın konumu
          ve türü: eşleşmeyen kapanış, tür uyuşmazlığı, açık kalan
Çalıştır: python3 H09_03_parantez_denetimi.py \\
          < ../girdiler/H09_03_parantez_denetimi.txt
Eşleri  : c/H09_03_parantez_denetimi.c ·
          cpp/H09_03_parantez_denetimi.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum

DENGELI, ESLESMEYEN_KAPANIS, TUR_UYUSMAZLIGI, ACIK_KALAN = range(4)


class Acilis:
    __slots__ = ("tur", "sutun")  # tur: '(' '[' '{'; sutun: 1 tabanlı

    def __init__(self, tur, sutun):
        self.tur = tur
        self.sutun = sutun


class Yigin:
    __slots__ = ("veri", "kapasite", "boyut")


class Sonuc:
    __slots__ = ("durum", "sutun", "bulunan", "beklenen", "acilis_sutun",
                 "acik_sayisi")

    def __init__(self, durum, sutun, bulunan, beklenen, acilis_sutun,
                 acik_sayisi):
        self.durum = durum
        self.sutun = sutun                # hatanın bulunduğu sütun
        self.bulunan = bulunan            # hatalı kapanış / açık açılış
        self.beklenen = beklenen          # uyuşmazlıkta beklenen kapanış
        self.acilis_sutun = acilis_sutun  # ilgili açılışın sütunu
        self.acik_sayisi = acik_sayisi    # açık kalan parantez sayısı


it_sayisi = cikar_sayisi = islenen = 0
en_buyuk_derinlik = 0


def sayaclari_sifirla():
    global it_sayisi, cikar_sayisi, islenen, en_buyuk_derinlik
    it_sayisi = cikar_sayisi = islenen = 0
    en_buyuk_derinlik = 0


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [None] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, a):
    global it_sayisi, en_buyuk_derinlik
    if y.boyut == y.kapasite:
        return False
    y.veri[y.boyut] = a
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut
    return True


def yigin_cikar(y):
    global cikar_sayisi
    if y.boyut == 0:
        return False, None
    y.boyut -= 1
    cikar_sayisi += 1
    return True, y.veri[y.boyut]


def acilis_karsiligi(kapanis):
    if kapanis == ")":
        return "("
    return "[" if kapanis == "]" else "{"


def kapanis_karsiligi(acilis):
    if acilis == "(":
        return ")"
    return "]" if acilis == "[" else "}"


def parantez_denetle(s, iz):
    """s taranır; ilk hatada durulur (erken çıkış)"""
    global islenen
    n = len(s)
    r = Sonuc(DENGELI, 0, "", "", 0, 0)
    y = yigin_olustur(n if n > 0 else 1)
    i = 0
    while i < n and r.durum == DENGELI:
        c = s[i]
        islenen += 1
        if c in "([{":
            yigin_it(y, Acilis(c, i + 1))
        elif c in ")]}":
            tamam, a = yigin_cikar(y)
            if not tamam:
                r = Sonuc(ESLESMEYEN_KAPANIS, i + 1, c, "", 0, 0)
            elif a.tur != acilis_karsiligi(c):
                r = Sonuc(TUR_UYUSMAZLIGI, i + 1, c,
                          kapanis_karsiligi(a.tur), a.sutun, 0)
        else:
            i += 1
            continue  # parantez olmayan karakterler atlanır
        if iz:
            icerik = "".join(y.veri[k].tur for k in range(y.boyut))
            print(f"    sütun {i + 1:2d} '{c}' -> yığın: "
                  + (icerik if y.boyut > 0 else "(boş)"))
        i += 1
    if r.durum == DENGELI and y.boyut > 0:
        a = y.veri[y.boyut - 1]  # en içteki açık parantez
        r = Sonuc(ACIK_KALAN, n + 1, a.tur, "", a.sutun, y.boyut)
    return r


def sonuc_metni(r):
    if r.durum == DENGELI:
        return "dengeli"
    if r.durum == ESLESMEYEN_KAPANIS:
        return (f"HATA sütun {r.sutun}: eşleşmeyen kapanış '{r.bulunan}' "
                "(yığın boş)")
    if r.durum == TUR_UYUSMAZLIGI:
        return (f"HATA sütun {r.sutun}: tür uyuşmazlığı: '{r.bulunan}' "
                f"bulundu, '{r.beklenen}' bekleniyordu (açılış sütun "
                f"{r.acilis_sutun})")
    return (f"HATA satır sonu: açık kalan {r.acik_sayisi} parantez; en "
            f"içteki '{r.bulunan}' (sütun {r.acilis_sutun})")


def rastgele_dengeli(n):
    """n uzunluğunda (çift) rastgele dengeli dizgi; üretici de yığınlı"""
    s = [" "] * n
    y = yigin_olustur(n // 2 + 1)
    turler = "([{"
    for i in range(n):
        if y.boyut == 0:
            ac = True
        elif y.boyut == n - i:
            ac = False
        else:
            ac = rastgele_aralik(0, 1) == 0
        if ac:
            t = turler[rastgele_aralik(0, 2)]
            yigin_it(y, Acilis(t, i + 1))
            s[i] = t
        else:
            a = yigin_cikar(y)[1]
            s[i] = kapanis_karsiligi(a.tur)
    return "".join(s)


def buyuk_satir(ad, s):
    sayaclari_sifirla()
    r = parantez_denetle(s, False)
    print(f"  {ad:<22}: " + sonuc_metni(r))
    print("  " + " " * 22 + f"  işlenen karakter = {islenen}, "
          f"it = {it_sayisi}, çıkar = {cikar_sayisi}, "
          f"en büyük derinlik = {en_buyuk_derinlik}")


def main():
    veri = sys.stdin.buffer.read().decode("utf-8")
    satirlar = veri.split("\n")
    if satirlar and satirlar[-1] == "":
        satirlar.pop()  # dosya sonundaki satır sonu (C'deki fgets gibi)
    print("1) Girdi dosyasındaki satırlar")
    dengeli = 0
    for no, satir in enumerate(satirlar, start=1):
        sayaclari_sifirla()
        r = parantez_denetle(satir, False)
        print(f"  satır {no:2d}: {satir}\n    -> " + sonuc_metni(r)
              + f"; it = {it_sayisi}, çıkar = {cikar_sayisi}, "
              f"en büyük derinlik = {en_buyuk_derinlik}")
        dengeli += 1 if r.durum == DENGELI else 0
    no = len(satirlar)
    print(f"  toplam {no} satır: dengeli {dengeli}, hatalı {no - dengeli}")

    print("\n2) Yığın izi: her parantezden sonra yığının içeriği "
          "(taban solda)")
    for iz in ("{[()()]}", "[(a + b])", "((a)"):
        print("  " + iz)
        r = parantez_denetle(iz, True)
        print("    sonuç: " + sonuc_metni(r))

    print("\n3) Büyük girdi (n = 100000, tohum 42): Θ(n) tarama ve "
          "erken çıkış")
    n = 100000
    rastgele_tohum(42)
    s = rastgele_dengeli(n)
    buyuk_satir("rastgele dengeli", s)
    son = s[n - 1]
    buyuk_satir("son karakter bozuk",
                s[:n - 1] + ("]" if son == ")" else ")"))
    buyuk_satir("ilk karakter ')'", ")" + s[1:])


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::stack<char>;
# Python — list (append/pop). Hazır "parantez denetimi" fonksiyonu yoktur;
# derleyiciler ve düzenleyiciler bu algoritmayı kendileri gerçekler.

"""H09_04_sonek_degerlendirme.py — AP-2 Hafta 9 · Örnek 4 (★★)
Amaç    : Sonek (postfix, RPN) ifade değerlendirme: işlenen yığını;
          çok basamaklı tamsayılar, + - * / ^ ve tekli eksi ~; işlenen
          sırası a − b (önce b çıkar); sıfıra bölme, eksik/fazla işlenen,
          taşma hataları; bölme sıfıra doğru keser (C kuralı)
Çalıştır: python3 H09_04_sonek_degerlendirme.py \\
          < ../girdiler/H09_04_sonek_degerlendirme.txt
Eşleri  : c/H09_04_sonek_degerlendirme.c ·
          cpp/H09_04_sonek_degerlendirme.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

(HATA_YOK, SIFIRA_BOLME, EKSIK_ISLENEN, FAZLA_ISLENEN, GECERSIZ_BELIRTEC,
 TASMA, NEGATIF_US, BOS_IFADE) = range(8)

HATA_ILETISI = ("yok", "sıfıra bölme", "eksik işlenen", "fazla işlenen",
                "geçersiz belirteç", "taşma (int aralığı dışında)",
                "negatif üs", "boş ifade")

INT_MIN = -2 ** 31        # C'deki 32 bitlik int sınırları (Python
INT_MAX = 2 ** 31 - 1     # tamsayısı sınırsızdır; denetim elle yapılır)


class Yigin:
    __slots__ = ("veri", "kapasite", "boyut")


it_sayisi = cikar_sayisi = 0
en_buyuk_derinlik = 0


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [0] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, x):
    global it_sayisi, en_buyuk_derinlik
    if y.boyut == y.kapasite:
        return False
    y.veri[y.boyut] = x
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut
    return True


def yigin_cikar(y):
    global cikar_sayisi
    if y.boyut == 0:
        return False, 0
    y.boyut -= 1
    cikar_sayisi += 1
    return True, y.veri[y.boyut]


def us_al(a, b):
    """a^b (b >= 0); |a| >= 2 için en çok 31 adımda taşma yakalanır"""
    if a == 0 or a == 1:
        return HATA_YOK, (1 if b == 0 else a)
    if a == -1:
        return HATA_YOK, (1 if b % 2 == 0 else -1)
    r = 1
    for _ in range(b):
        r *= a
        if r < INT_MIN or r > INT_MAX:
            return TASMA, 0
    return HATA_YOK, r


def kesik_bol(a, b):
    """C'deki gibi sıfıra doğru kesen bölme (// aşağı yuvarlar)"""
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q


def islem_uygula(op, a, b):
    """a op b: (hata kodu, sonuç); int aralığı elle denetlenir"""
    if op == "+":
        r = a + b
    elif op == "-":
        r = a - b
    elif op == "*":
        r = a * b
    elif op == "/":
        if b == 0:
            return SIFIRA_BOLME, 0
        r = kesik_bol(a, b)  # 7 / -2 = -3 (C gibi); 7 // -2 = -4 olurdu
    else:
        if b < 0:
            return NEGATIF_US, 0
        return us_al(a, b)
    if r < INT_MIN or r > INT_MAX:
        return TASMA, 0
    return HATA_YOK, r


def yigin_yaz(y):
    return "[" + " ".join(str(y.veri[i]) for i in range(y.boyut)) + "]"


def sonek_degerlendir(s, iz):
    """s: boşlukla ayrılmış belirteçler. (hata, sonuç, sütun, kalan) döner;
    sütun hatalı belirtecin 1 tabanlı konumu, kalan yığındaki değer sayısı"""
    n = len(s)
    y = yigin_olustur(n // 2 + 1)
    hata, sonuc, sutun = HATA_YOK, 0, 0
    i = 0
    while hata == HATA_YOK:
        while i < n and s[i] in " \t":
            i += 1
        if i == n:
            break
        bas = i
        while i < n and s[i] not in " \t":
            i += 1
        belirtec = s[bas:i]
        sutun = bas + 1
        c = s[bas]
        if "0" <= c <= "9":
            v = 0
            k = bas
            while k < i and hata == HATA_YOK:
                if not "0" <= s[k] <= "9":
                    hata = GECERSIZ_BELIRTEC
                else:
                    v = 10 * v + (ord(s[k]) - ord("0"))
                    hata = TASMA if v > INT_MAX else HATA_YOK
                k += 1
            if hata == HATA_YOK:
                yigin_it(y, v)
        elif belirtec == "~":
            tamam, a = yigin_cikar(y)
            if not tamam:
                hata = EKSIK_ISLENEN
            elif a == INT_MIN:
                hata = TASMA
            else:
                yigin_it(y, -a)
        elif len(belirtec) == 1 and c in "+-*/^":
            tamam, b = yigin_cikar(y)  # önce b (tepe), sonra a
            if tamam:
                tamam, a = yigin_cikar(y)
            if not tamam:
                hata = EKSIK_ISLENEN
            else:
                hata, r = islem_uygula(c, a, b)
                if hata == HATA_YOK:
                    yigin_it(y, r)
        else:
            hata = GECERSIZ_BELIRTEC
        if iz:
            print(f"    {belirtec:<11} -> yığın: " + yigin_yaz(y))
    kalan = y.boyut
    if hata == HATA_YOK:
        sutun = n + 1
        if y.boyut == 0:
            hata = BOS_IFADE
        elif y.boyut > 1:
            hata = FAZLA_ISLENEN
        else:
            sonuc = y.veri[0]
    return hata, sonuc, sutun, kalan


def satir_isle(s, iz):
    """Bir ifadeyi değerlendirip yazar; geçerliyse True döner"""
    global it_sayisi, cikar_sayisi, en_buyuk_derinlik
    it_sayisi = cikar_sayisi = 0
    en_buyuk_derinlik = 0
    if iz:
        print("  " + s)
    hata, sonuc, sutun, kalan = sonek_degerlendir(s, iz)
    bas = "    sonuç: " if iz else f"  {s:<22} "
    if hata == HATA_YOK:
        govde = f"= {sonuc}"
    elif hata == FAZLA_ISLENEN:
        govde = (f"-> HATA ifade sonu: {HATA_ILETISI[hata]} "
                 f"(yığında {kalan} değer kaldı)")
    elif hata == BOS_IFADE:
        govde = f"-> HATA: {HATA_ILETISI[hata]}"
    else:
        govde = f"-> HATA sütun {sutun}: {HATA_ILETISI[hata]}"
    print(bas + govde + f"   [it {it_sayisi}, çıkar {cikar_sayisi}, "
          f"derinlik {en_buyuk_derinlik}]")
    return hata == HATA_YOK


def main():
    print("1) Yığın izi: her belirteçten sonra işlenen yığını "
          "(taban solda)")
    satir_isle("5 1 2 + 4 * + 3 -", True)
    satir_isle("10 3 -", True)
    satir_isle("2 3 2 ^ ^", True)

    print("\n2) Girdi dosyasındaki ifadeler")
    satirlar = sys.stdin.buffer.read().decode("utf-8").split("\n")
    if satirlar and satirlar[-1] == "":
        satirlar.pop()  # dosya sonundaki satır sonu (C'deki fgets gibi)
    gecerli = 0
    for satir in satirlar:
        gecerli += 1 if satir_isle(satir, False) else 0
    toplam = len(satirlar)
    print(f"  toplam {toplam} ifade: geçerli {gecerli}, "
          f"hatalı {toplam - gecerli}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int> ile aynı
# algoritma; Python — list (append/pop). Hazır sonek değerlendirici
# standart kütüphanelerde yoktur (HP-35 gibi RPN hesap makineleri ve
# PostScript, JVM, CPython yığın makineleri bu ilkeyle çalışır).

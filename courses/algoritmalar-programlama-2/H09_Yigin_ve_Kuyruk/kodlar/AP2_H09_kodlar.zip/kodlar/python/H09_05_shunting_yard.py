"""H09_05_shunting_yard.py — AP-2 Hafta 9 · Örnek 5 (★★★)
Amaç    : Dijkstra'nın manevra sahası (Shunting-yard) algoritmasıyla araek
          (infix) → sonek (postfix) dönüşümü: öncelik ve birleşme yönü
          tablosu (^ sağdan birleşmeli), tekli eksi ayrı işleç (~),
          sözdizimi ve parantez hataları
Çalıştır: python3 H09_05_shunting_yard.py \\
          < ../girdiler/H09_05_shunting_yard.txt
Eşleri  : c/H09_05_shunting_yard.c · cpp/H09_05_shunting_yard.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

IZ_BASLIK = "    belirteç işleç yığını   çıktı                eylem"

SAYI, AD, ISLEC, SOL_PAR, SAG_PAR = range(5)
(HATA_YOK, GECERSIZ_KARAKTER, ISLENEN_BEKLENIYOR, ISLEC_BEKLENIYOR,
 ESLESMEYEN_KAPANIS, ACIK_PARANTEZ, BOS_IFADE) = range(7)

HATA_ILETISI = ("yok", "geçersiz karakter", "işlenen bekleniyordu",
                "işleç bekleniyordu", "eşleşmeyen ')'", "kapanmamış '('",
                "boş ifade")


class Belirtec:
    __slots__ = ("tur", "bas", "uz", "islec")  # yer: s[bas:bas + uz]

    def __init__(self, tur, bas, uz, islec):
        self.tur = tur
        self.bas = bas
        self.uz = uz
        self.islec = islec  # + - * / ^ ve tekli eksi için ~


class Yigin:
    __slots__ = ("veri", "kapasite", "boyut")  # belirteç indisleri


it_sayisi = cikar_sayisi = 0
en_buyuk_derinlik = 0


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [0] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, x):
    global it_sayisi, en_buyuk_derinlik
    if y.boyut == y.kapasite:
        return False
    y.veri[y.boyut] = x
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut
    return True


def yigin_cikar(y):
    global cikar_sayisi
    if y.boyut == 0:
        return False, 0
    y.boyut -= 1
    cikar_sayisi += 1
    return True, y.veri[y.boyut]


def yigin_tepe(y):
    if y.boyut == 0:
        return False, 0
    return True, y.veri[y.boyut - 1]


def oncelik(op):
    """Öncelik ve birleşme yönü tablosu"""
    if op in "+-":
        return 1
    if op in "*/":
        return 2
    return 3 if op == "~" else 4  # ~ tekli eksi, ^ üs


def sag_birlesmeli(op):
    return op == "^" or op == "~"


def once_cikar_mi(ust, gelen):
    """Yığının tepesindeki ust, gelen işleçten önce çıktıya gitmeli mi?"""
    return (oncelik(ust) > oncelik(gelen) or
            (oncelik(ust) == oncelik(gelen) and not sag_birlesmeli(gelen)))


def belirtecle(s):
    """s belirteçlere ayrılır; (hata, belirteçler, sütun) döner"""
    n = len(s)
    b = []
    islenen_bekleniyor = True
    i = 0
    while i < n:
        c = s[i]
        if c in " \t":
            i += 1
            continue
        t = Belirtec(SAYI, i, 1, c)
        if "0" <= c <= "9":
            while i + t.uz < n and "0" <= s[i + t.uz] <= "9":
                t.uz += 1
        elif "a" <= c <= "z":
            t.tur = AD
        elif c in "()":
            t.tur = SOL_PAR if c == "(" else SAG_PAR
        elif c in "+-*/^":
            t.tur = ISLEC
            if c == "-" and islenen_bekleniyor:
                t.islec = "~"  # başta, '(' ya da işleçten sonra: tekli
        else:
            return GECERSIZ_KARAKTER, b, i + 1
        if islenen_bekleniyor:
            if t.tur == SAG_PAR or (t.tur == ISLEC and t.islec != "~"):
                return ISLENEN_BEKLENIYOR, b, i + 1
            islenen_bekleniyor = t.tur in (SOL_PAR, ISLEC)
        else:
            if t.tur in (SAYI, AD, SOL_PAR):
                return ISLEC_BEKLENIYOR, b, i + 1
            islenen_bekleniyor = t.tur == ISLEC
        b.append(t)
        i += t.uz
    if islenen_bekleniyor:
        return (BOS_IFADE if not b else ISLENEN_BEKLENIYOR), b, n + 1
    return HATA_YOK, b, n + 1


def metin(s, t):
    """Belirtecin metni: sayı ve adlar girdiden, işleçler tek karakter"""
    if t.tur in (SAYI, AD):
        return s[t.bas:t.bas + t.uz]
    return t.islec


def iz_satiri(bt, y, b, cikti, s, eylem):
    yg = "[" + " ".join(metin(s, b[y.veri[j]]) for j in range(y.boyut)) + "]"
    ck = " ".join(metin(s, b[j]) for j in cikti)
    print(f"    {bt:<8} {yg:<14} {ck:<20} {eylem}")


def sonege_cevir(b, s, iz):
    """Shunting-yard: b → çıktı (belirteç indisleri); (hata, çıktı, sütun)"""
    m = len(b)
    y = yigin_olustur(m + 1)
    hata, sutun = HATA_YOK, 0
    cikti = []
    i = 0
    while i < m and hata == HATA_YOK:
        t = b[i]
        if t.tur in (SAYI, AD):
            cikti.append(i)
            eylem = "çıktıya yaz"
        elif t.tur == SOL_PAR:
            yigin_it(y, i)
            eylem = "it ("
        elif t.tur == SAG_PAR:
            eylem = "çıkar:"
            tamam, j = yigin_tepe(y)
            while tamam and b[j].tur != SOL_PAR:
                yigin_cikar(y)
                cikti.append(j)
                eylem += " " + metin(s, b[j])
                tamam, j = yigin_tepe(y)
            if not yigin_cikar(y)[0]:
                hata, sutun = ESLESMEYEN_KAPANIS, t.bas + 1
            eylem += "; ( atılır" if hata == HATA_YOK else "; ( yok!"
        elif t.islec == "~":
            yigin_it(y, i)  # önek işleç: hiçbir şeyi çıkarmaz
            eylem = "it ~ (tekli eksi)"
        else:
            eylem = ""
            tamam, j = yigin_tepe(y)
            while (tamam and b[j].tur == ISLEC and
                   once_cikar_mi(b[j].islec, t.islec)):
                yigin_cikar(y)
                cikti.append(j)
                eylem += ("çıkar: " if eylem == "" else " ") + metin(s, b[j])
                tamam, j = yigin_tepe(y)
            eylem += ("it " if eylem == "" else "; it ") + metin(s, t)
            yigin_it(y, i)
        if iz:
            iz_satiri(metin(s, t), y, b, cikti, s, eylem)
        i += 1
    if hata == HATA_YOK:
        eylem = "boşalt:"
        tamam, j = yigin_cikar(y)
        while tamam:
            if b[j].tur == SOL_PAR:
                hata, sutun = ACIK_PARANTEZ, b[j].bas + 1
                eylem += " ( kapanmamış!"
                break
            cikti.append(j)
            eylem += " " + metin(s, b[j])
            tamam, j = yigin_cikar(y)
        if iz:
            iz_satiri("(son)", y, b, cikti, s, eylem)
    return hata, cikti, sutun


def satir_isle(s, iz):
    global it_sayisi, cikar_sayisi, en_buyuk_derinlik
    it_sayisi = cikar_sayisi = 0
    en_buyuk_derinlik = 0
    if iz:
        print("  " + s + "\n" + IZ_BASLIK)
    hata, b, sutun = belirtecle(s)
    cikti = []
    if hata == HATA_YOK:
        hata, cikti, sutun = sonege_cevir(b, s, iz)
    bas = "    sonuç: " if iz else f"  {s:<22} "
    if hata != HATA_YOK:
        print(bas + f"-> HATA sütun {sutun}: {HATA_ILETISI[hata]}")
        return False
    ck = " ".join(metin(s, b[j]) for j in cikti)
    print(bas + f"-> {ck}   [belirteç {len(b)}, it {it_sayisi}, "
          f"çıkar {cikar_sayisi}, derinlik {en_buyuk_derinlik}]")
    return True


def main():
    print("1) Öncelik ve birleşme yönü tablosu")
    print("  işleç  öncelik  birleşme")
    for op in "+-*/~^":
        print(f"    {op}       {oncelik(op)}     "
              + ("sağdan" if sag_birlesmeli(op) else "soldan"))
    print("  (~ tekli eksidir: başta, '(' ya da işleçten sonra gelen '-')")

    print("\n2) Adım adım dönüşüm (her belirteçten sonra yığın ve çıktı)")
    satir_isle("3 + 4 * 2", True)
    satir_isle("(1 + 2) * 3", True)
    satir_isle("2 ^ 3 ^ 2", True)
    satir_isle("a - b - c", True)

    print("\n3) Girdi dosyasındaki ifadeler")
    satirlar = sys.stdin.buffer.read().decode("utf-8").split("\n")
    if satirlar and satirlar[-1] == "":
        satirlar.pop()  # dosya sonundaki satır sonu (C'deki fgets gibi)
    gecerli = 0
    for satir in satirlar:
        gecerli += 1 if satir_isle(satir, False) else 0
    toplam = len(satirlar)
    print(f"  toplam {toplam} ifade: dönüştürülen {gecerli}, "
          f"hatalı {toplam - gecerli}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack yalnızca
# işleç yığınını sağlar); Python — yok (ast modülü ifadeyi ayrıştırır ama
# sonek üretmez). Derleyicilerin ayrıştırıcıları aynı öncelik/birleşme
# kurallarını uygular.

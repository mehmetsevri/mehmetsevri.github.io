"""H09_01_dizi_yigin.py — AP-2 Hafta 9 · Örnek 1 (★)
Amaç    : Dizi tabanlı yığın ADT'si (sabit kapasite): it, çıkar, tepe,
          boş mu; taşma ve alt taşma dönüş koduyla (bool) bildirilir
Çalıştır: python3 H09_01_dizi_yigin.py
Eşleri  : c/H09_01_dizi_yigin.c · cpp/H09_01_dizi_yigin.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Yigin:
    """veri[0..boyut-1] dolu; tepe veri[boyut-1]; boyut <= kapasite"""
    __slots__ = ("veri", "kapasite", "boyut")


it_sayisi = 0
cikar_sayisi = 0
en_buyuk_derinlik = 0


def yigin_olustur(kapasite):
    """Sabit uzunluklu liste ayrılır; yerleşik büyümeye güvenilmez."""
    y = Yigin()
    y.veri = [0] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_bos_mu(y):
    return y.boyut == 0


def yigin_dolu_mu(y):
    return y.boyut == y.kapasite


def yigin_it(y, x):
    """Taşma: yığın doluysa False döner ve yığın değişmez"""
    global it_sayisi, en_buyuk_derinlik
    if yigin_dolu_mu(y):
        return False
    y.veri[y.boyut] = x
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut
    return True


def yigin_cikar(y):
    """Alt taşma: yığın boşsa (False, 0); değilse (True, tepe)"""
    global cikar_sayisi
    if yigin_bos_mu(y):
        return False, 0
    y.boyut -= 1
    cikar_sayisi += 1
    return True, y.veri[y.boyut]


def yigin_tepe(y):
    """Tepedeki elemanı çıkarmadan okur"""
    if yigin_bos_mu(y):
        return False, 0
    return True, y.veri[y.boyut - 1]


def yigin_yaz(y):
    return ("taban [" + " ".join(str(y.veri[i]) for i in range(y.boyut))
            + "] tepe")


def ikiliye_cevir(sayi):
    """Ondalık sayıyı ikiliye çevirir: kalanlar yığına, sonra ters sırada"""
    y = yigin_olustur(32)
    satir = f"  {sayi} ->"
    n = sayi
    while n > 0:
        yigin_it(y, n % 2)
        satir += f" {n % 2}"
        n //= 2
    print(satir + "  (kalanlar üretildiği sırada)")
    satir = "  ikili: "
    tamam, b = yigin_cikar(y)
    while tamam:
        satir += str(b)
        tamam, b = yigin_cikar(y)
    print(satir + "  (yığından çıkış sırası)")


def rastgele_sinama(islem, kapasite):
    y = yigin_olustur(kapasite)
    it0, cikar0 = it_sayisi, cikar_sayisi
    tasma = alt_tasma = 0
    rastgele_tohum(42)
    for _ in range(islem):
        if rastgele_aralik(0, 1) == 0:
            if not yigin_it(y, rastgele_aralik(0, 999)):
                tasma += 1
        elif not yigin_cikar(y)[0]:
            alt_tasma += 1
    basarili = (it_sayisi - it0) + (cikar_sayisi - cikar0)
    fark = (it_sayisi - it0) - (cikar_sayisi - cikar0)
    print(f"  {islem} işlem, kapasite {kapasite}: başarılı = {basarili}, "
          f"taşma = {tasma}, alt taşma = {alt_tasma}")
    print(f"  son boyut = {y.boyut}; it - çıkar = {fark}; tutarlı mı? "
          + ("evet" if y.boyut == fark else "HAYIR"))


def main():
    y = yigin_olustur(4)
    print("1) Kapasitesi 4 olan yığına 10, 20, 30, 40, 50 itilir")
    for k in range(1, 6):
        tamam = yigin_it(y, 10 * k)
        print(f"  it {10 * k} -> "
              + ("evet" if tamam else "HAYIR (taşma: yığın dolu)")
              + "  " + yigin_yaz(y) + f"  boyut = {y.boyut}")

    print("\n2) Tepeye bakma ve çıkarma (LIFO: son giren ilk çıkar)")
    tamam, x = yigin_tepe(y)
    if tamam:
        print(f"  tepe -> {x} (çıkarılmadı)")
    for _ in range(5):
        tamam, x = yigin_cikar(y)
        if tamam:
            print(f"  çıkar -> {x}  " + yigin_yaz(y))
        else:
            print("  çıkar -> HAYIR (alt taşma: yığın boş)  " + yigin_yaz(y))
    print("  tepe -> " + ("?" if yigin_tepe(y)[0] else "HAYIR (boş yığın)"))
    print(f"  sayaçlar: it = {it_sayisi}, çıkar = {cikar_sayisi}, "
          f"en büyük derinlik = {en_buyuk_derinlik}")

    print("\n3) Uygulama: ondalıktan ikiliye (kalanlar yığına)")
    ikiliye_cevir(2026)
    ikiliye_cevir(37)

    print("\n4) Rastgele it/çıkar dizisi (tohum 42): sözleşme denetimi")
    rastgele_sinama(100000, 8)
    rastgele_sinama(100000, 1000)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int> (push, pop,
# top, empty; boş yığında pop/top tanımsız davranış); Python — list
# (append, pop, a[-1]; boş listede pop IndexError verir).

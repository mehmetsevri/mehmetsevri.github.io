"""H09_12_yiginli_hizli_siralama.py — AP-2 Hafta 9 · Örnek 12 (★★★)
Amaç    : Özyinelemesiz hızlı sıralama: çağrı yığını yerine açık yığın
          (lo, hi) aralıkları. BÜYÜK parça yığına itilir, KÜÇÜK parça hemen
          işlenir → yığın derinliği <= ⌊log2 n⌋ + 1 (kapasite tam bu kadar
          ayrılır). Lomuto bölümleme (H6 Örnek 4); özyinelemeli sürümün
          derinliğiyle karşılaştırma; kâhin: kütüphane sıralaması
Çalıştır: python3 H09_12_yiginli_hizli_siralama.py
Eşleri  : c/H09_12_yiginli_hizli_siralama.c ·
          cpp/H09_12_yiginli_hizli_siralama.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Yigin:
    """(lo, hi) demetleri: sıralanmayı bekleyen a[lo..hi]"""
    __slots__ = ("veri", "kapasite", "boyut")


karsilastirma = takas_sayisi = it_sayisi = cikar_sayisi = tasma = 0
en_buyuk_derinlik = ozy_derinlik = 0


def sayaclari_sifirla():
    global karsilastirma, takas_sayisi, it_sayisi, cikar_sayisi, tasma
    global en_buyuk_derinlik, ozy_derinlik
    karsilastirma = takas_sayisi = it_sayisi = cikar_sayisi = tasma = 0
    en_buyuk_derinlik = ozy_derinlik = 0


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [None] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, r):
    global tasma, it_sayisi, en_buyuk_derinlik
    if y.boyut == y.kapasite:
        tasma += 1  # ⌊log2 n⌋ + 1 sınırı aşılsaydı burada görülürdü
        return
    y.veri[y.boyut] = r
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut


def yigin_cikar(y):
    global cikar_sayisi
    if y.boyut == 0:
        return False, None
    y.boyut -= 1
    cikar_sayisi += 1
    return True, y.veri[y.boyut]


def taban_log2(n):
    k = 0
    while n > 1:
        n //= 2
        k += 1
    return k


def takas(a, i, j):
    global takas_sayisi
    a[i], a[j] = a[j], a[i]
    takas_sayisi += 1


def bolumle(a, lo, hi):
    """Lomuto: pivot a[hi]; değişmez a[lo..i] < pivot <= a[i+1..j-1]"""
    global karsilastirma
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        karsilastirma += 1
        if a[j] < pivot:
            i += 1
            takas(a, i, j)
    takas(a, i + 1, hi)
    return i + 1


def yigin_yaz(y):
    return "[" + " ".join(f"{y.veri[k][0]}..{y.veri[k][1]}"
                          for k in range(y.boyut)) + "]"


def izle(a, y, pivot, p, buyuk, lo, hi):
    s = f"    pivot {pivot} -> p = {p}; "
    if buyuk[0] < buyuk[1]:
        s += f"it {buyuk[0]}..{buyuk[1]}"
    else:
        s += "büyük parça < 2 eleman"
    if lo < hi:
        s += f", sırada {lo}..{hi}"
    print(s + "; yığın " + yigin_yaz(y))
    print("      dizi " + " ".join(str(x) for x in a))


def yiginli_hizli_sirala(a, iz):
    """Açık yığınlı hızlı sıralama: büyük parçayı it, küçüğü hemen işle"""
    n = len(a)
    y = yigin_olustur(taban_log2(n if n > 0 else 1) + 1)
    if n > 1:
        yigin_it(y, (0, n - 1))
    tamam, r = yigin_cikar(y)
    while tamam:
        lo, hi = r
        if iz:
            print(f"  çıkar {lo}..{hi}")
        while lo < hi:
            pivot = a[hi]
            p = bolumle(a, lo, hi)
            if p - lo < hi - p:  # sol küçük: sağı it
                buyuk = (p + 1, hi)
                hi = p - 1
            else:                # sağ küçük: solu it
                buyuk = (lo, p - 1)
                lo = p + 1
            if buyuk[0] < buyuk[1]:
                yigin_it(y, buyuk)
            if iz:
                izle(a, y, pivot, p, buyuk, lo, hi)
        tamam, r = yigin_cikar(y)


def hizli_ozyinelemeli(a, lo, hi, d):
    """Karşılaştırma için iki çağrılı özyinelemeli sürüm (d: derinlik)"""
    global ozy_derinlik
    if d > ozy_derinlik:
        ozy_derinlik = d
    if lo >= hi:
        return
    p = bolumle(a, lo, hi)
    hizli_ozyinelemeli(a, lo, p - 1, d + 1)
    hizli_ozyinelemeli(a, p + 1, hi, d + 1)


def girdi_uret(n, tur):
    if tur == 0:
        return [rastgele_aralik(0, 1000000) for _ in range(n)]
    if tur == 1:
        return list(range(n))
    if tur == 2:
        return [n - i for i in range(n)]
    return [5] * n


def satir(ad, n, tur):
    """İki sürümü aynı girdide çalıştırır, kâhinle karşılaştırır"""
    rastgele_tohum(42)
    a = girdi_uret(n, tur)
    b = a[:]
    k = sorted(a)  # kâhin
    sayaclari_sifirla()
    hizli_ozyinelemeli(b, 0, n - 1, 1)
    ozy = ozy_derinlik
    sayaclari_sifirla()
    yiginli_hizli_sirala(a, False)
    dogru = a == k and b == k
    print(f"  {ad} {n:7d} {karsilastirma:11d} {en_buyuk_derinlik:8d} "
          f"{taban_log2(n) + 1:6d} {ozy:10d} {tasma:6d}  "
          + ("evet" if dogru else "HAYIR"))


def main():
    a = [7, 3, 5, 9, 2, 4, 1, 8, 6]
    print("1) İzleme: a = [7 3 5 9 2 4 1 8 6], pivot = a[hi] (Lomuto)")
    sayaclari_sifirla()
    yiginli_hizli_sirala(a, True)
    print(f"  karşılaştırma = {karsilastirma}, takas = {takas_sayisi}, "
          f"it = {it_sayisi}, çıkar = {cikar_sayisi}, en büyük derinlik = "
          f"{en_buyuk_derinlik} (sınır {taban_log2(9) + 1})")

    print("\n2) Yığın derinliği: açık yığın (kapasite ⌊log2 n⌋ + 1) ve "
          "özyinelemeli sürüm")
    print("  girdi          n  karşılaşt.  yığın   sınır  özyineli  taşma"
          "  kâhin")
    satir("rastgele", 500, 0)
    satir("sıralı  ", 500, 1)
    satir("ters    ", 500, 2)
    satir("aynı    ", 500, 3)
    satir("rastgele", 1000, 0)
    satir("rastgele", 10000, 0)
    satir("rastgele", 100000, 0)
    print("  (sıralı/ters/aynı girdide Lomuto en kötü durumdadır: "
          "özyinelemeli derinlik n'e çıkar)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort (algoritmayı standart belirtmez);
# C++ — std::sort (libstdc++: introsort; derinlik 2⌊log2 n⌋ aşılınca öbek
# sıralamasına geçer);
# Python — list.sort / sorted (Timsort). Kütüphaneler yalnızca kâhin.

"""H09_13_kayan_pencere.py — AP-2 Hafta 9 · Örnek 13 (★★★)
Amaç    : İki uçlu kuyruk (deque) ile kayan pencere en büyüğü: deque'da
          penceredeki indisler değerleri azalan sırada tutulur (monotonik
          deque); önde pencereden çıkan indis, arkada yeni elemandan küçük
          ya da eşit olanlar atılır → Θ(n), ek bellek O(k). Deque elle,
          dairesel tamponla (kapasite k); O(nk) kaba kuvvet kâhinle sınama
Çalıştır: python3 H09_13_kayan_pencere.py
Eşleri  : c/H09_13_kayan_pencere.c · cpp/H09_13_kayan_pencere.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Deque:
    """veri[bas], veri[bas+1], ... (mod kapasite); sayac eleman"""
    __slots__ = ("veri", "kapasite", "bas", "sayac")


ekle_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0
en_buyuk_boyut = 0


def sayaclari_sifirla():
    global ekle_sayisi, cikar_sayisi, karsilastirma, kaba_karsilastirma
    global en_buyuk_boyut
    ekle_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0
    en_buyuk_boyut = 0


def deque_olustur(kapasite):
    d = Deque()
    d.veri = [0] * kapasite
    d.kapasite = kapasite
    d.bas = d.sayac = 0
    return d


def deque_bos_mu(d):
    return d.sayac == 0


def boyut_guncelle(d):
    global ekle_sayisi, en_buyuk_boyut
    ekle_sayisi += 1
    if d.sayac > en_buyuk_boyut:
        en_buyuk_boyut = d.sayac


def arkaya_ekle(d, x):
    if d.sayac == d.kapasite:
        return False
    d.veri[(d.bas + d.sayac) % d.kapasite] = x
    d.sayac += 1
    boyut_guncelle(d)
    return True


def one_ekle(d, x):
    if d.sayac == d.kapasite:
        return False
    d.bas = (d.bas - 1 + d.kapasite) % d.kapasite  # geriye sarma
    d.veri[d.bas] = x
    d.sayac += 1
    boyut_guncelle(d)
    return True


def arkadan_cikar(d):
    global cikar_sayisi
    if d.sayac == 0:
        return False, 0
    d.sayac -= 1
    cikar_sayisi += 1
    return True, d.veri[(d.bas + d.sayac) % d.kapasite]


def onden_cikar(d):
    global cikar_sayisi
    if d.sayac == 0:
        return False, 0
    x = d.veri[d.bas]
    d.bas = (d.bas + 1) % d.kapasite
    d.sayac -= 1
    cikar_sayisi += 1
    return True, x


def deque_on(d):
    return d.veri[d.bas]


def deque_arka(d):
    return d.veri[(d.bas + d.sayac - 1) % d.kapasite]


def kucuk_esit_mi(x, y):
    global karsilastirma
    karsilastirma += 1
    return x <= y


def kayan_en_buyuk(a, k, iz):
    """en_buyuk[i] = max(a[i..i+k-1]), i = 0..n-k (1 <= k <= n)"""
    n = len(a)
    d = deque_olustur(k)
    en_buyuk = [0] * (n - k + 1)
    for i in range(n):
        atilan = []
        if not deque_bos_mu(d) and deque_on(d) == i - k:
            x = onden_cikar(d)[1]  # pencereden çıkan indis
            atilan.append(f"önden {a[x]}")
        while not deque_bos_mu(d) and kucuk_esit_mi(a[deque_arka(d)], a[i]):
            x = arkadan_cikar(d)[1]  # bundan sonra hiç en büyük olamaz
            atilan.append(f"arkadan {a[x]}")
        arkaya_ekle(d, i)
        if i >= k - 1:
            en_buyuk[i - k + 1] = a[deque_on(d)]
        if iz:
            ic = "[" + " ".join(str(a[d.veri[(d.bas + q) % k]])
                                for q in range(d.sayac)) + "]"
            eb = str(en_buyuk[i - k + 1]) if i >= k - 1 else "-"
            print(f"  {i:2d} {a[i]:4d}   {ic:<12} {eb:>5}   "
                  + (", ".join(atilan) if atilan else "-"))
    return en_buyuk


def kaba_kuvvet(a, k):
    """Kâhin: her pencereyi baştan tara, O(nk)"""
    global kaba_karsilastirma
    n = len(a)
    en_buyuk = [0] * (n - k + 1)
    for i in range(n - k + 1):
        m = a[i]
        for j in range(i + 1, i + k):
            kaba_karsilastirma += 1
            if a[j] > m:
                m = a[j]
        en_buyuk[i] = m
    return en_buyuk


def deque_gosterimi():
    d = deque_olustur(4)
    print("1) İki uçlu kuyruk (kapasite 4): iki uçtan ekleme ve çıkarma")
    arkaya_ekle(d, 10)
    arkaya_ekle(d, 20)
    one_ekle(d, 5)
    print(f"  arkaya 10, arkaya 20, öne 5   -> bas = {d.bas}, sayaç = "
          f"{d.sayac} (öne ekleme bas'ı geriye sardı)")
    print("  sırası: " + "".join(f"{d.veri[(d.bas + q) % 4]} "
                                 for q in range(d.sayac))
          + f"| ön = {deque_on(d)}, arka = {deque_arka(d)}")
    e1, e0 = one_ekle(d, 1), one_ekle(d, 0)
    print("  öne 1 -> " + ("evet" if e1 else "HAYIR") + "; öne 0 -> "
          + ("evet" if e0 else "HAYIR") + " (kapasite 4)")
    x = arkadan_cikar(d)[1]
    y = onden_cikar(d)[1]
    print(f"  arkadan çıkar -> {x}; önden çıkar -> {y}; kalan sayaç = "
          f"{d.sayac}")


def main():
    deque_gosterimi()

    a = [4, 2, 12, 3, 8, 1, 5, 7, 6, 2]
    print("\n2) İzleme: a = [4 2 12 3 8 1 5 7 6 2], k = 3 (deque'da "
          "indisler; değerleri yazılı)")
    print("   i a[i]   deque        en büyük  atılanlar")
    sayaclari_sifirla()
    sonuc = kayan_en_buyuk(a, 3, True)
    print("  pencere en büyükleri: " + " ".join(str(v) for v in sonuc))
    print(f"  ekle = {ekle_sayisi}, çıkar = {cikar_sayisi}, karşılaştırma = "
          f"{karsilastirma}, en büyük deque boyu = {en_buyuk_boyut} (k = 3)")

    print("\n3) Rastgele 2000 girdi (n = 1..80, k = 1..n, tohum 42) ve "
          "kâhin")
    uyusmazlik = ihlal = 0
    rastgele_tohum(42)
    for _ in range(2000):
        n = rastgele_aralik(1, 80)
        k = rastgele_aralik(1, n)
        dizi = [rastgele_aralik(0, 50) for _ in range(n)]
        sayaclari_sifirla()
        r1 = kayan_en_buyuk(dizi, k, False)
        r2 = kaba_kuvvet(dizi, k)
        uyusmazlik += 1 if r1 != r2 else 0
        ihlal += 1 if (ekle_sayisi + cikar_sayisi > 2 * n
                       or en_buyuk_boyut > k) else 0
    print(f"  kâhinle uyuşmazlık = {uyusmazlik}, ekle + çıkar > 2n ya da "
          f"boy > k = {ihlal}")

    print("\n4) n = 100000 rastgele: deque Θ(n), kaba kuvvet "
          "(n - k + 1)(k - 1) karşılaştırma")
    print("       k  ekle + çıkar  karş./n  en büyük boy   kaba karş.")
    n = 100000
    rastgele_tohum(42)
    b = [rastgele_aralik(0, 1000000) for _ in range(n)]
    k = 10
    while k <= 10000:
        sayaclari_sifirla()
        kayan_en_buyuk(b, k, False)
        print(f"  {k:6d} {ekle_sayisi + cikar_sayisi:13d} "
              f"{karsilastirma / n:8.3f} {en_buyuk_boyut:13d} "
              f"{(n - k + 1) * (k - 1):12d}")
        k *= 10


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::deque<int> (push_back,
# pop_back, pop_front, front, back); Python — collections.deque (append,
# pop, popleft, d[0], d[-1]).

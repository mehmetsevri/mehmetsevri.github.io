"""H09_14_histogram_dikdortgen.py — AP-2 Hafta 9 · Örnek 14 (★★★)
Amaç    : (Meydan okuma) Histogramdaki en büyük dikdörtgen: yükseklikleri
          artan sırada tutan monotonik yığın; bir çubuk çıkarıldığında
          solundaki ilk kısa çubuk yığında altındaki, sağındaki ilk kısa
          çubuk o anki i'dir → genişlik = i - sol - 1. Θ(n); O(n^2)
          kâhinle sınanır
Çalıştır: python3 H09_14_histogram_dikdortgen.py
Eşleri  : c/H09_14_histogram_dikdortgen.c ·
          cpp/H09_14_histogram_dikdortgen.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Yigin:
    """çubuk indisleri; yükseklikleri tabandan tepeye artar"""
    __slots__ = ("veri", "kapasite", "boyut")


it_sayisi = cikar_sayisi = karsilastirma = 0
en_buyuk_derinlik = 0


def sayaclari_sifirla():
    global it_sayisi, cikar_sayisi, karsilastirma, en_buyuk_derinlik
    it_sayisi = cikar_sayisi = karsilastirma = 0
    en_buyuk_derinlik = 0


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [0] * (kapasite if kapasite > 0 else 1)
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, i):
    global it_sayisi, en_buyuk_derinlik
    y.veri[y.boyut] = i
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut


def yigin_cikar(y):
    global cikar_sayisi
    cikar_sayisi += 1
    y.boyut -= 1
    return y.veri[y.boyut]


def buyuk_esit_mi(x, y):
    global karsilastirma
    karsilastirma += 1
    return x >= y


def en_buyuk_dikdortgen(h, iz):
    """h histogramındaki en büyük dikdörtgenin alanı"""
    n = len(h)
    y = yigin_olustur(n)
    en_iyi = 0
    for i in range(n + 1):
        yuk = 0 if i == n else h[i]  # i == n: tüm yığını boşaltan bekçi
        cikan = []
        while y.boyut > 0 and buyuk_esit_mi(h[y.veri[y.boyut - 1]], yuk):
            t = yigin_cikar(y)
            sol = y.veri[y.boyut - 1] if y.boyut > 0 else -1
            alan = h[t] * (i - sol - 1)
            if alan > en_iyi:
                en_iyi = alan
            cikan.append(f"{h[t]}x{i - sol - 1}={alan}")
        if i < n:
            yigin_it(y, i)
        if iz:
            ic = "[" + " ".join(str(h[y.veri[q]])
                                for q in range(y.boyut)) + "]"
            bas = f"  {i:2d} {yuk:4d}   " if i < n else "  son  (0)  "
            son = " ".join(cikan) if cikan or i == n else "-"
            print(bas + f"{ic:<14} {en_iyi:4d}   {son}")
    return en_iyi


def kaba_kuvvet(h):
    """Kâhin: her sol uç için en kısa çubuğu taşıyarak sağa genişlet"""
    n = len(h)
    en_iyi = 0
    for i in range(n):
        en_kisa = h[i]
        for j in range(i, n):
            if h[j] < en_kisa:
                en_kisa = h[j]
            alan = en_kisa * (j - i + 1)
            if alan > en_iyi:
                en_iyi = alan
    return en_iyi


def main():
    h = [2, 4, 3, 5, 1, 4, 4, 2]
    print("1) İzleme: h = [2 4 3 5 1 4 4 2] (çıkan çubuk: yükseklik x "
          "genişlik = alan)")
    print("   i    h   yığın (yük.)   en iyi  çıkanlar")
    sayaclari_sifirla()
    alan = en_buyuk_dikdortgen(h, True)
    print(f"  en büyük alan = {alan} (kâhin {kaba_kuvvet(h)}); it = "
          f"{it_sayisi}, çıkar = {cikar_sayisi}, karşılaştırma = "
          f"{karsilastirma}")

    print("\n2) Rastgele 2000 histogram (n = 0..60, yükseklik 0..30, tohum "
          "42) ve kâhin")
    uyusmazlik = ihlal = 0
    rastgele_tohum(42)
    for _ in range(2000):
        n = rastgele_aralik(0, 60)
        dizi = [rastgele_aralik(0, 30) for _ in range(n)]
        sayaclari_sifirla()
        if en_buyuk_dikdortgen(dizi, False) != kaba_kuvvet(dizi):
            uyusmazlik += 1
        ihlal += 1 if it_sayisi + cikar_sayisi > 2 * n else 0
    print(f"  kâhinle uyuşmazlık = {uyusmazlik}, it + çıkar > 2n = {ihlal}")

    print("\n3) Büyük girdiler (n = 100000): karşılaştırma <= 2n")
    print("  girdi           en büyük alan  karş./n  derinlik")
    n = 100000
    ad = ["rastgele 0..10^4", "artan           ", "azalan          ",
          "sabit 7         "]
    rastgele_tohum(42)
    for tur in range(4):
        if tur == 0:
            b = [rastgele_aralik(0, 10000) for _ in range(n)]
        elif tur == 1:
            b = [i + 1 for i in range(n)]
        elif tur == 2:
            b = [n - i for i in range(n)]
        else:
            b = [7] * n
        sayaclari_sifirla()
        alan = en_buyuk_dikdortgen(b, False)
        print(f"  {ad[tur]} {alan:14d} {karsilastirma / n:8.3f} "
              f"{en_buyuk_derinlik:9d}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack<int> ile
# aynı algoritma); Python — yok (list yığın olarak). İki boyutlu sürüm
# (0/1 matriste en büyük dolu dikdörtgen) her satırı bir histogram sayar.

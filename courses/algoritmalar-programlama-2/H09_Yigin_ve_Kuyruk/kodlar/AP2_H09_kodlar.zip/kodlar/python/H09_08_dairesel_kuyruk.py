"""H09_08_dairesel_kuyruk.py — AP-2 Hafta 9 · Örnek 8 (★★)
Amaç    : Dairesel tampon (circular buffer) kuyruk: bas/son indisleri ve
          mod aritmetiği; dolu/boş ayrımı iki yöntemle: (A) eleman sayacı,
          (B) bir hücre boş bırakılır. Kapasite 2'nin kuvvetiyse mod
          yerine bit maskesi. Rastgele işlem dizisiyle kâhinli sınama
Çalıştır: python3 H09_08_dairesel_kuyruk.py
Eşleri  : c/H09_08_dairesel_kuyruk.c · cpp/H09_08_dairesel_kuyruk.cpp
Çıktı   : üç dilde aynı (=)
"""
from collections import deque  # yalnızca kâhin olarak

from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Kuyruk:
    """(A) Sayaçlı: veri[bas], ..., veri[son - 1] (mod kapasite) doludur"""
    __slots__ = ("veri", "kapasite", "bas", "son", "sayac", "maskeli")


class KuyrukBH:
    """(B) Bir boş hücreli: hucre = kapasite + 1; bas == son ise boş"""
    __slots__ = ("veri", "hucre", "bas", "son")


ekle_sayisi = cikar_sayisi = sarma_sayisi = 0


def kuyruk_olustur(kapasite):
    q = Kuyruk()
    q.veri = [0] * kapasite
    q.kapasite = kapasite
    q.bas = q.son = q.sayac = 0
    q.maskeli = (kapasite & (kapasite - 1)) == 0
    return q


def kuyruk_bos_mu(q):
    return q.sayac == 0


def kuyruk_dolu_mu(q):
    return q.sayac == q.kapasite


def ilerle(q, i):
    """Sonraki indis: son hücreden sonra 0'a sarar"""
    global sarma_sayisi
    if i + 1 == q.kapasite:
        sarma_sayisi += 1
    if q.maskeli:
        return (i + 1) & (q.kapasite - 1)
    return (i + 1) % q.kapasite


def kuyruk_ekle(q, x):
    """Dolu kuyrukta False döner (taşma politikası: reddet)"""
    global ekle_sayisi
    if kuyruk_dolu_mu(q):
        return False
    q.veri[q.son] = x
    q.son = ilerle(q, q.son)
    q.sayac += 1
    ekle_sayisi += 1
    return True


def kuyruk_cikar(q):
    """Boş kuyrukta (False, -1); değilse (True, en eski eleman)"""
    global cikar_sayisi
    if kuyruk_bos_mu(q):
        return False, -1
    x = q.veri[q.bas]
    q.bas = ilerle(q, q.bas)
    q.sayac -= 1
    cikar_sayisi += 1
    return True, x


# ---- (B) bir boş hücre: sayaç yok; dolu iken bir hücre kullanılmaz ----
def bh_olustur(kapasite):
    q = KuyrukBH()
    q.veri = [0] * (kapasite + 1)
    q.hucre = kapasite + 1
    q.bas = q.son = 0
    return q


def bh_bos_mu(q):
    return q.bas == q.son


def bh_dolu_mu(q):
    return (q.son + 1) % q.hucre == q.bas


def bh_boyut(q):
    return (q.son - q.bas + q.hucre) % q.hucre


def bh_ekle(q, x):
    if bh_dolu_mu(q):
        return False
    q.veri[q.son] = x
    q.son = (q.son + 1) % q.hucre
    return True


def bh_cikar(q):
    if bh_bos_mu(q):
        return False, -1
    x = q.veri[q.bas]
    q.bas = (q.bas + 1) % q.hucre
    return True, x


def dizi_metni(veri, hucre, bas, boyut):
    """Fiziksel dizi: dolu hücre değeriyle, boş hücre '.' ile"""
    return "[" + " ".join(str(veri[i]) if (i - bas + hucre) % hucre < boyut
                          else "." for i in range(hucre)) + "]"


def satir_yaz(bas, son, boyut, dizi, islem):
    print(f"    {bas:3d} {son:3d} {boyut:5d}   {dizi:<16} {islem}")


def izle_sayacli():
    adim = [10, 20, 30, 40, 50, 0, 0, 50, 60, 70, 0, 0, 0, 0, 0]
    q = kuyruk_olustur(4)
    print("  (A) sayaçlı, kapasite 4 (2'nin kuvveti: & 3 ile ilerler)")
    print("    bas son sayaç   fiziksel dizi    işlem")
    satir_yaz(q.bas, q.son, q.sayac, dizi_metni(q.veri, 4, q.bas, q.sayac),
              "(başlangıç: bas == son, boş)")
    for a in adim:
        sarma0 = sarma_sayisi
        if a > 0:
            tamam = kuyruk_ekle(q, a)
            islem = f"ekle {a}" + ("" if tamam else " -> dolu, reddedildi")
        else:
            tamam, x = kuyruk_cikar(q)
            islem = f"çıkar -> {x}" if tamam else "çıkar -> boş, reddedildi"
        if sarma_sayisi > sarma0:
            islem += "  (sarma)"
        if q.bas == q.son:
            islem += ("  [bas == son, sayaç 0: boş]" if q.sayac == 0
                      else "  [bas == son, sayaç 4: dolu]")
        satir_yaz(q.bas, q.son, q.sayac,
                  dizi_metni(q.veri, 4, q.bas, q.sayac), islem)


def izle_bos_hucreli():
    adim = [10, 20, 30, 40, 50, 0, 0, 50, 60, 0, 0, 0, 0, 0]
    q = bh_olustur(4)
    print("  (B) bir boş hücreli, kapasite 4 (5 hücre, % 5 ile ilerler)")
    print("    bas son boyut   fiziksel dizi    işlem")
    for a in adim:
        if a > 0:
            tamam = bh_ekle(q, a)
            islem = f"ekle {a}" + ("" if tamam else " -> dolu, reddedildi")
        else:
            tamam, x = bh_cikar(q)
            islem = f"çıkar -> {x}" if tamam else "çıkar -> boş, reddedildi"
        if bh_dolu_mu(q):
            islem += "  [(son + 1) % 5 == bas: dolu]"
        satir_yaz(q.bas, q.son, bh_boyut(q),
                  dizi_metni(q.veri, 5, q.bas, bh_boyut(q)), islem)


def rastgele_sinama(islem, kapasite):
    """Kâhin: collections.deque (kapasite sınırı elle uygulanır)"""
    q = kuyruk_olustur(kapasite)
    b = bh_olustur(kapasite)
    kahin = deque()
    uyusmazlik = dolu = bos = 0
    sarma0 = sarma_sayisi
    rastgele_tohum(42)
    for _ in range(islem):
        if rastgele_aralik(0, 99) < 55:
            v = rastgele_aralik(0, 999)
            ra, rb = kuyruk_ekle(q, v), bh_ekle(b, v)
            rk = len(kahin) < kapasite
            if rk:
                kahin.append(v)
            dolu += 0 if rk else 1
            uyusmazlik += 1 if (ra != rk or rb != rk) else 0
        else:
            ra, xa = kuyruk_cikar(q)
            rb, xb = bh_cikar(b)
            rk = len(kahin) > 0
            xk = kahin.popleft() if rk else -1
            bos += 0 if rk else 1
            uyusmazlik += 1 if (ra != rk or rb != rk or xa != xk
                                or xb != xk) else 0
    print(f"  kapasite {kapasite:4d} (" + ("maske" if q.maskeli else "mod  ")
          + f"): dolu reddi {dolu:5d}, boş reddi {bos:5d}, "
          f"sarma {sarma_sayisi - sarma0:6d}, uyuşmazlık {uyusmazlik}")


def main():
    print("1) Adım adım: bas, son ve dolu/boş ayrımı")
    izle_sayacli()
    print()
    izle_bos_hucreli()

    print("\n2) Rastgele 100000 işlem (%55 ekle, tohum 42): (A) ve (B) "
          "kâhinle")
    for kapasite in (4, 6, 8, 1024):
        rastgele_sinama(100000, kapasite)
    print(f"  toplam (A): ekle = {ekle_sayisi}, çıkar = {cikar_sayisi}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int> (kap
# uyarlayıcısı; varsayılan alttaki kap std::deque, kapasite sınırı yok);
# Python — collections.deque (maxlen verilirse dolunca EN ESKİ eleman
# sessizce atılır: taşma politikası "üzerine yaz").

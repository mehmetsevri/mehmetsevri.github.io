"""H09_09_liste_kuyruk.py — AP-2 Hafta 9 · Örnek 9 (★)
Amaç    : Bağlı liste tabanlı kuyruk: baş (çıkarma) ve son (ekleme)
          başvurularıyla iki işlem de O(1); son düğüm çıkarılınca son da
          None yapılır. Uygulamalar: katman katman işleme (BFS'ye köprü)
          ve sıcak patates (Josephus) sırası
Çalıştır: python3 H09_09_liste_kuyruk.py
Eşleri  : c/H09_09_liste_kuyruk.c · cpp/H09_09_liste_kuyruk.cpp
Çıktı   : üç dilde aynı (=)
"""
from collections import deque  # yalnızca kâhin olarak

from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Dugum:
    __slots__ = ("deger", "sonraki")  # sonraki: baştan sona doğru

    def __init__(self, deger):
        self.deger = deger
        self.sonraki = None


class Kuyruk:
    """bas en eski, son en yeni düğüm; boşken ikisi de None"""
    __slots__ = ("bas", "son", "boyut")


ekle_sayisi = cikar_sayisi = 0
ayrilan_dugum = serbest_dugum = 0


def kuyruk_olustur():
    q = Kuyruk()
    q.bas = q.son = None
    q.boyut = 0
    return q


def kuyruk_yok_et(q):
    """Kalan düğümler bırakılır (C'deki free döngüsünün karşılığı)"""
    global serbest_dugum
    while q.bas is not None:
        d = q.bas
        q.bas = d.sonraki
        serbest_dugum += 1
    q.son = None
    q.boyut = 0


def kuyruk_bos_mu(q):
    return q.bas is None


def kuyruk_ekle(q, x):
    """Sona ekler; bellek yetmezse MemoryError oluşur"""
    global ayrilan_dugum, ekle_sayisi
    d = Dugum(x)
    ayrilan_dugum += 1
    if q.son is None:
        q.bas = d           # boş kuyruk: ilk düğüm hem baş hem son
    else:
        q.son.sonraki = d   # eski sonun arkasına bağla
    q.son = d
    q.boyut += 1
    ekle_sayisi += 1
    return True


def kuyruk_cikar(q):
    """Baştan çıkarır; boş kuyrukta (False, -1)"""
    global serbest_dugum, cikar_sayisi
    if kuyruk_bos_mu(q):
        return False, -1
    d = q.bas
    x = d.deger
    q.bas = d.sonraki
    if q.bas is None:
        q.son = None  # boşaldı: son da None olmalı
    serbest_dugum += 1
    q.boyut -= 1
    cikar_sayisi += 1
    return True, x


def kuyruk_yaz(q):
    parcalar = []
    d = q.bas
    while d is not None:
        parcalar.append(str(d.deger))
        d = d.sonraki
    s = "baş [" + " ".join(parcalar) + "] son"
    if q.son is None:
        return s + "   (bas = son = NULL)"
    return s + f"   (bas -> {q.bas.deger}, son -> {q.son.deger})"


def katman_katman(n):
    """Tam ikili ağacın düzey sırası: x'in çocukları 2x ve 2x + 1"""
    q = kuyruk_olustur()
    kuyruk_ekle(q, 1)
    duzey = 0
    while not kuyruk_bos_mu(q):
        katman = q.boyut  # bu katmanda işlenecek eleman sayısı
        satir = f"  düzey {duzey}:"
        for _ in range(katman):
            x = kuyruk_cikar(q)[1]
            satir += f" {x}"
            if 2 * x <= n:
                kuyruk_ekle(q, 2 * x)
            if 2 * x + 1 <= n:
                kuyruk_ekle(q, 2 * x + 1)
        print(satir + f"   (sırada bekleyen: {q.boyut})")
        duzey += 1
    kuyruk_yok_et(q)


def sicak_patates(n, k):
    """n kişi dairede; her k'ıncı kişi çıkar (kuyruğu döndürerek)"""
    q = kuyruk_olustur()
    for i in range(1, n + 1):
        kuyruk_ekle(q, i)
    satir = f"  n = {n}, k = {k}: çıkış sırası"
    while q.boyut > 1:
        for _ in range(1, k):
            kuyruk_ekle(q, kuyruk_cikar(q)[1])  # baştakini sona aktar
        satir += f" {kuyruk_cikar(q)[1]}"
    print(satir + f"; kalan {kuyruk_cikar(q)[1]}")
    kuyruk_yok_et(q)


def rastgele_sinama(islem):
    """Kâhin: collections.deque (yalnızca karşılaştırma için)"""
    q = kuyruk_olustur()
    kahin = deque()
    uyusmazlik = bos = en_buyuk = 0
    rastgele_tohum(42)
    for _ in range(islem):
        if rastgele_aralik(0, 99) < 52:
            v = rastgele_aralik(0, 999)
            kuyruk_ekle(q, v)
            kahin.append(v)
        else:
            tamam, x = kuyruk_cikar(q)
            rk = len(kahin) > 0
            xk = kahin.popleft() if rk else -1
            bos += 0 if rk else 1
            uyusmazlik += 1 if (tamam != rk or x != xk) else 0
        uyusmazlik += 1 if (q.boyut != len(kahin) or
                            (q.boyut == 0) != (q.son is None)) else 0
        if q.boyut > en_buyuk:
            en_buyuk = q.boyut
    print(f"  {islem} işlem: boş reddi {bos}, en büyük boyut {en_buyuk}, "
          f"son boyut {q.boyut}, kâhinle uyuşmazlık {uyusmazlik}")
    kuyruk_yok_et(q)


def main():
    q = kuyruk_olustur()
    print("1) Ekle 10, 20, 30; çıkar; ekle 40; tümünü çıkar; yeniden ekle")
    print("  " + kuyruk_yaz(q))
    for k in range(1, 4):
        kuyruk_ekle(q, 10 * k)
        print(f"  ekle {10 * k}   -> " + kuyruk_yaz(q))
    x = kuyruk_cikar(q)[1]
    print(f"  çıkar {x}  -> " + kuyruk_yaz(q))
    kuyruk_ekle(q, 40)
    print("  ekle 40   -> " + kuyruk_yaz(q))
    tamam, x = kuyruk_cikar(q)
    while tamam:
        print(f"  çıkar {x}  -> " + kuyruk_yaz(q))
        tamam, x = kuyruk_cikar(q)
    print("  çıkar     -> "
          + ("?" if kuyruk_cikar(q)[0] else "HAYIR (boş kuyruk)"))
    kuyruk_ekle(q, 50)
    print("  ekle 50   -> " + kuyruk_yaz(q))
    kuyruk_yok_et(q)

    print("\n2) Katman katman işleme: 1'den başla, x'in ardılları 2x ve "
          "2x + 1 (<= 15)")
    katman_katman(15)

    print("\n3) Sıcak patates (Josephus): kuyruğu döndürerek eleme")
    sicak_patates(7, 3)
    sicak_patates(10, 2)

    print("\n4) Rastgele 100000 işlem (%52 ekle, tohum 42) ve kâhin")
    rastgele_sinama(100000)
    print(f"  toplam: ekle = {ekle_sayisi}, çıkar = {cikar_sayisi}; "
          f"düğüm ayrılan = {ayrilan_dugum}, serbest = {serbest_dugum}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int,
# std::list<int>> ya da varsayılan std::queue<int> (alttaki kap std::deque);
# Python — collections.deque (append/popleft) ya da iş parçacığı güvenli
# queue.Queue.

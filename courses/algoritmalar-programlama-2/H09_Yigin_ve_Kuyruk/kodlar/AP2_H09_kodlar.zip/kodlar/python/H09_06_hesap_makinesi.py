"""H09_06_hesap_makinesi.py — AP-2 Hafta 9 · Örnek 6 (★★★)
Amaç    : Basit hesap makinesi: araek ifade → Shunting-yard (Örnek 5) →
          sonek değerlendirme (Örnek 4); + - * / ^, parantez, tekli eksi;
          hata iletileri ve çıkış kodları üç dilde aynı; rastgele ifade
          ağaçlarıyla kâhinli sınama
Çalıştır: python3 H09_06_hesap_makinesi.py \\
          < ../girdiler/H09_06_hesap_makinesi.txt
          python3 H09_06_hesap_makinesi.py "3 + 4 * 2"     (tek ifade)
          çıkış kodu: 0 geçerli · 1 hatalı ifade · 2 hatalı kullanım
Eşleri  : c/H09_06_hesap_makinesi.c · cpp/H09_06_hesap_makinesi.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum

SAYI, ISLEC, SOL_PAR, SAG_PAR = range(4)
(HATA_YOK, GECERSIZ_KARAKTER, ISLENEN_BEKLENIYOR, ISLEC_BEKLENIYOR,
 ESLESMEYEN_KAPANIS, ACIK_PARANTEZ, BOS_IFADE, SIFIRA_BOLME, TASMA,
 NEGATIF_US) = range(10)

HATA_ILETISI = ("yok", "geçersiz karakter", "işlenen bekleniyordu",
                "işleç bekleniyordu", "eşleşmeyen ')'", "kapanmamış '('",
                "boş ifade", "sıfıra bölme", "taşma (int aralığı dışında)",
                "negatif üs")

INT_MIN = -2 ** 31        # C'deki 32 bitlik int sınırları
INT_MAX = 2 ** 31 - 1


class Belirtec:
    __slots__ = ("tur", "sutun", "islec", "deger")

    def __init__(self, tur, sutun, islec, deger):
        self.tur = tur
        self.sutun = sutun  # 1 tabanlı konum
        self.islec = islec  # + - * / ^ ve tekli eksi için ~
        self.deger = deger  # SAYI için


class Yigin:
    __slots__ = ("veri", "kapasite", "boyut")


it_sayisi = cikar_sayisi = 0


def yigin_olustur(kapasite):
    y = Yigin()
    y.veri = [0] * kapasite
    y.kapasite = kapasite
    y.boyut = 0
    return y


def yigin_it(y, x):
    global it_sayisi
    if y.boyut == y.kapasite:
        return False
    y.veri[y.boyut] = x
    y.boyut += 1
    it_sayisi += 1
    return True


def yigin_cikar(y):
    global cikar_sayisi
    if y.boyut == 0:
        return False, 0
    y.boyut -= 1
    cikar_sayisi += 1
    return True, y.veri[y.boyut]


def yigin_tepe(y):
    if y.boyut == 0:
        return False, 0
    return True, y.veri[y.boyut - 1]


# ---- Aritmetik (Örnek 4): int aralığı denetimli ----
def us_al(a, b):
    if a == 0 or a == 1:
        return HATA_YOK, (1 if b == 0 else a)
    if a == -1:
        return HATA_YOK, (1 if b % 2 == 0 else -1)
    r = 1
    for _ in range(b):
        r *= a
        if r < INT_MIN or r > INT_MAX:
            return TASMA, 0
    return HATA_YOK, r


def kesik_bol(a, b):
    """C'deki gibi sıfıra doğru kesen bölme (// aşağı yuvarlar)"""
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q


def islem_uygula(op, a, b):
    if op == "+":
        r = a + b
    elif op == "-":
        r = a - b
    elif op == "*":
        r = a * b
    elif op == "/":
        if b == 0:
            return SIFIRA_BOLME, 0
        r = kesik_bol(a, b)
    else:
        if b < 0:
            return NEGATIF_US, 0
        return us_al(a, b)
    if r < INT_MIN or r > INT_MAX:
        return TASMA, 0
    return HATA_YOK, r


# ---- Belirteçleme ve Shunting-yard (Örnek 5) ----
def oncelik(op):
    if op in "+-":
        return 1
    if op in "*/":
        return 2
    return 3 if op == "~" else 4


def sag_birlesmeli(op):
    return op == "^" or op == "~"


def once_cikar_mi(ust, gelen):
    return (oncelik(ust) > oncelik(gelen) or
            (oncelik(ust) == oncelik(gelen) and not sag_birlesmeli(gelen)))


def belirtecle(s):
    """(hata, belirteçler, sütun) döner"""
    n = len(s)
    b = []
    islenen_bekleniyor = True
    i = 0
    while i < n:
        c = s[i]
        if c in " \t":
            i += 1
            continue
        t = Belirtec(SAYI, i + 1, c, 0)
        sutun = i + 1
        if "0" <= c <= "9":
            v = 0
            while i < n and "0" <= s[i] <= "9":
                v = 10 * v + (ord(s[i]) - ord("0"))
                i += 1
                if v > INT_MAX:
                    return TASMA, b, sutun
            t.deger = v
        elif c in "()":
            t.tur = SOL_PAR if c == "(" else SAG_PAR
            i += 1
        elif c in "+-*/^":
            t.tur = ISLEC
            if c == "-" and islenen_bekleniyor:
                t.islec = "~"
            i += 1
        else:
            return GECERSIZ_KARAKTER, b, sutun
        if islenen_bekleniyor:
            if t.tur == SAG_PAR or (t.tur == ISLEC and t.islec != "~"):
                return ISLENEN_BEKLENIYOR, b, sutun
            islenen_bekleniyor = t.tur in (SOL_PAR, ISLEC)
        else:
            if t.tur in (SAYI, SOL_PAR):
                return ISLEC_BEKLENIYOR, b, sutun
            islenen_bekleniyor = t.tur == ISLEC
        b.append(t)
    if islenen_bekleniyor:
        return (BOS_IFADE if not b else ISLENEN_BEKLENIYOR), b, n + 1
    return HATA_YOK, b, n + 1


def sonege_cevir(b):
    """(hata, çıktı indisleri, sütun) döner"""
    m = len(b)
    y = yigin_olustur(m + 1)
    hata, sutun = HATA_YOK, 0
    cikti = []
    i = 0
    while i < m and hata == HATA_YOK:
        if b[i].tur == SAYI:
            cikti.append(i)
        elif b[i].tur == SOL_PAR or b[i].islec == "~":
            yigin_it(y, i)
        elif b[i].tur == SAG_PAR:
            tamam, j = yigin_tepe(y)
            while tamam and b[j].tur != SOL_PAR:
                yigin_cikar(y)
                cikti.append(j)
                tamam, j = yigin_tepe(y)
            if not yigin_cikar(y)[0]:
                hata, sutun = ESLESMEYEN_KAPANIS, b[i].sutun
        else:
            tamam, j = yigin_tepe(y)
            while (tamam and b[j].tur == ISLEC and
                   once_cikar_mi(b[j].islec, b[i].islec)):
                yigin_cikar(y)
                cikti.append(j)
                tamam, j = yigin_tepe(y)
            yigin_it(y, i)
        i += 1
    while hata == HATA_YOK:
        tamam, j = yigin_cikar(y)
        if not tamam:
            break
        if b[j].tur == SOL_PAR:
            hata, sutun = ACIK_PARANTEZ, b[j].sutun
        else:
            cikti.append(j)
    return hata, cikti, sutun


# ---- Sonek değerlendirme (Örnek 4), belirteç dizisi üzerinde ----
def sonek_hesapla(b, cikti, iz):
    """(hata, sonuç, sütun) döner"""
    y = yigin_olustur(len(cikti) + 1)
    hata, sutun = HATA_YOK, 0
    i = 0
    while i < len(cikti) and hata == HATA_YOK:
        t = b[cikti[i]]
        if t.tur == SAYI:
            yigin_it(y, t.deger)
        elif t.islec == "~":
            a = yigin_cikar(y)[1]  # sözdizimi denetimi işleneni garantiler
            if a == INT_MIN:
                hata = TASMA
            else:
                yigin_it(y, -a)
        else:
            bb = yigin_cikar(y)[1]  # önce b (tepe), sonra a
            a = yigin_cikar(y)[1]
            hata, r = islem_uygula(t.islec, a, bb)
            if hata == HATA_YOK:
                yigin_it(y, r)
        if hata != HATA_YOK:
            sutun = t.sutun
        if iz:
            bt = str(t.deger) if t.tur == SAYI else t.islec
            print(f"    {bt:<4} ->"
                  + "".join(f" {y.veri[q]}" for q in range(y.boyut)))
        i += 1
    return hata, yigin_tepe(y)[1], sutun


def hesapla(s, iz):
    """Bir ifadeyi hesaplar: (hata, sonuç, sütun, sonek metni)"""
    hata, b, sutun = belirtecle(s)
    if hata == HATA_YOK:
        hata, cikti, sutun = sonege_cevir(b)
    if hata != HATA_YOK:
        return hata, 0, sutun, ""
    sonek = " ".join(str(b[j].deger) if b[j].tur == SAYI else b[j].islec
                     for j in cikti)
    hata, sonuc, sutun = sonek_hesapla(b, cikti, iz)
    return hata, sonuc, sutun, sonek


def satir_isle(s):
    hata, sonuc, sutun, sonek = hesapla(s, False)
    if hata == HATA_YOK:
        print(f"  {s:<32} = {sonuc}   (sonek: {sonek})")
    else:
        print(f"  {s:<32} -> HATA sütun {sutun}: {HATA_ILETISI[hata]}")
    return hata == HATA_YOK


# ---- Kâhin: rastgele ifade ağacı; değer üretilirken hesaplanır ----
def rastgele_ifade(derinlik):
    """(metin, öncelik, değer, hata) döner"""
    r = 0 if derinlik == 0 else rastgele_aralik(0, 4)
    if r == 0:
        deger = rastgele_aralik(-9, 9)
        return str(deger), 9, deger, HATA_YOK  # yaprak: parantez gerekmez
    op = "+-*/"[r - 1]
    sol, os, a, ha = rastgele_ifade(derinlik - 1)
    sag, og, b, hb = rastgele_ifade(derinlik - 1)
    p = oncelik(op)
    s = ((f"({sol})" if os < p else sol) + f" {op} "
         + (f"({sag})" if og <= p else sag))
    hata = ha if ha != HATA_YOK else hb
    deger = 0
    if hata == HATA_YOK:
        hata, deger = islem_uygula(op, a, b)
    return s, p, deger, hata


def kahinli_sinama(adet):
    uyusmazlik = hatali = 0
    rastgele_tohum(42)
    for t in range(adet):
        s, _, beklenen, beklenen_hata = rastgele_ifade(3)
        hata, sonuc, _, _ = hesapla(s, False)
        if hata != beklenen_hata or (hata == HATA_YOK and sonuc != beklenen):
            uyusmazlik += 1
        hatali += 1 if hata == SIFIRA_BOLME else 0
        if t < 4:
            if hata == HATA_YOK:
                print(f"  {s:<40} -> {sonuc} (kâhin {beklenen})")
            else:
                print(f"  {s:<40} -> HATA: {HATA_ILETISI[hata]} "
                      f"(kâhin: {HATA_ILETISI[beklenen_hata]})")
    print(f"  {adet} ifade: sıfıra bölmeli {hatali}, "
          f"kâhinle uyuşmazlık {uyusmazlik}")


def main():
    if len(sys.argv) > 2:
        print('kullanım: H09_06_hesap_makinesi ["ifade"]  '
              "(ifade yoksa stdin)", file=sys.stderr)
        return 2
    if len(sys.argv) == 2:
        return 0 if satir_isle(sys.argv[1]) else 1
    print("1) 3 + 4 * 2: önce sonek gösterimine, sonra yığınla hesap")
    _, sonuc, _, sonek = hesapla("3 + 4 * 2", True)
    print(f"  sonek: {sonek}  ->  sonuç {sonuc}")

    print("\n2) Rastgele ifade ağaçları (derinlik <= 3, tohum 42) ve kâhin")
    kahinli_sinama(2000)

    print("\n3) Girdi dosyasındaki ifadeler")
    satirlar = sys.stdin.buffer.read().decode("utf-8").split("\n")
    if satirlar and satirlar[-1] == "":
        satirlar.pop()  # dosya sonundaki satır sonu (C'deki fgets gibi)
    gecerli = 0
    for satir in satirlar:
        gecerli += 1 if satir_isle(satir) else 0
    toplam = len(satirlar)
    print(f"  toplam {toplam} ifade: geçerli {gecerli}, hatalı "
          f"{toplam - gecerli} (yığın işlemleri: it {it_sayisi}, "
          f"çıkar {cikar_sayisi})")
    return 0 if gecerli == toplam else 1


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok; Python — eval()
# (ifadeyi Python kurallarıyla hesaplar: / gerçek bölme, // aşağı yuvarlar,
# ^ XOR'dur — bu yüzden kâhin olarak bile kullanılmadı; güvensiz girdide
# eval kullanılmaz).

"""H09_02_liste_yigin.py — AP-2 Hafta 9 · Örnek 2 (★)
Amaç    : Bağlı liste tabanlı yığın (sınırsız): Örnek 1 ile AYNI arayüz,
          farklı gerçekleştirim; tepe = listenin başı, it/çıkar O(1)
Çalıştır: python3 H09_02_liste_yigin.py
Eşleri  : c/H09_02_liste_yigin.c · cpp/H09_02_liste_yigin.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Dugum:
    __slots__ = ("deger", "sonraki")  # sonraki: tepeden tabana doğru

    def __init__(self, deger, sonraki):
        self.deger = deger
        self.sonraki = sonraki


class Yigin:
    """tepe listenin ilk düğümü; boş yığında tepe is None"""
    __slots__ = ("tepe", "boyut")


it_sayisi = 0
cikar_sayisi = 0
en_buyuk_derinlik = 0
ayrilan_dugum = 0
serbest_dugum = 0


def yigin_olustur():
    y = Yigin()
    y.tepe = None
    y.boyut = 0
    return y


def yigin_yok_et(y):
    """C'deki free döngüsünün karşılığı: başvurular bırakılır (sayaçlı)"""
    global serbest_dugum
    d = y.tepe
    while d is not None:
        sonraki = d.sonraki
        d.sonraki = None
        serbest_dugum += 1
        d = sonraki
    y.tepe = None
    y.boyut = 0


def yigin_bos_mu(y):
    return y.tepe is None


def yigin_it(y, x):
    """Kapasite sınırı yok: bellek yetmezse MemoryError oluşur"""
    global it_sayisi, en_buyuk_derinlik, ayrilan_dugum
    d = Dugum(x, y.tepe)  # yeni düğüm eski tepenin önüne
    ayrilan_dugum += 1
    y.tepe = d
    y.boyut += 1
    it_sayisi += 1
    if y.boyut > en_buyuk_derinlik:
        en_buyuk_derinlik = y.boyut
    return True


def yigin_cikar(y):
    """Alt taşma: yığın boşsa (False, 0); değilse (True, tepe)"""
    global serbest_dugum, cikar_sayisi
    if yigin_bos_mu(y):
        return False, 0
    d = y.tepe
    x = d.deger
    y.tepe = d.sonraki
    serbest_dugum += 1
    y.boyut -= 1
    cikar_sayisi += 1
    return True, x


def yigin_tepe(y):
    """Tepedeki elemanı çıkarmadan okur"""
    if yigin_bos_mu(y):
        return False, 0
    return True, y.tepe.deger


def tabandan_yaz(d):
    """Tabandan tepeye yazmak için liste ters sırada dolaşılır"""
    if d is None:
        return ""
    return tabandan_yaz(d.sonraki) + \
        (" " if d.sonraki is not None else "") + str(d.deger)


def yigin_yaz(y):
    return "taban [" + tabandan_yaz(y.tepe) + "] tepe"


def rastgele_sinama(islem):
    """Kâhin: Python listesi (append/pop; yalnızca karşılaştırma için)"""
    y = yigin_olustur()
    ayna = []
    uyusmazlik = alt_tasma = 0
    it0, cikar0 = it_sayisi, cikar_sayisi
    rastgele_tohum(42)
    for _ in range(islem):
        if rastgele_aralik(0, 1) == 0:
            v = rastgele_aralik(0, 999)
            yigin_it(y, v)
            ayna.append(v)
        else:
            tamam, x = yigin_cikar(y)
            if tamam:
                if not ayna or ayna.pop() != x:
                    uyusmazlik += 1
            else:
                alt_tasma += 1
                uyusmazlik += 1 if ayna else 0
    print(f"  {islem} işlem: başarılı = "
          f"{(it_sayisi - it0) + (cikar_sayisi - cikar0)}, "
          f"alt taşma = {alt_tasma}, son boyut = {y.boyut}")
    print(f"  kâhinle uyuşmazlık = {uyusmazlik}")
    yigin_yok_et(y)


def main():
    y = yigin_olustur()
    print("1) Liste tabanlı yığına 10, 20, 30, 40, 50 itilir "
          "(kapasite yok)")
    for k in range(1, 6):
        tamam = yigin_it(y, 10 * k)
        print(f"  it {10 * k} -> " + ("evet" if tamam else "HAYIR")
              + "  " + yigin_yaz(y) + f"  boyut = {y.boyut}")

    print("\n2) Tepeye bakma ve çıkarma: Örnek 1 ile aynı sözleşme")
    tamam, x = yigin_tepe(y)
    if tamam:
        print(f"  tepe -> {x} (çıkarılmadı)")
    for _ in range(6):
        tamam, x = yigin_cikar(y)
        if tamam:
            print(f"  çıkar -> {x}  " + yigin_yaz(y))
        else:
            print("  çıkar -> HAYIR (alt taşma: yığın boş)  " + yigin_yaz(y))
    print(f"  sayaçlar: it = {it_sayisi}, çıkar = {cikar_sayisi}, "
          f"en büyük derinlik = {en_buyuk_derinlik}")

    print("\n3) Sınırsızlık ve bellek: 100000 it, ardından yok et")
    for k in range(100000):
        yigin_it(y, k)
    x = yigin_tepe(y)[1]
    print(f"  boyut = {y.boyut}, tepe = {x}, ayrılan düğüm = {ayrilan_dugum}")
    yigin_yok_et(y)
    print("  yok et sonrası: boş mu? "
          + ("evet" if yigin_bos_mu(y) else "HAYIR")
          + f"; serbest bırakılan = {serbest_dugum}; "
          f"fark = {ayrilan_dugum - serbest_dugum}")

    print("\n4) Rastgele it/çıkar dizisi (tohum 42) ve kâhin")
    rastgele_sinama(100000)
    print(f"  toplam: ayrılan = {ayrilan_dugum}, serbest = {serbest_dugum}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int,
# std::list<int>> (kap uyarlayıcısı, alttaki kap değiştirilebilir);
# Python — list (append/pop) ya da collections.deque.

"""H09_10_gise_simulasyonu.py — AP-2 Hafta 9 · Örnek 10 (★★)
Amaç    : Kayıt gişesi simülasyonu: tek FIFO kuyruk (dairesel tampon,
          Örnek 8) ve k gişe; zaman tamsayı saniye; her saniye bir öğrenci
          p = gelis_milyonda / 10^6 olasılıkla gelir (ortak LCG); hizmet
          süresi [60, 180] s'de düzgün (ortalama 120 s). Ortalama ve en
          uzun bekleme, kuyruk uzunluğu, gişe doluluğu; yük oranı ρ
Çalıştır: python3 H09_10_gise_simulasyonu.py
Eşleri  : c/H09_10_gise_simulasyonu.c · cpp/H09_10_gise_simulasyonu.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

HIZMET_EN_AZ = 60
HIZMET_EN_COK = 180  # ortalama hizmet süresi E[S] = 120 s


class Kuyruk:
    """Örnek 8'in sayaçlı dairesel tamponu (geliş anları)"""
    __slots__ = ("veri", "kapasite", "bas", "son", "sayac")


class Sonuc:
    __slots__ = ("gelen", "reddedilen", "hizmet_alan", "toplam_bekleme",
                 "mesgul", "toplam_kuyruk", "en_uzun_bekleme",
                 "en_uzun_kuyruk", "kuyrukta_kalan")

    def __init__(self):
        self.gelen = self.reddedilen = self.hizmet_alan = 0
        self.toplam_bekleme = self.mesgul = 0
        self.toplam_kuyruk = 0  # her saniyenin kuyruk uzunluğu toplamı
        self.en_uzun_bekleme = self.en_uzun_kuyruk = 0
        self.kuyrukta_kalan = 0


def kuyruk_olustur(kapasite):
    q = Kuyruk()
    q.veri = [0] * kapasite
    q.kapasite = kapasite
    q.bas = q.son = q.sayac = 0
    return q


def kuyruk_ekle(q, x):
    if q.sayac == q.kapasite:
        return False  # taşma politikası: reddet
    q.veri[q.son] = x
    q.son = (q.son + 1) % q.kapasite
    q.sayac += 1
    return True


def kuyruk_cikar(q):
    if q.sayac == 0:
        return False, 0
    x = q.veri[q.bas]
    q.bas = (q.bas + 1) % q.kapasite
    q.sayac -= 1
    return True, x


def gise_benzet(k, gelis_milyonda, sure, kapasite, olay_siniri):
    """k gişe, sure saniye; ilk olay_siniri olay yazdırılır"""
    s = Sonuc()
    q = kuyruk_olustur(kapasite)
    kalan = [0] * k  # gişedeki işin kalan süresi (0: boş)
    olay = 0
    for t in range(sure):
        if rastgele_aralik(0, 999999) < gelis_milyonda:  # 1) geliş
            s.gelen += 1
            tamam = kuyruk_ekle(q, t)
            s.reddedilen += 0 if tamam else 1
            if olay < olay_siniri:
                print(f"  t = {t:4d}  öğrenci {s.gelen} geldi"
                      + ("" if tamam else " (kuyruk dolu: geri döndü)")
                      + f"; kuyruk {q.sayac}")
            olay += 1
        for g in range(k):  # 2) boş gişe sıradakini alır
            if kalan[g] == 0:
                tamam, gelis = kuyruk_cikar(q)
                if tamam:
                    bekleme = t - gelis
                    s.hizmet_alan += 1
                    s.toplam_bekleme += bekleme
                    if bekleme > s.en_uzun_bekleme:
                        s.en_uzun_bekleme = bekleme
                    kalan[g] = rastgele_aralik(HIZMET_EN_AZ, HIZMET_EN_COK)
                    if olay < olay_siniri:
                        print(f"  t = {t:4d}  gişe {g + 1}: öğrenci "
                              f"{s.hizmet_alan} (bekleme {bekleme} s, "
                              f"hizmet {kalan[g]} s); kuyruk {q.sayac}")
                    olay += 1
        for g in range(k):  # 3) saat ilerler
            if kalan[g] > 0:
                kalan[g] -= 1
                s.mesgul += 1
        s.toplam_kuyruk += q.sayac
        if q.sayac > s.en_uzun_kuyruk:
            s.en_uzun_kuyruk = q.sayac
    s.kuyrukta_kalan = q.sayac
    return s


def gelis_hizi(rho_binde, k):
    """Yük oranı ρ = λ E[S] / k; λ = gelis_milyonda / 10^6 (saniyede)"""
    return (rho_binde * k * 1000 + 60) // 120  # yuvarlanmış milyonda


def satir_yaz(k, gelis_milyonda, sure, s):
    rho = gelis_milyonda * 120.0 / (1000000.0 * k)
    ort = s.toplam_bekleme / s.hizmet_alan if s.hizmet_alan > 0 else 0.0
    lq = s.toplam_kuyruk / sure
    little = (s.gelen - s.reddedilen) / sure * ort
    doluluk = 100.0 * s.mesgul / (k * sure)
    print(f"  {k}  {rho:5.2f} {s.gelen:6d} {s.hizmet_alan:6d} "
          f"{s.kuyrukta_kalan:5d} {ort:10.2f} {s.en_uzun_bekleme:7d} "
          f"{lq:9.2f} {little:8.2f} {s.en_uzun_kuyruk:7d} {doluluk:7.1f}")


def tablo_basligi():
    print("  k      ρ  gelen hizmet kalan  ort.bekl. en uzun ort.kuyr."
          "      λ·W en uzun doluluk")
    print("                                      (s)     (s)       (L)"
          " (Little)   kuyr.     (%)")


def main():
    gun = 8 * 3600
    print("1) Olay çizelgesi: k = 2, saniyede p = 0.02 (ρ = 1.20), ilk 16 "
          "olay")
    rastgele_tohum(42)
    gise_benzet(2, 20000, 600, 4096, 16)

    print(f"\n2) Bir kayıt günü (8 saat = {gun} s), saatte ortalama 36 "
          "öğrenci (p = 0.01)")
    tablo_basligi()
    for k in range(1, 5):
        rastgele_tohum(42)
        satir_yaz(k, 10000, gun, gise_benzet(k, 10000, gun, 4096, 0))

    print("\n3) Tek gişe (k = 1), yük oranı ρ 1'e yaklaşırken "
          "(8 saat, tohum 42)")
    tablo_basligi()
    for r in (500, 700, 800, 900, 950):
        p = gelis_hizi(r, 1)
        rastgele_tohum(42)
        satir_yaz(1, p, gun, gise_benzet(1, p, gun, 4096, 0))
    print("  (λ·W ≈ L: Little yasası; uzun benzetim ve k = 1..4 için bkz. "
          "Haftanın Deneyi)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int>; Python —
# collections.deque. Olay kuyruğu (zamana göre sıralı) gereken ayrık olay
# benzetimlerinde öncelik kuyruğu (H7 öbeği) kullanılır.

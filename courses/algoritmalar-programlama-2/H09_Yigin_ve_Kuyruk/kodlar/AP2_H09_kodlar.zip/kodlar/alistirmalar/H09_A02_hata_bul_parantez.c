/* H09_A02_hata_bul_parantez.c — AP-2 Hafta 9 · Alıştırma 9.8 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: parantez_denetle altı satırın bazıları için
 * yanlış sonuç veriyor. Önce çıktıyı tahmin edin, sonra hatalı satırı bulup
 * düzeltin (Örnek 3 ile karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_A02_hata_bul_parantez.c -o H09_A02_hata_bul_parantez
 * Çalıştır: ./H09_A02_hata_bul_parantez
 */
#include <stdbool.h>
#include <stdio.h>

#define MAKS 64

static char acilis_karsiligi(char k)
{
    return k == ')' ? '(' : k == ']' ? '[' : '{';
}

/* s dengeliyse true; yığın en çok MAKS açılış tutar */
static bool parantez_denetle(const char *s)
{
    char yigin[MAKS];
    int boyut = 0;
    for (int i = 0; s[i] != '\0'; i++) {
        char c = s[i];
        if (c == '(' || c == '[' || c == '{') {
            if (boyut == MAKS) {
                return false;
            }
            yigin[boyut++] = c;
        } else if (c == ')' || c == ']' || c == '}') {
            if (boyut == 0 || yigin[--boyut] != acilis_karsiligi(c)) {
                return false;
            }
        }
    }
    return true;
}

int main(void)
{
    const char *satirlar[] = {"(a + b) * [c - {d / e}]", "[(a + b])",
                              "a + b) * c", "((a + b) * c", "{[()()]}",
                              "(()"};
    for (int i = 0; i < 6; i++) {
        printf("%-24s -> %s\n", satirlar[i],
               parantez_denetle(satirlar[i]) ? "dengeli" : "HATA");
    }
    return 0;
}

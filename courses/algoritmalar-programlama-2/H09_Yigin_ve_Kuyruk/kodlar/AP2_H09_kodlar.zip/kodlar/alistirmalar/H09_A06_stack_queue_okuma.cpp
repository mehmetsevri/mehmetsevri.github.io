/* H09_A06_stack_queue_okuma.cpp — AP-2 Hafta 9 · Alıştırma 9.15 (★★)
 * Amaç    : Diller arası okuma: std::stack ve std::queue kap uyarlayıcıları;
 *           programı çalıştırmadan çıktısını tahmin edin
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H09_A06_stack_queue_okuma.cpp -o H09_A06_stack_queue_okuma
 * Çalıştır: ./H09_A06_stack_queue_okuma
 */
#include <iostream>
#include <queue>
#include <stack>
#include <vector>

int main()
{
    std::stack<int, std::vector<int>> s;
    std::queue<int> q;
    for (int i = 1; i <= 4; i++) {
        s.push(i * i);
        q.push(i * i);
    }
    s.pop();
    q.pop();
    std::cout << s.top() << " " << q.front() << " " << q.back() << "\n";
    while (!s.empty()) {
        q.push(s.top());
        s.pop();
    }
    std::cout << q.size() << ":";
    while (!q.empty()) {
        std::cout << " " << q.front();
        q.pop();
    }
    std::cout << "\n" << 7 / -2 << " " << -7 % 2 << "\n";
    return 0;
}

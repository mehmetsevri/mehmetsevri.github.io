/* H09_A04_parsons_sonek.c — AP-2 Hafta 9 · Alıştırma 9.10 (★★) — Parsons
 * Tamamlanacak; bu hâliyle derlenmez: aşağıdaki satırlar tek basamaklı
 * işlenenli sonek ifadeyi (ör. "512+4*+3-") değerlendiren fonksiyonun
 * KARIŞTIRILMIŞ satırlarıdır; iki satır fazladır (kullanılmayacak). Doğru
 * sıraya dizin, girintiyi düzeltin; "512+4*+3-" için 14 döndürmeli.
 */
            int a = yigin[--n];
    return yigin[n];
        if (c >= '0' && c <= '9') {
    int yigin[64], n = 0;
            yigin[n++] = c - '0';
static int sonek(const char *s)
    return yigin[n - 1];
            yigin[++n] = c - '0';
        } else if (c == '+' || c == '-' || c == '*') {
    for (int i = 0; s[i] != '\0'; i++) {
            int b = yigin[--n];
        char c = s[i];
            yigin[n++] = c == '+' ? a + b : c == '-' ? a - b : a * b;
        }
    }
}

/* H09_A03_hata_bul_dairesel.c — AP-2 Hafta 9 · Alıştırma 9.9 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: sayaçlı dairesel kuyruk (kapasite 4)
 * 10, 20, 30, 40 sırasıyla eklenen elemanları aynı sırayla vermeli; vermiyor.
 * Hatalı satırları bulun ve düzeltin (Örnek 8'in yöntem A'sıyla
 * karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_A03_hata_bul_dairesel.c -o H09_A03_hata_bul_dairesel
 * Çalıştır: ./H09_A03_hata_bul_dairesel
 */
#include <stdbool.h>
#include <stdio.h>

#define KAPASITE 4

typedef struct {
    int veri[KAPASITE];
    int bas;    /* ilk (en eski) elemanın indisi */
    int sayac;  /* eleman sayısı */
} Kuyruk;

static bool kuyruk_ekle(Kuyruk *q, int x)
{
    if (q->sayac == KAPASITE) {
        return false;
    }
    q->sayac++;
    q->veri[(q->bas + q->sayac) % KAPASITE] = x;
    return true;
}

static bool kuyruk_cikar(Kuyruk *q, int *x)
{
    if (q->sayac == 0) {
        return false;
    }
    *x = q->veri[q->bas];
    q->bas = (q->bas + 1) % KAPASITE;
    q->sayac--;
    return true;
}

int main(void)
{
    Kuyruk q = {{0}, 0, 0};
    int x = 0;
    for (int k = 1; k <= 4; k++) {
        kuyruk_ekle(&q, 10 * k);
    }
    printf("çıkarılanlar:");
    while (kuyruk_cikar(&q, &x)) {
        printf(" %d", x);
    }
    printf("\n");
    for (int k = 5; k <= 7; k++) {
        kuyruk_ekle(&q, 10 * k);
    }
    kuyruk_cikar(&q, &x);
    printf("50, 60, 70 eklendi; ilk çıkan: %d\n", x);
    return 0;
}

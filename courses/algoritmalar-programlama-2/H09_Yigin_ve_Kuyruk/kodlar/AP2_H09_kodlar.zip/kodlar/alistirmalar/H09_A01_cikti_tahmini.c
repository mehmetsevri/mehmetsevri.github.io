/* H09_A01_cikti_tahmini.c — AP-2 Hafta 9 · Alıştırma 9.1 (★)
 * Amaç    : Sabit kapasiteli yığın ve sayaçlı dairesel kuyruk aynı değerleri
 *           alıyor; programı çalıştırmadan çıktısını tahmin edin (önce
 *           kâğıtta yığını ve kuyruğun hücrelerini çizin)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_A01_cikti_tahmini.c \
 *           -o H09_A01_cikti_tahmini
 * Çalıştır: ./H09_A01_cikti_tahmini
 */
#include <stdio.h>

#define KAP 4

static int yigin[KAP], boyut = 0;            /* tepe: yigin[boyut - 1] */
static int kuyruk[KAP], bas = 0, sayac = 0;  /* sayaçlı dairesel tampon */

static void it(int x)
{
    if (boyut < KAP) {
        yigin[boyut++] = x;
    }
}

static int cikar(void)
{
    return boyut > 0 ? yigin[--boyut] : -1;
}

static void ekle(int x)
{
    if (sayac < KAP) {
        kuyruk[(bas + sayac) % KAP] = x;
        sayac++;
    }
}

static int al(void)
{
    if (sayac == 0) {
        return -1;
    }
    int x = kuyruk[bas];
    bas = (bas + 1) % KAP;
    sayac--;
    return x;
}

int main(void)
{
    for (int i = 1; i <= 5; i++) {
        it(10 * i);
        ekle(10 * i);
    }
    int y = cikar();
    int q = al();
    printf("%d %d\n", y, q);
    it(y + 1);
    ekle(q + 1);
    printf("boyut = %d, bas = %d, sayac = %d\n", boyut, bas, sayac);
    printf("yığın:");
    while (boyut > 0) {
        printf(" %d", cikar());
    }
    printf("\nkuyruk:");
    while (sayac > 0) {
        printf(" %d", al());
    }
    printf("\n");
    return 0;
}

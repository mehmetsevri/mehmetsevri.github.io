"""H09_A05_deque_okuma.py — AP-2 Hafta 9 · Alıştırma 9.14 (★★)
Amaç    : Diller arası okuma: collections.deque (maxlen ile), list.pop ve
          tamsayı bölmesi; programı çalıştırmadan çıktısını tahmin edin
Çalıştır: python3 H09_A05_deque_okuma.py
"""
from collections import deque


def main():
    d = deque(maxlen=3)
    for x in [1, 2, 3, 4, 5]:
        d.append(x)
    print(list(d))
    d.appendleft(0)
    print(list(d), d.pop())
    y = [10, 20, 30, 40]
    print(y.pop(), y.pop(0), y)
    q = deque([10, 20, 30, 40])
    q.rotate(1)
    print(q.popleft(), list(q))
    print(7 // -2, -7 % 2, 7 - 2 * (7 // 2))


if __name__ == "__main__":
    main()

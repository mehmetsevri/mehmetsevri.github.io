/* H09_03_parantez_denetimi.c — AP-2 Hafta 9 · Örnek 3 (★★)
 * Amaç    : ( ) [ ] { } dengesinin yığınla denetimi; ilk hatanın konumu
 *           ve türü: eşleşmeyen kapanış, tür uyuşmazlığı, açık kalan
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_03_parantez_denetimi.c ortak_rastgele.c \
 *           -o H09_03_parantez_denetimi
 * Çalıştır: ./H09_03_parantez_denetimi \
 *           < ../girdiler/H09_03_parantez_denetimi.txt
 * Eşleri  : cpp/H09_03_parantez_denetimi.cpp ·
 *           python/H09_03_parantez_denetimi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

enum { DENGELI, ESLESMEYEN_KAPANIS, TUR_UYUSMAZLIGI, ACIK_KALAN };

typedef struct {
    char tur;   /* '(' '[' '{' */
    int sutun;  /* 1 tabanlı konum */
} Acilis;

typedef struct {
    Acilis *veri;
    int kapasite;
    int boyut;
} Yigin;

typedef struct {
    int durum;
    int sutun;         /* hatanın bulunduğu sütun */
    char bulunan;      /* hatalı kapanış ya da açık kalan açılış */
    char beklenen;     /* tür uyuşmazlığında beklenen kapanış */
    int acilis_sutun;  /* ilgili açılışın sütunu */
    int acik_sayisi;   /* açık kalan parantez sayısı */
} Sonuc;

static long long it_sayisi = 0, cikar_sayisi = 0, islenen = 0;
static int en_buyuk_derinlik = 0;

static void sayaclari_sifirla(void)
{
    it_sayisi = cikar_sayisi = islenen = 0;
    en_buyuk_derinlik = 0;
}

/* Sahiplik: y->veri burada ayrılır; yigin_yok_et ile serbest bırakılır. */
static bool yigin_olustur(Yigin *y, int kapasite)
{
    y->veri = malloc((size_t)kapasite * sizeof *y->veri);
    y->kapasite = (y->veri != NULL) ? kapasite : 0;
    y->boyut = 0;
    return y->veri != NULL;
}

static void yigin_yok_et(Yigin *y)
{
    free(y->veri);
    y->veri = NULL;
    y->kapasite = y->boyut = 0;
}

static bool yigin_it(Yigin *y, Acilis a)
{
    if (y->boyut == y->kapasite) {
        return false;
    }
    y->veri[y->boyut++] = a;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
    return true;
}

static bool yigin_cikar(Yigin *y, Acilis *a)
{
    if (y->boyut == 0) {
        return false;
    }
    *a = y->veri[--y->boyut];
    cikar_sayisi++;
    return true;
}

static char acilis_karsiligi(char kapanis)
{
    if (kapanis == ')') {
        return '(';
    }
    return kapanis == ']' ? '[' : '{';
}

static char kapanis_karsiligi(char acilis)
{
    if (acilis == '(') {
        return ')';
    }
    return acilis == '[' ? ']' : '}';
}

/* s[0..n-1] taranır; ilk hatada durulur (erken çıkış) */
Sonuc parantez_denetle(const char *s, int n, bool iz)
{
    Sonuc r = {DENGELI, 0, 0, 0, 0, 0};
    Yigin y;
    if (!yigin_olustur(&y, n > 0 ? n : 1)) {
        exit(1);
    }
    for (int i = 0; i < n && r.durum == DENGELI; i++) {
        char c = s[i];
        islenen++;
        if (c == '(' || c == '[' || c == '{') {
            yigin_it(&y, (Acilis){c, i + 1});
        } else if (c == ')' || c == ']' || c == '}') {
            Acilis a;
            if (!yigin_cikar(&y, &a)) {
                r = (Sonuc){ESLESMEYEN_KAPANIS, i + 1, c, 0, 0, 0};
            } else if (a.tur != acilis_karsiligi(c)) {
                r = (Sonuc){TUR_UYUSMAZLIGI, i + 1, c,
                            kapanis_karsiligi(a.tur), a.sutun, 0};
            }
        } else {
            continue;  /* parantez olmayan karakterler atlanır */
        }
        if (iz) {
            printf("    sütun %2d '%c' -> yığın: ", i + 1, c);
            for (int k = 0; k < y.boyut; k++) {
                printf("%c", y.veri[k].tur);
            }
            printf("%s\n", y.boyut == 0 ? "(boş)" : "");
        }
    }
    if (r.durum == DENGELI && y.boyut > 0) {
        Acilis a = y.veri[y.boyut - 1];  /* en içteki açık parantez */
        r = (Sonuc){ACIK_KALAN, n + 1, a.tur, 0, a.sutun, y.boyut};
    }
    yigin_yok_et(&y);
    return r;
}

static void sonuc_yaz(Sonuc r)
{
    switch (r.durum) {
    case DENGELI:
        printf("dengeli");
        break;
    case ESLESMEYEN_KAPANIS:
        printf("HATA sütun %d: eşleşmeyen kapanış '%c' (yığın boş)",
               r.sutun, r.bulunan);
        break;
    case TUR_UYUSMAZLIGI:
        printf("HATA sütun %d: tür uyuşmazlığı: '%c' bulundu, '%c' "
               "bekleniyordu (açılış sütun %d)", r.sutun, r.bulunan,
               r.beklenen, r.acilis_sutun);
        break;
    default:
        printf("HATA satır sonu: açık kalan %d parantez; en içteki '%c' "
               "(sütun %d)", r.acik_sayisi, r.bulunan, r.acilis_sutun);
    }
}

/* n uzunluğunda (çift) rastgele dengeli dizgi; üretici de yığın kullanır */
static void rastgele_dengeli(char *s, int n)
{
    Yigin y;
    const char *turler = "([{";
    if (!yigin_olustur(&y, n / 2 + 1)) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        bool ac;
        if (y.boyut == 0) {
            ac = true;
        } else if (y.boyut == n - i) {
            ac = false;
        } else {
            ac = rastgele_aralik(0, 1) == 0;
        }
        if (ac) {
            char t = turler[rastgele_aralik(0, 2)];
            yigin_it(&y, (Acilis){t, i + 1});
            s[i] = t;
        } else {
            Acilis a;
            yigin_cikar(&y, &a);
            s[i] = kapanis_karsiligi(a.tur);
        }
    }
    s[n] = '\0';
    yigin_yok_et(&y);
}

static void buyuk_satir(const char *ad, const char *s, int n)
{
    sayaclari_sifirla();
    Sonuc r = parantez_denetle(s, n, false);
    printf("  %-22s: ", ad);
    sonuc_yaz(r);
    printf("\n  %22s  işlenen karakter = %lld, it = %lld, çıkar = %lld, "
           "en büyük derinlik = %d\n", "", islenen, it_sayisi, cikar_sayisi,
           en_buyuk_derinlik);
}

int main(void)
{
    char satir[512];
    int no = 0, dengeli = 0;
    printf("1) Girdi dosyasındaki satırlar\n");
    while (fgets(satir, sizeof satir, stdin) != NULL) {
        int n = (int)strcspn(satir, "\n");
        satir[n] = '\0';
        no++;
        sayaclari_sifirla();
        Sonuc r = parantez_denetle(satir, n, false);
        printf("  satır %2d: %s\n    -> ", no, satir);
        sonuc_yaz(r);
        printf("; it = %lld, çıkar = %lld, en büyük derinlik = %d\n",
               it_sayisi, cikar_sayisi, en_buyuk_derinlik);
        dengeli += (r.durum == DENGELI);
    }
    printf("  toplam %d satır: dengeli %d, hatalı %d\n", no, dengeli,
           no - dengeli);

    printf("\n2) Yığın izi: her parantezden sonra yığının içeriği "
           "(taban solda)\n");
    const char *izler[] = {"{[()()]}", "[(a + b])", "((a)"};
    for (int k = 0; k < 3; k++) {
        printf("  %s\n", izler[k]);
        Sonuc r = parantez_denetle(izler[k], (int)strlen(izler[k]), true);
        printf("    sonuç: ");
        sonuc_yaz(r);
        printf("\n");
    }

    printf("\n3) Büyük girdi (n = 100000, tohum 42): Θ(n) tarama ve "
           "erken çıkış\n");
    int n = 100000;
    char *s = malloc((size_t)n + 1);
    if (s == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dengeli(s, n);
    buyuk_satir("rastgele dengeli", s, n);
    char son = s[n - 1];
    s[n - 1] = (son == ')') ? ']' : ')';
    buyuk_satir("son karakter bozuk", s, n);
    s[n - 1] = son;
    s[0] = ')';
    buyuk_satir("ilk karakter ')'", s, n);
    free(s);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::stack<char>;
 * Python — list (append/pop). Hazır "parantez denetimi" fonksiyonu yoktur;
 * derleyiciler ve düzenleyiciler bu algoritmayı kendileri gerçekler. */

/* H09_12_yiginli_hizli_siralama.c — AP-2 Hafta 9 · Örnek 12 (★★★)
 * Amaç    : Özyinelemesiz hızlı sıralama: çağrı yığını yerine açık yığın
 *           (lo, hi) aralıkları. BÜYÜK parça yığına itilir, KÜÇÜK parça hemen
 *           işlenir → yığın derinliği <= ⌊log2 n⌋ + 1 (kapasite tam bu kadar
 *           ayrılır). Lomuto bölümleme (H6 Örnek 4); özyinelemeli sürümün
 *           derinliğiyle karşılaştırma; kâhin: kütüphane sıralaması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_12_yiginli_hizli_siralama.c ortak_rastgele.c \
 *           -o H09_12_yiginli_hizli_siralama
 * Çalıştır: ./H09_12_yiginli_hizli_siralama
 * Eşleri  : cpp/H09_12_yiginli_hizli_siralama.cpp ·
 *           python/H09_12_yiginli_hizli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    int lo, hi;  /* sıralanmayı bekleyen a[lo..hi] */
} Aralik;

typedef struct {
    Aralik *veri;
    int kapasite;
    int boyut;
} Yigin;

static long long karsilastirma = 0, takas_sayisi = 0;
static long long it_sayisi = 0, cikar_sayisi = 0, tasma = 0;
static int en_buyuk_derinlik = 0, ozy_derinlik = 0;

static void sayaclari_sifirla(void)
{
    karsilastirma = takas_sayisi = it_sayisi = cikar_sayisi = tasma = 0;
    en_buyuk_derinlik = ozy_derinlik = 0;
}

/* Sahiplik: y->veri burada ayrılır; yigin_yok_et ile serbest bırakılır. */
static bool yigin_olustur(Yigin *y, int kapasite)
{
    y->veri = malloc((size_t)kapasite * sizeof *y->veri);
    y->kapasite = (y->veri != NULL) ? kapasite : 0;
    y->boyut = 0;
    return y->veri != NULL;
}

static void yigin_yok_et(Yigin *y)
{
    free(y->veri);
    y->veri = NULL;
}

static void yigin_it(Yigin *y, Aralik r)
{
    if (y->boyut == y->kapasite) {
        tasma++;  /* ⌊log2 n⌋ + 1 sınırı aşılsaydı burada görülürdü */
        return;
    }
    y->veri[y->boyut++] = r;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
}

static bool yigin_cikar(Yigin *y, Aralik *r)
{
    if (y->boyut == 0) {
        return false;
    }
    *r = y->veri[--y->boyut];
    cikar_sayisi++;
    return true;
}

static int taban_log2(int n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

static void takas(int *a, int i, int j)
{
    int g = a[i];
    a[i] = a[j];
    a[j] = g;
    takas_sayisi++;
}

/* Lomuto: pivot a[hi]; değişmez a[lo..i] < pivot <= a[i+1..j-1] */
static int bolumle(int *a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

static void yigin_yaz(const Yigin *y)
{
    printf("[");
    for (int k = 0; k < y->boyut; k++) {
        printf("%s%d..%d", k > 0 ? " " : "", y->veri[k].lo, y->veri[k].hi);
    }
    printf("]");
}

static void izle(const int *a, int n, const Yigin *y, int pivot, int p,
                 Aralik buyuk, int lo, int hi)
{
    printf("    pivot %d -> p = %d; ", pivot, p);
    if (buyuk.lo < buyuk.hi) {
        printf("it %d..%d", buyuk.lo, buyuk.hi);
    } else {
        printf("büyük parça < 2 eleman");
    }
    if (lo < hi) {
        printf(", sırada %d..%d", lo, hi);
    }
    printf("; yığın ");
    yigin_yaz(y);
    printf("\n      dizi");
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

/* Açık yığınlı hızlı sıralama: büyük parçayı it, küçüğü hemen işle */
void yiginli_hizli_sirala(int *a, int n, bool iz)
{
    Yigin y;
    Aralik r;
    if (!yigin_olustur(&y, taban_log2(n > 0 ? n : 1) + 1)) {
        exit(1);
    }
    if (n > 1) {
        yigin_it(&y, (Aralik){0, n - 1});
    }
    while (yigin_cikar(&y, &r)) {
        int lo = r.lo, hi = r.hi;
        if (iz) {
            printf("  çıkar %d..%d\n", lo, hi);
        }
        while (lo < hi) {
            int pivot = a[hi];
            int p = bolumle(a, lo, hi);
            Aralik buyuk;
            if (p - lo < hi - p) {  /* sol küçük: sağı it */
                buyuk = (Aralik){p + 1, hi};
                hi = p - 1;
            } else {                /* sağ küçük: solu it */
                buyuk = (Aralik){lo, p - 1};
                lo = p + 1;
            }
            if (buyuk.lo < buyuk.hi) {
                yigin_it(&y, buyuk);
            }
            if (iz) {
                izle(a, n, &y, pivot, p, buyuk, lo, hi);
            }
        }
    }
    yigin_yok_et(&y);
}

/* Karşılaştırma için iki çağrılı özyinelemeli sürüm (d: çağrı derinliği) */
void hizli_ozyinelemeli(int *a, int lo, int hi, int d)
{
    if (d > ozy_derinlik) {
        ozy_derinlik = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = bolumle(a, lo, hi);
    hizli_ozyinelemeli(a, lo, p - 1, d + 1);
    hizli_ozyinelemeli(a, p + 1, hi, d + 1);
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

static void girdi_uret(int *a, int n, int tur)
{
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = rastgele_aralik(0, 1000000);
        } else if (tur == 1) {
            a[i] = i;
        } else if (tur == 2) {
            a[i] = n - i;
        } else {
            a[i] = 5;
        }
    }
}

/* İki sürümü aynı girdide çalıştırır, kâhinle karşılaştırır */
static void satir(const char *ad, int n, int tur)
{
    int *a = malloc((size_t)n * sizeof *a);
    int *b = malloc((size_t)n * sizeof *b);
    int *k = malloc((size_t)n * sizeof *k);
    if (a == NULL || b == NULL || k == NULL) {
        exit(1);
    }
    rastgele_tohum(42);
    girdi_uret(a, n, tur);
    for (int i = 0; i < n; i++) {
        b[i] = k[i] = a[i];
    }
    qsort(k, (size_t)n, sizeof *k, kucukten_buyuge);  /* kâhin */
    sayaclari_sifirla();
    hizli_ozyinelemeli(b, 0, n - 1, 1);
    int ozy = ozy_derinlik;
    sayaclari_sifirla();
    yiginli_hizli_sirala(a, n, false);
    bool dogru = true;
    for (int i = 0; i < n; i++) {
        dogru = dogru && a[i] == k[i] && b[i] == k[i];
    }
    printf("  %s %7d %11lld %8d %6d %10d %6lld  %s\n", ad, n,
           karsilastirma, en_buyuk_derinlik, taban_log2(n) + 1, ozy, tasma,
           dogru ? "evet" : "HAYIR");
    free(a);
    free(b);
    free(k);
}

int main(void)
{
    int a[] = {7, 3, 5, 9, 2, 4, 1, 8, 6};
    printf("1) İzleme: a = [7 3 5 9 2 4 1 8 6], pivot = a[hi] (Lomuto)\n");
    sayaclari_sifirla();
    yiginli_hizli_sirala(a, 9, true);
    printf("  karşılaştırma = %lld, takas = %lld, it = %lld, çıkar = %lld, "
           "en büyük derinlik = %d (sınır %d)\n", karsilastirma,
           takas_sayisi, it_sayisi, cikar_sayisi, en_buyuk_derinlik,
           taban_log2(9) + 1);

    printf("\n2) Yığın derinliği: açık yığın (kapasite ⌊log2 n⌋ + 1) ve "
           "özyinelemeli sürüm\n");
    printf("  girdi          n  karşılaşt.  yığın   sınır  özyineli  taşma"
           "  kâhin\n");
    satir("rastgele", 500, 0);
    satir("sıralı  ", 500, 1);
    satir("ters    ", 500, 2);
    satir("aynı    ", 500, 3);
    satir("rastgele", 1000, 0);
    satir("rastgele", 10000, 0);
    satir("rastgele", 100000, 0);
    printf("  (sıralı/ters/aynı girdide Lomuto en kötü durumdadır: "
           "özyinelemeli derinlik n'e çıkar)\n");
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritmayı standart belirtmez);
 * C++ — std::sort (libstdc++: introsort; derinlik 2⌊log2 n⌋ aşılınca öbek
 * sıralamasına geçer);
 * Python — list.sort / sorted (Timsort). Kütüphaneler yalnızca kâhin. */

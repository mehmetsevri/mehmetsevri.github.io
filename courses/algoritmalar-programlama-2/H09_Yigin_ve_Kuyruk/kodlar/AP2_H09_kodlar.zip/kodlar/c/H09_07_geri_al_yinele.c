/* H09_07_geri_al_yinele.c — AP-2 Hafta 9 · Örnek 7 (★★)
 * Amaç    : Geri al / yinele (undo/redo) iki yığınla: her işlem geri
 *           yığınına itilir; geri al onu yinele yığınına taşır; YENİ bir
 *           işlem yinele yığınını boşaltır. Komutlar girdi dosyasından;
 *           rastgele komut dizisi durum geçmişi kâhiniyle sınanır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_07_geri_al_yinele.c ortak_rastgele.c -o H09_07_geri_al_yinele
 * Çalıştır: ./H09_07_geri_al_yinele < ../girdiler/H09_07_geri_al_yinele.txt
 * Eşleri  : cpp/H09_07_geri_al_yinele.cpp · python/H09_07_geri_al_yinele.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS_BELGE 256

typedef struct {
    char tur;                /* '+': yaz (sona ekle), '-': sil (sondan) */
    char metin[MAKS_BELGE];  /* eklenen ya da silinen metin */
} Islem;

typedef struct Dugum {
    Islem islem;
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    Dugum *tepe;
    int boyut;
} Yigin;

typedef struct {
    char metin[MAKS_BELGE];
    int uzunluk;
} Belge;

typedef struct {
    Belge belge;
    Yigin geri;    /* yapılan işlemler (tepe: en son) */
    Yigin yinele;  /* geri alınan işlemler (tepe: en son geri alınan) */
} Duzenleyici;

static long long it_sayisi = 0, cikar_sayisi = 0, temizlenen = 0;
static long long ayrilan_dugum = 0, serbest_dugum = 0;
static int en_buyuk_derinlik = 0;

static void yigin_olustur(Yigin *y)
{
    y->tepe = NULL;
    y->boyut = 0;
}

/* Sahiplik: düğümler yığınındır; kalanlar burada serbest bırakılır */
static long long yigin_yok_et(Yigin *y)
{
    long long adet = 0;
    while (y->tepe != NULL) {
        Dugum *d = y->tepe;
        y->tepe = d->sonraki;
        free(d);
        serbest_dugum++;
        adet++;
    }
    y->boyut = 0;
    return adet;
}

static bool yigin_it(Yigin *y, const Islem *i)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return false;
    }
    ayrilan_dugum++;
    d->islem = *i;  /* yapı kopyası: metin dizisi de kopyalanır */
    d->sonraki = y->tepe;
    y->tepe = d;
    y->boyut++;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
    return true;
}

static bool yigin_cikar(Yigin *y, Islem *i)
{
    if (y->tepe == NULL) {
        return false;
    }
    Dugum *d = y->tepe;
    *i = d->islem;
    y->tepe = d->sonraki;
    free(d);
    serbest_dugum++;
    y->boyut--;
    cikar_sayisi++;
    return true;
}

/* İşlemi belgeye uygular: yaz → sona ekle, sil → sondan çıkar */
static void uygula(Belge *b, const Islem *i)
{
    int u = (int)strlen(i->metin);
    if (i->tur == '+') {
        memcpy(b->metin + b->uzunluk, i->metin, (size_t)u + 1);
        b->uzunluk += u;
    } else {
        b->uzunluk -= u;
        b->metin[b->uzunluk] = '\0';
    }
}

/* İşlemin tersini uygular (geri al) */
static void ters_uygula(Belge *b, const Islem *i)
{
    Islem ters = *i;
    ters.tur = (i->tur == '+') ? '-' : '+';
    uygula(b, &ters);
}

/* Yeni işlem: uygula, geri yığınına it, yinele yığınını boşalt */
static void yeni_islem(Duzenleyici *e, const Islem *i)
{
    uygula(&e->belge, i);
    yigin_it(&e->geri, i);
    temizlenen += yigin_yok_et(&e->yinele);
}

static bool duzenle_yaz(Duzenleyici *e, const char *metin)
{
    int u = (int)strlen(metin);
    if (u == 0 || e->belge.uzunluk + u >= MAKS_BELGE) {
        return false;  /* boş metin ya da belge dolu */
    }
    Islem i = {'+', ""};
    memcpy(i.metin, metin, (size_t)u + 1);
    yeni_islem(e, &i);
    return true;
}

static bool duzenle_sil(Duzenleyici *e, int k)
{
    if (k > e->belge.uzunluk) {
        k = e->belge.uzunluk;
    }
    if (k <= 0) {
        return false;  /* silinecek karakter yok */
    }
    Islem i = {'-', ""};
    memcpy(i.metin, e->belge.metin + e->belge.uzunluk - k, (size_t)k + 1);
    yeni_islem(e, &i);
    return true;
}

static bool geri_al(Duzenleyici *e)
{
    Islem i;
    if (!yigin_cikar(&e->geri, &i)) {
        return false;
    }
    ters_uygula(&e->belge, &i);
    yigin_it(&e->yinele, &i);
    return true;
}

static bool yinele(Duzenleyici *e)
{
    Islem i;
    if (!yigin_cikar(&e->yinele, &i)) {
        return false;
    }
    uygula(&e->belge, &i);
    yigin_it(&e->geri, &i);
    return true;
}

static void duzenleyici_olustur(Duzenleyici *e)
{
    e->belge.metin[0] = '\0';
    e->belge.uzunluk = 0;
    yigin_olustur(&e->geri);
    yigin_olustur(&e->yinele);
}

static void duzenleyici_yok_et(Duzenleyici *e)
{
    yigin_yok_et(&e->geri);
    yigin_yok_et(&e->yinele);
}

/* Yığını tabandan tepeye yazar (liste ters sırada: özyinelemeli) */
static void tabandan_yaz(const Dugum *d)
{
    if (d == NULL) {
        return;
    }
    tabandan_yaz(d->sonraki);
    printf("%s%c\"%s\"", d->sonraki != NULL ? " " : "", d->islem.tur,
           d->islem.metin);
}

static void durum_yaz(const Duzenleyici *e)
{
    printf("    belge: \"%s\"\n    geri  : [", e->belge.metin);
    tabandan_yaz(e->geri.tepe);
    printf("]\n    yinele: [");
    tabandan_yaz(e->yinele.tepe);
    printf("]\n");
}

static void komut_isle(Duzenleyici *e, const char *k)
{
    char *son;
    printf("  > %s\n", k);
    if (strncmp(k, "yaz ", 4) == 0) {
        if (!duzenle_yaz(e, k + 4)) {
            printf("    (reddedildi: boş metin ya da belge dolu)\n");
        }
    } else if (strncmp(k, "sil ", 4) == 0) {
        errno = 0;
        long n = strtol(k + 4, &son, 10);
        if (son == k + 4 || *son != '\0' || errno == ERANGE || n < 0) {
            printf("    (hata: geçersiz sayı)\n");
            return;
        }
        if (!duzenle_sil(e, n > MAKS_BELGE ? MAKS_BELGE : (int)n)) {
            printf("    (reddedildi: silinecek karakter yok)\n");
        }
    } else if (strcmp(k, "geri") == 0) {
        if (!geri_al(e)) {
            printf("    (geri alınacak işlem yok)\n");
        }
    } else if (strcmp(k, "yinele") == 0) {
        if (!yinele(e)) {
            printf("    (yinelenecek işlem yok)\n");
        }
    } else {
        printf("    (hata: bilinmeyen komut)\n");
        return;
    }
    durum_yaz(e);
}

/* Kâhin: belge durumlarının dizisi + etkin indis (geri al = indis - 1) */
static void rastgele_sinama(int adim)
{
    Duzenleyici e;
    duzenleyici_olustur(&e);
    char (*durum)[MAKS_BELGE] = malloc((size_t)(adim + 1) * sizeof *durum);
    if (durum == NULL) {
        exit(1);
    }
    int etkin = 0, son = 0, uyusmazlik = 0, sayac[4] = {0, 0, 0, 0};
    durum[0][0] = '\0';
    rastgele_tohum(42);
    for (int t = 0; t < adim; t++) {
        int r = rastgele_aralik(0, 3);
        bool tamam;
        if (r == 0) {
            char m[8];
            int u = rastgele_aralik(1, 5);
            for (int q = 0; q < u; q++) {
                m[q] = (char)('a' + rastgele_aralik(0, 25));
            }
            m[u] = '\0';
            tamam = duzenle_yaz(&e, m);
        } else if (r == 1) {
            tamam = duzenle_sil(&e, rastgele_aralik(1, 6));
        } else if (r == 2) {
            tamam = geri_al(&e);
            uyusmazlik += (tamam != (etkin > 0));
            etkin -= tamam;
        } else {
            tamam = yinele(&e);
            uyusmazlik += (tamam != (etkin < son));
            etkin += tamam;
        }
        if (r <= 1 && tamam) {
            etkin++;
            son = etkin;  /* yeni işlem: ileri geçmiş silinir */
            memcpy(durum[etkin], e.belge.metin, (size_t)e.belge.uzunluk + 1);
        }
        sayac[r] += tamam;
        uyusmazlik += strcmp(e.belge.metin, durum[etkin]) != 0;
    }
    printf("  %d adım: başarılı yaz %d, sil %d, geri %d, yinele %d\n", adim,
           sayac[0], sayac[1], sayac[2], sayac[3]);
    printf("  son belge uzunluğu %d; geri yığını %d, yinele yığını %d\n",
           e.belge.uzunluk, e.geri.boyut, e.yinele.boyut);
    printf("  durum geçmişi kâhiniyle uyuşmazlık = %d\n", uyusmazlik);
    free(durum);
    duzenleyici_yok_et(&e);
}

int main(void)
{
    Duzenleyici e;
    char satir[MAKS_BELGE + 8];
    duzenleyici_olustur(&e);
    printf("1) Komutlar (girdi dosyasından); yığınlar tabandan tepeye, "
           "+ yaz, - sil\n");
    while (fgets(satir, sizeof satir, stdin) != NULL) {
        satir[strcspn(satir, "\n")] = '\0';
        komut_isle(&e, satir);
    }
    printf("  sayaçlar: it = %lld, çıkar = %lld, yeni işlemle temizlenen "
           "yinele kaydı = %lld, en büyük derinlik = %d\n", it_sayisi,
           cikar_sayisi, temizlenen, en_buyuk_derinlik);
    duzenleyici_yok_et(&e);

    printf("\n2) Rastgele 20000 komut (tohum 42) ve kâhin\n");
    rastgele_sinama(20000);
    printf("  düğüm: ayrılan = %lld, serbest = %lld\n", ayrilan_dugum,
           serbest_dugum);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — iki std::stack<Islem>;
 * Python — iki list (append/pop). Gerçek düzenleyiciler geri alma geçmişini
 * çoğunlukla sınırlar (en eski kayıt atılır: dairesel tampon ya da iki uçlu
 * kuyruk). */

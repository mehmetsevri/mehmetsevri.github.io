/*
 * zamanlayici.h — AP-2 ortak zaman ölçüm modülü (C)
 *
 * Amaç   : Algoritma deneylerinde süre ölçümü için küçük, taşınabilir bir
 *          arayüz. Ölçülen süreler stderr'e yazılır; stdout'a yalnızca
 *          deterministik sonuçlar yazılır (AP-2 kod standardı, Bölüm 6.5).
 * Kaynak : timespec_get (C11, TIME_UTC duvar saati) ve clock() (işlemci
 *          zamanı). zaman_sn() ilk çağrıdan bu yana geçen süreyi verir; böylece
 *          double değişkende nanosaniye düzeyinde çözünürlük korunur.
 *          TIME_UTC monotonik değildir: ölçüm sırasında sistem saati
 *          ayarlanırsa (NTP) tek ölçüm bozulabilir; ortanca bunu sınırlar.
 * Kullanım:
 *   gcc -std=c17 -Wall -Wextra -pedantic -O2 deney.c zamanlayici.c -o deney
 * Eşleri : zamanlayici.hpp (C++, std::chrono::steady_clock),
 *          zamanlayici.py (Python, time.perf_counter)
 */
#ifndef ZAMANLAYICI_H
#define ZAMANLAYICI_H

/* Duvar saati zamanı (saniye, ilk çağrıya göreli). İki çağrının farkı geçen
 * süreyi verir. */
double zaman_sn(void);

/* Bu sürecin kullandığı işlemci zamanı (saniye). */
double islemci_sn(void);

/* x[0..n-1] değerlerinin ortancasını döndürür. DİKKAT: x yerinde sıralanır. */
double ortanca(double *x, int n);

/* gorev(veri) çağrısını önce 1 kez ısınma, sonra tekrar kez çalıştırır;
 * ölçülen sürelerin ortancasını (saniye) döndürür. 1 <= tekrar <= 101. */
double olc_ortanca(void (*gorev)(void *), void *veri, int tekrar);

#endif /* ZAMANLAYICI_H */

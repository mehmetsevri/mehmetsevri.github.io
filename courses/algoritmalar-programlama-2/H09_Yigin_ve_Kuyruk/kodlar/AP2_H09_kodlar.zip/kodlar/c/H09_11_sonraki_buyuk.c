/* H09_11_sonraki_buyuk.c — AP-2 Hafta 9 · Örnek 11 (★★★)
 * Amaç    : Monotonik yığınla "sonraki büyük eleman" (next greater element):
 *           yığında cevabı henüz bulunmamış indisler azalan değer sırasında
 *           tutulur; her indis bir kez itilir, en çok bir kez çıkarılır →
 *           it + çıkar <= 2n, O(n). O(n^2) kaba kuvvet kâhinle sınanır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_11_sonraki_buyuk.c \
 *           ortak_rastgele.c -o H09_11_sonraki_buyuk
 * Çalıştır: ./H09_11_sonraki_buyuk
 * Eşleri  : cpp/H09_11_sonraki_buyuk.cpp · python/H09_11_sonraki_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

typedef struct {
    int *veri;  /* a'nın indisleri; değerleri tabandan tepeye azalmaz */
    int kapasite;
    int boyut;
} Yigin;

static long long it_sayisi = 0, cikar_sayisi = 0, karsilastirma = 0;
static long long kaba_karsilastirma = 0;
static int en_buyuk_derinlik = 0;

static void sayaclari_sifirla(void)
{
    it_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0;
    en_buyuk_derinlik = 0;
}

/* Sahiplik: y->veri burada ayrılır; yigin_yok_et ile serbest bırakılır. */
static bool yigin_olustur(Yigin *y, int kapasite)
{
    y->veri = malloc((size_t)(kapasite > 0 ? kapasite : 1) * sizeof *y->veri);
    y->kapasite = (y->veri != NULL) ? kapasite : 0;
    y->boyut = 0;
    return y->veri != NULL;
}

static void yigin_yok_et(Yigin *y)
{
    free(y->veri);
    y->veri = NULL;
}

static void yigin_it(Yigin *y, int i)
{
    y->veri[y->boyut++] = i;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
}

static int yigin_cikar(Yigin *y)
{
    cikar_sayisi++;
    return y->veri[--y->boyut];
}

static bool kucuk_mu(int x, int y)
{
    karsilastirma++;
    return x < y;
}

/* sonuc[i] = a[i]'nin sağındaki ilk büyük değer; yoksa -1 (a[i] >= 0).
 * iz: her adımda cevabı bulunanları (çıkarılanları) ve yığını yazar */
void sonraki_buyuk(const int *a, int n, int *sonuc, bool iz)
{
    Yigin y;
    char coz[256];
    if (!yigin_olustur(&y, n)) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        coz[0] = '\0';
        while (y.boyut > 0 && kucuk_mu(a[y.veri[y.boyut - 1]], a[i])) {
            int j = yigin_cikar(&y);
            sonuc[j] = a[i];  /* a[j]'nin cevabı bulundu */
            snprintf(coz + strlen(coz), sizeof coz - strlen(coz), "%s%d",
                     coz[0] != '\0' ? " " : "", a[j]);
        }
        yigin_it(&y, i);
        if (iz) {
            printf("  %2d %5d   %-13s [", i, a[i], coz[0] ? coz : "-");
            for (int k = 0; k < y.boyut; k++) {
                printf(k > 0 ? " %d" : "%d", a[y.veri[k]]);
            }
            printf("]\n");
        }
    }
    while (y.boyut > 0) {
        sonuc[yigin_cikar(&y)] = -1;  /* sağda büyüğü olmayanlar */
    }
    yigin_yok_et(&y);
}

/* Kâhin: her i için sağa doğru tarama, O(n^2) */
static void kaba_kuvvet(const int *a, int n, int *sonuc)
{
    for (int i = 0; i < n; i++) {
        sonuc[i] = -1;
        for (int j = i + 1; j < n; j++) {
            kaba_karsilastirma++;
            if (a[j] > a[i]) {
                sonuc[i] = a[j];
                break;
            }
        }
    }
}

static bool ayni_mi(const int *x, const int *y, int n)
{
    for (int i = 0; i < n; i++) {
        if (x[i] != y[i]) {
            return false;
        }
    }
    return true;
}

static void girdi_uret(int *a, int n, int tur)
{
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = i;           /* artan */
        } else if (tur == 1) {
            a[i] = n - i;       /* azalan */
        } else if (tur == 2) {
            a[i] = 7;           /* sabit */
        } else {
            a[i] = rastgele_aralik(0, 1000000);
        }
    }
}

int main(void)
{
    const int a[] = {3, 8, 4, 1, 2, 6, 5, 9, 7};
    const int n = 9;
    int sonuc[9];
    printf("1) İzleme: a = [3 8 4 1 2 6 5 9 7]\n");
    printf("   i  a[i]   çıkarılanlar  yığın (taban -> tepe, değer)\n");
    sayaclari_sifirla();
    sonraki_buyuk(a, n, sonuc, true);
    printf("  sonraki büyük:");
    for (int i = 0; i < n; i++) {
        printf(" %d", sonuc[i]);
    }
    printf("\n  it = %lld, çıkar = %lld, karşılaştırma = %lld, en büyük "
           "derinlik = %d\n", it_sayisi, cikar_sayisi, karsilastirma,
           en_buyuk_derinlik);

    printf("\n2) Girdi türüne göre (n = 1000): yığın O(n), kaba kuvvet "
           "O(n^2)\n");
    printf("  girdi      it  çıkar  karş.  derinlik   kaba karş.  aynı mı\n");
    const char *ad[] = {"artan   ", "azalan  ", "sabit   ", "rastgele"};
    int m = 1000;
    int *b = malloc((size_t)m * sizeof *b);
    int *s1 = malloc((size_t)m * sizeof *s1);
    int *s2 = malloc((size_t)m * sizeof *s2);
    if (b == NULL || s1 == NULL || s2 == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    for (int tur = 0; tur < 4; tur++) {
        girdi_uret(b, m, tur);
        sayaclari_sifirla();
        sonraki_buyuk(b, m, s1, false);
        kaba_kuvvet(b, m, s2);
        printf("  %s %5lld %6lld %6lld %9d %12lld  %s\n", ad[tur], it_sayisi,
               cikar_sayisi, karsilastirma, en_buyuk_derinlik,
               kaba_karsilastirma, ayni_mi(s1, s2, m) ? "evet" : "HAYIR");
    }
    free(b);
    free(s1);
    free(s2);

    printf("\n3) Rastgele 2000 dizi (n = 0..60, değerler 0..20, tohum 42) "
           "ve kâhin\n");
    int dizi[60], r1[60], r2[60], uyusmazlik = 0, sinir_ihlali = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 2000; t++) {
        int k = rastgele_aralik(0, 60);
        for (int i = 0; i < k; i++) {
            dizi[i] = rastgele_aralik(0, 20);
        }
        sayaclari_sifirla();
        sonraki_buyuk(dizi, k, r1, false);
        kaba_kuvvet(dizi, k, r2);
        uyusmazlik += !ayni_mi(r1, r2, k);
        sinir_ihlali += (it_sayisi + cikar_sayisi > 2LL * k);
    }
    printf("  kâhinle uyuşmazlık = %d, it + çıkar > 2n olan dizi = %d\n",
           uyusmazlik, sinir_ihlali);

    printf("\n4) Büyüme: rastgele girdi, değerler 0..10^6\n");
    printf("        n     it + çıkar    2n   karş./n\n");
    for (int k = 1000; k <= 100000; k *= 10) {
        int *c = malloc((size_t)k * sizeof *c);
        int *s = malloc((size_t)k * sizeof *s);
        if (c == NULL || s == NULL) {
            return 1;
        }
        rastgele_tohum(42);
        girdi_uret(c, k, 3);
        sayaclari_sifirla();
        sonraki_buyuk(c, k, s, false);
        printf("  %7d %14lld %7d %9.3f\n", k, it_sayisi + cikar_sayisi,
               2 * k, (double)karsilastirma / k);
        free(c);
        free(s);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack<int> ile
 * aynı algoritma); Python — yok (list yığın olarak). Monotonik yığın;
 * histogramdaki en büyük dikdörtgen (Örnek 14), stok açıklığı (stock span)
 * ve sonraki küçük eleman problemlerinde de kullanılır. */

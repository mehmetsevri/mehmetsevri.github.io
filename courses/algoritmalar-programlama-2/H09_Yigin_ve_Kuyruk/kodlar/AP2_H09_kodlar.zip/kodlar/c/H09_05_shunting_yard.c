/* H09_05_shunting_yard.c — AP-2 Hafta 9 · Örnek 5 (★★★)
 * Amaç    : Dijkstra'nın manevra sahası (Shunting-yard) algoritmasıyla araek
 *           (infix) → sonek (postfix) dönüşümü: öncelik ve birleşme yönü
 *           tablosu (^ sağdan birleşmeli), tekli eksi ayrı işleç (~),
 *           sözdizimi ve parantez hataları
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_05_shunting_yard.c \
 *           -o H09_05_shunting_yard
 * Çalıştır: ./H09_05_shunting_yard < ../girdiler/H09_05_shunting_yard.txt
 * Eşleri  : cpp/H09_05_shunting_yard.cpp · python/H09_05_shunting_yard.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS 512
static const char *const IZ_BASLIK =
    "    belirteç işleç yığını   çıktı                eylem";

enum { SAYI, AD, ISLEC, SOL_PAR, SAG_PAR };
enum { HATA_YOK, GECERSIZ_KARAKTER, ISLENEN_BEKLENIYOR, ISLEC_BEKLENIYOR,
       ESLESMEYEN_KAPANIS, ACIK_PARANTEZ, BOS_IFADE };

static const char *const HATA_ILETISI[] = {
    "yok", "geçersiz karakter", "işlenen bekleniyordu",
    "işleç bekleniyordu", "eşleşmeyen ')'", "kapanmamış '('",
    "boş ifade"};

typedef struct {
    int tur;
    int bas, uz;  /* girdideki yeri: s[bas .. bas+uz-1] */
    char islec;   /* + - * / ^ ve tekli eksi için ~ */
} Belirtec;

typedef struct {
    int *veri;  /* işleç yığını belirteç indislerini tutar */
    int kapasite;
    int boyut;
} Yigin;

static long long it_sayisi = 0, cikar_sayisi = 0;
static int en_buyuk_derinlik = 0;

/* Sahiplik: y->veri burada ayrılır; yigin_yok_et ile serbest bırakılır. */
static bool yigin_olustur(Yigin *y, int kapasite)
{
    y->veri = malloc((size_t)kapasite * sizeof *y->veri);
    y->kapasite = (y->veri != NULL) ? kapasite : 0;
    y->boyut = 0;
    return y->veri != NULL;
}

static void yigin_yok_et(Yigin *y)
{
    free(y->veri);
    y->veri = NULL;
    y->kapasite = y->boyut = 0;
}

static bool yigin_it(Yigin *y, int x)
{
    if (y->boyut == y->kapasite) {
        return false;
    }
    y->veri[y->boyut++] = x;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
    return true;
}

static bool yigin_cikar(Yigin *y, int *x)
{
    if (y->boyut == 0) {
        return false;
    }
    *x = y->veri[--y->boyut];
    cikar_sayisi++;
    return true;
}

static bool yigin_tepe(const Yigin *y, int *x)
{
    if (y->boyut == 0) {
        return false;
    }
    *x = y->veri[y->boyut - 1];
    return true;
}

/* Öncelik ve birleşme yönü tablosu */
static int oncelik(char op)
{
    if (op == '+' || op == '-') {
        return 1;
    }
    if (op == '*' || op == '/') {
        return 2;
    }
    return op == '~' ? 3 : 4;  /* ~ tekli eksi, ^ üs */
}

static bool sag_birlesmeli(char op) { return op == '^' || op == '~'; }

/* Yığının tepesindeki ust, gelen işleçten önce çıktıya gitmeli mi? */
static bool once_cikar_mi(char ust, char gelen)
{
    return oncelik(ust) > oncelik(gelen) ||
           (oncelik(ust) == oncelik(gelen) && !sag_birlesmeli(gelen));
}

/* s[0..n-1] belirteçlere ayrılır; işlenen/işleç sırası denetlenir */
static int belirtecle(const char *s, int n, Belirtec *b, int *m, int *sutun)
{
    int k = 0;
    bool islenen_bekleniyor = true;
    int i = 0;
    while (i < n) {
        char c = s[i];
        if (c == ' ' || c == '\t') {
            i++;
            continue;
        }
        Belirtec t = {SAYI, i, 1, c};
        if (c >= '0' && c <= '9') {
            while (i + t.uz < n && s[i + t.uz] >= '0' && s[i + t.uz] <= '9') {
                t.uz++;
            }
        } else if (c >= 'a' && c <= 'z') {
            t.tur = AD;
        } else if (c == '(' || c == ')') {
            t.tur = (c == '(') ? SOL_PAR : SAG_PAR;
        } else if (strchr("+-*/^", c) != NULL) {
            t.tur = ISLEC;
            if (c == '-' && islenen_bekleniyor) {
                t.islec = '~';  /* başta, '(' ya da işleçten sonra: tekli */
            }
        } else {
            *sutun = i + 1;
            return GECERSIZ_KARAKTER;
        }
        *sutun = i + 1;
        if (islenen_bekleniyor) {
            if (t.tur == SAG_PAR || (t.tur == ISLEC && t.islec != '~')) {
                return ISLENEN_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == SOL_PAR || t.tur == ISLEC);
        } else {
            if (t.tur == SAYI || t.tur == AD || t.tur == SOL_PAR) {
                return ISLEC_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == ISLEC);
        }
        b[k++] = t;
        i += t.uz;
    }
    *m = k;
    *sutun = n + 1;
    if (islenen_bekleniyor) {
        return k == 0 ? BOS_IFADE : ISLENEN_BEKLENIYOR;
    }
    return HATA_YOK;
}

/* Belirtecin metni: sayı ve adlar girdiden, işleçler tek karakter */
static void belirtec_ekle(char *hedef, const char *s, const Belirtec *t)
{
    size_t u = strlen(hedef);
    if (t->tur == SAYI || t->tur == AD) {
        memcpy(hedef + u, s + t->bas, (size_t)t->uz);
        hedef[u + (size_t)t->uz] = '\0';
    } else {
        hedef[u] = t->islec;
        hedef[u + 1] = '\0';
    }
}

static void iz_satiri(const char *bt, const Yigin *y, const Belirtec *b,
                      const int *cikti, int k, const char *s,
                      const char *eylem)
{
    char yg[MAKS] = "[", ck[MAKS] = "";
    for (int j = 0; j < y->boyut; j++) {
        if (j > 0) {
            strcat(yg, " ");
        }
        belirtec_ekle(yg, s, &b[y->veri[j]]);
    }
    strcat(yg, "]");
    for (int j = 0; j < k; j++) {
        if (j > 0) {
            strcat(ck, " ");
        }
        belirtec_ekle(ck, s, &b[cikti[j]]);
    }
    printf("    %-8s %-14s %-20s %s\n", bt, yg, ck, eylem);
}

/* Shunting-yard: b[0..m-1] → cikti[0..*k-1] (belirteç indisleri) */
int sonege_cevir(const Belirtec *b, int m, int *cikti, int *k, int *sutun,
                 const char *s, bool iz)
{
    Yigin y;
    int hata = HATA_YOK, j;
    char bt[MAKS], eylem[MAKS];
    if (!yigin_olustur(&y, m + 1)) {
        exit(1);
    }
    *k = 0;
    for (int i = 0; i < m && hata == HATA_YOK; i++) {
        Belirtec t = b[i];
        bt[0] = eylem[0] = '\0';
        belirtec_ekle(bt, s, &t);
        if (t.tur == SAYI || t.tur == AD) {
            cikti[(*k)++] = i;
            strcpy(eylem, "çıktıya yaz");
        } else if (t.tur == SOL_PAR) {
            yigin_it(&y, i);
            strcpy(eylem, "it (");
        } else if (t.tur == SAG_PAR) {
            strcpy(eylem, "çıkar:");
            while (yigin_tepe(&y, &j) && b[j].tur != SOL_PAR) {
                yigin_cikar(&y, &j);
                cikti[(*k)++] = j;
                strcat(eylem, " ");
                belirtec_ekle(eylem, s, &b[j]);
            }
            if (!yigin_cikar(&y, &j)) {
                hata = ESLESMEYEN_KAPANIS;
                *sutun = t.bas + 1;
            }
            strcat(eylem, hata == HATA_YOK ? "; ( atılır" : "; ( yok!");
        } else if (t.islec == '~') {
            yigin_it(&y, i);  /* önek işleç: hiçbir şeyi çıkarmaz */
            strcpy(eylem, "it ~ (tekli eksi)");
        } else {
            strcpy(eylem, "");
            while (yigin_tepe(&y, &j) && b[j].tur == ISLEC &&
                   once_cikar_mi(b[j].islec, t.islec)) {
                yigin_cikar(&y, &j);
                cikti[(*k)++] = j;
                strcat(eylem, eylem[0] == '\0' ? "çıkar: " : " ");
                belirtec_ekle(eylem, s, &b[j]);
            }
            strcat(eylem, eylem[0] == '\0' ? "it " : "; it ");
            belirtec_ekle(eylem, s, &t);
            yigin_it(&y, i);
        }
        if (iz) {
            iz_satiri(bt, &y, b, cikti, *k, s, eylem);
        }
    }
    if (hata == HATA_YOK) {
        strcpy(eylem, "boşalt:");
        while (yigin_cikar(&y, &j)) {
            if (b[j].tur == SOL_PAR) {
                hata = ACIK_PARANTEZ;
                *sutun = b[j].bas + 1;
                strcat(eylem, " ( kapanmamış!");
                break;
            }
            cikti[(*k)++] = j;
            strcat(eylem, " ");
            belirtec_ekle(eylem, s, &b[j]);
        }
        if (iz) {
            iz_satiri("(son)", &y, b, cikti, *k, s, eylem);
        }
    }
    yigin_yok_et(&y);
    return hata;
}

static bool satir_isle(const char *s, bool iz)
{
    Belirtec b[MAKS];
    int cikti[MAKS];
    int n = (int)strlen(s), m = 0, k = 0, sutun = 0;
    it_sayisi = cikar_sayisi = 0;
    en_buyuk_derinlik = 0;
    if (iz) {
        printf("  %s\n%s\n", s, IZ_BASLIK);
    }
    int hata = belirtecle(s, n, b, &m, &sutun);
    if (hata == HATA_YOK) {
        hata = sonege_cevir(b, m, cikti, &k, &sutun, s, iz);
    }
    if (iz) {
        printf("    sonuç: ");
    } else {
        printf("  %-22s ", s);
    }
    if (hata != HATA_YOK) {
        printf("-> HATA sütun %d: %s\n", sutun, HATA_ILETISI[hata]);
        return false;
    }
    char ck[MAKS] = "";
    for (int j = 0; j < k; j++) {
        if (j > 0) {
            strcat(ck, " ");
        }
        belirtec_ekle(ck, s, &b[cikti[j]]);
    }
    printf("-> %s   [belirteç %d, it %lld, çıkar %lld, derinlik %d]\n", ck,
           m, it_sayisi, cikar_sayisi, en_buyuk_derinlik);
    return true;
}

int main(void)
{
    char satir[MAKS];
    int gecerli = 0, toplam = 0;
    printf("1) Öncelik ve birleşme yönü tablosu\n");
    printf("  işleç  öncelik  birleşme\n");
    const char *islecler = "+-*/~^";
    for (int i = 0; islecler[i] != '\0'; i++) {
        printf("    %c       %d     %s\n", islecler[i], oncelik(islecler[i]),
               sag_birlesmeli(islecler[i]) ? "sağdan" : "soldan");
    }
    printf("  (~ tekli eksidir: başta, '(' ya da işleçten sonra gelen '-')\n");

    printf("\n2) Adım adım dönüşüm (her belirteçten sonra yığın ve çıktı)\n");
    satir_isle("3 + 4 * 2", true);
    satir_isle("(1 + 2) * 3", true);
    satir_isle("2 ^ 3 ^ 2", true);
    satir_isle("a - b - c", true);

    printf("\n3) Girdi dosyasındaki ifadeler\n");
    while (fgets(satir, sizeof satir, stdin) != NULL) {
        satir[strcspn(satir, "\n")] = '\0';
        gecerli += satir_isle(satir, false);
        toplam++;
    }
    printf("  toplam %d ifade: dönüştürülen %d, hatalı %d\n", toplam,
           gecerli, toplam - gecerli);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack yalnızca
 * işleç yığınını sağlar); Python — yok (ast modülü ifadeyi ayrıştırır ama
 * sonek üretmez). Derleyicilerin ayrıştırıcıları aynı öncelik/birleşme
 * kurallarını uygular. */

/*
 * zamanlayici.c — AP-2 ortak zaman ölçüm modülü (C gerçekleştirimi)
 * Ayrıntılar için bkz. zamanlayici.h
 */
#include "zamanlayici.h"

#include <time.h>

double zaman_sn(void)
{
    /* Çağdan (1970) bu yana geçen ~1,7e9 saniye double'da tutulursa
     * çözünürlük ~240 ns'ye düşer; ilk çağrının saniyesini taban alırız. */
    static time_t taban = 0;
    static int taban_var = 0;
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    if (!taban_var) {
        taban = ts.tv_sec;
        taban_var = 1;
    }
    return (double)(ts.tv_sec - taban) + (double)ts.tv_nsec * 1e-9;
}

double islemci_sn(void)
{
    return (double)clock() / CLOCKS_PER_SEC;
}

double ortanca(double *x, int n)
{
    /* Küçük n için araya ekleme sıralaması (yardımcı; ders konusu H5) */
    for (int i = 1; i < n; i++) {
        double anahtar = x[i];
        int j = i - 1;
        while (j >= 0 && x[j] > anahtar) {
            x[j + 1] = x[j];
            j--;
        }
        x[j + 1] = anahtar;
    }
    if (n % 2 == 1) {
        return x[n / 2];
    }
    return (x[n / 2 - 1] + x[n / 2]) / 2.0;
}

double olc_ortanca(void (*gorev)(void *), void *veri, int tekrar)
{
    double sureler[101];
    if (tekrar < 1) {
        tekrar = 1;
    }
    if (tekrar > 101) {
        tekrar = 101;
    }
    gorev(veri); /* ısınma: önbellek ve sayfa tablolarını doldurur */
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn();
        gorev(veri);
        sureler[k] = zaman_sn() - t0;
    }
    return ortanca(sureler, tekrar);
}

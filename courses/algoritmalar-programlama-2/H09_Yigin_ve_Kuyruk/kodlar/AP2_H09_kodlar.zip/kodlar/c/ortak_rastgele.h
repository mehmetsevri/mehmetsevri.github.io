/*
 * ortak_rastgele.h — AP-2 ortak rastgele sayı modülü (C)
 *
 * Amaç   : C, C++ ve Python'da BİREBİR AYNI sözde rastgele diziyi üreten
 *          64 bitlik doğrusal eşlik üreteci (LCG). rand() platforma göre
 *          farklı dizi ürettiği için deneyleri tekrarlanamaz kılar; bu
 *          modül her platformda ve her dilde aynı sayıları verir.
 * Formül : durum = (durum * 6364136223846793005 + 1442695040888963407)
 *          mod 2^64
 *          çıktı = durum >> 33   (31 bit: 0 .. 2^31 - 1)
 *          (Çarpan ve artım: Knuth, MMIX LCG.)
 * Kullanım:
 *   gcc -std=c17 -Wall -Wextra -pedantic -O2 ornek.c ortak_rastgele.c -o ornek
 * Eşleri : ortak_rastgele.hpp (C++), ortak_rastgele.py (Python)
 * Not    : Kriptografik amaçla KULLANILMAZ; yalnızca tekrarlanabilir deney
 *          ve test verisi içindir. rastgele_aralik'taki mod işleminin küçük
 *          yanlılığı (modulo bias) ders deneyleri için önemsizdir.
 */
#ifndef ORTAK_RASTGELE_H
#define ORTAK_RASTGELE_H

#include <stddef.h>
#include <stdint.h>

/* Üretecin durumunu verilen tohumla başlatır. */
void rastgele_tohum(uint64_t tohum);

/* Bir sonraki sayıyı döndürür: 0 .. 2^31 - 1 (dahil). */
uint32_t rastgele_sayi(void);

/* [alt, ust] kapalı aralığında tamsayı döndürür (alt <= ust olmalı). */
int rastgele_aralik(int alt, int ust);

/* [0, 1) aralığında ondalık sayı döndürür. */
double rastgele_kesir(void);

/* a[0..n-1] dizisini [alt, ust] aralığındaki sayılarla doldurur. */
void rastgele_dizi(int *a, size_t n, int alt, int ust);

/* a[0..n-1] dizisini Fisher–Yates yöntemiyle yerinde karıştırır. */
void rastgele_karistir(int *a, size_t n);

#endif /* ORTAK_RASTGELE_H */

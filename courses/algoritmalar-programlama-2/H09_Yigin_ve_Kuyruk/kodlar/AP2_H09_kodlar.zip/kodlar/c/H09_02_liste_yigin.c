/* H09_02_liste_yigin.c — AP-2 Hafta 9 · Örnek 2 (★)
 * Amaç    : Bağlı liste tabanlı yığın (sınırsız): Örnek 1 ile AYNI arayüz,
 *           farklı gerçekleştirim; tepe = listenin başı, it/çıkar O(1)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_02_liste_yigin.c \
 *           ortak_rastgele.c -o H09_02_liste_yigin
 * Çalıştır: ./H09_02_liste_yigin
 * Eşleri  : cpp/H09_02_liste_yigin.cpp · python/H09_02_liste_yigin.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int deger;
    struct Dugum *sonraki;  /* tepeden tabana doğru */
} Dugum;

/* Yığın: tepe listenin ilk düğümü; boş yığında tepe == NULL */
typedef struct {
    Dugum *tepe;
    int boyut;
} Yigin;

static long long it_sayisi = 0, cikar_sayisi = 0;
static int en_buyuk_derinlik = 0;
static long long ayrilan_dugum = 0, serbest_dugum = 0;

void yigin_olustur(Yigin *y)
{
    y->tepe = NULL;
    y->boyut = 0;
}

/* Sahiplik: düğümler yığınındır; kalan düğümler burada serbest bırakılır */
void yigin_yok_et(Yigin *y)
{
    Dugum *d = y->tepe;
    while (d != NULL) {
        Dugum *sonraki = d->sonraki;
        free(d);
        serbest_dugum++;
        d = sonraki;
    }
    y->tepe = NULL;
    y->boyut = 0;
}

bool yigin_bos_mu(const Yigin *y) { return y->tepe == NULL; }

/* Kapasite sınırı yok: yalnızca malloc başarısız olursa false döner */
bool yigin_it(Yigin *y, int x)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return false;
    }
    ayrilan_dugum++;
    d->deger = x;
    d->sonraki = y->tepe;  /* yeni düğüm eski tepenin önüne */
    y->tepe = d;
    y->boyut++;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
    return true;
}

/* Alt taşma: yığın boşsa false döner; *x değişmez */
bool yigin_cikar(Yigin *y, int *x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    Dugum *d = y->tepe;
    *x = d->deger;
    y->tepe = d->sonraki;
    free(d);
    serbest_dugum++;
    y->boyut--;
    cikar_sayisi++;
    return true;
}

/* Tepedeki elemanı çıkarmadan okur */
bool yigin_tepe(const Yigin *y, int *x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    *x = y->tepe->deger;
    return true;
}

/* Tabandan tepeye yazmak için liste ters sırada dolaşılır (özyinelemeli) */
static void tabandan_yaz(const Dugum *d)
{
    if (d == NULL) {
        return;
    }
    tabandan_yaz(d->sonraki);
    printf(d->sonraki != NULL ? " %d" : "%d", d->deger);
}

static void yigin_yaz(const Yigin *y)
{
    printf("taban [");
    tabandan_yaz(y->tepe);
    printf("] tepe");
}

/* Kâhin: ayrı bir dizi ve indis (Örnek 1'in kapasitesiz eşdeğeri) */
static void rastgele_sinama(int islem)
{
    Yigin y;
    yigin_olustur(&y);
    int *ayna = malloc((size_t)islem * sizeof *ayna);
    if (ayna == NULL) {
        exit(1);
    }
    int ust = 0, uyusmazlik = 0, alt_tasma = 0, x;
    long long it0 = it_sayisi, cikar0 = cikar_sayisi;
    rastgele_tohum(42);
    for (int k = 0; k < islem; k++) {
        if (rastgele_aralik(0, 1) == 0) {
            int v = rastgele_aralik(0, 999);
            yigin_it(&y, v);
            ayna[ust++] = v;
        } else if (yigin_cikar(&y, &x)) {
            uyusmazlik += (ust == 0 || ayna[--ust] != x);
        } else {
            alt_tasma++;
            uyusmazlik += (ust != 0);
        }
    }
    printf("  %d işlem: başarılı = %lld, alt taşma = %d, son boyut = %d\n",
           islem, (it_sayisi - it0) + (cikar_sayisi - cikar0), alt_tasma,
           y.boyut);
    printf("  kâhinle uyuşmazlık = %d\n", uyusmazlik);
    free(ayna);
    yigin_yok_et(&y);
}

int main(void)
{
    Yigin y;
    int x = 0;
    yigin_olustur(&y);
    printf("1) Liste tabanlı yığına 10, 20, 30, 40, 50 itilir "
           "(kapasite yok)\n");
    for (int k = 1; k <= 5; k++) {
        bool tamam = yigin_it(&y, 10 * k);
        printf("  it %d -> %s  ", 10 * k, tamam ? "evet" : "HAYIR");
        yigin_yaz(&y);
        printf("  boyut = %d\n", y.boyut);
    }

    printf("\n2) Tepeye bakma ve çıkarma: Örnek 1 ile aynı sözleşme\n");
    if (yigin_tepe(&y, &x)) {
        printf("  tepe -> %d (çıkarılmadı)\n", x);
    }
    for (int k = 0; k < 6; k++) {
        if (yigin_cikar(&y, &x)) {
            printf("  çıkar -> %d  ", x);
        } else {
            printf("  çıkar -> HAYIR (alt taşma: yığın boş)  ");
        }
        yigin_yaz(&y);
        printf("\n");
    }
    printf("  sayaçlar: it = %lld, çıkar = %lld, en büyük derinlik = %d\n",
           it_sayisi, cikar_sayisi, en_buyuk_derinlik);

    printf("\n3) Sınırsızlık ve bellek: 100000 it, ardından yok et\n");
    for (int k = 0; k < 100000; k++) {
        yigin_it(&y, k);
    }
    yigin_tepe(&y, &x);
    printf("  boyut = %d, tepe = %d, ayrılan düğüm = %lld\n", y.boyut, x,
           ayrilan_dugum);
    yigin_yok_et(&y);
    printf("  yok et sonrası: boş mu? %s; serbest bırakılan = %lld; "
           "fark = %lld\n", yigin_bos_mu(&y) ? "evet" : "HAYIR",
           serbest_dugum, ayrilan_dugum - serbest_dugum);

    printf("\n4) Rastgele it/çıkar dizisi (tohum 42) ve kâhin\n");
    rastgele_sinama(100000);
    printf("  toplam: ayrılan = %lld, serbest = %lld\n", ayrilan_dugum,
           serbest_dugum);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int,
 * std::list<int>> (kap uyarlayıcısı, alttaki kap değiştirilebilir);
 * Python — list (append/pop) ya da collections.deque. */

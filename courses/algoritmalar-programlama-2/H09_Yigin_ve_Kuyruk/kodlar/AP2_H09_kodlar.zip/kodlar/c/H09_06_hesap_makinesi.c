/* H09_06_hesap_makinesi.c — AP-2 Hafta 9 · Örnek 6 (★★★)
 * Amaç    : Basit hesap makinesi: araek ifade → Shunting-yard (Örnek 5) →
 *           sonek değerlendirme (Örnek 4); + - * / ^, parantez, tekli eksi;
 *           hata iletileri ve çıkış kodları üç dilde aynı; rastgele ifade
 *           ağaçlarıyla kâhinli sınama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_06_hesap_makinesi.c ortak_rastgele.c \
 *           -o H09_06_hesap_makinesi
 * Çalıştır: ./H09_06_hesap_makinesi < ../girdiler/H09_06_hesap_makinesi.txt
 *           ./H09_06_hesap_makinesi "3 + 4 * 2"     (tek ifade)
 *           çıkış kodu: 0 geçerli · 1 hatalı ifade · 2 hatalı kullanım
 * Eşleri  : cpp/H09_06_hesap_makinesi.cpp · python/H09_06_hesap_makinesi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS 512

enum { SAYI, ISLEC, SOL_PAR, SAG_PAR };
enum { HATA_YOK, GECERSIZ_KARAKTER, ISLENEN_BEKLENIYOR, ISLEC_BEKLENIYOR,
       ESLESMEYEN_KAPANIS, ACIK_PARANTEZ, BOS_IFADE, SIFIRA_BOLME, TASMA,
       NEGATIF_US };

static const char *const HATA_ILETISI[] = {
    "yok", "geçersiz karakter", "işlenen bekleniyordu",
    "işleç bekleniyordu", "eşleşmeyen ')'", "kapanmamış '('", "boş ifade",
    "sıfıra bölme", "taşma (int aralığı dışında)", "negatif üs"};

typedef struct {
    int tur;
    int sutun;   /* 1 tabanlı konum */
    char islec;  /* + - * / ^ ve tekli eksi için ~ */
    int deger;   /* SAYI için */
} Belirtec;

typedef struct {
    int *veri;
    int kapasite;
    int boyut;
} Yigin;

static long long it_sayisi = 0, cikar_sayisi = 0;

/* Sahiplik: y->veri burada ayrılır; yigin_yok_et ile serbest bırakılır. */
static bool yigin_olustur(Yigin *y, int kapasite)
{
    y->veri = malloc((size_t)kapasite * sizeof *y->veri);
    y->kapasite = (y->veri != NULL) ? kapasite : 0;
    y->boyut = 0;
    return y->veri != NULL;
}

static void yigin_yok_et(Yigin *y)
{
    free(y->veri);
    y->veri = NULL;
    y->kapasite = y->boyut = 0;
}

static bool yigin_it(Yigin *y, int x)
{
    if (y->boyut == y->kapasite) {
        return false;
    }
    y->veri[y->boyut++] = x;
    it_sayisi++;
    return true;
}

static bool yigin_cikar(Yigin *y, int *x)
{
    if (y->boyut == 0) {
        return false;
    }
    *x = y->veri[--y->boyut];
    cikar_sayisi++;
    return true;
}

static bool yigin_tepe(const Yigin *y, int *x)
{
    if (y->boyut == 0) {
        return false;
    }
    *x = y->veri[y->boyut - 1];
    return true;
}

/* ---- Aritmetik (Örnek 4): int aralığı denetimli ---- */
static int us_al(int a, int b, int *sonuc)
{
    if (a == 0 || a == 1) {
        *sonuc = (b == 0) ? 1 : a;
        return HATA_YOK;
    }
    if (a == -1) {
        *sonuc = (b % 2 == 0) ? 1 : -1;
        return HATA_YOK;
    }
    long long r = 1;
    for (int k = 0; k < b; k++) {
        r *= a;
        if (r < INT_MIN || r > INT_MAX) {
            return TASMA;
        }
    }
    *sonuc = (int)r;
    return HATA_YOK;
}

static int islem_uygula(char op, int a, int b, int *sonuc)
{
    long long r;
    if (op == '+') {
        r = (long long)a + b;
    } else if (op == '-') {
        r = (long long)a - b;
    } else if (op == '*') {
        r = (long long)a * b;
    } else if (op == '/') {
        if (b == 0) {
            return SIFIRA_BOLME;
        }
        r = (long long)a / b;  /* C: sıfıra doğru kesme */
    } else {
        if (b < 0) {
            return NEGATIF_US;
        }
        return us_al(a, b, sonuc);
    }
    if (r < INT_MIN || r > INT_MAX) {
        return TASMA;
    }
    *sonuc = (int)r;
    return HATA_YOK;
}

/* ---- Belirteçleme ve Shunting-yard (Örnek 5) ---- */
static int oncelik(char op)
{
    if (op == '+' || op == '-') {
        return 1;
    }
    if (op == '*' || op == '/') {
        return 2;
    }
    return op == '~' ? 3 : 4;
}

static bool sag_birlesmeli(char op) { return op == '^' || op == '~'; }

static bool once_cikar_mi(char ust, char gelen)
{
    return oncelik(ust) > oncelik(gelen) ||
           (oncelik(ust) == oncelik(gelen) && !sag_birlesmeli(gelen));
}

static int belirtecle(const char *s, int n, Belirtec *b, int *m, int *sutun)
{
    int k = 0, i = 0;
    bool islenen_bekleniyor = true;
    while (i < n) {
        char c = s[i];
        if (c == ' ' || c == '\t') {
            i++;
            continue;
        }
        Belirtec t = {SAYI, i + 1, c, 0};
        *sutun = i + 1;
        if (c >= '0' && c <= '9') {
            long long v = 0;
            while (i < n && s[i] >= '0' && s[i] <= '9') {
                v = 10 * v + (s[i++] - '0');
                if (v > INT_MAX) {
                    return TASMA;
                }
            }
            t.deger = (int)v;
        } else if (c == '(' || c == ')') {
            t.tur = (c == '(') ? SOL_PAR : SAG_PAR;
            i++;
        } else if (strchr("+-*/^", c) != NULL) {
            t.tur = ISLEC;
            if (c == '-' && islenen_bekleniyor) {
                t.islec = '~';
            }
            i++;
        } else {
            return GECERSIZ_KARAKTER;
        }
        if (islenen_bekleniyor) {
            if (t.tur == SAG_PAR || (t.tur == ISLEC && t.islec != '~')) {
                return ISLENEN_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == SOL_PAR || t.tur == ISLEC);
        } else {
            if (t.tur == SAYI || t.tur == SOL_PAR) {
                return ISLEC_BEKLENIYOR;
            }
            islenen_bekleniyor = (t.tur == ISLEC);
        }
        b[k++] = t;
    }
    *m = k;
    *sutun = n + 1;
    if (islenen_bekleniyor) {
        return k == 0 ? BOS_IFADE : ISLENEN_BEKLENIYOR;
    }
    return HATA_YOK;
}

static int sonege_cevir(const Belirtec *b, int m, int *cikti, int *k,
                        int *sutun)
{
    Yigin y;
    int hata = HATA_YOK, j;
    if (!yigin_olustur(&y, m + 1)) {
        exit(1);
    }
    *k = 0;
    for (int i = 0; i < m && hata == HATA_YOK; i++) {
        if (b[i].tur == SAYI) {
            cikti[(*k)++] = i;
        } else if (b[i].tur == SOL_PAR || b[i].islec == '~') {
            yigin_it(&y, i);
        } else if (b[i].tur == SAG_PAR) {
            while (yigin_tepe(&y, &j) && b[j].tur != SOL_PAR) {
                yigin_cikar(&y, &j);
                cikti[(*k)++] = j;
            }
            if (!yigin_cikar(&y, &j)) {
                hata = ESLESMEYEN_KAPANIS;
                *sutun = b[i].sutun;
            }
        } else {
            while (yigin_tepe(&y, &j) && b[j].tur == ISLEC &&
                   once_cikar_mi(b[j].islec, b[i].islec)) {
                yigin_cikar(&y, &j);
                cikti[(*k)++] = j;
            }
            yigin_it(&y, i);
        }
    }
    while (hata == HATA_YOK && yigin_cikar(&y, &j)) {
        if (b[j].tur == SOL_PAR) {
            hata = ACIK_PARANTEZ;
            *sutun = b[j].sutun;
        } else {
            cikti[(*k)++] = j;
        }
    }
    yigin_yok_et(&y);
    return hata;
}

/* ---- Sonek değerlendirme (Örnek 4), belirteç dizisi üzerinde ---- */
static int sonek_hesapla(const Belirtec *b, const int *cikti, int k,
                         int *sonuc, int *sutun, bool iz)
{
    Yigin y;
    int hata = HATA_YOK, a = 0, x = 0;
    if (!yigin_olustur(&y, k + 1)) {
        exit(1);
    }
    for (int i = 0; i < k && hata == HATA_YOK; i++) {
        Belirtec t = b[cikti[i]];
        if (t.tur == SAYI) {
            yigin_it(&y, t.deger);
        } else if (t.islec == '~') {
            yigin_cikar(&y, &a);  /* sözdizimi denetimi işleneni garantiler */
            if (a == INT_MIN) {
                hata = TASMA;
            } else {
                yigin_it(&y, -a);
            }
        } else {
            int bb = 0, r = 0;
            yigin_cikar(&y, &bb);  /* önce b (tepe), sonra a */
            yigin_cikar(&y, &a);
            hata = islem_uygula(t.islec, a, bb, &r);
            if (hata == HATA_YOK) {
                yigin_it(&y, r);
            }
        }
        if (hata != HATA_YOK) {
            *sutun = t.sutun;
        }
        if (iz) {
            if (t.tur == SAYI) {
                printf("    %-4d ->", t.deger);
            } else {
                printf("    %-4c ->", t.islec);
            }
            for (int q = 0; q < y.boyut; q++) {
                printf(" %d", y.veri[q]);
            }
            printf("\n");
        }
    }
    yigin_tepe(&y, &x);
    *sonuc = x;
    yigin_yok_et(&y);
    return hata;
}

/* Bir ifadeyi hesaplar; hata kodu döner. sonek: sonek gösterimi metni */
int hesapla(const char *s, int *sonuc, int *sutun, char *sonek, bool iz)
{
    Belirtec b[MAKS];
    int cikti[MAKS];
    int n = (int)strlen(s), m = 0, k = 0;
    sonek[0] = '\0';
    int hata = belirtecle(s, n, b, &m, sutun);
    if (hata == HATA_YOK) {
        hata = sonege_cevir(b, m, cikti, &k, sutun);
    }
    if (hata != HATA_YOK) {
        return hata;
    }
    for (int i = 0; i < k; i++) {
        char parca[16];
        if (b[cikti[i]].tur == SAYI) {
            snprintf(parca, sizeof parca, "%d", b[cikti[i]].deger);
        } else {
            snprintf(parca, sizeof parca, "%c", b[cikti[i]].islec);
        }
        strcat(sonek, i > 0 ? " " : "");
        strcat(sonek, parca);
    }
    return sonek_hesapla(b, cikti, k, sonuc, sutun, iz);
}

static bool satir_isle(const char *s)
{
    char sonek[2 * MAKS];
    int sonuc = 0, sutun = 0;
    int hata = hesapla(s, &sonuc, &sutun, sonek, false);
    if (hata == HATA_YOK) {
        printf("  %-32s = %d   (sonek: %s)\n", s, sonuc, sonek);
    } else {
        printf("  %-32s -> HATA sütun %d: %s\n", s, sutun,
               HATA_ILETISI[hata]);
    }
    return hata == HATA_YOK;
}

/* ---- Kâhin: rastgele ifade ağacı; değer üretilirken hesaplanır ---- */
static int rastgele_ifade(int derinlik, char *s, int *deger, int *hata)
{
    int r = (derinlik == 0) ? 0 : rastgele_aralik(0, 4);
    if (r == 0) {
        *deger = rastgele_aralik(-9, 9);
        sprintf(s, "%d", *deger);
        return 9;  /* yaprak: hiç parantez gerektirmez */
    }
    char op = "+-*/"[r - 1];
    char sol[MAKS], sag[MAKS];
    int a, b, ha = HATA_YOK, hb = HATA_YOK;
    int os = rastgele_ifade(derinlik - 1, sol, &a, &ha);
    int og = rastgele_ifade(derinlik - 1, sag, &b, &hb);
    int p = oncelik(op);
    sprintf(s, os < p ? "(%s) %c " : "%s %c ", sol, op);
    sprintf(s + strlen(s), og <= p ? "(%s)" : "%s", sag);
    *hata = (ha != HATA_YOK) ? ha : hb;
    *deger = 0;
    if (*hata == HATA_YOK) {
        *hata = islem_uygula(op, a, b, deger);
    }
    return p;
}

static void kahinli_sinama(int adet)
{
    char s[MAKS], sonek[2 * MAKS];
    int uyusmazlik = 0, hatali = 0;
    rastgele_tohum(42);
    for (int t = 0; t < adet; t++) {
        int beklenen = 0, beklenen_hata = HATA_YOK, sonuc = 0, sutun = 0;
        rastgele_ifade(3, s, &beklenen, &beklenen_hata);
        int hata = hesapla(s, &sonuc, &sutun, sonek, false);
        if (hata != beklenen_hata ||
            (hata == HATA_YOK && sonuc != beklenen)) {
            uyusmazlik++;
        }
        hatali += (hata == SIFIRA_BOLME);
        if (t < 4) {
            printf("  %-40s -> ", s);
            if (hata == HATA_YOK) {
                printf("%d (kâhin %d)\n", sonuc, beklenen);
            } else {
                printf("HATA: %s (kâhin: %s)\n", HATA_ILETISI[hata],
                       HATA_ILETISI[beklenen_hata]);
            }
        }
    }
    printf("  %d ifade: sıfıra bölmeli %d, kâhinle uyuşmazlık %d\n", adet,
           hatali, uyusmazlik);
}

int main(int argc, char *argv[])
{
    if (argc > 2) {
        fprintf(stderr, "kullanım: H09_06_hesap_makinesi [\"ifade\"]  "
                "(ifade yoksa stdin)\n");
        return 2;
    }
    if (argc == 2) {
        return satir_isle(argv[1]) ? 0 : 1;
    }
    char satir[MAKS], sonek[2 * MAKS];
    int sonuc = 0, sutun = 0, gecerli = 0, toplam = 0;
    printf("1) 3 + 4 * 2: önce sonek gösterimine, sonra yığınla hesap\n");
    hesapla("3 + 4 * 2", &sonuc, &sutun, sonek, true);
    printf("  sonek: %s  ->  sonuç %d\n", sonek, sonuc);

    printf("\n2) Rastgele ifade ağaçları (derinlik <= 3, tohum 42) ve "
           "kâhin\n");
    kahinli_sinama(2000);

    printf("\n3) Girdi dosyasındaki ifadeler\n");
    while (fgets(satir, sizeof satir, stdin) != NULL) {
        satir[strcspn(satir, "\n")] = '\0';
        gecerli += satir_isle(satir);
        toplam++;
    }
    printf("  toplam %d ifade: geçerli %d, hatalı %d (yığın işlemleri: "
           "it %lld, çıkar %lld)\n", toplam, gecerli, toplam - gecerli,
           it_sayisi, cikar_sayisi);
    return gecerli == toplam ? 0 : 1;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok; Python — eval()
 * (ifadeyi Python kurallarıyla hesaplar: / gerçek bölme, // aşağı yuvarlar,
 * ^ XOR'dur — bu yüzden kâhin olarak bile kullanılmadı; güvensiz girdide
 * eval kullanılmaz). */

/* H09_01_dizi_yigin.c — AP-2 Hafta 9 · Örnek 1 (★)
 * Amaç    : Dizi tabanlı yığın ADT'si (sabit kapasite): it, çıkar, tepe,
 *           boş mu; taşma ve alt taşma dönüş koduyla (bool) bildirilir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_01_dizi_yigin.c \
 *           ortak_rastgele.c -o H09_01_dizi_yigin
 * Çalıştır: ./H09_01_dizi_yigin
 * Eşleri  : cpp/H09_01_dizi_yigin.cpp · python/H09_01_dizi_yigin.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

/* Yığın: veri[0..boyut-1] dolu; tepe veri[boyut-1]; boyut <= kapasite */
typedef struct {
    int *veri;
    int kapasite;
    int boyut;
} Yigin;

static long long it_sayisi = 0, cikar_sayisi = 0;
static int en_buyuk_derinlik = 0;

/* Sahiplik: y->veri burada ayrılır; yigin_yok_et ile serbest bırakılır. */
bool yigin_olustur(Yigin *y, int kapasite)
{
    y->veri = malloc((size_t)kapasite * sizeof *y->veri);
    y->kapasite = (y->veri != NULL) ? kapasite : 0;
    y->boyut = 0;
    return y->veri != NULL;
}

void yigin_yok_et(Yigin *y)
{
    free(y->veri);
    y->veri = NULL;
    y->kapasite = 0;
    y->boyut = 0;
}

bool yigin_bos_mu(const Yigin *y) { return y->boyut == 0; }

bool yigin_dolu_mu(const Yigin *y) { return y->boyut == y->kapasite; }

/* Taşma: yığın doluysa false döner ve yığın değişmez */
bool yigin_it(Yigin *y, int x)
{
    if (yigin_dolu_mu(y)) {
        return false;
    }
    y->veri[y->boyut] = x;
    y->boyut++;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
    return true;
}

/* Alt taşma: yığın boşsa false döner; *x değişmez */
bool yigin_cikar(Yigin *y, int *x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    y->boyut--;
    *x = y->veri[y->boyut];
    cikar_sayisi++;
    return true;
}

/* Tepedeki elemanı çıkarmadan okur */
bool yigin_tepe(const Yigin *y, int *x)
{
    if (yigin_bos_mu(y)) {
        return false;
    }
    *x = y->veri[y->boyut - 1];
    return true;
}

static void yigin_yaz(const Yigin *y)
{
    printf("taban [");
    for (int i = 0; i < y->boyut; i++) {
        printf(i > 0 ? " %d" : "%d", y->veri[i]);
    }
    printf("] tepe");
}

/* Ondalık sayıyı ikiliye çevirir: kalanlar yığına, sonra ters sırada */
static void ikiliye_cevir(int sayi)
{
    Yigin y;
    if (!yigin_olustur(&y, 32)) {
        exit(1);
    }
    printf("  %d ->", sayi);
    for (int n = sayi; n > 0; n /= 2) {
        yigin_it(&y, n % 2);
        printf(" %d", n % 2);
    }
    printf("  (kalanlar üretildiği sırada)\n  ikili: ");
    int b;
    while (yigin_cikar(&y, &b)) {
        printf("%d", b);
    }
    printf("  (yığından çıkış sırası)\n");
    yigin_yok_et(&y);
}

static void rastgele_sinama(int islem, int kapasite)
{
    Yigin y;
    if (!yigin_olustur(&y, kapasite)) {
        exit(1);
    }
    long long it0 = it_sayisi, cikar0 = cikar_sayisi;
    int tasma = 0, alt_tasma = 0, x;
    rastgele_tohum(42);
    for (int k = 0; k < islem; k++) {
        if (rastgele_aralik(0, 1) == 0) {
            if (!yigin_it(&y, rastgele_aralik(0, 999))) {
                tasma++;
            }
        } else if (!yigin_cikar(&y, &x)) {
            alt_tasma++;
        }
    }
    long long basarili = (it_sayisi - it0) + (cikar_sayisi - cikar0);
    printf("  %d işlem, kapasite %d: başarılı = %lld, taşma = %d, "
           "alt taşma = %d\n", islem, kapasite, basarili, tasma, alt_tasma);
    printf("  son boyut = %d; it - çıkar = %lld; tutarlı mı? %s\n", y.boyut,
           (it_sayisi - it0) - (cikar_sayisi - cikar0),
           y.boyut == (it_sayisi - it0) - (cikar_sayisi - cikar0)
               ? "evet" : "HAYIR");
    yigin_yok_et(&y);
}

int main(void)
{
    Yigin y;
    int x;
    if (!yigin_olustur(&y, 4)) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("1) Kapasitesi 4 olan yığına 10, 20, 30, 40, 50 itilir\n");
    for (int k = 1; k <= 5; k++) {
        bool tamam = yigin_it(&y, 10 * k);
        printf("  it %d -> %s  ", 10 * k,
               tamam ? "evet" : "HAYIR (taşma: yığın dolu)");
        yigin_yaz(&y);
        printf("  boyut = %d\n", y.boyut);
    }

    printf("\n2) Tepeye bakma ve çıkarma (LIFO: son giren ilk çıkar)\n");
    if (yigin_tepe(&y, &x)) {
        printf("  tepe -> %d (çıkarılmadı)\n", x);
    }
    for (int k = 0; k < 5; k++) {
        if (yigin_cikar(&y, &x)) {
            printf("  çıkar -> %d  ", x);
        } else {
            printf("  çıkar -> HAYIR (alt taşma: yığın boş)  ");
        }
        yigin_yaz(&y);
        printf("\n");
    }
    printf("  tepe -> %s\n", yigin_tepe(&y, &x) ? "?" : "HAYIR (boş yığın)");
    printf("  sayaçlar: it = %lld, çıkar = %lld, en büyük derinlik = %d\n",
           it_sayisi, cikar_sayisi, en_buyuk_derinlik);
    yigin_yok_et(&y);

    printf("\n3) Uygulama: ondalıktan ikiliye (kalanlar yığına)\n");
    ikiliye_cevir(2026);
    ikiliye_cevir(37);

    printf("\n4) Rastgele it/çıkar dizisi (tohum 42): sözleşme denetimi\n");
    rastgele_sinama(100000, 8);
    rastgele_sinama(100000, 1000);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::stack<int> (push, pop,
 * top, empty; boş yığında pop/top tanımsız davranış); Python — list
 * (append, pop, a[-1]; boş listede pop IndexError verir). */

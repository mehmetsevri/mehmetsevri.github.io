/* H09_13_kayan_pencere.c — AP-2 Hafta 9 · Örnek 13 (★★★)
 * Amaç    : İki uçlu kuyruk (deque) ile kayan pencere en büyüğü: deque'da
 *           penceredeki indisler değerleri azalan sırada tutulur (monotonik
 *           deque); önde pencereden çıkan indis, arkada yeni elemandan küçük
 *           ya da eşit olanlar atılır → Θ(n), ek bellek O(k). Deque elle,
 *           dairesel tamponla (kapasite k); O(nk) kaba kuvvet kâhinle sınama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_13_kayan_pencere.c \
 *           ortak_rastgele.c -o H09_13_kayan_pencere
 * Çalıştır: ./H09_13_kayan_pencere
 * Eşleri  : cpp/H09_13_kayan_pencere.cpp · python/H09_13_kayan_pencere.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

/* İki uçlu kuyruk: veri[bas], veri[bas+1], ... (mod kapasite), sayac eleman */
typedef struct {
    int *veri;
    int kapasite;
    int bas;
    int sayac;
} Deque;

static long long ekle_sayisi = 0, cikar_sayisi = 0, karsilastirma = 0;
static long long kaba_karsilastirma = 0;
static int en_buyuk_boyut = 0;

static void sayaclari_sifirla(void)
{
    ekle_sayisi = cikar_sayisi = karsilastirma = kaba_karsilastirma = 0;
    en_buyuk_boyut = 0;
}

/* Sahiplik: d->veri burada ayrılır; deque_yok_et ile serbest bırakılır. */
bool deque_olustur(Deque *d, int kapasite)
{
    d->veri = malloc((size_t)kapasite * sizeof *d->veri);
    d->kapasite = (d->veri != NULL) ? kapasite : 0;
    d->bas = d->sayac = 0;
    return d->veri != NULL;
}

void deque_yok_et(Deque *d)
{
    free(d->veri);
    d->veri = NULL;
}

bool deque_bos_mu(const Deque *d) { return d->sayac == 0; }

static void boyut_guncelle(const Deque *d)
{
    ekle_sayisi++;
    if (d->sayac > en_buyuk_boyut) {
        en_buyuk_boyut = d->sayac;
    }
}

bool arkaya_ekle(Deque *d, int x)
{
    if (d->sayac == d->kapasite) {
        return false;
    }
    d->veri[(d->bas + d->sayac) % d->kapasite] = x;
    d->sayac++;
    boyut_guncelle(d);
    return true;
}

bool one_ekle(Deque *d, int x)
{
    if (d->sayac == d->kapasite) {
        return false;
    }
    d->bas = (d->bas - 1 + d->kapasite) % d->kapasite;  /* geriye sarma */
    d->veri[d->bas] = x;
    d->sayac++;
    boyut_guncelle(d);
    return true;
}

bool arkadan_cikar(Deque *d, int *x)
{
    if (d->sayac == 0) {
        return false;
    }
    d->sayac--;
    *x = d->veri[(d->bas + d->sayac) % d->kapasite];
    cikar_sayisi++;
    return true;
}

bool onden_cikar(Deque *d, int *x)
{
    if (d->sayac == 0) {
        return false;
    }
    *x = d->veri[d->bas];
    d->bas = (d->bas + 1) % d->kapasite;
    d->sayac--;
    cikar_sayisi++;
    return true;
}

int deque_on(const Deque *d) { return d->veri[d->bas]; }

int deque_arka(const Deque *d)
{
    return d->veri[(d->bas + d->sayac - 1) % d->kapasite];
}

static bool kucuk_esit_mi(int x, int y)
{
    karsilastirma++;
    return x <= y;
}

/* en_buyuk[i] = max(a[i..i+k-1]), i = 0..n-k (1 <= k <= n) */
void kayan_en_buyuk(const int *a, int n, int k, int *en_buyuk, bool iz)
{
    Deque d;
    int x;
    char atilan[128];
    if (!deque_olustur(&d, k)) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        atilan[0] = '\0';
        if (!deque_bos_mu(&d) && deque_on(&d) == i - k) {
            onden_cikar(&d, &x);  /* pencereden çıkan indis */
            snprintf(atilan, sizeof atilan, "önden %d", a[x]);
        }
        while (!deque_bos_mu(&d) && kucuk_esit_mi(a[deque_arka(&d)], a[i])) {
            arkadan_cikar(&d, &x);  /* bundan sonra hiç en büyük olamaz */
            snprintf(atilan + strlen(atilan), sizeof atilan - strlen(atilan),
                     "%sarkadan %d", atilan[0] != '\0' ? ", " : "", a[x]);
        }
        arkaya_ekle(&d, i);
        if (i >= k - 1) {
            en_buyuk[i - k + 1] = a[deque_on(&d)];
        }
        if (iz) {
            char ic[128] = "[", eb[16] = "-";
            for (int q = 0; q < d.sayac; q++) {
                snprintf(ic + strlen(ic), sizeof ic - strlen(ic), "%s%d",
                         q > 0 ? " " : "", a[d.veri[(d.bas + q) % k]]);
            }
            strcat(ic, "]");
            if (i >= k - 1) {
                snprintf(eb, sizeof eb, "%d", en_buyuk[i - k + 1]);
            }
            printf("  %2d %4d   %-12s %5s   %s\n", i, a[i], ic, eb,
                   atilan[0] != '\0' ? atilan : "-");
        }
    }
    deque_yok_et(&d);
}

/* Kâhin: her pencereyi baştan tara, O(nk) */
static void kaba_kuvvet(const int *a, int n, int k, int *en_buyuk)
{
    for (int i = 0; i + k <= n; i++) {
        int m = a[i];
        for (int j = i + 1; j < i + k; j++) {
            kaba_karsilastirma++;
            if (a[j] > m) {
                m = a[j];
            }
        }
        en_buyuk[i] = m;
    }
}

static void deque_gosterimi(void)
{
    Deque d;
    int x;
    if (!deque_olustur(&d, 4)) {
        exit(1);
    }
    printf("1) İki uçlu kuyruk (kapasite 4): iki uçtan ekleme ve çıkarma\n");
    arkaya_ekle(&d, 10);
    arkaya_ekle(&d, 20);
    one_ekle(&d, 5);
    printf("  arkaya 10, arkaya 20, öne 5   -> bas = %d, sayaç = %d "
           "(öne ekleme bas'ı geriye sardı)\n", d.bas, d.sayac);
    printf("  sırası: ");
    for (int q = 0; q < d.sayac; q++) {
        printf("%d ", d.veri[(d.bas + q) % 4]);
    }
    printf("| ön = %d, arka = %d\n", deque_on(&d), deque_arka(&d));
    bool e1 = one_ekle(&d, 1), e0 = one_ekle(&d, 0);
    printf("  öne 1 -> %s; öne 0 -> %s (kapasite 4)\n", e1 ? "evet" : "HAYIR",
           e0 ? "evet" : "HAYIR");
    arkadan_cikar(&d, &x);
    printf("  arkadan çıkar -> %d; ", x);
    onden_cikar(&d, &x);
    printf("önden çıkar -> %d; kalan sayaç = %d\n", x, d.sayac);
    deque_yok_et(&d);
}

static bool ayni_mi(const int *x, const int *y, int n)
{
    for (int i = 0; i < n; i++) {
        if (x[i] != y[i]) {
            return false;
        }
    }
    return true;
}

int main(void)
{
    deque_gosterimi();

    const int a[] = {4, 2, 12, 3, 8, 1, 5, 7, 6, 2};
    int sonuc[10];
    printf("\n2) İzleme: a = [4 2 12 3 8 1 5 7 6 2], k = 3 (deque'da "
           "indisler; değerleri yazılı)\n");
    printf("   i a[i]   deque        en büyük  atılanlar\n");
    sayaclari_sifirla();
    kayan_en_buyuk(a, 10, 3, sonuc, true);
    printf("  pencere en büyükleri:");
    for (int i = 0; i < 8; i++) {
        printf(" %d", sonuc[i]);
    }
    printf("\n  ekle = %lld, çıkar = %lld, karşılaştırma = %lld, en büyük "
           "deque boyu = %d (k = 3)\n", ekle_sayisi, cikar_sayisi,
           karsilastirma, en_buyuk_boyut);

    printf("\n3) Rastgele 2000 girdi (n = 1..80, k = 1..n, tohum 42) ve "
           "kâhin\n");
    int dizi[80], r1[80], r2[80], uyusmazlik = 0, ihlal = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 2000; t++) {
        int n = rastgele_aralik(1, 80);
        int k = rastgele_aralik(1, n);
        for (int i = 0; i < n; i++) {
            dizi[i] = rastgele_aralik(0, 50);
        }
        sayaclari_sifirla();
        kayan_en_buyuk(dizi, n, k, r1, false);
        kaba_kuvvet(dizi, n, k, r2);
        uyusmazlik += !ayni_mi(r1, r2, n - k + 1);
        ihlal += (ekle_sayisi + cikar_sayisi > 2LL * n) ||
                 (en_buyuk_boyut > k);
    }
    printf("  kâhinle uyuşmazlık = %d, ekle + çıkar > 2n ya da boy > k = %d\n",
           uyusmazlik, ihlal);

    printf("\n4) n = 100000 rastgele: deque Θ(n), kaba kuvvet "
           "(n - k + 1)(k - 1) karşılaştırma\n");
    printf("       k  ekle + çıkar  karş./n  en büyük boy   kaba karş.\n");
    int n = 100000;
    int *b = malloc((size_t)n * sizeof *b);
    int *s = malloc((size_t)n * sizeof *s);
    if (b == NULL || s == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        b[i] = rastgele_aralik(0, 1000000);
    }
    for (int k = 10; k <= 10000; k *= 10) {
        sayaclari_sifirla();
        kayan_en_buyuk(b, n, k, s, false);
        printf("  %6d %13lld %8.3f %13d %12lld\n", k,
               ekle_sayisi + cikar_sayisi, (double)karsilastirma / n,
               en_buyuk_boyut, (long long)(n - k + 1) * (k - 1));
    }
    free(b);
    free(s);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::deque<int> (push_back,
 * pop_back, pop_front, front, back); Python — collections.deque (append,
 * pop, popleft, d[0], d[-1]). */

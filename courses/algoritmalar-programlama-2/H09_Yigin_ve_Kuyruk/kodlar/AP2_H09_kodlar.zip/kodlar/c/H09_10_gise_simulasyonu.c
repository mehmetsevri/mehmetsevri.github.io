/* H09_10_gise_simulasyonu.c — AP-2 Hafta 9 · Örnek 10 (★★)
 * Amaç    : Kayıt gişesi simülasyonu: tek FIFO kuyruk (dairesel tampon,
 *           Örnek 8) ve k gişe; zaman tamsayı saniye; her saniye bir öğrenci
 *           p = gelis_milyonda / 10^6 olasılıkla gelir (ortak LCG); hizmet
 *           süresi [60, 180] s'de düzgün (ortalama 120 s). Ortalama ve en
 *           uzun bekleme, kuyruk uzunluğu, gişe doluluğu; yük oranı ρ
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_10_gise_simulasyonu.c ortak_rastgele.c \
 *           -o H09_10_gise_simulasyonu
 * Çalıştır: ./H09_10_gise_simulasyonu
 * Eşleri  : cpp/H09_10_gise_simulasyonu.cpp ·
 *           python/H09_10_gise_simulasyonu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define HIZMET_EN_AZ 60
#define HIZMET_EN_COK 180  /* ortalama hizmet süresi E[S] = 120 s */
#define EN_COK_GISE 8

typedef struct {  /* Örnek 8'in sayaçlı dairesel tamponu (geliş anları) */
    int *veri;
    int kapasite, bas, son, sayac;
} Kuyruk;

typedef struct {
    long long gelen, reddedilen, hizmet_alan, toplam_bekleme, mesgul;
    long long toplam_kuyruk;  /* her saniyenin kuyruk uzunluğu toplamı */
    int en_uzun_bekleme, en_uzun_kuyruk, kuyrukta_kalan;
} Sonuc;

/* Sahiplik: q->veri burada ayrılır; kuyruk_yok_et ile serbest bırakılır. */
static bool kuyruk_olustur(Kuyruk *q, int kapasite)
{
    q->veri = malloc((size_t)kapasite * sizeof *q->veri);
    q->kapasite = (q->veri != NULL) ? kapasite : 0;
    q->bas = q->son = q->sayac = 0;
    return q->veri != NULL;
}

static void kuyruk_yok_et(Kuyruk *q)
{
    free(q->veri);
    q->veri = NULL;
}

static bool kuyruk_ekle(Kuyruk *q, int x)
{
    if (q->sayac == q->kapasite) {
        return false;  /* taşma politikası: reddet */
    }
    q->veri[q->son] = x;
    q->son = (q->son + 1) % q->kapasite;
    q->sayac++;
    return true;
}

static bool kuyruk_cikar(Kuyruk *q, int *x)
{
    if (q->sayac == 0) {
        return false;
    }
    *x = q->veri[q->bas];
    q->bas = (q->bas + 1) % q->kapasite;
    q->sayac--;
    return true;
}

/* k gişe, sure saniye; ilk olay_siniri olay yazdırılır */
Sonuc gise_benzet(int k, int gelis_milyonda, int sure, int kapasite,
                  int olay_siniri)
{
    Sonuc s = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    Kuyruk q;
    int kalan[EN_COK_GISE] = {0};  /* gişedeki işin kalan süresi (0: boş) */
    int olay = 0;
    if (!kuyruk_olustur(&q, kapasite)) {
        exit(1);
    }
    for (int t = 0; t < sure; t++) {
        if (rastgele_aralik(0, 999999) < gelis_milyonda) {  /* 1) geliş */
            s.gelen++;
            bool tamam = kuyruk_ekle(&q, t);
            s.reddedilen += !tamam;
            if (olay++ < olay_siniri) {
                printf("  t = %4d  öğrenci %lld geldi%s; kuyruk %d\n", t,
                       s.gelen, tamam ? "" : " (kuyruk dolu: geri döndü)",
                       q.sayac);
            }
        }
        for (int g = 0; g < k; g++) {  /* 2) boş gişe sıradakini alır */
            int gelis;
            if (kalan[g] == 0 && kuyruk_cikar(&q, &gelis)) {
                int bekleme = t - gelis;
                s.hizmet_alan++;
                s.toplam_bekleme += bekleme;
                if (bekleme > s.en_uzun_bekleme) {
                    s.en_uzun_bekleme = bekleme;
                }
                kalan[g] = rastgele_aralik(HIZMET_EN_AZ, HIZMET_EN_COK);
                if (olay++ < olay_siniri) {
                    printf("  t = %4d  gişe %d: öğrenci %lld (bekleme %d s,"
                           " hizmet %d s); kuyruk %d\n", t, g + 1,
                           s.hizmet_alan, bekleme, kalan[g], q.sayac);
                }
            }
        }
        for (int g = 0; g < k; g++) {  /* 3) saat ilerler */
            if (kalan[g] > 0) {
                kalan[g]--;
                s.mesgul++;
            }
        }
        s.toplam_kuyruk += q.sayac;
        if (q.sayac > s.en_uzun_kuyruk) {
            s.en_uzun_kuyruk = q.sayac;
        }
    }
    s.kuyrukta_kalan = q.sayac;
    kuyruk_yok_et(&q);
    return s;
}

/* Yük oranı ρ = λ E[S] / k; λ = gelis_milyonda / 10^6 (saniyede) */
static int gelis_hizi(int rho_binde, int k)
{
    return (rho_binde * k * 1000 + 60) / 120;  /* yuvarlanmış milyonda */
}

static void satir_yaz(int k, int gelis_milyonda, int sure, Sonuc s)
{
    double rho = gelis_milyonda * 120.0 / (1000000.0 * k);
    double ort = s.hizmet_alan > 0
                     ? (double)s.toplam_bekleme / s.hizmet_alan : 0.0;
    double lq = (double)s.toplam_kuyruk / sure;
    double little = (double)(s.gelen - s.reddedilen) / sure * ort;
    double doluluk = 100.0 * s.mesgul / ((double)k * sure);
    printf("  %d  %5.2f %6lld %6lld %5d %10.2f %7d %9.2f %8.2f %7d %7.1f\n",
           k, rho, s.gelen, s.hizmet_alan, s.kuyrukta_kalan, ort,
           s.en_uzun_bekleme, lq, little, s.en_uzun_kuyruk, doluluk);
}

static void tablo_basligi(void)
{
    printf("  k      ρ  gelen hizmet kalan  ort.bekl. en uzun ort.kuyr."
           "      λ·W en uzun doluluk\n");
    printf("                                      (s)     (s)       (L)"
           " (Little)   kuyr.     (%%)\n");
}

int main(void)
{
    const int gun = 8 * 3600;
    printf("1) Olay çizelgesi: k = 2, saniyede p = 0.02 (ρ = 1.20), ilk 16 "
           "olay\n");
    rastgele_tohum(42);
    gise_benzet(2, 20000, 600, 4096, 16);

    printf("\n2) Bir kayıt günü (8 saat = %d s), saatte ortalama 36 öğrenci"
           " (p = 0.01)\n", gun);
    tablo_basligi();
    for (int k = 1; k <= 4; k++) {
        rastgele_tohum(42);
        satir_yaz(k, 10000, gun, gise_benzet(k, 10000, gun, 4096, 0));
    }

    printf("\n3) Tek gişe (k = 1), yük oranı ρ 1'e yaklaşırken "
           "(8 saat, tohum 42)\n");
    tablo_basligi();
    const int rho_binde[] = {500, 700, 800, 900, 950};
    for (int i = 0; i < 5; i++) {
        int p = gelis_hizi(rho_binde[i], 1);
        rastgele_tohum(42);
        satir_yaz(1, p, gun, gise_benzet(1, p, gun, 4096, 0));
    }
    printf("  (λ·W ≈ L: Little yasası; uzun benzetim ve k = 1..4 için bkz. "
           "Haftanın Deneyi)\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int>; Python —
 * collections.deque. Olay kuyruğu (zamana göre sıralı) gereken ayrık olay
 * benzetimlerinde öncelik kuyruğu (H7 öbeği) kullanılır. */

/*
 * ortak_rastgele.c — AP-2 ortak rastgele sayı modülü (C gerçekleştirimi)
 * Ayrıntılar ve formül için bkz. ortak_rastgele.h
 */
#include "ortak_rastgele.h"

static uint64_t durum = 2027u; /* varsayılan tohum */

void rastgele_tohum(uint64_t tohum)
{
    durum = tohum;
}

uint32_t rastgele_sayi(void)
{
    /* uint64_t aritmetiği 2^64 modunda sarar: işaretsiz taşma tanımlıdır */
    durum = durum * 6364136223846793005u + 1442695040888963407u;
    return (uint32_t)(durum >> 33);
}

int rastgele_aralik(int alt, int ust)
{
    uint64_t genislik = (uint64_t)((int64_t)ust - (int64_t)alt + 1);
    return (int)((int64_t)alt + (int64_t)(rastgele_sayi() % genislik));
}

double rastgele_kesir(void)
{
    return rastgele_sayi() / 2147483648.0; /* 2^31 */
}

void rastgele_dizi(int *a, size_t n, int alt, int ust)
{
    for (size_t i = 0; i < n; i++) {
        a[i] = rastgele_aralik(alt, ust);
    }
}

void rastgele_karistir(int *a, size_t n)
{
    if (n < 2) {
        return;
    }
    for (size_t i = n - 1; i > 0; i--) {
        size_t j = (size_t)rastgele_aralik(0, (int)i);
        int gecici = a[i];
        a[i] = a[j];
        a[j] = gecici;
    }
}

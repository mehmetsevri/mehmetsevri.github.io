/* H09_08_dairesel_kuyruk.c — AP-2 Hafta 9 · Örnek 8 (★★)
 * Amaç    : Dairesel tampon (circular buffer) kuyruk: bas/son indisleri ve
 *           mod aritmetiği; dolu/boş ayrımı iki yöntemle: (A) eleman sayacı,
 *           (B) bir hücre boş bırakılır. Kapasite 2'nin kuvvetiyse mod
 *           yerine bit maskesi. Rastgele işlem dizisiyle kâhinli sınama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_08_dairesel_kuyruk.c ortak_rastgele.c -o H09_08_dairesel_kuyruk
 * Çalıştır: ./H09_08_dairesel_kuyruk
 * Eşleri  : cpp/H09_08_dairesel_kuyruk.cpp · python/H09_08_dairesel_kuyruk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

/* (A) Sayaçlı: veri[bas], ..., veri[son - 1] (mod kapasite) doludur */
typedef struct {
    int *veri;
    int kapasite;
    int bas;       /* ilk (en eski) elemanın indisi */
    int son;       /* sıradaki yazma indisi */
    int sayac;     /* eleman sayısı: dolu/boş ayrımını bu yapar */
    bool maskeli;  /* kapasite 2'nin kuvveti: & (kapasite - 1) */
} Kuyruk;

/* (B) Bir boş hücreli: hucre = kapasite + 1; bas == son ise boş */
typedef struct {
    int *veri;
    int hucre;
    int bas;
    int son;
} KuyrukBH;

static long long ekle_sayisi = 0, cikar_sayisi = 0, sarma_sayisi = 0;

/* Sahiplik: q->veri burada ayrılır; kuyruk_yok_et ile serbest bırakılır. */
bool kuyruk_olustur(Kuyruk *q, int kapasite)
{
    q->veri = malloc((size_t)kapasite * sizeof *q->veri);
    q->kapasite = (q->veri != NULL) ? kapasite : 0;
    q->bas = q->son = q->sayac = 0;
    q->maskeli = (kapasite & (kapasite - 1)) == 0;
    return q->veri != NULL;
}

void kuyruk_yok_et(Kuyruk *q)
{
    free(q->veri);
    q->veri = NULL;
    q->kapasite = q->bas = q->son = q->sayac = 0;
}

bool kuyruk_bos_mu(const Kuyruk *q) { return q->sayac == 0; }

bool kuyruk_dolu_mu(const Kuyruk *q) { return q->sayac == q->kapasite; }

/* Sonraki indis: son hücreden sonra 0'a sarar */
static int ilerle(const Kuyruk *q, int i)
{
    if (i + 1 == q->kapasite) {
        sarma_sayisi++;
    }
    if (q->maskeli) {
        return (i + 1) & (q->kapasite - 1);
    }
    return (i + 1) % q->kapasite;
}

/* Dolu kuyrukta false döner (taşma politikası: reddet) */
bool kuyruk_ekle(Kuyruk *q, int x)
{
    if (kuyruk_dolu_mu(q)) {
        return false;
    }
    q->veri[q->son] = x;
    q->son = ilerle(q, q->son);
    q->sayac++;
    ekle_sayisi++;
    return true;
}

/* Boş kuyrukta false döner; *x değişmez */
bool kuyruk_cikar(Kuyruk *q, int *x)
{
    if (kuyruk_bos_mu(q)) {
        return false;
    }
    *x = q->veri[q->bas];
    q->bas = ilerle(q, q->bas);
    q->sayac--;
    cikar_sayisi++;
    return true;
}

/* ---- (B) bir boş hücre: sayaç yok; dolu iken bir hücre kullanılmaz ---- */
bool bh_olustur(KuyrukBH *q, int kapasite)
{
    q->veri = malloc(((size_t)kapasite + 1) * sizeof *q->veri);
    q->hucre = (q->veri != NULL) ? kapasite + 1 : 0;
    q->bas = q->son = 0;
    return q->veri != NULL;
}

void bh_yok_et(KuyrukBH *q)
{
    free(q->veri);
    q->veri = NULL;
    q->hucre = q->bas = q->son = 0;
}

bool bh_bos_mu(const KuyrukBH *q) { return q->bas == q->son; }

bool bh_dolu_mu(const KuyrukBH *q) { return (q->son + 1) % q->hucre == q->bas; }

int bh_boyut(const KuyrukBH *q)
{
    return (q->son - q->bas + q->hucre) % q->hucre;
}

bool bh_ekle(KuyrukBH *q, int x)
{
    if (bh_dolu_mu(q)) {
        return false;
    }
    q->veri[q->son] = x;
    q->son = (q->son + 1) % q->hucre;
    return true;
}

bool bh_cikar(KuyrukBH *q, int *x)
{
    if (bh_bos_mu(q)) {
        return false;
    }
    *x = q->veri[q->bas];
    q->bas = (q->bas + 1) % q->hucre;
    return true;
}

/* Fiziksel diziyi yazar: dolu hücre değeriyle, boş hücre '.' ile */
static void dizi_metni(char *m, const int *veri, int hucre, int bas,
                       int boyut)
{
    strcpy(m, "[");
    for (int i = 0; i < hucre; i++) {
        char p[16];
        if ((i - bas + hucre) % hucre < boyut) {
            snprintf(p, sizeof p, "%d", veri[i]);
        } else {
            strcpy(p, ".");
        }
        strcat(m, i > 0 ? " " : "");
        strcat(m, p);
    }
    strcat(m, "]");
}

static void satir_yaz(int bas, int son, int boyut, const char *dizi,
                      const char *islem)
{
    printf("    %3d %3d %5d   %-16s %s\n", bas, son, boyut, dizi, islem);
}

static void izle_sayacli(void)
{
    const int adim[] = {10, 20, 30, 40, 50, 0, 0, 50, 60, 70, 0, 0, 0, 0, 0};
    Kuyruk q;
    char dizi[128], islem[64];
    if (!kuyruk_olustur(&q, 4)) {
        exit(1);
    }
    printf("  (A) sayaçlı, kapasite 4 (2'nin kuvveti: & 3 ile ilerler)\n");
    printf("    bas son sayaç   fiziksel dizi    işlem\n");
    dizi_metni(dizi, q.veri, 4, q.bas, q.sayac);
    satir_yaz(q.bas, q.son, q.sayac, dizi, "(başlangıç: bas == son, boş)");
    for (int k = 0; k < 15; k++) {
        long long sarma0 = sarma_sayisi;
        int x;
        if (adim[k] > 0) {
            bool tamam = kuyruk_ekle(&q, adim[k]);
            snprintf(islem, sizeof islem, "ekle %d%s", adim[k],
                     tamam ? "" : " -> dolu, reddedildi");
        } else if (kuyruk_cikar(&q, &x)) {
            snprintf(islem, sizeof islem, "çıkar -> %d", x);
        } else {
            strcpy(islem, "çıkar -> boş, reddedildi");
        }
        if (sarma_sayisi > sarma0) {
            strcat(islem, "  (sarma)");
        }
        if (q.bas == q.son) {
            strcat(islem, q.sayac == 0 ? "  [bas == son, sayaç 0: boş]"
                                       : "  [bas == son, sayaç 4: dolu]");
        }
        dizi_metni(dizi, q.veri, 4, q.bas, q.sayac);
        satir_yaz(q.bas, q.son, q.sayac, dizi, islem);
    }
    kuyruk_yok_et(&q);
}

static void izle_bos_hucreli(void)
{
    const int adim[] = {10, 20, 30, 40, 50, 0, 0, 50, 60, 0, 0, 0, 0, 0};
    KuyrukBH q;
    char dizi[128], islem[64];
    if (!bh_olustur(&q, 4)) {
        exit(1);
    }
    printf("  (B) bir boş hücreli, kapasite 4 (5 hücre, %% 5 ile ilerler)\n");
    printf("    bas son boyut   fiziksel dizi    işlem\n");
    for (int k = 0; k < 14; k++) {
        int x;
        if (adim[k] > 0) {
            bool tamam = bh_ekle(&q, adim[k]);
            snprintf(islem, sizeof islem, "ekle %d%s", adim[k],
                     tamam ? "" : " -> dolu, reddedildi");
        } else if (bh_cikar(&q, &x)) {
            snprintf(islem, sizeof islem, "çıkar -> %d", x);
        } else {
            strcpy(islem, "çıkar -> boş, reddedildi");
        }
        if (bh_dolu_mu(&q)) {
            strcat(islem, "  [(son + 1) % 5 == bas: dolu]");
        }
        dizi_metni(dizi, q.veri, 5, q.bas, bh_boyut(&q));
        satir_yaz(q.bas, q.son, bh_boyut(&q), dizi, islem);
    }
    bh_yok_et(&q);
}

/* Kâhin: sarmayan, büyük bir dizi ve hiç azalmayan iki indis */
static void rastgele_sinama(int islem, int kapasite)
{
    Kuyruk q;
    KuyrukBH b;
    int *kahin = malloc((size_t)islem * sizeof *kahin);
    if (!kuyruk_olustur(&q, kapasite) || !bh_olustur(&b, kapasite) ||
        kahin == NULL) {
        exit(1);
    }
    int kbas = 0, kson = 0, uyusmazlik = 0, dolu = 0, bos = 0;
    long long sarma0 = sarma_sayisi;
    rastgele_tohum(42);
    for (int t = 0; t < islem; t++) {
        if (rastgele_aralik(0, 99) < 55) {
            int v = rastgele_aralik(0, 999);
            bool ra = kuyruk_ekle(&q, v), rb = bh_ekle(&b, v);
            bool rk = kson - kbas < kapasite;
            if (rk) {
                kahin[kson++] = v;
            }
            dolu += !rk;
            uyusmazlik += (ra != rk) || (rb != rk);
        } else {
            int xa = -1, xb = -1;
            bool ra = kuyruk_cikar(&q, &xa), rb = bh_cikar(&b, &xb);
            bool rk = kbas < kson;
            int xk = rk ? kahin[kbas++] : -1;
            bos += !rk;
            uyusmazlik += (ra != rk) || (rb != rk) || xa != xk || xb != xk;
        }
    }
    printf("  kapasite %4d (%s): dolu reddi %5d, boş reddi %5d, "
           "sarma %6lld, uyuşmazlık %d\n", kapasite,
           q.maskeli ? "maske" : "mod  ", dolu, bos,
           sarma_sayisi - sarma0, uyusmazlik);
    free(kahin);
    kuyruk_yok_et(&q);
    bh_yok_et(&b);
}

int main(void)
{
    printf("1) Adım adım: bas, son ve dolu/boş ayrımı\n");
    izle_sayacli();
    printf("\n");
    izle_bos_hucreli();

    printf("\n2) Rastgele 100000 işlem (%%55 ekle, tohum 42): (A) ve (B) "
           "kâhinle\n");
    rastgele_sinama(100000, 4);
    rastgele_sinama(100000, 6);
    rastgele_sinama(100000, 8);
    rastgele_sinama(100000, 1024);
    printf("  toplam (A): ekle = %lld, çıkar = %lld\n", ekle_sayisi,
           cikar_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int> (kap
 * uyarlayıcısı; varsayılan alttaki kap std::deque, kapasite sınırı yok);
 * Python — collections.deque (maxlen verilirse dolunca EN ESKİ eleman
 * sessizce atılır: taşma politikası "üzerine yaz"). */

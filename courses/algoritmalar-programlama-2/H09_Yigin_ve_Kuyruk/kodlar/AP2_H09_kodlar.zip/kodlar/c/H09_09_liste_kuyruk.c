/* H09_09_liste_kuyruk.c — AP-2 Hafta 9 · Örnek 9 (★)
 * Amaç    : Bağlı liste tabanlı kuyruk: baş (çıkarma) ve son (ekleme)
 *           işaretçileriyle iki işlem de O(1); son düğüm çıkarılınca son
 *           da NULL yapılır. Uygulamalar: katman katman işleme (BFS'ye
 *           köprü) ve sıcak patates (Josephus) sırası
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H09_09_liste_kuyruk.c \
 *           ortak_rastgele.c -o H09_09_liste_kuyruk
 * Çalıştır: ./H09_09_liste_kuyruk
 * Eşleri  : cpp/H09_09_liste_kuyruk.cpp · python/H09_09_liste_kuyruk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int deger;
    struct Dugum *sonraki;  /* baştan sona doğru */
} Dugum;

/* Kuyruk: bas en eski, son en yeni düğüm; boşken ikisi de NULL */
typedef struct {
    Dugum *bas;
    Dugum *son;
    int boyut;
} Kuyruk;

static long long ekle_sayisi = 0, cikar_sayisi = 0;
static long long ayrilan_dugum = 0, serbest_dugum = 0;

void kuyruk_olustur(Kuyruk *q)
{
    q->bas = q->son = NULL;
    q->boyut = 0;
}

/* Sahiplik: düğümler kuyruğundur; kalanlar burada serbest bırakılır */
void kuyruk_yok_et(Kuyruk *q)
{
    while (q->bas != NULL) {
        Dugum *d = q->bas;
        q->bas = d->sonraki;
        free(d);
        serbest_dugum++;
    }
    q->son = NULL;
    q->boyut = 0;
}

bool kuyruk_bos_mu(const Kuyruk *q) { return q->bas == NULL; }

/* Sona ekler; yalnızca malloc başarısız olursa false döner */
bool kuyruk_ekle(Kuyruk *q, int x)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return false;
    }
    ayrilan_dugum++;
    d->deger = x;
    d->sonraki = NULL;
    if (q->son == NULL) {
        q->bas = d;           /* boş kuyruk: ilk düğüm hem baş hem son */
    } else {
        q->son->sonraki = d;  /* eski sonun arkasına bağla */
    }
    q->son = d;
    q->boyut++;
    ekle_sayisi++;
    return true;
}

/* Baştan çıkarır; boş kuyrukta false döner */
bool kuyruk_cikar(Kuyruk *q, int *x)
{
    if (kuyruk_bos_mu(q)) {
        return false;
    }
    Dugum *d = q->bas;
    *x = d->deger;
    q->bas = d->sonraki;
    if (q->bas == NULL) {
        q->son = NULL;  /* boşaldı: son da NULL olmalı */
    }
    free(d);
    serbest_dugum++;
    q->boyut--;
    cikar_sayisi++;
    return true;
}

static void kuyruk_yaz(const Kuyruk *q)
{
    printf("baş [");
    for (const Dugum *d = q->bas; d != NULL; d = d->sonraki) {
        printf(d != q->bas ? " %d" : "%d", d->deger);
    }
    printf("] son");
    if (q->son == NULL) {
        printf("   (bas = son = NULL)");
    } else {
        printf("   (bas -> %d, son -> %d)", q->bas->deger, q->son->deger);
    }
    printf("\n");
}

/* Tam ikili ağacın düzey sırası: x'in çocukları 2x ve 2x + 1 */
static void katman_katman(int n)
{
    Kuyruk q;
    kuyruk_olustur(&q);
    kuyruk_ekle(&q, 1);
    int duzey = 0;
    while (!kuyruk_bos_mu(&q)) {
        int katman = q.boyut;  /* bu katmanda işlenecek eleman sayısı */
        printf("  düzey %d:", duzey);
        for (int k = 0; k < katman; k++) {
            int x;
            kuyruk_cikar(&q, &x);
            printf(" %d", x);
            if (2 * x <= n) {
                kuyruk_ekle(&q, 2 * x);
            }
            if (2 * x + 1 <= n) {
                kuyruk_ekle(&q, 2 * x + 1);
            }
        }
        printf("   (sırada bekleyen: %d)\n", q.boyut);
        duzey++;
    }
    kuyruk_yok_et(&q);
}

/* n kişi dairede; her k'ıncı kişi çıkar (kuyruğu döndürerek) */
static void sicak_patates(int n, int k)
{
    Kuyruk q;
    int x;
    kuyruk_olustur(&q);
    for (int i = 1; i <= n; i++) {
        kuyruk_ekle(&q, i);
    }
    printf("  n = %d, k = %d: çıkış sırası", n, k);
    while (q.boyut > 1) {
        for (int s = 1; s < k; s++) {
            kuyruk_cikar(&q, &x);  /* baştakini sona aktar */
            kuyruk_ekle(&q, x);
        }
        kuyruk_cikar(&q, &x);
        printf(" %d", x);
    }
    kuyruk_cikar(&q, &x);
    printf("; kalan %d\n", x);
    kuyruk_yok_et(&q);
}

/* Kâhin: sarmayan büyük dizi ve hiç azalmayan iki indis */
static void rastgele_sinama(int islem)
{
    Kuyruk q;
    kuyruk_olustur(&q);
    int *kahin = malloc((size_t)islem * sizeof *kahin);
    if (kahin == NULL) {
        exit(1);
    }
    int kbas = 0, kson = 0, uyusmazlik = 0, bos = 0, en_buyuk = 0;
    rastgele_tohum(42);
    for (int t = 0; t < islem; t++) {
        if (rastgele_aralik(0, 99) < 52) {
            int v = rastgele_aralik(0, 999);
            kuyruk_ekle(&q, v);
            kahin[kson++] = v;
        } else {
            int x = -1;
            bool tamam = kuyruk_cikar(&q, &x);
            bool rk = kbas < kson;
            int xk = rk ? kahin[kbas++] : -1;
            bos += !rk;
            uyusmazlik += (tamam != rk) || x != xk;
        }
        uyusmazlik += (q.boyut != kson - kbas) ||
                      ((q.boyut == 0) != (q.son == NULL));
        if (q.boyut > en_buyuk) {
            en_buyuk = q.boyut;
        }
    }
    printf("  %d işlem: boş reddi %d, en büyük boyut %d, son boyut %d, "
           "kâhinle uyuşmazlık %d\n", islem, bos, en_buyuk, q.boyut,
           uyusmazlik);
    free(kahin);
    kuyruk_yok_et(&q);
}

int main(void)
{
    Kuyruk q;
    int x;
    kuyruk_olustur(&q);
    printf("1) Ekle 10, 20, 30; çıkar; ekle 40; tümünü çıkar; yeniden "
           "ekle\n  ");
    kuyruk_yaz(&q);
    for (int k = 1; k <= 3; k++) {
        kuyruk_ekle(&q, 10 * k);
        printf("  ekle %d   -> ", 10 * k);
        kuyruk_yaz(&q);
    }
    kuyruk_cikar(&q, &x);
    printf("  çıkar %d  -> ", x);
    kuyruk_yaz(&q);
    kuyruk_ekle(&q, 40);
    printf("  ekle 40   -> ");
    kuyruk_yaz(&q);
    while (kuyruk_cikar(&q, &x)) {
        printf("  çıkar %d  -> ", x);
        kuyruk_yaz(&q);
    }
    printf("  çıkar     -> %s\n", kuyruk_cikar(&q, &x)
                                      ? "?" : "HAYIR (boş kuyruk)");
    kuyruk_ekle(&q, 50);
    printf("  ekle 50   -> ");
    kuyruk_yaz(&q);
    kuyruk_yok_et(&q);

    printf("\n2) Katman katman işleme: 1'den başla, x'in ardılları 2x ve "
           "2x + 1 (<= 15)\n");
    katman_katman(15);

    printf("\n3) Sıcak patates (Josephus): kuyruğu döndürerek eleme\n");
    sicak_patates(7, 3);
    sicak_patates(10, 2);

    printf("\n4) Rastgele 100000 işlem (%%52 ekle, tohum 42) ve kâhin\n");
    rastgele_sinama(100000);
    printf("  toplam: ekle = %lld, çıkar = %lld; düğüm ayrılan = %lld, "
           "serbest = %lld\n", ekle_sayisi, cikar_sayisi, ayrilan_dugum,
           serbest_dugum);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::queue<int,
 * std::list<int>> ya da varsayılan std::queue<int> (alttaki kap std::deque);
 * Python — collections.deque (append/popleft) ya da iş parçacığı güvenli
 * queue.Queue. */

/* H09_14_histogram_dikdortgen.c — AP-2 Hafta 9 · Örnek 14 (★★★)
 * Amaç    : (Meydan okuma) Histogramdaki en büyük dikdörtgen: yükseklikleri
 *           artan sırada tutan monotonik yığın; bir çubuk çıkarıldığında
 *           solundaki ilk kısa çubuk yığında altındaki, sağındaki ilk kısa
 *           çubuk o anki i'dir → genişlik = i - sol - 1. Θ(n); O(n^2)
 *           kâhinle sınanır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H09_14_histogram_dikdortgen.c ortak_rastgele.c \
 *           -o H09_14_histogram_dikdortgen
 * Çalıştır: ./H09_14_histogram_dikdortgen
 * Eşleri  : cpp/H09_14_histogram_dikdortgen.cpp ·
 *           python/H09_14_histogram_dikdortgen.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

typedef struct {
    int *veri;  /* çubuk indisleri; yükseklikleri tabandan tepeye artar */
    int kapasite;
    int boyut;
} Yigin;

static long long it_sayisi = 0, cikar_sayisi = 0, karsilastirma = 0;
static int en_buyuk_derinlik = 0;

static void sayaclari_sifirla(void)
{
    it_sayisi = cikar_sayisi = karsilastirma = 0;
    en_buyuk_derinlik = 0;
}

/* Sahiplik: y->veri burada ayrılır; yigin_yok_et ile serbest bırakılır. */
static bool yigin_olustur(Yigin *y, int kapasite)
{
    y->veri = malloc((size_t)(kapasite > 0 ? kapasite : 1) * sizeof *y->veri);
    y->kapasite = (y->veri != NULL) ? kapasite : 0;
    y->boyut = 0;
    return y->veri != NULL;
}

static void yigin_yok_et(Yigin *y)
{
    free(y->veri);
    y->veri = NULL;
}

static void yigin_it(Yigin *y, int i)
{
    y->veri[y->boyut++] = i;
    it_sayisi++;
    if (y->boyut > en_buyuk_derinlik) {
        en_buyuk_derinlik = y->boyut;
    }
}

static int yigin_cikar(Yigin *y)
{
    cikar_sayisi++;
    return y->veri[--y->boyut];
}

static bool buyuk_esit_mi(int x, int y)
{
    karsilastirma++;
    return x >= y;
}

/* h[0..n-1] histogramındaki en büyük dikdörtgenin alanı */
long long en_buyuk_dikdortgen(const int *h, int n, bool iz)
{
    Yigin y;
    long long en_iyi = 0;
    char cikan[256];
    if (!yigin_olustur(&y, n)) {
        exit(1);
    }
    for (int i = 0; i <= n; i++) {
        int yuk = (i == n) ? 0 : h[i];  /* i == n: tüm yığını boşaltan bekçi */
        cikan[0] = '\0';
        while (y.boyut > 0 && buyuk_esit_mi(h[y.veri[y.boyut - 1]], yuk)) {
            int t = yigin_cikar(&y);
            int sol = (y.boyut > 0) ? y.veri[y.boyut - 1] : -1;
            long long alan = (long long)h[t] * (i - sol - 1);
            if (alan > en_iyi) {
                en_iyi = alan;
            }
            snprintf(cikan + strlen(cikan), sizeof cikan - strlen(cikan),
                     "%s%dx%d=%lld", cikan[0] != '\0' ? " " : "", h[t],
                     i - sol - 1, alan);
        }
        if (i < n) {
            yigin_it(&y, i);
        }
        if (iz) {
            char ic[128] = "[";
            for (int q = 0; q < y.boyut; q++) {
                snprintf(ic + strlen(ic), sizeof ic - strlen(ic), "%s%d",
                         q > 0 ? " " : "", h[y.veri[q]]);
            }
            strcat(ic, "]");
            if (i < n) {
                printf("  %2d %4d   %-14s %4lld   %s\n", i, yuk, ic, en_iyi,
                       cikan[0] != '\0' ? cikan : "-");
            } else {
                printf("  son  (0)  %-14s %4lld   %s\n", ic, en_iyi, cikan);
            }
        }
    }
    yigin_yok_et(&y);
    return en_iyi;
}

/* Kâhin: her sol uç için en kısa çubuğu taşıyarak sağa genişlet, O(n^2) */
static long long kaba_kuvvet(const int *h, int n)
{
    long long en_iyi = 0;
    for (int i = 0; i < n; i++) {
        int en_kisa = h[i];
        for (int j = i; j < n; j++) {
            if (h[j] < en_kisa) {
                en_kisa = h[j];
            }
            long long alan = (long long)en_kisa * (j - i + 1);
            if (alan > en_iyi) {
                en_iyi = alan;
            }
        }
    }
    return en_iyi;
}

int main(void)
{
    const int h[] = {2, 4, 3, 5, 1, 4, 4, 2};
    printf("1) İzleme: h = [2 4 3 5 1 4 4 2] (çıkan çubuk: yükseklik x "
           "genişlik = alan)\n");
    printf("   i    h   yığın (yük.)   en iyi  çıkanlar\n");
    sayaclari_sifirla();
    long long alan = en_buyuk_dikdortgen(h, 8, true);
    printf("  en büyük alan = %lld (kâhin %lld); it = %lld, çıkar = %lld, "
           "karşılaştırma = %lld\n", alan, kaba_kuvvet(h, 8), it_sayisi,
           cikar_sayisi, karsilastirma);

    printf("\n2) Rastgele 2000 histogram (n = 0..60, yükseklik 0..30, tohum "
           "42) ve kâhin\n");
    int dizi[60], uyusmazlik = 0, ihlal = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 2000; t++) {
        int n = rastgele_aralik(0, 60);
        for (int i = 0; i < n; i++) {
            dizi[i] = rastgele_aralik(0, 30);
        }
        sayaclari_sifirla();
        uyusmazlik += en_buyuk_dikdortgen(dizi, n, false) !=
                      kaba_kuvvet(dizi, n);
        ihlal += (it_sayisi + cikar_sayisi > 2LL * n);
    }
    printf("  kâhinle uyuşmazlık = %d, it + çıkar > 2n = %d\n", uyusmazlik,
           ihlal);

    printf("\n3) Büyük girdiler (n = 100000): karşılaştırma <= 2n\n");
    printf("  girdi           en büyük alan  karş./n  derinlik\n");
    int n = 100000;
    int *b = malloc((size_t)n * sizeof *b);
    if (b == NULL) {
        return 1;
    }
    const char *ad[] = {"rastgele 0..10^4", "artan           ",
                        "azalan          ", "sabit 7         "};
    rastgele_tohum(42);
    for (int tur = 0; tur < 4; tur++) {
        for (int i = 0; i < n; i++) {
            if (tur == 0) {
                b[i] = rastgele_aralik(0, 10000);
            } else {
                b[i] = (tur == 1) ? i + 1 : (tur == 2) ? n - i : 7;
            }
        }
        sayaclari_sifirla();
        alan = en_buyuk_dikdortgen(b, n, false);
        printf("  %s %14lld %8.3f %9d\n", ad[tur], alan,
               (double)karsilastirma / n, en_buyuk_derinlik);
    }
    free(b);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::stack<int> ile
 * aynı algoritma); Python — yok (list yığın olarak). İki boyutlu sürüm
 * (0/1 matriste en büyük dolu dikdörtgen) her satırı bir histogram sayar. */

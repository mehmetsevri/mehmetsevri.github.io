# Hafta 9 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı ve beklenen çıktısıyla aşağıdadır. **Ders notu** sütunu dosyanın kodunun ya da adının geçtiği bölümleri (Ek A: dil karşılıkları), **Sunum** sütunu slayt numaralarını, **Web** sütunu web sayfasındaki bölüm kimliklerini (`h09-…`) verir; değerler üretilmiş materyalden betikle çıkarıldı. Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11.15 (örnekler 3.10 uyumludur; 3.10, 3.12 ve 3.13 ile de aynı çıktı).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] -o program -lm` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py [< ../girdiler/KÖK.txt]`. Girdi dosyası olan örnekler standart girdiden okur (aşağıdaki **Girdi** sütunu).

Eşdeğerlik: `python3 esdeger_test.py .` → **14/14 GEÇTİ** (14 “=”: üç dilde bayt bayt aynı stdout; Δ 0), derleyici uyarısı 0; `--asan` (AddressSanitizer + UBSan + LSan) ile 14/14 GEÇTİ. Valgrind ve merdiven dışı programların sanitizer denetimi: `BELLEK_DENETIMI.txt` (TÜMÜ TEMİZ).


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Girdi | Argüman / çıkış kodu | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|---|
| `H09_01_dizi_yigin` | ★ | = | evet | Dizi tabanlı yığın (sabit kapasite): it, çıkar, tepe; taşma ve alt taşma dönüş koduyla | — | — | 1.1, 2, 4.1, 11.6, Ek A.1 | 12 | `baglanti`, `kuyruk`, `yigin` |
| `H09_02_liste_yigin` | ★ | = | evet | Liste tabanlı yığın (sınırsız): aynı arayüz, farklı gerçekleştirim; düğüm sayaçları ve kâhinli sınama | — | — | 1.1, 2, 4.1, Ek A.2 | 14 | `baglanti`, `yigin` |
| `H09_03_parantez_denetimi` | ★★ | = | evet | Parantez denetimi ( ) [ ] { }: ilk hatanın konumu ve türü (eşleşmeyen kapanış, tür uyuşmazlığı, açık kalan) | `girdiler/H09_03_parantez_denetimi.txt` | — | 1.1, 4.3, 11.3, 11.4, Ek A, Ek A.3 | 20 | `alistirmalar`, `parantez` |
| `H09_04_sonek_degerlendirme` | ★★ | = | evet | Sonek (RPN) değerlendirme: işlenen yığını, a − b sırası, sıfıra bölme, eksik/fazla işlenen ve taşma hataları | `girdiler/H09_04_sonek_degerlendirme.txt` | — | 1.1, 2, 4.4, 5.1, 7, 11.9, Ek A, Ek A.4 | 24, 27, 34 | `alistirmalar`, `baglanti`, `sonek` |
| `H09_05_shunting_yard` | ★★★ | = | evet | Shunting-yard: araek → sonek; öncelik ve birleşme yönü tablosu (^ sağdan), tekli eksi (~), sözdizimi hataları | `girdiler/H09_05_shunting_yard.txt` | — | 1, 1.1, 3.4, 4.5, 11.1, 11.8, Ek A.5 | 5, 28, 33 | `alistirmalar`, `buyuk-soru`, `quiz`, `shunting`, `sonek` |
| `H09_06_hesap_makinesi` | ★★★ | = | — | Basit hesap makinesi: Shunting-yard + sonek değerlendirme; hata iletileri ve çıkış kodları (0/1/2) üç dilde aynı | `girdiler/H09_06_hesap_makinesi.txt` | çıkış 1 (tasarım gereği) | 1, 1.1, 2, 4.4, 4.5, 5, 5.1, 11.9, Ek A, Ek A.6 | 5, 34 | `alistirmalar`, `baglanti`, `buyuk-soru`, `quiz`, `shunting`, `sonek` |
| `H09_07_geri_al_yinele` | ★★ | = | — | Geri al / yinele: iki yığın; yeni işlem yinele yığınını boşaltır; durum geçmişi kâhiniyle rastgele sınama | `girdiler/H09_07_geri_al_yinele.txt` | — | 3.2, 5, 5.2, 10, Ek A.7 | 35 | `geri-al`, `mini-obs` |
| `H09_08_dairesel_kuyruk` | ★★ | = | evet | Dairesel tampon kuyruk: bas/son, mod ve bit maskesi; dolu/boş ayrımı sayaçla ve bir boş hücreyle | — | — | 1.1, 3.5, 4.2, 5.4, 7, 9, 10, 11.6, Ek A.8 | 15, 17, 18, 50 | `alistirmalar`, `gise`, `hata-avcisi`, `kuyruk`, `mini-obs`, `muhendis`, `quiz` |
| `H09_09_liste_kuyruk` | ★ | = | — | Liste tabanlı kuyruk: baş ve son işaretçisi; katman katman işleme ve sıcak patates (Josephus) | — | — | 1.1, 2, 3.3, 4.2, 5, 5.3, Ek A.9 | 19 | `baglanti`, `kuyruk` |
| `H09_10_gise_simulasyonu` | ★★ | = | — | Kayıt gişesi simülasyonu: k gişe, tek FIFO kuyruk, ortak LCG; bekleme, kuyruk uzunluğu, doluluk ve Little yasası | — | — | 1.1, 3.3, 5, 5.4, 6.1, 6.6, 9, 10, 11.10, Ek A.10 | 45, 50 | `alistirmalar`, `gise`, `mini-obs`, `muhendis` |
| `H09_11_sonraki_buyuk` | ★★★ | = | evet | Monotonik yığın: sonraki büyük eleman, it + çıkar ≤ 2n; O(n²) kaba kuvvet kâhinle sınama | — | — | 1.1, 4.6, 11.2, Ek A.11 | 36 | `alistirmalar`, `monotonik`, `quiz` |
| `H09_12_yiginli_hizli_siralama` | ★★★ | = | — | Özyinelemesiz hızlı sıralama: açık yığın, büyük parça itilir → derinlik ≤ ⌊log₂ n⌋ + 1; özyinelemeli sürümle karşılaştırma | — | — | 4.8, 9, Ek A.12 | 42 | `acik-yigin` |
| `H09_13_kayan_pencere` | ★★★ | = | evet | İki uçlu kuyrukla (elle, dairesel tampon) kayan pencere en büyüğü: monotonik deque, Θ(n) ve O(k) bellek | — | — | 1.1, 3.1, 3.3, 4.2, 4.7, 8, 11.3, 11.6, Ek A.13 | 39 | `alistirmalar`, `dil`, `kayan-pencere`, `quiz`, `yigin` |
| `H09_14_histogram_dikdortgen` | ★★★ | = | — | Meydan okuma: histogramdaki en büyük dikdörtgen (monotonik yığın, Θ(n)); O(n²) kâhinle sınama | — | — | 13, Ek A.14 | 51 | `monotonik` |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt`. C++/Python'da C'den anlam olarak farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`. H09_06 hesap makinesi girdi dosyasındaki hatalı ifadeler yüzünden 1 ile çıkar (`ornekler.json`: `"cikis": 1`); komut satırından tek ifadeyle çalıştırıldığında çıkış kodları 0 (geçerli), 1 (değerlendirme hatası), 2 (kullanım).

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`. Kullananlar: ortak_rastgele — Örnek 1, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14; zamanlayici — merdivende yok (yalnızca deney/).


## 2. Kavram programları (kavram/)

Merdiven dışı küçük programlar: opak tip, bayt kodu, çağrı yığını, ızgara dolaşma, mod ve maske, kapsülleme, kütüphane karşılıkları. Çıktılar `kavram/ciktilar/` (ortam satırı, derleme komutu ve çıkış koduyla).

| Dosya | Dil | Amaç | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H09_K01_opak_yigin/main.c` | C | Opak yığını kullanan program. Yalnızca yigin.h'yi bilir; AYNI main.c iki gerçekleştirimle de derlenir ve stdout'a AYNI çıktıyı yazar (arayüz–gerçekleştirim ayrımı). Hangi gerçekleştirimin bağlandığı stderr'e yazılır. | `ciktilar/H09_K01_opak_yigin_dizi.txt`, `ciktilar/H09_K01_opak_yigin_karsilastirma.txt`, `ciktilar/H09_K01_opak_yigin_liste.txt` | 2, 3.1, 4.1, 7, 9, 12 | 10 | `baglanti`, `muhendis`, `yigin` |
| `kavram/H09_K01_opak_yigin/opak_ihlal.c` | C | Opak tipin korunması. KASITLI DERLEME HATASI İÇERİR — bu hâliyle derlenmez. Kullanıcı kodu struct Yigin'in alanlarına erişmeye ya da boyutunu almaya çalışınca derleyici durdurur: alanlar yalnızca yigin_dizi.c / yigin_liste.c'de tanımlıdır. Derleyici iletisi: ../ciktilar/H09_K01_opak_ihlal.txt | `ciktilar/H09_K01_opak_ihlal.txt` | 2, 3.1, 4.1, 7, 9, 12 | 10 | `baglanti`, `muhendis`, `yigin` |
| `kavram/H09_K01_opak_yigin/yigin.h` | C (başlık) | Opak tip ile yığın ADT'si (arayüz). Kullanıcı yalnızca bu dosyayı görür: struct Yigin'in alanları burada YOKTUR (eksik tip, incomplete type). Gerçekleştirim yigin_dizi.c ya da yigin_liste.c'dedir; ikisi de AYNI sözleşmeyi sağlar. | — | 2, 3.1, 4.1, 7, 9, 12 | 10 | `baglanti`, `muhendis`, `yigin` |
| `kavram/H09_K01_opak_yigin/yigin_dizi.c` | C | yigin.h'nin DİZİ gerçekleştirimi. Dinamik dizi (H8): dolunca kapasite iki katına çıkar → it amortize O(1). struct Yigin'in alanları yalnızca bu dosyada görünür. | — | 2, 3.1, 4.1, 7, 9, 12 | 10 | `baglanti`, `muhendis`, `yigin` |
| `kavram/H09_K01_opak_yigin/yigin_liste.c` | C | yigin.h'nin LİSTE gerçekleştirimi. Tek bağlı liste: tepe = listenin başı; it ve çıkar O(1) (her it bir malloc). struct Yigin'in alanları yalnızca bu dosyada görünür. | — | 2, 3.1, 4.1, 7, 9, 12 | 10 | `baglanti`, `muhendis`, `yigin` |
| `kavram/H09_K02_dis_bayt_kodu.py` | Python | CPython bir YIĞIN MAKİNESİdir: a + b * c ifadesinin bayt kodu (dis modülü) ve her komuttan sonra işlenen yığınının içeriği; sabit ifade 3 + 4 * 2 derleme anında 11'e katlanır. Çıktı Python sürümüne bağlıdır (3.10'da BINARY_MULTIPLY/BINARY_ADD, 3.11'de BINARY_OP); kavram/ciktilar/ altındaki dosyalar sürüm adıyla etiketlidir. | `ciktilar/H09_K02_dis_bayt_kodu_py310.txt`, `ciktilar/H09_K02_dis_bayt_kodu_py311.txt` | 3.5 | 44 | `acik-yigin` |
| `kavram/H09_K03_cagri_yigini.c` | C | Özyineleme örtük bir yığındır: toplam(n) = n + toplam(n - 1) her çağrıda çağrı yığınına bir çerçeve iter. Aynı hesap açık yığınla (öbekte ayrılan dizi) derinlik sınırına takılmadan yapılır. | `ciktilar/H09_K03_cagri_yigini_c.txt` | 3.5, 9 | 43 | `acik-yigin` |
| `kavram/H09_K03_cagri_yigini.cpp` | C++ | C sürümünün C++ karşılığı: özyinelemeli toplam(n) çağrı yığınını kullanır; açık yığın std::vector'deki (öbekte) bir dizidir. C++ de derinlik sınırı koymaz: taşma yığın boyutuna (ulimit -s) bağlıdır ve istisna değil çökmedir. | `ciktilar/H09_K03_cagri_yigini_cpp.txt` | 3.5, 9 | 43 | `acik-yigin` |
| `kavram/H09_K03_cagri_yigini.py` | Python | Özyineleme örtük bir yığındır: toplam(n) = n + toplam(n - 1) her çağrıda bir çerçeve iter. CPython çerçeve sayısını sys.getrecursionlimit() (varsayılan 1000) ile sınırlar ve aşılınca RecursionError verir; açık yığınla aynı hesap sınırsızdır. | `ciktilar/H09_K03_cagri_yigini_py.txt` | 3.5, 9 | 43 | `acik-yigin` |
| `kavram/H09_K04_izgara_dolasma.c` | C | Izgarada bölge doldurma (flood fill) üç biçimde: özyinelemeli (örtük çağrı yığını), açık yığınla (derinlik öncelikli) ve kuyrukla (genişlik öncelikli: katman katman uzaklık). Aynı bölgeler bulunur; ziyaret SIRASI ve bellek kullanımı farklıdır. | `ciktilar/H09_K04_izgara_dolasma_c.txt` | 4.8, 13 | 42, 51 | `acik-yigin`, `ileri` |
| `kavram/H09_K04_izgara_dolasma.py` | Python | Izgarada bölge doldurma (flood fill) üç biçimde: özyinelemeli (örtük çağrı yığını), açık yığınla (derinlik öncelikli) ve kuyrukla (genişlik öncelikli: katman katman uzaklık). C sürümüyle aynı çıktı. | `ciktilar/H09_K04_izgara_dolasma_py.txt` | 4.8, 13 | 42, 51 | `acik-yigin`, `ileri` |
| `kavram/H09_K05_mod_maske.c` | C | Kapasite 2'nin kuvvetiyse dairesel tamponda (i + 1) % kapasite ile (i + 1) & (kapasite - 1) aynıdır (negatif olmayan i için): kapasite - 1'in ikilik yazımı ...0111'dir ve & yalnızca alt bitleri bırakır. 2'nin kuvveti olmayan kapasitede eşdeğerlik bozulur. Negatif sayıda C'nin % işleci negatif kalan verir. | `ciktilar/H09_K05_mod_maske_c.txt` | 3.5 | 18 | `kuyruk` |
| `kavram/H09_K05_mod_maske.py` | Python | Kapasite 2'nin kuvvetiyse (i + 1) % kapasite ile (i + 1) & (kapasite - 1) aynıdır. Python'da % taban bölmesinin kalanıdır: -1 % 8 == 7 (C'de -1); Python tamsayıları sonsuz ikiye tümleyen gibi davrandığından -1 & 7 de 7'dir. | `ciktilar/H09_K05_mod_maske_py.txt` | 3.5 | 18 | `kuyruk` |
| `kavram/H09_K06_kapsulleme.cpp` | C++ | C'deki opak struct'ın (K01) C++ karşılığı: sınıf ve private üyeler. Arayüz (public üye fonksiyonlar) sabit kalırken gerçekleştirim gizlenir; private alana dışarıdan erişim DERLEME HATASIDIR (aşağıdaki yorumlu satır). Hata bildirimi: bool dönüş kodu ya da istisna (std::out_of_range). | `ciktilar/H09_K06_kapsulleme_cpp.txt` | 8 | — | `dil` |
| `kavram/H09_K06_kapsulleme.py` | Python | Python'da erişim denetimi yoktur; "gizli" alanlar adlandırma geleneğiyle belirtilir: _alan ("dokunma" anlamında bir uyarı), __alan (ad bozma, name mangling: _Sinif__alan olur). Hata bildirimi istisnayla (IndexError). | `ciktilar/H09_K06_kapsulleme_py.txt` | 8 | — | `dil` |
| `kavram/H09_K07_kutuphane.cpp` | C++ | Kütüphane karşılıkları (merdivende yalnızca kâhin ve dosya sonu notunda geçenler): std::stack ve std::queue KAP UYARLAYICILARIdır (alttaki kap varsayılan olarak std::deque; değiştirilebilir); std::deque iki uçtan O(1) ekleme/çıkarma sağlar. Boş std::stack üzerinde pop()/top() TANIMSIZ DAVRANIŞTIR (denetim yok) — bu yüzden önce empty() sorulur; deque::at() ise std::out_of_range atar. | `ciktilar/H09_K07_kutuphane_cpp.txt` | 8 | — | `dil` |
| `kavram/H09_K07_kutuphane.py` | Python | Kütüphane karşılıkları (merdivende yalnızca kâhin ve dosya sonu notunda geçenler): list yığın olarak (append/pop, sona O(1)), collections.deque (iki uçtan O(1); maxlen ile sınırlı tampon: dolunca EN ESKİ eleman sessizce atılır) ve iş parçacığı güvenli queue.Queue / queue.LifoQueue. Boş listede pop() IndexError verir. | `ciktilar/H09_K07_kutuphane_py.txt` | 8 | — | `dil` |
| `kavram/H09_K08_etiket_dengesi.c` | C | Parantez denetiminin (Örnek 3) etiketlere genellenmesi: <ad> açılış, </ad> kapanış, <ad/> kendini kapatan etiket (yığına girmez). Yığında etiket adları tutulur; kapanış tepedeki adla aynı olmalıdır. (HTML'in gerçek kuralları daha karmaşıktır: bazı etiketler kapanış gerektirmez.) | `ciktilar/H09_K08_etiket_dengesi_c.txt` | 4.3 | 23 | `parantez` |
| `kavram/H09_K08_etiket_dengesi.py` | Python | Parantez denetiminin (Örnek 3) etiketlere genellenmesi: <ad> açılış, </ad> kapanış, <ad/> kendini kapatan etiket (yığına girmez). C sürümüyle aynı çıktı; yığın elle (sabit liste + boyut). | `ciktilar/H09_K08_etiket_dengesi_py.txt` | 4.3 | 23 | `parantez` |
| `kavram/H09_K09_tarayici_gecmisi.c` | C | Tarayıcının geri/ileri düğmeleri iki yığındır (Örnek 7'deki geri al/yinele ile aynı desen): yeni sayfaya gidince eski sayfa geri yığınına itilir ve ileri yığını boşaltılır. | `ciktilar/H09_K09_tarayici_gecmisi_c.txt` | 3.2 | — | `yigin` |
| `kavram/H09_K09_tarayici_gecmisi.py` | Python | Tarayıcının geri/ileri düğmeleri iki yığındır (Örnek 7 ile aynı desen): yeni sayfaya gidince eski sayfa geri yığınına itilir ve ileri yığını boşaltılır. C sürümüyle aynı çıktı. | `ciktilar/H09_K09_tarayici_gecmisi_py.txt` | 3.2 | — | `yigin` |
| `kavram/H09_K10_bolme_tanimi.c` | C | Tamsayı bölmesi ve kalan: C bölümü sıfıra doğru keser (7 / -2 = -3), kalanın işareti bölünenin işaretidir; Örnek 4 ve 6'daki hesap makinesi üç dilde bu tanımı kullanır | `ciktilar/H09_K10_bolme_tanimi_c.txt` | 8 | — | `shunting` |
| `kavram/H09_K10_bolme_tanimi.py` | Python | Python'da // aşağı yuvarlar (7 // -2 = -4) ve % bölenin işaretini alır; C'nin kesmesi kesik_bol ile elle kurulur (Örnek 4 ve 6 bu fonksiyonu kullanır). int(a / b) kayan noktaya gider ve büyük sayılarda yanlış sonuç verebilir | `ciktilar/H09_K10_bolme_tanimi_py.txt` | 8 | — | `shunting` |

## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir (hata mantıksaldır; HA1 ve HA6'nın C sürümü sınır dışı erişimle TANIMSIZ DAVRANIŞTIR, açıkça işaretlidir). Bu makinede gözlenen belirtiler `hata_avcisi/ciktilar/` altındadır (ASan ve Valgrind raporları sadeleştirilmiş: süreç numarası ve adresler gizli).

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H09_HA1_bos_yigindan_cikar.c` | C | kasıtlı hata | Boş yığından çıkarmada alt taşma denetimi yok: C'de veri[-1] okunur (bu çalıştırmada 5. çıkarma 0, boyut −1, sonda SIGABRT; ASan: heap-buffer-overflow); Python'da negatif indis sessizce son hücreyi verir (5. çıkarma 40) | `ciktilar/H09_HA1_bos_yigindan_cikar_c.txt`, `ciktilar/H09_HA1_bos_yigindan_cikar_asan.txt`, `ciktilar/H09_HA1_bos_yigindan_cikar_valgrind.txt` | 4.1, 7, 9, 12 | — | `muhendis` |
| `hata_avcisi/H09_HA1_bos_yigindan_cikar_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H09_HA1_bos_yigindan_cikar_duzeltilmis_c.txt` | — | — | — |
| `hata_avcisi/H09_HA1_bos_yigindan_cikar.py` | Python | kasıtlı hata | Boş yığından çıkarmada alt taşma denetimi yok: C'de veri[-1] okunur (bu çalıştırmada 5. çıkarma 0, boyut −1, sonda SIGABRT; ASan: heap-buffer-overflow); Python'da negatif indis sessizce son hücreyi verir (5. çıkarma 40) | `ciktilar/H09_HA1_bos_yigindan_cikar_py.txt` | 4.1, 7, 9, 12 | — | `muhendis` |
| `hata_avcisi/H09_HA1_bos_yigindan_cikar_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H09_HA1_bos_yigindan_cikar_duzeltilmis_py.txt` | — | — | — |
| `hata_avcisi/H09_HA2_bas_esit_son.c` | C | kasıtlı hata | Dairesel kuyrukta yalnızca bas == son ile boşluk denetimi: 4 eleman eklenince kuyruk boş görünür, sonraki eklemeyle eski elemanlar kaybolur (çıkarılanlar: 50; 10 20 30 40 50 bekleniyordu) | `ciktilar/H09_HA2_bas_esit_son.txt` | 1.1, 4.2, 12 | — | `kuyruk` |
| `hata_avcisi/H09_HA2_bas_esit_son_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H09_HA2_bas_esit_son_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H09_HA3_us_soldan.cpp` | C++ | kasıtlı hata | Shunting-yard'da ^ soldan birleşmeli işlenir: 2 ^ 3 ^ 2 = 64 (doğrusu 512) | `ciktilar/H09_HA3_us_soldan.txt` | 4.5, 11.8, 12 | 48 | `quiz`, `shunting` |
| `hata_avcisi/H09_HA3_us_soldan_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H09_HA3_us_soldan_duzeltilmis.txt` | — | 48 | — |
| `hata_avcisi/H09_HA4_islenen_sirasi.c` | C | kasıtlı hata | Sonek değerlendirmede işlenen sırası ters (b ∘ a): 10 3 - = -7; 6 ifadenin 4'ünde yanlış sonuç (+ ve * değişmeli olduğu için doğru görünür) | `ciktilar/H09_HA4_islenen_sirasi.txt` | 7, 12 | 26 | `hata-avcisi`, `quiz`, `sonek` |
| `hata_avcisi/H09_HA4_islenen_sirasi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H09_HA4_islenen_sirasi_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H09_HA5_pop0_kuyruk.py` | Python | kasıtlı hata | list.pop(0) ile kuyruk: her çıkarma tüm elemanları kaydırır; n iki katına çıkınca süre 4,47; 3,38; 4,32 katına çıkar (karesel) | `ciktilar/H09_HA5_pop0_kuyruk.txt` | 6.6 | — | `quiz` |
| `hata_avcisi/H09_HA5_pop0_kuyruk_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H09_HA5_pop0_kuyruk_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H09_HA6_kapasite_asimi.c` | C | kasıtlı hata | Dizi tabanlı yığında taşma denetimi yok: kapasite 4'e 10 eleman itilir, komşu öbek bloğu bozulur (bu çalıştırmada "Z", sonda SIGABRT; ASan: heap-buffer-overflow) | `ciktilar/H09_HA6_kapasite_asimi_c.txt`, `ciktilar/H09_HA6_kapasite_asimi_asan.txt`, `ciktilar/H09_HA6_kapasite_asimi_valgrind.txt` | 4.1, 7, 9, 12 | — | `muhendis` |
| `hata_avcisi/H09_HA6_kapasite_asimi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H09_HA6_kapasite_asimi_duzeltilmis_c.txt` | — | — | — |

## 4. Haftanın Deneyi (deney/)

| Dosya | Görev |
|---|---|
| `deney/c/H09_deney_kuyruk.c` | C ölçüm programı: `izgara` (gişe, k = 1..4 × ρ × tohum), `sabit` (sabit geliş hızı), `tek` (tek nokta), `kuyruk TUR N TEKRAR` (kaydirmali · dairesel); stdout deterministik, süreler stderr'de |
| `deney/cpp/H09_deney_kuyruk.cpp` | C++ eşi (gişe CSV'si C ile bayt bayt aynı) |
| `deney/python/H09_deney_kuyruk.py` | Python eşi; kuyruk türlerine ek olarak `pop0` (list.pop(0)) ve `deque` (collections.deque.popleft) — etiketli kütüphane serileri |
| `deney/h09_olcum_calistir.py` | Sürücü: derler, gişe ızgarasını ve kuyruk ölçümlerini çalıştırır (1 ısınma + 5 tekrar, ortanca; tutarsız ölçümü yineler; süre bütçesi aşılacaksa ölçmez, kestirim yazar); `--ikinci-oturum`, `--devam`, `--hizli` |
| `deney/h09_cozumle.py` | Çözümleme: ortalama/en az/en çok bekleme, Little denetimi, M/M/1 ve M/G/1 (Pollaczek–Khinchine) karşılaştırması, katlar, log–log eğimler (`sonuclar/h09_ozet_*.csv`, `h09_ozet_sayim.json`) |
| `deney/sonuclar/h09_deney_gise.csv` | Ham veri: gişe ızgarası (k, ρ, tohum; 2 000 000 s benzetim) |
| `deney/sonuclar/h09_deney_gise_sabit.csv` | Ham veri: sabit geliş hızında (saatte 12–48 öğrenci) k = 1..4 |
| `deney/sonuclar/h09_deney_gise_dogrulama.csv` | Python ile C'nin aynı satırı ürettiğinin denetimi (k = 1..4, ρ = 0,90) |
| `deney/sonuclar/h09_deney_kuyruk.csv` | Ham ölçüm: kuyruk gerçekleştirimleri × n (işlemci ve duvar saati ortancası; kestirimler işaretli) |
| `deney/sonuclar/h09_ham.jsonl` | Tüm oturumların ham kayıtları |
| `deney/OLCUM_ORTAMI.txt` | Makine, derleyici, yöntem, yük ortalaması, süre |

Grafikler `../gorseller/h09_deney_*_{belge,sunum}.png` (kaynak `../gorseller/kaynak/h09_deney_grafik.py`). Deney programları ortak modüllerin kopyalarını kullanır (`deney/c`, `deney/cpp`, `deney/python`). Materyalde: ders notu Bölüm 6 (6.1–6.6) ve Bölüm 1.1, 9; sunum slayt 45, 46; web `h09-deney`.


## 5. Alıştırmalar (alistirmalar/) ve quiz (quiz/)

Alıştırma dosyalarının numaraları ders notuyla aynıdır (Alıştırma 9.1, 9.8, 9.9, 9.10, 9.14, 9.15); çözümleri öğrenci arşivinde yoktur. A02 ve A03 kasıtlı mantık hatası içerir (bellek hatası değil); A04 Parsons bulmacasıdır ve tasarım gereği derlenmez. Beklenen çıktılar ZIP'te yoktur (önce tahmin edin, sonra çalıştırın). Quiz dosyaları web sayfasındaki haftalık quiz'in kodlu sorularıdır.

| Dosya | Dil | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `alistirmalar/H09_A01_cikti_tahmini.c` | C | Sabit kapasiteli yığın ve sayaçlı dairesel kuyruk aynı değerleri alıyor; programı çalıştırmadan çıktısını tahmin edin (önce kâğıtta yığını ve kuyruğun hücrelerini çizin) | 11.1, Alıştırma 9.1 | — | `alistirmalar` |
| `alistirmalar/H09_A02_hata_bul_parantez.c` | C | AP-2 Hafta 9 · Alıştırma 9.8 (★★). BU DOSYA KASITLI HATA İÇERİR: parantez_denetle altı satırın bazıları için yanlış sonuç veriyor. Önce çıktıyı tahmin edin, sonra hatalı satırı bulup düzeltin (Örnek 3 ile karşılaştırın). | 11.4, Alıştırma 9.8 | — | `alistirmalar` |
| `alistirmalar/H09_A03_hata_bul_dairesel.c` | C | AP-2 Hafta 9 · Alıştırma 9.9 (★★). BU DOSYA KASITLI HATA İÇERİR: sayaçlı dairesel kuyruk (kapasite 4) 10, 20, 30, 40 sırasıyla eklenen elemanları aynı sırayla vermeli; vermiyor. Hatalı satırları bulun ve düzeltin (Örnek 8'in yöntem A'sıyla karşılaştırın). | 11.4, Alıştırma 9.9 | — | `alistirmalar` |
| `alistirmalar/H09_A04_parsons_sonek.c` | C | AP-2 Hafta 9 · Alıştırma 9.10 (★★) — Parsons. Tamamlanacak; bu hâliyle derlenmez: aşağıdaki satırlar tek basamaklı işlenenli sonek ifadeyi (ör. "512+4*+3-") değerlendiren fonksiyonun KARIŞTIRILMIŞ satırlarıdır; iki satır fazladır (kullanılmayacak). Doğru sıraya dizin, girintiyi düzeltin; "512+4*+3-" için 14 döndürmeli. | 11.5, Alıştırma 9.10 | — | `alistirmalar` |
| `alistirmalar/H09_A05_deque_okuma.py` | Python | Diller arası okuma: collections.deque (maxlen ile), list.pop ve tamsayı bölmesi; programı çalıştırmadan çıktısını tahmin edin | 11.7, Alıştırma 9.14 | — | `alistirmalar` |
| `alistirmalar/H09_A06_stack_queue_okuma.cpp` | C++ | Diller arası okuma: std::stack ve std::queue kap uyarlayıcıları; programı çalıştırmadan çıktısını tahmin edin | 11.7, Alıştırma 9.15 | — | `alistirmalar` |
| `quiz/H09_Q01_yigin_izleme.c` | C | Dizi tabanlı yığında it (y[n++] = x) ve çıkar (y[--n]) işlemlerinin izlenmesi | — | — | `quiz` |
| `quiz/H09_Q07_bolme.c` | C | H09_Q07_bolme.py'nin C karşılığı: -7 / 2 ve -7 % 2 | — | — | `quiz` |
| `quiz/H09_Q07_bolme.py` | Python | H09_Q07_bolme.c'nin Python karşılığı: -7 // 2 ve -7 % 2 | — | — | `quiz` |
| `quiz/H09_Q08_pop0.py` | Python | Python listesini kuyruk gibi kullanan döngünün maliyeti | — | — | `quiz` |

## 6. Bellek denetimi

`BELLEK_DENETIMI.txt`: merdivenin 14 örneği C ve C++'ta `esdeger_test.py --asan`; kavram, deney, Hata Avcısı'nın düzeltilmiş C/C++ dosyaları, alıştırma ve quiz programları ASan + UBSan ile; hepsi Valgrind (`--leak-check=full`) ile. Sonuç: TÜMÜ TEMİZ.


## 7. Arşiv

`AP2_H09_kodlar.zip`: bu klasörün tamamı; derleme ürünleri, önbellek dosyaları, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` hariç (yanıt sızmasın). Açtıktan sonra `python3 esdeger_test.py .` 14/14 GEÇTİ vermelidir.

"""H08_K07_list_deque.py — AP-2 Hafta 8 · Kavram 7
Amaç    : Python list bir dinamik dizidir: append fazladan yer ayırır
          (sys.getsizeof ile gözlenir; değerler CPython sürümüne bağlı);
          collections.deque iki uçta O(1) ekler/çıkarır
Çalıştır: python3 H08_K07_list_deque.py
"""
import sys
from collections import deque


def main():
    print(f"CPython {sys.version_info[0]}.{sys.version_info[1]}"
          " (sayılar sürüme bağlıdır)")
    a = []
    onceki = sys.getsizeof(a)
    print(f"getsizeof([]) = {onceki} bayt")
    print("append ile boyut değişimleri (öğe sayısı: bayt, yuva):")
    for i in range(1, 41):
        a.append(i)
        b = sys.getsizeof(a)
        if b != onceki:
            yuva = (b - sys.getsizeof([])) // 8
            print(f"  len = {len(a):2d}: {b} bayt, {yuva} yuva")
            onceki = b
    # list.insert(0, x) her öğeyi bir sağa kaydırır: Θ(len)
    d = deque()
    for x in (3, 1, 4):
        d.appendleft(x)          # O(1): dizi kaydırması yok
    d.append(9)
    print("deque (appendleft 3, 1, 4; append 9):", list(d))
    x = d.popleft()
    print("deque.popleft() ->", x, "; kalan:", list(d))
    lst = [1, 4]
    lst.insert(0, 3)             # kaydırmalı başa ekleme
    print("list.insert(0, 3):", lst)
    x = lst.pop(0)               # kaydırmalı baştan çıkarma
    print("list.pop(0) ->", x, "; kalan:", lst)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle dinamik dizi, Örnek 1); C++ —
# std::vector ve std::deque; Python — list ve collections.deque.

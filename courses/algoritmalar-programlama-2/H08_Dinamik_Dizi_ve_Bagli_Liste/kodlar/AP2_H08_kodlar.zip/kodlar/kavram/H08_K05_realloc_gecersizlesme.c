/* H08_K05_realloc_gecersizlesme.c — AP-2 Hafta 8 · Kavram 5
 * Amaç    : realloc bloğu yerinde büyütebilir ya da taşıyabilir; taşınınca
 *           eski bloğu gösteren her işaretçi geçersizdir (yineleyici
 *           geçersizleşmesine giriş). Adres YAZDIRILMAZ: yalnızca realloc
 *           ÖNCESİNDE uintptr_t'ye çevrilmiş değer karşılaştırılır. Sonuç
 *           ayırıcıya ve çalıştırmaya bağlıdır ("bu çalıştırmada").
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_K05_realloc_gecersizlesme.c -o H08_K05_realloc_gecersizlesme
 * Çalıştır: ./H08_K05_realloc_gecersizlesme
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Bloğu yeni_n öğeye büyütür; *tasindi'ya taşınıp taşınmadığını yazar.
 * NULL dönerse eski blok geçerli kalır. Sahiplik: dönen blok çağıranındır. */
static int *buyut(int *a, size_t yeni_n, int *tasindi)
{
    uintptr_t eski = (uintptr_t)a;        /* realloc'tan ÖNCE */
    int *g = realloc(a, yeni_n * sizeof *g);
    if (g != NULL) {
        *tasindi = (uintptr_t)g != eski;
    }
    return g;
}

int main(void)
{
    size_t n = 4;
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t i = 0; i < n; i++) {
        a[i] = (int)(10 * (i + 1));
    }
    int *ilk = &a[0];        /* takma ad: a[0]'ı gösterir */
    size_t ilk_indis = 0;    /* güvenli seçenek: indis */
    printf("[bu çalıştırmada; ayırıcıya bağlı]\n");
    for (int tur = 1; tur <= 3; tur++) {
        int tasindi = 0;
        int *g = buyut(a, 4 * n, &tasindi);
        if (g == NULL) {
            free(a);
            return 1;
        }
        a = g;
        n *= 4;
        printf("tur %d: %zu öğeye büyüdü, blok %s\n", tur, n,
               tasindi ? "TAŞINDI" : "yerinde kaldı");
        if (tasindi) {
            printf("  ilk eski bloğu gösteriyor: *ilk okunamaz "
                   "(tanımsız davranış); yeniden bağlanır\n");
        }
        ilk = &a[0];         /* her büyütmeden sonra tazele */
        printf("  *ilk = %d, a[ilk_indis] = %d\n", *ilk, a[ilk_indis]);
    }
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — realloc; C++ — std::vector: kapasite değişince
 * yineleyiciler, başvurular ve işaretçiler geçersizleşir; Python — list
 * öğelere başvuru tutar (dışarıya işaretçi vermez). */

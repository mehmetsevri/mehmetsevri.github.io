"""H08_K08_slots_none.py — AP-2 Hafta 8 · Kavram 8
Amaç    : Python düğüm sınıfı: __slots__ nesne başına sözlüğü (__dict__)
          kaldırır; boş bağlantı None'dır ve "is" ile denetlenir; düğüm
          kimliği "is", değer eşitliği "==" ile. Bellek satırları
          tracemalloc ölçümüdür (CPython sürümüne bağlı).
Çalıştır: python3 H08_K08_slots_none.py
"""
import sys
import tracemalloc


class DugumSlots:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


class DugumSozluk:
    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


def dugum_basina_bayt(sinif, n):
    tracemalloc.start()
    once = tracemalloc.get_traced_memory()[0]
    bas = None
    for i in range(n):
        d = sinif(i + 1000)       # küçük int önbelleği dışında
        d.sonraki = bas
        bas = d
    sonra = tracemalloc.get_traced_memory()[0]
    tracemalloc.stop()
    return (sonra - once) / n, bas


def main():
    s, z = DugumSlots(1), DugumSozluk(1)
    print("__dict__ var mı? slots:", hasattr(s, "__dict__"),
          "· sözlüklü:", hasattr(z, "__dict__"))
    try:
        s.renk = "kırmızı"
    except AttributeError:
        print("slots düğümüne yeni alan eklenemez (AttributeError)")
    z.renk = "kırmızı"
    print("sözlüklü düğüme eklenir:", z.__dict__)
    print("s.sonraki is None:", s.sonraki is None)
    a, b = DugumSlots(5), DugumSlots(5)
    print("a.veri == b.veri:", a.veri == b.veri, "· a is b:", a is b)
    v = sys.version_info
    print(f"CPython {v[0]}.{v[1]}, 10^5 düğüm (tracemalloc; int dahil):")
    for sinif in (DugumSlots, DugumSozluk):
        bayt, _ = dugum_basina_bayt(sinif, 100000)
        print(f"  {sinif.__name__:<12}: düğüm başına ≈ {bayt:.0f} bayt")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — struct (alanlar sabit); C++ — struct/class;
# Python — __slots__ ya da dataclass(slots=True) (3.10+).

/* H08_K02_liste_islemleri.c — AP-2 Hafta 8 · Kavram 2
 * Amaç    : Başlıklı (bas, son) tek bağlı listede başa, sona ve araya
 *           ekleme (Dugum ** ile, baş için de aynı kod), baştan silme,
 *           değere göre silme ve ters çevirme; her işlemden sonra liste,
 *           bas/son ve sayaçlar (Örnek 3–7 ile aynı tanımlar)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_K02_liste_islemleri.c -o H08_K02_liste_islemleri
 * Çalıştır: ./H08_K02_liste_islemleri
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    Dugum *bas;
    Dugum *son;
} Liste;

/* ziyaret: bir düğüme bakıldı; bag: bir düğümün sonraki alanına yazıldı */
static long long ziyaret = 0, bag = 0;
static long long ayirma = 0, birakma = 0;

/* Sahiplik: dönen düğüm listenindir; liste_yok_et ile bırakılır */
static Dugum *dugum_olustur(int x)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = x;
    d->sonraki = NULL;
    ayirma++;
    return d;
}

/* 1) Başa ekleme: O(1) */
static void basa_ekle(Liste *l, int x)
{
    Dugum *d = dugum_olustur(x);
    d->sonraki = l->bas;
    bag++;
    l->bas = d;
    if (l->son == NULL) {
        l->son = d;               /* boş listeye ilk düğüm */
    }
}

/* 2) Sona ekleme (kuyruk işaretçisi): O(1) */
static void sona_ekle(Liste *l, int x)
{
    Dugum *d = dugum_olustur(x);
    if (l->son == NULL) {
        l->bas = d;
    } else {
        l->son->sonraki = d;
        bag++;
    }
    l->son = d;
}

/* 3) Araya ekleme: konum (0 tabanlı) düğümünün önüne; Θ(konum) yürüme,
 *    sonra O(1) bağlama. p, yeni düğümü gösterecek bağlantının adresi. */
static bool konuma_ekle(Liste *l, int konum, int x)
{
    Dugum **p = &l->bas;
    for (int i = 0; i < konum; i++) {
        if (*p == NULL) {
            return false;         /* liste konumdan kısa */
        }
        ziyaret++;
        p = &(*p)->sonraki;
    }
    Dugum *d = dugum_olustur(x);
    d->sonraki = *p;
    bag++;
    if (p != &l->bas) {
        bag++;                    /* *p bir düğümün sonraki alanı */
    }
    *p = d;
    if (d->sonraki == NULL) {
        l->son = d;               /* sona eklendi */
    }
    return true;
}

/* 4) Baştan silme: O(1); tek düğüm silinince son da NULL olur */
static bool bastan_sil(Liste *l, int *x)
{
    Dugum *d = l->bas;
    if (d == NULL) {
        return false;
    }
    *x = d->veri;
    l->bas = d->sonraki;
    if (l->bas == NULL) {
        l->son = NULL;
    }
    free(d);
    birakma++;
    return true;
}

/* 5) Değere göre silme (Dugum **, Örnek 5 sürüm 2); son düğüm silinirse
 *    kuyruk işaretçisi önceki düğüme çekilir */
static bool sil(Liste *l, int x)
{
    Dugum **p = &l->bas;
    Dugum *onceki = NULL;
    while (*p != NULL) {
        ziyaret++;
        if ((*p)->veri == x) {
            break;
        }
        onceki = *p;
        p = &(*p)->sonraki;
    }
    if (*p == NULL) {
        return false;
    }
    Dugum *silinen = *p;
    *p = silinen->sonraki;
    if (p != &l->bas) {
        bag++;
    }
    if (silinen == l->son) {
        l->son = onceki;
    }
    free(silinen);
    birakma++;
    return true;
}

/* 6) Ters çevirme (Örnek 7): her düğüme bir bağlantı yazılır; bas ile son
 *    yer değiştirir */
static void ters_cevir(Liste *l)
{
    Dugum *onceki = NULL, *gecerli = l->bas;
    l->son = l->bas;
    while (gecerli != NULL) {
        Dugum *sonraki = gecerli->sonraki;
        gecerli->sonraki = onceki;
        bag++;
        onceki = gecerli;
        gecerli = sonraki;
    }
    l->bas = onceki;
}

static void liste_yok_et(Liste *l)
{
    Dugum *d = l->bas;
    while (d != NULL) {
        Dugum *sonraki = d->sonraki;
        free(d);
        birakma++;
        d = sonraki;
    }
    l->bas = NULL;
    l->son = NULL;
}

/* UTF-8 karakter sayısına göre dolgu (printf genişliği bayt sayar) */
static void dolgulu_yaz(const char *s, int genislik)
{
    int n = 0;
    for (const char *c = s; *c != '\0'; c++) {
        n += ((unsigned char)*c & 0xC0) != 0x80;
    }
    printf("%s%*s", s, genislik > n ? genislik - n : 0, "");
}

static void durum(const char *islem, const Liste *l)
{
    printf("  ");
    dolgulu_yaz(islem, 19);
    printf("[");
    for (const Dugum *p = l->bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]  bas = ");
    if (l->bas != NULL) {
        printf("%d", l->bas->veri);
    } else {
        printf("NULL");
    }
    printf(", son = ");
    if (l->son != NULL) {
        printf("%d", l->son->veri);
    } else {
        printf("NULL");
    }
    printf("  (ziyaret %lld, bağlantı %lld)\n", ziyaret, bag);
    ziyaret = 0;
    bag = 0;
}

int main(void)
{
    Liste l = {NULL, NULL};
    int x;
    printf("1) Kurma: sona_ekle 3, 1, 4\n");
    sona_ekle(&l, 3);
    sona_ekle(&l, 1);
    sona_ekle(&l, 4);
    durum("kuruldu", &l);
    printf("\n2) Araya ekleme: aynı kod başa, ortaya ve sona ekler\n");
    konuma_ekle(&l, 2, 9);
    durum("konuma_ekle(2, 9)", &l);
    konuma_ekle(&l, 0, 7);
    durum("konuma_ekle(0, 7)", &l);
    konuma_ekle(&l, 5, 8);
    durum("konuma_ekle(5, 8)", &l);
    bool b3 = konuma_ekle(&l, 9, 6);
    printf("  konuma_ekle(9, 6): %s (liste kısa; ziyaret %lld)\n",
           b3 ? "true" : "false", ziyaret);
    ziyaret = 0;
    printf("\n3) Silme ve ters çevirme\n");
    bastan_sil(&l, &x);
    durum("bastan_sil -> 7", &l);
    sil(&l, 8);
    durum("sil(8)", &l);
    basa_ekle(&l, 5);
    durum("basa_ekle(5)", &l);
    ters_cevir(&l);
    durum("ters_cevir", &l);
    printf("\n4) Sınır durumları\n");
    Liste b = {NULL, NULL};
    bool b1 = bastan_sil(&b, &x), b2 = sil(&b, 1);
    printf("  boş listede bastan_sil: %s, sil(1): %s\n",
           b1 ? "true" : "false", b2 ? "true" : "false");
    basa_ekle(&b, 6);
    durum("basa_ekle(6)", &b);
    bastan_sil(&b, &x);
    durum("bastan_sil -> 6", &b);
    liste_yok_et(&l);
    liste_yok_et(&b);
    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n", ayirma,
           birakma);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list
 * (push_front, insert_after, erase_after, remove, reverse); Python — yok
 * (collections.deque iki uçlu yapıdır). */

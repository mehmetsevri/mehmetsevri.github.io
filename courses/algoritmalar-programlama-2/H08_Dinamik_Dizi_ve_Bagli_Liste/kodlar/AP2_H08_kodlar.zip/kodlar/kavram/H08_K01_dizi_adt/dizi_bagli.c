/* dizi_bagli.c — AP-2 Hafta 8 · Kavram 1: Dizi ADT'sinin tek bağlı liste
 * gerçekleştirimi (kuyruk işaretçisiyle sona ekleme O(1); indisle erişim
 * baştan yürüyerek Θ(i)). Derleme: bkz. dizi.h
 */
#include <stdlib.h>

#include "dizi.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

struct Dizi {
    Dugum *bas, *son;
    size_t boyut;
};

static long long adim = 0;   /* ziyaret edilen düğüm */

Dizi *dizi_olustur(void)
{
    Dizi *d = malloc(sizeof *d);
    if (d != NULL) {
        d->bas = NULL;
        d->son = NULL;
        d->boyut = 0;
    }
    return d;
}

int dizi_ekle(Dizi *d, int x)
{
    Dugum *yeni = malloc(sizeof *yeni);
    if (yeni == NULL) {
        return -1;
    }
    yeni->veri = x;
    yeni->sonraki = NULL;
    if (d->son == NULL) {
        d->bas = yeni;
    } else {
        d->son->sonraki = yeni;
    }
    d->son = yeni;
    d->boyut++;
    return 0;
}

bool dizi_al(const Dizi *d, size_t i, int *x)
{
    if (i >= d->boyut) {
        return false;
    }
    const Dugum *p = d->bas;
    adim++;
    for (size_t k = 0; k < i; k++) {   /* Θ(i): rastgele erişim yok */
        p = p->sonraki;
        adim++;
    }
    *x = p->veri;
    return true;
}

size_t dizi_boyut(const Dizi *d)
{
    return d->boyut;
}

const char *dizi_gerceklestirim(void)
{
    return "tek bağlı liste (kuyruk işaretçili)";
}

long long dizi_adim(void)
{
    return adim;
}

void dizi_yok_et(Dizi *d)
{
    if (d == NULL) {
        return;
    }
    Dugum *p = d->bas;
    while (p != NULL) {
        Dugum *sonraki = p->sonraki;   /* free'den ÖNCE sakla */
        free(p);
        p = sonraki;
    }
    free(d);
}

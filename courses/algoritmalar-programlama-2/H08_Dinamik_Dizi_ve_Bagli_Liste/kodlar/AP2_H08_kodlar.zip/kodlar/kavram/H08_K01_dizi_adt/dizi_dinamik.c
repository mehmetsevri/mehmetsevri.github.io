/* dizi_dinamik.c — AP-2 Hafta 8 · Kavram 1: Dizi ADT'sinin dinamik dizi
 * gerçekleştirimi (kapasite dolunca × 2; realloc sonucu önce geçici
 * işaretçiye alınır). Derleme: bkz. dizi.h
 */
#include <stdlib.h>

#include "dizi.h"

struct Dizi {
    int *veri;        /* öbekte bitişik blok */
    size_t boyut;     /* kullanılan öğe */
    size_t kapasite;  /* ayrılmış yuva */
};

static long long adim = 0;   /* okunan ya da kopyalanan öğe */

Dizi *dizi_olustur(void)
{
    Dizi *d = malloc(sizeof *d);
    if (d != NULL) {
        d->veri = NULL;
        d->boyut = 0;
        d->kapasite = 0;
    }
    return d;
}

int dizi_ekle(Dizi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 1;
        int *g = realloc(d->veri, yeni * sizeof *g);
        if (g == NULL) {
            return -1;            /* d->veri hâlâ geçerli */
        }
        adim += (long long)d->boyut;   /* model: taşınan öğe */
        d->veri = g;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

bool dizi_al(const Dizi *d, size_t i, int *x)
{
    if (i >= d->boyut) {
        return false;
    }
    adim++;
    *x = d->veri[i];          /* O(1): adres = veri + i */
    return true;
}

size_t dizi_boyut(const Dizi *d)
{
    return d->boyut;
}

const char *dizi_gerceklestirim(void)
{
    return "dinamik dizi (× 2)";
}

long long dizi_adim(void)
{
    return adim;
}

void dizi_yok_et(Dizi *d)
{
    if (d != NULL) {
        free(d->veri);
        free(d);
    }
}

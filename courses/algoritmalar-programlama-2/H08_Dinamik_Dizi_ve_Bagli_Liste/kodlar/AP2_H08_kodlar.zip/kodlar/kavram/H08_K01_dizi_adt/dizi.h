/* dizi.h — AP-2 Hafta 8 · Kavram 1: Dizi soyut veri tipinin ARAYÜZÜ
 * Aynı arayüzün iki gerçekleştirimi: dizi_dinamik.c (× 2 dinamik dizi) ve
 * dizi_bagli.c (kuyruk işaretçili tek bağlı liste); main.c yalnızca bu
 * dosyayı görür. Derleme (birini seçin):
 *   gcc -std=c17 -Wall -Wextra -pedantic -O2 main.c dizi_dinamik.c -o dizi_d
 *   gcc -std=c17 -Wall -Wextra -pedantic -O2 main.c dizi_bagli.c -o dizi_b
 */
#ifndef DIZI_H
#define DIZI_H

#include <stdbool.h>
#include <stddef.h>

typedef struct Dizi Dizi;   /* opak tip: alanlar yalnızca .c dosyasında */

/* Sahiplik: dönen dizi çağıranındır; dizi_yok_et ile bırakılır.
 * Bellek yetersizse NULL döner. */
Dizi *dizi_olustur(void);

/* x'i sona ekler. 0: başarı, -1: bellek yetersiz (dizi değişmez). */
int dizi_ekle(Dizi *d, int x);

/* i < boyut ise *x'e yazar ve true döner; değilse false döner. */
bool dizi_al(const Dizi *d, size_t i, int *x);

size_t dizi_boyut(const Dizi *d);

/* Öğretim amaçlı: gerçekleştirimin adı ve öğe/düğüm erişim sayacı */
const char *dizi_gerceklestirim(void);
long long dizi_adim(void);

/* Bütün belleği bırakır; d bundan sonra kullanılmaz. NULL güvenlidir. */
void dizi_yok_et(Dizi *d);

#endif

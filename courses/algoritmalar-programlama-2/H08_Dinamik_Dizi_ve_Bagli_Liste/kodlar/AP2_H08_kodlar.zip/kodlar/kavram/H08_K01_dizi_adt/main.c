/* main.c — AP-2 Hafta 8 · Kavram 1: Dizi ADT'sinin istemcisi
 * Yalnızca dizi.h'yi görür: aynı main iki gerçekleştirimle de derlenir ve
 * aynı sonuçları verir; değişen tek şey adım sayısıdır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 main.c \
 *           dizi_dinamik.c -o dizi_d   (ya da dizi_bagli.c -o dizi_b)
 * Çalıştır: ./dizi_d   ·   ./dizi_b
 */
#include <stdio.h>

#include "dizi.h"

int main(void)
{
    Dizi *d = dizi_olustur();
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("gerçekleştirim: %s\n", dizi_gerceklestirim());
    const int n = 1000;
    for (int i = 1; i <= n; i++) {
        if (dizi_ekle(d, i * i) != 0) {
            fprintf(stderr, "bellek yetersiz\n");
            dizi_yok_et(d);
            return 1;
        }
    }
    printf("1) %d sona ekleme: boyut = %zu, adım = %lld\n", n,
           dizi_boyut(d), dizi_adim());
    long long once = dizi_adim(), toplam = 0;
    for (size_t i = 0; i < dizi_boyut(d); i++) {
        int x;
        if (dizi_al(d, i, &x)) {
            toplam += x;
        }
    }
    printf("2) indisle okuma (i = 0..%d): toplam = %lld, adım = %lld\n",
           n - 1, toplam, dizi_adim() - once);
    int x;
    if (dizi_al(d, 9, &x)) {
        printf("3) dizi_al(9) = %d\n", x);
    }
    if (!dizi_al(d, (size_t)n, &x)) {
        printf("4) dizi_al(%d): sınır dışı (false)\n", n);
    }
    dizi_yok_et(d);
    return 0;
}

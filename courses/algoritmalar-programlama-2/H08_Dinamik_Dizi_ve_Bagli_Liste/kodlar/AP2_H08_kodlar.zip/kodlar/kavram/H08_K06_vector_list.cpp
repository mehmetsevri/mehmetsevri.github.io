/* H08_K06_vector_list.cpp — AP-2 Hafta 8 · Kavram 6
 * Amaç    : Kütüphane karşılıkları: std::vector (dinamik dizi; kapasite
 *           büyümesi gerçekleştirime bağlı), std::list (çift bağlı),
 *           std::forward_list (tek bağlı); kapasite satırları "bu
 *           derleyicide" (libstdc++) gözlemdir
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_K06_vector_list.cpp -o H08_K06_vector_list
 * Çalıştır: ./H08_K06_vector_list
 */
#include <cstddef>
#include <forward_list>
#include <iostream>
#include <list>
#include <vector>

template <typename K>
static void yaz(const char* ad, const K& k)
{
    std::cout << ad << ":";
    for (int x : k) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

int main()
{
    // 1) vector: push_back amortize O(1); kapasite değişimleri
    std::vector<int> v;
    std::size_t onceki = v.capacity();
    std::cout << "vector kapasiteleri (bu derleyicide):";
    for (int i = 1; i <= 100; i++) {
        v.push_back(i);
        if (v.capacity() != onceki) {
            onceki = v.capacity();
            std::cout << " " << onceki;
        }
    }
    std::cout << "\n";
    std::vector<int> r;
    r.reserve(100);              // önceden ayır: büyütme olmaz
    std::size_t k0 = r.capacity();
    for (int i = 0; i < 100; i++) {
        r.push_back(i);
    }
    std::cout << "reserve(100) sonrası kapasite değişti mi? "
              << (r.capacity() != k0 ? "evet" : "hayır") << "\n";

    // 2) list: çift bağlı; konumu bilinen yerde O(1) insert/erase
    std::list<int> l = {1, 4, 5, 9};
    auto it = l.begin();
    ++it;                         // 4'ü gösterir
    l.insert(it, 7);              // 4'ün önüne
    l.push_front(2);
    l.erase(it);                  // 4'ü sil (yineleyici artık geçersiz)
    yaz("list", l);
    l.reverse();
    yaz("list.reverse", l);
    std::list<int> a = {1, 3, 5}, b = {2, 3, 6};
    a.merge(b);                   // düğümleri taşır; b boşalır, kararlı
    yaz("list.merge", a);
    std::cout << "merge sonrası b boş mu? " << (b.empty() ? "evet" : "hayır")
              << "\n";

    // 3) forward_list: tek bağlı; yalnızca "sonrasına" ekle/sil
    std::forward_list<int> f = {3, 1, 4};
    f.push_front(5);
    f.insert_after(f.begin(), 8); // ilk düğümden sonra
    f.reverse();
    yaz("forward_list", f);
    f.sort();
    yaz("forward_list.sort", f);
    return 0;
}

/* Kütüphane karşılığı: bu dosyanın kendisi kütüphane gösterimidir;
 * merdivendeki algoritmalar elle yazılmıştır (Örnek 1–13). */

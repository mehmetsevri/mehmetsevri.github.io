/* H08_K03_ozel_durumsuz_silme.c — AP-2 Hafta 8 · Kavram 3
 * Amaç    : Adresi bilinen düğümü listeden çıkarmanın iki yazımı: önceki
 *           işaretçisiyle (baş için ayrı dal) ve Dugum ** ile (dal yok);
 *           iki yazım her konumda aynı listeyi bırakır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_K03_ozel_durumsuz_silme.c -o H08_K03_ozel_durumsuz_silme
 * Çalıştır: ./H08_K03_ozel_durumsuz_silme
 */
#include <stdio.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    Dugum *bas;
} Liste;

/* hedef listede olmalı; düğüm bırakılmaz (çağıranın işi) */
static void cikar_ozel(Liste *l, Dugum *hedef)
{
    Dugum *onceki = NULL;
    Dugum *p = l->bas;
    while (p != hedef) {
        onceki = p;
        p = p->sonraki;
    }
    if (onceki == NULL) {
        l->bas = hedef->sonraki;
    } else {
        onceki->sonraki = hedef->sonraki;
    }
}

/* p: hedefi gösteren bağlantının adresi */
static void cikar_pp(Liste *l, Dugum *hedef)
{
    Dugum **p = &l->bas;
    while (*p != hedef) {
        p = &(*p)->sonraki;
    }
    *p = hedef->sonraki;
}

/* d[0..n-1] düğümlerini sırayla bağlar (düğümler yığında: ayırma yok) */
static void kur(Liste *l, Dugum *d, int n)
{
    for (int i = 0; i < n; i++) {
        d[i].veri = 10 * (i + 1);
        d[i].sonraki = i + 1 < n ? &d[i + 1] : NULL;
    }
    l->bas = n > 0 ? &d[0] : NULL;
}

static void yaz(const Liste *l)
{
    printf("[");
    for (const Dugum *p = l->bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]");
}

static int ayni(const Liste *a, const Liste *b)
{
    const Dugum *p = a->bas, *q = b->bas;
    while (p != NULL && q != NULL && p->veri == q->veri) {
        p = p->sonraki;
        q = q->sonraki;
    }
    return p == NULL && q == NULL;
}

int main(void)
{
    const char *ad[] = {"baş", "orta", "son"};
    const int konum[] = {0, 2, 4};
    for (int t = 0; t < 3; t++) {
        Dugum d1[5], d2[5];
        Liste a, b;
        kur(&a, d1, 5);
        kur(&b, d2, 5);
        cikar_ozel(&a, &d1[konum[t]]);
        cikar_pp(&b, &d2[konum[t]]);
        printf("%s (%d) çıkarılır\n  özel durumlu: ", ad[t],
               10 * (konum[t] + 1));
        yaz(&a);
        printf("\n  Dugum **    : ");
        yaz(&b);
        printf("  aynı mı? %s\n", ayni(&a, &b) ? "evet" : "HAYIR");
    }
    Dugum tek[1], tek2[1];
    Liste a, b;
    kur(&a, tek, 1);
    kur(&b, tek2, 1);
    cikar_ozel(&a, &tek[0]);
    cikar_pp(&b, &tek2[0]);
    printf("tek düğüm (10) çıkarılır\n  özel durumlu: ");
    yaz(&a);
    printf("\n  Dugum **    : ");
    yaz(&b);
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list::erase_after
 * (öncekini ister) ve std::list::erase (çift bağlı: O(1)); Python — yok. */

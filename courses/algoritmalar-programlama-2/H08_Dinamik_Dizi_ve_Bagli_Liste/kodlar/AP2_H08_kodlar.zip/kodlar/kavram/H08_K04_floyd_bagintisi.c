/* H08_K04_floyd_bagintisi.c — AP-2 Hafta 8 · Kavram 4
 * Amaç    : Floyd döngü tespitinin izlemesiz, kısa yazımı ve uzaklık
 *           bağıntısının sınanması: buluşmada kaplumbağanın attığı adım
 *           (i) λ'nın katıdır; buluşmadan μ adım ilerlemek döngü başına
 *           götürür. Düğümler yığında bir dizidir (ayırma yok).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_K04_floyd_bagintisi.c -o H08_K04_floyd_bagintisi
 * Çalıştır: ./H08_K04_floyd_bagintisi
 */
#include <stdio.h>

typedef struct Dugum {
    int veri;                /* düğümün konumu: 0..n-1 */
    struct Dugum *sonraki;
} Dugum;

static int adim = 0;

/* Evre 1: döngü yoksa NULL; varsa buluşma düğümü */
static Dugum *bulusma(Dugum *bas)
{
    Dugum *kap = bas, *tav = bas;
    adim = 0;
    while (tav != NULL && tav->sonraki != NULL) {
        kap = kap->sonraki;
        tav = tav->sonraki->sonraki;
        adim++;
        if (kap == tav) {
            return kap;
        }
    }
    return NULL;
}

/* Evre 2: biri baştan, biri buluşmadan; birer adım */
static Dugum *baslangic(Dugum *bas, Dugum *b)
{
    while (bas != b) {
        bas = bas->sonraki;
        b = b->sonraki;
    }
    return bas;
}

/* d[0..n-1]: son düğüm mu konumuna bağlanır (mu < 0: döngü yok) */
static Dugum *kur(Dugum *d, int n, int mu)
{
    for (int i = 0; i < n; i++) {
        d[i].veri = i;
        d[i].sonraki = i + 1 < n ? &d[i + 1] : NULL;
    }
    if (mu >= 0) {
        d[n - 1].sonraki = &d[mu];
    }
    return &d[0];
}

int main(void)
{
    static Dugum d[64];
    const int durum[][2] = {{10, 4}, {10, 0}, {10, 9}, {7, 3}, {12, 1},
                            {12, 8}, {40, 37}, {9, -1}};
    printf("   n   mu  lambda   i  i mod lambda  buluşma  "
           "mu + (i - mu) mod lambda  başlangıç\n");
    for (int t = 0; t < 8; t++) {
        int n = durum[t][0], mu = durum[t][1];
        Dugum *bas = kur(d, n, mu);
        Dugum *b = bulusma(bas);
        if (b == NULL) {
            printf("%4d %4d   döngü yok: tavşan NULL'a %d adımda vardı\n",
                   n, mu, adim);
            continue;
        }
        int lambda = n - mu;
        int tahmin = mu + ((adim - mu) % lambda + lambda) % lambda;
        printf("%4d %4d %7d %3d %13d %8d %25d %10d\n", n, mu, lambda, adim,
               adim % lambda, b->veri, tahmin, baslangic(bas, b)->veri);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok; Python — yok. */

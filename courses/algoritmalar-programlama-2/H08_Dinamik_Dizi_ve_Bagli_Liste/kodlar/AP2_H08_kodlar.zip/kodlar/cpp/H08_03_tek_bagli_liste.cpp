/* H08_03_tek_bagli_liste.cpp — AP-2 Hafta 8 · Örnek 3 (★)
 * Amaç    : Tek bağlı liste: düğüm, baş işaretçisi, başa ekleme (O(1)),
 *           dolaşarak yazdırma ve uzunluk (Θ(n)); ziyaret sayacı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_03_tek_bagli_liste.cpp -o H08_03_tek_bagli_liste
 * Çalıştır: ./H08_03_tek_bagli_liste
 * Eşleri  : c/H08_03_tek_bagli_liste.c · python/H08_03_tek_bagli_liste.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <initializer_list>
#include <iomanip>
#include <iostream>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;
    Dugum* sonraki;   // sonraki düğümün adresi; son düğümde nullptr
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ziyaret_sayisi = 0, baglanti_sayisi = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, nullptr};   // yetersizse std::bad_alloc
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

// Yeni düğüm eski başın önüne bağlanır; YENİ BAŞI döndürür: O(1)
static Dugum* basa_ekle(Dugum* bas, int x)
{
    Dugum* d = dugum_olustur(x);
    d->sonraki = bas;
    baglanti_sayisi++;
    return d;
}

static void liste_yaz(const Dugum* bas)
{
    std::cout << "[";
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        std::cout << p->veri << " -> ";
    }
    std::cout << "NULL]\n";
}

// Baştan nullptr'a kadar yürür: Θ(n)
static int uzunluk(const Dugum* bas)
{
    int n = 0;
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        ziyaret_sayisi++;
        n++;
    }
    return n;
}

// Tüm düğümleri serbest bırakır (ayrıntısı Örnek 6)
static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;   // delete'ten ÖNCE sakla
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Sahiplik (RAII): Liste nesnesi düğümlerin sahibidir; kapsamdan
// çıkınca yıkıcı liste_yok_et'i çağırır. Kopyalanamaz (çift silme olurdu).
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

int main()
{
    std::cout << "1) Boş liste: baş işaretçisi NULL\n";
    {
        Liste liste;
        std::cout << "  ";
        liste_yaz(liste.bas);
        std::cout << "  uzunluk = " << uzunluk(liste.bas) << "\n";
    }

    std::cout << "\n2) Başa ekleme: 4, 1, 3\n";
    {
        Liste liste;
        for (int x : {4, 1, 3}) {
            liste.bas = basa_ekle(liste.bas, x);
            std::cout << "  basa_ekle(" << x << "): ";
            liste_yaz(liste.bas);
        }
        ziyaret_sayisi = 0;
        int n = uzunluk(liste.bas);
        std::cout << "  uzunluk = " << n << " (ziyaret edilen düğüm = "
                  << ziyaret_sayisi << ")\n";
        std::cout << "  baş düğüm: veri = " << liste.bas->veri
                  << "; son düğümün sonraki'si NULL\n";
    }   // yıkıcı: liste_yok_et(liste.bas)

    std::cout << "\n3) 10 rastgele değer (tohum 42, 0..99) başa eklenince "
                 "sıra tersine döner\n";
    {
        rastgele_tohum(42);
        Liste liste;
        std::cout << "  girdi :";
        for (int i = 0; i < 10; i++) {
            int x = rastgele_aralik(0, 99);
            std::cout << " " << x;
            liste.bas = basa_ekle(liste.bas, x);
        }
        std::cout << "\n  liste : ";
        liste_yaz(liste.bas);
        long long toplam = 0;
        int en_buyuk = liste.bas->veri;
        for (const Dugum* p = liste.bas; p != nullptr; p = p->sonraki) {
            toplam += p->veri;
            if (p->veri > en_buyuk) {
                en_buyuk = p->veri;
            }
        }
        std::cout << "  uzunluk = " << uzunluk(liste.bas) << ", toplam = "
                  << toplam << ", en büyük = " << en_buyuk << "\n";
    }

    std::cout << "\n4) Maliyet: başa ekleme sabit iş, uzunluk Θ(n)\n";
    std::cout << "        n   ayırma  bağlantı yazma  ekleme ziyareti"
                 "  uzunluk ziyareti\n";
    for (int n : {10, 100, 1000, 10000}) {
        long long a0 = ayirma_sayisi, b0 = baglanti_sayisi;
        ziyaret_sayisi = 0;
        Liste liste;
        for (int i = 0; i < n; i++) {
            liste.bas = basa_ekle(liste.bas, i);
        }
        long long ekleme_ziyareti = ziyaret_sayisi;
        uzunluk(liste.bas);
        std::cout << "  " << std::setw(7) << n << " " << std::setw(8)
                  << ayirma_sayisi - a0 << " " << std::setw(15)
                  << baglanti_sayisi - b0 << " " << std::setw(16)
                  << ekleme_ziyareti << " " << std::setw(17)
                  << ziyaret_sayisi - ekleme_ziyareti << "\n";
    }

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list
 * (push_front), std::list; Python — yerleşik bağlı liste yok
 * (collections.deque.appendleft O(1); list.insert(0, x) Θ(n)). */

/* H08_11_cift_bagli_liste.cpp — AP-2 Hafta 8 · Örnek 11 (★★)
 * Amaç    : Kukla düğümlü dairesel çift bağlı liste: adresi bilinen düğümü
 *           O(1) silme, ileri ve geri dolaşma; tek bağlı listeyle kıyas
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_11_cift_bagli_liste.cpp -o H08_11_cift_bagli_liste
 * Çalıştır: ./H08_11_cift_bagli_liste
 * Eşleri  : c/H08_11_cift_bagli_liste.c · python/H08_11_cift_bagli_liste.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

struct CDugum {
    int veri;
    CDugum* onceki;
    CDugum* sonraki;
};

struct Dugum {             // karşılaştırma için tek bağlı düğüm
    int veri;
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long baglanti_sayisi = 0, ziyaret_sayisi = 0;

// Dairesel, kukla düğümlü: kukla.sonraki = ilk, kukla.onceki = son; boş
// listede ikisi de kuklanın kendisidir. Hiçbir bağlantı nullptr değildir.
// Sahiplik (RAII): yıkıcı düğümleri siler. Kopyalanamaz: kopyada kukla'nın
// kendini gösteren bağlantıları ESKİ nesnenin kuklasını gösterirdi.
struct CiftListe {
    CDugum kukla;      // veri taşımaz; nesnenin içinde, ayrılmaz
    int uzunluk;
    CiftListe() : kukla{0, &kukla, &kukla}, uzunluk(0) {}
    CiftListe(const CiftListe&) = delete;
    CiftListe& operator=(const CiftListe&) = delete;
    ~CiftListe();
};

// Yeni düğümü konum'un ÖNÜNE ekler: dört bağlantı, özel durum yok.
// Sahiplik: düğüm listenindir; dönen işaretçi yalnızca bir "tutamaktır".
static CDugum* once_ekle(CiftListe& liste, CDugum* konum, int x)
{
    CDugum* d = new CDugum{x, nullptr, nullptr};
    ayirma_sayisi++;
    d->sonraki = konum;
    d->onceki = konum->onceki;
    konum->onceki->sonraki = d;
    konum->onceki = d;
    baglanti_sayisi += 4;
    liste.uzunluk++;
    return d;
}

static CDugum* sona_ekle(CiftListe& liste, int x)
{
    return once_ekle(liste, &liste.kukla, x);    // kuklanın önü = son
}

static CDugum* basa_ekle(CiftListe& liste, int x)
{
    return once_ekle(liste, liste.kukla.sonraki, x);
}

// Adresi bilinen düğümü O(1) siler: iki bağlantı, yürüme yok, baş/son için
// özel durum yok (komşular her zaman vardır: en kötü kukla). d kukla
// olmamalıdır.
static void dugumu_sil(CiftListe& liste, CDugum* d)
{
    d->onceki->sonraki = d->sonraki;
    d->sonraki->onceki = d->onceki;
    baglanti_sayisi += 2;
    liste.uzunluk--;
    delete d;
    birakma_sayisi++;
}

CiftListe::~CiftListe()
{
    CDugum* d = kukla.sonraki;
    while (d != &kukla) {
        CDugum* sonraki = d->sonraki;
        delete d;
        birakma_sayisi++;
        d = sonraki;
    }
}

static void ileri_yaz(const CiftListe& liste)
{
    std::cout << "  ileri:";
    if (liste.uzunluk == 0) {
        std::cout << " (boş)";
    }
    for (const CDugum* d = liste.kukla.sonraki; d != &liste.kukla;
         d = d->sonraki) {
        std::cout << (d == liste.kukla.sonraki ? " " : " <-> ") << d->veri;
    }
    std::cout << "\n";
}

static void geri_yaz(const CiftListe& liste)
{
    std::cout << "  geri :";
    if (liste.uzunluk == 0) {
        std::cout << " (boş)";
    }
    for (const CDugum* d = liste.kukla.onceki; d != &liste.kukla;
         d = d->onceki) {
        std::cout << (d == liste.kukla.onceki ? " " : " <-> ") << d->veri;
    }
    std::cout << "\n";
}

// Değişmez: her düğüm için d->sonraki->onceki == d; iki yönde de sayım
// uzunluğa eşit
static bool tutarli_mi(const CiftListe& liste)
{
    int ileri = 0, geri = 0;
    const CDugum* d = &liste.kukla;
    do {
        if (d->sonraki->onceki != d) {
            return false;
        }
        d = d->sonraki;
        ileri++;
    } while (d != &liste.kukla);
    for (d = liste.kukla.onceki; d != &liste.kukla; d = d->onceki) {
        geri++;
    }
    return ileri - 1 == liste.uzunluk && geri == liste.uzunluk;
}

// Tek bağlı listede adresi bilinen düğümü silmek: önce ÖNCEKİSİ bulunmalı
// (Dugum ** ile baştan yürüyerek): Θ(konum) ziyaret
static void tek_sil_adresle(Dugum*& bas, Dugum* hedef)
{
    Dugum** p = &bas;
    while (*p != hedef) {
        p = &(*p)->sonraki;
        ziyaret_sayisi++;
    }
    *p = hedef->sonraki;
    baglanti_sayisi++;
    delete hedef;
    birakma_sayisi++;
}

static void durum_yaz(const CiftListe& liste, long long b0)
{
    ileri_yaz(liste);
    geri_yaz(liste);
    std::cout << "  uzunluk = " << liste.uzunluk << ", bağlantı yazma = "
              << baglanti_sayisi - b0 << ", tutarlı mı? "
              << (tutarli_mi(liste) ? "evet" : "HAYIR") << "\n";
}

int main()
{
    {
        CiftListe liste;
        std::cout << "1) Kurma: sona_ekle 1, 4, 5, 9; basa_ekle 2\n";
        long long b0 = baglanti_sayisi;
        sona_ekle(liste, 1);
        sona_ekle(liste, 4);
        CDugum* bes = sona_ekle(liste, 5);   // tutamak: adres saklanır
        sona_ekle(liste, 9);
        basa_ekle(liste, 2);
        durum_yaz(liste, b0);

        std::cout << "\n2) Adresi bilinen düğümleri O(1) silme (yürüme "
                     "yok)\n";
        std::cout << "  sil 5 (ortadan, tutamakla):\n";
        b0 = baglanti_sayisi;
        dugumu_sil(liste, bes);
        durum_yaz(liste, b0);
        std::cout << "  sil ilk (kukla.sonraki):\n";
        b0 = baglanti_sayisi;
        dugumu_sil(liste, liste.kukla.sonraki);
        durum_yaz(liste, b0);
        std::cout << "  sil son (kukla.onceki):\n";
        b0 = baglanti_sayisi;
        dugumu_sil(liste, liste.kukla.onceki);
        durum_yaz(liste, b0);

        std::cout << "\n3) Kalanları sil: boş liste kukla'yı kendine "
                     "bağlar\n";
        while (liste.uzunluk > 0) {
            dugumu_sil(liste, liste.kukla.sonraki);
        }
        ileri_yaz(liste);
        std::cout << "  kukla.sonraki == kukla mı? "
                  << (liste.kukla.sonraki == &liste.kukla ? "evet" : "HAYIR")
                  << ", kukla.onceki == kukla mı? "
                  << (liste.kukla.onceki == &liste.kukla ? "evet" : "HAYIR")
                  << "\n  tutarlı mı? "
                  << (tutarli_mi(liste) ? "evet" : "HAYIR") << "\n";

        std::cout << "\n4) n = 1000 düğümü rastgele sırayla adresle silme "
                     "(tohum 42)\n";
        const int N = 1000;
        std::vector<CDugum*> cift_adres(N);
        std::vector<Dugum*> tek_adres(N);
        std::vector<int> sira(N);
        Dugum* tek_bas = nullptr;
        Dugum* tek_son = nullptr;
        for (int i = 0; i < N; i++) {
            cift_adres[i] = sona_ekle(liste, i);
            Dugum* d = new Dugum{i, nullptr};
            ayirma_sayisi++;
            if (tek_son == nullptr) {
                tek_bas = d;
            } else {
                tek_son->sonraki = d;
            }
            tek_son = d;
            tek_adres[i] = d;
            sira[i] = i;
        }
        rastgele_tohum(42);
        rastgele_karistir(sira);
        baglanti_sayisi = 0;
        ziyaret_sayisi = 0;
        for (int i = 0; i < N; i++) {
            dugumu_sil(liste, cift_adres[sira[i]]);
        }
        std::cout << "  çift bağlı: ziyaret = " << ziyaret_sayisi
                  << ", bağlantı yazma = " << baglanti_sayisi
                  << " (2n), tutarlı mı? "
                  << (tutarli_mi(liste) ? "evet" : "HAYIR") << "\n";
        baglanti_sayisi = 0;
        for (int i = 0; i < N; i++) {
            tek_sil_adresle(tek_bas, tek_adres[sira[i]]);
        }
        std::cout << "  tek bağlı : ziyaret = " << ziyaret_sayisi
                  << " (n²/4 ≈ " << N * N / 4 << "), bağlantı yazma = "
                  << baglanti_sayisi << "\n";
        std::cout << "  bedel: çift bağlı düğümde ikinci bağlantı alanı "
                     "(onceki)\n";
    }   // ~CiftListe

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list (çift bağlı;
 * erase(yineleyici) O(1)); Python — collections.deque (bloklardan oluşan
 * iki uçlu yapı; ortadan silme O(n)). */

/* H08_09_iki_isaretci.cpp — AP-2 Hafta 8 · Örnek 9 (★★)
 * Amaç    : İki işaretçi tekniği: ortadaki düğüm (yavaş–hızlı) ve sondan
 *           k'ıncı düğüm (k adım önden giden işaretçi); sözleşmeler
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_09_iki_isaretci.cpp -o H08_09_iki_isaretci
 * Çalıştır: ./H08_09_iki_isaretci
 * Eşleri  : c/H08_09_iki_isaretci.c · python/H08_09_iki_isaretci.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ilerletme_sayisi = 0;  // p = p->sonraki adımları

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Sahiplik (RAII): yıkıcı düğümleri siler; kopyalanamaz
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

// 10, 20, ..., 10n değerli n düğümlük liste
static Dugum* onlar_listesi(int n)
{
    Dugum* bas = nullptr;
    for (int i = n; i >= 1; i--) {
        Dugum* d = dugum_olustur(10 * i);
        d->sonraki = bas;
        bas = d;
    }
    return bas;
}

// Yavaş–hızlı: hızlı iki, yavaş bir adım atar. Sözleşme: n düğümde 0
// tabanlı ⌊n/2⌋ indisli düğüm (çift n'de İKİ ortadan İKİNCİSİ); boşsa
// nullptr. Hızlı sona varınca yavaş ortadadır: tek geçiş.
static Dugum* ortadaki(Dugum* bas)
{
    Dugum* yavas = bas;
    Dugum* hizli = bas;
    while (hizli != nullptr && hizli->sonraki != nullptr) {
        yavas = yavas->sonraki;
        hizli = hizli->sonraki->sonraki;
        ilerletme_sayisi += 3;
    }
    return yavas;
}

// Hızlı bir adım önden başlar: ⌊(n-1)/2⌋ indisli düğüm (çift n'de
// BİRİNCİ orta; birleştirmeli sıralamada ilk yarının sonu, Örnek 12)
static Dugum* ilk_orta(Dugum* bas)
{
    if (bas == nullptr) {
        return nullptr;
    }
    Dugum* yavas = bas;
    Dugum* hizli = bas->sonraki;
    ilerletme_sayisi++;
    while (hizli != nullptr && hizli->sonraki != nullptr) {
        yavas = yavas->sonraki;
        hizli = hizli->sonraki->sonraki;
        ilerletme_sayisi += 3;
    }
    return yavas;
}

// Sondan k'ıncı (k = 1: son düğüm). Sözleşme: k < 1 ya da k > n ise
// nullptr. ileri, k adım önden gider; ileri nullptr olunca geri hedeftedir.
static Dugum* sondan_k(Dugum* bas, int k)
{
    if (k < 1) {
        return nullptr;
    }
    Dugum* ileri = bas;
    for (int i = 0; i < k; i++) {
        if (ileri == nullptr) {
            return nullptr;              // liste k'dan kısa
        }
        ileri = ileri->sonraki;
        ilerletme_sayisi++;
    }
    Dugum* geri = bas;
    while (ileri != nullptr) {
        ileri = ileri->sonraki;
        geri = geri->sonraki;
        ilerletme_sayisi += 2;
    }
    return geri;
}

// Karşılaştırma için iki geçişli sürümler: önce uzunluk, sonra yürüme
static int uzunluk(const Dugum* bas)
{
    int n = 0;
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        n++;
        ilerletme_sayisi++;
    }
    return n;
}

static Dugum* indisteki(Dugum* bas, int i)
{
    Dugum* p = bas;
    for (int j = 0; j < i; j++) {
        p = p->sonraki;
        ilerletme_sayisi++;
    }
    return p;
}

static std::string hucre(const Dugum* d, int indis)
{
    if (d == nullptr) {
        return "NULL";
    }
    return std::to_string(d->veri) + " (" + std::to_string(indis) + ")";
}

// d'nin bas'tan indisi (yoksa -1)
static int indis_bul(const Dugum* bas, const Dugum* d)
{
    int i = 0;
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki, i++) {
        if (p == d) {
            return i;
        }
    }
    return -1;
}

int main()
{
    std::cout << "1) Ortadaki düğüm; liste 10, 20, ..., 10n\n";
    std::cout << "  sözleşme: ortadaki -> indis n/2 (çiftte ikinci orta), "
                 "ilk_orta -> (n-1)/2\n";
    std::cout << "     n  ortadaki (indis)  ilk_orta (indis)  döngü turu\n";
    for (int n = 0; n <= 7; n++) {
        Liste liste;
        liste.bas = onlar_listesi(n);
        ilerletme_sayisi = 0;
        Dugum* o = ortadaki(liste.bas);
        long long tur = ilerletme_sayisi / 3;
        Dugum* ilk = ilk_orta(liste.bas);
        std::cout << "  " << std::setw(4) << n << "  " << std::setw(16)
                  << hucre(o, indis_bul(liste.bas, o)) << "  "
                  << std::setw(16) << hucre(ilk, indis_bul(liste.bas, ilk))
                  << "  " << std::setw(10) << tur << "\n";
    }

    std::cout << "\n2) Sondan k'ıncı; liste [10 -> 20 -> 30 -> 40 -> 50 -> "
                 "NULL]\n";
    std::cout << "  sözleşme: k = 1 son düğüm; k < 1 ya da k > n ise NULL\n";
    {
        Liste liste;
        liste.bas = onlar_listesi(5);
        for (int k = 0; k <= 6; k++) {
            ilerletme_sayisi = 0;
            Dugum* d = sondan_k(liste.bas, k);
            std::cout << "  k = " << k << ": " << std::left << std::setw(8)
                      << hucre(d, indis_bul(liste.bas, d)) << std::right
                      << "  ilerletme = " << ilerletme_sayisi << "\n";
        }
    }

    std::cout << "\n3) Kâhinle sınama: 500 rastgele liste (n = 0..40, tohum "
                 "42), her k = 0..n+1\n";
    rastgele_tohum(42);
    int uyusmaz = 0, sinama = 0;
    for (int t = 0; t < 500; t++) {
        int n = rastgele_aralik(0, 40);
        Liste liste;
        liste.bas = onlar_listesi(n);
        Dugum* o = ortadaki(liste.bas);
        sinama++;
        if ((n == 0 && o != nullptr) ||
            (n > 0 && indis_bul(liste.bas, o) != n / 2)) {
            uyusmaz++;
        }
        for (int k = 0; k <= n + 1; k++) {
            Dugum* d = sondan_k(liste.bas, k);
            int beklenen = (k >= 1 && k <= n) ? n - k : -1;   // kâhin
            sinama++;
            if ((beklenen < 0 && d != nullptr) ||
                (beklenen >= 0 && indis_bul(liste.bas, d) != beklenen)) {
                uyusmaz++;
            }
        }
    }
    std::cout << "  sınama = " << sinama << ", uyuşmazlık = " << uyusmaz
              << "\n";

    std::cout << "\n4) İlerletme sayısı, n = 100000: tek geçiş ve iki "
                 "geçiş\n";
    {
        Liste liste;
        liste.bas = onlar_listesi(100000);
        ilerletme_sayisi = 0;
        Dugum* o1 = ortadaki(liste.bas);
        long long tek = ilerletme_sayisi;
        ilerletme_sayisi = 0;
        Dugum* o2 = indisteki(liste.bas, uzunluk(liste.bas) / 2);
        std::cout << "  ortadaki : yavaş–hızlı = " << tek << ", iki geçiş = "
                  << ilerletme_sayisi << "; aynı düğüm? "
                  << (o1 == o2 ? "evet" : "HAYIR") << "\n";
        ilerletme_sayisi = 0;
        Dugum* s1 = sondan_k(liste.bas, 10);
        tek = ilerletme_sayisi;
        ilerletme_sayisi = 0;
        Dugum* s2 = indisteki(liste.bas, uzunluk(liste.bas) - 10);
        std::cout << "  sondan 10: iki işaretçi = " << tek
                  << ", iki geçiş = " << ilerletme_sayisi << "; aynı düğüm? "
                  << (s1 == s2 ? "evet" : "HAYIR") << "\n";
        std::cout << "  (ilerletme: bir işaretçiyi bir düğüm ileri taşımak) "
                     "İş aynıdır;\n  kazanç: uzunluğu ayrıca hesaplamadan "
                     "tek döngüde sonuç\n";
    }

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::next(it, n / 2),
 * std::prev(l.end(), k) (std::list, çift yönlü yineleyici); Python —
 * yerleşik bağlı liste yok (dizide a[len(a) // 2], a[-k]). */

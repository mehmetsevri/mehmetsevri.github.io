/* H08_10_floyd_dongu.cpp — AP-2 Hafta 8 · Örnek 10 (★★★)
 * Amaç    : Floyd döngü tespiti (kaplumbağa ve tavşan): buluşma, döngü
 *           başlangıcı (μ) ve döngü uzunluğu (λ); yok etmeden önce kırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_10_floyd_dongu.cpp -o H08_10_floyd_dongu
 * Çalıştır: ./H08_10_floyd_dongu
 * Eşleri  : c/H08_10_floyd_dongu.c · python/H08_10_floyd_dongu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;                // düğümün konumu: 0..n-1
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long adim_sayisi = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

// Yalnızca döngüsüz listede çağrılır (döngülüde sonsuza dek döner)
static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Sahiplik (RAII): yıkıcı düğümleri siler. DİKKAT: döngülü listede
// yıkıcıdan ÖNCE donguyu_kir çağrılmalıdır.
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

// 0..n-1 konumlu n düğüm; mu >= 0 ise son düğüm mu konumundakine bağlanır
// (döngü), mu < 0 ise döngü yok.
static Dugum* dongulu_liste_kur(int n, int mu)
{
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    Dugum* hedef = nullptr;
    for (int i = 0; i < n; i++) {
        Dugum* d = dugum_olustur(i);
        if (son == nullptr) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
        if (i == mu) {
            hedef = d;
        }
    }
    if (son != nullptr) {
        son->sonraki = hedef;            // mu < 0 ise nullptr kalır
    }
    return bas;
}

// Evre 1: kaplumbağa bir, tavşan iki adım atar. Döngü varsa döngünün
// içinde buluşurlar (buluşma düğümü döner); yoksa tavşan nullptr'a varır.
static Dugum* bulusma_bul(Dugum* bas, bool izle)
{
    Dugum* kaplumbaga = bas;
    Dugum* tavsan = bas;
    while (tavsan != nullptr && tavsan->sonraki != nullptr) {
        kaplumbaga = kaplumbaga->sonraki;
        tavsan = tavsan->sonraki->sonraki;
        adim_sayisi++;
        if (izle) {
            std::cout << "  adım " << adim_sayisi << ": kaplumbağa = "
                      << kaplumbaga->veri << ", tavşan = " << tavsan->veri
                      << "\n";
        }
        if (kaplumbaga == tavsan) {
            return kaplumbaga;
        }
    }
    return nullptr;
}

// Evre 2: kaplumbağa baştan, tavşan buluşmadan; ikisi de BİRER adım.
// μ adım sonra döngünün başlangıç düğümünde buluşurlar.
static Dugum* dongu_baslangici(Dugum* bas, Dugum* bulusma, bool izle)
{
    Dugum* kaplumbaga = bas;
    Dugum* tavsan = bulusma;
    while (kaplumbaga != tavsan) {
        kaplumbaga = kaplumbaga->sonraki;
        tavsan = tavsan->sonraki;
        adim_sayisi++;
        if (izle) {
            std::cout << "  adım " << adim_sayisi << ": kaplumbağa = "
                      << kaplumbaga->veri << ", tavşan = " << tavsan->veri
                      << "\n";
        }
    }
    return kaplumbaga;
}

// Evre 3: buluşma düğümünden çıkıp ona geri dönene kadar say: λ
static int dongu_uzunlugu(const Dugum* bulusma)
{
    int lambda = 1;
    for (const Dugum* p = bulusma->sonraki; p != bulusma; p = p->sonraki) {
        lambda++;
    }
    return lambda;
}

// Döngünün son düğümünü bulup sonraki'sini nullptr yapar (yok etmeden önce)
static Dugum* donguyu_kir(Dugum* baslangic)
{
    Dugum* p = baslangic;
    while (p->sonraki != baslangic) {
        p = p->sonraki;
    }
    p->sonraki = nullptr;
    return p;
}

int main()
{
    rastgele_tohum(42);
    int n = 10;
    int mu = rastgele_aralik(0, n - 1);
    std::cout << "1) n = " << n << " düğüm (0.." << n - 1
              << "); döngü konumu LCG ile (tohum 42): " << n - 1 << " -> "
              << mu << "\n";
    {
        Liste liste;
        liste.bas = dongulu_liste_kur(n, mu);
        std::cout << "  evre 1: kaplumbağa 1, tavşan 2 adım (başlangıç: ikisi "
                     "de 0)\n";
        adim_sayisi = 0;
        Dugum* bulusma = bulusma_bul(liste.bas, true);
        std::cout << "  buluşma düğümü = " << bulusma->veri << " ("
                  << adim_sayisi << " adım)\n";
        std::cout << "  evre 2: kaplumbağa baştan (0), tavşan buluşmadan ("
                  << bulusma->veri << "); birer adım\n";
        adim_sayisi = 0;
        Dugum* baslangic = dongu_baslangici(liste.bas, bulusma, true);
        std::cout << "  döngü başlangıcı = " << baslangic->veri << " (mu = "
                  << adim_sayisi << " adım), döngü uzunluğu lambda = "
                  << dongu_uzunlugu(bulusma) << "\n";
        Dugum* kirilan = donguyu_kir(baslangic);
        std::cout << "  döngü kırıldı: " << kirilan->veri
                  << " -> NULL; yok etme güvenli\n";
    }   // yıkıcı: döngü kırıldığı için sonlanır

    std::cout << "\n2) Seçilmiş durumlar (mu = -1: döngü yok)\n";
    std::cout << "     n   mu  bulunan mu  lambda  evre1 adım  evre2 adım  "
                 "doğru\n";
    const int durum[8][2] = {{1, -1}, {1, 0}, {2, -1}, {2, 1}, {6, 0},
                             {10, 9}, {10, -1}, {100, 37}};
    for (const auto& d : durum) {
        int dn = d[0], dmu = d[1];
        Liste liste;
        liste.bas = dongulu_liste_kur(dn, dmu);
        adim_sayisi = 0;
        Dugum* bulusma = bulusma_bul(liste.bas, false);
        long long a1 = adim_sayisi;
        int bulunan = -1, lambda = 0;
        long long a2 = 0;
        if (bulusma != nullptr) {
            adim_sayisi = 0;
            Dugum* baslangic = dongu_baslangici(liste.bas, bulusma, false);
            a2 = adim_sayisi;
            bulunan = baslangic->veri;
            lambda = dongu_uzunlugu(bulusma);
            donguyu_kir(baslangic);
        }
        bool dogru = bulunan == dmu && (dmu < 0 || lambda == dn - dmu);
        std::cout << "  " << std::setw(4) << dn << " " << std::setw(4) << dmu
                  << " " << std::setw(11) << bulunan << " " << std::setw(7)
                  << lambda << " " << std::setw(11) << a1 << " "
                  << std::setw(11) << a2 << "  " << (dogru ? "evet" : "HAYIR")
                  << "\n";
    }

    std::cout << "\n3) 1000 rastgele liste (n = 1..200; %20 döngüsüz; tohum "
                 "42)\n";
    int dogru_sayisi = 0, sinir_icinde = 0;
    long long toplam1 = 0, toplam_mulambda = 0;
    for (int t = 0; t < 1000; t++) {
        int rn = rastgele_aralik(1, 200);
        int rmu = rastgele_aralik(0, 4) == 0 ? -1 : rastgele_aralik(0, rn - 1);
        Liste liste;
        liste.bas = dongulu_liste_kur(rn, rmu);
        adim_sayisi = 0;
        Dugum* bulusma = bulusma_bul(liste.bas, false);
        long long a1 = adim_sayisi;
        int bulunan = -1, lambda = 0;
        if (bulusma != nullptr) {
            Dugum* baslangic = dongu_baslangici(liste.bas, bulusma, false);
            bulunan = baslangic->veri;
            lambda = dongu_uzunlugu(bulusma);
            donguyu_kir(baslangic);
        }
        bool dogru = bulunan == rmu && (rmu < 0 || lambda == rn - rmu);
        dogru_sayisi += dogru;
        if (rmu >= 0) {
            sinir_icinde += a1 <= rmu + lambda;   // evre 1 <= mu + lambda
            toplam1 += a1;
            toplam_mulambda += rn;                // mu + lambda = n
        } else {
            sinir_icinde += a1 == rn / 2;         // döngüsüz: n/2 adım
        }
    }
    std::cout << "  doğru (mu, lambda): " << dogru_sayisi
              << "/1000; evre 1 adım sınırı tutan: " << sinir_icinde
              << "/1000\n";
    std::cout << std::fixed << std::setprecision(3)
              << "  döngülülerde evre 1 adımı / (mu + lambda) = "
              << static_cast<double>(toplam1) / toplam_mulambda << "\n";

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::list ve
 * std::forward_list döngü kurdurmaz); Python — yok. */

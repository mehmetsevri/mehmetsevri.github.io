/* H08_12_listede_birlestirmeli.cpp — AP-2 Hafta 8 · Örnek 12 (★★★)
 * Amaç    : Bağlı listede birleştirmeli sıralama: ortadan bölme (yavaş–
 *           hızlı), birleştirme (Örnek 8); ek dizi yok, kararlı, derinlik
 *           O(log n); dizi kâhinine karşı rastgele sınama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_12_listede_birlestirmeli.cpp -o H08_12_listede_birlestirmeli
 * Çalıştır: ./H08_12_listede_birlestirmeli
 * Eşleri  : c/H08_12_listede_birlestirmeli.c ·
 *           python/H08_12_listede_birlestirmeli.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;
    int kimlik;              // oluşturulma sırası (kararlılık denetimi)
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long karsilastirma_sayisi = 0, baglanti_sayisi = 0;
static long long cagri_sayisi = 0;
static int en_derin = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, static_cast<int>(ayirma_sayisi), nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Sahiplik (RAII): yıkıcı düğümleri siler; kopyalanamaz
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

static Dugum* liste_olustur(const std::vector<int>& a)
{
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    for (int x : a) {
        Dugum* d = dugum_olustur(x);
        if (son == nullptr) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void kisa_yaz(const Dugum* bas, bool kimlikli)
{
    std::cout << "[";
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        std::cout << (p == bas ? "" : " ") << p->veri;
        if (kimlikli) {
            std::cout << "#" << p->kimlik;
        }
    }
    std::cout << "]";
}

// Örnek 8'deki birleştirme: kukla düğüm, kararlı (<=), yeni düğüm yok
static Dugum* birlestir(Dugum* a, Dugum* b)
{
    Dugum kukla{0, 0, nullptr};
    Dugum* son = &kukla;
    while (a != nullptr && b != nullptr) {
        karsilastirma_sayisi++;
        if (a->veri <= b->veri) {
            son->sonraki = a;
            a = a->sonraki;
        } else {
            son->sonraki = b;
            b = b->sonraki;
        }
        baglanti_sayisi++;
        son = son->sonraki;
    }
    son->sonraki = (a != nullptr) ? a : b;
    baglanti_sayisi++;
    return kukla.sonraki;
}

// En az iki düğümlü listeyi ikiye böler: ilk yarı ⌈n/2⌉ düğüm (yavaş–
// hızlı, hızlı bir adım önden: çift n'de BİRİNCİ orta). İkinci yarının
// başını döndürür.
static Dugum* ortadan_bol(Dugum* bas)
{
    Dugum* yavas = bas;
    Dugum* hizli = bas->sonraki;
    while (hizli != nullptr && hizli->sonraki != nullptr) {
        yavas = yavas->sonraki;
        hizli = hizli->sonraki->sonraki;
    }
    Dugum* ikinci = yavas->sonraki;
    yavas->sonraki = nullptr;  // ilk yarıyı kes
    baglanti_sayisi++;
    return ikinci;
}

// Sıralı listenin başını döndürür; düğümler yeniden bağlanır (ek dizi
// yok). Derinlik ⌈log2 n⌉ + 1: yığında O(log n) çerçeve.
static Dugum* birlestirmeli_sirala(Dugum* bas, int derinlik)
{
    cagri_sayisi++;
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (bas == nullptr || bas->sonraki == nullptr) {
        return bas;                       // 0 ya da 1 düğüm: sıralı
    }
    Dugum* ikinci = ortadan_bol(bas);
    Dugum* sol = birlestirmeli_sirala(bas, derinlik + 1);
    Dugum* sag = birlestirmeli_sirala(ikinci, derinlik + 1);
    return birlestir(sol, sag);
}

// Aynı özyineleme; her çağrıda bölme ve birleştirme girintiyle yazılır
static Dugum* birlestirmeli_sirala_izle(Dugum* bas, int derinlik)
{
    if (bas == nullptr || bas->sonraki == nullptr) {
        return bas;
    }
    std::string girinti(2 * derinlik, ' ');
    std::cout << girinti << "böl ";
    kisa_yaz(bas, false);
    Dugum* ikinci = ortadan_bol(bas);
    std::cout << " -> ";
    kisa_yaz(bas, false);
    std::cout << " | ";
    kisa_yaz(ikinci, false);
    std::cout << "\n";
    Dugum* sol = birlestirmeli_sirala_izle(bas, derinlik + 1);
    Dugum* sag = birlestirmeli_sirala_izle(ikinci, derinlik + 1);
    Dugum* sonuc = birlestir(sol, sag);
    std::cout << girinti << "birleştir -> ";
    kisa_yaz(sonuc, false);
    std::cout << "\n";
    return sonuc;
}

static int tavan_log2(long long n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

// Sıralı mı, kararlı mı (eşitlerde kimlik artan), kâhinle aynı mı?
static bool denetle(const Dugum* bas, const std::vector<int>& kahin,
                    bool& kararli)
{
    std::size_t i = 0;
    bool ayni = true;
    kararli = true;
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki, i++) {
        ayni = ayni && i < kahin.size() && p->veri == kahin[i];
        if (p->sonraki != nullptr && p->veri == p->sonraki->veri &&
            p->kimlik > p->sonraki->kimlik) {
            kararli = false;
        }
    }
    return ayni && i == kahin.size();
}

int main()
{
    std::cout << "1) Bölme ve birleştirme ağacı, n = 7\n";
    {
        Liste liste;
        liste.bas = liste_olustur({5, 2, 7, 2, 9, 1, 5});
        std::cout << "  girdi : ";
        kisa_yaz(liste.bas, true);
        std::cout << "   (veri#kimlik)\n";
        liste.bas = birlestirmeli_sirala_izle(liste.bas, 1);
        std::cout << "  çıktı : ";
        kisa_yaz(liste.bas, true);
        std::cout << "\n";
        bool kararli = true;
        for (const Dugum* p = liste.bas; p->sonraki != nullptr;
             p = p->sonraki) {
            if (p->veri == p->sonraki->veri &&
                p->kimlik > p->sonraki->kimlik) {
                kararli = false;
            }
        }
        std::cout << "  kararlı mı (2#2 2#4 ve 5#1 5#7 sırası korundu mu)? "
                  << (kararli ? "evet" : "HAYIR") << "\n";
    }

    std::cout << "\n2) Sınır durumları\n";
    const std::vector<int> s = {8, 3};
    for (int n = 0; n <= 2; n++) {
        Liste liste;
        liste.bas = liste_olustur(std::vector<int>(s.begin(), s.begin() + n));
        std::cout << "  n = " << n << ": ";
        kisa_yaz(liste.bas, false);
        liste.bas = birlestirmeli_sirala(liste.bas, 1);
        std::cout << " -> ";
        kisa_yaz(liste.bas, false);
        std::cout << "\n";
    }

    std::cout << "\n3) Kâhinle 200 rastgele sınama (n = 0..300, anahtar "
                 "0..20, tohum 42)\n";
    rastgele_tohum(42);
    int dogru = 0, kararli_sayisi = 0, derinlik_tutan = 0;
    long long yeni = 0;
    for (int t = 0; t < 200; t++) {
        int n = rastgele_aralik(0, 300);
        std::vector<int> x = rastgele_dizi(n, 0, 20);
        std::vector<int> kahin = x;
        std::sort(kahin.begin(), kahin.end());       // yalnızca kâhin
        Liste liste;
        liste.bas = liste_olustur(x);
        long long a0 = ayirma_sayisi;
        en_derin = 0;
        liste.bas = birlestirmeli_sirala(liste.bas, 1);
        yeni += ayirma_sayisi - a0;
        bool k;
        dogru += denetle(liste.bas, kahin, k);
        kararli_sayisi += k;
        derinlik_tutan += en_derin <= tavan_log2(n) + 1;
    }
    std::cout << "  kâhinle aynı: " << dogru << "/200, kararlı: "
              << kararli_sayisi << "/200, derinlik <= ⌈lg n⌉ + 1: "
              << derinlik_tutan << "/200,\n  sıralamada yeni düğüm: " << yeni
              << "\n";

    std::cout << "\n4) Sayaçlar (rastgele anahtar 0..10^6)\n";
    std::cout << "        n  karşılaştırma  k/(n lg n)  derinlik  ⌈lg n⌉+1"
                 "     çağrı  bağlantı\n";
    for (int n : {1000, 10000, 100000}) {
        std::vector<int> b = rastgele_dizi(n, 0, 1000000);
        Liste liste;
        liste.bas = liste_olustur(b);
        karsilastirma_sayisi = baglanti_sayisi = cagri_sayisi = 0;
        en_derin = 0;
        liste.bas = birlestirmeli_sirala(liste.bas, 1);
        std::cout << std::fixed << std::setprecision(3) << "  "
                  << std::setw(7) << n << " " << std::setw(14)
                  << karsilastirma_sayisi << " " << std::setw(11)
                  << karsilastirma_sayisi / (n * std::log2(n)) << " "
                  << std::setw(9) << en_derin << " " << std::setw(9)
                  << tavan_log2(n) + 1 << " " << std::setw(9) << cagri_sayisi
                  << " " << std::setw(9) << baglanti_sayisi << "\n";
    }

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; qsort yalnızca kâhin); C++ —
 * std::list::sort (kararlı, düğümleri taşır); Python — list.sort /
 * sorted (Timsort; dinamik dizide). */

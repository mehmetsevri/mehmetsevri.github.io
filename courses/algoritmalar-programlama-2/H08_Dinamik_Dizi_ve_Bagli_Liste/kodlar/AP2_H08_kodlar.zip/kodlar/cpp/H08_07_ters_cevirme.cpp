/* H08_07_ters_cevirme.cpp — AP-2 Hafta 8 · Örnek 7 (★★)
 * Amaç    : Listeyi ters çevirme: yinelemeli (onceki–gecerli–sonraki
 *           üçlüsü, O(1) ek bellek) ve özyinelemeli (derinlik n)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_07_ters_cevirme.cpp -o H08_07_ters_cevirme
 * Çalıştır: ./H08_07_ters_cevirme [n]   (n verilirse: özyinelemeli, n düğüm)
 * Eşleri  : c/H08_07_ters_cevirme.c · python/H08_07_ters_cevirme.py
 * Çıktı   : üç dilde aynı (=) (argümanlı çalıştırma dile özgüdür)
 */
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long baglanti_sayisi = 0;
static int en_derin = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Sahiplik (RAII): yıkıcı düğümleri siler; kopyalanamaz
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

static Dugum* liste_olustur(const std::vector<int>& a, std::size_t n)
{
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    for (std::size_t i = 0; i < n; i++) {
        Dugum* d = dugum_olustur(a[i]);
        if (son == nullptr) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum* bas)
{
    std::cout << "[";
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        std::cout << p->veri << " -> ";
    }
    std::cout << "NULL]";
}

static void deger_yaz(const Dugum* d)
{
    if (d != nullptr) {
        std::cout << d->veri;
    } else {
        std::cout << "NULL";
    }
}

// Yinelemeli ters çevirme; yeni başı döndürür. Değişmez: onceki, ters
// çevrilmiş önekin başı; gecerli, henüz işlenmemiş sonekin başı.
// Her turda: (1) sonraki bağlantıyı kaydet, (2) oku tersine çevir,
// (3) onceki ve gecerli'yi bir düğüm ilerlet.
static Dugum* ters_cevir(Dugum* bas)
{
    Dugum* onceki = nullptr;
    Dugum* gecerli = bas;
    while (gecerli != nullptr) {
        Dugum* sonraki = gecerli->sonraki; // kaydet
        gecerli->sonraki = onceki;         // çevir
        baglanti_sayisi++;
        onceki = gecerli;                  // ilerle
        gecerli = sonraki;
    }
    return onceki;
}

// Aynı döngü; her adımda üç işaretçi ve iki parça yazdırılır
static Dugum* ters_cevir_izle(Dugum* bas)
{
    Dugum* onceki = nullptr;
    Dugum* gecerli = bas;
    int adim = 0;
    while (gecerli != nullptr) {
        Dugum* sonraki = gecerli->sonraki;
        gecerli->sonraki = onceki;
        baglanti_sayisi++;
        std::cout << "  adım " << ++adim << ": sonraki = ";
        deger_yaz(sonraki);
        std::cout << ", bağ " << gecerli->veri << " -> ";
        deger_yaz(onceki);
        onceki = gecerli;
        gecerli = sonraki;
        std::cout << ", onceki = ";
        deger_yaz(onceki);
        std::cout << ", gecerli = ";
        deger_yaz(gecerli);
        std::cout << "\n          ters: ";
        liste_yaz(onceki);
        std::cout << "  kalan: ";
        liste_yaz(gecerli);
        std::cout << "\n";
    }
    return onceki;
}

// Özyinelemeli: önce kuyruğu ters çevir, sonra bas'ı onun sonuna tak.
// Dönüşte bas->sonraki, ters kuyruğun SON düğümüdür.
static Dugum* ters_cevir_ozyinelemeli(Dugum* bas, int derinlik)
{
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (bas == nullptr || bas->sonraki == nullptr) {
        return bas;                         // 0 ya da 1 düğüm
    }
    Dugum* yeni_bas = ters_cevir_ozyinelemeli(bas->sonraki, derinlik + 1);
    bas->sonraki->sonraki = bas;
    bas->sonraki = nullptr;
    baglanti_sayisi += 2;
    return yeni_bas;
}

// Liste a[n-1..0] ile aynı mı? (kâhin: dizinin tersi)
static bool ters_mi(const Dugum* bas, const std::vector<int>& a, int n)
{
    int i = n - 1;
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki, i--) {
        if (i < 0 || p->veri != a[i]) {
            return false;
        }
    }
    return i == -1;
}

// Liste a[0..n-1] ile aynı mı?
static bool ayni_mi(const Dugum* bas, const std::vector<int>& a, int n)
{
    int i = 0;
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki, i++) {
        if (i >= n || p->veri != a[i]) {
            return false;
        }
    }
    return i == n;
}

int main(int argc, char* argv[])
{
    if (argc > 1) {   // isteğe bağlı: derin özyineleme gösterimi
        long n = 0;
        try {
            std::size_t son = 0;
            std::string s = argv[1];
            n = std::stol(s, &son);
            if (son != s.size() || n < 1 || n > 100000000) {
                throw std::invalid_argument(s);
            }
        } catch (...) {
            std::cerr << "kullanım: " << argv[0] << " [n]\n";
            return 2;
        }
        Liste liste;
        for (long i = 0; i < n; i++) {
            Dugum* d = dugum_olustur(static_cast<int>(n - i));
            d->sonraki = liste.bas;
            liste.bas = d;
        }
        liste.bas = ters_cevir_ozyinelemeli(liste.bas, 1);
        std::cout << "özyinelemeli ters çevirme, n = " << n
                  << ": en büyük derinlik = " << en_derin << ", baş = "
                  << liste.bas->veri << "\n";
        return 0;
    }
    const std::vector<int> a = {1, 2, 3, 4, 5};

    std::cout << "1) Yinelemeli ters çevirme, adım adım\n  başta: ";
    {
        Liste liste;
        liste.bas = liste_olustur(a, 5);
        liste_yaz(liste.bas);
        std::cout << "\n";
        baglanti_sayisi = 0;
        liste.bas = ters_cevir_izle(liste.bas);
        std::cout << "  sonuç: ";
        liste_yaz(liste.bas);
        std::cout << "  bağlantı yazma = " << baglanti_sayisi << " (n)\n";
    }

    std::cout << "\n2) Özyinelemeli ters çevirme\n  sonuç: ";
    {
        Liste liste;
        liste.bas = liste_olustur(a, 5);
        baglanti_sayisi = 0;
        en_derin = 0;
        liste.bas = ters_cevir_ozyinelemeli(liste.bas, 1);
        liste_yaz(liste.bas);
        std::cout << "\n  bağlantı yazma = " << baglanti_sayisi
                  << " (2(n - 1)), en büyük derinlik = " << en_derin
                  << " (n)\n";
    }

    std::cout << "\n3) Sınır durumları\n";
    const std::vector<int> tek = {7};
    for (std::size_t n = 0; n <= 1; n++) {
        Liste l1, l2;
        l1.bas = liste_olustur(tek, n);
        l2.bas = liste_olustur(tek, n);
        l1.bas = ters_cevir(l1.bas);
        l2.bas = ters_cevir_ozyinelemeli(l2.bas, 1);
        std::cout << "  n = " << n << ": yinelemeli ";
        liste_yaz(l1.bas);
        std::cout << ", özyinelemeli ";
        liste_yaz(l2.bas);
        std::cout << "\n";
    }

    std::cout << "\n4) Kâhinle sınama (tohum 42, değerler 0..999)\n";
    rastgele_tohum(42);
    std::vector<int> b = rastgele_dizi(1000, 0, 999);
    {
        Liste liste;
        liste.bas = liste_olustur(b, 1000);
        baglanti_sayisi = 0;
        liste.bas = ters_cevir(liste.bas);
        bool dogru = ters_mi(liste.bas, b, 1000);
        liste.bas = ters_cevir(liste.bas);     // iki kez ters = asıl
        bool geri = ayni_mi(liste.bas, b, 1000);
        std::cout << "  yinelemeli, n = 1000: tersiyle aynı mı? "
                  << (dogru ? "evet" : "HAYIR") << "; iki kez ters = asıl mı? "
                  << (geri ? "evet" : "HAYIR") << "\n    bağlantı yazma = "
                  << baglanti_sayisi << " (2n)\n";
    }
    {
        Liste liste;
        liste.bas = liste_olustur(b, 500);
        baglanti_sayisi = 0;
        en_derin = 0;
        liste.bas = ters_cevir_ozyinelemeli(liste.bas, 1);
        std::cout << "  özyinelemeli, n = 500: tersiyle aynı mı? "
                  << (ters_mi(liste.bas, b, 500) ? "evet" : "HAYIR")
                  << "\n    bağlantı yazma = " << baglanti_sayisi
                  << " (2(n - 1)), en büyük derinlik = " << en_derin << "\n";
    }

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list::reverse,
 * std::list::reverse; Python — list.reverse() / reversed (dinamik dizide
 * öğe takası; bağlantı yok). */

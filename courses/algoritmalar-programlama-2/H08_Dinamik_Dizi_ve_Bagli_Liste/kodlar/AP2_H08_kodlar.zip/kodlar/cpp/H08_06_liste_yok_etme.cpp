/* H08_06_liste_yok_etme.cpp — AP-2 Hafta 8 · Örnek 6 (★★)
 * Amaç    : Listenin yok edilmesi ve bellek sahipliği: yinelemeli yok etme
 *           (sonraki delete'ten ÖNCE saklanır), derin kopya, sayaçlar
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_06_liste_yok_etme.cpp -o H08_06_liste_yok_etme
 * Çalıştır: ./H08_06_liste_yok_etme [n]      (n: bölüm 4, varsayılan 1e5)
 * Denetim : -fsanitize=address,undefined ve valgrind --leak-check=full
 * Eşleri  : c/H08_06_liste_yok_etme.c · python/H08_06_liste_yok_etme.py
 * Çıktı   : Δ — 1–4 üç dilde aynı; 5. bölüm dile özgü (bkz. Dil Penceresi)
 */
#include <cstddef>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

struct Dugum {
    int veri;
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static int en_derin = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

// Sahiplik: dönen liste çağıranındır; liste_yok_et ile serbest bırakılır
static Dugum* liste_olustur(const std::vector<int>& a)
{
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    for (int x : a) {
        Dugum* d = dugum_olustur(x);
        if (son == nullptr) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

// Yinelemeli yok etme: O(1) ek bellek. sonraki, delete'ten ÖNCE saklanır.
// Başvuruyla gelen baş sonunda nullptr olur: sarkan baş işaretçisi kalmaz.
static void liste_yok_et(Dugum*& bas)
{
    Dugum* d = bas;
    while (d != nullptr) {
        Dugum* sonraki = d->sonraki;
        dugum_birak(d);
        d = sonraki;
    }
    bas = nullptr;
}

// Aynı adımlar, her adım yazdırılarak
static void liste_yok_et_izle(Dugum*& bas)
{
    Dugum* d = bas;
    while (d != nullptr) {
        Dugum* sonraki = d->sonraki;
        if (sonraki != nullptr) {
            std::cout << "  bırak " << d->veri << " (sonraki = "
                      << sonraki->veri << " önceden saklandı)\n";
        } else {
            std::cout << "  bırak " << d->veri << " (sonraki = NULL)\n";
        }
        dugum_birak(d);
        d = sonraki;
    }
    bas = nullptr;
}

// Özyinelemeli yok etme: önce kuyruk, sonra düğüm. Derinlik n + 1 olur;
// büyük n'de yığın taşabilir (yalnız küçük listede kullanılır).
static void liste_yok_et_ozyinelemeli(Dugum* bas, int derinlik)
{
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (bas == nullptr) {
        return;
    }
    liste_yok_et_ozyinelemeli(bas->sonraki, derinlik + 1);
    dugum_birak(bas);
}

// Derin kopya. Sahiplik: dönen kopya çağıranındır; kaynak değişmez.
static Dugum* liste_kopyala(const Dugum* kaynak)
{
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    for (const Dugum* p = kaynak; p != nullptr; p = p->sonraki) {
        Dugum* d = dugum_olustur(p->veri);
        if (son == nullptr) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum* bas)
{
    std::cout << "[";
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        std::cout << p->veri << " -> ";
    }
    std::cout << "NULL]";
}

static void sayac_yaz()
{
    std::cout << "  ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << ", canlı = "
              << ayirma_sayisi - birakma_sayisi << "\n";
}

// Sahiplik (RAII): Liste nesnesi düğümlerin sahibidir; yıkıcı siler
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

// Sahiplik std::unique_ptr ile: her düğüm sonrakinin TEK sahibidir
struct UDugum {
    int veri;
    std::unique_ptr<UDugum> sonraki;
    explicit UDugum(int v) : veri(v) { ayirma_sayisi++; }
    ~UDugum() { birakma_sayisi++; }
};

struct UListe {
    std::unique_ptr<UDugum> bas;
    // Varsayılan yıkıcı bas'ı siler, o da sonraki'yi siler, ...: n
    // derinlikte özyineleme (büyük n'de yığın taşar). Döngüyle koparırız:
    ~UListe()
    {
        while (bas != nullptr) {
            bas = std::move(bas->sonraki);   // eski baş burada silinir
        }
    }
};

int main(int argc, char* argv[])
{
    long n_buyuk = 100000;
    if (argc > 1) {
        try {
            std::size_t son = 0;
            std::string s = argv[1];
            n_buyuk = std::stol(s, &son);
            if (son != s.size() || n_buyuk < 1) {
                throw std::invalid_argument(s);
            }
        } catch (...) {
            std::cerr << "kullanım: " << argv[0] << " [n >= 1]\n";
            return 2;
        }
    }
    const std::vector<int> a = {3, 1, 4, 1, 5};

    std::cout << "1) Liste kurma: sahiplik çağıranda\n  bas = ";
    Dugum* bas = liste_olustur(a);
    liste_yaz(bas);
    std::cout << "\n";
    sayac_yaz();

    std::cout << "\n2) Yinelemeli yok etme: sonraki free'den ÖNCE "
                 "saklanır\n";
    liste_yok_et_izle(bas);
    std::cout << "  bas " << (bas == nullptr ? "==" : "!=") << " NULL\n";
    sayac_yaz();

    std::cout << "\n3) Derin kopya: iki ayrı sahip, iki ayrı yok etme\n";
    Dugum* asil = liste_olustur(a);
    Dugum* kopya = liste_kopyala(asil);
    kopya->veri = 99;   // kopyayı değiştirmek asılı etkilemez
    std::cout << "  asıl  = ";
    liste_yaz(asil);
    std::cout << "\n  kopya = ";
    liste_yaz(kopya);
    std::cout << "\n";
    sayac_yaz();
    liste_yok_et(asil);
    liste_yok_et(kopya);
    std::cout << "  ikisi de yok edildi:\n";
    sayac_yaz();

    std::cout << "\n4) Büyük liste ve özyinelemeli yok etme\n";
    long long b0 = birakma_sayisi;
    Dugum* buyuk = nullptr;
    for (long i = 0; i < n_buyuk; i++) {
        Dugum* d = dugum_olustur(static_cast<int>(i % 1000));
        d->sonraki = buyuk;
        buyuk = d;
    }
    liste_yok_et(buyuk);
    std::cout << "  n = " << n_buyuk << ": yinelemeli yok etme "
              << birakma_sayisi - b0 << " düğüm bıraktı, ek bellek O(1)\n";
    Dugum* kucuk = liste_olustur(a);
    en_derin = 0;
    liste_yok_et_ozyinelemeli(kucuk, 1);
    std::cout << "  özyinelemeli (n = 5): en büyük derinlik = " << en_derin
              << " (n + 1); n = " << n_buyuk << " için " << n_buyuk + 1
              << "\n";
    std::cout << "  1-4. bölümlerin toplamı:\n";
    sayac_yaz();

    std::cout << "\n5) C++: RAII (yıkıcı kapsam sonunda siler) ve "
                 "std::unique_ptr (tek sahip)\n";
    Dugum* orta = nullptr;
    {
        Liste liste;
        liste.bas = liste_olustur(a);
        orta = liste.bas->sonraki->sonraki;
        std::cout << "  { Liste liste; ... } içinde orta->veri = "
                  << orta->veri << "\n";
        b0 = birakma_sayisi;
    }   // yıkıcı: liste_yok_et(liste.bas)
    std::cout << "  kapsam kapandı: yıkıcı " << birakma_sayisi - b0
              << " düğümü sildi; ham işaretçi orta sahip değildir,\n"
                 "  artık SARKANDIR (C'deki gibi; okunursa tanımsız "
                 "davranış)\n";
    orta = nullptr;
    b0 = birakma_sayisi;
    {
        UListe u;
        for (long i = 0; i < n_buyuk; i++) {
            auto d = std::make_unique<UDugum>(static_cast<int>(i % 1000));
            d->sonraki = std::move(u.bas);
            u.bas = std::move(d);
        }
    }   // ~UListe: döngüyle tek tek
    std::cout << "  unique_ptr zinciri (n = " << n_buyuk << "): ~UListe "
              << birakma_sayisi - b0 << " düğümü döngüyle sildi\n"
                 "  (varsayılan yıkıcı özyinelemeli olurdu: derinlik n)\n";
    sayac_yaz();
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list / std::forward_list
 * yıkıcısı (RAII), std::unique_ptr; Python — başvuru sayımı + döngüsel çöp
 * toplayıcı (gc). */

/* H08_02_buyume_stratejisi.cpp — AP-2 Hafta 8 · Örnek 2 (★★)
 * Amaç    : Büyüme stratejisine göre toplam kopya sayısı (+1, +10, × 1,5,
 *           × 2): amortize analizde toplam yöntemi ve kapalı biçimler
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_02_buyume_stratejisi.cpp -o H08_02_buyume_stratejisi
 * Çalıştır: ./H08_02_buyume_stratejisi
 * Eşleri  : c/H08_02_buyume_stratejisi.c ·
 *           python/H08_02_buyume_stratejisi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

const int STRATEJI_SAYISI = 4;
// Adlar 8 karakterlik doldurulmuş dizgiler: std::setw bayt sayar,
// "×" UTF-8'de 2 bayttır; hizalama üç dilde aynı kalsın
const std::string AD[STRATEJI_SAYISI] = {"+1      ", "+10     ",
                                         "× 1,5   ", "× 2     "};

// Kapasite k doluyken yeni kapasite. × 1,5'te tamsayı yuvarlaması üç
// dilde aynı tanımlıdır: k + (k + 1) / 2, yani ⌈1,5 k⌉ (k = 1 → 2).
static long long yeni_kapasite(int strateji, long long k)
{
    switch (strateji) {
    case 0:
        return k + 1;
    case 1:
        return k + 10;
    case 2:
        return k + (k + 1) / 2;
    default:
        return 2 * k;
    }
}

struct Sonuc {
    long long kopya;      // büyütmelerde kopyalanan öğe toplamı
    long long buyutme;    // kapasite değişimi sayısı
    long long kapasite;   // n eklemeden sonraki kapasite
};

// n sona eklemenin benzetimi (ilk kapasite 1): dolu dizide büyütme,
// boyut kadar öğeyi yeni bloğa kopyalar. Toplam yöntemi: Σ kopya.
static Sonuc benzet(int strateji, long long n)
{
    Sonuc s = {0, 0, 1};
    for (long long boyut = 0; boyut < n; boyut++) {  // ekleme öncesi
        if (boyut == s.kapasite) {
            s.kopya += boyut;
            s.kapasite = yeni_kapasite(strateji, s.kapasite);
            s.buyutme++;
        }
    }
    return s;
}

// +k için kapalı biçim: kapasiteler 1, 1 + k, 1 + 2k, ...; n - 1'i
// aşmayan m tanesinde büyütülür: Σ (1 + jk) = m + k m (m - 1) / 2
static long long arti_k_kapali(long long n, long long k)
{
    if (n < 2) {
        return 0;
    }
    long long m = (n - 2) / k + 1;
    return m + k * m * (m - 1) / 2;
}

// × 2 için kapalı biçim: 1 + 2 + 4 + ... + 2^(m-1) = 2^m - 1;
// m = ⌊log2(n - 1)⌋ + 1 (n - 1'i aşmayan ikinin kuvvetleri)
static long long kat_2_kapali(long long n)
{
    if (n < 2) {
        return 0;
    }
    long long kuvvet = 1;
    while (kuvvet <= n - 1) {
        kuvvet *= 2;
    }
    return kuvvet - 1;
}

static void zaman_cizelgesi(int strateji, long long n)
{
    std::vector<long long> kapasiteler;
    long long kapasite = 1;
    kapasiteler.push_back(kapasite);
    for (long long boyut = 0; boyut < n; boyut++) {
        if (boyut == kapasite) {
            kapasite = yeni_kapasite(strateji, kapasite);
            kapasiteler.push_back(kapasite);
        }
    }
    Sonuc s = benzet(strateji, n);
    int m = static_cast<int>(kapasiteler.size());
    std::cout << "  " << AD[strateji] << ":";
    for (int i = 0; i < m; i++) {
        if (m > 8 && i == 4) {
            std::cout << " -> ...";
            i = m - 3;
            continue;
        }
        std::cout << (i == 0 ? " " : " -> ") << kapasiteler[i];
    }
    std::cout << "  (" << s.buyutme << " büyütme, " << s.kopya << " kopya)\n";
}

// Gerçek dinamik dizi: büyütmede yeni blok + öğe öğe kopya (sayılır)
struct DinamikDizi {
    int* veri;
    long long boyut, kapasite;
};

static long long gercek_kopya = 0;
// Sahiplik: d.veri dizinindir (new[]); dd_ekle eskisini, main sonuncuyu siler
static void dd_ekle(DinamikDizi& d, int x, int strateji)
{
    if (d.boyut == d.kapasite) {
        long long yeni = yeni_kapasite(strateji, d.kapasite);
        int* blok = new int[yeni];
        for (long long i = 0; i < d.boyut; i++) {
            blok[i] = d.veri[i];
            gercek_kopya++;
        }
        delete[] d.veri;
        d.veri = blok;
        d.kapasite = yeni;
    }
    d.veri[d.boyut++] = x;
}

int main()
{
    std::cout << "1) Kapasite zaman çizelgesi: n = 20 ekleme, ilk kapasite 1\n";
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        zaman_cizelgesi(s, 20);
    }

    std::cout << "\n2) Toplam yöntemi: n sona eklemede toplam kopya\n";
    std::cout << "  strateji       n büyüt.       kopya   kopya/n "
                 "kapalı biçim   oran kuram\n";
    const long long nler[3] = {1000, 10000, 100000};
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        for (long long n : nler) {
            Sonuc r = benzet(s, n);
            long long kapali = -1;
            double kuram;          // kestirim (+k) ya da üst sınır
            std::string ad;
            if (s <= 1) {
                long long k = (s == 0) ? 1 : 10;
                kapali = arti_k_kapali(n, k);
                kuram = static_cast<double>(n) * n / (2.0 * k);
                ad = "(n²/2k)";
            } else if (s == 2) {
                kuram = 3.0 * n;
                ad = "(<3n)";
            } else {
                kapali = kat_2_kapali(n);
                kuram = 2.0 * n;
                ad = "(<2n)";
            }
            std::cout << std::fixed << std::setprecision(3) << "  " << AD[s]
                      << " " << std::setw(7) << n << " " << std::setw(6)
                      << r.buyutme << " " << std::setw(11) << r.kopya << " "
                      << std::setw(9) << static_cast<double>(r.kopya) / n
                      << " ";
            if (kapali >= 0) {
                std::cout << std::setw(10) << kapali << " "
                          << (kapali == r.kopya ? "=" : "!");
            } else {
                std::cout << "           —";
            }
            std::cout << " " << std::setw(6) << r.kopya / kuram << " " << ad
                      << "\n";
        }
    }

    std::cout << "\n3) Gerçek dinamik dizi (öğe öğe kopya) ile benzetim, "
                 "n = 1000\n";
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        DinamikDizi d = {new int[1], 0, 1};
        gercek_kopya = 0;
        long long toplam = 0;
        for (int i = 0; i < 1000; i++) {
            dd_ekle(d, i, s);
        }
        for (long long i = 0; i < d.boyut; i++) {
            toplam += d.veri[i];
        }
        Sonuc r = benzet(s, 1000);
        std::cout << "  " << AD[s] << ": gerçek = " << std::setw(6)
                  << gercek_kopya << ", benzetim = " << std::setw(6)
                  << r.kopya << ", aynı mı? "
                  << (gercek_kopya == r.kopya ? "evet" : "HAYIR")
                  << "; toplam = " << toplam << "\n";
        delete[] d.veri;
    }

    std::cout << "\n4) Ödünleşim: n = 100000'de boş yuva (bellek israfı)\n";
    std::cout << "  strateji   kapasite  boş yuva  boş/kapasite\n";
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        Sonuc r = benzet(s, 100000);
        long long bos = r.kapasite - 100000;
        std::cout << "  " << AD[s] << " " << std::setw(10) << r.kapasite
                  << " " << std::setw(9) << bos << " " << std::setw(13)
                  << static_cast<double>(bos) / r.kapasite << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::vector büyüme çarpanı
 * gerçekleştirime bağlıdır (capacity() ile gözlenir); Python — list
 * fazladan ayırır (Objects/listobject.c; sys.getsizeof ile gözlenir). */

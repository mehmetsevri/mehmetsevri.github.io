/* H08_05_degere_gore_silme.cpp — AP-2 Hafta 8 · Örnek 5 (★★)
 * Amaç    : Değere göre silme: önce baş için özel durumlu sürüm (önceki–
 *           gecerli), sonra Dugum ** ile özel durumsuz sürüm; tümünü silme
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_05_degere_gore_silme.cpp -o H08_05_degere_gore_silme
 * Çalıştır: ./H08_05_degere_gore_silme
 * Eşleri  : c/H08_05_degere_gore_silme.c ·
 *           python/H08_05_degere_gore_silme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ziyaret_sayisi = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Sahiplik (RAII): yıkıcı düğümleri siler; kopyalanamaz
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

// a'dan sırayla liste kurar. Sahiplik: dönen liste çağıranındır.
static Dugum* liste_olustur(const std::vector<int>& a)
{
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    for (int x : a) {
        Dugum* d = dugum_olustur(x);
        if (son == nullptr) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum* bas)
{
    std::cout << "[";
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        std::cout << p->veri << " -> ";
    }
    std::cout << "NULL]";
}

// Ziyaret sayacı: bir düğümün verisine bakıldı
static bool aranan_mi(const Dugum* d, int x)
{
    ziyaret_sayisi++;
    return d->veri == x;
}

// Sürüm 1 (özel durumlu): önceki–gecerli ile ilk x'i siler ve YENİ BAŞI
// döndürür. Baş siliniyorsa ayrı bir dal gerekir.
static Dugum* sil_v1(Dugum* bas, int x)
{
    Dugum* onceki = nullptr;
    Dugum* gecerli = bas;
    while (gecerli != nullptr && !aranan_mi(gecerli, x)) {
        onceki = gecerli;
        gecerli = gecerli->sonraki;
    }
    if (gecerli == nullptr) {
        return bas;                          // x yok: liste aynı
    }
    if (onceki == nullptr) {
        bas = gecerli->sonraki;              // ÖZEL DURUM: baş siliniyor
    } else {
        onceki->sonraki = gecerli->sonraki;  // ortadaki ya da son düğüm
    }
    dugum_birak(gecerli);
    return bas;
}

// Sürüm 2 (Dugum **): baş işaretçisi BAŞVURUYLA (Dugum*&) gelir; p,
// "sıradaki düğümü gösteren bağlantının" adresidir. Başvuru yeniden
// bağlanamadığı için yürüyüşte yine Dugum** gerekir.
static bool sil_v2(Dugum*& bas, int x)
{
    Dugum** p = &bas;
    while (*p != nullptr && !aranan_mi(*p, x)) {
        p = &(*p)->sonraki;
    }
    if (*p == nullptr) {
        return false;
    }
    Dugum* silinen = *p;
    *p = silinen->sonraki;  // baş da aynı satır
    dugum_birak(silinen);
    return true;
}

// Tüm x'leri siler (Dugum ** ile); silinen düğüm sayısını döndürür
static int tumunu_sil(Dugum*& bas, int x)
{
    int silinen_sayisi = 0;
    Dugum** p = &bas;
    while (*p != nullptr) {
        if (aranan_mi(*p, x)) {
            Dugum* silinen = *p;
            *p = silinen->sonraki;   // p ilerlemez: yeni *p de denetlenir
            dugum_birak(silinen);
            silinen_sayisi++;
        } else {
            p = &(*p)->sonraki;
        }
    }
    return silinen_sayisi;
}

static void sonuc_yaz(const std::string& etiket, const Dugum* bas,
                      long long b0)
{
    std::cout << "  " << etiket << " ";
    liste_yaz(bas);
    std::cout << "  " << (birakma_sayisi > b0 ? "silindi" : "yok")
              << ", ziyaret = " << ziyaret_sayisi << "\n";
}

int main()
{
    const std::vector<int> a = {3, 1, 4, 1, 5, 9, 2, 6};
    const std::vector<int> silinecek = {3, 1, 6, 7};
    const std::vector<std::string> etiket = {"sil 3 (baş) :", "sil 1 (ilk) :",
                                             "sil 6 (son) :", "sil 7 (yok) :"};

    std::cout << "1) Sürüm 1 (özel durumlu, yeni başı döndürür)\n"
                 "  başta       : ";
    {
        Liste liste;
        liste.bas = liste_olustur(a);
        liste_yaz(liste.bas);
        std::cout << "\n";
        for (int i = 0; i < 4; i++) {
            long long b0 = birakma_sayisi;
            ziyaret_sayisi = 0;
            liste.bas = sil_v1(liste.bas, silinecek[i]);
            sonuc_yaz(etiket[i], liste.bas, b0);
        }
    }

    std::cout << "\n2) Sürüm 2 (özel durumsuz; C/C++: Dugum **, Python: "
                 "kukla düğüm)\n  başta       : ";
    {
        Liste liste;
        liste.bas = liste_olustur(a);
        liste_yaz(liste.bas);
        std::cout << "\n";
        for (int i = 0; i < 4; i++) {
            long long b0 = birakma_sayisi;
            ziyaret_sayisi = 0;
            sil_v2(liste.bas, silinecek[i]);
            sonuc_yaz(etiket[i], liste.bas, b0);
        }
    }

    std::cout << "\n3) Sınır durumları (iki sürüm aynı sonucu verir)\n";
    for (int surum = 1; surum <= 2; surum++) {
        const int x[3] = {5, 8, 8};
        const std::string et[3] = {"tek düğüm, sil 5 :", "tek düğüm, sil 8 :",
                                   "boş liste, sil 8 :"};
        Liste liste;
        liste.bas = liste_olustur({8});
        std::cout << "  sürüm " << surum << "\n";
        for (int i = 0; i < 3; i++) {
            long long b0 = birakma_sayisi;
            ziyaret_sayisi = 0;
            if (surum == 1) {
                liste.bas = sil_v1(liste.bas, x[i]);
            } else {
                sil_v2(liste.bas, x[i]);
            }
            sonuc_yaz(et[i], liste.bas, b0);
        }
    }

    std::cout << "\n4) Tüm 1'leri silme (ardışık ve baştaki 1'ler)\n";
    {
        Liste liste;
        liste.bas = liste_olustur({1, 1, 2, 1, 3, 1, 1});
        std::cout << "  başta : ";
        liste_yaz(liste.bas);
        ziyaret_sayisi = 0;
        int k = tumunu_sil(liste.bas, 1);
        std::cout << "\n  sonra : ";
        liste_yaz(liste.bas);
        std::cout << "  silinen = " << k << ", ziyaret = " << ziyaret_sayisi
                  << "\n";
    }

    std::cout << "\n5) 1000 rastgele sınama (n = 0..10, değerler 0..5, "
                 "tohum 42)\n";
    rastgele_tohum(42);
    int ayni = 0, ziyaret_ayni = 0;
    for (int t = 0; t < 1000; t++) {
        int n = rastgele_aralik(0, 10);
        std::vector<int> dizi(n);
        for (int i = 0; i < n; i++) {
            dizi[i] = rastgele_aralik(0, 5);
        }
        int x = rastgele_aralik(0, 5);
        Liste l1, l2;
        l1.bas = liste_olustur(dizi);
        l2.bas = liste_olustur(dizi);
        ziyaret_sayisi = 0;
        l1.bas = sil_v1(l1.bas, x);
        long long z1 = ziyaret_sayisi;
        ziyaret_sayisi = 0;
        sil_v2(l2.bas, x);
        bool esit = true;
        const Dugum* p = l1.bas;
        const Dugum* q = l2.bas;
        while (p != nullptr && q != nullptr) {
            esit = esit && p->veri == q->veri;
            p = p->sonraki;
            q = q->sonraki;
        }
        ayni += esit && p == nullptr && q == nullptr;
        ziyaret_ayni += z1 == ziyaret_sayisi;
    }
    std::cout << "  sonuç listeleri aynı: " << ayni
              << "/1000, ziyaret sayıları aynı: " << ziyaret_ayni
              << "/1000\n";

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list::remove
 * (tüm eşleşenler), std::list::remove; Python — list.remove(x) (ilk
 * eşleşen; dinamik dizide Θ(n) kaydırma). */

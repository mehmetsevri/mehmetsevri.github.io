/* H08_08_sirali_birlestirme.cpp — AP-2 Hafta 8 · Örnek 8 (★★)
 * Amaç    : İki sıralı listeyi kukla düğümle birleştirme: düğümler yeniden
 *           bağlanır (yeni düğüm yok), kararlı, Θ(n + m); kâhinle sınama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_08_sirali_birlestirme.cpp -o H08_08_sirali_birlestirme
 * Çalıştır: ./H08_08_sirali_birlestirme
 * Eşleri  : c/H08_08_sirali_birlestirme.c ·
 *           python/H08_08_sirali_birlestirme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;
    int kimlik;              // oluşturulma sırası (kararlılık denetimi)
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long karsilastirma_sayisi = 0, baglanti_sayisi = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, static_cast<int>(ayirma_sayisi), nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Sahiplik (RAII): yıkıcı düğümleri siler; kopyalanamaz
struct Liste {
    Dugum* bas = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

static Dugum* liste_olustur(const std::vector<int>& a, int n)
{
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    for (int i = 0; i < n; i++) {
        Dugum* d = dugum_olustur(a[i]);
        if (son == nullptr) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum* bas, bool kimlikli)
{
    std::cout << "[";
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        std::cout << p->veri;
        if (kimlikli) {
            std::cout << "#" << p->kimlik;
        }
        std::cout << " -> ";
    }
    std::cout << "NULL]";
}

// İki sıralı listeyi düğümleri YENİDEN BAĞLAYARAK birleştirir; yeni düğüm
// ayrılmaz. Kararlı: eşitlikte a'dan gelen önce (<=). Sahiplik: a ve b'nin
// düğümleri dönen listeye geçer; çağıran a ve b'yi artık kullanmaz.
static Dugum* birlestir(Dugum* a, Dugum* b)
{
    Dugum kukla{0, 0, nullptr};   // yığında: ayrılmaz, bırakılmaz
    Dugum* son = &kukla;          // sonucun son düğümü
    while (a != nullptr && b != nullptr) {
        karsilastirma_sayisi++;
        if (a->veri <= b->veri) {
            son->sonraki = a;
            a = a->sonraki;
        } else {
            son->sonraki = b;
            b = b->sonraki;
        }
        baglanti_sayisi++;
        son = son->sonraki;
    }
    son->sonraki = (a != nullptr) ? a : b;   // kalan kuyruk tek bağlantıyla
    baglanti_sayisi++;
    return kukla.sonraki;
}

// Aynı döngü; her adım yazdırılarak
static Dugum* birlestir_izle(Dugum* a, Dugum* b)
{
    Dugum kukla{0, 0, nullptr};
    Dugum* son = &kukla;
    int adim = 0;
    while (a != nullptr && b != nullptr) {
        std::cout << "  adım " << ++adim << ": a.baş = " << a->veri
                  << ", b.baş = " << b->veri << " -> ";
        karsilastirma_sayisi++;
        if (a->veri <= b->veri) {
            std::cout << a->veri << " (a)\n";
            son->sonraki = a;
            a = a->sonraki;
        } else {
            std::cout << b->veri << " (b)\n";
            son->sonraki = b;
            b = b->sonraki;
        }
        baglanti_sayisi++;
        son = son->sonraki;
    }
    son->sonraki = (a != nullptr) ? a : b;
    baglanti_sayisi++;
    std::cout << "  kalan kuyruk (" << (a != nullptr ? "a" : "b")
              << ") tek bağlantıyla eklendi: ";
    liste_yaz(son->sonraki, false);
    std::cout << "\n";
    return kukla.sonraki;
}

// n öğe: rastgele artışlarla sıralı dizi (sıralama gerekmez)
static std::vector<int> sirali_dizi(int n, int en_cok_artis)
{
    std::vector<int> x(n);
    int deger = rastgele_aralik(0, 3);
    for (int i = 0; i < n; i++) {
        x[i] = deger;
        deger += rastgele_aralik(0, en_cok_artis);
    }
    return x;
}

int main()
{
    std::cout << "1) Kukla düğümle birleştirme\n";
    {
        Liste a, b, c;
        a.bas = liste_olustur({1, 3, 5, 7}, 4);
        b.bas = liste_olustur({2, 3, 5, 8, 9}, 5);
        std::cout << "  a = ";
        liste_yaz(a.bas, false);
        std::cout << "\n  b = ";
        liste_yaz(b.bas, false);
        std::cout << "\n";
        long long a0 = ayirma_sayisi;
        c.bas = birlestir_izle(a.bas, b.bas);
        a.bas = b.bas = nullptr;      // sahiplik devri: düğümler artık c'nin
        std::cout << "  c = ";
        liste_yaz(c.bas, false);
        std::cout << "\n  karşılaştırma = " << karsilastirma_sayisi
                  << ", bağlantı yazma = " << baglanti_sayisi
                  << ", yeni düğüm = " << ayirma_sayisi - a0 << "\n";

        std::cout << "\n2) Kararlılık: veri#kimlik (a'nın düğümleri 1-4, "
                     "b'ninkiler 5-9)\n  c = ";
        liste_yaz(c.bas, true);
        bool kararli = true;
        for (const Dugum* p = c.bas; p != nullptr && p->sonraki != nullptr;
             p = p->sonraki) {
            if (p->veri == p->sonraki->veri &&
                p->kimlik > p->sonraki->kimlik) {
                kararli = false;
            }
        }
        std::cout << "\n  eşit anahtarlarda a'dan gelen önce mi? "
                  << (kararli ? "evet" : "HAYIR") << "\n";
    }

    std::cout << "\n3) Sınır durumları\n";
    const std::vector<std::vector<int>> sol = {{}, {}, {1, 2}, {5}};
    const std::vector<std::vector<int>> sag = {{}, {1, 2}, {}, {1, 2, 3}};
    for (std::size_t t = 0; t < sol.size(); t++) {
        Liste x, y, z;
        x.bas = liste_olustur(sol[t], static_cast<int>(sol[t].size()));
        y.bas = liste_olustur(sag[t], static_cast<int>(sag[t].size()));
        std::cout << "  ";
        liste_yaz(x.bas, false);
        std::cout << " + ";
        liste_yaz(y.bas, false);
        z.bas = birlestir(x.bas, y.bas);
        x.bas = y.bas = nullptr;
        std::cout << " = ";
        liste_yaz(z.bas, false);
        std::cout << "\n";
    }

    std::cout << "\n4) Kâhinle 1000 rastgele sınama (uzunluk 0..20, tohum "
                 "42)\n";
    rastgele_tohum(42);
    int dogru = 0, kararli_sayisi = 0;
    long long yeni = 0;
    for (int t = 0; t < 1000; t++) {
        int n = rastgele_aralik(0, 20), m = rastgele_aralik(0, 20);
        std::vector<int> x = sirali_dizi(n, 3);
        std::vector<int> y = sirali_dizi(m, 3);
        std::vector<int> kahin = x;
        kahin.insert(kahin.end(), y.begin(), y.end());
        std::sort(kahin.begin(), kahin.end());     // yalnızca kâhin
        Liste p, q, z;
        p.bas = liste_olustur(x, n);
        q.bas = liste_olustur(y, m);
        long long a0 = ayirma_sayisi;
        z.bas = birlestir(p.bas, q.bas);
        p.bas = q.bas = nullptr;
        yeni += ayirma_sayisi - a0;
        int i = 0;
        bool ayni = true, k = true;
        for (const Dugum* d = z.bas; d != nullptr; d = d->sonraki, i++) {
            ayni = ayni && i < n + m && d->veri == kahin[i];
            if (d->sonraki != nullptr && d->veri == d->sonraki->veri &&
                d->kimlik > d->sonraki->kimlik) {
                k = false;
            }
        }
        dogru += ayni && i == n + m;
        kararli_sayisi += k;
    }
    std::cout << "  kâhinle aynı: " << dogru << "/1000, kararlı: "
              << kararli_sayisi << "/1000, birleştirmede yeni düğüm: " << yeni
              << "\n";

    std::cout << "\n5) Maliyet Θ(n + m): n = m = 100000 (artışlar 0..9)\n";
    {
        std::vector<int> x = sirali_dizi(100000, 9);
        std::vector<int> y = sirali_dizi(100000, 9);
        Liste a, b, c;
        a.bas = liste_olustur(x, 100000);
        b.bas = liste_olustur(y, 100000);
        karsilastirma_sayisi = baglanti_sayisi = 0;
        c.bas = birlestir(a.bas, b.bas);
        a.bas = b.bas = nullptr;
        std::cout << "  karşılaştırma = " << karsilastirma_sayisi
                  << " (<= n + m - 1 = 199999), bağlantı yazma = "
                  << baglanti_sayisi << "\n";
    }

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list::merge,
 * std::forward_list::merge (düğümleri taşır; kararlı), std::merge
 * (dizilerde); Python — heapq.merge (yineleyici), sorted(a + b). */

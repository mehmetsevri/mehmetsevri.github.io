/* H08_04_sona_ekleme_arama.cpp — AP-2 Hafta 8 · Örnek 4 (★)
 * Amaç    : Kuyruk (son) işaretçisiyle O(1) sona ekleme, kuyruksuz Θ(n)
 *           sona ekleme ile ziyaret karşılaştırması; doğrusal arama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_04_sona_ekleme_arama.cpp -o H08_04_sona_ekleme_arama
 * Çalıştır: ./H08_04_sona_ekleme_arama
 * Eşleri  : c/H08_04_sona_ekleme_arama.c ·
 *           python/H08_04_sona_ekleme_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Dugum {
    int veri;
    Dugum* sonraki;
};

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ziyaret_sayisi = 0, baglanti_sayisi = 0;

// Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır
static Dugum* dugum_olustur(int veri)
{
    ayirma_sayisi++;
    return new Dugum{veri, nullptr};
}

static void dugum_birak(Dugum* d)
{
    delete d;
    birakma_sayisi++;
}

static void liste_yok_et(Dugum* bas)
{
    while (bas != nullptr) {
        Dugum* sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

// Liste başlığı: baş ve kuyruk (son düğüm) işaretçileri. Sahiplik (RAII):
// yıkıcı düğümleri siler; kopyalanamaz.
struct Liste {
    Dugum* bas = nullptr;
    Dugum* son = nullptr;
    Liste() = default;
    Liste(const Liste&) = delete;
    Liste& operator=(const Liste&) = delete;
    ~Liste() { liste_yok_et(bas); }
};

static void liste_yaz(const Dugum* bas)
{
    std::cout << "[";
    for (const Dugum* p = bas; p != nullptr; p = p->sonraki) {
        std::cout << p->veri << " -> ";
    }
    std::cout << "NULL]";
}

// Kuyruk işaretçisiyle sona ekleme: yürümeden O(1)
static void sona_ekle(Liste& liste, int x)
{
    Dugum* d = dugum_olustur(x);
    if (liste.son == nullptr) {  // boş liste
        liste.bas = d;
    } else {
        liste.son->sonraki = d;
        baglanti_sayisi++;
    }
    liste.son = d;
}

// Kuyruk işaretçisi olmadan sona ekleme: son düğüme kadar yürür, Θ(n).
// Yeni başı döndürür (boş listede baş değişir).
static Dugum* sona_ekle_kuyruksuz(Dugum* bas, int x)
{
    Dugum* d = dugum_olustur(x);
    if (bas == nullptr) {
        return d;
    }
    Dugum* p = bas;
    ziyaret_sayisi++;
    while (p->sonraki != nullptr) {
        p = p->sonraki;
        ziyaret_sayisi++;
    }
    p->sonraki = d;
    baglanti_sayisi++;
    return bas;
}

// İlk x'i arar; düğümü ya da nullptr döndürür, konum 0 tabanlı (yoksa -1)
static Dugum* ara(Dugum* bas, int x, int& konum)
{
    int i = 0;
    for (Dugum* p = bas; p != nullptr; p = p->sonraki) {
        ziyaret_sayisi++;
        if (p->veri == x) {
            konum = i;
            return p;
        }
        i++;
    }
    konum = -1;
    return nullptr;
}

static void ara_yaz(Dugum* bas, int x, const std::string& on_ek)
{
    int konum;
    ziyaret_sayisi = 0;
    Dugum* d = ara(bas, x, konum);
    if (d != nullptr) {
        std::cout << "  " << on_ek << "ara(" << x << "): bulundu, konum "
                  << konum << ", ziyaret = " << ziyaret_sayisi << "\n";
    } else {
        std::cout << "  " << on_ek << "ara(" << x
                  << "): bulunamadı (NULL), ziyaret = " << ziyaret_sayisi
                  << "\n";
    }
}

int main()
{
    std::cout << "1) Kuyruk işaretçisiyle sona ekleme: 3, 1, 4, 1, 5\n";
    {
        Liste liste;
        for (int x : {3, 1, 4, 1, 5}) {
            sona_ekle(liste, x);
            std::cout << "  sona_ekle(" << x << "): ";
            liste_yaz(liste.bas);
            std::cout << "  bas = " << liste.bas->veri << ", son = "
                      << liste.son->veri << "\n";
        }

        std::cout << "\n2) Doğrusal arama (ilk eşleşme)\n";
        ara_yaz(liste.bas, 4, "");
        ara_yaz(liste.bas, 1, "");
        ara_yaz(liste.bas, 5, "");
        ara_yaz(liste.bas, 9, "");
        ara_yaz(nullptr, 3, "boş listede ");
    }

    std::cout << "\n3) n sona ekleme: kuyruklu ve kuyruksuz ziyaret sayısı\n";
    std::cout << "       n  kuyruklu  kuyruksuz   n(n-1)/2\n";
    for (int n : {10, 100, 1000}) {
        Liste k;
        ziyaret_sayisi = 0;
        for (int i = 0; i < n; i++) {
            sona_ekle(k, i);
        }
        long long kuyruklu = ziyaret_sayisi;
        Liste kuyruksuz;   // yalnızca bas kullanılır
        ziyaret_sayisi = 0;
        for (int i = 0; i < n; i++) {
            kuyruksuz.bas = sona_ekle_kuyruksuz(kuyruksuz.bas, i);
        }
        std::cout << "  " << std::setw(6) << n << " " << std::setw(9)
                  << kuyruklu << " " << std::setw(10) << ziyaret_sayisi
                  << " " << std::setw(10)
                  << static_cast<long long>(n) * (n - 1) / 2 << "\n";
    }

    std::cout << "\n4) Arama maliyeti: 0..999 karıştırılmış (tohum 42), "
                 "her değer bir kez aranır\n";
    {
        std::vector<int> a(1000);
        for (int i = 0; i < 1000; i++) {
            a[i] = i;
        }
        rastgele_tohum(42);
        rastgele_karistir(a);
        Liste m;
        for (int x : a) {
            sona_ekle(m, x);
        }
        int konum;
        ziyaret_sayisi = 0;
        for (int x = 0; x < 1000; x++) {
            ara(m.bas, x, konum);
        }
        std::cout << std::fixed << std::setprecision(2)
                  << "  başarılı arama: ortalama ziyaret = "
                  << ziyaret_sayisi / 1000.0 << ", (n + 1) / 2 = "
                  << 1001 / 2.0 << "\n";
        ziyaret_sayisi = 0;
        ara(m.bas, -1, konum);
        std::cout << "  başarısız arama: ziyaret = " << ziyaret_sayisi
                  << " (= n)\n";
    }

    std::cout << "\nbellek: ayrılan = " << ayirma_sayisi << ", bırakılan = "
              << birakma_sayisi << " düğüm\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list::push_back,
 * std::find; Python — yerleşik bağlı liste yok (collections.deque.append,
 * x in d). */

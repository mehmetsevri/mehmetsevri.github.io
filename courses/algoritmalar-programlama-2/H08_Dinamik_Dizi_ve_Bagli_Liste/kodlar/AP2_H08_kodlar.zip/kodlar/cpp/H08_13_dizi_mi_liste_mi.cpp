/* H08_13_dizi_mi_liste_mi.cpp — AP-2 Hafta 8 · Örnek 13 (★★★)
 * Amaç    : Stroustrup deneyi: n rastgele tamsayıyı sıralı dinamik diziye
 *           ve bağlı listeye DOĞRUSAL arayarak ekle, sonra rastgele
 *           konumlardan sil; deterministik sayaçlar (+ isteğe bağlı süre;
 *           --olc ayrıca std::vector ve std::list kütüphane serisi)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_13_dizi_mi_liste_mi.cpp -o H08_13_dizi_mi_liste_mi
 * Çalıştır: ./H08_13_dizi_mi_liste_mi            (sayaçlar, n <= 1000)
 *           ./H08_13_dizi_mi_liste_mi --olc [n] [tekrar]   (süre ölçümü)
 * Eşleri  : c/H08_13_dizi_mi_liste_mi.c · python/H08_13_dizi_mi_liste_mi.py
 * Çıktı   : üç dilde aynı (=) (--olc çıktısı dile ve makineye özgüdür)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

struct DinamikDizi {
    int* veri = nullptr;
    std::size_t boyut = 0, kapasite = 0;
};

struct Dugum {
    int veri;
    Dugum* sonraki;
};

static long long dizi_karsilastirma = 0, dizi_kaydirma_ekle = 0;
static long long dizi_kaydirma_sil = 0;
static long long liste_ziyaret_ekle = 0, liste_ziyaret_sil = 0;
static long long ayirma_sayisi = 0, birakma_sayisi = 0;
// Sahiplik: d.veri (new[]) ve düğümler (new) görevindir; görev sonunda silinir
// Sıralı diziye x: konum DOĞRUSAL aranır (ilk > x), sağdakiler kayar
static void dizi_sirali_ekle(DinamikDizi& d, int x)
{
    std::size_t konum = 0;
    while (konum < d.boyut) {
        dizi_karsilastirma++;
        if (d.veri[konum] > x) {
            break;
        }
        konum++;
    }
    if (d.boyut == d.kapasite) {                  // × 2 büyütme
        std::size_t yeni = d.kapasite == 0 ? 1 : 2 * d.kapasite;
        int* blok = new int[yeni];
        for (std::size_t i = 0; i < d.boyut; i++) {
            blok[i] = d.veri[i];
        }
        delete[] d.veri;
        d.veri = blok;
        d.kapasite = yeni;
    }
    for (std::size_t j = d.boyut; j > konum; j--) {   // sağa kaydır
        d.veri[j] = d.veri[j - 1];
    }
    dizi_kaydirma_ekle += static_cast<long long>(d.boyut - konum);
    d.veri[konum] = x;
    d.boyut++;
}

// konum'daki öğeyi siler (sola kaydırarak); değerini döndürür
static int dizi_konumdan_sil(DinamikDizi& d, std::size_t konum)
{
    int x = d.veri[konum];
    for (std::size_t j = konum; j + 1 < d.boyut; j++) {
        d.veri[j] = d.veri[j + 1];
    }
    dizi_kaydirma_sil += static_cast<long long>(d.boyut - konum - 1);
    d.boyut--;
    return x;
}

// Sıralı listeye x: Dugum** ile ilk > x düğüme kadar yürünür, önüne
// bağlanır (ekleme O(1), konum bulma Θ(konum))
static void liste_sirali_ekle(Dugum*& bas, int x)
{
    Dugum** p = &bas;
    while (*p != nullptr) {
        liste_ziyaret_ekle++;
        if ((*p)->veri > x) {
            break;
        }
        p = &(*p)->sonraki;
    }
    *p = new Dugum{x, *p};
    ayirma_sayisi++;
}

// konum'daki düğüme yürüyüp siler; değerini döndürür
static int liste_konumdan_sil(Dugum*& bas, std::size_t konum)
{
    Dugum** p = &bas;
    for (std::size_t i = 0; i < konum; i++) {
        p = &(*p)->sonraki;
        liste_ziyaret_sil++;
    }
    Dugum* silinen = *p;
    int x = silinen->veri;
    *p = silinen->sonraki;
    delete silinen;
    birakma_sayisi++;
    return x;
}

// İş yükü verisi: değerler ve silme konumları (konumlar[i] < n - i)
static void is_yuku(std::vector<int>& degerler,
                    std::vector<std::size_t>& konumlar, std::size_t n)
{
    degerler.assign(n, 0);
    konumlar.assign(n, 0);
    rastgele_tohum(42);
    for (std::size_t i = 0; i < n; i++) {
        degerler[i] = static_cast<int>(rastgele_sayi());
    }
    for (std::size_t i = 0; i < n; i++) {
        konumlar[i] = static_cast<std::size_t>(
            rastgele_aralik(0, static_cast<int>(n - 1 - i)));
    }
}

// Silinen değerlerin toplamını (denetim) döndürür
static long long dizi_gorevi(const std::vector<int>& degerler,
                             const std::vector<std::size_t>& konumlar)
{
    DinamikDizi d;
    for (int x : degerler) {
        dizi_sirali_ekle(d, x);
    }
    long long toplam = 0;
    for (std::size_t k : konumlar) {
        toplam += dizi_konumdan_sil(d, k);
    }
    delete[] d.veri;
    return toplam;
}

static long long liste_gorevi(const std::vector<int>& degerler,
                              const std::vector<std::size_t>& konumlar)
{
    Dugum* bas = nullptr;
    for (int x : degerler) {
        liste_sirali_ekle(bas, x);
    }
    long long toplam = 0;
    for (std::size_t k : konumlar) {
        toplam += liste_konumdan_sil(bas, k);
    }
    return toplam;
}

// Kütüphane serisi: aynı algoritma (doğrusal arama), kaydırma/bağlama
// işini std::vector::insert/erase ve std::list::insert/erase yapar
static long long vector_gorevi(const std::vector<int>& degerler,
                               const std::vector<std::size_t>& konumlar)
{
    std::vector<int> v;
    for (int x : degerler) {
        std::size_t i = 0;
        while (i < v.size() && v[i] <= x) {
            i++;
        }
        v.insert(v.begin() + static_cast<std::ptrdiff_t>(i), x);
    }
    long long toplam = 0;
    for (std::size_t k : konumlar) {
        auto it = v.begin() + static_cast<std::ptrdiff_t>(k);
        toplam += *it;
        v.erase(it);
    }
    return toplam;
}

static long long list_gorevi(const std::vector<int>& degerler,
                             const std::vector<std::size_t>& konumlar)
{
    std::list<int> l;
    for (int x : degerler) {
        auto it = l.begin();
        while (it != l.end() && *it <= x) {
            ++it;
        }
        l.insert(it, x);
    }
    long long toplam = 0;
    for (std::size_t k : konumlar) {
        auto it = std::next(l.begin(), static_cast<std::ptrdiff_t>(k));
        toplam += *it;
        l.erase(it);
    }
    return toplam;
}

// İki yapı aynı sıralı diziyi kuruyor mu? (ekleme bitince karşılaştır)
static bool ayni_sira_mi(const std::vector<int>& degerler)
{
    DinamikDizi d;
    Dugum* bas = nullptr;
    for (int x : degerler) {
        dizi_sirali_ekle(d, x);
        liste_sirali_ekle(bas, x);
    }
    bool ayni = true;
    std::size_t i = 0;
    for (Dugum* p = bas; p != nullptr; p = p->sonraki, i++) {
        ayni = ayni && i < d.boyut && p->veri == d.veri[i] &&
               (i == 0 || d.veri[i - 1] <= d.veri[i]);
    }
    ayni = ayni && i == d.boyut;
    while (bas != nullptr) {
        liste_konumdan_sil(bas, 0);
    }
    delete[] d.veri;
    return ayni;
}

static int olc(int argc, char* argv[])
{
    long n = 20000;
    int tekrar = 5;
    try {
        if (argc > 2) {
            n = std::stol(argv[2]);
        }
        if (argc > 3) {
            tekrar = std::stoi(argv[3]);
        }
    } catch (...) {
        n = 0;
    }
    if (n < 1 || n > 10000000 || tekrar < 1) {
        std::cerr << "kullanım: " << argv[0] << " --olc [n] [tekrar]\n";
        return 2;
    }
    std::vector<int> degerler;
    std::vector<std::size_t> konumlar;
    is_yuku(degerler, konumlar, static_cast<std::size_t>(n));
    long long t[4] = {0, 0, 0, 0};
    double sure[4];
    sure[0] = olc_ortanca([&] { t[0] = dizi_gorevi(degerler, konumlar); },
                          tekrar);
    sure[1] = olc_ortanca([&] { t[1] = liste_gorevi(degerler, konumlar); },
                          tekrar);
    sure[2] = olc_ortanca([&] { t[2] = vector_gorevi(degerler, konumlar); },
                          tekrar);
    sure[3] = olc_ortanca([&] { t[3] = list_gorevi(degerler, konumlar); },
                          tekrar);
    const std::string ad[4] = {"dizi (elle)      ", "liste (elle)     ",
                               "std::vector (küt)", "std::list (küt)  "};
    std::cout << "n = " << n << ", tekrar = " << tekrar
              << " (1 ısınma + ortanca)\n"
              << std::fixed << std::setprecision(3);
    for (int i = 0; i < 4; i++) {
        std::cout << "  " << ad[i] << ": " << std::setw(10) << sure[i] * 1e3
                  << " ms\n";
    }
    std::cout << std::setprecision(2) << "  liste/dizi = " << sure[1] / sure[0]
              << ", std::list/std::vector = " << sure[3] / sure[2] << "\n";
    std::cout << "  denetim toplamları aynı mı? "
              << (t[0] == t[1] && t[1] == t[2] && t[2] == t[3] ? "evet"
                                                               : "HAYIR")
              << "\n";
    return 0;
}

int main(int argc, char* argv[])
{
    if (argc > 1 && std::string(argv[1]) == "--olc") {
        return olc(argc, argv);
    }
    std::cout << "İş yükü: n rastgele tamsayı (tohum 42) sıralı yapıya "
                 "doğrusal aramayla\neklenir, sonra rastgele konumlardan tek "
                 "tek silinir.\n";
    std::cout << "\n1) Dinamik dizi (bitişik bellek, × 2 büyüme)\n";
    std::cout << "        n   arama karş.  kaydırma (ekle)  kaydırma (sil)"
                 "       n²/4\n";
    const std::size_t nler[3] = {250, 500, 1000};
    std::vector<int> degerler;
    std::vector<std::size_t> konumlar;
    long long dizi_toplam[3], liste_toplam[3];
    long long d_is[3], l_is[3];
    for (int j = 0; j < 3; j++) {
        std::size_t n = nler[j];
        is_yuku(degerler, konumlar, n);
        dizi_karsilastirma = dizi_kaydirma_ekle = dizi_kaydirma_sil = 0;
        dizi_toplam[j] = dizi_gorevi(degerler, konumlar);
        d_is[j] = dizi_karsilastirma + dizi_kaydirma_ekle + dizi_kaydirma_sil;
        std::cout << "  " << std::setw(7) << n << " " << std::setw(13)
                  << dizi_karsilastirma << " " << std::setw(16)
                  << dizi_kaydirma_ekle << " " << std::setw(15)
                  << dizi_kaydirma_sil << " " << std::setw(10)
                  << static_cast<long long>(n * n / 4) << "\n";
    }
    std::cout << "\n2) Tek bağlı liste (düğüm başına bir malloc)\n";
    std::cout << "        n  ziyaret (ekle)  ziyaret (sil)   ayırma  bırakma"
                 "       n²/4\n";
    for (int j = 0; j < 3; j++) {
        std::size_t n = nler[j];
        is_yuku(degerler, konumlar, n);
        liste_ziyaret_ekle = liste_ziyaret_sil = 0;
        ayirma_sayisi = birakma_sayisi = 0;
        liste_toplam[j] = liste_gorevi(degerler, konumlar);
        l_is[j] = liste_ziyaret_ekle + liste_ziyaret_sil;
        std::cout << "  " << std::setw(7) << n << " " << std::setw(15)
                  << liste_ziyaret_ekle << " " << std::setw(14)
                  << liste_ziyaret_sil << " " << std::setw(8) << ayirma_sayisi
                  << " " << std::setw(8) << birakma_sayisi << " "
                  << std::setw(10) << static_cast<long long>(n * n / 4)
                  << "\n";
    }

    std::cout << "\n3) Denetim\n";
    for (int j = 0; j < 3; j++) {
        is_yuku(degerler, konumlar, nler[j]);
        std::cout << "  n = " << std::setw(4) << nler[j]
                  << ": aynı sıralı dizi? "
                  << (ayni_sira_mi(degerler) ? "evet" : "HAYIR")
                  << "; silinenler aynı? "
                  << (dizi_toplam[j] == liste_toplam[j] ? "evet" : "HAYIR")
                  << " (toplam " << dizi_toplam[j] << ")\n";
    }

    std::cout << "\n4) Kuram: iki yapıda da adım sayısı Θ(n²); n iki katına "
                 "çıkınca\n";
    std::cout << std::fixed << std::setprecision(2)
              << "  dizi adımı (karş. + kaydırma) oranı: "
              << static_cast<double>(d_is[1]) / d_is[0] << ", "
              << static_cast<double>(d_is[2]) / d_is[1]
              << "\n  liste ziyareti oranı               : "
              << static_cast<double>(l_is[1]) / l_is[0] << ", "
              << static_cast<double>(l_is[2]) / l_is[1] << "\n";
    std::cout << "  Liste daha az adım atar (kaydırma yok) ama her adımı bir "
                 "işaretçi\n  kovalamadır; dizi ardışık bellekte ilerler. "
                 "Süreler için: --olc n\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::vector (insert/erase)
 * ve std::list (insert/erase; konum yine yürüyerek bulunur); Python —
 * list.insert / list.pop (dinamik dizi). */

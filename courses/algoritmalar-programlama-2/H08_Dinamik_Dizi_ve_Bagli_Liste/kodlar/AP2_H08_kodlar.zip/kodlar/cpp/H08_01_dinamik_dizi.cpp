/* H08_01_dinamik_dizi.cpp — AP-2 Hafta 8 · Örnek 1 (★)
 * Amaç    : Dinamik dizi ADT'si (dd_olustur, dd_ekle, dd_al, dd_boyut,
 *           dd_yok_et); kapasite dolunca ikiye katlama ve kapasite izleme
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_01_dinamik_dizi.cpp -o H08_01_dinamik_dizi
 * Çalıştır: ./H08_01_dinamik_dizi
 * Eşleri  : c/H08_01_dinamik_dizi.c · python/H08_01_dinamik_dizi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>

struct DinamikDizi {
    int* veri;              // öbekte ayrılmış blok (new[])
    std::size_t boyut;      // kullanılan öğe sayısı
    std::size_t kapasite;   // ayrılmış yuva sayısı
};

static long long kopya_sayisi = 0;  // büyütmede kopyalanan öğe
static int buyutme_sayisi = 0;      // kapasite değişimi

// Sahiplik: dönen dizi çağıranındır; dd_yok_et ile serbest bırakılır.
// Bellek yetersizse new std::bad_alloc fırlatır. ilk_kapasite >= 1.
static DinamikDizi* dd_olustur(std::size_t ilk_kapasite)
{
    DinamikDizi* d = new DinamikDizi{nullptr, 0, ilk_kapasite};
    d->veri = new int[ilk_kapasite];
    return d;
}

// x'i sona ekler; doluysa kapasiteyi ikiye katlar (yeni blok + kopya).
// Bellek yetersizse std::bad_alloc: dizi değişmeden geçerli kalır.
static void dd_ekle(DinamikDizi* d, int x)
{
    if (d->boyut == d->kapasite) {
        std::size_t yeni_kapasite = 2 * d->kapasite;
        int* yeni = new int[yeni_kapasite];
        for (std::size_t i = 0; i < d->boyut; i++) {
            yeni[i] = d->veri[i];
        }
        kopya_sayisi += static_cast<long long>(d->boyut);
        buyutme_sayisi++;
        delete[] d->veri;
        d->veri = yeni;
        d->kapasite = yeni_kapasite;
    }
    d->veri[d->boyut] = x;
    d->boyut++;
}

// Ön koşul yerine denetim: i < boyut ise x'e yazar ve true döner
static bool dd_al(const DinamikDizi* d, std::size_t i, int& x)
{
    if (i >= d->boyut) {
        return false;
    }
    x = d->veri[i];
    return true;
}

static std::size_t dd_boyut(const DinamikDizi* d)
{
    return d->boyut;
}

// Bloğu ve tanımlayıcıyı serbest bırakır; d bundan sonra kullanılmaz
static void dd_yok_et(DinamikDizi* d)
{
    if (d != nullptr) {
        delete[] d->veri;
        delete d;
    }
}

static void al_yaz(const DinamikDizi* d, std::size_t i)
{
    int x;
    if (dd_al(d, i, x)) {
        std::cout << "  dd_al(" << i << ") = " << x << "\n";
    } else {
        std::cout << "  dd_al(" << i << "): sınır dışı (boyut = "
                  << dd_boyut(d) << ")\n";
    }
}

int main()
{
    DinamikDizi* d = dd_olustur(1);
    std::cout << "1) dd_ekle ile 1..20'nin kareleri (ilk kapasite 1, "
                 "büyütme × 2)\n";
    std::cout << "  ekle    x  boyut  kapasite  kopya  toplam iş  iş/ekleme\n";
    long long toplam_is = 0;   // yazma (1) + kopya
    std::cout << std::fixed << std::setprecision(2);
    for (int i = 1; i <= 20; i++) {
        std::size_t eski_kapasite = d->kapasite;
        long long once = kopya_sayisi;
        dd_ekle(d, i * i);
        long long kopya = kopya_sayisi - once;
        toplam_is += 1 + kopya;
        std::cout << "  " << std::setw(4) << i << " " << std::setw(4) << i * i
                  << " " << std::setw(6) << dd_boyut(d) << " "
                  << std::setw(9) << d->kapasite << " " << std::setw(6)
                  << kopya << " " << std::setw(10) << toplam_is << " "
                  << std::setw(10)
                  << static_cast<double>(toplam_is) / i;
        if (d->kapasite != eski_kapasite) {
            std::cout << "  <- büyüdü " << eski_kapasite << " -> "
                      << d->kapasite;
        }
        std::cout << "\n";
    }
    std::cout << "  toplam kopya = " << kopya_sayisi << ", ekleme sayısı = "
              << dd_boyut(d) << ", kopya/ekleme = "
              << static_cast<double>(kopya_sayisi) / dd_boyut(d) << "\n";
    std::cout << "  boş yuva = " << d->kapasite - d->boyut << " (kapasite "
              << d->kapasite << ", boyut " << d->boyut << ")\n";

    std::cout << "\n2) İndisle erişim O(1): dd_al\n";
    al_yaz(d, 0);
    al_yaz(d, 9);
    al_yaz(d, 19);
    al_yaz(d, 20);

    std::cout << "\n3) Büyük n: 10^6 ekleme\n";
    DinamikDizi* b = dd_olustur(1);
    kopya_sayisi = 0;
    int buyutme_once = buyutme_sayisi;
    for (int i = 0; i < 1000000; i++) {
        dd_ekle(b, i);
    }
    long long toplam = 0;
    for (std::size_t i = 0; i < dd_boyut(b); i++) {
        int x;
        dd_al(b, i, x);
        toplam += x;
    }
    std::cout << "  boyut = " << dd_boyut(b) << ", kapasite = " << b->kapasite
              << ", büyütme = " << buyutme_sayisi - buyutme_once << "\n";
    std::cout << std::setprecision(3) << "  toplam kopya = " << kopya_sayisi
              << ", kopya/ekleme = "
              << static_cast<double>(kopya_sayisi) / dd_boyut(b)
              << " (< 2)\n";
    std::cout << "  öğelerin toplamı = " << toplam << " (beklenen "
              << 999999LL * 1000000LL / 2 << ")\n";
    dd_yok_et(b);
    dd_yok_et(d);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; realloc ile); C++ — std::vector
 * (push_back, operator[], size, capacity); Python — list (append, a[i],
 * len). */

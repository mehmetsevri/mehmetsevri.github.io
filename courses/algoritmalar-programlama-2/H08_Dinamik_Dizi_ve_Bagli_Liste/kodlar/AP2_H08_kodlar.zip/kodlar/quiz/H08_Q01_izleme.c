/* H08_Q01_izleme.c — AP-2 Hafta 8 · Quiz 1
 * Amaç    : İzleme sorusu: program ne yazdırır?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_Q01_izleme.c \
 *           -o H08_Q01_izleme
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    Dugum *bas, *son;
} Liste;
/* Sahiplik: dönen düğüm çağıranındır; free ile serbest bırakılır. */
static Dugum *yeni(int x)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        exit(1);
    }
    d->veri = x;
    d->sonraki = NULL;
    return d;
}

static void basa_ekle(Liste *l, int x)
{
    Dugum *d = yeni(x);
    d->sonraki = l->bas;
    l->bas = d;
    if (l->son == NULL) {
        l->son = d;
    }
}

static void sona_ekle(Liste *l, int x)
{
    Dugum *d = yeni(x);
    if (l->son == NULL) {
        l->bas = d;
    } else {
        l->son->sonraki = d;
    }
    l->son = d;
}

int main(void)
{
    Liste l = {NULL, NULL};
    for (int i = 1; i <= 4; i++) {
        if (i % 2 == 1) {
            basa_ekle(&l, i);
        } else {
            sona_ekle(&l, i);
        }
    }
    for (Dugum *p = l.bas; p != NULL; p = p->sonraki) {
        printf("%d ", p->veri);
    }
    printf("\n");
    while (l.bas != NULL) {
        Dugum *s = l.bas->sonraki;
        free(l.bas);
        l.bas = s;
    }
    return 0;
}

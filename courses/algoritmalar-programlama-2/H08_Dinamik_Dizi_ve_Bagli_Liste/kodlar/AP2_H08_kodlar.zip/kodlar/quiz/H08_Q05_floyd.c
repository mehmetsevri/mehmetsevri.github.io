/* H08_Q05_floyd.c — AP-2 Hafta 8 · Quiz 5
 * Amaç    : n = 8 düğüm (0..7); son düğüm 2'ye bağlı. Kaplumbağa (1 adım)
 *           ile tavşan (2 adım) baştan başlarsa hangi düğümde buluşur?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_Q05_floyd.c \
 *           -o H08_Q05_floyd
 */
#include <stdio.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

int main(void)
{
    Dugum d[8];
    for (int i = 0; i < 8; i++) {
        d[i].veri = i;
        d[i].sonraki = i < 7 ? &d[i + 1] : &d[2];
    }
    Dugum *kap = &d[0], *tav = &d[0];
    do {
        kap = kap->sonraki;
        tav = tav->sonraki->sonraki;
    } while (kap != tav);
    printf("buluşma düğümü: %d\n", kap->veri);
    return 0;
}

"""H08_Q06_insert.py — AP-2 Hafta 8 · Quiz 6
Amaç    : n öğeyi list.insert(0, x) ile başa eklemenin toplam maliyeti?
Çalıştır: python3 H08_Q06_insert.py
"""


def basa_ekleyerek(veri):
    a = []
    for x in veri:
        a.insert(0, x)
    return a


def main():
    print(basa_ekleyerek(range(1, 6)))


if __name__ == "__main__":
    main()

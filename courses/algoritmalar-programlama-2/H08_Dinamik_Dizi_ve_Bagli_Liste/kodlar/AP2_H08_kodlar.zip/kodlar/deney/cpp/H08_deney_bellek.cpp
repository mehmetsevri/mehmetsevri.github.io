/* H08_deney_bellek.cpp — AP-2 Hafta 8 · Bellek boyutu gözlemi (C++)
 * Amaç    : Kütüphane kaplarının öğe başına ayırdığı bellek: sayan bir
 *           ayırıcıyla (allocator) std::list<int>, std::forward_list<int>
 *           düğüm boyutları ve std::vector<int> kapasite dizisi. Düğüm
 *           boyutu GERÇEKLEŞTİRİME BAĞLIDIR (burada libstdc++, bu makine).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H08_deney_bellek.cpp \
 *           -o H08_deney_bellek
 * Çalıştır: ./H08_deney_bellek
 */
#include <cstddef>
#include <cstdio>
#include <forward_list>
#include <list>
#include <new>
#include <vector>

static std::size_t istenen_bayt = 0, istek_sayisi = 0;

template <class T>
struct SayanAyirici {
    using value_type = T;
    SayanAyirici() = default;
    template <class U>
    SayanAyirici(const SayanAyirici<U>&) {}
    T* allocate(std::size_t k)
    {
        istenen_bayt += k * sizeof(T);
        istek_sayisi++;
        return static_cast<T*>(::operator new(k * sizeof(T)));
    }
    void deallocate(T* p, std::size_t) { ::operator delete(p); }
};
template <class T, class U>
bool operator==(const SayanAyirici<T>&, const SayanAyirici<U>&)
{
    return true;
}
template <class T, class U>
bool operator!=(const SayanAyirici<T>&, const SayanAyirici<U>&)
{
    return false;
}

int main()
{
    const int n = 1000;
    {
        istenen_bayt = istek_sayisi = 0;
        std::list<int, SayanAyirici<int>> l;
        for (int i = 0; i < n; i++) {
            l.push_back(i);
        }
        std::printf("std::list<int>        : %d öğe, %zu istek, düğüm başına "
                    "%zu bayt (libstdc++)\n", n, istek_sayisi,
                    istenen_bayt / istek_sayisi);
    }
    {
        istenen_bayt = istek_sayisi = 0;
        std::forward_list<int, SayanAyirici<int>> f;
        for (int i = 0; i < n; i++) {
            f.push_front(i);
        }
        std::printf("std::forward_list<int>: %d öğe, %zu istek, düğüm başına "
                    "%zu bayt (libstdc++)\n", n, istek_sayisi,
                    istenen_bayt / istek_sayisi);
    }
    {
        std::vector<int> v;
        std::size_t kapasite = v.capacity();
        std::printf("std::vector<int> kapasiteleri (push_back, libstdc++):");
        int yazilan = 0;
        for (int i = 0; i < 1000000; i++) {
            v.push_back(i);
            if (v.capacity() != kapasite) {
                kapasite = v.capacity();
                if (yazilan++ < 12) {
                    std::printf(" %zu", kapasite);
                }
            }
        }
        std::printf(" ... (%d değişim, son kapasite %zu)\n", yazilan,
                    v.capacity());
    }
    std::printf("sizeof: std::list<int> = %zu, std::vector<int> = %zu, "
                "std::forward_list<int> = %zu\n", sizeof(std::list<int>),
                sizeof(std::vector<int>), sizeof(std::forward_list<int>));
    return 0;
}

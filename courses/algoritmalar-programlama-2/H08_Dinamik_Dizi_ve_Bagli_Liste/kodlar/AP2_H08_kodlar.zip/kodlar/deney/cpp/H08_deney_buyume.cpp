/* H08_deney_buyume.cpp — AP-2 Hafta 8 · Haftanın Deneyi (b), C++
 * Amaç    : n sona ekleme: elle dinamik dizi (strateji 0..3, yeni blok +
 *           kopya) ve etiketli kütüphane serisi std::vector::push_back
 *           (strateji gerçekleştirime bağlı: kapasite değişimleri sayılır)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H08_deney_buyume.cpp \
 *           -o H08_deney_buyume
 * Çalıştır: ./H08_deney_buyume elle|vector strateji n tekrar [ic [isinma]]
 * Çıktı   : seri;strateji;n;tekrar;duvar_ms;islemci_ms;en_az_ms;en_cok_ms;
 *           kopya;son_kapasite;buyutme (vector: kopya = Σ boyut, büyütme
 *           anında; buyutme = capacity() değişim sayısı)
 */
#include <algorithm>
#include <cstddef>
#include <cstdio>
#include <string>
#include <vector>

#include "zamanlayici.hpp"

static int strateji = 3;
static std::size_t n = 0;
static long long kopya = 0, son_kapasite = 0, buyutme = 0, denetim = 0;

static std::size_t yeni_kapasite(std::size_t k)
{
    switch (strateji) {
    case 0:
        return k + 1;
    case 1:
        return k + 10;
    case 2:
        return k + (k + 1) / 2;
    default:
        return 2 * k;
    }
}

static void elle_gorevi()
{
    std::size_t boyut = 0, kapasite = 1;
    int* veri = new int[1];
    kopya = buyutme = 0;
    for (std::size_t i = 0; i < n; i++) {
        if (boyut == kapasite) {
            std::size_t yeni = yeni_kapasite(kapasite);
            int* blok = new int[yeni];
            for (std::size_t j = 0; j < boyut; j++) {
                blok[j] = veri[j];
            }
            delete[] veri;
            kopya += static_cast<long long>(boyut);
            buyutme++;
            veri = blok;
            kapasite = yeni;
        }
        veri[boyut++] = static_cast<int>(i);
    }
    denetim = veri[n / 2];
    son_kapasite = static_cast<long long>(kapasite);
    delete[] veri;
}

static void vector_gorevi()     // ölçülen: yalnızca push_back
{
    std::vector<int> v;
    for (std::size_t i = 0; i < n; i++) {
        v.push_back(static_cast<int>(i));
    }
    denetim = v[n / 2];
}

static void vector_istatistik()   // ölçülmeyen ayrı geçiş: capacity()
{
    std::vector<int> v;
    kopya = buyutme = 0;
    std::size_t kapasite = v.capacity();
    for (std::size_t i = 0; i < n; i++) {
        if (v.size() == kapasite && kapasite > 0) {
            kopya += static_cast<long long>(v.size());   // taşınacak öğe
        }
        v.push_back(static_cast<int>(i));
        if (v.capacity() != kapasite) {
            kapasite = v.capacity();
            buyutme++;
        }
    }
    son_kapasite = static_cast<long long>(v.capacity());
}

int main(int argc, char* argv[])
{
    if (argc < 5 || argc > 7) {
        std::fprintf(stderr, "kullanım: %s elle|vector strateji n tekrar "
                     "[ic]\n", argv[0]);
        return 2;
    }
    std::string seri = argv[1];
    strateji = std::stoi(argv[2]);
    n = std::stoul(argv[3]);
    int tekrar = std::stoi(argv[4]);
    int ic = argc >= 6 ? std::stoi(argv[5]) : 1;
    int isinma = argc == 7 ? std::stoi(argv[6]) : 1;
    void (*gorev)() = seri == "vector" ? vector_gorevi : elle_gorevi;
    std::vector<double> duvar, islemci;
    if (isinma) {
        gorev();                                    // ısınma
    }
    for (int k = 0; k < tekrar; k++) {
        double c0 = islemci_sn(), w0 = zaman_sn();
        for (int r = 0; r < ic; r++) {
            gorev();
        }
        duvar.push_back((zaman_sn() - w0) * 1e3 / ic);
        islemci.push_back((islemci_sn() - c0) * 1e3 / ic);
    }
    if (seri == "vector") {
        vector_istatistik();
    }
    std::printf("%s;%d;%zu;%d;%.4f;%.4f;%.4f;%.4f;%lld;%lld;%lld\n",
                seri.c_str(), strateji, n, tekrar, ortanca(duvar),
                ortanca(islemci),
                *std::min_element(duvar.begin(), duvar.end()),
                *std::max_element(duvar.begin(), duvar.end()), kopya,
                son_kapasite, buyutme);
    return denetim == static_cast<long long>(n / 2) ? 0 : 1;
}

/* H08_deney_stroustrup.cpp — AP-2 Hafta 8 · Haftanın Deneyi (a), C++
 * Amaç    : Stroustrup iş yükü: elle dinamik dizi ve elle liste ile
 *           etiketli kütüphane serisi std::vector ve std::list
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_deney_stroustrup.cpp -o H08_deney_stroustrup
 * Çalıştır: ./H08_deney_stroustrup SERİ n tekrar [ic [isinma]]
 *   SERİ: dizi (elle, × 2, yeni blok + kopya), liste (elle, new/delete),
 *         vector (std::vector::insert/erase), list (std::list::insert/erase)
 *   Konum her seride ELLE doğrusal aranır (Stroustrup'un iş yükü).
 * Çıktı   : seri;n;tekrar;duvar_ms;islemci_ms;en_az_ms;en_cok_ms;0;0;
 *           adim;denetim (ortancalar)
 */
#include <algorithm>
#include <cstddef>
#include <cstdio>
#include <iterator>
#include <list>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

struct Dugum {
    int veri;
    Dugum* sonraki;
};

static std::vector<int> degerler;
static std::vector<std::size_t> konumlar;
static long long adim = 0, denetim = 0;

static void dizi_gorevi()
{
    int* veri = nullptr;
    std::size_t boyut = 0, kapasite = 0;
    adim = denetim = 0;
    for (int x : degerler) {
        std::size_t konum = 0;
        while (konum < boyut && veri[konum] <= x) {
            konum++;
        }
        if (boyut == kapasite) {
            std::size_t yeni = kapasite == 0 ? 1 : 2 * kapasite;
            int* blok = new int[yeni];
            for (std::size_t i = 0; i < boyut; i++) {
                blok[i] = veri[i];
            }
            delete[] veri;
            veri = blok;
            kapasite = yeni;
        }
        for (std::size_t j = boyut; j > konum; j--) {
            veri[j] = veri[j - 1];
        }
        veri[konum] = x;
        adim += static_cast<long long>(boyut);
        boyut++;
    }
    for (std::size_t k : konumlar) {
        int x = veri[k];
        for (std::size_t j = k; j + 1 < boyut; j++) {
            veri[j] = veri[j + 1];
        }
        adim += static_cast<long long>(boyut - k - 1);
        boyut--;
        denetim += x;
    }
    delete[] veri;
}

static void liste_gorevi()
{
    Dugum* bas = nullptr;
    adim = denetim = 0;
    for (int x : degerler) {
        Dugum** p = &bas;
        while (*p != nullptr && (*p)->veri <= x) {
            p = &(*p)->sonraki;
            adim++;
        }
        *p = new Dugum{x, *p};
    }
    for (std::size_t k : konumlar) {
        Dugum** p = &bas;
        for (std::size_t i = 0; i < k; i++) {
            p = &(*p)->sonraki;
        }
        adim += static_cast<long long>(k);
        Dugum* s = *p;
        *p = s->sonraki;
        denetim += s->veri;
        delete s;
    }
}

static void vector_gorevi()
{
    std::vector<int> v;
    adim = denetim = 0;
    for (int x : degerler) {
        std::size_t i = 0;
        while (i < v.size() && v[i] <= x) {
            i++;
        }
        adim += static_cast<long long>(v.size());
        v.insert(v.begin() + static_cast<std::ptrdiff_t>(i), x);
    }
    for (std::size_t k : konumlar) {
        auto it = v.begin() + static_cast<std::ptrdiff_t>(k);
        adim += static_cast<long long>(v.size() - k - 1);
        denetim += *it;
        v.erase(it);
    }
}

static void list_gorevi()
{
    std::list<int> l;
    adim = denetim = 0;
    for (int x : degerler) {
        auto it = l.begin();
        while (it != l.end() && *it <= x) {
            ++it;
            adim++;
        }
        l.insert(it, x);
    }
    for (std::size_t k : konumlar) {
        auto it = std::next(l.begin(), static_cast<std::ptrdiff_t>(k));
        adim += static_cast<long long>(k);
        denetim += *it;
        l.erase(it);
    }
}

int main(int argc, char* argv[])
{
    if (argc < 4 || argc > 6) {
        std::fprintf(stderr, "kullanım: %s SERİ n tekrar [ic [isinma]]\n",
                     argv[0]);
        return 2;
    }
    int ic = argc >= 5 ? std::stoi(argv[4]) : 1;
    int isinma = argc == 6 ? std::stoi(argv[5]) : 1;
    std::string seri = argv[1];
    std::size_t n = std::stoul(argv[2]);
    int tekrar = std::stoi(argv[3]);
    void (*gorev)() = nullptr;
    if (seri == "dizi") {
        gorev = dizi_gorevi;
    } else if (seri == "liste") {
        gorev = liste_gorevi;
    } else if (seri == "vector") {
        gorev = vector_gorevi;
    } else if (seri == "list") {
        gorev = list_gorevi;
    } else {
        std::fprintf(stderr, "bilinmeyen seri: %s\n", seri.c_str());
        return 2;
    }
    degerler.resize(n);
    konumlar.resize(n);
    rastgele_tohum(42);
    for (std::size_t i = 0; i < n; i++) {
        degerler[i] = static_cast<int>(rastgele_sayi());
    }
    for (std::size_t i = 0; i < n; i++) {
        konumlar[i] = static_cast<std::size_t>(
            rastgele_aralik(0, static_cast<int>(n - 1 - i)));
    }
    std::vector<double> duvar, islemci;
    if (isinma) {
        gorev();                                    // ısınma
    }
    for (int k = 0; k < tekrar; k++) {
        double c0 = islemci_sn(), w0 = zaman_sn();
        for (int r = 0; r < ic; r++) {
            gorev();
        }
        duvar.push_back((zaman_sn() - w0) * 1e3 / ic);
        islemci.push_back((islemci_sn() - c0) * 1e3 / ic);
    }
    double en_az = *std::min_element(duvar.begin(), duvar.end());
    double en_cok = *std::max_element(duvar.begin(), duvar.end());
    std::printf("%s;%zu;%d;%.4f;%.4f;%.4f;%.4f;0;0;%lld;%lld\n",
                seri.c_str(), n, tekrar, ortanca(duvar), ortanca(islemci),
                en_az, en_cok, adim, denetim);
    return 0;
}

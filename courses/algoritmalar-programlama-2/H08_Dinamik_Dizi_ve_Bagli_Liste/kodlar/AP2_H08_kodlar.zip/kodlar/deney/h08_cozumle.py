#!/usr/bin/env python3
"""h08_cozumle.py — AP-2 Hafta 8 · Haftanın Deneyi çözümlemesi

Girdi : sonuclar/h08_deney_{stroustrup,ayristirma,buyume,dolasma}.csv
Çıktı : sonuclar/h08_ozet_*.csv ve sonuclar/h08_buyume_kopya.csv
Süre ölçütü: işlemci zamanı ortancası (OLCUM_ORTAMI.txt). Tüm oranlar,
eğimler ve kestirimler burada CSV'den hesaplanır.
Kestirim: ölçülmeyen büyüklük, aynı serinin ölçülen en büyük n'sinden
(n_ref) karesel modelle T(n) = T(n_ref) · (n / n_ref)² — Θ(n²) iş yükleri
(Stroustrup; +1 ve +10 büyüme). Model sınaması: 2·10⁴'ten 5·10⁴ kestirilip
"tek" ölçümle karşılaştırılır.
Kullanım: python3 h08_cozumle.py
"""
import csv
import math
import os

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
N_STR = [1000, 2000, 5000, 10000, 20000, 50000, 100000]
N_BUY = [1000, 10000, 100000, 1000000]


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def yaz(ad, baslik, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(baslik) + "\n")
        for s in satirlar:
            f.write(";".join(bicim(x) for x in s) + "\n")


def bicim(x):
    if isinstance(x, float):
        return f"{x:.6g}"
    return str(x)


def egim(noktalar):
    """log–log en küçük kareler eğimi"""
    xs = [math.log(n) for n, _ in noktalar]
    ys = [math.log(t) for _, t in noktalar]
    k = len(xs)
    if k < 2:
        return float("nan")
    xo, yo = sum(xs) / k, sum(ys) / k
    pay = sum((x - xo) * (y - yo) for x, y in zip(xs, ys))
    payda = sum((x - xo) ** 2 for x in xs)
    return pay / payda


def stroustrup():
    ham = oku("h08_deney_stroustrup.csv")
    seriler = {}
    for r in ham:
        seriler.setdefault((r["dil"], r["seri"]), {})[int(r["n"])] = r
    ozet, egimler, sinama = [], [], []
    deger = {}
    for (dil, seri), d in sorted(seriler.items()):
        olculen = sorted(n for n in d if d[n]["olcum"] == "olculen")
        n_ref = max(olculen)
        for n in N_STR:
            if n in d:
                t = float(d[n]["islemci_ms"])
                tur = d[n]["olcum"]
                kaynak = n
            else:
                # en büyük ölçülen (tek dahil) noktadan karesel kestirim
                kaynak = max(d)
                t = float(d[kaynak]["islemci_ms"]) * (n / kaynak) ** 2
                tur = "kestirim"
            deger[(dil, seri, n)] = (t, tur, kaynak)
        noktalar = [(n, float(d[n]["islemci_ms"])) for n in olculen
                    if n >= 2000]
        egimler.append([dil, seri, len(noktalar),
                        min(n for n, _ in noktalar), n_ref,
                        egim(noktalar)])
        tekler = [n for n in d if d[n]["olcum"] == "tek"]
        for n in tekler:
            t_ref = float(d[n_ref]["islemci_ms"])
            kest = t_ref * (n / n_ref) ** 2
            olc = float(d[n]["islemci_ms"])
            sinama.append([dil, seri, n_ref, n, kest, olc,
                           100.0 * (olc - kest) / olc])
    taban = {"c": "dizi", "cpp": "dizi", "py": "dizi"}
    for (dil, seri, n), (t, tur, kaynak) in sorted(deger.items()):
        oran = ""
        if seri != "dizi":
            ref = "vector" if seri == "list" else taban[dil]
            t0, tur0, _ = deger[(dil, ref, n)]
            oran = t / t0
            if tur0 == "kestirim" or tur == "kestirim":
                tur_oran = "kestirim"
            else:
                tur_oran = "olculen"
        else:
            tur_oran = ""
        ozet.append([dil, seri, n, t, tur, kaynak, oran, tur_oran])
    yaz("h08_ozet_stroustrup.csv",
        ["dil", "seri", "n", "islemci_ms", "tur", "kaynak_n",
         "oran_dizi_ya_da_vector", "oran_turu"], ozet)
    yaz("h08_ozet_egim.csv",
        ["dil", "seri", "nokta", "n_en_kucuk", "n_en_buyuk",
         "loglog_egim"], egimler)
    yaz("h08_ozet_kestirim.csv",
        ["dil", "seri", "n_ref", "n_hedef", "kestirim_ms", "olculen_ms",
         "hata_yuzde"], sinama)
    ortam = {}
    for r in ham:
        if float(r["islemci_ms"]) >= 10:
            ortam.setdefault(r["dil"], []).append(
                float(r["duvar_ms"]) / float(r["islemci_ms"]))
    satir = []
    for dil, v in sorted(ortam.items()):
        v.sort()
        satir.append([dil, len(v), v[len(v) // 2], v[0], v[-1]])
    yaz("h08_ozet_ortam.csv",
        ["dil", "olcum", "duvar_islemci_ortanca", "en_az", "en_cok"], satir)


def ayristirma():
    ham = oku("h08_deney_ayristirma.csv")
    satir = []
    for r in sorted(ham, key=lambda r: (r["seri"], int(r["n"]))):
        ara, deg = float(r["ara_duvar_ms"]), float(r["degistir_duvar_ms"])
        satir.append([r["seri"], int(r["n"]), ara, deg, ara / (ara + deg),
                      float(r["duvar_ms"])])
    yaz("h08_ozet_ayristirma.csv",
        ["seri", "n", "ara_ms", "degistir_ms", "ara_payi", "toplam_duvar_ms"],
        satir)


def yeni_kapasite(st, k):
    return k + 1 if st == 0 else k + 10 if st == 1 else \
        k + (k + 1) // 2 if st == 2 else 2 * k


def kopya_say(st, n):
    """Kopya sayısı (benzetim; büyüme anlarında atlayarak): Örnek 2 ile
    aynı tanım (ilk kapasite 1, büyütmede boyut kadar kopya)"""
    kap, kopya, buy = 1, 0, 0
    while kap < n:          # boyut kap'a ulaşınca büyüt (n'inci ekleme)
        kopya += kap
        kap = yeni_kapasite(st, kap)
        buy += 1
    return kopya, buy, kap


def buyume():
    satir = []
    for st in range(4):
        for n in [1000, 3000, 10000, 30000, 100000, 300000, 1000000]:
            k, b, kap = kopya_say(st, n)
            satir.append([st, n, k, k / n, b, kap, kap - n])
    yaz("h08_buyume_kopya.csv",
        ["strateji", "n", "kopya", "kopya_oge_basina", "buyutme",
         "son_kapasite", "bos_yuva"], satir)
    kopya = {(r[0], r[1]): r[2] for r in satir}
    ham = oku("h08_deney_buyume.csv")
    seriler = {}
    for r in ham:
        seriler.setdefault((r["dil"], r["seri"], int(r["strateji"])),
                           {})[int(r["n"])] = r
    ozet = []
    for (dil, seri, st), d in sorted(seriler.items()):
        for n in N_BUY:
            if n in d:
                t = float(d[n]["islemci_ms"])
                tur = d[n]["olcum"]
                kaynak = n
                k_olc = int(d[n]["kopya"])
            else:
                kaynak = max(d)
                t = float(d[kaynak]["islemci_ms"]) * (n / kaynak) ** 2
                tur = "kestirim"
                k_olc = ""
            k_mod = kopya.get((st, n), "")
            esit = "" if k_olc == "" or k_mod == "" or seri in (
                "vector", "list") else int(k_olc == k_mod)
            ozet.append([dil, seri, st, n, t, t * 1e6 / n, tur, kaynak,
                         k_olc, k_mod, esit])
    yaz("h08_ozet_buyume.csv",
        ["dil", "seri", "strateji", "n", "islemci_ms", "ns_ekleme", "tur",
         "kaynak_n", "kopya_program", "kopya_benzetim", "kopya_esit"], ozet)


def dolasma():
    ham = oku("h08_deney_dolasma.csv")
    d = {(r["dil"], r["duzen"], int(r["n"])): float(r["islemci_ns_dugum"])
         for r in ham}
    satir = []
    for (dil, duzen, n), ns in sorted(d.items()):
        if duzen != "karisik":
            continue
        b = d[(dil, "bitisik", n)]
        z = d[(dil, "dizi", n)]
        satir.append([dil, n, z, b, ns, ns / b, b / z, n * 32 / 1024])
    yaz("h08_ozet_dolasma.csv",
        ["dil", "n", "dizi_ns", "bitisik_ns", "karisik_ns",
         "karisik_bitisik_orani", "bitisik_dizi_orani",
         "c_dugum_bellegi_KiB"], satir)


def main():
    stroustrup()
    ayristirma()
    buyume()
    dolasma()
    print("özet CSV'ler yazıldı:", ", ".join(sorted(
        a for a in os.listdir(SONUC) if a.startswith("h08_ozet")
        or a == "h08_buyume_kopya.csv")))


if __name__ == "__main__":
    main()

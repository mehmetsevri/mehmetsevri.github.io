"""H08_deney_getsizeof.py — AP-2 Hafta 8 · CPython bellek gözlemi
Amaç    : (1) Yerleşik list'in fazladan ayırması (over-allocation):
          her append sonrası sys.getsizeof'tan ayrılmış yuva sayısı ve
          CPython Objects/listobject.c'deki list_resize formülüyle
          karşılaştırma; (2) düğüm nesnelerinin boyutu (__slots__ ile ve
          sözlükle) ve tracemalloc ile düğüm başına bellek.
          Değerler CPython SÜRÜMÜNE ve 64 bit yapıya bağlıdır.
Çalıştır: python3 H08_deney_getsizeof.py [csv_yolu]
"""
import platform
import sys
import tracemalloc


def formul_yuva(eski_yuva, eski_boy, yeni_boy):
    """list_resize (3.10–3.13'te aynı): sığıyorsa ve yarısından büyükse
    yeniden ayırma yok; değilse yeni_boy + yeni_boy >> 3 + 6, 4'ün katına
    aşağı yuvarlanır (& ~3)."""
    if eski_yuva >= yeni_boy and yeni_boy >= (eski_yuva >> 1):
        return eski_yuva
    yeni = (yeni_boy + (yeni_boy >> 3) + 6) & ~3
    if yeni_boy - eski_boy > yeni - yeni_boy:
        yeni = (yeni_boy + 3) & ~3
    if yeni_boy == 0:
        yeni = 0
    return yeni


class DugumSlots:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


class DugumSozluk:
    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def dugum_basina_bayt(sinif, n):
    tracemalloc.start()
    t0 = tracemalloc.get_traced_memory()[0]
    bas = None
    for i in range(n):
        bas = sinif(i + 100000, bas)    # küçük int önbelleğinin dışı
    t1 = tracemalloc.get_traced_memory()[0]
    tracemalloc.stop()
    bas = None
    return (t1 - t0) / n


def main():
    surum = (f"CPython {platform.python_version()} "
             f"({platform.architecture()[0]})")
    a = []
    taban = sys.getsizeof(a)
    satirlar = ["n;getsizeof_bayt;yuva;formul_yuva;esit"]
    degisim = []
    uyusmaz = 0
    yuva = formul = 0
    for n in range(1, 10001):
        a.append(n)
        boy = sys.getsizeof(a)
        yeni_yuva = (boy - taban) // 8
        formul = formul_yuva(formul, n - 1, n)
        uyusmaz += yeni_yuva != formul
        if yeni_yuva != yuva:
            degisim.append((n, yeni_yuva))
            satirlar.append(f"{n};{boy};{yeni_yuva};{formul};"
                            f"{int(yeni_yuva == formul)}")
        yuva = yeni_yuva
    print(f"{surum}: sys.getsizeof([]) = {taban} bayt; her yuva 8 bayt "
          f"(PyObject * başvurusu)")
    print("append ile yuva sayısı değişimleri (n -> yuva): " + ", ".join(
        f"{n}->{y}" for n, y in degisim[:14]) + ", ...")
    print(f"n = 1..10000: {len(degisim)} yeniden ayırma; formülle "
          f"uyuşmayan n sayısı = {uyusmaz}")
    oranlar = [degisim[i + 1][1] / degisim[i][1]
               for i in range(len(degisim) - 1) if degisim[i][1] >= 1000]
    print(f"büyük boyda büyüme oranı (yuva >= 1000): ≈ "
          f"{sum(oranlar) / len(oranlar):.3f} (formül: ≈ 1 + 1/8)")
    print(f"sys.getsizeof: int 100000 = {sys.getsizeof(100000)}, "
          f"DugumSlots = {sys.getsizeof(DugumSlots(1, None))}, "
          f"DugumSozluk = {sys.getsizeof(DugumSozluk(1, None))} (sözlük "
          f"ayrıca; boyutu sürüme bağlı, tracemalloc'a bakın)")
    for sinif in (DugumSlots, DugumSozluk):
        print(f"tracemalloc, 100000 düğüm: {sinif.__name__} düğüm başına "
              f"≈ {dugum_basina_bayt(sinif, 100000):.1f} bayt (int dahil)")
    if len(sys.argv) > 1:
        with open(sys.argv[1], "w", encoding="utf-8") as f:
            f.write(f"# {surum}\n" + "\n".join(satirlar) + "\n")


if __name__ == "__main__":
    main()

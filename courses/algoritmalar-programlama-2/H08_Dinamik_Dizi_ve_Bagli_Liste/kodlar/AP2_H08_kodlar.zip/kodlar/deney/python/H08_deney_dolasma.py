"""H08_deney_dolasma.py — AP-2 Hafta 8 · Haftanın Deneyi (c), Python
Amaç    : Düğümlerin oluşturulma/bağlanma sırasının etkisi Python'da: n
          düğümü dolaşmanın düğüm başına süresi (yorumlayıcı yükü önbellek
          etkisini ne kadar gölgeler?)
Çalıştır: python3 H08_deney_dolasma.py dizi|bitisik|karisik n tekrar
Çıktı   : duzen;n;tekrar;gecis;duvar_ns;islemci_ns;denetim
"""
import sys

from ortak_rastgele import rastgele_karistir, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


def main():
    if len(sys.argv) != 4:
        print(f"kullanım: {sys.argv[0]} dizi|bitisik|karisik n tekrar",
              file=sys.stderr)
        sys.exit(2)
    duzen, n, tekrar = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    gecis = max(1, 2000000 // n)
    dizi = bas = None
    if duzen == "dizi":
        dizi = [i % 1000 for i in range(n)]
    else:
        dugumler = [Dugum(i % 1000) for i in range(n)]   # art arda
        sira = list(range(n))
        if duzen == "karisik":
            rastgele_tohum(42)
            rastgele_karistir(sira)
        for i in range(n - 1):
            dugumler[sira[i]].sonraki = dugumler[sira[i + 1]]
        bas = dugumler[sira[0]]
        dugumler = None

    def gorev():
        toplam = 0
        for _ in range(gecis):
            if dizi is not None:
                for x in dizi:
                    toplam += x
            else:
                p = bas
                while p is not None:
                    toplam += p.veri
                    p = p.sonraki
        return toplam

    denetim = gorev()                               # ısınma
    duvar, islemci = [], []
    for _ in range(tekrar):
        c0, w0 = islemci_sn(), zaman_sn()
        denetim = gorev()
        ziyaret = n * gecis
        duvar.append((zaman_sn() - w0) * 1e9 / ziyaret)
        islemci.append((islemci_sn() - c0) * 1e9 / ziyaret)
    print(f"{duzen};{n};{tekrar};{gecis};{ortanca(duvar):.4f};"
          f"{ortanca(islemci):.4f};{denetim}")


if __name__ == "__main__":
    main()

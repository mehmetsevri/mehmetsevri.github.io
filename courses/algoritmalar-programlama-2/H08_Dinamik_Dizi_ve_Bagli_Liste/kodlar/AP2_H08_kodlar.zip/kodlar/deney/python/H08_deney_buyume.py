"""H08_deney_buyume.py — AP-2 Hafta 8 · Haftanın Deneyi (b), Python
Amaç    : n sona ekleme: elle dinamik dizi ([None] * kapasite; strateji
          0..3, öğe öğe kopya) ve etiketli kütüphane serisi list.append
          (CPython fazladan ayırır: sys.getsizeof değişimleri sayılır)
Çalıştır: python3 H08_deney_buyume.py elle|list strateji n tekrar
          [ic [isinma]]
Çıktı   : seri;strateji;n;tekrar;duvar_ms;islemci_ms;en_az_ms;en_cok_ms;
          kopya;son_kapasite;buyutme
"""
import sys

from zamanlayici import islemci_sn, ortanca, zaman_sn


def yeni_kapasite(strateji, k):
    if strateji == 0:
        return k + 1
    if strateji == 1:
        return k + 10
    if strateji == 2:
        return k + (k + 1) // 2
    return 2 * k


def elle_gorevi(strateji, n):
    boyut, kapasite = 0, 1
    veri = [None] * 1
    kopya = buyutme = 0
    for i in range(n):
        if boyut == kapasite:
            yeni = yeni_kapasite(strateji, kapasite)
            blok = [None] * yeni
            for j in range(boyut):
                blok[j] = veri[j]
            kopya += boyut
            buyutme += 1
            veri = blok
            kapasite = yeni
        veri[boyut] = i
        boyut += 1
    return veri[n // 2], kopya, kapasite, buyutme


def list_gorevi(strateji, n):
    """Kütüphane serisi: yalnızca list.append (ölçülen)"""
    a = []
    for i in range(n):
        a.append(i)
    return a[n // 2], 0, 0, 0


def list_istatistik(n):
    """Ölçülmeyen ayrı geçiş: kapasite sys.getsizeof'tan (CPython 64 bit:
    getsizeof = taban + 8 × ayrılmış yuva)"""
    a = []
    taban = sys.getsizeof(a)
    boy = taban
    buyutme = kopya = 0
    for i in range(n):
        a.append(i)
        yeni = sys.getsizeof(a)
        if yeni != boy:
            buyutme += 1
            kopya += len(a) - 1     # taşınırsa kopyalanacak öğe (model)
            boy = yeni
    return a[n // 2], kopya, (boy - taban) // 8, buyutme


def main():
    if len(sys.argv) not in (5, 6, 7):
        print(f"kullanım: {sys.argv[0]} elle|list strateji n tekrar [ic]",
              file=sys.stderr)
        sys.exit(2)
    seri, strateji = sys.argv[1], int(sys.argv[2])
    n, tekrar = int(sys.argv[3]), int(sys.argv[4])
    ic = int(sys.argv[5]) if len(sys.argv) >= 6 else 1
    isinma = int(sys.argv[6]) if len(sys.argv) == 7 else 1
    gorev = list_gorevi if seri == "list" else elle_gorevi
    sonuc = gorev(strateji, 2) if not isinma else gorev(strateji, n)
    duvar, islemci = [], []
    for _ in range(tekrar):
        c0, w0 = islemci_sn(), zaman_sn()
        for _ in range(ic):
            sonuc = gorev(strateji, n)
        duvar.append((zaman_sn() - w0) * 1e3 / ic)
        islemci.append((islemci_sn() - c0) * 1e3 / ic)
    if seri == "list":
        sonuc = list_istatistik(n)
    print(f"{seri};{strateji};{n};{tekrar};{ortanca(duvar):.4f};"
          f"{ortanca(islemci):.4f};{min(duvar):.4f};{max(duvar):.4f};"
          f"{sonuc[1]};{sonuc[2]};{sonuc[3]}")
    sys.exit(0 if sonuc[0] == n // 2 else 1)


if __name__ == "__main__":
    main()

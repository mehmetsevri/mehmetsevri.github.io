"""H08_deney_stroustrup.py — AP-2 Hafta 8 · Haftanın Deneyi (a), Python
Amaç    : Stroustrup iş yükü: elle dinamik dizi ([None] * kapasite), elle
          bağlı liste ve etiketli kütüphane serisi (yerleşik list: konum
          elle aranır, list.insert / list.pop kaydırır)
Çalıştır: python3 H08_deney_stroustrup.py SERİ n tekrar [ic [isinma]]
          SERİ: dizi | liste | pylist
Çıktı   : seri;n;tekrar;duvar_ms;islemci_ms;en_az_ms;en_cok_ms;0;0;
          adim;denetim (ortancalar)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def dizi_gorevi(degerler, konumlar):
    veri, boyut, kapasite = [], 0, 0
    adim = denetim = 0
    for x in degerler:
        konum = 0
        while konum < boyut and veri[konum] <= x:
            konum += 1
        if boyut == kapasite:
            kapasite = 1 if kapasite == 0 else 2 * kapasite
            blok = [None] * kapasite
            for i in range(boyut):
                blok[i] = veri[i]
            veri = blok
        for j in range(boyut, konum, -1):
            veri[j] = veri[j - 1]
        veri[konum] = x
        adim += boyut
        boyut += 1
    for k in konumlar:
        x = veri[k]
        for j in range(k, boyut - 1):
            veri[j] = veri[j + 1]
        adim += boyut - k - 1
        boyut -= 1
        denetim += x
    return adim, denetim


def liste_gorevi(degerler, konumlar):
    bas = None
    adim = denetim = 0
    for x in degerler:
        onceki, p = None, bas
        while p is not None and p.veri <= x:
            onceki, p = p, p.sonraki
            adim += 1
        d = Dugum(x, p)
        if onceki is None:
            bas = d
        else:
            onceki.sonraki = d
    for k in konumlar:
        onceki, p = None, bas
        for _ in range(k):
            onceki, p = p, p.sonraki
        adim += k
        if onceki is None:
            bas = p.sonraki
        else:
            onceki.sonraki = p.sonraki
        denetim += p.veri
    return adim, denetim


def pylist_gorevi(degerler, konumlar):
    """Kütüphane serisi: konum elle (doğrusal) aranır; kaydırmayı
    list.insert ve list.pop (C'de memmove) yapar"""
    a = []
    adim = denetim = 0
    for x in degerler:
        i = 0
        n = len(a)
        while i < n and a[i] <= x:
            i += 1
        adim += n
        a.insert(i, x)
    for k in konumlar:
        adim += len(a) - k - 1
        denetim += a.pop(k)
    return adim, denetim


def main():
    if len(sys.argv) not in (4, 5, 6):
        print(f"kullanım: {sys.argv[0]} SERİ n tekrar [ic [isinma]]",
              file=sys.stderr)
        sys.exit(2)
    seri, n, tekrar = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    ic = int(sys.argv[4]) if len(sys.argv) >= 5 else 1
    isinma = int(sys.argv[5]) if len(sys.argv) == 6 else 1
    gorev = {"dizi": dizi_gorevi, "liste": liste_gorevi,
             "pylist": pylist_gorevi}[seri]
    rastgele_tohum(42)
    degerler = [rastgele_sayi() for _ in range(n)]
    konumlar = [rastgele_aralik(0, n - 1 - i) for i in range(n)]
    if isinma:
        sonuc = gorev(degerler, konumlar)          # ısınma
    duvar, islemci = [], []
    for _ in range(tekrar):
        c0, w0 = islemci_sn(), zaman_sn()
        for _ in range(ic):
            sonuc = gorev(degerler, konumlar)
        duvar.append((zaman_sn() - w0) * 1e3 / ic)
        islemci.append((islemci_sn() - c0) * 1e3 / ic)
    print(f"{seri};{n};{tekrar};{ortanca(duvar):.4f};{ortanca(islemci):.4f};"
          f"{min(duvar):.4f};{max(duvar):.4f};0;0;{sonuc[0]};{sonuc[1]}")


if __name__ == "__main__":
    main()

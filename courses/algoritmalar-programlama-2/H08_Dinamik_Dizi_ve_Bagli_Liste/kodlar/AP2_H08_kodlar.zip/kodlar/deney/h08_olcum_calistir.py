#!/usr/bin/env python3
"""h08_olcum_calistir.py — AP-2 Hafta 8 · Haftanın Deneyi sürücüsü

Üç deney:
  (a) stroustrup : sıralı yapıya doğrusal aramayla ekleme + rastgele
                   konumdan silme; C (dizi, liste, liste_bitisik,
                   liste_karisik, ayrıştırma), C++ (dizi, liste, vector,
                   list), Python (dizi, liste, pylist)
  (b) buyume     : n sona ekleme, strateji +1 / +10 / × 1,5 / × 2; C
                   (realloc, realloc_engelli, elle), C++ (elle, vector),
                   Python (elle, list)
  (c) dolasma    : n düğümü dolaşma (dizi / art arda bağlı / karışık bağlı)
Ölçüm düzeni: -O2; 1 ısınma + 5 tekrar (uzun ölçümlerde 3; çok uzun tek
ölçümler ısınmasız), ortanca. Hem duvar saati hem işlemci zamanı yazılır;
çözümleme işlemci zamanını kullanır (paylaşımlı makine, bkz. OLCUM_ORTAMI).
Ölçülmeyen büyüklükler h08_cozumle.py'de n² modeliyle KESTİRİLİR.

Kullanım:
  python3 h08_olcum_calistir.py            # tüm ızgara (≈ 5 dk)
  python3 h08_olcum_calistir.py --devam    # ham kayıtta olanları atla
  python3 h08_olcum_calistir.py --hizli    # küçük alt küme (CSV yazmaz)
Çıktı: sonuclar/h08_ham.jsonl (her ölçüm anında), sonuclar/h08_deney_*.csv,
       OLCUM_ORTAMI.txt
"""
import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
HAM = os.path.join(SONUC, "h08_ham.jsonl")
C = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic", "-O2"]
CPP = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic", "-O2"]

N_STR = [1000, 2000, 5000, 10000, 20000, 50000, 100000]
N_BUY = [1000, 10000, 100000, 1000000]
N_DOL_C = [1000, 3000, 10000, 30000, 100000, 300000, 1000000, 3000000,
           10000000]
N_DOL_PY = [1000, 10000, 100000, 1000000]


def derle(gecici):
    ikili = {}
    for ad, dil, ekler in (
            ("stroustrup", "c", ["ortak_rastgele.c", "zamanlayici.c"]),
            ("buyume", "c", ["zamanlayici.c"]),
            ("dolasma", "c", ["ortak_rastgele.c", "zamanlayici.c"]),
            ("bellek", "c", []),
            ("stroustrup", "cpp", []), ("buyume", "cpp", []),
            ("bellek", "cpp", [])):
        kl = os.path.join(KOK, dil)
        kaynak = os.path.join(kl, f"H08_deney_{ad}.{dil}")
        hedef = os.path.join(gecici, f"h08ikili_{ad}_{dil}")
        komut = (C if dil == "c" else CPP) + [kaynak] + \
            [os.path.join(kl, e) for e in ekler] + ["-o", hedef]
        p = subprocess.run(komut, capture_output=True, text=True)
        if p.returncode != 0 or p.stderr.strip():
            sys.exit(f"derleme sorunu: {kaynak}\n{p.stderr}")
        ikili[(ad, dil)] = hedef
    return ikili


def plan():
    """(deney, dil, seri, strateji, n, tekrar, ic, isinma) listesi"""
    p = []
    # (a) Stroustrup
    for dil, seri, en_cok, tek in (
            ("c", "dizi", 100000, None),
            ("c", "liste", 20000, 50000),
            ("c", "liste_bitisik", 20000, 50000),
            ("c", "liste_karisik", 20000, 50000),
            ("cpp", "dizi", 100000, None),
            ("cpp", "vector", 100000, None),
            ("cpp", "liste", 20000, None),
            ("cpp", "list", 20000, 50000),
            ("py", "dizi", 5000, None),
            ("py", "liste", 5000, None),
            ("py", "pylist", 5000, None)):
        for n in N_STR:
            if n <= en_cok:
                buyuk = n >= 50000 or (dil == "py" and n >= 5000) or \
                    (seri.startswith("liste") and n >= 20000) or \
                    (seri == "list" and n >= 20000)
                ic = max(1, 20000 // n) if dil != "py" else 1
                p.append(("stroustrup", dil, seri, -1, n,
                          3 if buyuk else 5, ic, 1))
            elif n == tek:
                p.append(("stroustrup", dil, seri, -1, n, 1, 1, 0))
    for seri in ("dizi_ayristir", "liste_ayristir"):
        for n in (5000, 10000, 20000):
            p.append(("stroustrup", "c", seri, -1, n, 3, 1, 1))
    # (b) büyüme
    for dil, seri, stratejiler in (
            ("c", "realloc", (0, 1, 2, 3)),
            ("c", "realloc_engelli", (0, 1, 2, 3)),
            ("c", "elle", (0, 1, 2, 3)),
            ("cpp", "elle", (0, 1, 2, 3)),
            ("cpp", "vector", (9,)),
            ("py", "elle", (0, 1, 2, 3)),
            ("py", "list", (9,))):
        for st in stratejiler:
            for n in N_BUY:
                # Karesel stratejilerde ölçülen sınır (kalanı kestirim)
                if dil in ("c", "cpp") and seri == "elle":
                    sinir = {0: 100000, 1: 100000}.get(st, 10 ** 9)
                    tek = {0: 100000}.get(st)
                elif dil == "py" and seri == "elle":
                    sinir = {0: 10000, 1: 10000}.get(st, 10 ** 9)
                    tek = {0: 10000}.get(st)
                else:
                    sinir, tek = 10 ** 9, None
                if n > sinir:
                    continue
                if n == tek:
                    p.append(("buyume", dil, seri, st, n, 1, 1, 0))
                    continue
                ic = max(1, (10 ** 6 if dil != "py" else 10 ** 5) // n)
                if st in (0, 1) and seri not in ("realloc",
                                                 "realloc_engelli"):
                    ic = 1
                p.append(("buyume", dil, seri, st, n, 5, ic, 1))
    # (c) dolaşma
    for duzen in ("dizi", "bitisik", "karisik"):
        for n in N_DOL_C:
            p.append(("dolasma", "c", duzen, -1, n,
                      3 if n >= 3000000 else 5, 1, 1))
        for n in N_DOL_PY:
            p.append(("dolasma", "py", duzen, -1, n,
                      3 if n >= 1000000 else 5, 1, 1))
    return p


def anahtar(k):
    return f"{k[0]}|{k[1]}|{k[2]}|{k[3]}|{k[4]}"


def calistir(ikili, k):
    deney, dil, seri, st, n, tekrar, ic, isinma = k
    if dil == "py":
        betik = os.path.join(KOK, "python", f"H08_deney_{deney}.py")
        komut = [sys.executable, betik]
    else:
        komut = [ikili[(deney, dil)]]
    if deney == "stroustrup":
        komut += [seri, str(n), str(tekrar), str(ic), str(isinma)]
    elif deney == "buyume":
        komut += [seri, str(st), str(n), str(tekrar), str(ic), str(isinma)]
    else:
        komut += [seri, str(n), str(tekrar)]
    t0 = time.time()
    p = subprocess.run(komut, capture_output=True, text=True,
                       cwd=os.path.join(KOK, "python"),
                       env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1",
                                PYTHONHASHSEED="0"))
    sure = time.time() - t0
    if p.returncode != 0:
        sys.exit(f"ölçüm hatası: {' '.join(komut)}\n{p.stderr}")
    alan = p.stdout.strip().split(";")
    return {"deney": deney, "dil": dil, "seri": seri, "strateji": st,
            "n": n, "tekrar": tekrar, "ic": ic, "isinma": isinma,
            "alanlar": alan, "sure_sn": round(sure, 3),
            "yuk": open("/proc/loadavg").read().split()[:3],
            "zaman": time.strftime("%Y-%m-%dT%H:%M:%S")}


def csv_yaz(kayitlar):
    """Ham kayıtlardan (son kayıt geçerli) CSV'leri üretir"""
    son = {}
    for r in kayitlar:
        son[anahtar((r["deney"], r["dil"], r["seri"], r["strateji"],
                     r["n"]))] = r
    st, ay, by, dl = [], [], [], []
    for r in son.values():
        a = r["alanlar"]
        olcum = "tek" if (r["tekrar"] == 1 and r["isinma"] == 0) else \
            "olculen"
        if r["deney"] == "stroustrup":
            satir = [r["dil"], r["seri"], r["n"], r["tekrar"], r["ic"],
                     a[3], a[4], a[5], a[6], a[9], a[10], olcum]
            if r["seri"].endswith("_ayristir"):
                ay.append([r["seri"].replace("_ayristir", ""), r["n"],
                           r["tekrar"], a[3], a[4], a[7], a[8]])
            else:
                st.append(satir)
        elif r["deney"] == "buyume":
            by.append([r["dil"], r["seri"], r["strateji"], r["n"],
                       r["tekrar"], r["ic"], a[4], a[5], a[6], a[7], a[8],
                       a[9], a[10], olcum])
        else:
            dl.append([r["dil"], r["seri"], r["n"], r["tekrar"], a[3],
                       a[4], a[5], a[6]])
    yaz = [("h08_deney_stroustrup.csv",
            "dil;seri;n;tekrar;ic;duvar_ms;islemci_ms;duvar_en_az_ms;"
            "duvar_en_cok_ms;adim;denetim;olcum", st),
           ("h08_deney_ayristirma.csv",
            "seri;n;tekrar;duvar_ms;islemci_ms;ara_duvar_ms;"
            "degistir_duvar_ms", ay),
           ("h08_deney_buyume.csv",
            "dil;seri;strateji;n;tekrar;ic;duvar_ms;islemci_ms;"
            "duvar_en_az_ms;duvar_en_cok_ms;kopya;son_kapasite;"
            "tasima_ya_da_buyutme;olcum", by),
           ("h08_deney_dolasma.csv",
            "dil;duzen;n;tekrar;gecis;duvar_ns_dugum;islemci_ns_dugum;"
            "denetim", dl)]
    sira = {"c": 0, "cpp": 1, "py": 2}
    for ad, baslik, satirlar in yaz:
        satirlar.sort(key=lambda s: tuple(
            sira.get(x, x) if isinstance(x, str) and x in sira else
            (x if isinstance(x, int) else str(x)) for x in s[:4]))
        with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
            f.write(baslik + "\n")
            for s in satirlar:
                f.write(";".join(str(x) for x in s) + "\n")


def surum(komut):
    p = subprocess.run(komut, capture_output=True, text=True)
    return (p.stdout or p.stderr).splitlines()[0]


def gozlem(ikili):
    """Bellek gözlemleri (C, C++, CPython 3.10–3.13)"""
    metin = "# AP-2 H8 · Bellek boyutu gözlemleri (bu makinede, " + \
        time.strftime("%Y-%m-%d") + ")\n\n## C (gcc, glibc)\n"
    metin += subprocess.run([ikili[("bellek", "c")]], capture_output=True,
                            text=True).stdout
    metin += "\n## C++ (g++, libstdc++)\n"
    metin += subprocess.run([ikili[("bellek", "cpp")]], capture_output=True,
                            text=True).stdout
    for v in ("3.10", "3.11", "3.12", "3.13"):
        yorum = shutil.which(f"python{v}")
        if yorum is None:
            continue
        csv = os.path.join(SONUC, "h08_list_buyume.csv") if v == \
            platform.python_version().rsplit(".", 1)[0] else os.devnull
        metin += f"\n## Python {v}\n"
        metin += subprocess.run(
            [yorum, os.path.join(KOK, "python", "H08_deney_getsizeof.py"),
             csv], capture_output=True, text=True,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")).stdout
    with open(os.path.join(SONUC, "h08_bellek_gozlem.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)


def ortam_yaz(baslangic_yuk, bitis_yuk, toplam, sayi):
    model = "?"
    for s in open("/proc/cpuinfo"):
        if s.startswith("model name"):
            model = s.split(":", 1)[1].strip()
            break
    onbellek = subprocess.run(["lscpu"], capture_output=True,
                              text=True).stdout
    ob = "; ".join(s.split(":")[0].strip() + " " + s.split(":")[1].strip()
                   for s in onbellek.splitlines() if "cache" in s)
    yuk = (f"önce {' '.join(baslangic_yuk)} · sonra "
           f"{' '.join(bitis_yuk)} (/proc/loadavg: 1, 5, 15 dk)")
    isl = (f"{platform.system()} {platform.release()} "
           f"({platform.machine()}), glibc {platform.libc_ver()[1]}")
    satirlar = [
        "AP-2 Hafta 8 · Haftanın Deneyi — ölçüm ortamı",
        f"Tarih          : {time.strftime('%Y-%m-%d')}",
        f"İşlemci        : {model}",
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine; ölçüm sırasında "
        "başka süreçler de çalışıyordu)",
        f"Önbellek       : {ob}",
        f"Yük ortalaması : {yuk}",
        f"İşletim sistemi: {isl}",
        f"C derleyicisi  : {surum(['gcc', '--version'])}",
        f"C++ derleyicisi: {surum(['g++', '--version'])}",
        f"Python         : Python {platform.python_version()}",
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra "
        "-pedantic -O2",
        "Yöntem         : 1 ısınma + 5 tekrar (uzun ölçümlerde 3; \"tek\" "
        "işaretli çok uzun ölçümler ısınmasız tek çalıştırma), ortanca; "
        "küçük n'de bir ölçüm görevi ic kez yineler (süre ic'ye bölünür)",
        "Saat           : duvar saati C timespec_get, C++ steady_clock, "
        "Python time.perf_counter; işlemci zamanı C/C++ clock(), Python "
        "time.process_time",
        "Süre ölçütü    : çözümleme ve grafiklerde İŞLEMCİ ZAMANI ortancası "
        "(paylaşımlı makinede duvar saati bekleme süresini de içerir); "
        "duvar saati CSV'de",
        f"Ölçüm sayısı   : {sayi} (bu çalıştırma)",
        f"Toplam süre    : {toplam:.1f} s duvar saati (derleme ve gözlemler "
        "dahil)",
    ]
    metin = "\n".join(satirlar) + "\n"
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--devam", action="store_true")
    ap.add_argument("--hizli", action="store_true")
    a = ap.parse_args()
    os.makedirs(SONUC, exist_ok=True)
    t0 = time.time()
    yuk0 = open("/proc/loadavg").read().split()[:3]
    gecici = tempfile.mkdtemp(prefix="h08x_")
    try:
        ikili = derle(gecici)
        p = plan()
        if a.hizli:
            p = [k for k in p if k[4] <= 10000 and k[5] > 1]
            for k in p:
                print(";".join(calistir(ikili, k)["alanlar"]))
            print(f"hızlı kip: {len(p)} ölçüm, {time.time() - t0:.1f} s")
            return
        yapilan = set()
        kayitlar = []
        if a.devam and os.path.exists(HAM):
            for s in open(HAM, encoding="utf-8"):
                r = json.loads(s)
                kayitlar.append(r)
                yapilan.add(anahtar((r["deney"], r["dil"], r["seri"],
                                     r["strateji"], r["n"])))
        elif os.path.exists(HAM):
            os.remove(HAM)
        sayi = 0
        for i, k in enumerate(p):
            if anahtar(k[:5]) in yapilan:
                continue
            r = calistir(ikili, k)
            kayitlar.append(r)
            sayi += 1
            with open(HAM, "a", encoding="utf-8") as f:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
            print(f"[{i + 1}/{len(p)}] {';'.join(r['alanlar'])}  "
                  f"({r['sure_sn']} s)", flush=True)
        gozlem(ikili)
        csv_yaz(kayitlar)
        ortam_yaz(yuk0, open("/proc/loadavg").read().split()[:3],
                  time.time() - t0, len(kayitlar))
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    print(f"bitti: {time.time() - t0:.1f} s")


if __name__ == "__main__":
    main()

/* H08_deney_buyume.c — AP-2 Hafta 8 · Haftanın Deneyi (b), C
 * Amaç    : Büyüme stratejisine göre n sona eklemenin süresi ve kopya
 *           sayısı: realloc ile ve elle (yeni blok + öğe öğe kopya)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_deney_buyume.c \
 *           zamanlayici.c -o H08_deney_buyume
 * Çalıştır: ./H08_deney_buyume SERİ strateji n tekrar [ic [isinma]]
 *   ic: bir ölçümde görevin kaç kez yinelendiği (küçük n için; süre ic'ye
 *       bölünür)
 *   SERİ: realloc | realloc_engelli | elle
 *         realloc_engelli: her büyütmeden sonra küçük bir "engel" bloğu
 *         ayrılır (gerçek programlardaki araya giren ayırmaların benzeri);
 *         blok öbeğin tepesinde kalamaz, realloc yerinde büyütemeyebilir
 *   strateji: 0 (+1), 1 (+10), 2 (× 1,5), 3 (× 2)
 *   × 1,5: yeni = k + (k + 1) / 2 (Örnek 2 ile aynı tanım)
 * Çıktı   : seri;strateji;n;tekrar;duvar_ms;islemci_ms;en_az_ms;en_cok_ms;
 *           kopya;son_kapasite;tasima (kopya: realloc'ta en kötü durum
 *           modeli; tasima: realloc'un bloğu başka adrese taşıdığı büyütme
 *           sayısı — glibc'ye ve bu çalıştırmaya özgü)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "zamanlayici.h"

static int strateji = 3, elle = 0, engelli = 0;
static void **engeller;          /* realloc_engelli: araya giren bloklar */
static size_t n = 0;
static long long kopya = 0, son_kapasite = 0, denetim = 0;
static long long tasima = 0;     /* realloc bloğu başka adrese taşıdı */

static size_t yeni_kapasite(size_t k)
{
    switch (strateji) {
    case 0:
        return k + 1;
    case 1:
        return k + 10;
    case 2:
        return k + (k + 1) / 2;
    default:
        return 2 * k;
    }
}

static void gorev(void *v)
{
    (void)v;
    size_t boyut = 0, kapasite = 1;
    int *veri = malloc(sizeof *veri);
    if (veri == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    size_t engel_sayisi = 0;
    kopya = 0;
    tasima = 0;
    for (size_t i = 0; i < n; i++) {
        if (boyut == kapasite) {
            size_t yeni = yeni_kapasite(kapasite);
            int *blok;
            if (elle) {
                blok = malloc(yeni * sizeof *blok);
                if (blok != NULL) {
                    for (size_t j = 0; j < boyut; j++) {
                        blok[j] = veri[j];
                    }
                    free(veri);
                }
            } else {
                uintptr_t eski = (uintptr_t)veri;   /* yalnız sayaç için */
                blok = realloc(veri, yeni * sizeof *blok);
                tasima += (uintptr_t)blok != eski;
            }
            if (blok == NULL) {
                fprintf(stderr, "bellek yetersiz\n");
                exit(1);
            }
            kopya += (long long)boyut;
            veri = blok;
            kapasite = yeni;
            if (engelli) {
                engeller[engel_sayisi++] = malloc(16);
            }
        }
        veri[boyut++] = (int)i;
        if (i == n / 2) {
            denetim = veri[i];      /* yazılanı geri oku (denetim) */
        }
    }
    son_kapasite = (long long)kapasite;
    free(veri);
    for (size_t j = 0; j < engel_sayisi; j++) {
        free(engeller[j]);
    }
}

static int kucuk(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

int main(int argc, char *argv[])
{
    if (argc < 5 || argc > 7) {
        fprintf(stderr, "kullanım: %s SERİ strateji n tekrar [ic [isinma]]"
                "\n", argv[0]);
        return 2;
    }
    int ic = argc >= 6 ? atoi(argv[5]) : 1;
    int isinma = argc == 7 ? atoi(argv[6]) : 1;
    elle = strcmp(argv[1], "elle") == 0;
    engelli = strcmp(argv[1], "realloc_engelli") == 0;
    strateji = atoi(argv[2]);
    n = (size_t)strtoul(argv[3], NULL, 10);
    int tekrar = atoi(argv[4]);
    if (n < 2 || tekrar < 1 || tekrar > 101 || strateji < 0 ||
        strateji > 3 || ic < 1) {
        return 2;
    }
    engeller = malloc(n * sizeof *engeller);
    if (engeller == NULL) {
        return 1;
    }
    double duvar[101], islemci[101];
    if (isinma) {
        gorev(NULL);                               /* ısınma */
    }
    for (int k = 0; k < tekrar; k++) {
        double c0 = islemci_sn(), w0 = zaman_sn();
        for (int r = 0; r < ic; r++) {
            gorev(NULL);
        }
        duvar[k] = (zaman_sn() - w0) * 1e3 / ic;
        islemci[k] = (islemci_sn() - c0) * 1e3 / ic;
    }
    double kopyalar[101];
    memcpy(kopyalar, duvar, sizeof duvar);
    qsort(kopyalar, (size_t)tekrar, sizeof kopyalar[0], kucuk);
    printf("%s;%d;%zu;%d;%.4f;%.4f;%.4f;%.4f;%lld;%lld;%lld\n", argv[1],
           strateji, n, tekrar, ortanca(duvar, tekrar),
           ortanca(islemci, tekrar), kopyalar[0], kopyalar[tekrar - 1], kopya,
           son_kapasite, tasima);
    free(engeller);
    if (denetim != (long long)(n / 2)) {
        fprintf(stderr, "denetim hatası\n");
        return 1;
    }
    return 0;
}

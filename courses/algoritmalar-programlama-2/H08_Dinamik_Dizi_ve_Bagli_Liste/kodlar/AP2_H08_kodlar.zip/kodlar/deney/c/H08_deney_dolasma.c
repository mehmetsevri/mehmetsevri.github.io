/* H08_deney_dolasma.c — AP-2 Hafta 8 · Haftanın Deneyi (c), C
 * Amaç    : Düğümlerin ayrılma/bağlanma sırasının önbellek etkisi: n
 *           düğümü baştan sona dolaşmanın düğüm başına süresi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_deney_dolasma.c \
 *           ortak_rastgele.c zamanlayici.c -o H08_deney_dolasma
 * Çalıştır: ./H08_deney_dolasma DÜZEN n tekrar
 *   DÜZEN: dizi     int dizisinin toplamı (karşılaştırma tabanı)
 *          bitisik  düğümler art arda malloc edilir, AYNI sırayla bağlanır
 *          karisik  aynı düğümler karıştırılmış sırayla bağlanır (dağınık)
 * Çıktı   : duzen;n;tekrar;gecis;duvar_ns;islemci_ns;denetim
 *           (ns: düğüm/öğe başına, ortanca; gecis: ölçüm başına geçiş)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *bas = NULL;
static int *dizi = NULL;
static size_t n = 0;
static long gecis = 1;
static int duzen = 0;            /* 0 dizi, 1 bitişik, 2 karışık */
static long long denetim = 0;

static void gorev(void *v)
{
    (void)v;
    long long toplam = 0;
    for (long g = 0; g < gecis; g++) {
        if (duzen == 0) {
            for (size_t i = 0; i < n; i++) {
                toplam += dizi[i];
            }
        } else {
            for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
                toplam += p->veri;
            }
        }
    }
    denetim = toplam;
}

int main(int argc, char *argv[])
{
    if (argc != 4) {
        fprintf(stderr, "kullanım: %s dizi|bitisik|karisik n tekrar\n",
                argv[0]);
        return 2;
    }
    duzen = strcmp(argv[1], "dizi") == 0      ? 0
            : strcmp(argv[1], "bitisik") == 0 ? 1
                                              : 2;
    n = (size_t)strtoul(argv[2], NULL, 10);
    int tekrar = atoi(argv[3]);
    if (n < 2 || tekrar < 1 || tekrar > 101) {
        return 2;
    }
    gecis = (long)(10000000 / n);   /* ölçüm başına ≈ 10^7 ziyaret */
    if (gecis < 1) {
        gecis = 1;
    }
    Dugum **dugumler = NULL;
    if (duzen == 0) {
        dizi = malloc(n * sizeof *dizi);
        if (dizi == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            dizi[i] = (int)(i % 1000);
        }
    } else {
        dugumler = malloc(n * sizeof *dugumler);
        int *sira = malloc(n * sizeof *sira);
        if (dugumler == NULL || sira == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {       /* art arda ayırma */
            dugumler[i] = malloc(sizeof **dugumler);
            if (dugumler[i] == NULL) {
                return 1;
            }
            dugumler[i]->veri = (int)(i % 1000);
            sira[i] = (int)i;
        }
        if (duzen == 2) {
            rastgele_tohum(42);
            rastgele_karistir(sira, n);
        }
        for (size_t i = 0; i < n; i++) {        /* bağlama sırası */
            dugumler[sira[i]]->sonraki =
                i + 1 < n ? dugumler[sira[i + 1]] : NULL;
        }
        bas = dugumler[sira[0]];
        free(sira);
    }
    double duvar[101], islemci[101];
    gorev(NULL);                                  /* ısınma */
    for (int k = 0; k < tekrar; k++) {
        double c0 = islemci_sn(), w0 = zaman_sn();
        gorev(NULL);
        double ziyaret = (double)n * (double)gecis;
        duvar[k] = (zaman_sn() - w0) * 1e9 / ziyaret;
        islemci[k] = (islemci_sn() - c0) * 1e9 / ziyaret;
    }
    printf("%s;%zu;%d;%ld;%.4f;%.4f;%lld\n", argv[1], n, tekrar, gecis,
           ortanca(duvar, tekrar), ortanca(islemci, tekrar), denetim);
    if (dugumler != NULL) {
        for (size_t i = 0; i < n; i++) {
            free(dugumler[i]);
        }
        free(dugumler);
    }
    free(dizi);
    return 0;
}

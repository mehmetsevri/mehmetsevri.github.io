/* H08_deney_stroustrup.c — AP-2 Hafta 8 · Haftanın Deneyi (a), C
 * Amaç    : Stroustrup iş yükü (sıralı yapıya doğrusal aramayla ekleme,
 *           rastgele konumlardan silme) için süre ölçümü; düğüm yerleşimi
 *           değişkeni ve arama/değiştirme ayrıştırması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_deney_stroustrup.c \
 *           ortak_rastgele.c zamanlayici.c -o H08_deney_stroustrup
 * Çalıştır: ./H08_deney_stroustrup SERİ n tekrar [ic [isinma]]
 *   ic: bir ölçümde görevin kaç kez yinelendiği (küçük n için);
 *   isinma: 1 (varsayılan) ya da 0 (çok uzun tek ölçümlerde ısınmasız)
 *   SERİ: dizi           dinamik dizi (× 2, realloc), kaydırma döngüsü
 *         liste          tek bağlı liste, düğüm başına malloc (doğal)
 *         liste_bitisik  düğümler tek blokta, adres sırası = liste sırası
 *         liste_karisik  aynı blok, adresler karıştırılmış (dağınık)
 *         dizi_ayristir / liste_ayristir: dizi / liste, işlem başına
 *                        arama ve değiştirme süreleri ayrı toplanır
 * Çıktı   : tek satır: seri;n;tekrar;duvar_ms;islemci_ms;en_az_ms;
 *           en_cok_ms;ara_ms;degistir_ms;adim;denetim (ortancalar)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    int *veri;
    size_t boyut, kapasite;
} DinamikDizi;

static int *degerler;            /* ekleme sırası */
static size_t *konumlar;         /* silme konumları: konumlar[i] < n - i */
static Dugum **hazir;            /* havuzlu serilerde i. eklemenin düğümü */
static Dugum *havuz;
static size_t n;
static int ayristir = 0;
static double t_ara = 0, t_degistir = 0;
static long long adim = 0;       /* karşılaştırma + kaydırma / ziyaret */
static long long denetim = 0;    /* silinen değerlerin toplamı */

static void *ayir(size_t bayt)
{
    void *p = malloc(bayt);
    if (p == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    return p;
}

static void dizi_gorevi(void)
{
    DinamikDizi d = {NULL, 0, 0};
    adim = 0;
    denetim = 0;
    for (size_t i = 0; i < n; i++) {
        int x = degerler[i];
        double t0 = ayristir ? zaman_sn() : 0;
        size_t konum = 0;
        while (konum < d.boyut && d.veri[konum] <= x) {
            konum++;
        }
        double t1 = ayristir ? zaman_sn() : 0;
        if (d.boyut == d.kapasite) {
            size_t yeni = d.kapasite == 0 ? 1 : 2 * d.kapasite;
            int *g = realloc(d.veri, yeni * sizeof *g);
            if (g == NULL) {
                fprintf(stderr, "bellek yetersiz\n");
                exit(1);
            }
            d.veri = g;
            d.kapasite = yeni;
        }
        for (size_t j = d.boyut; j > konum; j--) {
            d.veri[j] = d.veri[j - 1];
        }
        d.veri[konum] = x;
        adim += (long long)konum + (long long)(d.boyut - konum);
        d.boyut++;
        if (ayristir) {
            double t2 = zaman_sn();
            t_ara += t1 - t0;
            t_degistir += t2 - t1;
        }
    }
    for (size_t i = 0; i < n; i++) {
        double t0 = ayristir ? zaman_sn() : 0;
        size_t konum = konumlar[i];       /* dizide konum O(1) bulunur */
        int x = d.veri[konum];
        for (size_t j = konum; j + 1 < d.boyut; j++) {
            d.veri[j] = d.veri[j + 1];
        }
        adim += (long long)(d.boyut - konum - 1);
        d.boyut--;
        denetim += x;
        if (ayristir) {
            t_degistir += zaman_sn() - t0;
        }
    }
    free(d.veri);
}

/* havuzlu = 0: düğüm başına malloc/free; 1: hazir[i] kullanılır */
static void liste_gorevi(int havuzlu)
{
    Dugum *bas = NULL;
    adim = 0;
    denetim = 0;
    for (size_t i = 0; i < n; i++) {
        int x = degerler[i];
        double t0 = ayristir ? zaman_sn() : 0;
        Dugum **p = &bas;
        while (*p != NULL && (*p)->veri <= x) {
            p = &(*p)->sonraki;
            adim++;
        }
        double t1 = ayristir ? zaman_sn() : 0;
        Dugum *d = havuzlu ? hazir[i] : ayir(sizeof *d);
        d->veri = x;
        d->sonraki = *p;
        *p = d;
        if (ayristir) {
            double t2 = zaman_sn();
            t_ara += t1 - t0;
            t_degistir += t2 - t1;
        }
    }
    for (size_t i = 0; i < n; i++) {
        double t0 = ayristir ? zaman_sn() : 0;
        Dugum **p = &bas;
        for (size_t k = 0; k < konumlar[i]; k++) {
            p = &(*p)->sonraki;
        }
        adim += (long long)konumlar[i];
        double t1 = ayristir ? zaman_sn() : 0;
        Dugum *s = *p;
        *p = s->sonraki;
        denetim += s->veri;
        if (!havuzlu) {
            free(s);
        }
        if (ayristir) {
            double t2 = zaman_sn();
            t_ara += t1 - t0;
            t_degistir += t2 - t1;
        }
    }
}

static int siraya_gore(const void *a, const void *b)
{
    size_t i = *(const size_t *)a, j = *(const size_t *)b;
    if (degerler[i] != degerler[j]) {
        return degerler[i] < degerler[j] ? -1 : 1;
    }
    return (i > j) - (i < j);
}

/* Havuz: n düğüm tek blokta. i. eklenen değerin son sıradaki yeri r ise
 * bitişikte havuz[r], karışıkta havuz[karisim[r]] kullanılır. */
static void havuz_hazirla(int karisik)
{
    havuz = ayir(n * sizeof *havuz);
    hazir = ayir(n * sizeof *hazir);
    size_t *sira = ayir(n * sizeof *sira);
    int *karisim = ayir(n * sizeof *karisim);
    for (size_t i = 0; i < n; i++) {
        sira[i] = i;
        karisim[i] = (int)i;
    }
    qsort(sira, n, sizeof *sira, siraya_gore);   /* hazırlık; ölçülmez */
    if (karisik) {
        rastgele_tohum(7);
        rastgele_karistir(karisim, n);
    }
    for (size_t r = 0; r < n; r++) {
        hazir[sira[r]] = &havuz[karisim[r]];
    }
    free(sira);
    free(karisim);
}

static int seri_no = 0;
static void gorev(void *v)
{
    (void)v;
    if (seri_no == 0) {
        dizi_gorevi();
    } else {
        liste_gorevi(seri_no >= 2);
    }
}

static int kucuk(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

int main(int argc, char *argv[])
{
    if (argc < 4 || argc > 6) {
        fprintf(stderr, "kullanım: %s SERİ n tekrar [ic [isinma]]\n",
                argv[0]);
        return 2;
    }
    int ic = argc >= 5 ? atoi(argv[4]) : 1;
    int isinma = argc == 6 ? atoi(argv[5]) : 1;
    const char *seri = argv[1];
    n = (size_t)strtoul(argv[2], NULL, 10);
    int tekrar = atoi(argv[3]);
    if (n < 1 || tekrar < 1 || tekrar > 101 || ic < 1) {
        return 2;
    }
    if (strcmp(seri, "dizi") == 0 || strcmp(seri, "dizi_ayristir") == 0) {
        seri_no = 0;
    } else if (strcmp(seri, "liste") == 0 ||
               strcmp(seri, "liste_ayristir") == 0) {
        seri_no = 1;
    } else if (strcmp(seri, "liste_bitisik") == 0) {
        seri_no = 2;
    } else if (strcmp(seri, "liste_karisik") == 0) {
        seri_no = 3;
    } else {
        fprintf(stderr, "bilinmeyen seri: %s\n", seri);
        return 2;
    }
    ayristir = strstr(seri, "ayristir") != NULL;
    degerler = ayir(n * sizeof *degerler);
    konumlar = ayir(n * sizeof *konumlar);
    rastgele_tohum(42);
    for (size_t i = 0; i < n; i++) {
        degerler[i] = (int)rastgele_sayi();
    }
    for (size_t i = 0; i < n; i++) {
        konumlar[i] = (size_t)rastgele_aralik(0, (int)(n - 1 - i));
    }
    if (seri_no >= 2) {
        havuz_hazirla(seri_no == 3);
    }
    double duvar[101], islemci[101], ara[101], degis[101];
    if (isinma) {
        gorev(NULL);                               /* ısınma */
    }
    for (int k = 0; k < tekrar; k++) {
        t_ara = t_degistir = 0;
        double c0 = islemci_sn(), w0 = zaman_sn();
        for (int r = 0; r < ic; r++) {
            gorev(NULL);
        }
        duvar[k] = (zaman_sn() - w0) * 1e3 / ic;
        islemci[k] = (islemci_sn() - c0) * 1e3 / ic;
        ara[k] = t_ara * 1e3 / ic;
        degis[k] = t_degistir * 1e3 / ic;
    }
    qsort(duvar, (size_t)tekrar, sizeof duvar[0], kucuk);
    double en_az = duvar[0], en_cok = duvar[tekrar - 1];
    printf("%s;%zu;%d;%.4f;%.4f;%.4f;%.4f;%.4f;%.4f;%lld;%lld\n", seri, n,
           tekrar, ortanca(duvar, tekrar), ortanca(islemci, tekrar), en_az,
           en_cok, ortanca(ara, tekrar), ortanca(degis, tekrar), adim,
           denetim);
    free(degerler);
    free(konumlar);
    free(havuz);
    free(hazir);
    return 0;
}

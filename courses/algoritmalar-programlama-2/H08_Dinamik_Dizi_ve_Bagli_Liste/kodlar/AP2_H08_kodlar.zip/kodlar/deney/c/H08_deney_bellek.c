/* H08_deney_bellek.c — AP-2 Hafta 8 · Bellek boyutu gözlemi (C, glibc)
 * Amaç    : int verisi için dizi ve bağlı liste bellek maliyeti: sizeof
 *           (bu makinede, x86-64 LP64), malloc_usable_size (GLIBC
 *           UZANTISI; taşınabilir C değildir) ve art arda ayrılan
 *           düğümlerin adres aralıkları (bu çalıştırmada)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_deney_bellek.c \
 *           -o H08_deney_bellek
 * Çalıştır: ./H08_deney_bellek
 * Not     : Adreslerin kendisi yazdırılmaz (ASLR); yalnızca ardışık iki
 *           düğüm arasındaki fark (bayt) istatistiği yazdırılır.
 */
#define _GNU_SOURCE
#include <malloc.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

typedef struct CDugum {
    int veri;
    struct CDugum *onceki, *sonraki;
} CDugum;

static int kucuk(const void *a, const void *b)
{
    long long x = *(const long long *)a, y = *(const long long *)b;
    return (x > y) - (x < y);
}

int main(void)
{
    printf("sizeof (bu makinede, x86-64 LP64):\n");
    printf("  int = %zu, void * = %zu, Dugum {int; Dugum *} = %zu, "
           "CDugum {int; 2 işaretçi} = %zu\n", sizeof(int), sizeof(void *),
           sizeof(Dugum), sizeof(CDugum));
    Dugum *d = malloc(sizeof *d);
    CDugum *c = malloc(sizeof *c);
    int *a = malloc(1000 * sizeof *a);
    if (d == NULL || c == NULL || a == NULL) {
        return 1;
    }
    printf("malloc_usable_size (glibc uzantısı):\n");
    printf("  malloc(%zu) -> %zu kullanılabilir bayt; malloc(%zu) -> %zu; "
           "malloc(4000) -> %zu\n", sizeof *d, malloc_usable_size(d),
           sizeof *c, malloc_usable_size(c), malloc_usable_size(a));
    free(d);
    free(c);
    free(a);

    enum { N = 100000 };
    static Dugum *dugum[N];
    static long long fark[N - 1];
    for (int i = 0; i < N; i++) {
        dugum[i] = malloc(sizeof **dugum);
        if (dugum[i] == NULL) {
            return 1;
        }
    }
    int otuz_iki = 0;
    for (int i = 0; i + 1 < N; i++) {
        fark[i] = (long long)((intptr_t)dugum[i + 1] - (intptr_t)dugum[i]);
        otuz_iki += fark[i] == 32;
    }
    qsort(fark, N - 1, sizeof fark[0], kucuk);
    printf("art arda %d malloc(%zu) (bu çalıştırmada):\n", N, sizeof(Dugum));
    printf("  ardışık adres farkı: ortanca = %lld bayt, en küçük = %lld, "
           "en büyük = %lld;\n  farkı tam 32 bayt olan çift = %d/%d "
           "(%.1f%%)\n", fark[(N - 1) / 2], fark[0], fark[N - 2], otuz_iki,
           N - 1, 100.0 * otuz_iki / (N - 1));
    for (int i = 0; i < N; i++) {
        free(dugum[i]);
    }
    printf("int verisi için öğe başına bellek (bu makinede):\n");
    printf("  dizi: %zu bayt (+ büyüme payı); tek bağlı düğüm: %zu bayt "
           "(sizeof) / 32 bayt (öbek bloğu);\n  çift bağlı düğüm: %zu bayt "
           "(sizeof) / 32 bayt (öbek bloğu)\n", sizeof(int), sizeof(Dugum),
           sizeof(CDugum));
    return 0;
}

/* H08_HA9_unique_ptr_yigin.cpp — AP-2 Hafta 8 · Hata Avcısı 9 (ek, C++)
 * BU DOSYA KASITLI HATA İÇERİR: std::unique_ptr<Dugum> sonraki zincirinin
 *   VARSAYILAN yıkıcısı özyinelemelidir: baş silinir, o sonraki'yi siler,
 *   o da kendi sonraki'sini... Derinlik n'dir; büyük n'de çağrı yığını
 *   taşar (bu derleyicide ve bu çalıştırmada: bkz. ciktilar/H08_HA9_*).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA9_unique_ptr_yigin.cpp -o H08_HA9_unique_ptr_yigin
 * Çalıştır: ./H08_HA9_unique_ptr_yigin [n]      (varsayılan n = 1000000)
 * Düzeltme: H08_HA9_unique_ptr_yigin_duzeltilmis.cpp
 */
#include <iostream>
#include <memory>
#include <string>
#include <utility>

struct Dugum {
    int veri;
    std::unique_ptr<Dugum> sonraki;   // sahiplik zinciri
};

struct Liste {
    std::unique_ptr<Dugum> bas;
    // HATA: yıkıcı yazılmadı; ~unique_ptr -> ~Dugum -> ~unique_ptr -> ...
};

int main(int argc, char* argv[])
{
    long n = argc > 1 ? std::stol(argv[1]) : 1000000;
    {
        Liste liste;
        for (long i = 0; i < n; i++) {
            auto d = std::make_unique<Dugum>();
            d->veri = static_cast<int>(i);
            d->sonraki = std::move(liste.bas);
            liste.bas = std::move(d);
        }
        std::cout << n << " düğüm kuruldu; kapsam kapanıyor (yıkıcı)..."
                  << std::endl;
    }
    std::cout << "liste yok edildi" << std::endl;
    return 0;
}

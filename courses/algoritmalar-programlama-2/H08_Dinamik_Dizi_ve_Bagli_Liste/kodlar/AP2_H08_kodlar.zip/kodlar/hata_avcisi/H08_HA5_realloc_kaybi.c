/* H08_HA5_realloc_kaybi.c — AP-2 Hafta 8 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR: d->veri = realloc(d->veri, ...) —
 *   realloc başarısız olup NULL döndürünce eski blok yerinde ve geçerlidir
 *   ama tek adresi NULL ile ezilir: veriler ve blok kaybolur (sızıntı).
 * Başarısızlık güvenli biçimde benzetilir: yeniden_ayir sarmalayıcısı
 *   BASARISIZ_CAGRI'ncı çağrıda realloc'u çağırmadan NULL döndürür
 *   (gerçek realloc'un başarısızlıktaki davranışı: eski blok dokunulmaz).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_HA5_realloc_kaybi.c \
 *           -o H08_HA5_realloc_kaybi
 * Denetim : -g -fsanitize=address (LeakSanitizer) / valgrind
 * Düzeltme: H08_HA5_realloc_kaybi_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

#define BASARISIZ_CAGRI 4    /* 4. büyütme (kapasite 8 -> 16) başarısız */

typedef struct {
    int *veri;
    size_t boyut, kapasite;
} DinamikDizi;

static int cagri_sayisi = 0;

/* Ayırıcı sarmalayıcısı: başarısızlık benzetimi (sınama amaçlı) */
static void *yeniden_ayir(void *p, size_t bayt)
{
    if (++cagri_sayisi == BASARISIZ_CAGRI) {
        return NULL;                /* p'ye dokunulmaz (realloc gibi) */
    }
    return realloc(p, bayt);
}

/* HATA: dönüş değeri doğrudan d->veri'ye atanıyor */
static int dd_ekle(DinamikDizi *d, int x)
{
    if (d->boyut == d->kapasite) {
        d->kapasite *= 2;
        d->veri = yeniden_ayir(d->veri, d->kapasite * sizeof *d->veri);
        if (d->veri == NULL) {
            return -1;              /* eski blok artık erişilemez */
        }
    }
    d->veri[d->boyut++] = x;
    return 0;
}

int main(void)
{
    DinamikDizi d = {malloc(sizeof(int)), 0, 1};
    if (d.veri == NULL) {
        return 1;
    }
    for (int i = 1; i <= 20; i++) {
        if (dd_ekle(&d, i * i) != 0) {
            printf("ekle %d: bellek yetersiz (benzetim); d.veri = %s, "
                   "boyut = %zu\n", i, d.veri == NULL ? "NULL" : "geçerli",
                   d.boyut);
            printf("ilk %zu öğe kurtarılamaz: tek adresleri kayboldu\n",
                   d.boyut);
            break;
        }
    }
    free(d.veri);                   /* free(NULL): hiçbir şey yapmaz */
    return 0;
}

/* H08_HA4_bas_degerle.c — AP-2 Hafta 8 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR: basa_ekle baş işaretçisini DEĞERLE alır;
 *   fonksiyondaki bas = d yalnızca yerel kopyayı değiştirir (AP-1 H8
 *   takas sorusunun yeni yüzü). main'in listesi boş kalır, düğümler sızar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_HA4_bas_degerle.c \
 *           -o H08_HA4_bas_degerle
 * Denetim : -g -fsanitize=address (LeakSanitizer); bkz. ciktilar/H08_HA4_*
 * Düzeltme: H08_HA4_bas_degerle_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

/* HATA: bas, çağıranın işaretçisinin KOPYASIDIR */
static void basa_ekle(Dugum *bas, int x)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        exit(1);
    }
    d->veri = x;
    d->sonraki = bas;
    bas = d;                 /* yerel kopya değişir; main'deki değişmez */
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

int main(void)
{
    Dugum *bas = NULL;
    basa_ekle(bas, 4);
    basa_ekle(bas, 1);
    basa_ekle(bas, 3);
    printf("3 kez basa_ekle sonrası liste: ");
    liste_yaz(bas);
    printf("bas %s NULL\n", bas == NULL ? "==" : "!=");
    return 0;
}

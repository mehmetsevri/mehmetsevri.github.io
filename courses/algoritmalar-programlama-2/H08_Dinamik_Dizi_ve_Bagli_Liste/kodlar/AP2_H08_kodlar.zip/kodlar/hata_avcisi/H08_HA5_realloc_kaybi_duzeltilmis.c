/* H08_HA5_realloc_kaybi_duzeltilmis.c — AP-2 Hafta 8 · Hata Avcısı 5
 * Düzeltme: realloc sonucu önce GEÇİCİ işaretçiye alınır; NULL ise eski
 *   blok ve kapasite değişmeden kalır, çağıran durumu bilir ve veriler
 *   korunur. Aynı başarısızlık benzetimi (BASARISIZ_CAGRI) kullanılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA5_realloc_kaybi_duzeltilmis.c -o H08_HA5_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

#define BASARISIZ_CAGRI 4    /* 4. büyütme (kapasite 8 -> 16) başarısız */

typedef struct {
    int *veri;
    size_t boyut, kapasite;
} DinamikDizi;

static int cagri_sayisi = 0;

/* Ayırıcı sarmalayıcısı: başarısızlık benzetimi (sınama amaçlı) */
static void *yeniden_ayir(void *p, size_t bayt)
{
    if (++cagri_sayisi == BASARISIZ_CAGRI) {
        return NULL;                /* p'ye dokunulmaz (realloc gibi) */
    }
    return realloc(p, bayt);
}

/* 0: başarı, -1: bellek yetersiz (dizi değişmeden geçerli kalır) */
static int dd_ekle(DinamikDizi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = 2 * d->kapasite;
        int *gecici = yeniden_ayir(d->veri, yeni * sizeof *d->veri);
        if (gecici == NULL) {
            return -1;              /* d->veri ve d->kapasite aynen */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

int main(void)
{
    DinamikDizi d = {malloc(sizeof(int)), 0, 1};
    if (d.veri == NULL) {
        return 1;
    }
    for (int i = 1; i <= 20; i++) {
        if (dd_ekle(&d, i * i) != 0) {
            printf("ekle %d: bellek yetersiz (benzetim); d.veri = %s, "
                   "boyut = %zu, kapasite = %zu\n", i,
                   d.veri == NULL ? "NULL" : "geçerli", d.boyut, d.kapasite);
            printf("veriler korunuyor:");
            for (size_t j = 0; j < d.boyut; j++) {
                printf(" %d", d.veri[j]);
            }
            printf("\n");
            break;
        }
    }
    free(d.veri);
    return 0;
}

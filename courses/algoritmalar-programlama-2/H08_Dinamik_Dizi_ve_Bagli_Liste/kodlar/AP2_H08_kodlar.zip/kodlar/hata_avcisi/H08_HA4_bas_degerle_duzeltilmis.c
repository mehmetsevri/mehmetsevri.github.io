/* H08_HA4_bas_degerle_duzeltilmis.c — AP-2 Hafta 8 · Hata Avcısı 4
 * Düzeltme (iki yol): (1) basa_ekle(Dugum **bas, x) — işaretçinin ADRESİ
 *   verilir, *bas = d çağıranınkini değiştirir; (2) yeni baş döndürülür:
 *   bas = basa_ekle_dondur(bas, x). Sonunda liste serbest bırakılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA4_bas_degerle_duzeltilmis.c -o H08_HA4_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *dugum_olustur(int x, Dugum *sonraki)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        exit(1);
    }
    d->veri = x;
    d->sonraki = sonraki;
    return d;
}

/* (1) Adres verilir: çağıranın baş işaretçisi güncellenir */
static void basa_ekle(Dugum **bas, int x)
{
    *bas = dugum_olustur(x, *bas);
}

/* (2) Yeni baş döndürülür: çağıran atar */
static Dugum *basa_ekle_dondur(Dugum *bas, int x)
{
    return dugum_olustur(x, bas);
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

static void liste_yok_et(Dugum **bas)
{
    while (*bas != NULL) {
        Dugum *sonraki = (*bas)->sonraki;
        free(*bas);
        *bas = sonraki;
    }
}

int main(void)
{
    Dugum *bas = NULL;
    basa_ekle(&bas, 4);
    basa_ekle(&bas, 1);
    basa_ekle(&bas, 3);
    printf("(1) Dugum ** ile    : ");
    liste_yaz(bas);
    liste_yok_et(&bas);
    bas = basa_ekle_dondur(bas, 4);
    bas = basa_ekle_dondur(bas, 1);
    bas = basa_ekle_dondur(bas, 3);
    printf("(2) yeni baş dönüşü : ");
    liste_yaz(bas);
    liste_yok_et(&bas);
    printf("bas %s NULL (liste serbest bırakıldı)\n",
           bas == NULL ? "==" : "!=");
    return 0;
}

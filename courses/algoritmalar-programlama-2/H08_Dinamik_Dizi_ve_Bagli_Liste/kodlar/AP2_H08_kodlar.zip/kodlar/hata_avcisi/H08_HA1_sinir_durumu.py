"""H08_HA1_sinir_durumu.py — AP-2 Hafta 8 · Hata Avcısı 1 (Python)
BU DOSYA KASITLI HATA İÇERİR: son_dugumu_sil en az iki düğüm varsayar;
  tek düğümlü (ve boş) liste sınır durumu atlanmıştır.
Çalıştır: python3 H08_HA1_sinir_durumu.py
Belirti : ciktilar/H08_HA1_sinir_durumu_py.txt (AttributeError)
Düzeltme: H08_HA1_sinir_durumu_duzeltilmis.py
"""


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def liste_olustur(n):
    bas = None
    for i in range(n, 0, -1):
        bas = Dugum(i, bas)
    return bas


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]")


def son_dugumu_sil(bas):
    """HATA: p.sonraki.sonraki, en az İKİ düğüm varsayar"""
    p = bas
    while p.sonraki.sonraki is not None:
        p = p.sonraki
    p.sonraki = None


def main():
    bas = liste_olustur(3)
    print("başta    : ", end="")
    liste_yaz(bas)
    for _ in range(3):
        son_dugumu_sil(bas)
        print("son silindi: ", end="")
        liste_yaz(bas)


if __name__ == "__main__":
    main()

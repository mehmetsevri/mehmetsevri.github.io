/* H08_HA3_free_sonrasi.c — AP-2 Hafta 8 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR: liste_yok_et, free ettiği düğümün
 *   sonraki alanını SONRA okur (free sonrası kullanım; tanımsız davranış).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA3_free_sonrasi.c -o H08_HA3_free_sonrasi
 * Denetim : -g -fsanitize=address ya da valgrind; belirti bu derleyicide
 *           ve bu çalıştırmada gözlenendir (bkz. ciktilar/H08_HA3_*)
 * Düzeltme: H08_HA3_free_sonrasi_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *dugum_olustur(int veri, Dugum *sonraki)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        exit(1);
    }
    d->veri = veri;
    d->sonraki = sonraki;
    return d;
}

/* HATA: p = p->sonraki, free(p)'den SONRA çalışır: serbest bırakılmış
 * bloğun içinden okur. Ayırıcı o bloğa kendi kayıtlarını yazmış olabilir. */
static void liste_yok_et(Dugum *bas)
{
    int sayac = 0;
    for (Dugum *p = bas; p != NULL; p = p->sonraki) {
        free(p);
        sayac++;
    }
    printf("liste_yok_et: %d düğüm bırakıldı\n", sayac);
}

int main(void)
{
    Dugum *bas = NULL;
    for (int i = 5; i >= 1; i--) {
        bas = dugum_olustur(i, bas);
    }
    printf("5 düğümlük liste kuruldu\n");
    liste_yok_et(bas);
    printf("program sona erdi\n");
    return 0;
}

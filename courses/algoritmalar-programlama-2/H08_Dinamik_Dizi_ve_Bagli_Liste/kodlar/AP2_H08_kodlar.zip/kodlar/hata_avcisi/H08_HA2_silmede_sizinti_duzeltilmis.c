/* H08_HA2_silmede_sizinti_duzeltilmis.c — AP-2 Hafta 8 · Hata Avcısı 2
 * Düzeltme: koparılacak düğümün adresi önce bir değişkende saklanır,
 *   bağlantı güncellenir, SONRA free edilir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA2_silmede_sizinti_duzeltilmis.c -o H08_HA2_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static long ayirma_sayisi = 0, birakma_sayisi = 0;

static Dugum *dugum_olustur(int veri, Dugum *sonraki)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        exit(1);
    }
    d->veri = veri;
    d->sonraki = sonraki;
    ayirma_sayisi++;
    return d;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

/* İlk x'i siler: önce sakla, sonra kopar, en son free */
static void sil(Dugum **bas, int x)
{
    Dugum **p = bas;
    while (*p != NULL && (*p)->veri != x) {
        p = &(*p)->sonraki;
    }
    if (*p != NULL) {
        Dugum *silinen = *p;
        *p = silinen->sonraki;
        free(silinen);
        birakma_sayisi++;
    }
}

static void liste_yok_et(Dugum **bas)
{
    while (*bas != NULL) {
        Dugum *sonraki = (*bas)->sonraki;
        free(*bas);
        birakma_sayisi++;
        *bas = sonraki;
    }
}

int main(void)
{
    Dugum *bas = NULL;
    for (int i = 5; i >= 1; i--) {
        bas = dugum_olustur(i, bas);
    }
    printf("başta : ");
    liste_yaz(bas);
    sil(&bas, 3);
    printf("sil 3 : ");
    liste_yaz(bas);
    liste_yok_et(&bas);
    printf("ayrılan = %ld, bırakılan = %ld -> %ld düğüm sızdı\n",
           ayirma_sayisi, birakma_sayisi, ayirma_sayisi - birakma_sayisi);
    return 0;
}

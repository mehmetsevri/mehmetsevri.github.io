"""H08_HA4_bas_degerle_duzeltilmis.py — AP-2 Hafta 8 · Hata Avcısı 4
Düzeltme: Python'da işaretçiye işaretçi yoktur; yeni baş DÖNDÜRÜLÜR ve
  çağıran atar (bas = basa_ekle(bas, x)). Diğer yol: başı bir nesnenin
  alanında tutmak (liste.bas = ...).
Çalıştır: python3 H08_HA4_bas_degerle_duzeltilmis.py
"""


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def basa_ekle(bas, x):
    """Yeni başı döndürür"""
    return Dugum(x, bas)


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]")


def main():
    bas = None
    bas = basa_ekle(bas, 4)
    bas = basa_ekle(bas, 1)
    bas = basa_ekle(bas, 3)
    print("3 kez basa_ekle sonrası liste: ", end="")
    liste_yaz(bas)
    print(f"bas {'is' if bas is None else 'is not'} None")


if __name__ == "__main__":
    main()

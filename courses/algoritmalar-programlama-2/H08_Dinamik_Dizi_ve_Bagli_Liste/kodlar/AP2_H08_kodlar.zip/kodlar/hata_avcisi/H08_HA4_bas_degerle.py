"""H08_HA4_bas_degerle.py — AP-2 Hafta 8 · Hata Avcısı 4 (Python)
BU DOSYA KASITLI HATA İÇERİR: basa_ekle parametre adını yeniden bağlar;
  Python'da bu, çağıranın değişkenini DEĞİŞTİRMEZ (C'deki değerle aktarımın
  aynısı). Liste boş kalır; sızıntı yoktur (başvurusuz düğümleri başvuru
  sayımı geri alır).
Çalıştır: python3 H08_HA4_bas_degerle.py
Düzeltme: H08_HA4_bas_degerle_duzeltilmis.py
"""


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def basa_ekle(bas, x):
    """HATA: 'bas' yerel bir addır; yeniden bağlamak çağıranı etkilemez"""
    d = Dugum(x, bas)
    bas = d  # noqa: F841 (kasıtlı: değer hiç kullanılmaz)


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]")


def main():
    bas = None
    basa_ekle(bas, 4)
    basa_ekle(bas, 1)
    basa_ekle(bas, 3)
    print("3 kez basa_ekle sonrası liste: ", end="")
    liste_yaz(bas)
    print(f"bas {'is' if bas is None else 'is not'} None")


if __name__ == "__main__":
    main()

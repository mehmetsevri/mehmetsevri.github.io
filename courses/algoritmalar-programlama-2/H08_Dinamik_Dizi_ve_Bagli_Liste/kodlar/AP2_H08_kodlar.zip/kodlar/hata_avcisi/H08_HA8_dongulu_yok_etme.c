/* H08_HA8_dongulu_yok_etme.c — AP-2 Hafta 8 · Hata Avcısı 8 (ek)
 * BU DOSYA KASITLI HATA İÇERİR: döngülü liste, döngü KIRILMADAN olağan
 *   liste_yok_et ile serbest bırakılır: son düğümden sonra döngünün
 *   başlangıcına (zaten free edilmiş düğüme) dönülür — free sonrası okuma
 *   ve çift free (tanımsız davranış).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA8_dongulu_yok_etme.c -o H08_HA8_dongulu_yok_etme
 * Belirti : bu derleyicide, bu çalıştırmada: bkz. ciktilar/H08_HA8_*
 * Düzeltme: H08_HA8_dongulu_yok_etme_duzeltilmis.c (Floyd + döngüyü kır)
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

/* 0..n-1 konumlu düğümler; son düğüm mu konumundakine bağlanır */
static Dugum *dongulu_liste_kur(int n, int mu)
{
    Dugum *bas = NULL, *son = NULL, *hedef = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = malloc(sizeof *d);
        if (d == NULL) {
            exit(1);
        }
        d->veri = i;
        d->sonraki = NULL;
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
        if (i == mu) {
            hedef = d;
        }
    }
    son->sonraki = hedef;
    return bas;
}

/* Döngüsüz liste için doğru; döngülüde HATA: NULL'a hiç ulaşılmaz */
static void liste_yok_et(Dugum *bas)
{
    int sayac = 0;
    while (bas != NULL && sayac < 100) {   /* sayac: sonsuz döngü freni */
        Dugum *sonraki = bas->sonraki;
        printf("free(%d)\n", bas->veri);
        free(bas);
        bas = sonraki;
        sayac++;
    }
}

int main(void)
{
    Dugum *bas = dongulu_liste_kur(5, 2);   /* 0 1 2 3 4 -> 2 */
    printf("liste: 0 -> 1 -> 2 -> 3 -> 4 -> (2'ye döner)\n");
    liste_yok_et(bas);
    printf("bitti\n");
    return 0;
}

"""H08_HA7_list_bagli_liste_degil.py — AP-2 Hafta 8 · Hata Avcısı 7
BU DOSYA KASITLI HATA İÇERİR: Python list'ini bağlı liste sanıp başa
  ekleme için list.insert(0, x) kullanmak. list bir DİNAMİK DİZİDİR: her
  insert(0, x) mevcut tüm öğeleri bir sağa kaydırır (Θ(boyut)); n başa
  ekleme Θ(n²) olur. Süreler stderr'e değil stdout'a yazılır: çıktı bu
  makinede, bu çalıştırmada ölçülendir (deterministik değildir).
Çalıştır: python3 H08_HA7_list_bagli_liste_degil.py
Düzeltme: H08_HA7_list_bagli_liste_degil_duzeltilmis.py
"""
import time


def basa_ekle_hepsi(n):
    """HATA: 'bağlı liste gibi' başa ekleme sanılıyor"""
    a = []
    for x in range(n):
        a.insert(0, x)             # her çağrı len(a) öğeyi kaydırır
    return a


def main():
    print("n kez list.insert(0, x) — öğe kaydırma (model) ve süre")
    print("       n   kaydırma n(n-1)/2   süre (ms)   oran")
    onceki = None
    for n in (10000, 20000, 40000):
        t0 = time.perf_counter()
        a = basa_ekle_hepsi(n)
        sure = (time.perf_counter() - t0) * 1e3
        oran = "" if onceki is None else f"{sure / onceki:6.2f}"
        print(f"  {n:6d} {n * (n - 1) // 2:19d} {sure:11.2f}  {oran}")
        onceki = sure
        assert a[0] == n - 1 and a[-1] == 0
    print("n iki katına çıkınca süre ≈ 4 katına çıkıyorsa: Θ(n²)")


if __name__ == "__main__":
    main()

/* H08_HA8_dongulu_yok_etme_duzeltilmis.c — AP-2 Hafta 8 · Hata Avcısı 8
 * Düzeltme: yok etmeden önce Floyd ile döngü aranır; varsa döngünün son
 *   düğümünün sonraki'si NULL yapılır (döngü kırılır), sonra olağan
 *   yinelemeli yok etme güvenlidir (Örnek 10).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA8_dongulu_yok_etme_duzeltilmis.c -o H08_HA8_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *dongulu_liste_kur(int n, int mu)
{
    Dugum *bas = NULL, *son = NULL, *hedef = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = malloc(sizeof *d);
        if (d == NULL) {
            exit(1);
        }
        d->veri = i;
        d->sonraki = NULL;
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
        if (i == mu) {
            hedef = d;
        }
    }
    son->sonraki = hedef;
    return bas;
}

/* Döngü varsa kırar; kırılan düğümün konumunu (yoksa -1) döndürür */
static int donguyu_kir(Dugum *bas)
{
    Dugum *kaplumbaga = bas, *tavsan = bas;
    while (tavsan != NULL && tavsan->sonraki != NULL) {
        kaplumbaga = kaplumbaga->sonraki;
        tavsan = tavsan->sonraki->sonraki;
        if (kaplumbaga == tavsan) {
            kaplumbaga = bas;                /* evre 2: başlangıcı bul */
            while (kaplumbaga != tavsan) {
                kaplumbaga = kaplumbaga->sonraki;
                tavsan = tavsan->sonraki;
            }
            Dugum *p = kaplumbaga;           /* döngünün son düğümü */
            while (p->sonraki != kaplumbaga) {
                p = p->sonraki;
            }
            p->sonraki = NULL;
            return p->veri;
        }
    }
    return -1;
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        printf("free(%d)\n", bas->veri);
        free(bas);
        bas = sonraki;
    }
}

int main(void)
{
    Dugum *bas = dongulu_liste_kur(5, 2);   /* 0 1 2 3 4 -> 2 */
    printf("liste: 0 -> 1 -> 2 -> 3 -> 4 -> (2'ye döner)\n");
    int k = donguyu_kir(bas);
    printf("döngü kırıldı: %d -> NULL\n", k);
    liste_yok_et(bas);
    printf("bitti\n");
    return 0;
}

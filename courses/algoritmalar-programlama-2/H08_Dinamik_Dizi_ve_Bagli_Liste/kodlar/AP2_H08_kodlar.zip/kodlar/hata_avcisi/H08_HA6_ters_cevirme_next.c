/* H08_HA6_ters_cevirme_next.c — AP-2 Hafta 8 · Hata Avcısı 6
 * BU DOSYA KASITLI HATA İÇERİR: ters çevirmede gecerli->sonraki, değeri
 *   SAKLANMADAN değiştirilir; listenin geri kalanına giden tek bağlantı
 *   kaybolur (sonuç yanlış, kalan düğümler sızar).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA6_ters_cevirme_next.c -o H08_HA6_ters_cevirme_next
 * Denetim : -g -fsanitize=address (LeakSanitizer); bkz. ciktilar/H08_HA6_*
 * Düzeltme: H08_HA6_ters_cevirme_next_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *liste_olustur(int n)       /* 1, 2, ..., n */
{
    Dugum *bas = NULL;
    for (int i = n; i >= 1; i--) {
        Dugum *d = malloc(sizeof *d);
        if (d == NULL) {
            exit(1);
        }
        d->veri = i;
        d->sonraki = bas;
        bas = d;
    }
    return bas;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        free(bas);
        bas = sonraki;
    }
}

/* HATA: 'sonraki' saklanmadan bağlantı ters çevriliyor */
static Dugum *ters_cevir(Dugum *bas)
{
    Dugum *onceki = NULL;
    Dugum *gecerli = bas;
    while (gecerli != NULL) {
        gecerli->sonraki = onceki;   /* 2 -> 3 -> ... bağlantısı silindi */
        onceki = gecerli;
        gecerli = gecerli->sonraki;  /* artık onceki'yi (NULL'ı) gösterir */
    }
    return onceki;
}

int main(void)
{
    Dugum *bas = liste_olustur(5);
    printf("başta   : ");
    liste_yaz(bas);
    bas = ters_cevir(bas);
    printf("ters    : ");
    liste_yaz(bas);
    printf("beklenen: [5 -> 4 -> 3 -> 2 -> 1 -> NULL]\n");
    liste_yok_et(bas);
    return 0;
}

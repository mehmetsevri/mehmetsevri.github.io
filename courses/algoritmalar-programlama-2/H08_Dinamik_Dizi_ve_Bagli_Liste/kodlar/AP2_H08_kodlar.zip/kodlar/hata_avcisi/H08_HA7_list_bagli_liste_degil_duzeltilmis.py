"""H08_HA7_list_bagli_liste_degil_duzeltilmis.py — AP-2 Hafta 8 · HA 7
Düzeltme: başa O(1) ekleme gerekiyorsa (1) collections.deque.appendleft
  (bloklardan oluşan iki uçlu yapı) ya da (2) elle bağlı liste (Örnek 3)
  ya da (3) sona ekleyip en sonda bir kez ters çevirmek (list.append +
  reverse: toplam Θ(n)). Süreler bu makinede, bu çalıştırmada ölçülendir.
Çalıştır: python3 H08_HA7_list_bagli_liste_degil_duzeltilmis.py
"""
import time
from collections import deque


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def deque_ile(n):
    d = deque()
    for x in range(n):
        d.appendleft(x)            # O(1)
    return d[0]


def bagli_liste_ile(n):
    bas = None
    for x in range(n):
        bas = Dugum(x, bas)        # O(1): yalnız bağlantı
    return bas.veri


def sona_ekle_ters_cevir(n):
    a = []
    for x in range(n):
        a.append(x)                # amortize O(1)
    a.reverse()                    # bir kez Θ(n)
    return a[0]


def main():
    print("n başa ekleme: üç doğru yol (süre, ms) ve n iki katına çıkınca "
          "oran")
    print("       n      deque   bağlı liste   append+reverse")
    onceki = None
    for n in (10000, 20000, 40000):
        sureler = []
        for gorev in (deque_ile, bagli_liste_ile, sona_ekle_ters_cevir):
            t0 = time.perf_counter()
            ilk = gorev(n)
            sureler.append((time.perf_counter() - t0) * 1e3)
            assert ilk == n - 1
        satir = f"  {n:6d} " + "".join(f"{s:10.2f}   " for s in sureler)
        if onceki is not None:
            satir += "oran: " + " ".join(f"{s / o:.2f}"
                                         for s, o in zip(sureler, onceki))
        print(satir)
        onceki = sureler
    print("oranlar ≈ 2: Θ(n) (her ekleme O(1))")


if __name__ == "__main__":
    main()

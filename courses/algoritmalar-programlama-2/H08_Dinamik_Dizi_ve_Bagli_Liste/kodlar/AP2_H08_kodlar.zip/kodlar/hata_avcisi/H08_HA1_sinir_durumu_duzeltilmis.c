/* H08_HA1_sinir_durumu_duzeltilmis.c — AP-2 Hafta 8 · Hata Avcısı 1
 * Düzeltme: son_dugumu_sil(Dugum **bas) — p, "son düğümü gösteren
 *   bağlantıyı" arar; boş listede hiçbir şey yapmaz, tek düğümde başı
 *   NULL yapar (özel durum kalmaz). Sınır durumları sınanır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA1_sinir_durumu_duzeltilmis.c -o H08_HA1_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *liste_olustur(int n)       /* 1, 2, ..., n */
{
    Dugum *bas = NULL;
    for (int i = n; i >= 1; i--) {
        Dugum *d = malloc(sizeof *d);
        if (d == NULL) {
            exit(1);
        }
        d->veri = i;
        d->sonraki = bas;
        bas = d;
    }
    return bas;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

/* Son düğümü siler; boş listede bir şey yapmaz. 1 silindiyse 1 döner. */
static int son_dugumu_sil(Dugum **bas)
{
    if (*bas == NULL) {
        return 0;                       /* boş liste */
    }
    Dugum **p = bas;
    while ((*p)->sonraki != NULL) {     /* *p: son düğüme kadar ilerle */
        p = &(*p)->sonraki;
    }
    free(*p);
    *p = NULL;                          /* tek düğümde bu bas'ın kendisi */
    return 1;
}

int main(void)
{
    Dugum *bas = liste_olustur(3);
    printf("başta    : ");
    liste_yaz(bas);
    for (int i = 0; i < 4; i++) {       /* 4. çağrı boş listede */
        int silindi = son_dugumu_sil(&bas);
        printf("%s: ", silindi ? "son silindi" : "boş, yok  ");
        liste_yaz(bas);
    }
    return 0;
}

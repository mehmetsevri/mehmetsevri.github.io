"""H08_HA1_sinir_durumu_duzeltilmis.py — AP-2 Hafta 8 · Hata Avcısı 1
Düzeltme: boş liste (None) ve tek düğüm ayrı ayrı ele alınır; yeni baş
  döndürülür (Python'da çağıranın değişkeni değiştirilemez).
Çalıştır: python3 H08_HA1_sinir_durumu_duzeltilmis.py
"""


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def liste_olustur(n):
    bas = None
    for i in range(n, 0, -1):
        bas = Dugum(i, bas)
    return bas


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]")


def son_dugumu_sil(bas):
    """Son düğümü siler; (yeni baş, silindi mi) döndürür"""
    if bas is None:
        return None, False              # boş liste
    if bas.sonraki is None:
        return None, True               # tek düğüm: baş değişir
    p = bas
    while p.sonraki.sonraki is not None:
        p = p.sonraki
    p.sonraki = None
    return bas, True


def main():
    bas = liste_olustur(3)
    print("başta    : ", end="")
    liste_yaz(bas)
    for _ in range(4):                  # 4. çağrı boş listede
        bas, silindi = son_dugumu_sil(bas)
        print("son silindi: " if silindi else "boş, yok  : ", end="")
        liste_yaz(bas)


if __name__ == "__main__":
    main()

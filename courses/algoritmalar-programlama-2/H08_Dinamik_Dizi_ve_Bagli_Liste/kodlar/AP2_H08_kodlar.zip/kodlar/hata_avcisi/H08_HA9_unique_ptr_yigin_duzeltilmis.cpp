/* H08_HA9_unique_ptr_yigin_duzeltilmis.cpp — AP-2 Hafta 8 · HA 9 (C++)
 * Düzeltme: Liste'ye döngüyle silen bir yıkıcı yazılır:
 *   bas = std::move(bas->sonraki) her adımda TEK düğümü siler (eski başın
 *   sonraki'si önceden alındığı için özyineleme olmaz).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA9_unique_ptr_yigin_duzeltilmis.cpp -o H08_HA9_duzeltilmis
 * Çalıştır: ./H08_HA9_duzeltilmis [n]           (varsayılan n = 1000000)
 */
#include <iostream>
#include <memory>
#include <string>
#include <utility>

struct Dugum {
    int veri;
    std::unique_ptr<Dugum> sonraki;   // sahiplik zinciri
};

struct Liste {
    std::unique_ptr<Dugum> bas;
    ~Liste()
    {
        while (bas != nullptr) {
            bas = std::move(bas->sonraki);   // tek düğüm silinir
        }
    }
};

int main(int argc, char* argv[])
{
    long n = argc > 1 ? std::stol(argv[1]) : 1000000;
    {
        Liste liste;
        for (long i = 0; i < n; i++) {
            auto d = std::make_unique<Dugum>();
            d->veri = static_cast<int>(i);
            d->sonraki = std::move(liste.bas);
            liste.bas = std::move(d);
        }
        std::cout << n << " düğüm kuruldu; kapsam kapanıyor (yıkıcı)..."
                  << std::endl;
    }
    std::cout << "liste yok edildi" << std::endl;
    return 0;
}

/* H08_HA3_free_sonrasi_duzeltilmis.c — AP-2 Hafta 8 · Hata Avcısı 3
 * Düzeltme: sonraki, free'den ÖNCE yerel değişkende saklanır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_HA3_free_sonrasi_duzeltilmis.c -o H08_HA3_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *dugum_olustur(int veri, Dugum *sonraki)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        exit(1);
    }
    d->veri = veri;
    d->sonraki = sonraki;
    return d;
}

static void liste_yok_et(Dugum *bas)
{
    int sayac = 0;
    Dugum *p = bas;
    while (p != NULL) {
        Dugum *sonraki = p->sonraki;   /* önce sakla */
        free(p);                       /* sonra bırak */
        p = sonraki;
        sayac++;
    }
    printf("liste_yok_et: %d düğüm bırakıldı\n", sayac);
}

int main(void)
{
    Dugum *bas = NULL;
    for (int i = 5; i >= 1; i--) {
        bas = dugum_olustur(i, bas);
    }
    printf("5 düğümlük liste kuruldu\n");
    liste_yok_et(bas);
    printf("program sona erdi\n");
    return 0;
}

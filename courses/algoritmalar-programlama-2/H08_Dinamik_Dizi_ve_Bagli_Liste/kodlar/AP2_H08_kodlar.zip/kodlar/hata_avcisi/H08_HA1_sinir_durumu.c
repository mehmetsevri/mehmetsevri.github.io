/* H08_HA1_sinir_durumu.c — AP-2 Hafta 8 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR: son_dugumu_sil en az iki düğüm varsayar;
 *   tek düğümlü (ve boş) liste sınır durumu atlanmıştır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_HA1_sinir_durumu.c \
 *           -o H08_HA1_sinir_durumu
 * Belirti : bkz. ciktilar/H08_HA1_sinir_durumu*.txt (bu derleyicide, bu
 *           çalıştırmada; NULL'ı izlemek tanımsız davranıştır)
 * Düzeltme: H08_HA1_sinir_durumu_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *liste_olustur(int n)       /* 1, 2, ..., n */
{
    Dugum *bas = NULL;
    for (int i = n; i >= 1; i--) {
        Dugum *d = malloc(sizeof *d);
        if (d == NULL) {
            exit(1);
        }
        d->veri = i;
        d->sonraki = bas;
        bas = d;
    }
    return bas;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

/* HATA: p->sonraki->sonraki, listede en az İKİ düğüm olduğunu varsayar;
 * tek düğümde p->sonraki NULL'dır ve NULL->sonraki okunur. Ayrıca tek
 * düğüm silinince baş işaretçisi NULL olmalıydı: bu imza bunu yapamaz. */
static void son_dugumu_sil(Dugum *bas)
{
    Dugum *p = bas;
    while (p->sonraki->sonraki != NULL) {
        p = p->sonraki;
    }
    free(p->sonraki);
    p->sonraki = NULL;
}

int main(void)
{
    Dugum *bas = liste_olustur(3);
    printf("başta    : ");
    liste_yaz(bas);
    for (int i = 0; i < 3; i++) {
        son_dugumu_sil(bas);
        printf("son silindi: ");
        liste_yaz(bas);
    }
    free(bas);
    return 0;
}

/* H08_A01_cikti_tahmini.c — AP-2 Hafta 8 · Alıştırma 8.1 (★)
 * Amaç    : Çalıştırmadan önce her satırın çıktısını kutu–ok çizerek
 *           tahmin edin; sonra çalıştırıp karşılaştırın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_A01_cikti_tahmini.c -o H08_A01_cikti_tahmini
 * Çalıştır: ./H08_A01_cikti_tahmini
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;
/* Sahiplik: dönen düğüm çağıranındır; free ile serbest bırakılır. */
static Dugum *dugum(int x, Dugum *sonraki)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        exit(1);
    }
    d->veri = x;
    d->sonraki = sonraki;
    return d;
}

static void yaz(const Dugum *p)
{
    printf("[");
    for (; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

int main(void)
{
    Dugum *bas = NULL;
    for (int i = 1; i <= 4; i++) {
        bas = dugum(i * 10, bas);
    }
    yaz(bas);                                  /* (1) */
    Dugum *p = bas->sonraki;
    p->sonraki = dugum(25, p->sonraki);
    yaz(bas);                                  /* (2) */
    Dugum *s = bas;
    bas = bas->sonraki;
    free(s);
    yaz(bas);                                  /* (3) */
    Dugum **q = &bas;
    while ((*q)->sonraki != NULL) {
        q = &(*q)->sonraki;
    }
    free(*q);
    *q = NULL;
    yaz(bas);                                  /* (4) */
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        free(bas);
        bas = sonraki;
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list;
 * Python — yok. */

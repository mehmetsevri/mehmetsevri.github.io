/* H08_A13_okuma.cpp — AP-2 Hafta 8 · Alıştırma 8.13 (★★)
 * Amaç    : Diller arası okuma (Python eşi: H08_A13_okuma.py). Program
 *           ne yazdırır? Bağımsız değişkenle n = 1000000 verilirse ne
 *           olabilir, neden? Python sürümünde aynı soru neden doğmaz?
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H08_A13_okuma.cpp \
 *           -o H08_A13_okuma
 * Çalıştır: ./H08_A13_okuma        (varsayılan n = 5)
 */
#include <cstdlib>
#include <iostream>
#include <memory>

struct Dugum {
    int veri;
    std::unique_ptr<Dugum> sonraki;
};

int main(int argc, char* argv[])
{
    long n = argc > 1 ? std::strtol(argv[1], nullptr, 10) : 5;
    std::unique_ptr<Dugum> bas;
    for (long i = n; i >= 1; i--) {
        auto d = std::make_unique<Dugum>();
        d->veri = static_cast<int>(i);
        d->sonraki = std::move(bas);
        bas = std::move(d);
    }
    long toplam = 0;
    for (const Dugum* p = bas.get(); p != nullptr; p = p->sonraki.get()) {
        toplam += p->veri;
    }
    std::cout << "n = " << n << ", toplam = " << toplam << "\n";
    std::cout << "bas boş mu? " << (bas ? "hayır" : "evet") << "\n";
    return 0;
}

/* Kütüphane karşılığı: C++ — std::forward_list<int> (yıkıcısı döngüyle
 * siler); Python — list. */

/* H08_A08_hata_bul_birlestir.c — AP-2 Hafta 8 · Alıştırma 8.8 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: birlestir bazı girdilerde düğüm
 * kaybediyor (sonuç kısa çıkıyor). Hangi girdilerde? Hatalı satırı bulun
 * ve Örnek 8'deki birleştirmeyle karşılaştırın. Düğümler yığındaki
 * dizilerdir (malloc yok); kaybolan düğüm sızıntı değil, kayıp veridir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_A08_hata_bul_birlestir.c -o H08_A08_hata_bul_birlestir
 * Çalıştır: ./H08_A08_hata_bul_birlestir
 */
#include <stdio.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *birlestir(Dugum *a, Dugum *b)
{
    Dugum kukla = {0, NULL};
    Dugum *son = &kukla;
    while (a != NULL && b != NULL) {
        if (a->veri <= b->veri) {
            son->sonraki = a;
            a = a->sonraki;
        } else {
            son->sonraki = b;
            b = b->sonraki;
        }
        son = son->sonraki;
    }
    son->sonraki = a;
    return kukla.sonraki;
}

/* d[0..n-1]'i v[] değerleriyle bağlar */
static Dugum *kur(Dugum *d, const int *v, int n)
{
    for (int i = 0; i < n; i++) {
        d[i].veri = v[i];
        d[i].sonraki = i + 1 < n ? &d[i + 1] : NULL;
    }
    return n > 0 ? &d[0] : NULL;
}

static void yaz(const Dugum *p)
{
    int n = 0;
    printf("[");
    for (; p != NULL; p = p->sonraki, n++) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]  (%d düğüm)\n", n);
}

int main(void)
{
    const int a1[] = {1, 4, 6}, b1[] = {2, 3, 9};
    const int a2[] = {5, 8}, b2[] = {1, 2, 3};
    const int a3[] = {1, 2}, b3[] = {7, 8, 9};
    Dugum da[3], db[3];
    yaz(birlestir(kur(da, a1, 3), kur(db, b1, 3)));
    yaz(birlestir(kur(da, a2, 2), kur(db, b2, 3)));
    yaz(birlestir(kur(da, a3, 2), kur(db, b3, 3)));
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list::merge;
 * Python — heapq.merge. */

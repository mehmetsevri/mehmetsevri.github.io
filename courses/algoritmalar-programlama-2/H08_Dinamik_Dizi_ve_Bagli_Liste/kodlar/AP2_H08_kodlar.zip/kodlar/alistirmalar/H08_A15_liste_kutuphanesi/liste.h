/* liste.h — AP-2 Hafta 8 · Atölye 2: liste kütüphanesinin ARAYÜZÜ
 * Siz liste.c'yi yazacaksınız (eşinizle: biri gerçekleştirir, öteki
 * liste_test.c'ye test ekler; sonra rolleri değiştirin). Derleme:
 *   gcc -std=c17 -Wall -Wextra -pedantic -O1 -g \
 *       -fsanitize=address,undefined liste_test.c liste.c -o liste_test
 * Sözleşmeler bu dosyadadır; liste.c bunlara uymak ZORUNDADIR.
 */
#ifndef LISTE_H
#define LISTE_H

#include <stdbool.h>
#include <stddef.h>

typedef struct Liste Liste;   /* opak: tek bağlı, bas + son + uzunluk */

/* Sahiplik: dönen liste çağıranındır; liste_yok_et ile bırakılır.
 * Bellek yetersizse NULL. */
Liste *liste_olustur(void);

/* Bütün düğümleri ve başlığı bırakır. NULL güvenlidir. */
void liste_yok_et(Liste *l);

size_t liste_uzunluk(const Liste *l);

/* O(1). 0: başarı, -1: bellek yetersiz (liste değişmez). */
int liste_basa_ekle(Liste *l, int x);
int liste_sona_ekle(Liste *l, int x);

/* O(1). Boşsa false; değilse baştaki değeri *x'e yazar ve düğümü bırakır. */
bool liste_bastan_cikar(Liste *l, int *x);

/* İlk x'i siler ve düğümü bırakır; yoksa false. Son düğüm silinirse
 * kuyruk işaretçisi güncellenir. */
bool liste_sil(Liste *l, int x);

bool liste_icerir(const Liste *l, int x);

/* Yerinde ters çevirir: yeni düğüm ayırmaz. */
void liste_ters_cevir(Liste *l);

/* Baştan en çok n öğeyi a'ya yazar; yazılan öğe sayısını döndürür. */
size_t liste_diziye(const Liste *l, int *a, size_t n);

#endif

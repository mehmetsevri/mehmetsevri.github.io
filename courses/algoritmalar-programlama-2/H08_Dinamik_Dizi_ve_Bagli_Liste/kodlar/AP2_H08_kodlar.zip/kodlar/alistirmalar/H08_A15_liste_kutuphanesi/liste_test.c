/* liste_test.c — AP-2 Hafta 8 · Atölye 2: liste.h için birim testleri
 * Her DENETLE bir koşuldur; başarısız olanlar satır numarasıyla yazılır.
 * Eşiniz yeni testleri "test_" ile başlayan fonksiyonlar olarak ekler ve
 * main'e kaydeder. Derleme: bkz. liste.h (liste.c sizin yazacağınız dosya)
 */
#include <stdio.h>

#include "liste.h"

static int gecen = 0, kalan = 0;

#define DENETLE(kosul)                                                  \
    do {                                                                \
        if (kosul) {                                                    \
            gecen++;                                                    \
        } else {                                                        \
            kalan++;                                                    \
            printf("  BAŞARISIZ satır %d: %s\n", __LINE__, #kosul);     \
        }                                                               \
    } while (0)

/* l'nin içeriği beklenen[0..n-1] ile aynı mı? */
static bool icerik(const Liste *l, const int *beklenen, size_t n)
{
    int a[16];
    if (liste_uzunluk(l) != n || n > 16) {
        return false;
    }
    size_t k = liste_diziye(l, a, 16);
    for (size_t i = 0; i < n; i++) {
        if (a[i] != beklenen[i]) {
            return false;
        }
    }
    return k == n;
}

static void test_bos(void)
{
    Liste *l = liste_olustur();
    int x = -1;
    DENETLE(l != NULL);
    DENETLE(liste_uzunluk(l) == 0);
    DENETLE(!liste_bastan_cikar(l, &x) && x == -1);
    DENETLE(!liste_sil(l, 5));
    DENETLE(!liste_icerir(l, 5));
    liste_ters_cevir(l);
    DENETLE(liste_uzunluk(l) == 0);
    liste_yok_et(l);
}

static void test_ekleme(void)
{
    Liste *l = liste_olustur();
    DENETLE(liste_sona_ekle(l, 2) == 0);
    DENETLE(liste_basa_ekle(l, 1) == 0);
    DENETLE(liste_sona_ekle(l, 3) == 0);
    const int b[] = {1, 2, 3};
    DENETLE(icerik(l, b, 3));
    liste_yok_et(l);
}

static void test_son_dugum_silme(void)
{
    Liste *l = liste_olustur();
    liste_sona_ekle(l, 10);
    liste_sona_ekle(l, 20);
    liste_sona_ekle(l, 30);
    DENETLE(liste_sil(l, 30));       /* son düğüm: kuyruk güncellenmeli */
    DENETLE(liste_sona_ekle(l, 40) == 0);
    const int b[] = {10, 20, 40};
    DENETLE(icerik(l, b, 3));
    DENETLE(liste_sil(l, 10));       /* baş düğüm */
    const int c[] = {20, 40};
    DENETLE(icerik(l, c, 2));
    liste_yok_et(l);
}

static void test_tek_dugum(void)
{
    Liste *l = liste_olustur();
    int x = 0;
    liste_basa_ekle(l, 7);
    DENETLE(liste_bastan_cikar(l, &x) && x == 7);
    DENETLE(liste_uzunluk(l) == 0);
    DENETLE(liste_sona_ekle(l, 8) == 0);   /* son NULL'a çekilmiş olmalı */
    const int b[] = {8};
    DENETLE(icerik(l, b, 1));
    liste_yok_et(l);
}

static void test_ters_cevir(void)
{
    Liste *l = liste_olustur();
    for (int i = 1; i <= 5; i++) {
        liste_sona_ekle(l, i);
    }
    liste_ters_cevir(l);
    const int b[] = {5, 4, 3, 2, 1};
    DENETLE(icerik(l, b, 5));
    DENETLE(liste_sona_ekle(l, 0) == 0);   /* son eski baş olmalı */
    const int c[] = {5, 4, 3, 2, 1, 0};
    DENETLE(icerik(l, c, 6));
    liste_yok_et(l);
}

static void test_yinelenen(void)
{
    Liste *l = liste_olustur();
    const int v[] = {5, 6, 5};
    for (int i = 0; i < 3; i++) {
        liste_sona_ekle(l, v[i]);
    }
    DENETLE(liste_sil(l, 5));              /* yalnızca İLK 5 */
    const int b[] = {6, 5};
    DENETLE(icerik(l, b, 2));
    DENETLE(liste_icerir(l, 5) && !liste_icerir(l, 7));
    liste_yok_et(l);
}

int main(void)
{
    test_bos();
    test_ekleme();
    test_son_dugum_silme();
    test_tek_dugum();
    test_ters_cevir();
    test_yinelenen();
    printf("liste testleri: %d geçti, %d başarısız\n", gecen, kalan);
    return kalan == 0 ? 0 : 1;
}

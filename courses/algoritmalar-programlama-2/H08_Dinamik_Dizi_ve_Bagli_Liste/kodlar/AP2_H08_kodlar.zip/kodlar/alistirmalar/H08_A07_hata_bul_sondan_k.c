/* H08_A07_hata_bul_sondan_k.c — AP-2 Hafta 8 · Alıştırma 8.7 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: sondan_k, sözleşmeye göre (k = 1 son
 * düğüm; k < 1 ya da k > n ise NULL) sonuç vermiyor. Çıktıyı Örnek 9'un
 * 2. bölümüyle karşılaştırın, hatalı satırı bulun ve düzeltin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_A07_hata_bul_sondan_k.c -o H08_A07_hata_bul_sondan_k
 * Çalıştır: ./H08_A07_hata_bul_sondan_k
 */
#include <stdio.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *sondan_k(Dugum *bas, int k)
{
    if (k < 1) {
        return NULL;
    }
    Dugum *ileri = bas;
    for (int i = 0; i <= k; i++) {
        if (ileri == NULL) {
            return NULL;
        }
        ileri = ileri->sonraki;
    }
    Dugum *geri = bas;
    while (ileri != NULL) {
        ileri = ileri->sonraki;
        geri = geri->sonraki;
    }
    return geri;
}

int main(void)
{
    Dugum d[5];
    for (int i = 0; i < 5; i++) {
        d[i].veri = 10 * (i + 1);
        d[i].sonraki = i < 4 ? &d[i + 1] : NULL;
    }
    printf("liste: [10 -> 20 -> 30 -> 40 -> 50 -> NULL]\n");
    for (int k = 0; k <= 6; k++) {
        Dugum *p = sondan_k(&d[0], k);
        if (p != NULL) {
            printf("  k = %d: %d\n", k, p->veri);
        } else {
            printf("  k = %d: NULL\n", k);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::prev(l.end(), k)
 * (std::list, çift bağlı); Python — a[-k] (dizide). */

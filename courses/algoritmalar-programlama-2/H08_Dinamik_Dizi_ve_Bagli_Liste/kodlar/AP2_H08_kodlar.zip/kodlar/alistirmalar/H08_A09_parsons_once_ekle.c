/* H08_A09_parsons_once_ekle.c — AP-2 Hafta 8 · Alıştırma 8.9 (★★) — Parsons
 * Tamamlanacak; bu hâliyle derlenmez: aşağıdaki satırlar kukla düğümlü
 * dairesel çift bağlı listede yeni düğümü konum'un ÖNÜNE ekleyen
 * fonksiyonun KARIŞTIRILMIŞ satırlarıdır (iki satır fazladır). Doğru sırayı
 * ve girintiyi bulun; dört bağlantı ataması hangi sırada YAPILMAMALIDIR?
 */
    konum->onceki = d;
    d->veri = x;
    return d;
CDugum *once_ekle(CDugum *konum, int x)
    konum->onceki->sonraki = d;
    konum->sonraki = d;
}
    d->sonraki = konum;
    CDugum *d = malloc(sizeof *d);
    d->sonraki = konum->sonraki;
{
    d->onceki = konum->onceki;
    if (d == NULL) {
        return NULL;
    }

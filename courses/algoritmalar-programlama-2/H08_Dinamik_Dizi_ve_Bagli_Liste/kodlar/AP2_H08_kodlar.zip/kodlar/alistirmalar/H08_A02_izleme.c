/* H08_A02_izleme.c — AP-2 Hafta 8 · Alıştırma 8.2 (★★)
 * Amaç    : İzleme: f'nin [1 2 3 4 5 6] ve [1 2 3 4 5] listelerinde her
 *           turdaki sira, p, son_a, son_b değerlerini tablo olarak yazın;
 *           fonksiyonun ne yaptığını bir cümleyle söyleyin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_A02_izleme.c \
 *           -o H08_A02_izleme
 * Çalıştır: ./H08_A02_izleme
 */
#include <stdio.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static Dugum *f(Dugum *bas)
{
    Dugum kukla_a = {0, NULL}, kukla_b = {0, NULL};
    Dugum *son_a = &kukla_a, *son_b = &kukla_b;
    int sira = 0;
    for (Dugum *p = bas; p != NULL; p = p->sonraki, sira++) {
        if (sira % 2 == 0) {
            son_a->sonraki = p;
            son_a = p;
        } else {
            son_b->sonraki = p;
            son_b = p;
        }
    }
    son_b->sonraki = NULL;
    son_a->sonraki = kukla_b.sonraki;
    return kukla_a.sonraki;
}

static void dene(int n)
{
    Dugum d[8];
    for (int i = 0; i < n; i++) {
        d[i].veri = i + 1;
        d[i].sonraki = i + 1 < n ? &d[i + 1] : NULL;
    }
    printf("n = %d: [", n);
    for (Dugum *p = f(&d[0]); p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

int main(void)
{
    dene(6);
    dene(5);
    dene(1);
    return 0;
}

/* Kütüphane karşılığı: alıştırma tartışıldıktan sonra derste verilir. */

/* H08_A14_sizinti_avi.c — AP-2 Hafta 8 · Atölye 3: Sızıntı avı
 * BU DOSYA KASITLI HATA İÇERİR: program doğru görünen çıktılar verir, ama
 * belleği eksik bırakır. ASan (LeakSanitizer) ile derleyip raporu okuyun;
 * her rapor bloğunun yığın izinden ayrıldığı satırı bulun, düzeltin ve
 * rapor temizlenene kadar yineleyin; sonra Valgrind ile doğrulayın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O1 -g \
 *           -fsanitize=address,undefined -fno-omit-frame-pointer \
 *           H08_A14_sizinti_avi.c -o sizinti
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

/* Sahiplik: dönen düğüm çağıranındır */
static Dugum *dugum(int x, Dugum *sonraki)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = x;
    d->sonraki = sonraki;
    return d;
}

/* Sahiplik: dönen liste çağıranındır; liste_yok_et ile bırakılır */
static Dugum *liste_kur(int n)
{
    Dugum *bas = NULL;
    for (int i = n; i >= 1; i--) {
        bas = dugum(i, bas);
    }
    return bas;
}

static void liste_yok_et(Dugum *bas)
{
    Dugum *p = bas;
    while (p != NULL && p->sonraki != NULL) {
        Dugum *sonraki = p->sonraki;
        free(p);
        p = sonraki;
    }
}

/* İlk x'i listeden çıkarır; çıkardıysa 1 döner */
static int sil(Dugum **bas, int x)
{
    for (Dugum **p = bas; *p != NULL; p = &(*p)->sonraki) {
        if ((*p)->veri == x) {
            *p = (*p)->sonraki;
            return 1;
        }
    }
    return 0;
}

/* İlk k düğümün kopyası; liste k'dan kısaysa NULL.
 * Sahiplik: dönen kopya çağıranındır. */
static Dugum *ilk_k_kopya(const Dugum *bas, int k)
{
    Dugum *kopya = NULL, **son = &kopya;
    for (int i = 0; i < k; i++) {
        if (bas == NULL) {
            return NULL;
        }
        *son = dugum(bas->veri, NULL);
        son = &(*son)->sonraki;
        bas = bas->sonraki;
    }
    return kopya;
}

static int toplam(const Dugum *p)
{
    int t = 0;
    for (; p != NULL; p = p->sonraki) {
        t += p->veri;
    }
    return t;
}

int main(void)
{
    Dugum *bas = liste_kur(6);
    printf("kuruldu, toplam = %d\n", toplam(bas));
    sil(&bas, 3);
    sil(&bas, 6);
    printf("3 ve 6 silindi, toplam = %d\n", toplam(bas));
    Dugum *k = ilk_k_kopya(bas, 2);
    printf("ilk 2'nin kopyası, toplam = %d\n", toplam(k));
    Dugum *u = ilk_k_kopya(bas, 10);
    printf("ilk 10'un kopyası %s\n", u == NULL ? "yok (liste kısa)" : "var");
    liste_yok_et(bas);
    return 0;
}

"""H08_A13_okuma.py — AP-2 Hafta 8 · Alıştırma 8.13 (★★)
Amaç    : Diller arası okuma (C++ eşi: H08_A13_okuma.cpp). Program ne
          yazdırır? n = 1000000 verilince belleği kim, ne zaman geri alır?
Çalıştır: python3 H08_A13_okuma.py        (varsayılan n = 5)
"""
import sys


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    bas = None
    for i in range(n, 0, -1):
        bas = Dugum(i, bas)
    toplam = 0
    p = bas
    while p is not None:
        toplam += p.veri
        p = p.sonraki
    print(f"n = {n}, toplam = {toplam}")
    print("bas boş mu?", "hayır" if bas is not None else "evet")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C++ — std::forward_list; Python — list.

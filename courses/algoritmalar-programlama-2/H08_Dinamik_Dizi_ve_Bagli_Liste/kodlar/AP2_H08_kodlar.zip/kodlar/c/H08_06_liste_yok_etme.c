/* H08_06_liste_yok_etme.c — AP-2 Hafta 8 · Örnek 6 (★★)
 * Amaç    : Listenin yok edilmesi ve bellek sahipliği: yinelemeli yok etme
 *           (sonraki free'den ÖNCE saklanır), derin kopya, sayaçlar
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_06_liste_yok_etme.c -o H08_06_liste_yok_etme
 * Çalıştır: ./H08_06_liste_yok_etme [n]      (n: bölüm 4, varsayılan 1e5)
 * Denetim : -fsanitize=address,undefined ve valgrind --leak-check=full
 * Eşleri  : cpp/H08_06_liste_yok_etme.cpp · python/H08_06_liste_yok_etme.py
 * Çıktı   : Δ — 1–4 üç dilde aynı; 5. bölüm dile özgü (bkz. Dil Penceresi)
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static int en_derin = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = veri;
    d->sonraki = NULL;
    ayirma_sayisi++;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

/* Sahiplik: dönen liste çağıranındır; liste_yok_et ile serbest bırakılır */
static Dugum *liste_olustur(const int *a, int n)
{
    Dugum *bas = NULL, *son = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = dugum_olustur(a[i]);
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

/* Yinelemeli yok etme: O(1) ek bellek. sonraki, free'den ÖNCE saklanır
 * (free'den sonra d->sonraki okunamaz). Sonunda çağıranın başı NULL olur:
 * sarkan baş işaretçisi kalmaz. */
static void liste_yok_et(Dugum **bas)
{
    Dugum *d = *bas;
    while (d != NULL) {
        Dugum *sonraki = d->sonraki;
        dugum_birak(d);
        d = sonraki;
    }
    *bas = NULL;
}

/* Aynı adımlar, her adım yazdırılarak */
static void liste_yok_et_izle(Dugum **bas)
{
    Dugum *d = *bas;
    while (d != NULL) {
        Dugum *sonraki = d->sonraki;
        if (sonraki != NULL) {
            printf("  bırak %d (sonraki = %d önceden saklandı)\n", d->veri,
                   sonraki->veri);
        } else {
            printf("  bırak %d (sonraki = NULL)\n", d->veri);
        }
        dugum_birak(d);
        d = sonraki;
    }
    *bas = NULL;
}

/* Özyinelemeli yok etme: önce kuyruk, sonra düğüm. Derinlik n + 1 olur;
 * büyük n'de yığın taşabilir (yalnız küçük listede kullanılır). */
static void liste_yok_et_ozyinelemeli(Dugum *bas, int derinlik)
{
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (bas == NULL) {
        return;
    }
    liste_yok_et_ozyinelemeli(bas->sonraki, derinlik + 1);
    dugum_birak(bas);
}

/* Derin kopya. Sahiplik: dönen kopya çağıranındır; kaynak değişmez. */
static Dugum *liste_kopyala(const Dugum *kaynak)
{
    Dugum *bas = NULL, *son = NULL;
    for (const Dugum *p = kaynak; p != NULL; p = p->sonraki) {
        Dugum *d = dugum_olustur(p->veri);
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]");
}

static void sayac_yaz(void)
{
    printf("  ayrılan = %lld, bırakılan = %lld, canlı = %lld\n",
           ayirma_sayisi, birakma_sayisi, ayirma_sayisi - birakma_sayisi);
}

int main(int argc, char *argv[])
{
    long n_buyuk = 100000;
    if (argc > 1) {
        char *son;
        n_buyuk = strtol(argv[1], &son, 10);
        if (*son != '\0' || n_buyuk < 1) {
            fprintf(stderr, "kullanım: %s [n >= 1]\n", argv[0]);
            return 2;
        }
    }
    const int a[5] = {3, 1, 4, 1, 5};

    printf("1) Liste kurma: sahiplik çağıranda\n  bas = ");
    Dugum *bas = liste_olustur(a, 5);
    liste_yaz(bas);
    printf("\n");
    sayac_yaz();

    printf("\n2) Yinelemeli yok etme: sonraki free'den ÖNCE saklanır\n");
    liste_yok_et_izle(&bas);
    printf("  bas %s NULL\n", bas == NULL ? "==" : "!=");
    sayac_yaz();

    printf("\n3) Derin kopya: iki ayrı sahip, iki ayrı yok etme\n");
    Dugum *asil = liste_olustur(a, 5);
    Dugum *kopya = liste_kopyala(asil);
    kopya->veri = 99;   /* kopyayı değiştirmek asılı etkilemez */
    printf("  asıl  = ");
    liste_yaz(asil);
    printf("\n  kopya = ");
    liste_yaz(kopya);
    printf("\n");
    sayac_yaz();
    liste_yok_et(&asil);
    liste_yok_et(&kopya);
    printf("  ikisi de yok edildi:\n");
    sayac_yaz();

    printf("\n4) Büyük liste ve özyinelemeli yok etme\n");
    long long b0 = birakma_sayisi;
    Dugum *buyuk = NULL;
    for (long i = 0; i < n_buyuk; i++) {
        Dugum *d = dugum_olustur((int)(i % 1000));
        d->sonraki = buyuk;
        buyuk = d;
    }
    liste_yok_et(&buyuk);
    printf("  n = %ld: yinelemeli yok etme %lld düğüm bıraktı, ek bellek "
           "O(1)\n", n_buyuk, birakma_sayisi - b0);
    Dugum *kucuk = liste_olustur(a, 5);
    en_derin = 0;
    liste_yok_et_ozyinelemeli(kucuk, 1);
    printf("  özyinelemeli (n = 5): en büyük derinlik = %d (n + 1); "
           "n = %ld için %ld\n", en_derin, n_buyuk, n_buyuk + 1);
    printf("  1-4. bölümlerin toplamı:\n");
    sayac_yaz();

    printf("\n5) C: serbest bırakılmış düğümü gösteren işaretçi SARKANDIR\n");
    bas = liste_olustur(a, 5);
    Dugum *orta = bas->sonraki->sonraki;
    printf("  orta = bas->sonraki->sonraki; orta->veri = %d\n", orta->veri);
    liste_yok_et(&bas);
    printf("  liste_yok_et(&bas): bas = NULL yapıldı; orta ise eski adresi "
           "tutuyor\n");
    printf("  orta->veri okunursa tanımsız davranış (ASan: "
           "heap-use-after-free;\n  bkz. Hata Avcısı 3). Çözüm: sahibi "
           "yok edince tüm takma adları\n  geçersiz say (orta = NULL).\n");
    orta = NULL;
    sayac_yaz();
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list / std::forward_list
 * yıkıcısı (RAII), std::unique_ptr; Python — başvuru sayımı + döngüsel çöp
 * toplayıcı (gc). */

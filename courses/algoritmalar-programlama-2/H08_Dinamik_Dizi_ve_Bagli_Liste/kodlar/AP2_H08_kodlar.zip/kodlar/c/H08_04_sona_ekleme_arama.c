/* H08_04_sona_ekleme_arama.c — AP-2 Hafta 8 · Örnek 4 (★)
 * Amaç    : Kuyruk (son) işaretçisiyle O(1) sona ekleme, kuyruksuz Θ(n)
 *           sona ekleme ile ziyaret karşılaştırması; doğrusal arama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_04_sona_ekleme_arama.c ortak_rastgele.c \
 *           -o H08_04_sona_ekleme_arama
 * Çalıştır: ./H08_04_sona_ekleme_arama
 * Eşleri  : cpp/H08_04_sona_ekleme_arama.cpp ·
 *           python/H08_04_sona_ekleme_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

/* Liste başlığı: baş ve kuyruk (son düğüm) işaretçileri */
typedef struct {
    Dugum *bas;
    Dugum *son;
} Liste;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ziyaret_sayisi = 0, baglanti_sayisi = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = veri;
    d->sonraki = NULL;
    ayirma_sayisi++;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]");
}

/* Kuyruk işaretçisiyle sona ekleme: yürümeden O(1) */
static void sona_ekle(Liste *liste, int x)
{
    Dugum *d = dugum_olustur(x);
    if (liste->son == NULL) {   /* boş liste */
        liste->bas = d;
    } else {
        liste->son->sonraki = d;
        baglanti_sayisi++;
    }
    liste->son = d;
}

/* Kuyruk işaretçisi olmadan sona ekleme: son düğüme kadar yürür, Θ(n).
 * Yeni başı döndürür (boş listede baş değişir). */
static Dugum *sona_ekle_kuyruksuz(Dugum *bas, int x)
{
    Dugum *d = dugum_olustur(x);
    if (bas == NULL) {
        return d;
    }
    Dugum *p = bas;
    ziyaret_sayisi++;
    while (p->sonraki != NULL) {
        p = p->sonraki;
        ziyaret_sayisi++;
    }
    p->sonraki = d;
    baglanti_sayisi++;
    return bas;
}

/* İlk x'i arar; düğümü ya da NULL döndürür, *konum 0 tabanlı (yoksa -1) */
static Dugum *ara(Dugum *bas, int x, int *konum)
{
    int i = 0;
    for (Dugum *p = bas; p != NULL; p = p->sonraki) {
        ziyaret_sayisi++;
        if (p->veri == x) {
            *konum = i;
            return p;
        }
        i++;
    }
    *konum = -1;
    return NULL;
}

static void ara_yaz(Dugum *bas, int x, const char *on_ek)
{
    int konum;
    ziyaret_sayisi = 0;
    Dugum *d = ara(bas, x, &konum);
    if (d != NULL) {
        printf("  %sara(%d): bulundu, konum %d, ziyaret = %lld\n", on_ek, x,
               konum, ziyaret_sayisi);
    } else {
        printf("  %sara(%d): bulunamadı (NULL), ziyaret = %lld\n", on_ek, x,
               ziyaret_sayisi);
    }
}

int main(void)
{
    printf("1) Kuyruk işaretçisiyle sona ekleme: 3, 1, 4, 1, 5\n");
    Liste liste = {NULL, NULL};
    const int sira[5] = {3, 1, 4, 1, 5};
    for (int i = 0; i < 5; i++) {
        sona_ekle(&liste, sira[i]);
        printf("  sona_ekle(%d): ", sira[i]);
        liste_yaz(liste.bas);
        printf("  bas = %d, son = %d\n", liste.bas->veri, liste.son->veri);
    }

    printf("\n2) Doğrusal arama (ilk eşleşme)\n");
    ara_yaz(liste.bas, 4, "");
    ara_yaz(liste.bas, 1, "");
    ara_yaz(liste.bas, 5, "");
    ara_yaz(liste.bas, 9, "");
    ara_yaz(NULL, 3, "boş listede ");
    liste_yok_et(liste.bas);

    printf("\n3) n sona ekleme: kuyruklu ve kuyruksuz ziyaret sayısı\n");
    printf("       n  kuyruklu  kuyruksuz   n(n-1)/2\n");
    const int nler[3] = {10, 100, 1000};
    for (int j = 0; j < 3; j++) {
        int n = nler[j];
        Liste k = {NULL, NULL};
        ziyaret_sayisi = 0;
        for (int i = 0; i < n; i++) {
            sona_ekle(&k, i);
        }
        long long kuyruklu = ziyaret_sayisi;
        Dugum *bas = NULL;
        ziyaret_sayisi = 0;
        for (int i = 0; i < n; i++) {
            bas = sona_ekle_kuyruksuz(bas, i);
        }
        printf("  %6d %9lld %10lld %10lld\n", n, kuyruklu, ziyaret_sayisi,
               (long long)n * (n - 1) / 2);
        liste_yok_et(k.bas);
        liste_yok_et(bas);
    }

    printf("\n4) Arama maliyeti: 0..999 karıştırılmış (tohum 42), "
           "her değer bir kez aranır\n");
    int a[1000];
    for (int i = 0; i < 1000; i++) {
        a[i] = i;
    }
    rastgele_tohum(42);
    rastgele_karistir(a, 1000);
    Liste m = {NULL, NULL};
    for (int i = 0; i < 1000; i++) {
        sona_ekle(&m, a[i]);
    }
    int konum;
    ziyaret_sayisi = 0;
    for (int x = 0; x < 1000; x++) {
        ara(m.bas, x, &konum);
    }
    printf("  başarılı arama: ortalama ziyaret = %.2f, (n + 1) / 2 = %.2f\n",
           ziyaret_sayisi / 1000.0, 1001 / 2.0);
    ziyaret_sayisi = 0;
    ara(m.bas, -1, &konum);
    printf("  başarısız arama: ziyaret = %lld (= n)\n", ziyaret_sayisi);
    liste_yok_et(m.bas);

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list::push_back,
 * std::find; Python — yerleşik bağlı liste yok (collections.deque.append,
 * x in d). */

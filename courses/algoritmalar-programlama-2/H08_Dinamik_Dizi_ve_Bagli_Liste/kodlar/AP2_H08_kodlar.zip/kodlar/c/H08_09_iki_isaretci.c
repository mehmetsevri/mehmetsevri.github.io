/* H08_09_iki_isaretci.c — AP-2 Hafta 8 · Örnek 9 (★★)
 * Amaç    : İki işaretçi tekniği: ortadaki düğüm (yavaş–hızlı) ve sondan
 *           k'ıncı düğüm (k adım önden giden işaretçi); sözleşmeler
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_09_iki_isaretci.c \
 *           ortak_rastgele.c -o H08_09_iki_isaretci
 * Çalıştır: ./H08_09_iki_isaretci
 * Eşleri  : cpp/H08_09_iki_isaretci.cpp · python/H08_09_iki_isaretci.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ilerletme_sayisi = 0;  /* p = p->sonraki adımları */

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = veri;
    d->sonraki = NULL;
    ayirma_sayisi++;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

/* 10, 20, ..., 10n değerli n düğümlük liste */
static Dugum *onlar_listesi(int n)
{
    Dugum *bas = NULL;
    for (int i = n; i >= 1; i--) {
        Dugum *d = dugum_olustur(10 * i);
        d->sonraki = bas;
        bas = d;
    }
    return bas;
}

/* Yavaş–hızlı: hızlı iki, yavaş bir adım atar. Sözleşme: n düğümde 0
 * tabanlı ⌊n/2⌋ indisli düğüm (çift n'de İKİ ortadan İKİNCİSİ); boşsa
 * NULL. Hızlı sona varınca yavaş ortadadır: tek geçiş. */
static Dugum *ortadaki(Dugum *bas)
{
    Dugum *yavas = bas, *hizli = bas;
    while (hizli != NULL && hizli->sonraki != NULL) {
        yavas = yavas->sonraki;
        hizli = hizli->sonraki->sonraki;
        ilerletme_sayisi += 3;
    }
    return yavas;
}

/* Hızlı bir adım önden başlar: ⌊(n-1)/2⌋ indisli düğüm (çift n'de
 * BİRİNCİ orta; birleştirmeli sıralamada ilk yarının sonu, Örnek 12) */
static Dugum *ilk_orta(Dugum *bas)
{
    if (bas == NULL) {
        return NULL;
    }
    Dugum *yavas = bas, *hizli = bas->sonraki;
    ilerletme_sayisi++;
    while (hizli != NULL && hizli->sonraki != NULL) {
        yavas = yavas->sonraki;
        hizli = hizli->sonraki->sonraki;
        ilerletme_sayisi += 3;
    }
    return yavas;
}

/* Sondan k'ıncı (k = 1: son düğüm). Sözleşme: k < 1 ya da k > n ise
 * NULL. ileri, k adım önden gider; ileri NULL olunca geri hedeftedir. */
static Dugum *sondan_k(Dugum *bas, int k)
{
    if (k < 1) {
        return NULL;
    }
    Dugum *ileri = bas;
    for (int i = 0; i < k; i++) {
        if (ileri == NULL) {
            return NULL;                 /* liste k'dan kısa */
        }
        ileri = ileri->sonraki;
        ilerletme_sayisi++;
    }
    Dugum *geri = bas;
    while (ileri != NULL) {
        ileri = ileri->sonraki;
        geri = geri->sonraki;
        ilerletme_sayisi += 2;
    }
    return geri;
}

/* Karşılaştırma için iki geçişli sürümler: önce uzunluk, sonra yürüme */
static int uzunluk(const Dugum *bas)
{
    int n = 0;
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        n++;
        ilerletme_sayisi++;
    }
    return n;
}

static Dugum *indisteki(Dugum *bas, int i)
{
    Dugum *p = bas;
    for (int j = 0; j < i; j++) {
        p = p->sonraki;
        ilerletme_sayisi++;
    }
    return p;
}

static void hucre(char *tampon, size_t boy, const Dugum *d, int indis)
{
    if (d == NULL) {
        snprintf(tampon, boy, "NULL");
    } else {
        snprintf(tampon, boy, "%d (%d)", d->veri, indis);
    }
}

/* d'nin bas'tan indisi (yoksa -1) */
static int indis_bul(const Dugum *bas, const Dugum *d)
{
    int i = 0;
    for (const Dugum *p = bas; p != NULL; p = p->sonraki, i++) {
        if (p == d) {
            return i;
        }
    }
    return -1;
}

int main(void)
{
    char h1[32], h2[32];
    printf("1) Ortadaki düğüm; liste 10, 20, ..., 10n\n");
    printf("  sözleşme: ortadaki -> indis n/2 (çiftte ikinci orta), "
           "ilk_orta -> (n-1)/2\n");
    printf("     n  ortadaki (indis)  ilk_orta (indis)  döngü turu\n");
    for (int n = 0; n <= 7; n++) {
        Dugum *bas = onlar_listesi(n);
        ilerletme_sayisi = 0;
        Dugum *o = ortadaki(bas);
        long long tur = ilerletme_sayisi / 3;
        Dugum *ilk = ilk_orta(bas);
        hucre(h1, sizeof h1, o, indis_bul(bas, o));
        hucre(h2, sizeof h2, ilk, indis_bul(bas, ilk));
        printf("  %4d  %16s  %16s  %10lld\n", n, h1, h2, tur);
        liste_yok_et(bas);
    }

    printf("\n2) Sondan k'ıncı; liste [10 -> 20 -> 30 -> 40 -> 50 -> NULL]\n");
    printf("  sözleşme: k = 1 son düğüm; k < 1 ya da k > n ise NULL\n");
    Dugum *bas = onlar_listesi(5);
    for (int k = 0; k <= 6; k++) {
        ilerletme_sayisi = 0;
        Dugum *d = sondan_k(bas, k);
        hucre(h1, sizeof h1, d, indis_bul(bas, d));
        printf("  k = %d: %-8s  ilerletme = %lld\n", k, h1, ilerletme_sayisi);
    }
    liste_yok_et(bas);

    printf("\n3) Kâhinle sınama: 500 rastgele liste (n = 0..40, tohum 42), "
           "her k = 0..n+1\n");
    rastgele_tohum(42);
    int uyusmaz = 0, sinama = 0;
    for (int t = 0; t < 500; t++) {
        int n = rastgele_aralik(0, 40);
        bas = onlar_listesi(n);
        Dugum *o = ortadaki(bas);
        sinama++;
        if ((n == 0 && o != NULL) ||
            (n > 0 && indis_bul(bas, o) != n / 2)) {
            uyusmaz++;
        }
        for (int k = 0; k <= n + 1; k++) {
            Dugum *d = sondan_k(bas, k);
            int beklenen = (k >= 1 && k <= n) ? n - k : -1;   /* kâhin */
            sinama++;
            if ((beklenen < 0 && d != NULL) ||
                (beklenen >= 0 && indis_bul(bas, d) != beklenen)) {
                uyusmaz++;
            }
        }
        liste_yok_et(bas);
    }
    printf("  sınama = %d, uyuşmazlık = %d\n", sinama, uyusmaz);

    printf("\n4) İlerletme sayısı, n = 100000: tek geçiş ve iki geçiş\n");
    bas = onlar_listesi(100000);
    ilerletme_sayisi = 0;
    Dugum *o1 = ortadaki(bas);
    long long tek = ilerletme_sayisi;
    ilerletme_sayisi = 0;
    Dugum *o2 = indisteki(bas, uzunluk(bas) / 2);
    printf("  ortadaki : yavaş–hızlı = %lld, iki geçiş = %lld; aynı düğüm? "
           "%s\n", tek, ilerletme_sayisi, o1 == o2 ? "evet" : "HAYIR");
    ilerletme_sayisi = 0;
    Dugum *s1 = sondan_k(bas, 10);
    tek = ilerletme_sayisi;
    ilerletme_sayisi = 0;
    Dugum *s2 = indisteki(bas, uzunluk(bas) - 10);
    printf("  sondan 10: iki işaretçi = %lld, iki geçiş = %lld; aynı düğüm? "
           "%s\n", tek, ilerletme_sayisi, s1 == s2 ? "evet" : "HAYIR");
    printf("  (ilerletme: bir işaretçiyi bir düğüm ileri taşımak) İş aynıdır;"
           "\n  kazanç: uzunluğu ayrıca hesaplamadan tek döngüde sonuç\n");
    liste_yok_et(bas);

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::next(it, n / 2),
 * std::prev(l.end(), k) (std::list, çift yönlü yineleyici); Python —
 * yerleşik bağlı liste yok (dizide a[len(a) // 2], a[-k]). */

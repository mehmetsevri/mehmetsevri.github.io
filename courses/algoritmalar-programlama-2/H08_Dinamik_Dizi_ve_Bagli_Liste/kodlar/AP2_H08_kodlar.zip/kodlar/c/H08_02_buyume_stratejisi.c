/* H08_02_buyume_stratejisi.c — AP-2 Hafta 8 · Örnek 2 (★★)
 * Amaç    : Büyüme stratejisine göre toplam kopya sayısı (+1, +10, × 1,5,
 *           × 2): amortize analizde toplam yöntemi ve kapalı biçimler
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_02_buyume_stratejisi.c -o H08_02_buyume_stratejisi
 * Çalıştır: ./H08_02_buyume_stratejisi
 * Eşleri  : cpp/H08_02_buyume_stratejisi.cpp ·
 *           python/H08_02_buyume_stratejisi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#define STRATEJI_SAYISI 4
/* Adlar 8 karakterlik doldurulmuş dizgiler: printf genişliği bayt sayar,
 * "×" UTF-8'de 2 bayttır; hizalama üç dilde aynı kalsın */
static const char *const AD[STRATEJI_SAYISI] = {"+1      ", "+10     ",
                                                "× 1,5   ", "× 2     "};

/* Kapasite k doluyken yeni kapasite. × 1,5'te tamsayı yuvarlaması üç
 * dilde aynı tanımlıdır: k + (k + 1) / 2, yani ⌈1,5 k⌉ (k = 1 → 2). */
static long long yeni_kapasite(int strateji, long long k)
{
    switch (strateji) {
    case 0:
        return k + 1;
    case 1:
        return k + 10;
    case 2:
        return k + (k + 1) / 2;
    default:
        return 2 * k;
    }
}

typedef struct {
    long long kopya;      /* büyütmelerde kopyalanan öğe toplamı */
    long long buyutme;    /* kapasite değişimi sayısı */
    long long kapasite;   /* n eklemeden sonraki kapasite */
} Sonuc;

/* n sona eklemenin benzetimi (ilk kapasite 1): dolu dizide büyütme,
 * boyut kadar öğeyi yeni bloğa kopyalar. Toplam yöntemi: Σ kopya. */
static Sonuc benzet(int strateji, long long n)
{
    Sonuc s = {0, 0, 1};
    for (long long boyut = 0; boyut < n; boyut++) {  /* ekleme öncesi */
        if (boyut == s.kapasite) {
            s.kopya += boyut;
            s.kapasite = yeni_kapasite(strateji, s.kapasite);
            s.buyutme++;
        }
    }
    return s;
}

/* +k için kapalı biçim: kapasiteler 1, 1 + k, 1 + 2k, ...; n - 1'i
 * aşmayan m tanesinde büyütülür: Σ (1 + jk) = m + k m (m - 1) / 2 */
static long long arti_k_kapali(long long n, long long k)
{
    if (n < 2) {
        return 0;
    }
    long long m = (n - 2) / k + 1;
    return m + k * m * (m - 1) / 2;
}

/* × 2 için kapalı biçim: 1 + 2 + 4 + ... + 2^(m-1) = 2^m - 1;
 * m = ⌊log2(n - 1)⌋ + 1 (n - 1'i aşmayan ikinin kuvvetleri) */
static long long kat_2_kapali(long long n)
{
    if (n < 2) {
        return 0;
    }
    long long kuvvet = 1;
    while (kuvvet <= n - 1) {
        kuvvet *= 2;
    }
    return kuvvet - 1;
}

static void zaman_cizelgesi(int strateji, long long n)
{
    long long kapasiteler[64];
    int m = 0;
    long long kapasite = 1;
    kapasiteler[m++] = kapasite;
    for (long long boyut = 0; boyut < n; boyut++) {
        if (boyut == kapasite) {
            kapasite = yeni_kapasite(strateji, kapasite);
            kapasiteler[m++] = kapasite;
        }
    }
    Sonuc s = benzet(strateji, n);
    printf("  %s:", AD[strateji]);
    for (int i = 0; i < m; i++) {
        if (m > 8 && i == 4) {
            printf(" -> ...");
            i = m - 3;
            continue;
        }
        printf(i == 0 ? " %lld" : " -> %lld", kapasiteler[i]);
    }
    printf("  (%lld büyütme, %lld kopya)\n", s.buyutme, s.kopya);
}

/* Gerçek dinamik dizi: büyütmede yeni blok + öğe öğe kopya (sayılır) */
typedef struct {
    int *veri;
    long long boyut, kapasite;
} DinamikDizi;

static long long gercek_kopya = 0;
/* Sahiplik: d->veri dizinindir; dd_ekle eski bloğu bırakır, sonuncuyu main. */
static bool dd_ekle(DinamikDizi *d, int x, int strateji)
{
    if (d->boyut == d->kapasite) {
        long long yeni = yeni_kapasite(strateji, d->kapasite);
        int *blok = malloc((size_t)yeni * sizeof *blok);
        if (blok == NULL) {
            return false;
        }
        for (long long i = 0; i < d->boyut; i++) {
            blok[i] = d->veri[i];
            gercek_kopya++;
        }
        free(d->veri);
        d->veri = blok;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return true;
}

int main(void)
{
    printf("1) Kapasite zaman çizelgesi: n = 20 ekleme, ilk kapasite 1\n");
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        zaman_cizelgesi(s, 20);
    }

    printf("\n2) Toplam yöntemi: n sona eklemede toplam kopya\n");
    printf("  strateji       n büyüt.       kopya   kopya/n "
           "kapalı biçim   oran kuram\n");
    const long long nler[3] = {1000, 10000, 100000};
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        for (int j = 0; j < 3; j++) {
            long long n = nler[j];
            Sonuc r = benzet(s, n);
            long long kapali = -1;
            double kuram;          /* kestirim (+k) ya da üst sınır */
            const char *ad;
            if (s <= 1) {
                long long k = (s == 0) ? 1 : 10;
                kapali = arti_k_kapali(n, k);
                kuram = (double)n * n / (2.0 * k);
                ad = "(n²/2k)";
            } else if (s == 2) {
                kuram = 3.0 * n;
                ad = "(<3n)";
            } else {
                kapali = kat_2_kapali(n);
                kuram = 2.0 * n;
                ad = "(<2n)";
            }
            printf("  %s %7lld %6lld %11lld %9.3f ", AD[s], n, r.buyutme,
                   r.kopya, (double)r.kopya / n);
            if (kapali >= 0) {
                printf("%10lld %s", kapali, kapali == r.kopya ? "=" : "!");
            } else {
                printf("           —");
            }
            printf(" %6.3f %s\n", r.kopya / kuram, ad);
        }
    }

    printf("\n3) Gerçek dinamik dizi (öğe öğe kopya) ile benzetim, n = 1000\n");
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        DinamikDizi d = {NULL, 0, 1};
        d.veri = malloc(sizeof *d.veri);
        if (d.veri == NULL) {
            fprintf(stderr, "bellek yetersiz\n");
            return 1;
        }
        gercek_kopya = 0;
        long long toplam = 0;
        for (int i = 0; i < 1000; i++) {
            if (!dd_ekle(&d, i, s)) {
                fprintf(stderr, "bellek yetersiz\n");
                free(d.veri);
                return 1;
            }
        }
        for (long long i = 0; i < d.boyut; i++) {
            toplam += d.veri[i];
        }
        Sonuc r = benzet(s, 1000);
        printf("  %s: gerçek = %6lld, benzetim = %6lld, aynı mı? %s; "
               "toplam = %lld\n", AD[s], gercek_kopya, r.kopya,
               gercek_kopya == r.kopya ? "evet" : "HAYIR", toplam);
        free(d.veri);
    }

    printf("\n4) Ödünleşim: n = 100000'de boş yuva (bellek israfı)\n");
    printf("  strateji   kapasite  boş yuva  boş/kapasite\n");
    for (int s = 0; s < STRATEJI_SAYISI; s++) {
        Sonuc r = benzet(s, 100000);
        long long bos = r.kapasite - 100000;
        printf("  %s %10lld %9lld %13.3f\n", AD[s], r.kapasite, bos,
               (double)bos / r.kapasite);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::vector büyüme çarpanı
 * gerçekleştirime bağlıdır (capacity() ile gözlenir); Python — list
 * fazladan ayırır (Objects/listobject.c; sys.getsizeof ile gözlenir). */

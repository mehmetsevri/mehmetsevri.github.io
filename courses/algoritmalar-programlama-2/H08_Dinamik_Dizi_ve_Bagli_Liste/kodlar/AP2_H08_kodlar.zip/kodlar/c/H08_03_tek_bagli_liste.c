/* H08_03_tek_bagli_liste.c — AP-2 Hafta 8 · Örnek 3 (★)
 * Amaç    : Tek bağlı liste: düğüm, baş işaretçisi, başa ekleme (O(1)),
 *           dolaşarak yazdırma ve uzunluk (Θ(n)); ziyaret sayacı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_03_tek_bagli_liste.c ortak_rastgele.c \
 *           -o H08_03_tek_bagli_liste
 * Çalıştır: ./H08_03_tek_bagli_liste
 * Eşleri  : cpp/H08_03_tek_bagli_liste.cpp · python/H08_03_tek_bagli_liste.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;   /* sonraki düğümün adresi; son düğümde NULL */
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ziyaret_sayisi = 0, baglanti_sayisi = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = veri;
    d->sonraki = NULL;
    ayirma_sayisi++;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

/* Yeni düğüm eski başın önüne bağlanır; YENİ BAŞI döndürür: O(1) */
static Dugum *basa_ekle(Dugum *bas, int x)
{
    Dugum *d = dugum_olustur(x);
    d->sonraki = bas;
    baglanti_sayisi++;
    return d;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]\n");
}

/* Baştan NULL'a kadar yürür: Θ(n) */
static int uzunluk(const Dugum *bas)
{
    int n = 0;
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        ziyaret_sayisi++;
        n++;
    }
    return n;
}

/* Tüm düğümleri serbest bırakır (ayrıntısı Örnek 6) */
static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;   /* free'den ÖNCE sakla */
        dugum_birak(bas);
        bas = sonraki;
    }
}

int main(void)
{
    printf("1) Boş liste: baş işaretçisi NULL\n");
    Dugum *bas = NULL;
    printf("  ");
    liste_yaz(bas);
    printf("  uzunluk = %d\n", uzunluk(bas));

    printf("\n2) Başa ekleme: 4, 1, 3\n");
    const int sira[3] = {4, 1, 3};
    for (int i = 0; i < 3; i++) {
        bas = basa_ekle(bas, sira[i]);
        printf("  basa_ekle(%d): ", sira[i]);
        liste_yaz(bas);
    }
    ziyaret_sayisi = 0;
    int n = uzunluk(bas);
    printf("  uzunluk = %d (ziyaret edilen düğüm = %lld)\n", n,
           ziyaret_sayisi);
    printf("  baş düğüm: veri = %d; son düğümün sonraki'si NULL\n",
           bas->veri);
    liste_yok_et(bas);

    printf("\n3) 10 rastgele değer (tohum 42, 0..99) başa eklenince sıra "
           "tersine döner\n");
    rastgele_tohum(42);
    bas = NULL;
    printf("  girdi :");
    for (int i = 0; i < 10; i++) {
        int x = rastgele_aralik(0, 99);
        printf(" %d", x);
        bas = basa_ekle(bas, x);
    }
    printf("\n  liste : ");
    liste_yaz(bas);
    long long toplam = 0;
    int en_buyuk = bas->veri;
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        toplam += p->veri;
        if (p->veri > en_buyuk) {
            en_buyuk = p->veri;
        }
    }
    printf("  uzunluk = %d, toplam = %lld, en büyük = %d\n", uzunluk(bas),
           toplam, en_buyuk);
    liste_yok_et(bas);

    printf("\n4) Maliyet: başa ekleme sabit iş, uzunluk Θ(n)\n");
    printf("        n   ayırma  bağlantı yazma  ekleme ziyareti"
           "  uzunluk ziyareti\n");
    const int nler[4] = {10, 100, 1000, 10000};
    for (int j = 0; j < 4; j++) {
        long long a0 = ayirma_sayisi, b0 = baglanti_sayisi;
        ziyaret_sayisi = 0;
        bas = NULL;
        for (int i = 0; i < nler[j]; i++) {
            bas = basa_ekle(bas, i);
        }
        long long ekleme_ziyareti = ziyaret_sayisi;
        uzunluk(bas);
        printf("  %7d %8lld %15lld %16lld %17lld\n", nler[j],
               ayirma_sayisi - a0, baglanti_sayisi - b0, ekleme_ziyareti,
               ziyaret_sayisi - ekleme_ziyareti);
        liste_yok_et(bas);
    }

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list
 * (push_front), std::list; Python — yerleşik bağlı liste yok
 * (collections.deque.appendleft O(1); list.insert(0, x) Θ(n)). */

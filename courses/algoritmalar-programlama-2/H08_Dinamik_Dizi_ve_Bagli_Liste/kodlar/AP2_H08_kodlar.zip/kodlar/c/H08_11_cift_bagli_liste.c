/* H08_11_cift_bagli_liste.c — AP-2 Hafta 8 · Örnek 11 (★★)
 * Amaç    : Kukla düğümlü dairesel çift bağlı liste: adresi bilinen düğümü
 *           O(1) silme, ileri ve geri dolaşma; tek bağlı listeyle kıyas
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_11_cift_bagli_liste.c ortak_rastgele.c \
 *           -o H08_11_cift_bagli_liste
 * Çalıştır: ./H08_11_cift_bagli_liste
 * Eşleri  : cpp/H08_11_cift_bagli_liste.cpp ·
 *           python/H08_11_cift_bagli_liste.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct CDugum {
    int veri;
    struct CDugum *onceki;
    struct CDugum *sonraki;
} CDugum;

/* Dairesel, kukla düğümlü: kukla.sonraki = ilk, kukla.onceki = son; boş
 * listede ikisi de kuklanın kendisidir. Hiçbir bağlantı NULL değildir. */
typedef struct {
    CDugum kukla;      /* veri taşımaz; yapının içinde, ayrılmaz */
    int uzunluk;
} CiftListe;

typedef struct Dugum {     /* karşılaştırma için tek bağlı düğüm */
    int veri;
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long baglanti_sayisi = 0, ziyaret_sayisi = 0;

static void *bellek_ayir(size_t boyut)
{
    void *p = malloc(boyut);
    if (p == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    ayirma_sayisi++;
    return p;
}

static void bellek_birak(void *p)
{
    free(p);
    birakma_sayisi++;
}

static void cl_baslat(CiftListe *liste)
{
    liste->kukla.veri = 0;
    liste->kukla.onceki = &liste->kukla;
    liste->kukla.sonraki = &liste->kukla;
    liste->uzunluk = 0;
}

/* Yeni düğümü konum'un ÖNÜNE ekler: dört bağlantı, özel durum yok.
 * Sahiplik: düğüm listenindir; dönen işaretçi yalnızca bir "tutamaktır". */
static CDugum *once_ekle(CiftListe *liste, CDugum *konum, int x)
{
    CDugum *d = bellek_ayir(sizeof *d);
    d->veri = x;
    d->sonraki = konum;
    d->onceki = konum->onceki;
    konum->onceki->sonraki = d;
    konum->onceki = d;
    baglanti_sayisi += 4;
    liste->uzunluk++;
    return d;
}

static CDugum *sona_ekle(CiftListe *liste, int x)
{
    return once_ekle(liste, &liste->kukla, x);    /* kuklanın önü = son */
}

static CDugum *basa_ekle(CiftListe *liste, int x)
{
    return once_ekle(liste, liste->kukla.sonraki, x);
}

/* Adresi bilinen düğümü O(1) siler: iki bağlantı, yürüme yok, baş/son için
 * özel durum yok (komşular her zaman vardır: en kötü kukla). d kukla
 * olmamalıdır. */
static void dugumu_sil(CiftListe *liste, CDugum *d)
{
    d->onceki->sonraki = d->sonraki;
    d->sonraki->onceki = d->onceki;
    baglanti_sayisi += 2;
    liste->uzunluk--;
    bellek_birak(d);
}

static void cl_yok_et(CiftListe *liste)
{
    CDugum *d = liste->kukla.sonraki;
    while (d != &liste->kukla) {
        CDugum *sonraki = d->sonraki;
        bellek_birak(d);
        d = sonraki;
    }
    cl_baslat(liste);
}

static void ileri_yaz(const CiftListe *liste)
{
    printf("  ileri:");
    if (liste->uzunluk == 0) {
        printf(" (boş)");
    }
    for (const CDugum *d = liste->kukla.sonraki; d != &liste->kukla;
         d = d->sonraki) {
        printf(d == liste->kukla.sonraki ? " %d" : " <-> %d", d->veri);
    }
    printf("\n");
}

static void geri_yaz(const CiftListe *liste)
{
    printf("  geri :");
    if (liste->uzunluk == 0) {
        printf(" (boş)");
    }
    for (const CDugum *d = liste->kukla.onceki; d != &liste->kukla;
         d = d->onceki) {
        printf(d == liste->kukla.onceki ? " %d" : " <-> %d", d->veri);
    }
    printf("\n");
}

/* Değişmez: her düğüm için d->sonraki->onceki == d; iki yönde de sayım
 * uzunluğa eşit */
static bool tutarli_mi(const CiftListe *liste)
{
    int ileri = 0, geri = 0;
    const CDugum *d = &liste->kukla;
    do {
        if (d->sonraki->onceki != d) {
            return false;
        }
        d = d->sonraki;
        ileri++;
    } while (d != &liste->kukla);
    for (d = liste->kukla.onceki; d != &liste->kukla; d = d->onceki) {
        geri++;
    }
    return ileri - 1 == liste->uzunluk && geri == liste->uzunluk;
}

/* Tek bağlı listede adresi bilinen düğümü silmek: önce ÖNCEKİSİ bulunmalı
 * (Dugum ** ile baştan yürüyerek): Θ(konum) ziyaret */
static void tek_sil_adresle(Dugum **bas, Dugum *hedef)
{
    Dugum **p = bas;
    while (*p != hedef) {
        p = &(*p)->sonraki;
        ziyaret_sayisi++;
    }
    *p = hedef->sonraki;
    baglanti_sayisi++;
    bellek_birak(hedef);
}

static void durum_yaz(const CiftListe *liste, long long b0)
{
    ileri_yaz(liste);
    geri_yaz(liste);
    printf("  uzunluk = %d, bağlantı yazma = %lld, tutarlı mı? %s\n",
           liste->uzunluk, baglanti_sayisi - b0,
           tutarli_mi(liste) ? "evet" : "HAYIR");
}

int main(void)
{
    CiftListe liste;
    cl_baslat(&liste);
    printf("1) Kurma: sona_ekle 1, 4, 5, 9; basa_ekle 2\n");
    long long b0 = baglanti_sayisi;
    sona_ekle(&liste, 1);
    sona_ekle(&liste, 4);
    CDugum *bes = sona_ekle(&liste, 5);   /* tutamak: adres saklanır */
    sona_ekle(&liste, 9);
    basa_ekle(&liste, 2);
    durum_yaz(&liste, b0);

    printf("\n2) Adresi bilinen düğümleri O(1) silme (yürüme yok)\n");
    printf("  sil 5 (ortadan, tutamakla):\n");
    b0 = baglanti_sayisi;
    dugumu_sil(&liste, bes);
    durum_yaz(&liste, b0);
    printf("  sil ilk (kukla.sonraki):\n");
    b0 = baglanti_sayisi;
    dugumu_sil(&liste, liste.kukla.sonraki);
    durum_yaz(&liste, b0);
    printf("  sil son (kukla.onceki):\n");
    b0 = baglanti_sayisi;
    dugumu_sil(&liste, liste.kukla.onceki);
    durum_yaz(&liste, b0);

    printf("\n3) Kalanları sil: boş liste kukla'yı kendine bağlar\n");
    while (liste.uzunluk > 0) {
        dugumu_sil(&liste, liste.kukla.sonraki);
    }
    ileri_yaz(&liste);
    printf("  kukla.sonraki == kukla mı? %s, kukla.onceki == kukla mı? %s\n"
           "  tutarlı mı? %s\n",
           liste.kukla.sonraki == &liste.kukla ? "evet" : "HAYIR",
           liste.kukla.onceki == &liste.kukla ? "evet" : "HAYIR",
           tutarli_mi(&liste) ? "evet" : "HAYIR");

    printf("\n4) n = 1000 düğümü rastgele sırayla adresle silme (tohum 42)\n");
    enum { N = 1000 };
    static CDugum *cift_adres[N];
    static Dugum *tek_adres[N];
    static int sira[N];
    Dugum *tek_bas = NULL, *tek_son = NULL;
    for (int i = 0; i < N; i++) {
        cift_adres[i] = sona_ekle(&liste, i);
        Dugum *d = bellek_ayir(sizeof *d);
        d->veri = i;
        d->sonraki = NULL;
        if (tek_son == NULL) {
            tek_bas = d;
        } else {
            tek_son->sonraki = d;
        }
        tek_son = d;
        tek_adres[i] = d;
        sira[i] = i;
    }
    rastgele_tohum(42);
    rastgele_karistir(sira, N);
    baglanti_sayisi = 0;
    ziyaret_sayisi = 0;
    for (int i = 0; i < N; i++) {
        dugumu_sil(&liste, cift_adres[sira[i]]);
    }
    printf("  çift bağlı: ziyaret = %lld, bağlantı yazma = %lld (2n), "
           "tutarlı mı? %s\n", ziyaret_sayisi, baglanti_sayisi,
           tutarli_mi(&liste) ? "evet" : "HAYIR");
    baglanti_sayisi = 0;
    for (int i = 0; i < N; i++) {
        tek_sil_adresle(&tek_bas, tek_adres[sira[i]]);
    }
    printf("  tek bağlı : ziyaret = %lld (n²/4 ≈ %d), bağlantı yazma = "
           "%lld\n", ziyaret_sayisi, N * N / 4, baglanti_sayisi);
    printf("  bedel: çift bağlı düğümde ikinci bağlantı alanı "
           "(onceki)\n");
    cl_yok_et(&liste);

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list (çift bağlı;
 * erase(yineleyici) O(1)); Python — collections.deque (bloklardan oluşan
 * iki uçlu yapı; ortadan silme O(n)). */

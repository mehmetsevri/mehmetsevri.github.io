/* H08_10_floyd_dongu.c — AP-2 Hafta 8 · Örnek 10 (★★★)
 * Amaç    : Floyd döngü tespiti (kaplumbağa ve tavşan): buluşma, döngü
 *           başlangıcı (μ) ve döngü uzunluğu (λ); yok etmeden önce kırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_10_floyd_dongu.c \
 *           ortak_rastgele.c -o H08_10_floyd_dongu
 * Çalıştır: ./H08_10_floyd_dongu
 * Eşleri  : cpp/H08_10_floyd_dongu.cpp · python/H08_10_floyd_dongu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;                /* düğümün konumu: 0..n-1 */
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long adim_sayisi = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = veri;
    d->sonraki = NULL;
    ayirma_sayisi++;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

/* Yalnızca döngüsüz listede çağrılır (döngülüde sonsuza dek döner) */
static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

/* 0..n-1 konumlu n düğüm; mu >= 0 ise son düğüm mu konumundakine bağlanır
 * (döngü), mu < 0 ise döngü yok. Sahiplik: liste çağıranındır; döngülüyse
 * yok etmeden önce donguyu_kir çağrılmalıdır. */
static Dugum *dongulu_liste_kur(int n, int mu)
{
    Dugum *bas = NULL, *son = NULL, *hedef = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = dugum_olustur(i);
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
        if (i == mu) {
            hedef = d;
        }
    }
    if (son != NULL) {
        son->sonraki = hedef;            /* mu < 0 ise NULL kalır */
    }
    return bas;
}

/* Evre 1: kaplumbağa bir, tavşan iki adım atar. Döngü varsa döngünün
 * içinde buluşurlar (buluşma düğümü döner); yoksa tavşan NULL'a varır. */
static Dugum *bulusma_bul(Dugum *bas, bool izle)
{
    Dugum *kaplumbaga = bas, *tavsan = bas;
    while (tavsan != NULL && tavsan->sonraki != NULL) {
        kaplumbaga = kaplumbaga->sonraki;
        tavsan = tavsan->sonraki->sonraki;
        adim_sayisi++;
        if (izle) {
            printf("  adım %lld: kaplumbağa = %d, tavşan = %d\n",
                   adim_sayisi, kaplumbaga->veri, tavsan->veri);
        }
        if (kaplumbaga == tavsan) {
            return kaplumbaga;
        }
    }
    return NULL;
}

/* Evre 2: kaplumbağa baştan, tavşan buluşmadan; ikisi de BİRER adım.
 * μ adım sonra döngünün başlangıç düğümünde buluşurlar. */
static Dugum *dongu_baslangici(Dugum *bas, Dugum *bulusma, bool izle)
{
    Dugum *kaplumbaga = bas, *tavsan = bulusma;
    while (kaplumbaga != tavsan) {
        kaplumbaga = kaplumbaga->sonraki;
        tavsan = tavsan->sonraki;
        adim_sayisi++;
        if (izle) {
            printf("  adım %lld: kaplumbağa = %d, tavşan = %d\n",
                   adim_sayisi, kaplumbaga->veri, tavsan->veri);
        }
    }
    return kaplumbaga;
}

/* Evre 3: buluşma düğümünden çıkıp ona geri dönene kadar say: λ */
static int dongu_uzunlugu(const Dugum *bulusma)
{
    int lambda = 1;
    for (const Dugum *p = bulusma->sonraki; p != bulusma; p = p->sonraki) {
        lambda++;
    }
    return lambda;
}

/* Döngünün son düğümünü bulup sonraki'sini NULL yapar (yok etmeden önce) */
static Dugum *donguyu_kir(Dugum *baslangic)
{
    Dugum *p = baslangic;
    while (p->sonraki != baslangic) {
        p = p->sonraki;
    }
    p->sonraki = NULL;
    return p;
}

int main(void)
{
    rastgele_tohum(42);
    int n = 10;
    int mu = rastgele_aralik(0, n - 1);
    printf("1) n = %d düğüm (0..%d); döngü konumu LCG ile (tohum 42): "
           "%d -> %d\n", n, n - 1, n - 1, mu);
    Dugum *bas = dongulu_liste_kur(n, mu);
    printf("  evre 1: kaplumbağa 1, tavşan 2 adım (başlangıç: ikisi de 0)\n");
    adim_sayisi = 0;
    Dugum *bulusma = bulusma_bul(bas, true);
    printf("  buluşma düğümü = %d (%lld adım)\n", bulusma->veri, adim_sayisi);
    printf("  evre 2: kaplumbağa baştan (0), tavşan buluşmadan (%d); birer "
           "adım\n", bulusma->veri);
    adim_sayisi = 0;
    Dugum *baslangic = dongu_baslangici(bas, bulusma, true);
    printf("  döngü başlangıcı = %d (mu = %lld adım), döngü uzunluğu "
           "lambda = %d\n", baslangic->veri, adim_sayisi,
           dongu_uzunlugu(bulusma));
    Dugum *kirilan = donguyu_kir(baslangic);
    printf("  döngü kırıldı: %d -> NULL; yok etme güvenli\n", kirilan->veri);
    liste_yok_et(bas);

    printf("\n2) Seçilmiş durumlar (mu = -1: döngü yok)\n");
    printf("     n   mu  bulunan mu  lambda  evre1 adım  evre2 adım  doğru\n");
    const int durum[8][2] = {{1, -1}, {1, 0}, {2, -1}, {2, 1}, {6, 0},
                             {10, 9}, {10, -1}, {100, 37}};
    for (int t = 0; t < 8; t++) {
        int dn = durum[t][0], dmu = durum[t][1];
        bas = dongulu_liste_kur(dn, dmu);
        adim_sayisi = 0;
        bulusma = bulusma_bul(bas, false);
        long long a1 = adim_sayisi;
        int bulunan = -1, lambda = 0;
        long long a2 = 0;
        if (bulusma != NULL) {
            adim_sayisi = 0;
            baslangic = dongu_baslangici(bas, bulusma, false);
            a2 = adim_sayisi;
            bulunan = baslangic->veri;
            lambda = dongu_uzunlugu(bulusma);
            donguyu_kir(baslangic);
        }
        bool dogru = bulunan == dmu && (dmu < 0 || lambda == dn - dmu);
        printf("  %4d %4d %11d %7d %11lld %11lld  %s\n", dn, dmu, bulunan,
               lambda, a1, a2, dogru ? "evet" : "HAYIR");
        liste_yok_et(bas);
    }

    printf("\n3) 1000 rastgele liste (n = 1..200; %%20 döngüsüz; tohum 42)\n");
    int dogru_sayisi = 0, sinir_icinde = 0;
    long long toplam1 = 0, toplam_mulambda = 0;
    for (int t = 0; t < 1000; t++) {
        int rn = rastgele_aralik(1, 200);
        int rmu = rastgele_aralik(0, 4) == 0 ? -1 : rastgele_aralik(0, rn - 1);
        bas = dongulu_liste_kur(rn, rmu);
        adim_sayisi = 0;
        bulusma = bulusma_bul(bas, false);
        long long a1 = adim_sayisi;
        int bulunan = -1, lambda = 0;
        if (bulusma != NULL) {
            baslangic = dongu_baslangici(bas, bulusma, false);
            bulunan = baslangic->veri;
            lambda = dongu_uzunlugu(bulusma);
            donguyu_kir(baslangic);
        }
        bool dogru = bulunan == rmu && (rmu < 0 || lambda == rn - rmu);
        dogru_sayisi += dogru;
        if (rmu >= 0) {
            sinir_icinde += a1 <= rmu + lambda;   /* evre 1 <= mu + lambda */
            toplam1 += a1;
            toplam_mulambda += rn;                /* mu + lambda = n */
        } else {
            sinir_icinde += a1 == rn / 2;         /* döngüsüz: n/2 adım */
        }
        liste_yok_et(bas);
    }
    printf("  doğru (mu, lambda): %d/1000; evre 1 adım sınırı tutan: "
           "%d/1000\n", dogru_sayisi, sinir_icinde);
    printf("  döngülülerde evre 1 adımı / (mu + lambda) = %.3f\n",
           (double)toplam1 / toplam_mulambda);

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::list ve
 * std::forward_list döngü kurdurmaz); Python — yok. */

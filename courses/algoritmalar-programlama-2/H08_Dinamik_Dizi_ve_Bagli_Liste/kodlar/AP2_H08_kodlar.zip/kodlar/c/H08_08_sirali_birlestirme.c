/* H08_08_sirali_birlestirme.c — AP-2 Hafta 8 · Örnek 8 (★★)
 * Amaç    : İki sıralı listeyi kukla düğümle birleştirme: düğümler yeniden
 *           bağlanır (yeni düğüm yok), kararlı, Θ(n + m); kâhinle sınama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_08_sirali_birlestirme.c ortak_rastgele.c \
 *           -o H08_08_sirali_birlestirme
 * Çalıştır: ./H08_08_sirali_birlestirme
 * Eşleri  : cpp/H08_08_sirali_birlestirme.cpp ·
 *           python/H08_08_sirali_birlestirme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;
    int kimlik;              /* oluşturulma sırası (kararlılık denetimi) */
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long karsilastirma_sayisi = 0, baglanti_sayisi = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    ayirma_sayisi++;
    d->veri = veri;
    d->kimlik = (int)ayirma_sayisi;
    d->sonraki = NULL;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

static Dugum *liste_olustur(const int *a, int n)
{
    Dugum *bas = NULL, *son = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = dugum_olustur(a[i]);
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum *bas, bool kimlikli)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        if (kimlikli) {
            printf("%d#%d -> ", p->veri, p->kimlik);
        } else {
            printf("%d -> ", p->veri);
        }
    }
    printf("NULL]");
}

/* İki sıralı listeyi düğümleri YENİDEN BAĞLAYARAK birleştirir; yeni düğüm
 * ayrılmaz. Kararlı: eşitlikte a'dan gelen önce (<=). Sahiplik: a ve b'nin
 * düğümleri dönen listeye geçer; çağıran a ve b'yi artık kullanmaz. */
static Dugum *birlestir(Dugum *a, Dugum *b)
{
    Dugum kukla = {0, 0, NULL};   /* yığında: ayrılmaz, bırakılmaz */
    Dugum *son = &kukla;          /* sonucun son düğümü */
    while (a != NULL && b != NULL) {
        karsilastirma_sayisi++;
        if (a->veri <= b->veri) {
            son->sonraki = a;
            a = a->sonraki;
        } else {
            son->sonraki = b;
            b = b->sonraki;
        }
        baglanti_sayisi++;
        son = son->sonraki;
    }
    son->sonraki = (a != NULL) ? a : b;   /* kalan kuyruk tek bağlantıyla */
    baglanti_sayisi++;
    return kukla.sonraki;
}

/* Aynı döngü; her adım yazdırılarak */
static Dugum *birlestir_izle(Dugum *a, Dugum *b)
{
    Dugum kukla = {0, 0, NULL};
    Dugum *son = &kukla;
    int adim = 0;
    while (a != NULL && b != NULL) {
        printf("  adım %d: a.baş = %d, b.baş = %d -> ", ++adim, a->veri,
               b->veri);
        karsilastirma_sayisi++;
        if (a->veri <= b->veri) {
            printf("%d (a)\n", a->veri);
            son->sonraki = a;
            a = a->sonraki;
        } else {
            printf("%d (b)\n", b->veri);
            son->sonraki = b;
            b = b->sonraki;
        }
        baglanti_sayisi++;
        son = son->sonraki;
    }
    son->sonraki = (a != NULL) ? a : b;
    baglanti_sayisi++;
    printf("  kalan kuyruk (%s) tek bağlantıyla eklendi: ",
           a != NULL ? "a" : "b");
    liste_yaz(son->sonraki, false);
    printf("\n");
    return kukla.sonraki;
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

/* x[0..n-1]: rastgele artışlarla sıralı dizi (sıralama gerekmez) */
static void sirali_dizi(int *x, int n, int en_cok_artis)
{
    int deger = rastgele_aralik(0, 3);
    for (int i = 0; i < n; i++) {
        x[i] = deger;
        deger += rastgele_aralik(0, en_cok_artis);
    }
}

int main(void)
{
    const int a1[4] = {1, 3, 5, 7};
    const int b1[5] = {2, 3, 5, 8, 9};

    printf("1) Kukla düğümle birleştirme\n");
    Dugum *a = liste_olustur(a1, 4);
    Dugum *b = liste_olustur(b1, 5);
    printf("  a = ");
    liste_yaz(a, false);
    printf("\n  b = ");
    liste_yaz(b, false);
    printf("\n");
    long long a0 = ayirma_sayisi;
    Dugum *c = birlestir_izle(a, b);
    a = b = NULL;                 /* düğümler artık c'nin */
    printf("  c = ");
    liste_yaz(c, false);
    printf("\n  karşılaştırma = %lld, bağlantı yazma = %lld, yeni düğüm = "
           "%lld\n", karsilastirma_sayisi, baglanti_sayisi, ayirma_sayisi - a0);

    printf("\n2) Kararlılık: veri#kimlik (a'nın düğümleri 1-4, b'ninkiler "
           "5-9)\n  c = ");
    liste_yaz(c, true);
    bool kararli = true;
    for (const Dugum *p = c; p != NULL && p->sonraki != NULL; p = p->sonraki) {
        if (p->veri == p->sonraki->veri && p->kimlik > p->sonraki->kimlik) {
            kararli = false;
        }
    }
    printf("\n  eşit anahtarlarda a'dan gelen önce mi? %s\n",
           kararli ? "evet" : "HAYIR");
    liste_yok_et(c);

    printf("\n3) Sınır durumları\n");
    const int s1[2] = {1, 2}, s2[1] = {5}, s3[3] = {1, 2, 3};
    const int *sol[4] = {s1, s1, s1, s2};
    const int *sag[4] = {s1, s1, s1, s3};
    const int nsol[4] = {0, 0, 2, 1}, nsag[4] = {0, 2, 0, 3};
    for (int t = 0; t < 4; t++) {
        Dugum *x = liste_olustur(sol[t], nsol[t]);
        Dugum *y = liste_olustur(sag[t], nsag[t]);
        printf("  ");
        liste_yaz(x, false);
        printf(" + ");
        liste_yaz(y, false);
        Dugum *z = birlestir(x, y);
        printf(" = ");
        liste_yaz(z, false);
        printf("\n");
        liste_yok_et(z);
    }

    printf("\n4) Kâhinle 1000 rastgele sınama (uzunluk 0..20, tohum 42)\n");
    rastgele_tohum(42);
    int dogru = 0, kararli_sayisi = 0;
    long long yeni = 0;
    for (int t = 0; t < 1000; t++) {
        int n = rastgele_aralik(0, 20), m = rastgele_aralik(0, 20);
        int x[20], y[20], kahin[40];
        sirali_dizi(x, n, 3);
        sirali_dizi(y, m, 3);
        for (int i = 0; i < n; i++) {
            kahin[i] = x[i];
        }
        for (int i = 0; i < m; i++) {
            kahin[n + i] = y[i];
        }
        qsort(kahin, (size_t)(n + m), sizeof kahin[0], kucukten_buyuge);
        Dugum *p = liste_olustur(x, n);
        Dugum *q = liste_olustur(y, m);
        a0 = ayirma_sayisi;
        Dugum *z = birlestir(p, q);
        yeni += ayirma_sayisi - a0;
        int i = 0;
        bool ayni = true, k = true;
        for (const Dugum *d = z; d != NULL; d = d->sonraki, i++) {
            ayni = ayni && i < n + m && d->veri == kahin[i];
            if (d->sonraki != NULL && d->veri == d->sonraki->veri &&
                d->kimlik > d->sonraki->kimlik) {
                k = false;
            }
        }
        dogru += ayni && i == n + m;
        kararli_sayisi += k;
        liste_yok_et(z);
    }
    printf("  kâhinle aynı: %d/1000, kararlı: %d/1000, birleştirmede yeni "
           "düğüm: %lld\n", dogru, kararli_sayisi, yeni);

    printf("\n5) Maliyet Θ(n + m): n = m = 100000 (artışlar 0..9)\n");
    static int x[100000], y[100000];
    sirali_dizi(x, 100000, 9);
    sirali_dizi(y, 100000, 9);
    a = liste_olustur(x, 100000);
    b = liste_olustur(y, 100000);
    karsilastirma_sayisi = baglanti_sayisi = 0;
    c = birlestir(a, b);
    printf("  karşılaştırma = %lld (<= n + m - 1 = 199999), bağlantı yazma = "
           "%lld\n", karsilastirma_sayisi, baglanti_sayisi);
    liste_yok_et(c);

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::list::merge,
 * std::forward_list::merge (düğümleri taşır; kararlı), std::merge
 * (dizilerde); Python — heapq.merge (yineleyici), sorted(a + b). */

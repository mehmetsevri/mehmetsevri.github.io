/* H08_12_listede_birlestirmeli.c — AP-2 Hafta 8 · Örnek 12 (★★★)
 * Amaç    : Bağlı listede birleştirmeli sıralama: ortadan bölme (yavaş–
 *           hızlı), birleştirme (Örnek 8); ek dizi yok, kararlı, derinlik
 *           O(log n); dizi kâhinine karşı rastgele sınama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_12_listede_birlestirmeli.c ortak_rastgele.c \
 *           -o H08_12_listede_birlestirmeli -lm
 * Çalıştır: ./H08_12_listede_birlestirmeli
 * Eşleri  : cpp/H08_12_listede_birlestirmeli.cpp ·
 *           python/H08_12_listede_birlestirmeli.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;
    int kimlik;              /* oluşturulma sırası (kararlılık denetimi) */
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long karsilastirma_sayisi = 0, baglanti_sayisi = 0;
static long long cagri_sayisi = 0;
static int en_derin = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    ayirma_sayisi++;
    d->veri = veri;
    d->kimlik = (int)ayirma_sayisi;
    d->sonraki = NULL;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

static Dugum *liste_olustur(const int *a, int n)
{
    Dugum *bas = NULL, *son = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = dugum_olustur(a[i]);
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void kisa_yaz(const Dugum *bas, bool kimlikli)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf(p == bas ? "%d" : " %d", p->veri);
        if (kimlikli) {
            printf("#%d", p->kimlik);
        }
    }
    printf("]");
}

/* Örnek 8'deki birleştirme: kukla düğüm, kararlı (<=), yeni düğüm yok */
static Dugum *birlestir(Dugum *a, Dugum *b)
{
    Dugum kukla = {0, 0, NULL};
    Dugum *son = &kukla;
    while (a != NULL && b != NULL) {
        karsilastirma_sayisi++;
        if (a->veri <= b->veri) {
            son->sonraki = a;
            a = a->sonraki;
        } else {
            son->sonraki = b;
            b = b->sonraki;
        }
        baglanti_sayisi++;
        son = son->sonraki;
    }
    son->sonraki = (a != NULL) ? a : b;
    baglanti_sayisi++;
    return kukla.sonraki;
}

/* En az iki düğümlü listeyi ikiye böler: ilk yarı ⌈n/2⌉ düğüm (yavaş–
 * hızlı, hızlı bir adım önden: çift n'de BİRİNCİ orta). İkinci yarının
 * başını döndürür. */
static Dugum *ortadan_bol(Dugum *bas)
{
    Dugum *yavas = bas, *hizli = bas->sonraki;
    while (hizli != NULL && hizli->sonraki != NULL) {
        yavas = yavas->sonraki;
        hizli = hizli->sonraki->sonraki;
    }
    Dugum *ikinci = yavas->sonraki;
    yavas->sonraki = NULL;  /* ilk yarıyı kes */
    baglanti_sayisi++;
    return ikinci;
}

/* Sıralı listenin başını döndürür; düğümler yeniden bağlanır (ek dizi
 * yok). Derinlik ⌈log2 n⌉ + 1: yığında O(log n) çerçeve. */
static Dugum *birlestirmeli_sirala(Dugum *bas, int derinlik)
{
    cagri_sayisi++;
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (bas == NULL || bas->sonraki == NULL) {
        return bas;                       /* 0 ya da 1 düğüm: sıralı */
    }
    Dugum *ikinci = ortadan_bol(bas);
    Dugum *sol = birlestirmeli_sirala(bas, derinlik + 1);
    Dugum *sag = birlestirmeli_sirala(ikinci, derinlik + 1);
    return birlestir(sol, sag);
}

/* Aynı özyineleme; her çağrıda bölme ve birleştirme girintiyle yazılır */
static Dugum *birlestirmeli_sirala_izle(Dugum *bas, int derinlik)
{
    if (bas == NULL || bas->sonraki == NULL) {
        return bas;
    }
    printf("%*sböl ", 2 * derinlik, "");
    kisa_yaz(bas, false);
    Dugum *ikinci = ortadan_bol(bas);
    printf(" -> ");
    kisa_yaz(bas, false);
    printf(" | ");
    kisa_yaz(ikinci, false);
    printf("\n");
    Dugum *sol = birlestirmeli_sirala_izle(bas, derinlik + 1);
    Dugum *sag = birlestirmeli_sirala_izle(ikinci, derinlik + 1);
    Dugum *sonuc = birlestir(sol, sag);
    printf("%*sbirleştir -> ", 2 * derinlik, "");
    kisa_yaz(sonuc, false);
    printf("\n");
    return sonuc;
}

static int tavan_log2(long long n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

/* Sıralı mı, kararlı mı (eşitlerde kimlik artan), kâhinle aynı mı? */
static bool denetle(const Dugum *bas, const int *kahin, int n, bool *kararli)
{
    int i = 0;
    bool ayni = true;
    *kararli = true;
    for (const Dugum *p = bas; p != NULL; p = p->sonraki, i++) {
        ayni = ayni && i < n && p->veri == kahin[i];
        if (p->sonraki != NULL && p->veri == p->sonraki->veri &&
            p->kimlik > p->sonraki->kimlik) {
            *kararli = false;
        }
    }
    return ayni && i == n;
}

int main(void)
{
    const int a[7] = {5, 2, 7, 2, 9, 1, 5};
    printf("1) Bölme ve birleştirme ağacı, n = 7\n");
    Dugum *bas = liste_olustur(a, 7);
    printf("  girdi : ");
    kisa_yaz(bas, true);
    printf("   (veri#kimlik)\n");
    bas = birlestirmeli_sirala_izle(bas, 1);
    printf("  çıktı : ");
    kisa_yaz(bas, true);
    printf("\n");
    bool kararli = true;
    for (const Dugum *p = bas; p->sonraki != NULL; p = p->sonraki) {
        if (p->veri == p->sonraki->veri && p->kimlik > p->sonraki->kimlik) {
            kararli = false;
        }
    }
    printf("  kararlı mı (2#2 2#4 ve 5#1 5#7 sırası korundu mu)? %s\n",
           kararli ? "evet" : "HAYIR");
    liste_yok_et(bas);

    printf("\n2) Sınır durumları\n");
    const int s[2] = {8, 3};
    for (int n = 0; n <= 2; n++) {
        bas = liste_olustur(s, n);
        printf("  n = %d: ", n);
        kisa_yaz(bas, false);
        bas = birlestirmeli_sirala(bas, 1);
        printf(" -> ");
        kisa_yaz(bas, false);
        printf("\n");
        liste_yok_et(bas);
    }

    printf("\n3) Kâhinle 200 rastgele sınama (n = 0..300, anahtar 0..20, "
           "tohum 42)\n");
    rastgele_tohum(42);
    int dogru = 0, kararli_sayisi = 0, derinlik_tutan = 0;
    long long yeni = 0;
    for (int t = 0; t < 200; t++) {
        int n = rastgele_aralik(0, 300);
        static int x[300], kahin[300];
        rastgele_dizi(x, (size_t)n, 0, 20);
        for (int i = 0; i < n; i++) {
            kahin[i] = x[i];
        }
        qsort(kahin, (size_t)n, sizeof kahin[0], kucukten_buyuge);
        bas = liste_olustur(x, n);
        long long a0 = ayirma_sayisi;
        en_derin = 0;
        bas = birlestirmeli_sirala(bas, 1);
        yeni += ayirma_sayisi - a0;
        bool k;
        dogru += denetle(bas, kahin, n, &k);
        kararli_sayisi += k;
        derinlik_tutan += en_derin <= tavan_log2(n) + 1;
        liste_yok_et(bas);
    }
    printf("  kâhinle aynı: %d/200, kararlı: %d/200, derinlik <= ⌈lg n⌉ + 1:"
           " %d/200,\n  sıralamada yeni düğüm: %lld\n", dogru,
           kararli_sayisi, derinlik_tutan, yeni);

    printf("\n4) Sayaçlar (rastgele anahtar 0..10^6)\n");
    printf("        n  karşılaştırma  k/(n lg n)  derinlik  ⌈lg n⌉+1"
           "     çağrı  bağlantı\n");
    const int nler[3] = {1000, 10000, 100000};
    static int b[100000];
    for (int j = 0; j < 3; j++) {
        int n = nler[j];
        rastgele_dizi(b, (size_t)n, 0, 1000000);
        bas = liste_olustur(b, n);
        karsilastirma_sayisi = baglanti_sayisi = cagri_sayisi = 0;
        en_derin = 0;
        bas = birlestirmeli_sirala(bas, 1);
        printf("  %7d %14lld %11.3f %9d %9d %9lld %9lld\n", n,
               karsilastirma_sayisi,
               karsilastirma_sayisi / (n * log2((double)n)), en_derin,
               tavan_log2(n) + 1, cagri_sayisi, baglanti_sayisi);
        liste_yok_et(bas);
    }

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; qsort yalnızca kâhin); C++ —
 * std::list::sort (kararlı, düğümleri taşır); Python — list.sort /
 * sorted (Timsort; dinamik dizide). */

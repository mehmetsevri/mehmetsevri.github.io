/* H08_05_degere_gore_silme.c — AP-2 Hafta 8 · Örnek 5 (★★)
 * Amaç    : Değere göre silme: önce baş için özel durumlu sürüm (önceki–
 *           gecerli), sonra Dugum ** ile özel durumsuz sürüm; tümünü silme
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_05_degere_gore_silme.c ortak_rastgele.c \
 *           -o H08_05_degere_gore_silme
 * Çalıştır: ./H08_05_degere_gore_silme
 * Eşleri  : cpp/H08_05_degere_gore_silme.cpp ·
 *           python/H08_05_degere_gore_silme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long ziyaret_sayisi = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = veri;
    d->sonraki = NULL;
    ayirma_sayisi++;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

/* a[0..n-1]'den sırayla liste kurar. Sahiplik: dönen liste çağıranındır. */
static Dugum *liste_olustur(const int *a, int n)
{
    Dugum *bas = NULL, *son = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = dugum_olustur(a[i]);
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]");
}

/* Ziyaret sayacı: bir düğümün verisine bakıldı */
static bool aranan_mi(const Dugum *d, int x)
{
    ziyaret_sayisi++;
    return d->veri == x;
}

/* Sürüm 1 (özel durumlu): önceki–gecerli ile ilk x'i siler ve YENİ BAŞI
 * döndürür. Baş siliniyorsa ayrı bir dal gerekir. */
static Dugum *sil_v1(Dugum *bas, int x)
{
    Dugum *onceki = NULL;
    Dugum *gecerli = bas;
    while (gecerli != NULL && !aranan_mi(gecerli, x)) {
        onceki = gecerli;
        gecerli = gecerli->sonraki;
    }
    if (gecerli == NULL) {
        return bas;                          /* x yok: liste aynı */
    }
    if (onceki == NULL) {
        bas = gecerli->sonraki;              /* ÖZEL DURUM: baş siliniyor */
    } else {
        onceki->sonraki = gecerli->sonraki;  /* ortadaki ya da son düğüm */
    }
    dugum_birak(gecerli);
    return bas;
}

/* Sürüm 2 (Dugum **): p, "sıradaki düğümü gösteren bağlantının" adresidir.
 * Baş işaretçisi de bir bağlantıdır: özel durum kalmaz. */
static bool sil_v2(Dugum **bas, int x)
{
    Dugum **p = bas;
    while (*p != NULL && !aranan_mi(*p, x)) {
        p = &(*p)->sonraki;
    }
    if (*p == NULL) {
        return false;
    }
    Dugum *silinen = *p;
    *p = silinen->sonraki;  /* baş da aynı satır */
    dugum_birak(silinen);
    return true;
}

/* Tüm x'leri siler (Dugum ** ile); silinen düğüm sayısını döndürür */
static int tumunu_sil(Dugum **bas, int x)
{
    int silinen_sayisi = 0;
    Dugum **p = bas;
    while (*p != NULL) {
        if (aranan_mi(*p, x)) {
            Dugum *silinen = *p;
            *p = silinen->sonraki;   /* p ilerlemez: yeni *p de denetlenir */
            dugum_birak(silinen);
            silinen_sayisi++;
        } else {
            p = &(*p)->sonraki;
        }
    }
    return silinen_sayisi;
}

static void sonuc_yaz(const char *etiket, const Dugum *bas, long long b0)
{
    printf("  %s ", etiket);
    liste_yaz(bas);
    printf("  %s, ziyaret = %lld\n",
           birakma_sayisi > b0 ? "silindi" : "yok", ziyaret_sayisi);
}

int main(void)
{
    const int a[8] = {3, 1, 4, 1, 5, 9, 2, 6};
    const int silinecek[4] = {3, 1, 6, 7};
    const char *etiket[4] = {"sil 3 (baş) :", "sil 1 (ilk) :", "sil 6 (son) :",
                             "sil 7 (yok) :"};

    printf("1) Sürüm 1 (özel durumlu, yeni başı döndürür)\n  başta       : ");
    Dugum *bas = liste_olustur(a, 8);
    liste_yaz(bas);
    printf("\n");
    for (int i = 0; i < 4; i++) {
        long long b0 = birakma_sayisi;
        ziyaret_sayisi = 0;
        bas = sil_v1(bas, silinecek[i]);
        sonuc_yaz(etiket[i], bas, b0);
    }
    liste_yok_et(bas);

    printf("\n2) Sürüm 2 (özel durumsuz; C/C++: Dugum **, Python: kukla "
           "düğüm)\n  başta       : ");
    bas = liste_olustur(a, 8);
    liste_yaz(bas);
    printf("\n");
    for (int i = 0; i < 4; i++) {
        long long b0 = birakma_sayisi;
        ziyaret_sayisi = 0;
        sil_v2(&bas, silinecek[i]);
        sonuc_yaz(etiket[i], bas, b0);
    }
    liste_yok_et(bas);

    printf("\n3) Sınır durumları (iki sürüm aynı sonucu verir)\n");
    const int tek[1] = {8};
    for (int surum = 1; surum <= 2; surum++) {
        const int x[3] = {5, 8, 8};
        const char *et[3] = {"tek düğüm, sil 5 :", "tek düğüm, sil 8 :",
                             "boş liste, sil 8 :"};
        bas = liste_olustur(tek, 1);
        printf("  sürüm %d\n", surum);
        for (int i = 0; i < 3; i++) {
            long long b0 = birakma_sayisi;
            ziyaret_sayisi = 0;
            if (surum == 1) {
                bas = sil_v1(bas, x[i]);
            } else {
                sil_v2(&bas, x[i]);
            }
            sonuc_yaz(et[i], bas, b0);
        }
        liste_yok_et(bas);
    }

    printf("\n4) Tüm 1'leri silme (ardışık ve baştaki 1'ler)\n");
    const int b[7] = {1, 1, 2, 1, 3, 1, 1};
    bas = liste_olustur(b, 7);
    printf("  başta : ");
    liste_yaz(bas);
    ziyaret_sayisi = 0;
    int k = tumunu_sil(&bas, 1);
    printf("\n  sonra : ");
    liste_yaz(bas);
    printf("  silinen = %d, ziyaret = %lld\n", k, ziyaret_sayisi);
    liste_yok_et(bas);

    printf("\n5) 1000 rastgele sınama (n = 0..10, değerler 0..5, tohum 42)\n");
    rastgele_tohum(42);
    int ayni = 0, ziyaret_ayni = 0;
    for (int t = 0; t < 1000; t++) {
        int n = rastgele_aralik(0, 10);
        int dizi[10];
        for (int i = 0; i < n; i++) {
            dizi[i] = rastgele_aralik(0, 5);
        }
        int x = rastgele_aralik(0, 5);
        Dugum *l1 = liste_olustur(dizi, n);
        Dugum *l2 = liste_olustur(dizi, n);
        ziyaret_sayisi = 0;
        l1 = sil_v1(l1, x);
        long long z1 = ziyaret_sayisi;
        ziyaret_sayisi = 0;
        sil_v2(&l2, x);
        bool esit = true;
        const Dugum *p = l1, *q = l2;
        while (p != NULL && q != NULL) {
            esit = esit && p->veri == q->veri;
            p = p->sonraki;
            q = q->sonraki;
        }
        ayni += esit && p == NULL && q == NULL;
        ziyaret_ayni += z1 == ziyaret_sayisi;
        liste_yok_et(l1);
        liste_yok_et(l2);
    }
    printf("  sonuç listeleri aynı: %d/1000, ziyaret sayıları aynı: %d/1000\n",
           ayni, ziyaret_ayni);

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list::remove
 * (tüm eşleşenler), std::list::remove; Python — list.remove(x) (ilk
 * eşleşen; dinamik dizide Θ(n) kaydırma). */

/* H08_13_dizi_mi_liste_mi.c — AP-2 Hafta 8 · Örnek 13 (★★★)
 * Amaç    : Stroustrup deneyi: n rastgele tamsayıyı sıralı dinamik diziye
 *           ve bağlı listeye DOĞRUSAL arayarak ekle, sonra rastgele
 *           konumlardan sil; deterministik sayaçlar (+ isteğe bağlı süre)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H08_13_dizi_mi_liste_mi.c ortak_rastgele.c zamanlayici.c \
 *           -o H08_13_dizi_mi_liste_mi
 * Çalıştır: ./H08_13_dizi_mi_liste_mi            (sayaçlar, n <= 1000)
 *           ./H08_13_dizi_mi_liste_mi --olc [n] [tekrar]   (süre ölçümü)
 * Eşleri  : cpp/H08_13_dizi_mi_liste_mi.cpp · python/H08_13_dizi_mi_liste_mi.py
 * Çıktı   : üç dilde aynı (=) (--olc çıktısı dile ve makineye özgüdür)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

typedef struct {
    int *veri;
    size_t boyut, kapasite;
} DinamikDizi;

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static long long dizi_karsilastirma = 0, dizi_kaydirma_ekle = 0;
static long long dizi_kaydirma_sil = 0;
static long long liste_ziyaret_ekle = 0, liste_ziyaret_sil = 0;
static long long ayirma_sayisi = 0, birakma_sayisi = 0;
/* Sahiplik: dönen blok çağıranındır; free ile serbest bırakılır. */
static void *bellek_ayir(size_t boyut)
{
    void *p = malloc(boyut);
    if (p == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    return p;
}

/* Sıralı diziye x: konum DOĞRUSAL aranır (ilk > x), sağdakiler kayar */
static void dizi_sirali_ekle(DinamikDizi *d, int x)
{
    size_t konum = 0;
    while (konum < d->boyut) {
        dizi_karsilastirma++;
        if (d->veri[konum] > x) {
            break;
        }
        konum++;
    }
    if (d->boyut == d->kapasite) {                 /* × 2 büyütme */
        size_t yeni = d->kapasite == 0 ? 1 : 2 * d->kapasite;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            fprintf(stderr, "bellek yetersiz\n");
            exit(1);
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    for (size_t j = d->boyut; j > konum; j--) {    /* sağa kaydır */
        d->veri[j] = d->veri[j - 1];
    }
    dizi_kaydirma_ekle += (long long)(d->boyut - konum);
    d->veri[konum] = x;
    d->boyut++;
}

/* konum'daki öğeyi siler (sola kaydırarak); değerini döndürür */
static int dizi_konumdan_sil(DinamikDizi *d, size_t konum)
{
    int x = d->veri[konum];
    for (size_t j = konum; j + 1 < d->boyut; j++) {
        d->veri[j] = d->veri[j + 1];
    }
    dizi_kaydirma_sil += (long long)(d->boyut - konum - 1);
    d->boyut--;
    return x;
}

/* Sıralı listeye x: Dugum ** ile ilk > x düğüme kadar yürünür, önüne
 * bağlanır (ekleme O(1), konum bulma Θ(konum)) */
static void liste_sirali_ekle(Dugum **bas, int x)
{
    Dugum **p = bas;
    while (*p != NULL) {
        liste_ziyaret_ekle++;
        if ((*p)->veri > x) {
            break;
        }
        p = &(*p)->sonraki;
    }
    Dugum *d = bellek_ayir(sizeof *d);
    ayirma_sayisi++;
    d->veri = x;
    d->sonraki = *p;
    *p = d;
}

/* konum'daki düğüme yürüyüp siler; değerini döndürür */
static int liste_konumdan_sil(Dugum **bas, size_t konum)
{
    Dugum **p = bas;
    for (size_t i = 0; i < konum; i++) {
        p = &(*p)->sonraki;
        liste_ziyaret_sil++;
    }
    Dugum *silinen = *p;
    int x = silinen->veri;
    *p = silinen->sonraki;
    free(silinen);
    birakma_sayisi++;
    return x;
}

/* İş yükü verisi: değerler ve silme konumları (konumlar[i] < n - i) */
static void is_yuku(int *degerler, size_t *konumlar, size_t n)
{
    rastgele_tohum(42);
    for (size_t i = 0; i < n; i++) {
        degerler[i] = (int)rastgele_sayi();
    }
    for (size_t i = 0; i < n; i++) {
        konumlar[i] = (size_t)rastgele_aralik(0, (int)(n - 1 - i));
    }
}

typedef struct {
    const int *degerler;
    const size_t *konumlar;
    size_t n;
    long long toplam;        /* silinen değerlerin toplamı (denetim) */
} Gorev;

static void dizi_gorevi(void *v)
{
    Gorev *g = v;
    DinamikDizi d = {NULL, 0, 0};
    for (size_t i = 0; i < g->n; i++) {
        dizi_sirali_ekle(&d, g->degerler[i]);
    }
    g->toplam = 0;
    for (size_t i = 0; i < g->n; i++) {
        g->toplam += dizi_konumdan_sil(&d, g->konumlar[i]);
    }
    free(d.veri);
}

static void liste_gorevi(void *v)
{
    Gorev *g = v;
    Dugum *bas = NULL;
    for (size_t i = 0; i < g->n; i++) {
        liste_sirali_ekle(&bas, g->degerler[i]);
    }
    g->toplam = 0;
    for (size_t i = 0; i < g->n; i++) {
        g->toplam += liste_konumdan_sil(&bas, g->konumlar[i]);
    }
}

/* İki yapı aynı sıralı diziyi kuruyor mu? (ekleme bitince karşılaştır) */
static bool ayni_sira_mi(const int *degerler, size_t n)
{
    DinamikDizi d = {NULL, 0, 0};
    Dugum *bas = NULL;
    for (size_t i = 0; i < n; i++) {
        dizi_sirali_ekle(&d, degerler[i]);
        liste_sirali_ekle(&bas, degerler[i]);
    }
    bool ayni = true;
    size_t i = 0;
    for (Dugum *p = bas; p != NULL; p = p->sonraki, i++) {
        ayni = ayni && i < d.boyut && p->veri == d.veri[i] &&
               (i == 0 || d.veri[i - 1] <= d.veri[i]);
    }
    ayni = ayni && i == d.boyut;
    while (bas != NULL) {
        liste_konumdan_sil(&bas, 0);
    }
    free(d.veri);
    return ayni;
}

static int olc(int argc, char *argv[])
{
    long n = argc > 2 ? strtol(argv[2], NULL, 10) : 20000;
    int tekrar = argc > 3 ? (int)strtol(argv[3], NULL, 10) : 5;
    if (n < 1 || n > 10000000 || tekrar < 1) {
        fprintf(stderr, "kullanım: %s --olc [n] [tekrar]\n", argv[0]);
        return 2;
    }
    int *degerler = bellek_ayir((size_t)n * sizeof *degerler);
    size_t *konumlar = bellek_ayir((size_t)n * sizeof *konumlar);
    is_yuku(degerler, konumlar, (size_t)n);
    Gorev g = {degerler, konumlar, (size_t)n, 0};
    double td = olc_ortanca(dizi_gorevi, &g, tekrar);
    long long toplam_d = g.toplam;
    double tl = olc_ortanca(liste_gorevi, &g, tekrar);
    printf("n = %ld, tekrar = %d (1 ısınma + ortanca)\n", n, tekrar);
    printf("  dizi : %10.3f ms\n  liste: %10.3f ms   liste/dizi = %.2f\n",
           td * 1e3, tl * 1e3, tl / td);
    printf("  denetim toplamları aynı mı? %s\n",
           toplam_d == g.toplam ? "evet" : "HAYIR");
    free(degerler);
    free(konumlar);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc > 1 && strcmp(argv[1], "--olc") == 0) {
        return olc(argc, argv);
    }
    printf("İş yükü: n rastgele tamsayı (tohum 42) sıralı yapıya doğrusal "
           "aramayla\neklenir, sonra rastgele konumlardan tek tek silinir.\n");
    printf("\n1) Dinamik dizi (bitişik bellek, × 2 büyüme)\n");
    printf("        n   arama karş.  kaydırma (ekle)  kaydırma (sil)"
           "       n²/4\n");
    static int degerler[1000];
    static size_t konumlar[1000];
    const size_t nler[3] = {250, 500, 1000};
    long long dizi_toplam[3], liste_toplam[3];
    long long d_is[3], l_is[3];
    for (int j = 0; j < 3; j++) {
        size_t n = nler[j];
        is_yuku(degerler, konumlar, n);
        dizi_karsilastirma = dizi_kaydirma_ekle = dizi_kaydirma_sil = 0;
        Gorev g = {degerler, konumlar, n, 0};
        dizi_gorevi(&g);
        dizi_toplam[j] = g.toplam;
        d_is[j] = dizi_karsilastirma + dizi_kaydirma_ekle + dizi_kaydirma_sil;
        printf("  %7zu %13lld %16lld %15lld %10lld\n", n, dizi_karsilastirma,
               dizi_kaydirma_ekle, dizi_kaydirma_sil,
               (long long)(n * n / 4));
    }
    printf("\n2) Tek bağlı liste (düğüm başına bir malloc)\n");
    printf("        n  ziyaret (ekle)  ziyaret (sil)   ayırma  bırakma"
           "       n²/4\n");
    for (int j = 0; j < 3; j++) {
        size_t n = nler[j];
        is_yuku(degerler, konumlar, n);
        liste_ziyaret_ekle = liste_ziyaret_sil = 0;
        ayirma_sayisi = birakma_sayisi = 0;
        Gorev g = {degerler, konumlar, n, 0};
        liste_gorevi(&g);
        liste_toplam[j] = g.toplam;
        l_is[j] = liste_ziyaret_ekle + liste_ziyaret_sil;
        printf("  %7zu %15lld %14lld %8lld %8lld %10lld\n", n,
               liste_ziyaret_ekle, liste_ziyaret_sil, ayirma_sayisi,
               birakma_sayisi, (long long)(n * n / 4));
    }

    printf("\n3) Denetim\n");
    for (int j = 0; j < 3; j++) {
        is_yuku(degerler, konumlar, nler[j]);
        printf("  n = %4zu: aynı sıralı dizi? %s; silinenler aynı? %s "
               "(toplam %lld)\n", nler[j],
               ayni_sira_mi(degerler, nler[j]) ? "evet" : "HAYIR",
               dizi_toplam[j] == liste_toplam[j] ? "evet" : "HAYIR",
               dizi_toplam[j]);
    }

    printf("\n4) Kuram: iki yapıda da adım sayısı Θ(n²); n iki katına "
           "çıkınca\n");
    printf("  dizi adımı (karş. + kaydırma) oranı: %.2f, %.2f\n"
           "  liste ziyareti oranı               : %.2f, %.2f\n",
           (double)d_is[1] / d_is[0],
           (double)d_is[2] / d_is[1], (double)l_is[1] / l_is[0],
           (double)l_is[2] / l_is[1]);
    printf("  Liste daha az adım atar (kaydırma yok) ama her adımı bir "
           "işaretçi\n  kovalamadır; dizi ardışık bellekte ilerler. Süreler "
           "için: --olc n\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::vector (insert/erase)
 * ve std::list (insert/erase; konum yine yürüyerek bulunur); Python —
 * list.insert / list.pop (dinamik dizi). */

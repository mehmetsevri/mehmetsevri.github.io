/* H08_01_dinamik_dizi.c — AP-2 Hafta 8 · Örnek 1 (★)
 * Amaç    : Dinamik dizi ADT'si (dd_olustur, dd_ekle, dd_al, dd_boyut,
 *           dd_yok_et); kapasite dolunca ikiye katlama ve kapasite izleme
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_01_dinamik_dizi.c \
 *           -o H08_01_dinamik_dizi
 * Çalıştır: ./H08_01_dinamik_dizi
 * Eşleri  : cpp/H08_01_dinamik_dizi.cpp · python/H08_01_dinamik_dizi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *veri;          /* öbekte ayrılmış blok */
    size_t boyut;       /* kullanılan öğe sayısı */
    size_t kapasite;    /* ayrılmış yuva sayısı */
} DinamikDizi;

static long long kopya_sayisi = 0;  /* büyütmede kopyalanan öğe */
static int buyutme_sayisi = 0;      /* kapasite değişimi */
static int tasima_sayisi = 0;       /* realloc bloğu başka yere taşıdı */

/* Sahiplik: dönen dizi çağıranındır; dd_yok_et ile serbest bırakılır.
 * Bellek yetersizse NULL döner. ilk_kapasite >= 1 olmalı. */
DinamikDizi *dd_olustur(size_t ilk_kapasite)
{
    DinamikDizi *d = malloc(sizeof *d);
    if (d == NULL) {
        return NULL;
    }
    d->veri = malloc(ilk_kapasite * sizeof *d->veri);
    if (d->veri == NULL) {
        free(d);
        return NULL;
    }
    d->boyut = 0;
    d->kapasite = ilk_kapasite;
    return d;
}

/* x'i sona ekler; doluysa kapasiteyi ikiye katlar.
 * 0: başarı, -1: bellek yetersiz (dizi değişmeden geçerli kalır). */
int dd_ekle(DinamikDizi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni_kapasite = 2 * d->kapasite;
        uintptr_t eski_adres = (uintptr_t)d->veri;  /* yalnız stderr için */
        int *gecici = realloc(d->veri, yeni_kapasite * sizeof *d->veri);
        if (gecici == NULL) {
            return -1;              /* d->veri hâlâ eski, geçerli blok */
        }
        tasima_sayisi += (uintptr_t)gecici != eski_adres;
        kopya_sayisi += (long long)d->boyut;  /* taşınırsa boyut kadar */
        buyutme_sayisi++;
        d->veri = gecici;
        d->kapasite = yeni_kapasite;
    }
    d->veri[d->boyut] = x;
    d->boyut++;
    return 0;
}

/* Ön koşul yerine denetim: i < boyut ise *x'e yazar ve true döner */
bool dd_al(const DinamikDizi *d, size_t i, int *x)
{
    if (i >= d->boyut) {
        return false;
    }
    *x = d->veri[i];
    return true;
}

size_t dd_boyut(const DinamikDizi *d)
{
    return d->boyut;
}

/* Bloğu ve tanımlayıcıyı serbest bırakır; d bundan sonra kullanılmaz */
void dd_yok_et(DinamikDizi *d)
{
    if (d != NULL) {
        free(d->veri);
        free(d);
    }
}

static void al_yaz(const DinamikDizi *d, size_t i)
{
    int x;
    if (dd_al(d, i, &x)) {
        printf("  dd_al(%zu) = %d\n", i, x);
    } else {
        printf("  dd_al(%zu): sınır dışı (boyut = %zu)\n", i, dd_boyut(d));
    }
}

int main(void)
{
    DinamikDizi *d = dd_olustur(1);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("1) dd_ekle ile 1..20'nin kareleri (ilk kapasite 1, büyütme × 2)\n");
    printf("  ekle    x  boyut  kapasite  kopya  toplam iş  iş/ekleme\n");
    long long toplam_is = 0;   /* yazma (1) + kopya */
    for (int i = 1; i <= 20; i++) {
        size_t eski_kapasite = d->kapasite;
        long long once = kopya_sayisi;
        if (dd_ekle(d, i * i) != 0) {
            fprintf(stderr, "bellek yetersiz\n");
            dd_yok_et(d);
            return 1;
        }
        long long kopya = kopya_sayisi - once;
        toplam_is += 1 + kopya;
        printf("  %4d %4d %6zu %9zu %6lld %10lld %10.2f", i, i * i,
               dd_boyut(d), d->kapasite, kopya, toplam_is,
               (double)toplam_is / i);
        if (d->kapasite != eski_kapasite) {
            printf("  <- büyüdü %zu -> %zu", eski_kapasite, d->kapasite);
        }
        printf("\n");
    }
    printf("  toplam kopya = %lld, ekleme sayısı = %zu, kopya/ekleme = %.2f\n",
           kopya_sayisi, dd_boyut(d), (double)kopya_sayisi / dd_boyut(d));
    printf("  boş yuva = %zu (kapasite %zu, boyut %zu)\n",
           d->kapasite - d->boyut, d->kapasite, d->boyut);

    printf("\n2) İndisle erişim O(1): dd_al\n");
    al_yaz(d, 0);
    al_yaz(d, 9);
    al_yaz(d, 19);
    al_yaz(d, 20);

    printf("\n3) Büyük n: 10^6 ekleme\n");
    DinamikDizi *b = dd_olustur(1);
    if (b == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        dd_yok_et(d);
        return 1;
    }
    kopya_sayisi = 0;
    int buyutme_once = buyutme_sayisi;
    for (int i = 0; i < 1000000; i++) {
        if (dd_ekle(b, i) != 0) {
            fprintf(stderr, "bellek yetersiz\n");
            dd_yok_et(b);
            dd_yok_et(d);
            return 1;
        }
    }
    long long toplam = 0;
    for (size_t i = 0; i < dd_boyut(b); i++) {
        int x;
        dd_al(b, i, &x);
        toplam += x;
    }
    printf("  boyut = %zu, kapasite = %zu, büyütme = %d\n", dd_boyut(b),
           b->kapasite, buyutme_sayisi - buyutme_once);
    printf("  toplam kopya = %lld, kopya/ekleme = %.3f (< 2)\n",
           kopya_sayisi, (double)kopya_sayisi / dd_boyut(b));
    printf("  öğelerin toplamı = %lld (beklenen %lld)\n", toplam,
           999999LL * 1000000LL / 2);
    dd_yok_et(b);
    dd_yok_et(d);
    fprintf(stderr, "[stderr; bu çalıştırmada] realloc'un bloğu başka "
            "adrese taşıdığı büyütme: %d / %d\n", tasima_sayisi,
            buyutme_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; realloc ile); C++ — std::vector
 * (push_back, operator[], size, capacity); Python — list (append, a[i],
 * len). */

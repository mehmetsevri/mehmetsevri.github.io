/* H08_07_ters_cevirme.c — AP-2 Hafta 8 · Örnek 7 (★★)
 * Amaç    : Listeyi ters çevirme: yinelemeli (onceki–gecerli–sonraki
 *           üçlüsü, O(1) ek bellek) ve özyinelemeli (derinlik n)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H08_07_ters_cevirme.c \
 *           ortak_rastgele.c -o H08_07_ters_cevirme
 * Çalıştır: ./H08_07_ters_cevirme [n]   (n verilirse: özyinelemeli, n düğüm)
 * Eşleri  : cpp/H08_07_ters_cevirme.cpp · python/H08_07_ters_cevirme.py
 * Çıktı   : üç dilde aynı (=) (argümanlı çalıştırma dile özgüdür)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    int veri;
    struct Dugum *sonraki;
} Dugum;

static long long ayirma_sayisi = 0, birakma_sayisi = 0;
static long long baglanti_sayisi = 0;
static int en_derin = 0;

/* Sahiplik: dönen düğüm çağıranındır; dugum_birak ile serbest bırakılır */
static Dugum *dugum_olustur(int veri)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    d->veri = veri;
    d->sonraki = NULL;
    ayirma_sayisi++;
    return d;
}

static void dugum_birak(Dugum *d)
{
    free(d);
    birakma_sayisi++;
}

static void liste_yok_et(Dugum *bas)
{
    while (bas != NULL) {
        Dugum *sonraki = bas->sonraki;
        dugum_birak(bas);
        bas = sonraki;
    }
}

static Dugum *liste_olustur(const int *a, int n)
{
    Dugum *bas = NULL, *son = NULL;
    for (int i = 0; i < n; i++) {
        Dugum *d = dugum_olustur(a[i]);
        if (son == NULL) {
            bas = d;
        } else {
            son->sonraki = d;
        }
        son = d;
    }
    return bas;
}

static void liste_yaz(const Dugum *bas)
{
    printf("[");
    for (const Dugum *p = bas; p != NULL; p = p->sonraki) {
        printf("%d -> ", p->veri);
    }
    printf("NULL]");
}

static void deger_yaz(const Dugum *d)
{
    if (d != NULL) {
        printf("%d", d->veri);
    } else {
        printf("NULL");
    }
}

/* Yinelemeli ters çevirme; yeni başı döndürür. Değişmez: onceki, ters
 * çevrilmiş önekin başı; gecerli, henüz işlenmemiş sonekin başı.
 * Her turda: (1) sonraki bağlantıyı kaydet, (2) oku tersine çevir,
 * (3) onceki ve gecerli'yi bir düğüm ilerlet. */
static Dugum *ters_cevir(Dugum *bas)
{
    Dugum *onceki = NULL;
    Dugum *gecerli = bas;
    while (gecerli != NULL) {
        Dugum *sonraki = gecerli->sonraki; /* kaydet */
        gecerli->sonraki = onceki;         /* çevir */
        baglanti_sayisi++;
        onceki = gecerli;                  /* ilerle */
        gecerli = sonraki;
    }
    return onceki;
}

/* Aynı döngü; her adımda üç işaretçi ve iki parça yazdırılır */
static Dugum *ters_cevir_izle(Dugum *bas)
{
    Dugum *onceki = NULL;
    Dugum *gecerli = bas;
    int adim = 0;
    while (gecerli != NULL) {
        Dugum *sonraki = gecerli->sonraki;
        gecerli->sonraki = onceki;
        baglanti_sayisi++;
        printf("  adım %d: sonraki = ", ++adim);
        deger_yaz(sonraki);
        printf(", bağ %d -> ", gecerli->veri);
        deger_yaz(onceki);
        onceki = gecerli;
        gecerli = sonraki;
        printf(", onceki = ");
        deger_yaz(onceki);
        printf(", gecerli = ");
        deger_yaz(gecerli);
        printf("\n          ters: ");
        liste_yaz(onceki);
        printf("  kalan: ");
        liste_yaz(gecerli);
        printf("\n");
    }
    return onceki;
}

/* Özyinelemeli: önce kuyruğu ters çevir, sonra bas'ı onun sonuna tak.
 * Dönüşte bas->sonraki, ters kuyruğun SON düğümüdür. */
static Dugum *ters_cevir_ozyinelemeli(Dugum *bas, int derinlik)
{
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (bas == NULL || bas->sonraki == NULL) {
        return bas;                         /* 0 ya da 1 düğüm */
    }
    Dugum *yeni_bas = ters_cevir_ozyinelemeli(bas->sonraki, derinlik + 1);
    bas->sonraki->sonraki = bas;
    bas->sonraki = NULL;
    baglanti_sayisi += 2;
    return yeni_bas;
}

/* Liste a[n-1..0] ile aynı mı? (kâhin: dizinin tersi) */
static bool ters_mi(const Dugum *bas, const int *a, int n)
{
    int i = n - 1;
    for (const Dugum *p = bas; p != NULL; p = p->sonraki, i--) {
        if (i < 0 || p->veri != a[i]) {
            return false;
        }
    }
    return i == -1;
}

/* Liste a[0..n-1] ile aynı mı? */
static bool ayni_mi(const Dugum *bas, const int *a, int n)
{
    int i = 0;
    for (const Dugum *p = bas; p != NULL; p = p->sonraki, i++) {
        if (i >= n || p->veri != a[i]) {
            return false;
        }
    }
    return i == n;
}

int main(int argc, char *argv[])
{
    if (argc > 1) {   /* isteğe bağlı: derin özyineleme gösterimi */
        char *son;
        long n = strtol(argv[1], &son, 10);
        if (*son != '\0' || n < 1 || n > 100000000) {
            fprintf(stderr, "kullanım: %s [n]\n", argv[0]);
            return 2;
        }
        Dugum *bas = NULL;
        for (long i = 0; i < n; i++) {
            Dugum *d = dugum_olustur((int)(n - i));
            d->sonraki = bas;
            bas = d;
        }
        bas = ters_cevir_ozyinelemeli(bas, 1);
        printf("özyinelemeli ters çevirme, n = %ld: en büyük derinlik = %d, "
               "baş = %d\n", n, en_derin, bas->veri);
        liste_yok_et(bas);
        return 0;
    }
    const int a[5] = {1, 2, 3, 4, 5};

    printf("1) Yinelemeli ters çevirme, adım adım\n  başta: ");
    Dugum *bas = liste_olustur(a, 5);
    liste_yaz(bas);
    printf("\n");
    baglanti_sayisi = 0;
    bas = ters_cevir_izle(bas);
    printf("  sonuç: ");
    liste_yaz(bas);
    printf("  bağlantı yazma = %lld (n)\n", baglanti_sayisi);
    liste_yok_et(bas);

    printf("\n2) Özyinelemeli ters çevirme\n  sonuç: ");
    bas = liste_olustur(a, 5);
    baglanti_sayisi = 0;
    en_derin = 0;
    bas = ters_cevir_ozyinelemeli(bas, 1);
    liste_yaz(bas);
    printf("\n  bağlantı yazma = %lld (2(n - 1)), en büyük derinlik = %d (n)\n",
           baglanti_sayisi, en_derin);
    liste_yok_et(bas);

    printf("\n3) Sınır durumları\n");
    const int tek[1] = {7};
    for (int n = 0; n <= 1; n++) {
        Dugum *l1 = liste_olustur(tek, n);
        Dugum *l2 = liste_olustur(tek, n);
        l1 = ters_cevir(l1);
        l2 = ters_cevir_ozyinelemeli(l2, 1);
        printf("  n = %d: yinelemeli ", n);
        liste_yaz(l1);
        printf(", özyinelemeli ");
        liste_yaz(l2);
        printf("\n");
        liste_yok_et(l1);
        liste_yok_et(l2);
    }

    printf("\n4) Kâhinle sınama (tohum 42, değerler 0..999)\n");
    rastgele_tohum(42);
    static int b[1000];
    rastgele_dizi(b, 1000, 0, 999);
    bas = liste_olustur(b, 1000);
    baglanti_sayisi = 0;
    bas = ters_cevir(bas);
    bool dogru = ters_mi(bas, b, 1000);
    bas = ters_cevir(bas);                 /* iki kez ters = asıl */
    bool geri = ayni_mi(bas, b, 1000);
    printf("  yinelemeli, n = 1000: tersiyle aynı mı? %s; iki kez ters = "
           "asıl mı? %s\n    bağlantı yazma = %lld (2n)\n",
           dogru ? "evet" : "HAYIR", geri ? "evet" : "HAYIR",
           baglanti_sayisi);
    liste_yok_et(bas);
    bas = liste_olustur(b, 500);
    baglanti_sayisi = 0;
    en_derin = 0;
    bas = ters_cevir_ozyinelemeli(bas, 1);
    printf("  özyinelemeli, n = 500: tersiyle aynı mı? %s\n    bağlantı "
           "yazma = %lld (2(n - 1)), en büyük derinlik = %d\n",
           ters_mi(bas, b, 500) ? "evet" : "HAYIR", baglanti_sayisi,
           en_derin);
    liste_yok_et(bas);

    printf("\nbellek: ayrılan = %lld, bırakılan = %lld düğüm\n",
           ayirma_sayisi, birakma_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list::reverse,
 * std::list::reverse; Python — list.reverse() / reversed (dinamik dizide
 * öğe takası; bağlantı yok). */

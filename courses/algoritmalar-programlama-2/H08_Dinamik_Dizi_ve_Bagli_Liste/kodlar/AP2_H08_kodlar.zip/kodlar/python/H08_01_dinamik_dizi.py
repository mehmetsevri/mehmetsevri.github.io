"""H08_01_dinamik_dizi.py — AP-2 Hafta 8 · Örnek 1 (★)
Amaç    : Dinamik dizi ADT'si (dd_olustur, dd_ekle, dd_al, dd_boyut,
          dd_yok_et); kapasite dolunca ikiye katlama ve kapasite izleme
Çalıştır: python3 H08_01_dinamik_dizi.py
Eşleri  : c/H08_01_dinamik_dizi.c · cpp/H08_01_dinamik_dizi.cpp
Çıktı   : üç dilde aynı (=)
"""


class DinamikDizi:
    __slots__ = ("veri", "boyut", "kapasite")


kopya_sayisi = 0    # büyütmede kopyalanan öğe
buyutme_sayisi = 0  # kapasite değişimi


def dd_olustur(ilk_kapasite):
    """Sabit kapasiteli yuva listesi: yerleşik list'in büyümesine
    güvenmeyiz ([None] * kapasite). ilk_kapasite >= 1 olmalı."""
    d = DinamikDizi()
    d.veri = [None] * ilk_kapasite
    d.boyut = 0
    d.kapasite = ilk_kapasite
    return d


def dd_ekle(d, x):
    """x'i sona ekler; doluysa kapasiteyi ikiye katlar (yeni blok + kopya).
    Bellek yetersizse MemoryError: dizi değişmeden geçerli kalır."""
    global kopya_sayisi, buyutme_sayisi
    if d.boyut == d.kapasite:
        yeni_kapasite = 2 * d.kapasite
        yeni = [None] * yeni_kapasite
        for i in range(d.boyut):
            yeni[i] = d.veri[i]
        kopya_sayisi += d.boyut
        buyutme_sayisi += 1
        d.veri = yeni
        d.kapasite = yeni_kapasite
    d.veri[d.boyut] = x
    d.boyut += 1


def dd_al(d, i):
    """Ön koşul yerine denetim: i < boyut ise öğeyi, değilse None döner"""
    if i >= d.boyut:
        return None
    return d.veri[i]


def dd_boyut(d):
    return d.boyut


def dd_yok_et(d):
    """Python'da free yoktur: bloğa başvuruyu bırakırız (başvuru sayımı)"""
    d.veri = None
    d.boyut = 0
    d.kapasite = 0


def al_yaz(d, i):
    x = dd_al(d, i)
    if x is not None:
        print(f"  dd_al({i}) = {x}")
    else:
        print(f"  dd_al({i}): sınır dışı (boyut = {dd_boyut(d)})")


def main():
    global kopya_sayisi
    d = dd_olustur(1)
    print("1) dd_ekle ile 1..20'nin kareleri (ilk kapasite 1, büyütme × 2)")
    print("  ekle    x  boyut  kapasite  kopya  toplam iş  iş/ekleme")
    toplam_is = 0   # yazma (1) + kopya
    for i in range(1, 21):
        eski_kapasite = d.kapasite
        once = kopya_sayisi
        dd_ekle(d, i * i)
        kopya = kopya_sayisi - once
        toplam_is += 1 + kopya
        satir = (f"  {i:4d} {i * i:4d} {dd_boyut(d):6d} {d.kapasite:9d} "
                 f"{kopya:6d} {toplam_is:10d} {toplam_is / i:10.2f}")
        if d.kapasite != eski_kapasite:
            satir += f"  <- büyüdü {eski_kapasite} -> {d.kapasite}"
        print(satir)
    print(f"  toplam kopya = {kopya_sayisi}, ekleme sayısı = {dd_boyut(d)}, "
          f"kopya/ekleme = {kopya_sayisi / dd_boyut(d):.2f}")
    print(f"  boş yuva = {d.kapasite - d.boyut} (kapasite {d.kapasite}, "
          f"boyut {d.boyut})")

    print("\n2) İndisle erişim O(1): dd_al")
    al_yaz(d, 0)
    al_yaz(d, 9)
    al_yaz(d, 19)
    al_yaz(d, 20)

    print("\n3) Büyük n: 10^6 ekleme")
    b = dd_olustur(1)
    kopya_sayisi = 0
    buyutme_once = buyutme_sayisi
    for i in range(1000000):
        dd_ekle(b, i)
    toplam = 0
    for i in range(dd_boyut(b)):
        toplam += dd_al(b, i)
    print(f"  boyut = {dd_boyut(b)}, kapasite = {b.kapasite}, "
          f"büyütme = {buyutme_sayisi - buyutme_once}")
    print(f"  toplam kopya = {kopya_sayisi}, "
          f"kopya/ekleme = {kopya_sayisi / dd_boyut(b):.3f} (< 2)")
    print(f"  öğelerin toplamı = {toplam} (beklenen {999999 * 1000000 // 2})")
    dd_yok_et(b)
    dd_yok_et(d)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle; realloc ile); C++ — std::vector
# (push_back, operator[], size, capacity); Python — list (append, a[i],
# len).

"""H08_09_iki_isaretci.py — AP-2 Hafta 8 · Örnek 9 (★★)
Amaç    : İki işaretçi tekniği: ortadaki düğüm (yavaş–hızlı) ve sondan
          k'ıncı düğüm (k adım önden giden işaretçi); sözleşmeler
Çalıştır: python3 H08_09_iki_isaretci.py
Eşleri  : c/H08_09_iki_isaretci.c · cpp/H08_09_iki_isaretci.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


ayirma_sayisi = 0
birakma_sayisi = 0
ilerletme_sayisi = 0   # p = p.sonraki adımları


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler"""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_yok_et(bas):
    while bas is not None:
        sonraki = bas.sonraki
        dugum_birak(bas)
        bas = sonraki


def onlar_listesi(n):
    """10, 20, ..., 10n değerli n düğümlük liste"""
    bas = None
    for i in range(n, 0, -1):
        d = dugum_olustur(10 * i)
        d.sonraki = bas
        bas = d
    return bas


def ortadaki(bas):
    """Yavaş–hızlı: hızlı iki, yavaş bir adım atar. Sözleşme: n düğümde 0
    tabanlı ⌊n/2⌋ indisli düğüm (çift n'de İKİ ortadan İKİNCİSİ); boşsa
    None. Hızlı sona varınca yavaş ortadadır: tek geçiş."""
    global ilerletme_sayisi
    yavas = hizli = bas
    while hizli is not None and hizli.sonraki is not None:
        yavas = yavas.sonraki
        hizli = hizli.sonraki.sonraki
        ilerletme_sayisi += 3
    return yavas


def ilk_orta(bas):
    """Hızlı bir adım önden başlar: ⌊(n-1)/2⌋ indisli düğüm (çift n'de
    BİRİNCİ orta; birleştirmeli sıralamada ilk yarının sonu, Örnek 12)"""
    global ilerletme_sayisi
    if bas is None:
        return None
    yavas, hizli = bas, bas.sonraki
    ilerletme_sayisi += 1
    while hizli is not None and hizli.sonraki is not None:
        yavas = yavas.sonraki
        hizli = hizli.sonraki.sonraki
        ilerletme_sayisi += 3
    return yavas


def sondan_k(bas, k):
    """Sondan k'ıncı (k = 1: son düğüm). Sözleşme: k < 1 ya da k > n ise
    None. ileri, k adım önden gider; ileri None olunca geri hedeftedir."""
    global ilerletme_sayisi
    if k < 1:
        return None
    ileri = bas
    for _ in range(k):
        if ileri is None:
            return None                  # liste k'dan kısa
        ileri = ileri.sonraki
        ilerletme_sayisi += 1
    geri = bas
    while ileri is not None:
        ileri = ileri.sonraki
        geri = geri.sonraki
        ilerletme_sayisi += 2
    return geri


def uzunluk(bas):
    """Karşılaştırma için iki geçişli sürümler: önce uzunluk, sonra yürüme"""
    global ilerletme_sayisi
    n = 0
    p = bas
    while p is not None:
        n += 1
        ilerletme_sayisi += 1
        p = p.sonraki
    return n


def indisteki(bas, i):
    global ilerletme_sayisi
    p = bas
    for _ in range(i):
        p = p.sonraki
        ilerletme_sayisi += 1
    return p


def hucre(d, indis):
    return "NULL" if d is None else f"{d.veri} ({indis})"


def indis_bul(bas, d):
    """d'nin bas'tan indisi (yoksa -1); 'is': aynı nesne mi?"""
    i = 0
    p = bas
    while p is not None:
        if p is d:
            return i
        p = p.sonraki
        i += 1
    return -1


def main():
    global ilerletme_sayisi
    print("1) Ortadaki düğüm; liste 10, 20, ..., 10n")
    print("  sözleşme: ortadaki -> indis n/2 (çiftte ikinci orta), "
          "ilk_orta -> (n-1)/2")
    print("     n  ortadaki (indis)  ilk_orta (indis)  döngü turu")
    for n in range(8):
        bas = onlar_listesi(n)
        ilerletme_sayisi = 0
        o = ortadaki(bas)
        tur = ilerletme_sayisi // 3
        ilk = ilk_orta(bas)
        print(f"  {n:4d}  {hucre(o, indis_bul(bas, o)):>16}  "
              f"{hucre(ilk, indis_bul(bas, ilk)):>16}  {tur:10d}")
        liste_yok_et(bas)

    print("\n2) Sondan k'ıncı; liste [10 -> 20 -> 30 -> 40 -> 50 -> NULL]")
    print("  sözleşme: k = 1 son düğüm; k < 1 ya da k > n ise NULL")
    bas = onlar_listesi(5)
    for k in range(7):
        ilerletme_sayisi = 0
        d = sondan_k(bas, k)
        print(f"  k = {k}: {hucre(d, indis_bul(bas, d)):<8}  "
              f"ilerletme = {ilerletme_sayisi}")
    liste_yok_et(bas)

    print("\n3) Kâhinle sınama: 500 rastgele liste (n = 0..40, tohum 42), "
          "her k = 0..n+1")
    rastgele_tohum(42)
    uyusmaz = sinama = 0
    for _ in range(500):
        n = rastgele_aralik(0, 40)
        bas = onlar_listesi(n)
        o = ortadaki(bas)
        sinama += 1
        if (n == 0 and o is not None) or \
                (n > 0 and indis_bul(bas, o) != n // 2):
            uyusmaz += 1
        for k in range(n + 2):
            d = sondan_k(bas, k)
            beklenen = n - k if 1 <= k <= n else -1   # kâhin
            sinama += 1
            if (beklenen < 0 and d is not None) or \
                    (beklenen >= 0 and indis_bul(bas, d) != beklenen):
                uyusmaz += 1
        liste_yok_et(bas)
    print(f"  sınama = {sinama}, uyuşmazlık = {uyusmaz}")

    print("\n4) İlerletme sayısı, n = 100000: tek geçiş ve iki geçiş")
    bas = onlar_listesi(100000)
    ilerletme_sayisi = 0
    o1 = ortadaki(bas)
    tek = ilerletme_sayisi
    ilerletme_sayisi = 0
    o2 = indisteki(bas, uzunluk(bas) // 2)
    print(f"  ortadaki : yavaş–hızlı = {tek}, iki geçiş = {ilerletme_sayisi}; "
          f"aynı düğüm? {'evet' if o1 is o2 else 'HAYIR'}")
    ilerletme_sayisi = 0
    s1 = sondan_k(bas, 10)
    tek = ilerletme_sayisi
    ilerletme_sayisi = 0
    s2 = indisteki(bas, uzunluk(bas) - 10)
    print(f"  sondan 10: iki işaretçi = {tek}, iki geçiş = {ilerletme_sayisi}"
          f"; aynı düğüm? {'evet' if s1 is s2 else 'HAYIR'}")
    print("  (ilerletme: bir işaretçiyi bir düğüm ileri taşımak) İş aynıdır;"
          "\n  kazanç: uzunluğu ayrıca hesaplamadan tek döngüde sonuç")
    liste_yok_et(bas)

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::next(it, n / 2),
# std::prev(l.end(), k) (std::list, çift yönlü yineleyici); Python —
# yerleşik bağlı liste yok (dizide a[len(a) // 2], a[-k]).

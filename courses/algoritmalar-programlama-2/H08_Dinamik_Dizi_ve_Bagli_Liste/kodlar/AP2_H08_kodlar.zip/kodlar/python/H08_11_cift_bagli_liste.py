"""H08_11_cift_bagli_liste.py — AP-2 Hafta 8 · Örnek 11 (★★)
Amaç    : Kukla düğümlü dairesel çift bağlı liste: adresi bilinen düğümü
          O(1) silme, ileri ve geri dolaşma; tek bağlı listeyle kıyas
Çalıştır: python3 H08_11_cift_bagli_liste.py
Eşleri  : c/H08_11_cift_bagli_liste.c · cpp/H08_11_cift_bagli_liste.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_karistir, rastgele_tohum


class CDugum:
    __slots__ = ("veri", "onceki", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.onceki = None
        self.sonraki = None


class Dugum:
    """Karşılaştırma için tek bağlı düğüm"""
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


class CiftListe:
    """Dairesel, kukla düğümlü: kukla.sonraki = ilk, kukla.onceki = son;
    boş listede ikisi de kuklanın kendisidir. Hiçbir bağlantı None değil."""
    __slots__ = ("kukla", "uzunluk")

    def __init__(self):
        self.kukla = CDugum(0)          # veri taşımaz
        self.kukla.onceki = self.kukla
        self.kukla.sonraki = self.kukla
        self.uzunluk = 0


ayirma_sayisi = 0
birakma_sayisi = 0
baglanti_sayisi = 0
ziyaret_sayisi = 0


def once_ekle(liste, konum, x):
    """Yeni düğümü konum'un ÖNÜNE ekler: dört bağlantı, özel durum yok.
    Dönen düğüm yalnızca bir 'tutamaktır'."""
    global ayirma_sayisi, baglanti_sayisi
    d = CDugum(x)
    ayirma_sayisi += 1
    d.sonraki = konum
    d.onceki = konum.onceki
    konum.onceki.sonraki = d
    konum.onceki = d
    baglanti_sayisi += 4
    liste.uzunluk += 1
    return d


def sona_ekle(liste, x):
    return once_ekle(liste, liste.kukla, x)    # kuklanın önü = son


def basa_ekle(liste, x):
    return once_ekle(liste, liste.kukla.sonraki, x)


def dugumu_sil(liste, d):
    """Adresi bilinen düğümü O(1) siler: iki bağlantı, yürüme yok, baş/son
    için özel durum yok (komşular her zaman vardır: en kötü kukla)."""
    global baglanti_sayisi, birakma_sayisi
    d.onceki.sonraki = d.sonraki
    d.sonraki.onceki = d.onceki
    baglanti_sayisi += 2
    liste.uzunluk -= 1
    birakma_sayisi += 1     # free yok; yalnız sayaç


def cl_yok_et(liste):
    """Döngüsel yapıdır (kukla <-> düğümler): başvuruları açıkça koparırız
    ki başvuru sayımı (gc beklemeden) geri alabilsin."""
    global birakma_sayisi
    d = liste.kukla.sonraki
    while d is not liste.kukla:
        sonraki = d.sonraki
        d.onceki = d.sonraki = None
        birakma_sayisi += 1
        d = sonraki
    liste.kukla.onceki = liste.kukla.sonraki = liste.kukla
    liste.uzunluk = 0


def ileri_yaz(liste):
    parcalar = []
    d = liste.kukla.sonraki
    while d is not liste.kukla:
        parcalar.append(str(d.veri))
        d = d.sonraki
    print("  ileri: " + (" <-> ".join(parcalar) if parcalar else "(boş)"))


def geri_yaz(liste):
    parcalar = []
    d = liste.kukla.onceki
    while d is not liste.kukla:
        parcalar.append(str(d.veri))
        d = d.onceki
    print("  geri : " + (" <-> ".join(parcalar) if parcalar else "(boş)"))


def tutarli_mi(liste):
    """Değişmez: her düğüm için d.sonraki.onceki is d; iki yönde de sayım
    uzunluğa eşit"""
    ileri = geri = 0
    d = liste.kukla
    while True:
        if d.sonraki.onceki is not d:
            return False
        d = d.sonraki
        ileri += 1
        if d is liste.kukla:
            break
    d = liste.kukla.onceki
    while d is not liste.kukla:
        geri += 1
        d = d.onceki
    return ileri - 1 == liste.uzunluk and geri == liste.uzunluk


def tek_sil_adresle(bas, hedef):
    """Tek bağlı listede adresi bilinen düğümü silmek: önce ÖNCEKİSİ
    bulunmalı (kukla düğümle baştan yürüyerek): Θ(konum) ziyaret.
    Yeni başı döndürür."""
    global ziyaret_sayisi, baglanti_sayisi, birakma_sayisi
    kukla = Dugum(0)
    kukla.sonraki = bas
    onceki = kukla
    while onceki.sonraki is not hedef:
        onceki = onceki.sonraki
        ziyaret_sayisi += 1
    onceki.sonraki = hedef.sonraki
    baglanti_sayisi += 1
    birakma_sayisi += 1
    return kukla.sonraki


def durum_yaz(liste, b0):
    ileri_yaz(liste)
    geri_yaz(liste)
    print(f"  uzunluk = {liste.uzunluk}, bağlantı yazma = "
          f"{baglanti_sayisi - b0}, tutarlı mı? "
          f"{'evet' if tutarli_mi(liste) else 'HAYIR'}")


def main():
    global ayirma_sayisi, baglanti_sayisi, ziyaret_sayisi
    liste = CiftListe()
    print("1) Kurma: sona_ekle 1, 4, 5, 9; basa_ekle 2")
    b0 = baglanti_sayisi
    sona_ekle(liste, 1)
    sona_ekle(liste, 4)
    bes = sona_ekle(liste, 5)            # tutamak: başvuru saklanır
    sona_ekle(liste, 9)
    basa_ekle(liste, 2)
    durum_yaz(liste, b0)

    print("\n2) Adresi bilinen düğümleri O(1) silme (yürüme yok)")
    print("  sil 5 (ortadan, tutamakla):")
    b0 = baglanti_sayisi
    dugumu_sil(liste, bes)
    durum_yaz(liste, b0)
    print("  sil ilk (kukla.sonraki):")
    b0 = baglanti_sayisi
    dugumu_sil(liste, liste.kukla.sonraki)
    durum_yaz(liste, b0)
    print("  sil son (kukla.onceki):")
    b0 = baglanti_sayisi
    dugumu_sil(liste, liste.kukla.onceki)
    durum_yaz(liste, b0)

    print("\n3) Kalanları sil: boş liste kukla'yı kendine bağlar")
    while liste.uzunluk > 0:
        dugumu_sil(liste, liste.kukla.sonraki)
    ileri_yaz(liste)
    print(f"  kukla.sonraki == kukla mı? "
          f"{'evet' if liste.kukla.sonraki is liste.kukla else 'HAYIR'}, "
          f"kukla.onceki == kukla mı? "
          f"{'evet' if liste.kukla.onceki is liste.kukla else 'HAYIR'}")
    print(f"  tutarlı mı? {'evet' if tutarli_mi(liste) else 'HAYIR'}")

    print("\n4) n = 1000 düğümü rastgele sırayla adresle silme (tohum 42)")
    n = 1000
    cift_adres = [None] * n
    tek_adres = [None] * n
    sira = list(range(n))
    tek_bas = tek_son = None
    for i in range(n):
        cift_adres[i] = sona_ekle(liste, i)
        d = Dugum(i)
        ayirma_sayisi += 1
        if tek_son is None:
            tek_bas = d
        else:
            tek_son.sonraki = d
        tek_son = d
        tek_adres[i] = d
    rastgele_tohum(42)
    rastgele_karistir(sira)
    baglanti_sayisi = 0
    ziyaret_sayisi = 0
    for i in range(n):
        dugumu_sil(liste, cift_adres[sira[i]])
    print(f"  çift bağlı: ziyaret = {ziyaret_sayisi}, bağlantı yazma = "
          f"{baglanti_sayisi} (2n), tutarlı mı? "
          f"{'evet' if tutarli_mi(liste) else 'HAYIR'}")
    baglanti_sayisi = 0
    for i in range(n):
        tek_bas = tek_sil_adresle(tek_bas, tek_adres[sira[i]])
    print(f"  tek bağlı : ziyaret = {ziyaret_sayisi} (n²/4 ≈ {n * n // 4}), "
          f"bağlantı yazma = {baglanti_sayisi}")
    print("  bedel: çift bağlı düğümde ikinci bağlantı alanı (onceki)")
    cl_yok_et(liste)

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::list (çift bağlı;
# erase(yineleyici) O(1)); Python — collections.deque (bloklardan oluşan
# iki uçlu yapı; ortadan silme O(n)).

"""H08_08_sirali_birlestirme.py — AP-2 Hafta 8 · Örnek 8 (★★)
Amaç    : İki sıralı listeyi kukla düğümle birleştirme: düğümler yeniden
          bağlanır (yeni düğüm yok), kararlı, Θ(n + m); kâhinle sınama
Çalıştır: python3 H08_08_sirali_birlestirme.py
Eşleri  : c/H08_08_sirali_birlestirme.c · cpp/H08_08_sirali_birlestirme.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "kimlik", "sonraki")

    def __init__(self, veri, kimlik):
        self.veri = veri
        self.kimlik = kimlik   # oluşturulma sırası (kararlılık denetimi)
        self.sonraki = None


ayirma_sayisi = 0
birakma_sayisi = 0
karsilastirma_sayisi = 0
baglanti_sayisi = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri, ayirma_sayisi)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler"""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_yok_et(bas):
    while bas is not None:
        sonraki = bas.sonraki
        dugum_birak(bas)
        bas = sonraki


def liste_olustur(a, n):
    bas = son = None
    for i in range(n):
        d = dugum_olustur(a[i])
        if son is None:
            bas = d
        else:
            son.sonraki = d
        son = d
    return bas


def liste_metni(bas, kimlikli):
    parcalar = []
    p = bas
    while p is not None:
        if kimlikli:
            parcalar.append(f"{p.veri}#{p.kimlik} -> ")
        else:
            parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    return "[" + "".join(parcalar) + "NULL]"


def birlestir(a, b):
    """İki sıralı listeyi düğümleri YENİDEN BAĞLAYARAK birleştirir; yeni
    düğüm oluşturulmaz. Kararlı: eşitlikte a'dan gelen önce (<=). a ve b'nin
    düğümleri dönen listeye geçer; çağıran a ve b'yi artık kullanmaz."""
    global karsilastirma_sayisi, baglanti_sayisi
    kukla = Dugum(0, 0)            # geçici; listeye ait değil
    son = kukla                    # sonucun son düğümü
    while a is not None and b is not None:
        karsilastirma_sayisi += 1
        if a.veri <= b.veri:
            son.sonraki = a
            a = a.sonraki
        else:
            son.sonraki = b
            b = b.sonraki
        baglanti_sayisi += 1
        son = son.sonraki
    son.sonraki = a if a is not None else b   # kalan kuyruk tek bağlantıyla
    baglanti_sayisi += 1
    return kukla.sonraki


def birlestir_izle(a, b):
    """Aynı döngü; her adım yazdırılarak"""
    global karsilastirma_sayisi, baglanti_sayisi
    kukla = Dugum(0, 0)
    son = kukla
    adim = 0
    while a is not None and b is not None:
        adim += 1
        satir = f"  adım {adim}: a.baş = {a.veri}, b.baş = {b.veri} -> "
        karsilastirma_sayisi += 1
        if a.veri <= b.veri:
            print(satir + f"{a.veri} (a)")
            son.sonraki = a
            a = a.sonraki
        else:
            print(satir + f"{b.veri} (b)")
            son.sonraki = b
            b = b.sonraki
        baglanti_sayisi += 1
        son = son.sonraki
    son.sonraki = a if a is not None else b
    baglanti_sayisi += 1
    print(f"  kalan kuyruk ({'a' if a is not None else 'b'}) tek "
          f"bağlantıyla eklendi: {liste_metni(son.sonraki, False)}")
    return kukla.sonraki


def sirali_dizi(n, en_cok_artis):
    """n öğe: rastgele artışlarla sıralı dizi (sıralama gerekmez)"""
    x = [0] * n
    deger = rastgele_aralik(0, 3)
    for i in range(n):
        x[i] = deger
        deger += rastgele_aralik(0, en_cok_artis)
    return x


def main():
    global karsilastirma_sayisi, baglanti_sayisi
    print("1) Kukla düğümle birleştirme")
    a = liste_olustur([1, 3, 5, 7], 4)
    b = liste_olustur([2, 3, 5, 8, 9], 5)
    print(f"  a = {liste_metni(a, False)}\n  b = {liste_metni(b, False)}")
    a0 = ayirma_sayisi
    c = birlestir_izle(a, b)
    a = b = None                  # düğümler artık c'nin
    print(f"  c = {liste_metni(c, False)}")
    print(f"  karşılaştırma = {karsilastirma_sayisi}, bağlantı yazma = "
          f"{baglanti_sayisi}, yeni düğüm = {ayirma_sayisi - a0}")

    print("\n2) Kararlılık: veri#kimlik (a'nın düğümleri 1-4, b'ninkiler "
          "5-9)")
    print(f"  c = {liste_metni(c, True)}")
    kararli = True
    p = c
    while p is not None and p.sonraki is not None:
        if p.veri == p.sonraki.veri and p.kimlik > p.sonraki.kimlik:
            kararli = False
        p = p.sonraki
    print(f"  eşit anahtarlarda a'dan gelen önce mi? "
          f"{'evet' if kararli else 'HAYIR'}")
    liste_yok_et(c)

    print("\n3) Sınır durumları")
    sol = [[], [], [1, 2], [5]]
    sag = [[], [1, 2], [], [1, 2, 3]]
    for t in range(4):
        x = liste_olustur(sol[t], len(sol[t]))
        y = liste_olustur(sag[t], len(sag[t]))
        satir = f"  {liste_metni(x, False)} + {liste_metni(y, False)}"
        z = birlestir(x, y)
        print(satir + f" = {liste_metni(z, False)}")
        liste_yok_et(z)

    print("\n4) Kâhinle 1000 rastgele sınama (uzunluk 0..20, tohum 42)")
    rastgele_tohum(42)
    dogru = kararli_sayisi = yeni = 0
    for _ in range(1000):
        n = rastgele_aralik(0, 20)
        m = rastgele_aralik(0, 20)
        x = sirali_dizi(n, 3)
        y = sirali_dizi(m, 3)
        kahin = sorted(x + y)                     # yalnızca kâhin
        p = liste_olustur(x, n)
        q = liste_olustur(y, m)
        a0 = ayirma_sayisi
        z = birlestir(p, q)
        yeni += ayirma_sayisi - a0
        i = 0
        ayni = k = True
        d = z
        while d is not None:
            ayni = ayni and i < n + m and d.veri == kahin[i]
            if (d.sonraki is not None and d.veri == d.sonraki.veri
                    and d.kimlik > d.sonraki.kimlik):
                k = False
            d = d.sonraki
            i += 1
        dogru += ayni and i == n + m
        kararli_sayisi += k
        liste_yok_et(z)
    print(f"  kâhinle aynı: {dogru}/1000, kararlı: {kararli_sayisi}/1000, "
          f"birleştirmede yeni düğüm: {yeni}")

    print("\n5) Maliyet Θ(n + m): n = m = 100000 (artışlar 0..9)")
    x = sirali_dizi(100000, 9)
    y = sirali_dizi(100000, 9)
    a = liste_olustur(x, 100000)
    b = liste_olustur(y, 100000)
    karsilastirma_sayisi = baglanti_sayisi = 0
    c = birlestir(a, b)
    print(f"  karşılaştırma = {karsilastirma_sayisi} (<= n + m - 1 = 199999), "
          f"bağlantı yazma = {baglanti_sayisi}")
    liste_yok_et(c)

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::list::merge,
# std::forward_list::merge (düğümleri taşır; kararlı), std::merge
# (dizilerde); Python — heapq.merge (yineleyici), sorted(a + b).

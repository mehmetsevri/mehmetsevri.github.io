"""H08_05_degere_gore_silme.py — AP-2 Hafta 8 · Örnek 5 (★★)
Amaç    : Değere göre silme: önce baş için özel durumlu sürüm (önceki–
          gecerli), sonra kukla düğümle özel durumsuz sürüm; tümünü silme
Çalıştır: python3 H08_05_degere_gore_silme.py
Eşleri  : c/H08_05_degere_gore_silme.c · cpp/H08_05_degere_gore_silme.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


ayirma_sayisi = 0
birakma_sayisi = 0
ziyaret_sayisi = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler"""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_yok_et(bas):
    while bas is not None:
        sonraki = bas.sonraki
        dugum_birak(bas)
        bas = sonraki


def liste_olustur(a):
    """a'dan sırayla liste kurar ve başını döndürür"""
    bas = son = None
    for x in a:
        d = dugum_olustur(x)
        if son is None:
            bas = d
        else:
            son.sonraki = d
        son = d
    return bas


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]", end="")


def aranan_mi(d, x):
    """Ziyaret sayacı: bir düğümün verisine bakıldı"""
    global ziyaret_sayisi
    ziyaret_sayisi += 1
    return d.veri == x


def sil_v1(bas, x):
    """Sürüm 1 (özel durumlu): önceki–gecerli ile ilk x'i siler ve YENİ
    BAŞI döndürür. Baş siliniyorsa ayrı bir dal gerekir."""
    onceki = None
    gecerli = bas
    while gecerli is not None and not aranan_mi(gecerli, x):
        onceki = gecerli
        gecerli = gecerli.sonraki
    if gecerli is None:
        return bas                          # x yok: liste aynı
    if onceki is None:
        bas = gecerli.sonraki               # ÖZEL DURUM: baş siliniyor
    else:
        onceki.sonraki = gecerli.sonraki    # ortadaki ya da son düğüm
    dugum_birak(gecerli)
    return bas


def sil_v2(bas, x):
    """Sürüm 2 (kukla düğüm): Python'da işaretçiye işaretçi yoktur ve
    çağıranın değişkeni değiştirilemez. Başın önüne geçici bir kukla düğüm
    koyarız: her düğümün bir 'öncekisi' olur, özel durum kalmaz.
    (yeni_bas, silindi_mi) döner."""
    kukla = Dugum(0)
    kukla.sonraki = bas
    onceki = kukla
    while onceki.sonraki is not None and not aranan_mi(onceki.sonraki, x):
        onceki = onceki.sonraki
    if onceki.sonraki is None:
        return kukla.sonraki, False
    silinen = onceki.sonraki
    onceki.sonraki = silinen.sonraki  # baş da aynı
    dugum_birak(silinen)
    return kukla.sonraki, True


def tumunu_sil(bas, x):
    """Tüm x'leri siler (kukla düğümle); (yeni_bas, silinen sayısı) döner"""
    silinen_sayisi = 0
    kukla = Dugum(0)
    kukla.sonraki = bas
    onceki = kukla
    while onceki.sonraki is not None:
        if aranan_mi(onceki.sonraki, x):
            silinen = onceki.sonraki
            onceki.sonraki = silinen.sonraki  # onceki ilerlemez
            dugum_birak(silinen)
            silinen_sayisi += 1
        else:
            onceki = onceki.sonraki
    return kukla.sonraki, silinen_sayisi


def sonuc_yaz(etiket, bas, b0):
    print(f"  {etiket} ", end="")
    liste_yaz(bas)
    durum = "silindi" if birakma_sayisi > b0 else "yok"
    print(f"  {durum}, ziyaret = {ziyaret_sayisi}")


def main():
    global ziyaret_sayisi
    a = [3, 1, 4, 1, 5, 9, 2, 6]
    silinecek = [3, 1, 6, 7]
    etiket = ["sil 3 (baş) :", "sil 1 (ilk) :", "sil 6 (son) :",
              "sil 7 (yok) :"]

    print("1) Sürüm 1 (özel durumlu, yeni başı döndürür)\n  başta       : ",
          end="")
    bas = liste_olustur(a)
    liste_yaz(bas)
    print()
    for i in range(4):
        b0 = birakma_sayisi
        ziyaret_sayisi = 0
        bas = sil_v1(bas, silinecek[i])
        sonuc_yaz(etiket[i], bas, b0)
    liste_yok_et(bas)

    print("\n2) Sürüm 2 (özel durumsuz; C/C++: Dugum **, Python: kukla "
          "düğüm)\n  başta       : ", end="")
    bas = liste_olustur(a)
    liste_yaz(bas)
    print()
    for i in range(4):
        b0 = birakma_sayisi
        ziyaret_sayisi = 0
        bas, _ = sil_v2(bas, silinecek[i])
        sonuc_yaz(etiket[i], bas, b0)
    liste_yok_et(bas)

    print("\n3) Sınır durumları (iki sürüm aynı sonucu verir)")
    for surum in (1, 2):
        x = [5, 8, 8]
        et = ["tek düğüm, sil 5 :", "tek düğüm, sil 8 :",
              "boş liste, sil 8 :"]
        bas = liste_olustur([8])
        print(f"  sürüm {surum}")
        for i in range(3):
            b0 = birakma_sayisi
            ziyaret_sayisi = 0
            if surum == 1:
                bas = sil_v1(bas, x[i])
            else:
                bas, _ = sil_v2(bas, x[i])
            sonuc_yaz(et[i], bas, b0)
        liste_yok_et(bas)

    print("\n4) Tüm 1'leri silme (ardışık ve baştaki 1'ler)")
    bas = liste_olustur([1, 1, 2, 1, 3, 1, 1])
    print("  başta : ", end="")
    liste_yaz(bas)
    ziyaret_sayisi = 0
    bas, k = tumunu_sil(bas, 1)
    print("\n  sonra : ", end="")
    liste_yaz(bas)
    print(f"  silinen = {k}, ziyaret = {ziyaret_sayisi}")
    liste_yok_et(bas)

    print("\n5) 1000 rastgele sınama (n = 0..10, değerler 0..5, tohum 42)")
    rastgele_tohum(42)
    ayni = ziyaret_ayni = 0
    for _ in range(1000):
        n = rastgele_aralik(0, 10)
        dizi = [0] * n
        for i in range(n):
            dizi[i] = rastgele_aralik(0, 5)
        x = rastgele_aralik(0, 5)
        l1 = liste_olustur(dizi)
        l2 = liste_olustur(dizi)
        ziyaret_sayisi = 0
        l1 = sil_v1(l1, x)
        z1 = ziyaret_sayisi
        ziyaret_sayisi = 0
        l2, _ = sil_v2(l2, x)
        esit = True
        p, q = l1, l2
        while p is not None and q is not None:
            esit = esit and p.veri == q.veri
            p = p.sonraki
            q = q.sonraki
        ayni += esit and p is None and q is None
        ziyaret_ayni += z1 == ziyaret_sayisi
        liste_yok_et(l1)
        liste_yok_et(l2)
    print(f"  sonuç listeleri aynı: {ayni}/1000, ziyaret sayıları aynı: "
          f"{ziyaret_ayni}/1000")

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list::remove
# (tüm eşleşenler), std::list::remove; Python — list.remove(x) (ilk
# eşleşen; dinamik dizide Θ(n) kaydırma).

"""H08_02_buyume_stratejisi.py — AP-2 Hafta 8 · Örnek 2 (★★)
Amaç    : Büyüme stratejisine göre toplam kopya sayısı (+1, +10, × 1,5,
          × 2): amortize analizde toplam yöntemi ve kapalı biçimler
Çalıştır: python3 H08_02_buyume_stratejisi.py
Eşleri  : c/H08_02_buyume_stratejisi.c · cpp/H08_02_buyume_stratejisi.cpp
Çıktı   : üç dilde aynı (=)
"""

STRATEJI_SAYISI = 4
# Adlar 8 karakterlik doldurulmuş dizgiler: C'de printf genişliği bayt
# sayar, "×" UTF-8'de 2 bayttır; hizalama üç dilde aynı kalsın
AD = ["+1      ", "+10     ", "× 1,5   ", "× 2     "]


def yeni_kapasite(strateji, k):
    """Kapasite k doluyken yeni kapasite. × 1,5'te tamsayı yuvarlaması üç
    dilde aynı tanımlıdır: k + (k + 1) // 2, yani ⌈1,5 k⌉ (k = 1 → 2)."""
    if strateji == 0:
        return k + 1
    if strateji == 1:
        return k + 10
    if strateji == 2:
        return k + (k + 1) // 2
    return 2 * k


class Sonuc:
    __slots__ = ("kopya", "buyutme", "kapasite")

    def __init__(self):
        self.kopya = 0      # büyütmelerde kopyalanan öğe toplamı
        self.buyutme = 0    # kapasite değişimi sayısı
        self.kapasite = 1   # n eklemeden sonraki kapasite


def benzet(strateji, n):
    """n sona eklemenin benzetimi (ilk kapasite 1): dolu dizide büyütme,
    boyut kadar öğeyi yeni bloğa kopyalar. Toplam yöntemi: Σ kopya."""
    s = Sonuc()
    for boyut in range(n):  # ekleme öncesi
        if boyut == s.kapasite:
            s.kopya += boyut
            s.kapasite = yeni_kapasite(strateji, s.kapasite)
            s.buyutme += 1
    return s


def arti_k_kapali(n, k):
    """+k için kapalı biçim: kapasiteler 1, 1 + k, 1 + 2k, ...; n - 1'i
    aşmayan m tanesinde büyütülür: Σ (1 + jk) = m + k m (m - 1) / 2"""
    if n < 2:
        return 0
    m = (n - 2) // k + 1
    return m + k * m * (m - 1) // 2


def kat_2_kapali(n):
    """× 2 için kapalı biçim: 1 + 2 + 4 + ... + 2^(m-1) = 2^m - 1;
    m = ⌊log2(n - 1)⌋ + 1 (n - 1'i aşmayan ikinin kuvvetleri)"""
    if n < 2:
        return 0
    kuvvet = 1
    while kuvvet <= n - 1:
        kuvvet *= 2
    return kuvvet - 1


def zaman_cizelgesi(strateji, n):
    kapasiteler = []
    kapasite = 1
    kapasiteler.append(kapasite)
    for boyut in range(n):
        if boyut == kapasite:
            kapasite = yeni_kapasite(strateji, kapasite)
            kapasiteler.append(kapasite)
    s = benzet(strateji, n)
    m = len(kapasiteler)
    satir = "  " + AD[strateji] + ":"
    i = 0
    while i < m:
        if m > 8 and i == 4:
            satir += " -> ..."
            i = m - 2
            continue
        satir += (" " if i == 0 else " -> ") + str(kapasiteler[i])
        i += 1
    print(satir + f"  ({s.buyutme} büyütme, {s.kopya} kopya)")


class DinamikDizi:
    """Gerçek dinamik dizi: büyütmede yeni blok + öğe öğe kopya (sayılır)"""
    __slots__ = ("veri", "boyut", "kapasite")


gercek_kopya = 0


def dd_ekle(d, x, strateji):
    global gercek_kopya
    if d.boyut == d.kapasite:
        yeni = yeni_kapasite(strateji, d.kapasite)
        blok = [None] * yeni
        for i in range(d.boyut):
            blok[i] = d.veri[i]
            gercek_kopya += 1
        d.veri = blok
        d.kapasite = yeni
    d.veri[d.boyut] = x
    d.boyut += 1


def main():
    global gercek_kopya
    print("1) Kapasite zaman çizelgesi: n = 20 ekleme, ilk kapasite 1")
    for s in range(STRATEJI_SAYISI):
        zaman_cizelgesi(s, 20)

    print("\n2) Toplam yöntemi: n sona eklemede toplam kopya")
    print("  strateji       n büyüt.       kopya   kopya/n "
          "kapalı biçim   oran kuram")
    nler = (1000, 10000, 100000)
    for s in range(STRATEJI_SAYISI):
        for n in nler:
            r = benzet(s, n)
            kapali = -1
            if s <= 1:     # kuram: kestirim (+k) ya da üst sınır
                k = 1 if s == 0 else 10
                kapali = arti_k_kapali(n, k)
                kuram = n * n / (2.0 * k)
                ad = "(n²/2k)"
            elif s == 2:
                kuram = 3.0 * n
                ad = "(<3n)"
            else:
                kapali = kat_2_kapali(n)
                kuram = 2.0 * n
                ad = "(<2n)"
            satir = (f"  {AD[s]} {n:7d} {r.buyutme:6d} {r.kopya:11d} "
                     f"{r.kopya / n:9.3f} ")
            if kapali >= 0:
                satir += f"{kapali:10d} " + ("=" if kapali == r.kopya
                                             else "!")
            else:
                satir += "           —"
            satir += f" {r.kopya / kuram:6.3f} {ad}"
            print(satir)

    print("\n3) Gerçek dinamik dizi (öğe öğe kopya) ile benzetim, n = 1000")
    for s in range(STRATEJI_SAYISI):
        d = DinamikDizi()
        d.veri = [None] * 1
        d.boyut = 0
        d.kapasite = 1
        gercek_kopya = 0
        toplam = 0
        for i in range(1000):
            dd_ekle(d, i, s)
        for i in range(d.boyut):
            toplam += d.veri[i]
        r = benzet(s, 1000)
        print(f"  {AD[s]}: gerçek = {gercek_kopya:6d}, benzetim = "
              f"{r.kopya:6d}, aynı mı? "
              f"{'evet' if gercek_kopya == r.kopya else 'HAYIR'}; "
              f"toplam = {toplam}")

    print("\n4) Ödünleşim: n = 100000'de boş yuva (bellek israfı)")
    print("  strateji   kapasite  boş yuva  boş/kapasite")
    for s in range(STRATEJI_SAYISI):
        r = benzet(s, 100000)
        bos = r.kapasite - 100000
        print(f"  {AD[s]} {r.kapasite:10d} {bos:9d} {bos / r.kapasite:13.3f}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::vector büyüme çarpanı
# gerçekleştirime bağlıdır (capacity() ile gözlenir); Python — list
# fazladan ayırır (Objects/listobject.c; sys.getsizeof ile gözlenir).

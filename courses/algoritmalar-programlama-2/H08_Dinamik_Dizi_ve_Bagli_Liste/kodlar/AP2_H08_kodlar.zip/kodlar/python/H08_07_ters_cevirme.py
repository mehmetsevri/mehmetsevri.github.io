"""H08_07_ters_cevirme.py — AP-2 Hafta 8 · Örnek 7 (★★)
Amaç    : Listeyi ters çevirme: yinelemeli (onceki–gecerli–sonraki
          üçlüsü, O(1) ek bellek) ve özyinelemeli (derinlik n)
Çalıştır: python3 H08_07_ters_cevirme.py [n]   (n: özyinelemeli, n düğüm)
Eşleri  : c/H08_07_ters_cevirme.c · cpp/H08_07_ters_cevirme.cpp
Çıktı   : üç dilde aynı (=) (argümanlı çalıştırma dile özgüdür)
"""
import sys

from ortak_rastgele import rastgele_dizi, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


ayirma_sayisi = 0
birakma_sayisi = 0
baglanti_sayisi = 0
en_derin = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler"""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_yok_et(bas):
    while bas is not None:
        sonraki = bas.sonraki
        dugum_birak(bas)
        bas = sonraki


def liste_olustur(a, n):
    bas = son = None
    for i in range(n):
        d = dugum_olustur(a[i])
        if son is None:
            bas = d
        else:
            son.sonraki = d
        son = d
    return bas


def liste_metni(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    return "[" + "".join(parcalar) + "NULL]"


def deger_metni(d):
    return str(d.veri) if d is not None else "NULL"


def ters_cevir(bas):
    """Yinelemeli ters çevirme; yeni başı döndürür. Değişmez: onceki, ters
    çevrilmiş önekin başı; gecerli, henüz işlenmemiş sonekin başı.
    Her turda: (1) sonraki bağlantıyı kaydet, (2) oku tersine çevir,
    (3) onceki ve gecerli'yi bir düğüm ilerlet."""
    global baglanti_sayisi
    onceki = None
    gecerli = bas
    while gecerli is not None:
        sonraki = gecerli.sonraki   # kaydet
        gecerli.sonraki = onceki    # çevir
        baglanti_sayisi += 1
        onceki = gecerli            # ilerle
        gecerli = sonraki
    return onceki


def ters_cevir_izle(bas):
    """Aynı döngü; her adımda üç işaretçi ve iki parça yazdırılır"""
    global baglanti_sayisi
    onceki = None
    gecerli = bas
    adim = 0
    while gecerli is not None:
        sonraki = gecerli.sonraki
        gecerli.sonraki = onceki
        baglanti_sayisi += 1
        adim += 1
        satir = (f"  adım {adim}: sonraki = {deger_metni(sonraki)}, "
                 f"bağ {gecerli.veri} -> {deger_metni(onceki)}")
        onceki = gecerli
        gecerli = sonraki
        print(satir + f", onceki = {deger_metni(onceki)}, "
              f"gecerli = {deger_metni(gecerli)}")
        print(f"          ters: {liste_metni(onceki)}  "
              f"kalan: {liste_metni(gecerli)}")
    return onceki


def ters_cevir_ozyinelemeli(bas, derinlik):
    """Önce kuyruğu ters çevir, sonra bas'ı onun sonuna tak. Dönüşte
    bas.sonraki, ters kuyruğun SON düğümüdür."""
    global baglanti_sayisi, en_derin
    if derinlik > en_derin:
        en_derin = derinlik
    if bas is None or bas.sonraki is None:
        return bas                          # 0 ya da 1 düğüm
    yeni_bas = ters_cevir_ozyinelemeli(bas.sonraki, derinlik + 1)
    bas.sonraki.sonraki = bas
    bas.sonraki = None
    baglanti_sayisi += 2
    return yeni_bas


def ters_mi(bas, a, n):
    """Liste a[n-1..0] ile aynı mı? (kâhin: dizinin tersi)"""
    i = n - 1
    p = bas
    while p is not None:
        if i < 0 or p.veri != a[i]:
            return False
        p = p.sonraki
        i -= 1
    return i == -1


def ayni_mi(bas, a, n):
    """Liste a[0..n-1] ile aynı mı?"""
    i = 0
    p = bas
    while p is not None:
        if i >= n or p.veri != a[i]:
            return False
        p = p.sonraki
        i += 1
    return i == n


def derin_ozyineleme(n):
    """İsteğe bağlı gösterim: Python'un özyineleme sınırı"""
    bas = None
    for i in range(n):
        d = dugum_olustur(n - i)
        d.sonraki = bas
        bas = d
    try:
        bas = ters_cevir_ozyinelemeli(bas, 1)
        print(f"özyinelemeli ters çevirme, n = {n}: en büyük derinlik = "
              f"{en_derin}, baş = {bas.veri}")
    except RecursionError as e:
        print(f"özyinelemeli ters çevirme, n = {n}: RecursionError ({e}); "
              f"sys.getrecursionlimit() = {sys.getrecursionlimit()}")


def main():
    global baglanti_sayisi, en_derin
    if len(sys.argv) > 1:   # isteğe bağlı: derin özyineleme gösterimi
        try:
            n = int(sys.argv[1])
            if n < 1 or n > 100000000:
                raise ValueError
        except ValueError:
            print(f"kullanım: {sys.argv[0]} [n]", file=sys.stderr)
            sys.exit(2)
        derin_ozyineleme(n)
        return
    a = [1, 2, 3, 4, 5]

    bas = liste_olustur(a, 5)
    print("1) Yinelemeli ters çevirme, adım adım\n  başta: "
          + liste_metni(bas))
    baglanti_sayisi = 0
    bas = ters_cevir_izle(bas)
    print(f"  sonuç: {liste_metni(bas)}  bağlantı yazma = {baglanti_sayisi} "
          f"(n)")
    liste_yok_et(bas)

    bas = liste_olustur(a, 5)
    baglanti_sayisi = 0
    en_derin = 0
    bas = ters_cevir_ozyinelemeli(bas, 1)
    print("\n2) Özyinelemeli ters çevirme\n  sonuç: " + liste_metni(bas))
    print(f"  bağlantı yazma = {baglanti_sayisi} (2(n - 1)), en büyük "
          f"derinlik = {en_derin} (n)")
    liste_yok_et(bas)

    print("\n3) Sınır durumları")
    tek = [7]
    for n in range(2):
        l1 = liste_olustur(tek, n)
        l2 = liste_olustur(tek, n)
        l1 = ters_cevir(l1)
        l2 = ters_cevir_ozyinelemeli(l2, 1)
        print(f"  n = {n}: yinelemeli {liste_metni(l1)}, özyinelemeli "
              f"{liste_metni(l2)}")
        liste_yok_et(l1)
        liste_yok_et(l2)

    print("\n4) Kâhinle sınama (tohum 42, değerler 0..999)")
    rastgele_tohum(42)
    b = rastgele_dizi(1000, 0, 999)
    bas = liste_olustur(b, 1000)
    baglanti_sayisi = 0
    bas = ters_cevir(bas)
    dogru = ters_mi(bas, b, 1000)
    bas = ters_cevir(bas)                  # iki kez ters = asıl
    geri = ayni_mi(bas, b, 1000)
    print(f"  yinelemeli, n = 1000: tersiyle aynı mı? "
          f"{'evet' if dogru else 'HAYIR'}; iki kez ters = asıl mı? "
          f"{'evet' if geri else 'HAYIR'}")
    print(f"    bağlantı yazma = {baglanti_sayisi} (2n)")
    liste_yok_et(bas)
    bas = liste_olustur(b, 500)
    baglanti_sayisi = 0
    en_derin = 0
    bas = ters_cevir_ozyinelemeli(bas, 1)
    print(f"  özyinelemeli, n = 500: tersiyle aynı mı? "
          f"{'evet' if ters_mi(bas, b, 500) else 'HAYIR'}")
    print(f"    bağlantı yazma = {baglanti_sayisi} (2(n - 1)), en büyük "
          f"derinlik = {en_derin}")
    liste_yok_et(bas)

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list::reverse,
# std::list::reverse; Python — list.reverse() / reversed (dinamik dizide
# öğe takası; bağlantı yok).

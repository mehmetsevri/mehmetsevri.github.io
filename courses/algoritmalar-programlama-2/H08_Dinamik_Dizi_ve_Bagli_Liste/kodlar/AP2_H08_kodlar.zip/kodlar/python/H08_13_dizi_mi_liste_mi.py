"""H08_13_dizi_mi_liste_mi.py — AP-2 Hafta 8 · Örnek 13 (★★★)
Amaç    : Stroustrup deneyi: n rastgele tamsayıyı sıralı dinamik diziye
          ve bağlı listeye DOĞRUSAL arayarak ekle, sonra rastgele
          konumlardan sil; deterministik sayaçlar (+ isteğe bağlı süre)
Çalıştır: python3 H08_13_dizi_mi_liste_mi.py            (sayaçlar)
          python3 H08_13_dizi_mi_liste_mi.py --olc [n] [tekrar]
Eşleri  : c/H08_13_dizi_mi_liste_mi.c · cpp/H08_13_dizi_mi_liste_mi.cpp
Çıktı   : üç dilde aynı (=) (--olc çıktısı dile ve makineye özgüdür)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum
from zamanlayici import olc_ortanca


class DinamikDizi:
    __slots__ = ("veri", "boyut", "kapasite")

    def __init__(self):
        self.veri = []          # [None] * kapasite ile büyütülür
        self.boyut = 0
        self.kapasite = 0


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri, sonraki):
        self.veri = veri
        self.sonraki = sonraki


dizi_karsilastirma = 0
dizi_kaydirma_ekle = 0
dizi_kaydirma_sil = 0
liste_ziyaret_ekle = 0
liste_ziyaret_sil = 0
ayirma_sayisi = 0
birakma_sayisi = 0


def dizi_sirali_ekle(d, x):
    """Sıralı diziye x: konum DOĞRUSAL aranır (ilk > x), sağdakiler kayar"""
    global dizi_karsilastirma, dizi_kaydirma_ekle
    konum = 0
    while konum < d.boyut:
        dizi_karsilastirma += 1
        if d.veri[konum] > x:
            break
        konum += 1
    if d.boyut == d.kapasite:                    # × 2 büyütme
        yeni = 1 if d.kapasite == 0 else 2 * d.kapasite
        blok = [None] * yeni
        for i in range(d.boyut):
            blok[i] = d.veri[i]
        d.veri = blok
        d.kapasite = yeni
    for j in range(d.boyut, konum, -1):          # sağa kaydır
        d.veri[j] = d.veri[j - 1]
    dizi_kaydirma_ekle += d.boyut - konum
    d.veri[konum] = x
    d.boyut += 1


def dizi_konumdan_sil(d, konum):
    """konum'daki öğeyi siler (sola kaydırarak); değerini döndürür"""
    global dizi_kaydirma_sil
    x = d.veri[konum]
    for j in range(konum, d.boyut - 1):
        d.veri[j] = d.veri[j + 1]
    dizi_kaydirma_sil += d.boyut - konum - 1
    d.boyut -= 1
    return x


def liste_sirali_ekle(bas, x):
    """Sıralı listeye x: ilk > x düğüme kadar yürünür, önüne bağlanır
    (Python'da işaretçiye işaretçi yok: önceki düğümle). Yeni başı döner."""
    global liste_ziyaret_ekle, ayirma_sayisi
    onceki = None
    p = bas
    while p is not None:
        liste_ziyaret_ekle += 1
        if p.veri > x:
            break
        onceki = p
        p = p.sonraki
    d = Dugum(x, p)
    ayirma_sayisi += 1
    if onceki is None:
        return d
    onceki.sonraki = d
    return bas


def liste_konumdan_sil(bas, konum):
    """konum'daki düğüme yürüyüp siler; (yeni baş, değer) döndürür"""
    global liste_ziyaret_sil, birakma_sayisi
    onceki = None
    p = bas
    for _ in range(konum):
        onceki = p
        p = p.sonraki
        liste_ziyaret_sil += 1
    birakma_sayisi += 1
    if onceki is None:
        return p.sonraki, p.veri
    onceki.sonraki = p.sonraki
    return bas, p.veri


def is_yuku(n):
    """İş yükü verisi: değerler ve silme konumları (konumlar[i] < n - i)"""
    rastgele_tohum(42)
    degerler = [rastgele_sayi() for _ in range(n)]
    konumlar = [rastgele_aralik(0, n - 1 - i) for i in range(n)]
    return degerler, konumlar


def dizi_gorevi(degerler, konumlar):
    """Silinen değerlerin toplamını (denetim) döndürür"""
    d = DinamikDizi()
    for x in degerler:
        dizi_sirali_ekle(d, x)
    toplam = 0
    for k in konumlar:
        toplam += dizi_konumdan_sil(d, k)
    return toplam


def liste_gorevi(degerler, konumlar):
    bas = None
    for x in degerler:
        bas = liste_sirali_ekle(bas, x)
    toplam = 0
    for k in konumlar:
        bas, x = liste_konumdan_sil(bas, k)
        toplam += x
    return toplam


def ayni_sira_mi(degerler):
    """İki yapı aynı sıralı diziyi kuruyor mu? (ekleme bitince)"""
    d = DinamikDizi()
    bas = None
    for x in degerler:
        dizi_sirali_ekle(d, x)
        bas = liste_sirali_ekle(bas, x)
    ayni = True
    i = 0
    p = bas
    while p is not None:
        ayni = (ayni and i < d.boyut and p.veri == d.veri[i]
                and (i == 0 or d.veri[i - 1] <= d.veri[i]))
        p = p.sonraki
        i += 1
    ayni = ayni and i == d.boyut
    while bas is not None:
        bas, _ = liste_konumdan_sil(bas, 0)
    return ayni


def olc():
    try:
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 2000
        tekrar = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    except ValueError:
        n = 0
    if n < 1 or n > 10000000 or tekrar < 1:
        print(f"kullanım: {sys.argv[0]} --olc [n] [tekrar]", file=sys.stderr)
        sys.exit(2)
    degerler, konumlar = is_yuku(n)
    sonuc = [0, 0]
    td = olc_ortanca(lambda: sonuc.__setitem__(
        0, dizi_gorevi(degerler, konumlar)), tekrar)
    tl = olc_ortanca(lambda: sonuc.__setitem__(
        1, liste_gorevi(degerler, konumlar)), tekrar)
    print(f"n = {n}, tekrar = {tekrar} (1 ısınma + ortanca)")
    print(f"  dizi : {td * 1e3:10.3f} ms\n  liste: {tl * 1e3:10.3f} ms   "
          f"liste/dizi = {tl / td:.2f}")
    print(f"  denetim toplamları aynı mı? "
          f"{'evet' if sonuc[0] == sonuc[1] else 'HAYIR'}")


def main():
    global dizi_karsilastirma, dizi_kaydirma_ekle, dizi_kaydirma_sil
    global liste_ziyaret_ekle, liste_ziyaret_sil
    global ayirma_sayisi, birakma_sayisi
    if len(sys.argv) > 1 and sys.argv[1] == "--olc":
        olc()
        return
    print("İş yükü: n rastgele tamsayı (tohum 42) sıralı yapıya doğrusal "
          "aramayla\neklenir, sonra rastgele konumlardan tek tek silinir.")
    print("\n1) Dinamik dizi (bitişik bellek, × 2 büyüme)")
    print("        n   arama karş.  kaydırma (ekle)  kaydırma (sil)"
          "       n²/4")
    nler = (250, 500, 1000)
    dizi_toplam, liste_toplam, d_is, l_is = [], [], [], []
    for n in nler:
        degerler, konumlar = is_yuku(n)
        dizi_karsilastirma = dizi_kaydirma_ekle = dizi_kaydirma_sil = 0
        dizi_toplam.append(dizi_gorevi(degerler, konumlar))
        d_is.append(dizi_karsilastirma + dizi_kaydirma_ekle
                    + dizi_kaydirma_sil)
        print(f"  {n:7d} {dizi_karsilastirma:13d} {dizi_kaydirma_ekle:16d} "
              f"{dizi_kaydirma_sil:15d} {n * n // 4:10d}")
    print("\n2) Tek bağlı liste (düğüm başına bir malloc)")
    print("        n  ziyaret (ekle)  ziyaret (sil)   ayırma  bırakma"
          "       n²/4")
    for n in nler:
        degerler, konumlar = is_yuku(n)
        liste_ziyaret_ekle = liste_ziyaret_sil = 0
        ayirma_sayisi = birakma_sayisi = 0
        liste_toplam.append(liste_gorevi(degerler, konumlar))
        l_is.append(liste_ziyaret_ekle + liste_ziyaret_sil)
        print(f"  {n:7d} {liste_ziyaret_ekle:15d} {liste_ziyaret_sil:14d} "
              f"{ayirma_sayisi:8d} {birakma_sayisi:8d} {n * n // 4:10d}")

    print("\n3) Denetim")
    for j, n in enumerate(nler):
        degerler, _ = is_yuku(n)
        ayni = 'evet' if ayni_sira_mi(degerler) else 'HAYIR'
        esit = 'evet' if dizi_toplam[j] == liste_toplam[j] else 'HAYIR'
        print(f"  n = {n:4d}: aynı sıralı dizi? {ayni}; silinenler aynı? "
              f"{esit} (toplam {dizi_toplam[j]})")

    print("\n4) Kuram: iki yapıda da adım sayısı Θ(n²); n iki katına "
          "çıkınca")
    print(f"  dizi adımı (karş. + kaydırma) oranı: {d_is[1] / d_is[0]:.2f}, "
          f"{d_is[2] / d_is[1]:.2f}")
    print(f"  liste ziyareti oranı               : {l_is[1] / l_is[0]:.2f}, "
          f"{l_is[2] / l_is[1]:.2f}")
    print("  Liste daha az adım atar (kaydırma yok) ama her adımı bir "
          "işaretçi\n  kovalamadır; dizi ardışık bellekte ilerler. Süreler "
          "için: --olc n")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::vector (insert/erase)
# ve std::list (insert/erase; konum yine yürüyerek bulunur); Python —
# list.insert / list.pop (dinamik dizi).

"""H08_06_liste_yok_etme.py — AP-2 Hafta 8 · Örnek 6 (★★)
Amaç    : Listenin yok edilmesi ve bellek sahipliği: C'deki adımların
          karşılığı (başvuruları bırakmak), derin kopya, sayaçlar
Çalıştır: python3 H08_06_liste_yok_etme.py [n]   (n: bölüm 4, varsayılan 1e5)
Eşleri  : c/H08_06_liste_yok_etme.c · cpp/H08_06_liste_yok_etme.cpp
Çıktı   : Δ — 1–4 üç dilde aynı; 5. bölüm dile özgü (bkz. Dil Penceresi)
"""
import gc
import sys


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


ayirma_sayisi = 0
birakma_sayisi = 0
en_derin = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler; nesne, son
    başvurusu kalkınca (başvuru sayımı) geri alınır."""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_olustur(a):
    bas = son = None
    for x in a:
        d = dugum_olustur(x)
        if son is None:
            bas = d
        else:
            son.sonraki = d
        son = d
    return bas


def liste_yok_et(bas):
    """C'deki yinelemeli yok etmenin karşılığı. Çağıranın değişkeni
    değiştirilemez: çağıran ayrıca bas = None yazar (dönüş değeriyle)."""
    d = bas
    while d is not None:
        sonraki = d.sonraki
        dugum_birak(d)
        d = sonraki
    return None


def liste_yok_et_izle(bas):
    """Aynı adımlar, her adım yazdırılarak"""
    d = bas
    while d is not None:
        sonraki = d.sonraki
        if sonraki is not None:
            print(f"  bırak {d.veri} (sonraki = {sonraki.veri} önceden "
                  f"saklandı)")
        else:
            print(f"  bırak {d.veri} (sonraki = NULL)")
        dugum_birak(d)
        d = sonraki
    return None


def liste_yok_et_ozyinelemeli(bas, derinlik):
    """Önce kuyruk, sonra düğüm. Derinlik n + 1 olur; Python'da varsayılan
    özyineleme sınırı (≈ 1000) aşılır (yalnız küçük listede kullanılır)."""
    global en_derin
    if derinlik > en_derin:
        en_derin = derinlik
    if bas is None:
        return
    liste_yok_et_ozyinelemeli(bas.sonraki, derinlik + 1)
    dugum_birak(bas)


def liste_kopyala(kaynak):
    """Derin kopya: yeni düğümler; kaynak değişmez"""
    bas = son = None
    p = kaynak
    while p is not None:
        d = dugum_olustur(p.veri)
        if son is None:
            bas = d
        else:
            son.sonraki = d
        son = d
        p = p.sonraki
    return bas


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]", end="")


def sayac_yaz():
    print(f"  ayrılan = {ayirma_sayisi}, bırakılan = {birakma_sayisi}, "
          f"canlı = {ayirma_sayisi - birakma_sayisi}")


canli_izli = 0   # bölüm 5: gerçekten bellekte olan izli düğüm sayısı


class IzliDugum(Dugum):
    """__del__, CPython'da nesnenin son başvurusu kalktığı anda çalışır"""
    __slots__ = ()

    def __init__(self, veri):
        global canli_izli
        super().__init__(veri)
        canli_izli += 1

    def __del__(self):
        global canli_izli
        canli_izli -= 1


def main():
    global en_derin
    n_buyuk = 100000
    if len(sys.argv) > 1:
        try:
            n_buyuk = int(sys.argv[1])
            if n_buyuk < 1:
                raise ValueError
        except ValueError:
            print(f"kullanım: {sys.argv[0]} [n >= 1]", file=sys.stderr)
            sys.exit(2)
    a = [3, 1, 4, 1, 5]

    print("1) Liste kurma: sahiplik çağıranda\n  bas = ", end="")
    bas = liste_olustur(a)
    liste_yaz(bas)
    print()
    sayac_yaz()

    print("\n2) Yinelemeli yok etme: sonraki free'den ÖNCE saklanır")
    bas = liste_yok_et_izle(bas)
    print(f"  bas {'==' if bas is None else '!='} NULL")
    sayac_yaz()

    print("\n3) Derin kopya: iki ayrı sahip, iki ayrı yok etme")
    asil = liste_olustur(a)
    kopya = liste_kopyala(asil)
    kopya.veri = 99   # kopyayı değiştirmek asılı etkilemez
    print("  asıl  = ", end="")
    liste_yaz(asil)
    print("\n  kopya = ", end="")
    liste_yaz(kopya)
    print()
    sayac_yaz()
    asil = liste_yok_et(asil)
    kopya = liste_yok_et(kopya)
    print("  ikisi de yok edildi:")
    sayac_yaz()

    print("\n4) Büyük liste ve özyinelemeli yok etme")
    b0 = birakma_sayisi
    buyuk = None
    for i in range(n_buyuk):
        d = dugum_olustur(i % 1000)
        d.sonraki = buyuk
        buyuk = d
    buyuk = liste_yok_et(buyuk)
    print(f"  n = {n_buyuk}: yinelemeli yok etme {birakma_sayisi - b0} düğüm "
          f"bıraktı, ek bellek O(1)")
    kucuk = liste_olustur(a)
    en_derin = 0
    liste_yok_et_ozyinelemeli(kucuk, 1)
    kucuk = None
    print(f"  özyinelemeli (n = 5): en büyük derinlik = {en_derin} (n + 1); "
          f"n = {n_buyuk} için {n_buyuk + 1}")
    print("  1-4. bölümlerin toplamı:")
    sayac_yaz()

    print("\n5) Python: free yok; nesne son başvurusu kalkınca geri alınır "
          "(CPython)")
    bas = None
    for x in reversed(a):           # izli düğümlerle aynı liste
        d = IzliDugum(x)
        d.sonraki = bas
        bas = d
    d = None                        # döngü değişkeni de bir başvurudur!
    orta = bas.sonraki.sonraki
    print(f"  orta = bas.sonraki.sonraki; canlı düğüm = {canli_izli}")
    bas = None
    print(f"  bas = None: canlı düğüm = {canli_izli} (orta ve ardılları "
          f"hâlâ erişilebilir)")
    print(f"  orta.veri = {orta.veri} okunabilir: sarkan başvuru yoktur")
    orta = None
    print(f"  orta = None: canlı düğüm = {canli_izli}")
    gc.disable()                    # otomatik toplama ölçümü bozmasın
    bas = IzliDugum(1)
    bas.sonraki = IzliDugum(2)
    bas.sonraki.sonraki = IzliDugum(3)
    bas.sonraki.sonraki.sonraki = bas   # döngü: 3 -> 1
    bas = None
    print(f"  döngülü 3 düğüm, bas = None: canlı düğüm = {canli_izli} "
          f"(başvurular birbirini tutar)")
    gc.collect()
    gc.enable()
    print(f"  gc.collect(): canlı düğüm = {canli_izli} (döngüsel çöp "
          f"toplayıcı)")
    sayac_yaz()


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::list / std::forward_list
# yıkıcısı (RAII), std::unique_ptr; Python — başvuru sayımı + döngüsel çöp
# toplayıcı (gc).

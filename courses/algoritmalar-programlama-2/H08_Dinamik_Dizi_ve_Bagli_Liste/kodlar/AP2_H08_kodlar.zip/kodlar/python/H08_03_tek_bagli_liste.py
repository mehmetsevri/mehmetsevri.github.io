"""H08_03_tek_bagli_liste.py — AP-2 Hafta 8 · Örnek 3 (★)
Amaç    : Tek bağlı liste: düğüm, baş işaretçisi, başa ekleme (O(1)),
          dolaşarak yazdırma ve uzunluk (Θ(n)); ziyaret sayacı
Çalıştır: python3 H08_03_tek_bagli_liste.py
Eşleri  : c/H08_03_tek_bagli_liste.c · cpp/H08_03_tek_bagli_liste.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "sonraki")   # sözlüksüz, küçük nesne

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None   # sonraki düğüme başvuru; son düğümde None


ayirma_sayisi = 0
birakma_sayisi = 0
ziyaret_sayisi = 0
baglanti_sayisi = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri)


def dugum_birak(d):
    """Python'da free yoktur: sayaç yalnızca C'deki adımı işaretler;
    nesneyi son başvuru kalkınca başvuru sayımı geri alır."""
    global birakma_sayisi
    birakma_sayisi += 1


def basa_ekle(bas, x):
    """Yeni düğüm eski başın önüne bağlanır; YENİ BAŞI döndürür: O(1)"""
    global baglanti_sayisi
    d = dugum_olustur(x)
    d.sonraki = bas
    baglanti_sayisi += 1
    return d


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]")


def uzunluk(bas):
    """Baştan None'a kadar yürür: Θ(n)"""
    global ziyaret_sayisi
    n = 0
    p = bas
    while p is not None:
        ziyaret_sayisi += 1
        n += 1
        p = p.sonraki
    return n


def liste_yok_et(bas):
    """Tüm düğümleri 'bırakır' (ayrıntısı Örnek 6)"""
    while bas is not None:
        sonraki = bas.sonraki   # C'deki gibi: bırakmadan ÖNCE sakla
        dugum_birak(bas)
        bas = sonraki


def main():
    global ziyaret_sayisi
    print("1) Boş liste: baş işaretçisi NULL")
    bas = None
    print("  ", end="")
    liste_yaz(bas)
    print(f"  uzunluk = {uzunluk(bas)}")

    print("\n2) Başa ekleme: 4, 1, 3")
    for x in (4, 1, 3):
        bas = basa_ekle(bas, x)
        print(f"  basa_ekle({x}): ", end="")
        liste_yaz(bas)
    ziyaret_sayisi = 0
    n = uzunluk(bas)
    print(f"  uzunluk = {n} (ziyaret edilen düğüm = {ziyaret_sayisi})")
    print(f"  baş düğüm: veri = {bas.veri}; son düğümün sonraki'si NULL")
    liste_yok_et(bas)

    print("\n3) 10 rastgele değer (tohum 42, 0..99) başa eklenince sıra "
          "tersine döner")
    rastgele_tohum(42)
    bas = None
    girdi = []
    for _ in range(10):
        x = rastgele_aralik(0, 99)
        girdi.append(str(x))
        bas = basa_ekle(bas, x)
    print("  girdi : " + " ".join(girdi))
    print("  liste : ", end="")
    liste_yaz(bas)
    toplam = 0
    en_buyuk = bas.veri
    p = bas
    while p is not None:
        toplam += p.veri
        if p.veri > en_buyuk:
            en_buyuk = p.veri
        p = p.sonraki
    print(f"  uzunluk = {uzunluk(bas)}, toplam = {toplam}, "
          f"en büyük = {en_buyuk}")
    liste_yok_et(bas)

    print("\n4) Maliyet: başa ekleme sabit iş, uzunluk Θ(n)")
    print("        n   ayırma  bağlantı yazma  ekleme ziyareti"
          "  uzunluk ziyareti")
    for n in (10, 100, 1000, 10000):
        a0, b0 = ayirma_sayisi, baglanti_sayisi
        ziyaret_sayisi = 0
        bas = None
        for i in range(n):
            bas = basa_ekle(bas, i)
        ekleme_ziyareti = ziyaret_sayisi
        uzunluk(bas)
        print(f"  {n:7d} {ayirma_sayisi - a0:8d} {baglanti_sayisi - b0:15d} "
              f"{ekleme_ziyareti:16d} {ziyaret_sayisi - ekleme_ziyareti:17d}")
        liste_yok_et(bas)

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::forward_list
# (push_front), std::list; Python — yerleşik bağlı liste yok
# (collections.deque.appendleft O(1); list.insert(0, x) Θ(n)).

"""H08_12_listede_birlestirmeli.py — AP-2 Hafta 8 · Örnek 12 (★★★)
Amaç    : Bağlı listede birleştirmeli sıralama: ortadan bölme (yavaş–
          hızlı), birleştirme (Örnek 8); ek dizi yok, kararlı, derinlik
          O(log n); dizi kâhinine karşı rastgele sınama
Çalıştır: python3 H08_12_listede_birlestirmeli.py
Eşleri  : c/H08_12_listede_birlestirmeli.c ·
          cpp/H08_12_listede_birlestirmeli.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "kimlik", "sonraki")

    def __init__(self, veri, kimlik):
        self.veri = veri
        self.kimlik = kimlik   # oluşturulma sırası (kararlılık denetimi)
        self.sonraki = None


ayirma_sayisi = 0
birakma_sayisi = 0
karsilastirma_sayisi = 0
baglanti_sayisi = 0
cagri_sayisi = 0
en_derin = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri, ayirma_sayisi)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler"""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_yok_et(bas):
    while bas is not None:
        sonraki = bas.sonraki
        dugum_birak(bas)
        bas = sonraki


def liste_olustur(a):
    bas = son = None
    for x in a:
        d = dugum_olustur(x)
        if son is None:
            bas = d
        else:
            son.sonraki = d
        son = d
    return bas


def kisa_metin(bas, kimlikli):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri}#{p.kimlik}" if kimlikli else str(p.veri))
        p = p.sonraki
    return "[" + " ".join(parcalar) + "]"


def birlestir(a, b):
    """Örnek 8'deki birleştirme: kukla düğüm, kararlı (<=), yeni düğüm
    yok"""
    global karsilastirma_sayisi, baglanti_sayisi
    kukla = Dugum(0, 0)
    son = kukla
    while a is not None and b is not None:
        karsilastirma_sayisi += 1
        if a.veri <= b.veri:
            son.sonraki = a
            a = a.sonraki
        else:
            son.sonraki = b
            b = b.sonraki
        baglanti_sayisi += 1
        son = son.sonraki
    son.sonraki = a if a is not None else b
    baglanti_sayisi += 1
    return kukla.sonraki


def ortadan_bol(bas):
    """En az iki düğümlü listeyi ikiye böler: ilk yarı ⌈n/2⌉ düğüm (yavaş–
    hızlı, hızlı bir adım önden: çift n'de BİRİNCİ orta). İkinci yarının
    başını döndürür."""
    global baglanti_sayisi
    yavas, hizli = bas, bas.sonraki
    while hizli is not None and hizli.sonraki is not None:
        yavas = yavas.sonraki
        hizli = hizli.sonraki.sonraki
    ikinci = yavas.sonraki
    yavas.sonraki = None  # ilk yarıyı kes
    baglanti_sayisi += 1
    return ikinci


def birlestirmeli_sirala(bas, derinlik):
    """Sıralı listenin başını döndürür; düğümler yeniden bağlanır (ek dizi
    yok). Derinlik ⌈log2 n⌉ + 1: çağrı yığınında O(log n) çerçeve."""
    global cagri_sayisi, en_derin
    cagri_sayisi += 1
    if derinlik > en_derin:
        en_derin = derinlik
    if bas is None or bas.sonraki is None:
        return bas                        # 0 ya da 1 düğüm: sıralı
    ikinci = ortadan_bol(bas)
    sol = birlestirmeli_sirala(bas, derinlik + 1)
    sag = birlestirmeli_sirala(ikinci, derinlik + 1)
    return birlestir(sol, sag)


def birlestirmeli_sirala_izle(bas, derinlik):
    """Aynı özyineleme; her çağrıda bölme ve birleştirme girintiyle"""
    if bas is None or bas.sonraki is None:
        return bas
    girinti = " " * (2 * derinlik)
    satir = girinti + "böl " + kisa_metin(bas, False)
    ikinci = ortadan_bol(bas)
    print(satir + f" -> {kisa_metin(bas, False)} | "
          f"{kisa_metin(ikinci, False)}")
    sol = birlestirmeli_sirala_izle(bas, derinlik + 1)
    sag = birlestirmeli_sirala_izle(ikinci, derinlik + 1)
    sonuc = birlestir(sol, sag)
    print(girinti + "birleştir -> " + kisa_metin(sonuc, False))
    return sonuc


def tavan_log2(n):
    k = 0
    while (1 << k) < n:
        k += 1
    return k


def denetle(bas, kahin):
    """(kâhinle aynı mı, kararlı mı (eşitlerde kimlik artan))"""
    i = 0
    ayni = kararli = True
    p = bas
    while p is not None:
        ayni = ayni and i < len(kahin) and p.veri == kahin[i]
        if (p.sonraki is not None and p.veri == p.sonraki.veri
                and p.kimlik > p.sonraki.kimlik):
            kararli = False
        p = p.sonraki
        i += 1
    return ayni and i == len(kahin), kararli


def main():
    global karsilastirma_sayisi, baglanti_sayisi, cagri_sayisi, en_derin
    print("1) Bölme ve birleştirme ağacı, n = 7")
    bas = liste_olustur([5, 2, 7, 2, 9, 1, 5])
    print(f"  girdi : {kisa_metin(bas, True)}   (veri#kimlik)")
    bas = birlestirmeli_sirala_izle(bas, 1)
    print(f"  çıktı : {kisa_metin(bas, True)}")
    kararli = True
    p = bas
    while p.sonraki is not None:
        if p.veri == p.sonraki.veri and p.kimlik > p.sonraki.kimlik:
            kararli = False
        p = p.sonraki
    print(f"  kararlı mı (2#2 2#4 ve 5#1 5#7 sırası korundu mu)? "
          f"{'evet' if kararli else 'HAYIR'}")
    liste_yok_et(bas)

    print("\n2) Sınır durumları")
    s = [8, 3]
    for n in range(3):
        bas = liste_olustur(s[:n])
        satir = f"  n = {n}: {kisa_metin(bas, False)}"
        bas = birlestirmeli_sirala(bas, 1)
        print(satir + f" -> {kisa_metin(bas, False)}")
        liste_yok_et(bas)

    print("\n3) Kâhinle 200 rastgele sınama (n = 0..300, anahtar 0..20, "
          "tohum 42)")
    rastgele_tohum(42)
    dogru = kararli_sayisi = derinlik_tutan = yeni = 0
    for _ in range(200):
        n = rastgele_aralik(0, 300)
        x = rastgele_dizi(n, 0, 20)
        kahin = sorted(x)                            # yalnızca kâhin
        bas = liste_olustur(x)
        a0 = ayirma_sayisi
        en_derin = 0
        bas = birlestirmeli_sirala(bas, 1)
        yeni += ayirma_sayisi - a0
        ayni, k = denetle(bas, kahin)
        dogru += ayni
        kararli_sayisi += k
        derinlik_tutan += en_derin <= tavan_log2(n) + 1
        liste_yok_et(bas)
    print(f"  kâhinle aynı: {dogru}/200, kararlı: {kararli_sayisi}/200, "
          f"derinlik <= ⌈lg n⌉ + 1: {derinlik_tutan}/200,")
    print(f"  sıralamada yeni düğüm: {yeni}")

    print("\n4) Sayaçlar (rastgele anahtar 0..10^6)")
    print("        n  karşılaştırma  k/(n lg n)  derinlik  ⌈lg n⌉+1"
          "     çağrı  bağlantı")
    for n in (1000, 10000, 100000):
        b = rastgele_dizi(n, 0, 1000000)
        bas = liste_olustur(b)
        karsilastirma_sayisi = baglanti_sayisi = cagri_sayisi = 0
        en_derin = 0
        bas = birlestirmeli_sirala(bas, 1)
        oran = karsilastirma_sayisi / (n * math.log2(n))
        print(f"  {n:7d} {karsilastirma_sayisi:14d} {oran:11.3f} "
              f"{en_derin:9d} {tavan_log2(n) + 1:9d} {cagri_sayisi:9d} "
              f"{baglanti_sayisi:9d}")
        liste_yok_et(bas)

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle; qsort yalnızca kâhin); C++ —
# std::list::sort (kararlı, düğümleri taşır); Python — list.sort /
# sorted (Timsort; dinamik dizide).

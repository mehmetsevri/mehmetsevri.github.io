"""H08_10_floyd_dongu.py — AP-2 Hafta 8 · Örnek 10 (★★★)
Amaç    : Floyd döngü tespiti (kaplumbağa ve tavşan): buluşma, döngü
          başlangıcı (μ) ve döngü uzunluğu (λ); yok etmeden önce kırma
Çalıştır: python3 H08_10_floyd_dongu.py
Eşleri  : c/H08_10_floyd_dongu.c · cpp/H08_10_floyd_dongu.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri       # düğümün konumu: 0..n-1
        self.sonraki = None


ayirma_sayisi = 0
birakma_sayisi = 0
adim_sayisi = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler"""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_yok_et(bas):
    """Yalnızca döngüsüz listede çağrılır (döngülüde sonsuza dek döner)"""
    while bas is not None:
        sonraki = bas.sonraki
        dugum_birak(bas)
        bas = sonraki


def dongulu_liste_kur(n, mu):
    """0..n-1 konumlu n düğüm; mu >= 0 ise son düğüm mu konumundakine
    bağlanır (döngü), mu < 0 ise döngü yok. Döngülü listeyi bırakmadan önce
    donguyu_kir çağrılmalıdır: Python'da da döngüdeki başvurular birbirini
    canlı tutar (yalnızca döngüsel çöp toplayıcı geri alabilir)."""
    bas = son = hedef = None
    for i in range(n):
        d = dugum_olustur(i)
        if son is None:
            bas = d
        else:
            son.sonraki = d
        son = d
        if i == mu:
            hedef = d
    if son is not None:
        son.sonraki = hedef               # mu < 0 ise None kalır
    return bas


def bulusma_bul(bas, izle):
    """Evre 1: kaplumbağa bir, tavşan iki adım atar. Döngü varsa döngünün
    içinde buluşurlar (buluşma düğümü döner); yoksa tavşan None'a varır."""
    global adim_sayisi
    kaplumbaga = tavsan = bas
    while tavsan is not None and tavsan.sonraki is not None:
        kaplumbaga = kaplumbaga.sonraki
        tavsan = tavsan.sonraki.sonraki
        adim_sayisi += 1
        if izle:
            print(f"  adım {adim_sayisi}: kaplumbağa = {kaplumbaga.veri}, "
                  f"tavşan = {tavsan.veri}")
        if kaplumbaga is tavsan:          # aynı NESNE mi? (is)
            return kaplumbaga
    return None


def dongu_baslangici(bas, bulusma, izle):
    """Evre 2: kaplumbağa baştan, tavşan buluşmadan; ikisi de BİRER adım.
    μ adım sonra döngünün başlangıç düğümünde buluşurlar."""
    global adim_sayisi
    kaplumbaga, tavsan = bas, bulusma
    while kaplumbaga is not tavsan:
        kaplumbaga = kaplumbaga.sonraki
        tavsan = tavsan.sonraki
        adim_sayisi += 1
        if izle:
            print(f"  adım {adim_sayisi}: kaplumbağa = {kaplumbaga.veri}, "
                  f"tavşan = {tavsan.veri}")
    return kaplumbaga


def dongu_uzunlugu(bulusma):
    """Evre 3: buluşma düğümünden çıkıp ona geri dönene kadar say: λ"""
    lambda_ = 1
    p = bulusma.sonraki
    while p is not bulusma:
        lambda_ += 1
        p = p.sonraki
    return lambda_


def donguyu_kir(baslangic):
    """Döngünün son düğümünü bulup sonraki'sini None yapar"""
    p = baslangic
    while p.sonraki is not baslangic:
        p = p.sonraki
    p.sonraki = None
    return p


def main():
    global adim_sayisi
    rastgele_tohum(42)
    n = 10
    mu = rastgele_aralik(0, n - 1)
    print(f"1) n = {n} düğüm (0..{n - 1}); döngü konumu LCG ile (tohum 42): "
          f"{n - 1} -> {mu}")
    bas = dongulu_liste_kur(n, mu)
    print("  evre 1: kaplumbağa 1, tavşan 2 adım (başlangıç: ikisi de 0)")
    adim_sayisi = 0
    bulusma = bulusma_bul(bas, True)
    print(f"  buluşma düğümü = {bulusma.veri} ({adim_sayisi} adım)")
    print(f"  evre 2: kaplumbağa baştan (0), tavşan buluşmadan "
          f"({bulusma.veri}); birer adım")
    adim_sayisi = 0
    baslangic = dongu_baslangici(bas, bulusma, True)
    print(f"  döngü başlangıcı = {baslangic.veri} (mu = {adim_sayisi} adım), "
          f"döngü uzunluğu lambda = {dongu_uzunlugu(bulusma)}")
    kirilan = donguyu_kir(baslangic)
    print(f"  döngü kırıldı: {kirilan.veri} -> NULL; yok etme güvenli")
    liste_yok_et(bas)

    print("\n2) Seçilmiş durumlar (mu = -1: döngü yok)")
    print("     n   mu  bulunan mu  lambda  evre1 adım  evre2 adım  doğru")
    durum = [(1, -1), (1, 0), (2, -1), (2, 1), (6, 0), (10, 9), (10, -1),
             (100, 37)]
    for dn, dmu in durum:
        bas = dongulu_liste_kur(dn, dmu)
        adim_sayisi = 0
        bulusma = bulusma_bul(bas, False)
        a1 = adim_sayisi
        bulunan, lambda_, a2 = -1, 0, 0
        if bulusma is not None:
            adim_sayisi = 0
            baslangic = dongu_baslangici(bas, bulusma, False)
            a2 = adim_sayisi
            bulunan = baslangic.veri
            lambda_ = dongu_uzunlugu(bulusma)
            donguyu_kir(baslangic)
        dogru = bulunan == dmu and (dmu < 0 or lambda_ == dn - dmu)
        print(f"  {dn:4d} {dmu:4d} {bulunan:11d} {lambda_:7d} {a1:11d} "
              f"{a2:11d}  {'evet' if dogru else 'HAYIR'}")
        liste_yok_et(bas)

    print("\n3) 1000 rastgele liste (n = 1..200; %20 döngüsüz; tohum 42)")
    dogru_sayisi = sinir_icinde = 0
    toplam1 = toplam_mulambda = 0
    for _ in range(1000):
        rn = rastgele_aralik(1, 200)
        rmu = -1 if rastgele_aralik(0, 4) == 0 else rastgele_aralik(0, rn - 1)
        bas = dongulu_liste_kur(rn, rmu)
        adim_sayisi = 0
        bulusma = bulusma_bul(bas, False)
        a1 = adim_sayisi
        bulunan, lambda_ = -1, 0
        if bulusma is not None:
            baslangic = dongu_baslangici(bas, bulusma, False)
            bulunan = baslangic.veri
            lambda_ = dongu_uzunlugu(bulusma)
            donguyu_kir(baslangic)
        dogru = bulunan == rmu and (rmu < 0 or lambda_ == rn - rmu)
        dogru_sayisi += dogru
        if rmu >= 0:
            sinir_icinde += a1 <= rmu + lambda_   # evre 1 <= mu + lambda
            toplam1 += a1
            toplam_mulambda += rn                 # mu + lambda = n
        else:
            sinir_icinde += a1 == rn // 2         # döngüsüz: n/2 adım
        liste_yok_et(bas)
    print(f"  doğru (mu, lambda): {dogru_sayisi}/1000; evre 1 adım sınırı "
          f"tutan: {sinir_icinde}/1000")
    print(f"  döngülülerde evre 1 adımı / (mu + lambda) = "
          f"{toplam1 / toplam_mulambda:.3f}")

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — yok (std::list ve
# std::forward_list döngü kurdurmaz); Python — yok.

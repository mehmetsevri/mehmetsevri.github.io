"""H08_04_sona_ekleme_arama.py — AP-2 Hafta 8 · Örnek 4 (★)
Amaç    : Kuyruk (son) işaretçisiyle O(1) sona ekleme, kuyruksuz Θ(n)
          sona ekleme ile ziyaret karşılaştırması; doğrusal arama
Çalıştır: python3 H08_04_sona_ekleme_arama.py
Eşleri  : c/H08_04_sona_ekleme_arama.c · cpp/H08_04_sona_ekleme_arama.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_karistir, rastgele_tohum


class Dugum:
    __slots__ = ("veri", "sonraki")

    def __init__(self, veri):
        self.veri = veri
        self.sonraki = None


class Liste:
    """Liste başlığı: baş ve kuyruk (son düğüm) başvuruları"""
    __slots__ = ("bas", "son")

    def __init__(self):
        self.bas = None
        self.son = None


ayirma_sayisi = 0
birakma_sayisi = 0
ziyaret_sayisi = 0
baglanti_sayisi = 0


def dugum_olustur(veri):
    global ayirma_sayisi
    ayirma_sayisi += 1
    return Dugum(veri)


def dugum_birak(d):
    """Python'da free yoktur: sayaç C'deki adımı işaretler"""
    global birakma_sayisi
    birakma_sayisi += 1


def liste_yok_et(bas):
    while bas is not None:
        sonraki = bas.sonraki
        dugum_birak(bas)
        bas = sonraki


def liste_yaz(bas):
    parcalar = []
    p = bas
    while p is not None:
        parcalar.append(f"{p.veri} -> ")
        p = p.sonraki
    print("[" + "".join(parcalar) + "NULL]", end="")


def sona_ekle(liste, x):
    """Kuyruk işaretçisiyle sona ekleme: yürümeden O(1)"""
    global baglanti_sayisi
    d = dugum_olustur(x)
    if liste.son is None:  # boş liste
        liste.bas = d
    else:
        liste.son.sonraki = d
        baglanti_sayisi += 1
    liste.son = d


def sona_ekle_kuyruksuz(bas, x):
    """Kuyruk işaretçisi olmadan sona ekleme: son düğüme kadar yürür,
    Θ(n). Yeni başı döndürür (boş listede baş değişir)."""
    global ziyaret_sayisi, baglanti_sayisi
    d = dugum_olustur(x)
    if bas is None:
        return d
    p = bas
    ziyaret_sayisi += 1
    while p.sonraki is not None:
        p = p.sonraki
        ziyaret_sayisi += 1
    p.sonraki = d
    baglanti_sayisi += 1
    return bas


def ara(bas, x):
    """İlk x'i arar; (düğüm ya da None, 0 tabanlı konum ya da -1) döner"""
    global ziyaret_sayisi
    i = 0
    p = bas
    while p is not None:
        ziyaret_sayisi += 1
        if p.veri == x:
            return p, i
        i += 1
        p = p.sonraki
    return None, -1


def ara_yaz(bas, x, on_ek):
    global ziyaret_sayisi
    ziyaret_sayisi = 0
    d, konum = ara(bas, x)
    if d is not None:
        print(f"  {on_ek}ara({x}): bulundu, konum {konum}, "
              f"ziyaret = {ziyaret_sayisi}")
    else:
        print(f"  {on_ek}ara({x}): bulunamadı (NULL), "
              f"ziyaret = {ziyaret_sayisi}")


def main():
    global ziyaret_sayisi
    print("1) Kuyruk işaretçisiyle sona ekleme: 3, 1, 4, 1, 5")
    liste = Liste()
    for x in (3, 1, 4, 1, 5):
        sona_ekle(liste, x)
        print(f"  sona_ekle({x}): ", end="")
        liste_yaz(liste.bas)
        print(f"  bas = {liste.bas.veri}, son = {liste.son.veri}")

    print("\n2) Doğrusal arama (ilk eşleşme)")
    ara_yaz(liste.bas, 4, "")
    ara_yaz(liste.bas, 1, "")
    ara_yaz(liste.bas, 5, "")
    ara_yaz(liste.bas, 9, "")
    ara_yaz(None, 3, "boş listede ")
    liste_yok_et(liste.bas)

    print("\n3) n sona ekleme: kuyruklu ve kuyruksuz ziyaret sayısı")
    print("       n  kuyruklu  kuyruksuz   n(n-1)/2")
    for n in (10, 100, 1000):
        k = Liste()
        ziyaret_sayisi = 0
        for i in range(n):
            sona_ekle(k, i)
        kuyruklu = ziyaret_sayisi
        bas = None
        ziyaret_sayisi = 0
        for i in range(n):
            bas = sona_ekle_kuyruksuz(bas, i)
        print(f"  {n:6d} {kuyruklu:9d} {ziyaret_sayisi:10d} "
              f"{n * (n - 1) // 2:10d}")
        liste_yok_et(k.bas)
        liste_yok_et(bas)

    print("\n4) Arama maliyeti: 0..999 karıştırılmış (tohum 42), "
          "her değer bir kez aranır")
    a = list(range(1000))
    rastgele_tohum(42)
    rastgele_karistir(a)
    m = Liste()
    for x in a:
        sona_ekle(m, x)
    ziyaret_sayisi = 0
    for x in range(1000):
        ara(m.bas, x)
    print(f"  başarılı arama: ortalama ziyaret = {ziyaret_sayisi / 1000.0:.2f}"
          f", (n + 1) / 2 = {1001 / 2.0:.2f}")
    ziyaret_sayisi = 0
    ara(m.bas, -1)
    print(f"  başarısız arama: ziyaret = {ziyaret_sayisi} (= n)")
    liste_yok_et(m.bas)

    print(f"\nbellek: ayrılan = {ayirma_sayisi}, bırakılan = "
          f"{birakma_sayisi} düğüm")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::list::push_back,
# std::find; Python — yerleşik bağlı liste yok (collections.deque.append,
# x in d).

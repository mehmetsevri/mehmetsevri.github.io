# Hafta 8 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı ve materyalde geçtiği yerlerle aşağıdadır. **Ders notu** sütunu bölüm numarasını (ya da alıştırma numarasını, Ek A bölümünü), **Sunum** slayt numarasını, **Web** web sayfasının bölüm kimliğini (`#h08-…`) verir; bu sütunlar materyal derleme betiklerinin kayıtlarından üretildi. Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11 (örnekler 3.10 uyumludur; 3.10, 3.12 ve 3.13 ile de çıktılar aynı).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program [-lm]` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. `-lm` yalnızca Örnek 12'de (`log2`) gerekir.

Eşdeğerlik: `python3 esdeger_test.py .` → **13/13 GEÇTİ** (12 “=”, 1 “Δ”: Örnek 6'nın 5. bölümü dile özgü), derleyici uyarısı 0, sütun aşımı 0; `--asan` (AddressSanitizer + UBSan + LeakSanitizer) ile de 13/13 GEÇTİ. Bellek: ASan + UBSan temiz 73/73; Valgrind 'ERROR SUMMARY: 0 errors' ve 'definitely lost: 0 bytes' 73/73. Ayrıntı: `BELLEK_DENETIMI.txt`.


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H08_01_dinamik_dizi` | ★ | = | evet | Dinamik dizi ADT'si: dd_olustur, dd_ekle, dd_al, dd_boyut, dd_yok_et; kapasite ikiye katlama ve kapasite izleme | — | 4.1, Ek A.1 | — | dinamik-dizi (kod kutusu) |
| `H08_02_buyume_stratejisi` | ★★ | = | — | Büyüme stratejisi deneyi: +1, +10, × 1,5 ve × 2 büyütmede toplam kopya sayısı; kapalı biçimler ve boş yuva ödünleşimi | — | Ek A.2 | — | dinamik-dizi (kod kutusu) |
| `H08_03_tek_bagli_liste` | ★ | = | evet | Tek bağlı liste: başa ekleme, yazdırma ([3 -> 1 -> 4 -> NULL]), uzunluk; ziyaret sayacı | — | 3.1, 4.2, Ek A.3 | — | liste (kod kutusu) |
| `H08_04_sona_ekleme_arama` | ★ | = | evet | Sona ekleme (kuyruk işaretçisiyle) ve doğrusal arama; kuyruksuz sona eklemenin n(n−1)/2 ziyareti | — | Ek A.4 | — | liste (kod kutusu) |
| `H08_05_degere_gore_silme` | ★★ | = | — | Değere göre silme: özel durumlu sürüm, Dugum ** ile özel durumsuz sürüm ve tüm eşleşenleri silme | — | 4.2, Ek A.5 | 20 | liste (kod kutusu) |
| `H08_06_liste_yok_etme` | ★★ | Δ | — | Listenin yok edilmesi ve bellek sahipliği: yinelemeli yok etme, derin kopya, sarkan işaretçi; ASan/Valgrind ile sızıntısız (Δ: 5. bölüm) | [n] (varsayılan 100000) | 5.1, 8, Ek A.6 | 41 | sahiplik (kod kutusu) |
| `H08_07_ters_cevirme` | ★★ | = | evet | Listeyi ters çevirme: yinelemeli (onceki–gecerli–sonraki) ve özyinelemeli; kâhinle sınama | [n]: özyinelemeli derinlik gösterimi | 4.3, Ek A.7 | 25 | ters (kod kutusu) |
| `H08_08_sirali_birlestirme` | ★★ | = | evet | İki sıralı listeyi kukla düğümle birleştirme: yeniden bağlama, kararlılık, Θ(n + m); kâhinle sınama | — | 4.4, Ek A.8 | 28 | birlestirme (kod kutusu) |
| `H08_09_iki_isaretci` | ★★ | = | — | İki işaretçi tekniği: ortadaki düğüm (yavaş–hızlı; çiftte ikinci orta) ve sondan k'ıncı düğüm (k < 1 ya da k > n ise NULL) | — | 5.3, Ek A.9 | — | iki-isaretci (kod kutusu) |
| `H08_10_floyd_dongu` | ★★★ | = | evet | Floyd döngü tespiti (kaplumbağa ve tavşan): buluşma, döngü başlangıcı μ, döngü uzunluğu λ; döngüyü kırıp yok etme | — | 4.5, Ek A.10 | — | floyd (kod kutusu) |
| `H08_11_cift_bagli_liste` | ★★ | = | — | Çift bağlı liste: kukla düğümlü dairesel gerçekleştirim, O(1) silme, ileri ve geri dolaşma; tek bağlıyla kıyas | — | 5.4, Ek A.11 | 37 | cift-bagli (kod kutusu) |
| `H08_12_listede_birlestirmeli` | ★★★ | = | evet | Bağlı listede birleştirmeli sıralama: yavaş–hızlıyla bölme, Örnek 8'in birleştirmesi; kararlılık, O(log n) derinlik, kâhin | — | 4.6, Ek A.12 | 39 | siralama (kod kutusu) |
| `H08_13_dizi_mi_liste_mi` | ★★★ | = | — | Dizi mi liste mi? Sıralı ekleme–silme deneyi (Stroustrup deneyi): deterministik sayaçlar; --olc ile süre | --olc [n] [tekrar] | Ek A.13 | — | deney (kod kutusu) |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt` (Δ örneği `ciktilar/KÖK_c.txt`, `_cpp.txt`, `_py.txt`). C++/Python'da anlamca farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`. Ders notunun Ek A'sı her örneğin C++ ve Python çekirdek fonksiyonlarını verir; web'deki kod kutusunda üç dil sekmeli ve çıktılıdır.

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py` (13 Ekim 2026 sürümü). Kullananlar: ortak_rastgele — Örnek 3, 4, 5, 7, 8, 9, 10, 11, 12, 13; zamanlayici — Örnek 13 (`--olc` kipi).


## 2. Kavram programları (kavram/)

Ders notunda ve sunumda gösterilen, merdiven dışı her parça bir dosyadadır (kod dosyası kuralı). Çıktılar `kavram/ciktilar/` (adres ve bellek değerleri “bu makinede, bu çalıştırmada”).

| Dosya | Dil | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `kavram/H08_K01_dizi_adt/dizi.h` | C (başlık) | AP-2 Hafta 8 · Kavram 1: Dizi soyut veri tipinin ARAYÜZÜ | 3.2 | 8 | bellek |
| `kavram/H08_K01_dizi_adt/dizi_bagli.c` | C | AP-2 Hafta 8 · Kavram 1: Dizi ADT'sinin tek bağlı liste | 3.2 | — | — |
| `kavram/H08_K01_dizi_adt/dizi_dinamik.c` | C | AP-2 Hafta 8 · Kavram 1: Dizi ADT'sinin dinamik dizi | 3.2 | 14 | — |
| `kavram/H08_K01_dizi_adt/main.c` | C | AP-2 Hafta 8 · Kavram 1: Dizi ADT'sinin istemcisi | 3.2 | — | — |
| `kavram/H08_K02_liste_islemleri.c` | C | Başlıklı (bas, son) tek bağlı listede başa, sona ve araya ekleme (Dugum ** ile, baş için de aynı kod), baştan silme, değere göre silme ve ters çevirme; her işlemden sonra liste, bas/son ve sayaçlar (Örnek 3–7 ile aynı tanımlar) | 4.2 | — | bellek, quiz |
| `kavram/H08_K03_ozel_durumsuz_silme.c` | C | Adresi bilinen düğümü listeden çıkarmanın iki yazımı: önceki işaretçisiyle (baş için ayrı dal) ve Dugum ** ile (dal yok); iki yazım her konumda aynı listeyi bırakır | 4.2 | 19 | — |
| `kavram/H08_K04_floyd_bagintisi.c` | C | Floyd döngü tespitinin izlemesiz, kısa yazımı ve uzaklık bağıntısının sınanması: buluşmada kaplumbağanın attığı adım (i) λ'nın katıdır; buluşmadan μ adım ilerlemek döngü başına götürür. Düğümler yığında bir dizidir (ayırma yok). | 4.5 | 34 | — |
| `kavram/H08_K05_realloc_gecersizlesme.c` | C | realloc bloğu yerinde büyütebilir ya da taşıyabilir; taşınınca eski bloğu gösteren her işaretçi geçersizdir (yineleyici geçersizleşmesine giriş). Adres YAZDIRILMAZ: yalnızca realloc ÖNCESİNDE uintptr_t'ye çevrilmiş değer karşılaştırılır. Sonuç ayırıcıya ve çalıştırmaya bağlıdır ("bu çalıştırmada"). | 3.4 | — | — |
| `kavram/H08_K06_vector_list.cpp` | C++ | Kütüphane karşılıkları: std::vector (dinamik dizi; kapasite büyümesi gerçekleştirime bağlı), std::list (çift bağlı), std::forward_list (tek bağlı); kapasite satırları "bu derleyicide" (libstdc++) gözlemdir | 8 | — | — |
| `kavram/H08_K07_list_deque.py` | Python | Python list bir dinamik dizidir: append fazladan yer ayırır (sys.getsizeof ile gözlenir; değerler CPython sürümüne bağlı); collections.deque iki uçta O(1) ekler/çıkarır | 8 | — | — |
| `kavram/H08_K08_slots_none.py` | Python | Python düğüm sınıfı: __slots__ nesne başına sözlüğü (__dict__) kaldırır; boş bağlantı None'dır ve "is" ile denetlenir; düğüm kimliği "is", değer eşitliği "==" ile. Bellek satırları tracemalloc ölçümüdür (CPython sürümüne bağlı). | 8 | — | — |


## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar. Gerçek çıktılar `hata_avcisi/ciktilar/` (olağan çalıştırma `.txt`, AddressSanitizer `_asan.txt`, Valgrind `_valgrind.txt`; PID, adres ve geçici yollar sadeleştirildi). Ders notu Bölüm 7, sunum Hata Avcısı slaytları ve web `#h08-hata-avcisi` hepsini tek tabloda verir; aşağıdaki sütunlar ayrıca kod ya da rapor alıntısının geçtiği yerleri gösterir.

| Dosya | Dil | Tür | Amaç | Çıktı dosyaları | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H08_HA1_sinir_durumu.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: son_dugumu_sil en az iki düğüm varsayar; tek düğümlü (ve boş) liste sınır durumu atlanmıştır. | `H08_HA1_sinir_durumu.txt`, `H08_HA1_sinir_durumu_asan.txt`, `H08_HA1_sinir_durumu_valgrind.txt` | 7 (HA1) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA1_sinir_durumu.py` | Python | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: son_dugumu_sil en az iki düğüm varsayar; tek düğümlü (ve boş) liste sınır durumu atlanmıştır. | `H08_HA1_sinir_durumu_py.txt` | 7 (HA1) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA1_sinir_durumu_duzeltilmis.c` | C | düzeltilmiş | son_dugumu_sil(Dugum **bas) — p, "son düğümü gösteren bağlantıyı" arar; boş listede hiçbir şey yapmaz, tek düğümde başı NULL yapar (özel durum kalmaz). Sınır durumları sınanır. | `H08_HA1_sinir_durumu_duzeltilmis.txt`, `H08_HA1_sinir_durumu_duzeltilmis_valgrind.txt` | 7 (HA1) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA1_sinir_durumu_duzeltilmis.py` | Python | düzeltilmiş | boş liste (None) ve tek düğüm ayrı ayrı ele alınır; yeni baş döndürülür (Python'da çağıranın değişkeni değiştirilemez). | `H08_HA1_sinir_durumu_duzeltilmis_py.txt` | 7 (HA1) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA2_silmede_sizinti.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: sil, düğümü listeden koparır ama free etmez; o düğüme artık hiçbir işaretçi yoktur (bellek sızıntısı). | `H08_HA2_silmede_sizinti.txt`, `H08_HA2_silmede_sizinti_asan.txt`, `H08_HA2_silmede_sizinti_valgrind.txt` | 7 (HA2) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA2_silmede_sizinti_duzeltilmis.c` | C | düzeltilmiş | koparılacak düğümün adresi önce bir değişkende saklanır, bağlantı güncellenir, SONRA free edilir. | `H08_HA2_silmede_sizinti_duzeltilmis.txt`, `H08_HA2_silmede_sizinti_duzeltilmis_valgrind.txt` | 7 (HA2) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA3_free_sonrasi.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: liste_yok_et, free ettiği düğümün sonraki alanını SONRA okur (free sonrası kullanım; tanımsız davranış). | `H08_HA3_free_sonrasi.txt`, `H08_HA3_free_sonrasi_asan.txt`, `H08_HA3_free_sonrasi_valgrind.txt` | 7 (HA3), 5.2 | 48–49 (tablo) | hata-avcisi, quiz |
| `hata_avcisi/H08_HA3_free_sonrasi_duzeltilmis.c` | C | düzeltilmiş | sonraki, free'den ÖNCE yerel değişkende saklanır. | `H08_HA3_free_sonrasi_duzeltilmis.txt`, `H08_HA3_free_sonrasi_duzeltilmis_valgrind.txt` | 7 (HA3) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA4_bas_degerle.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: basa_ekle baş işaretçisini DEĞERLE alır; fonksiyondaki bas = d yalnızca yerel kopyayı değiştirir (AP-1 H8 takas sorusunun yeni yüzü). main'in listesi boş kalır, düğümler sızar. | `H08_HA4_bas_degerle.txt`, `H08_HA4_bas_degerle_asan.txt`, `H08_HA4_bas_degerle_valgrind.txt` | 7 (HA4) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA4_bas_degerle.py` | Python | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: basa_ekle parametre adını yeniden bağlar; Python'da bu, çağıranın değişkenini DEĞİŞTİRMEZ (C'deki değerle aktarımın aynısı). Liste boş kalır; sızıntı yoktur (başvurusuz düğümleri başvuru sayımı geri alır). | `H08_HA4_bas_degerle_py.txt` | 7 (HA4) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA4_bas_degerle_duzeltilmis.c` | C | düzeltilmiş | Düzeltme (iki yol): (1) basa_ekle(Dugum **bas, x) — işaretçinin ADRESİ verilir, *bas = d çağıranınkini değiştirir; (2) yeni baş döndürülür: bas = basa_ekle_dondur(bas, x). Sonunda liste serbest bırakılır. | `H08_HA4_bas_degerle_duzeltilmis.txt`, `H08_HA4_bas_degerle_duzeltilmis_valgrind.txt` | 7 (HA4) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA4_bas_degerle_duzeltilmis.py` | Python | düzeltilmiş | Python'da işaretçiye işaretçi yoktur; yeni baş DÖNDÜRÜLÜR ve çağıran atar (bas = basa_ekle(bas, x)). Diğer yol: başı bir nesnenin alanında tutmak (liste.bas = ...). | `H08_HA4_bas_degerle_duzeltilmis_py.txt` | 7 (HA4) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA5_realloc_kaybi.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: d->veri = realloc(d->veri, ...) — realloc başarısız olup NULL döndürünce eski blok yerinde ve geçerlidir ama tek adresi NULL ile ezilir: veriler ve blok kaybolur (sızıntı). Başarısızlık güvenli biçimde benzetilir: yeniden_ayir sarmalayıcısı BASARISIZ_CAGRI'ncı çağrıda realloc'u çağırmadan NULL döndürür (gerçek realloc'un başarısızlıktaki davranışı: eski blok dokunulmaz). | `H08_HA5_realloc_kaybi.txt`, `H08_HA5_realloc_kaybi_asan.txt`, `H08_HA5_realloc_kaybi_valgrind.txt` | 7 (HA5) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA5_realloc_kaybi_duzeltilmis.c` | C | düzeltilmiş | realloc sonucu önce GEÇİCİ işaretçiye alınır; NULL ise eski blok ve kapasite değişmeden kalır, çağıran durumu bilir ve veriler korunur. Aynı başarısızlık benzetimi (BASARISIZ_CAGRI) kullanılır. | `H08_HA5_realloc_kaybi_duzeltilmis.txt`, `H08_HA5_realloc_kaybi_duzeltilmis_valgrind.txt` | 7 (HA5) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA6_ters_cevirme_next.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: ters çevirmede gecerli->sonraki, değeri SAKLANMADAN değiştirilir; listenin geri kalanına giden tek bağlantı kaybolur (sonuç yanlış, kalan düğümler sızar). | `H08_HA6_ters_cevirme_next.txt`, `H08_HA6_ters_cevirme_next_asan.txt`, `H08_HA6_ters_cevirme_next_valgrind.txt` | 7 (HA6) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA6_ters_cevirme_next_duzeltilmis.c` | C | düzeltilmiş | üç adımın sırası — (1) sonraki'yi sakla, (2) bağlantıyı tersine çevir, (3) onceki ve gecerli'yi ilerlet (Örnek 7). | `H08_HA6_ters_cevirme_next_duzeltilmis.txt`, `H08_HA6_ters_cevirme_next_duzeltilmis_valgrind.txt` | 7 (HA6) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA7_list_bagli_liste_degil.py` | Python | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: Python list'ini bağlı liste sanıp başa ekleme için list.insert(0, x) kullanmak. list bir DİNAMİK DİZİDİR: her insert(0, x) mevcut tüm öğeleri bir sağa kaydırır (Θ(boyut)); n başa ekleme Θ(n²) olur. Süreler stderr'e değil stdout'a yazılır: çıktı bu makinede, bu çalıştırmada ölçülendir (deterministik değildir). | `H08_HA7_list_bagli_liste_degil_py.txt` | 7 (HA7) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA7_list_bagli_liste_degil_duzeltilmis.py` | Python | düzeltilmiş | başa O(1) ekleme gerekiyorsa (1) collections.deque.appendleft (bloklardan oluşan iki uçlu yapı) ya da (2) elle bağlı liste (Örnek 3) ya da (3) sona ekleyip en sonda bir kez ters çevirmek (list.append + reverse: toplam Θ(n)). Süreler bu makinede, bu çalıştırmada ölçülendir. | `H08_HA7_list_bagli_liste_degil_duzeltilmis_py.txt` | 7 (HA7) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA8_dongulu_yok_etme.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: döngülü liste, döngü KIRILMADAN olağan liste_yok_et ile serbest bırakılır: son düğümden sonra döngünün başlangıcına (zaten free edilmiş düğüme) dönülür — free sonrası okuma ve çift free (tanımsız davranış). | `H08_HA8_dongulu_yok_etme.txt`, `H08_HA8_dongulu_yok_etme_asan.txt`, `H08_HA8_dongulu_yok_etme_valgrind.txt` | 7 (HA8) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA8_dongulu_yok_etme_duzeltilmis.c` | C | düzeltilmiş | yok etmeden önce Floyd ile döngü aranır; varsa döngünün son düğümünün sonraki'si NULL yapılır (döngü kırılır), sonra olağan yinelemeli yok etme güvenlidir (Örnek 10). | `H08_HA8_dongulu_yok_etme_duzeltilmis.txt`, `H08_HA8_dongulu_yok_etme_duzeltilmis_valgrind.txt` | 7 (HA8) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA9_unique_ptr_yigin.cpp` | C++ | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: std::unique_ptr<Dugum> sonraki zincirinin VARSAYILAN yıkıcısı özyinelemelidir: baş silinir, o sonraki'yi siler, o da kendi sonraki'sini... Derinlik n'dir; büyük n'de çağrı yığını taşar (bu derleyicide ve bu çalıştırmada: bkz. ciktilar/H08_HA9_*). | `H08_HA9_unique_ptr_yigin.txt`, `H08_HA9_unique_ptr_yigin_asan.txt` | 7 (HA9) | 48–49 (tablo) | hata-avcisi |
| `hata_avcisi/H08_HA9_unique_ptr_yigin_duzeltilmis.cpp` | C++ | düzeltilmiş | Liste'ye döngüyle silen bir yıkıcı yazılır: bas = std::move(bas->sonraki) her adımda TEK düğümü siler (eski başın sonraki'si önceden alındığı için özyineleme olmaz). | `H08_HA9_unique_ptr_yigin_duzeltilmis.txt` | 7 (HA9) | 48–49 (tablo) | hata-avcisi |


## 4. Haftanın Deneyi (deney/)

Sürücü `deney/h08_olcum_calistir.py` (tüm ızgara bu makinede ≈ 4,7 dk; `--hizli` küçük alt küme, `--devam` kesilen ölçümü sürdürür), çözümleme `deney/h08_cozumle.py`. Ham veriler `deney/sonuclar/`, ortam `deney/OLCUM_ORTAMI.txt`. Sonuçlar ders notunun 6. bölümünde, sunumun “Haftanın Deneyi” slaytlarında ve web `#h08-deney` bölümündedir.

| Dosya | Dil | Amaç |
|---|---|---|
| `deney/c/H08_deney_bellek.c` | C | int verisi için dizi ve bağlı liste bellek maliyeti: sizeof (bu makinede, x86-64 LP64), malloc_usable_size (GLIBC UZANTISI; taşınabilir C değildir) ve art arda ayrılan düğümlerin adres aralıkları (bu çalıştırmada) |
| `deney/c/H08_deney_buyume.c` | C | Büyüme stratejisine göre n sona eklemenin süresi ve kopya sayısı: realloc ile ve elle (yeni blok + öğe öğe kopya) |
| `deney/c/H08_deney_dolasma.c` | C | Düğümlerin ayrılma/bağlanma sırasının önbellek etkisi: n düğümü baştan sona dolaşmanın düğüm başına süresi |
| `deney/c/H08_deney_stroustrup.c` | C | Stroustrup iş yükü (sıralı yapıya doğrusal aramayla ekleme, rastgele konumlardan silme) için süre ölçümü; düğüm yerleşimi değişkeni ve arama/değiştirme ayrıştırması |
| `deney/cpp/H08_deney_bellek.cpp` | C++ | Kütüphane kaplarının öğe başına ayırdığı bellek: sayan bir ayırıcıyla (allocator) std::list<int>, std::forward_list<int> düğüm boyutları ve std::vector<int> kapasite dizisi. Düğüm boyutu GERÇEKLEŞTİRİME BAĞLIDIR (burada libstdc++, bu makine). |
| `deney/cpp/H08_deney_buyume.cpp` | C++ | n sona ekleme: elle dinamik dizi (strateji 0..3, yeni blok + kopya) ve etiketli kütüphane serisi std::vector::push_back (strateji gerçekleştirime bağlı: kapasite değişimleri sayılır) |
| `deney/cpp/H08_deney_stroustrup.cpp` | C++ | Stroustrup iş yükü: elle dinamik dizi ve elle liste ile etiketli kütüphane serisi std::vector ve std::list |
| `deney/python/H08_deney_buyume.py` | Python | n sona ekleme: elle dinamik dizi ([None] * kapasite; strateji 0..3, öğe öğe kopya) ve etiketli kütüphane serisi list.append (CPython fazladan ayırır: sys.getsizeof değişimleri sayılır) |
| `deney/python/H08_deney_dolasma.py` | Python | Düğümlerin oluşturulma/bağlanma sırasının etkisi Python'da: n düğümü dolaşmanın düğüm başına süresi (yorumlayıcı yükü önbellek etkisini ne kadar gölgeler?) |
| `deney/python/H08_deney_getsizeof.py` | Python | (1) Yerleşik list'in fazladan ayırması (over-allocation): her append sonrası sys.getsizeof'tan ayrılmış yuva sayısı ve CPython Objects/listobject.c'deki list_resize formülüyle karşılaştırma; (2) düğüm nesnelerinin boyutu (__slots__ ile ve sözlükle) ve tracemalloc ile düğüm başına bellek. Değerler CPython SÜRÜMÜNE ve 64 bit yapıya bağlıdır. |
| `deney/python/H08_deney_stroustrup.py` | Python | Stroustrup iş yükü: elle dinamik dizi ([None] * kapasite), elle bağlı liste ve etiketli kütüphane serisi (yerleşik list: konum elle aranır, list.insert / list.pop kaydırır) |

Sonuç dosyaları (`deney/sonuclar/`): `h08_bellek_gozlem.txt`, `h08_buyume_kopya.csv`, `h08_deney_ayristirma.csv`, `h08_deney_buyume.csv`, `h08_deney_dolasma.csv`, `h08_deney_stroustrup.csv`, `h08_ham.jsonl`, `h08_list_buyume.csv`, `h08_ozet_ayristirma.csv`, `h08_ozet_buyume.csv`, `h08_ozet_dolasma.csv`, `h08_ozet_egim.csv`, `h08_ozet_kestirim.csv`, `h08_ozet_ortam.csv`, `h08_ozet_stroustrup.csv`.


## 5. Alıştırmalar (alistirmalar/)

Ders notunun 11. bölümündeki alıştırmalar ve atölyeler için verilen dosyalar. Önce **çalıştırmadan** tahmin edin, sonra çalıştırıp karşılaştırın. Beklenen çıktılar bu klasörde yoktur (yanıttır).

| Dosya | Dil | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `alistirmalar/H08_A01_cikti_tahmini.c` | C | Çalıştırmadan önce her satırın çıktısını kutu–ok çizerek tahmin edin; sonra çalıştırıp karşılaştırın. | Alıştırma 8.1 | — | alistirmalar |
| `alistirmalar/H08_A02_izleme.c` | C | İzleme: f'nin [1 2 3 4 5 6] ve [1 2 3 4 5] listelerinde her turdaki sira, p, son_a, son_b değerlerini tablo olarak yazın; fonksiyonun ne yaptığını bir cümleyle söyleyin. | Alıştırma 8.2 | — | alistirmalar |
| `alistirmalar/H08_A07_hata_bul_sondan_k.c` | C | BU DOSYA KASITLI HATA İÇERİR: sondan_k, sözleşmeye göre (k = 1 son düğüm; k < 1 ya da k > n ise NULL) sonuç vermiyor. Çıktıyı Örnek 9'un 2. bölümüyle karşılaştırın, hatalı satırı bulun ve düzeltin. | Alıştırma 8.7 | — | alistirmalar |
| `alistirmalar/H08_A08_hata_bul_birlestir.c` | C | BU DOSYA KASITLI HATA İÇERİR: birlestir bazı girdilerde düğüm kaybediyor (sonuç kısa çıkıyor). Hangi girdilerde? Hatalı satırı bulun ve Örnek 8'deki birleştirmeyle karşılaştırın. Düğümler yığındaki dizilerdir (malloc yok); kaybolan düğüm sızıntı değil, kayıp veridir. | Alıştırma 8.8 | — | alistirmalar |
| `alistirmalar/H08_A09_parsons_once_ekle.c` | C | AP-2 Hafta 8 · Alıştırma 8.9 (★★) — Parsons | Alıştırma 8.9 | — | alistirmalar |
| `alistirmalar/H08_A11_kutu_ok_atolye.c` | C | Önce main'deki altı işlem türünü (başa, sona, araya ekle; baştan sil; değere göre sil; ters çevir) kâğıtta kutu–ok çizerek izleyin (her adımda bas, son ve değişen bağlantılar); SONRA çalıştırıp çizimlerinizi karşılaştırın. | — | — | — |
| `alistirmalar/H08_A13_okuma.cpp` | C++ | Diller arası okuma (Python eşi: H08_A13_okuma.py). Program ne yazdırır? Bağımsız değişkenle n = 1000000 verilirse ne olabilir, neden? Python sürümünde aynı soru neden doğmaz? | — | — | — |
| `alistirmalar/H08_A13_okuma.py` | Python | Diller arası okuma (C++ eşi: H08_A13_okuma.cpp). Program ne yazdırır? n = 1000000 verilince belleği kim, ne zaman geri alır? | — | — | — |
| `alistirmalar/H08_A14_sizinti_avi.c` | C | BU DOSYA KASITLI HATA İÇERİR: program doğru görünen çıktılar verir, ama belleği eksik bırakır. ASan (LeakSanitizer) ile derleyip raporu okuyun; her rapor bloğunun yığın izinden ayrıldığı satırı bulun, düzeltin ve rapor temizlenene kadar yineleyin; sonra Valgrind ile doğrulayın. | — | — | — |
| `alistirmalar/H08_A15_liste_kutuphanesi/liste.h` | C (başlık) | AP-2 Hafta 8 · Atölye 2: liste kütüphanesinin ARAYÜZÜ | 11.9 | — | — |
| `alistirmalar/H08_A15_liste_kutuphanesi/liste_test.c` | C | AP-2 Hafta 8 · Atölye 2: liste.h için birim testleri | 11.9 | — | — |


## 6. Quiz (quiz/)

Web sayfasındaki haftalık quiz'in kodlu soruları bu dosyalardan birebir alınır (`#h08-quiz`). Çıktılar yanıttır; bu klasörde yoktur.

| Dosya | Dil | Amaç |
|---|---|---|
| `quiz/H08_Q01_izleme.c` | C | İzleme sorusu: program ne yazdırır? |
| `quiz/H08_Q05_floyd.c` | C | n = 8 düğüm (0..7); son düğüm 2'ye bağlı. Kaplumbağa (1 adım) ile tavşan (2 adım) baştan başlarsa hangi düğümde buluşur? |
| `quiz/H08_Q06_insert.py` | Python | n öğeyi list.insert(0, x) ile başa eklemenin toplam maliyeti? |


## 7. Denetim dosyaları

- `BELLEK_DENETIMI.txt` — ASan/UBSan/LSan ve Valgrind sonuçları (araç sürümleri, komutlar, dosya başına sonuç); doğrulama kanıtıdır, yanıt değildir.
- `esdeger_test.py` — üç dilli eşdeğerlik denetimi (ortak varlıklardan kopya).
- `ornekler.json` — örnek üst verisi.

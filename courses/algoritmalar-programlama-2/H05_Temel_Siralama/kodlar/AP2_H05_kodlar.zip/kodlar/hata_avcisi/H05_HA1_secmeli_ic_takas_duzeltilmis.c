/* H05_HA1_secmeli_ic_takas_duzeltilmis.c — AP-2 Hafta 5 · Hata Avcısı 1
 * DÜZELTİLMİŞ: iç döngü yalnızca en küçüğün indisini günceller; takas
 * dış döngüde, geçiş başına en fazla bir kez yapılır (en fazla n - 1).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA1_secmeli_ic_takas_duzeltilmis.c \
 *           -o H05_HA1_secmeli_ic_takas_duzeltilmis
 */
#include <stdio.h>

static long long takas_sayisi = 0;

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
    takas_sayisi++;
}

static void secmeli_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en_kucuk = i;
        for (size_t j = i + 1; j < n; j++) {
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;           /* yalnızca indisi hatırla */
            }
        }
        if (en_kucuk != i) {
            takas(&a[i], &a[en_kucuk]); /* geçiş başına en çok 1 takas */
        }
    }
}

static void calistir(int *a, size_t n, const char *ad)
{
    takas_sayisi = 0;
    secmeli_sirala(a, n);
    int sirali = 1;
    for (size_t k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            sirali = 0;
        }
    }
    printf("%-12s n = %4zu  sıralı: %s  takas = %6lld  (n - 1 = %zu)\n",
           ad, n, sirali ? "evet" : "HAYIR", takas_sayisi, n - 1);
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 39, 12};
    int ters[1000];
    for (int k = 0; k < 1000; k++) {
        ters[k] = 1000 - k;
    }
    calistir(a, 8, "örnek dizi");
    calistir(ters, 1000, "ters sıralı");
    return 0;
}

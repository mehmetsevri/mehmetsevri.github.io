"""H05_HA9_sort_none.py — AP-2 Hafta 5 · Hata Avcısı 9 (Python)
BU DOSYA KASITLI HATA İÇERİR: notlar = notlar.sort(). list.sort()
listeyi YERİNDE sıralar ve None döndürür; atama listeyi None ile
değiştirir. Bir sonraki satır TypeError ile durur (bkz. ciktilar/).
Çalıştır: python3 H05_HA9_sort_none.py
Düzeltme: H05_HA9_sort_none_duzeltilmis.py
"""


def main():
    notlar = [78, 65, 90, 78, 55]
    notlar = notlar.sort()               # HATA: sort() None döndürür
    print("sıralı notlar:", notlar)
    print("en düşük not:", notlar[0])


if __name__ == "__main__":
    main()

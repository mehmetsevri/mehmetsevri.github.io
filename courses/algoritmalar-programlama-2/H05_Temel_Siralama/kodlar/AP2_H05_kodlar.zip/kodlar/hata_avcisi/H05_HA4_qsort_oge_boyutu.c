/* H05_HA4_qsort_oge_boyutu.c — AP-2 Hafta 5 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ: qsort'a öğe boyutu
 * olarak sizeof(a) verilmiş. a bir İŞARETÇİ olduğundan sizeof(a) = 8
 * (x86-64), öğe ise int (4 bayt). qsort diziyi 8 baytlık n öğe sanır:
 * ayrılan bölgenin iki katını okur/yazar (öbek taşması) ve karşılaştırıcı
 * yanlış adreslerden okur. Derleyici uyarı vermez.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA4_qsort_oge_boyutu.c -o H05_HA4_qsort_oge_boyutu
 * Denetim : aynı komuta -fsanitize=address -g eklenir
 * Düzeltme: H05_HA4_qsort_oge_boyutu_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

static int int_artan(const void *p, const void *q)
{
    int x = *(const int *)p;
    int y = *(const int *)q;
    return (x > y) - (x < y);
}

int main(void)
{
    const int veri[] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = sizeof veri / sizeof veri[0];
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t k = 0; k < n; k++) {
        a[k] = veri[k];
    }
    printf("sizeof(a) = %zu, sizeof(a[0]) = %zu\n", sizeof(a), sizeof(a[0]));
    qsort(a, n, sizeof(a), int_artan);       /* HATA: işaretçinin boyutu */
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
    free(a);
    return 0;
}

/* H05_HA2_kosul_sirasi_duzeltilmis.c — AP-2 Hafta 5 · Hata Avcısı 2
 * DÜZELTİLMİŞ: koruma koşulu önce gelir: "j >= 0 && a[j] > anahtar".
 * j = -1 olduğunda && kısa devre yapar ve a[-1] hiç okunmaz.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA2_kosul_sirasi_duzeltilmis.c \
 *           -o H05_HA2_kosul_sirasi_duzeltilmis
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && a[j] > anahtar) {   /* önce sınır, sonra değer */
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

int main(void)
{
    const int veri[] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = sizeof veri / sizeof veri[0];
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t k = 0; k < n; k++) {
        a[k] = veri[k];
    }
    araya_ekleme_sirala(a, n);
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
    free(a);
    return 0;
}

"""H05_HA10_dongu_siniri_duzeltilmis.py — AP-2 Hafta 5 · Hata Avcısı 10
DÜZELTİLMİŞ: range(n - 1 - i); erişilen en büyük indis j + 1 = n - 1 - i.
Çalıştır: python3 H05_HA10_dongu_siniri_duzeltilmis.py
"""


def kabarcik_sirala(a):
    n = len(a)
    for i in range(n - 1):
        for j in range(n - 1 - i):              # a[j + 1] içeride
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]


def main():
    a = [42, 17, 8, 31, 25, 4, 39, 12]
    kabarcik_sirala(a)
    print("sonuç:", *a)


if __name__ == "__main__":
    main()

/* H05_HA8_strcmp_turkce_duzeltilmis.c — AP-2 Hafta 5 · Hata Avcısı 8
 * DÜZELTİLMİŞ (en küçük çözüm): UTF-8 metinden kod noktaları okunur ve
 * her harf Türkçe alfabedeki sırasına (A B C Ç D E F G Ğ H I İ J K L M N
 * O Ö P R S Ş T U Ü V Y Z) çevrilerek karşılaştırılır; büyük/küçük harf
 * aynı sırayı alır (I/ı ve İ/i ayrı harflerdir). Eşitlikte strcmp ile
 * karar verilir. Tam sürüm: Mini-OBS 2 v2.4 (Türkçe karşılaştırıcı).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA8_strcmp_turkce_duzeltilmis.c \
 *           -o H05_HA8_strcmp_turkce_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* UTF-8'den bir kod noktası okur (1 ya da 2 baytlık dizi), *s ilerler */
static unsigned kod_noktasi(const unsigned char **s)
{
    const unsigned char *p = *s;
    if (p[0] < 0x80) {
        *s += 1;
        return p[0];
    }
    if ((p[0] & 0xE0) == 0xC0 && (p[1] & 0xC0) == 0x80) {
        *s += 2;
        return ((unsigned)(p[0] & 0x1F) << 6) | (p[1] & 0x3F);
    }
    *s += 1;                       /* desteklenmeyen dizi: tek bayt */
    return p[0];
}

/* Türkçe alfabe sırası 0..28; harf değilse 100 + kod noktası */
static unsigned harf_sirasi(unsigned c)
{
    static const unsigned buyuk[29] = {
        'A', 'B', 'C', 0xC7, 'D', 'E', 'F', 'G', 0x11E, 'H', 'I', 0x130,
        'J', 'K', 'L', 'M', 'N', 'O', 0xD6, 'P', 'R', 'S', 0x15E, 'T',
        'U', 0xDC, 'V', 'Y', 'Z'};
    static const unsigned kucuk[29] = {
        'a', 'b', 'c', 0xE7, 'd', 'e', 'f', 'g', 0x11F, 'h', 0x131, 'i',
        'j', 'k', 'l', 'm', 'n', 'o', 0xF6, 'p', 'r', 's', 0x15F, 't',
        'u', 0xFC, 'v', 'y', 'z'};
    for (unsigned k = 0; k < 29; k++) {
        if (c == buyuk[k] || c == kucuk[k]) {
            return k;
        }
    }
    return 100 + c;
}

static int turkce_karsilastir(const char *x, const char *y)
{
    const unsigned char *p = (const unsigned char *)x;
    const unsigned char *q = (const unsigned char *)y;
    while (*p != '\0' && *q != '\0') {
        unsigned a = harf_sirasi(kod_noktasi(&p));
        unsigned b = harf_sirasi(kod_noktasi(&q));
        if (a != b) {
            return (a > b) - (a < b);
        }
    }
    if (*p != *q) {                /* biri bitti: kısa olan önce */
        return *p == '\0' ? -1 : 1;
    }
    return strcmp(x, y);           /* yalnızca büyük/küçük harf farkı */
}

static int dizgi_artan(const void *p, const void *q)
{
    return turkce_karsilastir(*(const char *const *)p,
                              *(const char *const *)q);
}

int main(void)
{
    const char *s[] = {"Zeki", "Çelik", "Şahin", "Ilgaz", "İnce", "Öztürk",
                       "Uslu", "Ünal", "Can", "Demir", "Oral", "Sarı"};
    size_t n = sizeof s / sizeof s[0];
    qsort(s, n, sizeof s[0], dizgi_artan);
    printf("Türkçe alfabe sırası:");
    for (size_t k = 0; k < n; k++) {
        printf(" %s", s[k]);
    }
    printf("\nturkce_karsilastir(\"Çelik\", \"Zeki\") = %d  (< 0: Çelik "
           "önce gelir)\n", turkce_karsilastir("Çelik", "Zeki"));
    return 0;
}

"""H05_HA2_kosul_sirasi.py — AP-2 Hafta 5 · Hata Avcısı 2 (Python)
BU DOSYA KASITLI HATA İÇERİR: koşul "a[j] > anahtar and j >= 0"
sırasıyla yazılmış. Python'da a[-1] dizi dışı DEĞİLDİR: listenin SON
elemanını okur. Program çökmez, sonuç da doğru çıkabilir; ama her j = -1
anında anlamsız bir karşılaştırma yapılır (sayaçta görünür). Aynı kod
C'de dizi dışı okumadır (tanımsız davranış).
Çalıştır: python3 H05_HA2_kosul_sirasi.py
Düzeltme: H05_HA2_kosul_sirasi_duzeltilmis.py
"""

karsilastirma = 0
eksi_bir_okuma = 0


def buyuk_mu(a, j, anahtar):
    """a[j] > anahtar karşılaştırmasını sayar; a[-1] okumalarını da sayar"""
    global karsilastirma, eksi_bir_okuma
    karsilastirma += 1
    if j < 0:
        eksi_bir_okuma += 1
    return a[j] > anahtar


def araya_ekleme_sirala(a):
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while buyuk_mu(a, j, anahtar) and j >= 0:   # HATA: koşul sırası
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = anahtar


def main():
    a = [42, 17, 8, 31, 25, 4, 39, 12]
    araya_ekleme_sirala(a)
    print("sonuç:", *a)
    print(f"karşılaştırma = {karsilastirma}, a[-1] okuması = "
          f"{eksi_bir_okuma}")


if __name__ == "__main__":
    main()

"""H05_HA10_dongu_siniri.py — AP-2 Hafta 5 · Hata Avcısı 10 (Python)
BU DOSYA KASITLI HATA İÇERİR: kabarcık sıralamasında iç döngü sınırı
bir fazla: range(n - i) (doğrusu range(n - 1 - i)). İlk geçişte j = n - 1
iken a[j + 1] = a[n] istenir: Python IndexError fırlatır (C'de aynı
hata sessiz dizi dışı erişimdir).
Çalıştır: python3 H05_HA10_dongu_siniri.py
Düzeltme: H05_HA10_dongu_siniri_duzeltilmis.py
"""


def kabarcik_sirala(a):
    n = len(a)
    for i in range(n - 1):
        for j in range(n - i):                  # HATA: bir fazla
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]


def main():
    a = [42, 17, 8, 31, 25, 4, 39, 12]
    kabarcik_sirala(a)
    print("sonuç:", *a)


if __name__ == "__main__":
    main()

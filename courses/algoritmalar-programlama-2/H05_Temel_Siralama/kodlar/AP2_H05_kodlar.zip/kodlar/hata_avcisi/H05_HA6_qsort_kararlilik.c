/* H05_HA6_qsort_kararlilik.c — AP-2 Hafta 5 · Hata Avcısı 6
 * BU DOSYA KASITLI HATA İÇERİR: qsort'un KARARLI olduğu varsayılmış.
 * Çok anahtarlı sıra (ortalama azalan, eşitse ad artan) iki ardışık
 * qsort geçişiyle kurulmaya çalışılıyor: önce ada, sonra ortalamaya göre.
 * Bu yalnızca ikinci geçiş kararlıysa doğrudur. C standardı qsort'un
 * algoritmasını ve kararlılığını belirtmez: "eşit öğelerin sonuçtaki
 * sırası belirtilmemiştir". Bu makinedeki glibc'de sonuç doğru
 * görünebilir; standarda uyan başka bir qsort (burada: seçmeli
 * sıralamayla yazılmış secmeli_qsort) aynı kodu bozar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA6_qsort_kararlilik.c -o H05_HA6_qsort_kararlilik
 * Düzeltme: H05_HA6_qsort_kararlilik_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char ad[16];
    double ortalama;
} Ogrenci;

typedef void (*qsort_turu)(void *, size_t, size_t,
                           int (*)(const void *, const void *));

/* qsort ile aynı arayüz; standarda uygun ama KARARSIZ (seçmeli) */
static void secmeli_qsort(void *taban, size_t n, size_t boyut,
                          int (*kars)(const void *, const void *))
{
    char *a = taban;
    char gecici[64];                  /* örnekte boyut <= 64 */
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en = i;
        for (size_t j = i + 1; j < n; j++) {
            if (kars(a + j * boyut, a + en * boyut) < 0) {
                en = j;
            }
        }
        if (en != i) {
            memcpy(gecici, a + i * boyut, boyut);
            memcpy(a + i * boyut, a + en * boyut, boyut);
            memcpy(a + en * boyut, gecici, boyut);
        }
    }
}

static int ad_artan(const void *p, const void *q)
{
    return strcmp(((const Ogrenci *)p)->ad, ((const Ogrenci *)q)->ad);
}

static int ortalama_azalan(const void *p, const void *q)
{
    double x = ((const Ogrenci *)p)->ortalama;
    double y = ((const Ogrenci *)q)->ortalama;
    return (x < y) - (x > y);
}

static void dene(const char *ad, qsort_turu sirala, const Ogrenci *girdi,
                 size_t n)
{
    Ogrenci a[16];
    memcpy(a, girdi, n * sizeof a[0]);
    sirala(a, n, sizeof a[0], ad_artan);         /* 1. geçiş: ad */
    sirala(a, n, sizeof a[0], ortalama_azalan);  /* 2. geçiş: ortalama */
    int dogru = 1;
    printf("%s:\n  ", ad);
    for (size_t k = 0; k < n; k++) {
        printf(" %.0f %s", a[k].ortalama, a[k].ad);
        if (k > 0 && a[k - 1].ortalama == a[k].ortalama &&
            strcmp(a[k - 1].ad, a[k].ad) > 0) {
            dogru = 0;                           /* eşit puanda ad sırası */
        }
    }
    printf("\n   eşit ortalamada ad sırası doğru mu? %s\n",
           dogru ? "evet" : "HAYIR");
}

int main(void)
{
    const Ogrenci g[] = {{"Selin", 80}, {"Ali", 90}, {"Mert", 80},
                         {"Deniz", 70}, {"Burak", 90}, {"Ceren", 80},
                         {"Ebru", 70}, {"Kaan", 90}};
    size_t n = sizeof g / sizeof g[0];
    dene("glibc qsort (bu makine)", qsort, g, n);
    dene("secmeli_qsort (standarda uygun, kararsız)", secmeli_qsort, g, n);
    return 0;
}

/* H05_HA8_strcmp_turkce.c — AP-2 Hafta 5 · Hata Avcısı 8
 * BU DOSYA KASITLI HATA İÇERİR: Türkçe soyadları strcmp ile sıralanıyor.
 * strcmp BAYT sırasıyla karşılaştırır. UTF-8'de Ç, Ö, Ü (C3 xx), İ
 * (C4 B0) ve Ş (C5 9E) iki baytlıdır ve ilk baytları tüm ASCII
 * harflerinden büyüktür: "Çelik", "Zeki"den SONRA gelir. Sonuç Türkçe
 * alfabe sırası değildir. (Python'da sorted() da kod noktası sırası
 * kullandığı için aynı sonucu verir.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA8_strcmp_turkce.c -o H05_HA8_strcmp_turkce
 * Düzeltme: H05_HA8_strcmp_turkce_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int dizgi_artan(const void *p, const void *q)
{
    return strcmp(*(const char *const *)p, *(const char *const *)q);
}

int main(void)
{
    const char *s[] = {"Zeki", "Çelik", "Şahin", "Ilgaz", "İnce", "Öztürk",
                       "Uslu", "Ünal", "Can", "Demir", "Oral", "Sarı"};
    size_t n = sizeof s / sizeof s[0];
    qsort(s, n, sizeof s[0], dizgi_artan);   /* HATA: bayt sırası */
    printf("strcmp sırası:");
    for (size_t k = 0; k < n; k++) {
        printf(" %s", s[k]);
    }
    printf("\nstrcmp(\"Çelik\", \"Zeki\") > 0 mı? %s (Çelik sonra gelir)\n",
           strcmp("Çelik", "Zeki") > 0 ? "evet" : "hayır");
    printf("ilk baytlar: 'Ç' = 0x%02X, 'Z' = 0x%02X\n",
           (unsigned char)"Ç"[0], (unsigned char)"Z"[0]);
    return 0;
}

/* H05_HA5_karsilastirici_imzasi_duzeltilmis.c — AP-2 Hafta 5 · Hata Avcısı 5
 * DÜZELTİLMİŞ: imza qsort'un beklediği (const void *, const void *);
 * gelen adres önce "char * öğesinin adresi" (const char *const *)
 * olarak yorumlanır, sonra bir kez çözülerek dizgiye ulaşılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA5_karsilastirici_imzasi_duzeltilmis.c \
 *           -o H05_HA5_karsilastirici_imzasi_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int dizgi_artan(const void *p, const void *q)
{
    const char *x = *(const char *const *)p;   /* öğe: char * */
    const char *y = *(const char *const *)q;
    return strcmp(x, y);
}

int main(void)
{
    const char *s[] = {"elma", "kivi", "armut", "nar", "incir", "ayva",
                       "dut"};
    size_t n = sizeof s / sizeof s[0];
    qsort(s, n, sizeof s[0], dizgi_artan);
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %s", s[k]);
    }
    printf("\n");
    return 0;
}

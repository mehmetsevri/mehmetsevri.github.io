/* H05_HA11_erken_cikis_bayragi_duzeltilmis.c — AP-2 Hafta 5 · Hata Avcısı 11
 * DÜZELTİLMİŞ: bayrak her GEÇİŞİN başında bir kez sıfırlanır ve iç
 * döngüde yalnızca takas olduğunda 1 yapılır. (Bayrağı hiç sıfırlamamak
 * da hatadır: sonuç doğru olur ama erken çıkış hiç çalışmaz.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA11_erken_cikis_bayragi_duzeltilmis.c \
 *           -o H05_HA11_erken_cikis_bayragi_duzeltilmis
 */
#include <stdio.h>

static int gecis_sayisi = 0;

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

static void kabarcik_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;                  /* geçişin başında */
        for (size_t j = 0; j + 1 < n - i; j++) {
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
                takas_oldu = 1;
            }
        }
        gecis_sayisi++;
        if (!takas_oldu) {
            break;
        }
    }
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 12, 99};
    size_t n = sizeof a / sizeof a[0];
    kabarcik_sirala(a, n);
    int sirali = 1;
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
        if (k > 0 && a[k - 1] > a[k]) {
            sirali = 0;
        }
    }
    printf("\ngeçiş = %d, sıralı mı? %s\n", gecis_sayisi,
           sirali ? "evet" : "HAYIR");
    return 0;
}

/* H05_HA11_erken_cikis_bayragi.c — AP-2 Hafta 5 · Hata Avcısı 11
 * BU DOSYA KASITLI HATA İÇERİR: kabarcık sıralamasında erken çıkış
 * bayrağı YANLIŞ YERDE sıfırlanıyor: geçişin başında değil, iç döngünün
 * her adımında. Böylece bayrak "bu geçişte takas oldu mu?" yerine "SON
 * karşılaştırmada takas oldu mu?" sorusunu yanıtlar. Geçişin son çifti
 * zaten sıralıysa döngü erkenden biter ve dizi sırasız kalır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA11_erken_cikis_bayragi.c -o H05_HA11_erken_cikis_bayragi
 * Düzeltme: H05_HA11_erken_cikis_bayragi_duzeltilmis.c
 */
#include <stdio.h>

static int gecis_sayisi = 0;

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

static void kabarcik_sirala(int *a, size_t n)
{
    int takas_oldu = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = 0; j + 1 < n - i; j++) {
            takas_oldu = 0;                  /* HATA: yanlış yer */
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
                takas_oldu = 1;
            }
        }
        gecis_sayisi++;
        if (!takas_oldu) {
            break;
        }
    }
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 12, 99};
    size_t n = sizeof a / sizeof a[0];
    kabarcik_sirala(a, n);
    int sirali = 1;
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
        if (k > 0 && a[k - 1] > a[k]) {
            sirali = 0;
        }
    }
    printf("\ngeçiş = %d, sıralı mı? %s\n", gecis_sayisi,
           sirali ? "evet" : "HAYIR");
    return 0;
}

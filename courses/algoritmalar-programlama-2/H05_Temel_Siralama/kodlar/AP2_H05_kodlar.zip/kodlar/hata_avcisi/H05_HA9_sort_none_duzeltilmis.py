"""H05_HA9_sort_none_duzeltilmis.py — AP-2 Hafta 5 · Hata Avcısı 9
DÜZELTİLMİŞ: ya yerinde sırala ve dönüş değerini kullanma
(notlar.sort()), ya da yeni liste üret (sirali = sorted(notlar)).
Çalıştır: python3 H05_HA9_sort_none_duzeltilmis.py
"""


def main():
    notlar = [78, 65, 90, 78, 55]
    sirali = sorted(notlar)              # yeni liste; notlar değişmez
    notlar.sort()                        # yerinde; dönüş değeri None
    print("sıralı notlar:", notlar)
    print("en düşük not:", notlar[0])
    print("sorted() ile aynı mı?", sirali == notlar)


if __name__ == "__main__":
    main()

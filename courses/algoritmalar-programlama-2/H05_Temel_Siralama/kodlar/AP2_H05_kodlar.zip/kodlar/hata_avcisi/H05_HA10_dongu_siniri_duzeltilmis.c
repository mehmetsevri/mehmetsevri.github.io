/* H05_HA10_dongu_siniri_duzeltilmis.c — AP-2 Hafta 5 · Hata Avcısı 10
 * DÜZELTİLMİŞ: iç döngü "j + 1 < n - i": karşılaştırılan son çift
 * (a[n-2-i], a[n-1-i]) dizinin içindedir. Sınırı a[j + 1]'e bakarak
 * yazın: erişilen en büyük indis j + 1'dir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA10_dongu_siniri_duzeltilmis.c \
 *           -o H05_HA10_dongu_siniri_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

static void kabarcik_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = 0; j + 1 < n - i; j++) { /* a[j + 1] içeride */
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
            }
        }
    }
}

int main(void)
{
    const int veri[] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = sizeof veri / sizeof veri[0];
    int *a = calloc(n, sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t k = 0; k < n; k++) {
        a[k] = veri[k];
    }
    kabarcik_sirala(a, n);
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
    free(a);
    return 0;
}

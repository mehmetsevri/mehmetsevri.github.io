/* H05_HA3_fark_karsilastirici_duzeltilmis.c — AP-2 Hafta 5 · Hata Avcısı 3
 * DÜZELTİLMİŞ: iki karşılaştırıcı da (x > y) - (x < y) döndürür: sonuç
 * -1, 0 ya da 1'dir; ne taşma ne kesme olur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA3_fark_karsilastirici_duzeltilmis.c \
 *           -o H05_HA3_fark_karsilastirici_duzeltilmis
 */
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

static int int_artan(const void *p, const void *q)
{
    int x = *(const int *)p;
    int y = *(const int *)q;
    return (x > y) - (x < y);
}

static int double_artan(const void *p, const void *q)
{
    double x = *(const double *)p;
    double y = *(const double *)q;
    return (x > y) - (x < y);
}

int main(void)
{
    int a[] = {3, INT_MAX, -1, 0, INT_MIN, 7};
    size_t na = sizeof a / sizeof a[0];
    qsort(a, na, sizeof a[0], int_artan);
    printf("int   :");
    for (size_t k = 0; k < na; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");

    double d[] = {0.75, 0.25, 0.5, 0.1, 0.3, 2.5, 1.5};
    size_t nd = sizeof d / sizeof d[0];
    qsort(d, nd, sizeof d[0], double_artan);
    printf("double:");
    for (size_t k = 0; k < nd; k++) {
        printf(" %.2f", d[k]);
    }
    printf("\n");
    return 0;
}

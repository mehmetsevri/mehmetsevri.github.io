/* H05_HA2_kosul_sirasi.c — AP-2 Hafta 5 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ: araya eklemede
 * koşul "a[j] > anahtar && j >= 0" sırasıyla yazılmış. j = -1 olduğunda
 * önce a[-1] okunur (dizi dışı okuma), sonra j >= 0 denetlenir. Kısa
 * devre burada işe yaramaz: koruma koşulu SONDA olduğu için geç kalır.
 * Bu derleyicide ve bu çalıştırmada sonuç doğru görünebilir; hatayı
 * AddressSanitizer yakalar (bkz. ciktilar/).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA2_kosul_sirasi.c -o H05_HA2_kosul_sirasi
 * Denetim : aynı komuta -fsanitize=address -g eklenir
 * Düzeltme: H05_HA2_kosul_sirasi_duzeltilmis.c
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (a[j] > anahtar && j >= 0) {   /* HATA: koşul sırası */
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

int main(void)
{
    const int veri[] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = sizeof veri / sizeof veri[0];
    int *a = malloc(n * sizeof *a);          /* öbekte: ASan sınırı bilir */
    if (a == NULL) {
        return 1;
    }
    for (size_t k = 0; k < n; k++) {
        a[k] = veri[k];
    }
    araya_ekleme_sirala(a, n);
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
    free(a);
    return 0;
}

/* H05_HA7_kararsiz_gecisler_duzeltilmis.cpp — AP-2 Hafta 5 · Hata Avcısı 7
 * DÜZELTİLMİŞ: ikinci (ve her) geçiş std::stable_sort ile yapılır; eşit
 * ortalamalılar birinci geçişin kurduğu ad sırasını korur. (Başka çözüm:
 * tek geçiş + iki anahtarlı yüklem.)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA7_kararsiz_gecisler_duzeltilmis.cpp \
 *           -o H05_HA7_kararsiz_gecisler_duzeltilmis
 */
#include <algorithm>
#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

struct Ogrenci {
    std::string ad;
    int ortalama;
};

// n kayıt: adlar Ad01..Adnn (karışık sırada), ortalama 60/70/80/90
static std::vector<Ogrenci> kayitlar(int n)
{
    std::vector<Ogrenci> a;
    unsigned durum = 7;
    for (int i = 0; i < n; i++) {
        durum = durum * 1103515245u + 12345u;     // basit LCG (yalnız veri)
        int sira = (i * 7) % n + 1;               // 7 ile n aralarında asal
        std::string ad = "Ad" + std::string(sira < 10 ? "0" : "") +
                         std::to_string(sira);
        a.push_back({ad, 60 + 10 * static_cast<int>((durum >> 16) % 4)});
    }
    return a;
}

static void dene(int n)
{
    std::vector<Ogrenci> a = kayitlar(n);
    std::stable_sort(a.begin(), a.end(),          // 1. geçiş: ad
              [](const Ogrenci& x, const Ogrenci& y) { return x.ad < y.ad; });
    std::stable_sort(a.begin(), a.end(),          // 2. geçiş: ortalama
              [](const Ogrenci& x, const Ogrenci& y) {
                  return x.ortalama > y.ortalama;
              });
    int bozuk = 0;
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1].ortalama == a[k].ortalama && a[k - 1].ad > a[k].ad) {
            bozuk++;
        }
    }
    std::cout << "n = " << n << ": eşit ortalamada ad sırası bozuk komşu "
              << "çifti = " << bozuk << (bozuk ? "  <- HATA" : "") << "\n";
    if (n == 24) {
        std::cout << "  ilk 8:";
        for (std::size_t k = 0; k < 8; k++) {
            std::cout << " " << a[k].ortalama << "/" << a[k].ad;
        }
        std::cout << "\n";
    }
}

int main()
{
    dene(10);
    dene(16);
    dene(24);
    return 0;
}

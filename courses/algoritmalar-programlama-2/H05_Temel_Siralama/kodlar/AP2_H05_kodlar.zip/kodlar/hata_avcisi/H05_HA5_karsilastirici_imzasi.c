/* H05_HA5_karsilastirici_imzasi.c — AP-2 Hafta 5 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ: dizgi dizisi için
 * karşılaştırıcı yanlış imzayla (const char *, const char *) yazılmış ve
 * qsort'a verilmiş. İki ayrı hata:
 *  (1) imza: qsort int (*)(const void *, const void *) bekler; GCC 13
 *      -Wincompatible-pointer-types UYARISI verir (GCC 14'ten itibaren C
 *      kipinde varsayılan olarak HATA). Uyumsuz türden çağrı tanımsızdır.
 *  (2) anlam: qsort karşılaştırıcıya öğelerin ADRESİNİ verir. Öğe bir
 *      char * olduğundan gelen değer aslında char ** türündedir; strcmp
 *      dizgileri değil, işaretçilerin baytlarını karşılaştırır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA5_karsilastirici_imzasi.c -o H05_HA5_karsilastirici_imzasi
 * Düzeltme: H05_HA5_karsilastirici_imzasi_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int dizgi_artan(const char *x, const char *y)   /* HATA: imza */
{
    return strcmp(x, y);           /* HATA: x, y öğenin adresidir */
}

int main(void)
{
    const char *s[] = {"elma", "kivi", "armut", "nar", "incir", "ayva",
                       "dut"};
    size_t n = sizeof s / sizeof s[0];
    qsort(s, n, sizeof s[0], dizgi_artan);
    printf("sonuç:");
    for (size_t k = 0; k < n; k++) {
        printf(" %s", s[k]);
    }
    printf("\n");
    return 0;
}

/* H05_HA3_fark_karsilastirici.c — AP-2 Hafta 5 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR — İKİ BÖLÜM DE TANIMSIZ DAVRANIŞ:
 *  (1) int karşılaştırıcısı "return x - y;": x = INT_MAX, y = -1 gibi
 *      değerlerde fark int'e sığmaz (işaretli taşma: tanımsız davranış);
 *      bu derleyicide sonuç işaret değiştirir ve sıra bozulur.
 *  (2) double karşılaştırıcısı "return (int)(x - y);": |x - y| < 1 olan
 *      her çift 0'a kesilir, yani "eşit" sayılır; dizi sıralanmaz. Bu
 *      "eşitlik" geçişli değildir (0.25 ~ 0.75 ~ 1.5 ama 0.25 < 1.5):
 *      qsort'un istediği tutarlı sıralama bozulur (o da tanımsız).
 * Derleyici uyarı vermez. Gözlenen: bkz. ciktilar/
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_HA3_fark_karsilastirici.c -o H05_HA3_fark_karsilastirici
 * Denetim : aynı komuta -fsanitize=undefined eklenir
 * Düzeltme: H05_HA3_fark_karsilastirici_duzeltilmis.c
 */
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

static int int_artan(const void *p, const void *q)
{
    int x = *(const int *)p;
    int y = *(const int *)q;
    return x - y;                    /* HATA: taşabilir */
}

static int double_artan(const void *p, const void *q)
{
    double x = *(const double *)p;
    double y = *(const double *)q;
    return (int)(x - y);             /* HATA: kesme, 0.3 - 0.1 -> 0 */
}

int main(void)
{
    int a[] = {3, INT_MAX, -1, 0, INT_MIN, 7};
    size_t na = sizeof a / sizeof a[0];
    qsort(a, na, sizeof a[0], int_artan);
    printf("int   :");
    for (size_t k = 0; k < na; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");

    double d[] = {0.75, 0.25, 0.5, 0.1, 0.3, 2.5, 1.5};
    size_t nd = sizeof d / sizeof d[0];
    qsort(d, nd, sizeof d[0], double_artan);
    printf("double:");
    for (size_t k = 0; k < nd; k++) {
        printf(" %.2f", d[k]);
    }
    printf("\n");
    return 0;
}

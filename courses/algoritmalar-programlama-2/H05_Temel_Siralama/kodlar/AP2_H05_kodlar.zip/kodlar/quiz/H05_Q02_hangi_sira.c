/* H05_Q02_hangi_sira.c — AP-2 Hafta 5 · Quiz sorusu 9
 * Amaç    : Bu karşılaştırıcıyla qsort hangi sırayı üretir?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_Q02_hangi_sira.c -o H05_Q02_hangi_sira
 * Çalıştır: ./H05_Q02_hangi_sira
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int no;
    int puan;
} Kayit;

static int kars(const void *p, const void *q)
{
    const Kayit *x = p;
    const Kayit *y = q;
    if (x->puan != y->puan) {
        return (y->puan > x->puan) - (y->puan < x->puan);
    }
    return (x->no > y->no) - (x->no < y->no);
}

int main(void)
{
    Kayit a[] = {{3, 70}, {1, 85}, {4, 70}, {2, 85}};
    qsort(a, 4, sizeof a[0], kars);
    for (int k = 0; k < 4; k++) {
        printf("%d ", a[k].no);
    }
    printf("\n");
    return 0;
}

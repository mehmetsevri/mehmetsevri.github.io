/* H05_Q01_kac_gecis.c — AP-2 Hafta 5 · Quiz sorusu 2
 * Amaç    : Erken çıkışlı kabarcık sıralaması bu girdide kaç geçiş yapar?
 *           (Önce tahmin edin, sonra çalıştırın.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_Q01_kac_gecis.c -o H05_Q01_kac_gecis
 * Çalıştır: ./H05_Q01_kac_gecis
 */
#include <stddef.h>
#include <stdio.h>

int main(void)
{
    int a[] = {2, 3, 4, 5, 1};
    size_t n = sizeof a / sizeof a[0];
    int gecis = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;
        for (size_t j = 0; j + 1 < n - i; j++) {
            if (a[j] > a[j + 1]) {
                int g = a[j];
                a[j] = a[j + 1];
                a[j + 1] = g;
                takas_oldu = 1;
            }
        }
        gecis++;
        if (!takas_oldu) {
            break;
        }
    }
    printf("geçiş = %d\n", gecis);
    return 0;
}

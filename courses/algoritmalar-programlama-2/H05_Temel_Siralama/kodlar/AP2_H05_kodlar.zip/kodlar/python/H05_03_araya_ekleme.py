"""H05_03_araya_ekleme.py — AP-2 Hafta 5 · Örnek 3 (★)
Amaç    : Araya ekleme sıralaması: anahtarı sıralı öneke kaydırarak
          yerleştirme; değişmez (a[0..i] sıralı) ve çevrimiçi ekleme
Çalıştır: python3 H05_03_araya_ekleme.py
Eşleri  : c/H05_03_araya_ekleme.c · cpp/H05_03_araya_ekleme.cpp
Çıktı   : üç dilde aynı (=)
"""

karsilastirma = 0
kaydirma = 0


def dizi_yaz(a, sinir):
    """a'yı yazar; sinir < len(a) ise a[sinir]'dan önce '|' koyar"""
    for k in range(len(a)):
        if k == sinir:
            print(" |", end="")
        print(f"{a[k]:3d}", end="")
    print()


def buyuk_mu(x, y):
    """x > y karşılaştırmasını sayarak yapar"""
    global karsilastirma
    karsilastirma += 1
    return x > y


def yerlestir(a, i):
    """a[0..i-1] sıralı; a[i]'yi kaydırarak yerine koyar, konumu döner"""
    global kaydirma
    anahtar = a[i]
    j = i - 1
    while j >= 0 and buyuk_mu(a[j], anahtar):
        a[j + 1] = a[j]    # bir sağa kaydır
        kaydirma += 1
        j -= 1
    a[j + 1] = anahtar
    return j + 1


def araya_ekleme_sirala(a, yazdir):
    for i in range(1, len(a)):
        anahtar = a[i]
        onceki = kaydirma
        yer = yerlestir(a, i)
        if yazdir:
            print(f"i = {i}: anahtar = {anahtar:2d}, kaydırma = "
                  f"{kaydirma - onceki}, yeri a[{yer}]")
            print("      ", end="")
            dizi_yaz(a, i + 1)


def main():
    global karsilastirma, kaydirma
    a = [42, 17, 8, 31, 25, 4, 39, 12]

    print(f"Araya ekleme sıralaması, n = {len(a)} ('|' solu: sıralı önek)")
    print("başlangıç:\n      ", end="")
    dizi_yaz(a, 1)
    araya_ekleme_sirala(a, True)
    print(f"toplam: karşılaştırma = {karsilastirma}, kaydırma = {kaydirma}")

    print("\nÇevrimiçi: yeni gelen eleman sıralı diziye eklenir")
    for x in (15, 50, 1):
        karsilastirma = 0
        kaydirma = 0
        a.append(x)                        # sona ekle ...
        yer = yerlestir(a, len(a) - 1)     # ... ve yerine kaydır
        print(f"+{x:2d} -> yeri a[{yer}], karşılaştırma = {karsilastirma}, "
              f"kaydırma = {kaydirma}\n      ", end="")
        dizi_yaz(a, len(a))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort; C++ — std::sort, sıralı vektöre ekleme
# için std::upper_bound + insert; Python — bisect.insort (yalnızca not).

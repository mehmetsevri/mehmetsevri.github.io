"""H05_07_qsort_arayuzu.py — AP-2 Hafta 5 · Örnek 7 (★★)
Amaç    : Genel sıralama arayüzü (qsort · std::sort · sorted): int,
          double ve dizgi dizileri; taşmaya güvenli karşılaştırıcı
Çalıştır: python3 H05_07_qsort_arayuzu.py
Eşleri  : c/H05_07_qsort_arayuzu.c · cpp/H05_07_qsort_arayuzu.cpp
Çıktı   : üç dilde aynı (=)
"""

import functools

INT_MAX = 2**31 - 1        # C'deki INT_MAX ve INT_MIN (32 bitlik int)
INT_MIN = -2**31


def int_artan(x, y):
    """C tarzı karşılaştırıcı: -1, 0, 1 (cmp_to_key ile kullanılır)"""
    return (x > y) - (x < y)   # Python'da x - y de taşmaz (sınırsız int)


def int_yaz(etiket, a):
    print(f"   {etiket}:" + "".join(f" {x}" for x in a))


def double_yaz(etiket, a):
    print(f"   {etiket}:" + "".join(f" {x:.2f}" for x in a))


def dizgi_yaz(etiket, a):
    print(f"   {etiket}:" + "".join(f" {x}" for x in a))


def main():
    a = [3, -7, INT_MAX, 0, INT_MIN, 42, -1, 7]
    print("1) int dizisi: qsort + taşmaya güvenli karşılaştırıcı")
    int_yaz("girdi ", a)
    a = sorted(a, key=functools.cmp_to_key(int_artan))
    int_yaz("artan ", a)
    a = sorted(a, reverse=True)
    int_yaz("azalan", a)
    fark = INT_MAX - (-1)
    print(f"   neden x - y değil? INT_MAX - (-1) = {fark} > INT_MAX = "
          f"{INT_MAX}")
    print("   (int'te taşma: C'de tanımsız davranış; bkz. Hata Avcısı)")

    d = [2.5, -0.75, 3.14, 0.1, -2.0, 0.3]
    print("\n2) double dizisi")
    double_yaz("girdi ", d)
    d = sorted(d)
    double_yaz("artan ", d)
    print(f"   (int)(0.1 - 0.3) = {int(0.1 - 0.3)}: kesme, farklı "
          "sayıları \"eşit\" gösterir")

    s = ["elma", "Zeki", "armut", "Çelik", "Can", "ali", "Şule"]
    print("\n3) dizgi dizisi: strcmp (bayt sırası)")
    dizgi_yaz("girdi ", s)
    s.sort()                 # yerinde; kod noktası = UTF-8 bayt sırası
    dizgi_yaz("artan ", s)
    print("   bayt sırası alfabe sırası değil: Ç ve Ş, z'den bile sonra "
          "(Mini-OBS 2 v2.4)")

    m = ["elma", "kivi", "armut", "nar", "incir", "ayva", "dut"]
    print("\n4) iki anahtarlı karşılaştırıcı: uzunluk, sonra alfabe")
    dizgi_yaz("girdi ", m)
    m = sorted(m, key=lambda x: (len(x), x))   # demet: sözlük sırası
    dizgi_yaz("sonuç ", m)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: bu örneğin konusu kütüphane arayüzüdür.
# C — qsort; C++ — std::sort + karşılaştırıcı; Python — sorted(key=…).

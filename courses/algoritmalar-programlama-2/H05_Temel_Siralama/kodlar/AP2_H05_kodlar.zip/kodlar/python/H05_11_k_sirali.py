"""H05_11_k_sirali.py — AP-2 Hafta 5 · Örnek 11 (★★★)
Amaç    : k-sıralı (neredeyse sıralı) dizide araya eklemenin O(nk)
          davranışı; kabarcık ve seçmeli ile karşılaştırma
Çalıştır: python3 H05_11_k_sirali.py
Eşleri  : c/H05_11_k_sirali.c · cpp/H05_11_k_sirali.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_tohum

karsilastirma = 0
takas_sayisi = 0
kaydirma = 0
gecis_sayisi = 0


def sayaclari_sifirla():
    global karsilastirma, takas_sayisi, kaydirma, gecis_sayisi
    karsilastirma = 0
    takas_sayisi = 0
    kaydirma = 0
    gecis_sayisi = 0


def k_sirali_dizi(n, k):
    """1..n sıralı dizi; (k + 1)'lik bloklar kendi içinde karıştırılır:
    her eleman sıralı konumundan en fazla k uzaktadır (k-sıralı)"""
    a = [i + 1 for i in range(n)]
    for bas in range(0, n, k + 1):
        son = bas + k if bas + k < n else n - 1     # blok: bas..son
        for i in range(son, bas, -1):               # Fisher–Yates
            j = bas + rastgele_aralik(0, i - bas)
            a[i], a[j] = a[j], a[i]
    return a


def en_buyuk_uzaklik(a):
    """En büyük |i - sıralı konum|: değer v'nin sıralı konumu v - 1"""
    en = 0
    for i in range(len(a)):
        d = abs(i - (a[i] - 1))
        if d > en:
            en = d
    return en


def araya_ekleme_sirala(a):
    global karsilastirma, kaydirma
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while j >= 0:
            karsilastirma += 1
            if a[j] <= anahtar:
                break
            a[j + 1] = a[j]
            kaydirma += 1
            j -= 1
        a[j + 1] = anahtar


def kabarcik_sirala(a):
    global karsilastirma, takas_sayisi, gecis_sayisi
    n = len(a)
    for i in range(n - 1):
        takas_oldu = False
        for j in range(n - 1 - i):
            karsilastirma += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                takas_sayisi += 1
                takas_oldu = True
        gecis_sayisi += 1
        if not takas_oldu:
            break


def secmeli_sirala(a):
    global karsilastirma, takas_sayisi
    n = len(a)
    for i in range(n - 1):
        en_kucuk = i
        for j in range(i + 1, n):
            karsilastirma += 1
            if a[j] < a[en_kucuk]:
                en_kucuk = j
        if en_kucuk != i:
            a[i], a[en_kucuk] = a[en_kucuk], a[i]
            takas_sayisi += 1


def main():
    n = 1000
    ks = [0, 1, 2, 4, 8, 16, 32, 64, n - 1]

    print("k-sıralı dizi: her eleman sıralı yerinden en fazla k uzakta")
    print(f"(1..n, (k+1)'lik bloklar içinde karıştırılmış; n = {n}, "
          "tohum 7)")
    print("kuram: kaydırma = ters çevrim <= n·k; kabarcık geçişi "
          "<= k + 1\n")
    print("            araya ekleme                kabarcık        "
          "seçmeli")
    print("   k  uzak.  kaydırma kayd/(nk)   karş.  geçiş     karş."
          "     karş.")
    rastgele_tohum(7)
    for k in ks:
        girdi = k_sirali_dizi(n, k)
        uzaklik = en_buyuk_uzaklik(girdi)

        a = girdi[:]
        sayaclari_sifirla()
        araya_ekleme_sirala(a)
        ae_kayd, ae_kars = kaydirma, karsilastirma

        a = girdi[:]
        sayaclari_sifirla()
        kabarcik_sirala(a)
        kb_gecis, kb_kars = gecis_sayisi, karsilastirma

        a = girdi[:]
        sayaclari_sifirla()
        secmeli_sirala(a)

        print(f"{k:4d} {uzaklik:6d} {ae_kayd:9d}", end="")
        if k > 0:
            print(f" {ae_kayd / (n * k):9.3f}", end="")
        else:
            print(f" {'-':>9}", end="")            # k = 0: n·k = 0
        print(f" {ae_kars:7d} {kb_gecis:6d} {kb_kars:9d} {karsilastirma:9d}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort
# (Timsort: girdideki sıralı parçalardan yararlanan uyarlanabilir
# sıralama).

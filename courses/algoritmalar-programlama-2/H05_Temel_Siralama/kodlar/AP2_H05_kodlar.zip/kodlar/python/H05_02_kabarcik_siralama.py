"""H05_02_kabarcik_siralama.py — AP-2 Hafta 5 · Örnek 2 (★)
Amaç    : Kabarcık sıralaması: komşu takası ve erken çıkış bayrağı;
          kaplumbağa (sonda küçük) ve tavşan (başta büyük) elemanlar
Çalıştır: python3 H05_02_kabarcik_siralama.py
Eşleri  : c/H05_02_kabarcik_siralama.c
          cpp/H05_02_kabarcik_siralama.cpp
Çıktı   : üç dilde aynı (=)
"""

karsilastirma = 0
takas_sayisi = 0
gecis_sayisi = 0


def dizi_yaz(a, sinir):
    """a'yı yazar; sinir < len(a) ise a[sinir]'dan önce '|' koyar"""
    for k in range(len(a)):
        if k == sinir:
            print(" |", end="")
        print(f"{a[k]:3d}", end="")
    print()


def kabarcik_sirala(a, yazdir):
    global karsilastirma, takas_sayisi, gecis_sayisi
    n = len(a)
    for i in range(n - 1):
        takas_oldu = False                # bu geçişte takas var mı?
        onceki = takas_sayisi
        for j in range(n - 1 - i):
            karsilastirma += 1
            if a[j] > a[j + 1]:           # komşular ters sırada
                a[j], a[j + 1] = a[j + 1], a[j]
                takas_sayisi += 1
                takas_oldu = True
        gecis_sayisi += 1
        if yazdir:
            print(f"geçiş {gecis_sayisi}: karşılaştırma = {n - 1 - i}, "
                  f"takas = {takas_sayisi - onceki}")
            print("      ", end="")
            dizi_yaz(a, n - 1 - i)
        if not takas_oldu:
            break                         # erken çıkış: dizi sıralı


def calistir(a, ad):
    global karsilastirma, takas_sayisi, gecis_sayisi
    karsilastirma = 0
    takas_sayisi = 0
    gecis_sayisi = 0
    kabarcik_sirala(a, False)
    print(f"{gecis_sayisi:5d} {karsilastirma:6d} {takas_sayisi:6d}   {ad}")


def main():
    a = [42, 17, 8, 31, 25, 4, 39, 12]
    n = len(a)

    print(f"Kabarcık sıralaması, n = {n} ('|' sağı: yerine oturanlar)")
    print("başlangıç:\n      ", end="")
    dizi_yaz(a, n)
    kabarcik_sirala(a, True)
    print(f"toplam: geçiş = {gecis_sayisi}, karşılaştırma = "
          f"{karsilastirma}, takas = {takas_sayisi}")

    print("\nErken çıkış bayrağının etkisi (n = 8):")
    print("geçiş  karş.  takas   girdi")
    calistir([1, 2, 3, 4, 5, 6, 7, 8], "sıralı")
    calistir([1, 2, 4, 3, 5, 6, 8, 7],
             "neredeyse sıralı (iki komşu takası)")
    calistir([8, 1, 2, 3, 4, 5, 6, 7],
             "tavşan: 8 başta (bir geçişte sona gider)")
    calistir([2, 3, 4, 5, 6, 7, 8, 1],
             "kaplumbağa: 1 sonda (geçiş başına 1 adım)")
    calistir([8, 7, 6, 5, 4, 3, 2, 1], "ters sıralı (en kötü durum)")
    print(f"en fazla: n - 1 = {8 - 1} geçiş, n(n-1)/2 = {8 * 7 // 2} "
          "karşılaştırma")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort; C++ — std::sort (kararsız) ve
# std::stable_sort; Python — list.sort() / sorted() (yalnızca kâhin).

"""H05_09_kararlilik.py — AP-2 Hafta 5 · Örnek 9 (★★)
Amaç    : Kararlılık deneyi: eşit ortalamalı kayıtlarda seçmeli
          (kararsız) ve araya ekleme / kabarcık (kararlı) sıralama
Çalıştır: python3 H05_09_kararlilik.py
Eşleri  : c/H05_09_kararlilik.c · cpp/H05_09_kararlilik.cpp
Çıktı   : üç dilde aynı (=)
"""

from collections import namedtuple

Ogrenci = namedtuple("Ogrenci", "no ad soyad ortalama")   # no: kayıt sırası


def ortalama_azalan(o):
    """Anahtar fonksiyonu: küçük anahtar önce gelir (azalan için eksi)"""
    return -o.ortalama


def secmeli_sirala(a, anahtar_fn):
    n = len(a)
    for i in range(n - 1):
        en = i                              # sırada önce gelecek olan
        for j in range(i + 1, n):
            if anahtar_fn(a[j]) < anahtar_fn(a[en]):
                en = j
        if en != i:
            a[i], a[en] = a[en], a[i]       # uzak takas: sırayı bozar


def kabarcik_sirala(a, anahtar_fn):
    n = len(a)
    for i in range(n - 1):
        takas_oldu = False
        for j in range(n - 1 - i):
            if anahtar_fn(a[j]) > anahtar_fn(a[j + 1]):  # eşitse takas YOK
                a[j], a[j + 1] = a[j + 1], a[j]
                takas_oldu = True
        if not takas_oldu:
            break


def araya_ekleme_sirala(a, anahtar_fn):
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while j >= 0 and anahtar_fn(a[j]) > anahtar_fn(anahtar):  # eşit: dur
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = anahtar


def bozulan_ciftler(a):
    """Eşit anahtarlı olup kayıt sırası bozulan çiftleri yazar; sayısını
    döndürür (çift: çıktıda önce gelen no, sonra gelen no)"""
    sayi = 0
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            if a[i].ortalama == a[j].ortalama and a[i].no > a[j].no:
                print(("\n    (" if sayi % 6 == 0 else " (")
                      + f"{a[i].no} önce, {a[j].no} sonra)", end="")
                sayi += 1
    return sayi


def sonuc_yaz(ad, a, denetle):
    print(f"{ad}:\n   ", end="")
    for k, o in enumerate(a):
        print(f" {o.ortalama:.2f}({o.no})", end="")
        if k == 4:
            print("\n   ", end="")
    print()
    if not denetle:
        return
    print("   bozulan eşit çiftler:", end="")
    sayi = bozulan_ciftler(a)
    if sayi == 0:
        print(" yok", end="")
    print("\n   kararlı davrandı mı? " + ("evet" if sayi == 0 else "HAYIR")
          + f" ({sayi} çift)")


def main():
    girdi = [
        Ogrenci(101, "Ayşe", "Yılmaz", 78.50),
        Ogrenci(102, "Mehmet", "Kaya", 65.25),
        Ogrenci(103, "Zeynep", "Demir", 78.50),
        Ogrenci(104, "Can", "Yılmaz", 90.00),
        Ogrenci(105, "Elif", "Kaya", 78.50),
        Ogrenci(106, "Burak", "Demir", 65.25),
        Ogrenci(107, "Ali", "Yılmaz", 78.50),
        Ogrenci(108, "Deniz", "Arslan", 90.00),
        Ogrenci(109, "Emre", "Kaya", 65.25),
        Ogrenci(110, "Selin", "Demir", 78.50),
    ]
    adlar = ["seçmeli", "kabarcık", "araya ekleme"]
    f = [secmeli_sirala, kabarcik_sirala, araya_ekleme_sirala]

    print("Kararlılık: ortalamaya göre azalan; parantez içi kayıt no")
    print("(kararlı sıralama eşit ortalamalılarda no artan sırayı korur)")
    sonuc_yaz("girdi", girdi, False)
    for k in range(3):
        a = girdi[:]                        # liste kopyası
        f[k](a, ortalama_azalan)
        print()
        sonuc_yaz(adlar[k], a, True)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort (kararlılık güvencesi YOK); C++ —
# std::stable_sort (kararlı), std::sort (kararsız); Python — sorted
# ve list.sort (Timsort, kararlı).

"""H05_10_cok_anahtarli.py — AP-2 Hafta 5 · Örnek 10 (★★★)
Amaç    : Çok anahtarlı sıralama (ortalama azalan, soyad artan, ad
          artan): tek karşılaştırıcıyla ve kararlı ardışık geçişlerle
Çalıştır: python3 H05_10_cok_anahtarli.py
Eşleri  : c/H05_10_cok_anahtarli.c · cpp/H05_10_cok_anahtarli.cpp
Çıktı   : üç dilde aynı (=)
"""

from collections import namedtuple

Ogrenci = namedtuple("Ogrenci", "no ad soyad ortalama")

karsilastirma = 0


def ortalama_azalan(o):
    return -o.ortalama


def soyad_artan(o):
    return o.soyad


def ad_artan(o):
    return o.ad


def cok_anahtarli(o):
    """Tek anahtar: demet (tuple) sözlük sırasıyla karşılaştırılır"""
    return (-o.ortalama, o.soyad, o.ad)


def araya_ekleme_sirala(a, anahtar_fn):
    """Kararlı: araya ekleme"""
    global karsilastirma
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while j >= 0:
            karsilastirma += 1
            if anahtar_fn(a[j]) <= anahtar_fn(anahtar):
                break
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = anahtar


def secmeli_sirala(a, anahtar_fn):
    """Kararsız: seçmeli (karşılaştırma sayılmaz; yalnızca karşıtlık)"""
    n = len(a)
    for i in range(n - 1):
        en = i
        for j in range(i + 1, n):
            if anahtar_fn(a[j]) < anahtar_fn(a[en]):
                en = j
        if en != i:
            a[i], a[en] = a[en], a[i]


def ayni_sira(a, b):
    """İki liste aynı kayıt sırasında mı? (no karşılaştırılır)"""
    return [o.no for o in a] == [o.no for o in b]


def tablo_yaz(a):
    print("sıra  ortalama   no  soyad, ad")
    for k, o in enumerate(a):
        print(f"{k + 1:3d}.  {o.ortalama:8.2f}  {o.no:3d}  {o.soyad}, {o.ad}")


def no_yaz(etiket, a):
    print(etiket + "".join(f" {o.no}" for o in a))


def main():
    global karsilastirma
    girdi = [
        Ogrenci(101, "Ayşe", "Yılmaz", 78.50),
        Ogrenci(102, "Mehmet", "Kaya", 65.25),
        Ogrenci(103, "Zeynep", "Demir", 78.50),
        Ogrenci(104, "Can", "Yılmaz", 90.00),
        Ogrenci(105, "Elif", "Kaya", 78.50),
        Ogrenci(106, "Burak", "Demir", 65.25),
        Ogrenci(107, "Ali", "Yılmaz", 78.50),
        Ogrenci(108, "Deniz", "Arslan", 90.00),
        Ogrenci(109, "Emre", "Kaya", 65.25),
        Ogrenci(110, "Selin", "Demir", 78.50),
    ]

    # Yöntem A: tek karşılaştırıcı, tek geçiş
    a = girdi[:]
    karsilastirma = 0
    araya_ekleme_sirala(a, cok_anahtarli)
    karsilastirma_a = karsilastirma

    # Yöntem B: kararlı ardışık geçişler, en önemsizden en önemliye
    b = girdi[:]
    karsilastirma = 0
    araya_ekleme_sirala(b, ad_artan)
    araya_ekleme_sirala(b, soyad_artan)
    araya_ekleme_sirala(b, ortalama_azalan)
    karsilastirma_b = karsilastirma

    # Karşıtlık: aynı ardışık geçişler KARARSIZ sıralamayla
    c = girdi[:]
    secmeli_sirala(c, ad_artan)
    secmeli_sirala(c, soyad_artan)
    secmeli_sirala(c, ortalama_azalan)

    # Tam karşılaştırıcıyla kararsız sıralama da doğru sonuç verir
    d = girdi[:]
    secmeli_sirala(d, cok_anahtarli)

    print("Sıralama ölçütü: ortalama azalan, soyad artan, ad artan\n")
    print("A) tek karşılaştırıcı (araya ekleme, 1 geçiş):")
    tablo_yaz(a)
    print("\nB) kararlı ardışık geçişler: ad -> soyad -> ortalama")
    no_yaz("   B sırası:", b)
    print("   A ile aynı mı? " + ("evet" if ayni_sira(a, b) else "HAYIR"))
    print(f"   karşılaştırma: A = {karsilastirma_a} (1 geçiş), "
          f"B = {karsilastirma_b} (3 geçiş)")
    print("\nC) aynı ardışık geçişler, kararsız seçmeli sıralamayla:")
    no_yaz("   C sırası:", c)
    print("   A ile aynı mı? " + ("evet" if ayni_sira(a, c) else "HAYIR"))
    print("\nD) tek (tam) karşılaştırıcı, kararsız seçmeli sıralamayla:")
    no_yaz("   D sırası:", d)
    print("   A ile aynı mı? " + ("evet" if ayni_sira(a, d) else "HAYIR")
          + " (tam sıralamada kararlılık gerekmez)")
    print("\nNot: bu verideki ad/soyadlar ilk farklı harfte ASCII; Türkçe\n"
          "harfte strcmp bayt sırası yanıltır (Hata Avcısı 8).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort + cok_anahtarli (void * sarmalayıcı);
# C++ — std::sort + çok anahtarlı yüklem ya da std::stable_sort
# geçişleri; Python — sorted(a, key=lambda o: (-o.ortalama, o.soyad,
# o.ad)).

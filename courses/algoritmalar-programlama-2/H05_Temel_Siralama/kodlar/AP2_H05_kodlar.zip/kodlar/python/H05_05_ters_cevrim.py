"""H05_05_ters_cevrim.py — AP-2 Hafta 5 · Örnek 5 (★★)
Amaç    : Ters çevrim sayısı (kaba kuvvet, O(n²)) ve araya eklemenin
          kaydırma sayısıyla eşitliği; rastgele dizilerde doğrulama
Çalıştır: python3 H05_05_ters_cevrim.py
Eşleri  : c/H05_05_ters_cevrim.c · cpp/H05_05_ters_cevrim.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

kaydirma = 0


def ters_cevrim_say(a):
    """Ters çevrim: i < j ve a[i] > a[j] olan (i, j) çiftlerinin sayısı"""
    sayi = 0
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            if a[i] > a[j]:
                sayi += 1
    return sayi


def araya_ekleme_sirala(a, n):
    global kaydirma
    for i in range(1, n):
        anahtar = a[i]
        j = i - 1
        while j >= 0 and a[j] > anahtar:
            a[j + 1] = a[j]
            kaydirma += 1
            j -= 1
        a[j + 1] = anahtar


def ciftleri_yaz(a):
    yazilan = 0
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            if a[i] > a[j]:
                print(f" ({a[i]},{a[j]})", end="")
                yazilan += 1
                if yazilan % 8 == 0:
                    print()
    if yazilan % 8 != 0:
        print()


def main():
    global kaydirma
    a = [42, 17, 8, 31, 25, 4, 39, 12]
    n = len(a)

    print("1) a = ", end="")
    for x in a:
        print(f"{x} ", end="")
    print("\nters çevrim çiftleri (a[i], a[j]), i < j ve a[i] > a[j]:")
    ciftleri_yaz(a)
    print(f"ters çevrim sayısı = {ters_cevrim_say(a)}")

    print("\n2) araya eklemede i. anahtarın kaydırması = solundaki "
          "büyüklerin sayısı")
    print("   i  a[i]  soldaki büyük  kaydırma")
    b = a[:]
    toplam = 0
    for i in range(n):
        soldaki = 0
        for k in range(i):
            if a[k] > a[i]:
                soldaki += 1
        kaydirma = 0
        araya_ekleme_sirala(b, i + 1)   # b[0..i-1] zaten sıralı
        toplam += kaydirma
        print(f"{i:4d} {a[i]:5d} {soldaki:14d} {kaydirma:9d}")
    print(f"toplam kaydırma = {toplam}")

    print("\n3) rastgele diziler (değerler 0..999, ortak LCG)")
    print("   n  tohum  ters çevrim   kaydırma  eşit  oran (/ n(n-1)/4)")
    hepsi_esit = True
    for m in (10, 100, 1000):
        for tohum in range(1, 5):
            rastgele_tohum(tohum)
            a = rastgele_dizi(m, 0, 999)
            tc = ters_cevrim_say(a)
            kaydirma = 0
            araya_ekleme_sirala(a, m)
            esit = tc == kaydirma
            hepsi_esit = hepsi_esit and esit
            beklenen = m * (m - 1) / 4.0
            durum = "evet" if esit else "HAYIR"
            print(f"{m:4d} {tohum:6d} {tc:12d} {kaydirma:10d}  "
                  f"{durum:<5} {tc / beklenen:.3f}")
    print("tüm denemelerde kaydırma = ters çevrim: "
          + ("evet" if hepsi_esit else "HAYIR"))

    print("\n4) sınırlar (n = 1000):", end="")
    a = [k + 1 for k in range(1000)]
    print(f" sıralı -> {ters_cevrim_say(a)},", end="")
    a = [1000 - k for k in range(1000)]
    print(f" ters sıralı -> {ters_cevrim_say(a)} "
          f"(n(n-1)/2 = {1000 * 999 // 2})")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). O(n log n) sayım:
# birleştirmeli sıralama sırasında (H6).

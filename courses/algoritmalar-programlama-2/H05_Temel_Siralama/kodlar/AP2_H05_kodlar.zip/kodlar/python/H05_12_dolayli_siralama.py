"""H05_12_dolayli_siralama.py — AP-2 Hafta 5 · Örnek 12 (★★★)
Amaç    : Dolaylı sıralama: büyük kayıtları taşımadan işaretçi/indis
          dizisini sıralamak; kopyalanan bayt sayısının karşılaştırması
Çalıştır: python3 H05_12_dolayli_siralama.py [n=1000]   (süreler stderr'e)
Eşleri  : c/H05_12_dolayli_siralama.c
          cpp/H05_12_dolayli_siralama.cpp
Çıktı   : üç dilde aynı (=)
"""

import sys
from collections import namedtuple

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import zaman_sn

Kayit = namedtuple("Kayit", "anahtar no veri")   # no: kayıt sırası
KAYIT_BAYT = 256          # C'deki sizeof(Kayit): 4 + 4 + 248
ISARETCI_BAYT = 8         # C'de sizeof(Kayit *); Python başvurusu da 8

kopya = 0                 # öğe kopyası: anahtar + kaydırma


def kayit_sirala(a):
    """Doğrudan: listenin öğeleri kaydırılır (Python'da öğe = başvuru)"""
    global kopya
    for i in range(1, len(a)):
        anahtar = a[i]
        kopya += 1
        j = i - 1
        while j >= 0 and a[j].anahtar > anahtar.anahtar:
            a[j + 1] = a[j]
            kopya += 1
            j -= 1
        a[j + 1] = anahtar
        kopya += 1


def indis_sirala(sira, kayit):
    """Dolaylı: indisler kaydırılır; kayıt listesi yerinde kalır"""
    global kopya
    for i in range(1, len(sira)):
        anahtar = sira[i]
        kopya += 1
        j = i - 1
        while j >= 0 and kayit[sira[j]].anahtar > kayit[anahtar].anahtar:
            sira[j + 1] = sira[j]
            kopya += 1
            j -= 1
        sira[j + 1] = anahtar
        kopya += 1


def arguman_oku(varsayilan):
    if len(sys.argv) < 2:
        return varsayilan
    try:
        deger = int(sys.argv[1])
    except ValueError:
        deger = 0
    if deger < 1 or deger > 100000:
        print(f"kullanım: {sys.argv[0]} [n: 1..100000]", file=sys.stderr)
        sys.exit(2)
    return deger


def main():
    global kopya
    n = arguman_oku(1000)
    rastgele_tohum(5)
    kayit = [Kayit(rastgele_aralik(0, 99), i, f"kayıt {i}") for i in range(n)]
    dogrudan = kayit[:]                      # başvuruların kopyası
    sira = list(range(n))

    kopya = 0
    t0 = zaman_sn()
    kayit_sirala(dogrudan)
    t_dogrudan = zaman_sn() - t0
    kopya_dogrudan = kopya

    kopya = 0
    t0 = zaman_sn()
    indis_sirala(sira, kayit)
    duzenli = [kayit[i] for i in sira]       # bir kez yeniden düzenle
    t_dolayli = zaman_sn() - t0
    kopya_dolayli = kopya

    ayni = [k.no for k in dogrudan] == [k.no for k in duzenli]
    bayt_dogrudan = kopya_dogrudan * KAYIT_BAYT
    bayt_dolayli = kopya_dolayli * ISARETCI_BAYT
    bayt_duzenleme = n * KAYIT_BAYT

    print(f"Dolaylı sıralama: n = {n} kayıt, kayıt = {KAYIT_BAYT} bayt, "
          f"işaretçi/indis = {ISARETCI_BAYT} bayt")
    print("anahtar 0..99 (yinelenen), ortak LCG tohum 5; araya ekleme\n")
    print("yöntem                           öğe kopyası  kopyalanan bayt")
    print(f"doğrudan: kayıtları kaydır      {kopya_dogrudan:12d} "
          f"{bayt_dogrudan:14d}")
    print(f"dolaylı: işaretçileri kaydır    {kopya_dolayli:12d} "
          f"{bayt_dolayli:14d}")
    print(f"  + bir kez yeniden düzenleme   {n:12d} {bayt_duzenleme:14d}")
    print(f"dolaylı toplam                  {kopya_dolayli + n:12d} "
          f"{bayt_dolayli + bayt_duzenleme:14d}")
    oran = bayt_dogrudan / (bayt_dolayli + bayt_duzenleme)
    print(f"kopyalanan bayt oranı (doğrudan / dolaylı toplam) = {oran:.1f}")
    print("iki yöntem aynı kayıt sırasını verdi mi? "
          + ("evet" if ayni else "HAYIR"))
    print("ilk 8 (anahtar/no):"
          + "".join(f" {k.anahtar}/{k.no}" for k in duzenli[:8]))
    print(f"süre (tek ölçüm): doğrudan {t_dogrudan * 1e3:.3f} ms, dolaylı + "
          f"düzenleme {t_dolayli * 1e3:.3f} ms", file=sys.stderr)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort(p, n, sizeof p[0], kars) işaretçi
# dizisiyle; C++ — std::sort ile indis/işaretçi vektörü; Python —
# sorted(range(n), key=lambda i: kayit[i].anahtar).

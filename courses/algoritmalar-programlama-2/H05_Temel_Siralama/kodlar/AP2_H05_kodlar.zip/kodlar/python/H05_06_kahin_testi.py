"""H05_06_kahin_testi.py — AP-2 Hafta 5 · Örnek 6 (★★)
Amaç    : "Dizi sıralı mı?" denetimi ve kütüphane sıralamasıyla kâhin
          testi: özel diziler + rastgele diziler (deterministik özet)
Çalıştır: python3 H05_06_kahin_testi.py
Eşleri  : c/H05_06_kahin_testi.c · cpp/H05_06_kahin_testi.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

INT_MAX = 2**31 - 1        # C'deki INT_MAX ve INT_MIN (32 bitlik int)
INT_MIN = -2**31


def secmeli_sirala(a):
    n = len(a)
    for i in range(n - 1):
        en_kucuk = i
        for j in range(i + 1, n):
            if a[j] < a[en_kucuk]:
                en_kucuk = j
        if en_kucuk != i:
            a[i], a[en_kucuk] = a[en_kucuk], a[i]


def kabarcik_sirala(a):
    n = len(a)
    for i in range(n - 1):
        takas_oldu = False
        for j in range(n - 1 - i):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                takas_oldu = True
        if not takas_oldu:
            break


def araya_ekleme_sirala(a):
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while j >= 0 and a[j] > anahtar:
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = anahtar


def sahte_sirala(a):
    """HATALI "sıralama": a[i] yerine a[0..i]'nin en büyüğünü yazar.
    Sonuç her zaman sıralıdır ama girdinin permütasyonu olmayabilir."""
    for i in range(1, len(a)):
        if a[i] < a[i - 1]:
            a[i] = a[i - 1]


def sirali_mi(a):
    """a azalmayan sırada mı? (n - 1 karşılaştırma)"""
    for k in range(1, len(a)):
        if a[k - 1] > a[k]:
            return False
    return True


def kahin(girdi):
    """Kâhin: kütüphane sıralamasının sonucu (yalnızca test için)"""
    return sorted(girdi)


def sola_yasla(s, g):
    """s'yi yazar; görünen genişlik (kod noktası) g olana dek boşluk"""
    print(f"{s:<{g}}", end="")


def dizi_yaz(a):
    print("[" + " ".join(str(x) for x in a) + "]", end="")


def dizi_uret(t):
    """Test kümesi: 8 özel dizi + n = 0..30 için 20'şer rastgele dizi"""
    ozel = [[], [5], [2, 1], [1, 2], [3, 3, 3], [5, 4, 3, 2, 1],
            [1, 2, 3, 4, 5], [-3, 0, -3, INT_MAX, INT_MIN]]
    if t < 8:
        return ozel[t][:]
    n = (t - 8) // 20                          # 0, 1, ..., 30
    if (t - 8) % 2 == 0:
        return rastgele_dizi(n, 0, 9)          # çok yinelenen
    return rastgele_dizi(n, -1000, 1000)


def main():
    adlar = ["seçmeli", "kabarcık", "araya ekleme", "sahte (hatalı)"]
    fonksiyonlar = [secmeli_sirala, kabarcik_sirala, araya_ekleme_sirala,
                    sahte_sirala]
    test_sayisi = 8 + 31 * 20
    hata = None

    print("Kâhin testi: kendi sıralamalarımız ve kütüphane sıralaması")
    print("(kâhin: C qsort, C++ std::sort, Python sorted)")
    print("test kümesi: 8 özel dizi + n = 0..30 için 20'şer rastgele "
          f"dizi = {test_sayisi} dizi\n")
    print("algoritma          sıralı mı  kâhinle aynı")
    for f in range(4):
        sirali = ayni = 0
        rastgele_tohum(2026)         # her algoritmaya aynı diziler
        for t in range(test_sayisi):
            girdi = dizi_uret(t)
            a = girdi[:]
            fonksiyonlar[f](a)
            beklenen = kahin(girdi)
            sirali += 1 if sirali_mi(a) else 0
            esit = a == beklenen                 # liste karşılaştırması
            ayni += 1 if esit else 0
            if not esit and hata is None:        # ilk yakalanan hata
                hata = (girdi, a, beklenen)
        sola_yasla(adlar[f], 15)
        print(f"{sirali:9d}/{test_sayisi} {ayni:10d}/{test_sayisi}")
    if hata is not None:
        print("\nkâhinin yakaladığı ilk hata:\n  girdi  ", end="")
        dizi_yaz(hata[0])
        print("\n  çıktı  ", end="")
        dizi_yaz(hata[1])
        print("  sıralı mı: " + ("evet" if sirali_mi(hata[1]) else "hayır")
              + "\n  kâhin  ", end="")
        dizi_yaz(hata[2])
        print()
    print("\nSonuç: \"sıralı mı?\" tek başına yetmez; çıktı girdinin "
          "permütasyonu da olmalı.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı (burada kâhin): C — qsort; C++ — std::sort;
# Python — sorted(a).

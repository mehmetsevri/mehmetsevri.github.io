"""H05_13_shell_siralama.py — AP-2 Hafta 5 · Örnek 13 (★★★, merak)
Amaç    : Shell sıralaması (h-sıralama) ve aralık dizisi deneyi:
          Shell (n/2, n/4, ..., 1), Knuth (3h + 1), Ciura
Çalıştır: python3 H05_13_shell_siralama.py
Eşleri  : c/H05_13_shell_siralama.c
          cpp/H05_13_shell_siralama.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_karistir, rastgele_tohum

karsilastirma = 0
kaydirma = 0


def dizi_yaz(a):
    print("".join(f"{x:3d}" for x in a))


def h_gecisi(a, h):
    """Her h için: a[i], a[i-h], a[i-2h], ... alt dizisinde araya ekleme"""
    global karsilastirma, kaydirma
    for i in range(h, len(a)):
        anahtar = a[i]
        j = i                              # boşluğun konumu
        while j >= h:
            karsilastirma += 1
            if a[j - h] <= anahtar:
                break
            a[j] = a[j - h]    # h sağa kaydır
            kaydirma += 1
            j -= h
        a[j] = anahtar


def shell_sirala(a, h):
    for g in h:                            # h: büyükten küçüğe, son 1
        h_gecisi(a, g)


def h_sirali_mi(a, h):
    """a, h-sıralı mı? (her i için a[i - h] <= a[i])"""
    for i in range(h, len(a)):
        if a[i - h] > a[i]:
            return False
    return True


def shell_araliklari(n):
    """Aralık dizileri (azalan, son eleman 1)"""
    h = []
    g = n // 2
    while g > 0:
        h.append(g)
        g //= 2
    return h


def knuth_araliklari(n):
    g = 1
    while g < n // 3:
        g = 3 * g + 1                      # 1, 4, 13, 40, 121, ...
    h = []
    while g > 0:
        h.append(g)
        g //= 3
    return h


def ciura_araliklari(n):
    ciura = [701, 301, 132, 57, 23, 10, 4, 1]
    return [g for g in ciura if g < n or g == 1]


def h_listesi_yaz(ad, h):
    print(f"   {ad}:" + "".join(f" {g}" for g in h))


def main():
    global karsilastirma, kaydirma
    # 1) Küçük örnek: h = 4, 2, 1 geçişleri
    k = [42, 17, 8, 31, 25, 4, 39, 12]
    print("1) Shell sıralaması, n = 8, h = 4, 2, 1\n   başlangıç: ", end="")
    dizi_yaz(k)
    for g in shell_araliklari(len(k)):
        karsilastirma = 0
        kaydirma = 0
        h_gecisi(k, g)
        print(f"   h = {g}    : ", end="")
        dizi_yaz(k)
        durum = "evet" if h_sirali_mi(k, g) else "hayır"
        print(f"   {g}-sıralı mı? {durum}   karşılaştırma = {karsilastirma}, "
              f"kaydırma = {kaydirma}")

    # 2) Aralık dizisi deneyi
    print("\n2) aralık dizileri: rastgele permütasyon (ortak LCG, tohum 13)")
    for n in (100, 1000, 5000):
        girdi = [i + 1 for i in range(n)]
        rastgele_tohum(13)
        rastgele_karistir(girdi)
        print(f"\nn = {n}")
        print("   yöntem          karşılaştırma    kaydırma  sıralı")
        adlar = ["Shell (n/2)", "Knuth (3h+1)", "Ciura", "araya ekleme"]
        hd = [shell_araliklari(n), knuth_araliklari(n), ciura_araliklari(n),
              [1]]                         # h = 1: araya ekleme
        for y in range(4):
            a = girdi[:]
            karsilastirma = 0
            kaydirma = 0
            shell_sirala(a, hd[y])
            print(f"   {adlar[y]:<14} {karsilastirma:14d} {kaydirma:11d}  "
                  + ("evet" if h_sirali_mi(a, 1) else "HAYIR"))
        for y in range(3):
            h_listesi_yaz(adlar[y], hd[y])

    # 3) Kararlılık: anahtar = değer // 10, etiket = değer % 10
    e = [20, 10, 21, 11, 22, 12]
    print("\n3) kararlılık (sayı: anahtar, harf: özgün sıra etiketi)")
    print("   girdi : " + "".join(f" {x // 10}{chr(97 + x % 10)}" for x in e),
          end="")
    for g in shell_araliklari(len(e)):     # 3, 1
        for i in range(g, len(e)):         # yalnız anahtar kıyaslanır
            anahtar = e[i]
            j = i
            while j >= g and e[j - g] // 10 > anahtar // 10:
                e[j] = e[j - g]
                j -= g
            e[j] = anahtar
    print("\n   sonuç : "
          + "".join(f" {x // 10}{chr(97 + x % 10)}" for x in e))
    kararli = all(not (e[i - 1] // 10 == e[i] // 10 and e[i - 1] > e[i])
                  for i in range(1, len(e)))
    print("   eşit anahtarlarda etiket sırası korundu mu? "
          + ("evet" if kararli else "HAYIR (Shell sıralaması kararsız)"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Ciura aralıkları deneysel
# olarak bulunmuş bir dizidir; burada 701'e kadar kullanılır.

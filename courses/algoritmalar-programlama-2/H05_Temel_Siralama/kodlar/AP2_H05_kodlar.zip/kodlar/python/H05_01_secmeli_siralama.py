"""H05_01_secmeli_siralama.py — AP-2 Hafta 5 · Örnek 1 (★)
Amaç    : Seçmeli sıralama; her geçişten sonra dizi ve değişmez:
          a[0..i] sıralıdır ve dizinin en küçük i + 1 elemanını içerir
Çalıştır: python3 H05_01_secmeli_siralama.py
Eşleri  : c/H05_01_secmeli_siralama.c
          cpp/H05_01_secmeli_siralama.cpp
Çıktı   : üç dilde aynı (=)
"""

karsilastirma = 0
takas_sayisi = 0


def dizi_yaz(a, sinir):
    """a'yı yazar; sinir < len(a) ise a[sinir]'dan önce '|' koyar"""
    for k in range(len(a)):
        if k == sinir:
            print(" |", end="")
        print(f"{a[k]:3d}", end="")
    print()


def degismez_tamam_mi(a, s):
    """Değişmez: a[0..s-1] sıralı ve a[0..s-1] <= a[s..n-1] (her eleman)"""
    for k in range(1, s):
        if a[k - 1] > a[k]:
            return False
    for k in range(s, len(a) if s > 0 else 0):
        if a[s - 1] > a[k]:
            return False
    return True


def gecis_yaz(a, i, en_kucuk):
    print(f"i = {i}: en küçük a[{en_kucuk}] = {a[i]:2d}, ", end="")
    if en_kucuk != i:
        print(f"takas a[{i}] <-> a[{en_kucuk}]")
    else:
        print("takas yok")
    print("      ", end="")
    dizi_yaz(a, i + 1)
    print("      değişmez: "
          + ("evet" if degismez_tamam_mi(a, i + 1) else "HAYIR"))


def secmeli_sirala(a, yazdir):
    global karsilastirma, takas_sayisi
    n = len(a)
    for i in range(n - 1):
        en_kucuk = i
        for j in range(i + 1, n):
            karsilastirma += 1
            if a[j] < a[en_kucuk]:
                en_kucuk = j
        if en_kucuk != i:
            a[i], a[en_kucuk] = a[en_kucuk], a[i]
            takas_sayisi += 1
        if yazdir:
            gecis_yaz(a, i, en_kucuk)


def main():
    global karsilastirma, takas_sayisi
    a = [42, 17, 8, 31, 25, 4, 39, 12]
    n = len(a)

    print(f"Seçmeli sıralama, n = {n} ('|' solu: sıralı önek)")
    print("başlangıç:\n      ", end="")
    dizi_yaz(a, n)
    secmeli_sirala(a, True)
    print("sonuç:\n      ", end="")
    dizi_yaz(a, n)
    print(f"karşılaştırma = {karsilastirma}   n(n-1)/2 = {n * (n - 1) // 2}")
    print(f"takas = {takas_sayisi}   (en fazla n - 1 = {n - 1})")

    print("\nKenar durumları (i + 1 < n koşulu; n - 1 taşmaz):")
    for boyut in range(2):
        bir = [7] * boyut
        karsilastirma = 0
        takas_sayisi = 0
        secmeli_sirala(bir, False)
        print(f"n = {boyut}: karşılaştırma = {karsilastirma}, "
              f"takas = {takas_sayisi}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort (algoritma belirtilmez); C++ —
# std::sort; Python — list.sort() / sorted() (yalnızca kâhin).

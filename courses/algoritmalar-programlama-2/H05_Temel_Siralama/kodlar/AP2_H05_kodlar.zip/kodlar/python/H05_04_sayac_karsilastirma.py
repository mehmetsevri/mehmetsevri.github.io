"""H05_04_sayac_karsilastirma.py — AP-2 Hafta 5 · Örnek 4 (★★)
Amaç    : Üç algoritmanın karşılaştırma ve takas/kaydırma sayıları:
          rastgele, sıralı ve ters sıralı girdi; kuramsal formüllerle
Çalıştır: python3 H05_04_sayac_karsilastirma.py
Eşleri  : c/H05_04_sayac_karsilastirma.c
          cpp/H05_04_sayac_karsilastirma.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_karistir, rastgele_tohum

karsilastirma = 0
takas_sayisi = 0
kaydirma = 0


def sayaclari_sifirla():
    global karsilastirma, takas_sayisi, kaydirma
    karsilastirma = 0
    takas_sayisi = 0
    kaydirma = 0


def sola_yasla(s, g):
    """s'yi yazar; görünen genişlik (kod noktası) g olana dek boşluk"""
    print(f"{s:<{g}}", end="")


def secmeli_sirala(a):
    global karsilastirma, takas_sayisi
    n = len(a)
    for i in range(n - 1):
        en_kucuk = i
        for j in range(i + 1, n):
            karsilastirma += 1
            if a[j] < a[en_kucuk]:
                en_kucuk = j
        if en_kucuk != i:
            a[i], a[en_kucuk] = a[en_kucuk], a[i]
            takas_sayisi += 1


def kabarcik_sirala(a):
    global karsilastirma, takas_sayisi
    n = len(a)
    for i in range(n - 1):
        takas_oldu = False
        for j in range(n - 1 - i):
            karsilastirma += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                takas_sayisi += 1
                takas_oldu = True
        if not takas_oldu:
            break


def buyuk_mu(x, y):
    global karsilastirma
    karsilastirma += 1
    return x > y


def araya_ekleme_sirala(a):
    global kaydirma
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while j >= 0 and buyuk_mu(a[j], anahtar):
            a[j + 1] = a[j]
            kaydirma += 1
            j -= 1
        a[j + 1] = anahtar


def ters_cevrim(a):
    """Ters çevrim sayısı: i < j ve a[i] > a[j] olan çiftler (kaba kuvvet)"""
    sayi = 0
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            if a[i] > a[j]:
                sayi += 1
    return sayi


def basa_yerlesen(a):
    """Soldan sağa yeni en küçük sayısı (a[0] hariç): araya eklemede j = -1"""
    sayi = 0
    for i in range(1, len(a)):
        en_kucuk_mu = True
        for k in range(i):
            if a[k] <= a[i]:
                en_kucuk_mu = False
        sayi += 1 if en_kucuk_mu else 0
    return sayi


def girdi_hazirla(n, tur):
    a = [n - i if tur == 2 else i + 1 for i in range(n)]    # 2: ters
    if tur == 0:                                            # 0: rastgele
        rastgele_tohum(42)
        rastgele_karistir(a)
    return a


def deney(n):
    girdi_adi = ["rastgele", "sıralı", "ters sıralı"]
    algo_adi = ["seçmeli", "kabarcık", "araya ekleme"]
    en_cok = n * (n - 1) // 2

    print(f"\nn = {n}   n(n-1)/2 = {en_cok}   n(n-1)/4 = {en_cok / 2.0:.2f}")
    print("algoritma     girdi         karşılaştırma  takas  kaydırma")
    for alg in range(3):
        for tur in range(3):
            a = girdi_hazirla(n, tur)
            sayaclari_sifirla()
            if alg == 0:
                secmeli_sirala(a)
            elif alg == 1:
                kabarcik_sirala(a)
            else:
                araya_ekleme_sirala(a)
            sola_yasla(algo_adi[alg], 14)
            sola_yasla(girdi_adi[tur], 13)
            print(f"{karsilastirma:14d} {takas_sayisi:6d} {kaydirma:9d}")
    print("kuram denetimi (rastgele girdi):")
    girdi = girdi_hazirla(n, 0)
    tc = ters_cevrim(girdi)
    z = basa_yerlesen(girdi)
    print(f"  ters çevrim = {tc}  (beklenen değer n(n-1)/4 = "
          f"{en_cok / 2.0:.2f})")
    a = girdi[:]
    sayaclari_sifirla()
    kabarcik_sirala(a)
    print("  kabarcık takas = ters çevrim: "
          + ("evet" if takas_sayisi == tc else "HAYIR"))
    a = girdi[:]
    sayaclari_sifirla()
    araya_ekleme_sirala(a)
    print("  araya ekleme kaydırma = ters çevrim: "
          + ("evet" if kaydirma == tc else "HAYIR"))
    beklenen = kaydirma + (n - 1) - z
    print("  araya ekleme karşılaştırma = kaydırma + (n-1) - z")
    print(f"    = {kaydirma} + {n - 1} - {z} = {beklenen}: "
          + ("evet" if karsilastirma == beklenen else "HAYIR"))


def main():
    print("Karşılaştırma ve takas/kaydırma sayaçları")
    print("rastgele: 1..n karıştırılmış (ortak LCG, tohum 42)")
    print("z: araya eklemede başa (a[0]'a) yerleşen anahtar sayısı")
    deney(100)
    deney(1000)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort()
# / sorted(). Kütüphane sıralamalarının sayaçları gerçekleştirime bağlıdır.

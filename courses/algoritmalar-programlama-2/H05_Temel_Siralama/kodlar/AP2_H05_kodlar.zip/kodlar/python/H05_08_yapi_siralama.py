"""H05_08_yapi_siralama.py — AP-2 Hafta 5 · Örnek 8 (★★)
Amaç    : Yapı dizisini ortalamaya göre azalan sıralama: yapı
          karşılaştırıcısı + kendi araya ekleme sıralamamız
Çalıştır: python3 H05_08_yapi_siralama.py
Eşleri  : c/H05_08_yapi_siralama.c · cpp/H05_08_yapi_siralama.cpp
Çıktı   : üç dilde aynı (=)
"""

from collections import namedtuple

Ogrenci = namedtuple("Ogrenci", "no ad soyad ortalama")

karsilastirma = 0


def ogrenci_sirala(a, anahtar_fn):
    """Araya ekleme: anahtar_fn(a[j]) > anahtar_fn(x) oldukça kaydır"""
    global karsilastirma
    for i in range(1, len(a)):
        anahtar = a[i]                      # başvuru (kopya değil)
        j = i - 1
        while j >= 0:
            karsilastirma += 1
            if anahtar_fn(a[j]) <= anahtar_fn(anahtar):
                break
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = anahtar


def kayit_sirasi_korundu(a):
    """Komşu eşit ortalamalılarda no artıyor mu? (no = kayıt sırası)"""
    for k in range(1, len(a)):
        if a[k - 1].ortalama == a[k].ortalama and a[k - 1].no > a[k].no:
            return False
    return True


def tablo_yaz(a):
    print("sıra  ortalama   no  ad soyad")
    for k, o in enumerate(a):
        print(f"{k + 1:3d}.  {o.ortalama:8.2f}  {o.no:3d}  {o.ad} {o.soyad}")


def main():
    a = [
        Ogrenci(101, "Ayşe", "Yılmaz", 78.50),
        Ogrenci(102, "Mehmet", "Kaya", 65.25),
        Ogrenci(103, "Zeynep", "Demir", 78.50),
        Ogrenci(104, "Can", "Yılmaz", 90.00),
        Ogrenci(105, "Elif", "Kaya", 78.50),
        Ogrenci(106, "Burak", "Demir", 65.25),
        Ogrenci(107, "Ali", "Yılmaz", 78.50),
        Ogrenci(108, "Deniz", "Arslan", 90.00),
        Ogrenci(109, "Emre", "Kaya", 65.25),
        Ogrenci(110, "Selin", "Demir", 78.50),
    ]

    print("Girdi (kayıt sırası):")
    tablo_yaz(a)
    ogrenci_sirala(a, lambda o: -o.ortalama)    # anahtar: azalan için eksi
    print("\nOrtalamaya göre azalan (araya ekleme, karşılaştırıcıyla):")
    tablo_yaz(a)
    print(f"karşılaştırma = {karsilastirma}")
    print("eşit ortalamalılarda kayıt sırası (no artan) korundu mu? "
          + ("evet" if kayit_sirasi_korundu(a) else "hayır"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort(a, n, sizeof a[0], kars_void);
# C++ — std::stable_sort + lambda; Python — sorted(a, key=…).

/* H05_A03_hata_bul_secmeli.c — AP-2 Hafta 5 · Alıştırma 5.9 (hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: seçmeli sıralama bazı dizilerde yanlış
 * sonuç veriyor. Çıktıdaki ilk yanlış geçişi bulun, hatalı satırı
 * düzeltin ve değişmezin hangi adımda bozulduğunu açıklayın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_A03_hata_bul_secmeli.c -o H05_A03_hata_bul_secmeli
 * Çalıştır: ./H05_A03_hata_bul_secmeli
 */
#include <stddef.h>
#include <stdio.h>

static void yaz(const int *a, size_t n)
{
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

static void secmeli_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en_kucuk = 0;
        for (size_t j = i + 1; j < n; j++) {
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        int g = a[i];
        a[i] = a[en_kucuk];
        a[en_kucuk] = g;
        printf("i = %zu:", i);
        yaz(a, n);
    }
}

int main(void)
{
    int a[] = {3, 9, 1, 7, 4};
    secmeli_sirala(a, sizeof a / sizeof a[0]);
    return 0;
}

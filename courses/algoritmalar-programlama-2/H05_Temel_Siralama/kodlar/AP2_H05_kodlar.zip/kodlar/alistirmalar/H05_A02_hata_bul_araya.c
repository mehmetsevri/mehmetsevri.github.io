/* H05_A02_hata_bul_araya.c — AP-2 Hafta 5 · Alıştırma 5.8 (hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: sonuç anahtara göre sıralıdır, ama
 * araya ekleme sıralamasının bir özelliği kaybolmuştur. Hangisi? Hatalı
 * satırı bulun ve tek karakter değiştirerek düzeltin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_A02_hata_bul_araya.c -o H05_A02_hata_bul_araya
 * Çalıştır: ./H05_A02_hata_bul_araya
 */
#include <stddef.h>
#include <stdio.h>

typedef struct {
    int anahtar;
    char etiket;                 /* a, b, c: özgün sıra */
} Kayit;

static void araya_ekleme_sirala(Kayit *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        Kayit k = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && a[j].anahtar >= k.anahtar) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = k;
    }
}

static void yaz(const char *etiket, const Kayit *a, size_t n)
{
    printf("%s:", etiket);
    for (size_t k = 0; k < n; k++) {
        printf(" %d%c", a[k].anahtar, a[k].etiket);
    }
    printf("\n");
}

int main(void)
{
    Kayit a[] = {{2, 'a'}, {1, 'a'}, {2, 'b'}, {1, 'b'}, {2, 'c'}, {1, 'c'}};
    size_t n = sizeof a / sizeof a[0];
    yaz("girdi", a, n);
    araya_ekleme_sirala(a, n);
    yaz("sonuç", a, n);
    return 0;
}

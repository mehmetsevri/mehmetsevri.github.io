/* H05_A01_cikti_tahmini.c — AP-2 Hafta 5 · Alıştırma 5.2 (çıktı tahmini)
 * Amaç    : Önce ÇALIŞTIRMADAN programın yazdıracağı her satırı tahmin
 *           edin; sonra derleyip karşılaştırın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_A01_cikti_tahmini.c -o H05_A01_cikti_tahmini
 * Çalıştır: ./H05_A01_cikti_tahmini
 */
#include <stddef.h>
#include <stdio.h>

static void yaz(const int *a, size_t n)
{
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

static void f(int *a, size_t n)
{
    for (size_t son = n; son > 1; son--) {
        size_t k = 0;
        for (size_t j = 1; j < son; j++) {
            if (a[j] > a[k]) {
                k = j;
            }
        }
        int g = a[k];
        a[k] = a[son - 1];
        a[son - 1] = g;
        yaz(a, n);
    }
}

int main(void)
{
    int a[] = {5, 1, 4, 2, 3};
    f(a, sizeof a / sizeof a[0]);
    return 0;
}

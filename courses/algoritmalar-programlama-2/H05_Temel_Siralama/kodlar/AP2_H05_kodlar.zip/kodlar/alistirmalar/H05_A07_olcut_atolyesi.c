/* H05_A07_olcut_atolyesi.c — AP-2 Hafta 5 · Atölye 3 iskeleti
 * Amaç    : Karşılaştırıcı atölyesi: aynı 10 kaydı beş ölçüte göre
 *           sıralayın. Beş karşılaştırıcıyı TAMAMLAYIN (şimdilik hepsi 0
 *           döndürür: kararlı sıralama girdiyi olduğu gibi bırakır).
 *           Sözleşme: kars(x, y) < 0 ise x önce gelir; 0 ise kayıt sırası
 *           korunur (araya ekleme kararlıdır). Taşmaya güvenli yazın:
 *           (x > y) - (x < y).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_A07_olcut_atolyesi.c -o H05_A07_olcut_atolyesi
 * Çalıştır: ./H05_A07_olcut_atolyesi
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    int no;
    char ad[16];
    char soyad[16];
    double ortalama;
} Ogrenci;

typedef int (*ogrenci_kars)(const Ogrenci *, const Ogrenci *);

/* 1) Başarı: ortalama azalan; eşitse soyad artan, sonra ad artan */
static int olcut_basari(const Ogrenci *x, const Ogrenci *y)
{
    (void)x;
    (void)y;
    return 0;                    /* TAMAMLAYIN */
}

/* 2) Soyad artan; eşitse ad artan (bu verideki harfler ASCII) */
static int olcut_soyad(const Ogrenci *x, const Ogrenci *y)
{
    (void)x;
    (void)y;
    return 0;                    /* TAMAMLAYIN */
}

/* 3) Ad artan */
static int olcut_ad(const Ogrenci *x, const Ogrenci *y)
{
    (void)x;
    (void)y;
    return 0;                    /* TAMAMLAYIN */
}

/* 4) Numara azalan (en son kayıt önce) */
static int olcut_no_azalan(const Ogrenci *x, const Ogrenci *y)
{
    (void)x;
    (void)y;
    return 0;                    /* TAMAMLAYIN */
}

/* 5) Ortalama artan; eşitse kayıt sırası (karşılaştırıcıda no YOK:
 *    kararlılığa güvenin) */
static int olcut_ortalama_artan(const Ogrenci *x, const Ogrenci *y)
{
    (void)x;
    (void)y;
    return 0;                    /* TAMAMLAYIN */
}

/* Kararlı araya ekleme (Örnek 8 ile aynı) */
static void ogrenci_sirala(Ogrenci *a, size_t n, ogrenci_kars kars)
{
    for (size_t i = 1; i < n; i++) {
        Ogrenci anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && kars(&a[j], &anahtar) > 0) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

int main(void)
{
    const Ogrenci girdi[] = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };
    const char *adlar[] = {"başarı", "soyad", "ad", "no azalan",
                           "ortalama artan"};
    ogrenci_kars olcutler[] = {olcut_basari, olcut_soyad, olcut_ad,
                               olcut_no_azalan, olcut_ortalama_artan};
    size_t n = sizeof girdi / sizeof girdi[0];
    for (size_t t = 0; t < 5; t++) {
        Ogrenci a[10];
        memcpy(a, girdi, sizeof girdi);
        ogrenci_sirala(a, n, olcutler[t]);
        printf("%zu) %s:", t + 1, adlar[t]);
        for (size_t k = 0; k < n; k++) {
            printf(" %d", a[k].no);
        }
        printf("\n");
    }
    return 0;
}

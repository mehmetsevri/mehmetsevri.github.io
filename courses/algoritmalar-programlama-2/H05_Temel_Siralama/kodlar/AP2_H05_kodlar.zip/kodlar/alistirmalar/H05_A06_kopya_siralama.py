"""H05_A06_kopya_siralama.py — AP-2 Hafta 5 · Alıştırma 5.16 (Python)
Amaç    : Diller arası okuma: "sıralı kopya" alırken özgün liste ne olur?
          C++ yarısı: H05_A06_kopya_siralama.cpp
Çalıştır: python3 H05_A06_kopya_siralama.py
"""


def main():
    a = [42, 17, 8, 31]
    b = a
    b.sort()
    print("a:", *a)
    print("b:", *b)


if __name__ == "__main__":
    main()

/* H05_A04_parsons_kabarcik.c — AP-2 Hafta 5 · Alıştırma 5.10 (Parsons)
 * Tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar erken çıkışlı
 * kabarcık sıralamasının KARIŞTIRILMIŞ satırlarıdır. Doğru sırayı ve
 * girintiyi bulun; kapanış parantezleri ({ }) ayrı satırda verilmiştir.
 */
            takas(&a[j], &a[j + 1]);
    for (size_t i = 0; i + 1 < n; i++) {
        if (!takas_oldu) {
            takas_oldu = 1;
static void kabarcik_sirala(int *a, size_t n)
        int takas_oldu = 0;
            break;
        for (size_t j = 0; j + 1 < n - i; j++) {
            if (a[j] > a[j + 1]) {
{
}
}
}
}
}

"""H05_A05_reverse_kararlilik.py — AP-2 Hafta 5 · Alıştırma 5.15
Amaç    : Diller arası okuma. Önce ÇALIŞTIRMADAN üç satırın çıktısını
          tahmin edin; reverse=True eşitlerin sırasını değiştirir mi?
Çalıştır: python3 H05_A05_reverse_kararlilik.py
"""

notlar = [("Ali", 80), ("Can", 90), ("Ece", 80), ("Efe", 90),
          ("Naz", 70)]


def main():
    print(sorted(notlar, key=lambda x: x[1]))
    print(sorted(notlar, key=lambda x: x[1], reverse=True))
    print(sorted(notlar, key=lambda x: -x[1]))


if __name__ == "__main__":
    main()

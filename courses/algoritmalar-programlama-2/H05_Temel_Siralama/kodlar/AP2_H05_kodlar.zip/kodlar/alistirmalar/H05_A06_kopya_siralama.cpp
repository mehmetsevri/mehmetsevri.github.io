/* H05_A06_kopya_siralama.cpp — AP-2 Hafta 5 · Alıştırma 5.16 (C++ yarısı)
 * Amaç    : Diller arası okuma: "sıralı kopya" alırken özgün dizi ne olur?
 *           Python yarısı: H05_A06_kopya_siralama.py
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_A06_kopya_siralama.cpp -o H05_A06_kopya_siralama
 * Çalıştır: ./H05_A06_kopya_siralama
 */
#include <algorithm>
#include <iostream>
#include <vector>

static void yaz(const char *ad, const std::vector<int>& v)
{
    std::cout << ad << ":";
    for (int x : v) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

int main()
{
    std::vector<int> a = {42, 17, 8, 31};
    std::vector<int> b = a;
    std::sort(b.begin(), b.end());
    yaz("a", a);
    yaz("b", b);
    return 0;
}

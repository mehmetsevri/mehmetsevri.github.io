/* H05_K03_sayac_araci.c — AP-2 Hafta 5 · Kavram 3 (Atölye 1 aracı)
 * Amaç    : İnsan sıralama makinesi atölyesinde elle sayılanları sınamak:
 *           komut satırındaki sayıları seçmeli, kabarcık (erken çıkışlı) ve
 *           araya ekleme sıralamasıyla sıralar; her geçişten sonra diziyi,
 *           sonunda karşılaştırma, takas ve kaydırma sayılarını yazar
 *           (sayaç sözleşmesi Örnek 1–3 ile aynı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_K03_sayac_araci.c -o H05_K03_sayac_araci
 * Çalıştır: ./H05_K03_sayac_araci 42 17 8 31 25 4 39 12
 *           (sayı verilmezse bu sekiz sayı kullanılır; en çok 32 sayı)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EN_COK 32

static long long karsilastirma, takas_sayisi, kaydirma;

static void yaz(const char *etiket, const int *a, size_t n)
{
    printf("  %s:", etiket);
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

static void secmeli(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en = i;
        for (size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[j] < a[en]) {
                en = j;
            }
        }
        if (en != i) {
            takas(&a[i], &a[en]);
            takas_sayisi++;
        }
        yaz("geçiş", a, n);
    }
}

static void kabarcik(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;
        for (size_t j = 0; j + 1 < n - i; j++) {
            karsilastirma++;
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
                takas_sayisi++;
                takas_oldu = 1;
            }
        }
        yaz("geçiş", a, n);
        if (!takas_oldu) {
            break;
        }
    }
}

static void araya(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0) {
            karsilastirma++;
            if (a[j] <= anahtar) {
                break;
            }
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
        yaz("adım", a, n);
    }
}

int main(int argc, char *argv[])
{
    int girdi[EN_COK] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = 8;
    if (argc > 1) {
        if (argc - 1 > EN_COK) {
            fprintf(stderr, "en çok %d sayı verin\n", EN_COK);
            return 2;
        }
        n = (size_t)(argc - 1);
        for (size_t k = 0; k < n; k++) {
            char *son;
            long v = strtol(argv[k + 1], &son, 10);
            if (*son != '\0' || v < -999999 || v > 999999) {
                fprintf(stderr, "geçersiz sayı: %s\n", argv[k + 1]);
                return 2;
            }
            girdi[k] = (int)v;
        }
    }
    const char *adlar[] = {"seçmeli", "kabarcık", "araya ekleme"};
    void (*fonk[])(int *, size_t) = {secmeli, kabarcik, araya};
    for (int t = 0; t < 3; t++) {
        int a[EN_COK];
        memcpy(a, girdi, n * sizeof a[0]);
        karsilastirma = takas_sayisi = kaydirma = 0;
        printf("%s:\n", adlar[t]);
        yaz("girdi", a, n);
        fonk[t](a, n);
        printf("  karşılaştırma = %lld, takas = %lld, kaydırma = %lld\n",
               karsilastirma, takas_sayisi, kaydirma);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (öğretim aracı; algoritmalar Örnek 1–3). */

/* H05_K02_std_tie.cpp — AP-2 Hafta 5 · Kavram 2 (Dil Penceresi)
 * Amaç    : C++'ta çok anahtarlı karşılaştırıcıyı std::tie ile kurmak:
 *           demetler (tuple) sözlük sırasıyla karşılaştırılır; Python'un
 *           (-o.ortalama, o.soyad, o.ad) anahtarının karşılığı. Azalan
 *           anahtar için x ve y'nin yeri değiştirilir. Kâhin olarak
 *           std::stable_sort; sonuç Örnek 10'un A sırasıyla aynıdır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_K02_std_tie.cpp -o H05_K02_std_tie
 * Çalıştır: ./H05_K02_std_tie
 */
#include <algorithm>
#include <iostream>
#include <string>
#include <tuple>
#include <vector>

struct Ogrenci {
    int no;
    std::string ad;
    std::string soyad;
    double ortalama;
};

// ortalama azalan (y önce), soyad artan, ad artan (x önce)
static bool once_mi(const Ogrenci& x, const Ogrenci& y)
{
    return std::tie(y.ortalama, x.soyad, x.ad) <
           std::tie(x.ortalama, y.soyad, y.ad);
}

int main()
{
    std::vector<Ogrenci> a = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };
    std::stable_sort(a.begin(), a.end(), once_mi);   // yalnızca kâhin
    std::cout << "std::tie sırası:";
    for (const Ogrenci& o : a) {
        std::cout << " " << o.no;
    }
    std::cout << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (anahtarlar sırayla denenir); C++ —
 * std::tie / std::tuple operator<; Python — key=lambda o: (…, …). */

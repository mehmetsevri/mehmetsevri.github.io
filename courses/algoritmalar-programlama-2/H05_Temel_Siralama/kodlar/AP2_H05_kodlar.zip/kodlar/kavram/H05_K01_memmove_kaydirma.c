/* H05_K01_memmove_kaydirma.c — AP-2 Hafta 5 · Kavram 1 (Kaputun Altında)
 * Amaç    : Araya eklemede kaydırmayı memmove ile BLOK olarak yapmak: önce
 *           yeri bul, sonra a[yer..i-1]'i tek çağrıyla bir sağa taşı. Öğe
 *           öğe kaydırmayla aynı sonuç ve aynı kaydırma sayısı; süreler
 *           stderr'e (tek çalıştırma, bu makinede)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -I../c \
 *           H05_K01_memmove_kaydirma.c ../c/ortak_rastgele.c \
 *           ../c/zamanlayici.c -o H05_K01_memmove_kaydirma
 * Çalıştır: ./H05_K01_memmove_kaydirma [n]     (varsayılan n = 20000)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

static long long kaydirma = 0;

/* Öğe öğe: büyükleri birer birer bir sağa kopyalar */
static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && a[j] > anahtar) {
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

/* Blok: önce yeri bul, sonra a[yer..i-1]'i tek memmove ile kaydır */
static void araya_ekleme_memmove(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        size_t yer = i;
        while (yer > 0 && a[yer - 1] > anahtar) {
            yer--;                       /* yalnızca karşılaştır */
        }
        /* bölgeler örtüşür: memcpy değil memmove */
        memmove(&a[yer + 1], &a[yer], (i - yer) * sizeof a[0]);
        kaydirma += (long long)(i - yer);
        a[yer] = anahtar;
    }
}

static void dene(const char *ad, const int *girdi, size_t n)
{
    int *x = malloc(n * sizeof *x);
    int *y = malloc(n * sizeof *y);
    if (x == NULL || y == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    memcpy(x, girdi, n * sizeof *x);
    memcpy(y, girdi, n * sizeof *y);

    kaydirma = 0;
    double t0 = zaman_sn();
    araya_ekleme_sirala(x, n);
    double t_oge = zaman_sn() - t0;
    long long k_oge = kaydirma;

    kaydirma = 0;
    t0 = zaman_sn();
    araya_ekleme_memmove(y, n);
    double t_blok = zaman_sn() - t0;
    long long k_blok = kaydirma;

    int ayni = memcmp(x, y, n * sizeof *x) == 0;
    printf("%s: kaydırma öğe öğe = %lld, memmove = %lld; aynı: %s\n",
           ad, k_oge, k_blok, ayni ? "evet" : "HAYIR");
    fprintf(stderr, "%s: öğe öğe %.3f ms, memmove %.3f ms (oran %.2f)\n",
            ad, t_oge * 1e3, t_blok * 1e3, t_oge / t_blok);
    free(x);
    free(y);
}

int main(int argc, char *argv[])
{
    size_t n = 20000;
    if (argc > 1) {
        char *son;
        long v = strtol(argv[1], &son, 10);
        if (*son != '\0' || v < 1 || v > 200000) {
            fprintf(stderr, "kullanım: %s [n]  (1 <= n <= 200000)\n",
                    argv[0]);
            return 2;
        }
        n = (size_t)v;
    }
    int *rastgele = malloc(n * sizeof *rastgele);
    int *ters = malloc(n * sizeof *ters);
    if (rastgele == NULL || ters == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    for (size_t i = 0; i < n; i++) {
        rastgele[i] = (int)(i + 1);
        ters[i] = (int)(n - i);
    }
    rastgele_tohum(42);
    rastgele_karistir(rastgele, n);
    printf("n = %zu (rastgele: 1..n karıştırılmış, tohum 42)\n", n);
    dene("rastgele", rastgele, n);
    dene("ters sıralı", ters, n);
    free(rastgele);
    free(ters);
    return 0;
}

/* Kütüphane karşılığı: C — memmove (örtüşen bölgeyi doğru kopyalar);
 * C++ — std::move_backward / std::rotate; Python — list.insert. */

/* H05_K04_neden_siralariz.c — AP-2 Hafta 5 · Kavram 4
 * Amaç    : Sıralamanın açtığı kapılar: sıralı dizide (1) yinelenenleri
 *           komşu karşılaştırmayla bulmak, (2) eşitleri gruplayıp saymak,
 *           (3) iki sıralı diziyi tek geçişte birleştirmek (H6'ya köprü),
 *           (4) ikili aramayla aramak (H4); karşılaştırma sayılarıyla
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_K04_neden_siralariz.c -o H05_K04_neden_siralariz
 * Çalıştır: ./H05_K04_neden_siralariz
 */
#include <stddef.h>
#include <stdio.h>

static long long karsilastirma = 0;

static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && a[j] > anahtar) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

/* Sırasız dizide yinelenen var mı? Her çift: n(n-1)/2 karşılaştırma */
static int yinelenen_var_kaba(const int *a, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[i] == a[j]) {
                return 1;
            }
        }
    }
    return 0;
}

/* Sıralı dizide eşitler yan yanadır: n - 1 komşu karşılaştırması */
static int yinelenen_var_sirali(const int *a, size_t n)
{
    for (size_t k = 1; k < n; k++) {
        karsilastirma++;
        if (a[k - 1] == a[k]) {
            return 1;
        }
    }
    return 0;
}

/* Sıralı dizide eşit değerlerin grupları: değer ve tekrar sayısı */
static void gruplari_yaz(const int *a, size_t n)
{
    size_t bas = 0;
    printf("   gruplar (değer×sayı):");
    for (size_t k = 1; k <= n; k++) {
        if (k == n || a[k] != a[bas]) {
            printf(" %d×%zu", a[bas], k - bas);
            bas = k;
        }
    }
    printf("\n");
}

/* İki sıralı diziyi c'ye birleştirir: en çok na + nb - 1 karşılaştırma */
static void birlestir(const int *a, size_t na, const int *b, size_t nb,
                      int *c)
{
    size_t i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        karsilastirma++;
        c[k++] = a[i] <= b[j] ? a[i++] : b[j++];   /* eşitte a önce */
    }
    while (i < na) {
        c[k++] = a[i++];
    }
    while (j < nb) {
        c[k++] = b[j++];
    }
}

/* H4: sıralı dizide x'in konumu ya da -1 */
static ptrdiff_t ikili_ara(const int *a, size_t n, int x)
{
    size_t lo = 0, hi = n;                  /* [lo, hi) */
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        karsilastirma++;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return (lo < n && a[lo] == x) ? (ptrdiff_t)lo : -1;
}

static void dizi_yaz(const char *etiket, const int *a, size_t n)
{
    printf("   %s:", etiket);
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 39, 12, 25, 8, 17, 50};
    size_t n = sizeof a / sizeof a[0];
    printf("1) yinelenen tespiti (n = %zu)\n", n);
    karsilastirma = 0;
    int v = yinelenen_var_kaba(a, n);
    printf("   sırasız, her çift : %s, karşılaştırma = %lld\n",
           v ? "var" : "yok", karsilastirma);
    araya_ekleme_sirala(a, n);
    dizi_yaz("sıralı", a, n);
    karsilastirma = 0;
    v = yinelenen_var_sirali(a, n);
    printf("   sıralı, komşular  : %s, karşılaştırma = %lld\n",
           v ? "var" : "yok", karsilastirma);

    printf("2) gruplama (eşitler ardışık)\n");
    gruplari_yaz(a, n);

    printf("3) iki sıralı diziyi birleştirme (H6'da birleştirmeli sıralama)\n");
    int b[] = {3, 9, 17, 30};
    int c[16];
    karsilastirma = 0;
    birlestir(a, n, b, 4, c);
    dizi_yaz("sonuç", c, n + 4);
    printf("   karşılaştırma = %lld (en çok %zu)\n", karsilastirma, n + 3);

    printf("4) ikili arama (H4) sıralı dizide\n");
    int aranan[] = {31, 30};
    for (int k = 0; k < 2; k++) {
        karsilastirma = 0;
        ptrdiff_t yer = ikili_ara(a, n, aranan[k]);
        printf("   %d -> konum %td, karşılaştırma = %lld\n", aranan[k], yer,
               karsilastirma);
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort + bsearch; C++ — std::sort,
 * std::adjacent_find, std::merge, std::lower_bound; Python — sorted,
 * itertools.groupby, heapq.merge, bisect.bisect_left. */

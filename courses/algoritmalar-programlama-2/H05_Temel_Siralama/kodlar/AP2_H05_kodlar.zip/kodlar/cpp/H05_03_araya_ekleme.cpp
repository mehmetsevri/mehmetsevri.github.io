/* H05_03_araya_ekleme.cpp — AP-2 Hafta 5 · Örnek 3 (★)
 * Amaç    : Araya ekleme sıralaması: anahtarı sıralı öneke kaydırarak
 *           yerleştirme; değişmez (a[0..i] sıralı) ve çevrimiçi ekleme
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_03_araya_ekleme.cpp -o H05_03_araya_ekleme
 * Çalıştır: ./H05_03_araya_ekleme
 * Eşleri  : c/H05_03_araya_ekleme.c · python/H05_03_araya_ekleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

static long long karsilastirma = 0;
static long long kaydirma = 0;

// a'yı yazar; sinir < a.size() ise a[sinir]'dan önce '|' koyar
static void dizi_yaz(const std::vector<int>& a, std::size_t sinir)
{
    for (std::size_t k = 0; k < a.size(); k++) {
        if (k == sinir) {
            std::cout << " |";
        }
        std::cout << std::setw(3) << a[k];
    }
    std::cout << "\n";
}

// x > y karşılaştırmasını sayarak yapar
static bool buyuk_mu(int x, int y)
{
    karsilastirma++;
    return x > y;
}

// a[0..i-1] sıralı; a[i]'yi kaydırarak yerine koyar, konumunu döndürür
static std::size_t yerlestir(std::vector<int>& a, std::size_t i)
{
    int anahtar = a[i];
    auto j = static_cast<std::ptrdiff_t>(i) - 1;
    while (j >= 0 && buyuk_mu(a[j], anahtar)) {
        a[j + 1] = a[j];   // bir sağa kaydır
        kaydirma++;
        j--;
    }
    a[j + 1] = anahtar;
    return static_cast<std::size_t>(j + 1);
}

static void araya_ekleme_sirala(std::vector<int>& a, bool yazdir)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        int anahtar = a[i];
        long long onceki = kaydirma;
        std::size_t yer = yerlestir(a, i);
        if (yazdir) {
            std::cout << "i = " << i << ": anahtar = " << std::setw(2)
                      << anahtar << ", kaydırma = " << kaydirma - onceki
                      << ", yeri a[" << yer << "]\n";
            std::cout << "      ";
            dizi_yaz(a, i + 1);
        }
    }
}

int main()
{
    std::vector<int> a = {42, 17, 8, 31, 25, 4, 39, 12};

    std::cout << "Araya ekleme sıralaması, n = " << a.size()
              << " ('|' solu: sıralı önek)\n";
    std::cout << "başlangıç:\n      ";
    dizi_yaz(a, 1);
    araya_ekleme_sirala(a, true);
    std::cout << "toplam: karşılaştırma = " << karsilastirma
              << ", kaydırma = " << kaydirma << "\n";

    std::cout << "\nÇevrimiçi: yeni gelen eleman sıralı diziye eklenir\n";
    for (int x : {15, 50, 1}) {
        karsilastirma = 0;
        kaydirma = 0;
        a.push_back(x);                    // sona ekle ...
        std::size_t yer = yerlestir(a, a.size() - 1);  // ... ve kaydır
        std::cout << "+" << std::setw(2) << x << " -> yeri a[" << yer
                  << "], karşılaştırma = " << karsilastirma
                  << ", kaydırma = " << kaydirma << "\n      ";
        dizi_yaz(a, a.size());
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort, sıralı vektöre ekleme
 * için std::upper_bound + insert; Python — bisect.insort (yalnızca not). */

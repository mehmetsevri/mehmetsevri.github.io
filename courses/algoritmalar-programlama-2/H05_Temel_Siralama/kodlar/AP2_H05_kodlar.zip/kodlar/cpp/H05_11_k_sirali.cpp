/* H05_11_k_sirali.cpp — AP-2 Hafta 5 · Örnek 11 (★★★)
 * Amaç    : k-sıralı (neredeyse sıralı) dizide araya eklemenin O(nk)
 *           davranışı; kabarcık ve seçmeli ile karşılaştırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_11_k_sirali.cpp -o H05_11_k_sirali
 * Çalıştır: ./H05_11_k_sirali
 * Eşleri  : c/H05_11_k_sirali.c · python/H05_11_k_sirali.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0;
static long long takas_sayisi = 0;
static long long kaydirma = 0;
static long long gecis_sayisi = 0;

static void sayaclari_sifirla()
{
    karsilastirma = 0;
    takas_sayisi = 0;
    kaydirma = 0;
    gecis_sayisi = 0;
}

// 1..n sıralı dizi; (k + 1)'lik bloklar kendi içinde karıştırılır:
// her eleman sıralı konumundan en fazla k uzaktadır (k-sıralı)
static std::vector<int> k_sirali_dizi(std::size_t n, std::size_t k)
{
    std::vector<int> a(n);
    for (std::size_t i = 0; i < n; i++) {
        a[i] = static_cast<int>(i + 1);
    }
    for (std::size_t bas = 0; bas < n; bas += k + 1) {
        std::size_t son = bas + k < n ? bas + k : n - 1;  // blok: bas..son
        for (std::size_t i = son; i > bas; i--) {         // Fisher–Yates
            int ust = static_cast<int>(i - bas);
            std::size_t j = bas + static_cast<std::size_t>(
                                      rastgele_aralik(0, ust));
            std::swap(a[i], a[j]);
        }
    }
    return a;
}

// En büyük |i - sıralı konum|: değer v'nin sıralı konumu v - 1
static std::size_t en_buyuk_uzaklik(const std::vector<int>& a)
{
    std::size_t en = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        std::size_t hedef = static_cast<std::size_t>(a[i]) - 1;
        std::size_t d = i > hedef ? i - hedef : hedef - i;
        if (d > en) {
            en = d;
        }
    }
    return en;
}

static void araya_ekleme_sirala(std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        int anahtar = a[i];
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0) {
            karsilastirma++;
            if (a[j] <= anahtar) {
                break;
            }
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

static void kabarcik_sirala(std::vector<int>& a)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        bool takas_oldu = false;
        for (std::size_t j = 0; j + 1 < n - i; j++) {
            karsilastirma++;
            if (a[j] > a[j + 1]) {
                std::swap(a[j], a[j + 1]);
                takas_sayisi++;
                takas_oldu = true;
            }
        }
        gecis_sayisi++;
        if (!takas_oldu) {
            break;
        }
    }
}

static void secmeli_sirala(std::vector<int>& a)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        std::size_t en_kucuk = i;
        for (std::size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            std::swap(a[i], a[en_kucuk]);
            takas_sayisi++;
        }
    }
}

int main()
{
    const std::size_t n = 1000;
    const std::vector<std::size_t> ks = {0, 1, 2, 4, 8, 16, 32, 64, n - 1};

    std::cout << "k-sıralı dizi: her eleman sıralı yerinden en fazla k "
                 "uzakta\n";
    std::cout << "(1..n, (k+1)'lik bloklar içinde karıştırılmış; n = " << n
              << ", tohum 7)\n";
    std::cout << "kuram: kaydırma = ters çevrim <= n·k; kabarcık geçişi "
                 "<= k + 1\n\n";
    std::cout << "            araya ekleme                kabarcık        "
                 "seçmeli\n";
    std::cout << "   k  uzak.  kaydırma kayd/(nk)   karş.  geçiş     karş."
                 "     karş.\n";
    rastgele_tohum(7);
    for (std::size_t k : ks) {
        const std::vector<int> girdi = k_sirali_dizi(n, k);
        std::size_t uzaklik = en_buyuk_uzaklik(girdi);

        std::vector<int> a = girdi;
        sayaclari_sifirla();
        araya_ekleme_sirala(a);
        long long ae_kayd = kaydirma, ae_kars = karsilastirma;

        a = girdi;
        sayaclari_sifirla();
        kabarcik_sirala(a);
        long long kb_gecis = gecis_sayisi, kb_kars = karsilastirma;

        a = girdi;
        sayaclari_sifirla();
        secmeli_sirala(a);

        std::cout << std::setw(4) << k << " " << std::setw(6) << uzaklik
                  << " " << std::setw(9) << ae_kayd;
        if (k > 0) {
            double oran = static_cast<double>(ae_kayd) /
                          (static_cast<double>(n) * static_cast<double>(k));
            std::cout << " " << std::fixed << std::setprecision(3)
                      << std::setw(9) << oran;
        } else {
            std::cout << " " << std::setw(9) << "-";  // k = 0: n·k = 0
        }
        std::cout << " " << std::setw(7) << ae_kars << " " << std::setw(6)
                  << kb_gecis << " " << std::setw(9) << kb_kars << " "
                  << std::setw(9) << karsilastirma << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort
 * (Timsort: girdideki sıralı parçalardan yararlanan uyarlanabilir
 * sıralama). */

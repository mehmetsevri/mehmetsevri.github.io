/* H05_09_kararlilik.cpp — AP-2 Hafta 5 · Örnek 9 (★★)
 * Amaç    : Kararlılık deneyi: eşit ortalamalı kayıtlarda seçmeli
 *           (kararsız) ve araya ekleme / kabarcık (kararlı) sıralama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_09_kararlilik.cpp -o H05_09_kararlilik
 * Çalıştır: ./H05_09_kararlilik
 * Eşleri  : c/H05_09_kararlilik.c · python/H05_09_kararlilik.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

struct Ogrenci {
    int no;                 // kayıt sırası etiketi: 101, 102, ...
    std::string ad;
    std::string soyad;
    double ortalama;
};

using OnceMi = bool (*)(const Ogrenci&, const Ogrenci&);
using Siralayici = void (*)(std::vector<Ogrenci>&, OnceMi);

static bool ortalama_azalan(const Ogrenci& x, const Ogrenci& y)
{
    return x.ortalama > y.ortalama;         // x, y'den önce mi?
}

static void secmeli_sirala(std::vector<Ogrenci>& a, OnceMi once_mi)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        std::size_t en = i;                 // sırada önce gelecek olan
        for (std::size_t j = i + 1; j < n; j++) {
            if (once_mi(a[j], a[en])) {
                en = j;
            }
        }
        if (en != i) {
            std::swap(a[i], a[en]);         // uzak takas: sırayı bozar
        }
    }
}

static void kabarcik_sirala(std::vector<Ogrenci>& a, OnceMi once_mi)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        bool takas_oldu = false;
        for (std::size_t j = 0; j + 1 < n - i; j++) {
            if (once_mi(a[j + 1], a[j])) {   // eşitse takas YOK
                std::swap(a[j], a[j + 1]);
                takas_oldu = true;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
}

static void araya_ekleme_sirala(std::vector<Ogrenci>& a, OnceMi once_mi)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        Ogrenci anahtar = a[i];
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0 && once_mi(anahtar, a[j])) {   // eşitse dur
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

// Eşit anahtarlı olup kayıt sırası bozulan çiftleri yazar; sayısını
// döndürür (çift: çıktıda önce gelen no, sonra gelen no)
static int bozulan_ciftler(const std::vector<Ogrenci>& a)
{
    int sayi = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        for (std::size_t j = i + 1; j < a.size(); j++) {
            if (a[i].ortalama == a[j].ortalama && a[i].no > a[j].no) {
                std::cout << (sayi % 6 == 0 ? "\n    (" : " (") << a[i].no
                          << " önce, " << a[j].no << " sonra)";
                sayi++;
            }
        }
    }
    return sayi;
}

static void sonuc_yaz(const std::string& ad, const std::vector<Ogrenci>& a,
                      bool denetle)
{
    std::cout << ad << ":\n   " << std::fixed << std::setprecision(2);
    for (std::size_t k = 0; k < a.size(); k++) {
        std::cout << " " << a[k].ortalama << "(" << a[k].no << ")";
        if (k == 4) {
            std::cout << "\n   ";
        }
    }
    std::cout << "\n";
    if (!denetle) {
        return;
    }
    std::cout << "   bozulan eşit çiftler:";
    int sayi = bozulan_ciftler(a);
    if (sayi == 0) {
        std::cout << " yok";
    }
    std::cout << "\n   kararlı davrandı mı? " << (sayi == 0 ? "evet" : "HAYIR")
              << " (" << sayi << " çift)\n";
}

int main()
{
    const std::vector<Ogrenci> girdi = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };
    const std::vector<std::string> adlar = {"seçmeli", "kabarcık",
                                            "araya ekleme"};
    const std::vector<Siralayici> f = {secmeli_sirala, kabarcik_sirala,
                                       araya_ekleme_sirala};

    std::cout << "Kararlılık: ortalamaya göre azalan; parantez içi kayıt "
                 "no\n";
    std::cout << "(kararlı sıralama eşit ortalamalılarda no artan sırayı "
                 "korur)\n";
    sonuc_yaz("girdi", girdi, false);
    for (std::size_t k = 0; k < 3; k++) {
        std::vector<Ogrenci> a = girdi;     // vektör kopyası
        f[k](a, ortalama_azalan);
        std::cout << "\n";
        sonuc_yaz(adlar[k], a, true);
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (kararlılık güvencesi YOK); C++ —
 * std::stable_sort (kararlı), std::sort (kararsız); Python — sorted
 * ve list.sort (Timsort, kararlı). */

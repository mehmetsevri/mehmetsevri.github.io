/* H05_13_shell_siralama.cpp — AP-2 Hafta 5 · Örnek 13 (★★★, merak)
 * Amaç    : Shell sıralaması (h-sıralama) ve aralık dizisi deneyi:
 *           Shell (n/2, n/4, ..., 1), Knuth (3h + 1), Ciura
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_13_shell_siralama.cpp -o H05_13_shell_siralama
 * Çalıştır: ./H05_13_shell_siralama
 * Eşleri  : c/H05_13_shell_siralama.c
 *           python/H05_13_shell_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0;
static long long kaydirma = 0;

static void dizi_yaz(const std::vector<int>& a)
{
    for (int x : a) {
        std::cout << std::setw(3) << x;
    }
    std::cout << "\n";
}

// Her h için: a[i], a[i-h], a[i-2h], ... alt dizisinde araya ekleme
static void h_gecisi(std::vector<int>& a, std::size_t h)
{
    for (std::size_t i = h; i < a.size(); i++) {
        int anahtar = a[i];
        std::size_t j = i;                 // boşluğun konumu
        while (j >= h) {
            karsilastirma++;
            if (a[j - h] <= anahtar) {
                break;
            }
            a[j] = a[j - h];   // h sağa kaydır
            kaydirma++;
            j -= h;
        }
        a[j] = anahtar;
    }
}

static void shell_sirala(std::vector<int>& a,
                         const std::vector<std::size_t>& h)
{
    for (std::size_t g : h) {              // h: büyükten küçüğe, son 1
        h_gecisi(a, g);
    }
}

// a, h-sıralı mı? (her i için a[i - h] <= a[i])
static bool h_sirali_mi(const std::vector<int>& a, std::size_t h)
{
    for (std::size_t i = h; i < a.size(); i++) {
        if (a[i - h] > a[i]) {
            return false;
        }
    }
    return true;
}

// Aralık dizileri (azalan, son eleman 1)
static std::vector<std::size_t> shell_araliklari(std::size_t n)
{
    std::vector<std::size_t> h;
    for (std::size_t g = n / 2; g > 0; g /= 2) {
        h.push_back(g);
    }
    return h;
}

static std::vector<std::size_t> knuth_araliklari(std::size_t n)
{
    std::size_t g = 1;
    while (g < n / 3) {
        g = 3 * g + 1;                     // 1, 4, 13, 40, 121, ...
    }
    std::vector<std::size_t> h;
    for (; g > 0; g /= 3) {
        h.push_back(g);
    }
    return h;
}

static std::vector<std::size_t> ciura_araliklari(std::size_t n)
{
    const std::vector<std::size_t> ciura = {701, 301, 132, 57, 23, 10, 4, 1};
    std::vector<std::size_t> h;
    for (std::size_t g : ciura) {
        if (g < n || g == 1) {
            h.push_back(g);
        }
    }
    return h;
}

static void h_listesi_yaz(const std::string& ad,
                          const std::vector<std::size_t>& h)
{
    std::cout << "   " << ad << ":";
    for (std::size_t g : h) {
        std::cout << " " << g;
    }
    std::cout << "\n";
}

int main()
{
    // 1) Küçük örnek: h = 4, 2, 1 geçişleri
    std::vector<int> k = {42, 17, 8, 31, 25, 4, 39, 12};
    std::cout << "1) Shell sıralaması, n = 8, h = 4, 2, 1\n   başlangıç: ";
    dizi_yaz(k);
    for (std::size_t g : shell_araliklari(k.size())) {
        karsilastirma = 0;
        kaydirma = 0;
        h_gecisi(k, g);
        std::cout << "   h = " << g << "    : ";
        dizi_yaz(k);
        std::cout << "   " << g << "-sıralı mı? "
                  << (h_sirali_mi(k, g) ? "evet" : "hayır")
                  << "   karşılaştırma = " << karsilastirma
                  << ", kaydırma = " << kaydirma << "\n";
    }

    // 2) Aralık dizisi deneyi
    std::cout << "\n2) aralık dizileri: rastgele permütasyon (ortak LCG, "
                 "tohum 13)\n";
    for (std::size_t n : {100, 1000, 5000}) {
        std::vector<int> girdi(n);
        for (std::size_t i = 0; i < n; i++) {
            girdi[i] = static_cast<int>(i + 1);
        }
        rastgele_tohum(13);
        rastgele_karistir(girdi);
        std::cout << "\nn = " << n << "\n";
        std::cout << "   yöntem          karşılaştırma    kaydırma  sıralı\n";
        const std::vector<std::string> adlar = {"Shell (n/2)", "Knuth (3h+1)",
                                                "Ciura", "araya ekleme"};
        const std::vector<std::vector<std::size_t>> hd = {
            shell_araliklari(n), knuth_araliklari(n), ciura_araliklari(n),
            {1}};                            // h = 1: araya ekleme
        for (std::size_t y = 0; y < 4; y++) {
            std::vector<int> a = girdi;
            karsilastirma = 0;
            kaydirma = 0;
            shell_sirala(a, hd[y]);
            std::cout << "   " << std::left << std::setw(14) << adlar[y]
                      << std::right << " " << std::setw(14) << karsilastirma
                      << " " << std::setw(11) << kaydirma << "  "
                      << (h_sirali_mi(a, 1) ? "evet" : "HAYIR") << "\n";
        }
        for (std::size_t y = 0; y < 3; y++) {
            h_listesi_yaz(adlar[y], hd[y]);
        }
    }

    // 3) Kararlılık: anahtar = değer / 10, etiket = değer % 10
    std::vector<int> e = {20, 10, 21, 11, 22, 12};
    std::cout << "\n3) kararlılık (sayı: anahtar, harf: özgün sıra "
                 "etiketi)\n";
    std::cout << "   girdi : ";
    for (int x : e) {
        std::cout << " " << x / 10 << static_cast<char>('a' + x % 10);
    }
    for (std::size_t g : shell_araliklari(e.size())) {  // 3, 1
        for (std::size_t i = g; i < e.size(); i++) {    // yalnız anahtar
            int anahtar = e[i];
            std::size_t j = i;
            while (j >= g && e[j - g] / 10 > anahtar / 10) {
                e[j] = e[j - g];
                j -= g;
            }
            e[j] = anahtar;
        }
    }
    std::cout << "\n   sonuç : ";
    bool kararli = true;
    for (std::size_t i = 0; i < e.size(); i++) {
        std::cout << " " << e[i] / 10 << static_cast<char>('a' + e[i] % 10);
        if (i > 0 && e[i - 1] / 10 == e[i] / 10 && e[i - 1] > e[i]) {
            kararli = false;
        }
    }
    std::cout << "\n   eşit anahtarlarda etiket sırası korundu mu? "
              << (kararli ? "evet" : "HAYIR (Shell sıralaması kararsız)")
              << "\n";
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Ciura aralıkları deneysel
 * olarak bulunmuş bir dizidir; burada 701'e kadar kullanılır. */

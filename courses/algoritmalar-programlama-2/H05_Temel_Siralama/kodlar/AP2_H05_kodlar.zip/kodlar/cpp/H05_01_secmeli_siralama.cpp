/* H05_01_secmeli_siralama.cpp — AP-2 Hafta 5 · Örnek 1 (★)
 * Amaç    : Seçmeli sıralama; her geçişten sonra dizi ve değişmez:
 *           a[0..i] sıralıdır ve dizinin en küçük i + 1 elemanını içerir
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_01_secmeli_siralama.cpp -o H05_01_secmeli_siralama
 * Çalıştır: ./H05_01_secmeli_siralama
 * Eşleri  : c/H05_01_secmeli_siralama.c
 *           python/H05_01_secmeli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

static long long karsilastirma = 0;
static long long takas_sayisi = 0;

// a'yı yazar; sinir < a.size() ise a[sinir]'dan önce '|' koyar
static void dizi_yaz(const std::vector<int>& a, std::size_t sinir)
{
    for (std::size_t k = 0; k < a.size(); k++) {
        if (k == sinir) {
            std::cout << " |";
        }
        std::cout << std::setw(3) << a[k];
    }
    std::cout << "\n";
}

// Değişmez: a[0..s-1] sıralı ve a[0..s-1] <= a[s..n-1] (her eleman)
static bool degismez_tamam_mi(const std::vector<int>& a, std::size_t s)
{
    for (std::size_t k = 1; k < s; k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    for (std::size_t k = s; s > 0 && k < a.size(); k++) {
        if (a[s - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

static void gecis_yaz(const std::vector<int>& a, std::size_t i,
                      std::size_t en_kucuk)
{
    std::cout << "i = " << i << ": en küçük a[" << en_kucuk << "] = "
              << std::setw(2) << a[i] << ", ";
    if (en_kucuk != i) {
        std::cout << "takas a[" << i << "] <-> a[" << en_kucuk << "]\n";
    } else {
        std::cout << "takas yok\n";
    }
    std::cout << "      ";
    dizi_yaz(a, i + 1);
    std::cout << "      değişmez: "
              << (degismez_tamam_mi(a, i + 1) ? "evet" : "HAYIR") << "\n";
}

static void secmeli_sirala(std::vector<int>& a, bool yazdir)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        std::size_t en_kucuk = i;
        for (std::size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            std::swap(a[i], a[en_kucuk]);
            takas_sayisi++;
        }
        if (yazdir) {
            gecis_yaz(a, i, en_kucuk);
        }
    }
}

int main()
{
    std::vector<int> a = {42, 17, 8, 31, 25, 4, 39, 12};
    std::size_t n = a.size();

    std::cout << "Seçmeli sıralama, n = " << n
              << " ('|' solu: sıralı önek)\n";
    std::cout << "başlangıç:\n      ";
    dizi_yaz(a, n);
    secmeli_sirala(a, true);
    std::cout << "sonuç:\n      ";
    dizi_yaz(a, n);
    std::cout << "karşılaştırma = " << karsilastirma
              << "   n(n-1)/2 = " << n * (n - 1) / 2 << "\n";
    std::cout << "takas = " << takas_sayisi << "   (en fazla n - 1 = "
              << n - 1 << ")\n";

    std::cout << "\nKenar durumları (i + 1 < n koşulu; n - 1 taşmaz):\n";
    for (std::size_t boyut = 0; boyut <= 1; boyut++) {
        std::vector<int> bir(boyut, 7);
        karsilastirma = 0;
        takas_sayisi = 0;
        secmeli_sirala(bir, false);
        std::cout << "n = " << boyut << ": karşılaştırma = "
                  << karsilastirma << ", takas = " << takas_sayisi << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritma belirtilmez); C++ —
 * std::sort; Python — list.sort() / sorted() (yalnızca kâhin). */

/* H05_07_qsort_arayuzu.cpp — AP-2 Hafta 5 · Örnek 7 (★★)
 * Amaç    : Genel sıralama arayüzü (qsort · std::sort · sorted): int,
 *           double ve dizgi dizileri; taşmaya güvenli karşılaştırıcı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_07_qsort_arayuzu.cpp -o H05_07_qsort_arayuzu
 * Çalıştır: ./H05_07_qsort_arayuzu
 * Eşleri  : c/H05_07_qsort_arayuzu.c · python/H05_07_qsort_arayuzu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <climits>
#include <cstddef>
#include <functional>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

// std::sort(ilk, son, once_mi): once_mi(x, y) "x, y'den önce gelir mi?"
// sorusunu yanıtlar (bool; katı zayıf sıralama). Varsayılan: x < y.

// İki anahtar: önce uzunluk (artan), eşitse alfabe (bayt) sırası
static bool uzunluk_sonra_alfabe(const std::string& x, const std::string& y)
{
    if (x.size() != y.size()) {
        return x.size() < y.size();
    }
    return x < y;
}

static void int_yaz(const std::string& etiket, const std::vector<int>& a)
{
    std::cout << "   " << etiket << ":";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

static void double_yaz(const std::string& etiket,
                       const std::vector<double>& a)
{
    std::cout << "   " << etiket << ":" << std::fixed << std::setprecision(2);
    for (double x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

static void dizgi_yaz(const std::string& etiket,
                      const std::vector<std::string>& a)
{
    std::cout << "   " << etiket << ":";
    for (const std::string& x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

int main()
{
    std::vector<int> a = {3, -7, INT_MAX, 0, INT_MIN, 42, -1, 7};
    std::cout << "1) int dizisi: qsort + taşmaya güvenli karşılaştırıcı\n";
    int_yaz("girdi ", a);
    std::sort(a.begin(), a.end());                       // x < y
    int_yaz("artan ", a);
    std::sort(a.begin(), a.end(), std::greater<int>());  // x > y
    int_yaz("azalan", a);
    long long fark = static_cast<long long>(INT_MAX) - (-1);
    std::cout << "   neden x - y değil? INT_MAX - (-1) = " << fark
              << " > INT_MAX = " << INT_MAX << "\n";
    std::cout << "   (int'te taşma: C'de tanımsız davranış; bkz. Hata "
                 "Avcısı)\n";

    std::vector<double> d = {2.5, -0.75, 3.14, 0.1, -2.0, 0.3};
    std::cout << "\n2) double dizisi\n";
    double_yaz("girdi ", d);
    std::sort(d.begin(), d.end(),
              [](double x, double y) { return x < y; });  // lambda
    double_yaz("artan ", d);
    std::cout << "   (int)(0.1 - 0.3) = " << static_cast<int>(0.1 - 0.3)
              << ": kesme, farklı sayıları \"eşit\" gösterir\n";

    std::vector<std::string> s = {"elma", "Zeki", "armut", "Çelik", "Can",
                                  "ali", "Şule"};
    std::cout << "\n3) dizgi dizisi: strcmp (bayt sırası)\n";
    dizgi_yaz("girdi ", s);
    std::sort(s.begin(), s.end());       // std::string < : bayt sırası
    dizgi_yaz("artan ", s);
    std::cout << "   bayt sırası alfabe sırası değil: Ç ve Ş, z'den bile sonra "
                 "(Mini-OBS 2 v2.4)\n";

    std::vector<std::string> m = {"elma", "kivi", "armut", "nar", "incir",
                                  "ayva", "dut"};
    std::cout << "\n4) iki anahtarlı karşılaştırıcı: uzunluk, sonra alfabe\n";
    dizgi_yaz("girdi ", m);
    std::sort(m.begin(), m.end(), uzunluk_sonra_alfabe);
    dizgi_yaz("sonuç ", m);
    return 0;
}

/* Kütüphane karşılığı: bu örneğin konusu kütüphane arayüzüdür.
 * C — qsort; C++ — std::sort + karşılaştırıcı; Python — sorted(key=…). */

/* H05_06_kahin_testi.cpp — AP-2 Hafta 5 · Örnek 6 (★★)
 * Amaç    : "Dizi sıralı mı?" denetimi ve kütüphane sıralamasıyla kâhin
 *           testi: özel diziler + rastgele diziler (deterministik özet)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_06_kahin_testi.cpp -o H05_06_kahin_testi
 * Çalıştır: ./H05_06_kahin_testi
 * Eşleri  : c/H05_06_kahin_testi.c · python/H05_06_kahin_testi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <climits>
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

using Siralayici = void (*)(std::vector<int>&);

static void secmeli_sirala(std::vector<int>& a)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        std::size_t en_kucuk = i;
        for (std::size_t j = i + 1; j < n; j++) {
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            std::swap(a[i], a[en_kucuk]);
        }
    }
}

static void kabarcik_sirala(std::vector<int>& a)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        bool takas_oldu = false;
        for (std::size_t j = 0; j + 1 < n - i; j++) {
            if (a[j] > a[j + 1]) {
                std::swap(a[j], a[j + 1]);
                takas_oldu = true;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
}

static void araya_ekleme_sirala(std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        int anahtar = a[i];
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0 && a[j] > anahtar) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

// HATALI "sıralama": a[i] yerine a[0..i]'nin en büyüğünü yazar.
// Sonuç her zaman sıralıdır ama girdinin permütasyonu olmayabilir.
static void sahte_sirala(std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (a[i] < a[i - 1]) {
            a[i] = a[i - 1];
        }
    }
}

// a azalmayan sırada mı? (n - 1 karşılaştırma)
static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

// Kâhin: kütüphane sıralamasının sonucu (yalnızca test için)
static std::vector<int> kahin(std::vector<int> girdi)
{
    std::sort(girdi.begin(), girdi.end());
    return girdi;
}

// s'yi yazar; görünen genişlik (UTF-8 kod noktası) g olana dek boşluk
static void sola_yasla(const std::string& s, int g)
{
    int uzunluk = 0;
    for (unsigned char c : s) {
        if ((c & 0xC0) != 0x80) {
            uzunluk++;
        }
    }
    std::cout << s << std::string(g > uzunluk ? g - uzunluk : 0, ' ');
}

static void dizi_yaz(const std::vector<int>& a)
{
    std::cout << "[";
    for (std::size_t k = 0; k < a.size(); k++) {
        std::cout << (k ? " " : "") << a[k];
    }
    std::cout << "]";
}

// Test kümesi: 8 özel dizi + n = 0..30 için 20'şer rastgele dizi
static std::vector<int> dizi_uret(std::size_t t)
{
    static const std::vector<std::vector<int>> ozel = {
        {}, {5}, {2, 1}, {1, 2}, {3, 3, 3}, {5, 4, 3, 2, 1},
        {1, 2, 3, 4, 5}, {-3, 0, -3, INT_MAX, INT_MIN}};
    if (t < 8) {
        return ozel[t];
    }
    std::size_t n = (t - 8) / 20;                 // 0, 1, ..., 30
    if ((t - 8) % 2 == 0) {
        return rastgele_dizi(n, 0, 9);            // çok yinelenen
    }
    return rastgele_dizi(n, -1000, 1000);
}

int main()
{
    const std::vector<std::string> adlar = {"seçmeli", "kabarcık",
                                            "araya ekleme",
                                            "sahte (hatalı)"};
    const std::vector<Siralayici> fonksiyonlar = {
        secmeli_sirala, kabarcik_sirala, araya_ekleme_sirala, sahte_sirala};
    std::size_t test_sayisi = 8 + 31 * 20;
    std::vector<int> hata_girdi, hata_cikti, hata_kahin;
    bool hata_var = false;

    std::cout << "Kâhin testi: kendi sıralamalarımız ve kütüphane "
                 "sıralaması\n";
    std::cout << "(kâhin: C qsort, C++ std::sort, Python sorted)\n";
    std::cout << "test kümesi: 8 özel dizi + n = 0..30 için 20'şer "
                 "rastgele dizi = " << test_sayisi << " dizi\n\n";
    std::cout << "algoritma          sıralı mı  kâhinle aynı\n";
    for (std::size_t f = 0; f < 4; f++) {
        std::size_t sirali = 0, ayni = 0;
        rastgele_tohum(2026);        // her algoritmaya aynı diziler
        for (std::size_t t = 0; t < test_sayisi; t++) {
            std::vector<int> girdi = dizi_uret(t);
            std::vector<int> a = girdi;
            fonksiyonlar[f](a);
            std::vector<int> beklenen = kahin(girdi);
            sirali += sirali_mi(a) ? 1 : 0;
            bool esit = a == beklenen;            // vektör karşılaştırması
            ayni += esit ? 1 : 0;
            if (!esit && !hata_var) {             // ilk yakalanan hata
                hata_var = true;
                hata_girdi = girdi;
                hata_cikti = a;
                hata_kahin = beklenen;
            }
        }
        sola_yasla(adlar[f], 15);
        std::cout << std::setw(9) << sirali << "/" << test_sayisi << " "
                  << std::setw(10) << ayni << "/" << test_sayisi << "\n";
    }
    if (hata_var) {
        std::cout << "\nkâhinin yakaladığı ilk hata:\n  girdi  ";
        dizi_yaz(hata_girdi);
        std::cout << "\n  çıktı  ";
        dizi_yaz(hata_cikti);
        std::cout << "  sıralı mı: " << (sirali_mi(hata_cikti) ? "evet"
                                                                : "hayır")
                  << "\n  kâhin  ";
        dizi_yaz(hata_kahin);
        std::cout << "\n";
    }
    std::cout << "\nSonuç: \"sıralı mı?\" tek başına yetmez; çıktı girdinin "
                 "permütasyonu da olmalı.\n";
    return 0;
}

/* Kütüphane karşılığı (burada kâhin): C — qsort; C++ — std::sort;
 * Python — sorted(a). */

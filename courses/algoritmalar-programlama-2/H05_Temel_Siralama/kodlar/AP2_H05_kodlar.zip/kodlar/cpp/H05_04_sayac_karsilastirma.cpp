/* H05_04_sayac_karsilastirma.cpp — AP-2 Hafta 5 · Örnek 4 (★★)
 * Amaç    : Üç algoritmanın karşılaştırma ve takas/kaydırma sayıları:
 *           rastgele, sıralı ve ters sıralı girdi; kuramsal formüllerle
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_04_sayac_karsilastirma.cpp -o H05_04_sayac_karsilastirma
 * Çalıştır: ./H05_04_sayac_karsilastirma
 * Eşleri  : c/H05_04_sayac_karsilastirma.c
 *           python/H05_04_sayac_karsilastirma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0;
static long long takas_sayisi = 0;
static long long kaydirma = 0;

static void sayaclari_sifirla()
{
    karsilastirma = 0;
    takas_sayisi = 0;
    kaydirma = 0;
}

// s'yi yazar; görünen genişlik (UTF-8 kod noktası) g olana dek boşluk
static void sola_yasla(const std::string& s, int g)
{
    int uzunluk = 0;
    for (unsigned char c : s) {
        if ((c & 0xC0) != 0x80) {
            uzunluk++;
        }
    }
    std::cout << s << std::string(g > uzunluk ? g - uzunluk : 0, ' ');
}

static void secmeli_sirala(std::vector<int>& a)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        std::size_t en_kucuk = i;
        for (std::size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            std::swap(a[i], a[en_kucuk]);
            takas_sayisi++;
        }
    }
}

static void kabarcik_sirala(std::vector<int>& a)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        bool takas_oldu = false;
        for (std::size_t j = 0; j + 1 < n - i; j++) {
            karsilastirma++;
            if (a[j] > a[j + 1]) {
                std::swap(a[j], a[j + 1]);
                takas_sayisi++;
                takas_oldu = true;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
}

static bool buyuk_mu(int x, int y)
{
    karsilastirma++;
    return x > y;
}

static void araya_ekleme_sirala(std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        int anahtar = a[i];
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0 && buyuk_mu(a[j], anahtar)) {
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

// Ters çevrim sayısı: i < j ve a[i] > a[j] olan çiftler (kaba kuvvet)
static long long ters_cevrim(const std::vector<int>& a)
{
    long long sayi = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        for (std::size_t j = i + 1; j < a.size(); j++) {
            if (a[i] > a[j]) {
                sayi++;
            }
        }
    }
    return sayi;
}

// Soldan sağa yeni en küçük sayısı (a[0] hariç): araya eklemede j = -1
static long long basa_yerlesen(const std::vector<int>& a)
{
    long long sayi = 0;
    for (std::size_t i = 1; i < a.size(); i++) {
        bool en_kucuk_mu = true;
        for (std::size_t k = 0; k < i; k++) {
            if (a[k] <= a[i]) {
                en_kucuk_mu = false;
            }
        }
        sayi += en_kucuk_mu ? 1 : 0;
    }
    return sayi;
}

static std::vector<int> girdi_hazirla(std::size_t n, int tur)
{
    std::vector<int> a(n);
    for (std::size_t i = 0; i < n; i++) {
        a[i] = tur == 2 ? static_cast<int>(n - i)        // 2: ters
                        : static_cast<int>(i + 1);
    }
    if (tur == 0) {                                     // 0: rastgele
        rastgele_tohum(42);
        rastgele_karistir(a);
    }
    return a;
}

static void deney(std::size_t n)
{
    const std::vector<std::string> girdi_adi = {"rastgele", "sıralı",
                                                "ters sıralı"};
    const std::vector<std::string> algo_adi = {"seçmeli", "kabarcık",
                                               "araya ekleme"};
    long long en_cok = static_cast<long long>(n) *
                       static_cast<long long>(n - 1) / 2;

    std::cout << "\nn = " << n << "   n(n-1)/2 = " << en_cok
              << "   n(n-1)/4 = " << std::fixed << std::setprecision(2)
              << static_cast<double>(en_cok) / 2.0 << "\n";
    std::cout << "algoritma     girdi         karşılaştırma  takas  "
                 "kaydırma\n";
    for (int alg = 0; alg < 3; alg++) {
        for (int tur = 0; tur < 3; tur++) {
            std::vector<int> a = girdi_hazirla(n, tur);
            sayaclari_sifirla();
            if (alg == 0) {
                secmeli_sirala(a);
            } else if (alg == 1) {
                kabarcik_sirala(a);
            } else {
                araya_ekleme_sirala(a);
            }
            sola_yasla(algo_adi[alg], 14);
            sola_yasla(girdi_adi[tur], 13);
            std::cout << std::setw(14) << karsilastirma << " "
                      << std::setw(6) << takas_sayisi << " "
                      << std::setw(9) << kaydirma << "\n";
        }
    }
    std::cout << "kuram denetimi (rastgele girdi):\n";
    const std::vector<int> girdi = girdi_hazirla(n, 0);
    long long tc = ters_cevrim(girdi);
    long long z = basa_yerlesen(girdi);
    std::cout << "  ters çevrim = " << tc << "  (beklenen değer n(n-1)/4 = "
              << static_cast<double>(en_cok) / 2.0 << ")\n";
    std::vector<int> a = girdi;
    sayaclari_sifirla();
    kabarcik_sirala(a);
    std::cout << "  kabarcık takas = ters çevrim: "
              << (takas_sayisi == tc ? "evet" : "HAYIR") << "\n";
    a = girdi;
    sayaclari_sifirla();
    araya_ekleme_sirala(a);
    std::cout << "  araya ekleme kaydırma = ters çevrim: "
              << (kaydirma == tc ? "evet" : "HAYIR") << "\n";
    long long beklenen = kaydirma + static_cast<long long>(n - 1) - z;
    std::cout << "  araya ekleme karşılaştırma = kaydırma + (n-1) - z\n";
    std::cout << "    = " << kaydirma << " + " << n - 1 << " - " << z
              << " = " << beklenen << ": "
              << (karsilastirma == beklenen ? "evet" : "HAYIR") << "\n";
}

int main()
{
    std::cout << "Karşılaştırma ve takas/kaydırma sayaçları\n";
    std::cout << "rastgele: 1..n karıştırılmış (ortak LCG, tohum 42)\n";
    std::cout << "z: araya eklemede başa (a[0]'a) yerleşen anahtar sayısı\n";
    deney(100);
    deney(1000);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort()
 * / sorted(). Kütüphane sıralamalarının sayaçları gerçekleştirime bağlıdır.
 */

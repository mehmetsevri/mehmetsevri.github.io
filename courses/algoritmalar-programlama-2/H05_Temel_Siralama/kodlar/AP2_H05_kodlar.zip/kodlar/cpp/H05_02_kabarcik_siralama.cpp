/* H05_02_kabarcik_siralama.cpp — AP-2 Hafta 5 · Örnek 2 (★)
 * Amaç    : Kabarcık sıralaması: komşu takası ve erken çıkış bayrağı;
 *           kaplumbağa (sonda küçük) ve tavşan (başta büyük) elemanlar
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_02_kabarcik_siralama.cpp -o H05_02_kabarcik_siralama
 * Çalıştır: ./H05_02_kabarcik_siralama
 * Eşleri  : c/H05_02_kabarcik_siralama.c
 *           python/H05_02_kabarcik_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

static long long karsilastirma = 0;
static long long takas_sayisi = 0;
static long long gecis_sayisi = 0;

// a'yı yazar; sinir < a.size() ise a[sinir]'dan önce '|' koyar
static void dizi_yaz(const std::vector<int>& a, std::size_t sinir)
{
    for (std::size_t k = 0; k < a.size(); k++) {
        if (k == sinir) {
            std::cout << " |";
        }
        std::cout << std::setw(3) << a[k];
    }
    std::cout << "\n";
}

static void kabarcik_sirala(std::vector<int>& a, bool yazdir)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        bool takas_oldu = false;          // bu geçişte takas var mı?
        long long onceki = takas_sayisi;
        for (std::size_t j = 0; j + 1 < n - i; j++) {
            karsilastirma++;
            if (a[j] > a[j + 1]) {        // komşular ters sırada
                std::swap(a[j], a[j + 1]);
                takas_sayisi++;
                takas_oldu = true;
            }
        }
        gecis_sayisi++;
        if (yazdir) {
            std::cout << "geçiş " << gecis_sayisi << ": karşılaştırma = "
                      << n - 1 - i << ", takas = "
                      << takas_sayisi - onceki << "\n";
            std::cout << "      ";
            dizi_yaz(a, n - 1 - i);
        }
        if (!takas_oldu) {
            break;                        // erken çıkış: dizi sıralı
        }
    }
}

static void calistir(std::vector<int> a, const std::string& ad)
{
    karsilastirma = 0;
    takas_sayisi = 0;
    gecis_sayisi = 0;
    kabarcik_sirala(a, false);
    std::cout << std::setw(5) << gecis_sayisi << " " << std::setw(6)
              << karsilastirma << " " << std::setw(6) << takas_sayisi
              << "   " << ad << "\n";
}

int main()
{
    std::vector<int> a = {42, 17, 8, 31, 25, 4, 39, 12};
    std::size_t n = a.size();

    std::cout << "Kabarcık sıralaması, n = " << n
              << " ('|' sağı: yerine oturanlar)\n";
    std::cout << "başlangıç:\n      ";
    dizi_yaz(a, n);
    kabarcik_sirala(a, true);
    std::cout << "toplam: geçiş = " << gecis_sayisi << ", karşılaştırma = "
              << karsilastirma << ", takas = " << takas_sayisi << "\n";

    std::cout << "\nErken çıkış bayrağının etkisi (n = 8):\n";
    std::cout << "geçiş  karş.  takas   girdi\n";
    calistir({1, 2, 3, 4, 5, 6, 7, 8}, "sıralı");
    calistir({1, 2, 4, 3, 5, 6, 8, 7},
             "neredeyse sıralı (iki komşu takası)");
    calistir({8, 1, 2, 3, 4, 5, 6, 7},
             "tavşan: 8 başta (bir geçişte sona gider)");
    calistir({2, 3, 4, 5, 6, 7, 8, 1},
             "kaplumbağa: 1 sonda (geçiş başına 1 adım)");
    calistir({8, 7, 6, 5, 4, 3, 2, 1}, "ters sıralı (en kötü durum)");
    std::cout << "en fazla: n - 1 = " << 8 - 1 << " geçiş, n(n-1)/2 = "
              << 8 * 7 / 2 << " karşılaştırma\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (kararsız) ve
 * std::stable_sort; Python — list.sort() / sorted() (yalnızca kâhin). */

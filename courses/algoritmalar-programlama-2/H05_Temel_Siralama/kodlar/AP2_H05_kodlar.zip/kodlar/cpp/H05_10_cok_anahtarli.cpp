/* H05_10_cok_anahtarli.cpp — AP-2 Hafta 5 · Örnek 10 (★★★)
 * Amaç    : Çok anahtarlı sıralama (ortalama azalan, soyad artan, ad
 *           artan): tek karşılaştırıcıyla ve kararlı ardışık geçişlerle
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_10_cok_anahtarli.cpp -o H05_10_cok_anahtarli
 * Çalıştır: ./H05_10_cok_anahtarli
 * Eşleri  : c/H05_10_cok_anahtarli.c · python/H05_10_cok_anahtarli.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

struct Ogrenci {
    int no;
    std::string ad;
    std::string soyad;
    double ortalama;
};

using OnceMi = bool (*)(const Ogrenci&, const Ogrenci&);

static long long karsilastirma = 0;

static bool ortalama_azalan(const Ogrenci& x, const Ogrenci& y)
{
    return x.ortalama > y.ortalama;
}

static bool soyad_artan(const Ogrenci& x, const Ogrenci& y)
{
    return x.soyad < y.soyad;
}

static bool ad_artan(const Ogrenci& x, const Ogrenci& y)
{
    return x.ad < y.ad;
}

// Tek karşılaştırıcı: sözlük sırası (önce en önemli anahtar)
static bool cok_anahtarli(const Ogrenci& x, const Ogrenci& y)
{
    if (x.ortalama != y.ortalama) {
        return x.ortalama > y.ortalama;
    }
    if (x.soyad != y.soyad) {
        return x.soyad < y.soyad;
    }
    return x.ad < y.ad;
}

// Kararlı: araya ekleme
static void araya_ekleme_sirala(std::vector<Ogrenci>& a, OnceMi once_mi)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        Ogrenci anahtar = a[i];
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0) {
            karsilastirma++;
            if (!once_mi(anahtar, a[j])) {
                break;
            }
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

// Kararsız: seçmeli (karşılaştırma sayılmaz; yalnızca karşıtlık için)
static void secmeli_sirala(std::vector<Ogrenci>& a, OnceMi once_mi)
{
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        std::size_t en = i;
        for (std::size_t j = i + 1; j < n; j++) {
            if (once_mi(a[j], a[en])) {
                en = j;
            }
        }
        if (en != i) {
            std::swap(a[i], a[en]);
        }
    }
}

// İki dizi aynı kayıt sırasında mı? (no karşılaştırılır)
static bool ayni_sira(const std::vector<Ogrenci>& a,
                      const std::vector<Ogrenci>& b)
{
    for (std::size_t k = 0; k < a.size(); k++) {
        if (a[k].no != b[k].no) {
            return false;
        }
    }
    return true;
}

static void tablo_yaz(const std::vector<Ogrenci>& a)
{
    std::cout << "sıra  ortalama   no  soyad, ad\n";
    for (std::size_t k = 0; k < a.size(); k++) {
        std::cout << std::setw(3) << k + 1 << ".  " << std::fixed
                  << std::setprecision(2) << std::setw(8) << a[k].ortalama
                  << "  " << std::setw(3) << a[k].no << "  " << a[k].soyad
                  << ", " << a[k].ad << "\n";
    }
}

static void no_yaz(const std::string& etiket, const std::vector<Ogrenci>& a)
{
    std::cout << etiket;
    for (const Ogrenci& o : a) {
        std::cout << " " << o.no;
    }
    std::cout << "\n";
}

int main()
{
    const std::vector<Ogrenci> girdi = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };

    // Yöntem A: tek karşılaştırıcı, tek geçiş
    std::vector<Ogrenci> a = girdi;
    karsilastirma = 0;
    araya_ekleme_sirala(a, cok_anahtarli);
    long long karsilastirma_a = karsilastirma;

    // Yöntem B: kararlı ardışık geçişler, en önemsizden en önemliye
    std::vector<Ogrenci> b = girdi;
    karsilastirma = 0;
    araya_ekleme_sirala(b, ad_artan);
    araya_ekleme_sirala(b, soyad_artan);
    araya_ekleme_sirala(b, ortalama_azalan);
    long long karsilastirma_b = karsilastirma;

    // Karşıtlık: aynı ardışık geçişler KARARSIZ sıralamayla
    std::vector<Ogrenci> c = girdi;
    secmeli_sirala(c, ad_artan);
    secmeli_sirala(c, soyad_artan);
    secmeli_sirala(c, ortalama_azalan);

    // Tam karşılaştırıcıyla kararsız sıralama da doğru sonuç verir
    std::vector<Ogrenci> d = girdi;
    secmeli_sirala(d, cok_anahtarli);

    std::cout << "Sıralama ölçütü: ortalama azalan, soyad artan, ad "
                 "artan\n\n";
    std::cout << "A) tek karşılaştırıcı (araya ekleme, 1 geçiş):\n";
    tablo_yaz(a);
    std::cout << "\nB) kararlı ardışık geçişler: ad -> soyad -> ortalama\n";
    no_yaz("   B sırası:", b);
    std::cout << "   A ile aynı mı? " << (ayni_sira(a, b) ? "evet" : "HAYIR")
              << "\n";
    std::cout << "   karşılaştırma: A = " << karsilastirma_a
              << " (1 geçiş), B = " << karsilastirma_b << " (3 geçiş)\n";
    std::cout << "\nC) aynı ardışık geçişler, kararsız seçmeli "
                 "sıralamayla:\n";
    no_yaz("   C sırası:", c);
    std::cout << "   A ile aynı mı? " << (ayni_sira(a, c) ? "evet" : "HAYIR")
              << "\n";
    std::cout << "\nD) tek (tam) karşılaştırıcı, kararsız seçmeli "
                 "sıralamayla:\n";
    no_yaz("   D sırası:", d);
    std::cout << "   A ile aynı mı? " << (ayni_sira(a, d) ? "evet" : "HAYIR")
              << " (tam sıralamada kararlılık gerekmez)\n";
    std::cout << "\nNot: bu verideki ad/soyadlar ilk farklı harfte ASCII; "
                 "Türkçe\nharfte strcmp bayt sırası yanıltır (Hata Avcısı "
                 "8).\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort + cok_anahtarli (void * sarmalayıcı);
 * C++ — std::sort + çok anahtarlı yüklem ya da std::stable_sort
 * geçişleri; Python — sorted(a, key=lambda o: (-o.ortalama, o.soyad,
 * o.ad)). */

/* H05_08_yapi_siralama.cpp — AP-2 Hafta 5 · Örnek 8 (★★)
 * Amaç    : Yapı dizisini ortalamaya göre azalan sıralama: yapı
 *           karşılaştırıcısı + kendi araya ekleme sıralamamız
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_08_yapi_siralama.cpp -o H05_08_yapi_siralama
 * Çalıştır: ./H05_08_yapi_siralama
 * Eşleri  : c/H05_08_yapi_siralama.c · python/H05_08_yapi_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

struct Ogrenci {
    int no;
    std::string ad;
    std::string soyad;
    double ortalama;
};

static long long karsilastirma = 0;

// Araya ekleme: once_mi(anahtar, a[j]) doğru oldukça kaydır (kararlı)
template <class Once>
static void ogrenci_sirala(std::vector<Ogrenci>& a, Once once_mi)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        Ogrenci anahtar = a[i];             // yapı ataması: kopya
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0) {
            karsilastirma++;
            if (!once_mi(anahtar, a[j])) {
                break;
            }
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

// Komşu eşit ortalamalılarda no artıyor mu? (no = kayıt sırası)
static bool kayit_sirasi_korundu(const std::vector<Ogrenci>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1].ortalama == a[k].ortalama && a[k - 1].no > a[k].no) {
            return false;
        }
    }
    return true;
}

static void tablo_yaz(const std::vector<Ogrenci>& a)
{
    std::cout << "sıra  ortalama   no  ad soyad\n";
    for (std::size_t k = 0; k < a.size(); k++) {
        std::cout << std::setw(3) << k + 1 << ".  " << std::fixed
                  << std::setprecision(2) << std::setw(8) << a[k].ortalama
                  << "  " << std::setw(3) << a[k].no << "  " << a[k].ad
                  << " " << a[k].soyad << "\n";
    }
}

int main()
{
    std::vector<Ogrenci> a = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };

    std::cout << "Girdi (kayıt sırası):\n";
    tablo_yaz(a);
    ogrenci_sirala(a, [](const Ogrenci& x, const Ogrenci& y) {
        return x.ortalama > y.ortalama;     // x, y'den önce mi?
    });
    std::cout << "\nOrtalamaya göre azalan (araya ekleme, "
                 "karşılaştırıcıyla):\n";
    tablo_yaz(a);
    std::cout << "karşılaştırma = " << karsilastirma << "\n";
    std::cout << "eşit ortalamalılarda kayıt sırası (no artan) korundu mu? "
              << (kayit_sirasi_korundu(a) ? "evet" : "hayır") << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort(a, n, sizeof a[0], kars_void);
 * C++ — std::stable_sort + lambda; Python — sorted(a, key=…). */

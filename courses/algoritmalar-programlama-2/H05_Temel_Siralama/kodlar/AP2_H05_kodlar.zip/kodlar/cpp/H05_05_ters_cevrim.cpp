/* H05_05_ters_cevrim.cpp — AP-2 Hafta 5 · Örnek 5 (★★)
 * Amaç    : Ters çevrim sayısı (kaba kuvvet, O(n²)) ve araya eklemenin
 *           kaydırma sayısıyla eşitliği; rastgele dizilerde doğrulama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_05_ters_cevrim.cpp -o H05_05_ters_cevrim
 * Çalıştır: ./H05_05_ters_cevrim
 * Eşleri  : c/H05_05_ters_cevrim.c · python/H05_05_ters_cevrim.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

static long long kaydirma = 0;

// Ters çevrim: i < j ve a[i] > a[j] olan (i, j) çiftlerinin sayısı
static long long ters_cevrim_say(const std::vector<int>& a)
{
    long long sayi = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        for (std::size_t j = i + 1; j < a.size(); j++) {
            if (a[i] > a[j]) {
                sayi++;
            }
        }
    }
    return sayi;
}

static void araya_ekleme_sirala(std::vector<int>& a, std::size_t n)
{
    for (std::size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0 && a[j] > anahtar) {
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

static void ciftleri_yaz(const std::vector<int>& a)
{
    int yazilan = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        for (std::size_t j = i + 1; j < a.size(); j++) {
            if (a[i] > a[j]) {
                std::cout << " (" << a[i] << "," << a[j] << ")";
                yazilan++;
                if (yazilan % 8 == 0) {
                    std::cout << "\n";
                }
            }
        }
    }
    if (yazilan % 8 != 0) {
        std::cout << "\n";
    }
}

int main()
{
    std::vector<int> a = {42, 17, 8, 31, 25, 4, 39, 12};
    std::size_t n = a.size();

    std::cout << "1) a = ";
    for (int x : a) {
        std::cout << x << " ";
    }
    std::cout << "\nters çevrim çiftleri (a[i], a[j]), i < j ve "
                 "a[i] > a[j]:\n";
    ciftleri_yaz(a);
    std::cout << "ters çevrim sayısı = " << ters_cevrim_say(a) << "\n";

    std::cout << "\n2) araya eklemede i. anahtarın kaydırması = solundaki "
                 "büyüklerin sayısı\n";
    std::cout << "   i  a[i]  soldaki büyük  kaydırma\n";
    std::vector<int> b = a;
    long long toplam = 0;
    for (std::size_t i = 0; i < n; i++) {
        int soldaki = 0;
        for (std::size_t k = 0; k < i; k++) {
            if (a[k] > a[i]) {
                soldaki++;
            }
        }
        kaydirma = 0;
        araya_ekleme_sirala(b, i + 1);   // b[0..i-1] zaten sıralı
        toplam += kaydirma;
        std::cout << std::setw(4) << i << " " << std::setw(5) << a[i] << " "
                  << std::setw(14) << soldaki << " " << std::setw(9)
                  << kaydirma << "\n";
    }
    std::cout << "toplam kaydırma = " << toplam << "\n";

    std::cout << "\n3) rastgele diziler (değerler 0..999, ortak LCG)\n";
    std::cout << "   n  tohum  ters çevrim   kaydırma  eşit  oran "
                 "(/ n(n-1)/4)\n";
    bool hepsi_esit = true;
    for (std::size_t m : {10, 100, 1000}) {
        for (int tohum = 1; tohum <= 4; tohum++) {
            rastgele_tohum(static_cast<std::uint64_t>(tohum));
            a = rastgele_dizi(m, 0, 999);
            long long tc = ters_cevrim_say(a);
            kaydirma = 0;
            araya_ekleme_sirala(a, m);
            bool esit = tc == kaydirma;
            hepsi_esit = hepsi_esit && esit;
            double beklenen = static_cast<double>(m) *
                              static_cast<double>(m - 1) / 4.0;
            std::string durum = esit ? "evet" : "HAYIR";
            std::cout << std::setw(4) << m << " " << std::setw(6) << tohum
                      << " " << std::setw(12) << tc << " " << std::setw(10)
                      << kaydirma << "  " << durum
                      << std::string(6 - durum.size(), ' ') << std::fixed
                      << std::setprecision(3)
                      << static_cast<double>(tc) / beklenen << "\n";
        }
    }
    std::cout << "tüm denemelerde kaydırma = ters çevrim: "
              << (hepsi_esit ? "evet" : "HAYIR") << "\n";

    std::cout << "\n4) sınırlar (n = 1000):";
    a.assign(1000, 0);
    for (std::size_t k = 0; k < 1000; k++) {
        a[k] = static_cast<int>(k + 1);
    }
    std::cout << " sıralı -> " << ters_cevrim_say(a) << ",";
    for (std::size_t k = 0; k < 1000; k++) {
        a[k] = static_cast<int>(1000 - k);
    }
    std::cout << " ters sıralı -> " << ters_cevrim_say(a)
              << " (n(n-1)/2 = " << 1000 * 999 / 2 << ")\n";
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). O(n log n) sayım:
 * birleştirmeli sıralama sırasında (H6). */

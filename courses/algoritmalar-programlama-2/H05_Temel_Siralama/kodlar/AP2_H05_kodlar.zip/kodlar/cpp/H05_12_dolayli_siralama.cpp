/* H05_12_dolayli_siralama.cpp — AP-2 Hafta 5 · Örnek 12 (★★★)
 * Amaç    : Dolaylı sıralama: büyük kayıtları taşımadan işaretçi/indis
 *           dizisini sıralamak; kopyalanan bayt sayısının karşılaştırması
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_12_dolayli_siralama.cpp -o H05_12_dolayli_siralama
 * Çalıştır: ./H05_12_dolayli_siralama [n=1000]   (süreler stderr'e)
 * Eşleri  : c/H05_12_dolayli_siralama.c
 *           python/H05_12_dolayli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <array>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

struct Kayit {
    int anahtar;
    int no;                          // kayıt sırası: 0, 1, 2, ...
    std::array<char, 248> veri;      // "büyük" yük: ad, adres, notlar ...
};                                   // 4 + 4 + 248 = 256 bayt

static_assert(sizeof(Kayit) == 256, "Kayit 256 bayt olmalı");

static long long kopya = 0;          // öğe kopyası: anahtar + kaydırma

// Doğrudan: kayıtların kendisi kaydırılır (her kopya 256 bayt)
static void kayit_sirala(std::vector<Kayit>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        Kayit anahtar = a[i];
        kopya++;
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0 && a[j].anahtar > anahtar.anahtar) {
            a[j + 1] = a[j];
            kopya++;
            j--;
        }
        a[j + 1] = anahtar;
        kopya++;
    }
}

// Dolaylı: işaretçiler kaydırılır (her kopya 8 bayt); kayıtlar yerinde
static void isaretci_sirala(std::vector<const Kayit*>& p)
{
    for (std::size_t i = 1; i < p.size(); i++) {
        const Kayit* anahtar = p[i];
        kopya++;
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0 && p[j]->anahtar > anahtar->anahtar) {
            p[j + 1] = p[j];
            kopya++;
            j--;
        }
        p[j + 1] = anahtar;
        kopya++;
    }
}

static long arguman_oku(int argc, char* argv[], long varsayilan)
{
    if (argc < 2) {
        return varsayilan;
    }
    std::size_t son = 0;
    long deger = 0;
    try {
        deger = std::stol(argv[1], &son);
    } catch (...) {
        son = 0;
    }
    if (son == 0 || argv[1][son] != '\0' || deger < 1 || deger > 100000) {
        std::cerr << "kullanım: " << argv[0] << " [n: 1..100000]\n";
        std::exit(2);
    }
    return deger;
}

int main(int argc, char* argv[])
{
    std::size_t n = static_cast<std::size_t>(arguman_oku(argc, argv, 1000));
    std::vector<Kayit> kayit(n);
    rastgele_tohum(5);
    for (std::size_t i = 0; i < n; i++) {
        kayit[i].anahtar = rastgele_aralik(0, 99);
        kayit[i].no = static_cast<int>(i);
        std::snprintf(kayit[i].veri.data(), kayit[i].veri.size(),
                      "kayıt %zu", i);
    }
    std::vector<Kayit> dogrudan = kayit;            // vektör kopyası
    std::vector<const Kayit*> p(n);
    for (std::size_t i = 0; i < n; i++) {
        p[i] = &kayit[i];
    }

    kopya = 0;
    double t0 = zaman_sn();
    kayit_sirala(dogrudan);
    double t_dogrudan = zaman_sn() - t0;
    long long kopya_dogrudan = kopya;

    kopya = 0;
    t0 = zaman_sn();
    isaretci_sirala(p);
    std::vector<Kayit> duzenli;
    duzenli.reserve(n);
    for (const Kayit* k : p) {
        duzenli.push_back(*k);                      // bir kez yeniden düzenle
    }
    double t_dolayli = zaman_sn() - t0;
    long long kopya_dolayli = kopya;

    bool ayni = true;
    for (std::size_t i = 0; i < n; i++) {
        if (dogrudan[i].no != duzenli[i].no) {
            ayni = false;
        }
    }
    long long kb = static_cast<long long>(sizeof(Kayit));
    long long ib = static_cast<long long>(sizeof(const Kayit*));
    long long ln = static_cast<long long>(n);
    long long bayt_dogrudan = kopya_dogrudan * kb;
    long long bayt_dolayli = kopya_dolayli * ib;
    long long bayt_duzenleme = ln * kb;

    std::cout << "Dolaylı sıralama: n = " << n << " kayıt, kayıt = " << kb
              << " bayt, işaretçi/indis = " << ib << " bayt\n";
    std::cout << "anahtar 0..99 (yinelenen), ortak LCG tohum 5; araya "
                 "ekleme\n\n";
    std::cout << "yöntem                           öğe kopyası  kopyalanan "
                 "bayt\n";
    std::cout << "doğrudan: kayıtları kaydır      " << std::setw(12)
              << kopya_dogrudan << " " << std::setw(14) << bayt_dogrudan
              << "\n";
    std::cout << "dolaylı: işaretçileri kaydır    " << std::setw(12)
              << kopya_dolayli << " " << std::setw(14) << bayt_dolayli
              << "\n";
    std::cout << "  + bir kez yeniden düzenleme   " << std::setw(12) << n
              << " " << std::setw(14) << bayt_duzenleme << "\n";
    std::cout << "dolaylı toplam                  " << std::setw(12)
              << kopya_dolayli + ln << " " << std::setw(14)
              << bayt_dolayli + bayt_duzenleme << "\n";
    std::cout << "kopyalanan bayt oranı (doğrudan / dolaylı toplam) = "
              << std::fixed << std::setprecision(1)
              << static_cast<double>(bayt_dogrudan) /
                     static_cast<double>(bayt_dolayli + bayt_duzenleme)
              << "\n";
    std::cout << "iki yöntem aynı kayıt sırasını verdi mi? "
              << (ayni ? "evet" : "HAYIR") << "\n";
    std::cout << "ilk 8 (anahtar/no):";
    for (std::size_t i = 0; i < 8 && i < n; i++) {
        std::cout << " " << duzenli[i].anahtar << "/" << duzenli[i].no;
    }
    std::cout << "\n";
    std::cerr << std::fixed << std::setprecision(3)
              << "süre (tek ölçüm): doğrudan " << t_dogrudan * 1e3
              << " ms, dolaylı + düzenleme " << t_dolayli * 1e3 << " ms\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort(p, n, sizeof p[0], kars) işaretçi
 * dizisiyle; C++ — std::sort ile indis/işaretçi vektörü; Python —
 * sorted(range(n), key=lambda i: kayit[i].anahtar). */

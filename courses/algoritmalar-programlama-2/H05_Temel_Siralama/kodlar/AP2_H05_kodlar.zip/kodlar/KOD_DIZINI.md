# Hafta 5 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, çıktı türü, amacı ve derleme durumuyla aşağıdadır. **Ders notu / Sunum / Web** sütunları dosyanın kodunun gösterildiği yerleri verir: ders notu bölümü (Ek A: C++ ve Python karşılıkları), slayt numarası, web sayfasındaki bölüm kimliği; “—” o materyalde kodun gösterilmediğini belirtir (çıktısı ya da sayıları yine kullanılabilir). Web sayfasındaki karşılaştırıcı oynatıcısı kayıtlarını Örnek 10'dan, Türkçe alfabe tablosunu Hata Avcısı 8'in düzeltilmiş sürümünden alır. Ortam: gcc/g++ 13.3 (x86-64 Linux, glibc 2.39), Python 3.11.15 (örnekler 3.10 uyumludur; 3.10, 3.12 ve 3.13 ile de aynı stdout doğrulandı).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`.

Eşdeğerlik: `python3 esdeger_test.py .` → **13/13 GEÇTİ** (tümü “=”), derleyici uyarısı 0, sütun aşımı 0; `--asan` (AddressSanitizer + UBSan) ile 13/13 GEÇTİ.


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Ortak modül | Derleme | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|---|
| `H05_01_secmeli_siralama` | ★ | = | evet | Seçmeli sıralama ve her geçişte dizinin yazdırılması; değişmez: önek sıralı ve en küçükleri içerir | — | sıfır uyarı (3 dil) | 4.1, A.1 | slayt 15, 32 | `#h05-algoritmalar` |
| `H05_02_kabarcik_siralama` | ★ | = | evet | Kabarcık sıralaması (erken çıkış bayraklı): komşu takası; kaplumbağa ve tavşan elemanlar | — | sıfır uyarı (3 dil) | 4.2, A.2 | — | `#h05-algoritmalar` |
| `H05_03_araya_ekleme` | ★ | = | evet | Araya ekleme sıralaması: kaydırarak yerleştirme ve çevrimiçi ekleme | — | sıfır uyarı (3 dil) | 4.3, A.3 | — | `#h05-algoritmalar` |
| `H05_04_sayac_karsilastirma` | ★★ | = | — | Karşılaştırma/takas/kaydırma sayaçlarıyla üç algoritma: rastgele, sıralı, ters sıralı girdi ve kuramsal formüller | ortak_rastgele | sıfır uyarı (3 dil) | A.4 | — | `#h05-algoritmalar` |
| `H05_05_ters_cevrim` | ★★ | = | — | Ters çevrim sayısı (O(n²)) ve araya ekleme kaydırma sayısıyla eşitliği; rastgele dizilerde doğrulama | ortak_rastgele | sıfır uyarı (3 dil) | 3.3, A.5 | — | `#h05-kavramlar` |
| `H05_06_kahin_testi` | ★★ | = | — | “Dizi sıralı mı?” ve kütüphane sıralamasıyla kâhin testi (özel + rastgele diziler; hatalı “sahte” sıralama yakalanır) | ortak_rastgele | sıfır uyarı (3 dil) | 5.1, A.6 | slayt 21, 27 | `#h05-ornekler` |
| `H05_07_qsort_arayuzu` | ★★ | = | — | qsort ile int, double ve dizgi dizisi sıralama; taşmaya güvenli karşılaştırıcı (genel sıralama arayüzü) | — | sıfır uyarı (3 dil) | 3.5, A.7 | slayt 37 | `#h05-karsilastirici` |
| `H05_08_yapi_siralama` | ★★ | = | — | Yapı dizisini ortalamaya göre azalan sıralama: yapı karşılaştırıcısı ve kendi araya ekleme sıralamamız | — | sıfır uyarı (3 dil) | 5.2, A.8 | — | `#h05-karsilastirici` |
| `H05_09_kararlilik` | ★★ | = | — | Kararlılık deneyi: eşit ortalamalı kayıtlarda seçmeli (kararsız), kabarcık ve araya ekleme (kararlı) | — | sıfır uyarı (3 dil) | A.9 | — | `#h05-kavramlar` |
| `H05_10_cok_anahtarli` | ★★★ | = | — | Çok anahtarlı sıralama (ortalama ↓, soyad ↑, ad ↑): tek karşılaştırıcıyla ve kararlı ardışık geçişlerle | — | sıfır uyarı (3 dil) | 3.6, A.10 | slayt 39 | `#h05-karsilastirici` |
| `H05_11_k_sirali` | ★★★ | = | — | k-sıralı (neredeyse sıralı) dizide araya eklemenin O(nk) davranışı | ortak_rastgele | sıfır uyarı (3 dil) | 5.3, A.11 | — | `#h05-ornekler` |
| `H05_12_dolayli_siralama` | ★★★ | = | — | İşaretçi/indis dizisiyle dolaylı sıralama: büyük kayıtları taşımadan sıralama ve kopyalanan bayt karşılaştırması | ortak_rastgele, zamanlayici | sıfır uyarı (3 dil) | 3.7, A.12 | — | `#h05-karsilastirici` |
| `H05_13_shell_siralama` | ★★★ | = | evet | Shell sıralaması ve aralık dizisi deneyi (Shell n/2, Knuth 3h+1, Ciura) — merak | ortak_rastgele | sıfır uyarı (3 dil) | 4.4, A.13 | — | `#h05-algoritmalar` |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`. Beklenen çıktılar: `ciktilar/KÖK.txt` (13 örneğin tümü “=”: üç dilin çıktısı bayt bayt aynı). C++/Python'da öğretilen dil farkı satırları ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`. Örnek 12 isteğe bağlı `n` argümanı alır (varsayılan 1000; süreler stderr'e).

Ortak modüller (90_Ortak_Varliklar/kod_ortak kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`.


## 2. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tanımsız davranış içerenler başlıkta “TANIMSIZ DAVRANIŞ” diye işaretlidir. Gerçek belirtiler (derleme komutu, derleyici iletisi, çıktı, çıkış kodu; ASan/UBSan raporları) `hata_avcisi/ciktilar/` altındadır.

| Dosya | Dil | Tür | Açıklama (başlıktan) | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H05_HA1_secmeli_ic_takas.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: seçmeli sıralamada en küçüğün İNDİSİ tutulmuyor; iç döngüde daha küçük her eleman HEMEN takas ediliyor. Sonuç yine sıralıdır (derleyici de test de sessiz kalır), ama algoritma artık seçmeli değildir: … | `ciktilar/H05_HA1_secmeli_ic_takas.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA1_secmeli_ic_takas_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: iç döngü yalnızca en küçüğün indisini günceller; takas dış döngüde, geçiş başına en fazla bir kez yapılır (en fazla n - 1). | `ciktilar/H05_HA1_secmeli_ic_takas_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA2_kosul_sirasi.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ: araya eklemede koşul "a[j] > anahtar && j >= 0" sırasıyla yazılmış. j = -1 olduğunda önce a[-1] okunur (dizi dışı okuma), sonra j >= 0 denetlenir. Kısa devre burada işe yaramaz: ko… | `ciktilar/H05_HA2_kosul_sirasi_c.txt` | 7 | slayt 45 | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA2_kosul_sirasi.py` | Python | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: koşul "a[j] > anahtar and j >= 0" sırasıyla yazılmış. Python'da a[-1] dizi dışı DEĞİLDİR: listenin SON elemanını okur. Program çökmez, sonuç da doğru çıkabilir; ama her j = -1 anında anlamsız bir karş… | `ciktilar/H05_HA2_kosul_sirasi_py.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA2_kosul_sirasi_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: koruma koşulu önce gelir: "j >= 0 && a[j] > anahtar". j = -1 olduğunda && kısa devre yapar ve a[-1] hiç okunmaz. | `ciktilar/H05_HA2_kosul_sirasi_duzeltilmis_c.txt` | — | slayt 45 | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA2_kosul_sirasi_duzeltilmis.py` | Python | düzeltilmiş | DÜZELTİLMİŞ: "j >= 0 and a[j] > anahtar"; and kısa devre yapar, j = -1 iken a[j] hiç değerlendirilmez. | `ciktilar/H05_HA2_kosul_sirasi_duzeltilmis_py.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA3_fark_karsilastirici.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR — İKİ BÖLÜM DE TANIMSIZ DAVRANIŞ: (1) int karşılaştırıcısı "return x - y;": x = INT_MAX, y = -1 gibi değerlerde fark int'e sığmaz (işaretli taşma: tanımsız davranış); bu derleyicide sonuç işaret değişt… | `ciktilar/H05_HA3_fark_karsilastirici.txt` | 7 | slayt 46 | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA3_fark_karsilastirici_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: iki karşılaştırıcı da (x > y) - (x < y) döndürür: sonuç -1, 0 ya da 1'dir; ne taşma ne kesme olur. | `ciktilar/H05_HA3_fark_karsilastirici_duzeltilmis.txt` | — | slayt 46 | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA4_qsort_oge_boyutu.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ: qsort'a öğe boyutu olarak sizeof(a) verilmiş. a bir İŞARETÇİ olduğundan sizeof(a) = 8 (x86-64), öğe ise int (4 bayt). qsort diziyi 8 baytlık n öğe sanır: ayrılan bölgenin iki katın… | `ciktilar/H05_HA4_qsort_oge_boyutu.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA4_qsort_oge_boyutu_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: öğe boyutu sizeof a[0] (ya da sizeof *a) ile verilir; bu yazım dizinin türü değişse bile doğru kalır. | `ciktilar/H05_HA4_qsort_oge_boyutu_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA5_karsilastirici_imzasi.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ: dizgi dizisi için karşılaştırıcı yanlış imzayla (const char *, const char *) yazılmış ve qsort'a verilmiş. İki ayrı hata: (1) imza: qsort int (*)(const void *, const void *) bekler… | `ciktilar/H05_HA5_karsilastirici_imzasi.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA5_karsilastirici_imzasi_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: imza qsort'un beklediği (const void *, const void *); gelen adres önce "char * öğesinin adresi" (const char *const *) olarak yorumlanır, sonra bir kez çözülerek dizgiye ulaşılır. | `ciktilar/H05_HA5_karsilastirici_imzasi_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA6_qsort_kararlilik.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: qsort'un KARARLI olduğu varsayılmış. Çok anahtarlı sıra (ortalama azalan, eşitse ad artan) iki ardışık qsort geçişiyle kurulmaya çalışılıyor: önce ada, sonra ortalamaya göre. Bu yalnızca ikinci geçiş … | `ciktilar/H05_HA6_qsort_kararlilik.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA6_qsort_kararlilik_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: kararlılığa güvenmek yerine TEK, TAM bir karşılaştırıcı (ortalama azalan, eşitse ad artan). Böylece qsort'un hangi algoritmayı kullandığı önemsizleşir; iki sıralayıcı da aynı doğru sonucu verir. | `ciktilar/H05_HA6_qsort_kararlilik_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA7_kararsiz_gecisler.cpp` | C++ | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: çok anahtarlı sıra (ortalama azalan, eşitse ad artan) iki ardışık std::sort geçişiyle kuruluyor. std::sort KARARSIZDIR: ikinci geçiş, birinci geçişin kurduğu ad sırasını eşit ortalamalılarda bozabilir… | `ciktilar/H05_HA7_kararsiz_gecisler.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA7_kararsiz_gecisler_duzeltilmis.cpp` | C++ | düzeltilmiş | DÜZELTİLMİŞ: ikinci (ve her) geçiş std::stable_sort ile yapılır; eşit ortalamalılar birinci geçişin kurduğu ad sırasını korur. (Başka çözüm: tek geçiş + iki anahtarlı yüklem.) | `ciktilar/H05_HA7_kararsiz_gecisler_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA8_strcmp_turkce.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: Türkçe soyadları strcmp ile sıralanıyor. strcmp BAYT sırasıyla karşılaştırır. UTF-8'de Ç, Ö, Ü (C3 xx), İ (C4 B0) ve Ş (C5 9E) iki baytlıdır ve ilk baytları tüm ASCII harflerinden büyüktür: "Çelik", "… | `ciktilar/H05_HA8_strcmp_turkce.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA8_strcmp_turkce_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ (en küçük çözüm): UTF-8 metinden kod noktaları okunur ve her harf Türkçe alfabedeki sırasına (A B C Ç D E F G Ğ H I İ J K L M N O Ö P R S Ş T U Ü V Y Z) çevrilerek karşılaştırılır; büyük/küçük harf aynı sırayı alır (I/… | `ciktilar/H05_HA8_strcmp_turkce_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA9_sort_none.py` | Python | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: notlar = notlar.sort(). list.sort() listeyi YERİNDE sıralar ve None döndürür; atama listeyi None ile değiştirir. Bir sonraki satır TypeError ile durur (bkz. ciktilar/). | `ciktilar/H05_HA9_sort_none.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA9_sort_none_duzeltilmis.py` | Python | düzeltilmiş | DÜZELTİLMİŞ: ya yerinde sırala ve dönüş değerini kullanma (notlar.sort()), ya da yeni liste üret (sirali = sorted(notlar)). | `ciktilar/H05_HA9_sort_none_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA10_dongu_siniri.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ: kabarcık sıralamasında iç döngü sınırı bir fazla: "j < n - i" (doğrusu "j + 1 < n - i"). İlk geçişte j = n - 1 iken a[j + 1] = a[n] okunur ve gerekirse takasla a[n]'ye YAZILIR (diz… | `ciktilar/H05_HA10_dongu_siniri_c.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA10_dongu_siniri.py` | Python | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: kabarcık sıralamasında iç döngü sınırı bir fazla: range(n - i) (doğrusu range(n - 1 - i)). İlk geçişte j = n - 1 iken a[j + 1] = a[n] istenir: Python IndexError fırlatır (C'de aynı hata sessiz dizi dı… | `ciktilar/H05_HA10_dongu_siniri_py.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA10_dongu_siniri_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: iç döngü "j + 1 < n - i": karşılaştırılan son çift (a[n-2-i], a[n-1-i]) dizinin içindedir. Sınırı a[j + 1]'e bakarak yazın: erişilen en büyük indis j + 1'dir. | `ciktilar/H05_HA10_dongu_siniri_duzeltilmis_c.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA10_dongu_siniri_duzeltilmis.py` | Python | düzeltilmiş | DÜZELTİLMİŞ: range(n - 1 - i); erişilen en büyük indis j + 1 = n - 1 - i. | `ciktilar/H05_HA10_dongu_siniri_duzeltilmis_py.txt` | — | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA11_erken_cikis_bayragi.c` | C | kasıtlı hata | BU DOSYA KASITLI HATA İÇERİR: kabarcık sıralamasında erken çıkış bayrağı YANLIŞ YERDE sıfırlanıyor: geçişin başında değil, iç döngünün her adımında. Böylece bayrak "bu geçişte takas oldu mu?" yerine "SON karşılaştırmada takas oldu… | `ciktilar/H05_HA11_erken_cikis_bayragi.txt` | 7 | — | `#h05-hata-avcisi` |
| `hata_avcisi/H05_HA11_erken_cikis_bayragi_duzeltilmis.c` | C | düzeltilmiş | DÜZELTİLMİŞ: bayrak her GEÇİŞİN başında bir kez sıfırlanır ve iç döngüde yalnızca takas olduğunda 1 yapılır. (Bayrağı hiç sıfırlamamak da hatadır: sonuç doğru olur ama erken çıkış hiç çalışmaz.) | `ciktilar/H05_HA11_erken_cikis_bayragi_duzeltilmis.txt` | — | — | `#h05-hata-avcisi` |

## 3. Haftanın Deneyi (deney/)

| Dosya | Tür | Açıklama |
|---|---|---|
| `deney/c/H05_deney_siralama.c` (+ `ortak_rastgele.h/.c`, `zamanlayici.h/.c`) | deney programı (C) | `ALGORITMA GIRDI N [TEKRAR] [--csv]`; seçmeli, kabarcık, araya ekleme (+ `kutuphane`: qsort başvurusu); sayaçlar stdout, süreler (duvar + işlemci) stderr/CSV; sıfır uyarı |
| `deney/cpp/H05_deney_siralama.cpp` (+ `.hpp`) | deney programı (C++) | aynı arayüz; `kutuphane` = `std::sort` |
| `deney/python/H05_deney_siralama.py` (+ `.py` modüller) | deney programı (Python) | aynı arayüz; `kutuphane` = `list.sort` |
| `deney/olcum_calistir.py` | ölçüm sürücüsü | iki tur, 1 ısınma + 5 tekrar, ortanca; `--devam` ile kaldığı yerden sürer; `sonuclar/h05_deney_olcum.csv` ve `OLCUM_ORTAMI.txt` yazar |
| `deney/kestirim.py` | çözümleme | seçim, oran testi, kestirim, ısı haritası değerleri, kuram tablosu, kütüphane başvurusu, veri özeti |
| `deney/sonuclar/*.csv`, `h05_deney_veri_ozeti.txt` | ham ve türetilmiş veri | `olcum`, `secim`, `oran`, `kestirim`, `isi`, `kuram`, `kutuphane` |
| `deney/OLCUM_ORTAMI.txt` | ölçüm ortamı | işlemci, derleyiciler, yöntem, yük ortalaması, toplam süre |

## 4. Diğer

- `ornekler.json` — örnek üst verisi (başlık, düzey, tür, amiral, farklar, dil_notu); fark satırları kaynak dosyalardan otomatik bulunur.
- `kavram/`, `alistirmalar/`, `quiz/` — Bölüm 5.
- `AP2_H05_kodlar.zip` — bu klasörün tamamı (kaynaklar, ortak modül kopyaları, `ciktilar/`, `deney/sonuclar/`, `hata_avcisi/ciktilar/`, `ornekler.json`, `esdeger_test.py`, bu dizin); derleme ürünleri ve `__pycache__` yoktur (bu hafta stdin girdisi kullanan örnek olmadığından `girdiler/` boştur). Arşivi açıp `kodlar/` içinde `python3 esdeger_test.py .` çalıştırın.

## 5. Kavram, alıştırma ve quiz programları (kavram/, alistirmalar/, quiz/)

Ders notunda, sunumda ya da web sayfasında gösterilen ve merdivende olmayan her kod parçası buradaki küçük, derlenip çalışan programlardandır. Kavram programlarının çıktıları `kavram/ciktilar/` altındadır (ilk satır ortam bilgisi). Alıştırma ve quiz programlarının çıktıları yanıtı verdiği için arşivde yoktur: önce tahmin edin, sonra çalıştırın. Kasıtlı hatalı alıştırmaların başlığında “BU DOSYA KASITLI HATA İÇERİR”, Parsons dosyasında “Tamamlanacak; bu hâliyle derlenmez” yazar. Derleme komutu her dosyanın başlığındadır (kavram programları `-I../c` ile ortak modülleri kullanabilir).

| Dosya | Tür | Amaç | Derleme | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H05_K01_memmove_kaydirma.c` | kavram programı | Araya eklemede kaydırmayı memmove ile BLOK olarak yapmak: önce yeri bul, sonra a[yer..i-1]'i tek çağrıyla bir sağa taşı. Öğe öğe kaydırmayla aynı sonuç ve aynı kaydırma sayısı; süreler stderr'e (tek çalıştırma, bu makinede) | sıfır uyarı | 3.8 | slayt 42 | `#h05-karsilastirici` |
| `kavram/H05_K02_std_tie.cpp` | kavram programı | C++'ta çok anahtarlı karşılaştırıcıyı std::tie ile kurmak: demetler (tuple) sözlük sırasıyla karşılaştırılır; Python'un (-o.ortalama, o.soyad, o.ad) anahtarının karşılığı. Azalan anahtar için x ve y'nin yeri değiştirilir. Kâhin olarak std::stable_sort; sonuç Örnek 10'un A sırasıyla aynıdır. | sıfır uyarı | — | — | `#h05-karsilastirici` |
| `kavram/H05_K03_sayac_araci.c` | kavram programı | İnsan sıralama makinesi atölyesinde elle sayılanları sınamak: komut satırındaki sayıları seçmeli, kabarcık (erken çıkışlı) ve araya ekleme sıralamasıyla sıralar; her geçişten sonra diziyi, sonunda karşılaştırma, takas ve kaydırma sayılarını yazar (sayaç sözleşmesi Örnek 1–3 ile aynı) | sıfır uyarı | — | — | `#h05-alistirmalar` |
| `kavram/H05_K04_neden_siralariz.c` | kavram programı | Sıralamanın açtığı kapılar: sıralı dizide (1) yinelenenleri komşu karşılaştırmayla bulmak, (2) eşitleri gruplayıp saymak, (3) iki sıralı diziyi tek geçişte birleştirmek (H6'ya köprü), (4) ikili aramayla aramak (H4); karşılaştırma sayılarıyla | sıfır uyarı | — | — | `#h05-kavramlar` |
| `alistirmalar/H05_A01_cikti_tahmini.c` | alıştırma | Önce ÇALIŞTIRMADAN programın yazdıracağı her satırı tahmin edin; sonra derleyip karşılaştırın. | sıfır uyarı | Alıştırma 5.2 | — | `#h05-alistirmalar` |
| `alistirmalar/H05_A02_hata_bul_araya.c` | alıştırma | Kasıtlı hata: sonuç anahtara göre sıralıdır, ama araya ekleme sıralamasının bir özelliği kaybolmuştur. Hangisi? Hatalı satırı bulun ve tek karakter değiştirerek düzeltin. | sıfır uyarı | Alıştırma 5.8 | — | `#h05-alistirmalar` |
| `alistirmalar/H05_A03_hata_bul_secmeli.c` | alıştırma | Kasıtlı hata: seçmeli sıralama bazı dizilerde yanlış sonuç veriyor. Çıktıdaki ilk yanlış geçişi bulun, hatalı satırı düzeltin ve değişmezin hangi adımda bozulduğunu açıklayın. | sıfır uyarı | Alıştırma 5.9 | — | `#h05-alistirmalar` |
| `alistirmalar/H05_A04_parsons_kabarcik.c` | alıştırma | Tamamlanacak (derlenmez): Aşağıdaki satırlar erken çıkışlı kabarcık sıralamasının KARIŞTIRILMIŞ satırlarıdır. Doğru sırayı ve girintiyi bulun; kapanış parantezleri ({ }) ayrı satırda verilmiştir. | tamamlanacak (derlenmez) | Alıştırma 5.10 | — | `#h05-alistirmalar` |
| `alistirmalar/H05_A05_reverse_kararlilik.py` | alıştırma | Diller arası okuma. Önce ÇALIŞTIRMADAN üç satırın çıktısını tahmin edin; reverse=True eşitlerin sırasını değiştirir mi? | — | Alıştırma 5.15 | — | `#h05-alistirmalar` |
| `alistirmalar/H05_A06_kopya_siralama.cpp` | alıştırma | Diller arası okuma: "sıralı kopya" alırken özgün dizi ne olur? Python yarısı: H05_A06_kopya_siralama.py | sıfır uyarı | Alıştırma 5.16 | — | `#h05-alistirmalar` |
| `alistirmalar/H05_A06_kopya_siralama.py` | alıştırma | Diller arası okuma: "sıralı kopya" alırken özgün liste ne olur? C++ yarısı: H05_A06_kopya_siralama.cpp | — | Alıştırma 5.16 | — | `#h05-alistirmalar` |
| `alistirmalar/H05_A07_olcut_atolyesi.c` | alıştırma | Karşılaştırıcı atölyesi: aynı 10 kaydı beş ölçüte göre sıralayın. Beş karşılaştırıcıyı TAMAMLAYIN (şimdilik hepsi 0 döndürür: kararlı sıralama girdiyi olduğu gibi bırakır). Sözleşme: kars(x, y) < 0 ise x önce gelir; 0 ise kayıt sırası korunur (araya ekleme kararlıdır). Taşmaya güvenli yazın: (x > y) - (x < y). | sıfır uyarı | — | — | `#h05-alistirmalar` |
| `quiz/H05_Q01_kac_gecis.c` | quiz | Erken çıkışlı kabarcık sıralaması bu girdide kaç geçiş yapar? (Önce tahmin edin, sonra çalıştırın.) | sıfır uyarı | — | — | `#h05-quiz` |
| `quiz/H05_Q02_hangi_sira.c` | quiz | Bu karşılaştırıcıyla qsort hangi sırayı üretir? | sıfır uyarı | — | — | `#h05-quiz` |

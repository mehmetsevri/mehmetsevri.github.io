#!/usr/bin/env python3
"""kestirim.py — AP-2 Hafta 5 · Haftanın Deneyi: çözümleme

Girdi : sonuclar/h05_deney_olcum.csv (olcum_calistir.py; iki tur)
Çıktı : sonuclar/h05_deney_secim.csv     her yapılandırma için seçilen tur
                                         (küçük ortanca) + turlar arası oran
        sonuclar/h05_deney_oran.csv      iki katına çıkarma oranları:
                                         T(2n)/T(n), K(2n)/K(n), log2 eğim
        sonuclar/h05_deney_kestirim.csv  ölçülmeyen n için süre kestirimi:
                                         ana yöntem T(n) = T(n0)·(n/n0)²
                                         (n0 = en büyük ölçülen n); ayrıca
                                         log–log en küçük kareler eğimiyle;
                                         doğrulama ölçümüne göre hata %
        sonuclar/h05_deney_isi.csv       ısı haritası değerleri: algoritma ×
                                         girdi; sayaçlar n = 10 000 ve
                                         süreler (C, C++, Python; Python'da
                                         karesel hücreler kestirim)
        sonuclar/h05_deney_kuram.csv     n = 10 000'de sayaçlar ve kuramsal
                                         değerler
Süre ölçütü: süreç İŞLEMCİ ZAMANI ortancası (islemci_ortanca_ms); makine
paylaşımlı olduğundan duvar saati (ortanca_ms) bekleme süresini de içerir
ve yalnızca veri olarak raporlanır (duvar/işlemci oranı).
Tüm oranlar ve kestirimler bu betikte hesaplanır (elle sayı yazılmaz).
Kullanım (deney/ klasöründe): python3 kestirim.py
"""
import csv
import math
import os

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
ALGOLAR = ["secmeli", "kabarcik", "araya"]
GIRDILER = ["rastgele", "sirali", "ters", "neredeyse"]
KARESEL = {("secmeli", g) for g in GIRDILER} | {
    ("kabarcik", "rastgele"), ("kabarcik", "ters"),
    ("araya", "rastgele"), ("araya", "ters")}
ISI_N = 10000
ZAMAN = "islemci_ortanca_ms"


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def yaz(ad, alanlar, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join(_bicim(s[a]) for a in alanlar) + "\n")


def _bicim(x):
    if isinstance(x, float):
        return f"{x:.6g}" if abs(x) < 1e-3 or abs(x) >= 1e7 else f"{x:.6f}"
    return "" if x is None else str(x)


def secim_yap(olcum):
    """(dil, derleme, alg, girdi, n, tur) başına küçük ortancalı tur."""
    gruplar = {}
    for s in olcum:
        anahtar = (s["dil"], s["derleme"], s["algoritma"], s["girdi"],
                   int(s["n"]), s["tur"])
        gruplar.setdefault(anahtar, []).append(s)
    secilen = {}
    for anahtar, ss in gruplar.items():
        ss.sort(key=lambda s: float(s[ZAMAN]))
        en_iyi = dict(ss[0])
        en_iyi["tur_orani"] = (float(ss[-1][ZAMAN]) /
                               max(float(ss[0][ZAMAN]), 1e-12))
        en_iyi["tur_sayisi"] = len(ss)
        en_iyi["duvar_islemci_orani"] = (float(ss[0]["ortanca_ms"]) /
                                         max(float(ss[0][ZAMAN]), 1e-12))
        secilen[anahtar] = en_iyi
    return secilen


def main():
    olcum = oku("h05_deney_olcum.csv")
    secilen = secim_yap(olcum)
    alanlar = ["n", "dil", "derleme", "algoritma", "girdi", "tur",
               "tur_no", "karsilastirma", "takas", "kaydirma", "yazma",
               "tekrar", "deneme", "ortanca_ms", "en_az_ms", "en_cok_ms",
               "islemci_ortanca_ms", "islemci_en_az_ms", "islemci_en_cok_ms",
               "tur_sayisi", "tur_orani", "duvar_islemci_orani"]
    yaz("h05_deney_secim.csv", alanlar,
        [secilen[k] for k in sorted(secilen, key=lambda k: (
            k[0], k[1], ALGOLAR.index(k[2]) if k[2] in ALGOLAR else 9,
            GIRDILER.index(k[3]), k[4]))])

    # Sayaçlar diller arasında aynı mı? (aynı alg, girdi, n)
    sayac = {}
    farkli = 0
    for (dil, der, alg, girdi, n, tur), s in secilen.items():
        if alg == "kutuphane":
            continue
        k = (alg, girdi, n)
        deger = (s["karsilastirma"], s["takas"], s["kaydirma"], s["yazma"])
        if k in sayac and sayac[k] != deger:
            farkli += 1
        sayac[k] = deger
    print(f"diller arası sayaç farkı: {farkli} (0 olmalı); "
          f"{len(sayac)} farklı (algoritma, girdi, n)")

    # İki katına çıkarma oranları (yalnız "olcum" turu)
    oranlar = []
    seriler = {}
    for (dil, der, alg, girdi, n, tur), s in secilen.items():
        if tur == "olcum":
            seriler.setdefault((dil, der, alg, girdi), {})[n] = s
    for (dil, der, alg, girdi), d in sorted(seriler.items()):
        for n in sorted(d):
            if 2 * n in d:
                t1 = float(d[n][ZAMAN])
                t2 = float(d[2 * n][ZAMAN])
                k1 = int(d[n]["karsilastirma"])
                k2 = int(d[2 * n]["karsilastirma"])
                oranlar.append({
                    "dil": dil, "derleme": der, "algoritma": alg,
                    "girdi": girdi, "n": n, "n2": 2 * n,
                    "sure_orani": t2 / t1,
                    "egim_b": math.log2(t2 / t1),
                    "karsilastirma_orani": k2 / k1 if k1 > 0 else None,
                    "karesel": "evet" if (alg, girdi) in KARESEL
                    else "hayır",
                    "ortanca1_ms": t1})
    yaz("h05_deney_oran.csv", ["dil", "derleme", "algoritma", "girdi", "n",
                               "n2", "sure_orani", "egim_b",
                               "karsilastirma_orani", "karesel",
                               "ortanca1_ms"], oranlar)

    # Kestirim (ölçülmeyen n): ana yöntem kuramdır — karesel durumlarda
    # karşılaştırma sayısı Θ(n²) olduğundan T(n) = T(n0)·(n/n0)², n0 = en
    # büyük ölçülen n. Karşılaştırma için tüm ölçüm noktalarından log–log
    # en küçük kareler eğimi b̂ ile de kestirilir (T = c·n^b̂).
    def egim_uydur(d):
        xs = [math.log(n) for n in sorted(d)]
        ys = [math.log(float(d[n][ZAMAN])) for n in sorted(d)]
        ox, oy = sum(xs) / len(xs), sum(ys) / len(ys)
        b = (sum((x - ox) * (y - oy) for x, y in zip(xs, ys)) /
             sum((x - ox) ** 2 for x in xs))
        return b, math.exp(oy - b * ox)

    kestirim = []
    hedefler = [("Python", "-", ISI_N), ("Python", "-", 4000),
                ("C", "-O2", 40000), ("C", "-O2", 100000),
                ("C", "-O2", 1000000), ("C++", "-O2", 1000000),
                ("Python", "-", 1000000)]
    for dil, der, n in hedefler:
        for alg, girdi in sorted(KARESEL):
            d = seriler.get((dil, der, alg, girdi))
            if d is None:
                continue
            n0 = max(d)
            if n <= n0:
                continue
            t0 = float(d[n0][ZAMAN])
            tahmin = t0 * (n / n0) ** 2
            b_uy, c_uy = egim_uydur(d)
            tahmin_uy = c_uy * n ** b_uy
            olculen = secilen.get((dil, der, alg, girdi, n, "dogrulama"))
            hata = hata_uy = None
            if olculen is not None:
                o = float(olculen[ZAMAN])
                hata = 100.0 * (tahmin - o) / o
                hata_uy = 100.0 * (tahmin_uy - o) / o
            kestirim.append({
                "dil": dil, "derleme": der, "algoritma": alg,
                "girdi": girdi, "n": n, "taban_n": n0, "taban_ms": t0,
                "kestirim_ms": tahmin, "egim_uydurma": b_uy,
                "kestirim_uydurma_ms": tahmin_uy,
                "olculen_ms": float(olculen[ZAMAN]) if olculen else None,
                "hata_yuzde": hata, "hata_uydurma_yuzde": hata_uy,
                "tur": "kestirim"})
    yaz("h05_deney_kestirim.csv", ["dil", "derleme", "algoritma", "girdi",
                                   "n", "taban_n", "taban_ms", "kestirim_ms",
                                   "egim_uydurma", "kestirim_uydurma_ms",
                                   "olculen_ms", "hata_yuzde",
                                   "hata_uydurma_yuzde", "tur"], kestirim)

    # Isı haritası değerleri (n = 10 000)
    isi = []
    for alg in ALGOLAR:
        for girdi in GIRDILER:
            satir = {"algoritma": alg, "girdi": girdi, "n": ISI_N}
            c = secilen[("C", "-O2", alg, girdi, ISI_N, "olcum")]
            for alan in ("karsilastirma", "takas", "kaydirma", "yazma"):
                satir[alan] = int(c[alan])
            for dil, der, ad in (("C", "-O2", "c"), ("C++", "-O2", "cpp"),
                                 ("Python", "-", "py")):
                s = secilen.get((dil, der, alg, girdi, ISI_N, "olcum"))
                if s is not None:
                    satir[f"{ad}_ms"] = float(s[ZAMAN])
                    satir[f"{ad}_duvar_ms"] = float(s["ortanca_ms"])
                    satir[f"{ad}_tur"] = "olcum"
                else:
                    k = next(x for x in kestirim if x["dil"] == dil and
                             x["algoritma"] == alg and x["girdi"] == girdi
                             and x["n"] == ISI_N)
                    satir[f"{ad}_ms"] = k["kestirim_ms"]
                    satir[f"{ad}_duvar_ms"] = None
                    satir[f"{ad}_tur"] = "kestirim"
            isi.append(satir)
    yaz("h05_deney_isi.csv", ["algoritma", "girdi", "n", "karsilastirma",
                              "takas", "kaydirma", "yazma", "c_ms", "c_tur",
                              "c_duvar_ms", "cpp_ms", "cpp_tur",
                              "cpp_duvar_ms", "py_ms", "py_tur",
                              "py_duvar_ms"], isi)

    # Kütüphane başvurusu (yalnız süre)
    kut = []
    for (dil, der, alg, girdi, n, tur), s in sorted(secilen.items()):
        if alg == "kutuphane":
            kut.append({"dil": dil, "derleme": der, "n": n,
                        "islemci_ms": float(s[ZAMAN]),
                        "duvar_ms": float(s["ortanca_ms"])})
    yaz("h05_deney_kutuphane.csv", ["dil", "derleme", "n", "islemci_ms",
                                    "duvar_ms"], kut)

    # Kuramsal değerler (n = 10 000)
    n = ISI_N
    kuram = []
    ters_cevrim = int(secilen[("C", "-O2", "araya", "rastgele", n,
                               "olcum")]["kaydirma"])
    ters_cevrim_nk = int(secilen[("C", "-O2", "araya", "neredeyse", n,
                                  "olcum")]["kaydirma"])
    formuller = {
        ("secmeli", "karsilastirma"): ("n(n-1)/2", n * (n - 1) // 2),
        ("kabarcik", "sirali"): ("n-1", n - 1),
        ("kabarcik", "ters"): ("n(n-1)/2", n * (n - 1) // 2),
        ("araya", "sirali"): ("n-1", n - 1),
        ("araya", "ters"): ("n(n-1)/2", n * (n - 1) // 2),
    }
    for satir in isi:
        alg, girdi = satir["algoritma"], satir["girdi"]
        if alg == "secmeli":
            ad, deger = formuller[("secmeli", "karsilastirma")]
        elif (alg, girdi) in formuller:
            ad, deger = formuller[(alg, girdi)]
        else:
            ad, deger = "", None
        hareket = satir["takas"] if alg != "araya" else satir["kaydirma"]
        tc = {"rastgele": ters_cevrim, "sirali": 0,
              "ters": n * (n - 1) // 2, "neredeyse": ters_cevrim_nk}[girdi]
        kuram.append({
            "algoritma": alg, "girdi": girdi, "n": n,
            "karsilastirma": satir["karsilastirma"],
            "kuramsal_formul": ad, "kuramsal_karsilastirma": deger,
            "ters_cevrim": tc, "takas_veya_kaydirma": hareket,
            "hareket_eq_ters_cevrim": "—" if alg == "secmeli" else
            ("evet" if hareket == tc else "HAYIR"),
            "beklenen_ters_cevrim_rastgele": n * (n - 1) / 4})
    yaz("h05_deney_kuram.csv", ["algoritma", "girdi", "n", "karsilastirma",
                                "kuramsal_formul", "kuramsal_karsilastirma",
                                "ters_cevrim", "takas_veya_kaydirma",
                                "hareket_eq_ters_cevrim",
                                "beklenen_ters_cevrim_rastgele"], kuram)
    # Ham veri özeti (gürültü ve yineleme bilgisi; sonuclar/ altına)
    from collections import Counter
    sayim = Counter((s["tur_no"], s["dil"], s["derleme"], s["algoritma"],
                     s["girdi"], s["n"], s["tur"]) for s in olcum)
    yapilandirma = Counter(k[1:] for k in sayim)
    olcu_sayisi = Counter(yapilandirma.values())
    oranlar_dv = sorted(float(s["duvar_islemci_orani"])
                        for s in secilen.values()
                        if float(s[ZAMAN]) >= 1.0)
    aykiri = [o for o in oranlar if o["karesel"] == "evet" and
              not 3.5 <= o["sure_orani"] <= 4.5]
    with open(os.path.join(SONUC, "h05_deney_veri_ozeti.txt"), "w",
              encoding="utf-8") as f:
        f.write(f"ham satır: {len(olcum)}; farklı (tur_no, yapılandırma): "
                f"{len(sayim)}; aynı anahtarla birden çok satır: "
                f"{sum(1 for v in sayim.values() if v > 1)}\n")
        f.write(f"seçilen yapılandırma: {len(secilen)} (her biri için "
                "işlemci ortancası en küçük satır)\n")
        f.write("yapılandırma başına tur sayısı dağılımı: "
                + ", ".join(f"{k} tur: {v}" for k, v in
                            sorted(olcu_sayisi.items())) + "\n")
        if oranlar_dv:
            orta = oranlar_dv[len(oranlar_dv) // 2]
            f.write(f"duvar/işlemci oranı (>= 1 ms ölçümler): ortanca "
                    f"{orta:.2f}, aralık {oranlar_dv[0]:.2f}–"
                    f"{oranlar_dv[-1]:.2f}\n")
        f.write(f"karesel durumlarda oran testi 3,5–4,5 dışında kalan "
                f"ikiye katlama: {len(aykiri)} / "
                f"{sum(1 for o in oranlar if o['karesel'] == 'evet')}\n")
        for o in aykiri:
            f.write(f"  {o['dil']} {o['derleme']} {o['algoritma']} "
                    f"{o['girdi']} {o['n']}->{o['n2']}: "
                    f"{o['sure_orani']:.2f}\n")
        f.write(f"diller arası sayaç farkı: {farkli}\n")
    print("yazıldı: h05_deney_secim/oran/kestirim/isi/kuram/kutuphane.csv, "
          "h05_deney_veri_ozeti.txt")


if __name__ == "__main__":
    main()

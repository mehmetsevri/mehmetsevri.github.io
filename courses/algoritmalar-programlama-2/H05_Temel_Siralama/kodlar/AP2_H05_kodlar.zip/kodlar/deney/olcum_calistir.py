#!/usr/bin/env python3
"""olcum_calistir.py — AP-2 Hafta 5 · Haftanın Deneyi: ölçüm sürücüsü

Seçmeli, kabarcık ve araya ekleme sıralamasını dört girdi türünde
(rastgele, sıralı, ters sıralı, neredeyse sıralı) üç dilde ölçer; ham
sonuçları sonuclar/h05_deney_olcum.csv, makine bilgisini OLCUM_ORTAMI.txt
dosyasına yazar.

Düzen (AP-2 Ajan Rehberi, Bölüm 3):
  * C ve C++ -O2; karşılaştırma için C ayrıca -O0 (yalnız n = 5000).
  * Her ölçüm: 1 ısınma + 5 tekrar, ORTANCA. Girdinin kopyalanması
    ölçüme girmez (her tekrar öncesi kopya, sonra saat).
  * Süre iki saatle ölçülür: duvar saati ve süreç İŞLEMCİ ZAMANI. Makine
    paylaşımlı olduğundan (başka ajanların deneyleri de çalışıyor) duvar
    saati bekleme süresini de içerir; çözümlemede işlemci zamanı esas
    alınır, duvar saati veri olarak raporlanır.
  * Tutarsız ölçüm (işlemci zamanında en_cok / en_az > 1,5 ve ortanca
    > 2 ms) en çok iki kez
    yinelenir; yayılımı en küçük deneme tutulur, deneme sayısı yazılır.
  * Makinede başka süreçler (ajanlar) çalıştığından tüm plan İKİ TUR
    ölçülür (2. tur ters sırada); iki tur da CSV'ye yazılır (tur_no).
    Çözümleme (kestirim.py) her yapılandırma için ortancası küçük olan
    turu ("daha az bozulmuş") kullanır ve turlar arası farkı raporlar.
  * Karesel (Θ(n²)) durumlar: C n <= 20 000, C++ n <= 10 000, Python
    n <= 2 000. Doğrusal durumlar (kabarcık/araya ekleme × sıralı/
    neredeyse sıralı) daha büyük n'lerde de ölçülür.
  * Başvuru noktası: kütüphane sıralaması (qsort, std::sort, list.sort)
    rastgele girdide n = 10 000 ve 1 000 000 (yalnız süre; sayaç yok).
  * Kestirim yöntemini sınamak için "dogrulama" ölçümleri (tek tekrar):
    C seçmeli/rastgele n = 40 000; Python seçmeli ve araya ekleme/rastgele
    n = 4 000.
Kullanım (deney/ klasöründe):  python3 olcum_calistir.py [--devam]
  Her ölçüm satırı hemen CSV'ye eklenir; --devam ile yarıda kalan bir
  çalıştırma, CSV'deki satırlar atlanarak kaldığı yerden sürdürülür.
Toplam süre bu makinede yaklaşık 3–4 dakikadır.
"""
import datetime
import os
import platform
import subprocess
import sys
import tempfile

KOK = os.path.dirname(os.path.realpath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C_DERLE = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP_DERLE = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]

KARESEL = [("secmeli", "rastgele"), ("secmeli", "sirali"),
           ("secmeli", "ters"), ("secmeli", "neredeyse"),
           ("kabarcik", "rastgele"), ("kabarcik", "ters"),
           ("araya", "rastgele"), ("araya", "ters")]
DOGRUSAL = [("kabarcik", "sirali"), ("kabarcik", "neredeyse"),
            ("araya", "sirali"), ("araya", "neredeyse")]


def derle(gecici):
    """İkilileri derler; {(dil, derleme): komut önü} döndürür."""
    c = os.path.join(KOK, "c")
    ikili = {}
    for bayrak in ("-O2", "-O0"):
        hedef = os.path.join(gecici, f"deney_c{bayrak}")
        kaynak = [os.path.join(c, "H05_deney_siralama.c"),
                  os.path.join(c, "ortak_rastgele.c"),
                  os.path.join(c, "zamanlayici.c")]
        subprocess.run(C_DERLE + [bayrak] + kaynak + ["-o", hedef],
                       check=True)
        ikili[("C", bayrak)] = [hedef]
    hedef = os.path.join(gecici, "deney_cpp")
    subprocess.run(CPP_DERLE + ["-O2", os.path.join(
        KOK, "cpp", "H05_deney_siralama.cpp"), "-o", hedef], check=True)
    ikili[("C++", "-O2")] = [hedef]
    ikili[("Python", "-")] = [sys.executable, os.path.join(
        KOK, "python", "H05_deney_siralama.py")]
    return ikili


def olc(komut, alg, girdi, n, tekrar):
    p = subprocess.run(komut + [alg, girdi, str(n), str(tekrar), "--csv"],
                       capture_output=True, text=True, check=True)
    a = p.stdout.strip().split(";")
    return {"algoritma": a[0], "girdi": a[1], "n": int(a[2]),
            "karsilastirma": int(a[3]), "takas": int(a[4]),
            "kaydirma": int(a[5]), "yazma": int(a[6]), "tekrar": int(a[7]),
            "ortanca_ms": float(a[8]), "en_az_ms": float(a[9]),
            "en_cok_ms": float(a[10]), "islemci_ortanca_ms": float(a[11]),
            "islemci_en_az_ms": float(a[12]),
            "islemci_en_cok_ms": float(a[13])}


def olc_tutarli(komut, alg, girdi, n, tekrar):
    en_iyi, deneme = None, 0
    for deneme in range(1, 4):
        s = olc(komut, alg, girdi, n, tekrar)
        yayilim = s["islemci_en_cok_ms"] / max(s["islemci_en_az_ms"], 1e-9)
        if en_iyi is None or yayilim < en_iyi[0]:
            en_iyi = (yayilim, s)
        if yayilim <= 1.5 or s["islemci_ortanca_ms"] <= 2.0 or tekrar == 1:
            break
    sonuc = dict(en_iyi[1])
    sonuc["deneme"] = deneme
    return sonuc


def plan():
    """(dil, derleme, algoritma, girdi, n, tekrar, tur) listesi"""
    p = []
    seriler = [
        ("C", "-O2", [1250, 2500, 5000, 10000, 20000],
         [1250, 2500, 5000, 10000, 20000, 100000, 1000000]),
        ("C++", "-O2", [1250, 2500, 5000, 10000],
         [1250, 2500, 5000, 10000, 100000, 1000000]),
        ("Python", "-", [250, 500, 1000, 2000],
         [250, 500, 1000, 2000, 10000, 100000]),
    ]
    for dil, der, nq, nl in seriler:
        for alg, girdi in KARESEL:
            for n in nq:
                p.append((dil, der, alg, girdi, n, 5, "olcum"))
        for alg, girdi in DOGRUSAL:
            for n in nl:
                p.append((dil, der, alg, girdi, n, 5, "olcum"))
    for alg, girdi in KARESEL + DOGRUSAL:
        p.append(("C", "-O0", alg, girdi, 5000, 5, "olcum"))
    for dil, der in (("C", "-O2"), ("C++", "-O2"), ("Python", "-")):
        for n in (10000, 1000000):            # başvuru: kütüphane sıralaması
            p.append((dil, der, "kutuphane", "rastgele", n, 5, "kutuphane"))
    p.append(("C", "-O2", "secmeli", "rastgele", 40000, 1, "dogrulama"))
    p.append(("Python", "-", "secmeli", "rastgele", 4000, 1, "dogrulama"))
    p.append(("Python", "-", "araya", "rastgele", 4000, 1, "dogrulama"))
    return p


def ortam_yaz(sure_sn, yuk, onceki=0):
    def ilk(komut):
        try:
            return subprocess.run(komut, capture_output=True, text=True
                                  ).stdout.strip().splitlines()[0]
        except (OSError, IndexError):
            return "?"
    model = "?"
    for satir in subprocess.run(["lscpu"], capture_output=True, text=True
                                ).stdout.splitlines():
        if satir.startswith("Model name:"):
            model = satir.split(":", 1)[1].strip()
    metin = (
        "AP-2 Hafta 5 · Haftanın Deneyi — ölçüm ortamı\n"
        f"Tarih          : {datetime.date.today().isoformat()}\n"
        f"İşlemci        : {model}\n"
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine; aynı anda başka "
        "ajanların deneyleri de çalışıyordu)\n"
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})\n"
        f"C derleyicisi  : {ilk(['gcc', '--version'])}\n"
        f"C++ derleyicisi: {ilk(['g++', '--version'])}\n"
        f"Python         : {ilk([sys.executable, '--version'])}\n"
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra "
        "-pedantic -O2 (C ayrıca -O0, n = 5000)\n"
        "Yöntem         : 1 ısınma + 5 tekrar, ortanca (doğrulama: 1 "
        "tekrar); en_cok/en_az > 1,5 ise en çok 2 kez yineleme;\n"
        "                 girdinin kopyalanması ölçüme girmez; sayaçlar "
        "ölçülen kodun içindedir\n"
        "Girdiler       : rastgele = 1..n karıştırılmış (ortak LCG, tohum "
        "42); sıralı = 1..n;\n"
        "                 ters = n..1; neredeyse = 1..n, 11'lik bloklar "
        "içinde karıştırılmış (k = 10)\n"
        "Saat           : duvar: C timespec_get, C++ steady_clock, Python "
        "time.perf_counter;\n"
        "                 işlemci (esas ölçüt): C/C++ clock(), Python "
        "time.process_time\n"
        "Tekrar turu    : tüm plan 2 tur (2. tur ters sırada); "
        "çözümlemede her yapılandırmanın küçük ortancalı turu\n"
        f"Yük ortalaması : başta {yuk[0]:.2f}, sonda {yuk[1]:.2f} "
        "(1 dk; 2 çekirdek)\n"
        f"Toplam deney süresi: {sure_sn:.1f} s"
        + (f" (son bölüm; önceki bölüm(ler)den {onceki} satır --devam ile "
           "birleştirildi)" if onceki else "") + "\n")
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)
    print(metin)


ALANLAR = ["n", "dil", "derleme", "algoritma", "girdi", "tur", "tur_no",
           "karsilastirma", "takas", "kaydirma", "yazma", "tekrar",
           "deneme", "ortanca_ms", "en_az_ms", "en_cok_ms",
           "islemci_ortanca_ms", "islemci_en_az_ms", "islemci_en_cok_ms"]


def anahtar(tur_no, dil, der, alg, girdi, n, tur):
    return (str(tur_no), dil, der, alg, girdi, str(n), tur)


def main():
    os.makedirs(SONUC, exist_ok=True)
    yol = os.path.join(SONUC, "h05_deney_olcum.csv")
    yapilan = set()
    if "--devam" in sys.argv and os.path.exists(yol):
        with open(yol, encoding="utf-8") as f:
            for satir in list(f)[1:]:
                a = dict(zip(ALANLAR, satir.rstrip("\n").split(";")))
                yapilan.add(anahtar(a["tur_no"], a["dil"], a["derleme"],
                                    a["algoritma"], a["girdi"], a["n"],
                                    a["tur"]))
    else:
        with open(yol, "w", encoding="utf-8") as f:
            f.write(";".join(ALANLAR) + "\n")
    baslangic = datetime.datetime.now()
    yuk_bas = os.getloadavg()[0]
    with tempfile.TemporaryDirectory(prefix="h05olc_") as gecici:
        ikili = derle(gecici)
        p = plan()
        for tur_no, sira in ((1, p), (2, p[::-1])):
            for dil, der, alg, girdi, n, tekrar, tur in sira:
                if anahtar(tur_no, dil, der, alg, girdi, n,
                           tur) in yapilan:
                    continue
                s = olc_tutarli(ikili[(dil, der)], alg, girdi, n, tekrar)
                s.update(dil=dil, derleme=der, tur=tur, tur_no=tur_no)
                with open(yol, "a", encoding="utf-8") as f:
                    f.write(";".join(f"{s[a]:.6f}" if isinstance(s[a], float)
                                     else str(s[a]) for a in ALANLAR)
                            + "\n")
                print(f"{tur_no} {dil:<6} {der:<3} {alg:<9} {girdi:<9} "
                      f"n={n:>7} karş={s['karsilastirma']:>11} "
                      f"duvar={s['ortanca_ms']:11.4f} ms "
                      f"işlemci={s['islemci_ortanca_ms']:11.4f} ms "
                      f"[{s['islemci_en_az_ms']:.4f} … "
                      f"{s['islemci_en_cok_ms']:.4f}] "
                      f"deneme={s['deneme']}", flush=True)
    ortam_yaz((datetime.datetime.now() - baslangic).total_seconds(),
              (yuk_bas, os.getloadavg()[0]), len(yapilan))


if __name__ == "__main__":
    main()

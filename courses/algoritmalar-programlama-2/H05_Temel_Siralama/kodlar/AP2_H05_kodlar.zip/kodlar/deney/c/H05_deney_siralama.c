/* H05_deney_siralama.c — AP-2 Hafta 5 · Haftanın Deneyi (C)
 * Amaç    : Seçmeli, kabarcık (erken çıkışlı) ve araya ekleme
 *           sıralamasının rastgele / sıralı / ters sıralı / neredeyse
 *           sıralı girdide karşılaştırma, takas, kaydırma, yazma sayıları
 *           ve süreleri (1 ısınma + tekrar, ortanca)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_deney_siralama.c ortak_rastgele.c zamanlayici.c \
 *           -o H05_deney_siralama
 * Çalıştır: ./H05_deney_siralama ALGORITMA GIRDI N [TEKRAR] [--csv]
 *           ALGORITMA: secmeli | kabarcik | araya | kutuphane (qsort;
 *           yalnızca süre karşılaştırması için, sayaçlar -1 = sayılmadı)
 *           GIRDI    : rastgele | sirali | ters | neredeyse
 * Çıktı   : sayaçlar stdout'a; süreler stderr'e (--csv: tek CSV satırı)
 * Süre    : duvar saati (zaman_sn) ve süreç işlemci zamanı (islemci_sn)
 *           birlikte ölçülür; paylaşımlı makinede işlemci zamanı daha
 *           kararlıdır (bekleme süresini içermez)
 * Girdi   : rastgele = 1..N karıştırılmış (ortak LCG, tohum 42);
 *           neredeyse = 1..N, 11'lik bloklar içinde karıştırılmış (her
 *           eleman sıralı yerinden en fazla 10 uzakta), tohum 42
 * Yazma   : diziye yapılan öğe yazımı: takas = 2 yazma; araya eklemede
 *           kaydırma + anahtarın yerine konması (n - 1)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

typedef struct {
    long long karsilastirma;
    long long takas;
    long long kaydirma;
    long long yazma;
} Sayac;

static void secmeli_sirala(int *a, size_t n, Sayac *s)
{
    long long kars = 0, tk = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en_kucuk = i;
        for (size_t j = i + 1; j < n; j++) {
            kars++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            int gecici = a[i];
            a[i] = a[en_kucuk];
            a[en_kucuk] = gecici;
            tk++;
        }
    }
    s->karsilastirma = kars;
    s->takas = tk;
    s->kaydirma = 0;
    s->yazma = 2 * tk;
}

static void kabarcik_sirala(int *a, size_t n, Sayac *s)
{
    long long kars = 0, tk = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;
        for (size_t j = 0; j + 1 < n - i; j++) {
            kars++;
            if (a[j] > a[j + 1]) {
                int gecici = a[j];
                a[j] = a[j + 1];
                a[j + 1] = gecici;
                tk++;
                takas_oldu = 1;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
    s->karsilastirma = kars;
    s->takas = tk;
    s->kaydirma = 0;
    s->yazma = 2 * tk;
}

static void araya_ekleme_sirala(int *a, size_t n, Sayac *s)
{
    long long kars = 0, kayd = 0;
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0) {
            kars++;
            if (a[j] <= anahtar) {
                break;
            }
            a[j + 1] = a[j];
            kayd++;
            j--;
        }
        a[j + 1] = anahtar;
    }
    s->karsilastirma = kars;
    s->takas = 0;
    s->kaydirma = kayd;
    s->yazma = kayd + (n > 0 ? (long long)n - 1 : 0);
}

static int int_artan(const void *p, const void *q)
{
    int x = *(const int *)p;
    int y = *(const int *)q;
    return (x > y) - (x < y);
}

/* Başvuru noktası: kütüphane sıralaması (algoritması belirtilmez) */
static void kutuphane_sirala(int *a, size_t n, Sayac *s)
{
    qsort(a, n, sizeof a[0], int_artan);
    s->karsilastirma = s->takas = s->kaydirma = s->yazma = -1;
}

static void girdi_uret(int *a, size_t n, const char *tur)
{
    for (size_t i = 0; i < n; i++) {
        a[i] = strcmp(tur, "ters") == 0 ? (int)(n - i) : (int)(i + 1);
    }
    rastgele_tohum(42);
    if (strcmp(tur, "rastgele") == 0) {
        rastgele_karistir(a, n);
    } else if (strcmp(tur, "neredeyse") == 0) {
        for (size_t bas = 0; bas < n; bas += 11) {     /* k = 10 */
            size_t son = bas + 10 < n ? bas + 10 : n - 1;
            for (size_t i = son; i > bas; i--) {
                size_t j = bas + (size_t)rastgele_aralik(0, (int)(i - bas));
                int gecici = a[i];
                a[i] = a[j];
                a[j] = gecici;
            }
        }
    }
}

static int sirali_mi(const int *a, size_t n)
{
    for (size_t k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

static void kullanim(const char *ad)
{
    fprintf(stderr, "kullanım: %s secmeli|kabarcik|araya|kutuphane "
            "rastgele|sirali|ters|neredeyse N [TEKRAR] [--csv]\n", ad);
    exit(2);
}

int main(int argc, char *argv[])
{
    if (argc < 4) {
        kullanim(argv[0]);
    }
    const char *alg = argv[1];
    const char *tur = argv[2];
    char *son;
    long n_l = strtol(argv[3], &son, 10);
    if (*son != '\0' || n_l < 1 || n_l > 10000000) {
        kullanim(argv[0]);
    }
    int tekrar = 5, csv = 0;
    for (int k = 4; k < argc; k++) {
        if (strcmp(argv[k], "--csv") == 0) {
            csv = 1;
        } else {
            tekrar = (int)strtol(argv[k], &son, 10);
            if (*son != '\0' || tekrar < 1 || tekrar > 101) {
                kullanim(argv[0]);
            }
        }
    }
    void (*sirala)(int *, size_t, Sayac *) = NULL;
    if (strcmp(alg, "secmeli") == 0) {
        sirala = secmeli_sirala;
    } else if (strcmp(alg, "kabarcik") == 0) {
        sirala = kabarcik_sirala;
    } else if (strcmp(alg, "araya") == 0) {
        sirala = araya_ekleme_sirala;
    } else if (strcmp(alg, "kutuphane") == 0) {
        sirala = kutuphane_sirala;
    }
    if (sirala == NULL || (strcmp(tur, "rastgele") && strcmp(tur, "sirali")
                           && strcmp(tur, "ters") &&
                           strcmp(tur, "neredeyse"))) {
        kullanim(argv[0]);
    }
    size_t n = (size_t)n_l;
    int *girdi = malloc(n * sizeof *girdi);
    int *a = malloc(n * sizeof *a);
    if (girdi == NULL || a == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    girdi_uret(girdi, n, tur);

    double sure[102], islemci[102];
    Sayac s = {0, 0, 0, 0};
    for (int k = 0; k <= tekrar; k++) {        /* k = 0: ısınma */
        memcpy(a, girdi, n * sizeof *a);       /* kopya ölçüme girmez */
        double t0 = zaman_sn();
        double c0 = islemci_sn();
        sirala(a, n, &s);
        islemci[k] = islemci_sn() - c0;
        sure[k] = zaman_sn() - t0;
        if (!sirali_mi(a, n)) {
            fprintf(stderr, "HATA: sonuç sıralı değil\n");
            return 1;
        }
    }
    double en_az = sure[1], en_cok = sure[1];
    double i_az = islemci[1], i_cok = islemci[1];
    for (int k = 2; k <= tekrar; k++) {
        en_az = sure[k] < en_az ? sure[k] : en_az;
        en_cok = sure[k] > en_cok ? sure[k] : en_cok;
        i_az = islemci[k] < i_az ? islemci[k] : i_az;
        i_cok = islemci[k] > i_cok ? islemci[k] : i_cok;
    }
    double orta = ortanca(sure + 1, tekrar);   /* ısınma hariç */
    double i_orta = ortanca(islemci + 1, tekrar);
    if (csv) {
        printf("%s;%s;%zu;%lld;%lld;%lld;%lld;%d;%.6f;%.6f;%.6f;"
               "%.6f;%.6f;%.6f\n", alg, tur, n, s.karsilastirma, s.takas,
               s.kaydirma, s.yazma, tekrar, orta * 1e3, en_az * 1e3,
               en_cok * 1e3, i_orta * 1e3, i_az * 1e3, i_cok * 1e3);
    } else {
        printf("%s %s n = %zu: karşılaştırma = %lld, takas = %lld, "
               "kaydırma = %lld, yazma = %lld\n", alg, tur, n,
               s.karsilastirma, s.takas, s.kaydirma, s.yazma);
        fprintf(stderr, "ortanca = %.4f ms duvar, %.4f ms işlemci "
                "(%d tekrar)\n", orta * 1e3, i_orta * 1e3, tekrar);
    }
    free(girdi);
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort
 * (burada yalnızca "kutuphane" başvuru ölçümünde kullanılır). */

/* H05_deney_siralama.cpp — AP-2 Hafta 5 · Haftanın Deneyi (C++)
 * Amaç    : Seçmeli, kabarcık (erken çıkışlı) ve araya ekleme
 *           sıralamasının rastgele / sıralı / ters sıralı / neredeyse
 *           sıralı girdide karşılaştırma, takas, kaydırma, yazma sayıları
 *           ve süreleri (1 ısınma + tekrar, ortanca)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H05_deney_siralama.cpp -o H05_deney_siralama
 * Çalıştır: ./H05_deney_siralama ALGORITMA GIRDI N [TEKRAR] [--csv]
 *           ALGORITMA: secmeli | kabarcik | araya | kutuphane (std::sort;
 *           yalnızca süre karşılaştırması için, sayaçlar -1 = sayılmadı)
 *           GIRDI    : rastgele | sirali | ters | neredeyse
 * Çıktı   : sayaçlar stdout'a; süreler stderr'e (--csv: tek CSV satırı)
 * Süre    : duvar saati (zaman_sn) ve süreç işlemci zamanı (islemci_sn)
 * Girdi   : C sürümüyle aynı (bkz. c/H05_deney_siralama.c)
 */
#include <algorithm>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

struct Sayac {
    long long karsilastirma = 0;
    long long takas = 0;
    long long kaydirma = 0;
    long long yazma = 0;
};

static void secmeli_sirala(std::vector<int>& a, Sayac& s)
{
    long long kars = 0, tk = 0;
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        std::size_t en_kucuk = i;
        for (std::size_t j = i + 1; j < n; j++) {
            kars++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            std::swap(a[i], a[en_kucuk]);
            tk++;
        }
    }
    s = {kars, tk, 0, 2 * tk};
}

static void kabarcik_sirala(std::vector<int>& a, Sayac& s)
{
    long long kars = 0, tk = 0;
    std::size_t n = a.size();
    for (std::size_t i = 0; i + 1 < n; i++) {
        bool takas_oldu = false;
        for (std::size_t j = 0; j + 1 < n - i; j++) {
            kars++;
            if (a[j] > a[j + 1]) {
                std::swap(a[j], a[j + 1]);
                tk++;
                takas_oldu = true;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
    s = {kars, tk, 0, 2 * tk};
}

static void araya_ekleme_sirala(std::vector<int>& a, Sayac& s)
{
    long long kars = 0, kayd = 0;
    for (std::size_t i = 1; i < a.size(); i++) {
        int anahtar = a[i];
        auto j = static_cast<std::ptrdiff_t>(i) - 1;
        while (j >= 0) {
            kars++;
            if (a[j] <= anahtar) {
                break;
            }
            a[j + 1] = a[j];
            kayd++;
            j--;
        }
        a[j + 1] = anahtar;
    }
    long long n = static_cast<long long>(a.size());
    s = {kars, 0, kayd, kayd + (n > 0 ? n - 1 : 0)};
}

// Başvuru noktası: kütüphane sıralaması (genellikle introsort)
static void kutuphane_sirala(std::vector<int>& a, Sayac& s)
{
    std::sort(a.begin(), a.end());
    s = {-1, -1, -1, -1};
}

static std::vector<int> girdi_uret(std::size_t n, const std::string& tur)
{
    std::vector<int> a(n);
    for (std::size_t i = 0; i < n; i++) {
        a[i] = tur == "ters" ? static_cast<int>(n - i)
                             : static_cast<int>(i + 1);
    }
    rastgele_tohum(42);
    if (tur == "rastgele") {
        rastgele_karistir(a);
    } else if (tur == "neredeyse") {
        for (std::size_t bas = 0; bas < n; bas += 11) {   // k = 10
            std::size_t son = bas + 10 < n ? bas + 10 : n - 1;
            for (std::size_t i = son; i > bas; i--) {
                int ust = static_cast<int>(i - bas);
                std::size_t j =
                    bas + static_cast<std::size_t>(rastgele_aralik(0, ust));
                std::swap(a[i], a[j]);
            }
        }
    }
    return a;
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

[[noreturn]] static void kullanim(const char* ad)
{
    std::cerr << "kullanım: " << ad << " secmeli|kabarcik|araya|kutuphane "
              << "rastgele|sirali|ters|neredeyse N [TEKRAR] [--csv]\n";
    std::exit(2);
}

static long sayi_oku(const char* s, long alt, long ust, const char* ad)
{
    char* son = nullptr;
    long x = std::strtol(s, &son, 10);
    if (*son != '\0' || x < alt || x > ust) {
        kullanim(ad);
    }
    return x;
}

int main(int argc, char* argv[])
{
    if (argc < 4) {
        kullanim(argv[0]);
    }
    const std::string alg = argv[1];
    const std::string tur = argv[2];
    std::size_t n = static_cast<std::size_t>(
        sayi_oku(argv[3], 1, 10000000, argv[0]));
    int tekrar = 5;
    bool csv = false;
    for (int k = 4; k < argc; k++) {
        if (std::string(argv[k]) == "--csv") {
            csv = true;
        } else {
            tekrar = static_cast<int>(sayi_oku(argv[k], 1, 101, argv[0]));
        }
    }
    void (*sirala)(std::vector<int>&, Sayac&) = nullptr;
    if (alg == "secmeli") {
        sirala = secmeli_sirala;
    } else if (alg == "kabarcik") {
        sirala = kabarcik_sirala;
    } else if (alg == "araya") {
        sirala = araya_ekleme_sirala;
    } else if (alg == "kutuphane") {
        sirala = kutuphane_sirala;
    }
    if (sirala == nullptr || (tur != "rastgele" && tur != "sirali" &&
                              tur != "ters" && tur != "neredeyse")) {
        kullanim(argv[0]);
    }
    const std::vector<int> girdi = girdi_uret(n, tur);

    std::vector<double> sure, islemci;
    Sayac s;
    for (int k = 0; k <= tekrar; k++) {        // k = 0: ısınma
        std::vector<int> a = girdi;            // kopya ölçüme girmez
        double t0 = zaman_sn();
        double c0 = islemci_sn();
        sirala(a, s);
        double c = islemci_sn() - c0;
        double t = zaman_sn() - t0;
        if (k > 0) {
            sure.push_back(t);
            islemci.push_back(c);
        }
        if (!sirali_mi(a)) {
            std::cerr << "HATA: sonuç sıralı değil\n";
            return 1;
        }
    }
    double en_az = sure[0], en_cok = sure[0];
    double i_az = islemci[0], i_cok = islemci[0];
    for (std::size_t k = 0; k < sure.size(); k++) {
        en_az = sure[k] < en_az ? sure[k] : en_az;
        en_cok = sure[k] > en_cok ? sure[k] : en_cok;
        i_az = islemci[k] < i_az ? islemci[k] : i_az;
        i_cok = islemci[k] > i_cok ? islemci[k] : i_cok;
    }
    double orta = ortanca(sure);
    double i_orta = ortanca(islemci);
    if (csv) {
        std::printf("%s;%s;%zu;%lld;%lld;%lld;%lld;%d;%.6f;%.6f;%.6f;"
                    "%.6f;%.6f;%.6f\n", alg.c_str(), tur.c_str(), n,
                    s.karsilastirma, s.takas, s.kaydirma, s.yazma, tekrar,
                    orta * 1e3, en_az * 1e3, en_cok * 1e3, i_orta * 1e3,
                    i_az * 1e3, i_cok * 1e3);
    } else {
        std::printf("%s %s n = %zu: karşılaştırma = %lld, takas = %lld, "
                    "kaydırma = %lld, yazma = %lld\n", alg.c_str(),
                    tur.c_str(), n, s.karsilastirma, s.takas, s.kaydirma,
                    s.yazma);
        std::fprintf(stderr, "ortanca = %.4f ms duvar, %.4f ms işlemci "
                     "(%d tekrar)\n", orta * 1e3, i_orta * 1e3, tekrar);
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort
 * (burada yalnızca "kutuphane" başvuru ölçümünde kullanılır). */

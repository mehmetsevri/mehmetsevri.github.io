"""H05_deney_siralama.py — AP-2 Hafta 5 · Haftanın Deneyi (Python)
Amaç    : Seçmeli, kabarcık (erken çıkışlı) ve araya ekleme
          sıralamasının rastgele / sıralı / ters sıralı / neredeyse
          sıralı girdide karşılaştırma, takas, kaydırma, yazma sayıları
          ve süreleri (1 ısınma + tekrar, ortanca)
Çalıştır: python3 H05_deney_siralama.py ALGORITMA GIRDI N [TEKRAR] [--csv]
          ALGORITMA: secmeli | kabarcik | araya | kutuphane (list.sort;
          yalnızca süre karşılaştırması için, sayaçlar -1 = sayılmadı)
          GIRDI    : rastgele | sirali | ters | neredeyse
Çıktı   : sayaçlar stdout'a; süreler stderr'e (--csv: tek CSV satırı)
Süre    : duvar saati (zaman_sn) ve süreç işlemci zamanı (islemci_sn)
Girdi   : C sürümüyle aynı (bkz. c/H05_deney_siralama.c)
"""

import sys

from ortak_rastgele import rastgele_aralik, rastgele_karistir, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn


def secmeli_sirala(a):
    kars = tk = 0
    n = len(a)
    for i in range(n - 1):
        en_kucuk = i
        for j in range(i + 1, n):
            kars += 1
            if a[j] < a[en_kucuk]:
                en_kucuk = j
        if en_kucuk != i:
            a[i], a[en_kucuk] = a[en_kucuk], a[i]
            tk += 1
    return kars, tk, 0, 2 * tk


def kabarcik_sirala(a):
    kars = tk = 0
    n = len(a)
    for i in range(n - 1):
        takas_oldu = False
        for j in range(n - 1 - i):
            kars += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                tk += 1
                takas_oldu = True
        if not takas_oldu:
            break
    return kars, tk, 0, 2 * tk


def araya_ekleme_sirala(a):
    kars = kayd = 0
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while j >= 0:
            kars += 1
            if a[j] <= anahtar:
                break
            a[j + 1] = a[j]
            kayd += 1
            j -= 1
        a[j + 1] = anahtar
    n = len(a)
    return kars, 0, kayd, kayd + (n - 1 if n > 0 else 0)


def kutuphane_sirala(a):
    """Başvuru noktası: kütüphane sıralaması (Timsort, C ile yazılmış)"""
    a.sort()
    return -1, -1, -1, -1


def girdi_uret(n, tur):
    a = [n - i if tur == "ters" else i + 1 for i in range(n)]
    rastgele_tohum(42)
    if tur == "rastgele":
        rastgele_karistir(a)
    elif tur == "neredeyse":
        for bas in range(0, n, 11):                    # k = 10
            son = bas + 10 if bas + 10 < n else n - 1
            for i in range(son, bas, -1):
                j = bas + rastgele_aralik(0, i - bas)
                a[i], a[j] = a[j], a[i]
    return a


def sirali_mi(a):
    return all(a[k - 1] <= a[k] for k in range(1, len(a)))


def kullanim():
    print(f"kullanım: {sys.argv[0]} secmeli|kabarcik|araya|kutuphane "
          "rastgele|sirali|ters|neredeyse N [TEKRAR] [--csv]",
          file=sys.stderr)
    sys.exit(2)


def sayi_oku(s, alt, ust):
    try:
        x = int(s)
    except ValueError:
        kullanim()
    if x < alt or x > ust:
        kullanim()
    return x


def main():
    if len(sys.argv) < 4:
        kullanim()
    alg, tur = sys.argv[1], sys.argv[2]
    n = sayi_oku(sys.argv[3], 1, 10000000)
    tekrar, csv = 5, False
    for s in sys.argv[4:]:
        if s == "--csv":
            csv = True
        else:
            tekrar = sayi_oku(s, 1, 101)
    sirala = {"secmeli": secmeli_sirala, "kabarcik": kabarcik_sirala,
              "araya": araya_ekleme_sirala,
              "kutuphane": kutuphane_sirala}.get(alg)
    if sirala is None or tur not in ("rastgele", "sirali", "ters",
                                     "neredeyse"):
        kullanim()
    girdi = girdi_uret(n, tur)

    sure, islemci = [], []
    sayac = (0, 0, 0, 0)
    for k in range(tekrar + 1):                # k = 0: ısınma
        a = girdi[:]                           # kopya ölçüme girmez
        t0 = zaman_sn()
        c0 = islemci_sn()
        sayac = sirala(a)
        c = islemci_sn() - c0
        t = zaman_sn() - t0
        if k > 0:
            sure.append(t)
            islemci.append(c)
        if not sirali_mi(a):
            print("HATA: sonuç sıralı değil", file=sys.stderr)
            sys.exit(1)
    orta = ortanca(sure)
    i_orta = ortanca(islemci)
    kars, tk, kayd, yazma = sayac
    if csv:
        print(f"{alg};{tur};{n};{kars};{tk};{kayd};{yazma};{tekrar};"
              f"{orta * 1e3:.6f};{min(sure) * 1e3:.6f};"
              f"{max(sure) * 1e3:.6f};{i_orta * 1e3:.6f};"
              f"{min(islemci) * 1e3:.6f};{max(islemci) * 1e3:.6f}")
    else:
        print(f"{alg} {tur} n = {n}: karşılaştırma = {kars}, takas = {tk}, "
              f"kaydırma = {kayd}, yazma = {yazma}")
        print(f"ortanca = {orta * 1e3:.4f} ms duvar, {i_orta * 1e3:.4f} ms "
              f"işlemci ({tekrar} tekrar)", file=sys.stderr)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort
# (burada yalnızca "kutuphane" başvuru ölçümünde kullanılır).

/* H05_11_k_sirali.c — AP-2 Hafta 5 · Örnek 11 (★★★)
 * Amaç    : k-sıralı (neredeyse sıralı) dizide araya eklemenin O(nk)
 *           davranışı; kabarcık ve seçmeli ile karşılaştırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_11_k_sirali.c ortak_rastgele.c -o H05_11_k_sirali
 * Çalıştır: ./H05_11_k_sirali
 * Eşleri  : cpp/H05_11_k_sirali.cpp · python/H05_11_k_sirali.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "ortak_rastgele.h"

#define N 1000

static long long karsilastirma = 0;
static long long takas_sayisi = 0;
static long long kaydirma = 0;
static long long gecis_sayisi = 0;

static void sayaclari_sifirla(void)
{
    karsilastirma = 0;
    takas_sayisi = 0;
    kaydirma = 0;
    gecis_sayisi = 0;
}

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

/* 1..n sıralı dizi; (k + 1)'lik bloklar kendi içinde karıştırılır:
 * her eleman sıralı konumundan en fazla k uzaktadır (k-sıralı) */
static void k_sirali_dizi(int *a, size_t n, size_t k)
{
    for (size_t i = 0; i < n; i++) {
        a[i] = (int)(i + 1);
    }
    for (size_t bas = 0; bas < n; bas += k + 1) {
        size_t son = bas + k < n ? bas + k : n - 1;   /* blok: bas..son */
        for (size_t i = son; i > bas; i--) {          /* Fisher–Yates */
            size_t j = bas + (size_t)rastgele_aralik(0, (int)(i - bas));
            takas(&a[i], &a[j]);
        }
    }
}

/* En büyük |i - sıralı konum|: değer v'nin sıralı konumu v - 1 */
static size_t en_buyuk_uzaklik(const int *a, size_t n)
{
    size_t en = 0;
    for (size_t i = 0; i < n; i++) {
        size_t hedef = (size_t)a[i] - 1;
        size_t d = i > hedef ? i - hedef : hedef - i;
        if (d > en) {
            en = d;
        }
    }
    return en;
}

static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0) {
            karsilastirma++;
            if (a[j] <= anahtar) {
                break;
            }
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

static void kabarcik_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;
        for (size_t j = 0; j + 1 < n - i; j++) {
            karsilastirma++;
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
                takas_sayisi++;
                takas_oldu = 1;
            }
        }
        gecis_sayisi++;
        if (!takas_oldu) {
            break;
        }
    }
}

static void secmeli_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en_kucuk = i;
        for (size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            takas(&a[i], &a[en_kucuk]);
            takas_sayisi++;
        }
    }
}

int main(void)
{
    static int girdi[N], a[N];
    const size_t ks[] = {0, 1, 2, 4, 8, 16, 32, 64, N - 1};
    size_t n = N;

    printf("k-sıralı dizi: her eleman sıralı yerinden en fazla k uzakta\n");
    printf("(1..n, (k+1)'lik bloklar içinde karıştırılmış; n = %zu, "
           "tohum 7)\n", n);
    printf("kuram: kaydırma = ters çevrim <= n·k; kabarcık geçişi "
           "<= k + 1\n\n");
    printf("            araya ekleme                kabarcık        "
           "seçmeli\n");
    printf("   k  uzak.  kaydırma kayd/(nk)   karş.  geçiş     karş."
           "     karş.\n");
    rastgele_tohum(7);
    for (size_t t = 0; t < sizeof ks / sizeof ks[0]; t++) {
        size_t k = ks[t];
        k_sirali_dizi(girdi, n, k);
        size_t uzaklik = en_buyuk_uzaklik(girdi, n);

        memcpy(a, girdi, sizeof girdi);
        sayaclari_sifirla();
        araya_ekleme_sirala(a, n);
        long long ae_kayd = kaydirma, ae_kars = karsilastirma;

        memcpy(a, girdi, sizeof girdi);
        sayaclari_sifirla();
        kabarcik_sirala(a, n);
        long long kb_gecis = gecis_sayisi, kb_kars = karsilastirma;

        memcpy(a, girdi, sizeof girdi);
        sayaclari_sifirla();
        secmeli_sirala(a, n);

        printf("%4zu %6zu %9lld", k, uzaklik, ae_kayd);
        if (k > 0) {
            printf(" %9.3f", (double)ae_kayd / ((double)n * (double)k));
        } else {
            printf(" %9s", "-");               /* k = 0: n·k = 0 */
        }
        printf(" %7lld %6lld %9lld %9lld\n", ae_kars, kb_gecis, kb_kars,
               karsilastirma);
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort
 * (Timsort: girdideki sıralı parçalardan yararlanan uyarlanabilir
 * sıralama). */

/* H05_07_qsort_arayuzu.c — AP-2 Hafta 5 · Örnek 7 (★★)
 * Amaç    : Genel sıralama arayüzü (qsort · std::sort · sorted): int,
 *           double ve dizgi dizileri; taşmaya güvenli karşılaştırıcı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_07_qsort_arayuzu.c -o H05_07_qsort_arayuzu
 * Çalıştır: ./H05_07_qsort_arayuzu
 * Eşleri  : cpp/H05_07_qsort_arayuzu.cpp · python/H05_07_qsort_arayuzu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* void qsort(void *taban, size_t n, size_t boyut,
 *            int (*kars)(const void *, const void *));
 * kars(p, q): p ve q öğelerin ADRESİdir; < 0, 0, > 0 döndürür. */

static int int_artan(const void *p, const void *q)
{
    int x = *(const int *)p;
    int y = *(const int *)q;
    return (x > y) - (x < y);   /* -1, 0, 1; taşma yok */
    /* YANLIŞ: return x - y;  x = INT_MAX, y = -1 için taşar (UB) */
}

static int int_azalan(const void *p, const void *q)
{
    return int_artan(q, p);     /* bağımsız değişkenlerin yeri değişir */
}

static int double_artan(const void *p, const void *q)
{
    double x = *(const double *)p;
    double y = *(const double *)q;
    return (x > y) - (x < y);
    /* YANLIŞ: return (int)(x - y);  0.1 - 0.3 = -0.2 -> 0 ("eşit") */
}

static int dizgi_artan(const void *p, const void *q)
{
    const char *x = *(const char *const *)p;  /* öğe bir char * */
    const char *y = *(const char *const *)q;
    return strcmp(x, y);                      /* bayt sırası */
}

/* İki anahtar: önce uzunluk (artan), eşitse alfabe (bayt) sırası */
static int uzunluk_sonra_alfabe(const void *p, const void *q)
{
    const char *x = *(const char *const *)p;
    const char *y = *(const char *const *)q;
    size_t ux = strlen(x);
    size_t uy = strlen(y);
    if (ux != uy) {
        return (ux > uy) - (ux < uy);
    }
    return strcmp(x, y);
}

static void int_yaz(const char *etiket, const int *a, size_t n)
{
    printf("   %s:", etiket);
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

static void double_yaz(const char *etiket, const double *a, size_t n)
{
    printf("   %s:", etiket);
    for (size_t k = 0; k < n; k++) {
        printf(" %.2f", a[k]);
    }
    printf("\n");
}

static void dizgi_yaz(const char *etiket, const char *const *a, size_t n)
{
    printf("   %s:", etiket);
    for (size_t k = 0; k < n; k++) {
        printf(" %s", a[k]);
    }
    printf("\n");
}

int main(void)
{
    int a[] = {3, -7, INT_MAX, 0, INT_MIN, 42, -1, 7};
    size_t na = sizeof a / sizeof a[0];
    printf("1) int dizisi: qsort + taşmaya güvenli karşılaştırıcı\n");
    int_yaz("girdi ", a, na);
    qsort(a, na, sizeof a[0], int_artan);
    int_yaz("artan ", a, na);
    qsort(a, na, sizeof a[0], int_azalan);
    int_yaz("azalan", a, na);
    long long fark = (long long)INT_MAX - (-1);  /* geniş türde hesap */
    printf("   neden x - y değil? INT_MAX - (-1) = %lld > INT_MAX = %d\n",
           fark, INT_MAX);
    printf("   (int'te taşma: C'de tanımsız davranış; bkz. Hata Avcısı)\n");

    double d[] = {2.5, -0.75, 3.14, 0.1, -2.0, 0.3};
    size_t nd = sizeof d / sizeof d[0];
    printf("\n2) double dizisi\n");
    double_yaz("girdi ", d, nd);
    qsort(d, nd, sizeof d[0], double_artan);
    double_yaz("artan ", d, nd);
    printf("   (int)(0.1 - 0.3) = %d: kesme, farklı sayıları \"eşit\" "
           "gösterir\n", (int)(0.1 - 0.3));

    const char *s[] = {"elma", "Zeki", "armut", "Çelik", "Can", "ali",
                       "Şule"};
    size_t ns = sizeof s / sizeof s[0];
    printf("\n3) dizgi dizisi: strcmp (bayt sırası)\n");
    dizgi_yaz("girdi ", s, ns);
    qsort(s, ns, sizeof s[0], dizgi_artan);
    dizgi_yaz("artan ", s, ns);
    printf("   bayt sırası alfabe sırası değil: Ç ve Ş, z'den bile sonra "
           "(Mini-OBS 2 v2.4)\n");

    const char *m[] = {"elma", "kivi", "armut", "nar", "incir", "ayva",
                       "dut"};
    size_t nm = sizeof m / sizeof m[0];
    printf("\n4) iki anahtarlı karşılaştırıcı: uzunluk, sonra alfabe\n");
    dizgi_yaz("girdi ", m, nm);
    qsort(m, nm, sizeof m[0], uzunluk_sonra_alfabe);
    dizgi_yaz("sonuç ", m, nm);
    return 0;
}

/* Kütüphane karşılığı: bu örneğin konusu kütüphane arayüzüdür.
 * C — qsort; C++ — std::sort + karşılaştırıcı; Python — sorted(key=…). */

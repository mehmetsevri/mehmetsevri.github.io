/* H05_13_shell_siralama.c — AP-2 Hafta 5 · Örnek 13 (★★★, merak)
 * Amaç    : Shell sıralaması (h-sıralama) ve aralık dizisi deneyi:
 *           Shell (n/2, n/4, ..., 1), Knuth (3h + 1), Ciura
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_13_shell_siralama.c ortak_rastgele.c \
 *           -o H05_13_shell_siralama
 * Çalıştır: ./H05_13_shell_siralama
 * Eşleri  : cpp/H05_13_shell_siralama.cpp
 *           python/H05_13_shell_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS_N 5000
#define MAKS_H 32

static long long karsilastirma = 0;
static long long kaydirma = 0;

static void dizi_yaz(const int *a, size_t n)
{
    for (size_t k = 0; k < n; k++) {
        printf("%3d", a[k]);
    }
    printf("\n");
}

/* Her h için: a[i], a[i-h], a[i-2h], ... alt dizisinde araya ekleme */
static void h_gecisi(int *a, size_t n, size_t h)
{
    for (size_t i = h; i < n; i++) {
        int anahtar = a[i];
        size_t j = i;                      /* boşluğun konumu */
        while (j >= h) {
            karsilastirma++;
            if (a[j - h] <= anahtar) {
                break;
            }
            a[j] = a[j - h];   /* h sağa kaydır */
            kaydirma++;
            j -= h;
        }
        a[j] = anahtar;
    }
}

static void shell_sirala(int *a, size_t n, const size_t *h, size_t hs)
{
    for (size_t t = 0; t < hs; t++) {      /* h: büyükten küçüğe, son 1 */
        h_gecisi(a, n, h[t]);
    }
}

/* a, h-sıralı mı? (her i için a[i - h] <= a[i]) */
static int h_sirali_mi(const int *a, size_t n, size_t h)
{
    for (size_t i = h; i < n; i++) {
        if (a[i - h] > a[i]) {
            return 0;
        }
    }
    return 1;
}

/* Aralık dizileri (azalan, son eleman 1); eleman sayısını döndürür */
static size_t shell_araliklari(size_t n, size_t *h)
{
    size_t s = 0;
    for (size_t g = n / 2; g > 0; g /= 2) {
        h[s++] = g;
    }
    return s;
}

static size_t knuth_araliklari(size_t n, size_t *h)
{
    size_t g = 1;
    while (g < n / 3) {
        g = 3 * g + 1;                     /* 1, 4, 13, 40, 121, ... */
    }
    size_t s = 0;
    for (; g > 0; g /= 3) {
        h[s++] = g;
    }
    return s;
}

static size_t ciura_araliklari(size_t n, size_t *h)
{
    static const size_t ciura[] = {701, 301, 132, 57, 23, 10, 4, 1};
    size_t s = 0;
    for (size_t k = 0; k < 8; k++) {
        if (ciura[k] < n || ciura[k] == 1) {
            h[s++] = ciura[k];
        }
    }
    return s;
}

static void h_listesi_yaz(const char *ad, const size_t *h, size_t hs)
{
    printf("   %s:", ad);
    for (size_t t = 0; t < hs; t++) {
        printf(" %zu", h[t]);
    }
    printf("\n");
}

int main(void)
{
    static int girdi[MAKS_N], a[MAKS_N];
    size_t h[MAKS_H];

    /* 1) Küçük örnek: h = 4, 2, 1 geçişleri */
    int k[] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t nk = 8;
    size_t hs = shell_araliklari(nk, h);
    printf("1) Shell sıralaması, n = 8, h = 4, 2, 1\n   başlangıç: ");
    dizi_yaz(k, nk);
    for (size_t t = 0; t < hs; t++) {
        karsilastirma = 0;
        kaydirma = 0;
        h_gecisi(k, nk, h[t]);
        printf("   h = %zu    : ", h[t]);
        dizi_yaz(k, nk);
        printf("   %zu-sıralı mı? %s   karşılaştırma = %lld, kaydırma = "
               "%lld\n", h[t], h_sirali_mi(k, nk, h[t]) ? "evet" : "hayır",
               karsilastirma, kaydirma);
    }

    /* 2) Aralık dizisi deneyi */
    printf("\n2) aralık dizileri: rastgele permütasyon (ortak LCG, tohum "
           "13)\n");
    const size_t boyutlar[] = {100, 1000, 5000};
    for (size_t b = 0; b < 3; b++) {
        size_t n = boyutlar[b];
        for (size_t i = 0; i < n; i++) {
            girdi[i] = (int)(i + 1);
        }
        rastgele_tohum(13);
        rastgele_karistir(girdi, n);
        printf("\nn = %zu\n", n);
        printf("   yöntem          karşılaştırma    kaydırma  sıralı\n");
        const char *const adlar[] = {"Shell (n/2)", "Knuth (3h+1)",
                                     "Ciura", "araya ekleme"};
        size_t hd[4][MAKS_H];
        size_t hsay[4];
        hsay[0] = shell_araliklari(n, hd[0]);
        hsay[1] = knuth_araliklari(n, hd[1]);
        hsay[2] = ciura_araliklari(n, hd[2]);
        hd[3][0] = 1;                       /* h = 1: araya ekleme */
        hsay[3] = 1;
        for (int y = 0; y < 4; y++) {
            memcpy(a, girdi, n * sizeof a[0]);
            karsilastirma = 0;
            kaydirma = 0;
            shell_sirala(a, n, hd[y], hsay[y]);
            printf("   %-14s %14lld %11lld  %s\n", adlar[y], karsilastirma,
                   kaydirma, h_sirali_mi(a, n, 1) ? "evet" : "HAYIR");
        }
        for (int y = 0; y < 3; y++) {
            h_listesi_yaz(adlar[y], hd[y], hsay[y]);
        }
    }

    /* 3) Kararlılık: anahtar = değer / 10, etiket = değer % 10 */
    int e[] = {20, 10, 21, 11, 22, 12};
    size_t ne = 6;
    hs = shell_araliklari(ne, h);           /* 3, 1 */
    printf("\n3) kararlılık (sayı: anahtar, harf: özgün sıra etiketi)\n");
    printf("   girdi : ");
    for (size_t i = 0; i < ne; i++) {
        printf(" %d%c", e[i] / 10, 'a' + e[i] % 10);
    }
    for (size_t t = 0; t < hs; t++) {       /* yalnız anahtar kıyaslanır */
        size_t g = h[t];
        for (size_t i = g; i < ne; i++) {
            int anahtar = e[i];
            size_t j = i;
            while (j >= g && e[j - g] / 10 > anahtar / 10) {
                e[j] = e[j - g];
                j -= g;
            }
            e[j] = anahtar;
        }
    }
    printf("\n   sonuç : ");
    int kararli = 1;
    for (size_t i = 0; i < ne; i++) {
        printf(" %d%c", e[i] / 10, 'a' + e[i] % 10);
        if (i > 0 && e[i - 1] / 10 == e[i] / 10 && e[i - 1] > e[i]) {
            kararli = 0;
        }
    }
    printf("\n   eşit anahtarlarda etiket sırası korundu mu? %s\n",
           kararli ? "evet" : "HAYIR (Shell sıralaması kararsız)");
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Ciura aralıkları deneysel
 * olarak bulunmuş bir dizidir; burada 701'e kadar kullanılır. */

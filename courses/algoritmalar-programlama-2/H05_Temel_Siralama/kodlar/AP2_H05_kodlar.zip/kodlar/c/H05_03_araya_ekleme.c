/* H05_03_araya_ekleme.c — AP-2 Hafta 5 · Örnek 3 (★)
 * Amaç    : Araya ekleme sıralaması: anahtarı sıralı öneke kaydırarak
 *           yerleştirme; değişmez (a[0..i] sıralı) ve çevrimiçi ekleme
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_03_araya_ekleme.c -o H05_03_araya_ekleme
 * Çalıştır: ./H05_03_araya_ekleme
 * Eşleri  : cpp/H05_03_araya_ekleme.cpp · python/H05_03_araya_ekleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

static long long karsilastirma = 0;
static long long kaydirma = 0;

/* a[0..n-1]'i yazar; sinir < n ise a[sinir]'dan önce '|' koyar */
static void dizi_yaz(const int *a, size_t n, size_t sinir)
{
    for (size_t k = 0; k < n; k++) {
        if (k == sinir) {
            printf(" |");
        }
        printf("%3d", a[k]);
    }
    printf("\n");
}

/* x > y karşılaştırmasını sayarak yapar */
static int buyuk_mu(int x, int y)
{
    karsilastirma++;
    return x > y;
}

/* a[0..i-1] sıralı; a[i]'yi kaydırarak yerine koyar, konumunu döndürür */
static size_t yerlestir(int *a, size_t i)
{
    int anahtar = a[i];
    ptrdiff_t j = (ptrdiff_t)i - 1;   /* -1 olabilir */
    while (j >= 0 && buyuk_mu(a[j], anahtar)) {
        a[j + 1] = a[j];   /* bir sağa kaydır */
        kaydirma++;
        j--;
    }
    a[j + 1] = anahtar;
    return (size_t)(j + 1);
}

static void araya_ekleme_sirala(int *a, size_t n, int yazdir)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        long long onceki = kaydirma;
        size_t yer = yerlestir(a, i);
        if (yazdir) {
            printf("i = %zu: anahtar = %2d, kaydırma = %lld, yeri a[%zu]\n",
                   i, anahtar, kaydirma - onceki, yer);
            printf("      ");
            dizi_yaz(a, n, i + 1);
        }
    }
}

int main(void)
{
    int a[11] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = 8;

    printf("Araya ekleme sıralaması, n = %zu ('|' solu: sıralı önek)\n", n);
    printf("başlangıç:\n      ");
    dizi_yaz(a, n, 1);
    araya_ekleme_sirala(a, n, 1);
    printf("toplam: karşılaştırma = %lld, kaydırma = %lld\n",
           karsilastirma, kaydirma);

    printf("\nÇevrimiçi: yeni gelen eleman sıralı diziye eklenir\n");
    int gelen[] = {15, 50, 1};
    for (size_t k = 0; k < 3; k++) {
        karsilastirma = 0;
        kaydirma = 0;
        a[n] = gelen[k];                   /* sona ekle ... */
        size_t yer = yerlestir(a, n);      /* ... ve yerine kaydır */
        n++;
        printf("+%2d -> yeri a[%zu], karşılaştırma = %lld, "
               "kaydırma = %lld\n      ", gelen[k], yer, karsilastirma,
               kaydirma);
        dizi_yaz(a, n, n);
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort, sıralı vektöre ekleme
 * için std::upper_bound + insert; Python — bisect.insort (yalnızca not). */

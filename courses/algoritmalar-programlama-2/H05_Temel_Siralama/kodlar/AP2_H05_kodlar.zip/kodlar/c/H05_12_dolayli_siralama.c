/* H05_12_dolayli_siralama.c — AP-2 Hafta 5 · Örnek 12 (★★★)
 * Amaç    : Dolaylı sıralama: büyük kayıtları taşımadan işaretçi/indis
 *           dizisini sıralamak; kopyalanan bayt sayısının karşılaştırması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_12_dolayli_siralama.c ortak_rastgele.c zamanlayici.c \
 *           -o H05_12_dolayli_siralama
 * Çalıştır: ./H05_12_dolayli_siralama [n=1000]   (süreler stderr'e)
 * Eşleri  : cpp/H05_12_dolayli_siralama.cpp
 *           python/H05_12_dolayli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define VERI_BOYUT 248

typedef struct {
    int anahtar;
    int no;                       /* kayıt sırası: 0, 1, 2, ... */
    char veri[VERI_BOYUT];        /* "büyük" yük: ad, adres, notlar ... */
} Kayit;                          /* 4 + 4 + 248 = 256 bayt */

_Static_assert(sizeof(Kayit) == 256, "Kayit 256 bayt olmalı");

static long long kopya = 0;       /* öğe kopyası: anahtar + kaydırma */

/* Doğrudan: kayıtların kendisi kaydırılır (her kopya 256 bayt) */
static void kayit_sirala(Kayit *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        Kayit anahtar = a[i];
        kopya++;
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && a[j].anahtar > anahtar.anahtar) {
            a[j + 1] = a[j];
            kopya++;
            j--;
        }
        a[j + 1] = anahtar;
        kopya++;
    }
}

/* Dolaylı: işaretçiler kaydırılır (her kopya 8 bayt); kayıtlar yerinde */
static void isaretci_sirala(const Kayit **p, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        const Kayit *anahtar = p[i];
        kopya++;
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && p[j]->anahtar > anahtar->anahtar) {
            p[j + 1] = p[j];
            kopya++;
            j--;
        }
        p[j + 1] = anahtar;
        kopya++;
    }
}

static long arguman_oku(int argc, char *argv[], long varsayilan)
{
    if (argc < 2) {
        return varsayilan;
    }
    char *son;
    long deger = strtol(argv[1], &son, 10);
    if (*son != '\0' || deger < 1 || deger > 100000) {
        fprintf(stderr, "kullanım: %s [n: 1..100000]\n", argv[0]);
        exit(2);
    }
    return deger;
}

int main(int argc, char *argv[])
{
    size_t n = (size_t)arguman_oku(argc, argv, 1000);
    Kayit *kayit = malloc(n * sizeof *kayit);
    Kayit *dogrudan = malloc(n * sizeof *dogrudan);
    const Kayit **p = malloc(n * sizeof *p);
    Kayit *duzenli = malloc(n * sizeof *duzenli);
    if (!kayit || !dogrudan || !p || !duzenli) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(5);
    for (size_t i = 0; i < n; i++) {
        kayit[i].anahtar = rastgele_aralik(0, 99);
        kayit[i].no = (int)i;
        snprintf(kayit[i].veri, VERI_BOYUT, "kayıt %zu", i);
        dogrudan[i] = kayit[i];
        p[i] = &kayit[i];
    }

    kopya = 0;
    double t0 = zaman_sn();
    kayit_sirala(dogrudan, n);
    double t_dogrudan = zaman_sn() - t0;
    long long kopya_dogrudan = kopya;

    kopya = 0;
    t0 = zaman_sn();
    isaretci_sirala(p, n);
    for (size_t i = 0; i < n; i++) {
        duzenli[i] = *p[i];            /* bir kez yeniden düzenle */
    }
    double t_dolayli = zaman_sn() - t0;
    long long kopya_dolayli = kopya;

    int ayni = 1;
    for (size_t i = 0; i < n; i++) {
        if (dogrudan[i].no != duzenli[i].no) {
            ayni = 0;
        }
    }
    long long bayt_dogrudan = kopya_dogrudan * (long long)sizeof(Kayit);
    long long bayt_dolayli = kopya_dolayli * (long long)sizeof(Kayit *);
    long long bayt_duzenleme = (long long)n * (long long)sizeof(Kayit);

    printf("Dolaylı sıralama: n = %zu kayıt, kayıt = %zu bayt, "
           "işaretçi/indis = %zu bayt\n", n, sizeof(Kayit),
           sizeof(Kayit *));
    printf("anahtar 0..99 (yinelenen), ortak LCG tohum 5; araya ekleme\n\n");
    printf("yöntem                           öğe kopyası  kopyalanan bayt\n");
    printf("doğrudan: kayıtları kaydır      %12lld %14lld\n",
           kopya_dogrudan, bayt_dogrudan);
    printf("dolaylı: işaretçileri kaydır    %12lld %14lld\n",
           kopya_dolayli, bayt_dolayli);
    printf("  + bir kez yeniden düzenleme   %12zu %14lld\n", n,
           bayt_duzenleme);
    printf("dolaylı toplam                  %12lld %14lld\n",
           kopya_dolayli + (long long)n, bayt_dolayli + bayt_duzenleme);
    printf("kopyalanan bayt oranı (doğrudan / dolaylı toplam) = %.1f\n",
           (double)bayt_dogrudan / (double)(bayt_dolayli + bayt_duzenleme));
    printf("iki yöntem aynı kayıt sırasını verdi mi? %s\n",
           ayni ? "evet" : "HAYIR");
    printf("ilk 8 (anahtar/no):");
    for (size_t i = 0; i < 8 && i < n; i++) {
        printf(" %d/%d", duzenli[i].anahtar, duzenli[i].no);
    }
    printf("\n");
    fprintf(stderr, "süre (tek ölçüm): doğrudan %.3f ms, dolaylı + "
            "düzenleme %.3f ms\n", t_dogrudan * 1e3, t_dolayli * 1e3);
    free(kayit);
    free(dogrudan);
    free(p);
    free(duzenli);
    return 0;
}

/* Kütüphane karşılığı: C — qsort(p, n, sizeof p[0], kars) işaretçi
 * dizisiyle; C++ — std::sort ile indis/işaretçi vektörü; Python —
 * sorted(range(n), key=lambda i: kayit[i].anahtar). */

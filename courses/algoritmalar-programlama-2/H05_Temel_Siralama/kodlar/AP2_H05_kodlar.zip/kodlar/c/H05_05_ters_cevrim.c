/* H05_05_ters_cevrim.c — AP-2 Hafta 5 · Örnek 5 (★★)
 * Amaç    : Ters çevrim sayısı (kaba kuvvet, O(n²)) ve araya eklemenin
 *           kaydırma sayısıyla eşitliği; rastgele dizilerde doğrulama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_05_ters_cevrim.c ortak_rastgele.c -o H05_05_ters_cevrim
 * Çalıştır: ./H05_05_ters_cevrim
 * Eşleri  : cpp/H05_05_ters_cevrim.cpp · python/H05_05_ters_cevrim.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

#include "ortak_rastgele.h"

#define MAKS_N 1000

static long long kaydirma = 0;

/* Ters çevrim: i < j ve a[i] > a[j] olan (i, j) çiftlerinin sayısı */
static long long ters_cevrim_say(const int *a, size_t n)
{
    long long sayi = 0;
    for (size_t i = 0; i < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                sayi++;
            }
        }
    }
    return sayi;
}

static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && a[j] > anahtar) {
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

static void ciftleri_yaz(const int *a, size_t n)
{
    int yazilan = 0;
    for (size_t i = 0; i < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                printf(" (%d,%d)", a[i], a[j]);
                yazilan++;
                if (yazilan % 8 == 0) {
                    printf("\n");
                }
            }
        }
    }
    if (yazilan % 8 != 0) {
        printf("\n");
    }
}

int main(void)
{
    int a[MAKS_N] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = 8;

    printf("1) a = ");
    for (size_t k = 0; k < n; k++) {
        printf("%d ", a[k]);
    }
    printf("\nters çevrim çiftleri (a[i], a[j]), i < j ve a[i] > a[j]:\n");
    ciftleri_yaz(a, n);
    printf("ters çevrim sayısı = %lld\n", ters_cevrim_say(a, n));

    printf("\n2) araya eklemede i. anahtarın kaydırması = solundaki "
           "büyüklerin sayısı\n");
    printf("   i  a[i]  soldaki büyük  kaydırma\n");
    int b[MAKS_N];
    for (size_t k = 0; k < n; k++) {
        b[k] = a[k];
    }
    long long toplam = 0;
    for (size_t i = 0; i < n; i++) {
        int soldaki = 0;
        for (size_t k = 0; k < i; k++) {
            if (a[k] > a[i]) {
                soldaki++;
            }
        }
        kaydirma = 0;
        araya_ekleme_sirala(b, i + 1);   /* b[0..i-1] zaten sıralı */
        toplam += kaydirma;
        printf("%4zu %5d %14d %9lld\n", i, a[i], soldaki, kaydirma);
    }
    printf("toplam kaydırma = %lld\n", toplam);

    printf("\n3) rastgele diziler (değerler 0..999, ortak LCG)\n");
    printf("   n  tohum  ters çevrim   kaydırma  eşit  oran (/ n(n-1)/4)\n");
    size_t boyutlar[] = {10, 100, 1000};
    int hepsi_esit = 1;
    for (size_t t = 0; t < 3; t++) {
        size_t m = boyutlar[t];
        for (int tohum = 1; tohum <= 4; tohum++) {
            rastgele_tohum((uint64_t)tohum);
            rastgele_dizi(a, m, 0, 999);
            long long tc = ters_cevrim_say(a, m);
            kaydirma = 0;
            araya_ekleme_sirala(a, m);
            int esit = tc == kaydirma;
            hepsi_esit = hepsi_esit && esit;
            double beklenen = (double)m * (double)(m - 1) / 4.0;
            printf("%4zu %6d %12lld %10lld  %-5s %.3f\n", m, tohum, tc,
                   kaydirma, esit ? "evet" : "HAYIR",
                   (double)tc / beklenen);
        }
    }
    printf("tüm denemelerde kaydırma = ters çevrim: %s\n",
           hepsi_esit ? "evet" : "HAYIR");

    printf("\n4) sınırlar (n = 1000):");
    for (size_t k = 0; k < 1000; k++) {
        a[k] = (int)(k + 1);
    }
    printf(" sıralı -> %lld,", ters_cevrim_say(a, 1000));
    for (size_t k = 0; k < 1000; k++) {
        a[k] = (int)(1000 - k);
    }
    printf(" ters sıralı -> %lld (n(n-1)/2 = %d)\n",
           ters_cevrim_say(a, 1000), 1000 * 999 / 2);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). O(n log n) sayım:
 * birleştirmeli sıralama sırasında (H6). */

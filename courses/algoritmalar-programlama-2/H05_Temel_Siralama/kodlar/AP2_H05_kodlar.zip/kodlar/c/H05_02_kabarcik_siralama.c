/* H05_02_kabarcik_siralama.c — AP-2 Hafta 5 · Örnek 2 (★)
 * Amaç    : Kabarcık sıralaması: komşu takası ve erken çıkış bayrağı;
 *           kaplumbağa (sonda küçük) ve tavşan (başta büyük) elemanlar
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_02_kabarcik_siralama.c -o H05_02_kabarcik_siralama
 * Çalıştır: ./H05_02_kabarcik_siralama
 * Eşleri  : cpp/H05_02_kabarcik_siralama.cpp
 *           python/H05_02_kabarcik_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

static long long karsilastirma = 0;
static long long takas_sayisi = 0;
static long long gecis_sayisi = 0;

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

/* a[0..n-1]'i yazar; sinir < n ise a[sinir]'dan önce '|' koyar */
static void dizi_yaz(const int *a, size_t n, size_t sinir)
{
    for (size_t k = 0; k < n; k++) {
        if (k == sinir) {
            printf(" |");
        }
        printf("%3d", a[k]);
    }
    printf("\n");
}

static void kabarcik_sirala(int *a, size_t n, int yazdir)
{
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;               /* bu geçişte takas var mı? */
        long long onceki = takas_sayisi;
        for (size_t j = 0; j + 1 < n - i; j++) {
            karsilastirma++;
            if (a[j] > a[j + 1]) {        /* komşular ters sırada */
                takas(&a[j], &a[j + 1]);
                takas_sayisi++;
                takas_oldu = 1;
            }
        }
        gecis_sayisi++;
        if (yazdir) {
            printf("geçiş %lld: karşılaştırma = %zu, takas = %lld\n",
                   gecis_sayisi, n - 1 - i, takas_sayisi - onceki);
            printf("      ");
            dizi_yaz(a, n, n - 1 - i);
        }
        if (!takas_oldu) {
            break;                        /* erken çıkış: dizi sıralı */
        }
    }
}

static void calistir(int *a, size_t n, const char *ad)
{
    karsilastirma = 0;
    takas_sayisi = 0;
    gecis_sayisi = 0;
    kabarcik_sirala(a, n, 0);
    printf("%5lld %6lld %6lld   %s\n", gecis_sayisi, karsilastirma,
           takas_sayisi, ad);
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = sizeof a / sizeof a[0];

    printf("Kabarcık sıralaması, n = %zu ('|' sağı: yerine oturanlar)\n", n);
    printf("başlangıç:\n      ");
    dizi_yaz(a, n, n);
    kabarcik_sirala(a, n, 1);
    printf("toplam: geçiş = %lld, karşılaştırma = %lld, takas = %lld\n",
           gecis_sayisi, karsilastirma, takas_sayisi);

    printf("\nErken çıkış bayrağının etkisi (n = 8):\n");
    printf("geçiş  karş.  takas   girdi\n");
    int sirali[] = {1, 2, 3, 4, 5, 6, 7, 8};
    int neredeyse[] = {1, 2, 4, 3, 5, 6, 8, 7};
    int tavsan[] = {8, 1, 2, 3, 4, 5, 6, 7};
    int kaplumbaga[] = {2, 3, 4, 5, 6, 7, 8, 1};
    int ters[] = {8, 7, 6, 5, 4, 3, 2, 1};
    calistir(sirali, 8, "sıralı");
    calistir(neredeyse, 8, "neredeyse sıralı (iki komşu takası)");
    calistir(tavsan, 8, "tavşan: 8 başta (bir geçişte sona gider)");
    calistir(kaplumbaga, 8, "kaplumbağa: 1 sonda (geçiş başına 1 adım)");
    calistir(ters, 8, "ters sıralı (en kötü durum)");
    printf("en fazla: n - 1 = %d geçiş, n(n-1)/2 = %d karşılaştırma\n",
           8 - 1, 8 * 7 / 2);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (kararsız) ve
 * std::stable_sort; Python — list.sort() / sorted() (yalnızca kâhin). */

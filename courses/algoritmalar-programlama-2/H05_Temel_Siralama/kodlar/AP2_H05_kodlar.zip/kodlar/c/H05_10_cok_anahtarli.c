/* H05_10_cok_anahtarli.c — AP-2 Hafta 5 · Örnek 10 (★★★)
 * Amaç    : Çok anahtarlı sıralama (ortalama azalan, soyad artan, ad
 *           artan): tek karşılaştırıcıyla ve kararlı ardışık geçişlerle
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_10_cok_anahtarli.c -o H05_10_cok_anahtarli
 * Çalıştır: ./H05_10_cok_anahtarli
 * Eşleri  : cpp/H05_10_cok_anahtarli.cpp · python/H05_10_cok_anahtarli.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    int no;
    char ad[16];
    char soyad[16];
    double ortalama;
} Ogrenci;

typedef int (*ogrenci_kars)(const Ogrenci *, const Ogrenci *);

static long long karsilastirma = 0;

static int ortalama_azalan(const Ogrenci *x, const Ogrenci *y)
{
    return (x->ortalama < y->ortalama) - (x->ortalama > y->ortalama);
}

static int soyad_artan(const Ogrenci *x, const Ogrenci *y)
{
    return strcmp(x->soyad, y->soyad);
}

static int ad_artan(const Ogrenci *x, const Ogrenci *y)
{
    return strcmp(x->ad, y->ad);
}

/* Tek karşılaştırıcı: sözlük sırası (önce en önemli anahtar) */
static int cok_anahtarli(const Ogrenci *x, const Ogrenci *y)
{
    int k = ortalama_azalan(x, y);
    if (k != 0) {
        return k;
    }
    k = soyad_artan(x, y);
    if (k != 0) {
        return k;
    }
    return ad_artan(x, y);
}

/* Kararlı: araya ekleme */
static void araya_ekleme_sirala(Ogrenci *a, size_t n, ogrenci_kars kars)
{
    for (size_t i = 1; i < n; i++) {
        Ogrenci anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0) {
            karsilastirma++;
            if (kars(&a[j], &anahtar) <= 0) {
                break;
            }
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

/* Kararsız: seçmeli (karşılaştırma sayılmaz; yalnızca karşıtlık için) */
static void secmeli_sirala(Ogrenci *a, size_t n, ogrenci_kars kars)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en = i;
        for (size_t j = i + 1; j < n; j++) {
            if (kars(&a[j], &a[en]) < 0) {
                en = j;
            }
        }
        if (en != i) {
            Ogrenci gecici = a[i];
            a[i] = a[en];
            a[en] = gecici;
        }
    }
}

/* İki dizi aynı kayıt sırasında mı? (no karşılaştırılır) */
static int ayni_sira(const Ogrenci *a, const Ogrenci *b, size_t n)
{
    for (size_t k = 0; k < n; k++) {
        if (a[k].no != b[k].no) {
            return 0;
        }
    }
    return 1;
}

static void tablo_yaz(const Ogrenci *a, size_t n)
{
    printf("sıra  ortalama   no  soyad, ad\n");
    for (size_t k = 0; k < n; k++) {
        printf("%3zu.  %8.2f  %3d  %s, %s\n", k + 1, a[k].ortalama, a[k].no,
               a[k].soyad, a[k].ad);
    }
}

static void no_yaz(const char *etiket, const Ogrenci *a, size_t n)
{
    printf("%s", etiket);
    for (size_t k = 0; k < n; k++) {
        printf(" %d", a[k].no);
    }
    printf("\n");
}

int main(void)
{
    const Ogrenci girdi[] = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };
    size_t n = sizeof girdi / sizeof girdi[0];
    Ogrenci a[10], b[10], c[10], d[10];

    /* Yöntem A: tek karşılaştırıcı, tek geçiş */
    memcpy(a, girdi, sizeof girdi);
    karsilastirma = 0;
    araya_ekleme_sirala(a, n, cok_anahtarli);
    long long karsilastirma_a = karsilastirma;

    /* Yöntem B: kararlı ardışık geçişler, en önemsizden en önemliye */
    memcpy(b, girdi, sizeof girdi);
    karsilastirma = 0;
    araya_ekleme_sirala(b, n, ad_artan);
    araya_ekleme_sirala(b, n, soyad_artan);
    araya_ekleme_sirala(b, n, ortalama_azalan);
    long long karsilastirma_b = karsilastirma;

    /* Karşıtlık: aynı ardışık geçişler KARARSIZ sıralamayla */
    memcpy(c, girdi, sizeof girdi);
    secmeli_sirala(c, n, ad_artan);
    secmeli_sirala(c, n, soyad_artan);
    secmeli_sirala(c, n, ortalama_azalan);

    /* Tam karşılaştırıcıyla kararsız sıralama da doğru sonuç verir */
    memcpy(d, girdi, sizeof girdi);
    secmeli_sirala(d, n, cok_anahtarli);

    printf("Sıralama ölçütü: ortalama azalan, soyad artan, ad artan\n\n");
    printf("A) tek karşılaştırıcı (araya ekleme, 1 geçiş):\n");
    tablo_yaz(a, n);
    printf("\nB) kararlı ardışık geçişler: ad -> soyad -> ortalama\n");
    no_yaz("   B sırası:", b, n);
    printf("   A ile aynı mı? %s\n", ayni_sira(a, b, n) ? "evet" : "HAYIR");
    printf("   karşılaştırma: A = %lld (1 geçiş), B = %lld (3 geçiş)\n",
           karsilastirma_a, karsilastirma_b);
    printf("\nC) aynı ardışık geçişler, kararsız seçmeli sıralamayla:\n");
    no_yaz("   C sırası:", c, n);
    printf("   A ile aynı mı? %s\n", ayni_sira(a, c, n) ? "evet" : "HAYIR");
    printf("\nD) tek (tam) karşılaştırıcı, kararsız seçmeli sıralamayla:\n");
    no_yaz("   D sırası:", d, n);
    printf("   A ile aynı mı? %s (tam sıralamada kararlılık gerekmez)\n",
           ayni_sira(a, d, n) ? "evet" : "HAYIR");
    printf("\nNot: bu verideki ad/soyadlar ilk farklı harfte ASCII; Türkçe\n"
           "harfte strcmp bayt sırası yanıltır (Hata Avcısı 8).\n");
    return 0;
}

/* Kütüphane karşılığı: C — qsort + cok_anahtarli (void * sarmalayıcı);
 * C++ — std::sort + çok anahtarlı yüklem ya da std::stable_sort
 * geçişleri; Python — sorted(a, key=lambda o: (-o.ortalama, o.soyad,
 * o.ad)). */

/* H05_08_yapi_siralama.c — AP-2 Hafta 5 · Örnek 8 (★★)
 * Amaç    : Yapı dizisini ortalamaya göre azalan sıralama: yapı
 *           karşılaştırıcısı + kendi araya ekleme sıralamamız
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_08_yapi_siralama.c -o H05_08_yapi_siralama
 * Çalıştır: ./H05_08_yapi_siralama
 * Eşleri  : cpp/H05_08_yapi_siralama.cpp · python/H05_08_yapi_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

typedef struct {
    int no;
    char ad[16];
    char soyad[16];
    double ortalama;
} Ogrenci;

typedef int (*ogrenci_kars)(const Ogrenci *, const Ogrenci *);

static long long karsilastirma = 0;

/* < 0: x önce, > 0: y önce, 0: eşit (sıra korunur) — ortalama azalan */
static int ortalama_azalan(const Ogrenci *x, const Ogrenci *y)
{
    return (x->ortalama < y->ortalama) - (x->ortalama > y->ortalama);
}

/* Araya ekleme: kars(a[j], anahtar) > 0 oldukça kaydır (kararlı) */
static void ogrenci_sirala(Ogrenci *a, size_t n, ogrenci_kars kars)
{
    for (size_t i = 1; i < n; i++) {
        Ogrenci anahtar = a[i];             /* yapı ataması: kopya */
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0) {
            karsilastirma++;
            if (kars(&a[j], &anahtar) <= 0) {
                break;
            }
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

/* Komşu eşit ortalamalılarda no artıyor mu? (no = kayıt sırası) */
static int kayit_sirasi_korundu(const Ogrenci *a, size_t n)
{
    for (size_t k = 1; k < n; k++) {
        if (a[k - 1].ortalama == a[k].ortalama && a[k - 1].no > a[k].no) {
            return 0;
        }
    }
    return 1;
}

static void tablo_yaz(const Ogrenci *a, size_t n)
{
    printf("sıra  ortalama   no  ad soyad\n");
    for (size_t k = 0; k < n; k++) {
        printf("%3zu.  %8.2f  %3d  %s %s\n", k + 1, a[k].ortalama, a[k].no,
               a[k].ad, a[k].soyad);
    }
}

int main(void)
{
    Ogrenci a[] = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };
    size_t n = sizeof a / sizeof a[0];

    printf("Girdi (kayıt sırası):\n");
    tablo_yaz(a, n);
    ogrenci_sirala(a, n, ortalama_azalan);
    printf("\nOrtalamaya göre azalan (araya ekleme, karşılaştırıcıyla):\n");
    tablo_yaz(a, n);
    printf("karşılaştırma = %lld\n", karsilastirma);
    printf("eşit ortalamalılarda kayıt sırası (no artan) korundu mu? %s\n",
           kayit_sirasi_korundu(a, n) ? "evet" : "hayır");
    return 0;
}

/* Kütüphane karşılığı: C — qsort(a, n, sizeof a[0], kars_void);
 * C++ — std::stable_sort + lambda; Python — sorted(a, key=…). */

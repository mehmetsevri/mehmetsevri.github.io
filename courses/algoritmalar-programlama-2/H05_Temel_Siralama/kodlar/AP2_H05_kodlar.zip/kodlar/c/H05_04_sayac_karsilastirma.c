/* H05_04_sayac_karsilastirma.c — AP-2 Hafta 5 · Örnek 4 (★★)
 * Amaç    : Üç algoritmanın karşılaştırma ve takas/kaydırma sayıları:
 *           rastgele, sıralı ve ters sıralı girdi; kuramsal formüllerle
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_04_sayac_karsilastirma.c ortak_rastgele.c \
 *           -o H05_04_sayac_karsilastirma
 * Çalıştır: ./H05_04_sayac_karsilastirma
 * Eşleri  : cpp/H05_04_sayac_karsilastirma.cpp
 *           python/H05_04_sayac_karsilastirma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS_N 1000

static long long karsilastirma = 0;
static long long takas_sayisi = 0;
static long long kaydirma = 0;

static void sayaclari_sifirla(void)
{
    karsilastirma = 0;
    takas_sayisi = 0;
    kaydirma = 0;
}

/* s'yi yazar; görünen genişlik (UTF-8 kod noktası) g olana dek boşluk */
static void sola_yasla(const char *s, int g)
{
    int uzunluk = 0;
    for (const char *p = s; *p != '\0'; p++) {
        if (((unsigned char)*p & 0xC0) != 0x80) {
            uzunluk++;
        }
    }
    printf("%s%*s", s, g > uzunluk ? g - uzunluk : 0, "");
}

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

static void secmeli_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en_kucuk = i;
        for (size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            takas(&a[i], &a[en_kucuk]);
            takas_sayisi++;
        }
    }
}

static void kabarcik_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;
        for (size_t j = 0; j + 1 < n - i; j++) {
            karsilastirma++;
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
                takas_sayisi++;
                takas_oldu = 1;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
}

static int buyuk_mu(int x, int y)
{
    karsilastirma++;
    return x > y;
}

static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && buyuk_mu(a[j], anahtar)) {
            a[j + 1] = a[j];
            kaydirma++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

/* Ters çevrim sayısı: i < j ve a[i] > a[j] olan çiftler (kaba kuvvet) */
static long long ters_cevrim(const int *a, size_t n)
{
    long long sayi = 0;
    for (size_t i = 0; i < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                sayi++;
            }
        }
    }
    return sayi;
}

/* Soldan sağa yeni en küçük sayısı (a[0] hariç): araya eklemede j = -1 */
static long long basa_yerlesen(const int *a, size_t n)
{
    long long sayi = 0;
    for (size_t i = 1; i < n; i++) {
        int en_kucuk_mu = 1;
        for (size_t k = 0; k < i; k++) {
            if (a[k] <= a[i]) {
                en_kucuk_mu = 0;
            }
        }
        sayi += en_kucuk_mu;
    }
    return sayi;
}

static void girdi_hazirla(int *a, size_t n, int tur)
{
    for (size_t i = 0; i < n; i++) {
        a[i] = tur == 2 ? (int)(n - i) : (int)(i + 1);  /* 2: ters */
    }
    if (tur == 0) {                                    /* 0: rastgele */
        rastgele_tohum(42);
        rastgele_karistir(a, n);
    }
}

static void deney(size_t n)
{
    static const char *const girdi_adi[] = {"rastgele", "sıralı",
                                            "ters sıralı"};
    static const char *const algo_adi[] = {"seçmeli", "kabarcık",
                                           "araya ekleme"};
    int girdi[MAKS_N];
    int a[MAKS_N];
    long long en_cok = (long long)n * (long long)(n - 1) / 2;

    printf("\nn = %zu   n(n-1)/2 = %lld   n(n-1)/4 = %.2f\n", n, en_cok,
           (double)en_cok / 2.0);
    printf("algoritma     girdi         karşılaştırma  takas  kaydırma\n");
    for (int alg = 0; alg < 3; alg++) {
        for (int tur = 0; tur < 3; tur++) {
            girdi_hazirla(girdi, n, tur);
            memcpy(a, girdi, n * sizeof a[0]);
            sayaclari_sifirla();
            if (alg == 0) {
                secmeli_sirala(a, n);
            } else if (alg == 1) {
                kabarcik_sirala(a, n);
            } else {
                araya_ekleme_sirala(a, n);
            }
            sola_yasla(algo_adi[alg], 14);
            sola_yasla(girdi_adi[tur], 13);
            printf("%14lld %6lld %9lld\n", karsilastirma, takas_sayisi,
                   kaydirma);
        }
    }
    printf("kuram denetimi (rastgele girdi):\n");
    girdi_hazirla(girdi, n, 0);
    long long tc = ters_cevrim(girdi, n);
    long long z = basa_yerlesen(girdi, n);
    printf("  ters çevrim = %lld  (beklenen değer n(n-1)/4 = %.2f)\n", tc,
           (double)en_cok / 2.0);
    memcpy(a, girdi, n * sizeof a[0]);
    sayaclari_sifirla();
    kabarcik_sirala(a, n);
    printf("  kabarcık takas = ters çevrim: %s\n",
           takas_sayisi == tc ? "evet" : "HAYIR");
    memcpy(a, girdi, n * sizeof a[0]);
    sayaclari_sifirla();
    araya_ekleme_sirala(a, n);
    printf("  araya ekleme kaydırma = ters çevrim: %s\n",
           kaydirma == tc ? "evet" : "HAYIR");
    long long beklenen = kaydirma + (long long)(n - 1) - z;
    printf("  araya ekleme karşılaştırma = kaydırma + (n-1) - z\n");
    printf("    = %lld + %zu - %lld = %lld: %s\n", kaydirma, n - 1, z,
           beklenen, karsilastirma == beklenen ? "evet" : "HAYIR");
}

int main(void)
{
    printf("Karşılaştırma ve takas/kaydırma sayaçları\n");
    printf("rastgele: 1..n karıştırılmış (ortak LCG, tohum 42)\n");
    printf("z: araya eklemede başa (a[0]'a) yerleşen anahtar sayısı\n");
    deney(100);
    deney(1000);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — list.sort()
 * / sorted(). Kütüphane sıralamalarının sayaçları gerçekleştirime bağlıdır.
 */

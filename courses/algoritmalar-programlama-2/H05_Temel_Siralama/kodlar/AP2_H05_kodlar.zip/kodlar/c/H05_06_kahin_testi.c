/* H05_06_kahin_testi.c — AP-2 Hafta 5 · Örnek 6 (★★)
 * Amaç    : "Dizi sıralı mı?" denetimi ve kütüphane sıralamasıyla kâhin
 *           testi: özel diziler + rastgele diziler (deterministik özet)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_06_kahin_testi.c ortak_rastgele.c -o H05_06_kahin_testi
 * Çalıştır: ./H05_06_kahin_testi
 * Eşleri  : cpp/H05_06_kahin_testi.cpp · python/H05_06_kahin_testi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS_N 32

typedef void (*siralayici)(int *, size_t);

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

static void secmeli_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en_kucuk = i;
        for (size_t j = i + 1; j < n; j++) {
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            takas(&a[i], &a[en_kucuk]);
        }
    }
}

static void kabarcik_sirala(int *a, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;
        for (size_t j = 0; j + 1 < n - i; j++) {
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
                takas_oldu = 1;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
}

static void araya_ekleme_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        int anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && a[j] > anahtar) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

/* HATALI "sıralama": a[i] yerine a[0..i]'nin en büyüğünü yazar.
 * Sonuç her zaman sıralıdır ama girdinin permütasyonu olmayabilir. */
static void sahte_sirala(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++) {
        if (a[i] < a[i - 1]) {
            a[i] = a[i - 1];
        }
    }
}

/* a[0..n-1] azalmayan sırada mı? (n - 1 karşılaştırma) */
static int sirali_mi(const int *a, size_t n)
{
    for (size_t k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

/* qsort karşılaştırıcısı: taşmaya güvenli (bkz. Örnek 7) */
static int int_karsilastir(const void *p, const void *q)
{
    int x = *(const int *)p;
    int y = *(const int *)q;
    return (x > y) - (x < y);
}

/* Kâhin: kütüphane sıralamasının sonucu (yalnızca test için) */
static void kahin(const int *girdi, size_t n, int *beklenen)
{
    memcpy(beklenen, girdi, n * sizeof girdi[0]);
    qsort(beklenen, n, sizeof beklenen[0], int_karsilastir);
}

/* s'yi yazar; görünen genişlik (UTF-8 kod noktası) g olana dek boşluk */
static void sola_yasla(const char *s, int g)
{
    int uzunluk = 0;
    for (const char *p = s; *p != '\0'; p++) {
        if (((unsigned char)*p & 0xC0) != 0x80) {
            uzunluk++;
        }
    }
    printf("%s%*s", s, g > uzunluk ? g - uzunluk : 0, "");
}

static void dizi_yaz(const int *a, size_t n)
{
    printf("[");
    for (size_t k = 0; k < n; k++) {
        printf(k ? " %d" : "%d", a[k]);
    }
    printf("]");
}

/* Test kümesi: 8 özel dizi + n = 0..30 için 20'şer rastgele dizi */
static size_t dizi_uret(size_t t, int *a)
{
    static const int ozel[] = {5, 2, 1, 1, 2, 3, 3, 3, 5, 4, 3, 2, 1,
                               1, 2, 3, 4, 5, -3, 0, -3, INT_MAX,
                               INT_MIN};
    static const size_t boy[] = {0, 1, 2, 2, 3, 5, 5, 5};
    if (t < 8) {
        size_t bas = 0;
        for (size_t k = 0; k < t; k++) {
            bas += boy[k];
        }
        memcpy(a, ozel + bas, boy[t] * sizeof a[0]);
        return boy[t];
    }
    size_t n = (t - 8) / 20;                 /* 0, 1, ..., 30 */
    if ((t - 8) % 2 == 0) {
        rastgele_dizi(a, n, 0, 9);           /* çok yinelenen */
    } else {
        rastgele_dizi(a, n, -1000, 1000);
    }
    return n;
}

int main(void)
{
    const char *const adlar[] = {"seçmeli", "kabarcık", "araya ekleme",
                                 "sahte (hatalı)"};
    siralayici fonksiyonlar[] = {secmeli_sirala, kabarcik_sirala,
                                 araya_ekleme_sirala, sahte_sirala};
    size_t test_sayisi = 8 + 31 * 20;
    int girdi[MAKS_N], a[MAKS_N], beklenen[MAKS_N];
    int hata_girdi[MAKS_N], hata_cikti[MAKS_N], hata_kahin[MAKS_N];
    size_t hata_n = 0;
    int hata_var = 0;

    printf("Kâhin testi: kendi sıralamalarımız ve kütüphane sıralaması\n");
    printf("(kâhin: C qsort, C++ std::sort, Python sorted)\n");
    printf("test kümesi: 8 özel dizi + n = 0..30 için 20'şer rastgele "
           "dizi = %zu dizi\n\n", test_sayisi);
    printf("algoritma          sıralı mı  kâhinle aynı\n");
    for (int f = 0; f < 4; f++) {
        size_t sirali = 0, ayni = 0;
        rastgele_tohum(2026);        /* her algoritmaya aynı diziler */
        for (size_t t = 0; t < test_sayisi; t++) {
            size_t n = dizi_uret(t, girdi);
            memcpy(a, girdi, n * sizeof a[0]);
            fonksiyonlar[f](a, n);
            kahin(girdi, n, beklenen);
            sirali += (size_t)sirali_mi(a, n);
            int esit = memcmp(a, beklenen, n * sizeof a[0]) == 0;
            ayni += (size_t)esit;
            if (!esit && !hata_var) {        /* ilk yakalanan hata */
                hata_var = 1;
                hata_n = n;
                memcpy(hata_girdi, girdi, n * sizeof a[0]);
                memcpy(hata_cikti, a, n * sizeof a[0]);
                memcpy(hata_kahin, beklenen, n * sizeof a[0]);
            }
        }
        sola_yasla(adlar[f], 15);
        printf("%9zu/%zu %10zu/%zu\n", sirali, test_sayisi, ayni,
               test_sayisi);
    }
    if (hata_var) {
        printf("\nkâhinin yakaladığı ilk hata:\n  girdi  ");
        dizi_yaz(hata_girdi, hata_n);
        printf("\n  çıktı  ");
        dizi_yaz(hata_cikti, hata_n);
        printf("  sıralı mı: %s\n  kâhin  ",
               sirali_mi(hata_cikti, hata_n) ? "evet" : "hayır");
        dizi_yaz(hata_kahin, hata_n);
        printf("\n");
    }
    printf("\nSonuç: \"sıralı mı?\" tek başına yetmez; çıktı girdinin "
           "permütasyonu da olmalı.\n");
    return 0;
}

/* Kütüphane karşılığı (burada kâhin): C — qsort; C++ — std::sort;
 * Python — sorted(a). */

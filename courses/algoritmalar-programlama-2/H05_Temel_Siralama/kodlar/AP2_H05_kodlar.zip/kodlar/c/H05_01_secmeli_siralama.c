/* H05_01_secmeli_siralama.c — AP-2 Hafta 5 · Örnek 1 (★)
 * Amaç    : Seçmeli sıralama; her geçişten sonra dizi ve değişmez:
 *           a[0..i] sıralıdır ve dizinin en küçük i + 1 elemanını içerir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_01_secmeli_siralama.c -o H05_01_secmeli_siralama
 * Çalıştır: ./H05_01_secmeli_siralama
 * Eşleri  : cpp/H05_01_secmeli_siralama.cpp
 *           python/H05_01_secmeli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

static long long karsilastirma = 0;
static long long takas_sayisi = 0;

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

/* a[0..n-1]'i yazar; sinir < n ise a[sinir]'dan önce '|' koyar */
static void dizi_yaz(const int *a, size_t n, size_t sinir)
{
    for (size_t k = 0; k < n; k++) {
        if (k == sinir) {
            printf(" |");
        }
        printf("%3d", a[k]);
    }
    printf("\n");
}

/* Değişmez: a[0..s-1] sıralı ve a[0..s-1] <= a[s..n-1] (her eleman) */
static int degismez_tamam_mi(const int *a, size_t n, size_t s)
{
    for (size_t k = 1; k < s; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    for (size_t k = s; s > 0 && k < n; k++) {
        if (a[s - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

static void gecis_yaz(const int *a, size_t n, size_t i, size_t en_kucuk)
{
    printf("i = %zu: en küçük a[%zu] = %2d, ", i, en_kucuk, a[i]);
    if (en_kucuk != i) {
        printf("takas a[%zu] <-> a[%zu]\n", i, en_kucuk);
    } else {
        printf("takas yok\n");
    }
    printf("      ");
    dizi_yaz(a, n, i + 1);
    printf("      değişmez: %s\n",
           degismez_tamam_mi(a, n, i + 1) ? "evet" : "HAYIR");
}

static void secmeli_sirala(int *a, size_t n, int yazdir)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en_kucuk = i;
        for (size_t j = i + 1; j < n; j++) {
            karsilastirma++;
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        if (en_kucuk != i) {
            takas(&a[i], &a[en_kucuk]);
            takas_sayisi++;
        }
        if (yazdir) {
            gecis_yaz(a, n, i, en_kucuk);
        }
    }
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 39, 12};
    size_t n = sizeof a / sizeof a[0];

    printf("Seçmeli sıralama, n = %zu ('|' solu: sıralı önek)\n", n);
    printf("başlangıç:\n      ");
    dizi_yaz(a, n, n);
    secmeli_sirala(a, n, 1);
    printf("sonuç:\n      ");
    dizi_yaz(a, n, n);
    printf("karşılaştırma = %lld   n(n-1)/2 = %zu\n", karsilastirma,
           n * (n - 1) / 2);
    printf("takas = %lld   (en fazla n - 1 = %zu)\n", takas_sayisi, n - 1);

    printf("\nKenar durumları (i + 1 < n koşulu; n - 1 taşmaz):\n");
    int bir[] = {7};
    for (size_t boyut = 0; boyut <= 1; boyut++) {
        karsilastirma = 0;
        takas_sayisi = 0;
        secmeli_sirala(bir, boyut, 0);
        printf("n = %zu: karşılaştırma = %lld, takas = %lld\n", boyut,
               karsilastirma, takas_sayisi);
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritma belirtilmez); C++ —
 * std::sort; Python — list.sort() / sorted() (yalnızca kâhin). */

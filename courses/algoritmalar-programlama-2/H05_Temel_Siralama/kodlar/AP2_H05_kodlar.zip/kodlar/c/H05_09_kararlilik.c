/* H05_09_kararlilik.c — AP-2 Hafta 5 · Örnek 9 (★★)
 * Amaç    : Kararlılık deneyi: eşit ortalamalı kayıtlarda seçmeli
 *           (kararsız) ve araya ekleme / kabarcık (kararlı) sıralama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H05_09_kararlilik.c -o H05_09_kararlilik
 * Çalıştır: ./H05_09_kararlilik
 * Eşleri  : cpp/H05_09_kararlilik.cpp · python/H05_09_kararlilik.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    int no;                 /* kayıt sırası etiketi: 101, 102, ... */
    char ad[16];
    char soyad[16];
    double ortalama;
} Ogrenci;

typedef int (*ogrenci_kars)(const Ogrenci *, const Ogrenci *);
typedef void (*ogrenci_siralayici)(Ogrenci *, size_t, ogrenci_kars);

static int ortalama_azalan(const Ogrenci *x, const Ogrenci *y)
{
    return (x->ortalama < y->ortalama) - (x->ortalama > y->ortalama);
}

static void ogrenci_takas(Ogrenci *x, Ogrenci *y)
{
    Ogrenci gecici = *x;
    *x = *y;
    *y = gecici;
}

static void secmeli_sirala(Ogrenci *a, size_t n, ogrenci_kars kars)
{
    for (size_t i = 0; i + 1 < n; i++) {
        size_t en = i;                      /* sırada önce gelecek olan */
        for (size_t j = i + 1; j < n; j++) {
            if (kars(&a[j], &a[en]) < 0) {
                en = j;
            }
        }
        if (en != i) {
            ogrenci_takas(&a[i], &a[en]);   /* uzak takas: sırayı bozar */
        }
    }
}

static void kabarcik_sirala(Ogrenci *a, size_t n, ogrenci_kars kars)
{
    for (size_t i = 0; i + 1 < n; i++) {
        int takas_oldu = 0;
        for (size_t j = 0; j + 1 < n - i; j++) {
            if (kars(&a[j], &a[j + 1]) > 0) {  /* eşitse takas YOK */
                ogrenci_takas(&a[j], &a[j + 1]);
                takas_oldu = 1;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
}

static void araya_ekleme_sirala(Ogrenci *a, size_t n, ogrenci_kars kars)
{
    for (size_t i = 1; i < n; i++) {
        Ogrenci anahtar = a[i];
        ptrdiff_t j = (ptrdiff_t)i - 1;
        while (j >= 0 && kars(&a[j], &anahtar) > 0) {  /* eşitse dur */
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

/* Eşit anahtarlı olup kayıt sırası bozulan çiftleri yazar; sayısını
 * döndürür (çift: çıktıda önce gelen no, sonra gelen no) */
static int bozulan_ciftler(const Ogrenci *a, size_t n)
{
    int sayi = 0;
    for (size_t i = 0; i < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (a[i].ortalama == a[j].ortalama && a[i].no > a[j].no) {
                printf(sayi % 6 == 0 ? "\n    (%d önce, %d sonra)"
                                     : " (%d önce, %d sonra)",
                       a[i].no, a[j].no);
                sayi++;
            }
        }
    }
    return sayi;
}

static void sonuc_yaz(const char *ad, const Ogrenci *a, size_t n,
                      int denetle)
{
    printf("%s:\n   ", ad);
    for (size_t k = 0; k < n; k++) {
        printf(" %.2f(%d)", a[k].ortalama, a[k].no);
        if (k == 4) {
            printf("\n   ");
        }
    }
    printf("\n");
    if (!denetle) {
        return;
    }
    printf("   bozulan eşit çiftler:");
    int sayi = bozulan_ciftler(a, n);
    if (sayi == 0) {
        printf(" yok");
    }
    printf("\n   kararlı davrandı mı? %s (%d çift)\n",
           sayi == 0 ? "evet" : "HAYIR", sayi);
}

int main(void)
{
    const Ogrenci girdi[] = {
        {101, "Ayşe", "Yılmaz", 78.50}, {102, "Mehmet", "Kaya", 65.25},
        {103, "Zeynep", "Demir", 78.50}, {104, "Can", "Yılmaz", 90.00},
        {105, "Elif", "Kaya", 78.50},   {106, "Burak", "Demir", 65.25},
        {107, "Ali", "Yılmaz", 78.50},  {108, "Deniz", "Arslan", 90.00},
        {109, "Emre", "Kaya", 65.25},   {110, "Selin", "Demir", 78.50},
    };
    size_t n = sizeof girdi / sizeof girdi[0];
    const char *const adlar[] = {"seçmeli", "kabarcık", "araya ekleme"};
    ogrenci_siralayici f[] = {secmeli_sirala, kabarcik_sirala,
                              araya_ekleme_sirala};
    Ogrenci a[10];

    printf("Kararlılık: ortalamaya göre azalan; parantez içi kayıt no\n");
    printf("(kararlı sıralama eşit ortalamalılarda no artan sırayı korur)\n");
    sonuc_yaz("girdi", girdi, n, 0);
    for (int k = 0; k < 3; k++) {
        memcpy(a, girdi, sizeof girdi);
        f[k](a, n, ortalama_azalan);
        printf("\n");
        sonuc_yaz(adlar[k], a, n, 1);
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (kararlılık güvencesi YOK); C++ —
 * std::stable_sort (kararlı), std::sort (kararsız); Python — sorted
 * ve list.sort (Timsort, kararlı). */

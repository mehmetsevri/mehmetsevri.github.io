"""H02_01_dogrusal_toplam.py — AP-2 Hafta 2 · Örnek 1 (★)
Amaç    : İşlem sayacıyla doğrusal toplamda T(n) = n'in gözlenmesi;
          temel işlem seçimi sabiti değiştirir, büyüme sınıfını değil
Çalıştır: python3 H02_01_dogrusal_toplam.py
Eşleri  : c/H02_01_dogrusal_toplam.c · cpp/H02_01_dogrusal_toplam.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_tohum, rastgele_dizi

N_AZAMI = 100000


def dogrusal_toplam(a, n):
    """a[0..n-1] toplamı ve temel işlem (toplama) sayısı."""
    toplam = 0
    islem = 0
    for i in range(n):
        toplam += a[i]
        islem += 1                  # temel işlem: bir toplama
    return toplam, islem


def ayrintili_sayim(a, n):
    """Aynı döngü; RAM modelinde her ilkel adım sayılır."""
    toplam = 0
    adim = 2                        # toplam = 0 ve i = 0: 2 atama
    for i in range(n):
        toplam += a[i]
        adim += 3                   # i < n sınaması, toplama, i++
    adim += 1                       # döngüyü bitiren son i < n
    return toplam, adim


def main():
    boyutlar = [0, 1, 10, 100, 1000, 10000, 100000]
    rastgele_tohum(42)
    a = rastgele_dizi(N_AZAMI, 0, 99)

    print("Doğrusal toplam (a[i] değerleri 0..99, tohum 42)")
    print("a[0..9] =", " ".join(str(x) for x in a[:10]))
    print()
    print("       n      toplam   toplama  =n?     ayrıntılı  =3n+3?")
    for n in boyutlar:
        toplam, islem = dogrusal_toplam(a, n)
        _, adim = ayrintili_sayim(a, n)
        ok1 = "evet" if islem == n else "HAYIR"
        ok2 = "evet" if adim == 3 * n + 3 else "HAYIR"
        print(f"{n:8d} {toplam:11d} {islem:9d}  {ok1:<5} {adim:11d}  {ok2}")
    print()
    print("Toplama sayısı her n için tam n: T(n) = n.")
    print("Ayrıntılı sayım 3n + 3; ikisi de Θ(n): temel işlem seçimi")
    print("yalnızca sabit çarpanı değiştirir.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle döngü); C++ — std::accumulate;
# Python — sum(a)

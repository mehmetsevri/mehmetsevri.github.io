"""H02_08_deneme_bolmesi.py — AP-2 Hafta 2 · Örnek 8 (★★)
Amaç    : Deneme bölmesiyle asallık; √n sınırı i * i <= n ile (kayan
          nokta yok, taşma gerekçeli) ve 2..n-1 saf sürümle karşılaştırma
Çalıştır: python3 H02_08_deneme_bolmesi.py
Eşleri  : c/H02_08_deneme_bolmesi.c · cpp/H02_08_deneme_bolmesi.cpp
Çıktı   : üç dilde aynı (=)
"""

SAF_SINIR = 2000000


# n asal mı? Bölen adayları i = 2, 3, ... ve i * i <= n.
# Python tamsayısı taşmaz; C'deki ön koşul (n < 2^63) burada gerekmez.
# Döndürür: (asal mı, yapılan kalan (%) işlemi sayısı).
def asal_mi(n):
    bolme = 0
    if n < 2:
        return False, bolme
    i = 2
    while i * i <= n:
        bolme += 1
        if n % i == 0:
            return False, bolme  # i böler
        i += 1
    return True, bolme


def asal_mi_saf(n):
    """Saf sürüm: 2 .. n-1 arasındaki tüm adaylar."""
    bolme = 0
    if n < 2:
        return False, bolme
    for i in range(2, n):
        bolme += 1
        if n % i == 0:
            return False, bolme
    return True, bolme


def main():
    ornekler = [
        1, 2, 4, 17, 25, 91, 97, 7919, 999999, 1000003, 2147483647,
        1000000007, 1000036000099, 999999999989
    ]

    parca = "İzleme n = 91: aday"
    i = 2
    while i * i <= 91:
        parca += f" {i}"
        if 91 % i == 0:
            parca += f" -> {i} böler, 91 = {i} * {91 // i}"
            break
        i += 1
    print(parca)
    print("İzleme n = 97: aday 2..9 (10 * 10 > 97), hiçbiri bölmez\n")

    print("                   n  asal  bölme(√n)  bölme(saf)")
    for n in ornekler:
        a, b1 = asal_mi(n)
        satir = f"{n:20d}  {'evet ' if a else 'hayır'} {b1:9d}"
        if n <= SAF_SINIR:
            s, b2 = asal_mi_saf(n)
            satir += f" {b2:11d}" + ("" if s == a else "  UYUŞMAZ")
        else:
            satir += f" {'-':>11}"
        print(satir)
    print("\nAsal n için √n sürüm ⌊√n⌋ - 1 bölme yapar, saf sürüm n - 2.")
    print("Bileşik n'de ikisi de en küçük bölende durur (en iyi durum:")
    print("çift n, 1 bölme). En kötü durum O(√n).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok;
# Python — yok (sympy.isprime üçüncü taraf; kullanılmaz)

"""H02_06_buyume_tablosu.py — AP-2 Hafta 2 · Örnek 6 (★★)
Amaç    : Büyüme sınıflarının (log n ... n!) sayısal karşılaştırması ve
          "1 saniyede çözülebilecek en büyük n" uygulanabilirlik tablosu
Çalıştır: python3 H02_06_buyume_tablosu.py [islem_hizi]
          (varsayılan 100000000)
Eşleri  : c/H02_06_buyume_tablosu.c · cpp/H02_06_buyume_tablosu.cpp
Çıktı   : üç dilde aynı (=)
"""
import math
import sys


def deger_yaz(deger, lg):
    """f(n)'yi 12 sütunda yazar; double'a sığmayan (log10 >= 308) değer
    10^k biçiminde: değer 10^k ile 10^(k+1) arasındadır."""
    if lg < 308.0:
        return f" {deger:11.3e}"
    return f" {'10^' + str(math.floor(lg)):>11}"


def iki_us_yaz(n):
    """2^n: log10(2^n) = n log10(2); sığıyorsa ikiye katlayarak kesin.
    Not: 2.0 ** 10000 Python'da OverflowError verir (C'de inf olur)."""
    lg = float(n) * math.log10(2.0)
    d = 1.0
    if lg < 308.0:
        for i in range(n):
            d *= 2.0
    return deger_yaz(d, lg)


def faktoriyel_yaz(n):
    """n!: log10(n!) = log10(2) + log10(3) + ... + log10(n)."""
    lg = 0.0
    for k in range(2, n + 1):
        lg += math.log10(float(k))
    d = 1.0
    if lg < 308.0:
        for k in range(2, n + 1):
            d *= float(k)
    return deger_yaz(d, lg)


def en_buyuk_kuvvet(butce, k):
    """n^k <= butce olan en büyük n (k = 2, 3)."""
    n = 0
    while True:
        m = n + 1
        deger = 1
        for i in range(k):
            deger *= m
        if deger > butce:
            return n
        n = m


def en_buyuk_nlogn(butce):
    """n log2 n <= butce olan en büyük n: ikiye katla, sonra ikili ara."""
    def f(n):
        return float(n) * math.log2(float(n))
    lo, hi = 1, 2
    while f(hi) <= float(butce):
        lo = hi
        hi *= 2
    while hi - lo > 1:                  # f(lo) <= butce < f(hi)
        orta = lo + (hi - lo) // 2
        if f(orta) <= float(butce):
            lo = orta
        else:
            hi = orta
    return lo


def main():
    boyutlar = [10, 100, 1000, 10000, 100000, 1000000]
    butce = 100000000
    if len(sys.argv) > 2:
        print(f"Kullanım: {sys.argv[0]} [islem_hizi]", file=sys.stderr)
        sys.exit(2)
    if len(sys.argv) == 2:
        try:
            butce = int(sys.argv[1])
        except ValueError:
            butce = 0
        if butce < 1 or butce > 1000000000:
            print("islem_hizi 1..1000000000 olmalı", file=sys.stderr)
            sys.exit(2)

    print("Büyüme tablosu (log tabanı 2; 10^k: double'a sığmaz,"
          " 10^k ile 10^(k+1) arası)")
    print("f(n)   " + "".join(f" {n:11d}" for n in boyutlar))
    print("log n  " + "".join(f" {math.log2(float(n)):11.3e}"
                              for n in boyutlar))
    print("√n     " + "".join(f" {math.sqrt(float(n)):11.3e}"
                              for n in boyutlar))
    print("n      " + "".join(f" {float(n):11.3e}" for n in boyutlar))
    print("n log n" + "".join(f" {n * math.log2(float(n)):11.3e}"
                              for n in boyutlar))
    print("n²     " + "".join(f" {float(n) * float(n):11.3e}"
                              for n in boyutlar))
    print("n³     " + "".join(f" {float(n) * float(n) * float(n):11.3e}"
                              for n in boyutlar))
    print("2^n    " + "".join(iki_us_yaz(n) for n in boyutlar))
    print("n!     " + "".join(faktoriyel_yaz(n) for n in boyutlar))

    print("\n1 saniyede çözülebilecek en büyük n"
          f" (saniyede {butce} temel işlem)")
    print(f"log n    2^{butce}")
    print(f"√n       {butce * butce}")
    print(f"n        {butce}")
    print(f"n log n  {en_buyuk_nlogn(butce)}")
    print(f"n²       {en_buyuk_kuvvet(butce, 2)}")
    print(f"n³       {en_buyuk_kuvvet(butce, 3)}")
    n = 0
    while (1 << (n + 1)) <= butce:
        n += 1
    print(f"2^n      {n}")
    f = 1
    n = 0
    while f * (n + 1) <= butce:
        n += 1
        f *= n
    print(f"n!       {n}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — log2, sqrt, lgamma (math.h);
# C++ — std::log2, std::lgamma; Python — math.log2, math.lgamma

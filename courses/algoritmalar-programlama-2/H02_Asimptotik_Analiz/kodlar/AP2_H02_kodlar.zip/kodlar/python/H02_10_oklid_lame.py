"""H02_10_oklid_lame.py — AP-2 Hafta 2 · Örnek 10 (★★★)
Amaç    : Öklid algoritmasında adım (mod) sayısı; ardışık Fibonacci
          sayılarının en kötü durum olması (Lamé) — tablo ve tam tarama
Çalıştır: python3 H02_10_oklid_lame.py
Eşleri  : c/H02_10_oklid_lame.c · cpp/H02_10_oklid_lame.cpp
Çıktı   : üç dilde aynı (=)
"""

TARAMA = 500


def ebob(a, b):
    """ebob(a, b), a >= b >= 0: (ebob, kalan (mod) işlemi sayısı)."""
    adim = 0
    while b != 0:
        a, b = b, a % b
        adim += 1
    return a, adim


def ebob_izle(a, b):
    """Her adımı a = q * b + r biçiminde yazar."""
    while b != 0:
        print(f"  {a} = {a // b} * {b} + {a % b}")
        a, b = b, a % b
    print(f"  ebob = {a}")


def basamak(x):
    """Ondalık basamak sayısı."""
    d = 1
    while x >= 10:
        x //= 10
        d += 1
    return d


def main():
    satirlar = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
                20, 30, 40, 50, 60, 70, 80, 90, 92]
    fib = [0] * 94

    print("İzleme: ebob(1071, 462)")
    ebob_izle(1071, 462)
    print("\nİzleme: ebob(89, 55) — ardışık Fibonacci sayıları")
    ebob_izle(89, 55)

    fib[1] = 1
    fib[2] = 1
    for k in range(3, 94):
        fib[k] = fib[k - 1] + fib[k - 2]    # Python'da taşma yok
    print("\nArdışık Fibonacci çiftleri (F(k+1), F(k)): adım = k - 1")
    print("  k               F(k+1)                 F(k)  adım"
          "  basamak  5*basamak")
    for k in satirlar:
        _, adim = ebob(fib[k + 1], fib[k])
        d = basamak(fib[k])
        print(f"{k:3d} {fib[k + 1]:20d} {fib[k]:20d} {adim:5d} {d:8d} "
              f"{5 * d:10d}")

    # Tam tarama: 1 <= b < a <= TARAMA; her adım sayısı için en küçük a
    en_kucuk_a = [0] * 64
    en_kucuk_b = [0] * 64
    en_cok = 0
    cift = 0
    for a in range(2, TARAMA + 1):
        for b in range(1, a):
            _, adim = ebob(a, b)
            cift += 1
            if en_kucuk_a[adim] == 0:
                en_kucuk_a[adim] = a
                en_kucuk_b[adim] = b
            if adim > en_cok:
                en_cok = adim
    print(f"\nTam tarama: 1 <= b < a <= {TARAMA} ({cift} çift), en çok "
          f"{en_cok} adım")
    print("adım  en küçük a  (b)  Fibonacci?")
    for s in range(1, en_cok + 1):
        fib_mi = (en_kucuk_a[s] == fib[s + 2]
                  and en_kucuk_b[s] == fib[s + 1])
        print(f"{s:4d} {en_kucuk_a[s]:11d} {en_kucuk_b[s]:5d}  "
              f"{'evet' if fib_mi else 'HAYIR'}")
    print("\ns adım gerektiren en küçük çift (F(s+2), F(s+1)): Fibonacci")
    print("sayıları en kötü durumdur. Adım sayısı ≤ 5 x (küçük sayının")
    print("basamak sayısı) (Lamé): Öklid O(log min(a, b)).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++17 — std::gcd (<numeric>);
# Python — math.gcd

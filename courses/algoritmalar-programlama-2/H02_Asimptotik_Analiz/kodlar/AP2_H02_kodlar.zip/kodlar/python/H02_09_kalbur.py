"""H02_09_kalbur.py — AP-2 Hafta 2 · Örnek 9 (★★)
Amaç    : Eratosthenes kalburu (i * i'den başlatma) ve deneme bölmesiyle
          asal sayma: işlem sayıları ve zaman–bellek ödünleşimi
Çalıştır: python3 H02_09_kalbur.py [N [kalbur]]   (N verilirse yalnızca
          o N; "kalbur": deneme bölmesi atlanır)
Eşleri  : c/H02_09_kalbur.c · cpp/H02_09_kalbur.cpp
Çıktı   : üç dilde aynı (=); süreler stderr'e
"""
import sys

from zamanlayici import zaman_sn


def kalbur(n):
    """0..n için kalbur: bilesik[i] = 1 ise i bileşiktir.
    Döndürür: (asal sayısı, bilesik, işaretleme sayısı)."""
    asal = 0
    isaretleme = 0
    bilesik = bytearray(n + 1)          # n + 1 bayt, hepsi 0
    # i asalsa katlarını i*i'den başlayarak işaretle: daha küçük
    # katlar, daha küçük bir asal tarafından zaten işaretlendi
    i = 2
    while i * i <= n:
        if not bilesik[i]:
            for j in range(i * i, n + 1, i):
                bilesik[j] = 1
                isaretleme += 1
        i += 1
    for i in range(2, n + 1):
        if not bilesik[i]:
            asal += 1
    return asal, bilesik, isaretleme


def asal_mi(n):
    """Örnek 8'deki deneme bölmesi: (asal mı, bölme sayısı)."""
    bolme = 0
    if n < 2:
        return False, bolme
    i = 2
    while i * i <= n:
        bolme += 1
        if n % i == 0:
            return False, bolme
        i += 1
    return True, bolme


def deneme_say(n):
    """2..n arasındaki asalları deneme bölmesiyle sayar."""
    asal = 0
    toplam_bolme = 0
    for m in range(2, n + 1):
        a, b = asal_mi(m)
        if a:
            asal += 1
        toplam_bolme += b
    return asal, toplam_bolme


def satir(n, deneme_de):
    """Bir N için tablo satırı; süreler stderr'e."""
    bolme = 0
    t0 = zaman_sn()
    p1, _, isaret = kalbur(n)
    t1 = zaman_sn()
    p2 = -1
    if deneme_de:
        p2, bolme = deneme_say(n)
    t2 = zaman_sn()
    s = f"{n:10d} {p1:8d} "
    if deneme_de:
        s += f"{p2:8d} {bolme:12d}"
    else:
        s += f"{'-':>8} {'-':>12}"
    print(s + f" {isaret:11d} {isaret / n:8.3f} {n + 1:11d}")
    hata = f"N={n}: kalbur {(t1 - t0) * 1000:.3f} ms"
    if deneme_de:
        hata += f" · deneme bölmesi {(t2 - t1) * 1000:.3f} ms"
    print(hata, file=sys.stderr)


def main():
    boyutlar = [10, 100, 1000, 10000, 100000]
    argv = sys.argv[1:]
    if len(argv) > 2 or (len(argv) == 2 and argv[1] != "kalbur"):
        print(f"Kullanım: {sys.argv[0]} [N [kalbur]]", file=sys.stderr)
        sys.exit(2)
    if argv:
        try:
            n = int(argv[0])
        except ValueError:
            n = 0
        if n < 2 or n > 2000000000:
            print("N 2..2000000000 olmalı", file=sys.stderr)
            sys.exit(2)
        print("         N     π(N)   deneme        bölme  işaretleme"
              "  işar./N  bellek(B)")
        satir(n, len(argv) == 1)
        return

    p, bilesik, isaret = kalbur(100)
    print(f"Kalbur, N = 100: {p} asal, {isaret} işaretleme")
    s = 0
    parca = ""
    for i in range(2, 101):
        if not bilesik[i]:
            parca += f"{i:4d}"
            s += 1
            if s % 10 == 0:
                print(parca)
                parca = ""
    print(parca)
    print("\n         N     π(N)   deneme        bölme  işaretleme"
          "  işar./N  bellek(B)")
    for n in boyutlar:
        satir(n, True)
    print("\nKalbur Θ(N log log N) işaretleme ve N + 1 bayt bellek")
    print("kullanır; deneme bölmesi O(1) bellekle ama çok daha fazla")
    print("işlemle çalışır: zaman–bellek ödünleşimi. N = 10^8 için")
    print("kalbur dizisi yaklaşık 100 MB'tır (bit dizisiyle 12.5 MB).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok;
# Python — yok (sympy.primerange üçüncü taraf; kullanılmaz)

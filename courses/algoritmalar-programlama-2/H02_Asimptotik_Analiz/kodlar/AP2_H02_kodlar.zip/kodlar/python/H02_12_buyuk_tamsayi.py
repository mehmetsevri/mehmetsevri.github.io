"""H02_12_buyuk_tamsayi.py — AP-2 Hafta 2 · Örnek 12 (★★★)
Amaç    : 2^n'i ikiye katlayarak hesaplamak: C'de uint64_t n >= 64'te
          sarar (mod 2^64), Python'da büyük tamsayı kesin ama maliyetli
Çalıştır: python3 H02_12_buyuk_tamsayi.py
Eşleri  : c/H02_12_buyuk_tamsayi.c · cpp/H02_12_buyuk_tamsayi.cpp
Çıktı   : Δ — dile özgü (uint64_t sarması); bkz. Dil Penceresi
Not     : 3.11+'da 4300 basamaktan uzun tamsayının str()'ı hata verir;
          bu yüzden yalnızca bit uzunluğu ve kalanlar yazdırılır.
"""
import sys

from zamanlayici import zaman_sn, olc_ortanca


# 2^n: n kez ikiye katla. Python tamsayısı sarmaz, büyür: k bitlik
# sayıyı ikiye katlamak O(k) iş; toplam maliyet O(n²) bit işlemi.
def iki_us(n):
    x = 1
    for i in range(n):
        x = x * 2
    return x


def bit_uzunlugu(x):
    """x'in ikilik basamak (bit) sayısı; x = 0 için 0. Yerleşik yöntem:
    C'deki yarıya bölme döngüsü 10^5 bitlik sayıda O(k²) iş yapardı."""
    return x.bit_length()


def uc_us(e):
    """3^e: tamsayı çarpımıyla (Python'da her e için kesin)."""
    x = 1
    for i in range(e):
        x *= 3
    return x


def main():
    boyutlar = [1, 10, 63, 64, 65, 100, 1000, 10000, 100000]

    print("2^n, ikiye katlayarak (Python int)")
    print("     n  bit_uzunluğu  son_6_basamak  mod_1000000007")
    for n in boyutlar:
        t0 = zaman_sn()
        x = iki_us(n)
        sure = zaman_sn() - t0
        son6 = format(x % 1000000, "06d")
        print(f"{n:6d} {bit_uzunlugu(x):13d} {son6:>14} "
              f"{x % 1000000007:15d}")
        print(f"n={n}: {sure * 1000:.3f} ms", file=sys.stderr)

    # Kaputun altında: büyük tamsayı çarpması sabit zamanlı değildir
    for k in (100000, 200000, 400000, 800000):
        y = (1 << k) - 1
        s = olc_ortanca(lambda: y * y, 5)
        print(f"x*x, x {k} bit: {s * 1000:.3f} ms", file=sys.stderr)

    kesin = uc_us(39)
    yaklasik = int(3.0 ** 39.0)         # float: 53 bitlik anlamlı kısım
    print(f"\n3^39 tamsayı çarpımıyla : {kesin}")
    print(f"3^39 pow() ile (double) : {yaklasik}")
    print(f"fark                    : {kesin - yaklasik}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (GMP üçüncü taraf: mpz_ui_pow_ui);
# C++ — yok (Boost.Multiprecision); Python — 2 ** n, 1 << n

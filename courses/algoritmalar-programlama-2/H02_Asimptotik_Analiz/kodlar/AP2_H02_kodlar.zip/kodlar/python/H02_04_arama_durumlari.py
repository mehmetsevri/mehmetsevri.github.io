"""H02_04_arama_durumlari.py — AP-2 Hafta 2 · Örnek 4 (★★)
Amaç    : Doğrusal aramada en iyi, en kötü ve ortalama durum
          karşılaştırma sayaçları; ortalamanın bir varsayıma bağlılığı
Çalıştır: python3 H02_04_arama_durumlari.py
Eşleri  : c/H02_04_arama_durumlari.c · cpp/H02_04_arama_durumlari.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_tohum, rastgele_aralik, rastgele_karistir

HEDEF_SAYISI = 1000


def dogrusal_ara(a, x):
    """a içinde x'i arar: (indis ya da -1, karşılaştırma sayısı)."""
    kar = 0
    for i in range(len(a)):
        kar += 1                        # temel işlem: a[i] == x
        if a[i] == x:
            return i, kar
    return -1, kar


def basarili_toplam(a):
    """a'daki her elemanı bir kez arar: başarılı aramaların toplam sayacı."""
    toplam = 0
    for x in a:
        _, kar = dogrusal_ara(a, x)
        toplam += kar
    return toplam


def main():
    k10 = [42, 17, 8, 99, 23, 4, 16, 15, 61, 30]
    hedefler = [42, 30, 5]
    boyutlar = [10, 100, 1000, 2000]

    print("a =", " ".join(str(x) for x in k10), "  (n = 10)")
    for h in hedefler:
        ind, kar = dogrusal_ara(k10, h)
        print(f"ara({h}): indis {ind}, karşılaştırma {kar}")
    top = basarili_toplam(k10)
    print(f"Başarılı aramaların ortalaması: {top} / 10 = {top / 10:.2f}"
          f"   ((n+1)/2 = {11 / 2.0:.2f})\n")

    print(f"Rastgele permütasyon (1..n), tohum 42; {HEDEF_SAYISI} rastgele"
          " hedef 1..2n")
    print("       n  en_iyi  en_kötü  ort_başarılı  (n+1)/2"
          "  bulunan  ort_rastgele    model")
    for n in boyutlar:
        a = [i + 1 for i in range(n)]
        rastgele_tohum(42)
        rastgele_karistir(a)
        _, en_iyi = dogrusal_ara(a, a[0])       # ilk eleman
        _, en_kotu = dogrusal_ara(a, 0)         # dizide yok
        ort = basarili_toplam(a) / n
        bulunan = rtoplam = 0
        for h in range(HEDEF_SAYISI):
            x = rastgele_aralik(1, 2 * n)
            ind, kar = dogrusal_ara(a, x)
            if ind >= 0:
                bulunan += 1
            rtoplam += kar
        p = bulunan / HEDEF_SAYISI
        model = p * (n + 1) / 2 + (1 - p) * n
        print(f"{n:8d} {en_iyi:7d} {en_kotu:8d} {ort:13.2f} "
              f"{(n + 1) / 2:8.2f} {bulunan:8d} "
              f"{rtoplam / HEDEF_SAYISI:13.2f} {model:8.2f}")
    print("\nEn iyi durum 1, en kötü durum n karşılaştırma. Başarılı")
    print("aramaların ortalaması (her konum eşit olasılıklı) tam")
    print("(n+1)/2'dir. Hedeflerin yarısı dizide yoksa ortalama")
    print("p(n+1)/2 + (1-p)n modeline yaklaşır: ortalama durum bir")
    print("girdi dağılımı varsayımıdır.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (POSIX lfind); C++ — std::find;
# Python — a.index(x), x in a

"""H02_02_tum_ciftler.py — AP-2 Hafta 2 · Örnek 2 (★)
Amaç    : Bağımlı iç içe döngüde (j = i + 1'den) çift sayısı n(n-1)/2;
          bağımsız iç içe döngüyle (n*n) karşılaştırma
Çalıştır: python3 H02_02_tum_ciftler.py
Eşleri  : c/H02_02_tum_ciftler.c · cpp/H02_02_tum_ciftler.cpp
Çıktı   : üç dilde aynı (=)
"""


def tum_ciftler(n):
    """i < j olan (i, j) çiftlerini sayar: bağımlı iç içe döngü."""
    sayac = 0
    for i in range(n):
        for j in range(i + 1, n):       # n - 1 - i kez
            sayac += 1
    return sayac


def tum_sirali_ciftler(n):
    """Tüm sıralı (i, j) çiftlerini sayar: bağımsız iç içe döngü."""
    sayac = 0
    for i in range(n):
        for j in range(n):              # her i için n kez
            sayac += 1
    return sayac


def ucgen_yaz(n):
    """Küçük n için çiftleri satır satır yazar: işlem üçgeni."""
    toplam = 0
    for i in range(n):
        satir = 0
        parca = f"i={i}:"
        for j in range(i + 1, n):
            parca += f" ({i},{j})"
            satir += 1
        print(parca + " " * (6 * i) + f"  -> {satir}")
        toplam += satir
    print(f"toplam = {toplam} = {n}*{n - 1}/2")


def main():
    boyutlar = [0, 1, 2, 5, 10, 100, 1000, 2000]

    print("n = 5 için i < j çiftleri (i. satırda n-1-i çift):")
    ucgen_yaz(5)
    print("\n       n   bağımlı  n(n-1)/2   bağımsız  oran")
    for n in boyutlar:
        b = tum_ciftler(n)
        s = tum_sirali_ciftler(n)
        kuram = n * (n - 1) // 2
        oran = f"{s / b:.3f}" if b > 0 else "-"
        print(f"{n:8d} {b:9d} {kuram:9d} {s:10d}  {oran}")
    print("\nBağımlı döngü tam n(n-1)/2 kez döner; bağımsız döngü n*n.")
    print("Oran 2'ye yaklaşır: ikisi de Θ(n²), sabitleri farklı.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok;
# Python — itertools.combinations(range(n), 2) çiftleri üretir

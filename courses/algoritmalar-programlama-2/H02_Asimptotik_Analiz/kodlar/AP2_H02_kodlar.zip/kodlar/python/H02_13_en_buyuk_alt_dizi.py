"""H02_13_en_buyuk_alt_dizi.py — AP-2 Hafta 2 · Örnek 13 (★★★)
Amaç    : En büyük alt dizi toplamı: O(n³) → O(n²) → O(n) Kadane
          (Bentley, 2000); aynı sonuç, farklı toplama sayısı
Sözleşme: n >= 1; alt dizi BOŞ OLAMAZ (en az bir eleman). Tamamı negatif
          dizide sonuç en büyük elemandır. Eşitlikte ilk bulunan aralık.
Çalıştır: python3 H02_13_en_buyuk_alt_dizi.py [n [sinir]]  (n: süre
          ölçümü; bir sürüm toplama sayısı sinir'i, varsayılan 10^9,
          aşmıyorsa çalışır)
Eşleri  : c/H02_13_en_buyuk_alt_dizi.c ·
          cpp/H02_13_en_buyuk_alt_dizi.cpp
Çıktı   : üç dilde aynı (=); süreler stderr'e
"""
import sys

from ortak_rastgele import rastgele_tohum, rastgele_dizi
from zamanlayici import zaman_sn


def kubik(a, n):
    """O(n³): her (i, j) için a[i..j] baştan toplanır.
    Döndürür: (toplam, bas, son, toplama sayısı)."""
    en_iyi, bas, son, topl = a[0], 0, 0, 0
    for i in range(n):
        for j in range(i, n):
            toplam = 0
            for k in range(i, j + 1):
                toplam += a[k]
                topl += 1
            if toplam > en_iyi:
                en_iyi, bas, son = toplam, i, j
    return en_iyi, bas, son, topl


def karesel(a, n):
    """O(n²): a[i..j] toplamı, a[i..j-1] toplamına a[j] eklenerek."""
    en_iyi, bas, son, topl = a[0], 0, 0, 0
    for i in range(n):
        toplam = 0
        for j in range(i, n):
            toplam += a[j]
            topl += 1
            if toplam > en_iyi:
                en_iyi, bas, son = toplam, i, j
    return en_iyi, bas, son, topl


# O(n) Kadane: simdiki = a[i]'de biten en iyi alt dizinin toplamı.
# uzat < a[i] ise önceki kısım zarar ettiriyordur: a[i]'den yeniden başla
def kadane(a, n):
    en_iyi, bas, son, topl = a[0], 0, 0, 0
    simdiki = a[0]
    s_bas = 0
    for i in range(1, n):
        uzat = simdiki + a[i]
        topl += 1
        if uzat < a[i]:
            simdiki, s_bas = a[i], i
        else:
            simdiki = uzat
        if simdiki > en_iyi:
            en_iyi = simdiki
            bas, son = s_bas, i
    return en_iyi, bas, son, topl


def dizi_coz(ad, a):
    n = len(a)
    s1, s2, s3 = kubik(a, n), karesel(a, n), kadane(a, n)
    print(f"{ad} (n={n}): kübik {s1[0]} [{s1[1]}..{s1[2]}] · karesel "
          f"{s2[0]} [{s2[1]}..{s2[2]}] · Kadane {s3[0]} [{s3[1]}..{s3[2]}]")


def sure_olc(n, sinir):
    """Süre ölçümü kipi: toplama sayısı sinir'i aşmayan sürümler çalışır."""
    adlar = ["Kadane", "karesel", "kübik"]
    surumler = [kadane, karesel, kubik]
    nd = float(n)
    islem = [nd - 1, nd * (nd + 1) / 2, nd * (nd + 1) * (nd + 2) / 6]
    rastgele_tohum(42)
    a = rastgele_dizi(n, -100, 100)
    satir = f"n={n}"
    for v in range(3):
        if islem[v] > sinir:
            satir += f" · {adlar[v]} atlandı ({islem[v]:.2e} toplama)"
            continue
        z0 = zaman_sn()
        s = surumler[v](a, n)
        z1 = zaman_sn()
        satir += f" · {adlar[v]} {s[0]}"
        print(f"n={n} {adlar[v]}: {(z1 - z0) * 1e3:.3f} ms", file=sys.stderr)
    print(satir)


def main():
    boyutlar = [10, 100, 200, 1000, 2000, 10000, 100000]
    argv = sys.argv[1:]
    if len(argv) in (1, 2):             # süre ölçümü kipi
        try:
            n = int(argv[0])
        except ValueError:
            n = 0
        sinir = 1e9
        if len(argv) == 2:
            try:
                sinir = float(argv[1])
            except ValueError:
                sinir = 0
            if sinir <= 0:
                print("sinir pozitif bir sayı olmalı", file=sys.stderr)
                sys.exit(2)
        if n < 1 or n > 100000000:
            print("n 1..100000000 olmalı", file=sys.stderr)
            sys.exit(2)
        sure_olc(n, sinir)
        return
    if len(argv) > 2:
        print(f"Kullanım: {sys.argv[0]} [n [sinir]]", file=sys.stderr)
        sys.exit(2)

    dizi_coz("Bentley", [31, -41, 59, 26, -53, 58, 97, -93, -23, 84])
    dizi_coz("Tümü negatif", [-3, -1, -2])
    dizi_coz("Tek eleman", [5])
    dizi_coz("Sıfırlar", [0, -1, 0])
    dizi_coz("Klasik", [-2, 1, -3, 4, -1, 2, 1, -5, 4])

    rastgele_tohum(42)
    a = rastgele_dizi(100000, -100, 100)
    print("\nRastgele a[i] -100..100 (tohum 42); toplama sayıları")
    print("       n  en_büyük     kübik   n(n+1)(n+2)/6  karesel  Kadane")
    for n in boyutlar:
        s3 = kadane(a, n)
        satir = f"{n:8d} {s3[0]:9d}"
        if n <= 200:
            s1 = kubik(a, n)
            satir += f" {s1[3]:9d}" + ("" if s1[0] == s3[0] else "!")
        else:
            satir += f" {'-':>9}"
        satir += f" {n * (n + 1) * (n + 2) // 6:15d}"
        if n <= 2000:
            s2 = karesel(a, n)
            satir += f" {s2[3]:8d}" + ("" if s2[0] == s3[0] else "!")
        else:
            satir += f" {'-':>8}"
        print(satir + f" {s3[3]:7d}")
    print("\nÜç sürüm aynı toplamı bulur (uyuşmazlık '!' ile")
    print("işaretlenirdi). Toplama sayıları n(n+1)(n+2)/6, n(n+1)/2 ve")
    print("n - 1: n = 100000'de kübik sürüm 1.7 x 10^14 toplama isterdi,")
    print("Kadane 99999 toplama yapar.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok; Python — yok
# (itertools.accumulate önek toplamı verir, Kadane'yi vermez)

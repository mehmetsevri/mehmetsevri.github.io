"""H02_07_oran_testi.py — AP-2 Hafta 2 · Örnek 7 (★★)
Amaç    : Oran testi: n'i ikiye katlayıp T(2n)/T(n) oranından büyüme
          sınıfını kestirmek (Sedgewick & Wayne, 2011); sayaç ve süre
Çalıştır: python3 H02_07_oran_testi.py [--azami N] [--tekrar K] [--olc]
Eşleri  : c/H02_07_oran_testi.c · cpp/H02_07_oran_testi.cpp
Çıktı   : üç dilde aynı (=); ölçülen süreler stderr'e (--olc: stdout'a)
"""
import sys

from ortak_rastgele import rastgele_tohum, rastgele_dizi
from zamanlayici import olc_ortanca


def iki_toplam(a, n):
    """i < j ve a[i] + a[j] == 0 olan çiftler: (sayı, karşılaştırma)."""
    sayi = 0
    k = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            k += 1
            if a[i] + a[j] == 0:
                sayi += 1
    return sayi, k


def sayi_oku(s):
    """Pozitif tamsayı argümanını okur; geçersizse None."""
    try:
        deger = int(s)
    except ValueError:
        return None
    return deger if deger > 0 else None


def main():
    azami, tekrar, olc = 2000, 5, False
    argv = sys.argv[1:]
    i = 0
    while i < len(argv):
        if argv[i] == "--olc":
            olc = True
        elif (argv[i] == "--azami" and i + 1 < len(argv)
              and sayi_oku(argv[i + 1]) is not None):
            azami = sayi_oku(argv[i + 1])
            i += 1
        elif (argv[i] == "--tekrar" and i + 1 < len(argv)
              and sayi_oku(argv[i + 1]) is not None):
            tekrar = sayi_oku(argv[i + 1])
            i += 1
        else:
            print(f"Kullanım: {sys.argv[0]} [--azami N] [--tekrar K]"
                  " [--olc]", file=sys.stderr)
            sys.exit(2)
        i += 1
    rastgele_tohum(42)
    a = rastgele_dizi(azami, -1000, 1000)

    print("Oran testi: iki_toplam (i < j, a[i] + a[j] == 0),"
          " a[i] -1000..1000, tohum 42")
    print("       n  sıfır_çift  karşılaştırma  oran(sayaç)  kuram"
          + ("  ortanca_ms  oran(ölçülen)" if olc else ""))
    onceki_kar = 0
    onceki_sure = 0.0
    n = 250
    while n <= azami:
        sayi, kar = iki_toplam(a, n)
        sure = olc_ortanca(lambda: iki_toplam(a, n), tekrar) * 1000.0
        satir = f"{n:8d} {sayi:11d} {kar:14d}"
        if onceki_kar > 0:
            satir += f" {kar / onceki_kar:12.3f}  4.000"
        else:
            satir += f" {'-':>12}  {'-':>5}"
        if olc:                     # ölçüm stdout'a: deterministik değil
            satir += f" {sure:11.3f}"
            if onceki_sure > 0.0:
                satir += f" {sure / onceki_sure:14.2f}"
        else:
            hata = f"n={n}: ortanca {sure:.3f} ms"
            if onceki_sure > 0.0:
                hata += f" · oran {sure / onceki_sure:.2f}"
            print(hata, file=sys.stderr)
        print(satir)
        onceki_kar = kar
        onceki_sure = sure
        n *= 2
    print("\nSayaç oranı T(2n)/T(n) = 2(2n-1)/(n-1) -> 4: Θ(n²).")
    print("Ölçülen süre oranı da 4'e yaklaşmalı; küçük n'de sabit")
    print("maliyetler ve ölçüm gürültüsü baskındır (süreler stderr'de).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok; Python — timeit modülü
# süre ölçer (oran hesabı elle)

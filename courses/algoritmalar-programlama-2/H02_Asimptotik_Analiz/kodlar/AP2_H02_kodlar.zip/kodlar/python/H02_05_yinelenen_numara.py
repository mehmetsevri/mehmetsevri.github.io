"""H02_05_yinelenen_numara.py — AP-2 Hafta 2 · Örnek 5 (★★)
Amaç    : Yinelenen öğrenci numarası var mı? O(n²) kaba kuvvet; erken
          çıkışlı ve tüm çiftleri tarayan sürümün karşılaştırma sayıları
Çalıştır: python3 H02_05_yinelenen_numara.py
Eşleri  : c/H02_05_yinelenen_numara.c ·
          cpp/H02_05_yinelenen_numara.cpp
Çıktı   : üç dilde aynı (=) — Mini-OBS 2 v2.1 yinelenen.c ile aynı fikir
"""
from ortak_rastgele import rastgele_tohum, rastgele_aralik, rastgele_karistir


def yinelenen_var_mi(no):
    """İlk eşit çifti bulunca durur: (var mı, (i, j), karşılaştırma)."""
    kar = 0
    n = len(no)
    for i in range(n - 1):
        for j in range(i + 1, n):
            kar += 1
            if no[i] == no[j]:
                return True, (i, j), kar        # erken çıkış
    return False, None, kar


def yinelenen_bul(no):
    """Tüm çiftleri tarar: (eşit çift sayısı, karşılaştırma)."""
    cift = 0
    kar = 0
    n = len(no)
    for i in range(n - 1):
        for j in range(i + 1, n):
            kar += 1
            if no[i] == no[j]:
                cift += 1
    return cift, kar


def senaryo(ad, no):
    var, ij, k1 = yinelenen_var_mi(no)
    cift, k2 = yinelenen_bul(no)
    parca = f"{ad} n={len(no)}: var_mi={'EVET' if var else 'HAYIR'}"
    if var:
        parca += f" ({ij[0]},{ij[1]})"
    print(parca + f" kar={k1} | bul: {cift} çift, kar={k2}")


def main():
    boyutlar = [500, 1000, 2000]

    print("Küçük senaryolar (Mini-OBS 2 v2.1 test senaryoları 1-4):")
    senaryo("S1", [11, 22, 33, 44, 55])
    senaryo("S2", [7, 3, 7, 5, 3, 7])
    senaryo("S3", [9, 9, 1, 2, 3, 4])
    senaryo("S4", [1, 2, 3, 4, 8, 8])

    print("\nÖğrenci numaraları 2400000000 + karıştırılmış 0..n-1"
          " (tohum 42)")
    print("       n  durum        var_mi  kar(erken)   çift"
          "  kar(tümü)   n(n-1)/2")
    for n in boyutlar:
        sira = list(range(n))
        rastgele_tohum(42)
        rastgele_karistir(sira)
        no = [2400000000 + s for s in sira]
        for kopya in range(2):
            if kopya == 1:              # bir numarayı başka yere kopyala
                hedef = rastgele_aralik(1, n - 1)
                no[hedef] = no[0]
            var, _, k1 = yinelenen_var_mi(no)
            cift, k2 = yinelenen_bul(no)
            durum = "1-yinelenen" if kopya else "temiz"
            var_s = "EVET" if var else "HAYIR"
            print(f"{n:8d}  {durum:<11}  {var_s:<6} {k1:11d} {cift:6d} "
                  f"{k2:10d} {n * (n - 1) // 2:10d}")
    print("\nTüm çiftler her girdide tam n(n-1)/2 karşılaştırma yapar.")
    print("Erken çıkış en iyi durumda 1 karşılaştırmaya iner; ama temiz")
    print("dosyada (en kötü durum) kazancı yoktur: ikisi de O(n²).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (qsort + komşu karşılaştırma: H6);
# C++ — std::sort + std::adjacent_find; Python — len(set(no)) < len(no)

"""H02_03_yariya_inen.py — AP-2 Hafta 2 · Örnek 3 (★)
Amaç    : Yarıya inen döngü kaç adım sürer? ⌊log2 n⌋ + 1; üçe bölmeyle
          karşılaştırma: log tabanı yalnızca sabit çarpandır
Çalıştır: python3 H02_03_yariya_inen.py
Eşleri  : c/H02_03_yariya_inen.c · cpp/H02_03_yariya_inen.cpp
Çıktı   : üç dilde aynı (=)
"""


def yariya_adim(n):
    """n > 0 oldukça n'i yarıya indirir; adım sayısını döndürür."""
    adim = 0
    while n > 0:
        n //= 2                     # taban bölmesi (n >= 0'da C ile aynı)
        adim += 1
    return adim


def ucte_adim(n):
    """Aynı döngü, üçe bölerek."""
    adim = 0
    while n > 0:
        n //= 3
        adim += 1
    return adim


def taban_log2(n):
    """2^k <= n olan en büyük k (n >= 1): ⌊log2 n⌋, kayan nokta olmadan."""
    k = 0
    p = 1
    while p <= n // 2:              # 2p <= n (Python'da taşma yok)
        p *= 2
        k += 1
    return k


def main():
    ornekler = [
        1, 2, 3, 4, 7, 8, 15, 16, 100, 1000, 1000000, 1000000000,
        1000000000000, 1000000000000000000, 18446744073709551615
    ]

    n = 100
    adim = 0
    parca = f"İzleme (n = 100): {n}"
    while n > 0:
        n //= 2
        adim += 1
        parca += f" -> {n}"
    print(parca + f"   ({adim} adım)\n")

    print("                   n  yarıya  ⌊log2 n⌋+1  eşit  üçe  oran")
    for m in ornekler:
        y = yariya_adim(m)
        f = taban_log2(m) + 1
        u = ucte_adim(m)
        esit = "evet" if y == f else "HAYIR"
        print(f"{m:20d} {y:7d} {f:11d}  {esit:<5} {u:4d}  {y / u:.2f}")
    print("\nYarıya inen döngü ⌊log2 n⌋ + 1 adım sürer: n = 2^64 - 1")
    print("için bile 64 adım. Üçe bölmeyle adım sayısı log3 n'dir;")
    print("oran log2(3) = 1.58'e yaklaşır: taban yalnızca sabittir.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (GCC eklentisi __builtin_clzll);
# C++20 — std::bit_width(n); Python — n.bit_length()

"""H02_11_hizli_us.py — AP-2 Hafta 2 · Örnek 11 (★★★)
Amaç    : Hızlı üs alma (kare al ve çarp) ile a^b mod m: yinelemeli ve
          özyinelemeli sürüm, O(log b) çarpma; uint64_t ile güvenli çarpma
Çalıştır: python3 H02_11_hizli_us.py
Eşleri  : c/H02_11_hizli_us.c · cpp/H02_11_hizli_us.cpp
Çıktı   : üç dilde aynı (=)
Not     : Algoritma elle yazılır; yerleşik pow(a, b, m) YALNIZCA kâhindir.
"""

MOD_SINIR = 2 ** 32
SAF_SINIR = 1000000


def mod_gecerli(m):
    """Ön koşul 1 <= m < 2^32 (C ile aynı sözleşme; Python'da çarpım
    taşmaz ama sınır korunur ki üç dil aynı girdileri kabul etsin)."""
    return 1 <= m < MOD_SINIR


# a^b mod m, yinelemeli kare-al-çarp: (sonuç, çarpma sayısı)
def us_mod(a, b, m):
    sonuc = 1 % m
    a %= m
    carpma = 0
    while b > 0:
        if b % 2 == 1:      # son bit 1
            sonuc = sonuc * a % m
            carpma += 1
        a = a * a % m       # kare al
        carpma += 1
        b //= 2
    return sonuc, carpma


def us_mod_oz(a, b, m):
    """a^b mod m, özyinelemeli: a^b = (a^(b/2))² · (b tekse a)."""
    if b == 0:
        return 1 % m, 0
    yarim, carpma = us_mod_oz(a, b // 2, m)
    sonuc = yarim * yarim % m
    carpma += 1
    if b % 2 == 1:
        sonuc = sonuc * (a % m) % m
        carpma += 1
    return sonuc, carpma


def us_mod_saf(a, b, m):
    """Saf sürüm: b kez çarp — O(b)."""
    sonuc = 1 % m
    carpma = 0
    for i in range(b):
        sonuc = sonuc * (a % m) % m
        carpma += 1
    return sonuc, carpma


def us_mod_izle(a, b, m):
    """Yinelemeli sürümün her adımını yazar."""
    sonuc = 1 % m
    adim = 0
    a %= m
    print("adım     b  bit  sonuç  taban")
    print(f"{adim:4d} {b:5d}    - {sonuc:6d} {a:6d}")
    while b > 0:
        bit = b % 2
        if bit == 1:
            sonuc = sonuc * a % m
        a = a * a % m
        b //= 2
        adim += 1
        print(f"{adim:4d} {b:5d} {bit:4d} {sonuc:6d} {a:6d}")


def main():
    t = [
        (2, 10, 1000), (3, 13, 1000), (7, 0, 13), (5, 3, 1),
        (123456789, 1000000, 1000000007), (2, 1000000006, 1000000007),
        (3, 1000000000000000000, 1000000007),
        (4294967290, 18446744073709551615, 4294967291),
        (2, 10, 4294967311)
    ]

    print("İzleme: 3^13 mod 1000 (13 = 1101 ikilik; bitler sağdan)")
    us_mod_izle(3, 13, 1000)
    print("\n          a                     b           m       sonuç"
          "  yin   öz      saf  kâhin")
    for a, b, m in t:
        satir = f"{a:11d} {b:21d} {m:11d}"
        if not mod_gecerli(m):
            print(satir + "  ön koşul ihlali: m >= 2^32 (çarpım taşabilir)")
            continue
        r1, c1 = us_mod(a, b, m)
        r2, c2 = us_mod_oz(a, b, m)
        satir += f" {r1:11d} {c1:4d} {c2:4d}"
        if r1 != r2:
            print(satir + f"  UYUŞMAZ (özyinelemeli {r2})")
            continue
        if b <= SAF_SINIR:
            r3, c3 = us_mod_saf(a, b, m)
            kahin = pow(a, b, m)        # kâhin: yerleşik modüler üs
            esit = "=" if r3 == r1 and kahin == r1 else "FARKLI"
            print(satir + f" {c3:8d}  {esit}")
        else:
            print(satir + f" {'-':>8}  -")
    print("\nÇarpma sayısı = (b'nin bit uzunluğu) + (1 bitlerinin sayısı)")
    print("<= 2 log2 b + 2: O(log b). Saf sürüm b çarpma yapar.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (pow() double döndürür, mod almaz);
# C++ — yok; Python — pow(a, b, m) (burada yalnızca kâhin)

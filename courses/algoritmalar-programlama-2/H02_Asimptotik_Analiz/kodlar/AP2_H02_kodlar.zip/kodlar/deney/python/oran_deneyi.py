"""oran_deneyi.py — AP-2 Hafta 2 · Haftanın Deneyi (Python sürücüsü)
Amaç    : Kara kutu fonksiyonun süresini n'i ikiye katlayarak ölçer;
          1 ısınma + K tekrar, ortanca; tutarsız ölçüm (yayılım/ortanca
          > 0,3) en çok 2 kez yinelenir. Sonuç CSV olarak stdout'a.
Çalıştır: python3 oran_deneyi.py FONK N_BAS N_SON [TEKRAR]  (FONK = 1, 2, 3)
          örnek: python3 oran_deneyi.py 2 4096 1048576 5 > sonuc.csv
Eşleri  : ../c/oran_deneyi.c · ../cpp/oran_deneyi.cpp
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "..", "python"))

from gizemli import gizemli_1, gizemli_2, gizemli_3  # noqa: E402
from ortak_rastgele import rastgele_tohum, rastgele_dizi  # noqa: E402
from zamanlayici import zaman_sn, ortanca  # noqa: E402


def sayi(s):
    try:
        return int(s)
    except ValueError:
        return -1


def main():
    fonklar = [gizemli_1, gizemli_2, gizemli_3]
    argv = sys.argv[1:]
    if len(argv) not in (3, 4):
        print(f"Kullanım: {sys.argv[0]} FONK N_BAS N_SON [TEKRAR]",
              file=sys.stderr)
        sys.exit(2)
    f, n_bas, n_son = sayi(argv[0]), sayi(argv[1]), sayi(argv[2])
    tekrar = sayi(argv[3]) if len(argv) == 4 else 5
    if not (1 <= f <= 3) or n_bas < 2 or n_son < n_bas or tekrar < 1:
        print("geçersiz argüman", file=sys.stderr)
        sys.exit(2)
    rastgele_tohum(42)
    a = rastgele_dizi(n_son, 0, 999999)
    surum = f"{sys.version_info.major}.{sys.version_info.minor}"

    print("fonksiyon;n;dil;derleme;tekrar;ortanca_ms;en_az_ms;en_cok_ms;"
          "yeniden;kontrol", flush=True)
    n = n_bas
    while n <= n_son:
        kontrol = fonklar[f - 1](a, n)          # ısınma
        yeniden = 0
        while True:
            sure = []
            for _ in range(tekrar):
                t0 = zaman_sn()
                kontrol = fonklar[f - 1](a, n)
                sure.append((zaman_sn() - t0) * 1e3)
            ort = ortanca(sure)
            enaz, encok = min(sure), max(sure)
            if (encok - enaz) / ort <= 0.3 or yeniden == 2:
                break
            yeniden += 1                # tutarsız ölçüm: yinele
        print(f"gizemli_{f};{n};py;CPython{surum};{tekrar};{ort:.6f};"
              f"{enaz:.6f};{encok:.6f};{yeniden};{kontrol}", flush=True)
        n *= 2


if __name__ == "__main__":
    main()

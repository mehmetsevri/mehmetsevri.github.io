"""gizemli.py — AP-2 Hafta 2 · Haftanın Deneyi: üç "kara kutu" fonksiyon
Her fonksiyon a[0..n-1]'i okur (değiştirmez) ve bir sağlama değeri
döndürür. ÖĞRETİM ÜYESİ İÇİN: öğrenciye yalnızca derlenmiş hâli
(python3 -m py_compile gizemli.py → __pycache__/gizemli.*.pyc) verilebilir.
  Büyüme sınıfları bilerek yazılmamıştır: deney bitene kadar bu
  dosyayı açmayın; sınıfları ölçümle bulun (ders notu Bölüm 6 ve
  Atölye 2). Yanıt anahtarı öğretim üyesindedir.
Eşleri : ../c/gizemli.c · ../cpp/gizemli.cpp (aynı sağlama değerleri)
"""


def gizemli_1(a, n):
    ters = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            if a[i] > a[j]:
                ters += 1
    return ters


def gizemli_2(a, n):
    toplam = 0
    for i in range(1, n):
        if a[i] > a[i - 1]:
            toplam += a[i]
    return toplam


def gizemli_3(a, n):
    """a[0..n-1]'in sıralı kopyası üzerinde sağlama: Σ b[i] * (i % 7 + 1)."""
    b = a[:n]
    t = [0] * n
    w = 1
    while w < n:                        # koşu genişliği
        lo = 0
        while lo + w < n:
            orta = lo + w
            hi = lo + 2 * w if lo + 2 * w < n else n
            i, j, k = lo, orta, lo
            while i < orta and j < hi:
                if b[i] <= b[j]:
                    t[k] = b[i]
                    i += 1
                else:
                    t[k] = b[j]
                    j += 1
                k += 1
            while i < orta:
                t[k] = b[i]
                i += 1
                k += 1
            while j < hi:
                t[k] = b[j]
                j += 1
                k += 1
            lo += 2 * w
        while lo < n:                   # eşi olmayan kuyruk
            t[lo] = b[lo]
            lo += 1
        b, t = t, b
        w *= 2
    s = 0
    for i in range(n):
        s += b[i] * (i % 7 + 1)
    return s

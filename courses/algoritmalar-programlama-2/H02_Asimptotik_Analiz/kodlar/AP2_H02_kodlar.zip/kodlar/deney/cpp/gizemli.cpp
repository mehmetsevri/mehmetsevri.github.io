/*
 * gizemli.cpp — AP-2 Hafta 2 · Haftanın Deneyi (ÖĞRETİM ÜYESİ İÇİN)
 *   Büyüme sınıfları bilerek yazılmamıştır: deney bitene kadar bu
 *   dosyayı açmayın; sınıfları ölçümle bulun (ders notu Bölüm 6 ve
 *   Atölye 2). Yanıt anahtarı öğretim üyesindedir.
 * Eşleri : ../c/gizemli.c · ../python/gizemli.py (aynı sağlama değerleri)
 */
#include "gizemli.hpp"

#include <utility>

long long gizemli_1(const std::vector<int>& a, std::size_t n)
{
    long long ters = 0;
    for (std::size_t i = 0; i + 1 < n; i++) {
        for (std::size_t j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                ters++;
            }
        }
    }
    return ters;
}

long long gizemli_2(const std::vector<int>& a, std::size_t n)
{
    long long toplam = 0;
    for (std::size_t i = 1; i < n; i++) {
        if (a[i] > a[i - 1]) {
            toplam += a[i];
        }
    }
    return toplam;
}

// a[0..n-1]'in sıralı kopyası üzerinde sağlama: Σ b[i] * (i % 7 + 1)
long long gizemli_3(const std::vector<int>& a, std::size_t n)
{
    std::vector<int> b(a.begin(), a.begin() + static_cast<long>(n));
    std::vector<int> t(n);
    for (std::size_t w = 1; w < n; w *= 2) {    // koşu genişliği
        std::size_t lo = 0;
        for (; lo + w < n; lo += 2 * w) {
            std::size_t orta = lo + w, hi = lo + 2 * w < n ? lo + 2 * w : n;
            std::size_t i = lo, j = orta, k = lo;
            while (i < orta && j < hi) {
                t[k++] = b[i] <= b[j] ? b[i++] : b[j++];
            }
            while (i < orta) {
                t[k++] = b[i++];
            }
            while (j < hi) {
                t[k++] = b[j++];
            }
        }
        for (; lo < n; lo++) {                  // eşi olmayan kuyruk
            t[lo] = b[lo];
        }
        std::swap(b, t);                        // O(1): yalnızca tutamaçlar
    }
    long long s = 0;
    for (std::size_t i = 0; i < n; i++) {
        s += static_cast<long long>(b[i]) * static_cast<long long>(i % 7 + 1);
    }
    return s;
}

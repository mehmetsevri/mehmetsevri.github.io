/*
 * oran_deneyi.cpp — AP-2 Hafta 2 · Haftanın Deneyi (C++ sürücüsü)
 * Amaç    : Kara kutu fonksiyonun süresini n'i ikiye katlayarak ölçer;
 *           1 ısınma + K tekrar, ortanca; tutarsız ölçüm (yayılım/ortanca
 *           > 0,3) en çok 2 kez yinelenir. Sonuç CSV olarak stdout'a.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 -I../../cpp \
 *           oran_deneyi.cpp gizemli.cpp -o oran_deneyi
 * Çalıştır: ./oran_deneyi FONK N_BAS N_SON [TEKRAR]   (FONK = 1, 2, 3)
 * Eşleri  : ../c/oran_deneyi.c · ../python/oran_deneyi.py
 */
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

#include "gizemli.hpp"
#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

#ifdef __OPTIMIZE__
const char* const DERLEME = "O2";
#else
const char* const DERLEME = "O0";
#endif

using Fonk = long long (*)(const std::vector<int>&, std::size_t);

static long sayi(const std::string& s)
{
    try {
        std::size_t son;
        long d = std::stol(s, &son);
        return son == s.size() ? d : -1;
    } catch (const std::exception&) {
        return -1;
    }
}

int main(int argc, char* argv[])
{
    const Fonk fonklar[3] = {gizemli_1, gizemli_2, gizemli_3};
    if (argc < 4 || argc > 5) {
        std::cerr << "Kullanım: " << argv[0]
                  << " FONK N_BAS N_SON [TEKRAR]\n";
        return 2;
    }
    long f = sayi(argv[1]), n_bas = sayi(argv[2]), n_son = sayi(argv[3]);
    long tekrar = argc == 5 ? sayi(argv[4]) : 5;
    if (f < 1 || f > 3 || n_bas < 2 || n_son < n_bas || tekrar < 1) {
        std::cerr << "geçersiz argüman\n";
        return 2;
    }
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(static_cast<std::size_t>(n_son), 0,
                                       999999);

    std::printf("fonksiyon;n;dil;derleme;tekrar;ortanca_ms;en_az_ms;"
                "en_cok_ms;yeniden;kontrol\n");
    for (long n = n_bas; n <= n_son; n *= 2) {
        std::size_t un = static_cast<std::size_t>(n);
        long long kontrol = fonklar[f - 1](a, un);     // ısınma
        int yeniden = 0;
        std::vector<double> sure;
        double ort, enaz, encok;
        for (;;) {
            sure.clear();
            for (long r = 0; r < tekrar; r++) {
                double t0 = zaman_sn();
                kontrol = fonklar[f - 1](a, un);
                sure.push_back((zaman_sn() - t0) * 1e3);
            }
            ort = ortanca(sure);
            enaz = encok = sure[0];
            for (double s : sure) {
                enaz = s < enaz ? s : enaz;
                encok = s > encok ? s : encok;
            }
            if ((encok - enaz) / ort <= 0.3 || yeniden == 2) {
                break;
            }
            yeniden++;                  // tutarsız ölçüm: yinele
        }
        std::printf("gizemli_%ld;%ld;cpp;%s;%ld;%.6f;%.6f;%.6f;%d;%lld\n", f,
                    n, DERLEME, tekrar, ort, enaz, encok, yeniden, kontrol);
        std::fflush(stdout);
    }
    return 0;
}

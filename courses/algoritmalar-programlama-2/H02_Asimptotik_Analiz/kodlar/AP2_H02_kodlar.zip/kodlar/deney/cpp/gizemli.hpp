/*
 * gizemli.hpp — AP-2 Hafta 2 · Haftanın Deneyi: üç "kara kutu" fonksiyon
 * Her fonksiyon a[0..n-1]'i okur (değiştirmez) ve bir sağlama değeri
 * döndürür. Büyüme sınıflarını YALNIZCA süre ölçümlerinden bulun.
 * Öğrenciye bu başlık ve derlenmiş gizemli.o verilebilir:
 *   g++ -std=c++17 -O2 -c gizemli.cpp -o gizemli.o
 */
#ifndef GIZEMLI_HPP
#define GIZEMLI_HPP

#include <cstddef>
#include <vector>

long long gizemli_1(const std::vector<int>& a, std::size_t n);
long long gizemli_2(const std::vector<int>& a, std::size_t n);
long long gizemli_3(const std::vector<int>& a, std::size_t n);

#endif // GIZEMLI_HPP

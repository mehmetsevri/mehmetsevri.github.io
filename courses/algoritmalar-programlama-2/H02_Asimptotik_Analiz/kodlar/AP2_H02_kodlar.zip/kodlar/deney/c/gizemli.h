/*
 * gizemli.h — AP-2 Hafta 2 · Haftanın Deneyi: üç "kara kutu" fonksiyon
 * Her fonksiyon a[0..n-1] dizisini okur (değiştirmez) ve bir sağlama
 * değeri döndürür. İç yapıları gizlidir: hangi büyüme sınıfında
 * olduklarını YALNIZCA süre ölçümlerinden (oran testi, log-log eğim)
 * bulacaksınız. Öğrenciye bu başlık ve derlenmiş gizemli.o verilebilir:
 *   gcc -std=c17 -O2 -c gizemli.c -o gizemli.o
 */
#ifndef GIZEMLI_H
#define GIZEMLI_H

#include <stddef.h>

long long gizemli_1(const int *a, size_t n);
long long gizemli_2(const int *a, size_t n);
long long gizemli_3(const int *a, size_t n);

#endif /* GIZEMLI_H */

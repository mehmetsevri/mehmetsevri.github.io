/*
 * oran_deneyi.c — AP-2 Hafta 2 · Haftanın Deneyi (C sürücüsü)
 * Amaç    : Kara kutu fonksiyonun süresini n'i ikiye katlayarak ölçer;
 *           1 ısınma + K tekrar, ortanca; tutarsız ölçüm (yayılım/ortanca
 *           > 0,3) en çok 2 kez yinelenir. Sonuç CSV olarak stdout'a.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -I../../c \
 *           oran_deneyi.c gizemli.c ../../c/ortak_rastgele.c \
 *           ../../c/zamanlayici.c -o oran_deneyi
 * Çalıştır: ./oran_deneyi FONK N_BAS N_SON [TEKRAR]   (FONK = 1, 2, 3)
 *           örnek: ./oran_deneyi 2 4096 1048576 5 > sonuc.csv
 * Eşleri  : ../cpp/oran_deneyi.cpp · ../python/oran_deneyi.py
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#include "gizemli.h"
#include "ortak_rastgele.h"
#include "zamanlayici.h"

#ifdef __OPTIMIZE__
#define DERLEME "O2"
#else
#define DERLEME "O0"
#endif

typedef long long (*Fonk)(const int *, size_t);

static long sayi(const char *s)
{
    char *son;
    errno = 0;
    long d = strtol(s, &son, 10);
    return (errno != 0 || *son != '\0') ? -1 : d;
}

int main(int argc, char *argv[])
{
    static const Fonk fonklar[3] = {gizemli_1, gizemli_2, gizemli_3};
    if (argc < 4 || argc > 5) {
        fprintf(stderr, "Kullanım: %s FONK N_BAS N_SON [TEKRAR]\n", argv[0]);
        return 2;
    }
    long f = sayi(argv[1]), n_bas = sayi(argv[2]), n_son = sayi(argv[3]);
    long tekrar = argc == 5 ? sayi(argv[4]) : 5;
    if (f < 1 || f > 3 || n_bas < 2 || n_son < n_bas || tekrar < 1 ||
        tekrar > 101) {
        fprintf(stderr, "geçersiz argüman\n");
        return 2;
    }
    int *a = malloc((size_t)n_son * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n_son, 0, 999999);

    printf("fonksiyon;n;dil;derleme;tekrar;ortanca_ms;en_az_ms;en_cok_ms;"
           "yeniden;kontrol\n");
    double sure[101];
    for (long n = n_bas; n <= n_son; n *= 2) {
        long long kontrol = fonklar[f - 1](a, (size_t)n);   /* ısınma */
        int yeniden = 0;
        double ort, enaz, encok;
        for (;;) {
            for (long r = 0; r < tekrar; r++) {
                double t0 = zaman_sn();
                kontrol = fonklar[f - 1](a, (size_t)n);
                sure[r] = (zaman_sn() - t0) * 1e3;
            }
            ort = ortanca(sure, (int)tekrar);       /* sure[] sıralanır */
            enaz = sure[0];
            encok = sure[tekrar - 1];
            if ((encok - enaz) / ort <= 0.3 || yeniden == 2) {
                break;
            }
            yeniden++;                  /* tutarsız ölçüm: yinele */
        }
        printf("gizemli_%ld;%ld;c;%s;%ld;%.6f;%.6f;%.6f;%d;%lld\n", f, n,
               DERLEME, tekrar, ort, enaz, encok, yeniden, kontrol);
        fflush(stdout);
    }
    free(a);
    return 0;
}

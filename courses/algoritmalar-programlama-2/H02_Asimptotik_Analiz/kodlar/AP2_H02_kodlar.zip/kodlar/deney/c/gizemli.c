/*
 * gizemli.c — AP-2 Hafta 2 · Haftanın Deneyi (ÖĞRETİM ÜYESİ İÇİN)
 * Kara kutu fonksiyonların gerçekleştirimi. Öğrenciye kaynak yerine
 * gizemli.o verilecekse bu dosya paylaşılmaz.
 *   Büyüme sınıfları bilerek yazılmamıştır: deney bitene kadar bu
 *   dosyayı açmayın; sınıfları ölçümle bulun (ders notu Bölüm 6 ve
 *   Atölye 2). Yanıt anahtarı öğretim üyesindedir.
 * Eşleri : ../cpp/gizemli.hpp · ../python/gizemli.py (aynı sağlama değerleri)
 */
#include <stdlib.h>

#include "gizemli.h"

long long gizemli_1(const int *a, size_t n)
{
    long long ters = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                ters++;
            }
        }
    }
    return ters;
}

long long gizemli_2(const int *a, size_t n)
{
    long long toplam = 0;
    for (size_t i = 1; i < n; i++) {
        if (a[i] > a[i - 1]) {
            toplam += a[i];
        }
    }
    return toplam;
}

/* a[0..n-1]'in sıralı kopyası üzerinde sağlama: Σ b[i] * (i % 7 + 1) */
long long gizemli_3(const int *a, size_t n)
{
    int *b = malloc(n * sizeof *b), *t = malloc(n * sizeof *t);
    if (b == NULL || t == NULL) {
        free(b);
        free(t);
        return -1;
    }
    for (size_t i = 0; i < n; i++) {
        b[i] = a[i];
    }
    for (size_t w = 1; w < n; w *= 2) {         /* koşu genişliği */
        size_t lo = 0;
        for (; lo + w < n; lo += 2 * w) {
            size_t orta = lo + w, hi = lo + 2 * w < n ? lo + 2 * w : n;
            size_t i = lo, j = orta, k = lo;
            while (i < orta && j < hi) {
                t[k++] = b[i] <= b[j] ? b[i++] : b[j++];
            }
            while (i < orta) {
                t[k++] = b[i++];
            }
            while (j < hi) {
                t[k++] = b[j++];
            }
        }
        for (; lo < n; lo++) {                  /* eşi olmayan kuyruk */
            t[lo] = b[lo];
        }
        int *g = b;
        b = t;
        t = g;
    }
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += (long long)b[i] * (long long)(i % 7 + 1);
    }
    free(b);
    free(t);
    return s;
}

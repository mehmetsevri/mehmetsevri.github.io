"""H02_K03_sandvic_n0.py — AP-2 Hafta 2 · Kavram programı
Amaç    : f(n) = 3n² + 10n + 5 için Θ(n²) tanımındaki sabitler:
          c1 = 3, c2 = 4 ile 3n² ≤ f(n) ≤ 4n² eşitsizliğinin başladığı
          ilk n0'ı bulmak ve limit yaklaşımını (f(n)/n² → 3) göstermek.
          Program yalnızca bir sınamadır; kanıt cebirseldir (ders notu 3.3).
Çalıştır: python3 H02_K03_sandvic_n0.py
"""


def f(n):
    return 3 * n * n + 10 * n + 5


def main():
    n0 = 1
    while f(n0) > 4 * n0 * n0:
        n0 += 1
    print(f"f(n) <= 4n² ilk kez n0 = {n0}: f({n0}) = {f(n0)}, "
          f"4·{n0}² = {4 * n0 * n0}")
    print(f"bir önceki n = {n0 - 1}: f = {f(n0 - 1)} > {4 * (n0 - 1) ** 2}")
    bozan = [n for n in range(n0, 100001)
             if not 3 * n * n <= f(n) <= 4 * n * n]
    print(f"n0..100000 aralığında eşitsizliği bozan n sayısı: {len(bozan)}")
    print("\n         n   f(n)/n²")
    n = 10
    while n <= 1000000:
        print(f"{n:10d}   {f(n) / (n * n):.6f}")
        n *= 10
    print("Oran 3'e yaklaşır (limit = 3, 0 < 3 < ∞): f(n) = Θ(n²).")


if __name__ == "__main__":
    main()

/*
 * H02_K01_karmasiklik_kartlari.c — AP-2 Hafta 2 · Kavram programı
 * Amaç    : "Karmaşıklığını söyle" kart oyunundaki 11 C kod parçası
 *           (Kart 12 Python: H02_K02_kart12_liste.py). Önce kartları
 *           sınıflandırın; sonra bu programı çalıştırıp sayaç oranlarıyla
 *           tahminlerinizi sınayın (oran testi, Sedgewick & Wayne, 2011).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_K01_karmasiklik_kartlari.c -o H02_K01_karmasiklik_kartlari
 * Çalıştır: ./H02_K01_karmasiklik_kartlari
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* Kart 1 */
long long kart01(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        s++;
    }
    for (long long j = 0; j < n; j++) {
        s++;
    }
    return s;
}

/* Kart 2 */
long long kart02(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        for (long long j = 0; j < n; j++) {
            s++;
        }
    }
    return s;
}

/* Kart 3 */
long long kart03(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        for (long long j = i + 1; j < n; j++) {
            s++;
        }
    }
    return s;
}

/* Kart 4 */
long long kart04(long long n)
{
    long long s = 0;
    for (long long i = n; i > 0; i /= 2) {
        s++;
    }
    return s;
}

/* Kart 5 */
long long kart05(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        for (long long j = 1; j < n; j *= 2) {
            s++;
        }
    }
    return s;
}

/* Kart 6 */
long long kart06(long long n)
{
    long long s = 0;
    for (long long i = 1; i * i <= n; i++) {
        s++;
    }
    return s;
}

/* Kart 7 */
long long kart07(const int *a, long long n, int x)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        s++;
        if (a[i] == x) {
            return s;
        }
    }
    return s;
}

/* Kart 8 */
long long kart08(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n && i < 1000; i++) {
        s++;
    }
    return s;
}

/* Kart 9 */
long long kart09(long long n)
{
    long long s = 0;
    for (long long i = 1; i < n; i *= 2) {
        for (long long j = 0; j < i; j++) {
            s++;
        }
    }
    return s;
}

/* Kart 10 */
size_t kart10(char *s)
{
    size_t say = 0;
    for (size_t i = 0; i < strlen(s); i++) {
        if (s[i] == ' ') {
            s[i] = '_';
            say++;
        }
    }
    return say;
}

/* Kart 11 */
long long kart11(int n)
{
    long long s = 0;
    for (long long m = 0; m < (1LL << n); m++) {
        s++;
    }
    return s;
}

static double sure_ms(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec * 1e3 + (double)ts.tv_nsec * 1e-6;
}

typedef long long (*Kart)(long long);

int main(void)
{
    static const Kart kartlar[] = {kart01, kart02, kart03, kart04, kart05,
                                   kart06, NULL, kart08, kart09};
    static const long long boyut[] = {1000, 2000, 4000, 8000};
    printf("Sayaç (temel işlem) değerleri; oran = T(2n) / T(n)\n");
    printf("kart     n=1000     n=2000     n=4000     n=8000   oranlar\n");
    for (int k = 0; k < 9; k++) {
        long long t[4];
        int *a = NULL;
        if (k == 6) {                       /* Kart 7: aranan dizide yok */
            a = malloc(8000 * sizeof *a);
            if (a == NULL) {
                return 1;
            }
            for (int i = 0; i < 8000; i++) {
                a[i] = i;
            }
        }
        for (int b = 0; b < 4; b++) {
            t[b] = k == 6 ? kart07(a, boyut[b], -1) : kartlar[k](boyut[b]);
        }
        printf("K%02d %10lld %10lld %10lld %10lld  ", k + 1, t[0], t[1], t[2],
               t[3]);
        for (int b = 1; b < 4; b++) {
            printf(" %.2f", (double)t[b] / (double)t[b - 1]);
        }
        if (k == 6) {
            printf("   (aranan a[0] olsaydı: %lld)", kart07(a, 8000, 0));
            free(a);
        }
        printf("\n");
    }
    printf("K11 n=16..19: ");
    for (int n = 16; n <= 19; n++) {
        printf(" %lld", kart11(n));
    }
    printf("   (n bir artınca oran %.2f)\n",
           (double)kart11(19) / (double)kart11(18));

    printf("K10 (strlen koşulda) süre, ms:");
    double onceki = 0;
    for (size_t n = 10000; n <= 80000; n *= 2) {
        char *s = malloc(n + 1);
        if (s == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            s[i] = (i % 5 == 4) ? ' ' : 'x';
        }
        s[n] = '\0';
        double t0 = sure_ms();
        size_t d = kart10(s);
        double ms = sure_ms() - t0;
        printf(" n=%zu: %.2f (%zu)", n, ms, d);
        if (onceki > 0) {
            printf(" oran %.2f", ms / onceki);
        }
        onceki = ms;
        free(s);
    }
    printf("\n");
    return 0;
}

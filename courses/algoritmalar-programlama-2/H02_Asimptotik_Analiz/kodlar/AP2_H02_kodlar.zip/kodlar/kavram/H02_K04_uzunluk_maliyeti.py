"""H02_K04_uzunluk_maliyeti.py — AP-2 Hafta 2 · Kavram programı
Amaç    : Aynı görünen döngü koşulu, farklı maliyet: C'de strlen(s) her
          çağrıda '\\0'ı arar (O(n)); C++ std::string::size() ve Python
          len() uzunluğu nesnede saklar (O(1)). n katlanınca süre oranı.
Çalıştır: python3 H02_K04_uzunluk_maliyeti.py
Eşleri  : H02_K04_uzunluk_maliyeti.c · H02_K04_uzunluk_maliyeti.cpp
"""
import time


# Boşlukları alt çizgiye çevirir; koşul her turda yeniden hesaplanır
def bosluk_degistir(s):
    say = 0
    i = 0
    while i < len(s):                   # len(): O(1)
        if s[i] == ' ':
            s[i] = '_'
            say += 1
        i += 1
    return say


def main():
    onceki = 0.0
    print("       n  değişen  süre(ms)  oran")
    n = 10000
    while n <= 80000:
        s = ['x'] * n
        for i in range(4, n, 5):
            s[i] = ' '
        t0 = time.perf_counter()
        d = bosluk_degistir(s)
        ms = (time.perf_counter() - t0) * 1000
        satir = f"{n:8d} {d:8d} {ms:9.3f}"
        if onceki > 0:
            satir += f"  {ms / onceki:.2f}"
        print(satir)
        onceki = ms
        n *= 2


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: Python — "".join(...).replace(" ", "_")

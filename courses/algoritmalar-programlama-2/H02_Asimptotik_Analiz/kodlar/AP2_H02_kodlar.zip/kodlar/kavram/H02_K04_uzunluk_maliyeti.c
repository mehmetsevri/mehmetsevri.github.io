/*
 * H02_K04_uzunluk_maliyeti.c — AP-2 Hafta 2 · Kavram programı (Dil Penceresi)
 * Amaç    : Aynı görünen döngü koşulu, farklı maliyet: C'de strlen(s) her
 *           çağrıda '\0'ı arar (O(n)); C++ std::string::size() ve Python
 *           len() uzunluğu nesnede saklar (O(1)). n katlanınca süre oranı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_K04_uzunluk_maliyeti.c -o H02_K04_uzunluk_maliyeti
 * Çalıştır: ./H02_K04_uzunluk_maliyeti
 * Eşleri  : H02_K04_uzunluk_maliyeti.cpp · H02_K04_uzunluk_maliyeti.py
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static double sure_ms(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec * 1e3 + (double)ts.tv_nsec * 1e-6;
}

/* Boşlukları alt çizgiye çevirir; koşul her turda yeniden hesaplanır */
size_t bosluk_degistir(char *s)
{
    size_t say = 0, i = 0;
    while (i < strlen(s)) {             /* strlen: O(n) */
        if (s[i] == ' ') {
            s[i] = '_';
            say++;
        }
        i++;
    }
    return say;
}

int main(void)
{
    double onceki = 0;
    printf("       n  değişen  süre(ms)  oran\n");
    for (size_t n = 10000; n <= 80000; n *= 2) {
        char *s = malloc(n + 1);
        if (s == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            s[i] = (i % 5 == 4) ? ' ' : 'x';
        }
        s[n] = '\0';
        double t0 = sure_ms();
        size_t d = bosluk_degistir(s);
        double ms = sure_ms() - t0;
        printf("%8zu %8zu %9.3f", n, d, ms);
        if (onceki > 0) {
            printf("  %.2f", ms / onceki);
        }
        printf("\n");
        onceki = ms;
        free(s);
    }
    return 0;
}

/* Kütüphane karşılığı: C — uzunluğu bir kez hesaplayıp saklamak;
 * C++ — std::string::size(); Python — len(s) */

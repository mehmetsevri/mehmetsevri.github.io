"""H02_K02_kart12_liste.py — AP-2 Hafta 2 · Kavram programı
Amaç    : "Karmaşıklığını söyle" Kart 12 (Python): döngü içinde
          `x not in sonuc` liste taraması. Önce kartı sınıflandırın; sonra
          programı çalıştırıp oran testiyle tahmininizi sınayın.
Çalıştır: python3 H02_K02_kart12_liste.py
"""
import time


# Kart 12
def kart12(a):
    sonuc = []
    for x in a:
        if x not in sonuc:
            sonuc.append(x)
    return sonuc


def main():
    onceki = 0.0
    print("     n  tekil  süre(ms)  oran   (tüm değerler farklı: en kötü)")
    n = 2000
    while n <= 16000:
        veri = list(range(n))
        t0 = time.perf_counter()
        t = kart12(veri)
        ms = (time.perf_counter() - t0) * 1000
        satir = f"{n:6d} {len(t):6d} {ms:9.1f}"
        if onceki > 0:
            satir += f"  {ms / onceki:.2f}"
        print(satir)
        onceki = ms
        n *= 2
    t0 = time.perf_counter()
    kart12([7] * 16000)
    ms = (time.perf_counter() - t0) * 1000
    print(f"tüm değerler aynı (en iyi), n = 16000: {ms:.1f} ms")


if __name__ == "__main__":
    main()

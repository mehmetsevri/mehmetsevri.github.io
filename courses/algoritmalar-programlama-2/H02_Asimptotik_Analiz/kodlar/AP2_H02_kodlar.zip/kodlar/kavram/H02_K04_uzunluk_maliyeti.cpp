/*
 * H02_K04_uzunluk_maliyeti.cpp — AP-2 Hafta 2 · Kavram programı (Dil Penceresi)
 * Amaç    : Aynı görünen döngü koşulu, farklı maliyet: C'de strlen(s) her
 *           çağrıda '\0'ı arar (O(n)); C++ std::string::size() ve Python
 *           len() uzunluğu nesnede saklar (O(1)). n katlanınca süre oranı.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_K04_uzunluk_maliyeti.cpp -o H02_K04_uzunluk_maliyeti
 * Çalıştır: ./H02_K04_uzunluk_maliyeti
 * Eşleri  : H02_K04_uzunluk_maliyeti.c · H02_K04_uzunluk_maliyeti.py
 */
#include <chrono>
#include <cstdio>
#include <string>

static double sure_ms()
{
    using namespace std::chrono;
    return duration<double, std::milli>(
               steady_clock::now().time_since_epoch()).count();
}

// Boşlukları alt çizgiye çevirir; koşul her turda yeniden hesaplanır
std::size_t bosluk_degistir(std::string& s)
{
    std::size_t say = 0, i = 0;
    while (i < s.size()) {              // size(): O(1)
        if (s[i] == ' ') {
            s[i] = '_';
            say++;
        }
        i++;
    }
    return say;
}

int main()
{
    double onceki = 0;
    std::printf("       n  değişen  süre(ms)  oran\n");
    for (std::size_t n = 10000; n <= 80000; n *= 2) {
        std::string s(n, 'x');
        for (std::size_t i = 4; i < n; i += 5) {
            s[i] = ' ';
        }
        double t0 = sure_ms();
        std::size_t d = bosluk_degistir(s);
        double ms = sure_ms() - t0;
        std::printf("%8zu %8zu %9.3f", n, d, ms);
        if (onceki > 0) {
            std::printf("  %.2f", ms / onceki);
        }
        std::printf("\n");
        onceki = ms;
    }
    return 0;
}

// Kütüphane karşılığı: C++ — std::string::size(), std::replace

/*
 * H02_HA7_modmul_tasma_duzeltilmis.c — AP-2 Hafta 2 · Hata Avcısı 7
 * Düzeltme: çarpma, "ikiye katla ve ekle" ile mod m'de yapılır (hızlı üs
 *           almanın toplama karşılığı; O(log b) toplama). Ara değerler
 *           < 2m olduğundan m < 2^63 için uint64_t taşmaz. Alternatif:
 *           m < 2^32 ön koşulunu denetlemek (Örnek 11).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA7_modmul_tasma_duzeltilmis.c \
 *           -o H02_HA7_modmul_tasma_duzeltilmis
 * Çalıştır: ./H02_HA7_modmul_tasma_duzeltilmis
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

/* (a * b) mod m, taşmadan; ön koşul 1 <= m < 2^63 */
uint64_t carp_mod(uint64_t a, uint64_t b, uint64_t m)
{
    uint64_t sonuc = 0;
    a %= m;
    while (b > 0) {
        if (b % 2 == 1) {
            sonuc = (sonuc + a) % m;    /* sonuc + a < 2m < 2^64 */
        }
        a = (a + a) % m;                /* a + a < 2m < 2^64 */
        b /= 2;
    }
    return sonuc;
}

/* a^b mod m; çarpmalar carp_mod ile (ön koşul 1 <= m < 2^63) */
uint64_t us_mod(uint64_t a, uint64_t b, uint64_t m)
{
    uint64_t sonuc = 1 % m;
    a %= m;
    while (b > 0) {
        if (b % 2 == 1) {
            sonuc = carp_mod(sonuc, a, m);
        }
        a = carp_mod(a, a, m);
        b /= 2;
    }
    return sonuc;
}

int main(void)
{
    static const uint64_t asallar[] = {1000000007ULL, 4294967291ULL,
                                       999999999989ULL,
                                       1000000000000000003ULL};
    for (size_t t = 0; t < 4; t++) {
        uint64_t m = asallar[t];
        printf("m = %20" PRIu64 ": 2^(m-1) mod m = %20" PRIu64 "%s\n", m,
               us_mod(2, m - 1, m), us_mod(2, m - 1, m) == 1 ? "" : "  ??");
    }
    uint64_t m = 999999999989ULL;
    printf("(m-1)*(m-1) mod m, m = %" PRIu64 ": %" PRIu64
           " (doğrusu 1)\n", m, carp_mod(m - 1, m - 1, m));
    return 0;
}

/*
 * H02_HA1_buyuk_o_her_zaman.c — AP-2 Hafta 2 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR: "O(n) algoritma her zaman O(n²)
 * algoritmadan hızlıdır" varsayımıyla yöntem seçilir; sabit çarpanlar
 * ve küçük n göz ardı edilir (gizli maliyet: her çağrıda 1 MB sıfırlama).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA1_buyuk_o_her_zaman.c -o H02_HA1_buyuk_o_her_zaman
 * Çalıştır: ./H02_HA1_buyuk_o_her_zaman
 * Düzeltme: H02_HA1_buyuk_o_her_zaman_duzeltilmis.c
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ARALIK 1000000                  /* numaralar 0 .. ARALIK-1 */
#define GRUP 20000                      /* denetlenecek küçük grup sayısı */
#define GRUP_N 16                       /* her grupta 16 numara */

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* "O(n)" yöntem: işaret dizisi. Gerçek maliyet O(n + ARALIK) */
bool yinelenen_isaret(const int *no, size_t n, unsigned char *isaret)
{
    memset(isaret, 0, ARALIK);          /* gizli maliyet: 1 MB yazma */
    for (size_t i = 0; i < n; i++) {
        if (isaret[no[i]]) {
            return true;
        }
        isaret[no[i]] = 1;
    }
    return false;
}

/* O(n²) kaba kuvvet: tüm çiftler */
bool yinelenen_kaba(const int *no, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (no[i] == no[j]) {
                return true;
            }
        }
    }
    return false;
}

/* HATA: seçim yalnızca büyük-O etiketine göre — "O(n) her zaman kazanır" */
bool yinelenen_var_mi(const int *no, size_t n, unsigned char *isaret)
{
    return yinelenen_isaret(no, n, isaret);
}

int main(void)
{
    unsigned char *isaret = malloc(ARALIK);
    int *no = malloc((size_t)GRUP * GRUP_N * sizeof *no);
    if (isaret == NULL || no == NULL) {
        return 1;
    }
    unsigned long long durum = 42;      /* küçük LCG: tekrarlanabilir veri */
    for (size_t i = 0; i < (size_t)GRUP * GRUP_N; i++) {
        durum = durum * 6364136223846793005ULL + 1442695040888963407ULL;
        no[i] = (int)((durum >> 33) % ARALIK);
    }
    double t0 = sure_sn();
    int yinelenenli = 0;
    for (size_t g = 0; g < GRUP; g++) {
        if (yinelenen_var_mi(no + g * GRUP_N, GRUP_N, isaret)) {
            yinelenenli++;
        }
    }
    double t1 = sure_sn();
    printf("%d grup x %d numara: %d grupta yinelenen var\n", GRUP, GRUP_N,
           yinelenenli);
    printf("Seçilen yöntem: işaret dizisi (\"O(n), en hızlısı\")\n");
    printf("Toplam süre: %.1f ms (grup başına %.2f µs)\n", (t1 - t0) * 1e3,
           (t1 - t0) * 1e6 / GRUP);
    free(isaret);
    free(no);
    return 0;
}

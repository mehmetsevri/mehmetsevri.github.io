/*
 * H02_HA1_buyuk_o_her_zaman_duzeltilmis.c — AP-2 Hafta 2 · Hata Avcısı 1
 * Düzeltme: maliyet modeli sabitleri de içerir. İşaret yöntemi gerçekte
 *           O(n + ARALIK), kaba kuvvet n(n-1)/2 karşılaştırma; eşik ÖLÇÜMLE
 *           belirlenir ve küçük gruplarda kaba kuvvet seçilir (melez yöntem).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA1_buyuk_o_her_zaman_duzeltilmis.c \
 *           -o H02_HA1_buyuk_o_her_zaman_duzeltilmis
 * Çalıştır: ./H02_HA1_buyuk_o_her_zaman_duzeltilmis
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ARALIK 1000000                  /* numaralar 0 .. ARALIK-1 */
#define GRUP 20000
#define GRUP_N 16
#define ESIK 384      /* ölçülen kesişim bu makinede 256 ile 512 arasında */

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* İşaret dizisi: O(n + ARALIK) */
bool yinelenen_isaret(const int *no, size_t n, unsigned char *isaret)
{
    memset(isaret, 0, ARALIK);
    for (size_t i = 0; i < n; i++) {
        if (isaret[no[i]]) {
            return true;
        }
        isaret[no[i]] = 1;
    }
    return false;
}

/* Kaba kuvvet: O(n²) ama küçük sabitle */
bool yinelenen_kaba(const int *no, size_t n)
{
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (no[i] == no[j]) {
                return true;
            }
        }
    }
    return false;
}

/* DÜZELTME: eşik altında kaba kuvvet, üstünde işaret dizisi */
bool yinelenen_var_mi(const int *no, size_t n, unsigned char *isaret)
{
    if (n < ESIK) {
        return yinelenen_kaba(no, n);
    }
    return yinelenen_isaret(no, n, isaret);
}

/* 5 değerin ortancası (araya ekleme) */
static double ortanca5(double *s)
{
    for (int i = 1; i < 5; i++) {
        for (int j = i; j > 0 && s[j - 1] > s[j]; j--) {
            double g = s[j];
            s[j] = s[j - 1];
            s[j - 1] = g;
        }
    }
    return s[2];
}

/* Tek bir n için iki yöntemin ortanca süresi (µs), 5 tekrar */
static void karsilastir(const int *no, size_t n, unsigned char *isaret)
{
    double si[5], sk[5];
    volatile bool sonuc = false;
    for (int r = 0; r < 5; r++) {
        double t0 = sure_sn();
        sonuc = yinelenen_isaret(no, n, isaret);
        double t1 = sure_sn();
        sonuc = yinelenen_kaba(no, n);
        double t2 = sure_sn();
        si[r] = (t1 - t0) * 1e6;
        sk[r] = (t2 - t1) * 1e6;
    }
    (void)sonuc;
    double oi = ortanca5(si), ok = ortanca5(sk);
    printf("%7zu %12.2f %12.2f %14llu  %s\n", n, oi, ok,
           (unsigned long long)n * (n - 1) / 2,
           ok < oi ? "kaba kuvvet" : "işaret dizisi");
}

int main(void)
{
    static const size_t boyutlar[] = {16, 64, 256, 512, 1024, 2048, 4096,
                                      16384};
    unsigned char *isaret = malloc(ARALIK);
    int *no = malloc((size_t)GRUP * GRUP_N * sizeof *no);   /* 320000 */
    if (isaret == NULL || no == NULL) {
        return 1;
    }
    /* yinelenensiz veri (en kötü durum): 0, 61, 122, ... mod ARALIK */
    for (size_t i = 0; i < 20000; i++) {
        no[i] = (int)((i * 61) % ARALIK);
    }
    printf("Yinelenensiz girdide ortanca süre (µs), 5 tekrar\n");
    printf("      n  işaret(µs)    kaba(µs)  karşılaştırma  hızlı olan\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        karsilastir(no, boyutlar[t], isaret);
    }

    unsigned long long durum = 42;      /* hatalı sürümle aynı veri */
    for (size_t i = 0; i < (size_t)GRUP * GRUP_N; i++) {
        durum = durum * 6364136223846793005ULL + 1442695040888963407ULL;
        no[i] = (int)((durum >> 33) % ARALIK);
    }
    double t0 = sure_sn();
    int yinelenenli = 0;
    for (size_t g = 0; g < GRUP; g++) {
        if (yinelenen_var_mi(no + g * GRUP_N, GRUP_N, isaret)) {
            yinelenenli++;
        }
    }
    double t1 = sure_sn();
    printf("\n%d grup x %d numara: %d grupta yinelenen var\n", GRUP, GRUP_N,
           yinelenenli);
    printf("Seçilen yöntem: n < %d için kaba kuvvet (melez)\n", ESIK);
    printf("Toplam süre: %.1f ms (grup başına %.2f µs)\n", (t1 - t0) * 1e3,
           (t1 - t0) * 1e6 / GRUP);
    free(isaret);
    free(no);
    return 0;
}

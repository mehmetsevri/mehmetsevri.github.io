/*
 * H02_HA2_en_iyi_durum_olcumu_duzeltilmis.c — AP-2 Hafta 2 · Hata Avcısı 2
 * Düzeltme: üç girdi ailesi ayrı ölçülür (en iyi: a[0]; en kötü: dizide
 *           yok; ortalama: rastgele konum). Rapor durumu ve gösterimi açıkça
 *           söyler: en iyi Θ(1), en kötü ve ortalama Θ(n); O(n) ise tüm
 *           girdiler için geçerli bir ÜST sınırdır (O ≠ "en kötü durum").
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA2_en_iyi_durum_olcumu_duzeltilmis.c \
 *           -o H02_HA2_en_iyi_durum_olcumu_duzeltilmis -lm
 * Çalıştır: ./H02_HA2_en_iyi_durum_olcumu_duzeltilmis
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TEKRAR 200

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

long dogrusal_ara(const int *a, size_t n, int x, long long *kar)
{
    *kar = 0;
    for (size_t i = 0; i < n; i++) {
        (*kar)++;
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

int main(void)
{
    static const char *const adlar[3] = {"en iyi (a[0])", "en kötü (yok)",
                                         "ortalama (rastgele)"};
    size_t azami = 1600000;
    int *a = malloc(azami * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t i = 0; i < azami; i++) {
        a[i] = (int)(i * 7 + 3);
    }
    unsigned long long durum = 42;
    for (int d = 0; d < 3; d++) {
        printf("%s\n        n  ort. karşılaştırma  süre/arama(ns)  oran\n",
               adlar[d]);
        double onceki = 0, lx[5], ly[5];
        int k = 0;
        for (size_t n = 100000; n <= azami; n *= 2) {
            long long kar = 0, toplam = 0;
            double t0 = sure_sn();
            for (int r = 0; r < TEKRAR; r++) {
                volatile int hedef;
                if (d == 0) {
                    hedef = a[0];
                } else if (d == 1) {
                    hedef = -1;             /* dizide yok */
                } else {
                    durum = durum * 6364136223846793005ULL +
                            1442695040888963407ULL;
                    hedef = a[(durum >> 33) % n];
                }
                dogrusal_ara(a, n, hedef, &kar);
                toplam += kar;
            }
            double ns = (sure_sn() - t0) * 1e9 / TEKRAR;
            printf("%9zu %19.1f %15.1f", n, (double)toplam / TEKRAR, ns);
            if (onceki > 0) {
                printf("  %.2f", ns / onceki);
            }
            printf("\n");
            onceki = ns;
            lx[k] = log2((double)n);
            ly[k] = log2(ns);
            k++;
        }
        double mx = 0, my = 0, sxy = 0, sxx = 0;   /* en küçük kareler */
        for (int i = 0; i < k; i++) {
            mx += lx[i] / k;
            my += ly[i] / k;
        }
        for (int i = 0; i < k; i++) {
            sxy += (lx[i] - mx) * (ly[i] - my);
            sxx += (lx[i] - mx) * (lx[i] - mx);
        }
        printf("  log-log eğim (üs kestirimi) = %.2f\n\n", sxy / sxx);
    }
    printf("Rapor: en iyi durum Θ(1); en kötü durum Θ(n); ortalama\n");
    printf("durum (rastgele konum) Θ(n), yaklaşık n/2 karşılaştırma.\n");
    printf("Tüm girdiler için T(n) = O(n) ve T(n) = Ω(1): O bir üst\n");
    printf("sınırdır, \"en kötü durum\" demek değildir; Θ ise üst ve alt\n");
    printf("sınırın çakıştığı yerde (bir durum için) kullanılır.\n");
    free(a);
    return 0;
}

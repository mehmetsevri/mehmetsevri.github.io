/*
 * H02_HA2_en_iyi_durum_olcumu.c — AP-2 Hafta 2 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR: doğrusal aramanın karmaşıklığı yalnızca
 * EN İYİ DURUM girdisiyle (aranan = a[0]) ölçülüp tüm girdilere
 * genellenir ve sonuç "Θ(1)" diye raporlanır (O, Θ ve durum karışıklığı).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA2_en_iyi_durum_olcumu.c -o H02_HA2_en_iyi_durum_olcumu -lm
 * Çalıştır: ./H02_HA2_en_iyi_durum_olcumu
 * Düzeltme: H02_HA2_en_iyi_durum_olcumu_duzeltilmis.c
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TEKRAR 2000                     /* süre ölçümünde arama sayısı */

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

long dogrusal_ara(const int *a, size_t n, int x, long long *kar)
{
    *kar = 0;
    for (size_t i = 0; i < n; i++) {
        (*kar)++;
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

int main(void)
{
    size_t azami = 1600000;
    int *a = malloc(azami * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t i = 0; i < azami; i++) {
        a[i] = (int)(i * 7 + 3);        /* hepsi farklı */
    }
    volatile int hedef = a[0];          /* HATA: hep en iyi durum */
    double onceki = 0;
    printf("        n  karşılaştırma  süre/arama(ns)  oran\n");
    for (size_t n = 100000; n <= azami; n *= 2) {
        long long kar = 0, toplam = 0;
        double t0 = sure_sn();
        for (int r = 0; r < TEKRAR; r++) {
            dogrusal_ara(a, n, hedef, &kar);
            toplam += kar;
        }
        double ns = (sure_sn() - t0) * 1e9 / TEKRAR;
        printf("%9zu %14lld %15.2f", n, toplam / TEKRAR, ns);
        if (onceki > 0) {
            printf("  %.2f", ns / onceki);
        }
        printf("\n");
        onceki = ns;
    }
    double us = log2(1.0);              /* sayaç oranı hep 1 */
    printf("Kestirim: oran ≈ 1 → üs %.2f → doğrusal arama Θ(1)!\n", us);
    printf("Rapor: \"Doğrusal arama sabit zamanlıdır; 10^9 elemanda da"
           " anında biter.\"\n");
    free(a);
    return 0;
}

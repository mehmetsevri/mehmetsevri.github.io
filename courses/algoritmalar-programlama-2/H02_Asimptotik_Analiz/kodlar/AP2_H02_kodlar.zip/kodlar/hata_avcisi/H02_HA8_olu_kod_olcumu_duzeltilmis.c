/*
 * H02_HA8_olu_kod_olcumu_duzeltilmis.c — AP-2 Hafta 2 · Hata Avcısı 8
 * Düzeltme: sonuç kullanılır (toplanıp yazdırılır), böylece derleyici
 *           hesabı silemez. Ayrıca sayaçla (çift sayısı) karşılaştırılır:
 *           süre sıfıra yakınsa önce ölçümden şüphelenin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA8_olu_kod_olcumu_duzeltilmis.c \
 *           -o H02_HA8_olu_kod_olcumu_duzeltilmis
 * Çalıştır: ./H02_HA8_olu_kod_olcumu_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* i < j ve a[i] + a[j] == 0 olan çiftlerin sayısı: Θ(n²) */
long long iki_toplam(const int *a, size_t n)
{
    long long sayi = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (a[i] + a[j] == 0) {
                sayi++;
            }
        }
    }
    return sayi;
}

int main(void)
{
    size_t azami = 16000;
    int *a = malloc(azami * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t i = 0; i < azami; i++) {
        a[i] = (int)(i * 7919 % 2001) - 1000;
    }
    double onceki = 0;
    long long kontrol = 0;
    printf("       n   süre(ms)  oran  sıfır_çift\n");
    for (size_t n = 1000; n <= azami; n *= 2) {
        double t0 = sure_sn();
        long long s = iki_toplam(a, n);     /* DÜZELTME: sonuç kullanılır */
        double ms = (sure_sn() - t0) * 1e3;
        kontrol += s;
        printf("%8zu %10.4f", n, ms);
        if (onceki > 0) {
            printf("  %.2f", ms / onceki);
        } else {
            printf("      ");
        }
        printf("  %lld\n", s);
        onceki = ms;
    }
    printf("Sonuç: oran ≈ 4 → Θ(n²) (kontrol toplamı %lld)\n", kontrol);
    free(a);
    return 0;
}

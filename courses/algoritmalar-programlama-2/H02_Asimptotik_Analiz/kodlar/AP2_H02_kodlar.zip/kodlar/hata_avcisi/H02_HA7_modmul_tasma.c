/*
 * H02_HA7_modmul_tasma.c — AP-2 Hafta 2 · Hata Avcısı 7
 * BU DOSYA KASITLI HATA İÇERİR: modüler üs almada a * b % m çarpımı 64
 * biti aşar. m ≈ 10^12 iken a, b < m çarpımı 10^24'e ulaşır (> 2^64 ≈
 * 1.8 x 10^19); uint64_t sessizce mod 2^64 sarar ve sonuç YANLIŞ olur.
 * Küçük m'li (< 2^32) testler geçtiği için hata gözden kaçar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA7_modmul_tasma.c -o H02_HA7_modmul_tasma
 * Çalıştır: ./H02_HA7_modmul_tasma
 * Düzeltme: H02_HA7_modmul_tasma_duzeltilmis.c
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

/* a^b mod m — HATA: m < 2^32 ön koşulu denetlenmiyor */
uint64_t us_mod(uint64_t a, uint64_t b, uint64_t m)
{
    uint64_t sonuc = 1 % m;
    a %= m;
    while (b > 0) {
        if (b % 2 == 1) {
            sonuc = sonuc * a % m;      /* HATA: sonuc * a taşabilir */
        }
        a = a * a % m;                  /* HATA: a * a taşabilir */
        b /= 2;
    }
    return sonuc;
}

int main(void)
{
    /* Asal m için Fermat: 2^(m-1) mod m = 1 olmalı */
    static const uint64_t asallar[] = {1000000007ULL, 4294967291ULL,
                                       999999999989ULL,
                                       1000000000000000003ULL};
    for (size_t t = 0; t < 4; t++) {
        uint64_t m = asallar[t];
        printf("m = %20" PRIu64 ": 2^(m-1) mod m = %20" PRIu64 "%s\n", m,
               us_mod(2, m - 1, m), us_mod(2, m - 1, m) == 1 ? "" : "  ??");
    }
    uint64_t m = 999999999989ULL;
    printf("(m-1)*(m-1) mod m, m = %" PRIu64 ": %" PRIu64
           " (doğrusu 1)\n", m, (m - 1) * (m - 1) % m);
    return 0;
}

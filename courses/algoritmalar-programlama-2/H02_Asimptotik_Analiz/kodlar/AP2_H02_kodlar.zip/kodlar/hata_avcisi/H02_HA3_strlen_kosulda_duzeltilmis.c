/*
 * H02_HA3_strlen_kosulda_duzeltilmis.c — AP-2 Hafta 2 · Hata Avcısı 3
 * Düzeltme: uzunluk döngüden önce BİR KEZ hesaplanır (O(n)); döngü
 *           toplamda O(n) olur. (C++'ta std::string::size() ve Python'da
 *           len() O(1)'dir: uzunluk nesnede saklanır.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA3_strlen_kosulda_duzeltilmis.c \
 *           -o H02_HA3_strlen_kosulda_duzeltilmis
 * Çalıştır: ./H02_HA3_strlen_kosulda_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* CSV satırındaki virgülleri noktalı virgüle çevirir; değişen sayısı */
size_t ayirici_degistir(char *s)
{
    size_t degisen = 0;
    size_t uzunluk = strlen(s);                 /* DÜZELTME: bir kez */
    for (size_t i = 0; i < uzunluk; i++) {
        if (s[i] == ',') {
            s[i] = ';';
            degisen++;
        }
    }
    return degisen;
}

int main(void)
{
    double onceki = 0;
    printf("       n  değişen  süre(ms)  oran\n");
    for (size_t n = 10000; n <= 10240000; n *= 2) {
        char *s = malloc(n + 1);
        if (s == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            s[i] = (i % 4 == 3) ? ',' : 'a';
        }
        s[n] = '\0';
        double t0 = sure_sn();
        size_t d = ayirici_degistir(s);
        double ms = (sure_sn() - t0) * 1e3;
        printf("%8zu %8zu %9.3f", n, d, ms);
        if (onceki > 0) {
            printf("  %.2f", ms / onceki);
        }
        printf("\n");
        onceki = ms;
        free(s);
    }
    return 0;
}

"""H02_HA4_liste_uyelik.py — AP-2 Hafta 2 · Hata Avcısı 4
BU DOSYA KASITLI HATA İÇERİR: Python'da `x in liste` ifadesi listeyi
baştan sona tarar (O(n)); döngü içinde kullanılınca tekilleştirme O(n²)
olur. Kod kısa ve "tek satır" görünür; maliyeti gizlidir.
Çalıştır: python3 H02_HA4_liste_uyelik.py
Düzeltme: H02_HA4_liste_uyelik_duzeltilmis.py
"""
import time


def tekillestir(a):
    """Sırayı koruyarak yinelenenleri atar."""
    sonuc = []
    for x in a:
        if x not in sonuc:              # HATA: liste taraması, O(len)
            sonuc.append(x)
    return sonuc


def main():
    durum = 42                          # küçük LCG: tekrarlanabilir veri
    veri = []
    for _ in range(64000):
        durum = (durum * 6364136223846793005
                 + 1442695040888963407) & ((1 << 64) - 1)
        veri.append((durum >> 33) % 64000)
    onceki = 0.0
    print("       n  tekil  süre(ms)  oran")
    n = 4000
    while n <= 32000:
        t0 = time.perf_counter()
        t = tekillestir(veri[:n])
        ms = (time.perf_counter() - t0) * 1000
        satir = f"{n:8d} {len(t):6d} {ms:9.1f}"
        if onceki > 0:
            satir += f"  {ms / onceki:.2f}"
        print(satir)
        onceki = ms
        n *= 2


if __name__ == "__main__":
    main()

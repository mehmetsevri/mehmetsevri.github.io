/*
 * H02_HA5_kalbur_tasma.c — AP-2 Hafta 2 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR: dış döngü i <= n'e kadar gider ve iç
 * döngü int j = i * i ile başlar. i > 46340 olunca i * i, 32 bitlik int'i
 * aşar: işaretli taşma TANIMSIZ DAVRANIŞTIR (sarma, çökme ya da sessizce
 * yanlış sonuç). Burada n = 100000 iken i = 46349 asal olduğu anda olur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA5_kalbur_tasma.c -o H02_HA5_kalbur_tasma
 *           (UBSan ile: ... -fsanitize=undefined -o H02_HA5_kalbur_tasma_ub)
 * Çalıştır: ./H02_HA5_kalbur_tasma
 * Düzeltme: H02_HA5_kalbur_tasma_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

/* 0..n kalburu; asal sayısını döndürür */
int kalbur(int n, unsigned char *bilesik)
{
    int asal = 0;
    for (int i = 0; i <= n; i++) {
        bilesik[i] = 0;
    }
    for (int i = 2; i <= n; i++) {              /* HATA 1: i * i <= n değil */
        if (!bilesik[i]) {
            for (int j = i * i; j <= n; j += i) {   /* HATA 2: i*i taşar */
                bilesik[j] = 1;
            }
        }
    }
    for (int i = 2; i <= n; i++) {
        if (!bilesik[i]) {
            asal++;
        }
    }
    return asal;
}

int main(void)
{
    static const int boyutlar[] = {1000, 10000, 46340, 100000};
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        int n = boyutlar[t];
        unsigned char *bilesik = malloc((size_t)n + 1);
        if (bilesik == NULL) {
            return 1;
        }
        printf("N = %d: ", n);
        fflush(stdout);                 /* çökmeden önce yazılsın */
        printf("%d asal\n", kalbur(n, bilesik));
        free(bilesik);
    }
    return 0;
}

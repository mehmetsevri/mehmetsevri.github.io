"""H02_HA4_liste_uyelik_duzeltilmis.py — AP-2 Hafta 2 · Hata Avcısı 4
Düzeltme: görülen değerler bir kümede (set) tutulur; `x in kume`
ortalama O(1) olduğundan tekilleştirme O(n) olur (karma tablosu: H10).
Sıra, ayrı tutulan sonuç listesiyle korunur.
Çalıştır: python3 H02_HA4_liste_uyelik_duzeltilmis.py
"""
import time


def tekillestir(a):
    """Sırayı koruyarak yinelenenleri atar."""
    sonuc = []
    gorulen = set()
    for x in a:
        if x not in gorulen:            # DÜZELTME: küme, ortalama O(1)
            gorulen.add(x)
            sonuc.append(x)
    return sonuc


def main():
    durum = 42
    veri = []
    for _ in range(1024000):
        durum = (durum * 6364136223846793005
                 + 1442695040888963407) & ((1 << 64) - 1)
        veri.append((durum >> 33) % 64000)
    onceki = 0.0
    print("       n  tekil  süre(ms)  oran")
    n = 4000
    while n <= 1024000:
        t0 = time.perf_counter()
        t = tekillestir(veri[:n])
        ms = (time.perf_counter() - t0) * 1000
        satir = f"{n:8d} {len(t):6d} {ms:9.1f}"
        if onceki > 0:
            satir += f"  {ms / onceki:.2f}"
        print(satir)
        onceki = ms
        n *= 2


if __name__ == "__main__":
    main()

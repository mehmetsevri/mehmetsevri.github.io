/*
 * H02_HA3_strlen_kosulda.c — AP-2 Hafta 2 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR: döngü koşulunda gizli maliyet.
 * for (i = 0; i < strlen(s); i++) her turda strlen'i yeniden çağırır;
 * strlen O(n) olduğundan döngü O(n²) olur (AP-1 H13; GTA Online örneği).
 * Döngü s'yi değiştirdiği için derleyici strlen'i döngü dışına alamaz.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA3_strlen_kosulda.c -o H02_HA3_strlen_kosulda
 * Çalıştır: ./H02_HA3_strlen_kosulda
 * Düzeltme: H02_HA3_strlen_kosulda_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* CSV satırındaki virgülleri noktalı virgüle çevirir; değişen sayısı */
size_t ayirici_degistir(char *s)
{
    size_t degisen = 0;
    for (size_t i = 0; i < strlen(s); i++) {    /* HATA: her turda O(n) */
        if (s[i] == ',') {
            s[i] = ';';
            degisen++;
        }
    }
    return degisen;
}

int main(void)
{
    double onceki = 0;
    printf("       n  değişen  süre(ms)  oran\n");
    for (size_t n = 10000; n <= 160000; n *= 2) {
        char *s = malloc(n + 1);
        if (s == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            s[i] = (i % 4 == 3) ? ',' : 'a';    /* "aaa,aaa,..." */
        }
        s[n] = '\0';
        double t0 = sure_sn();
        size_t d = ayirici_degistir(s);
        double ms = (sure_sn() - t0) * 1e3;
        printf("%8zu %8zu %9.3f", n, d, ms);
        if (onceki > 0) {
            printf("  %.2f", ms / onceki);
        }
        printf("\n");
        onceki = ms;
        free(s);
    }
    return 0;
}

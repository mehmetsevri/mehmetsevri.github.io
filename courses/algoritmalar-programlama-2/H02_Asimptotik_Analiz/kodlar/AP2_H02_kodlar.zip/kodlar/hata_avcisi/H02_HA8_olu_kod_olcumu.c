/*
 * H02_HA8_olu_kod_olcumu.c — AP-2 Hafta 2 · Hata Avcısı 8 (ölçüm yanılgısı)
 * BU DOSYA KASITLI HATA İÇERİR: ölçülen fonksiyonun sonucu kullanılmıyor.
 * iki_toplam yan etkisiz (yalnızca okur ve değer döndürür) olduğundan
 * -O2 derleyici çağrıyı "ölü kod" sayıp siler: süre ≈ 0 ölçülür ve
 * Θ(n²) bir işlem "sabit zamanlı" sanılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA8_olu_kod_olcumu.c -o H02_HA8_olu_kod_olcumu
 * Çalıştır: ./H02_HA8_olu_kod_olcumu
 * Düzeltme: H02_HA8_olu_kod_olcumu_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* i < j ve a[i] + a[j] == 0 olan çiftlerin sayısı: Θ(n²) */
long long iki_toplam(const int *a, size_t n)
{
    long long sayi = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            if (a[i] + a[j] == 0) {
                sayi++;
            }
        }
    }
    return sayi;
}

int main(void)
{
    size_t azami = 16000;
    int *a = malloc(azami * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (size_t i = 0; i < azami; i++) {
        a[i] = (int)(i * 7919 % 2001) - 1000;
    }
    double onceki = 0, ilk = -1;
    printf("       n   süre(ms)  oran\n");
    for (size_t n = 1000; n <= azami; n *= 2) {
        double t0 = sure_sn();
        iki_toplam(a, n);                   /* HATA: sonuç atılıyor */
        double ms = (sure_sn() - t0) * 1e3;
        printf("%8zu %10.4f", n, ms);
        if (onceki > 0) {
            printf("  %.2f", ms / onceki);
        }
        printf("\n");
        onceki = ms;
        if (ilk < 0) {
            ilk = ms;
        }
    }
    if (onceki <= 4 * ilk) {            /* n 16 kat büyüdü, süre büyümedi */
        printf("Sonuç: süre n'den bağımsız → \"iki_toplam O(1)\"?!\n");
    } else {
        printf("Sonuç: süre n ile büyüyor (bu derlemede çağrı silinmedi)\n");
    }
    free(a);
    return 0;
}

/*
 * H02_HA5_kalbur_tasma_duzeltilmis.c — AP-2 Hafta 2 · Hata Avcısı 5
 * Düzeltme: dış döngü i <= n / i koşuluyla √n'de durur (i * i hiç
 *           taşmaz ve iç döngüye yalnızca i*i <= n iken girilir); iç döngü
 *           sayacı j, j + i'nin taşmaması için long long'dur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA5_kalbur_tasma_duzeltilmis.c \
 *           -o H02_HA5_kalbur_tasma_duzeltilmis
 * Çalıştır: ./H02_HA5_kalbur_tasma_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

/* 0..n kalburu; asal sayısını döndürür */
int kalbur(int n, unsigned char *bilesik)
{
    int asal = 0;
    for (int i = 0; i <= n; i++) {
        bilesik[i] = 0;
    }
    for (int i = 2; i <= n / i; i++) {          /* i * i <= n, taşmadan */
        if (!bilesik[i]) {
            for (long long j = (long long)i * i; j <= n; j += i) {
                bilesik[j] = 1;
            }
        }
    }
    for (int i = 2; i <= n; i++) {
        if (!bilesik[i]) {
            asal++;
        }
    }
    return asal;
}

int main(void)
{
    static const int boyutlar[] = {1000, 10000, 46340, 100000, 10000000};
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        int n = boyutlar[t];
        unsigned char *bilesik = malloc((size_t)n + 1);
        if (bilesik == NULL) {
            printf("N = %d: bellek yetersiz (%d bayt)\n", n, n + 1);
            continue;
        }
        printf("N = %d: %d asal\n", n, kalbur(n, bilesik));
        free(bilesik);
    }
    return 0;
}

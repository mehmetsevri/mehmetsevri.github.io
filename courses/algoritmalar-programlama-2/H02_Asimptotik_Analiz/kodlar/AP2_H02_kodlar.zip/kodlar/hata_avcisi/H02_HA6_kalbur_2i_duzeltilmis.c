/*
 * H02_HA6_kalbur_2i_duzeltilmis.c — AP-2 Hafta 2 · Hata Avcısı 6
 * Düzeltme: dış döngü i * i <= n iken döner, iç döngü i * i'den başlar:
 *           k < i olan her k*i katı, k'nin asal böleni tarafından zaten
 *           işaretlenmiştir. Sonuç aynı, işaretleme ve süre daha az.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_HA6_kalbur_2i_duzeltilmis.c -o H02_HA6_kalbur_2i_duzeltilmis
 * Çalıştır: ./H02_HA6_kalbur_2i_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double sure_sn(void)
{
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* 0..n kalburu; asal sayısı; *isaret: yazma sayısı */
long kalbur(size_t n, unsigned char *bilesik, long long *isaret)
{
    long asal = 0;
    *isaret = 0;
    for (size_t i = 0; i <= n; i++) {
        bilesik[i] = 0;
    }
    for (size_t i = 2; i * i <= n; i++) {       /* DÜZELTME: √n'e kadar */
        if (!bilesik[i]) {
            for (size_t j = i * i; j <= n; j += i) {    /* DÜZELTME */
                bilesik[j] = 1;
                (*isaret)++;
            }
        }
    }
    for (size_t i = 2; i <= n; i++) {
        if (!bilesik[i]) {
            asal++;
        }
    }
    return asal;
}

int main(void)
{
    printf("         N     π(N)   işaretleme  işaret/N  süre(ms)\n");
    for (size_t n = 1000; n <= 100000000; n *= 10) {
        unsigned char *bilesik = malloc(n + 1);
        if (bilesik == NULL) {
            return 1;
        }
        long long isaret;
        double t0 = sure_sn();
        long p = kalbur(n, bilesik, &isaret);
        double ms = (sure_sn() - t0) * 1e3;
        printf("%10zu %8ld %12lld %9.3f %9.2f\n", n, p, isaret,
               (double)isaret / (double)n, ms);
        free(bilesik);
    }
    return 0;
}

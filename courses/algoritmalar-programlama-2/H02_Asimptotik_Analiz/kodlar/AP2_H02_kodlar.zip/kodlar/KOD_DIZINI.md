# Hafta 2 · Kod dizini (kodlar/)

**Algoritma Analizi: İşlem Sayma, Asimptotik Gösterim ve Büyüme Hızları.** Bu klasördeki her dosya; türü, düzeyi, çıktı türü (“=” üç dilde bayt bayt aynı, “Δ” bilinçli dil farkı) ve materyalde geçtiği yerlerle aşağıdadır. *Ders notu* sütunu bölüm numarasıdır (Ek A.n = dil karşılıkları eki); *Sunum* sütunu slayt numarasıdır; *Web* sütunu haftanın web sayfasındaki bölüm bağlantısıdır. “Örnek n” diye anılan yerler de sayılmıştır.

**Derleme** (GCC 13.3, x86-64 Linux): C `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program -lm`; C++ `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program`; Python `python3 DOSYA.py` (3.10 ve üstü). Her dosyanın başındaki yorumda kendi komutu yazılıdır. Gerçek çıktılar `ciktilar/`, `kavram/ciktilar/`, `alistirmalar/ciktilar/`, `quiz/ciktilar/` ve `hata_avcisi/ciktilar/` altındadır. **Eşdeğerlik:** `python3 esdeger_test.py .` → 13/13 GEÇTİ, derleyici uyarısı 0. Python dosyalarını çalıştırırken `PYTHONDONTWRITEBYTECODE=1` klasörü temiz tutar.

## 1. Örnek merdiveni (her örnek C · C++ · Python)

| Dosya (gövde adı) | Düzey | Çıktı | Amiral | Satır (C/C++/Py) | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H02_01_dogrusal_toplam` (Örnek 1) | ★ | = | — | 79/80/59 | İşlem sayacıyla doğrusal toplamda T(n) = n'in gözlenmesi; temel işlem seçimi sabiti değiştirir, büyüme sınıfını değil | 3.1, 3.2, 5, Ek A.1 | 9 | `#h02-islem-sayma` |
| `H02_02_tum_ciftler` (Örnek 2) | ★ | = | — | 80/89/62 | Bağımlı iç içe döngüde (j = i + 1'den) çift sayısı n(n-1)/2; bağımsız iç içe döngüyle (n*n) karşılaştırma | 3.4, Ek A.2 | — | `#h02-desenler` |
| `H02_03_yariya_inen` (Örnek 3) | ★ | = | — | 81/85/69 | Yarıya inen döngü kaç adım sürer? ⌊log2 n⌋ + 1; üçe bölmeyle karşılaştırma: log tabanı yalnızca sabit çarpandır | 3.4, Ek A.3 | 13 | `#h02-desenler`, `#h02-quiz`, `#h02-alistirmalar` |
| `H02_04_arama_durumlari` (Örnek 4) | ★★ | = | — | 108/107/79 | Doğrusal aramada en iyi, en kötü ve ortalama durum karşılaştırma sayaçları; ortalamanın bir varsayıma bağlılığı | 3.2, 11.1, Ek A.4 | — | `#h02-durumlar` |
| `H02_05_yinelenen_numara` (Örnek 5) | ★★ | = | — | 124/121/83 | Yinelenen öğrenci numarası var mı? O(n²) kaba kuvvet; erken çıkışlı ve tüm çiftleri tarayan sürümün karşılaştırma sayıları | 5.1, 10, Ek A.5 | — | `#h02-merdiven`, `#h02-miniobs` |
| `H02_06_buyume_tablosu` (Örnek 6) | ★★ | = | — | 179/187/130 | Büyüme sınıflarının (log n ... n!) sayısal karşılaştırması ve "1 saniyede çözülebilecek en büyük n" uygulanabilirlik tablosu | 3.5, 5.2, Ek A.6 | 15 | `#h02-buyume` |
| `H02_07_oran_testi` (Örnek 7) | ★★ | = | — | 125/126/95 | Oran testi: n'i ikiye katlayıp T(2n)/T(n) oranından büyüme sınıfını kestirmek (Sedgewick & Wayne, 2011); sayaç ve süre | 3.6, Ek A.7 | — | `#h02-oran-testi` |
| `H02_08_deneme_bolmesi` (Örnek 8) | ★★ | = | evet | 93/96/76 | Deneme bölmesiyle asallık; √n sınırı i * i <= n ile (kayan nokta yok, taşma gerekçeli) ve 2..n-1 saf sürümle karşılaştırma | 4.1, 4.2, 8, Ek A.8 | 22 | `#h02-deneme` |
| `H02_09_kalbur` (Örnek 9) | ★★ | = | evet | 162/165/128 | Eratosthenes kalburu (i * i'den başlatma) ve deneme bölmesiyle asal sayma: işlem sayıları ve zaman–bellek ödünleşimi | 4.2, 11.1, 11.5, Ek A.9 | 28, 30 | `#h02-kalbur`, `#h02-alistirmalar` |
| `H02_10_oklid_lame` (Örnek 10) | ★★★ | = | — | 113/122/92 | Öklid algoritmasında adım (mod) sayısı; ardışık Fibonacci sayılarının en kötü durum olması (Lamé) — tablo ve tam tarama | 5.3, 11.1, Ek A.10 | — | `#h02-merdiven`, `#h02-alistirmalar` |
| `H02_11_hizli_us` (Örnek 11) | ★★★ | = | evet | 138/145/114 | Hızlı üs alma (kare al ve çarp) ile a^b mod m: yinelemeli ve özyinelemeli sürüm, O(log b) çarpma; uint64_t ile güvenli çarpma | 4.3, 7, 11.1, Ek A.11 | 34, 36 | `#h02-hizli-us`, `#h02-quiz` |
| `H02_12_buyuk_tamsayi` (Örnek 12) | ★★★ | Δ | — | 77/79/69 | 2^n'i ikiye katlayarak hesaplamak: C'de uint64_t n >= 64'te sarar (mod 2^64), Python'da büyük tamsayı kesin ama maliyetli | 3.7, 5.4, Ek A.12 | 44 | `#h02-merdiven`, `#h02-oran-testi`, `#h02-quiz`, `#h02-alistirmalar` |
| `H02_13_en_buyuk_alt_dizi` (Örnek 13) | ★★★ | = | evet | 208/209/155 | En büyük alt dizi toplamı: O(n³) → O(n²) → O(n) Kadane (Bentley, 2000); aynı sonuç, farklı toplama sayısı | 4.4, 11.1, 11.4, Ek A.13 | 42 | `#h02-kadane` |

Çıktı dosyaları: “=” örneklerinde `ciktilar/<gövde>.txt`; Δ örneğinde `ciktilar/H02_12_buyuk_tamsayi_{c,cpp,py}.txt` (C ve C++ aynı, Python farklı). Diller arasında farklı yazılan satırlar ve Dil Penceresi notları: `ornekler.json` (`farklar`, `dil_notu`).

## 2. Kavram programları (`kavram/`)

| Dosya | Tür | Satır | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H02_K01_karmasiklik_kartlari.c` | kavram | 215 | "Karmaşıklığını söyle" kart oyunundaki 11 C kod parçası (Kart 12 Python: H02_K02_kart12_liste.py). Önce kartları sınıflandırın; sonra bu programı çalıştırıp sayaç oranlarıyla tahminlerinizi sınayın (oran testi, Sedgewick & Wayne, 2011). | 11.1, 11.2 | — | `#h02-kartlar` |
| `kavram/H02_K02_kart12_liste.py` | kavram | 41 | "Karmaşıklığını söyle" Kart 12 (Python): döngü içinde `x not in sonuc` liste taraması. Önce kartı sınıflandırın; sonra programı çalıştırıp oran testiyle tahmininizi sınayın. | 11.2 | — | `#h02-kartlar` |
| `kavram/H02_K03_sandvic_n0.py` | kavram | 33 | f(n) = 3n² + 10n + 5 için Θ(n²) tanımındaki sabitler: c1 = 3, c2 = 4 ile 3n² ≤ f(n) ≤ 4n² eşitsizliğinin başladığı ilk n0'ı bulmak ve limit yaklaşımını (f(n)/n² → 3) göstermek. Program yalnızca bir sınamadır; kanıt cebirseldir (ders notu 3.3). | 3.3 | — | `#h02-asimptotik` |
| `kavram/H02_K04_uzunluk_maliyeti.c` | kavram | 65 | Aynı görünen döngü koşulu, farklı maliyet: C'de strlen(s) her çağrıda '\0'ı arar (O(n)); C++ std::string::size() ve Python len() uzunluğu nesnede saklar (O(1)). n katlanınca süre oranı. | 8 | — | `#h02-dil` |
| `kavram/H02_K04_uzunluk_maliyeti.cpp` | kavram | 58 | Aynı görünen döngü koşulu, farklı maliyet: C'de strlen(s) her çağrıda '\0'ı arar (O(n)); C++ std::string::size() ve Python len() uzunluğu nesnede saklar (O(1)). n katlanınca süre oranı. | 8 | — | `#h02-dil` |
| `kavram/H02_K04_uzunluk_maliyeti.py` | kavram | 45 | Aynı görünen döngü koşulu, farklı maliyet: C'de strlen(s) her çağrıda '\0'ı arar (O(n)); C++ std::string::size() ve Python len() uzunluğu nesnede saklar (O(1)). n katlanınca süre oranı. | 8 | — | `#h02-dil` |

`H02_K04_uzunluk_maliyeti` üç dilde yazılmıştır ama çıktıları bilinçli olarak farklıdır (Δ): C’deki `strlen` koşulu Θ(n²), C++ `size()` ve Python `len()` Θ(n) verir.

## 3. Alıştırma dosyaları (`alistirmalar/`)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar. Parsons dosyası bu hâliyle derlenmez; satırları sıralandıktan sonra derlenir.

| Dosya | Alıştırma | Satır | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `alistirmalar/H02_A01_cikti_tahmini.c` | 2.1 (çıktı tahmini) | 30 | 11.1 | — | `#h02-alistirmalar` |
| `alistirmalar/H02_A02_karmasiklik.c` | 2.3 (karmaşıklık) | 88 | 11.1 | — | `#h02-alistirmalar` |
| `alistirmalar/H02_A03_hata_bul_us.c` | 2.8 (hata bul) | 36 | 11.1 | — | `#h02-alistirmalar` |
| `alistirmalar/H02_A04_hata_bul_sayac.c` | 2.9 (hata bul) | 32 | 11.1 | — | `#h02-alistirmalar` |
| `alistirmalar/H02_A05_parsons_kadane.c` | 2.10 (Parsons) | 19 | 11.1 | — | `#h02-alistirmalar` |

## 4. Quiz kodu (`quiz/`)

| Dosya | Satır | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `quiz/H02_Q02_ic_ice_yariya.c` | 33 | Dış döngü n kez, iç döngü n'i yarıya indirerek döner; toplam iş kaç? Program sayaçla yanıtı doğrular. | — | — | `#h02-quiz` |

## 5. Ortak modüller (her haftanın arşivinde aynı)

| Dosya | Not |
|---|---|
| `c/ortak_rastgele.h` | LCG arayüzü |
| `c/ortak_rastgele.c` | LCG (tohum 42) |
| `c/zamanlayici.h` | süre ölçümü arayüzü |
| `c/zamanlayici.c` | timespec_get, ortanca |
| `cpp/ortak_rastgele.hpp` | yalnız başlık |
| `cpp/zamanlayici.hpp` | steady_clock |
| `python/ortak_rastgele.py` | LCG |
| `python/zamanlayici.py` | perf_counter |
| `esdeger_test.py` | üç dilin çıktılarını bayt düzeyinde karşılaştırır |

## 6. Haftanın Deneyi (`deney/`)

Derste öğretim üyesi `gizemli.h` başlığını ve derlenmiş kara kutuyu dağıtır. **`deney/*/gizemli.*` gerçekleştirimlerini deney ve Atölye 2 bitene kadar açmayın**: sınıfı ölçümden bulmak bu haftanın amacıdır.

| Dosya | Not | Ders notu | Sunum | Web |
|---|---|---|---|---|
| `deney/c/gizemli.h` | kara kutu arayüzü | 6, 11.3 | — | — |
| `deney/c/gizemli.c` | kara kutu gerçekleştirimi (açmayın) | 6 | — | — |
| `deney/c/oran_deneyi.c` | C sürücüsü (CSV stdout) | 3.5, 3.6, 3.7, 6, 11.3 | 16, 18, 45–46 | `#h02-buyume`, `#h02-oran-testi`, `#h02-deney` |
| `deney/cpp/gizemli.hpp` | kara kutu arayüzü | — | — | — |
| `deney/cpp/gizemli.cpp` | kara kutu gerçekleştirimi (açmayın) | — | — | — |
| `deney/cpp/oran_deneyi.cpp` | C++ sürücüsü | 3.5, 3.6, 3.7, 6, 11.3 | 16, 18, 45–46 | `#h02-buyume`, `#h02-oran-testi`, `#h02-deney` |
| `deney/python/gizemli.py` | kara kutu (açmayın) | — | — | — |
| `deney/python/oran_deneyi.py` | Python sürücüsü | 3.5, 3.6, 3.7, 6, 11.3 | 16, 18, 45–46 | `#h02-buyume`, `#h02-oran-testi`, `#h02-deney` |
| `deney/sonuclar/h02_deney_{c_O2,c_O0,cpp_O2,py}.csv` | ham ölçümler (n, tekrar, ortanca süre, sağlama) | 3.5, 3.6, 3.7, 6, 11.3 | 16, 18, 45–46 | `#h02-deney`, `#h02-buyume`, `#h02-oran-testi` |
| `deney/sonuclar/h02_deney_ozet.csv` | eğim, oran, sabit, düzlük testinin seçtiği model | 3.5, 3.6, 3.7, 6, 11.3 | 16, 18, 45–46 | `#h02-deney`, `#h02-buyume`, `#h02-oran-testi` |
| `deney/OLCUM_ORTAMI.txt` | ölçümün yapıldığı makine ve derleyici | 6 | — | — |

## 7. Hata Avcısı (`hata_avcisi/`)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; her birinin `_duzeltilmis` eşi vardır. Belirtiler `hata_avcisi/ciktilar/` altındaki gerçek çalıştırmalardandır (süreler ölçüm makinesindedir).

| Dosya | Tür | Gerçek belirti | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `hata_avcisi/H02_HA1_buyuk_o_her_zaman.c` | kasıtlı hata (kavramsal) | 20 000 küçük grupta (n = 16) “O(n)” işaret yöntemi 546,6 ms | 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA1_buyuk_o_her_zaman_duzeltilmis.c` | düzeltilmiş | kesişim n = 256–512 arası; melez yöntem 1,8 ms | 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA2_en_iyi_durum_olcumu.c` | kasıtlı hata (kavramsal) | oran ≈ 1 → yanlış “Θ(1)” raporu | 3.2, 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA2_en_iyi_durum_olcumu_duzeltilmis.c` | düzeltilmiş | en iyi / en kötü / ortalama ayrı; log–log eğimler −0,20 / 1,06 / 1,07 | 3.2, 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA3_strlen_kosulda.c` | kasıtlı hata (gizli maliyet) | oranlar 3,65–6,06 (Θ(n²)) | 7, 8 | 47–48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA3_strlen_kosulda_duzeltilmis.c` | düzeltilmiş | oranlar 1,58–2,87 (Θ(n)) | 7, 8 | 47–48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA4_liste_uyelik.py` | kasıtlı hata (gizli maliyet) | oranlar 3,41–3,79 (n = 32 000’de 3,9 s) | 7 | 48 | `#h02-hata-avcisi`, `#h02-quiz` |
| `hata_avcisi/H02_HA4_liste_uyelik_duzeltilmis.py` | düzeltilmiş | küme ile oranlar 1,47–3,05 | 7 | 48 | `#h02-hata-avcisi`, `#h02-quiz` |
| `hata_avcisi/H02_HA5_kalbur_tasma.c` | kasıtlı hata (tanımsız davranış) | N = 100 000’de çökme (SIGSEGV, çıkış 139); UBSan: signed integer overflow: 46349 * 46349 | 4.2, 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA5_kalbur_tasma_duzeltilmis.c` | düzeltilmiş | N = 10 000 000: 664 579 asal | 4.2, 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA6_kalbur_2i.c` | kasıtlı hata (verimlilik) | aynı π(N), %27–39 fazla işaretleme; N = 10⁸: 5,1 s ↔ 2,9 s | 4.2, 7 | 48 | `#h02-hata-avcisi`, `#h02-quiz` |
| `hata_avcisi/H02_HA6_kalbur_2i_duzeltilmis.c` | düzeltilmiş | iç döngü i · i’den, dış döngü i · i ≤ N | 4.2, 7 | 48 | `#h02-hata-avcisi`, `#h02-quiz` |
| `hata_avcisi/H02_HA7_modmul_tasma.c` | kasıtlı hata (taşma, yanlış sonuç) | m = 999 999 999 989 için 2^(m−1) mod m = 0 (Fermat’a göre 1 olmalı) | 4.3, 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA7_modmul_tasma_duzeltilmis.c` | düzeltilmiş | carp_mod ile dört modülde de 1 | 4.3, 7 | 48 | `#h02-hata-avcisi` |
| `hata_avcisi/H02_HA8_olu_kod_olcumu.c` | kasıtlı hata (ölçüm yanılgısı) | -O2’de süre ≈ 0 (ölü kod silindi); -O0’da oranlar 3,86–4,65 | 2, 7, 11.1 | 48 | `#h02-hata-avcisi`, `#h02-alistirmalar` |
| `hata_avcisi/H02_HA8_olu_kod_olcumu_duzeltilmis.c` | düzeltilmiş | sonuç kullanılır; oranlar 3,90–4,14 | 2, 7, 11.1 | 48 | `#h02-hata-avcisi`, `#h02-alistirmalar` |

## 8. Arşiv (`AP2_H02_kodlar.zip`)

Arşiv bu klasörün tamamını içerir (kaynak kodlar, `ciktilar/` klasörleri, `girdiler/`, ortak modüller, deney sonuçları, `ornekler.json`, `esdeger_test.py` ve bu dizin); derleme ürünleri ve `__pycache__` içermez.


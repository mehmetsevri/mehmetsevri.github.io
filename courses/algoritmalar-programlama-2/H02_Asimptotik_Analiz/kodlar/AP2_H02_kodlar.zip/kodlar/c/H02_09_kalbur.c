/*
 * H02_09_kalbur.c — AP-2 Hafta 2 · Örnek 9 (★★)
 * Amaç    : Eratosthenes kalburu (i * i'den başlatma) ve deneme bölmesiyle
 *           asal sayma: işlem sayıları ve zaman–bellek ödünleşimi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H02_09_kalbur.c \
 *           zamanlayici.c -o H02_09_kalbur
 * Çalıştır: ./H02_09_kalbur [N [kalbur]]   (N verilirse yalnızca o N;
 *           "kalbur": deneme bölmesi atlanır)
 * Eşleri  : cpp/H02_09_kalbur.cpp · python/H02_09_kalbur.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "zamanlayici.h"

/* 0..n için kalbur: bilesik[i] = 1 ise i bileşiktir. Asal sayısını
 * döndürür; *isaretleme: bilesik[j] = 1 yazma sayısı (n < 2^32) */
long kalbur(size_t n, unsigned char *bilesik, long long *isaretleme)
{
    long asal = 0;
    size_t i, j;
    *isaretleme = 0;
    for (i = 0; i <= n; i++) {
        bilesik[i] = 0;
    }
    /* i asalsa katlarını i*i'den başlayarak işaretle: daha küçük
     * katlar, daha küçük bir asal tarafından zaten işaretlendi */
    for (i = 2; i * i <= n; i++) {
        if (!bilesik[i]) {
            for (j = i * i; j <= n; j += i) {
                bilesik[j] = 1;
                (*isaretleme)++;
            }
        }
    }
    for (i = 2; i <= n; i++) {
        if (!bilesik[i]) {
            asal++;
        }
    }
    return asal;
}

/* Örnek 8'deki deneme bölmesi (ön koşul n < 2^63) */
bool asal_mi(uint64_t n, uint64_t *bolme)
{
    *bolme = 0;
    if (n < 2) {
        return false;
    }
    for (uint64_t i = 2; i * i <= n; i++) {
        (*bolme)++;
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

/* 2..n arasındaki asalları deneme bölmesiyle sayar */
long deneme_say(uint64_t n, long long *toplam_bolme)
{
    long asal = 0;
    uint64_t b;
    *toplam_bolme = 0;
    for (uint64_t m = 2; m <= n; m++) {
        if (asal_mi(m, &b)) {
            asal++;
        }
        *toplam_bolme += (long long)b;
    }
    return asal;
}

/* Bir N için tablo satırı; süreler stderr'e */
int satir(size_t n, bool deneme_de)
{
    unsigned char *bilesik = malloc(n + 1);  /* n + 1 bayt ek bellek */
    if (bilesik == NULL) {
        fprintf(stderr, "bellek yetersiz (%zu bayt)\n", n + 1);
        return 1;
    }
    long long isaret, bolme = 0;
    double t0 = zaman_sn();
    long p1 = kalbur(n, bilesik, &isaret);
    double t1 = zaman_sn();
    long p2 = -1;
    if (deneme_de) {
        p2 = deneme_say(n, &bolme);
    }
    double t2 = zaman_sn();
    printf("%10zu %8ld ", n, p1);
    if (deneme_de) {
        printf("%8ld %12lld", p2, bolme);
    } else {
        printf("%8s %12s", "-", "-");
    }
    printf(" %11lld %8.3f %11zu\n", isaret, (double)isaret / (double)n,
           n + 1);
    fprintf(stderr, "N=%zu: kalbur %.3f ms", n, (t1 - t0) * 1000);
    if (deneme_de) {
        fprintf(stderr, " · deneme bölmesi %.3f ms", (t2 - t1) * 1000);
    }
    fprintf(stderr, "\n");
    free(bilesik);
    return 0;
}

int main(int argc, char *argv[])
{
    static const size_t boyutlar[] = {10, 100, 1000, 10000, 100000};
    unsigned char bilesik[101];
    long long isaret;

    if (argc > 3 || (argc == 3 && strcmp(argv[2], "kalbur") != 0)) {
        fprintf(stderr, "Kullanım: %s [N [kalbur]]\n", argv[0]);
        return 2;
    }
    if (argc >= 2) {
        char *son;
        errno = 0;
        long long n = strtoll(argv[1], &son, 10);
        if (errno != 0 || *son != '\0' || n < 2 || n > 2000000000LL) {
            fprintf(stderr, "N 2..2000000000 olmalı\n");
            return 2;
        }
        printf("         N     π(N)   deneme        bölme  işaretleme"
               "  işar./N  bellek(B)\n");
        return satir((size_t)n, argc == 2);
    }

    long p = kalbur(100, bilesik, &isaret);
    printf("Kalbur, N = 100: %ld asal, %lld işaretleme\n", p, isaret);
    for (int i = 2, s = 0; i <= 100; i++) {
        if (!bilesik[i]) {
            printf("%4d", i);
            if (++s % 10 == 0) {
                printf("\n");
            }
        }
    }
    printf("\n\n         N     π(N)   deneme        bölme  işaretleme"
           "  işar./N  bellek(B)\n");
    for (size_t t = 0; t < 5; t++) {
        if (satir(boyutlar[t], true) != 0) {
            return 1;
        }
    }
    printf("\nKalbur Θ(N log log N) işaretleme ve N + 1 bayt bellek\n");
    printf("kullanır; deneme bölmesi O(1) bellekle ama çok daha fazla\n");
    printf("işlemle çalışır: zaman–bellek ödünleşimi. N = 10^8 için\n");
    printf("kalbur dizisi yaklaşık 100 MB'tır (bit dizisiyle 12.5 MB).\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok;
 * Python — yok (sympy.primerange üçüncü taraf; kullanılmaz) */

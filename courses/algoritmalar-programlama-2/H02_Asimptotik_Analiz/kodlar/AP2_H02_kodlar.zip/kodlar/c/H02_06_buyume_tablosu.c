/*
 * H02_06_buyume_tablosu.c — AP-2 Hafta 2 · Örnek 6 (★★)
 * Amaç    : Büyüme sınıflarının (log n ... n!) sayısal karşılaştırması ve
 *           "1 saniyede çözülebilecek en büyük n" uygulanabilirlik tablosu
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_06_buyume_tablosu.c -o H02_06_buyume_tablosu -lm
 * Çalıştır: ./H02_06_buyume_tablosu [islem_hizi]   (varsayılan 100000000)
 * Eşleri  : cpp/H02_06_buyume_tablosu.cpp · python/H02_06_buyume_tablosu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* f(n)'yi 12 sütunda yazar; double'a sığmayan (log10 >= 308) değer
 * 10^k biçiminde: değer 10^k ile 10^(k+1) arasındadır */
void deger_yaz(double deger, double lg)
{
    if (lg < 308.0) {
        printf(" %11.3e", deger);
    } else {
        char buf[32];
        snprintf(buf, sizeof buf, "10^%d", (int)floor(lg));
        printf(" %11s", buf);
    }
}

/* 2^n: log10(2^n) = n log10(2); sığıyorsa ikiye katlayarak kesin değer */
void iki_us_yaz(long n)
{
    double lg = (double)n * log10(2.0);
    double d = 1.0;
    if (lg < 308.0) {
        for (long i = 0; i < n; i++) {
            d *= 2.0;
        }
    }
    deger_yaz(d, lg);
}

/* n!: log10(n!) = log10(2) + log10(3) + ... + log10(n) */
void faktoriyel_yaz(long n)
{
    double lg = 0.0;
    for (long k = 2; k <= n; k++) {
        lg += log10((double)k);
    }
    double d = 1.0;
    if (lg < 308.0) {
        for (long k = 2; k <= n; k++) {
            d *= (double)k;
        }
    }
    deger_yaz(d, lg);
}

/* n^k <= butce olan en büyük n (k = 2, 3) */
long long en_buyuk_kuvvet(long long butce, int k)
{
    long long n = 0;
    for (;;) {
        long long m = n + 1, deger = 1;
        for (int i = 0; i < k; i++) {
            deger *= m;
        }
        if (deger > butce) {
            return n;
        }
        n = m;
    }
}

/* n log2 n <= butce olan en büyük n: ikiye katla, sonra ikili ara */
long long en_buyuk_nlogn(long long butce)
{
    long long lo = 1, hi = 2;
    while ((double)hi * log2((double)hi) <= (double)butce) {
        lo = hi;
        hi *= 2;
    }
    while (hi - lo > 1) {               /* f(lo) <= butce < f(hi) */
        long long orta = lo + (hi - lo) / 2;
        if ((double)orta * log2((double)orta) <= (double)butce) {
            lo = orta;
        } else {
            hi = orta;
        }
    }
    return lo;
}

int main(int argc, char *argv[])
{
    static const long boyutlar[] = {10, 100, 1000, 10000, 100000, 1000000};
    long long butce = 100000000;
    if (argc > 2) {
        fprintf(stderr, "Kullanım: %s [islem_hizi]\n", argv[0]);
        return 2;
    }
    if (argc == 2) {
        char *son;
        errno = 0;
        butce = strtoll(argv[1], &son, 10);
        if (errno != 0 || *son != '\0' || butce < 1 || butce > 1000000000) {
            fprintf(stderr, "islem_hizi 1..1000000000 olmalı\n");
            return 2;
        }
    }

    printf("Büyüme tablosu (log tabanı 2; 10^k: double'a sığmaz,"
           " 10^k ile 10^(k+1) arası)\n");
    printf("f(n)   ");
    for (int s = 0; s < 6; s++) {
        printf(" %11ld", boyutlar[s]);
    }
    printf("\n");
    printf("log n  ");
    for (int s = 0; s < 6; s++) {
        double n = (double)boyutlar[s];
        printf(" %11.3e", log2(n));
    }
    printf("\n√n     ");
    for (int s = 0; s < 6; s++) {
        printf(" %11.3e", sqrt((double)boyutlar[s]));
    }
    printf("\nn      ");
    for (int s = 0; s < 6; s++) {
        printf(" %11.3e", (double)boyutlar[s]);
    }
    printf("\nn log n");
    for (int s = 0; s < 6; s++) {
        double n = (double)boyutlar[s];
        printf(" %11.3e", n * log2(n));
    }
    printf("\nn²     ");
    for (int s = 0; s < 6; s++) {
        double n = (double)boyutlar[s];
        printf(" %11.3e", n * n);
    }
    printf("\nn³     ");
    for (int s = 0; s < 6; s++) {
        double n = (double)boyutlar[s];
        printf(" %11.3e", n * n * n);
    }
    printf("\n2^n    ");
    for (int s = 0; s < 6; s++) {
        iki_us_yaz(boyutlar[s]);
    }
    printf("\nn!     ");
    for (int s = 0; s < 6; s++) {
        faktoriyel_yaz(boyutlar[s]);
    }

    printf("\n\n1 saniyede çözülebilecek en büyük n"
           " (saniyede %lld temel işlem)\n", butce);
    printf("log n    2^%lld\n", butce);
    printf("√n       %lld\n", butce * butce);
    printf("n        %lld\n", butce);
    printf("n log n  %lld\n", en_buyuk_nlogn(butce));
    printf("n²       %lld\n", en_buyuk_kuvvet(butce, 2));
    printf("n³       %lld\n", en_buyuk_kuvvet(butce, 3));
    long long n = 0;
    while ((1LL << (n + 1)) <= butce) {
        n++;
    }
    printf("2^n      %lld\n", n);
    long long f = 1;
    n = 0;
    while (f * (n + 1) <= butce) {
        n++;
        f *= n;
    }
    printf("n!       %lld\n", n);
    return 0;
}

/* Kütüphane karşılığı: C — log2, sqrt, lgamma (math.h);
 * C++ — std::log2, std::lgamma; Python — math.log2, math.lgamma */

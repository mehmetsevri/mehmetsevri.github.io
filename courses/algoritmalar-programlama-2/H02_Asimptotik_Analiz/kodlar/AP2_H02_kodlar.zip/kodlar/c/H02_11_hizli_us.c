/*
 * H02_11_hizli_us.c — AP-2 Hafta 2 · Örnek 11 (★★★)
 * Amaç    : Hızlı üs alma (kare al ve çarp) ile a^b mod m: yinelemeli ve
 *           özyinelemeli sürüm, O(log b) çarpma; uint64_t ile güvenli çarpma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_11_hizli_us.c -o H02_11_hizli_us
 * Çalıştır: ./H02_11_hizli_us
 * Eşleri  : cpp/H02_11_hizli_us.cpp · python/H02_11_hizli_us.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define MOD_SINIR 4294967296ULL         /* 2^32 */
#define SAF_SINIR 1000000ULL

/* Ön koşul 1 <= m < 2^32: çarpanlar m'den küçük olduğundan
 * çarpım <= (m-1)² < 2^64 ve uint64_t çarpımı taşmaz. */
bool mod_gecerli(uint64_t m)
{
    return m >= 1 && m < MOD_SINIR;
}

/* a^b mod m, yinelemeli kare-al-çarp; *carpma: çarpma sayısı */
uint64_t us_mod(uint64_t a, uint64_t b, uint64_t m, int *carpma)
{
    uint64_t sonuc = 1 % m;
    a %= m;
    *carpma = 0;
    while (b > 0) {
        if (b % 2 == 1) {   /* son bit 1 */
            sonuc = sonuc * a % m;
            (*carpma)++;
        }
        a = a * a % m;      /* kare al */
        (*carpma)++;
        b /= 2;
    }
    return sonuc;
}

/* a^b mod m, özyinelemeli: a^b = (a^(b/2))² · (b tekse a) */
uint64_t us_mod_oz(uint64_t a, uint64_t b, uint64_t m, int *carpma)
{
    if (b == 0) {
        return 1 % m;
    }
    uint64_t yarim = us_mod_oz(a, b / 2, m, carpma);
    uint64_t sonuc = yarim * yarim % m;
    (*carpma)++;
    if (b % 2 == 1) {
        sonuc = sonuc * (a % m) % m;
        (*carpma)++;
    }
    return sonuc;
}

/* Saf sürüm: b kez çarp — O(b); burada kâhin olarak kullanılır */
uint64_t us_mod_saf(uint64_t a, uint64_t b, uint64_t m, uint64_t *carpma)
{
    uint64_t sonuc = 1 % m;
    *carpma = 0;
    for (uint64_t i = 0; i < b; i++) {
        sonuc = sonuc * (a % m) % m;
        (*carpma)++;
    }
    return sonuc;
}

/* Yinelemeli sürümün her adımını yazar */
void us_mod_izle(uint64_t a, uint64_t b, uint64_t m)
{
    uint64_t sonuc = 1 % m;
    int adim = 0;
    a %= m;
    printf("adım     b  bit  sonuç  taban\n");
    printf("%4d %5" PRIu64 "    - %6" PRIu64 " %6" PRIu64 "\n", adim, b,
           sonuc, a);
    while (b > 0) {
        int bit = (int)(b % 2);
        if (bit == 1) {
            sonuc = sonuc * a % m;
        }
        a = a * a % m;
        b /= 2;
        adim++;
        printf("%4d %5" PRIu64 " %4d %6" PRIu64 " %6" PRIu64 "\n", adim, b,
               bit, sonuc, a);
    }
}

int main(void)
{
    static const uint64_t t[][3] = {
        {2, 10, 1000}, {3, 13, 1000}, {7, 0, 13}, {5, 3, 1},
        {123456789, 1000000, 1000000007}, {2, 1000000006, 1000000007},
        {3, 1000000000000000000ULL, 1000000007},
        {4294967290ULL, 18446744073709551615ULL, 4294967291ULL},
        {2, 10, 4294967311ULL}
    };
    const size_t k = sizeof t / sizeof t[0];

    printf("İzleme: 3^13 mod 1000 (13 = 1101 ikilik; bitler sağdan)\n");
    us_mod_izle(3, 13, 1000);
    printf("\n          a                     b           m       sonuç"
           "  yin   öz      saf  kâhin\n");
    for (size_t s = 0; s < k; s++) {
        uint64_t a = t[s][0], b = t[s][1], m = t[s][2];
        printf("%11" PRIu64 " %21" PRIu64 " %11" PRIu64, a, b, m);
        if (!mod_gecerli(m)) {
            printf("  ön koşul ihlali: m >= 2^32 (çarpım taşabilir)\n");
            continue;
        }
        int c1, c2 = 0;                 /* özyinelemeli sayaç birikir */
        uint64_t r1 = us_mod(a, b, m, &c1);
        uint64_t r2 = us_mod_oz(a, b, m, &c2);
        printf(" %11" PRIu64 " %4d %4d", r1, c1, c2);
        if (r1 != r2) {
            printf("  UYUŞMAZ (özyinelemeli %" PRIu64 ")\n", r2);
            continue;
        }
        if (b <= SAF_SINIR) {
            uint64_t c3;
            uint64_t r3 = us_mod_saf(a, b, m, &c3);
            printf(" %8" PRIu64 "  %s\n", c3, r3 == r1 ? "=" : "FARKLI");
        } else {
            printf(" %8s  %s\n", "-", "-");
        }
    }
    printf("\nÇarpma sayısı = (b'nin bit uzunluğu) + (1 bitlerinin sayısı)\n");
    printf("<= 2 log2 b + 2: O(log b). Saf sürüm b çarpma yapar.\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (pow() double döndürür, mod almaz);
 * C++ — yok; Python — pow(a, b, m) (burada yalnızca kâhin) */

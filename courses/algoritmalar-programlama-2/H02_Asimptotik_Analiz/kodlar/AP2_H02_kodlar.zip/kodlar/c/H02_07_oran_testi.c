/*
 * H02_07_oran_testi.c — AP-2 Hafta 2 · Örnek 7 (★★)
 * Amaç    : Oran testi: n'i ikiye katlayıp T(2n)/T(n) oranından büyüme
 *           sınıfını kestirmek (Sedgewick & Wayne, 2011); sayaç ve süre
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H02_07_oran_testi.c \
 *           ortak_rastgele.c zamanlayici.c -o H02_07_oran_testi
 * Çalıştır: ./H02_07_oran_testi [--azami N] [--tekrar K] [--olc]
 * Eşleri  : cpp/H02_07_oran_testi.cpp · python/H02_07_oran_testi.py
 * Çıktı   : üç dilde aynı (=); ölçülen süreler stderr'e (--olc: stdout'a)
 */
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

/* i < j ve a[i] + a[j] == 0 olan çiftleri sayar: Θ(n²) */
long long iki_toplam(const int *a, size_t n, long long *kar)
{
    long long sayi = 0, k = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            k++;
            if (a[i] + a[j] == 0) {
                sayi++;
            }
        }
    }
    *kar = k;
    return sayi;
}

typedef struct {
    const int *a;
    size_t n;
    long long sonuc;
} Gorev;

void gorev(void *veri)
{
    Gorev *g = veri;
    long long kar;
    g->sonuc = iki_toplam(g->a, g->n, &kar);
}

/* "--ad DEGER" biçimindeki pozitif tamsayı argümanını okur */
bool sayi_oku(const char *s, long *deger)
{
    char *son;
    errno = 0;
    *deger = strtol(s, &son, 10);
    return errno == 0 && *son == '\0' && *deger > 0;
}

int main(int argc, char *argv[])
{
    long azami = 2000, tekrar = 5;
    bool olc = false;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--olc") == 0) {
            olc = true;
        } else if (strcmp(argv[i], "--azami") == 0 && i + 1 < argc &&
                   sayi_oku(argv[i + 1], &azami)) {
            i++;
        } else if (strcmp(argv[i], "--tekrar") == 0 && i + 1 < argc &&
                   sayi_oku(argv[i + 1], &tekrar)) {
            i++;
        } else {
            fprintf(stderr, "Kullanım: %s [--azami N] [--tekrar K] [--olc]\n",
                    argv[0]);
            return 2;
        }
    }
    int *a = malloc((size_t)azami * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)azami, -1000, 1000);

    printf("Oran testi: iki_toplam (i < j, a[i] + a[j] == 0),"
           " a[i] -1000..1000, tohum 42\n");
    printf("       n  sıfır_çift  karşılaştırma  oran(sayaç)  kuram%s\n",
           olc ? "  ortanca_ms  oran(ölçülen)" : "");
    long long onceki_kar = 0;
    double onceki_sure = 0.0;
    for (long n = 250; n <= azami; n *= 2) {
        long long kar;
        long long sayi = iki_toplam(a, (size_t)n, &kar);
        Gorev g = {a, (size_t)n, 0};
        double sure = olc_ortanca(gorev, &g, (int)tekrar) * 1000.0;
        printf("%8ld %11lld %14lld", n, sayi, kar);
        if (onceki_kar > 0) {
            printf(" %12.3f  4.000", (double)kar / (double)onceki_kar);
        } else {
            printf(" %12s  %5s", "-", "-");
        }
        if (olc) {                  /* ölçüm stdout'a: deterministik değil */
            printf(" %11.3f", sure);
            if (onceki_sure > 0.0) {
                printf(" %14.2f", sure / onceki_sure);
            }
        } else {
            fprintf(stderr, "n=%ld: ortanca %.3f ms", n, sure);
            if (onceki_sure > 0.0) {
                fprintf(stderr, " · oran %.2f", sure / onceki_sure);
            }
            fprintf(stderr, "\n");
        }
        printf("\n");
        onceki_kar = kar;
        onceki_sure = sure;
    }
    printf("\nSayaç oranı T(2n)/T(n) = 2(2n-1)/(n-1) -> 4: Θ(n²).\n");
    printf("Ölçülen süre oranı da 4'e yaklaşmalı; küçük n'de sabit\n");
    printf("maliyetler ve ölçüm gürültüsü baskındır (süreler stderr'de).\n");
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — timeit modülü
 * süre ölçer (oran hesabı elle) */

/*
 * H02_10_oklid_lame.c — AP-2 Hafta 2 · Örnek 10 (★★★)
 * Amaç    : Öklid algoritmasında adım (mod) sayısı; ardışık Fibonacci
 *           sayılarının en kötü durum olması (Lamé) — tablo ve tam tarama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_10_oklid_lame.c -o H02_10_oklid_lame
 * Çalıştır: ./H02_10_oklid_lame
 * Eşleri  : cpp/H02_10_oklid_lame.cpp · python/H02_10_oklid_lame.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

#define TARAMA 500

/* ebob(a, b), a >= b >= 0; *adim: kalan (mod) işlemi sayısı */
uint64_t ebob(uint64_t a, uint64_t b, int *adim)
{
    *adim = 0;
    while (b != 0) {
        uint64_t r = a % b;
        a = b;
        b = r;
        (*adim)++;
    }
    return a;
}

/* Her adımı a = q * b + r biçiminde yazar */
void ebob_izle(uint64_t a, uint64_t b)
{
    while (b != 0) {
        printf("  %" PRIu64 " = %" PRIu64 " * %" PRIu64 " + %" PRIu64 "\n",
               a, a / b, b, a % b);
        uint64_t r = a % b;
        a = b;
        b = r;
    }
    printf("  ebob = %" PRIu64 "\n", a);
}

/* Ondalık basamak sayısı */
int basamak(uint64_t x)
{
    int d = 1;
    while (x >= 10) {
        x /= 10;
        d++;
    }
    return d;
}

int main(void)
{
    static const int satirlar[] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
                                   20, 30, 40, 50, 60, 70, 80, 90, 92};
    uint64_t fib[94];
    int adim;

    printf("İzleme: ebob(1071, 462)\n");
    ebob_izle(1071, 462);
    printf("\nİzleme: ebob(89, 55) — ardışık Fibonacci sayıları\n");
    ebob_izle(89, 55);

    fib[1] = 1;
    fib[2] = 1;
    for (int k = 3; k <= 93; k++) {
        fib[k] = fib[k - 1] + fib[k - 2];   /* F(93) < 2^64 */
    }
    printf("\nArdışık Fibonacci çiftleri (F(k+1), F(k)): adım = k - 1\n");
    printf("  k               F(k+1)                 F(k)  adım"
           "  basamak  5*basamak\n");
    for (size_t t = 0; t < sizeof satirlar / sizeof satirlar[0]; t++) {
        int k = satirlar[t];
        ebob(fib[k + 1], fib[k], &adim);
        int d = basamak(fib[k]);
        printf("%3d %20" PRIu64 " %20" PRIu64 " %5d %8d %10d\n", k,
               fib[k + 1], fib[k], adim, d, 5 * d);
    }

    /* Tam tarama: 1 <= b < a <= TARAMA; her adım sayısı için en küçük a */
    int en_kucuk_a[64] = {0}, en_kucuk_b[64] = {0}, en_cok = 0;
    long long cift = 0;
    for (int a = 2; a <= TARAMA; a++) {
        for (int b = 1; b < a; b++) {
            ebob((uint64_t)a, (uint64_t)b, &adim);
            cift++;
            if (en_kucuk_a[adim] == 0) {
                en_kucuk_a[adim] = a;
                en_kucuk_b[adim] = b;
            }
            if (adim > en_cok) {
                en_cok = adim;
            }
        }
    }
    printf("\nTam tarama: 1 <= b < a <= %d (%lld çift), en çok %d adım\n",
           TARAMA, cift, en_cok);
    printf("adım  en küçük a  (b)  Fibonacci?\n");
    for (int s = 1; s <= en_cok; s++) {
        printf("%4d %11d %5d  %s\n", s, en_kucuk_a[s], en_kucuk_b[s],
               (uint64_t)en_kucuk_a[s] == fib[s + 2] &&
               (uint64_t)en_kucuk_b[s] == fib[s + 1] ? "evet" : "HAYIR");
    }
    printf("\ns adım gerektiren en küçük çift (F(s+2), F(s+1)): Fibonacci\n");
    printf("sayıları en kötü durumdur. Adım sayısı ≤ 5 x (küçük sayının\n");
    printf("basamak sayısı) (Lamé): Öklid O(log min(a, b)).\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++17 — std::gcd (<numeric>);
 * Python — math.gcd */

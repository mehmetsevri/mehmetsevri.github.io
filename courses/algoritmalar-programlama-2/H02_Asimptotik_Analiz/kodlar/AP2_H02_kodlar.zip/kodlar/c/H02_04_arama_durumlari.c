/*
 * H02_04_arama_durumlari.c — AP-2 Hafta 2 · Örnek 4 (★★)
 * Amaç    : Doğrusal aramada en iyi, en kötü ve ortalama durum
 *           karşılaştırma sayaçları; ortalamanın bir varsayıma bağlılığı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_04_arama_durumlari.c ortak_rastgele.c \
 *           -o H02_04_arama_durumlari
 * Çalıştır: ./H02_04_arama_durumlari
 * Eşleri  : cpp/H02_04_arama_durumlari.cpp · python/H02_04_arama_durumlari.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define HEDEF_SAYISI 1000

/* a[0..n-1] içinde x'i arar: indis ya da -1; *kar: karşılaştırma sayısı */
long dogrusal_ara(const int *a, size_t n, int x, long long *kar)
{
    *kar = 0;
    for (size_t i = 0; i < n; i++) {
        (*kar)++;                       /* temel işlem: a[i] == x */
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

/* a'daki her elemanı bir kez arar: başarılı aramaların toplam sayacı */
long long basarili_toplam(const int *a, size_t n)
{
    long long toplam = 0, kar;
    for (size_t i = 0; i < n; i++) {
        dogrusal_ara(a, n, a[i], &kar);
        toplam += kar;
    }
    return toplam;
}

int main(void)
{
    static const int k10[] = {42, 17, 8, 99, 23, 4, 16, 15, 61, 30};
    static const int hedefler[] = {42, 30, 5};
    static const size_t boyutlar[] = {10, 100, 1000, 2000};
    long long kar;

    printf("a =");
    for (size_t i = 0; i < 10; i++) {
        printf(" %d", k10[i]);
    }
    printf("   (n = 10)\n");
    for (size_t t = 0; t < 3; t++) {
        long ind = dogrusal_ara(k10, 10, hedefler[t], &kar);
        printf("ara(%d): indis %ld, karşılaştırma %lld\n", hedefler[t], ind,
               kar);
    }
    long long top = basarili_toplam(k10, 10);
    printf("Başarılı aramaların ortalaması: %lld / 10 = %.2f", top,
           (double)top / 10);
    printf("   ((n+1)/2 = %.2f)\n\n", 11 / 2.0);

    printf("Rastgele permütasyon (1..n), tohum 42; %d rastgele hedef 1..2n\n",
           HEDEF_SAYISI);
    printf("       n  en_iyi  en_kötü  ort_başarılı  (n+1)/2"
           "  bulunan  ort_rastgele    model\n");
    for (size_t t = 0; t < 4; t++) {
        size_t n = boyutlar[t];
        int *a = malloc(n * sizeof *a);
        if (a == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            a[i] = (int)i + 1;
        }
        rastgele_tohum(42);
        rastgele_karistir(a, n);
        long long en_iyi, en_kotu;
        dogrusal_ara(a, n, a[0], &en_iyi);      /* ilk eleman */
        dogrusal_ara(a, n, 0, &en_kotu);        /* dizide yok */
        double ort = (double)basarili_toplam(a, n) / (double)n;
        long long bulunan = 0, rtoplam = 0;
        for (int h = 0; h < HEDEF_SAYISI; h++) {
            int x = rastgele_aralik(1, 2 * (int)n);
            if (dogrusal_ara(a, n, x, &kar) >= 0) {
                bulunan++;
            }
            rtoplam += kar;
        }
        double p = (double)bulunan / HEDEF_SAYISI;
        double model = p * ((double)n + 1) / 2 + (1 - p) * (double)n;
        printf("%8zu %7lld %8lld %13.2f %8.2f %8lld %13.2f %8.2f\n", n,
               en_iyi, en_kotu, ort, ((double)n + 1) / 2, bulunan,
               (double)rtoplam / HEDEF_SAYISI, model);
        free(a);
    }
    printf("\nEn iyi durum 1, en kötü durum n karşılaştırma. Başarılı\n");
    printf("aramaların ortalaması (her konum eşit olasılıklı) tam\n");
    printf("(n+1)/2'dir. Hedeflerin yarısı dizide yoksa ortalama\n");
    printf("p(n+1)/2 + (1-p)n modeline yaklaşır: ortalama durum bir\n");
    printf("girdi dağılımı varsayımıdır.\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX lfind); C++ — std::find;
 * Python — a.index(x), x in a */

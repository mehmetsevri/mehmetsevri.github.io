/*
 * H02_02_tum_ciftler.c — AP-2 Hafta 2 · Örnek 2 (★)
 * Amaç    : Bağımlı iç içe döngüde (j = i + 1'den) çift sayısı n(n-1)/2;
 *           bağımsız iç içe döngüyle (n*n) karşılaştırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_02_tum_ciftler.c -o H02_02_tum_ciftler
 * Çalıştır: ./H02_02_tum_ciftler
 * Eşleri  : cpp/H02_02_tum_ciftler.cpp · python/H02_02_tum_ciftler.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

/* i < j olan (i, j) çiftlerini sayar: bağımlı iç içe döngü */
long long tum_ciftler(size_t n)
{
    long long sayac = 0;
    for (size_t i = 0; i < n; i++) {
        for (size_t j = i + 1; j < n; j++) {    /* n - 1 - i kez */
            sayac++;
        }
    }
    return sayac;
}

/* Tüm sıralı (i, j) çiftlerini sayar: bağımsız iç içe döngü */
long long tum_sirali_ciftler(size_t n)
{
    long long sayac = 0;
    for (size_t i = 0; i < n; i++) {
        for (size_t j = 0; j < n; j++) {        /* her i için n kez */
            sayac++;
        }
    }
    return sayac;
}

/* Küçük n için çiftleri satır satır yazar: işlem üçgeni */
void ucgen_yaz(size_t n)
{
    long long toplam = 0;
    for (size_t i = 0; i < n; i++) {
        long long satir = 0;
        printf("i=%zu:", i);
        for (size_t j = i + 1; j < n; j++) {
            printf(" (%zu,%zu)", i, j);
            satir++;
        }
        printf("%*s  -> %lld\n", (int)(6 * i), "", satir);
        toplam += satir;
    }
    printf("toplam = %lld = %zu*%zu/2\n", toplam, n, n - 1);
}

int main(void)
{
    static const size_t boyutlar[] = {0, 1, 2, 5, 10, 100, 1000, 2000};
    const size_t k = sizeof boyutlar / sizeof boyutlar[0];

    printf("n = 5 için i < j çiftleri (i. satırda n-1-i çift):\n");
    ucgen_yaz(5);
    printf("\n       n   bağımlı  n(n-1)/2   bağımsız  oran\n");
    for (size_t t = 0; t < k; t++) {
        size_t n = boyutlar[t];
        long long b = tum_ciftler(n);
        long long s = tum_sirali_ciftler(n);
        long long kuram = (long long)n * ((long long)n - 1) / 2;
        printf("%8zu %9lld %9lld %10lld  ", n, b, kuram, s);
        if (b > 0) {
            printf("%.3f\n", (double)s / (double)b);
        } else {
            printf("-\n");
        }
    }
    printf("\nBağımlı döngü tam n(n-1)/2 kez döner; bağımsız döngü n*n.\n");
    printf("Oran 2'ye yaklaşır: ikisi de Θ(n²), sabitleri farklı.\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok;
 * Python — itertools.combinations(range(n), 2) çiftleri üretir */

/*
 * H02_01_dogrusal_toplam.c — AP-2 Hafta 2 · Örnek 1 (★)
 * Amaç    : İşlem sayacıyla doğrusal toplamda T(n) = n'in gözlenmesi;
 *           temel işlem seçimi sabiti değiştirir, büyüme sınıfını değil
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_01_dogrusal_toplam.c ortak_rastgele.c -o H02_01_dogrusal_toplam
 * Çalıştır: ./H02_01_dogrusal_toplam
 * Eşleri  : cpp/H02_01_dogrusal_toplam.cpp · python/H02_01_dogrusal_toplam.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define N_AZAMI 100000

/* a[0..n-1] toplamı; *islem: temel işlem (toplama) sayısı */
long long dogrusal_toplam(const int *a, size_t n, long long *islem)
{
    long long toplam = 0;
    *islem = 0;
    for (size_t i = 0; i < n; i++) {
        toplam += a[i];
        (*islem)++;                 /* temel işlem: bir toplama */
    }
    return toplam;
}

/* Aynı döngü; RAM modelinde her ilkel adım sayılır */
long long ayrintili_sayim(const int *a, size_t n, long long *adim)
{
    long long toplam = 0;
    *adim = 2;                      /* toplam = 0 ve i = 0: 2 atama */
    for (size_t i = 0; i < n; i++) {
        toplam += a[i];
        *adim += 3;                 /* i < n sınaması, toplama, i++ */
    }
    *adim += 1;                     /* döngüyü bitiren son i < n */
    return toplam;
}

int main(void)
{
    static const size_t boyutlar[] = {0, 1, 10, 100, 1000, 10000, 100000};
    const size_t k = sizeof boyutlar / sizeof boyutlar[0];
    int *a = malloc(N_AZAMI * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, N_AZAMI, 0, 99);

    printf("Doğrusal toplam (a[i] değerleri 0..99, tohum 42)\n");
    printf("a[0..9] =");
    for (size_t i = 0; i < 10; i++) {
        printf(" %d", a[i]);
    }
    printf("\n\n");
    printf("       n      toplam   toplama  =n?     ayrıntılı  =3n+3?\n");
    for (size_t t = 0; t < k; t++) {
        size_t n = boyutlar[t];
        long long islem, adim;
        long long toplam = dogrusal_toplam(a, n, &islem);
        ayrintili_sayim(a, n, &adim);
        printf("%8zu %11lld %9lld  %-5s %11lld  %s\n", n, toplam, islem,
               islem == (long long)n ? "evet" : "HAYIR", adim,
               adim == 3 * (long long)n + 3 ? "evet" : "HAYIR");
    }
    printf("\nToplama sayısı her n için tam n: T(n) = n.\n");
    printf("Ayrıntılı sayım 3n + 3; ikisi de Θ(n): temel işlem seçimi\n");
    printf("yalnızca sabit çarpanı değiştirir.\n");
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle döngü); C++ — std::accumulate;
 * Python — sum(a) */

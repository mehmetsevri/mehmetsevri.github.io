/*
 * H02_05_yinelenen_numara.c — AP-2 Hafta 2 · Örnek 5 (★★)
 * Amaç    : Yinelenen öğrenci numarası var mı? O(n²) kaba kuvvet; erken
 *           çıkışlı ve tüm çiftleri tarayan sürümün karşılaştırma sayıları
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_05_yinelenen_numara.c ortak_rastgele.c \
 *           -o H02_05_yinelenen_numara
 * Çalıştır: ./H02_05_yinelenen_numara
 * Eşleri  : cpp/H02_05_yinelenen_numara.cpp ·
 *           python/H02_05_yinelenen_numara.py
 * Çıktı   : üç dilde aynı (=) — Mini-OBS 2 v2.1 yinelenen.c ile aynı fikir
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

/* İlk eşit çifti (i, j) bulunca durur; *kar: karşılaştırma sayısı */
bool yinelenen_var_mi(const long long *no, size_t n, size_t *ilk_i,
                      size_t *ilk_j, long long *kar)
{
    *kar = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            (*kar)++;
            if (no[i] == no[j]) {
                *ilk_i = i;
                *ilk_j = j;
                return true;                    /* erken çıkış */
            }
        }
    }
    return false;
}

/* Tüm çiftleri tarar: eşit çift sayısını döndürür */
long long yinelenen_bul(const long long *no, size_t n, long long *kar)
{
    long long cift = 0;
    *kar = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            (*kar)++;
            if (no[i] == no[j]) {
                cift++;
            }
        }
    }
    return cift;
}

void senaryo(const char *ad, const long long *no, size_t n)
{
    size_t i = 0, j = 0;
    long long k1, k2;
    bool var = yinelenen_var_mi(no, n, &i, &j, &k1);
    long long cift = yinelenen_bul(no, n, &k2);
    printf("%s n=%zu: var_mi=%s", ad, n, var ? "EVET" : "HAYIR");
    if (var) {
        printf(" (%zu,%zu)", i, j);
    }
    printf(" kar=%lld | bul: %lld çift, kar=%lld\n", k1, cift, k2);
}

int main(void)
{
    static const long long s1[] = {11, 22, 33, 44, 55};
    static const long long s2[] = {7, 3, 7, 5, 3, 7};
    static const long long s3[] = {9, 9, 1, 2, 3, 4};
    static const long long s4[] = {1, 2, 3, 4, 8, 8};
    static const size_t boyutlar[] = {500, 1000, 2000};

    printf("Küçük senaryolar (Mini-OBS 2 v2.1 test senaryoları 1-4):\n");
    senaryo("S1", s1, 5);
    senaryo("S2", s2, 6);
    senaryo("S3", s3, 6);
    senaryo("S4", s4, 6);

    printf("\nÖğrenci numaraları 2400000000 + karıştırılmış 0..n-1"
           " (tohum 42)\n");
    printf("       n  durum        var_mi  kar(erken)   çift"
           "  kar(tümü)   n(n-1)/2\n");
    for (size_t t = 0; t < 3; t++) {
        size_t n = boyutlar[t];
        int *sira = malloc(n * sizeof *sira);
        long long *no = malloc(n * sizeof *no);
        if (sira == NULL || no == NULL) {
            free(sira);
            free(no);
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            sira[i] = (int)i;
        }
        rastgele_tohum(42);
        rastgele_karistir(sira, n);
        for (size_t i = 0; i < n; i++) {
            no[i] = 2400000000LL + sira[i];
        }
        for (int kopya = 0; kopya < 2; kopya++) {
            if (kopya == 1) {           /* bir numarayı başka yere kopyala */
                size_t hedef = (size_t)rastgele_aralik(1, (int)n - 1);
                no[hedef] = no[0];
            }
            size_t i = 0, j = 0;
            long long k1, k2;
            bool var = yinelenen_var_mi(no, n, &i, &j, &k1);
            long long cift = yinelenen_bul(no, n, &k2);
            printf("%8zu  %-11s  %-6s %11lld %6lld %10lld %10lld\n", n,
                   kopya ? "1-yinelenen" : "temiz", var ? "EVET" : "HAYIR",
                   k1, cift, k2, (long long)(n * (n - 1) / 2));
        }
        free(sira);
        free(no);
    }
    printf("\nTüm çiftler her girdide tam n(n-1)/2 karşılaştırma yapar.\n");
    printf("Erken çıkış en iyi durumda 1 karşılaştırmaya iner; ama temiz\n");
    printf("dosyada (en kötü durum) kazancı yoktur: ikisi de O(n²).\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort + komşu karşılaştırma: H6);
 * C++ — std::sort + std::adjacent_find; Python — len(set(no)) < len(no) */

/*
 * H02_08_deneme_bolmesi.c — AP-2 Hafta 2 · Örnek 8 (★★)
 * Amaç    : Deneme bölmesiyle asallık; √n sınırı i * i <= n ile (kayan
 *           nokta yok, taşma gerekçeli) ve 2..n-1 saf sürümle karşılaştırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_08_deneme_bolmesi.c -o H02_08_deneme_bolmesi
 * Çalıştır: ./H02_08_deneme_bolmesi
 * Eşleri  : cpp/H02_08_deneme_bolmesi.cpp · python/H02_08_deneme_bolmesi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define SAF_SINIR 2000000u

/* n asal mı? Bölen adayları i = 2, 3, ... ve i * i <= n.
 * Ön koşul n < 2^63: döngü en geç i = ⌊√n⌋ + 1'de biter ve
 * (⌊√n⌋ + 1)² <= n + 2√n + 1 < 2^64 olduğundan i * i taşmaz.
 * *bolme: yapılan kalan (%) işlemi sayısı */
bool asal_mi(uint64_t n, uint64_t *bolme)
{
    *bolme = 0;
    if (n < 2) {
        return false;
    }
    for (uint64_t i = 2; i * i <= n; i++) {
        (*bolme)++;
        if (n % i == 0) {
            return false;   /* i böler */
        }
    }
    return true;
}

/* Saf sürüm: 2 .. n-1 arasındaki tüm adaylar */
bool asal_mi_saf(uint64_t n, uint64_t *bolme)
{
    *bolme = 0;
    if (n < 2) {
        return false;
    }
    for (uint64_t i = 2; i < n; i++) {
        (*bolme)++;
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

int main(void)
{
    static const uint64_t ornekler[] = {
        1, 2, 4, 17, 25, 91, 97, 7919, 999999, 1000003, 2147483647,
        1000000007, 1000036000099ULL, 999999999989ULL
    };
    const size_t k = sizeof ornekler / sizeof ornekler[0];
    uint64_t b1, b2;

    printf("İzleme n = 91: aday");
    for (uint64_t i = 2; i * i <= 91; i++) {
        printf(" %" PRIu64, i);
        if (91 % i == 0) {
            printf(" -> %" PRIu64 " böler, 91 = %" PRIu64 " * %" PRIu64,
                   i, i, 91 / i);
            break;
        }
    }
    printf("\nİzleme n = 97: aday 2..9 (10 * 10 > 97), hiçbiri bölmez\n\n");

    printf("                   n  asal  bölme(√n)  bölme(saf)\n");
    for (size_t t = 0; t < k; t++) {
        uint64_t n = ornekler[t];
        bool a = asal_mi(n, &b1);
        printf("%20" PRIu64 "  %s %9" PRIu64, n, a ? "evet " : "hayır",
               b1);                     /* "hayır" 5 harf ama 6 bayt */
        if (n <= SAF_SINIR) {
            bool s = asal_mi_saf(n, &b2);
            printf(" %11" PRIu64 "%s\n", b2, s == a ? "" : "  UYUŞMAZ");
        } else {
            printf(" %11s\n", "-");
        }
    }
    printf("\nAsal n için √n sürüm ⌊√n⌋ - 1 bölme yapar, saf sürüm n - 2.\n");
    printf("Bileşik n'de ikisi de en küçük bölende durur (en iyi durum:\n");
    printf("çift n, 1 bölme). En kötü durum O(√n).\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok;
 * Python — yok (sympy.isprime üçüncü taraf; kullanılmaz) */

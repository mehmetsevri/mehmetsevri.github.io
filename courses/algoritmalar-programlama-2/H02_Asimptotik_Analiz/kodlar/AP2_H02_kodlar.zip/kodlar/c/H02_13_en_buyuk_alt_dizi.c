/*
 * H02_13_en_buyuk_alt_dizi.c — AP-2 Hafta 2 · Örnek 13 (★★★)
 * Amaç    : En büyük alt dizi toplamı: O(n³) → O(n²) → O(n) Kadane
 *           (Bentley, 2000); aynı sonuç, farklı toplama sayısı
 * Sözleşme: n >= 1; alt dizi BOŞ OLAMAZ (en az bir eleman). Tamamı negatif
 *           dizide sonuç en büyük elemandır. Eşitlikte ilk bulunan aralık.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_13_en_buyuk_alt_dizi.c ortak_rastgele.c zamanlayici.c \
 *           -o H02_13_en_buyuk_alt_dizi
 * Çalıştır: ./H02_13_en_buyuk_alt_dizi [n [sinir]]  (n: süre ölçümü; bir
 *           sürüm toplama sayısı sinir'i, varsayılan 10^9, aşmıyorsa çalışır)
 * Eşleri  : cpp/H02_13_en_buyuk_alt_dizi.cpp ·
 *           python/H02_13_en_buyuk_alt_dizi.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

typedef struct {
    long long toplam;                   /* en büyük alt dizi toplamı */
    size_t bas, son;                    /* aralık a[bas..son] */
    long long topl;                     /* yapılan toplama sayısı */
} Sonuc;

/* O(n³): her (i, j) için a[i..j] baştan toplanır */
Sonuc kubik(const int *a, size_t n)
{
    Sonuc s = {a[0], 0, 0, 0};
    for (size_t i = 0; i < n; i++) {
        for (size_t j = i; j < n; j++) {
            long long toplam = 0;
            for (size_t k = i; k <= j; k++) {
                toplam += a[k];
                s.topl++;
            }
            if (toplam > s.toplam) {
                s.toplam = toplam;
                s.bas = i;
                s.son = j;
            }
        }
    }
    return s;
}

/* O(n²): a[i..j] toplamı, a[i..j-1] toplamına a[j] eklenerek */
Sonuc karesel(const int *a, size_t n)
{
    Sonuc s = {a[0], 0, 0, 0};
    for (size_t i = 0; i < n; i++) {
        long long toplam = 0;
        for (size_t j = i; j < n; j++) {
            toplam += a[j];
            s.topl++;
            if (toplam > s.toplam) {
                s.toplam = toplam;
                s.bas = i;
                s.son = j;
            }
        }
    }
    return s;
}

/* O(n) Kadane: simdiki = a[i]'de biten en iyi alt dizinin toplamı.
 * uzat < a[i] ise önceki kısım zarar ettiriyordur: a[i]'den yeniden başla */
Sonuc kadane(const int *a, size_t n)
{
    Sonuc s = {a[0], 0, 0, 0};
    long long simdiki = a[0];
    size_t s_bas = 0;
    for (size_t i = 1; i < n; i++) {
        long long uzat = simdiki + a[i];
        s.topl++;
        if (uzat < a[i]) {
            simdiki = a[i];
            s_bas = i;
        } else {
            simdiki = uzat;
        }
        if (simdiki > s.toplam) {
            s.toplam = simdiki;
            s.bas = s_bas;
            s.son = i;
        }
    }
    return s;
}

void dizi_coz(const char *ad, const int *a, size_t n)
{
    Sonuc s1 = kubik(a, n), s2 = karesel(a, n), s3 = kadane(a, n);
    printf("%s (n=%zu): kübik %lld [%zu..%zu] · karesel %lld [%zu..%zu]"
           " · Kadane %lld [%zu..%zu]\n", ad, n, s1.toplam, s1.bas, s1.son,
           s2.toplam, s2.bas, s2.son, s3.toplam, s3.bas, s3.son);
}

/* Süre ölçümü kipi: toplama sayısı sinir'i aşmayan sürümler çalışır */
int sure_olc(size_t n, double sinir)
{
    static const char *const adlar[3] = {"Kadane", "karesel", "kübik"};
    double nd = (double)n;
    double islem[3] = {nd - 1, nd * (nd + 1) / 2, nd * (nd + 1) * (nd + 2) / 6};
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, n, -100, 100);
    printf("n=%zu", n);
    for (int v = 0; v < 3; v++) {
        if (islem[v] > sinir) {
            printf(" · %s atlandı (%.2e toplama)", adlar[v], islem[v]);
            continue;
        }
        double z0 = zaman_sn();
        Sonuc s = v == 0 ? kadane(a, n) : v == 1 ? karesel(a, n)
                                                  : kubik(a, n);
        double z1 = zaman_sn();
        printf(" · %s %lld", adlar[v], s.toplam);
        fprintf(stderr, "n=%zu %s: %.3f ms\n", n, adlar[v], (z1 - z0) * 1e3);
    }
    printf("\n");
    free(a);
    return 0;
}

int main(int argc, char *argv[])
{
    static const int bentley[] = {31, -41, 59, 26, -53, 58, 97, -93, -23,
                                  84};
    static const int negatif[] = {-3, -1, -2};
    static const int tek[] = {5};
    static const int sifir[] = {0, -1, 0};
    static const int klasik[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    static const size_t boyutlar[] = {10, 100, 200, 1000, 2000, 10000,
                                      100000};

    if (argc == 2 || argc == 3) {       /* süre ölçümü kipi */
        char *son;
        errno = 0;
        long n = strtol(argv[1], &son, 10);
        double sinir = 1e9;
        if (errno != 0 || *son != '\0' || n < 1 || n > 100000000) {
            fprintf(stderr, "n 1..100000000 olmalı\n");
            return 2;
        }
        if (argc == 3) {
            sinir = strtod(argv[2], &son);
            if (*son != '\0' || sinir <= 0) {
                fprintf(stderr, "sinir pozitif bir sayı olmalı\n");
                return 2;
            }
        }
        return sure_olc((size_t)n, sinir);
    }
    if (argc > 3) {
        fprintf(stderr, "Kullanım: %s [n [sinir]]\n", argv[0]);
        return 2;
    }

    dizi_coz("Bentley", bentley, 10);
    dizi_coz("Tümü negatif", negatif, 3);
    dizi_coz("Tek eleman", tek, 1);
    dizi_coz("Sıfırlar", sifir, 3);
    dizi_coz("Klasik", klasik, 9);

    int *a = malloc(100000 * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, 100000, -100, 100);
    printf("\nRastgele a[i] -100..100 (tohum 42); toplama sayıları\n");
    printf("       n  en_büyük     kübik   n(n+1)(n+2)/6  karesel  Kadane\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        size_t n = boyutlar[t];
        Sonuc s3 = kadane(a, n);
        printf("%8zu %9lld", n, s3.toplam);
        if (n <= 200) {
            Sonuc s1 = kubik(a, n);
            printf(" %9lld%s", s1.topl, s1.toplam == s3.toplam ? "" : "!");
        } else {
            printf(" %9s", "-");
        }
        printf(" %15zu", n * (n + 1) * (n + 2) / 6);
        if (n <= 2000) {
            Sonuc s2 = karesel(a, n);
            printf(" %8lld%s", s2.topl, s2.toplam == s3.toplam ? "" : "!");
        } else {
            printf(" %8s", "-");
        }
        printf(" %7lld\n", s3.topl);
    }
    printf("\nÜç sürüm aynı toplamı bulur (uyuşmazlık '!' ile\n");
    printf("işaretlenirdi). Toplama sayıları n(n+1)(n+2)/6, n(n+1)/2 ve\n");
    printf("n - 1: n = 100000'de kübik sürüm 1.7 x 10^14 toplama isterdi,\n");
    printf("Kadane 99999 toplama yapar.\n");
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — yok
 * (itertools.accumulate önek toplamı verir, Kadane'yi vermez) */

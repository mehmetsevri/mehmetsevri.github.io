/*
 * H02_12_buyuk_tamsayi.c — AP-2 Hafta 2 · Örnek 12 (★★★)
 * Amaç    : 2^n'i ikiye katlayarak hesaplamak: C'de uint64_t n >= 64'te
 *           sarar (mod 2^64), Python'da büyük tamsayı kesin ama maliyetli
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_12_buyuk_tamsayi.c zamanlayici.c -o H02_12_buyuk_tamsayi -lm
 * Çalıştır: ./H02_12_buyuk_tamsayi
 * Eşleri  : cpp/H02_12_buyuk_tamsayi.cpp · python/H02_12_buyuk_tamsayi.py
 * Çıktı   : Δ — dile özgü (uint64_t sarması); bkz. Dil Penceresi
 */
#include <inttypes.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>

#include "zamanlayici.h"

/* 2^n: n kez ikiye katla. uint64_t 2^64 modunda sarar (tanımlı
 * davranış): n >= 64 için sonuç 0'dır. Her katlama O(1). */
uint64_t iki_us(int n)
{
    uint64_t x = 1;
    for (int i = 0; i < n; i++) {
        x = x * 2;
    }
    return x;
}

/* x'in ikilik basamak (bit) sayısı; x = 0 için 0 */
int bit_uzunlugu(uint64_t x)
{
    int b = 0;
    while (x > 0) {
        x /= 2;
        b++;
    }
    return b;
}

/* 3^e: tamsayı çarpımıyla (e <= 40 için uint64_t'ye sığar) */
uint64_t uc_us(int e)
{
    uint64_t x = 1;
    for (int i = 0; i < e; i++) {
        x *= 3;
    }
    return x;
}

int main(void)
{
    static const int boyutlar[] = {1, 10, 63, 64, 65, 100, 1000, 10000,
                                   100000};
    const size_t k = sizeof boyutlar / sizeof boyutlar[0];

    printf("2^n, ikiye katlayarak (uint64_t)\n");
    printf("     n  bit_uzunluğu  son_6_basamak  mod_1000000007\n");
    for (size_t t = 0; t < k; t++) {
        int n = boyutlar[t];
        double t0 = zaman_sn();
        uint64_t x = iki_us(n);
        double sure = zaman_sn() - t0;
        printf("%6d %13d %14.6" PRIu64 " %15" PRIu64 "\n", n,
               bit_uzunlugu(x), x % 1000000, x % 1000000007);
        fprintf(stderr, "n=%d: %.3f ms\n", n, sure * 1000);
    }

    uint64_t kesin = uc_us(39);
    uint64_t yaklasik = (uint64_t)pow(3.0, 39.0);   /* double: 53 bit */
    printf("\n3^39 tamsayı çarpımıyla : %" PRIu64 "\n", kesin);
    printf("3^39 pow() ile (double) : %" PRIu64 "\n", yaklasik);
    printf("fark                    : %" PRIu64 "\n", kesin - yaklasik);
    return 0;
}

/* Kütüphane karşılığı: C — yok (GMP üçüncü taraf: mpz_ui_pow_ui);
 * C++ — yok (Boost.Multiprecision); Python — 2 ** n, 1 << n */

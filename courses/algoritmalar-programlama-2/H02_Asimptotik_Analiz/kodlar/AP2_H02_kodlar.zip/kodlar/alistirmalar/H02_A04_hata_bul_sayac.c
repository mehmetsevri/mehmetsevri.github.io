/*
 * H02_A04_hata_bul_sayac.c — AP-2 Hafta 2 · Alıştırma 2.9 (hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: tüm çiftler sayacı n = 100000 için
 * kuramsal n(n-1)/2 değerinden farklı çıkıyor. Hata nerede, neden
 * yalnızca büyük n'de görünüyor? Düzeltin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_A04_hata_bul_sayac.c -o H02_A04_hata_bul_sayac
 * Çalıştır: ./H02_A04_hata_bul_sayac
 */
#include <stdio.h>

unsigned int tum_ciftler(unsigned int n)
{
    unsigned int sayac = 0;
    for (unsigned int i = 0; i < n; i++) {
        for (unsigned int j = i + 1; j < n; j++) {
            sayac++;
        }
    }
    return sayac;
}

int main(void)
{
    static const unsigned int boyut[] = {1000, 10000, 100000};
    for (int t = 0; t < 3; t++) {
        unsigned int n = boyut[t];
        printf("n = %6u: sayaç %10u, kuram %10llu\n", n, tum_ciftler(n),
               (unsigned long long)n * (n - 1) / 2);
    }
    return 0;
}

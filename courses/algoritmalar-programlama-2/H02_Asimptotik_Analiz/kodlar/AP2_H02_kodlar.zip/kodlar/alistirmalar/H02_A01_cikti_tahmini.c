/*
 * H02_A01_cikti_tahmini.c — AP-2 Hafta 2 · Alıştırma 2.1 (çıktı tahmini)
 * Amaç    : Çalıştırmadan önce her s değerini elle hesaplayın; sonra
 *           programı çalıştırıp tahminlerinizi denetleyin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_A01_cikti_tahmini.c -o H02_A01_cikti_tahmini
 * Çalıştır: ./H02_A01_cikti_tahmini
 */
#include <stdio.h>

int main(void)
{
    int n = 16;
    int s1 = 0, s2 = 0, s3 = 0;
    for (int i = 1; i < n; i *= 2) {
        for (int j = 0; j < n; j++) {
            s1++;
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            s2++;
        }
    }
    for (int i = n; i > 0; i /= 4) {
        s3++;
    }
    printf("s1 = %d, s2 = %d, s3 = %d\n", s1, s2, s3);
    return 0;
}

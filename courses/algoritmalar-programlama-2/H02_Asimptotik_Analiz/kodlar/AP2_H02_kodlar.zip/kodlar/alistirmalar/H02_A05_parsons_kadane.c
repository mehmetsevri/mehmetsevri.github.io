/*
 * H02_A05_parsons_kadane.c — AP-2 Hafta 2 · Alıştırma 2.10 (Parsons)
 * Kadane fonksiyonunun satırları karıştırılmıştır.
 * Kod tamamlanacak; bu hâliyle derlenmez. Satırları doğru sıraya ve
 * girintiye koyun; sonra Örnek 13 (H02_13_en_buyuk_alt_dizi.c) ile
 * karşılaştırın.
 */
        if (simdiki > en_iyi) {
    long long en_iyi = a[0], simdiki = a[0];
    return en_iyi;
            en_iyi = simdiki;
long long kadane(const int *a, size_t n)
        long long uzat = simdiki + a[i];
        simdiki = (uzat < a[i]) ? a[i] : uzat;
    for (size_t i = 1; i < n; i++) {
{
        }
    }
}

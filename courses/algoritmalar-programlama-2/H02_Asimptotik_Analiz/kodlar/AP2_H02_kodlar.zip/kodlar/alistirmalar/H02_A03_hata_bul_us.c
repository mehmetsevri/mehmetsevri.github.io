/*
 * H02_A03_hata_bul_us.c — AP-2 Hafta 2 · Alıştırma 2.8 (hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: hızlı üs fonksiyonunda iki hata vardır;
 * küçük testler yine de geçer. Hataları bulun ve düzeltin (ipucu: m = 1
 * ve büyük taban için sonucu Örnek 11 ile karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_A03_hata_bul_us.c -o H02_A03_hata_bul_us
 * Çalıştır: ./H02_A03_hata_bul_us
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

/* a^b mod m, kare al ve çarp (ön koşul 1 <= m < 2^32) */
uint64_t us_mod(uint64_t a, uint64_t b, uint64_t m)
{
    uint64_t sonuc = 1;
    while (b > 0) {
        if (b % 2 == 1) {
            sonuc = sonuc * a % m;
        }
        a = a * a;
        b /= 2;
    }
    return sonuc;
}

int main(void)
{
    printf("2^10 mod 1000 = %" PRIu64 "\n", us_mod(2, 10, 1000));
    printf("3^13 mod 1000 = %" PRIu64 "\n", us_mod(3, 13, 1000));
    printf("7^0 mod 1 = %" PRIu64 "\n", us_mod(7, 0, 1));
    printf("123456789^1000000 mod 1000000007 = %" PRIu64 "\n",
           us_mod(123456789, 1000000, 1000000007));
    return 0;
}

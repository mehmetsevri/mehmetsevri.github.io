/*
 * H02_A02_karmasiklik.c — AP-2 Hafta 2 · Alıştırma 2.3 (karmaşıklık)
 * Amaç    : Altı fonksiyonun büyüme sınıfını (Θ) belirleyin. Çözdükten
 *           sonra programı çalıştırın: sayaç oranları T(2n)/T(n) yanıtınızı
 *           sınamanıza yardım eder (oran testi).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_A02_karmasiklik.c -o H02_A02_karmasiklik
 * Çalıştır: ./H02_A02_karmasiklik
 */
#include <stdio.h>

long long b1(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i += 2) {
        s++;
    }
    return s;
}

long long b2(long long n)
{
    long long s = 0;
    for (long long i = n; i > 1; i /= 2) {
        for (long long j = 0; j < i; j++) {
            s++;
        }
    }
    return s;
}

long long b3(long long n)
{
    long long s = 0;
    for (long long i = 0; i * i < n; i++) {
        for (long long j = 0; j < n; j++) {
            s++;
        }
    }
    return s;
}

long long b4(long long n)
{
    long long s = 0;
    for (long long i = 2; i < n; i = i * i) {
        s++;
    }
    return s;
}

long long b5(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        for (long long j = 0; j < i; j++) {
            for (long long k = 0; k < j; k++) {
                s++;
            }
        }
    }
    return s;
}

long long b6(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        if (i % 100 == 0) {
            for (long long j = 0; j < n; j++) {
                s++;
            }
        }
    }
    return s;
}

int main(void)
{
    long long (*const f[6])(long long) = {b1, b2, b3, b4, b5, b6};
    printf("fonk    n=1000     n=2000     n=4000   oranlar\n");
    for (int k = 0; k < 6; k++) {
        long long t1 = f[k](1000), t2 = f[k](2000), t3 = f[k](4000);
        printf("b%d %10lld %10lld %10lld   %.2f %.2f\n", k + 1, t1, t2, t3,
               (double)t2 / (double)t1, (double)t3 / (double)t2);
    }
    return 0;
}

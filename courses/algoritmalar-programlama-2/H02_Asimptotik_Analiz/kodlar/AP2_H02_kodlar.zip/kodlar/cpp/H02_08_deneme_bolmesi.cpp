/*
 * H02_08_deneme_bolmesi.cpp — AP-2 Hafta 2 · Örnek 8 (★★)
 * Amaç    : Deneme bölmesiyle asallık; √n sınırı i * i <= n ile (kayan
 *           nokta yok, taşma gerekçeli) ve 2..n-1 saf sürümle karşılaştırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_08_deneme_bolmesi.cpp -o H02_08_deneme_bolmesi
 * Çalıştır: ./H02_08_deneme_bolmesi
 * Eşleri  : c/H02_08_deneme_bolmesi.c · python/H02_08_deneme_bolmesi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>

using u64 = std::uint64_t;
const u64 SAF_SINIR = 2000000;

// n asal mı? Bölen adayları i = 2, 3, ... ve i * i <= n.
// Ön koşul n < 2^63: döngü en geç i = ⌊√n⌋ + 1'de biter ve
// (⌊√n⌋ + 1)² <= n + 2√n + 1 < 2^64 olduğundan i * i taşmaz.
// bolme: yapılan kalan (%) işlemi sayısı
bool asal_mi(u64 n, u64& bolme)
{
    bolme = 0;
    if (n < 2) {
        return false;
    }
    for (u64 i = 2; i * i <= n; i++) {
        bolme++;
        if (n % i == 0) {
            return false;       // i böler
        }
    }
    return true;
}

// Saf sürüm: 2 .. n-1 arasındaki tüm adaylar
bool asal_mi_saf(u64 n, u64& bolme)
{
    bolme = 0;
    if (n < 2) {
        return false;
    }
    for (u64 i = 2; i < n; i++) {
        bolme++;
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

int main()
{
    const std::vector<u64> ornekler = {
        1, 2, 4, 17, 25, 91, 97, 7919, 999999, 1000003, 2147483647,
        1000000007, 1000036000099ULL, 999999999989ULL
    };
    u64 b1, b2;

    std::cout << "İzleme n = 91: aday";
    for (u64 i = 2; i * i <= 91; i++) {
        std::cout << ' ' << i;
        if (91 % i == 0) {
            std::cout << " -> " << i << " böler, 91 = " << i << " * "
                      << 91 / i;
            break;
        }
    }
    std::cout << "\nİzleme n = 97: aday 2..9 (10 * 10 > 97), hiçbiri"
                 " bölmez\n\n";

    std::cout << "                   n  asal  bölme(√n)  bölme(saf)\n";
    for (u64 n : ornekler) {
        bool a = asal_mi(n, b1);
        std::cout << std::setw(20) << n << "  " << (a ? "evet " : "hayır")
                  << ' ' << std::setw(9) << b1;
        if (n <= SAF_SINIR) {
            bool s = asal_mi_saf(n, b2);
            std::cout << ' ' << std::setw(11) << b2
                      << (s == a ? "" : "  UYUŞMAZ") << '\n';
        } else {
            std::cout << ' ' << std::setw(11) << "-" << '\n';
        }
    }
    std::cout << "\nAsal n için √n sürüm ⌊√n⌋ - 1 bölme yapar, saf sürüm"
                 " n - 2.\n";
    std::cout << "Bileşik n'de ikisi de en küçük bölende durur (en iyi"
                 " durum:\n";
    std::cout << "çift n, 1 bölme). En kötü durum O(√n).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok;
 * Python — yok (sympy.isprime üçüncü taraf; kullanılmaz) */

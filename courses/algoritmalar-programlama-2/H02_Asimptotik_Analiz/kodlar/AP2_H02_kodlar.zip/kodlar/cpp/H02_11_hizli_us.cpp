/*
 * H02_11_hizli_us.cpp — AP-2 Hafta 2 · Örnek 11 (★★★)
 * Amaç    : Hızlı üs alma (kare al ve çarp) ile a^b mod m: yinelemeli ve
 *           özyinelemeli sürüm, O(log b) çarpma; uint64_t ile güvenli çarpma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_11_hizli_us.cpp -o H02_11_hizli_us
 * Çalıştır: ./H02_11_hizli_us
 * Eşleri  : c/H02_11_hizli_us.c · python/H02_11_hizli_us.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <array>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>

using u64 = std::uint64_t;
const u64 MOD_SINIR = 4294967296ULL;   // 2^32
const u64 SAF_SINIR = 1000000ULL;

// Ön koşul 1 <= m < 2^32: çarpanlar m'den küçük olduğundan
// çarpım <= (m-1)² < 2^64 ve uint64_t çarpımı taşmaz.
bool mod_gecerli(u64 m)
{
    return m >= 1 && m < MOD_SINIR;
}

// a^b mod m, yinelemeli kare-al-çarp; carpma: çarpma sayısı
u64 us_mod(u64 a, u64 b, u64 m, int& carpma)
{
    u64 sonuc = 1 % m;
    a %= m;
    carpma = 0;
    while (b > 0) {
        if (b % 2 == 1) {   // son bit 1
            sonuc = sonuc * a % m;
            carpma++;
        }
        a = a * a % m;      // kare al
        carpma++;
        b /= 2;
    }
    return sonuc;
}

// a^b mod m, özyinelemeli: a^b = (a^(b/2))² · (b tekse a)
u64 us_mod_oz(u64 a, u64 b, u64 m, int& carpma)
{
    if (b == 0) {
        return 1 % m;
    }
    u64 yarim = us_mod_oz(a, b / 2, m, carpma);
    u64 sonuc = yarim * yarim % m;
    carpma++;
    if (b % 2 == 1) {
        sonuc = sonuc * (a % m) % m;
        carpma++;
    }
    return sonuc;
}

// Saf sürüm: b kez çarp — O(b); burada kâhin olarak kullanılır
u64 us_mod_saf(u64 a, u64 b, u64 m, u64& carpma)
{
    u64 sonuc = 1 % m;
    carpma = 0;
    for (u64 i = 0; i < b; i++) {
        sonuc = sonuc * (a % m) % m;
        carpma++;
    }
    return sonuc;
}

// Yinelemeli sürümün her adımını yazar
void us_mod_izle(u64 a, u64 b, u64 m)
{
    u64 sonuc = 1 % m;
    int adim = 0;
    a %= m;
    std::cout << "adım     b  bit  sonuç  taban\n";
    std::cout << std::setw(4) << adim << ' ' << std::setw(5) << b
              << "    - " << std::setw(6) << sonuc << ' ' << std::setw(6)
              << a << '\n';
    while (b > 0) {
        int bit = static_cast<int>(b % 2);
        if (bit == 1) {
            sonuc = sonuc * a % m;
        }
        a = a * a % m;
        b /= 2;
        adim++;
        std::cout << std::setw(4) << adim << ' ' << std::setw(5) << b << ' '
                  << std::setw(4) << bit << ' ' << std::setw(6) << sonuc
                  << ' ' << std::setw(6) << a << '\n';
    }
}

int main()
{
    const std::vector<std::array<u64, 3>> t = {
        {2, 10, 1000}, {3, 13, 1000}, {7, 0, 13}, {5, 3, 1},
        {123456789, 1000000, 1000000007}, {2, 1000000006, 1000000007},
        {3, 1000000000000000000ULL, 1000000007},
        {4294967290ULL, 18446744073709551615ULL, 4294967291ULL},
        {2, 10, 4294967311ULL}
    };

    std::cout << "İzleme: 3^13 mod 1000 (13 = 1101 ikilik; bitler sağdan)\n";
    us_mod_izle(3, 13, 1000);
    std::cout << "\n          a                     b           m       sonuç"
                 "  yin   öz      saf  kâhin\n";
    for (const auto& s : t) {
        u64 a = s[0], b = s[1], m = s[2];
        std::cout << std::setw(11) << a << ' ' << std::setw(21) << b << ' '
                  << std::setw(11) << m;
        if (!mod_gecerli(m)) {
            std::cout << "  ön koşul ihlali: m >= 2^32 (çarpım taşabilir)\n";
            continue;
        }
        int c1, c2 = 0;                 // özyinelemeli sayaç birikir
        u64 r1 = us_mod(a, b, m, c1);
        u64 r2 = us_mod_oz(a, b, m, c2);
        std::cout << ' ' << std::setw(11) << r1 << ' ' << std::setw(4) << c1
                  << ' ' << std::setw(4) << c2;
        if (r1 != r2) {
            std::cout << "  UYUŞMAZ (özyinelemeli " << r2 << ")\n";
            continue;
        }
        if (b <= SAF_SINIR) {
            u64 c3;
            u64 r3 = us_mod_saf(a, b, m, c3);
            std::cout << ' ' << std::setw(8) << c3 << "  "
                      << (r3 == r1 ? "=" : "FARKLI") << '\n';
        } else {
            std::cout << ' ' << std::setw(8) << "-" << "  -\n";
        }
    }
    std::cout << "\nÇarpma sayısı = (b'nin bit uzunluğu) + (1 bitlerinin"
                 " sayısı)\n";
    std::cout << "<= 2 log2 b + 2: O(log b). Saf sürüm b çarpma yapar.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (pow() double döndürür, mod almaz);
 * C++ — yok; Python — pow(a, b, m) (burada yalnızca kâhin) */

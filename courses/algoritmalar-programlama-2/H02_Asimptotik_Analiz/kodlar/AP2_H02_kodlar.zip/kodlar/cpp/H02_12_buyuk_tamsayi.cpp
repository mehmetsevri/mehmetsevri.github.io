/*
 * H02_12_buyuk_tamsayi.cpp — AP-2 Hafta 2 · Örnek 12 (★★★)
 * Amaç    : 2^n'i ikiye katlayarak hesaplamak: C'de uint64_t n >= 64'te
 *           sarar (mod 2^64), Python'da büyük tamsayı kesin ama maliyetli
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_12_buyuk_tamsayi.cpp -o H02_12_buyuk_tamsayi
 * Çalıştır: ./H02_12_buyuk_tamsayi
 * Eşleri  : c/H02_12_buyuk_tamsayi.c · python/H02_12_buyuk_tamsayi.py
 * Çıktı   : Δ — dile özgü (uint64_t sarması); bkz. Dil Penceresi
 */
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>

#include "zamanlayici.hpp"

// 2^n: n kez ikiye katla. std::uint64_t 2^64 modunda sarar (tanımlı
// davranış): n >= 64 için sonuç 0'dır. Her katlama O(1).
std::uint64_t iki_us(int n)
{
    std::uint64_t x = 1;
    for (int i = 0; i < n; i++) {
        x = x * 2;
    }
    return x;
}

// x'in ikilik basamak (bit) sayısı; x = 0 için 0
int bit_uzunlugu(std::uint64_t x)
{
    int b = 0;
    while (x > 0) {
        x /= 2;
        b++;
    }
    return b;
}

// 3^e: tamsayı çarpımıyla (e <= 40 için uint64_t'ye sığar)
std::uint64_t uc_us(int e)
{
    std::uint64_t x = 1;
    for (int i = 0; i < e; i++) {
        x *= 3;
    }
    return x;
}

int main()
{
    const std::vector<int> boyutlar = {1, 10, 63, 64, 65, 100, 1000, 10000,
                                       100000};

    std::cout << "2^n, ikiye katlayarak (uint64_t)\n";
    std::cout << "     n  bit_uzunluğu  son_6_basamak  mod_1000000007\n";
    std::cerr << std::fixed << std::setprecision(3);
    for (int n : boyutlar) {
        double t0 = zaman_sn();
        std::uint64_t x = iki_us(n);
        double sure = zaman_sn() - t0;
        std::cout << std::setw(6) << n << ' ' << std::setw(13)
                  << bit_uzunlugu(x) << "         " << std::setfill('0')
                  << std::setw(6) << x % 1000000 << std::setfill(' ') << ' '
                  << std::setw(15) << x % 1000000007 << '\n';
        std::cerr << "n=" << n << ": " << sure * 1000 << " ms\n";
    }

    std::uint64_t kesin = uc_us(39);
    auto yaklasik = static_cast<std::uint64_t>(std::pow(3.0, 39.0));
    std::cout << "\n3^39 tamsayı çarpımıyla : " << kesin << '\n';
    std::cout << "3^39 pow() ile (double) : " << yaklasik << '\n';
    std::cout << "fark                    : " << kesin - yaklasik << '\n';
    return 0;
}

/* Kütüphane karşılığı: C — yok (GMP üçüncü taraf: mpz_ui_pow_ui);
 * C++ — yok (Boost.Multiprecision); Python — 2 ** n, 1 << n */

/*
 * H02_09_kalbur.cpp — AP-2 Hafta 2 · Örnek 9 (★★)
 * Amaç    : Eratosthenes kalburu (i * i'den başlatma) ve deneme bölmesiyle
 *           asal sayma: işlem sayıları ve zaman–bellek ödünleşimi
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_09_kalbur.cpp -o H02_09_kalbur
 * Çalıştır: ./H02_09_kalbur [N [kalbur]]   (N verilirse yalnızca o N;
 *           "kalbur": deneme bölmesi atlanır)
 * Eşleri  : c/H02_09_kalbur.c · python/H02_09_kalbur.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "zamanlayici.hpp"

// 0..n için kalbur: bilesik[i] = 1 ise i bileşiktir. Asal sayısını
// döndürür; isaretleme: bilesik[j] = 1 yazma sayısı (n < 2^32)
long kalbur(std::size_t n, std::vector<unsigned char>& bilesik,
            long long& isaretleme)
{
    long asal = 0;
    std::size_t i, j;
    isaretleme = 0;
    bilesik.assign(n + 1, 0);           // n + 1 bayt; vector<bool> değil
    // i asalsa katlarını i*i'den başlayarak işaretle: daha küçük
    // katlar, daha küçük bir asal tarafından zaten işaretlendi
    for (i = 2; i * i <= n; i++) {
        if (!bilesik[i]) {
            for (j = i * i; j <= n; j += i) {
                bilesik[j] = 1;
                isaretleme++;
            }
        }
    }
    for (i = 2; i <= n; i++) {
        if (!bilesik[i]) {
            asal++;
        }
    }
    return asal;
}

// Örnek 8'deki deneme bölmesi (ön koşul n < 2^63)
bool asal_mi(std::uint64_t n, std::uint64_t& bolme)
{
    bolme = 0;
    if (n < 2) {
        return false;
    }
    for (std::uint64_t i = 2; i * i <= n; i++) {
        bolme++;
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

// 2..n arasındaki asalları deneme bölmesiyle sayar
long deneme_say(std::uint64_t n, long long& toplam_bolme)
{
    long asal = 0;
    std::uint64_t b;
    toplam_bolme = 0;
    for (std::uint64_t m = 2; m <= n; m++) {
        if (asal_mi(m, b)) {
            asal++;
        }
        toplam_bolme += static_cast<long long>(b);
    }
    return asal;
}

// Bir N için tablo satırı; süreler stderr'e
void satir(std::size_t n, bool deneme_de)
{
    std::vector<unsigned char> bilesik;
    long long isaret, bolme = 0;
    double t0 = zaman_sn();
    long p1 = kalbur(n, bilesik, isaret);
    double t1 = zaman_sn();
    long p2 = -1;
    if (deneme_de) {
        p2 = deneme_say(n, bolme);
    }
    double t2 = zaman_sn();
    std::cout << std::setw(10) << n << ' ' << std::setw(8) << p1 << ' ';
    if (deneme_de) {
        std::cout << std::setw(8) << p2 << ' ' << std::setw(12) << bolme;
    } else {
        std::cout << std::setw(8) << "-" << ' ' << std::setw(12) << "-";
    }
    std::cout << ' ' << std::setw(11) << isaret << ' ' << std::setw(8)
              << std::fixed << std::setprecision(3)
              << static_cast<double>(isaret) / n << ' ' << std::setw(11)
              << n + 1 << '\n';
    std::cerr << std::fixed << std::setprecision(3) << "N=" << n
              << ": kalbur " << (t1 - t0) * 1000 << " ms";
    if (deneme_de) {
        std::cerr << " · deneme bölmesi " << (t2 - t1) * 1000 << " ms";
    }
    std::cerr << '\n';
}

int main(int argc, char* argv[])
{
    const std::vector<std::size_t> boyutlar = {10, 100, 1000, 10000, 100000};
    std::vector<unsigned char> bilesik;
    long long isaret;

    if (argc > 3 || (argc == 3 && std::string(argv[2]) != "kalbur")) {
        std::cerr << "Kullanım: " << argv[0] << " [N [kalbur]]\n";
        return 2;
    }
    if (argc >= 2) {
        long long n = 0;
        try {
            std::size_t son;
            n = std::stoll(argv[1], &son);
            if (argv[1][son] != '\0') {
                n = 0;
            }
        } catch (const std::exception&) {
            n = 0;
        }
        if (n < 2 || n > 2000000000LL) {
            std::cerr << "N 2..2000000000 olmalı\n";
            return 2;
        }
        std::cout << "         N     π(N)   deneme        bölme  işaretleme"
                     "  işar./N  bellek(B)\n";
        satir(static_cast<std::size_t>(n), argc == 2);
        return 0;
    }

    long p = kalbur(100, bilesik, isaret);
    std::cout << "Kalbur, N = 100: " << p << " asal, " << isaret
              << " işaretleme\n";
    for (int i = 2, s = 0; i <= 100; i++) {
        if (!bilesik[i]) {
            std::cout << std::setw(4) << i;
            if (++s % 10 == 0) {
                std::cout << '\n';
            }
        }
    }
    std::cout << "\n\n         N     π(N)   deneme        bölme  işaretleme"
                 "  işar./N  bellek(B)\n";
    for (std::size_t n : boyutlar) {
        satir(n, true);
    }
    std::cout << "\nKalbur Θ(N log log N) işaretleme ve N + 1 bayt bellek\n";
    std::cout << "kullanır; deneme bölmesi O(1) bellekle ama çok daha fazla\n";
    std::cout << "işlemle çalışır: zaman–bellek ödünleşimi. N = 10^8 için\n";
    std::cout << "kalbur dizisi yaklaşık 100 MB'tır (bit dizisiyle 12.5"
                 " MB).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok;
 * Python — yok (sympy.primerange üçüncü taraf; kullanılmaz) */

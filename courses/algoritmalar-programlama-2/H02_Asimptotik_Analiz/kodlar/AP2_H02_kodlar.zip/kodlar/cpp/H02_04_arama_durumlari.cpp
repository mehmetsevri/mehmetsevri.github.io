/*
 * H02_04_arama_durumlari.cpp — AP-2 Hafta 2 · Örnek 4 (★★)
 * Amaç    : Doğrusal aramada en iyi, en kötü ve ortalama durum
 *           karşılaştırma sayaçları; ortalamanın bir varsayıma bağlılığı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_04_arama_durumlari.cpp -o H02_04_arama_durumlari
 * Çalıştır: ./H02_04_arama_durumlari
 * Eşleri  : c/H02_04_arama_durumlari.c · python/H02_04_arama_durumlari.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

const int HEDEF_SAYISI = 1000;

// a içinde x'i arar: indis ya da -1; kar: karşılaştırma sayısı
long dogrusal_ara(const std::vector<int>& a, int x, long long& kar)
{
    kar = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        kar++;                          // temel işlem: a[i] == x
        if (a[i] == x) {
            return static_cast<long>(i);
        }
    }
    return -1;
}

// a'daki her elemanı bir kez arar: başarılı aramaların toplam sayacı
long long basarili_toplam(const std::vector<int>& a)
{
    long long toplam = 0, kar;
    for (int x : a) {
        dogrusal_ara(a, x, kar);
        toplam += kar;
    }
    return toplam;
}

int main()
{
    const std::vector<int> k10 = {42, 17, 8, 99, 23, 4, 16, 15, 61, 30};
    const std::vector<int> hedefler = {42, 30, 5};
    const std::vector<std::size_t> boyutlar = {10, 100, 1000, 2000};
    long long kar;

    std::cout << "a =";
    for (int x : k10) {
        std::cout << ' ' << x;
    }
    std::cout << "   (n = 10)\n";
    for (int h : hedefler) {
        long ind = dogrusal_ara(k10, h, kar);
        std::cout << "ara(" << h << "): indis " << ind << ", karşılaştırma "
                  << kar << '\n';
    }
    long long top = basarili_toplam(k10);
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Başarılı aramaların ortalaması: " << top << " / 10 = "
              << top / 10.0 << "   ((n+1)/2 = " << 11 / 2.0 << ")\n\n";

    std::cout << "Rastgele permütasyon (1..n), tohum 42; " << HEDEF_SAYISI
              << " rastgele hedef 1..2n\n";
    std::cout << "       n  en_iyi  en_kötü  ort_başarılı  (n+1)/2"
                 "  bulunan  ort_rastgele    model\n";
    for (std::size_t n : boyutlar) {
        std::vector<int> a(n);
        for (std::size_t i = 0; i < n; i++) {
            a[i] = static_cast<int>(i) + 1;
        }
        rastgele_tohum(42);
        rastgele_karistir(a);
        long long en_iyi, en_kotu;
        dogrusal_ara(a, a[0], en_iyi);          // ilk eleman
        dogrusal_ara(a, 0, en_kotu);            // dizide yok
        double ort = static_cast<double>(basarili_toplam(a)) / n;
        long long bulunan = 0, rtoplam = 0;
        for (int h = 0; h < HEDEF_SAYISI; h++) {
            int x = rastgele_aralik(1, 2 * static_cast<int>(n));
            if (dogrusal_ara(a, x, kar) >= 0) {
                bulunan++;
            }
            rtoplam += kar;
        }
        double p = static_cast<double>(bulunan) / HEDEF_SAYISI;
        double model = p * (n + 1.0) / 2 + (1 - p) * static_cast<double>(n);
        std::cout << std::setw(8) << n << ' ' << std::setw(7) << en_iyi
                  << ' ' << std::setw(8) << en_kotu << ' ' << std::setw(13)
                  << ort << ' ' << std::setw(8) << (n + 1.0) / 2 << ' '
                  << std::setw(8) << bulunan << ' ' << std::setw(13)
                  << static_cast<double>(rtoplam) / HEDEF_SAYISI << ' '
                  << std::setw(8) << model << '\n';
    }
    std::cout << "\nEn iyi durum 1, en kötü durum n karşılaştırma. Başarılı\n";
    std::cout << "aramaların ortalaması (her konum eşit olasılıklı) tam\n";
    std::cout << "(n+1)/2'dir. Hedeflerin yarısı dizide yoksa ortalama\n";
    std::cout << "p(n+1)/2 + (1-p)n modeline yaklaşır: ortalama durum bir\n";
    std::cout << "girdi dağılımı varsayımıdır.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX lfind); C++ — std::find;
 * Python — a.index(x), x in a */

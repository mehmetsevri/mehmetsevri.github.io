/*
 * H02_03_yariya_inen.cpp — AP-2 Hafta 2 · Örnek 3 (★)
 * Amaç    : Yarıya inen döngü kaç adım sürer? ⌊log2 n⌋ + 1; üçe bölmeyle
 *           karşılaştırma: log tabanı yalnızca sabit çarpandır
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_03_yariya_inen.cpp -o H02_03_yariya_inen
 * Çalıştır: ./H02_03_yariya_inen
 * Eşleri  : c/H02_03_yariya_inen.c · python/H02_03_yariya_inen.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <vector>

// n > 0 oldukça n'i yarıya indirir; adım sayısını döndürür
int yariya_adim(unsigned long long n)
{
    int adim = 0;
    while (n > 0) {
        n /= 2;                     // tamsayı bölmesi: aşağı yuvarlar
        adim++;
    }
    return adim;
}

// Aynı döngü, üçe bölerek
int ucte_adim(unsigned long long n)
{
    int adim = 0;
    while (n > 0) {
        n /= 3;
        adim++;
    }
    return adim;
}

// 2^k <= n olan en büyük k (n >= 1): ⌊log2 n⌋, kayan nokta olmadan
int taban_log2(unsigned long long n)
{
    int k = 0;
    unsigned long long p = 1;
    while (p <= n / 2) {            // 2p <= n; 2p taşmadan sınanır
        p *= 2;
        k++;
    }
    return k;
}

int main()
{
    const std::vector<unsigned long long> ornekler = {
        1, 2, 3, 4, 7, 8, 15, 16, 100, 1000, 1000000, 1000000000,
        1000000000000ULL, 1000000000000000000ULL, 18446744073709551615ULL
    };

    unsigned long long n = 100;
    int adim = 0;
    std::cout << "İzleme (n = 100): " << n;
    while (n > 0) {
        n /= 2;
        adim++;
        std::cout << " -> " << n;
    }
    std::cout << "   (" << adim << " adım)\n\n";

    std::cout << "                   n  yarıya  ⌊log2 n⌋+1  eşit  üçe  oran\n";
    std::cout << std::fixed << std::setprecision(2);
    for (unsigned long long m : ornekler) {
        int y = yariya_adim(m);
        int f = taban_log2(m) + 1;
        int u = ucte_adim(m);
        std::cout << std::setw(20) << m << ' ' << std::setw(7) << y << ' '
                  << std::setw(11) << f << "  " << std::left << std::setw(5)
                  << (y == f ? "evet" : "HAYIR") << std::right << ' '
                  << std::setw(4) << u << "  "
                  << static_cast<double>(y) / u << '\n';
    }
    std::cout << "\nYarıya inen döngü ⌊log2 n⌋ + 1 adım sürer: n = 2^64 - 1\n";
    std::cout << "için bile 64 adım. Üçe bölmeyle adım sayısı log3 n'dir;\n";
    std::cout << "oran log2(3) = 1.58'e yaklaşır: taban yalnızca sabittir.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (GCC eklentisi __builtin_clzll);
 * C++20 — std::bit_width(n); Python — n.bit_length() */

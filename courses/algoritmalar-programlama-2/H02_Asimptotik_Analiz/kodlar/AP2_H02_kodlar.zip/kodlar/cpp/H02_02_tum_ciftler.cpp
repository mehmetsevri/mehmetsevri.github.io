/*
 * H02_02_tum_ciftler.cpp — AP-2 Hafta 2 · Örnek 2 (★)
 * Amaç    : Bağımlı iç içe döngüde (j = i + 1'den) çift sayısı n(n-1)/2;
 *           bağımsız iç içe döngüyle (n*n) karşılaştırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_02_tum_ciftler.cpp -o H02_02_tum_ciftler
 * Çalıştır: ./H02_02_tum_ciftler
 * Eşleri  : c/H02_02_tum_ciftler.c · python/H02_02_tum_ciftler.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

// i < j olan (i, j) çiftlerini sayar: bağımlı iç içe döngü
long long tum_ciftler(std::size_t n)
{
    long long sayac = 0;
    for (std::size_t i = 0; i < n; i++) {
        for (std::size_t j = i + 1; j < n; j++) {   // n - 1 - i kez
            sayac++;
        }
    }
    return sayac;
}

// Tüm sıralı (i, j) çiftlerini sayar: bağımsız iç içe döngü
long long tum_sirali_ciftler(std::size_t n)
{
    long long sayac = 0;
    for (std::size_t i = 0; i < n; i++) {
        for (std::size_t j = 0; j < n; j++) {       // her i için n kez
            sayac++;
        }
    }
    return sayac;
}

// Küçük n için çiftleri satır satır yazar: işlem üçgeni
void ucgen_yaz(std::size_t n)
{
    long long toplam = 0;
    for (std::size_t i = 0; i < n; i++) {
        long long satir = 0;
        std::cout << "i=" << i << ':';
        for (std::size_t j = i + 1; j < n; j++) {
            std::cout << " (" << i << ',' << j << ')';
            satir++;
        }
        std::cout << std::string(6 * i, ' ') << "  -> " << satir << '\n';
        toplam += satir;
    }
    std::cout << "toplam = " << toplam << " = " << n << '*' << n - 1
              << "/2\n";
}

int main()
{
    const std::vector<std::size_t> boyutlar = {0, 1, 2, 5, 10, 100, 1000,
                                               2000};

    std::cout << "n = 5 için i < j çiftleri (i. satırda n-1-i çift):\n";
    ucgen_yaz(5);
    std::cout << "\n       n   bağımlı  n(n-1)/2   bağımsız  oran\n";
    for (std::size_t n : boyutlar) {
        long long b = tum_ciftler(n);
        long long s = tum_sirali_ciftler(n);
        long long kuram = static_cast<long long>(n) *
                          (static_cast<long long>(n) - 1) / 2;
        std::cout << std::setw(8) << n << ' ' << std::setw(9) << b << ' '
                  << std::setw(9) << kuram << ' ' << std::setw(10) << s
                  << "  ";
        if (b > 0) {
            std::cout << std::fixed << std::setprecision(3)
                      << static_cast<double>(s) / b << '\n';
        } else {
            std::cout << "-\n";
        }
    }
    std::cout << "\nBağımlı döngü tam n(n-1)/2 kez döner; bağımsız döngü"
                 " n*n.\n";
    std::cout << "Oran 2'ye yaklaşır: ikisi de Θ(n²), sabitleri farklı.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok;
 * Python — itertools.combinations(range(n), 2) çiftleri üretir */

/*
 * H02_01_dogrusal_toplam.cpp — AP-2 Hafta 2 · Örnek 1 (★)
 * Amaç    : İşlem sayacıyla doğrusal toplamda T(n) = n'in gözlenmesi;
 *           temel işlem seçimi sabiti değiştirir, büyüme sınıfını değil
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_01_dogrusal_toplam.cpp -o H02_01_dogrusal_toplam
 * Çalıştır: ./H02_01_dogrusal_toplam
 * Eşleri  : c/H02_01_dogrusal_toplam.c · python/H02_01_dogrusal_toplam.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

const std::size_t N_AZAMI = 100000;

// a[0..n-1] toplamı; islem: temel işlem (toplama) sayısı
long long dogrusal_toplam(const std::vector<int>& a, std::size_t n,
                          long long& islem)
{
    long long toplam = 0;
    islem = 0;
    for (std::size_t i = 0; i < n; i++) {
        toplam += a[i];
        islem++;                    // temel işlem: bir toplama
    }
    return toplam;
}

// Aynı döngü; RAM modelinde her ilkel adım sayılır
long long ayrintili_sayim(const std::vector<int>& a, std::size_t n,
                          long long& adim)
{
    long long toplam = 0;
    adim = 2;                       // toplam = 0 ve i = 0: 2 atama
    for (std::size_t i = 0; i < n; i++) {
        toplam += a[i];
        adim += 3;                  // i < n sınaması, toplama, i++
    }
    adim += 1;                      // döngüyü bitiren son i < n
    return toplam;
}

int main()
{
    const std::vector<std::size_t> boyutlar = {0, 1, 10, 100, 1000, 10000,
                                               100000};
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(N_AZAMI, 0, 99);

    std::cout << "Doğrusal toplam (a[i] değerleri 0..99, tohum 42)\n";
    std::cout << "a[0..9] =";
    for (std::size_t i = 0; i < 10; i++) {
        std::cout << ' ' << a[i];
    }
    std::cout << "\n\n";
    std::cout << "       n      toplam   toplama  =n?     ayrıntılı  =3n+3?\n";
    for (std::size_t n : boyutlar) {
        long long islem, adim;
        long long toplam = dogrusal_toplam(a, n, islem);
        ayrintili_sayim(a, n, adim);
        bool ok1 = islem == static_cast<long long>(n);
        bool ok2 = adim == 3 * static_cast<long long>(n) + 3;
        std::cout << std::setw(8) << n << ' ' << std::setw(11) << toplam
                  << ' ' << std::setw(9) << islem << "  " << std::left
                  << std::setw(5) << (ok1 ? "evet" : "HAYIR") << std::right
                  << ' ' << std::setw(11) << adim << "  "
                  << (ok2 ? "evet" : "HAYIR") << '\n';
    }
    std::cout << "\nToplama sayısı her n için tam n: T(n) = n.\n";
    std::cout << "Ayrıntılı sayım 3n + 3; ikisi de Θ(n): temel işlem seçimi\n";
    std::cout << "yalnızca sabit çarpanı değiştirir.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle döngü); C++ — std::accumulate;
 * Python — sum(a) */

/*
 * H02_10_oklid_lame.cpp — AP-2 Hafta 2 · Örnek 10 (★★★)
 * Amaç    : Öklid algoritmasında adım (mod) sayısı; ardışık Fibonacci
 *           sayılarının en kötü durum olması (Lamé) — tablo ve tam tarama
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_10_oklid_lame.cpp -o H02_10_oklid_lame
 * Çalıştır: ./H02_10_oklid_lame
 * Eşleri  : c/H02_10_oklid_lame.c · python/H02_10_oklid_lame.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>

const int TARAMA = 500;

// ebob(a, b), a >= b >= 0; adim: kalan (mod) işlemi sayısı
std::uint64_t ebob(std::uint64_t a, std::uint64_t b, int& adim)
{
    adim = 0;
    while (b != 0) {
        std::uint64_t r = a % b;
        a = b;
        b = r;
        adim++;
    }
    return a;
}

// Her adımı a = q * b + r biçiminde yazar
void ebob_izle(std::uint64_t a, std::uint64_t b)
{
    while (b != 0) {
        std::cout << "  " << a << " = " << a / b << " * " << b << " + "
                  << a % b << '\n';
        std::uint64_t r = a % b;
        a = b;
        b = r;
    }
    std::cout << "  ebob = " << a << '\n';
}

// Ondalık basamak sayısı
int basamak(std::uint64_t x)
{
    int d = 1;
    while (x >= 10) {
        x /= 10;
        d++;
    }
    return d;
}

int main()
{
    const std::vector<int> satirlar = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
                                       20, 30, 40, 50, 60, 70, 80, 90, 92};
    std::vector<std::uint64_t> fib(94);
    int adim;

    std::cout << "İzleme: ebob(1071, 462)\n";
    ebob_izle(1071, 462);
    std::cout << "\nİzleme: ebob(89, 55) — ardışık Fibonacci sayıları\n";
    ebob_izle(89, 55);

    fib[1] = 1;
    fib[2] = 1;
    for (int k = 3; k <= 93; k++) {
        fib[k] = fib[k - 1] + fib[k - 2];   // F(93) < 2^64
    }
    std::cout << "\nArdışık Fibonacci çiftleri (F(k+1), F(k)): adım = k -"
                 " 1\n";
    std::cout << "  k               F(k+1)                 F(k)  adım"
                 "  basamak  5*basamak\n";
    for (int k : satirlar) {
        ebob(fib[k + 1], fib[k], adim);
        int d = basamak(fib[k]);
        std::cout << std::setw(3) << k << ' ' << std::setw(20) << fib[k + 1]
                  << ' ' << std::setw(20) << fib[k] << ' ' << std::setw(5)
                  << adim << ' ' << std::setw(8) << d << ' '
                  << std::setw(10) << 5 * d << '\n';
    }

    // Tam tarama: 1 <= b < a <= TARAMA; her adım sayısı için en küçük a
    std::vector<int> en_kucuk_a(64, 0), en_kucuk_b(64, 0);
    int en_cok = 0;
    long long cift = 0;
    for (int a = 2; a <= TARAMA; a++) {
        for (int b = 1; b < a; b++) {
            ebob(a, b, adim);
            cift++;
            if (en_kucuk_a[adim] == 0) {
                en_kucuk_a[adim] = a;
                en_kucuk_b[adim] = b;
            }
            if (adim > en_cok) {
                en_cok = adim;
            }
        }
    }
    std::cout << "\nTam tarama: 1 <= b < a <= " << TARAMA << " (" << cift
              << " çift), en çok " << en_cok << " adım\n";
    std::cout << "adım  en küçük a  (b)  Fibonacci?\n";
    for (int s = 1; s <= en_cok; s++) {
        bool fib_mi = static_cast<std::uint64_t>(en_kucuk_a[s]) ==
                          fib[s + 2] &&
                      static_cast<std::uint64_t>(en_kucuk_b[s]) == fib[s + 1];
        std::cout << std::setw(4) << s << ' ' << std::setw(11)
                  << en_kucuk_a[s] << ' ' << std::setw(5) << en_kucuk_b[s]
                  << "  " << (fib_mi ? "evet" : "HAYIR") << '\n';
    }
    std::cout << "\ns adım gerektiren en küçük çift (F(s+2), F(s+1)):"
                 " Fibonacci\n";
    std::cout << "sayıları en kötü durumdur. Adım sayısı ≤ 5 x (küçük"
                 " sayının\n";
    std::cout << "basamak sayısı) (Lamé): Öklid O(log min(a, b)).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++17 — std::gcd (<numeric>);
 * Python — math.gcd */

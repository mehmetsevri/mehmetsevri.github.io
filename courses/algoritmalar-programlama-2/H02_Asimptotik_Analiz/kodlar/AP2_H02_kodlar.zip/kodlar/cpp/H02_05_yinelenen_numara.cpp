/*
 * H02_05_yinelenen_numara.cpp — AP-2 Hafta 2 · Örnek 5 (★★)
 * Amaç    : Yinelenen öğrenci numarası var mı? O(n²) kaba kuvvet; erken
 *           çıkışlı ve tüm çiftleri tarayan sürümün karşılaştırma sayıları
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_05_yinelenen_numara.cpp -o H02_05_yinelenen_numara
 * Çalıştır: ./H02_05_yinelenen_numara
 * Eşleri  : c/H02_05_yinelenen_numara.c ·
 *           python/H02_05_yinelenen_numara.py
 * Çıktı   : üç dilde aynı (=) — Mini-OBS 2 v2.1 yinelenen.c ile aynı fikir
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

// İlk eşit çifti (i, j) bulunca durur; kar: karşılaştırma sayısı
bool yinelenen_var_mi(const std::vector<long long>& no, std::size_t& ilk_i,
                      std::size_t& ilk_j, long long& kar)
{
    kar = 0;
    for (std::size_t i = 0; i + 1 < no.size(); i++) {
        for (std::size_t j = i + 1; j < no.size(); j++) {
            kar++;
            if (no[i] == no[j]) {
                ilk_i = i;
                ilk_j = j;
                return true;                    // erken çıkış
            }
        }
    }
    return false;
}

// Tüm çiftleri tarar: eşit çift sayısını döndürür
long long yinelenen_bul(const std::vector<long long>& no, long long& kar)
{
    long long cift = 0;
    kar = 0;
    for (std::size_t i = 0; i + 1 < no.size(); i++) {
        for (std::size_t j = i + 1; j < no.size(); j++) {
            kar++;
            if (no[i] == no[j]) {
                cift++;
            }
        }
    }
    return cift;
}

void senaryo(const std::string& ad, const std::vector<long long>& no)
{
    std::size_t i = 0, j = 0;
    long long k1, k2;
    bool var = yinelenen_var_mi(no, i, j, k1);
    long long cift = yinelenen_bul(no, k2);
    std::cout << ad << " n=" << no.size() << ": var_mi="
              << (var ? "EVET" : "HAYIR");
    if (var) {
        std::cout << " (" << i << ',' << j << ')';
    }
    std::cout << " kar=" << k1 << " | bul: " << cift << " çift, kar=" << k2
              << '\n';
}

int main()
{
    const std::vector<std::size_t> boyutlar = {500, 1000, 2000};

    std::cout << "Küçük senaryolar (Mini-OBS 2 v2.1 test senaryoları 1-4):\n";
    senaryo("S1", {11, 22, 33, 44, 55});
    senaryo("S2", {7, 3, 7, 5, 3, 7});
    senaryo("S3", {9, 9, 1, 2, 3, 4});
    senaryo("S4", {1, 2, 3, 4, 8, 8});

    std::cout << "\nÖğrenci numaraları 2400000000 + karıştırılmış 0..n-1"
                 " (tohum 42)\n";
    std::cout << "       n  durum        var_mi  kar(erken)   çift"
                 "  kar(tümü)   n(n-1)/2\n";
    for (std::size_t n : boyutlar) {
        std::vector<int> sira(n);
        for (std::size_t i = 0; i < n; i++) {
            sira[i] = static_cast<int>(i);
        }
        rastgele_tohum(42);
        rastgele_karistir(sira);
        std::vector<long long> no(n);
        for (std::size_t i = 0; i < n; i++) {
            no[i] = 2400000000LL + sira[i];
        }
        for (int kopya = 0; kopya < 2; kopya++) {
            if (kopya == 1) {           // bir numarayı başka yere kopyala
                std::size_t hedef = static_cast<std::size_t>(
                    rastgele_aralik(1, static_cast<int>(n) - 1));
                no[hedef] = no[0];
            }
            std::size_t i = 0, j = 0;
            long long k1, k2;
            bool var = yinelenen_var_mi(no, i, j, k1);
            long long cift = yinelenen_bul(no, k2);
            std::cout << std::setw(8) << n << "  " << std::left
                      << std::setw(11) << (kopya ? "1-yinelenen" : "temiz")
                      << "  " << std::setw(6) << (var ? "EVET" : "HAYIR")
                      << std::right << ' ' << std::setw(11) << k1 << ' '
                      << std::setw(6) << cift << ' ' << std::setw(10) << k2
                      << ' ' << std::setw(10) << n * (n - 1) / 2 << '\n';
        }
    }
    std::cout << "\nTüm çiftler her girdide tam n(n-1)/2 karşılaştırma"
                 " yapar.\n";
    std::cout << "Erken çıkış en iyi durumda 1 karşılaştırmaya iner; ama"
                 " temiz\n";
    std::cout << "dosyada (en kötü durum) kazancı yoktur: ikisi de O(n²).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort + komşu karşılaştırma: H6);
 * C++ — std::sort + std::adjacent_find; Python — len(set(no)) < len(no) */

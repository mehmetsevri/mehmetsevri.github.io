/*
 * H02_06_buyume_tablosu.cpp — AP-2 Hafta 2 · Örnek 6 (★★)
 * Amaç    : Büyüme sınıflarının (log n ... n!) sayısal karşılaştırması ve
 *           "1 saniyede çözülebilecek en büyük n" uygulanabilirlik tablosu
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_06_buyume_tablosu.cpp -o H02_06_buyume_tablosu
 * Çalıştır: ./H02_06_buyume_tablosu [islem_hizi]   (varsayılan 100000000)
 * Eşleri  : c/H02_06_buyume_tablosu.c · python/H02_06_buyume_tablosu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

// f(n)'yi 12 sütunda yazar; double'a sığmayan (log10 >= 308) değer
// 10^k biçiminde: değer 10^k ile 10^(k+1) arasındadır
void deger_yaz(double deger, double lg)
{
    if (lg < 308.0) {
        std::cout << ' ' << std::setw(11) << std::scientific
                  << std::setprecision(3) << deger;
    } else {
        std::string s = "10^" + std::to_string(
                                    static_cast<int>(std::floor(lg)));
        std::cout << ' ' << std::setw(11) << s;
    }
}

// 2^n: log10(2^n) = n log10(2); sığıyorsa ikiye katlayarak kesin değer
void iki_us_yaz(long n)
{
    double lg = static_cast<double>(n) * std::log10(2.0);
    double d = 1.0;
    if (lg < 308.0) {
        for (long i = 0; i < n; i++) {
            d *= 2.0;
        }
    }
    deger_yaz(d, lg);
}

// n!: log10(n!) = log10(2) + log10(3) + ... + log10(n)
void faktoriyel_yaz(long n)
{
    double lg = 0.0;
    for (long k = 2; k <= n; k++) {
        lg += std::log10(static_cast<double>(k));
    }
    double d = 1.0;
    if (lg < 308.0) {
        for (long k = 2; k <= n; k++) {
            d *= static_cast<double>(k);
        }
    }
    deger_yaz(d, lg);
}

// n^k <= butce olan en büyük n (k = 2, 3)
long long en_buyuk_kuvvet(long long butce, int k)
{
    long long n = 0;
    for (;;) {
        long long m = n + 1, deger = 1;
        for (int i = 0; i < k; i++) {
            deger *= m;
        }
        if (deger > butce) {
            return n;
        }
        n = m;
    }
}

// n log2 n <= butce olan en büyük n: ikiye katla, sonra ikili ara
long long en_buyuk_nlogn(long long butce)
{
    auto f = [](long long n) {
        return static_cast<double>(n) * std::log2(static_cast<double>(n));
    };
    long long lo = 1, hi = 2;
    while (f(hi) <= static_cast<double>(butce)) {
        lo = hi;
        hi *= 2;
    }
    while (hi - lo > 1) {               // f(lo) <= butce < f(hi)
        long long orta = lo + (hi - lo) / 2;
        if (f(orta) <= static_cast<double>(butce)) {
            lo = orta;
        } else {
            hi = orta;
        }
    }
    return lo;
}

int main(int argc, char* argv[])
{
    const std::vector<long> boyutlar = {10, 100, 1000, 10000, 100000,
                                        1000000};
    long long butce = 100000000;
    if (argc > 2) {
        std::cerr << "Kullanım: " << argv[0] << " [islem_hizi]\n";
        return 2;
    }
    if (argc == 2) {
        try {
            std::size_t son;
            butce = std::stoll(argv[1], &son);
            if (argv[1][son] != '\0' || butce < 1 || butce > 1000000000) {
                throw std::out_of_range("aralık");
            }
        } catch (const std::exception&) {
            std::cerr << "islem_hizi 1..1000000000 olmalı\n";
            return 2;
        }
    }

    std::cout << "Büyüme tablosu (log tabanı 2; 10^k: double'a sığmaz,"
                 " 10^k ile 10^(k+1) arası)\n";
    std::cout << "f(n)   ";
    for (long n : boyutlar) {
        std::cout << ' ' << std::setw(11) << n;
    }
    std::cout << std::scientific << std::setprecision(3);
    std::cout << "\nlog n  ";
    for (long n : boyutlar) {
        std::cout << ' ' << std::setw(11) << std::log2(n * 1.0);
    }
    std::cout << "\n√n     ";
    for (long n : boyutlar) {
        std::cout << ' ' << std::setw(11) << std::sqrt(n * 1.0);
    }
    std::cout << "\nn      ";
    for (long n : boyutlar) {
        std::cout << ' ' << std::setw(11) << n * 1.0;
    }
    std::cout << "\nn log n";
    for (long n : boyutlar) {
        std::cout << ' ' << std::setw(11) << n * std::log2(n * 1.0);
    }
    std::cout << "\nn²     ";
    for (long n : boyutlar) {
        double d = static_cast<double>(n);
        std::cout << ' ' << std::setw(11) << d * d;
    }
    std::cout << "\nn³     ";
    for (long n : boyutlar) {
        double d = static_cast<double>(n);
        std::cout << ' ' << std::setw(11) << d * d * d;
    }
    std::cout << "\n2^n    ";
    for (long n : boyutlar) {
        iki_us_yaz(n);
    }
    std::cout << "\nn!     ";
    for (long n : boyutlar) {
        faktoriyel_yaz(n);
    }

    std::cout << "\n\n1 saniyede çözülebilecek en büyük n"
                 " (saniyede " << butce << " temel işlem)\n";
    std::cout << "log n    2^" << butce << '\n';
    std::cout << "√n       " << butce * butce << '\n';
    std::cout << "n        " << butce << '\n';
    std::cout << "n log n  " << en_buyuk_nlogn(butce) << '\n';
    std::cout << "n²       " << en_buyuk_kuvvet(butce, 2) << '\n';
    std::cout << "n³       " << en_buyuk_kuvvet(butce, 3) << '\n';
    long long n = 0;
    while ((1LL << (n + 1)) <= butce) {
        n++;
    }
    std::cout << "2^n      " << n << '\n';
    long long f = 1;
    n = 0;
    while (f * (n + 1) <= butce) {
        n++;
        f *= n;
    }
    std::cout << "n!       " << n << '\n';
    return 0;
}

/* Kütüphane karşılığı: C — log2, sqrt, lgamma (math.h);
 * C++ — std::log2, std::lgamma; Python — math.log2, math.lgamma */

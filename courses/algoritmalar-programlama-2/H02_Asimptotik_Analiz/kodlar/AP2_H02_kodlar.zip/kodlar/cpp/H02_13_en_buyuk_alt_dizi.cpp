/*
 * H02_13_en_buyuk_alt_dizi.cpp — AP-2 Hafta 2 · Örnek 13 (★★★)
 * Amaç    : En büyük alt dizi toplamı: O(n³) → O(n²) → O(n) Kadane
 *           (Bentley, 2000); aynı sonuç, farklı toplama sayısı
 * Sözleşme: n >= 1; alt dizi BOŞ OLAMAZ (en az bir eleman). Tamamı negatif
 *           dizide sonuç en büyük elemandır. Eşitlikte ilk bulunan aralık.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_13_en_buyuk_alt_dizi.cpp -o H02_13_en_buyuk_alt_dizi
 * Çalıştır: ./H02_13_en_buyuk_alt_dizi [n [sinir]]  (n: süre ölçümü; bir
 *           sürüm toplama sayısı sinir'i, varsayılan 10^9, aşmıyorsa çalışır)
 * Eşleri  : c/H02_13_en_buyuk_alt_dizi.c ·
 *           python/H02_13_en_buyuk_alt_dizi.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

struct Sonuc {
    long long toplam;                   // en büyük alt dizi toplamı
    std::size_t bas, son;               // aralık a[bas..son]
    long long topl;                     // yapılan toplama sayısı
};

// O(n³): her (i, j) için a[i..j] baştan toplanır
Sonuc kubik(const std::vector<int>& a, std::size_t n)
{
    Sonuc s = {a[0], 0, 0, 0};
    for (std::size_t i = 0; i < n; i++) {
        for (std::size_t j = i; j < n; j++) {
            long long toplam = 0;
            for (std::size_t k = i; k <= j; k++) {
                toplam += a[k];
                s.topl++;
            }
            if (toplam > s.toplam) {
                s.toplam = toplam;
                s.bas = i;
                s.son = j;
            }
        }
    }
    return s;
}

// O(n²): a[i..j] toplamı, a[i..j-1] toplamına a[j] eklenerek
Sonuc karesel(const std::vector<int>& a, std::size_t n)
{
    Sonuc s = {a[0], 0, 0, 0};
    for (std::size_t i = 0; i < n; i++) {
        long long toplam = 0;
        for (std::size_t j = i; j < n; j++) {
            toplam += a[j];
            s.topl++;
            if (toplam > s.toplam) {
                s.toplam = toplam;
                s.bas = i;
                s.son = j;
            }
        }
    }
    return s;
}

// O(n) Kadane: simdiki = a[i]'de biten en iyi alt dizinin toplamı.
// uzat < a[i] ise önceki kısım zarar ettiriyordur: a[i]'den yeniden başla
Sonuc kadane(const std::vector<int>& a, std::size_t n)
{
    Sonuc s = {a[0], 0, 0, 0};
    long long simdiki = a[0];
    std::size_t s_bas = 0;
    for (std::size_t i = 1; i < n; i++) {
        long long uzat = simdiki + a[i];
        s.topl++;
        if (uzat < a[i]) {
            simdiki = a[i];
            s_bas = i;
        } else {
            simdiki = uzat;
        }
        if (simdiki > s.toplam) {
            s.toplam = simdiki;
            s.bas = s_bas;
            s.son = i;
        }
    }
    return s;
}

void dizi_coz(const std::string& ad, const std::vector<int>& a)
{
    std::size_t n = a.size();
    Sonuc s1 = kubik(a, n), s2 = karesel(a, n), s3 = kadane(a, n);
    std::cout << ad << " (n=" << n << "): kübik " << s1.toplam << " ["
              << s1.bas << ".." << s1.son << "] · karesel " << s2.toplam
              << " [" << s2.bas << ".." << s2.son << "] · Kadane "
              << s3.toplam << " [" << s3.bas << ".." << s3.son << "]\n";
}

// Süre ölçümü kipi: toplama sayısı sinir'i aşmayan sürümler çalışır
int sure_olc(std::size_t n, double sinir)
{
    const char* const adlar[3] = {"Kadane", "karesel", "kübik"};
    double nd = static_cast<double>(n);
    double islem[3] = {nd - 1, nd * (nd + 1) / 2,
                       nd * (nd + 1) * (nd + 2) / 6};
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(n, -100, 100);
    std::cout << "n=" << n;
    for (int v = 0; v < 3; v++) {
        if (islem[v] > sinir) {
            std::cout << " · " << adlar[v] << " atlandı (" << std::scientific
                      << std::setprecision(2) << islem[v] << " toplama)";
            continue;
        }
        double z0 = zaman_sn();
        Sonuc s = v == 0 ? kadane(a, n) : v == 1 ? karesel(a, n)
                                                  : kubik(a, n);
        double z1 = zaman_sn();
        std::cout << " · " << adlar[v] << ' ' << s.toplam;
        std::cerr << "n=" << n << ' ' << adlar[v] << ": " << std::fixed
                  << std::setprecision(3) << (z1 - z0) * 1e3 << " ms\n";
    }
    std::cout << '\n';
    return 0;
}

int main(int argc, char* argv[])
{
    const std::vector<std::size_t> boyutlar = {10, 100, 200, 1000, 2000,
                                               10000, 100000};

    if (argc == 2 || argc == 3) {       // süre ölçümü kipi
        long n = 0;
        double sinir = 1e9;
        try {
            std::size_t son;
            n = std::stol(argv[1], &son);
            if (argv[1][son] != '\0') {
                n = 0;
            }
            if (argc == 3) {
                sinir = std::stod(argv[2], &son);
                if (argv[2][son] != '\0' || sinir <= 0) {
                    std::cerr << "sinir pozitif bir sayı olmalı\n";
                    return 2;
                }
            }
        } catch (const std::exception&) {
            n = 0;
        }
        if (n < 1 || n > 100000000) {
            std::cerr << "n 1..100000000 olmalı\n";
            return 2;
        }
        return sure_olc(static_cast<std::size_t>(n), sinir);
    }
    if (argc > 3) {
        std::cerr << "Kullanım: " << argv[0] << " [n [sinir]]\n";
        return 2;
    }

    dizi_coz("Bentley", {31, -41, 59, 26, -53, 58, 97, -93, -23, 84});
    dizi_coz("Tümü negatif", {-3, -1, -2});
    dizi_coz("Tek eleman", {5});
    dizi_coz("Sıfırlar", {0, -1, 0});
    dizi_coz("Klasik", {-2, 1, -3, 4, -1, 2, 1, -5, 4});

    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(100000, -100, 100);
    std::cout << "\nRastgele a[i] -100..100 (tohum 42); toplama sayıları\n";
    std::cout << "       n  en_büyük     kübik   n(n+1)(n+2)/6  karesel"
                 "  Kadane\n";
    for (std::size_t n : boyutlar) {
        Sonuc s3 = kadane(a, n);
        std::cout << std::setw(8) << n << ' ' << std::setw(9) << s3.toplam;
        if (n <= 200) {
            Sonuc s1 = kubik(a, n);
            std::cout << ' ' << std::setw(9) << s1.topl
                      << (s1.toplam == s3.toplam ? "" : "!");
        } else {
            std::cout << ' ' << std::setw(9) << "-";
        }
        std::cout << ' ' << std::setw(15) << n * (n + 1) * (n + 2) / 6;
        if (n <= 2000) {
            Sonuc s2 = karesel(a, n);
            std::cout << ' ' << std::setw(8) << s2.topl
                      << (s2.toplam == s3.toplam ? "" : "!");
        } else {
            std::cout << ' ' << std::setw(8) << "-";
        }
        std::cout << ' ' << std::setw(7) << s3.topl << '\n';
    }
    std::cout << "\nÜç sürüm aynı toplamı bulur (uyuşmazlık '!' ile\n";
    std::cout << "işaretlenirdi). Toplama sayıları n(n+1)(n+2)/6, n(n+1)/2"
                 " ve\n";
    std::cout << "n - 1: n = 100000'de kübik sürüm 1.7 x 10^14 toplama"
                 " isterdi,\n";
    std::cout << "Kadane 99999 toplama yapar.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — yok
 * (itertools.accumulate önek toplamı verir, Kadane'yi vermez) */

/*
 * H02_07_oran_testi.cpp — AP-2 Hafta 2 · Örnek 7 (★★)
 * Amaç    : Oran testi: n'i ikiye katlayıp T(2n)/T(n) oranından büyüme
 *           sınıfını kestirmek (Sedgewick & Wayne, 2011); sayaç ve süre
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H02_07_oran_testi.cpp -o H02_07_oran_testi
 * Çalıştır: ./H02_07_oran_testi [--azami N] [--tekrar K] [--olc]
 * Eşleri  : c/H02_07_oran_testi.c · python/H02_07_oran_testi.py
 * Çıktı   : üç dilde aynı (=); ölçülen süreler stderr'e (--olc: stdout'a)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

// i < j ve a[i] + a[j] == 0 olan çiftleri sayar: Θ(n²)
long long iki_toplam(const std::vector<int>& a, std::size_t n,
                     long long& kar)
{
    long long sayi = 0, k = 0;
    for (std::size_t i = 0; i + 1 < n; i++) {
        for (std::size_t j = i + 1; j < n; j++) {
            k++;
            if (a[i] + a[j] == 0) {
                sayi++;
            }
        }
    }
    kar = k;
    return sayi;
}

// "--ad DEGER" biçimindeki pozitif tamsayı argümanını okur
bool sayi_oku(const std::string& s, long& deger)
{
    try {
        std::size_t son;
        deger = std::stol(s, &son);
        return son == s.size() && deger > 0;
    } catch (const std::exception&) {
        return false;
    }
}

int main(int argc, char* argv[])
{
    long azami = 2000, tekrar = 5;
    bool olc = false;
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--olc") {
            olc = true;
        } else if (arg == "--azami" && i + 1 < argc &&
                   sayi_oku(argv[i + 1], azami)) {
            i++;
        } else if (arg == "--tekrar" && i + 1 < argc &&
                   sayi_oku(argv[i + 1], tekrar)) {
            i++;
        } else {
            std::cerr << "Kullanım: " << argv[0]
                      << " [--azami N] [--tekrar K] [--olc]\n";
            return 2;
        }
    }
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(static_cast<std::size_t>(azami),
                                       -1000, 1000);

    std::cout << "Oran testi: iki_toplam (i < j, a[i] + a[j] == 0),"
                 " a[i] -1000..1000, tohum 42\n";
    std::cout << "       n  sıfır_çift  karşılaştırma  oran(sayaç)  kuram"
              << (olc ? "  ortanca_ms  oran(ölçülen)" : "") << '\n';
    std::cout << std::fixed;
    std::cerr << std::fixed;
    long long onceki_kar = 0;
    double onceki_sure = 0.0;
    for (long n = 250; n <= azami; n *= 2) {
        long long kar;
        long long sayi = iki_toplam(a, static_cast<std::size_t>(n), kar);
        volatile long long havuz = 0;   // kullanılmayan sonucu -O2 siler
        double sure = olc_ortanca([&] {
            long long k;
            havuz = iki_toplam(a, static_cast<std::size_t>(n), k);
        }, static_cast<int>(tekrar)) * 1000.0;
        std::cout << std::setw(8) << n << ' ' << std::setw(11) << sayi << ' '
                  << std::setw(14) << kar;
        if (onceki_kar > 0) {
            std::cout << ' ' << std::setw(12) << std::setprecision(3)
                      << static_cast<double>(kar) / onceki_kar << "  4.000";
        } else {
            std::cout << ' ' << std::setw(12) << "-" << "  " << std::setw(5)
                      << "-";
        }
        if (olc) {                  // ölçüm stdout'a: deterministik değil
            std::cout << ' ' << std::setw(11) << std::setprecision(3)
                      << sure;
            if (onceki_sure > 0.0) {
                std::cout << ' ' << std::setw(14) << std::setprecision(2)
                          << sure / onceki_sure;
            }
        } else {
            std::cerr << "n=" << n << ": ortanca " << std::setprecision(3)
                      << sure << " ms";
            if (onceki_sure > 0.0) {
                std::cerr << " · oran " << std::setprecision(2)
                          << sure / onceki_sure;
            }
            std::cerr << '\n';
        }
        std::cout << '\n';
        onceki_kar = kar;
        onceki_sure = sure;
    }
    std::cout << "\nSayaç oranı T(2n)/T(n) = 2(2n-1)/(n-1) -> 4: Θ(n²).\n";
    std::cout << "Ölçülen süre oranı da 4'e yaklaşmalı; küçük n'de sabit\n";
    std::cout << "maliyetler ve ölçüm gürültüsü baskındır (süreler"
                 " stderr'de).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — timeit modülü
 * süre ölçer (oran hesabı elle) */

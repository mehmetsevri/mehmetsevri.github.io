/*
 * H02_Q02_ic_ice_yariya.c — AP-2 Hafta 2 · Quiz sorusu 2
 * Amaç    : Dış döngü n kez, iç döngü n'i yarıya indirerek döner;
 *           toplam iş kaç? Program sayaçla yanıtı doğrular.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H02_Q02_ic_ice_yariya.c -o H02_Q02_ic_ice_yariya
 * Çalıştır: ./H02_Q02_ic_ice_yariya
 */
#include <stdio.h>

long long say(long long n)
{
    long long s = 0;
    for (long long i = 0; i < n; i++) {
        for (long long j = n; j > 0; j /= 2) {
            s++;
        }
    }
    return s;
}

int main(void)
{
    for (long long n = 1024; n <= 8192; n *= 2) {
        long long k = 0;
        for (long long p = n; p > 1; p /= 2) {
            k++;                        /* k = ⌊log2 n⌋ */
        }
        printf("n = %5lld: s = %7lld (n * (log2 n + 1) = %lld)\n", n,
               say(n), n * (k + 1));
    }
    return 0;
}

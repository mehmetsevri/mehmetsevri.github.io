/* H01_02_en_buyuk_assert.c — AP-2 Hafta 1 · Örnek 2 (★)
 * Amaç    : Döngü değişmezi m = max(a[0..i-1]) her adımda assert ile
 *           denetlenir (başlatma, koruma, sonlanma)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_02_en_buyuk_assert.c -o H01_02_en_buyuk_assert
 * Çalıştır: ./H01_02_en_buyuk_assert   (-DNDEBUG: denetimler kapanır)
 * Eşleri  : cpp/H01_02_en_buyuk_assert.cpp · python/H01_02_en_buyuk_assert.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <assert.h>
#include <stddef.h>
#include <stdio.h>

/* Yalnızca gösterim için: degismez() kaç kez çağrıldı? -DNDEBUG ile
 * derlenince assert(...) içindeki ifade HİÇ değerlendirilmez ve bu
 * sayaç 0 kalır. Programın asıl işi assert içine konmamalıdır.    */
static long denetim_sayisi = 0;

/* degismez: m, a[0..i-1] bölümünün en büyüğü mü? (Θ(i) denetim)
 * m bu bölümde geçmeli ve bölümdeki hiçbir eleman m'den büyük
 * olmamalıdır.                                                  */
int degismez(const int a[], size_t i, int m)
{
    int gecti_mi = 0;
    denetim_sayisi++;
    for (size_t k = 0; k < i; k++) {
        if (a[k] > m) {
            return 0;
        }
        if (a[k] == m) {
            gecti_mi = 1;
        }
    }
    return gecti_mi;
}

/* Ön koşul: n >= 1. Son koşul: m = max(a[0..n-1]). */
int en_buyuk(const int a[], size_t n)
{
    assert(n >= 1);                    /* ön koşul */
    int m = a[0];
    size_t i = 1;
    assert(degismez(a, i, m));         /* başlatma */
    while (i < n) {
        if (a[i] > m) {
            m = a[i];
        }
        i++;
        assert(degismez(a, i, m));     /* koruma */
    }
    assert(i == n);                    /* sonlanma: i == n */
    return m;  /* değişmez + (i == n)  =>  m = max(a[0..n-1]) */
}

/* "ad = [x, y, ...] -> en büyük: m" biçiminde yazdırır. */
void sonuc_yaz(const char *ad, const int a[], size_t n)
{
    printf("%s = [", ad);
    for (size_t i = 0; i < n; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", a[i]);
    }
    printf("] -> en büyük: %d\n", en_buyuk(a, n));
}

int main(void)
{
    const int a[] = {3, -1, 7, 2, 7, 5};
    const int b[] = {-8, -3, -12};
    const int c[] = {42};

    sonuc_yaz("a", a, sizeof a / sizeof a[0]);
    sonuc_yaz("b", b, sizeof b / sizeof b[0]);
    sonuc_yaz("c", c, sizeof c / sizeof c[0]);
    printf("Değişmez assert ile %ld kez denetlendi", denetim_sayisi);
    printf(" (başarısız olsaydı program dururdu).\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
 * a.begin(), a.end()); Python — max(a). assert: C <assert.h>,
 * C++ <cassert>, Python assert deyimi (python3 -O ile kapanır). */

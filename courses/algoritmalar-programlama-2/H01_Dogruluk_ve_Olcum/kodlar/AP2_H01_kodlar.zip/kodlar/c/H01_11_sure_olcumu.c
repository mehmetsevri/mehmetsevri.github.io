/* H01_11_sure_olcumu.c — AP-2 Hafta 1 · Örnek 11 (★★)
 * Amaç    : Süre ölçümü: timespec_get (duvar saati), clock (işlemci
 *           zamanı) ve zamanlayici modülü (1 ısınma + 5 tekrar, ortanca)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_11_sure_olcumu.c ortak_rastgele.c zamanlayici.c \
 *           -o H01_11_sure_olcumu
 * Çalıştır: ./H01_11_sure_olcumu [n]      (varsayılan n = 1000000)
 * Eşleri  : cpp/H01_11_sure_olcumu.cpp · python/H01_11_sure_olcumu.py
 * Çıktı   : üç dilde aynı (=) — süreler stderr'e yazılır
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

/* toplam: a[0..n-1] elemanlarının toplamı (Θ(n)). */
long long toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return s;
}

/* olc_ortanca'ya verilecek görev ve verisi. Sonuç yapıda saklanır:
 * sonucu kullanılmayan bir hesabı -O2 silebilir (bkz. Örnek 12).   */
typedef struct {
    const int *a;
    size_t n;
    long long sonuc;
} ToplamGorevi;

void toplam_gorevi(void *veri)
{
    ToplamGorevi *g = veri;
    g->sonuc = toplam(g->a, g->n);
}

int main(int argc, char *argv[])
{
    long n = 1000000;
    if (argc > 2) {
        fprintf(stderr, "Kullanım: %s [n]   (1 <= n <= 100000000)\n",
                argv[0]);
        return 2;
    }
    if (argc == 2) {
        char *son;
        n = strtol(argv[1], &son, 10);
        if (*argv[1] == '\0' || *son != '\0' || n < 1 || n > 100000000) {
            fprintf(stderr, "Kullanım: %s [n]   (1 <= n <= 100000000)\n",
                    argv[0]);
            return 2;
        }
    }
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "Bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 0, 99);

    /* 1) Duvar saati: timespec_get (C11), nanosaniye çözünürlüklü */
    struct timespec t0, t1;
    timespec_get(&t0, TIME_UTC);
    long long s1 = toplam(a, (size_t)n);
    timespec_get(&t1, TIME_UTC);
    double duvar = (double)(t1.tv_sec - t0.tv_sec)
                   + (double)(t1.tv_nsec - t0.tv_nsec) * 1e-9;

    /* 2) İşlemci zamanı: clock() — süreç yalnızca CPU'da çalışırken */
    clock_t c0 = clock();
    long long s2 = toplam(a, (size_t)n);
    clock_t c1 = clock();
    double islemci = (double)(c1 - c0) / CLOCKS_PER_SEC;

    /* 3) zamanlayici modülü: 1 ısınma + 5 tekrar, ortanca */
    ToplamGorevi g = {a, (size_t)n, 0};
    double orta = olc_ortanca(toplam_gorevi, &g, 5);

    printf("n = %ld, tohum = 42, değerler 0..99\n", n);
    printf("toplam = %lld\n", s1);
    printf("Üç ölçümde de aynı sonuç: %s\n",
           (s1 == s2 && s2 == g.sonuc) ? "evet" : "HAYIR");
    printf("Süreler stderr'de (her çalıştırmada biraz farklıdır).\n");
    fprintf(stderr, "timespec_get (duvar saati)      : %10.3f ms\n",
            duvar * 1e3);
    fprintf(stderr, "clock (işlemci zamanı)          : %10.3f ms\n",
            islemci * 1e3);
    fprintf(stderr, "olc_ortanca (1 ısınma + 5, ort.): %10.3f ms\n",
            orta * 1e3);
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — timespec_get (C11), clock (C89), POSIX
 * clock_gettime(CLOCK_MONOTONIC); C++ — std::chrono::steady_clock;
 * Python — time.perf_counter, time.process_time, timeit modülü. */

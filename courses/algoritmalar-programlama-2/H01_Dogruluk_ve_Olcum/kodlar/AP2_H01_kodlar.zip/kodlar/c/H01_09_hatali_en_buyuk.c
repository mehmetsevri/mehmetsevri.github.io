/* H01_09_hatali_en_buyuk.c — AP-2 Hafta 1 · Örnek 9 (★★)
 * Amaç    : m = 0 ile başlatılmış hatalı en_buyuk'u sınır değer ve
 *           rastgele testle yakalamak. BU DOSYA KASITLI HATA İÇERİR.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_09_hatali_en_buyuk.c ortak_rastgele.c -o H01_09_hatali_en_buyuk
 * Çalıştır: ./H01_09_hatali_en_buyuk
 * Eşleri  : cpp/H01_09_hatali_en_buyuk.cpp · python/H01_09_hatali_en_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

#include "ortak_rastgele.h"

#define MAKS_N 8

/* en_buyuk: doğru sürüm (Örnek 1); burada kâhin olarak kullanılır. */
int en_buyuk(const int a[], size_t n)
{
    int m = a[0];
    for (size_t i = 1; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

/* en_buyuk_hatali: KASITLI HATA — m = 0 ile başlatılmış.
 * Dizide en az bir eleman >= 0 ise doğru sonuç verir; tamamı negatifse
 * 0 döndürür (0 dizide yok bile: son koşul bozulur).                 */
int en_buyuk_hatali(const int a[], size_t n)
{
    int m = 0;                     /* HATA: m = a[0] olmalıydı */
    for (size_t i = 0; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

/* a[0..n-1] dizisini "[x, y, ...]" biçiminde yazdırır (satır sonu yok). */
void dizi_yaz(const int a[], size_t n)
{
    printf("[");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]");
}

/* test_et: tek girdide hatalı sürümü kâhinle karşılaştırır. */
void test_et(const int a[], size_t n, const char *aciklama)
{
    int beklenen = en_buyuk(a, n);
    int bulunan = en_buyuk_hatali(a, n);
    printf("  ");
    dizi_yaz(a, n);
    printf(": beklenen %d, bulunan %d -> %s (%s)\n", beklenen, bulunan,
           beklenen == bulunan ? "geçti" : "YAKALANDI", aciklama);
}

/* rastgele_test: deneme kez n = 1..MAKS_N elemanlı, değerleri
 * [alt, ust] aralığında rastgele dizi üretir ve iki sürümü
 * karşılaştırır; ilk karşı örneği yazdırır.                      */
void rastgele_test(int deneme, int alt, int ust)
{
    int a[MAKS_N];
    int uyusmazlik = 0;
    rastgele_tohum(42);
    for (int t = 1; t <= deneme; t++) {
        size_t n = (size_t)rastgele_aralik(1, MAKS_N);
        rastgele_dizi(a, n, alt, ust);
        int beklenen = en_buyuk(a, n);
        int bulunan = en_buyuk_hatali(a, n);
        if (beklenen != bulunan) {
            uyusmazlik++;
            if (uyusmazlik == 1) {
                printf("  ilk karşı örnek (deneme %d): ", t);
                dizi_yaz(a, n);
                printf(" -> beklenen %d, bulunan %d\n", beklenen, bulunan);
            }
        }
    }
    printf("  değerler [%d, %d]: %d denemede %d uyuşmazlık%s\n", alt, ust,
           deneme, uyusmazlik, uyusmazlik == 0 ? " (hata görünmedi!)" : "");
}

int main(void)
{
    const int t1[] = {3, 9, 4};
    const int t2[] = {5};
    const int t3[] = {-5};
    const int t4[] = {-8, -3, -12};
    const int t5[] = {9, 1, 2};
    const int t6[] = {0, -1};

    printf("1) Örnek test (tipik girdi):\n");
    test_et(t1, 3, "tipik");
    printf("2) Sınır değer testleri:\n");
    test_et(t2, 1, "tek eleman");
    test_et(t3, 1, "tek negatif eleman");
    test_et(t4, 3, "tamamı negatif");
    test_et(t5, 3, "en büyük başta");
    test_et(t6, 2, "en büyük 0");
    printf("3) Rastgele test (ortak LCG, tohum 42, n = 1..%d):\n", MAKS_N);
    rastgele_test(1000, -100, 100);
    rastgele_test(1000, 0, 100);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
 * a.begin(), a.end()); Python — max(a). */

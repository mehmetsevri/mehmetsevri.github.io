/* H01_07_faktoriyel_tasma.c — AP-2 Hafta 1 · Örnek 7 (★★)
 * Amaç    : 13! hesabı: uint32_t 2^32 modunda sarar, uint64_t doğru
 *           değeri verir (21!'de o da sarar); işaretli taşma notu
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_07_faktoriyel_tasma.c -o H01_07_faktoriyel_tasma
 * Çalıştır: ./H01_07_faktoriyel_tasma
 * Eşleri  : cpp/H01_07_faktoriyel_tasma.cpp · python/H01_07_faktoriyel_tasma.py
 * Çıktı   : Δ — C ve C++ aynı, Python farklı; bkz. Dil Penceresi
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

/* UYARI — İŞARETLİ taşma TANIMSIZ DAVRANIŞTIR (C17 §6.5): int f;
 * f *= 13 işlemi 13! = 6227020800 > INT_MAX = 2147483647 olduğu için
 * tanımsızdır. "Başa sarar" varsayılamaz: derleyici taşmanın hiç
 * olmayacağını varsayıp kodu dönüştürebilir. Bu yüzden program
 * yalnızca İŞARETSİZ türler kullanır; işaretsiz aritmetik 2^N
 * modunda TANIMLIDIR (C17 §6.2.5). İşaretli sürüm çalıştırılmaz. */
int main(void)
{
    uint32_t f32 = 1;   /* 32 bit: 0 .. 4294967295            */
    uint64_t f64 = 1;   /* 64 bit: 0 .. 18446744073709551615  */

    printf("C: işaretsiz sabit genişlikli tamsayılar (2^N modunda sarar)\n");
    printf(" n      uint32_t              uint64_t\n");
    for (uint32_t n = 1; n <= 13; n++) {
        f32 *= n;       /* 2^32 modunda: tanımlı sarma */
        f64 *= n;
        printf("%2" PRIu32 " %13" PRIu32 " %21" PRIu64 "%s\n", n, f32, f64,
               (uint64_t)f32 == f64 ? "" : "  <- uint32_t sardı");
    }
    printf("13! mod 2^32 = %" PRIu64 " - %" PRIu64 " = %" PRIu32 "\n",
           f64, (uint64_t)1 << 32, f32);
    for (uint64_t n = 14; n <= 21; n++) {
        f64 *= n;       /* 2^64 modunda: 21!'de sarar */
        if (n == 20) {
            printf("20! (uint64_t) = %" PRIu64 "\n", f64);
        }
    }
    printf("21! (uint64_t) = %" PRIu64 "  <- uint64_t de sardı\n", f64);
    return 0;
}

/* Kütüphane karşılığı: C — standart faktöriyel yok; tgamma(n + 1.0)
 * (<math.h>) double verir (yaklaşık); C++ — std::tgamma; Python —
 * math.factorial(n) (tam değer). */

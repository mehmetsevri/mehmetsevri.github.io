/* H01_01_en_buyuk.c — AP-2 Hafta 1 · Örnek 1 (★)
 * Amaç    : Dizinin en büyük elemanı; ön koşul–son koşul sözleşmesi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_01_en_buyuk.c -o H01_01_en_buyuk
 * Çalıştır: ./H01_01_en_buyuk
 * Eşleri  : cpp/H01_01_en_buyuk.cpp · python/H01_01_en_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

/* en_buyuk: a[0..n-1] dizisinin en büyük elemanını döndürür.
 * Ön koşul : n >= 1 (dizi boş değil); a en az n elemanlıdır.
 * Son koşul: dönen m dizinin bir elemanıdır ve her k için
 *            (0 <= k < n) a[k] <= m sağlanır.
 * Ön koşul ihlali (n == 0) çağıranın hatasıdır: a[0] geçerli bir
 * eleman değildir, okunması tanımsız davranıştır; fonksiyon bunu
 * ayrıca denetlemez.                                              */
int en_buyuk(const int a[], size_t n)
{
    int m = a[0];
    for (size_t i = 1; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

/* "ad = [x, y, ...] -> en büyük: m" biçiminde yazdırır. */
void sonuc_yaz(const char *ad, const int a[], size_t n)
{
    printf("%s = [", ad);
    for (size_t i = 0; i < n; i++) {
        if (i > 0) {
            printf(", ");
        }
        printf("%d", a[i]);
    }
    printf("] -> en büyük: %d\n", en_buyuk(a, n));
}

int main(void)
{
    const int a[] = {3, -1, 7, 2, 7, 5};
    const int b[] = {-8, -3, -12};
    const int c[] = {42};

    sonuc_yaz("a", a, sizeof a / sizeof a[0]);
    sonuc_yaz("b", b, sizeof b / sizeof b[0]);
    sonuc_yaz("c", c, sizeof c / sizeof c[0]);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
 * a.begin(), a.end()); Python — max(a). */

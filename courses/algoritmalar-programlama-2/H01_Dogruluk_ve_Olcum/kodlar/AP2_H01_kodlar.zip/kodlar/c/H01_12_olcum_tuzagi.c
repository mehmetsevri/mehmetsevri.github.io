/* H01_12_olcum_tuzagi.c — AP-2 Hafta 1 · Örnek 12 (★★★)
 * Amaç    : Ölçüm tuzağı: sonucu kullanılmayan döngüyü -O2 tamamen
 *           siler; çözüm: sonucu kullan/yazdır. -O0 ile de deneyin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_12_olcum_tuzagi.c ortak_rastgele.c zamanlayici.c \
 *           -o H01_12_olcum_tuzagi
 * Çalıştır: ./H01_12_olcum_tuzagi [n]      (varsayılan n = 1000000)
 * Eşleri  : cpp/H01_12_olcum_tuzagi.cpp · python/H01_12_olcum_tuzagi.py
 * Çıktı   : üç dilde aynı (=) — asıl fark süredir (stderr)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

typedef struct {
    const int *a;
    size_t n;
} Dizi;

long long sonuc_yeri = 0;   /* kullanilan_dongu sonucu buraya yazar */

/* kullanilmayan_dongu: toplamı hesaplar ama sonucu hiçbir yere
 * yazmaz. Gözlemlenebilir bir etkisi olmadığından derleyici -O2'de
 * döngünün tamamını silebilir ("as-if" kuralı, C17 §5.1.2.3).     */
void kullanilmayan_dongu(void *veri)
{
    const Dizi *d = veri;
    long long s = 0;
    for (size_t i = 0; i < d->n; i++) {
        s += d->a[i];
    }
    (void)s;                /* yalnızca derleyici uyarısını susturur */
}

/* kullanilan_dongu: aynı döngü; sonuç dış değişkene yazılır ve
 * main'de yazdırılır: derleyici döngüyü silemez.                  */
void kullanilan_dongu(void *veri)
{
    const Dizi *d = veri;
    long long s = 0;
    for (size_t i = 0; i < d->n; i++) {
        s += d->a[i];
    }
    sonuc_yeri = s;         /* ÇÖZÜM: sonucu kullan */
}

int main(int argc, char *argv[])
{
    long n = 1000000;
    if (argc > 2) {
        fprintf(stderr, "Kullanım: %s [n]   (1 <= n <= 100000000)\n",
                argv[0]);
        return 2;
    }
    if (argc == 2) {
        char *son;
        n = strtol(argv[1], &son, 10);
        if (*argv[1] == '\0' || *son != '\0' || n < 1 || n > 100000000) {
            fprintf(stderr, "Kullanım: %s [n]   (1 <= n <= 100000000)\n",
                    argv[0]);
            return 2;
        }
    }
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "Bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 0, 99);
    Dizi d = {a, (size_t)n};

    double t_bos = olc_ortanca(kullanilmayan_dongu, &d, 5);
    double t_dolu = olc_ortanca(kullanilan_dongu, &d, 5);

    printf("n = %ld, tohum = 42, değerler 0..99\n", n);
    printf("Sonucu kullanılan döngü   : toplam = %lld\n", sonuc_yeri);
    printf("Sonucu kullanılmayan döngü: sonuç hiçbir yere yazılmadı\n");
    printf("Süreler stderr'de: -O0 ve -O2 ile derleyip karşılaştırın.\n");
    fprintf(stderr, "kullanılmayan: %12.6f ms (eleman başına %9.4f ns)\n",
            t_bos * 1e3, t_bos * 1e9 / (double)n);
    fprintf(stderr, "kullanılan   : %12.6f ms (eleman başına %9.4f ns)\n",
            t_dolu * 1e3, t_dolu * 1e9 / (double)n);
    /* Geçerlilik denetimi: 2,8 GHz'de bir saat çevrimi ≈ 0,36 ns. Eleman
     * başına 0,05 ns'den kısa süre, döngünün çalışmadığını gösterir. */
    if (t_bos * 1e9 / (double)n < 0.05) {
        fprintf(stderr, "UYARI: kullanılmayan döngü eleman başına 0,05 ns'den"
                        " kısa sürdü: döngü büyük olasılıkla SİLİNDİ.\n");
    }
    free(a);
    return 0;
}

/* Kütüphane karşılığı: ölçümde derleyicinin işi silmesini önlemek için
 * C/C++'ta sonucu volatile bir değişkene yazmak ya da Google Benchmark'ın
 * benchmark::DoNotOptimize'ı; Python'da gerekmez (CPython döngüyü silmez),
 * ölçüm için timeit modülü. */

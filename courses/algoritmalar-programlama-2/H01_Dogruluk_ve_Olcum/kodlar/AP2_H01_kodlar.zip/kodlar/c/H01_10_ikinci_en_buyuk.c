/* H01_10_ikinci_en_buyuk.c — AP-2 Hafta 1 · Örnek 10 (★★★)
 * Amaç    : Tek geçişli ikinci en büyük; sıralama tabanlı kâhinle
 *           rastgele karşılaştırmalı test ve stres testi.
 *           ikinci_en_buyuk_hatali KASITLI HATA İÇERİR (testi sınamak için).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_10_ikinci_en_buyuk.c ortak_rastgele.c \
 *           -o H01_10_ikinci_en_buyuk
 * Çalıştır: ./H01_10_ikinci_en_buyuk
 * Eşleri  : cpp/H01_10_ikinci_en_buyuk.cpp · python/H01_10_ikinci_en_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS_N 12

/* ikinci_en_buyuk: tek geçişte ikinci en büyük eleman.
 * Ön koşul : n >= 2.
 * Son koşul: dizi azalan sıralansaydı 1. konumda (0'dan) duracak değer.
 *            Eşitlik: en büyük birden çok kez geçiyorsa ikinci en büyük
 *            de odur ([7, 3, 7] -> 7).
 * Değişmez : döngü başında b1 >= b2 ve b1, b2 a[0..i-1]'in en büyük
 *            iki elemanıdır (yinelenenler ayrı sayılır).            */
int ikinci_en_buyuk(const int a[], size_t n)
{
    int b1 = a[0], b2 = a[1];
    if (b2 > b1) {
        b1 = a[1];
        b2 = a[0];
    }
    for (size_t i = 2; i < n; i++) {
        if (a[i] > b1) {
            b2 = b1;
            b1 = a[i];
        } else if (a[i] > b2) {
            b2 = a[i];
        }
    }
    return b2;
}

/* ikinci_en_buyuk_hatali: KASITLI HATA — "else if" dalı unutulmuş:
 * b2 < a[i] <= b1 olan eleman b2'yi güncellemez. Test düzeneğinin
 * hatayı yakalayabildiğini sınamak için kullanılır.                */
int ikinci_en_buyuk_hatali(const int a[], size_t n)
{
    int b1 = a[0], b2 = a[1];
    if (b2 > b1) {
        b1 = a[1];
        b2 = a[0];
    }
    for (size_t i = 2; i < n; i++) {
        if (a[i] > b1) {
            b2 = b1;
            b1 = a[i];
        }                          /* HATA: else if (a[i] > b2) eksik */
    }
    return b2;
}

/* qsort için artan sıra karşılaştırıcısı (taşmasız). */
static int karsilastir(const void *p, const void *q)
{
    int x = *(const int *)p;
    int y = *(const int *)q;
    return (x > y) - (x < y);
}

/* kahin: yavaş ama apaçık doğru — kopyayı sırala, sondan ikinciyi al.
 * Θ(n log n); qsort yalnızca kâhinde serbesttir.                    */
int kahin(const int a[], size_t n)
{
    int *kopya = malloc(n * sizeof *kopya);
    if (kopya == NULL) {
        fprintf(stderr, "Bellek yetersiz\n");
        exit(1);
    }
    memcpy(kopya, a, n * sizeof *kopya);
    qsort(kopya, n, sizeof *kopya, karsilastir);
    int sonuc = kopya[n - 2];
    free(kopya);
    return sonuc;
}

/* a[0..n-1] dizisini "[x, y, ...]" biçiminde yazdırır (satır sonu yok). */
void dizi_yaz(const int a[], size_t n)
{
    printf("[");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]");
}

/* karsilastirmali_test: f'yi kâhine karşı deneme kez sınar
 * (n = 2..MAKS_N, değerler [alt, ust], tohum 2027). İlk uyuşmazlığı
 * yazdırır; uyuşmazlık sayısını döndürür.                         */
int karsilastirmali_test(int (*f)(const int[], size_t), const char *ad,
                         int deneme, int alt, int ust)
{
    int a[MAKS_N];
    int uyusmazlik = 0;
    rastgele_tohum(2027);
    for (int t = 1; t <= deneme; t++) {
        size_t n = (size_t)rastgele_aralik(2, MAKS_N);
        rastgele_dizi(a, n, alt, ust);
        int beklenen = kahin(a, n);
        int bulunan = f(a, n);
        if (beklenen != bulunan) {
            uyusmazlik++;
            if (uyusmazlik == 1) {
                printf("  ilk uyuşmazlık (deneme %d): ", t);
                dizi_yaz(a, n);
                printf(" -> kâhin %d, bulunan %d\n", beklenen, bulunan);
            }
        }
    }
    printf("  %s, değerler [%d, %d]: %d deneme, %d uyuşmazlık\n", ad, alt,
           ust, deneme, uyusmazlik);
    return uyusmazlik;
}

int main(void)
{
    const int s1[] = {5, 9};
    const int s2[] = {9, 5};
    const int s3[] = {7, 7};
    const int s4[] = {7, 3, 7};
    const int s5[] = {1, 2, 3, 4};
    const int s6[] = {4, 3, 2, 1};
    const int s7[] = {-5, -5, -9};
    const int *sinir[] = {s1, s2, s3, s4, s5, s6, s7};
    const size_t boy[] = {2, 2, 2, 3, 4, 4, 3};

    printf("1) Sınır durumları (n = 2, eşitlik, en büyük başta/sonda):\n");
    for (int k = 0; k < 7; k++) {
        printf("  ");
        dizi_yaz(sinir[k], boy[k]);
        printf(" -> %d (kâhin %d)\n", ikinci_en_buyuk(sinir[k], boy[k]),
               kahin(sinir[k], boy[k]));
    }

    printf("2) Kâhinle rastgele karşılaştırmalı test (tohum 2027):\n");
    karsilastirmali_test(ikinci_en_buyuk, "ikinci_en_buyuk", 2000, -5, 5);
    karsilastirmali_test(ikinci_en_buyuk, "ikinci_en_buyuk", 2000,
                         -1000, 1000);

    printf("3) Testi sına: kasıtlı hatalı sürüm aynı testte\n");
    karsilastirmali_test(ikinci_en_buyuk_hatali, "ikinci_en_buyuk_hatali",
                         2000, -5, 5);

    printf("4) Stres testi: n = 100000, değerler [-10^6, 10^6], tohum 7\n");
    size_t n = 100000;
    int *b = malloc(n * sizeof *b);
    if (b == NULL) {
        fprintf(stderr, "Bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(7);
    rastgele_dizi(b, n, -1000000, 1000000);
    int hizli = ikinci_en_buyuk(b, n);
    int yavas = kahin(b, n);
    printf("  hızlı %d, kâhin %d -> %s\n", hizli, yavas,
           hizli == yavas ? "eşleşti" : "UYUŞMAZLIK");
    free(b);
    return 0;
}

/* Kütüphane karşılığı: C — yok (kâhin: qsort); C++ — std::nth_element ya
 * da std::partial_sort (kâhin: std::sort); Python — heapq.nlargest(2, a)
 * [1] ya da sorted(a)[-2] (kâhin). */

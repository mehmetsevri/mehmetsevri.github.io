/* H01_06_bolme_kalan.c — AP-2 Hafta 1 · Örnek 6 (★★)
 * Amaç    : -7 / 2 ve -7 % 2: C'de tamsayı bölmesi sıfıra doğru keser,
 *           kalan bölünenin işaretini alır (C99'dan beri tanımlı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_06_bolme_kalan.c -o H01_06_bolme_kalan
 * Çalıştır: ./H01_06_bolme_kalan
 * Eşleri  : cpp/H01_06_bolme_kalan.cpp · python/H01_06_bolme_kalan.py
 * Çıktı   : Δ — C ve C++ aynı, Python farklı; bkz. Dil Penceresi
 */
#include <stdio.h>

int main(void)
{
    const int a_deger[] = {7, -7, 7, -7};
    const int b_deger[] = {2, 2, -2, -2};

    printf("C: / sıfıra doğru keser, %% bölünenin işaretini alır\n");
    printf("   a    b   a / b   a %% b   (a / b) * b + a %% b\n");
    for (int i = 0; i < 4; i++) {
        int a = a_deger[i];
        int b = b_deger[i];
        int q = a / b;      /* bölüm: sıfıra doğru kesme */
        int r = a % b;      /* kalan: işareti a'nınki    */
        printf("%4d %4d %7d %7d %13d\n", a, b, q, r, q * b + r);
    }
    /* Yaygın tuzak: x % 2 == 1 negatif tek sayılarda yanlıştır. */
    printf("-7 tek mi? (-7 %% 2 == 1): %s\n",
           (-7 % 2 == 1) ? "evet" : "hayır");
    printf("-7 tek mi? (-7 %% 2 != 0): %s\n",
           (-7 % 2 != 0) ? "evet" : "hayır");
    return 0;
}

/* Kütüphane karşılığı: C — div(a, b) (<stdlib.h>; bölüm ve kalanı
 * birlikte verir, aynı kural); C++ — std::div; Python — divmod(a, b)
 * (taban bölmesi kuralıyla). */

/* H01_05_oklid_ebob.c — AP-2 Hafta 1 · Örnek 5 (★★)
 * Amaç    : Öklid algoritmasıyla EBOB; sonlanma kanıtı: b her adımda
 *           kesin azalır ve 0'ın altına inemez
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_05_oklid_ebob.c -o H01_05_oklid_ebob
 * Çalıştır: ./H01_05_oklid_ebob
 * Eşleri  : cpp/H01_05_oklid_ebob.cpp · python/H01_05_oklid_ebob.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

static int adim_sayisi = 0;   /* döngü adımı (mod işlemi) sayacı */

/* ebob: a ve b'nin en büyük ortak böleni (Öklid algoritması).
 * Ön koşul : a >= 0, b >= 0 ve ikisi birden 0 değil.
 * Son koşul: dönen d hem a'yı hem b'yi böler ve ortak bölenlerin
 *            en büyüğüdür.
 * Değişmez : ebob(a, b) döngü boyunca aynı kalır, çünkü
 *            ebob(a, b) = ebob(b, a mod b).
 * Sonlanma : b >= 0 ve her adımda kesin azalır (0 <= a % b < b);
 *            negatif olmayan tamsayılar sonsuza dek azalamaz.    */
int ebob(int a, int b)
{
    adim_sayisi = 0;
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
        adim_sayisi++;
    }
    return a;
}

/* ebob_izle: her adımda a, b ve a % b değerlerini yazdırır. */
void ebob_izle(int a, int b)
{
    printf("ebob(%d, %d) izlemesi (b her adımda kesin azalır):\n", a, b);
    while (b != 0) {
        printf("  a = %4d   b = %4d   a %% b = %4d\n", a, b, a % b);
        int r = a % b;
        a = b;
        b = r;
    }
    printf("  a = %4d   b = %4d   -> b = 0, sonuç: %d\n", a, b, a);
}

int main(void)
{
    /* Son iki çift ardışık Fibonacci sayılarıdır (F11, F10) ve
     * (F30, F29): Öklid'in en kötü durumu.                     */
    const int ciftler[][2] = {
        {252, 105}, {1071, 462}, {55, 89}, {17, 0}, {0, 9},
        {1000000, 999999}, {89, 55}, {832040, 514229}
    };
    const int adet = (int)(sizeof ciftler / sizeof ciftler[0]);

    ebob_izle(252, 105);
    printf("\n        a         b     ebob  adım\n");
    for (int i = 0; i < adet; i++) {
        int a = ciftler[i][0], b = ciftler[i][1];
        int d = ebob(a, b);
        printf("%9d %9d %8d %5d\n", a, b, d, adim_sayisi);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::gcd (<numeric>, C++17);
 * Python — math.gcd(a, b). */

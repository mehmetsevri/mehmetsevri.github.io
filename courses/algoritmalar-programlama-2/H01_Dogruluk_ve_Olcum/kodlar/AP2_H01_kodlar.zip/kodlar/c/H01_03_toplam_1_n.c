/* H01_03_toplam_1_n.c — AP-2 Hafta 1 · Örnek 3 (★)
 * Amaç    : 1 + 2 + ... + n: döngü ve formül; döngü değişmeziyle
 *           doğruluk (başlatma–koruma–sonlanma)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_03_toplam_1_n.c -o H01_03_toplam_1_n
 * Çalıştır: ./H01_03_toplam_1_n
 * Eşleri  : cpp/H01_03_toplam_1_n.cpp · python/H01_03_toplam_1_n.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

/* toplam_dongu: 1 + 2 + ... + n (ön koşul: n >= 0).
 * Değişmez (döngü başında): s = 1 + 2 + ... + (k-1) = (k-1)k/2
 * Başlatma : k = 1, s = 0 = 0·1/2.
 * Koruma   : s += k sonrası s = k(k+1)/2; k++ ile yine (k-1)k/2.
 * Sonlanma : döngü k = n+1'de biter → s = n(n+1)/2.             */
long long toplam_dongu(int n)
{
    long long s = 0;
    for (int k = 1; k <= n; k++) {
        s += k;
    }
    return s;
}

/* toplam_formul: Gauss formülü n(n+1)/2. Çarpım long long'da
 * yapılır: n = 65536 için n(n+1) = 4295032832, 32 bitlik int'e
 * sığmaz (işaretli taşma tanımsız davranış olurdu).            */
long long toplam_formul(int n)
{
    return (long long)n * (n + 1) / 2;
}

/* izle: döngü başındaki değişmezi her adımda yazdırır. */
void izle(int n)
{
    long long s = 0;
    int k = 1;
    printf("n = %d için değişmez s = (k-1)k/2 (döngü başında):\n", n);
    while (k <= n) {
        printf("  k = %d: s = %2lld, (k-1)k/2 = %2lld\n",
               k, s, (long long)(k - 1) * k / 2);
        s += k;
        k++;
    }
    printf("  k = %d: s = %2lld, (k-1)k/2 = %2lld  <- k = n+1, döngü biter\n",
           k, s, (long long)(k - 1) * k / 2);
}

int main(void)
{
    const int n_deger[] = {0, 1, 10, 100, 65536, 1000000};

    izle(5);
    /* %16s bayt sayar; ö, ü gibi harfler UTF-8'de 2 bayt olduğundan
     * Türkçe başlık sabit metin olarak yazılır (üç dilde aynı çıktı). */
    printf("\n       n            döngü           formül  eşit\n");
    for (int i = 0; i < 6; i++) {
        int n = n_deger[i];
        long long d = toplam_dongu(n);
        long long f = toplam_formul(n);
        printf("%8d %16lld %16lld  %s\n", n, d, f, d == f ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::accumulate (<numeric>) ya da
 * std::iota + std::accumulate; Python — sum(range(1, n + 1)). */

/* H01_04_dogrusal_arama.c — AP-2 Hafta 1 · Örnek 4 (★★)
 * Amaç    : Doğrusal arama; "bulunamadı" sözleşmesi (-1), döngü
 *           değişmezi, sonlanma ve iki çıkış noktası
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_04_dogrusal_arama.c -o H01_04_dogrusal_arama
 * Çalıştır: ./H01_04_dogrusal_arama
 * Eşleri  : cpp/H01_04_dogrusal_arama.cpp · python/H01_04_dogrusal_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

static long karsilastirma = 0;   /* a[i] == x karşılaştırma sayacı */

/* dogrusal_ara: x'in a[0..n-1] içindeki İLK konumunu döndürür;
 * x yoksa -1 döndürür ("bulunamadı" sözleşmesi).
 * Ön koşul : a en az n elemanlıdır (n = 0 olabilir).
 * Son koşul: dönen i >= 0 ise a[i] == x ve x, a[0..i-1]'de yok;
 *            -1 ise x, a[0..n-1]'in hiçbir yerinde yok.
 * Değişmez : döngü başında x, a[0..i-1] içinde yok.
 * Sonlanma : i her adımda 1 artar; en çok n adımda i == n olur. */
int dogrusal_ara(const int a[], size_t n,
                 int x)
{
    for (size_t i = 0; i < n; i++) {
        karsilastirma++;
        if (a[i] == x) {    /* 1. çıkış */
            return (int)i;
        }
    }
    return -1;              /* 2. çıkış */
}

/* ara_yaz: aramayı yapar; sonucu ve karşılaştırma sayısını yazar. */
void ara_yaz(const int a[], size_t n, int x)
{
    karsilastirma = 0;
    int k = dogrusal_ara(a, n, x);
    if (k == -1) {
        printf("ara(%d) -> bulunamadı", x);
    } else {
        printf("ara(%d) -> %d", x, k);
    }
    printf(", karşılaştırma: %ld\n", karsilastirma);
}

int main(void)
{
    const int a[] = {7, 3, 9, 3, 5, 1, 8};
    const size_t n = sizeof a / sizeof a[0];

    printf("a = [7, 3, 9, 3, 5, 1, 8] (n = %zu)\n", n);
    ara_yaz(a, n, 7);   /* en iyi durum: ilk eleman */
    ara_yaz(a, n, 3);   /* iki kez geçiyor: İLK konum */
    ara_yaz(a, n, 8);   /* son eleman */
    ara_yaz(a, n, 6);   /* yok: en kötü durum, n karşılaştırma */
    printf("boş dizi:\n");
    ara_yaz(a, 0, 7);   /* n = 0: döngüye hiç girilmez */
    return 0;
}

/* Kütüphane karşılığı: C — standart C'de yok (POSIX lfind);
 * C++ — std::find; Python — a.index(x) (yoksa ValueError), x in a. */

/* H01_08_ortak_lcg.c — AP-2 Hafta 1 · Örnek 8 (★★)
 * Amaç    : Ortak LCG modülüyle üç dilde BİREBİR aynı "rastgele" dizi;
 *           aynı tohum → aynı dizi (tekrarlanabilir deney)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_08_ortak_lcg.c ortak_rastgele.c -o H01_08_ortak_lcg
 * Çalıştır: ./H01_08_ortak_lcg
 * Eşleri  : cpp/H01_08_ortak_lcg.cpp · python/H01_08_ortak_lcg.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <inttypes.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include "ortak_rastgele.h"

/* a[0..n-1] dizisini "[x, y, ...]" biçiminde yazdırır. */
void dizi_yaz(const int a[], size_t n)
{
    printf("[");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]\n");
}

int main(void)
{
    /* 1) Formülü elle uygula: durum = durum * A + C (mod 2^64) */
    uint64_t durum = 42;
    durum = durum * UINT64_C(6364136223846793005)
            + UINT64_C(1442695040888963407);   /* uint64_t: 2^64 modunda */
    printf("Elle   : durum = %" PRIu64 "\n", durum);
    printf("         çıktı = durum >> 33 = %" PRIu64 "\n", durum >> 33);

    /* 2) Aynı hesabı modül yapar */
    rastgele_tohum(42);
    printf("Modül  : rastgele_sayi() x 4 =");
    for (int i = 0; i < 4; i++) {
        printf(" %" PRIu32, rastgele_sayi());
    }
    printf("\n");

    int zar[10];
    for (int i = 0; i < 10; i++) {
        zar[i] = rastgele_aralik(1, 6);
    }
    printf("rastgele_aralik(1, 6) x 10  = ");
    dizi_yaz(zar, 10);

    printf("rastgele_kesir() x 3        =");
    for (int i = 0; i < 3; i++) {
        printf(" %.6f", rastgele_kesir());
    }
    printf("\n");

    int a[8];
    rastgele_dizi(a, 8, -50, 50);
    printf("rastgele_dizi(8, -50, 50)   = ");
    dizi_yaz(a, 8);

    int p[10];
    for (int i = 0; i < 10; i++) {
        p[i] = i + 1;
    }
    rastgele_karistir(p, 10);
    printf("rastgele_karistir(1..10)    = ");
    dizi_yaz(p, 10);

    /* 3) Aynı tohum → aynı dizi */
    rastgele_tohum(42);
    uint32_t ilk = rastgele_sayi();
    printf("Yeniden tohum 42, ilk sayı  = %" PRIu32 " (aynı dizi baştan)\n",
           ilk);
    return 0;
}

/* Kütüphane karşılığı: C — rand()/srand() (dizi platforma göre değişir);
 * C++ — std::mt19937 + std::uniform_int_distribution (dağılım sınıfının
 * çıktısı gerçekleştirime göre değişebilir); Python — random.seed,
 * random.randint (Mersenne Twister). Ders örneklerinde kullanılmaz. */

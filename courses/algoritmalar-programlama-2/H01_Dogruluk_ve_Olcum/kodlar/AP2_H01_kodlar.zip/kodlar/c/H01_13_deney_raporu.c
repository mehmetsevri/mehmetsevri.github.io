/* H01_13_deney_raporu.c — AP-2 Hafta 1 · Örnek 13 (★★★)
 * Amaç    : Deney raporu: dizi toplamı için n'e karşı süre tablosu;
 *           --csv ile süreler CSV dosyasına yazılır (grafik için)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_13_deney_raporu.c ortak_rastgele.c zamanlayici.c \
 *           -o H01_13_deney_raporu
 * Çalıştır: ./H01_13_deney_raporu [--nmax N] [--csv dosya.csv]
 * Eşleri  : cpp/H01_13_deney_raporu.cpp · python/H01_13_deney_raporu.py
 * Çıktı   : üç dilde aynı (=) — süreler stderr'e ve CSV'ye yazılır
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define TEKRAR 5

/* __OPTIMIZE__ GCC/Clang'ın, optimizasyonlu derlemede tanımladığı
 * makrodur: CSV'deki "derleme" sütununu kendiliğinden doldurur.  */
#ifdef __OPTIMIZE__
#define DERLEME "O1+"
#else
#define DERLEME "O0"
#endif

/* toplam: a[0..n-1] elemanlarının toplamı (Θ(n)). */
long long toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return s;
}

typedef struct {
    const int *a;
    size_t n;
    long long sonuc;        /* sonucu sakla: -O2 döngüyü silemesin */
} ToplamGorevi;

void toplam_gorevi(void *veri)
{
    ToplamGorevi *g = veri;
    g->sonuc = toplam(g->a, g->n);
}

void kullanim(const char *ad)
{
    fprintf(stderr, "Kullanım: %s [--nmax N] [--csv dosya.csv]\n"
                    "  N: 1000 .. 100000000 (varsayılan 100000)\n", ad);
}

int main(int argc, char *argv[])
{
    long nmax = 100000;
    const char *csv_yolu = NULL;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--nmax") == 0 && i + 1 < argc) {
            char *son;
            const char *metin = argv[++i];
            nmax = strtol(metin, &son, 10);
            if (*metin == '\0' || *son != '\0' || nmax < 1000
                || nmax > 100000000) {
                kullanim(argv[0]);
                return 2;
            }
        } else if (strcmp(argv[i], "--csv") == 0 && i + 1 < argc) {
            csv_yolu = argv[++i];
        } else {
            kullanim(argv[0]);
            return 2;
        }
    }
    FILE *csv = NULL;
    if (csv_yolu != NULL) {
        csv = fopen(csv_yolu, "w");
        if (csv == NULL) {
            fprintf(stderr, "Hata: %s açılamadı\n", csv_yolu);
            return 1;
        }
        fprintf(csv, "n;dil;derleme;tekrar;ortanca_ms;toplam\n");
    }

    printf("Deney: dizi toplamı (Θ(n)), tohum 42, değerler 0..99\n");
    printf("Düzen: 1 ısınma + %d tekrar, ortanca (süreler stderr/CSV)\n",
           TEKRAR);
    printf("%10s %14s %10s\n", "n", "toplam", "ortalama");
    double onceki = 0.0;
    for (long n = 1000; n <= nmax; n *= 10) {
        int *a = malloc((size_t)n * sizeof *a);
        if (a == NULL) {
            fprintf(stderr, "Bellek yetersiz\n");
            return 1;
        }
        rastgele_tohum(42);
        rastgele_dizi(a, (size_t)n, 0, 99);
        ToplamGorevi g = {a, (size_t)n, 0};
        double t = olc_ortanca(toplam_gorevi, &g, TEKRAR);
        printf("%10ld %14lld %10.4f\n", n, g.sonuc,
               (double)g.sonuc / (double)n);
        fprintf(stderr, "n = %9ld: ortanca %10.4f ms", n, t * 1e3);
        if (onceki > 0.0) {
            fprintf(stderr, "   T(n)/T(n/10) = %.2f", t / onceki);
        }
        fprintf(stderr, "\n");
        if (csv != NULL) {
            fprintf(csv, "%ld;C;%s;%d;%.6f;%lld\n", n, DERLEME, TEKRAR,
                    t * 1e3, g.sonuc);
        }
        onceki = t;
        free(a);
    }
    if (csv != NULL) {
        fclose(csv);
        printf("CSV yazıldı: %s\n", csv_yolu);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (CSV elle yazılır); C++ — yok (std::ofstream);
 * Python — csv modülü (csv.writer(f, delimiter=";")); grafik için ayrı
 * betik: gorseller/kaynak/ (matplotlib, örnek kodun parçası değil). */

/* H01_07_faktoriyel_tasma.cpp — AP-2 Hafta 1 · Örnek 7 (★★)
 * Amaç    : 13! hesabı: uint32_t 2^32 modunda sarar, uint64_t doğru
 *           değeri verir (21!'de o da sarar); işaretli taşma notu
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_07_faktoriyel_tasma.cpp -o H01_07_faktoriyel_tasma
 * Çalıştır: ./H01_07_faktoriyel_tasma
 * Eşleri  : c/H01_07_faktoriyel_tasma.c · python/H01_07_faktoriyel_tasma.py
 * Çıktı   : Δ — C ve C++ aynı, Python farklı; bkz. Dil Penceresi
 */
#include <cstdint>
#include <iomanip>
#include <iostream>

// UYARI — İŞARETLİ taşma TANIMSIZ DAVRANIŞTIR (C++17 [expr]/4): int f;
// f *= 13 işlemi 13! = 6227020800 > INT_MAX = 2147483647 olduğu için
// tanımsızdır. "Başa sarar" varsayılamaz: derleyici taşmanın hiç
// olmayacağını varsayıp kodu dönüştürebilir. Bu yüzden program
// yalnızca İŞARETSİZ türler kullanır; işaretsiz aritmetik 2^N
// modunda TANIMLIDIR (C++17 [basic.fundamental]). İşaretli sürüm
// çalıştırılmaz.
int main()
{
    std::uint32_t f32 = 1;   // 32 bit: 0 .. 4294967295
    std::uint64_t f64 = 1;   // 64 bit: 0 .. 18446744073709551615

    std::cout << "C++: işaretsiz sabit genişlikli tamsayılar "
                 "(2^N modunda sarar)\n";
    std::cout << " n      uint32_t              uint64_t\n";
    for (std::uint32_t n = 1; n <= 13; n++) {
        f32 *= n;            // 2^32 modunda: tanımlı sarma
        f64 *= n;
        std::cout << std::setw(2) << n << " " << std::setw(13) << f32 << " "
                  << std::setw(21) << f64
                  << (f32 == f64 ? "" : "  <- uint32_t sardı") << "\n";
    }
    std::cout << "13! mod 2^32 = " << f64 << " - "
              << (std::uint64_t{1} << 32) << " = " << f32 << "\n";
    for (std::uint64_t n = 14; n <= 21; n++) {
        f64 *= n;            // 2^64 modunda: 21!'de sarar
        if (n == 20) {
            std::cout << "20! (uint64_t) = " << f64 << "\n";
        }
    }
    std::cout << "21! (uint64_t) = " << f64 << "  <- uint64_t de sardı\n";
    return 0;
}

/* Kütüphane karşılığı: C — standart faktöriyel yok; tgamma(n + 1.0)
 * (<math.h>) double verir (yaklaşık); C++ — std::tgamma; Python —
 * math.factorial(n) (tam değer). */

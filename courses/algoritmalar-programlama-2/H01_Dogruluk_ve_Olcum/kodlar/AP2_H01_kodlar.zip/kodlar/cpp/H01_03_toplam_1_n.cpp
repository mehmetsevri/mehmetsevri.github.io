/* H01_03_toplam_1_n.cpp — AP-2 Hafta 1 · Örnek 3 (★)
 * Amaç    : 1 + 2 + ... + n: döngü ve formül; döngü değişmeziyle
 *           doğruluk (başlatma–koruma–sonlanma)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_03_toplam_1_n.cpp -o H01_03_toplam_1_n
 * Çalıştır: ./H01_03_toplam_1_n
 * Eşleri  : c/H01_03_toplam_1_n.c · python/H01_03_toplam_1_n.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <vector>

// toplam_dongu: 1 + 2 + ... + n (ön koşul: n >= 0).
// Değişmez (döngü başında): s = 1 + 2 + ... + (k-1) = (k-1)k/2
// Başlatma : k = 1, s = 0 = 0·1/2.
// Koruma   : s += k sonrası s = k(k+1)/2; k++ ile yine (k-1)k/2.
// Sonlanma : döngü k = n+1'de biter → s = n(n+1)/2.
long long toplam_dongu(int n)
{
    long long s = 0;
    for (int k = 1; k <= n; k++) {
        s += k;
    }
    return s;
}

// toplam_formul: Gauss formülü n(n+1)/2. Çarpım long long'da
// yapılır: n = 65536 için n(n+1) = 4295032832, 32 bitlik int'e
// sığmaz (işaretli taşma tanımsız davranış olurdu).
long long toplam_formul(int n)
{
    return static_cast<long long>(n) * (n + 1) / 2;
}

// izle: döngü başındaki değişmezi her adımda yazdırır.
void izle(int n)
{
    long long s = 0;
    int k = 1;
    std::cout << "n = " << n
              << " için değişmez s = (k-1)k/2 (döngü başında):\n";
    while (k <= n) {
        std::cout << "  k = " << k << ": s = " << std::setw(2) << s
                  << ", (k-1)k/2 = " << std::setw(2)
                  << static_cast<long long>(k - 1) * k / 2 << "\n";
        s += k;
        k++;
    }
    std::cout << "  k = " << k << ": s = " << std::setw(2) << s
              << ", (k-1)k/2 = " << std::setw(2)
              << static_cast<long long>(k - 1) * k / 2
              << "  <- k = n+1, döngü biter\n";
}

int main()
{
    const std::vector<int> n_deger = {0, 1, 10, 100, 65536, 1000000};

    izle(5);
    // std::setw bayt sayar; ö, ü gibi harfler UTF-8'de 2 bayt olduğundan
    // Türkçe başlık sabit metin olarak yazılır (üç dilde aynı çıktı).
    std::cout << "\n       n            döngü           formül  eşit\n";
    for (int n : n_deger) {
        long long d = toplam_dongu(n);
        long long f = toplam_formul(n);
        std::cout << std::setw(8) << n << " " << std::setw(16) << d << " "
                  << std::setw(16) << f << "  " << (d == f ? "evet" : "HAYIR")
                  << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::accumulate (<numeric>) ya da
 * std::iota + std::accumulate; Python — sum(range(1, n + 1)). */

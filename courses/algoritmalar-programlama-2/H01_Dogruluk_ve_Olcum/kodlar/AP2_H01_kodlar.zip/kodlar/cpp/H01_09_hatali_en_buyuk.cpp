/* H01_09_hatali_en_buyuk.cpp — AP-2 Hafta 1 · Örnek 9 (★★)
 * Amaç    : m = 0 ile başlatılmış hatalı en_buyuk'u sınır değer ve
 *           rastgele testle yakalamak. BU DOSYA KASITLI HATA İÇERİR.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_09_hatali_en_buyuk.cpp -o H01_09_hatali_en_buyuk
 * Çalıştır: ./H01_09_hatali_en_buyuk
 * Eşleri  : c/H01_09_hatali_en_buyuk.c · python/H01_09_hatali_en_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const int MAKS_N = 8;

// en_buyuk: doğru sürüm (Örnek 1); burada kâhin olarak kullanılır.
int en_buyuk(const std::vector<int>& a)
{
    const std::size_t n = a.size();
    int m = a[0];
    for (std::size_t i = 1; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

// en_buyuk_hatali: KASITLI HATA — m = 0 ile başlatılmış.
// Dizide en az bir eleman >= 0 ise doğru sonuç verir; tamamı negatifse
// 0 döndürür (0 dizide yok bile: son koşul bozulur).
int en_buyuk_hatali(const std::vector<int>& a)
{
    int m = 0;                     // HATA: m = a[0] olmalıydı
    for (std::size_t i = 0; i < a.size(); i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

// a vektörünü "[x, y, ...]" biçiminde yazdırır (satır sonu yok).
void dizi_yaz(const std::vector<int>& a)
{
    std::cout << "[";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << a[i];
    }
    std::cout << "]";
}

// test_et: tek girdide hatalı sürümü kâhinle karşılaştırır.
void test_et(const std::vector<int>& a, const std::string& aciklama)
{
    int beklenen = en_buyuk(a);
    int bulunan = en_buyuk_hatali(a);
    std::cout << "  ";
    dizi_yaz(a);
    std::cout << ": beklenen " << beklenen << ", bulunan " << bulunan
              << " -> " << (beklenen == bulunan ? "geçti" : "YAKALANDI")
              << " (" << aciklama << ")\n";
}

// rastgele_test: deneme kez n = 1..MAKS_N elemanlı, değerleri
// [alt, ust] aralığında rastgele dizi üretir ve iki sürümü
// karşılaştırır; ilk karşı örneği yazdırır.
void rastgele_test(int deneme, int alt, int ust)
{
    int uyusmazlik = 0;
    rastgele_tohum(42);
    for (int t = 1; t <= deneme; t++) {
        auto n = static_cast<std::size_t>(rastgele_aralik(1, MAKS_N));
        std::vector<int> a = rastgele_dizi(n, alt, ust);
        int beklenen = en_buyuk(a);
        int bulunan = en_buyuk_hatali(a);
        if (beklenen != bulunan) {
            uyusmazlik++;
            if (uyusmazlik == 1) {
                std::cout << "  ilk karşı örnek (deneme " << t << "): ";
                dizi_yaz(a);
                std::cout << " -> beklenen " << beklenen << ", bulunan "
                          << bulunan << "\n";
            }
        }
    }
    std::cout << "  değerler [" << alt << ", " << ust << "]: " << deneme
              << " denemede " << uyusmazlik << " uyuşmazlık"
              << (uyusmazlik == 0 ? " (hata görünmedi!)" : "") << "\n";
}

int main()
{
    std::cout << "1) Örnek test (tipik girdi):\n";
    test_et({3, 9, 4}, "tipik");
    std::cout << "2) Sınır değer testleri:\n";
    test_et({5}, "tek eleman");
    test_et({-5}, "tek negatif eleman");
    test_et({-8, -3, -12}, "tamamı negatif");
    test_et({9, 1, 2}, "en büyük başta");
    test_et({0, -1}, "en büyük 0");
    std::cout << "3) Rastgele test (ortak LCG, tohum 42, n = 1.." << MAKS_N
              << "):\n";
    rastgele_test(1000, -100, 100);
    rastgele_test(1000, 0, 100);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
 * a.begin(), a.end()); Python — max(a). */

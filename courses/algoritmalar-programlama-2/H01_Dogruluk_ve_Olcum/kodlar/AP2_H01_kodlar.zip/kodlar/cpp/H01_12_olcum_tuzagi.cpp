/* H01_12_olcum_tuzagi.cpp — AP-2 Hafta 1 · Örnek 12 (★★★)
 * Amaç    : Ölçüm tuzağı: sonucu kullanılmayan döngüyü -O2 tamamen
 *           siler; çözüm: sonucu kullan/yazdır. -O0 ile de deneyin.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_12_olcum_tuzagi.cpp \
 *           -o H01_12_olcum_tuzagi
 * Çalıştır: ./H01_12_olcum_tuzagi [n]      (varsayılan n = 1000000)
 * Eşleri  : c/H01_12_olcum_tuzagi.c · python/H01_12_olcum_tuzagi.py
 * Çıktı   : üç dilde aynı (=) — asıl fark süredir (stderr)
 */
#include <cstddef>
#include <cstdio>
#include <exception>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

long long sonuc_yeri = 0;   // kullanilan_dongu sonucu buraya yazar

// kullanilmayan_dongu: toplamı hesaplar ama sonucu hiçbir yere
// yazmaz. Gözlemlenebilir bir etkisi olmadığından derleyici -O2'de
// döngünün tamamını silebilir ("as-if" kuralı, C++17 [intro.execution]).
void kullanilmayan_dongu(const std::vector<int>& a)
{
    long long s = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        s += a[i];
    }
    static_cast<void>(s);   // yalnızca derleyici uyarısını susturur
}

// kullanilan_dongu: aynı döngü; sonuç dış değişkene yazılır ve
// main'de yazdırılır: derleyici döngüyü silemez.
void kullanilan_dongu(const std::vector<int>& a)
{
    long long s = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        s += a[i];
    }
    sonuc_yeri = s;         // ÇÖZÜM: sonucu kullan
}

int main(int argc, char* argv[])
{
    long n = 1000000;
    if (argc > 2) {
        std::cerr << "Kullanım: " << argv[0]
                  << " [n]   (1 <= n <= 100000000)\n";
        return 2;
    }
    if (argc == 2) {
        try {
            std::size_t son = 0;
            n = std::stol(argv[1], &son);
            if (son != std::string(argv[1]).size()) {
                n = 0;    // sayıdan sonra artık karakter var
            }
        } catch (const std::exception&) {   // invalid_argument, out_of_range
            n = 0;
        }
        if (n < 1 || n > 100000000) {
            std::cerr << "Kullanım: " << argv[0]
                      << " [n]   (1 <= n <= 100000000)\n";
            return 2;
        }
    }
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(static_cast<std::size_t>(n), 0, 99);

    double t_bos = olc_ortanca([&] { kullanilmayan_dongu(a); }, 5);
    double t_dolu = olc_ortanca([&] { kullanilan_dongu(a); }, 5);

    std::cout << "n = " << n << ", tohum = 42, değerler 0..99\n";
    std::cout << "Sonucu kullanılan döngü   : toplam = " << sonuc_yeri << "\n";
    std::cout << "Sonucu kullanılmayan döngü: sonuç hiçbir yere yazılmadı\n";
    std::cout << "Süreler stderr'de: -O0 ve -O2 ile derleyip karşılaştırın.\n";
    const double nd = static_cast<double>(n);
    std::fprintf(stderr, "kullanılmayan: %12.6f ms (eleman başına %9.4f ns)\n",
                 t_bos * 1e3, t_bos * 1e9 / nd);
    std::fprintf(stderr, "kullanılan   : %12.6f ms (eleman başına %9.4f ns)\n",
                 t_dolu * 1e3, t_dolu * 1e9 / nd);
    // Geçerlilik denetimi: 2,8 GHz'de bir saat çevrimi ≈ 0,36 ns. Eleman
    // başına 0,05 ns'den kısa süre, döngünün çalışmadığını gösterir.
    if (t_bos * 1e9 / nd < 0.05) {
        std::fprintf(stderr, "UYARI: kullanılmayan döngü eleman başına 0,05"
                             " ns'den kısa sürdü: döngü büyük olasılıkla"
                             " SİLİNDİ.\n");
    }
    return 0;
}

/* Kütüphane karşılığı: ölçümde derleyicinin işi silmesini önlemek için
 * C/C++'ta sonucu volatile bir değişkene yazmak ya da Google Benchmark'ın
 * benchmark::DoNotOptimize'ı; Python'da gerekmez (CPython döngüyü silmez),
 * ölçüm için timeit modülü. */

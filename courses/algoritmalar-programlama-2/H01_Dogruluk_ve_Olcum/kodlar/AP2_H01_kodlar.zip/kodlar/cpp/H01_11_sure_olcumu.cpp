/* H01_11_sure_olcumu.cpp — AP-2 Hafta 1 · Örnek 11 (★★)
 * Amaç    : Süre ölçümü: std::chrono::steady_clock (monotonik saat),
 *           std::clock (işlemci zamanı) ve zamanlayici modülü
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_11_sure_olcumu.cpp \
 *           -o H01_11_sure_olcumu
 * Çalıştır: ./H01_11_sure_olcumu [n]      (varsayılan n = 1000000)
 * Eşleri  : c/H01_11_sure_olcumu.c · python/H01_11_sure_olcumu.py
 * Çıktı   : üç dilde aynı (=) — süreler stderr'e yazılır
 */
#include <chrono>
#include <cstddef>
#include <cstdio>
#include <ctime>
#include <exception>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

// toplam: a'nın elemanlarının toplamı (Θ(n)).
long long toplam(const std::vector<int>& a)
{
    long long s = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        s += a[i];
    }
    return s;
}

int main(int argc, char* argv[])
{
    long n = 1000000;
    if (argc > 2) {
        std::cerr << "Kullanım: " << argv[0]
                  << " [n]   (1 <= n <= 100000000)\n";
        return 2;
    }
    if (argc == 2) {
        try {
            std::size_t son = 0;
            n = std::stol(argv[1], &son);
            if (son != std::string(argv[1]).size()) {
                n = 0;    // sayıdan sonra artık karakter var
            }
        } catch (const std::exception&) {   // invalid_argument, out_of_range
            n = 0;
        }
        if (n < 1 || n > 100000000) {
            std::cerr << "Kullanım: " << argv[0]
                      << " [n]   (1 <= n <= 100000000)\n";
            return 2;
        }
    }
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(static_cast<std::size_t>(n), 0, 99);

    // 1) Monotonik saat: std::chrono::steady_clock (geri gitmez)
    auto t0 = std::chrono::steady_clock::now();
    long long s1 = toplam(a);
    auto t1 = std::chrono::steady_clock::now();
    double duvar = std::chrono::duration<double>(t1 - t0).count();

    // 2) İşlemci zamanı: std::clock() — süreç yalnızca CPU'da çalışırken
    std::clock_t c0 = std::clock();
    long long s2 = toplam(a);
    std::clock_t c1 = std::clock();
    double islemci = static_cast<double>(c1 - c0) / CLOCKS_PER_SEC;

    // 3) zamanlayici modülü: 1 ısınma + 5 tekrar, ortanca. Sonuç
    // dışarıdaki s3'e yazılır: kullanılmayan hesabı -O2 silebilir.
    long long s3 = 0;
    double orta = olc_ortanca([&] { s3 = toplam(a); }, 5);

    std::cout << "n = " << n << ", tohum = 42, değerler 0..99\n";
    std::cout << "toplam = " << s1 << "\n";
    std::cout << "Üç ölçümde de aynı sonuç: "
              << ((s1 == s2 && s2 == s3) ? "evet" : "HAYIR") << "\n";
    std::cout << "Süreler stderr'de (her çalıştırmada biraz farklıdır).\n";
    std::fprintf(stderr, "steady_clock (monotonik saat)   : %10.3f ms\n",
                 duvar * 1e3);
    std::fprintf(stderr, "std::clock (işlemci zamanı)     : %10.3f ms\n",
                 islemci * 1e3);
    std::fprintf(stderr, "olc_ortanca (1 ısınma + 5, ort.): %10.3f ms\n",
                 orta * 1e3);
    return 0;
}

/* Kütüphane karşılığı: C — timespec_get (C11), clock (C89), POSIX
 * clock_gettime(CLOCK_MONOTONIC); C++ — std::chrono::steady_clock;
 * Python — time.perf_counter, time.process_time, timeit modülü. */

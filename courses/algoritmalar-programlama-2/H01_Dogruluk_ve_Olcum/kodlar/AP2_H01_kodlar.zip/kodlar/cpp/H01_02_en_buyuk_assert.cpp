/* H01_02_en_buyuk_assert.cpp — AP-2 Hafta 1 · Örnek 2 (★)
 * Amaç    : Döngü değişmezi m = max(a[0..i-1]) her adımda assert ile
 *           denetlenir (başlatma, koruma, sonlanma)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_02_en_buyuk_assert.cpp -o H01_02_en_buyuk_assert
 * Çalıştır: ./H01_02_en_buyuk_assert   (-DNDEBUG: denetimler kapanır)
 * Eşleri  : c/H01_02_en_buyuk_assert.c · python/H01_02_en_buyuk_assert.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cassert>
#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

// Yalnızca gösterim için: degismez() kaç kez çağrıldı? -DNDEBUG ile
// derlenince assert(...) içindeki ifade HİÇ değerlendirilmez ve bu
// sayaç 0 kalır. Programın asıl işi assert içine konmamalıdır.
static long denetim_sayisi = 0;

// degismez: m, a[0..i-1] bölümünün en büyüğü mü? (Θ(i) denetim)
// m bu bölümde geçmeli ve bölümdeki hiçbir eleman m'den büyük
// olmamalıdır.
bool degismez(const std::vector<int>& a, std::size_t i, int m)
{
    bool gecti_mi = false;
    denetim_sayisi++;
    for (std::size_t k = 0; k < i; k++) {
        if (a[k] > m) {
            return false;
        }
        if (a[k] == m) {
            gecti_mi = true;
        }
    }
    return gecti_mi;
}

// Ön koşul: a.size() >= 1. Son koşul: m = max(a[0..n-1]).
int en_buyuk(const std::vector<int>& a)
{
    const std::size_t n = a.size();
    assert(n >= 1);                    // ön koşul
    int m = a[0];
    std::size_t i = 1;
    assert(degismez(a, i, m));         // başlatma
    while (i < n) {
        if (a[i] > m) {
            m = a[i];
        }
        i++;
        assert(degismez(a, i, m));     // koruma
    }
    assert(i == n);                    // sonlanma: i == n
    return m;  // değişmez + (i == n)  =>  m = max(a[0..n-1])
}

// "ad = [x, y, ...] -> en büyük: m" biçiminde yazdırır.
void sonuc_yaz(const std::string& ad, const std::vector<int>& a)
{
    std::cout << ad << " = [";
    for (std::size_t i = 0; i < a.size(); i++) {
        if (i > 0) {
            std::cout << ", ";
        }
        std::cout << a[i];
    }
    std::cout << "] -> en büyük: " << en_buyuk(a) << "\n";
}

int main()
{
    const std::vector<int> a = {3, -1, 7, 2, 7, 5};
    const std::vector<int> b = {-8, -3, -12};
    const std::vector<int> c = {42};

    sonuc_yaz("a", a);
    sonuc_yaz("b", b);
    sonuc_yaz("c", c);
    std::cout << "Değişmez assert ile " << denetim_sayisi << " kez denetlendi";
    std::cout << " (başarısız olsaydı program dururdu).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
 * a.begin(), a.end()); Python — max(a). assert: C <assert.h>,
 * C++ <cassert>, Python assert deyimi (python3 -O ile kapanır). */

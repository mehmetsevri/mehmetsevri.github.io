/* H01_10_ikinci_en_buyuk.cpp — AP-2 Hafta 1 · Örnek 10 (★★★)
 * Amaç    : Tek geçişli ikinci en büyük; sıralama tabanlı kâhinle
 *           rastgele karşılaştırmalı test ve stres testi.
 *           ikinci_en_buyuk_hatali KASITLI HATA İÇERİR (testi sınamak için).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_10_ikinci_en_buyuk.cpp \
 *           -o H01_10_ikinci_en_buyuk
 * Çalıştır: ./H01_10_ikinci_en_buyuk
 * Eşleri  : c/H01_10_ikinci_en_buyuk.c · python/H01_10_ikinci_en_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const int MAKS_N = 12;

// ikinci_en_buyuk: tek geçişte ikinci en büyük eleman.
// Ön koşul : a.size() >= 2.
// Son koşul: dizi azalan sıralansaydı 1. konumda (0'dan) duracak değer.
//            Eşitlik: en büyük birden çok kez geçiyorsa ikinci en büyük
//            de odur ([7, 3, 7] -> 7).
// Değişmez : döngü başında b1 >= b2 ve b1, b2 a[0..i-1]'in en büyük
//            iki elemanıdır (yinelenenler ayrı sayılır).
int ikinci_en_buyuk(const std::vector<int>& a)
{
    int b1 = a[0], b2 = a[1];
    if (b2 > b1) {
        std::swap(b1, b2);
    }
    for (std::size_t i = 2; i < a.size(); i++) {
        if (a[i] > b1) {
            b2 = b1;
            b1 = a[i];
        } else if (a[i] > b2) {
            b2 = a[i];
        }
    }
    return b2;
}

// ikinci_en_buyuk_hatali: KASITLI HATA — "else if" dalı unutulmuş:
// b2 < a[i] <= b1 olan eleman b2'yi güncellemez. Test düzeneğinin
// hatayı yakalayabildiğini sınamak için kullanılır.
int ikinci_en_buyuk_hatali(const std::vector<int>& a)
{
    int b1 = a[0], b2 = a[1];
    if (b2 > b1) {
        std::swap(b1, b2);
    }
    for (std::size_t i = 2; i < a.size(); i++) {
        if (a[i] > b1) {
            b2 = b1;
            b1 = a[i];
        }                          // HATA: else if (a[i] > b2) eksik
    }
    return b2;
}

// kahin: yavaş ama apaçık doğru — kopyayı sırala, sondan ikinciyi al.
// Θ(n log n); std::sort yalnızca kâhinde serbesttir.
int kahin(std::vector<int> kopya)   // değerle: kopya alınır
{
    std::sort(kopya.begin(), kopya.end());
    return kopya[kopya.size() - 2];
}

// a vektörünü "[x, y, ...]" biçiminde yazdırır (satır sonu yok).
void dizi_yaz(const std::vector<int>& a)
{
    std::cout << "[";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << a[i];
    }
    std::cout << "]";
}

// karsilastirmali_test: f'yi kâhine karşı deneme kez sınar
// (n = 2..MAKS_N, değerler [alt, ust], tohum 2027). İlk uyuşmazlığı
// yazdırır; uyuşmazlık sayısını döndürür.
int karsilastirmali_test(int (*f)(const std::vector<int>&),
                         const std::string& ad, int deneme, int alt,
                         int ust)
{
    int uyusmazlik = 0;
    rastgele_tohum(2027);
    for (int t = 1; t <= deneme; t++) {
        auto n = static_cast<std::size_t>(rastgele_aralik(2, MAKS_N));
        std::vector<int> a = rastgele_dizi(n, alt, ust);
        int beklenen = kahin(a);
        int bulunan = f(a);
        if (beklenen != bulunan) {
            uyusmazlik++;
            if (uyusmazlik == 1) {
                std::cout << "  ilk uyuşmazlık (deneme " << t << "): ";
                dizi_yaz(a);
                std::cout << " -> kâhin " << beklenen << ", bulunan "
                          << bulunan << "\n";
            }
        }
    }
    std::cout << "  " << ad << ", değerler [" << alt << ", " << ust
              << "]: " << deneme << " deneme, " << uyusmazlik
              << " uyuşmazlık\n";
    return uyusmazlik;
}

int main()
{
    const std::vector<std::vector<int>> sinir = {
        {5, 9}, {9, 5}, {7, 7}, {7, 3, 7}, {1, 2, 3, 4}, {4, 3, 2, 1},
        {-5, -5, -9}
    };

    std::cout << "1) Sınır durumları (n = 2, eşitlik, en büyük başta/sonda):\n";
    for (const auto& s : sinir) {
        std::cout << "  ";
        dizi_yaz(s);
        std::cout << " -> " << ikinci_en_buyuk(s) << " (kâhin " << kahin(s)
                  << ")\n";
    }

    std::cout << "2) Kâhinle rastgele karşılaştırmalı test (tohum 2027):\n";
    karsilastirmali_test(ikinci_en_buyuk, "ikinci_en_buyuk", 2000, -5, 5);
    karsilastirmali_test(ikinci_en_buyuk, "ikinci_en_buyuk", 2000,
                         -1000, 1000);

    std::cout << "3) Testi sına: kasıtlı hatalı sürüm aynı testte\n";
    karsilastirmali_test(ikinci_en_buyuk_hatali, "ikinci_en_buyuk_hatali",
                         2000, -5, 5);

    std::cout << "4) Stres testi: n = 100000, değerler [-10^6, 10^6], "
                 "tohum 7\n";
    rastgele_tohum(7);
    std::vector<int> b = rastgele_dizi(100000, -1000000, 1000000);
    int hizli = ikinci_en_buyuk(b);
    int yavas = kahin(b);
    std::cout << "  hızlı " << hizli << ", kâhin " << yavas << " -> "
              << (hizli == yavas ? "eşleşti" : "UYUŞMAZLIK") << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (kâhin: qsort); C++ — std::nth_element ya
 * da std::partial_sort (kâhin: std::sort); Python — heapq.nlargest(2, a)
 * [1] ya da sorted(a)[-2] (kâhin). */

/* H01_08_ortak_lcg.cpp — AP-2 Hafta 1 · Örnek 8 (★★)
 * Amaç    : Ortak LCG modülüyle üç dilde BİREBİR aynı "rastgele" dizi;
 *           aynı tohum → aynı dizi (tekrarlanabilir deney)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_08_ortak_lcg.cpp -o H01_08_ortak_lcg
 * Çalıştır: ./H01_08_ortak_lcg
 * Eşleri  : c/H01_08_ortak_lcg.c · python/H01_08_ortak_lcg.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

// a vektörünü "[x, y, ...]" biçiminde yazdırır.
void dizi_yaz(const std::vector<int>& a)
{
    std::cout << "[";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << a[i];
    }
    std::cout << "]\n";
}

int main()
{
    // 1) Formülü elle uygula: durum = durum * A + C (mod 2^64)
    std::uint64_t durum = 42;
    durum = durum * UINT64_C(6364136223846793005)
            + UINT64_C(1442695040888963407);  // uint64_t: 2^64 modunda
    std::cout << "Elle   : durum = " << durum << "\n";
    std::cout << "         çıktı = durum >> 33 = " << (durum >> 33) << "\n";

    // 2) Aynı hesabı modül yapar
    rastgele_tohum(42);
    std::cout << "Modül  : rastgele_sayi() x 4 =";
    for (int i = 0; i < 4; i++) {
        std::cout << " " << rastgele_sayi();
    }
    std::cout << "\n";

    std::vector<int> zar(10);
    for (int i = 0; i < 10; i++) {
        zar[i] = rastgele_aralik(1, 6);
    }
    std::cout << "rastgele_aralik(1, 6) x 10  = ";
    dizi_yaz(zar);

    std::cout << "rastgele_kesir() x 3        =";
    for (int i = 0; i < 3; i++) {
        std::printf(" %.6f", rastgele_kesir());
    }
    std::cout << "\n";

    std::vector<int> a = rastgele_dizi(8, -50, 50);
    std::cout << "rastgele_dizi(8, -50, 50)   = ";
    dizi_yaz(a);

    std::vector<int> p(10);
    for (int i = 0; i < 10; i++) {
        p[i] = i + 1;
    }
    rastgele_karistir(p);
    std::cout << "rastgele_karistir(1..10)    = ";
    dizi_yaz(p);

    // 3) Aynı tohum → aynı dizi
    rastgele_tohum(42);
    std::uint32_t ilk = rastgele_sayi();
    std::cout << "Yeniden tohum 42, ilk sayı  = " << ilk
              << " (aynı dizi baştan)\n";
    return 0;
}

/* Kütüphane karşılığı: C — rand()/srand() (dizi platforma göre değişir);
 * C++ — std::mt19937 + std::uniform_int_distribution (dağılım sınıfının
 * çıktısı gerçekleştirime göre değişebilir); Python — random.seed,
 * random.randint (Mersenne Twister). Ders örneklerinde kullanılmaz. */

/* H01_01_en_buyuk.cpp — AP-2 Hafta 1 · Örnek 1 (★)
 * Amaç    : Dizinin en büyük elemanı; ön koşul–son koşul sözleşmesi
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_01_en_buyuk.cpp -o H01_01_en_buyuk
 * Çalıştır: ./H01_01_en_buyuk
 * Eşleri  : c/H01_01_en_buyuk.c · python/H01_01_en_buyuk.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

// en_buyuk: a vektörünün en büyük elemanını döndürür.
// Ön koşul : a.size() >= 1 (vektör boş değil).
// Son koşul: dönen m vektörün bir elemanıdır ve her k için
//            (0 <= k < a.size()) a[k] <= m sağlanır.
// Ön koşul ihlali (boş vektör) çağıranın hatasıdır: a[0] sınır
// denetimi yapmaz, davranış tanımsızdır (a.at(0) olsaydı
// std::out_of_range istisnası atılırdı).
int en_buyuk(const std::vector<int>& a)
{
    const std::size_t n = a.size();
    int m = a[0];
    for (std::size_t i = 1; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

// "ad = [x, y, ...] -> en büyük: m" biçiminde yazdırır.
void sonuc_yaz(const std::string& ad, const std::vector<int>& a)
{
    std::cout << ad << " = [";
    for (std::size_t i = 0; i < a.size(); i++) {
        if (i > 0) {
            std::cout << ", ";
        }
        std::cout << a[i];
    }
    std::cout << "] -> en büyük: " << en_buyuk(a) << "\n";
}

int main()
{
    const std::vector<int> a = {3, -1, 7, 2, 7, 5};
    const std::vector<int> b = {-8, -3, -12};
    const std::vector<int> c = {42};

    sonuc_yaz("a", a);
    sonuc_yaz("b", b);
    sonuc_yaz("c", c);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
 * a.begin(), a.end()); Python — max(a). */

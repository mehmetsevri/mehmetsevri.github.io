/* H01_05_oklid_ebob.cpp — AP-2 Hafta 1 · Örnek 5 (★★)
 * Amaç    : Öklid algoritmasıyla EBOB; sonlanma kanıtı: b her adımda
 *           kesin azalır ve 0'ın altına inemez
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_05_oklid_ebob.cpp -o H01_05_oklid_ebob
 * Çalıştır: ./H01_05_oklid_ebob
 * Eşleri  : c/H01_05_oklid_ebob.c · python/H01_05_oklid_ebob.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

static int adim_sayisi = 0;   // döngü adımı (mod işlemi) sayacı

// ebob: a ve b'nin en büyük ortak böleni (Öklid algoritması).
// Ön koşul : a >= 0, b >= 0 ve ikisi birden 0 değil.
// Son koşul: dönen d hem a'yı hem b'yi böler ve ortak bölenlerin
//            en büyüğüdür.
// Değişmez : ebob(a, b) döngü boyunca aynı kalır, çünkü
//            ebob(a, b) = ebob(b, a mod b).
// Sonlanma : b >= 0 ve her adımda kesin azalır (0 <= a % b < b);
//            negatif olmayan tamsayılar sonsuza dek azalamaz.
int ebob(int a, int b)
{
    adim_sayisi = 0;
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
        adim_sayisi++;
    }
    return a;
}

// ebob_izle: her adımda a, b ve a % b değerlerini yazdırır.
void ebob_izle(int a, int b)
{
    std::cout << "ebob(" << a << ", " << b
              << ") izlemesi (b her adımda kesin azalır):\n";
    while (b != 0) {
        std::cout << "  a = " << std::setw(4) << a << "   b = "
                  << std::setw(4) << b << "   a % b = " << std::setw(4)
                  << a % b << "\n";
        int r = a % b;
        a = b;
        b = r;
    }
    std::cout << "  a = " << std::setw(4) << a << "   b = " << std::setw(4)
              << b << "   -> b = 0, sonuç: " << a << "\n";
}

int main()
{
    // Son iki çift ardışık Fibonacci sayılarıdır (F11, F10) ve
    // (F30, F29): Öklid'in en kötü durumu.
    const std::vector<std::pair<int, int>> ciftler = {
        {252, 105}, {1071, 462}, {55, 89}, {17, 0}, {0, 9},
        {1000000, 999999}, {89, 55}, {832040, 514229}
    };

    ebob_izle(252, 105);
    std::cout << "\n        a         b     ebob  adım\n";
    for (const auto& [a, b] : ciftler) {
        int d = ebob(a, b);
        std::cout << std::setw(9) << a << " " << std::setw(9) << b << " "
                  << std::setw(8) << d << " " << std::setw(5) << adim_sayisi
                  << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::gcd (<numeric>, C++17);
 * Python — math.gcd(a, b). */

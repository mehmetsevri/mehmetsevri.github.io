/* H01_04_dogrusal_arama.cpp — AP-2 Hafta 1 · Örnek 4 (★★)
 * Amaç    : Doğrusal arama; "bulunamadı" sözleşmesi (-1), döngü
 *           değişmezi, sonlanma ve iki çıkış noktası
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_04_dogrusal_arama.cpp -o H01_04_dogrusal_arama
 * Çalıştır: ./H01_04_dogrusal_arama
 * Eşleri  : c/H01_04_dogrusal_arama.c · python/H01_04_dogrusal_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iostream>
#include <vector>

static long karsilastirma = 0;   // a[i] == x karşılaştırma sayacı

// dogrusal_ara: x'in a içindeki İLK konumunu döndürür;
// x yoksa -1 döndürür ("bulunamadı" sözleşmesi).
// Ön koşul : yok (a boş olabilir).
// Son koşul: dönen i >= 0 ise a[i] == x ve x, a[0..i-1]'de yok;
//            -1 ise x, a'nın hiçbir yerinde yok.
// Değişmez : döngü başında x, a[0..i-1] içinde yok.
// Sonlanma : i her adımda 1 artar; en çok n adımda i == n olur.
int dogrusal_ara(const std::vector<int>& a,
                 int x)
{
    const std::size_t n = a.size();
    for (std::size_t i = 0; i < n; i++) {
        karsilastirma++;
        if (a[i] == x) {    // 1. çıkış
            return static_cast<int>(i);
        }
    }
    return -1;              // 2. çıkış
}

// ara_yaz: aramayı yapar; sonucu ve karşılaştırma sayısını yazar.
void ara_yaz(const std::vector<int>& a, int x)
{
    karsilastirma = 0;
    int k = dogrusal_ara(a, x);
    if (k == -1) {
        std::cout << "ara(" << x << ") -> bulunamadı";
    } else {
        std::cout << "ara(" << x << ") -> " << k;
    }
    std::cout << ", karşılaştırma: " << karsilastirma << "\n";
}

int main()
{
    const std::vector<int> a = {7, 3, 9, 3, 5, 1, 8};

    std::cout << "a = [7, 3, 9, 3, 5, 1, 8] (n = " << a.size() << ")\n";
    ara_yaz(a, 7);   // en iyi durum: ilk eleman
    ara_yaz(a, 3);   // iki kez geçiyor: İLK konum
    ara_yaz(a, 8);   // son eleman
    ara_yaz(a, 6);   // yok: en kötü durum, n karşılaştırma
    std::cout << "boş dizi:\n";
    ara_yaz({}, 7);  // boş vektör: döngüye hiç girilmez
    return 0;
}

/* Kütüphane karşılığı: C — standart C'de yok (POSIX lfind);
 * C++ — std::find; Python — a.index(x) (yoksa ValueError), x in a. */

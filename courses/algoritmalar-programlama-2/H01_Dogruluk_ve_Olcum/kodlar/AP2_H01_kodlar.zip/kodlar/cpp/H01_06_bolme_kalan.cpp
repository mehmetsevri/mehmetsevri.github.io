/* H01_06_bolme_kalan.cpp — AP-2 Hafta 1 · Örnek 6 (★★)
 * Amaç    : -7 / 2 ve -7 % 2: C++'ta tamsayı bölmesi sıfıra doğru keser,
 *           kalan bölünenin işaretini alır (C++11'den beri tanımlı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_06_bolme_kalan.cpp -o H01_06_bolme_kalan
 * Çalıştır: ./H01_06_bolme_kalan
 * Eşleri  : c/H01_06_bolme_kalan.c · python/H01_06_bolme_kalan.py
 * Çıktı   : Δ — C ve C++ aynı, Python farklı; bkz. Dil Penceresi
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

int main()
{
    const std::vector<int> a_deger = {7, -7, 7, -7};
    const std::vector<int> b_deger = {2, 2, -2, -2};

    std::cout << "C++: / sıfıra doğru keser, % bölünenin işaretini alır\n";
    std::cout << "   a    b   a / b   a % b   (a / b) * b + a % b\n";
    for (std::size_t i = 0; i < a_deger.size(); i++) {
        int a = a_deger[i];
        int b = b_deger[i];
        int q = a / b;      // bölüm: sıfıra doğru kesme (C ile aynı)
        int r = a % b;      // kalan: işareti a'nınki    (C ile aynı)
        std::cout << std::setw(4) << a << " " << std::setw(4) << b << " "
                  << std::setw(7) << q << " " << std::setw(7) << r << " "
                  << std::setw(13) << q * b + r << "\n";
    }
    // Yaygın tuzak: x % 2 == 1 negatif tek sayılarda yanlıştır.
    std::cout << "-7 tek mi? (-7 % 2 == 1): "
              << ((-7 % 2 == 1) ? "evet" : "hayır") << "\n";
    std::cout << "-7 tek mi? (-7 % 2 != 0): "
              << ((-7 % 2 != 0) ? "evet" : "hayır") << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — div(a, b) (<stdlib.h>; bölüm ve kalanı
 * birlikte verir, aynı kural); C++ — std::div; Python — divmod(a, b)
 * (taban bölmesi kuralıyla). */

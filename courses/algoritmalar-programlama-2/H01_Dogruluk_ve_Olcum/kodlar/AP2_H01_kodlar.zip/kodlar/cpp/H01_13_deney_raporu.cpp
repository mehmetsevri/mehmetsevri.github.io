/* H01_13_deney_raporu.cpp — AP-2 Hafta 1 · Örnek 13 (★★★)
 * Amaç    : Deney raporu: dizi toplamı için n'e karşı süre tablosu;
 *           --csv ile süreler CSV dosyasına yazılır (grafik için)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_13_deney_raporu.cpp \
 *           -o H01_13_deney_raporu
 * Çalıştır: ./H01_13_deney_raporu [--nmax N] [--csv dosya.csv]
 * Eşleri  : c/H01_13_deney_raporu.c · python/H01_13_deney_raporu.py
 * Çıktı   : üç dilde aynı (=) — süreler stderr'e ve CSV'ye yazılır
 */
#include <cstddef>
#include <cstdio>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

const int TEKRAR = 5;

// __OPTIMIZE__ GCC/Clang'ın, optimizasyonlu derlemede tanımladığı
// makrodur: CSV'deki "derleme" sütununu kendiliğinden doldurur.
#ifdef __OPTIMIZE__
const char* const DERLEME = "O1+";
#else
const char* const DERLEME = "O0";
#endif

// toplam: a'nın elemanlarının toplamı (Θ(n)).
long long toplam(const std::vector<int>& a)
{
    long long s = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        s += a[i];
    }
    return s;
}

void kullanim(const char* ad)
{
    std::cerr << "Kullanım: " << ad << " [--nmax N] [--csv dosya.csv]\n"
              << "  N: 1000 .. 100000000 (varsayılan 100000)\n";
}

int main(int argc, char* argv[])
{
    long nmax = 100000;
    std::string csv_yolu;
    for (int i = 1; i < argc; i++) {
        const std::string arg = argv[i];
        if (arg == "--nmax" && i + 1 < argc) {
            const std::string metin = argv[++i];
            try {
                std::size_t son = 0;
                nmax = std::stol(metin, &son);
                if (son != metin.size()) {
                    nmax = 0;
                }
            } catch (const std::exception&) {
                nmax = 0;
            }
            if (nmax < 1000 || nmax > 100000000) {
                kullanim(argv[0]);
                return 2;
            }
        } else if (arg == "--csv" && i + 1 < argc) {
            csv_yolu = argv[++i];
        } else {
            kullanim(argv[0]);
            return 2;
        }
    }
    std::ofstream csv;
    if (!csv_yolu.empty()) {
        csv.open(csv_yolu);
        if (!csv) {
            std::cerr << "Hata: " << csv_yolu << " açılamadı\n";
            return 1;
        }
        csv << "n;dil;derleme;tekrar;ortanca_ms;toplam\n";
    }

    std::cout << "Deney: dizi toplamı (Θ(n)), tohum 42, değerler 0..99\n";
    std::cout << "Düzen: 1 ısınma + " << TEKRAR
              << " tekrar, ortanca (süreler stderr/CSV)\n";
    std::cout << std::setw(10) << "n" << " " << std::setw(14) << "toplam"
              << " " << std::setw(10) << "ortalama" << "\n";
    double onceki = 0.0;
    for (long n = 1000; n <= nmax; n *= 10) {
        rastgele_tohum(42);
        std::vector<int> a =
            rastgele_dizi(static_cast<std::size_t>(n), 0, 99);
        long long sonuc = 0;     // sonucu sakla: -O2 döngüyü silemesin
        double t = olc_ortanca([&] { sonuc = toplam(a); }, TEKRAR);
        std::cout << std::setw(10) << n << " " << std::setw(14) << sonuc
                  << " " << std::fixed << std::setprecision(4)
                  << std::setw(10)
                  << static_cast<double>(sonuc) / static_cast<double>(n)
                  << "\n";
        std::fprintf(stderr, "n = %9ld: ortanca %10.4f ms", n, t * 1e3);
        if (onceki > 0.0) {
            std::fprintf(stderr, "   T(n)/T(n/10) = %.2f", t / onceki);
        }
        std::fprintf(stderr, "\n");
        if (csv) {
            csv << n << ";C++;" << DERLEME << ";" << TEKRAR << ";"
                << std::setprecision(6) << t * 1e3 << ";" << sonuc << "\n";
        }
        onceki = t;
    }
    if (csv.is_open()) {
        csv.close();
        std::cout << "CSV yazıldı: " << csv_yolu << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (CSV elle yazılır); C++ — yok (std::ofstream);
 * Python — csv modülü (csv.writer(f, delimiter=";")); grafik için ayrı
 * betik: gorseller/kaynak/ (matplotlib, örnek kodun parçası değil). */

/* H01_Q04_arama_sayac.c — AP-2 Hafta 1 · Quiz 4 (izleme)
 * Soru    : İki çağrıda karşılaştırma sayacı kaç olur?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_Q04_arama_sayac.c -o H01_Q04_arama_sayac
 */
#include <stddef.h>
#include <stdio.h>

static int karsilastirma = 0;

int dogrusal_ara(const int a[], size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {
        karsilastirma++;
        if (a[i] == x) {
            return (int)i;
        }
    }
    return -1;
}

int main(void)
{
    const int a[] = {4, 8, 15, 16, 23, 42};
    int k = dogrusal_ara(a, 6, 16);
    printf("16 -> %d, karşılaştırma: %d\n", k, karsilastirma);
    karsilastirma = 0;
    k = dogrusal_ara(a, 6, 5);
    printf(" 5 -> %d, karşılaştırma: %d\n", k, karsilastirma);
    return 0;
}

/* H01_Q03_isaretci.c — AP-2 Hafta 1 · Quiz 3 (geri çağırma: AP-1 H12)
 * Soru    : Program ne yazdırır?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_Q03_isaretci.c -o H01_Q03_isaretci
 */
#include <stdio.h>

void ekle(int *p, int k)
{
    *p += k;
}

int main(void)
{
    int x = 3;
    ekle(&x, 4);
    printf("%d\n", x);
    return 0;
}

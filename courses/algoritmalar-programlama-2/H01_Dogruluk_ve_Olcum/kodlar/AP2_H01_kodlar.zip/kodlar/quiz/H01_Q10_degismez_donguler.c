/* H01_Q10_degismez_donguler.c — AP-2 Hafta 1 · Quiz 10
 * Soru    : "Bu döngünün değişmezi hangisi?" Her fonksiyonda, döngünün
 *           her yinelemesinin BAŞINDA doğru olan ve sonlanmada son koşulu
 *           veren ifadeyi seçin (web oynatıcısı aday ifadeleri sınar).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_Q10_degismez_donguler.c -o H01_Q10_degismez_donguler
 * Çalıştır: ./H01_Q10_degismez_donguler
 */
#include <stddef.h>
#include <stdio.h>

/* 1) a[0..n-1] toplamı */
long long toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return s;
}

/* 2) b üzeri e (e >= 0) */
long long us_al(long long b, int e)
{
    long long p = 1;
    for (int k = 0; k < e; k++) {
        p *= b;
    }
    return p;
}

/* 3) a[0..n-1]'in en küçüğü (n >= 1) */
int en_kucuk(const int a[], size_t n)
{
    int m = a[0];
    for (size_t i = 1; i < n; i++) {
        if (a[i] < m) {
            m = a[i];
        }
    }
    return m;
}

/* 4) x, a[0..n-1] içinde kaç kez geçiyor? */
int say(const int a[], size_t n, int x)
{
    int c = 0;
    for (size_t i = 0; i < n; i++) {
        if (a[i] == x) {
            c++;
        }
    }
    return c;
}

/* 5) Öklid: ebob(a, b), a >= 0, b >= 0, ikisi birden 0 değil */
int ebob(int a, int b)
{
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

int main(void)
{
    const int a[] = {4, -2, 7, -2, 5};
    printf("toplam = %lld\n", toplam(a, 5));
    printf("us_al(3, 4) = %lld\n", us_al(3, 4));
    printf("en_kucuk = %d\n", en_kucuk(a, 5));
    printf("say(-2) = %d\n", say(a, 5, -2));
    printf("ebob(84, 36) = %d\n", ebob(84, 36));
    return 0;
}

/* H01_Q07_isaretsiz_sarma.c — AP-2 Hafta 1 · Quiz 7 (taşma)
 * Soru    : Program ne yazdırır?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_Q07_isaretsiz_sarma.c -o H01_Q07_isaretsiz_sarma
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    uint32_t x = UINT32_MAX;
    x = x + 1;
    printf("%" PRIu32 "\n", x);
    return 0;
}

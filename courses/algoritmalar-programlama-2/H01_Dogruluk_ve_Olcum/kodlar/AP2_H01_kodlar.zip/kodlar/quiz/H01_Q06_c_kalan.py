"""H01_Q06_c_kalan.py — AP-2 Hafta 1 · Quiz 6 (dil farkı, Python eşi)
Soru    : C'deki printf("%d\n", -7 % 3) satırının Python karşılığı
Çalıştır: python3 H01_Q06_c_kalan.py
"""

print(-7 % 3)

/* H01_Q06_c_kalan.c — AP-2 Hafta 1 · Quiz 6 (dil farkı)
 * Soru    : Program ne yazdırır? Aynı ifade Python'da ne verirdi?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_Q06_c_kalan.c -o H01_Q06_c_kalan
 */
#include <stdio.h>

int main(void)
{
    printf("%d\n", -7 % 3);
    return 0;
}

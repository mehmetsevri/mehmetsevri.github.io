/* H01_Q01_dizi_adim.c — AP-2 Hafta 1 · Quiz 1 (geri çağırma: AP-1 H10)
 * Soru    : Program ne yazdırır?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_Q01_dizi_adim.c -o H01_Q01_dizi_adim
 */
#include <stdio.h>

int main(void)
{
    int a[] = {3, 1, 4, 1, 5};
    int t = 0;
    for (int i = 0; i < 5; i += 2) {
        t += a[i];
    }
    printf("%d\n", t);
    return 0;
}

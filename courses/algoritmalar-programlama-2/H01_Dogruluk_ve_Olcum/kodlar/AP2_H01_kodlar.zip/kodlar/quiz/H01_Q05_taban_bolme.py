"""H01_Q05_taban_bolme.py — AP-2 Hafta 1 · Quiz 5 (dil farkı)
Soru    : Program ne yazdırır?
Çalıştır: python3 H01_Q05_taban_bolme.py
"""

print(7 // -2, 7 % -2)

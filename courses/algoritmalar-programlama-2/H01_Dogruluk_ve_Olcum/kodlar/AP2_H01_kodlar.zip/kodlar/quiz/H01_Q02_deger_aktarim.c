/* H01_Q02_deger_aktarim.c — AP-2 Hafta 1 · Quiz 2 (geri çağırma: AP-1 H8)
 * Soru    : Program ne yazdırır?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_Q02_deger_aktarim.c -o H01_Q02_deger_aktarim
 */
#include <stdio.h>

void arttir(int x)
{
    x = x + 1;
    printf("içeride x = %d\n", x);
}

int main(void)
{
    int x = 5;
    arttir(x);
    printf("main'de x = %d\n", x);
    return 0;
}

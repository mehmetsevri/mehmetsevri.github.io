/* H01_K06_bolme_tek_satir.cpp — AP-2 Hafta 1 · Kavram 6 (Dil Penceresi)
 * Amaç    : -7 / 2 ve -7 % 2 tek satırda (C++: sıfıra doğru kesme)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_K06_bolme_tek_satir.cpp -o H01_K06_bolme_tek_satir
 * Çalıştır: ./H01_K06_bolme_tek_satir
 * Eşleri  : H01_K06_bolme_tek_satir.c · H01_K06_bolme_tek_satir.py
 */
#include <iostream>

int main()
{
    std::cout << -7 / 2 << " " << -7 % 2 << "\n";
    return 0;
}

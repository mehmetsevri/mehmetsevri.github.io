/* H01_K04_double_cozunurluk.c — AP-2 Hafta 1 · Kavram 4 (Kaputun Altında)
 * Amaç    : Zamanı saniye cinsinden double'da tutmanın bedeli: değer
 *           büyüdükçe double'ın ayırt edebildiği en küçük adım büyür
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_K04_double_cozunurluk.c -o H01_K04_double_cozunurluk -lm
 * Çalıştır: ./H01_K04_double_cozunurluk
 * Eşi     : H01_K04_double_cozunurluk.py
 */
#include <math.h>
#include <stdio.h>

/* adim: x'ten büyük ilk double ile x arasındaki fark (x'teki ulp). */
double adim(double x)
{
    return nextafter(x, INFINITY) - x;
}

int main(void)
{
    /* 1 s ve 1000 s: "ilk çağrıdan beri" geçen süre; 1.76e9 s: 1970'ten
     * (Unix çağı) 2025-2026'ya kadar geçen saniye sayısı mertebesi.   */
    const double saniye[] = {1.0, 1000.0, 1.76e9};
    for (int i = 0; i < 3; i++) {
        double d = adim(saniye[i]);
        printf("t = %.3e s: en küçük adım %.3e s = %.6f ns\n",
               saniye[i], d, d * 1e9);
    }
    return 0;
}

"""H01_K04_double_cozunurluk.py — AP-2 Hafta 1 · Kavram 4 (Kaputun Altında)
Amaç    : Zamanı saniye cinsinden float'ta (C'deki double) tutmanın bedeli:
          değer büyüdükçe ayırt edilebilen en küçük adım büyür
Çalıştır: python3 H01_K04_double_cozunurluk.py
Eşi     : H01_K04_double_cozunurluk.c
"""

import math


def adim(x):
    """x'ten büyük ilk float ile x arasındaki fark (x'teki ulp)."""
    return math.nextafter(x, math.inf) - x


def main():
    # 1 s ve 1000 s: "ilk çağrıdan beri" geçen süre; 1.76e9 s: 1970'ten
    # (Unix çağı) 2025-2026'ya kadar geçen saniye sayısı mertebesi.
    for saniye in (1.0, 1000.0, 1.76e9):
        d = adim(saniye)
        print(f"t = {saniye:.3e} s: en küçük adım {d:.3e} s = "
              f"{d * 1e9:.6f} ns")


if __name__ == "__main__":
    main()

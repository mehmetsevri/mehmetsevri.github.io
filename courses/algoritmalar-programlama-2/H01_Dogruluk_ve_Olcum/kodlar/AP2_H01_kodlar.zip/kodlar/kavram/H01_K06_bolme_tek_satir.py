"""H01_K06_bolme_tek_satir.py — AP-2 Hafta 1 · Kavram 6 (Dil Penceresi)
Amaç    : -7 // 2 ve -7 % 2 tek satırda (Python: taban bölmesi)
Çalıştır: python3 H01_K06_bolme_tek_satir.py
Eşleri  : H01_K06_bolme_tek_satir.c · H01_K06_bolme_tek_satir.cpp
"""

print(-7 // 2, -7 % 2)

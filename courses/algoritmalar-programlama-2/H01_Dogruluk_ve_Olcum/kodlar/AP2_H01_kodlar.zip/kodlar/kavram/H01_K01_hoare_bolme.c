/* H01_K01_hoare_bolme.c — AP-2 Hafta 1 · Kavram 1
 * Amaç    : Hoare üçlüsü {P} S {Q}: Hoare'un (1969) ardışık çıkarmayla
 *           bölme örneği; ön koşul, değişmez ve son koşul assert ile
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_K01_hoare_bolme.c -o H01_K01_hoare_bolme
 * Çalıştır: ./H01_K01_hoare_bolme
 */
#include <assert.h>
#include <stdio.h>

/* bol: x'i y'ye ardışık çıkarmayla böler; bölümü *q'ya, kalanı *r'ye
 * yazar.  {P: x >= 0 ve y > 0}  S  {Q: x == r + y*q ve 0 <= r < y} */
void bol(int x, int y, int *q, int *r)
{
    assert(x >= 0 && y > 0);            /* P: ön koşul            */
    *r = x;
    *q = 0;
    while (y <= *r) {
        assert(x == *r + y * *q);       /* değişmez (döngü başı)  */
        *r = *r - y;
        *q = *q + 1;
    }
    assert(x == *r + y * *q && 0 <= *r && *r < y);   /* Q: son koşul */
}

int main(void)
{
    int q, r;
    bol(17, 5, &q, &r);
    printf("17 = 5 * %d + %d\n", q, r);
    bol(4, 9, &q, &r);
    printf(" 4 = 9 * %d + %d\n", q, r);
    /* bol(17, 0, ...) ön koşulu çiğner: y = 0 olsaydı r hiç azalmaz,
     * döngü sonlanmazdı. assert bunu döngüden ÖNCE yakalar. */
    return 0;
}

"""H01_K03_collatz.py — AP-2 Hafta 1 · Kavram 3 (Merak Kutusu)
Amaç    : Sonlanma kanıtı her zaman bulunamaz: Collatz döngüsü
          (n çiftse n/2, tekse 3n+1) denenen her n'de 1'e iner, ama
          her n için sonlandığı kanıtlanmış değildir
Çalıştır: python3 H01_K03_collatz.py
Eşi     : H01_K03_collatz.c
"""


def collatz_adim(n):
    """(adım sayısı, yol boyunca görülen en büyük değer); n >= 1."""
    adim = 0
    tepe = n
    while n != 1:
        n = n // 2 if n % 2 == 0 else 3 * n + 1
        if n > tepe:
            tepe = n
        adim += 1
    return adim, tepe


def main():
    print("     n   adım   en büyük değer")
    for n in (1, 6, 7, 27, 97):
        adim, tepe = collatz_adim(n)
        print(f"{n:6d} {adim:6d} {tepe:16d}")


if __name__ == "__main__":
    main()

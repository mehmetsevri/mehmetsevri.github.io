/* H01_K06_bolme_tek_satir.c — AP-2 Hafta 1 · Kavram 6 (Dil Penceresi)
 * Amaç    : -7 / 2 ve -7 % 2 tek satırda (C: sıfıra doğru kesme)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_K06_bolme_tek_satir.c -o H01_K06_bolme_tek_satir
 * Çalıştır: ./H01_K06_bolme_tek_satir
 * Eşleri  : H01_K06_bolme_tek_satir.cpp · H01_K06_bolme_tek_satir.py
 */
#include <stdio.h>

int main(void)
{
    printf("%d %d\n", -7 / 2, -7 % 2);
    return 0;
}

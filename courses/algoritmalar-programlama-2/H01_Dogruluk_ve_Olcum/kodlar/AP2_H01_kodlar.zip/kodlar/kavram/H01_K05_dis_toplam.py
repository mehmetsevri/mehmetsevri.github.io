"""H01_K05_dis_toplam.py — AP-2 Hafta 1 · Kavram 5 (Kaputun Altında)
Amaç    : CPython'un bir Python fonksiyonunu hangi bayt koduna çevirdiğini
          dis modülüyle görmek (çıktı Python sürümüne göre değişir)
Çalıştır: python3 H01_K05_dis_toplam.py
"""

import dis
import sys


def toplam(a):
    """a'nın elemanlarının toplamı (C'deki döngünün birebir karşılığı)."""
    s = 0
    for i in range(len(a)):
        s += a[i]
    return s


def main():
    print("Python", sys.version.split()[0])
    dis.dis(toplam)


if __name__ == "__main__":
    main()

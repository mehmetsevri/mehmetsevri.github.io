/* H01_K02_sozlesme_mutlak.c — AP-2 Hafta 1 · Kavram 2
 * Amaç    : Sözleşme ile tasarım: ön koşul ve son koşulun yorumda
 *           yazılması ve assert ile denetlenmesi (|x| örneği)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_K02_sozlesme_mutlak.c -o H01_K02_sozlesme_mutlak
 * Çalıştır: ./H01_K02_sozlesme_mutlak
 */
#include <assert.h>
#include <limits.h>
#include <stdio.h>

/* mutlak: x'in mutlak değeri.
 * Ön koşul : x != INT_MIN (-INT_MIN int'e sığmaz: işaretli taşma,
 *            tanımsız davranış olurdu)
 * Son koşul: dönen y >= 0 ve (y == x ya da y == -x)              */
int mutlak(int x)
{
    assert(x != INT_MIN);                      /* ön koşul  */
    int y = (x < 0) ? -x : x;
    assert(y >= 0 && (y == x || y == -x));     /* son koşul */
    return y;
}

int main(void)
{
    printf("mutlak(-7) = %d\n", mutlak(-7));
    printf("mutlak(0) = %d\n", mutlak(0));
    printf("mutlak(INT_MAX) = %d\n", mutlak(INT_MAX));
    /* mutlak(INT_MIN) çağrısı ön koşulu çiğner: sorumluluk
     * çağıranındır; assert açıkken program burada dururdu. */
    return 0;
}

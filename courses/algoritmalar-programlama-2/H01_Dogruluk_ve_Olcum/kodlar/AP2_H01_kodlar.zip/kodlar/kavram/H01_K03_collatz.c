/* H01_K03_collatz.c — AP-2 Hafta 1 · Kavram 3 (Merak Kutusu)
 * Amaç    : Sonlanma kanıtı her zaman bulunamaz: Collatz döngüsü
 *           (n çiftse n/2, tekse 3n+1) denenen her n'de 1'e iner, ama
 *           her n için sonlandığı kanıtlanmış değildir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_K03_collatz.c -o H01_K03_collatz
 * Çalıştır: ./H01_K03_collatz
 * Eşi     : H01_K03_collatz.py
 */
#include <stdio.h>

/* collatz_adim: n'den 1'e kaç adımda inildiğini döndürür (n >= 1);
 * yol boyunca görülen en büyük değeri *tepe'ye yazar. Azalan ve
 * alttan sınırlı bir nicelik bilinmediği için sonlanması kanıtsızdır. */
long collatz_adim(unsigned long long n, unsigned long long *tepe)
{
    long adim = 0;
    *tepe = n;
    while (n != 1) {
        n = (n % 2 == 0) ? n / 2 : 3 * n + 1;
        if (n > *tepe) {
            *tepe = n;
        }
        adim++;
    }
    return adim;
}

int main(void)
{
    const unsigned long long ornek[] = {1, 6, 7, 27, 97};
    printf("     n   adım   en büyük değer\n");
    for (int i = 0; i < 5; i++) {
        unsigned long long tepe;
        long adim = collatz_adim(ornek[i], &tepe);
        printf("%6llu %6ld %16llu\n", ornek[i], adim, tepe);
    }
    return 0;
}

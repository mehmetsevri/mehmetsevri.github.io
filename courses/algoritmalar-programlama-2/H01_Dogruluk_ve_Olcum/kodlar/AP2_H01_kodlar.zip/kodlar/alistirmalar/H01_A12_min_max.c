/* H01_A12_min_max.c — AP-2 Hafta 1 · Alıştırma 1.12 (★★★, kod yaz) — İSKELET
 * Görev   : En küçük ve en büyük elemanı AYNI geçişte, elemanları ikişer
 *           işleyerek en çok 3*floor(n/2) karşılaştırmayla bulun (önce
 *           çiftin iki elemanını birbiriyle, sonra küçüğünü enk ile,
 *           büyüğünü enb ile karşılaştırın). Karşılaştırmaları sayın;
 *           iki ayrı geçişli kâhinle rastgele test edin (ortak LCG).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A12_min_max.c ortak_rastgele.c -o H01_A12_min_max
 * Çalıştır: ./H01_A12_min_max   (iskelet derlenir; testler başarısız)
 * Not     : ortak_rastgele.h/.c bu klasördedir (c/ klasörünün kopyası).
 */
#include <stddef.h>
#include <stdio.h>

#include "ortak_rastgele.h"

static long kars = 0;   /* dizi elemanları arasındaki karşılaştırmalar */

/* min_max: a[0..n-1]'in en küçüğünü *enk'ye, en büyüğünü *enb'ye yazar.
 * Ön koşul: n >= 1.                                                  */
void min_max(const int a[], size_t n, int *enk, int *enb)
{
    (void)a;
    (void)n;
    *enk = 0;   /* TAMAMLAYIN */
    *enb = 0;
}

int main(void)
{
    const int a[] = {5, 2, 9, 1, 7, 3};
    int enk, enb;
    kars = 0;
    min_max(a, 6, &enk, &enb);
    printf("enk = %d, enb = %d, karşılaştırma = %ld (beklenen 1, 9, <= 9)\n",
           enk, enb, kars);
    /* TAMAMLAYIN: kâhinle rastgele test ve n = 1000 için sayaç. */
    rastgele_tohum(42);
    return (enk == 1 && enb == 9) ? 0 : 1;
}

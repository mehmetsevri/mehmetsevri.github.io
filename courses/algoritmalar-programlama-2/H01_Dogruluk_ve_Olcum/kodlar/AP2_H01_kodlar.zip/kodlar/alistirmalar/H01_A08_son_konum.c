/* H01_A08_son_konum.c — AP-2 Hafta 1 · Alıştırma 1.8 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR.
 * Görev   : dogrusal_ara sözleşmesi "x'in İLK konumu, yoksa -1" der.
 *           Aşağıdaki testlerin hiçbiri hatayı göstermez: hangi tür girdi
 *           gösterir? Hatayı düzeltin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A08_son_konum.c -o H01_A08_son_konum
 * Çalıştır: ./H01_A08_son_konum
 */
#include <stddef.h>
#include <stdio.h>

/* Sözleşme: x'in a[0..n-1] içindeki İLK konumu; yoksa -1. */
int dogrusal_ara(const int a[], size_t n, int x)
{
    int k = -1;
    for (size_t i = 0; i < n; i++) {
        if (a[i] == x) {
            k = (int)i;
        }
    }
    return k;
}

int main(void)
{
    const int a[] = {7, 3, 9, 5, 1};
    printf("%d %d %d\n", dogrusal_ara(a, 5, 7), dogrusal_ara(a, 5, 1),
           dogrusal_ara(a, 5, 6));
    return 0;
}

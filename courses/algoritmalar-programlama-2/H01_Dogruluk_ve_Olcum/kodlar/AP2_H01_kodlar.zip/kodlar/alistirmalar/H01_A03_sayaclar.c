/* H01_A03_sayaclar.c — AP-2 Hafta 1 · Alıştırma 1.3–1.4 (★/★★, karmaşıklık)
 * Görev   : Her fonksiyonun yaptığı karşılaştırma sayısını n cinsinden
 *           tahmin edin (en iyi / en kötü); sonra programla doğrulayın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A03_sayaclar.c -o H01_A03_sayaclar
 * Çalıştır: ./H01_A03_sayaclar
 */
#include <stddef.h>
#include <stdio.h>

static long kars = 0;   /* dizi elemanları arasındaki karşılaştırmalar */

int en_buyuk(const int a[], size_t n)
{
    int m = a[0];
    for (size_t i = 1; i < n; i++) {
        kars++;
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

int dogrusal_ara(const int a[], size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {
        kars++;
        if (a[i] == x) {
            return (int)i;
        }
    }
    return -1;
}

int ikinci_en_buyuk(const int a[], size_t n)
{
    int b1 = a[0], b2 = a[1];
    kars++;
    if (b2 > b1) {
        b1 = a[1];
        b2 = a[0];
    }
    for (size_t i = 2; i < n; i++) {
        kars++;
        if (a[i] > b1) {
            b2 = b1;
            b1 = a[i];
        } else {
            kars++;
            if (a[i] > b2) {
                b2 = a[i];
            }
        }
    }
    return b2;
}

int main(void)
{
    enum { N = 10 };
    int artan[N], azalan[N];
    for (int i = 0; i < N; i++) {
        artan[i] = i + 1;
        azalan[i] = N - i;
    }
    kars = 0; en_buyuk(artan, N);
    printf("en_buyuk, n = %d: %ld karşılaştırma\n", N, kars);
    kars = 0; dogrusal_ara(artan, N, 1);
    printf("dogrusal_ara, ilk eleman: %ld\n", kars);
    kars = 0; dogrusal_ara(artan, N, 99);
    printf("dogrusal_ara, yok: %ld\n", kars);
    kars = 0; ikinci_en_buyuk(artan, N);
    printf("ikinci_en_buyuk, artan dizi: %ld\n", kars);
    kars = 0; ikinci_en_buyuk(azalan, N);
    printf("ikinci_en_buyuk, azalan dizi: %ld\n", kars);
    return 0;
}

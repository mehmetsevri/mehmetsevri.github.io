/* H01_A10_en_kucuk.c — AP-2 Hafta 1 · Alıştırma 1.10 (★, kod yaz) — İSKELET
 * Görev   : en_kucuk(a, n) fonksiyonunu yazın: ön koşul ve son koşulu
 *           yorumda belirtin, ön koşulu ve döngü değişmezini assert ile
 *           denetleyin. main'deki testlerin hepsi geçmelidir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A10_en_kucuk.c -o H01_A10_en_kucuk
 * Çalıştır: ./H01_A10_en_kucuk   (iskelet derlenir; testler başarısız,
 *           çıkış kodu 1)
 */
#include <limits.h>
#include <stddef.h>
#include <stdio.h>

/* en_kucuk: a[0..n-1]'in en küçük elemanı.
 * Ön koşul : (yazın)
 * Son koşul: (yazın)                                               */
int en_kucuk(const int a[], size_t n)
{
    (void)a;
    (void)n;
    return 0;   /* TAMAMLAYIN */
}

int dene(const int a[], size_t n, int beklenen)
{
    int bulunan = en_kucuk(a, n);
    printf("beklenen %d, bulunan %d -> %s\n", beklenen, bulunan,
           bulunan == beklenen ? "geçti" : "BAŞARISIZ");
    return bulunan == beklenen;
}

int main(void)
{
    const int t1[] = {5};
    const int t2[] = {8, 3, 12};
    const int t3[] = {3, -1, 7, 2, -1};
    const int t4[] = {INT_MAX, INT_MIN};
    const int t5[] = {2, 4, 6, 8, 1};
    int gecen = dene(t1, 1, 5) + dene(t2, 3, 3) + dene(t3, 5, -1)
                + dene(t4, 2, INT_MIN) + dene(t5, 5, 1);
    printf("%d/5 test geçti\n", gecen);
    return gecen == 5 ? 0 : 1;
}

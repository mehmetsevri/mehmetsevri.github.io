/* H01_A06_basamak_toplami.c — AP-2 Hafta 1 · Alıştırma 1.6 (★★★, değişmez
 *           ve sonlanma)
 * Görev   : Döngünün değişmezini ve sonlanma niceliğini yazın; ardından
 *           değişmezi assert ile denetleyen bir sürüm yazın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A06_basamak_toplami.c -o H01_A06_basamak_toplami
 * Çalıştır: ./H01_A06_basamak_toplami
 */
#include <stdio.h>

/* basamak_toplami: n'nin onluk basamaklarının toplamı (n >= 0). */
int basamak_toplami(int n)
{
    int s = 0;
    int x = n;
    while (x > 0) {
        s += x % 10;
        x /= 10;
    }
    return s;
}

int main(void)
{
    printf("basamak_toplami(2026) = %d\n", basamak_toplami(2026));
    printf("basamak_toplami(0) = %d\n", basamak_toplami(0));
    return 0;
}

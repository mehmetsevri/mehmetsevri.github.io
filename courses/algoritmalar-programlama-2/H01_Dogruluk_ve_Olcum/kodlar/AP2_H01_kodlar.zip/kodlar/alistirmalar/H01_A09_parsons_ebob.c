/* H01_A09_parsons_ebob.c — AP-2 Hafta 1 · Alıştırma 1.9 (★★, Parsons)
 * Görev   : Aşağıdaki satırları doğru sıraya dizerek Öklid'in ebob
 *           fonksiyonunu kurun. Satırlardan BİRİ fazladır (çeldirici).
 *           Tamamlanacak; bu hâliyle derlenmez.
 */
        a = b;
    return a;
int ebob(int a, int b)
        b = r;
    }
{
        a = r;
    while (b != 0) {
}
        int r = a % b;

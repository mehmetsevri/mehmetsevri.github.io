/* H01_A07_hata_bul.c — AP-2 Hafta 1 · Alıştırma 1.7 (★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR.
 * Görev   : en_buyuk'taki hatayı bulun; testler neden geçiyor? Hatayı
 *           yakalayan bir test yazın ve değişmezin hangi adımının
 *           bozulduğunu söyleyin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A07_hata_bul.c -o H01_A07_hata_bul
 * Çalıştır: ./H01_A07_hata_bul
 */
#include <stddef.h>
#include <stdio.h>

int en_buyuk(const int a[], size_t n)
{
    int m = a[0];
    for (size_t i = 1; i < n - 1; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

int main(void)
{
    const int t1[] = {3, 9, 4};
    const int t2[] = {-8, -3, -12};
    const int t3[] = {7, 1, 5, 2};
    printf("%d %d %d\n", en_buyuk(t1, 3), en_buyuk(t2, 3), en_buyuk(t3, 4));
    return 0;
}

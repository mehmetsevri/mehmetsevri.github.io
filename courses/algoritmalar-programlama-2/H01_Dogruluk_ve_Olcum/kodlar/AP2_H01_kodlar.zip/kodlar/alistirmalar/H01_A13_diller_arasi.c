/* H01_A13_diller_arasi.c — AP-2 Hafta 1 · Alıştırma 1.13 (★★, diller arası)
 * Görev   : Aynı dört hesabın C, C++ ve Python sürümlerinin çıktısını
 *           çalıştırmadan tahmin edin; hangi satırlar dile göre değişir?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A13_diller_arasi.c -o H01_A13_diller_arasi
 * Çalıştır: ./H01_A13_diller_arasi
 * Eşleri  : H01_A13_diller_arasi.cpp · H01_A13_diller_arasi.py
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    printf("1) 7 / 2 = %d\n", 7 / 2);
    printf("2) -17 / 5 = %d, -17 %% 5 = %d\n", -17 / 5, -17 % 5);
    uint32_t x = 4000000000u;
    x = x + 500000000u;
    printf("3) 4000000000 + 500000000 = %" PRIu32 "\n", x);
    printf("4) (int)(-3.7) = %d\n", (int)(-3.7));
    return 0;
}

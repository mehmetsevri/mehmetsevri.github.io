/* H01_A15_hata_avi.c — AP-2 Hafta 1 · Atölye 2 (hata avı)
 * BU DOSYA KASITLI HATA İÇERİR (beş fonksiyonun her birinde bir hata).
 * Görev   : Her fonksiyon için (1) en az bir sınır değer testi ve (2)
 *           kâhinle rastgele karşılaştırmalı test (ortak LCG) yazın;
 *           hatayı gösteren EN KÜÇÜK girdiyi raporlayın. F1 için örnek bir
 *           sınır testi verilmiştir. Kâhinler (kahin_*) doğrudur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A15_hata_avi.c ortak_rastgele.c -o H01_A15_hata_avi
 * Çalıştır: ./H01_A15_hata_avi
 */
#include <stddef.h>
#include <stdio.h>

#include "ortak_rastgele.h"

/* F1 — toplam: a[0..n-1] elemanlarının toplamı (n >= 0). */
long long toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 1; i < n; i++) {
        s += a[i];
    }
    return s;
}

/* F2 — dogrusal_ara: x'in İLK konumu; yoksa -1. */
int dogrusal_ara(const int a[], size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {
        if (a[i] == x) {
            return (int)i;
        }
    }
    return 0;
}

/* F3 — en_buyuk_indis: en büyük elemanın İLK indisi (n >= 1). */
size_t en_buyuk_indis(const int a[], size_t n)
{
    size_t e = 0;
    for (size_t i = 1; i < n; i++) {
        if (a[i] >= a[e]) {
            e = i;
        }
    }
    return e;
}

/* F4 — ortalama: a[0..n-1]'in aritmetik ortalaması (n >= 1). */
double ortalama(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return (double)(s / (long long)n);
}

/* F5 — ebob: a >= 0, b >= 0, ikisi birden 0 değil. */
int ebob(int a, int b)
{
    while (b > 1) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

/* ---------------- kâhinler: yavaş ya da farklı yoldan, ama apaçık doğru */
long long kahin_toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return s;
}

int kahin_ara(const int a[], size_t n, int x)
{
    int k = -1;
    for (size_t i = n; i-- > 0;) {  /* sondan başa: son yazılan İLK konum */
        if (a[i] == x) {
            k = (int)i;
        }
    }
    return k;
}

size_t kahin_en_buyuk_indis(const int a[], size_t n)
{
    int m = a[0];
    for (size_t i = 1; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    size_t e = 0;
    while (a[e] != m) {
        e++;
    }
    return e;
}

double kahin_ortalama(const int a[], size_t n)
{
    return (double)kahin_toplam(a, n) / (double)n;
}

int kahin_ebob(int a, int b)
{
    if (a == 0 || b == 0) {
        return a + b;
    }
    int d = a < b ? a : b;
    while (a % d != 0 || b % d != 0) {
        d--;
    }
    return d;
}

int main(void)
{
    /* Örnek sınır testi (F1): tek elemanlı dizi */
    const int t[] = {5};
    long long beklenen = kahin_toplam(t, 1), bulunan = toplam(t, 1);
    printf("F1 sınır testi [5]: beklenen %lld, bulunan %lld -> %s\n",
           beklenen, bulunan, beklenen == bulunan ? "geçti" : "YAKALANDI");
    /* TAMAMLAYIN: F2–F5 için sınır testleri; beşi için rastgele test
     * (rastgele_tohum(7); n = 1..8; değerler dar bir aralıkta). */
    rastgele_tohum(7);
    return 0;
}

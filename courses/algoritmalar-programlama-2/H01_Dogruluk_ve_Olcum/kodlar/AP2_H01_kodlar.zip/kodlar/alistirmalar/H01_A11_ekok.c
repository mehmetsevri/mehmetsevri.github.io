/* H01_A11_ekok.c — AP-2 Hafta 1 · Alıştırma 1.11 (★★, kod yaz) — İSKELET
 * Görev   : ekok(a, b) = a / ebob(a, b) * b fonksiyonunu uint64_t ile
 *           yazın (önce bölün: ara sonuç taşmasın) ve kaba kuvvet bir
 *           kâhinle 1000 rastgele çiftte karşılaştırın (ortak LCG,
 *           tohum 2026, a, b ∈ [1, 1000]). Taşma sınır testi de geçmeli.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A11_ekok.c ortak_rastgele.c -o H01_A11_ekok
 * Çalıştır: ./H01_A11_ekok   (iskelet derlenir; testler başarısız)
 * Not     : ortak_rastgele.h/.c bu klasördedir (c/ klasörünün kopyası).
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

#include "ortak_rastgele.h"

uint64_t ebob(uint64_t a, uint64_t b)
{
    while (b != 0) {
        uint64_t r = a % b;
        a = b;
        b = r;
    }
    return a;
}

/* ekok: a ve b'nin en küçük ortak katı. Ön koşul: a >= 1, b >= 1. */
uint64_t ekok(uint64_t a, uint64_t b)
{
    (void)a;
    (void)b;
    return 0;   /* TAMAMLAYIN */
}

/* kahin_ekok: kaba kuvvet — a'nın katlarını b'ye bölünene dek dener. */
uint64_t kahin_ekok(uint64_t a, uint64_t b)
{
    (void)a;
    (void)b;
    return 0;   /* TAMAMLAYIN */
}

int main(void)
{
    /* TAMAMLAYIN: 1000 rastgele çift için ekok ile kahin_ekok'u
     * karşılaştırın; ilk uyuşmazlığı yazdırın. */
    uint64_t buyuk = UINT64_C(1) << 40;
    printf("ekok(2^40, 2^40) = %" PRIu64 " (beklenen %" PRIu64 ")\n",
           ekok(buyuk, buyuk), buyuk);
    rastgele_tohum(2026);
    return ekok(buyuk, buyuk) == buyuk ? 0 : 1;
}

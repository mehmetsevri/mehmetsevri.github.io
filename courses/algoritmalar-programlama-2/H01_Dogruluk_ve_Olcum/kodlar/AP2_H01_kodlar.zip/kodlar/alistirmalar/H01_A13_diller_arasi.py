"""H01_A13_diller_arasi.py — AP-2 Hafta 1 · Alıştırma 1.13 (★★, diller arası)
Görev   : Aynı dört hesabın C, C++ ve Python sürümlerinin çıktısını
          çalıştırmadan tahmin edin; hangi satırlar dile göre değişir?
Çalıştır: python3 H01_A13_diller_arasi.py
Eşleri  : H01_A13_diller_arasi.c · H01_A13_diller_arasi.cpp
"""


def main():
    print(f"1) 7 / 2 = {7 / 2}")
    print(f"2) -17 // 5 = {-17 // 5}, -17 % 5 = {-17 % 5}")
    x = 4000000000
    x = x + 500000000
    print(f"3) 4000000000 + 500000000 = {x}")
    print(f"4) int(-3.7) = {int(-3.7)}")


if __name__ == "__main__":
    main()

"""H01_A16_olcum_birlestir.py — AP-2 Hafta 1 · Atölye 3 (ölçüm deneyi)
Amaç    : Örnek 13'ün --csv seçeneğiyle ürettiği ölçüm dosyalarını tek
          tabloda birleştirir; her yapılandırma (dil + derleme) için
          T(10n)/T(n) oranını ve log-log eğimini hesaplar.
Çalıştır: python3 H01_A16_olcum_birlestir.py c_O0.csv c_O2.csv cpp.csv py.csv
          (sütunlar: n;dil;derleme;tekrar;ortanca_ms;toplam)
"""

import csv
import math
import sys


def oku(yollar):
    """Bütün CSV satırlarını sözlük listesi olarak döndürür."""
    satirlar = []
    for yol in yollar:
        with open(yol, encoding="utf-8", newline="") as f:
            satirlar.extend(csv.DictReader(f, delimiter=";"))
    return satirlar


def egim(noktalar):
    """log10(süre) ~ log10(n) doğrusunun en küçük kareler eğimi."""
    xs = [math.log10(n) for n, _ in noktalar]
    ys = [math.log10(t) for _, t in noktalar]
    xo = sum(xs) / len(xs)
    yo = sum(ys) / len(ys)
    pay = sum((x - xo) * (y - yo) for x, y in zip(xs, ys))
    payda = sum((x - xo) ** 2 for x in xs)
    return pay / payda


def main():
    if len(sys.argv) < 2:
        print("Kullanım: python3 H01_A16_olcum_birlestir.py a.csv [b.csv ...]",
              file=sys.stderr)
        return 2
    try:
        satirlar = oku(sys.argv[1:])
    except (OSError, UnicodeDecodeError) as e:
        print(f"Hata: {e}", file=sys.stderr)
        return 1
    gruplar = {}
    for s in satirlar:
        ad = f"{s['dil']} {s['derleme']}"
        gruplar.setdefault(ad, []).append((int(s["n"]),
                                           float(s["ortanca_ms"])))
    print(f"{'yapılandırma':<14} {'n':>10} {'ortanca (ms)':>13} "
          f"{'T(10n)/T(n)':>12}")
    for ad in sorted(gruplar):
        noktalar = sorted(gruplar[ad])
        onceki = None
        for n, t in noktalar:
            oran = f"{t / onceki:12.2f}" if onceki else f"{'—':>12}"
            print(f"{ad:<14} {n:>10} {t:>13.4f} {oran}")
            onceki = t
        if len(noktalar) >= 2 and all(t > 0 for _, t in noktalar):
            print(f"{ad:<14} log-log eğim = {egim(noktalar):.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

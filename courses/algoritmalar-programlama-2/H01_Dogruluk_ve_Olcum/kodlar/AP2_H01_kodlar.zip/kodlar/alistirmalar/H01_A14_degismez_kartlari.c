/* H01_A14_degismez_kartlari.c — AP-2 Hafta 1 · Atölye 1 ("Değişmezi bul")
 * Görev   : Altı kısa döngünün her biri için (eşli çalışın) döngü
 *           değişmezini yazın; "assert(1)" satırını değişmezinizi
 *           denetleyen bir assert ile değiştirin (gerekirse yardımcı bir
 *           denetim fonksiyonu yazın); başlatma, koruma ve sonlanmayı
 *           sözlü olarak gerekçelendirin. İskelet derlenir ve çalışır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A14_degismez_kartlari.c -o H01_A14_degismez_kartlari
 * Çalıştır: ./H01_A14_degismez_kartlari
 */
#include <assert.h>
#include <stddef.h>
#include <stdio.h>

/* KART 1 — negatif_say: a[0..n-1]'deki negatif elemanların sayısı. */
int negatif_say(const int a[], size_t n)
{
    int c = 0;
    for (size_t i = 0; i < n; i++) {
        assert(1);              /* KART 1: c == ... */
        if (a[i] < 0) {
            c++;
        }
    }
    return c;
}

/* KART 2 — sirali_mi: a[0..n-1] azalmayan sırada mı? (1: evet, 0: hayır) */
int sirali_mi(const int a[], size_t n)
{
    for (size_t i = 1; i < n; i++) {
        assert(1);              /* KART 2: a[0..i-1] ... */
        if (a[i] < a[i - 1]) {
            return 0;
        }
    }
    return 1;
}

/* KART 3 — faktoriyel: n! (0 <= n <= 20; 20! uint64'e sığar). */
unsigned long long faktoriyel(int n)
{
    unsigned long long f = 1;
    for (int k = 1; k <= n; k++) {
        assert(1);              /* KART 3: f == ... (k cinsinden) */
        f *= (unsigned long long)k;
    }
    return f;
}

/* KART 4 — ters_cevir: a[0..n-1]'i yerinde ters çevirir. orijinal[]
 * dizinin çağrıdan önceki kopyasıdır; yalnızca denetim içindir.   */
void ters_cevir(int a[], const int orijinal[], int n)
{
    (void)orijinal;             /* değişmezi yazınca bu satırı silin */
    int i = 0, j = n - 1;
    while (i < j) {
        assert(1);              /* KART 4: a[0..i-1] ve a[j+1..n-1] ... */
        int t = a[i];
        a[i] = a[j];
        a[j] = t;
        i++;
        j--;
    }
}

/* KART 5 — bir_say: x'in ikilik gösterimindeki 1 bitlerinin sayısı. */
int bir_say(unsigned x)
{
    int c = 0;
    while (x > 0) {
        assert(1);              /* KART 5: c + ... ; sonlanma: ... */
        c += (int)(x & 1u);
        x >>= 1;
    }
    return c;
}

/* KART 6 — var_mi: x, a[0..n-1] içinde var mı? (bayrakla, erken çıkışsız) */
int var_mi(const int a[], size_t n, int x)
{
    int bulundu = 0;
    for (size_t i = 0; i < n; i++) {
        assert(1);              /* KART 6: bulundu == ... */
        if (a[i] == x) {
            bulundu = 1;
        }
    }
    return bulundu;
}

int main(void)
{
    const int a[] = {3, -1, 4, -1, 5, -9};
    const int s[] = {1, 2, 2, 7, 9};
    int b[] = {1, 2, 3, 4, 5};
    const int b0[] = {1, 2, 3, 4, 5};

    printf("1) negatif_say = %d\n", negatif_say(a, 6));
    printf("2) sirali_mi(s) = %d, sirali_mi(a) = %d\n", sirali_mi(s, 5),
           sirali_mi(a, 6));
    printf("3) faktoriyel(10) = %llu\n", faktoriyel(10));
    ters_cevir(b, b0, 5);
    printf("4) ters_cevir = [%d, %d, %d, %d, %d]\n", b[0], b[1], b[2], b[3],
           b[4]);
    printf("5) bir_say(2026) = %d\n", bir_say(2026u));
    printf("6) var_mi(4) = %d, var_mi(8) = %d\n", var_mi(a, 6, 4),
           var_mi(a, 6, 8));
    return 0;
}

/* H01_A13_diller_arasi.cpp — AP-2 Hafta 1 · Alıştırma 1.13 (★★, diller arası)
 * Görev   : Aynı dört hesabın C, C++ ve Python sürümlerinin çıktısını
 *           çalıştırmadan tahmin edin; hangi satırlar dile göre değişir?
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_A13_diller_arasi.cpp -o H01_A13_diller_arasi
 * Çalıştır: ./H01_A13_diller_arasi
 * Eşleri  : H01_A13_diller_arasi.c · H01_A13_diller_arasi.py
 */
#include <cstdint>
#include <iostream>

int main()
{
    std::cout << "1) 7 / 2 = " << 7 / 2 << "\n";
    std::cout << "2) -17 / 5 = " << -17 / 5 << ", -17 % 5 = " << -17 % 5
              << "\n";
    std::uint32_t x = 4000000000u;
    x = x + 500000000u;
    std::cout << "3) 4000000000 + 500000000 = " << x << "\n";
    std::cout << "4) (int)(-3.7) = " << static_cast<int>(-3.7) << "\n";
    return 0;
}

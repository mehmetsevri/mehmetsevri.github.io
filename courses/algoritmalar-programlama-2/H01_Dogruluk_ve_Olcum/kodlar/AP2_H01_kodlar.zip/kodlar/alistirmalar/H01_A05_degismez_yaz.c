/* H01_A05_degismez_yaz.c — AP-2 Hafta 1 · Alıştırma 1.5 (★★, değişmez yaz)
 * Görev   : İki döngünün değişmezini yazın; "assert(1)" satırlarını
 *           kendi değişmezinizle değiştirip programı yeniden çalıştırın.
 *           (İskelet derlenir ve çalışır; denetimler henüz boştur.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A05_degismez_yaz.c -o H01_A05_degismez_yaz
 * Çalıştır: ./H01_A05_degismez_yaz
 */
#include <assert.h>
#include <stddef.h>
#include <stdio.h>

/* en_kucuk_indis: a[0..n-1]'deki en küçük elemanın İLK indisi (n >= 1). */
size_t en_kucuk_indis(const int a[], size_t n)
{
    size_t e = 0;
    for (size_t i = 1; i < n; i++) {
        assert(1);      /* DEĞİŞMEZ: ... (döngü başında) */
        if (a[i] < a[e]) {
            e = i;
        }
    }
    return e;
}

/* fibonacci: F(0) = 0, F(1) = 1, F(k+1) = F(k) + F(k-1); n >= 0. */
long long fibonacci(int n)
{
    long long x = 0, y = 1;
    for (int k = 0; k < n; k++) {
        assert(1);      /* DEĞİŞMEZ: ... (x ve y, k cinsinden) */
        long long t = x + y;
        x = y;
        y = t;
    }
    return x;
}

int main(void)
{
    const int a[] = {5, 2, 8, 2, 9};
    printf("en_kucuk_indis = %zu\n", en_kucuk_indis(a, 5));
    printf("fibonacci(10) = %lld\n", fibonacci(10));
    return 0;
}

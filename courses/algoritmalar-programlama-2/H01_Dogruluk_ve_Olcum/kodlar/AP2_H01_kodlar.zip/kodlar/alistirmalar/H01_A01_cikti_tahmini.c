/* H01_A01_cikti_tahmini.c — AP-2 Hafta 1 · Alıştırma 1.1 (★, çıktı tahmini)
 * Görev   : Çalıştırmadan önce çıktıyı tahmin edin; sonra > ile >= farkını
 *           açıklayın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_A01_cikti_tahmini.c -o H01_A01_cikti_tahmini
 * Çalıştır: ./H01_A01_cikti_tahmini
 */
#include <stddef.h>
#include <stdio.h>

int main(void)
{
    const int a[] = {4, 9, 2, 9, 1};
    int m = a[0];
    size_t yer = 0;
    for (size_t i = 1; i < 5; i++) {
        if (a[i] >= m) {
            m = a[i];
            yer = i;
            printf("i = %zu: m = %d\n", i, m);
        }
    }
    printf("sonuç: m = %d, yer = %zu\n", m, yer);
    return 0;
}

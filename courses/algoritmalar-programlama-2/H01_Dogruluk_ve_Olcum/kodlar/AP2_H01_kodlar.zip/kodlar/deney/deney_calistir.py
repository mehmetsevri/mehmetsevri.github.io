#!/usr/bin/env python3
"""deney_calistir.py — AP-2 Hafta 1 · Haftanın Deneyi sürücüsü

Amaç    : Aynı doğrusal toplam algoritmasının C (-O0, -O2), C++ (-O2) ve
          Python sürümlerini n = 10^5, 10^6, 10^7 için ölçer. Her OTURUM ayrı
          bir süreçtir: 1 soğuk (ısınmasız) "tek ölçüm" + 5 tekrar. Oturumlar
          yapılandırmalar arasında sırayla dönüşümlü çalıştırılır (gürültü
          hepsine eşit dağılsın). Oturumlar arası tutarsızlık eşiği aşılırsa
          o yapılandırma için ek oturum yapılır (tutarsız ölçümü tekrarla).
Çıktılar: sonuclar/h01_deney_ham.csv        (her ölçüm; programlar yazar)
          sonuclar/h01_deney_meta.csv       (oturum sırası, sistem yükü)
          sonuclar/h01_deney_oturumlar.csv  (oturum başına tek/ortalama/
                                             ortanca + sistem yükü)
          sonuclar/h01_deney_sapma.csv      (oturum içi: tek ölçümün ve
                                             ortalamanın ortancadan sapması)
          sonuclar/h01_deney_tablo.csv      (n'e karşı süre: ana tablo)
          sonuclar/h01_deney_tutarlilik.csv (tek ölçüm / 5 tekrar ortalaması
                                             / 5 tekrar ortancası: yayılım)
          sonuclar/h01_deney_python_yontem.csv (Python içi: indis, eleman,
                                             sum karşılaştırması)
          OLCUM_ORTAMI.txt                  (makine, derleyici, tarih)
Kullanım: python3 deney_calistir.py [--oturum 7] [--nler 100000,1000000,
          10000000] [--esik 20] [--yalniz-ozet]
Gereksinim: gcc, g++, python3 (3.10+); yalnızca standart kütüphane.
Bu makinede toplam süre ≈ 1,5–2 dakika (Python 10^7 baskın).
"""

import argparse
import csv
import datetime
import os
import platform
import shutil
import statistics
import subprocess
import sys
import tempfile
import time

KOK = os.path.dirname(os.path.abspath(__file__))
SON = os.path.join(KOK, "sonuclar")
C_BAYRAK = ["-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP_BAYRAK = ["-std=c++17", "-Wall", "-Wextra", "-pedantic"]
TEKRAR = 5


def komut_ciktisi(komut):
    try:
        return subprocess.run(komut, capture_output=True, text=True,
                              check=False).stdout.strip()
    except OSError:
        return "?"


def derle(gecici):
    """Yapılandırmaları derler: {ad: (komut listesi, dil, derleme)}."""
    c = os.path.join(KOK, "c")
    cpp = os.path.join(KOK, "cpp")
    yap = {}
    for opt in ("-O0", "-O2"):
        ikili = os.path.join(gecici, f"c{opt}")
        komut = (["gcc"] + C_BAYRAK + [opt, "H01_deney_toplam.c",
                                       "ortak_rastgele.c", "zamanlayici.c",
                                       "-o", ikili])
        p = subprocess.run(komut, cwd=c, capture_output=True, text=True)
        if p.returncode != 0 or p.stderr.strip():
            sys.exit("C derleme sorunu:\n" + p.stderr)
        yap[f"C {opt}"] = ([ikili], "C", opt[1:])
    ikili = os.path.join(gecici, "cpp-O2")
    komut = ["g++"] + CPP_BAYRAK + ["-O2", "H01_deney_toplam.cpp", "-o", ikili]
    p = subprocess.run(komut, cwd=cpp, capture_output=True, text=True)
    if p.returncode != 0 or p.stderr.strip():
        sys.exit("C++ derleme sorunu:\n" + p.stderr)
    yap["C++ -O2"] = ([ikili], "C++", "O2")
    yap["Python"] = ([sys.executable, os.path.join(KOK, "python",
                                                   "H01_deney_toplam.py")],
                     "Python", "CPython")
    return yap


def ortam_yaz(baslangic, bitis, sure_s, yuk_bas, yuk_son, oturum, nler):
    satirlar = [
        f"tarih: {baslangic:%Y-%m-%d %H:%M} – {bitis:%H:%M} "
        f"(deney süresi {sure_s:.0f} s)",
    ]
    lscpu = komut_ciktisi(["lscpu"])
    for s in lscpu.split("\n"):
        if s.split(":")[0].strip() in ("Model name", "CPU(s)", "L1d cache",
                                       "L2 cache", "L3 cache",
                                       "Hypervisor vendor"):
            satirlar.append(" ".join(s.split()))
    satirlar += [
        komut_ciktisi(["gcc", "--version"]).split("\n")[0],
        komut_ciktisi(["g++", "--version"]).split("\n")[0],
        "Python " + platform.python_version() + " ("
        + platform.python_implementation() + ")",
        "işletim sistemi: " + platform.platform(),
        "C bayrakları  : " + " ".join(C_BAYRAK) + " -O0 | -O2",
        "C++ bayrakları: " + " ".join(CPP_BAYRAK) + " -O2",
        f"düzen: oturum = ayrı süreç; 1 soğuk ölçüm + {TEKRAR} tekrar; "
        f"{oturum} oturum (tutarsızlıkta ek oturum); n = "
        + ", ".join(str(n) for n in nler),
        "veri: ortak LCG, tohum 42, değerler 0..99 (üç dilde aynı dizi)",
        f"sistem yükü (1 dk ortalaması): başta {yuk_bas:.2f}, sonda "
        f"{yuk_son:.2f} — 2 çekirdekli sanal makine; başka süreçler "
        "çalışıyordu",
        "zamanlayıcı: C zaman_sn() = timespec_get(TIME_UTC), ilk "
        "çağrıya göreli saniye (double; ns düzeyinde çözünürlük; "
        "TIME_UTC monotonik değildir). C++ steady_clock ve Python "
        "perf_counter monotonik, ns çözünürlüklü.",
    ]
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(satirlar) + "\n")


def calistir(komut, n, oturum, derleme, ham, yontem=None):
    k = list(komut) + ["--n", str(n), "--tekrar", str(TEKRAR), "--oturum",
                       str(oturum), "--derleme", derleme, "--csv", ham]
    if yontem:
        k += ["--yontem", yontem]
    yuk = os.getloadavg()[0]
    t0 = time.perf_counter()
    p = subprocess.run(k, capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit(f"Çalıştırma hatası: {' '.join(k)}\n{p.stderr}")
    return yuk, time.perf_counter() - t0, p.stdout.strip()


def oturum_ozetleri(ham):
    """Ham CSV → {(dil, derleme, yontem, n, oturum): {tek, ort, med, ...}}"""
    gruplar = {}
    with open(ham, encoding="utf-8") as f:
        for r in csv.DictReader(f, delimiter=";"):
            anahtar = (r["dil"], r["derleme"], r["yontem"], int(r["n"]),
                       int(r["oturum"]))
            gruplar.setdefault(anahtar, {})[int(r["olcum"])] = \
                float(r["sure_ms"])
    ozet = {}
    for anahtar, olc in gruplar.items():
        tekrarlar = [olc[i] for i in range(1, TEKRAR + 1)]
        ozet[anahtar] = {"tek": olc[0],
                         "ortalama": statistics.fmean(tekrarlar),
                         "ortanca": statistics.median(tekrarlar),
                         "en_az": min(tekrarlar), "en_cok": max(tekrarlar)}
    return ozet


def yayilim(degerler):
    m = statistics.median(degerler)
    return 100.0 * (max(degerler) - min(degerler)) / m


YAPILAR = (("C", "O0"), ("C", "O2"), ("C++", "O2"), ("Python", "CPython"))


def ozetle(nler):
    """Ham CSV'den (ve oturum yükü kaydından) bütün özet CSV'lerini üretir."""
    ham = os.path.join(SON, "h01_deney_ham.csv")
    meta_yol = os.path.join(SON, "h01_deney_meta.csv")
    yuk_haritasi = {}
    if os.path.exists(meta_yol):
        with open(meta_yol, encoding="utf-8") as f:
            for r in csv.DictReader(f, delimiter=";"):
                yuk_haritasi[(r["dil"], r["derleme"], int(r["n"]),
                              int(r["oturum"]))] = r["yuk_1dk"]
    ozet = oturum_ozetleri(ham)
    with open(os.path.join(SON, "h01_deney_oturumlar.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;derleme;yontem;n;oturum;yuk_1dk;tek_ms;ortalama5_ms;"
                "ortanca5_ms;en_az5_ms;en_cok5_ms\n")
        for k in sorted(ozet):
            v = ozet[k]
            yuk = yuk_haritasi.get((k[0], k[1], k[3], k[4]), "")
            f.write(f"{k[0]};{k[1]};{k[2]};{k[3]};{k[4]};{yuk};"
                    f"{v['tek']:.6f};{v['ortalama']:.6f};{v['ortanca']:.6f};"
                    f"{v['en_az']:.6f};{v['en_cok']:.6f}\n")

    def oturumlar(dil, derleme, n):
        return [v for k, v in sorted(ozet.items())
                if k[:4] == (dil, derleme, "indis", n) and k[4] < 100]

    tablo = []
    with open(os.path.join(SON, "h01_deney_tutarlilik.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;derleme;n;yontem;oturum_sayisi;en_az_ms;ortanca_ms;"
                "en_cok_ms;yayilim_yuzde;degisim_katsayisi_yuzde\n")
        for dil, derleme in YAPILAR:
            for n in nler:
                ots = oturumlar(dil, derleme, n)
                for y in ("tek", "ortalama", "ortanca"):
                    d = [o[y] for o in ots]
                    cv = 100.0 * statistics.stdev(d) / statistics.fmean(d)
                    f.write(f"{dil};{derleme};{n};{y};{len(d)};{min(d):.6f};"
                            f"{statistics.median(d):.6f};{max(d):.6f};"
                            f"{yayilim(d):.1f};{cv:.1f}\n")
                tablo.append((n, dil, derleme, len(ots),
                              statistics.median([o["ortanca"] for o in ots]),
                              statistics.median([o["tek"] for o in ots]),
                              statistics.median([o["ortalama"] for o in ots])))
    # Oturum İÇİ sapmalar: tek ölçüm ve ortalama, aynı oturumun
    # ortancasından yüzde kaç sapıyor? (her oturum için, sonra ortanca/en çok)
    with open(os.path.join(SON, "h01_deney_sapma.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;derleme;n;oturum_sayisi;tek_sapma_ortanca_yuzde;"
                "tek_sapma_en_cok_yuzde;ortalama_sapma_ortanca_yuzde;"
                "ortalama_sapma_en_cok_yuzde;"
                "oturum_ici_yayilim_ortanca_yuzde\n")
        for dil, derleme in YAPILAR:
            for n in nler:
                ots = oturumlar(dil, derleme, n)
                tek = [100.0 * (o["tek"] / o["ortanca"] - 1) for o in ots]
                ort = [100.0 * (o["ortalama"] / o["ortanca"] - 1)
                       for o in ots]
                ici = [100.0 * (o["en_cok"] - o["en_az"]) / o["ortanca"]
                       for o in ots]
                f.write(f"{dil};{derleme};{n};{len(ots)};"
                        f"{statistics.median(tek):.1f};"
                        f"{max(tek, key=abs):.1f};"
                        f"{statistics.median(ort):.1f};"
                        f"{max(ort, key=abs):.1f};"
                        f"{statistics.median(ici):.1f}\n")
    with open(os.path.join(SON, "h01_deney_tablo.csv"), "w",
              encoding="utf-8") as f:
        f.write("n;dil;derleme;tekrar;oturum_sayisi;ortanca_ms;tek_ms;"
                "ortalama_ms;eleman_basi_ns\n")
        for n, dil, derleme, s, med, tek, ort in sorted(tablo):
            f.write(f"{n};{dil};{derleme};{TEKRAR};{s};{med:.6f};{tek:.6f};"
                    f"{ort:.6f};{med * 1e6 / n:.4f}\n")
    with open(os.path.join(SON, "h01_deney_python_yontem.csv"), "w",
              encoding="utf-8") as f:
        f.write("n;yontem;oturum_sayisi;ortanca_ms;eleman_basi_ns\n")
        for n in nler[-2:]:
            for y in ("indis", "eleman", "sum"):
                d = [v["ortanca"] for k, v in ozet.items()
                     if k[0] == "Python" and k[2] == y and k[3] == n
                     and k[4] > 100]
                if d:
                    m = statistics.median(d)
                    f.write(f"{n};{y};{len(d)};{m:.6f};{m * 1e6 / n:.4f}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--oturum", type=int, default=7)
    ap.add_argument("--nler", default="100000,1000000,10000000")
    ap.add_argument("--esik", type=float, default=20.0,
                    help="oturum ortancalarının yayılımı %% eşiği")
    ap.add_argument("--yalniz-ozet", action="store_true",
                    help="ölçüm yapma; var olan ham CSV'den özetleri üret")
    a = ap.parse_args()
    nler = [int(x) for x in a.nler.split(",")]
    if a.yalniz_ozet:
        ozetle(nler)
        print(f"Özetler yeniden üretildi: {SON}")
        return 0
    os.makedirs(SON, exist_ok=True)
    ham = os.path.join(SON, "h01_deney_ham.csv")
    for ad in os.listdir(SON):
        if ad.startswith("h01_deney_"):
            os.remove(os.path.join(SON, ad))
    meta_yol = os.path.join(SON, "h01_deney_meta.csv")
    with open(meta_yol, "w", encoding="utf-8") as f:
        f.write("sira;oturum;dil;derleme;yontem;n;yuk_1dk;sure_s\n")
    gecici = tempfile.mkdtemp(prefix="h01_deney_")
    baslangic = datetime.datetime.now()
    yuk_bas = os.getloadavg()[0]
    t_bas = time.perf_counter()
    yap = derle(gecici)
    sira = 0

    def kaydet(oturum, dil, derleme, yontem, n, yuk, sure):
        nonlocal sira
        sira += 1
        with open(meta_yol, "a", encoding="utf-8") as f:
            f.write(f"{sira};{oturum};{dil};{derleme};{yontem};{n};"
                    f"{yuk:.2f};{sure:.3f}\n")

    def tur(oturum, secili):
        for n in nler:
            for ad, (komut, dil, derleme) in yap.items():
                if (ad, n) not in secili:
                    continue
                yuk, sure, _ = calistir(komut, n, oturum, derleme, ham)
                kaydet(oturum, dil, derleme, "indis", n, yuk, sure)
                print(f"[{sira:3d}] oturum {oturum} {ad:8s} n={n:<9d} "
                      f"{sure:6.2f} s  yük {yuk:.2f}", flush=True)

    hepsi = {(ad, n) for ad in yap for n in nler}
    for s in range(1, a.oturum + 1):
        tur(s, hepsi)
    # Tutarsız ölçümü tekrarla: oturum ortancalarının yayılımı eşiği
    # aşan yapılandırmalar için 4 ek oturum.
    ozet = oturum_ozetleri(ham)
    tutarsiz = set()
    for ad, (_, dil, derleme) in yap.items():
        for n in nler:
            med = [v["ortanca"] for k, v in ozet.items()
                   if k[:4] == (dil, derleme, "indis", n) and k[4] < 100]
            if yayilim(med) > a.esik:
                tutarsiz.add((ad, n))
    if tutarsiz:
        print("Tutarsız (yayılım > %{:.0f}): {}".format(
            a.esik, sorted(tutarsiz)), flush=True)
        for s in range(a.oturum + 1, a.oturum + 5):
            tur(s, tutarsiz)
    # Python içi karşılaştırma: indis / eleman / sum (aynı süreçte)
    pyk = yap["Python"][0]
    for s in range(1, 4):
        for n in nler[-2:]:
            yuk, sure, _ = calistir(pyk, n, 100 + s, "CPython", ham,
                                    "indis,eleman,sum")
            kaydet(100 + s, "Python", "CPython", "indis,eleman,sum", n, yuk,
                   sure)
            print(f"[{sira:3d}] Python yöntemleri n={n} {sure:.2f} s",
                  flush=True)
    t_son = time.perf_counter()
    yuk_son = os.getloadavg()[0]
    bitis = datetime.datetime.now()
    shutil.rmtree(gecici, ignore_errors=True)
    ortam_yaz(baslangic, bitis, t_son - t_bas, yuk_bas, yuk_son, a.oturum,
              nler)
    ozetle(nler)
    print(f"Bitti: {t_son - t_bas:.0f} s; sonuçlar {SON}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

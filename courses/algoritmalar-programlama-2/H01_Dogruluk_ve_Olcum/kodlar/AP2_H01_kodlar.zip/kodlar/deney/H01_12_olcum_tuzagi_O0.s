	.file	"H01_12_olcum_tuzagi.c"
	.text
	.globl	sonuc_yeri
	.bss
	.align 8
	.type	sonuc_yeri, @object
	.size	sonuc_yeri, 8
sonuc_yeri:
	.zero	8
	.text
	.globl	kullanilmayan_dongu
	.type	kullanilmayan_dongu, @function
kullanilmayan_dongu:
	endbr64
	pushq	%rbp
	movq	%rsp, %rbp
	movq	%rdi, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -8(%rbp)
	movq	$0, -24(%rbp)
	movq	$0, -16(%rbp)
	jmp	.L2
.L3:
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	-16(%rbp), %rdx
	salq	$2, %rdx
	addq	%rdx, %rax
	movl	(%rax), %eax
	cltq
	addq	%rax, -24(%rbp)
	addq	$1, -16(%rbp)
.L2:
	movq	-8(%rbp), %rax
	movq	8(%rax), %rax
	cmpq	%rax, -16(%rbp)
	jb	.L3
	nop
	nop
	popq	%rbp
	ret
	.size	kullanilmayan_dongu, .-kullanilmayan_dongu
	.globl	kullanilan_dongu
	.type	kullanilan_dongu, @function
kullanilan_dongu:
	endbr64
	pushq	%rbp
	movq	%rsp, %rbp
	movq	%rdi, -40(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -8(%rbp)
	movq	$0, -24(%rbp)
	movq	$0, -16(%rbp)
	jmp	.L5
.L6:
	movq	-8(%rbp), %rax
	movq	(%rax), %rax
	movq	-16(%rbp), %rdx
	salq	$2, %rdx
	addq	%rdx, %rax
	movl	(%rax), %eax
	cltq
	addq	%rax, -24(%rbp)
	addq	$1, -16(%rbp)
.L5:
	movq	-8(%rbp), %rax
	movq	8(%rax), %rax
	cmpq	%rax, -16(%rbp)
	jb	.L6
	movq	-24(%rbp), %rax
	movq	%rax, sonuc_yeri(%rip)
	nop
	popq	%rbp
	ret
	.size	kullanilan_dongu, .-kullanilan_dongu
	.section	.rodata
	.align 8
.LC0:
	.string	"Kullan\304\261m: %s [n]   (1 <= n <= 100000000)\n"
.LC1:
	.string	"Bellek yetersiz\n"
	.align 8
.LC2:
	.string	"n = %ld, tohum = 42, de\304\237erler 0..99\n"
	.align 8
.LC3:
	.string	"Sonucu kullan\304\261lan d\303\266ng\303\274   : toplam = %lld\n"
	.align 8
.LC4:
	.string	"Sonucu kullan\304\261lmayan d\303\266ng\303\274: sonu\303\247 hi\303\247bir yere yaz\304\261lmad\304\261"
	.align 8
.LC5:
	.string	"S\303\274reler stderr'de: -O0 ve -O2 ile derleyip kar\305\237\304\261la\305\237t\304\261r\304\261n."
	.align 8
.LC8:
	.string	"kullan\304\261lmayan: %12.6f ms (eleman ba\305\237\304\261na %9.4f ns)\n"
	.align 8
.LC9:
	.string	"kullan\304\261lan   : %12.6f ms (eleman ba\305\237\304\261na %9.4f ns)\n"
	.align 8
.LC11:
	.string	"UYARI: kullan\304\261lmayan d\303\266ng\303\274 eleman ba\305\237\304\261na 0,05 ns'den k\304\261sa s\303\274rd\303\274: d\303\266ng\303\274 b\303\274y\303\274k olas\304\261l\304\261kla S\304\260L\304\260ND\304\260.\n"
	.text
	.globl	main
	.type	main, @function
main:
	endbr64
	pushq	%rbp
	movq	%rsp, %rbp
	subq	$80, %rsp
	movl	%edi, -68(%rbp)
	movq	%rsi, -80(%rbp)
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movq	$1000000, -64(%rbp)
	cmpl	$2, -68(%rbp)
	jle	.L8
	movq	-80(%rbp), %rax
	movq	(%rax), %rdx
	movq	stderr(%rip), %rax
	leaq	.LC0(%rip), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	movl	$0, %eax
	call	fprintf@PLT
	movl	$2, %eax
	jmp	.L16
.L8:
	cmpl	$2, -68(%rbp)
	jne	.L10
	movq	-80(%rbp), %rax
	addq	$8, %rax
	movq	(%rax), %rax
	leaq	-32(%rbp), %rcx
	movl	$10, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	strtol@PLT
	movq	%rax, -64(%rbp)
	movq	-80(%rbp), %rax
	addq	$8, %rax
	movq	(%rax), %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	je	.L11
	movq	-32(%rbp), %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	jne	.L11
	cmpq	$0, -64(%rbp)
	jle	.L11
	cmpq	$100000000, -64(%rbp)
	jle	.L10
.L11:
	movq	-80(%rbp), %rax
	movq	(%rax), %rdx
	movq	stderr(%rip), %rax
	leaq	.LC0(%rip), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	movl	$0, %eax
	call	fprintf@PLT
	movl	$2, %eax
	jmp	.L16
.L10:
	movq	-64(%rbp), %rax
	salq	$2, %rax
	movq	%rax, %rdi
	call	malloc@PLT
	movq	%rax, -56(%rbp)
	cmpq	$0, -56(%rbp)
	jne	.L13
	movq	stderr(%rip), %rax
	movq	%rax, %rcx
	movl	$16, %edx
	movl	$1, %esi
	leaq	.LC1(%rip), %rax
	movq	%rax, %rdi
	call	fwrite@PLT
	movl	$1, %eax
	jmp	.L16
.L13:
	movl	$42, %edi
	call	rastgele_tohum@PLT
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movl	$99, %ecx
	movl	$0, %edx
	movq	%rax, %rdi
	call	rastgele_dizi@PLT
	movq	-56(%rbp), %rax
	movq	%rax, -32(%rbp)
	movq	-64(%rbp), %rax
	movq	%rax, -24(%rbp)
	leaq	-32(%rbp), %rax
	movl	$5, %edx
	movq	%rax, %rsi
	leaq	kullanilmayan_dongu(%rip), %rax
	movq	%rax, %rdi
	call	olc_ortanca@PLT
	movq	%xmm0, %rax
	movq	%rax, -48(%rbp)
	leaq	-32(%rbp), %rax
	movl	$5, %edx
	movq	%rax, %rsi
	leaq	kullanilan_dongu(%rip), %rax
	movq	%rax, %rdi
	call	olc_ortanca@PLT
	movq	%xmm0, %rax
	movq	%rax, -40(%rbp)
	movq	-64(%rbp), %rax
	movq	%rax, %rsi
	leaq	.LC2(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	movq	sonuc_yeri(%rip), %rax
	movq	%rax, %rsi
	leaq	.LC3(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	leaq	.LC4(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	leaq	.LC5(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	movsd	-48(%rbp), %xmm1
	movsd	.LC6(%rip), %xmm0
	mulsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	-64(%rbp), %xmm1
	movapd	%xmm0, %xmm2
	divsd	%xmm1, %xmm2
	movsd	-48(%rbp), %xmm1
	movsd	.LC7(%rip), %xmm0
	mulsd	%xmm0, %xmm1
	movq	%xmm1, %rdx
	movq	stderr(%rip), %rax
	movapd	%xmm2, %xmm1
	movq	%rdx, %xmm0
	leaq	.LC8(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	movl	$2, %eax
	call	fprintf@PLT
	movsd	-40(%rbp), %xmm1
	movsd	.LC6(%rip), %xmm0
	mulsd	%xmm1, %xmm0
	pxor	%xmm1, %xmm1
	cvtsi2sdq	-64(%rbp), %xmm1
	movapd	%xmm0, %xmm2
	divsd	%xmm1, %xmm2
	movsd	-40(%rbp), %xmm1
	movsd	.LC7(%rip), %xmm0
	mulsd	%xmm0, %xmm1
	movq	%xmm1, %rdx
	movq	stderr(%rip), %rax
	movapd	%xmm2, %xmm1
	movq	%rdx, %xmm0
	leaq	.LC9(%rip), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	movl	$2, %eax
	call	fprintf@PLT
	movsd	-48(%rbp), %xmm1
	movsd	.LC6(%rip), %xmm0
	mulsd	%xmm1, %xmm0
	pxor	%xmm2, %xmm2
	cvtsi2sdq	-64(%rbp), %xmm2
	divsd	%xmm2, %xmm0
	movapd	%xmm0, %xmm1
	movsd	.LC10(%rip), %xmm0
	comisd	%xmm1, %xmm0
	jbe	.L14
	movq	stderr(%rip), %rax
	movq	%rax, %rcx
	movl	$114, %edx
	movl	$1, %esi
	leaq	.LC11(%rip), %rax
	movq	%rax, %rdi
	call	fwrite@PLT
.L14:
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	free@PLT
	movl	$0, %eax
.L16:
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L17
	call	__stack_chk_fail@PLT
.L17:
	leave
	ret
	.size	main, .-main
	.section	.rodata
	.align 8
.LC6:
	.long	0
	.long	1104006501
	.align 8
.LC7:
	.long	0
	.long	1083129856
	.align 8
.LC10:
	.long	-1717986918
	.long	1068079513
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:

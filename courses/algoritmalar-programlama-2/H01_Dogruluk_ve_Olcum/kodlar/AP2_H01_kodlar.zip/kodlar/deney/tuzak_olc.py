#!/usr/bin/env python3
"""tuzak_olc.py — AP-2 Hafta 1 · Örnek 12'nin (ölçüm tuzağı) ölçümü

Amaç    : H01_12_olcum_tuzagi'nı C ve C++'ta -O0 ve -O2 ile derler, her
          yapılandırmayı birkaç kez çalıştırır; "sonucu kullanılmayan" ve
          "sonucu kullanılan" döngünün sürelerini stderr'den okur. Ayrıca
          derleyicinin ürettiği assembly'yi (gcc -S, objdump -d) ve CPython
          bayt kodunu (dis) kaydeder — Kaputun Altında için kanıt.
Çıktılar: sonuclar/h01_12_olcum_tuzagi.csv       (her çalıştırma)
          sonuclar/h01_12_olcum_tuzagi_ozet.csv  (yapılandırma başına ortanca)
          H01_12_olcum_tuzagi_O0.s, H01_12_olcum_tuzagi_O2.s (tam gcc -S)
          H01_12_asm_ozet.txt   (iki döngü fonksiyonu, -O0 / -O2, objdump)
          H01_12_dis_python.txt (CPython bayt kodu: dis)
Kullanım: python3 tuzak_olc.py [--n 1000000] [--calistirma 5]
"""

import argparse
import dis
import io
import os
import platform
import re
import shutil
import statistics
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True   # kodlar/python altında __pycache__ oluşmasın
KOK = os.path.dirname(os.path.abspath(__file__))
KODLAR = os.path.dirname(KOK)
SON = os.path.join(KOK, "sonuclar")
C_DIR = os.path.join(KODLAR, "c")
CPP_DIR = os.path.join(KODLAR, "cpp")
PY_DIR = os.path.join(KODLAR, "python")
STEM = "H01_12_olcum_tuzagi"
DESEN = re.compile(r"kullanılmayan:\s+([0-9.]+) ms.*\n"
                   r"kullanılan\s+:\s+([0-9.]+) ms")


def derle(gecici):
    yap = {}
    for opt in ("-O0", "-O2"):
        ikili = os.path.join(gecici, f"c{opt}")
        k = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic", opt,
             f"{STEM}.c", "ortak_rastgele.c", "zamanlayici.c", "-o", ikili]
        p = subprocess.run(k, cwd=C_DIR, capture_output=True, text=True)
        if p.returncode or p.stderr.strip():
            sys.exit(p.stderr)
        yap[("C", opt[1:])] = [ikili]
        ikili = os.path.join(gecici, f"cpp{opt}")
        k = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic", opt,
             f"{STEM}.cpp", "-o", ikili]
        p = subprocess.run(k, cwd=CPP_DIR, capture_output=True, text=True)
        if p.returncode or p.stderr.strip():
            sys.exit(p.stderr)
        yap[("C++", opt[1:])] = [ikili]
    yap[("Python", "CPython")] = [sys.executable,
                                  os.path.join(PY_DIR, f"{STEM}.py")]
    return yap


def fonksiyon_govdesi(metin, ad):
    """gcc -S çıktısından bir fonksiyonun etiketinden .size'a kadar."""
    satirlar = metin.split("\n")
    bas = satirlar.index(f"{ad}:")
    govde = []
    for s in satirlar[bas:]:
        st = s.strip()
        if st.startswith(".size"):
            break
        if st.startswith(".") and not st.startswith(".L") or \
                st.startswith(".LF") or st.startswith(".cfi"):
            continue
        govde.append(s.replace("\t", "    ").rstrip())
    return govde


def asm_kaydet(gecici):
    ozet = [f"gcc --version: " + subprocess.run(
        ["gcc", "--version"], capture_output=True,
        text=True).stdout.split("\n")[0], ""]
    for opt in ("-O0", "-O2"):
        hedef = os.path.join(KOK, f"{STEM}{opt.replace('-', '_')}.s")
        k = ["gcc", "-std=c17", opt, "-S", "-fno-asynchronous-unwind-tables",
             f"{STEM}.c", "-o", hedef]
        subprocess.run(k, cwd=C_DIR, check=True)
        metin = open(hedef, encoding="utf-8").read()
        for fonk in ("kullanilmayan_dongu", "kullanilan_dongu"):
            ozet.append(f"$ gcc -std=c17 {opt} -S "
                        f"-fno-asynchronous-unwind-tables {STEM}.c"
                        f"   # {fonk}")
            ozet += fonksiyon_govdesi(metin, fonk)
            ozet.append("")
    # objdump: -O2 ile derlenmiş ikilinin makine kodu (adres + komut)
    ikili = os.path.join(gecici, "c-O2")
    for fonk in ("kullanilmayan_dongu", "kullanilan_dongu"):
        p = subprocess.run(["objdump", "-d", "--no-show-raw-insn",
                            f"--disassemble={fonk}", ikili],
                           capture_output=True, text=True)
        satirlar = [s for s in p.stdout.split("\n")
                    if re.match(r"\s+[0-9a-f]+:", s) or s.endswith(">:")]
        ozet.append(f"$ objdump -d --no-show-raw-insn --disassemble={fonk} "
                    f"{STEM}   (-O2)")
        ozet += [s.replace("\t", "    ").rstrip() for s in satirlar]
        ozet.append("")
    with open(os.path.join(KOK, "H01_12_asm_ozet.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(ozet).rstrip() + "\n")


def dis_kaydet():
    sys.path.insert(0, PY_DIR)
    modul = __import__(STEM)
    tampon = io.StringIO()
    tampon.write(f"Python {platform.python_version()} "
                 f"({platform.python_implementation()}) — dis.dis çıktısı; "
                 "bayt kodu sürüme göre değişir (3.10'da BINARY_ADD/"
                 "INPLACE_ADD, 3.11+'da BINARY_OP).\n\n")
    for ad in ("kullanilmayan_dongu", "kullanilan_dongu"):
        tampon.write(f">>> dis.dis({ad})\n")
        dis.dis(getattr(modul, ad), file=tampon)
        tampon.write("\n")
    with open(os.path.join(KOK, "H01_12_dis_python.txt"), "w",
              encoding="utf-8") as f:
        f.write(tampon.getvalue().rstrip() + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1000000)
    ap.add_argument("--calistirma", type=int, default=5)
    a = ap.parse_args()
    os.makedirs(SON, exist_ok=True)
    gecici = tempfile.mkdtemp(prefix="h01_tuzak_")
    yap = derle(gecici)
    satirlar = []
    for c in range(1, a.calistirma + 1):          # dönüşümlü çalıştır
        for (dil, derleme), komut in yap.items():
            if dil == "Python" and c > 3:          # Python: 3 çalıştırma
                continue
            p = subprocess.run(komut + [str(a.n)], capture_output=True,
                               text=True)
            m = DESEN.search(p.stderr)
            if p.returncode or not m:
                sys.exit(f"Hata: {komut}\n{p.stderr}")
            satirlar.append((dil, derleme, c, float(m.group(1)),
                             float(m.group(2))))
            print(f"{dil:6s} {derleme:7s} #{c}: kullanılmayan "
                  f"{m.group(1)} ms, kullanılan {m.group(2)} ms")
    with open(os.path.join(SON, "h01_12_olcum_tuzagi.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;derleme;n;calistirma;kullanilmayan_ms;kullanilan_ms\n")
        for dil, derleme, c, bos, dolu in satirlar:
            f.write(f"{dil};{derleme};{a.n};{c};{bos:.6f};{dolu:.6f}\n")
    with open(os.path.join(SON, "h01_12_olcum_tuzagi_ozet.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;derleme;n;calistirma_sayisi;kullanilmayan_ms;"
                "kullanilan_ms;kullanilmayan_ns_eleman;kullanilan_ns_eleman\n")
        for (dil, derleme) in yap:
            bos = [s[3] for s in satirlar if s[:2] == (dil, derleme)]
            dolu = [s[4] for s in satirlar if s[:2] == (dil, derleme)]
            mb, md = statistics.median(bos), statistics.median(dolu)
            f.write(f"{dil};{derleme};{a.n};{len(bos)};{mb:.6f};{md:.6f};"
                    f"{mb * 1e6 / a.n:.4f};{md * 1e6 / a.n:.4f}\n")
    asm_kaydet(gecici)
    dis_kaydet()
    shutil.rmtree(gecici, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())

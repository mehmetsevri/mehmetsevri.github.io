	.file	"H01_12_olcum_tuzagi.c"
	.text
	.p2align 4
	.globl	kullanilmayan_dongu
	.type	kullanilmayan_dongu, @function
kullanilmayan_dongu:
	endbr64
	ret
	.size	kullanilmayan_dongu, .-kullanilmayan_dongu
	.p2align 4
	.globl	kullanilan_dongu
	.type	kullanilan_dongu, @function
kullanilan_dongu:
	endbr64
	movq	8(%rdi), %rdx
	testq	%rdx, %rdx
	je	.L6
	movq	(%rdi), %rax
	leaq	(%rax,%rdx,4), %rsi
	xorl	%edx, %edx
	.p2align 4,,10
	.p2align 3
.L5:
	movslq	(%rax), %rcx
	addq	$4, %rax
	addq	%rcx, %rdx
	cmpq	%rsi, %rax
	jne	.L5
	movq	%rdx, sonuc_yeri(%rip)
	ret
	.p2align 4,,10
	.p2align 3
.L6:
	xorl	%edx, %edx
	movq	%rdx, sonuc_yeri(%rip)
	ret
	.size	kullanilan_dongu, .-kullanilan_dongu
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC0:
	.string	"Kullan\304\261m: %s [n]   (1 <= n <= 100000000)\n"
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC1:
	.string	"Bellek yetersiz\n"
	.section	.rodata.str1.8
	.align 8
.LC2:
	.string	"n = %ld, tohum = 42, de\304\237erler 0..99\n"
	.align 8
.LC3:
	.string	"Sonucu kullan\304\261lan d\303\266ng\303\274   : toplam = %lld\n"
	.align 8
.LC4:
	.string	"Sonucu kullan\304\261lmayan d\303\266ng\303\274: sonu\303\247 hi\303\247bir yere yaz\304\261lmad\304\261\n"
	.align 8
.LC5:
	.string	"S\303\274reler stderr'de: -O0 ve -O2 ile derleyip kar\305\237\304\261la\305\237t\304\261r\304\261n.\n"
	.align 8
.LC8:
	.string	"kullan\304\261lmayan: %12.6f ms (eleman ba\305\237\304\261na %9.4f ns)\n"
	.align 8
.LC9:
	.string	"kullan\304\261lan   : %12.6f ms (eleman ba\305\237\304\261na %9.4f ns)\n"
	.align 8
.LC11:
	.string	"UYARI: kullan\304\261lmayan d\303\266ng\303\274 eleman ba\305\237\304\261na 0,05 ns'den k\304\261sa s\303\274rd\303\274: d\303\266ng\303\274 b\303\274y\303\274k olas\304\261l\304\261kla S\304\260L\304\260ND\304\260.\n"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
	endbr64
	pushq	%r12
	pushq	%rbp
	movq	%rsi, %rbp
	pushq	%rbx
	subq	$64, %rsp
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	cmpl	$2, %edi
	jg	.L22
	movl	$1000000, %ebx
	je	.L23
.L11:
	leaq	0(,%rbx,4), %rdi
	call	malloc@PLT
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.L24
	movl	$42, %edi
	leaq	32(%rsp), %r12
	call	rastgele_tohum@PLT
	movl	$99, %ecx
	xorl	%edx, %edx
	movq	%rbx, %rsi
	movq	%rbp, %rdi
	call	rastgele_dizi@PLT
	movl	$5, %edx
	movq	%r12, %rsi
	leaq	kullanilmayan_dongu(%rip), %rdi
	movq	%rbp, 32(%rsp)
	movq	%rbx, 40(%rsp)
	call	olc_ortanca@PLT
	movl	$5, %edx
	movq	%r12, %rsi
	leaq	kullanilan_dongu(%rip), %rdi
	movsd	%xmm0, 8(%rsp)
	call	olc_ortanca@PLT
	movq	%rbx, %rdx
	movl	$2, %edi
	xorl	%eax, %eax
	leaq	.LC2(%rip), %rsi
	movsd	%xmm0, 24(%rsp)
	call	__printf_chk@PLT
	movq	sonuc_yeri(%rip), %rdx
	leaq	.LC3(%rip), %rsi
	xorl	%eax, %eax
	movl	$2, %edi
	call	__printf_chk@PLT
	leaq	.LC4(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	__printf_chk@PLT
	leaq	.LC5(%rip), %rsi
	movl	$2, %edi
	xorl	%eax, %eax
	call	__printf_chk@PLT
	movsd	8(%rsp), %xmm3
	movsd	.LC6(%rip), %xmm4
	pxor	%xmm5, %xmm5
	cvtsi2sdq	%rbx, %xmm5
	movsd	.LC7(%rip), %xmm0
	movq	stderr(%rip), %rdi
	leaq	.LC8(%rip), %rdx
	mulsd	%xmm3, %xmm4
	movl	$2, %esi
	movl	$2, %eax
	mulsd	%xmm3, %xmm0
	movsd	%xmm5, 16(%rsp)
	divsd	%xmm5, %xmm4
	movapd	%xmm4, %xmm1
	movsd	%xmm4, 8(%rsp)
	call	__fprintf_chk@PLT
	movsd	24(%rsp), %xmm2
	movsd	.LC6(%rip), %xmm1
	leaq	.LC9(%rip), %rdx
	movsd	16(%rsp), %xmm5
	movl	$2, %esi
	movl	$2, %eax
	movsd	.LC7(%rip), %xmm0
	mulsd	%xmm2, %xmm1
	movq	stderr(%rip), %rdi
	mulsd	%xmm2, %xmm0
	divsd	%xmm5, %xmm1
	call	__fprintf_chk@PLT
	movsd	.LC10(%rip), %xmm0
	movsd	8(%rsp), %xmm4
	comisd	%xmm4, %xmm0
	ja	.L25
.L16:
	movq	%rbp, %rdi
	call	free@PLT
	xorl	%eax, %eax
.L8:
	movq	56(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L26
	addq	$64, %rsp
	popq	%rbx
	popq	%rbp
	popq	%r12
	ret
.L25:
	movq	stderr(%rip), %rdi
	leaq	.LC11(%rip), %rdx
	movl	$2, %esi
	xorl	%eax, %eax
	call	__fprintf_chk@PLT
	jmp	.L16
.L23:
	movq	8(%rbp), %rdi
	leaq	32(%rsp), %rsi
	movl	$10, %edx
	call	strtol@PLT
	movq	%rax, %rbx
	movq	8(%rbp), %rax
	cmpb	$0, (%rax)
	je	.L12
	movq	32(%rsp), %rax
	cmpb	$0, (%rax)
	jne	.L12
	leaq	-1(%rbx), %rax
	cmpq	$99999999, %rax
	jbe	.L11
.L12:
	movq	0(%rbp), %rcx
	movq	stderr(%rip), %rdi
	leaq	.LC0(%rip), %rdx
	xorl	%eax, %eax
	movl	$2, %esi
	call	__fprintf_chk@PLT
.L10:
	movl	$2, %eax
	jmp	.L8
.L22:
	movq	(%rsi), %rcx
	movq	stderr(%rip), %rdi
	leaq	.LC0(%rip), %rdx
	movl	$2, %esi
	call	__fprintf_chk@PLT
	jmp	.L10
.L26:
	call	__stack_chk_fail@PLT
.L24:
	movq	stderr(%rip), %rdi
	leaq	.LC1(%rip), %rdx
	movl	$2, %esi
	xorl	%eax, %eax
	call	__fprintf_chk@PLT
	movl	$1, %eax
	jmp	.L8
	.size	main, .-main
	.globl	sonuc_yeri
	.bss
	.align 8
	.type	sonuc_yeri, @object
	.size	sonuc_yeri, 8
sonuc_yeri:
	.zero	8
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC6:
	.long	0
	.long	1104006501
	.align 8
.LC7:
	.long	0
	.long	1083129856
	.align 8
.LC10:
	.long	-1717986918
	.long	1068079513
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:

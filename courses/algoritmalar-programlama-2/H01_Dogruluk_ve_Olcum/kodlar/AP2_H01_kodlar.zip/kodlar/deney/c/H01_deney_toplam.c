/* H01_deney_toplam.c — AP-2 Hafta 1 · Haftanın Deneyi (C)
 * Amaç    : Doğrusal dizi toplamının süresi. Bir "oturum" (bir süreç) =
 *           1 soğuk ölçüm (ısınmasız "tek ölçüm") + K tekrar. Ham süreler
 *           CSV'ye EKLENİR; özet ve grafik deney_calistir.py'dedir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_deney_toplam.c ortak_rastgele.c zamanlayici.c \
 *           -o H01_deney_toplam_O2          (karşılaştırma: -O0 ile de)
 * Çalıştır: ./H01_deney_toplam_O2 --n 1000000 [--tekrar 5] [--oturum 1]
 *               [--derleme O2] [--csv ham.csv]
 * Çıktı   : stdout: n ve toplam (deterministik); süreler stderr ve CSV
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define EN_COK_TEKRAR 101

/* toplam: a[0..n-1] elemanlarının toplamı (Θ(n)); merdivendeki
 * H01_11/H01_13 ile aynı fonksiyon. */
long long toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return s;
}

static void kullanim(const char *ad)
{
    fprintf(stderr, "Kullanım: %s --n N [--tekrar K] [--oturum S] "
                    "[--derleme ETIKET] [--csv dosya]\n"
                    "  N: 1..100000000, K: 1..%d\n", ad, EN_COK_TEKRAR - 1);
}

/* metin -> [alt, ust] aralığında tamsayı; hata: 0 döndürür. */
static int sayi_oku(const char *metin, long alt, long ust, long *sonuc)
{
    char *son;
    long x = strtol(metin, &son, 10);
    if (*metin == '\0' || *son != '\0' || x < alt || x > ust) {
        return 0;
    }
    *sonuc = x;
    return 1;
}

int main(int argc, char *argv[])
{
    long n = 0, tekrar = 5, oturum = 1;
    const char *derleme = "?";
    const char *csv_yolu = NULL;
    for (int i = 1; i < argc; i++) {
        int tamam = i + 1 < argc;
        if (tamam && strcmp(argv[i], "--n") == 0) {
            tamam = sayi_oku(argv[++i], 1, 100000000, &n);
        } else if (tamam && strcmp(argv[i], "--tekrar") == 0) {
            tamam = sayi_oku(argv[++i], 1, EN_COK_TEKRAR - 1, &tekrar);
        } else if (tamam && strcmp(argv[i], "--oturum") == 0) {
            tamam = sayi_oku(argv[++i], 1, 1000000, &oturum);
        } else if (tamam && strcmp(argv[i], "--derleme") == 0) {
            derleme = argv[++i];
        } else if (tamam && strcmp(argv[i], "--csv") == 0) {
            csv_yolu = argv[++i];
        } else {
            tamam = 0;
        }
        if (!tamam) {
            kullanim(argv[0]);
            return 2;
        }
    }
    if (n == 0) {
        kullanim(argv[0]);
        return 2;
    }
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "Bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 0, 99);

    /* olcum 0: soğuk (ısınmasız) tek ölçüm; 1..tekrar: tekrarlar */
    double sure[EN_COK_TEKRAR];
    long long kontrol = 0;
    for (long k = 0; k <= tekrar; k++) {
        double t0 = zaman_sn();
        long long s = toplam(a, (size_t)n);
        sure[k] = zaman_sn() - t0;
        if (k == 0) {
            kontrol = s;
        } else if (s != kontrol) {      /* sonuç kullanılır: silinemez */
            fprintf(stderr, "Hata: tekrarlar farklı toplam verdi\n");
            free(a);
            return 1;
        }
    }
    printf("n = %ld, toplam = %lld\n", n, kontrol);

    FILE *csv = NULL;
    if (csv_yolu != NULL) {
        csv = fopen(csv_yolu, "a");
        if (csv == NULL) {
            fprintf(stderr, "Hata: %s açılamadı\n", csv_yolu);
            free(a);
            return 1;
        }
        if (ftell(csv) == 0) {
            fprintf(csv, "oturum;dil;derleme;yontem;n;olcum;sure_ms;"
                         "toplam\n");
        }
    }
    for (long k = 0; k <= tekrar; k++) {
        fprintf(stderr, "olcum %ld: %.6f ms\n", k, sure[k] * 1e3);
        if (csv != NULL) {
            fprintf(csv, "%ld;C;%s;indis;%ld;%ld;%.6f;%lld\n", oturum,
                    derleme, n, k, sure[k] * 1e3, kontrol);
        }
    }
    if (csv != NULL) {
        fclose(csv);
    }
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::accumulate; Python — sum(a). */

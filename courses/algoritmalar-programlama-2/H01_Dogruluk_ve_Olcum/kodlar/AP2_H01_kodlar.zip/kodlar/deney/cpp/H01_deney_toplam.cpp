/* H01_deney_toplam.cpp — AP-2 Hafta 1 · Haftanın Deneyi (C++)
 * Amaç    : Doğrusal dizi toplamının süresi. Bir "oturum" (bir süreç) =
 *           1 soğuk ölçüm (ısınmasız "tek ölçüm") + K tekrar. Ham süreler
 *           CSV'ye EKLENİR; özet ve grafik deney_calistir.py'dedir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H01_deney_toplam.cpp -o H01_deney_toplam_cpp_O2
 * Çalıştır: ./H01_deney_toplam_cpp_O2 --n 1000000 [--tekrar 5] [--oturum 1]
 *               [--derleme O2] [--csv ham.csv]
 * Çıktı   : stdout: n ve toplam (deterministik); süreler stderr ve CSV
 */
#include <cstddef>
#include <cstdio>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

// toplam: a'nın elemanlarının toplamı (Θ(n)); merdivendeki H01_11/H01_13
// ile aynı fonksiyon.
long long toplam(const std::vector<int>& a)
{
    long long s = 0;
    for (std::size_t i = 0; i < a.size(); i++) {
        s += a[i];
    }
    return s;
}

static void kullanim(const char* ad)
{
    std::cerr << "Kullanım: " << ad << " --n N [--tekrar K] [--oturum S] "
              << "[--derleme ETIKET] [--csv dosya]\n"
              << "  N: 1..100000000, K: 1..100\n";
}

// metin -> [alt, ust] aralığında tamsayı; hata: false döndürür.
static bool sayi_oku(const std::string& metin, long alt, long ust,
                     long& sonuc)
{
    try {
        std::size_t son = 0;
        long x = std::stol(metin, &son);
        if (son != metin.size() || x < alt || x > ust) {
            return false;
        }
        sonuc = x;
        return true;
    } catch (const std::exception&) {
        return false;
    }
}

int main(int argc, char* argv[])
{
    long n = 0, tekrar = 5, oturum = 1;
    std::string derleme = "?";
    std::string csv_yolu;
    for (int i = 1; i < argc; i++) {
        const std::string arg = argv[i];
        bool tamam = i + 1 < argc;
        if (tamam && arg == "--n") {
            tamam = sayi_oku(argv[++i], 1, 100000000, n);
        } else if (tamam && arg == "--tekrar") {
            tamam = sayi_oku(argv[++i], 1, 100, tekrar);
        } else if (tamam && arg == "--oturum") {
            tamam = sayi_oku(argv[++i], 1, 1000000, oturum);
        } else if (tamam && arg == "--derleme") {
            derleme = argv[++i];
        } else if (tamam && arg == "--csv") {
            csv_yolu = argv[++i];
        } else {
            tamam = false;
        }
        if (!tamam) {
            kullanim(argv[0]);
            return 2;
        }
    }
    if (n == 0) {
        kullanim(argv[0]);
        return 2;
    }
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(static_cast<std::size_t>(n), 0, 99);

    // olcum 0: soğuk (ısınmasız) tek ölçüm; 1..tekrar: tekrarlar
    std::vector<double> sure;
    long long kontrol = 0;
    for (long k = 0; k <= tekrar; k++) {
        double t0 = zaman_sn();
        long long s = toplam(a);
        sure.push_back(zaman_sn() - t0);
        if (k == 0) {
            kontrol = s;
        } else if (s != kontrol) {      // sonuç kullanılır: silinemez
            std::cerr << "Hata: tekrarlar farklı toplam verdi\n";
            return 1;
        }
    }
    std::cout << "n = " << n << ", toplam = " << kontrol << "\n";

    std::ofstream csv;
    if (!csv_yolu.empty()) {
        csv.open(csv_yolu, std::ios::app);
        if (!csv) {
            std::cerr << "Hata: " << csv_yolu << " açılamadı\n";
            return 1;
        }
        csv.seekp(0, std::ios::end);
        if (csv.tellp() == 0) {
            csv << "oturum;dil;derleme;yontem;n;olcum;sure_ms;toplam\n";
        }
    }
    for (long k = 0; k <= tekrar; k++) {
        std::fprintf(stderr, "olcum %ld: %.6f ms\n", k,
                     sure[static_cast<std::size_t>(k)] * 1e3);
        if (csv.is_open()) {
            csv << oturum << ";C++;" << derleme << ";indis;" << n << ";" << k
                << ";" << std::fixed << std::setprecision(6)
                << sure[static_cast<std::size_t>(k)] * 1e3 << ";" << kontrol
                << "\n";
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::accumulate; Python — sum(a). */

"""H01_deney_toplam.py — AP-2 Hafta 1 · Haftanın Deneyi (Python)
Amaç    : Doğrusal dizi toplamının süresi. Bir "oturum" (bir süreç) =
          1 soğuk ölçüm (ısınmasız "tek ölçüm") + K tekrar. Ham süreler
          CSV'ye EKLENİR; özet ve grafik deney_calistir.py'dedir.
          --yontem: indis (C ile aynı döngü; ana deney), eleman
          (for x in a), sum (kütüphane; yalnızca karşılaştırma için).
Çalıştır: python3 H01_deney_toplam.py --n 1000000 [--tekrar 5]
              [--oturum 1] [--yontem indis[,eleman,sum]] [--csv ham.csv]
Çıktı   : stdout: n ve toplam (deterministik); süreler stderr ve CSV
"""

import argparse
import os
import sys

from ortak_rastgele import rastgele_dizi, rastgele_tohum
from zamanlayici import zaman_sn


def toplam(a):
    """a'nın elemanlarının toplamı (Θ(n)); C'deki döngünün aynısı."""
    s = 0
    for i in range(len(a)):
        s += a[i]
    return s


def toplam_eleman(a):
    """Aynı algoritma, Python'a özgü yineleme (indis yok)."""
    s = 0
    for x in a:
        s += x
    return s


def toplam_kutuphane(a):
    """Kütüphane karşılığı (C ile yazılmış yerleşik sum); YALNIZCA
    karşılaştırma için ölçülür, algoritmanın yerine geçmez."""
    return sum(a)


YONTEMLER = {"indis": toplam, "eleman": toplam_eleman,
             "sum": toplam_kutuphane}


def main():
    ap = argparse.ArgumentParser(description="Haftanın Deneyi: dizi toplamı")
    ap.add_argument("--n", type=int, required=True)
    ap.add_argument("--tekrar", type=int, default=5)
    ap.add_argument("--oturum", type=int, default=1)
    ap.add_argument("--derleme", default="CPython")
    ap.add_argument("--yontem", default="indis")
    ap.add_argument("--csv")
    try:
        a_ = ap.parse_args()
    except SystemExit as e:          # argparse: --help 0, hatalı kullanım 2
        return e.code
    yontemler = a_.yontem.split(",")
    if (not 1 <= a_.n <= 100000000 or not 1 <= a_.tekrar <= 100
            or any(y not in YONTEMLER for y in yontemler)):
        ap.print_usage(sys.stderr)
        return 2
    rastgele_tohum(42)
    a = rastgele_dizi(a_.n, 0, 99)

    satirlar = []
    for yontem in yontemler:
        f = YONTEMLER[yontem]
        kontrol = None
        for k in range(a_.tekrar + 1):    # k = 0: soğuk tek ölçüm
            t0 = zaman_sn()
            s = f(a)
            sure = zaman_sn() - t0
            if kontrol is None:
                kontrol = s
            elif s != kontrol:
                print("Hata: tekrarlar farklı toplam verdi", file=sys.stderr)
                return 1
            print(f"{yontem} olcum {k}: {sure * 1e3:.6f} ms", file=sys.stderr)
            satirlar.append(f"{a_.oturum};Python;{a_.derleme};{yontem};"
                            f"{a_.n};{k};{sure * 1e3:.6f};{kontrol}\n")
        print(f"n = {a_.n}, toplam = {kontrol}" +
              ("" if yontem == "indis" else f" ({yontem})"))
    if a_.csv:
        try:
            yeni = not os.path.exists(a_.csv) or os.path.getsize(a_.csv) == 0
            with open(a_.csv, "a", encoding="utf-8") as h:
                if yeni:
                    h.write("oturum;dil;derleme;yontem;n;olcum;sure_ms;"
                            "toplam\n")
                h.writelines(satirlar)
        except OSError:
            print(f"Hata: {a_.csv} açılamadı", file=sys.stderr)
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

/* H01_HA1_en_buyuk_sifir_duzeltilmis.c — AP-2 Hafta 1 · Hata Avcısı 1
 * Düzeltilmiş sürüm: başlangıç değeri dizinin İLK elemanı.
 * Neden   : Değişmez "m = max(a[0..i-1])" başlangıçta (i = 1) ancak
 *           m = a[0] ile kurulur; 0 dizinin elemanı olmayabilir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA1_en_buyuk_sifir_duzeltilmis.c \
 *           -o H01_HA1_en_buyuk_sifir_duzeltilmis
 */
#include <stddef.h>
#include <stdio.h>

/* Ön koşul: n >= 1. */
int en_buyuk(const int a[], size_t n)
{
    int m = a[0];               /* DÜZELTME: ilk elemanla başla */
    for (size_t i = 1; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

int main(void)
{
    /* Bir kış sabahı dört istasyonun ölçtüğü sıcaklıklar (°C) */
    const int sicaklik[] = {-8, -3, -12, -5};
    const int puan[] = {45, 72, 60};

    printf("Puanlar     : en yüksek %d\n", en_buyuk(puan, 3));
    printf("Sıcaklıklar : en yüksek %d °C\n", en_buyuk(sicaklik, 4));
    return 0;
}

/* H01_HA2_yanlis_degismez.c — AP-2 Hafta 1 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR.
 * Hata    : Döngü değişmezi yerine yalnızca gövdenin SONUNDA doğru olan
 *           bir ifade döngünün BAŞINDA denetleniyor
 * Belirti : İlk yinelemede (k = 1, s = 0) assert başarısız; program durur
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA2_yanlis_degismez.c -o H01_HA2_yanlis_degismez
 * Düzeltme: H01_HA2_yanlis_degismez_duzeltilmis.c
 */
#include <assert.h>
#include <stdio.h>

/* 1 + 2 + ... + n (n >= 0) */
long long toplam(int n)
{
    long long s = 0;
    for (int k = 1; k <= n; k++) {
        /* HATA: s = k(k+1)/2, "s += k" yapıldıktan SONRA doğrudur;
         * döngünün başında doğru olan s = (k-1)k/2'dir. */
        assert(s == (long long)k * (k + 1) / 2);
        s += k;
    }
    return s;
}

int main(void)
{
    printf("toplam(5) hesaplanıyor...\n");
    fflush(stdout);
    printf("toplam(5) = %lld\n", toplam(5));
    return 0;
}

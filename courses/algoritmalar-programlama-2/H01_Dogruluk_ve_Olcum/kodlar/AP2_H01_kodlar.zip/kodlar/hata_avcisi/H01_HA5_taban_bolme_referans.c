/* H01_HA5_taban_bolme_referans.c — AP-2 Hafta 1 · Hata Avcısı 5 (referans)
 * Amaç    : Python'a çevrilen özgün C fonksiyonu; Python testlerindeki
 *           "beklenen" değerler bu programın çıktısından alınmıştır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA5_taban_bolme_referans.c -o H01_HA5_taban_bolme_referans
 */
#include <stdio.h>

void dk_sn(int fark, int *dk, int *sn)
{
    *dk = fark / 60;
    *sn = fark % 60;
}

int main(void)
{
    const int farklar[] = {125, 60, 0, -125, -30};
    for (int i = 0; i < 5; i++) {
        int dk, sn;
        dk_sn(farklar[i], &dk, &sn);
        printf("dk_sn(%d) = (%d, %d)\n", farklar[i], dk, sn);
    }
    return 0;
}

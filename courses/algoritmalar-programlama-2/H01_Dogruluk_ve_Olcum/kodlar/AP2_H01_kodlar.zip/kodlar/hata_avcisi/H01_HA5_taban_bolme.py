"""H01_HA5_taban_bolme.py — AP-2 Hafta 1 · Hata Avcısı 5
BU DOSYA KASITLI HATA İÇERİR.
Hata    : C'deki / ve % işleçlerinin Python'da // ve % ile birebir aynı
          sonucu verdiği sanılmış (negatif sayılarda farklıdır)
Belirti : Negatif sürelerde C programından farklı dakika/saniye
Çalıştır: python3 H01_HA5_taban_bolme.py
Düzeltme: H01_HA5_taban_bolme_duzeltilmis.py
"""

# C'deki özgün fonksiyon (H01_HA5_taban_bolme_referans.c):
#     void dk_sn(int fark, int *dk, int *sn)
#     {
#         *dk = fark / 60;
#         *sn = fark % 60;
#     }
# Python'a "birebir" çevrildi:


def dk_sn(fark):
    """Saniye cinsinden farkı (dakika, saniye) olarak döndürür."""
    return fark // 60, fark % 60     # HATA: C'nin / ve % kuralı değil


def main():
    # Beklenen değerler C sürümünün çıktısından alındı
    # (hata_avcisi/ciktilar/H01_HA5_taban_bolme_referans.txt).
    testler = [(125, (2, 5)), (60, (1, 0)), (0, (0, 0)),
               (-125, (-2, -5)), (-30, (0, -30))]
    uyusmayan = 0
    for fark, beklenen in testler:
        bulunan = dk_sn(fark)
        if bulunan == beklenen:
            durum = "geçti"
        else:
            durum = "UYUŞMADI"
            uyusmayan += 1
        print(f"dk_sn({fark}) = {bulunan}, C'deki = {beklenen} -> {durum}")
    print(f"{len(testler)} testten {uyusmayan} tanesi uyuşmadı")
    return 1 if uyusmayan else 0


if __name__ == "__main__":
    raise SystemExit(main())

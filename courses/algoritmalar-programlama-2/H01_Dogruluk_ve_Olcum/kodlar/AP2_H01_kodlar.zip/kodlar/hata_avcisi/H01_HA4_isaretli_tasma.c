/* H01_HA4_isaretli_tasma.c — AP-2 Hafta 1 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR (tanımsız davranış).
 * Hata    : İşaretli tamsayı taşmasının "başa sarar" sanılması
 * Belirti : Programcı iki sorguda da "evet" bekler. gcc, 1. sürümü -O0'da
 *           bile "hayır"a indirger; 2. sürüm -O0'da "evet", -O2'de "hayır"
 *           der. UBSan "signed integer overflow" raporlar (C17 §6.5).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 (ve -O2) \
 *           H01_HA4_isaretli_tasma.c -o H01_HA4_isaretli_tasma
 * Düzeltme: H01_HA4_isaretli_tasma_duzeltilmis.c
 */
#include <limits.h>
#include <stdio.h>

/* x'e 1 eklenince taşma olur mu? Varsayım (YANLIŞ): taşarsa sonuç
 * negatife "sarar", dolayısıyla x + 1 < x olur. */
int tasar_mi_1(int x)
{
    return x + 1 < x;           /* HATA: x == INT_MAX ise tanımsız */
}

/* Aynı varsayım, toplama ayrı bir deyimde. */
int tasar_mi_2(int x)
{
    int y = x + 1;              /* HATA: x == INT_MAX ise tanımsız */
    return y < x;
}

int main(void)
{
    int x = INT_MAX;
    printf("x = %d\n", x);
    printf("1. sürüm: x + 1 taşar mı? %s\n", tasar_mi_1(x) ? "evet" : "hayır");
    printf("2. sürüm: x + 1 taşar mı? %s\n", tasar_mi_2(x) ? "evet" : "hayır");
    return 0;
}

"""H01_HA6_rand_deney_duzeltilmis.py — AP-2 Hafta 1 · Hata Avcısı 6
Düzeltilmiş sürüm (Python): ortak LCG modülü ve SABİT tohum (42); C
sürümüyle (H01_HA6_rand_deney_duzeltilmis.c) bayt bayt aynı çıktı.
Çalıştır: python3 H01_HA6_rand_deney_duzeltilmis.py
"""

from ortak_rastgele import rastgele_aralik, rastgele_tohum


def main():
    tohum = 42
    rastgele_tohum(tohum)
    toplam = 0
    print(f"tohum = {tohum}, ilk 5 değer (rastgele_aralik(0, 99)):", end="")
    for i in range(100000):
        x = rastgele_aralik(0, 99)
        if i < 5:
            print(f" {x}", end="")
        toplam += x
    print(f"\n100000 değerin toplamı: {toplam}")


if __name__ == "__main__":
    main()

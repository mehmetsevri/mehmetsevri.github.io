/* H01_HA6_rand_deney.c — AP-2 Hafta 1 · Hata Avcısı 6
 * BU DOSYA KASITLI HATA İÇERİR (tekrarlanamayan deney).
 * Hata    : Deney verisi rand() ile üretiliyor. srand(time(NULL)) her
 *           çalıştırmada başka dizi verir; sabit tohumla bile dizi C
 *           kitaplığına bağlıdır (standart algoritmayı belirlemez, yalnızca
 *           RAND_MAX >= 32767 ister — C17 §7.22.2).
 * Belirti : İki çalıştırma farklı toplam verir; aynı tohum 42 için glibc
 *           ile standardın örnek gerçekleştirimi farklı sayı üretir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA6_rand_deney.c -o H01_HA6_rand_deney
 * Düzeltme: H01_HA6_rand_deney_duzeltilmis.c (+ _duzeltilmis.py)
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* C standardının (C17 §7.22.2.2, "EXAMPLE") verdiği taşınabilir rand
 * örneği: bir C kitaplığı rand()'ı böyle de gerçekleştirebilir
 * (RAND_MAX = 32767). glibc başka bir algoritma kullanır.            */
static unsigned long int ornek_sonraki = 1;

int ornek_rand(void)
{
    ornek_sonraki = ornek_sonraki * 1103515245 + 12345;
    return (unsigned int)(ornek_sonraki / 65536) % 32768;
}

void ornek_srand(unsigned int tohum)
{
    ornek_sonraki = tohum;
}

int main(void)
{
    printf("Bu kitaplıkta RAND_MAX = %d\n", RAND_MAX);

    srand((unsigned)time(NULL));      /* HATA: her çalıştırmada başka tohum */
    long long toplam = 0;
    printf("srand(time(NULL)), ilk 5 değer (rand() %% 100):");
    for (int i = 0; i < 100000; i++) {
        int x = rand() % 100;
        if (i < 5) {
            printf(" %d", x);
        }
        toplam += x;
    }
    printf("\n100000 değerin toplamı: %lld\n", toplam);

    srand(42);                        /* sabit tohum: yalnız bu kitaplıkta */
    printf("srand(42), bu kitaplığın rand()'ı ilk 5:");
    for (int i = 0; i < 5; i++) {
        printf(" %d", rand());
    }
    ornek_srand(42);
    printf("\nsrand(42), standardın örnek rand()'ı ilk 5:");
    for (int i = 0; i < 5; i++) {
        printf(" %d", ornek_rand());
    }
    printf("\n");
    return 0;
}

/* H01_HA6_rand_deney_duzeltilmis.c — AP-2 Hafta 1 · Hata Avcısı 6
 * Düzeltilmiş sürüm: ortak LCG modülü ve SABİT tohum (42). Her
 * çalıştırmada, her platformda ve Python sürümünde (aynı adlı .py)
 * bayt bayt aynı çıktı. Tohum çıktıya yazılır (deney kaydı).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA6_rand_deney_duzeltilmis.c ortak_rastgele.c \
 *           -o H01_HA6_rand_deney_duzeltilmis
 */
#include <stdio.h>

#include "ortak_rastgele.h"

int main(void)
{
    const unsigned tohum = 42;
    rastgele_tohum(tohum);
    long long toplam = 0;
    printf("tohum = %u, ilk 5 değer (rastgele_aralik(0, 99)):", tohum);
    for (int i = 0; i < 100000; i++) {
        int x = rastgele_aralik(0, 99);
        if (i < 5) {
            printf(" %d", x);
        }
        toplam += x;
    }
    printf("\n100000 değerin toplamı: %lld\n", toplam);
    return 0;
}

/* H01_HA1_en_buyuk_sifir.c — AP-2 Hafta 1 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR.
 * Hata    : En büyük eleman aramasında başlangıç değeri 0 seçilmiş
 * Belirti : Tamamı negatif dizide 0 döner (0 dizide yok bile)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA1_en_buyuk_sifir.c -o H01_HA1_en_buyuk_sifir
 * Düzeltme: H01_HA1_en_buyuk_sifir_duzeltilmis.c
 */
#include <stddef.h>
#include <stdio.h>

int en_buyuk(const int a[], size_t n)
{
    int m = 0;                  /* HATA: 0 dizinin bir elemanı değil */
    for (size_t i = 0; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

int main(void)
{
    /* Bir kış sabahı dört istasyonun ölçtüğü sıcaklıklar (°C) */
    const int sicaklik[] = {-8, -3, -12, -5};
    const int puan[] = {45, 72, 60};

    printf("Puanlar     : en yüksek %d\n", en_buyuk(puan, 3));
    printf("Sıcaklıklar : en yüksek %d °C\n", en_buyuk(sicaklik, 4));
    return 0;
}

/* H01_HA3_tek_olcum_duzeltilmis.c — AP-2 Hafta 1 · Hata Avcısı 3
 * Düzeltilmiş sürüm: -O2, 1 ısınma + 11 tekrar, ortanca; en az–en çok
 * aralığı da raporlanır. Sonuç "bu makinede, bu derlemeyle" diye verilir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA3_tek_olcum_duzeltilmis.c ortak_rastgele.c zamanlayici.c \
 *           -o H01_HA3_tek_olcum_duzeltilmis
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define TEKRAR 11

long long toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return s;
}

int main(void)
{
    const size_t n = 100000;
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, n, 0, 99);

    double sure[TEKRAR];
    long long s = toplam(a, n);           /* 1 ısınma */
    for (int k = 0; k < TEKRAR; k++) {
        double t0 = zaman_sn();
        s = toplam(a, n);
        sure[k] = zaman_sn() - t0;
    }
    double orta = ortanca(sure, TEKRAR);  /* sure[] artık sıralı */

    printf("toplam = %lld\n", s);
    fprintf(stderr, "Ortanca %.4f ms (en az %.4f, en çok %.4f; "
                    "1 ısınma + %d tekrar, -O2, bu makinede)\n",
            orta * 1e3, sure[0] * 1e3, sure[TEKRAR - 1] * 1e3, TEKRAR);
    free(a);
    return 0;
}

/* H01_HA2_yanlis_degismez_duzeltilmis.c — AP-2 Hafta 1 · Hata Avcısı 2
 * Düzeltilmiş sürüm: döngü başında (k-1)k/2, gövde sonunda k(k+1)/2.
 * Neden   : Değişmez her yinelemenin BAŞINDA doğru olmalıdır; sonlanmada
 *           (k = n+1) son koşulu verir: s = n(n+1)/2. Gövde sonundaki
 *           ifade ise k = n+1'de (n+1)(n+2)/2 derdi — yanlış.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA2_yanlis_degismez_duzeltilmis.c \
 *           -o H01_HA2_yanlis_degismez_duzeltilmis
 */
#include <assert.h>
#include <stdio.h>

/* 1 + 2 + ... + n (n >= 0) */
long long toplam(int n)
{
    long long s = 0;
    int k = 1;
    for (k = 1; k <= n; k++) {
        assert(s == (long long)(k - 1) * k / 2);   /* değişmez: başta */
        s += k;
        assert(s == (long long)k * (k + 1) / 2);   /* gövde sonunda   */
    }
    assert(s == (long long)(k - 1) * k / 2);       /* sonlanma: k=n+1 */
    return s;
}

int main(void)
{
    printf("toplam(5) hesaplanıyor...\n");
    fflush(stdout);
    printf("toplam(5) = %lld\n", toplam(5));
    return 0;
}

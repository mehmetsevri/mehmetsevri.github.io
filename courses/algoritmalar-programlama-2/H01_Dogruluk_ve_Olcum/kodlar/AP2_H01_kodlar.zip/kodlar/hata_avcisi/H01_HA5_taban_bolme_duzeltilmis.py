"""H01_HA5_taban_bolme_duzeltilmis.py — AP-2 Hafta 1 · Hata Avcısı 5
Düzeltilmiş sürüm: C'nin sıfıra doğru kesen bölmesi tamsayılarla açıkça
yazılır; kalan C'deki gibi a - b * (a / b) ile bulunur.
Not     : int(a / b) de -3 verir ama ondalık bölme yapar: 2**53'ten büyük
          tamsayılarda duyarlık kaybı olabilir; aşağıdaki sürüm kayıpsızdır.
Çalıştır: python3 H01_HA5_taban_bolme_duzeltilmis.py
"""


def bol_sifira_dogru(a, b):
    """C'deki a / b: bölümü sıfıra doğru keser (yalnız tamsayılarla)."""
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q


def dk_sn(fark):
    """Saniye cinsinden farkı C'deki gibi (dakika, saniye) döndürür."""
    dk = bol_sifira_dogru(fark, 60)
    return dk, fark - 60 * dk        # C'deki %: a - b * (a / b)


def main():
    # Beklenen değerler C sürümünün çıktısından alındı
    # (hata_avcisi/ciktilar/H01_HA5_taban_bolme_referans.txt).
    testler = [(125, (2, 5)), (60, (1, 0)), (0, (0, 0)),
               (-125, (-2, -5)), (-30, (0, -30))]
    uyusmayan = 0
    for fark, beklenen in testler:
        bulunan = dk_sn(fark)
        if bulunan == beklenen:
            durum = "geçti"
        else:
            durum = "UYUŞMADI"
            uyusmayan += 1
        print(f"dk_sn({fark}) = {bulunan}, C'deki = {beklenen} -> {durum}")
    print(f"{len(testler)} testten {uyusmayan} tanesi uyuşmadı")
    return 1 if uyusmayan else 0


if __name__ == "__main__":
    raise SystemExit(main())

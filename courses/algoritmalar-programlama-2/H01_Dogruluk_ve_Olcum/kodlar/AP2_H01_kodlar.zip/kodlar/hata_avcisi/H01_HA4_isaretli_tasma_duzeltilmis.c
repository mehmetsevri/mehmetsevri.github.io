/* H01_HA4_isaretli_tasma_duzeltilmis.c — AP-2 Hafta 1 · Hata Avcısı 4
 * Düzeltilmiş sürüm: taşma, işlem YAPILMADAN ÖNCE sınırlarla
 * karşılaştırılarak denetlenir; hiçbir adımda tanımsız davranış yok.
 * Not     : GCC/Clang'da __builtin_add_overflow, C23'te <stdckdint.h>
 *           ckd_add aynı işi görür; işaretsiz türler ise tanımlı sarar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H01_HA4_isaretli_tasma_duzeltilmis.c \
 *           -o H01_HA4_isaretli_tasma_duzeltilmis
 */
#include <limits.h>
#include <stdio.h>

/* x'e 1 eklenince taşma olur mu? Toplamayı yapmadan sına. */
int tasar_mi(int x)
{
    return x == INT_MAX;
}

/* Genel durum: x + y int aralığının dışına çıkar mı? */
int toplam_tasar_mi(int x, int y)
{
    return (y > 0 && x > INT_MAX - y) || (y < 0 && x < INT_MIN - y);
}

int main(void)
{
    int x = INT_MAX;
    printf("x = %d\n", x);
    printf("x + 1 taşar mı? %s\n",
           tasar_mi(x) ? "evet" : "hayır");
    printf("INT_MAX - 5 + 5 taşar mı? %s\n",
           toplam_tasar_mi(INT_MAX - 5, 5) ? "evet" : "hayır");
    printf("INT_MAX - 5 + 6 taşar mı? %s\n",
           toplam_tasar_mi(INT_MAX - 5, 6) ? "evet" : "hayır");
    printf("INT_MIN + (-1) taşar mı? %s\n",
           toplam_tasar_mi(INT_MIN, -1) ? "evet" : "hayır");
    return 0;
}

/* H01_HA3_tek_olcum.c — AP-2 Hafta 1 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR (ölçüm yöntemi hatası).
 * Hata    : Süre TEK ölçümle (ısınmasız) ve -O0 ile ölçülüp genelleniyor
 * Belirti : Her çalıştırmada başka süre; -O2 ile birkaç kat farklı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H01_HA3_tek_olcum.c ortak_rastgele.c zamanlayici.c \
 *           -o H01_HA3_tek_olcum                        (HATA: -O0)
 * Düzeltme: H01_HA3_tek_olcum_duzeltilmis.c
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

long long toplam(const int a[], size_t n)
{
    long long s = 0;
    for (size_t i = 0; i < n; i++) {
        s += a[i];
    }
    return s;
}

int main(void)
{
    const size_t n = 100000;
    int *a = malloc(n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, n, 0, 99);

    double t0 = zaman_sn();
    long long s = toplam(a, n);           /* HATA: tek ölçüm */
    double t = zaman_sn() - t0;

    printf("toplam = %lld\n", s);
    fprintf(stderr, "Ölçülen süre: %.4f ms  =>  \"toplam, 100000 elemanı "
                    "her zaman %.4f ms'de toplar\" (HATALI GENELLEME)\n",
            t * 1e3, t * 1e3);
    free(a);
    return 0;
}

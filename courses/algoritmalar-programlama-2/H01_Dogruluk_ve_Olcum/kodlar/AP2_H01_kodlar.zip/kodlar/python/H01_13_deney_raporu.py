"""H01_13_deney_raporu.py — AP-2 Hafta 1 · Örnek 13 (★★★)
Amaç    : Deney raporu: dizi toplamı için n'e karşı süre tablosu;
          --csv ile süreler CSV dosyasına yazılır (grafik için)
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_13_deney_raporu.py [--nmax N] [--csv dosya.csv]
Eşleri  : c/H01_13_deney_raporu.c · cpp/H01_13_deney_raporu.cpp
Çıktı   : üç dilde aynı (=) — süreler stderr'e ve CSV'ye yazılır
"""

import sys

from ortak_rastgele import rastgele_dizi, rastgele_tohum
from zamanlayici import olc_ortanca

TEKRAR = 5
DERLEME = "CPython"   # Python'da derleme düzeyi yok; yorumlayıcının adı


def toplam(a):
    """a'nın elemanlarının toplamı (Θ(n))."""
    s = 0
    for i in range(len(a)):
        s += a[i]
    return s


def kullanim(ad):
    print(f"Kullanım: {ad} [--nmax N] [--csv dosya.csv]\n"
          "  N: 1000 .. 100000000 (varsayılan 100000)", file=sys.stderr)


def main():
    nmax = 100000
    csv_yolu = None
    i = 1
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg == "--nmax" and i + 1 < len(sys.argv):
            i += 1
            try:
                nmax = int(sys.argv[i])
            except ValueError:
                nmax = 0
            if nmax < 1000 or nmax > 100000000:
                kullanim(sys.argv[0])
                return 2
        elif arg == "--csv" and i + 1 < len(sys.argv):
            i += 1
            csv_yolu = sys.argv[i]
        else:
            kullanim(sys.argv[0])
            return 2
        i += 1
    csv = None
    if csv_yolu is not None:
        try:
            csv = open(csv_yolu, "w", encoding="utf-8")
        except OSError:
            print(f"Hata: {csv_yolu} açılamadı", file=sys.stderr)
            return 1
        csv.write("n;dil;derleme;tekrar;ortanca_ms;toplam\n")

    print("Deney: dizi toplamı (Θ(n)), tohum 42, değerler 0..99")
    print(f"Düzen: 1 ısınma + {TEKRAR} tekrar, ortanca (süreler stderr/CSV)")
    print(f"{'n':>10} {'toplam':>14} {'ortalama':>10}")
    onceki = 0.0
    n = 1000
    while n <= nmax:
        rastgele_tohum(42)
        a = rastgele_dizi(n, 0, 99)
        sonuc = 0

        def gorev():
            nonlocal sonuc
            sonuc = toplam(a)

        t = olc_ortanca(gorev, TEKRAR)
        print(f"{n:10d} {sonuc:14d} {sonuc / n:10.4f}")
        satir = f"n = {n:9d}: ortanca {t * 1e3:10.4f} ms"
        if onceki > 0.0:
            satir += f"   T(n)/T(n/10) = {t / onceki:.2f}"
        print(satir, file=sys.stderr)
        if csv is not None:
            csv.write(f"{n};Python;{DERLEME};{TEKRAR};{t * 1e3:.6f};"
                      f"{sonuc}\n")
        onceki = t
        n *= 10
    if csv is not None:
        csv.close()
        print(f"CSV yazıldı: {csv_yolu}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (CSV elle yazılır); C++ — yok (std::ofstream);
# Python — csv modülü (csv.writer(f, delimiter=";")); grafik için ayrı
# betik: gorseller/kaynak/ (matplotlib, örnek kodun parçası değil).

"""H01_05_oklid_ebob.py — AP-2 Hafta 1 · Örnek 5 (★★)
Amaç    : Öklid algoritmasıyla EBOB; sonlanma kanıtı: b her adımda
          kesin azalır ve 0'ın altına inemez
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_05_oklid_ebob.py
Eşleri  : c/H01_05_oklid_ebob.c · cpp/H01_05_oklid_ebob.cpp
Çıktı   : üç dilde aynı (=)
"""

adim_sayisi = 0  # döngü adımı (mod işlemi) sayacı


# ebob: a ve b'nin en büyük ortak böleni (Öklid algoritması).
# Ön koşul : a >= 0, b >= 0 ve ikisi birden 0 değil.
# Son koşul: dönen d hem a'yı hem b'yi böler ve ortak bölenlerin
#            en büyüğüdür.
# Değişmez : ebob(a, b) döngü boyunca aynı kalır, çünkü
#            ebob(a, b) = ebob(b, a mod b).
# Sonlanma : b >= 0 ve her adımda kesin azalır (0 <= a % b < b);
#            negatif olmayan tamsayılar sonsuza dek azalamaz.
def ebob(a, b):
    """Öklid algoritmasıyla ebob(a, b)."""
    global adim_sayisi
    adim_sayisi = 0
    while b != 0:
        a, b = b, a % b
        adim_sayisi += 1
    return a


def ebob_izle(a, b):
    """Her adımda a, b ve a % b değerlerini yazdırır."""
    print(f"ebob({a}, {b}) izlemesi (b her adımda kesin azalır):")
    while b != 0:
        print(f"  a = {a:4d}   b = {b:4d}   a % b = {a % b:4d}")
        a, b = b, a % b
    print(f"  a = {a:4d}   b = {b:4d}   -> b = 0, sonuç: {a}")


def main():
    # Son iki çift ardışık Fibonacci sayılarıdır (F11, F10) ve
    # (F30, F29): Öklid'in en kötü durumu.
    ciftler = [
        (252, 105), (1071, 462), (55, 89), (17, 0), (0, 9),
        (1000000, 999999), (89, 55), (832040, 514229)
    ]

    ebob_izle(252, 105)
    print("\n        a         b     ebob  adım")
    for a, b in ciftler:
        d = ebob(a, b)
        print(f"{a:9d} {b:9d} {d:8d} {adim_sayisi:5d}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::gcd (<numeric>, C++17);
# Python — math.gcd(a, b).

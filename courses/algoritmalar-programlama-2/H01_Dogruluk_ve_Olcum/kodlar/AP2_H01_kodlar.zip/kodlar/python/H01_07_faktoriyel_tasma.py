"""H01_07_faktoriyel_tasma.py — AP-2 Hafta 1 · Örnek 7 (★★)
Amaç    : 13! hesabı: Python int'i keyfi duyarlıklıdır, taşmaz; C'deki
          uint32_t / uint64_t sarması & maskesiyle taklit edilir
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_07_faktoriyel_tasma.py
Eşleri  : c/H01_07_faktoriyel_tasma.c · cpp/H01_07_faktoriyel_tasma.cpp
Çıktı   : Δ — C ve C++ aynı, Python farklı; bkz. Dil Penceresi
"""

MASKE32 = 0xFFFFFFFF   # 2**32 - 1: uint32_t taklidi için
MASKE64 = 2**64 - 1    # uint64_t taklidi için


def main():
    f = 1      # Python int: sınırsız büyüklük (bellek yettikçe)
    f32 = 1    # & MASKE32 ile 2^32 modunda tutulan taklit

    print("Python: int keyfi duyarlıklıdır (taşma yok)")
    print(" n           int  & 0xFFFFFFFF")
    for n in range(1, 14):
        f *= n
        f32 = (f32 * n) & MASKE32      # C'deki uint32_t sarması
        isaret = "" if f32 == f else "  <- 32 bit taklidi sardı"
        print(f"{n:2d} {f:13d} {f32:13d}{isaret}")
    print(f"13! mod 2^32 = {f} - {1 << 32} = {f32}")
    for n in range(14, 22):
        f *= n
        if n == 20:
            print(f"20! = {f}")
    print(f"21! = {f}  (sarma yok: keyfi duyarlık)")
    print(f"21! & (2**64 - 1) = {f & MASKE64}  (uint64_t taklidi)")
    print(f"21! için gereken bit sayısı: {f.bit_length()}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — standart faktöriyel yok; tgamma(n + 1.0)
# (<math.h>) double verir (yaklaşık); C++ — std::tgamma; Python —
# math.factorial(n) (tam değer).

"""H01_10_ikinci_en_buyuk.py — AP-2 Hafta 1 · Örnek 10 (★★★)
Amaç    : Tek geçişli ikinci en büyük; sıralama tabanlı kâhinle
          rastgele karşılaştırmalı test ve stres testi.
          ikinci_en_buyuk_hatali KASITLI HATA İÇERİR (testi sınamak için).
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_10_ikinci_en_buyuk.py
Eşleri  : c/H01_10_ikinci_en_buyuk.c · cpp/H01_10_ikinci_en_buyuk.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum

MAKS_N = 12


# ikinci_en_buyuk: tek geçişte ikinci en büyük eleman.
# Ön koşul : len(a) >= 2.
# Son koşul: liste azalan sıralansaydı 1. konumda (0'dan) duracak değer.
#            Eşitlik: en büyük birden çok kez geçiyorsa ikinci en büyük
#            de odur ([7, 3, 7] -> 7).
# Değişmez : döngü başında b1 >= b2 ve b1, b2 a[0..i-1]'in en büyük
#            iki elemanıdır (yinelenenler ayrı sayılır).
def ikinci_en_buyuk(a):
    """Tek geçişte ikinci en büyük eleman."""
    b1, b2 = a[0], a[1]
    if b2 > b1:
        b1, b2 = b2, b1
    for i in range(2, len(a)):
        if a[i] > b1:
            b2 = b1
            b1 = a[i]
        elif a[i] > b2:
            b2 = a[i]
    return b2


def ikinci_en_buyuk_hatali(a):
    """KASITLI HATA — "elif" dalı unutulmuş.

    b2 < a[i] <= b1 olan eleman b2'yi güncellemez. Test düzeneğinin
    hatayı yakalayabildiğini sınamak için kullanılır.
    """
    b1, b2 = a[0], a[1]
    if b2 > b1:
        b1, b2 = b2, b1
    for i in range(2, len(a)):
        if a[i] > b1:
            b2 = b1
            b1 = a[i]
        # HATA: elif a[i] > b2 dalı eksik
    return b2


def kahin(a):
    """Yavaş ama apaçık doğru — sırala, sondan ikinciyi al.

    Θ(n log n); sorted yalnızca kâhinde serbesttir.
    """
    return sorted(a)[len(a) - 2]


def dizi_metni(a):
    """a listesini "[x, y, ...]" biçiminde metne çevirir."""
    return "[" + ", ".join(str(x) for x in a) + "]"


def karsilastirmali_test(f, ad, deneme, alt, ust):
    """f'yi kâhine karşı deneme kez sınar (n = 2..MAKS_N, değerler
    [alt, ust], tohum 2027). İlk uyuşmazlığı yazdırır; uyuşmazlık
    sayısını döndürür."""
    uyusmazlik = 0
    rastgele_tohum(2027)
    for t in range(1, deneme + 1):
        n = rastgele_aralik(2, MAKS_N)
        a = rastgele_dizi(n, alt, ust)
        beklenen = kahin(a)
        bulunan = f(a)
        if beklenen != bulunan:
            uyusmazlik += 1
            if uyusmazlik == 1:
                print(f"  ilk uyuşmazlık (deneme {t}): {dizi_metni(a)}"
                      f" -> kâhin {beklenen}, bulunan {bulunan}")
    print(f"  {ad}, değerler [{alt}, {ust}]: {deneme} deneme, "
          f"{uyusmazlik} uyuşmazlık")
    return uyusmazlik


def main():
    sinir = [
        [5, 9], [9, 5], [7, 7], [7, 3, 7], [1, 2, 3, 4], [4, 3, 2, 1],
        [-5, -5, -9]
    ]

    print("1) Sınır durumları (n = 2, eşitlik, en büyük başta/sonda):")
    for s in sinir:
        print(f"  {dizi_metni(s)} -> {ikinci_en_buyuk(s)} (kâhin {kahin(s)})")

    print("2) Kâhinle rastgele karşılaştırmalı test (tohum 2027):")
    karsilastirmali_test(ikinci_en_buyuk, "ikinci_en_buyuk", 2000, -5, 5)
    karsilastirmali_test(ikinci_en_buyuk, "ikinci_en_buyuk", 2000,
                         -1000, 1000)

    print("3) Testi sına: kasıtlı hatalı sürüm aynı testte")
    karsilastirmali_test(ikinci_en_buyuk_hatali, "ikinci_en_buyuk_hatali",
                         2000, -5, 5)

    print("4) Stres testi: n = 100000, değerler [-10^6, 10^6], tohum 7")
    rastgele_tohum(7)
    b = rastgele_dizi(100000, -1000000, 1000000)
    hizli = ikinci_en_buyuk(b)
    yavas = kahin(b)
    durum = "eşleşti" if hizli == yavas else "UYUŞMAZLIK"
    print(f"  hızlı {hizli}, kâhin {yavas} -> {durum}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (kâhin: qsort); C++ — std::nth_element ya
# da std::partial_sort (kâhin: std::sort); Python — heapq.nlargest(2, a)
# [1] ya da sorted(a)[-2] (kâhin).

"""H01_02_en_buyuk_assert.py — AP-2 Hafta 1 · Örnek 2 (★)
Amaç    : Döngü değişmezi m = max(a[0..i-1]) her adımda assert ile
          denetlenir (başlatma, koruma, sonlanma)
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_02_en_buyuk_assert.py   (-O: denetimler kapanır)
Eşleri  : c/H01_02_en_buyuk_assert.c · cpp/H01_02_en_buyuk_assert.cpp
Çıktı   : üç dilde aynı (=)
"""

# Yalnızca gösterim için: degismez() kaç kez çağrıldı? python3 -O ile
# çalıştırılınca assert deyimleri HİÇ değerlendirilmez ve bu sayaç 0
# kalır. Programın asıl işi assert içine konmamalıdır.
denetim_sayisi = 0


def degismez(a, i, m):
    """m, a[0..i-1] bölümünün en büyüğü mü? (Θ(i) denetim)

    m bu bölümde geçmeli ve bölümdeki hiçbir eleman m'den büyük
    olmamalıdır.
    """
    global denetim_sayisi
    gecti_mi = False
    denetim_sayisi += 1
    for k in range(i):
        if a[k] > m:
            return False
        if a[k] == m:
            gecti_mi = True
    return gecti_mi


def en_buyuk(a):
    """Ön koşul: len(a) >= 1. Son koşul: m = max(a[0..n-1])."""
    n = len(a)
    assert n >= 1                      # ön koşul
    m = a[0]
    i = 1
    assert degismez(a, i, m)           # başlatma
    while i < n:
        if a[i] > m:
            m = a[i]
        i += 1
        assert degismez(a, i, m)       # koruma
    assert i == n                      # sonlanma: i == n
    return m  # değişmez + (i == n)  =>  m = max(a[0..n-1])


def sonuc_yaz(ad, a):
    """ad = [x, y, ...] -> en büyük: m biçiminde yazdırır."""
    metin = ", ".join(str(x) for x in a)
    print(f"{ad} = [{metin}] -> en büyük: {en_buyuk(a)}")


def main():
    a = [3, -1, 7, 2, 7, 5]
    b = [-8, -3, -12]
    c = [42]

    sonuc_yaz("a", a)
    sonuc_yaz("b", b)
    sonuc_yaz("c", c)
    print(f"Değişmez assert ile {denetim_sayisi} kez denetlendi", end="")
    print(" (başarısız olsaydı program dururdu).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
# a.begin(), a.end()); Python — max(a). assert: C <assert.h>,
# C++ <cassert>, Python assert deyimi (python3 -O ile kapanır).

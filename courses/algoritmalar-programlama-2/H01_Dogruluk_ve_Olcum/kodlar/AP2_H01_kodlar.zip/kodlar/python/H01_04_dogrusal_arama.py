"""H01_04_dogrusal_arama.py — AP-2 Hafta 1 · Örnek 4 (★★)
Amaç    : Doğrusal arama; "bulunamadı" sözleşmesi (None), döngü
          değişmezi, sonlanma ve iki çıkış noktası
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_04_dogrusal_arama.py
Eşleri  : c/H01_04_dogrusal_arama.c · cpp/H01_04_dogrusal_arama.cpp
Çıktı   : üç dilde aynı (=)
"""

karsilastirma = 0  # a[i] == x karşılaştırma sayacı


# dogrusal_ara: x'in a içindeki İLK konumunu döndürür; x yoksa None
# döndürür ("bulunamadı" sözleşmesi; C ve C++'taki -1'in yerine None).
# Ön koşul : yok (a boş olabilir).
# Son koşul: dönen i bir tamsayıysa a[i] == x ve x, a[0..i-1]'de yok;
#            None ise x, a'nın hiçbir yerinde yok.
# Değişmez : döngü başında x, a[0..i-1] içinde yok.
# Sonlanma : i her adımda 1 artar; en çok n adımda döngü biter.
def dogrusal_ara(a, x):
    """x'in ilk konumu; yoksa None."""
    global karsilastirma
    for i in range(len(a)):
        karsilastirma += 1
        if a[i] == x:    # 1. çıkış
            return i
    return None          # 2. çıkış


def ara_yaz(a, x):
    """Aramayı yapar; sonucu ve karşılaştırma sayısını yazar."""
    global karsilastirma
    karsilastirma = 0
    k = dogrusal_ara(a, x)
    if k is None:
        print(f"ara({x}) -> bulunamadı", end="")
    else:
        print(f"ara({x}) -> {k}", end="")
    print(f", karşılaştırma: {karsilastirma}")


def main():
    a = [7, 3, 9, 3, 5, 1, 8]

    print(f"a = [7, 3, 9, 3, 5, 1, 8] (n = {len(a)})")
    ara_yaz(a, 7)   # en iyi durum: ilk eleman
    ara_yaz(a, 3)   # iki kez geçiyor: İLK konum
    ara_yaz(a, 8)   # son eleman
    ara_yaz(a, 6)   # yok: en kötü durum, n karşılaştırma
    print("boş dizi:")
    ara_yaz([], 7)  # boş liste: döngüye hiç girilmez


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — standart C'de yok (POSIX lfind);
# C++ — std::find; Python — a.index(x) (yoksa ValueError), x in a.

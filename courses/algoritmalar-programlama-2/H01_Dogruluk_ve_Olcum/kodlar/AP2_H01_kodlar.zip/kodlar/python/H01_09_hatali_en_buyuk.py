"""H01_09_hatali_en_buyuk.py — AP-2 Hafta 1 · Örnek 9 (★★)
Amaç    : m = 0 ile başlatılmış hatalı en_buyuk'u sınır değer ve
          rastgele testle yakalamak. BU DOSYA KASITLI HATA İÇERİR.
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_09_hatali_en_buyuk.py
Eşleri  : c/H01_09_hatali_en_buyuk.c · cpp/H01_09_hatali_en_buyuk.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum

MAKS_N = 8


def en_buyuk(a):
    """Doğru sürüm (Örnek 1); burada kâhin olarak kullanılır."""
    m = a[0]
    for i in range(1, len(a)):
        if a[i] > m:
            m = a[i]
    return m


def en_buyuk_hatali(a):
    """KASITLI HATA — m = 0 ile başlatılmış.

    Listede en az bir eleman >= 0 ise doğru sonuç verir; tamamı negatifse
    0 döndürür (0 listede yok bile: son koşul bozulur).
    """
    m = 0                          # HATA: m = a[0] olmalıydı
    for i in range(len(a)):
        if a[i] > m:
            m = a[i]
    return m


def dizi_metni(a):
    """a listesini "[x, y, ...]" biçiminde metne çevirir."""
    return "[" + ", ".join(str(x) for x in a) + "]"


def test_et(a, aciklama):
    """Tek girdide hatalı sürümü kâhinle karşılaştırır."""
    beklenen = en_buyuk(a)
    bulunan = en_buyuk_hatali(a)
    durum = "geçti" if beklenen == bulunan else "YAKALANDI"
    print(f"  {dizi_metni(a)}: beklenen {beklenen}, bulunan {bulunan}"
          f" -> {durum} ({aciklama})")


def rastgele_test(deneme, alt, ust):
    """deneme kez n = 1..MAKS_N elemanlı, değerleri [alt, ust]
    aralığında rastgele liste üretir ve iki sürümü karşılaştırır;
    ilk karşı örneği yazdırır."""
    uyusmazlik = 0
    rastgele_tohum(42)
    for t in range(1, deneme + 1):
        n = rastgele_aralik(1, MAKS_N)
        a = rastgele_dizi(n, alt, ust)
        beklenen = en_buyuk(a)
        bulunan = en_buyuk_hatali(a)
        if beklenen != bulunan:
            uyusmazlik += 1
            if uyusmazlik == 1:
                print(f"  ilk karşı örnek (deneme {t}): {dizi_metni(a)}"
                      f" -> beklenen {beklenen}, bulunan {bulunan}")
    ek = " (hata görünmedi!)" if uyusmazlik == 0 else ""
    print(f"  değerler [{alt}, {ust}]: {deneme} denemede {uyusmazlik}"
          f" uyuşmazlık{ek}")


def main():
    print("1) Örnek test (tipik girdi):")
    test_et([3, 9, 4], "tipik")
    print("2) Sınır değer testleri:")
    test_et([5], "tek eleman")
    test_et([-5], "tek negatif eleman")
    test_et([-8, -3, -12], "tamamı negatif")
    test_et([9, 1, 2], "en büyük başta")
    test_et([0, -1], "en büyük 0")
    print(f"3) Rastgele test (ortak LCG, tohum 42, n = 1..{MAKS_N}):")
    rastgele_test(1000, -100, 100)
    rastgele_test(1000, 0, 100)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
# a.begin(), a.end()); Python — max(a).

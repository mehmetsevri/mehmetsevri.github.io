"""H01_08_ortak_lcg.py — AP-2 Hafta 1 · Örnek 8 (★★)
Amaç    : Ortak LCG modülüyle üç dilde BİREBİR aynı "rastgele" dizi;
          aynı tohum → aynı dizi (tekrarlanabilir deney)
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_08_ortak_lcg.py
Eşleri  : c/H01_08_ortak_lcg.c · cpp/H01_08_ortak_lcg.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import (rastgele_aralik, rastgele_dizi,
                            rastgele_karistir, rastgele_kesir,
                            rastgele_sayi, rastgele_tohum)


def dizi_yaz(a):
    """a listesini "[x, y, ...]" biçiminde yazdırır."""
    print("[" + ", ".join(str(x) for x in a) + "]")


def main():
    # 1) Formülü elle uygula: durum = durum * A + C (mod 2^64)
    durum = 42
    durum = (durum * 6364136223846793005
             + 1442695040888963407) & (2**64 - 1)  # sarmayı taklit et
    print(f"Elle   : durum = {durum}")
    print(f"         çıktı = durum >> 33 = {durum >> 33}")

    # 2) Aynı hesabı modül yapar
    rastgele_tohum(42)
    print("Modül  : rastgele_sayi() x 4 =", end="")
    for _ in range(4):
        print(f" {rastgele_sayi()}", end="")
    print()

    zar = [0] * 10
    for i in range(10):
        zar[i] = rastgele_aralik(1, 6)
    print("rastgele_aralik(1, 6) x 10  = ", end="")
    dizi_yaz(zar)

    print("rastgele_kesir() x 3        =", end="")
    for _ in range(3):
        print(f" {rastgele_kesir():.6f}", end="")
    print()

    a = rastgele_dizi(8, -50, 50)
    print("rastgele_dizi(8, -50, 50)   = ", end="")
    dizi_yaz(a)

    p = [0] * 10
    for i in range(10):
        p[i] = i + 1
    rastgele_karistir(p)
    print("rastgele_karistir(1..10)    = ", end="")
    dizi_yaz(p)

    # 3) Aynı tohum → aynı dizi
    rastgele_tohum(42)
    ilk = rastgele_sayi()
    print(f"Yeniden tohum 42, ilk sayı  = {ilk} (aynı dizi baştan)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — rand()/srand() (dizi platforma göre değişir);
# C++ — std::mt19937 + std::uniform_int_distribution (dağılım sınıfının
# çıktısı gerçekleştirime göre değişebilir); Python — random.seed,
# random.randint (Mersenne Twister). Ders örneklerinde kullanılmaz.

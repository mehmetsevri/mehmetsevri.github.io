"""H01_11_sure_olcumu.py — AP-2 Hafta 1 · Örnek 11 (★★)
Amaç    : Süre ölçümü: time.perf_counter (monotonik saat),
          time.process_time (işlemci zamanı) ve zamanlayici modülü
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_11_sure_olcumu.py [n]      (varsayılan n = 1000000)
Eşleri  : c/H01_11_sure_olcumu.c · cpp/H01_11_sure_olcumu.cpp
Çıktı   : üç dilde aynı (=) — süreler stderr'e yazılır
"""

import sys
import time

from ortak_rastgele import rastgele_dizi, rastgele_tohum
from zamanlayici import olc_ortanca


def toplam(a):
    """a'nın elemanlarının toplamı (Θ(n))."""
    s = 0
    for i in range(len(a)):
        s += a[i]
    return s


def main():
    kullanim = f"Kullanım: {sys.argv[0]} [n]   (1 <= n <= 100000000)"
    n = 1000000
    if len(sys.argv) > 2:
        print(kullanim, file=sys.stderr)
        return 2
    if len(sys.argv) == 2:
        try:
            n = int(sys.argv[1])
        except ValueError:
            n = 0
        if n < 1 or n > 100000000:
            print(kullanim, file=sys.stderr)
            return 2
    rastgele_tohum(42)
    a = rastgele_dizi(n, 0, 99)

    # 1) Monotonik saat: time.perf_counter (en yüksek çözünürlüklü saat)
    t0 = time.perf_counter()
    s1 = toplam(a)
    t1 = time.perf_counter()
    duvar = t1 - t0

    # 2) İşlemci zamanı: time.process_time — süreç CPU'da çalışırken
    c0 = time.process_time()
    s2 = toplam(a)
    c1 = time.process_time()
    islemci = c1 - c0

    # 3) zamanlayici modülü: 1 ısınma + 5 tekrar, ortanca. Sonuç
    # dışarıdaki s3'e yazılır (nonlocal; C ve C++ ile aynı düzen).
    s3 = 0

    def gorev():
        nonlocal s3
        s3 = toplam(a)

    orta = olc_ortanca(gorev, 5)

    print(f"n = {n}, tohum = 42, değerler 0..99")
    print(f"toplam = {s1}")
    ayni = "evet" if s1 == s2 == s3 else "HAYIR"
    print(f"Üç ölçümde de aynı sonuç: {ayni}")
    print("Süreler stderr'de (her çalıştırmada biraz farklıdır).")
    print(f"perf_counter (monotonik saat)   : {duvar * 1e3:10.3f} ms",
          file=sys.stderr)
    print(f"process_time (işlemci zamanı)   : {islemci * 1e3:10.3f} ms",
          file=sys.stderr)
    print(f"olc_ortanca (1 ısınma + 5, ort.): {orta * 1e3:10.3f} ms",
          file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — timespec_get (C11), clock (C89), POSIX
# clock_gettime(CLOCK_MONOTONIC); C++ — std::chrono::steady_clock;
# Python — time.perf_counter, time.process_time, timeit modülü.

"""H01_03_toplam_1_n.py — AP-2 Hafta 1 · Örnek 3 (★)
Amaç    : 1 + 2 + ... + n: döngü ve formül; döngü değişmeziyle
          doğruluk (başlatma–koruma–sonlanma)
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_03_toplam_1_n.py
Eşleri  : c/H01_03_toplam_1_n.c · cpp/H01_03_toplam_1_n.cpp
Çıktı   : üç dilde aynı (=)
"""


# toplam_dongu: 1 + 2 + ... + n (ön koşul: n >= 0).
# Değişmez (döngü başında): s = 1 + 2 + ... + (k-1) = (k-1)k/2
# Başlatma : k = 1, s = 0 = 0·1/2.
# Koruma   : s += k sonrası s = k(k+1)/2; k++ ile yine (k-1)k/2.
# Sonlanma : döngü k = n+1'de biter → s = n(n+1)/2.
def toplam_dongu(n):
    """1 + 2 + ... + n (döngüyle)."""
    s = 0
    for k in range(1, n + 1):
        s += k
    return s


# toplam_formul: Gauss formülü n(n+1)/2. Python int'i keyfi
# duyarlıklıdır: taşma yoktur. // tamsayı bölmesidir (/ ondalık sayı,
# float, verirdi).
def toplam_formul(n):
    """Gauss formülü n(n+1)/2."""
    return n * (n + 1) // 2


def izle(n):
    """Döngü başındaki değişmezi her adımda yazdırır."""
    s = 0
    k = 1
    print(f"n = {n} için değişmez s = (k-1)k/2 (döngü başında):")
    while k <= n:
        print(f"  k = {k}: s = {s:2d}, (k-1)k/2 = {(k - 1) * k // 2:2d}")
        s += k
        k += 1
    print(f"  k = {k}: s = {s:2d}, (k-1)k/2 = {(k - 1) * k // 2:2d}"
          "  <- k = n+1, döngü biter")


def main():
    n_deger = [0, 1, 10, 100, 65536, 1000000]

    izle(5)
    # C'de %16s ve C++'ta std::setw bayt sayar (ö, ü UTF-8'de 2 bayt);
    # üç dilde aynı çıktı için Türkçe başlık sabit metin olarak yazılır.
    print("\n       n            döngü           formül  eşit")
    for n in n_deger:
        d = toplam_dongu(n)
        f = toplam_formul(n)
        print(f"{n:8d} {d:16d} {f:16d}  {'evet' if d == f else 'HAYIR'}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::accumulate (<numeric>) ya da
# std::iota + std::accumulate; Python — sum(range(1, n + 1)).

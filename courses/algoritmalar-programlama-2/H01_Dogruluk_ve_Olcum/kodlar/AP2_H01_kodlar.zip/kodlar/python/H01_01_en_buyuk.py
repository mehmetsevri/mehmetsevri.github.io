"""H01_01_en_buyuk.py — AP-2 Hafta 1 · Örnek 1 (★)
Amaç    : Dizinin en büyük elemanı; ön koşul–son koşul sözleşmesi
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_01_en_buyuk.py
Eşleri  : c/H01_01_en_buyuk.c · cpp/H01_01_en_buyuk.cpp
Çıktı   : üç dilde aynı (=)
"""


# en_buyuk: a listesinin en büyük elemanını döndürür.
# Ön koşul : len(a) >= 1 (liste boş değil).
# Son koşul: dönen m listenin bir elemanıdır ve her k için
#            (0 <= k < len(a)) a[k] <= m sağlanır.
# Ön koşul ihlali (boş liste) çağıranın hatasıdır: a[0] okunurken
# IndexError istisnası oluşur; fonksiyon bunu ayrıca denetlemez.
def en_buyuk(a):
    """a'nın en büyük elemanı."""
    m = a[0]
    for i in range(1, len(a)):
        if a[i] > m:
            m = a[i]
    return m


def sonuc_yaz(ad, a):
    """ad = [x, y, ...] -> en büyük: m biçiminde yazdırır."""
    metin = ", ".join(str(x) for x in a)
    print(f"{ad} = [{metin}] -> en büyük: {en_buyuk(a)}")


def main():
    a = [3, -1, 7, 2, 7, 5]
    b = [-8, -3, -12]
    c = [42]

    sonuc_yaz("a", a)
    sonuc_yaz("b", b)
    sonuc_yaz("c", c)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle yazılır); C++ — *std::max_element(
# a.begin(), a.end()); Python — max(a).

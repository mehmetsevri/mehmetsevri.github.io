"""H01_06_bolme_kalan.py — AP-2 Hafta 1 · Örnek 6 (★★)
Amaç    : -7 // 2 ve -7 % 2: Python'da // taban bölmesidir (aşağı,
          -∞'a doğru yuvarlar), kalan bölenin işaretini alır
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_06_bolme_kalan.py
Eşleri  : c/H01_06_bolme_kalan.c · cpp/H01_06_bolme_kalan.cpp
Çıktı   : Δ — C ve C++ aynı, Python farklı; bkz. Dil Penceresi
"""

import math


def main():
    a_deger = [7, -7, 7, -7]
    b_deger = [2, 2, -2, -2]

    print("Python: // aşağı yuvarlar, % bölenin işaretini alır")
    print("   a    b  a // b   a % b  (a // b) * b + a % b")
    for i in range(len(a_deger)):
        a = a_deger[i]
        b = b_deger[i]
        q = a // b          # bölüm: taban bölmesi (aşağı yuvarlama)
        r = a % b           # kalan: işareti b'ninki
        print(f"{a:4d} {b:4d} {q:7d} {r:7d} {q * b + r:13d}")
    # Python'da x % 2 == 1 negatif tek sayılarda da doğru çalışır.
    print(f"-7 tek mi? (-7 % 2 == 1): {'evet' if -7 % 2 == 1 else 'hayır'}")
    print(f"-7 tek mi? (-7 % 2 != 0): {'evet' if -7 % 2 != 0 else 'hayır'}")
    # C'deki sıfıra doğru kesmenin taklidi (isteğe bağlı):
    # int(a / b) ondalık bölme yapar; çok büyük tamsayılarda (2**53
    # üstü) duyarlık kaybı olabilir. math.fmod C gibi kalan verir.
    print(f"C gibi: int(-7 / 2) = {int(-7 / 2)}, "
          f"math.fmod(-7, 2) = {math.fmod(-7, 2)}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — div(a, b) (<stdlib.h>; bölüm ve kalanı
# birlikte verir, aynı kural); C++ — std::div; Python — divmod(a, b)
# (taban bölmesi kuralıyla).

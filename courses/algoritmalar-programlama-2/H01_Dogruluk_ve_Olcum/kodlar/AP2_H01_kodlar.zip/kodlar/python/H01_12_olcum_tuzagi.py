"""H01_12_olcum_tuzagi.py — AP-2 Hafta 1 · Örnek 12 (★★★)
Amaç    : Ölçüm tuzağı: C/C++'ta sonucu kullanılmayan döngüyü -O2
          siler; CPython silmez — iki döngü de aynı sürede çalışır
Derleme : gerekmez — CPython kaynağı bayt koduna çevirip yorumlar
Çalıştır: python3 H01_12_olcum_tuzagi.py [n]      (varsayılan n = 1000000)
Eşleri  : c/H01_12_olcum_tuzagi.c · cpp/H01_12_olcum_tuzagi.cpp
Çıktı   : üç dilde aynı (=) — asıl fark süredir (stderr)
"""

import sys

from ortak_rastgele import rastgele_dizi, rastgele_tohum
from zamanlayici import olc_ortanca

sonuc_yeri = 0  # kullanilan_dongu sonucu buraya yazar


def kullanilmayan_dongu(a):
    """Toplamı hesaplar ama sonucu hiçbir yere yazmaz.

    CPython bayt kodunu olduğu gibi yürütür; ölü kodu (sonucu
    kullanılmayan döngüyü) silmez: döngü her seferinde çalışır.
    """
    s = 0
    for i in range(len(a)):
        s += a[i]


def kullanilan_dongu(a):
    """Aynı döngü; sonuç modül düzeyindeki değişkene yazılır."""
    global sonuc_yeri
    s = 0
    for i in range(len(a)):
        s += a[i]
    sonuc_yeri = s          # ÇÖZÜM: sonucu kullan


def main():
    kullanim = f"Kullanım: {sys.argv[0]} [n]   (1 <= n <= 100000000)"
    n = 1000000
    if len(sys.argv) > 2:
        print(kullanim, file=sys.stderr)
        return 2
    if len(sys.argv) == 2:
        try:
            n = int(sys.argv[1])
        except ValueError:
            n = 0
        if n < 1 or n > 100000000:
            print(kullanim, file=sys.stderr)
            return 2
    rastgele_tohum(42)
    a = rastgele_dizi(n, 0, 99)

    t_bos = olc_ortanca(lambda: kullanilmayan_dongu(a), 5)
    t_dolu = olc_ortanca(lambda: kullanilan_dongu(a), 5)

    print(f"n = {n}, tohum = 42, değerler 0..99")
    print(f"Sonucu kullanılan döngü   : toplam = {sonuc_yeri}")
    print("Sonucu kullanılmayan döngü: sonuç hiçbir yere yazılmadı")
    print("Süreler stderr'de: -O0 ve -O2 ile derleyip karşılaştırın.")
    print(f"kullanılmayan: {t_bos * 1e3:12.6f} ms (eleman başına "
          f"{t_bos * 1e9 / n:9.4f} ns)", file=sys.stderr)
    print(f"kullanılan   : {t_dolu * 1e3:12.6f} ms (eleman başına "
          f"{t_dolu * 1e9 / n:9.4f} ns)", file=sys.stderr)
    # Geçerlilik denetimi (C/C++ ile aynı): Python'da tetiklenmez.
    if t_bos * 1e9 / n < 0.05:
        print("UYARI: kullanılmayan döngü eleman başına 0,05 ns'den kısa"
              " sürdü: döngü büyük olasılıkla SİLİNDİ.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: ölçümde derleyicinin işi silmesini önlemek için
# C/C++'ta sonucu volatile bir değişkene yazmak ya da Google Benchmark'ın
# benchmark::DoNotOptimize'ı; Python'da gerekmez (CPython döngüyü silmez),
# ölçüm için timeit modülü.

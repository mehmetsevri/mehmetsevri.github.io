/* H11_11_kahn.c — AP-2 Hafta 11 · Örnek 11 (★★★)
 * Amaç    : Topolojik sıralama, Kahn algoritması: giriş dereceleri; giriş
 *           derecesi 0 olan köşelerden EN KÜÇÜK numaralısı seçilir (en
 *           küçük öbek, H7); "en erken dönem" katmanları; döngü varsa
 *           sıralanan < V: raporlanır. Karşılaştırma: FIFO kuyrukla Kahn
 *           ve geçerli sıraların sayısı (birden çok doğru yanıt vardır)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_11_kahn.c -o H11_11_kahn
 * Çalıştır: ./H11_11_kahn ../girdiler/dersler_dag.txt \
 *           ../girdiler/dersler_dongulu.txt
 * Eşleri  : cpp/H11_11_kahn.cpp · python/H11_11_kahn.py
 * Çıktı   : üç dilde aynı (=); yalnız yönlü graflar içindir
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

/* En küçük öbek (H7): a[0] en küçük; kapasite V (her köşe bir kez) */
typedef struct {
    int *a;
    int n;
} Obek;

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

static void obek_ekle(Obek *h, int x)
{
    int i = h->n++;
    h->a[i] = x;
    while (i > 0 && h->a[(i - 1) / 2] > h->a[i]) {    /* yukarı taşı */
        takas(&h->a[(i - 1) / 2], &h->a[i]);
        i = (i - 1) / 2;
    }
}

static int obek_cikar(Obek *h)
{
    int en = h->a[0], i = 0;
    h->a[0] = h->a[--h->n];
    for (;;) {                                        /* aşağı süz */
        int l = 2 * i + 1, r = l + 1, m = i;
        if (l < h->n && h->a[l] < h->a[m]) {
            m = l;
        }
        if (r < h->n && h->a[r] < h->a[m]) {
            m = r;
        }
        if (m == i) {
            break;
        }
        takas(&h->a[i], &h->a[m]);
        i = m;
    }
    return en;
}

/* Öbek içeriğini küçükten büyüğe yazar (yalnız gösterim için sıralanır) */
static void obek_yaz(const Obek *h, int tmp[])
{
    memcpy(tmp, h->a, (size_t)h->n * sizeof(int));
    if (h->n > 1) {
        qsort(tmp, (size_t)h->n, sizeof(int), int_karsilastir);
    }
    printf("[");
    for (int i = 0; i < h->n; i++) {
        printf(i ? " %d" : "%d", tmp[i]);
    }
    printf("]");
}

/* Kahn: fifo = 0 ise en küçük öbek, 1 ise FIFO kuyruk (giriş derecesi 0
 * olanlar artan sırada eklenir). sira[0..dönüş-1]; donem[v] = v'nin en
 * erken dönemi; derece[] sonunda kalan giriş dereceleri. iz: adımları
 * yazdır. Dönüş: sıralanan köşe sayısı (< V ise döngü var); -1 bellek. */
static int kahn(const Graf *g, int fifo, int iz, int sira[], int donem[],
                int derece[])
{
    Obek h = {malloc((size_t)g->V * sizeof(int)), 0};
    int *tmp = malloc((size_t)g->V * sizeof(int));
    int bas = 0, n = 0;
    if (h.a == NULL || tmp == NULL) {
        free(h.a);
        free(tmp);
        return -1;
    }
    for (int v = 0; v < g->V; v++) {
        derece[v] = 0;
        donem[v] = 1;
    }
    for (int u = 0; u < g->V; u++) {
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            derece[g->komsu[u].veri[i]]++;
        }
    }
    if (iz) {
        printf("   giriş dereceleri:");
        for (int v = 0; v < g->V; v++) {
            printf(" %d:%d", v, derece[v]);
        }
        printf("\n");
    }
    for (int v = 0; v < g->V; v++) {
        if (derece[v] == 0) {
            if (fifo) {
                h.a[h.n++] = v;              /* FIFO: dizinin sonuna */
            } else {
                obek_ekle(&h, v);
            }
        }
    }
    if (iz) {
        printf("   başlangıç öbeği (giriş derecesi 0): ");
        obek_yaz(&h, tmp);
        printf("\n");
    }
    while (bas < h.n) {
        int u = fifo ? h.a[bas++] : obek_cikar(&h);
        sira[n++] = u;
        if (iz) {
            printf("   adım %d: çıkan %d (dönem %d);", n, u, donem[u]);
        }
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            int v = g->komsu[u].veri[i];
            if (donem[u] + 1 > donem[v]) {
                donem[v] = donem[u] + 1;     /* en uzun önkoşul zinciri */
            }
            derece[v]--;
            if (iz) {
                printf("%s %d: %d->%d%s", i ? "," : "", v, derece[v] + 1,
                       derece[v], derece[v] == 0 ? " (öbeğe)" : "");
            }
            if (derece[v] == 0) {
                if (fifo) {
                    h.a[h.n++] = v;
                } else {
                    obek_ekle(&h, v);
                }
            }
        }
        if (iz) {
            printf("%s öbek: ", g->komsu[u].boyut ? ";" : "");
            obek_yaz(&h, tmp);
            printf("\n");
        }
    }
    free(h.a);
    free(tmp);
    return n;
}

/* Kâhin: her kenar u -> v için konum[u] < konum[v] mi? */
static int gecerli_mi(const Graf *g, const int sira[], int n, int konum[])
{
    if (n != g->V) {
        return 0;
    }
    for (int i = 0; i < n; i++) {
        konum[sira[i]] = i;
    }
    for (int u = 0; u < g->V; u++) {
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            if (konum[u] >= konum[g->komsu[u].veri[i]]) {
                return 0;
            }
        }
    }
    return 1;
}

/* Bütün geçerli topolojik sıraları sayar (H3 geri izleme): her adımda
 * giriş derecesi 0 olan, kullanılmamış her köşe denenir. */
static long sira_say(const Graf *g, int derece[], char kullanildi[],
                     int kalan)
{
    long toplam = 0;
    if (kalan == 0) {
        return 1;
    }
    for (int u = 0; u < g->V; u++) {
        if (!kullanildi[u] && derece[u] == 0) {
            kullanildi[u] = 1;                         /* seç */
            for (size_t i = 0; i < g->komsu[u].boyut; i++) {
                derece[g->komsu[u].veri[i]]--;
            }
            toplam += sira_say(g, derece, kullanildi, kalan - 1);
            for (size_t i = 0; i < g->komsu[u].boyut; i++) {
                derece[g->komsu[u].veri[i]]++;         /* geri al */
            }
            kullanildi[u] = 0;
        }
    }
    return toplam;
}

static void dizi_yaz(const char *baslik, const int a[], int n)
{
    printf("%s", baslik);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
}

static int rapor(const Graf *g)
{
    int *sira = malloc((size_t)g->V * sizeof(int));
    int *donem = malloc((size_t)g->V * sizeof(int));
    int *derece = malloc((size_t)g->V * sizeof(int));
    int *konum = malloc((size_t)g->V * sizeof(int));
    int *sira2 = malloc((size_t)g->V * sizeof(int));
    int *donem2 = malloc((size_t)g->V * sizeof(int));
    char *kullanildi = calloc((size_t)g->V, 1);
    int n = -1;
    if (sira && donem && derece && konum && sira2 && donem2 &&
        kullanildi) {
        n = kahn(g, 0, 1, sira, donem, derece);
    }
    if (n == g->V) {
        int en_son = 1;
        dizi_yaz("   topolojik sıra (en küçük öbek):", sira, n);
        printf("\n   kâhin: her kenar u->v için konum[u] < konum[v]: %s "
               "(%d kenar)\n", gecerli_mi(g, sira, n, konum) ? "evet"
               : "HAYIR", g->E);
        printf("   en erken dönem:");
        for (int v = 0; v < g->V; v++) {
            printf(" %d:%d", v, donem[v]);
            en_son = donem[v] > en_son ? donem[v] : en_son;
        }
        printf("\n  ");
        for (int d = 1; d <= en_son; d++) {
            printf(" dönem %d:", d);
            for (int i = 0; i < n; i++) {
                if (donem[sira[i]] == d) {
                    printf(" %d", sira[i]);
                }
            }
            printf(d < en_son ? ";" : "\n");
        }
        int n2 = kahn(g, 1, 0, sira2, donem2, derece);
        dizi_yaz("   FIFO kuyrukla Kahn:", sira2, n2);
        printf(" (geçerli: %s; en küçük öbek sırasından %s)\n",
               gecerli_mi(g, sira2, n2, konum) ? "evet" : "HAYIR",
               memcmp(sira, sira2, (size_t)n * sizeof(int)) != 0
               ? "farklı" : "farksız");
        for (int v = 0; v < g->V; v++) {
            derece[v] = 0;
        }
        for (int u = 0; u < g->V; u++) {
            for (size_t i = 0; i < g->komsu[u].boyut; i++) {
                derece[g->komsu[u].veri[i]]++;
            }
        }
        printf("   geçerli topolojik sıra sayısı (geri izlemeyle, H3): "
               "%ld\n", sira_say(g, derece, kullanildi, g->V));
    } else if (n >= 0) {
        dizi_yaz("   sıralanan köşeler:", sira, n);
        printf(" (%d / %d)\n   sıralanamayan (giriş derecesi > 0 kaldı):",
               n, g->V);
        for (int v = 0; v < g->V; v++) {
            if (derece[v] > 0) {
                printf(" %d:%d", v, derece[v]);
            }
        }
        printf("\n   SONUÇ: döngü var — geçerli bir sıra (ders planı) "
               "yok; döngüdeki ya da döngüye bağlı köşeler hiç 0'a inmez\n");
    }
    free(sira);
    free(donem);
    free(derece);
    free(konum);
    free(sira2);
    free(donem2);
    free(kullanildi);
    return n >= 0 ? 0 : 1;
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_11_kahn GRAF [GRAF2 ...]\n");
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (graf_yukle(argv[i], &g) != 0) {
            return 1;
        }
        if (!g.yonlu) {
            fprintf(stderr, "%s: yönlü bir graf gerekir\n",
                    taban_ad(argv[i]));
            graf_birak(&g);
            return 1;
        }
        printf("%d) %s (yönlü, V = %d, E = %d): Kahn, en küçük öbekle\n", i,
               taban_ad(argv[i]), g.V, g.E);
        int sonuc = rapor(&g);
        graf_birak(&g);
        if (sonuc != 0) {
            return 1;
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * topological_sort, DFS tabanlı); Python — graphlib.TopologicalSorter
 * (3.9+, standart kütüphane; yalnız kâhin) ve networkx.topological_sort
 * (doğrulama için). */

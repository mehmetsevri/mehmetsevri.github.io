/* H11_02_komsuluk_listesi.c — AP-2 Hafta 11 · Örnek 2 (★★)
 * Amaç    : Dosyadan kenar listesi okuma (ortak graf biçimi, denetimli);
 *           komşuluk listesi = dinamik dizilerden (H8) oluşan dizi; ekleme
 *           sırası ve artan sıra; liste ↔ matris ↔ kenar listesi dönüşümü;
 *           biçim hatası iletileri (üç dilde aynı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_02_komsuluk_listesi.c -o H11_02_komsuluk_listesi
 * Çalıştır: ./H11_02_komsuluk_listesi GRAF [GRAF2 ...]
 *           (ilk dosya ayrıntılı; sonrakiler özet ya da hata iletisi)
 * Eşleri  : cpp/H11_02_komsuluk_listesi.cpp ·
 *           python/H11_02_komsuluk_listesi.py
 * Çıktı   : üç dilde aynı (=); ilk dosyada biçim hatası: çıkış kodu 1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256

typedef struct {
    int u, v, w;
} Kenar;

typedef struct {
    int V, E, yonlu;   /* yonlu: 1 yönlü, 0 yönsüz */
    Kenar *kenar;      /* E kenar, dosyadaki sırayla */
} KenarListesi;

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla) */
static int belirtecle(char *satir, char *bel[4])
{
    const char *ayrac = " \t\r\n\v\f";
    int n = 0;
    for (char *p = strtok(satir, ayrac); p != NULL && n < 4;
         p = strtok(NULL, ayrac)) {
        bel[n++] = p;
    }
    return n;
}

/* Sahiplik: başarıda kl->kenar çağıranındır (free ile bırakılır).
 * Dönüş 0: başarı; 1: dosya ya da biçim hatası (ileti hata[]'da). */
static int graf_dosyasi_oku(const char *yol, KenarListesi *kl,
                            char *hata, size_t boy)
{
    char satir[SATIR_UZ];
    char *bel[4];
    const char *ad = taban_ad(yol);
    long V = 0, E = 0, x[3];
    int no = 0, okunan = 0, baslik = 0, sonuc = 0;
    FILE *f = fopen(yol, "r");
    kl->kenar = NULL;
    if (f == NULL) {
        snprintf(hata, boy, "%s: dosya açılamadı", ad);
        return 1;
    }
    while (sonuc == 0 && fgets(satir, sizeof satir, f) != NULL) {
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            snprintf(hata, boy, "%s: satır %d: satır çok uzun", ad, no);
            sonuc = 1;
            break;
        }
        int n = belirtecle(satir, bel);
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (!baslik) {
            if (n < 2 || n > 3 || !tamsayi_coz(bel[0], &V) ||
                !tamsayi_coz(bel[1], &E)) {
                snprintf(hata, boy, "%s: satır %d: başlık \"V E "
                         "[yonlu|yonsuz]\" bekleniyor", ad, no);
                sonuc = 1;
            } else if (V < 1 || V > MAKS_KOSE) {
                snprintf(hata, boy, "%s: satır %d: V = %ld geçersiz "
                         "(1..%ld)", ad, no, V, MAKS_KOSE);
                sonuc = 1;
            } else if (E < 0 || E > MAKS_KENAR) {
                snprintf(hata, boy, "%s: satır %d: E = %ld geçersiz "
                         "(0..%ld)", ad, no, E, MAKS_KENAR);
                sonuc = 1;
            } else if (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
                       strcmp(bel[2], "yonsuz") != 0) {
                snprintf(hata, boy, "%s: satır %d: tür \"%s\" tanınmıyor "
                         "(yonlu ya da yonsuz)", ad, no, bel[2]);
                sonuc = 1;
            } else {
                kl->V = (int)V;
                kl->E = (int)E;
                kl->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
                kl->kenar = malloc(((size_t)E + 1) * sizeof *kl->kenar);
                if (kl->kenar == NULL) {
                    snprintf(hata, boy, "%s: bellek yetersiz", ad);
                    sonuc = 1;
                }
                baslik = 1;
            }
            continue;
        }
        if (okunan == E) {
            snprintf(hata, boy, "%s: satır %d: fazladan kenar (başlıkta "
                     "E = %ld)", ad, no, E);
            sonuc = 1;
        } else if (n < 2 || n > 3 || !tamsayi_coz(bel[0], &x[0]) ||
                   !tamsayi_coz(bel[1], &x[1]) ||
                   (n == 3 && !tamsayi_coz(bel[2], &x[2]))) {
            snprintf(hata, boy, "%s: satır %d: kenar \"u v [w]\" "
                     "bekleniyor", ad, no);
            sonuc = 1;
        } else if (x[0] < 0 || x[0] >= V || x[1] < 0 || x[1] >= V) {
            long kotu = (x[0] < 0 || x[0] >= V) ? x[0] : x[1];
            snprintf(hata, boy, "%s: satır %d: köşe %ld aralık dışı "
                     "(0..%ld)", ad, no, kotu, V - 1);
            sonuc = 1;
        } else {
            kl->kenar[okunan].u = (int)x[0];
            kl->kenar[okunan].v = (int)x[1];
            kl->kenar[okunan].w = n == 3 ? (int)x[2] : 1;
            okunan++;
        }
    }
    fclose(f);
    if (sonuc == 0 && !baslik) {
        snprintf(hata, boy, "%s: dosya boş (başlık yok)", ad);
        sonuc = 1;
    } else if (sonuc == 0 && okunan < E) {
        snprintf(hata, boy, "%s: kenar eksik: E = %ld, okunan %d", ad, E,
                 okunan);
        sonuc = 1;
    }
    if (sonuc != 0) {
        free(kl->kenar);
        kl->kenar = NULL;
    }
    return sonuc;
}

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

/* Sahiplik: başarıda g->komsu çağıranındır; graf_birak ile bırakılır.
 * Kenarlar dosya sırasıyla eklenir (yönsüzde iki yöne). 0 / -1 */
static int graf_kur(const KenarListesi *kl, Graf *g)
{
    g->V = kl->V;
    g->E = kl->E;
    g->yonlu = kl->yonlu;
    g->komsu = malloc((size_t)g->V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    for (int i = 0; i < kl->E; i++) {
        const Kenar *k = &kl->kenar[i];
        if (dd_ekle(&g->komsu[k->u], k->v) != 0 ||
            (!g->yonlu && dd_ekle(&g->komsu[k->v], k->u) != 0)) {
            graf_birak(g);
            return -1;
        }
    }
    return 0;
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Komşu listeleri artan köşe numarasına (belirli sıra) */
static void graf_sirala(Graf *g)
{
    for (int u = 0; u < g->V; u++) {
        if (g->komsu[u].boyut > 1) {
            qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                  int_karsilastir);
        }
    }
}

static void listeleri_yaz(const Graf *g)
{
    for (int u = 0; u < g->V; u++) {
        printf("    %d:", u);
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            printf(" %d", g->komsu[u].veri[i]);
        }
        printf("\n");
    }
}

/* Sahiplik: dönen V × V matris çağıranındır (free); NULL: bellek yok */
static unsigned char *listeden_matris(const Graf *g)
{
    unsigned char *m = calloc((size_t)g->V * g->V, 1);
    if (m == NULL) {
        return NULL;
    }
    for (int u = 0; u < g->V; u++) {
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            m[(size_t)u * g->V + g->komsu[u].veri[i]] = 1;
        }
    }
    return m;
}

/* Matristen kenar listesi (yönsüzde u < v); kl->kenar en az E_ust yer.
 * Kenarları yazdırır, sayısını döndürür. */
static int matristen_kenarlar(const unsigned char *m, int V, int yonlu,
                              KenarListesi *kl, int E_ust)
{
    int sayac = 0;
    kl->V = V;
    kl->yonlu = yonlu;
    for (int u = 0; u < V; u++) {
        for (int v = yonlu ? 0 : u + 1; v < V; v++) {
            if (m[(size_t)u * V + v] && sayac < E_ust) {
                printf(" (%d,%d)", u, v);
                kl->kenar[sayac].u = u;
                kl->kenar[sayac].v = v;
                kl->kenar[sayac].w = 1;
                sayac++;
            }
        }
    }
    kl->E = sayac;
    return sayac;
}

static int graflar_esit(const Graf *a, const Graf *b)
{
    for (int u = 0; u < a->V; u++) {
        const KomsuDizisi *x = &a->komsu[u], *y = &b->komsu[u];
        if (x->boyut != y->boyut) {
            return 0;
        }
        for (size_t i = 0; i < x->boyut; i++) {
            if (x->veri[i] != y->veri[i]) {
                return 0;
            }
        }
    }
    return 1;
}

/* 4) liste -> matris -> kenar listesi -> liste. 0: başarı */
static int donusumler(const Graf *g)
{
    int V = g->V;
    KenarListesi kl2;
    Graf g2;
    unsigned char *m = listeden_matris(g);
    kl2.kenar = malloc(((size_t)g->E + 1) * sizeof *kl2.kenar);
    if (m == NULL || kl2.kenar == NULL) {
        free(m);
        free(kl2.kenar);
        return -1;
    }
    printf("4) Dönüşümler\n   liste -> matris (satır u: "
           "matris[u][0..V-1]):\n");
    for (int u = 0; u < V; u++) {
        printf("    %d: ", u);
        for (int v = 0; v < V; v++) {
            printf("%d", m[(size_t)u * V + v]);
        }
        printf("\n");
    }
    printf("   matris -> kenar listesi (%s):", g->yonlu ? "u -> v" : "u < v");
    int sayac = matristen_kenarlar(m, V, g->yonlu, &kl2, g->E);
    printf("\n   kenar sayısı = %d (E = %d)\n", sayac, g->E);
    int ayni = graf_kur(&kl2, &g2) == 0;
    if (ayni) {
        graf_sirala(&g2);
        ayni = graflar_esit(g, &g2);
        graf_birak(&g2);
    }
    printf("   kenar listesi -> liste: 3) ile aynı mı: %s\n",
           ayni ? "evet" : "HAYIR");
    free(kl2.kenar);
    free(m);
    return 0;
}

static int ayrintili(const char *yol)
{
    KenarListesi kl;
    Graf g;
    char hata[256];
    if (graf_dosyasi_oku(yol, &kl, hata, sizeof hata) != 0) {
        fprintf(stderr, "%s\n", hata);
        return 1;
    }
    if (graf_kur(&kl, &g) != 0) {
        fprintf(stderr, "bellek yetersiz\n");
        free(kl.kenar);
        return 1;
    }
    printf("1) Dosya: %s -> V = %d, E = %d, %s\n", taban_ad(yol), kl.V,
           kl.E, kl.yonlu ? "yönlü" : "yönsüz");
    printf("   kenar listesi (dosya sırası):");
    for (int i = 0; i < kl.E; i++) {
        printf(" (%d,%d)", kl.kenar[i].u, kl.kenar[i].v);
    }
    printf("\n2) Komşuluk listesi: dinamik dizilerden oluşan dizi "
           "(ekleme sırası)\n");
    listeleri_yaz(&g);
    graf_sirala(&g);
    printf("3) Listeler artan sıraya dizildi (dolaşma bu sırayla):\n");
    listeleri_yaz(&g);
    long toplam = 0;
    for (int u = 0; u < g.V; u++) {
        toplam += (long)g.komsu[u].boyut;
    }
    printf("   toplam liste öğesi = %ld = %s\n", toplam,
           g.yonlu ? "E (yönlü)" : "2E (yönsüz: her kenar iki listede)");
    int sonuc = donusumler(&g);
    if (sonuc == 0) {
        printf("   öğe sayısı: matris V² = %ld hücre; liste V + %s = %ld; "
               "kenar listesi 2E = %d sayı\n", (long)g.V * g.V,
               g.yonlu ? "E" : "2E", g.V + toplam, 2 * g.E);
    }
    graf_birak(&g);
    free(kl.kenar);
    return sonuc == 0 ? 0 : 1;
}

static void ozet(const char *yol)
{
    KenarListesi kl;
    Graf g;
    char hata[256];
    if (graf_dosyasi_oku(yol, &kl, hata, sizeof hata) != 0) {
        printf("   %s\n", hata);
        return;
    }
    if (graf_kur(&kl, &g) != 0) {
        free(kl.kenar);
        return;
    }
    graf_sirala(&g);
    printf("   %s: V = %d, E = %d, %s; sıralı listeler:\n", taban_ad(yol),
           kl.V, kl.E, kl.yonlu ? "yönlü" : "yönsüz");
    listeleri_yaz(&g);
    graf_birak(&g);
    free(kl.kenar);
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_02_komsuluk_listesi GRAF [GRAF2 ...]\n");
        return 2;
    }
    if (ayrintili(argv[1]) != 0) {
        return 1;
    }
    if (argc > 2) {
        printf("5) Öteki dosyalar (okuyucunun iletisi üç dilde aynıdır):\n");
    }
    for (int i = 2; i < argc; i++) {
        ozet(argv[i]);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (dinamik dizilerden oluşan dizi elle;
 * eşdeğeri int ** + boyut dizisi); C++ — std::vector<std::vector<int>>;
 * Python — liste listesi (ya da dict); hazır graf türü yalnız Boost.Graph
 * ve networkx'te (doğrulama için). */

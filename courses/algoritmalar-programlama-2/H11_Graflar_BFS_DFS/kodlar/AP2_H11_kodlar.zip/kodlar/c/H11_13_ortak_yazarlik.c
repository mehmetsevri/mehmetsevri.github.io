/* H11_13_ortak_yazarlik.c — AP-2 Hafta 11 · Örnek 13 (★★★)
 * Amaç    : KURGUSAL bir ortak yazarlık ağında "kaç adım uzakta?" (Erdős
 *           sayısı benzeri "Erdem sayısı"): ad -> köşe eşlemesi sıralı
 *           dizi + ikili arama (H4) ile; makaledeki her yazar çifti kenar;
 *           BFS uzaklıkları, ulaşılamayanlar (∞) ve en uzak yazarlara yol.
 *           2. bölüm: ortak LCG ile üretilen yapay ağda uzaklık dağılımı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_13_ortak_yazarlik.c ortak_rastgele.c -o H11_13_ortak_yazarlik
 * Çalıştır: ./H11_13_ortak_yazarlik ../girdiler/ortak_yazarlik.txt [N M]
 *           (N yazar, M makale; varsayılan 2000 3000)
 * Eşleri  : cpp/H11_13_ortak_yazarlik.cpp ·
 *           python/H11_13_ortak_yazarlik.py
 * Çıktı   : üç dilde aynı (=); adlar uydurmadır (girdi dosyasına bakınız)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"
#define MERKEZ "Erdem"

/* H8 dinamik dizisi (int) */
typedef struct {
    int *veri;
    size_t boyut, kapasite;
} Dizi;

static int dd_ekle(Dizi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 4;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

static int ad_karsilastir(const void *a, const void *b)
{
    return strcmp(*(char *const *)a, *(char *const *)b);  /* bayt sırası */
}

/* Sahiplik: dönen kopya çağıranındır (free). strdup C17'de yok. */
static char *dizgi_kopyala(const char *s)
{
    size_t n = strlen(s) + 1;
    char *k = malloc(n);
    if (k != NULL) {
        memcpy(k, s, n);
    }
    return k;
}

/* Sıralı ad[0..n-1] içinde x'in indisi; yoksa -1. sayac: karşılaştırma */
static int ikili_ara(char *const ad[], int n, const char *x, long *sayac)
{
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        int k = strcmp(ad[mid], x);
        (*sayac)++;
        if (k == 0) {
            return mid;
        }
        if (k < 0) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

/* Komşu listelerini sıralar ve yinelenenleri atar (aynı çift birden çok
 * makalede). Dönüş: atılan liste öğesi sayısı. */
static long listeleri_duzenle(Dizi komsu[], int V)
{
    long atilan = 0;
    for (int u = 0; u < V; u++) {
        size_t k = 0;
        if (komsu[u].boyut > 1) {
            qsort(komsu[u].veri, komsu[u].boyut, sizeof(int),
                  int_karsilastir);
        }
        for (size_t i = 0; i < komsu[u].boyut; i++) {
            if (k == 0 || komsu[u].veri[i] != komsu[u].veri[k - 1]) {
                komsu[u].veri[k++] = komsu[u].veri[i];
            }
        }
        atilan += (long)(komsu[u].boyut - k);
        komsu[u].boyut = k;
    }
    return atilan;
}

/* BFS: uzak[] (ulaşılamayan -1) ve ebeveyn[]; dönüş: kuyruğa ekleme */
static int bfs(const Dizi komsu[], int V, int s, int uzak[], int ebeveyn[],
               int q[], long *inceleme)
{
    int bas = 0, son = 0;
    for (int v = 0; v < V; v++) {
        uzak[v] = ebeveyn[v] = -1;
    }
    uzak[s] = 0;
    q[son++] = s;
    while (bas < son) {
        int u = q[bas++];
        for (size_t i = 0; i < komsu[u].boyut; i++) {
            int v = komsu[u].veri[i];
            (*inceleme)++;
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                ebeveyn[v] = u;
                q[son++] = v;
            }
        }
    }
    return son;
}

static void komsu_birak(Dizi komsu[], int V)
{
    if (komsu != NULL) {
        for (int u = 0; u < V; u++) {
            free(komsu[u].veri);
        }
        free(komsu);
    }
}

static Dizi *komsu_olustur(int V)
{
    Dizi *komsu = malloc((size_t)V * sizeof *komsu);
    if (komsu != NULL) {
        for (int u = 0; u < V; u++) {
            komsu[u].veri = NULL;
            komsu[u].boyut = komsu[u].kapasite = 0;
        }
    }
    return komsu;
}

/* Makaledeki yazarlar (köşe numaraları) arasında her çifte kenar */
static int makale_ekle(Dizi komsu[], const int yazar[], int k)
{
    for (int i = 0; i < k; i++) {
        for (int j = i + 1; j < k; j++) {
            if (dd_ekle(&komsu[yazar[i]], yazar[j]) != 0 ||
                dd_ekle(&komsu[yazar[j]], yazar[i]) != 0) {
                return -1;
            }
        }
    }
    return 0;
}

static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* Dosyadaki makaleler: bütün adlar dosya sırasıyla tek dizide; makale m'nin
 * yazarları ad[bas[m] .. bas[m + 1] - 1]. Sahiplik: adlar bu yapınındır. */
typedef struct {
    char **ad;
    size_t n, kap;
    Dizi bas;
} Makaleler;

static void makaleleri_birak(Makaleler *mk)
{
    for (size_t i = 0; i < mk->n; i++) {
        free(mk->ad[i]);
    }
    free(mk->ad);
    free(mk->bas.veri);
}

static int ad_ekle(Makaleler *mk, const char *p)
{
    if (mk->n == mk->kap) {
        size_t yeni = mk->kap ? 2 * mk->kap : 16;
        char **gecici = realloc(mk->ad, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;
        }
        mk->ad = gecici;
        mk->kap = yeni;
    }
    if ((mk->ad[mk->n] = dizgi_kopyala(p)) == NULL) {
        return -1;
    }
    mk->n++;
    return 0;
}

/* Her satır bir makale (adlar boşlukla ayrılır); '#' satırı yorum.
 * 0: başarı; 1: dosya açılamadı ya da bellek yok (ileti stderr'e). */
static int makaleleri_oku(const char *yol, Makaleler *mk)
{
    char satir[SATIR_UZ];
    int hata = 0;
    FILE *f = fopen(yol, "r");
    mk->ad = NULL;
    mk->n = mk->kap = 0;
    mk->bas = (Dizi){NULL, 0, 0};
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (!hata && fgets(satir, sizeof satir, f) != NULL) {
        char *p = strtok(satir, AYRAC);
        if (p == NULL || p[0] == '#') {
            continue;                /* boş satır ya da yorum */
        }
        hata = dd_ekle(&mk->bas, (int)mk->n) != 0;
        for (; p != NULL && !hata; p = strtok(NULL, AYRAC)) {
            hata = ad_ekle(mk, p) != 0;
        }
    }
    fclose(f);
    if (!hata) {
        hata = dd_ekle(&mk->bas, (int)mk->n) != 0;   /* bitiş işareti */
    }
    if (hata) {
        fprintf(stderr, "bellek yetersiz\n");
        makaleleri_birak(mk);
    }
    return hata;
}

/* En uzak köşelere yolları ebeveyn zincirinden geri çıkarıp yazar */
static void uzak_yollari_yaz(char *const ad[], int V, const int uzak[],
                             const int ebeveyn[], int en, int yol[])
{
    printf("   en uzaktakiler (%d adım):\n", en);
    for (int v = 0; v < V; v++) {
        if (uzak[v] != en) {
            continue;
        }
        int k = 0;
        for (int x = v; x != -1; x = ebeveyn[x]) {
            yol[k++] = x;
        }
        printf("     %s:", ad[v]);
        for (int i = k - 1; i >= 0; i--) {
            printf(" %s%s", ad[yol[i]], i ? " ->" : "\n");
        }
    }
}

/* Uzaklığa göre gruplar: 0, 1, ..., en ve ∞ (ulaşılamayan) */
static void gruplari_yaz(char *const ad[], int V, const int uzak[], int en)
{
    printf("   %s sayısı (%s'den BFS; komşular ad sırasıyla):\n", MERKEZ,
           MERKEZ);
    for (int d = 0; d <= en + 1; d++) {
        int hedef = d <= en ? d : -1, ilk = 1;
        for (int v = 0; v < V; v++) {
            if (uzak[v] == hedef) {
                if (ilk) {
                    printf(d <= en ? "     %d:" : "     ∞:", d);
                    ilk = 0;
                }
                printf(" %s", ad[v]);
            }
        }
        if (!ilk) {
            printf("%s\n", d <= en ? "" : " (zincir yok)");
        }
    }
}

/* 1. bölüm: kurgusal ağ. ad -> köşe eşlemesi, graf, BFS. 0 / 1 */
static int kurgusal_ag(const char *yol)
{
    Makaleler mk;
    long karsilastirma = 0, inceleme = 0, liste = 0;
    int V = 0, sonuc = 1;
    if (makaleleri_oku(yol, &mk) != 0) {
        return 1;
    }
    int M = (int)mk.bas.boyut - 1;
    char **ad = malloc((mk.n + 1) * sizeof *ad);     /* işaretçi kopyası */
    int *indeks = malloc((mk.n + 1) * sizeof *indeks);
    if (ad != NULL && indeks != NULL) {
        memcpy(ad, mk.ad, mk.n * sizeof *ad);
        qsort(ad, mk.n, sizeof *ad, ad_karsilastir);
        for (size_t i = 0; i < mk.n; i++) {          /* yinelenenleri at */
            if (V == 0 || strcmp(ad[i], ad[V - 1]) != 0) {
                ad[V++] = ad[i];
            }
        }
        for (size_t t = 0; t < mk.n; t++) {
            indeks[t] = ikili_ara(ad, V, mk.ad[t], &karsilastirma);
        }
    }
    Dizi *komsu = V > 0 ? komsu_olustur(V) : NULL;
    int *uzak = malloc(((size_t)V + 1) * sizeof(int));
    int *ebeveyn = malloc(((size_t)V + 1) * sizeof(int));
    int *q = malloc(((size_t)V + 1) * sizeof(int));
    long merkez_arama = 0;           /* eşleme sayacına katılmaz */
    int s = V > 0 ? ikili_ara(ad, V, MERKEZ, &merkez_arama) : -1;
    if (komsu != NULL && uzak && ebeveyn && q && s >= 0) {
        printf("1) %s: %d makale, %zu yazar adı (yinelemeli), %d farklı "
               "yazar\n", taban_ad(yol), M, mk.n, V);
        printf("   ad -> köşe: sıralı dizi + ikili arama (H4); %zu aramada "
               "%ld karşılaştırma\n   köşeler:", mk.n, karsilastirma);
        for (int v = 0; v < V; v++) {
            printf(" %d=%s", v, ad[v]);
        }
        printf("\n");
        sonuc = 0;
        for (int m = 0; m < M && sonuc == 0; m++) {
            int b = mk.bas.veri[m];
            sonuc = makale_ekle(komsu, indeks + b, mk.bas.veri[m + 1] - b);
        }
    }
    if (sonuc == 0) {
        long atilan = listeleri_duzenle(komsu, V);
        for (int u = 0; u < V; u++) {
            liste += (long)komsu[u].boyut;
        }
        int ulasilan = bfs(komsu, V, s, uzak, ebeveyn, q, &inceleme);
        int en = 0;
        for (int v = 0; v < V; v++) {
            en = uzak[v] > en ? uzak[v] : en;
        }
        printf("   kenar (ortak yazar çifti) = %ld; yinelenen çift atıldı: "
               "%ld kez (aynı ikili birden çok makalede)\n", liste / 2,
               atilan / 2);
        gruplari_yaz(ad, V, uzak, en);
        uzak_yollari_yaz(ad, V, uzak, ebeveyn, en, q);
        printf("   sayaçlar: ulaşılan = %d / %d, kenar inceleme = %ld "
               "(ulaşılan köşelerin dereceleri toplamı)\n", ulasilan, V,
               inceleme);
    } else if (s < 0 && V > 0) {
        fprintf(stderr, "%s: ağda %s yok\n", taban_ad(yol), MERKEZ);
    }
    komsu_birak(komsu, V);
    free(uzak);
    free(ebeveyn);
    free(q);
    free(ad);
    free(indeks);
    makaleleri_birak(&mk);
    return sonuc == 0 ? 0 : 1;
}

/* 2. bölüm: ortak LCG ile N yazarlı, M makaleli yapay ağ. Makale başına
 * 2..4 yazar; makalelerin yaklaşık %10'unun ilk yazarı merkez (0). */
static int yapay_ag(int N, int M)
{
    Dizi *komsu = komsu_olustur(N);
    int *uzak = malloc((size_t)N * sizeof(int));
    int *ebeveyn = malloc((size_t)N * sizeof(int));
    int *q = malloc((size_t)N * sizeof(int));
    long *dagilim = calloc((size_t)N + 1, sizeof(long));
    int sonuc = 1;
    if (komsu && uzak && ebeveyn && q && dagilim) {
        int hata = 0;
        rastgele_tohum(2026);
        for (int m = 0; m < M && !hata; m++) {
            int yazar[4], k = rastgele_aralik(2, 4), n = 0;
            yazar[n++] = rastgele_aralik(0, 9) == 0 ? 0
                         : rastgele_aralik(0, N - 1);
            while (n < k) {
                int a = rastgele_aralik(0, N - 1), yeni = 1;
                for (int i = 0; i < n; i++) {
                    yeni = yeni && yazar[i] != a;
                }
                if (yeni) {
                    yazar[n++] = a;  /* aynı makalede yinelenen yazar yok */
                }
            }
            hata = makale_ekle(komsu, yazar, n) != 0;
        }
        if (!hata) {
            long liste = 0, inceleme = 0, toplam = 0;
            listeleri_duzenle(komsu, N);
            for (int u = 0; u < N; u++) {
                liste += (long)komsu[u].boyut;
            }
            int ulasilan = bfs(komsu, N, 0, uzak, ebeveyn, q, &inceleme);
            int en = 0;
            for (int v = 0; v < N; v++) {
                if (uzak[v] >= 0) {
                    dagilim[uzak[v]]++;
                    toplam += uzak[v];
                    en = uzak[v] > en ? uzak[v] : en;
                }
            }
            printf("2) Yapay ağ (ortak LCG, tohum 2026): N = %d yazar, "
                   "M = %d makale (2-4 yazar)\n", N, M);
            long derece100 = (100L * liste + N / 2) / N;  /* yuvarlanmış */
            printf("   kenar = %ld, merkezin (0) derecesi = %zu, ortalama "
                   "derece = %ld.%02ld\n", liste / 2, komsu[0].boyut,
                   derece100 / 100, derece100 % 100);
            printf("   merkezden uzaklık dağılımı:");
            for (int d = 0; d <= en; d++) {
                printf(" %d:%ld", d, dagilim[d]);
            }
            printf(" ∞:%d\n", N - ulasilan);
            long yuzde = (100L * toplam + ulasilan / 2) / ulasilan;
            printf("   ulaşılan = %d / %d, ortalama uzaklık = %ld.%02ld, en "
                   "büyük = %d\n", ulasilan, N, yuzde / 100, yuzde % 100,
                   en);
            sonuc = 0;
        }
    }
    komsu_birak(komsu, N);
    free(uzak);
    free(ebeveyn);
    free(q);
    free(dagilim);
    return sonuc;
}

int main(int argc, char *argv[])
{
    long N = 2000, M = 3000;
    if (argc < 2 || argc == 3 || argc > 4) {
        fprintf(stderr, "Kullanım: H11_13_ortak_yazarlik AG_DOSYASI [N M]\n");
        return 2;
    }
    if (argc == 4) {
        char *son1, *son2;
        N = strtol(argv[2], &son1, 10);
        M = strtol(argv[3], &son2, 10);
        if (*son1 != '\0' || *son2 != '\0' || N < 5 || N > 1000000 ||
            M < 1 || M > 5000000) {
            fprintf(stderr, "N 5..1000000, M 1..5000000 olmalı\n");
            return 2;
        }
    }
    if (kurgusal_ag(argv[1]) != 0) {
        return 1;
    }
    return yapay_ag((int)N, (int)M);
}

/* Kütüphane karşılığı: C — yok (elle; ikili arama için bsearch); C++ —
 * yok (std::lower_bound, std::unordered_map ad -> köşe); Python — yok
 * (bisect, dict; networkx.shortest_path_length yalnız doğrulama için). */

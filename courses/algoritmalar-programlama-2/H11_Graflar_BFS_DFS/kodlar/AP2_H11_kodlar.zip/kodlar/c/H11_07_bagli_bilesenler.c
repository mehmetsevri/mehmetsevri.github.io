/* H11_07_bagli_bilesenler.c — AP-2 Hafta 11 · Örnek 7 (★★)
 * Amaç    : Bağlı bileşenler: her etiketsiz köşeden (artan sırada) bir
 *           BFS; bileşen sayısı ve etiketleri; bileşen başına köşe/kenar
 *           sayısı ve yönsüz grafta döngü (kenar >= köşe <=> ağaç değil);
 *           "aynı bileşende mi?" sorusu etiket karşılaştırmasıyla O(1)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_07_bagli_bilesenler.c -o H11_07_bagli_bilesenler
 * Çalıştır: ./H11_07_bagli_bilesenler ../girdiler/graf_bilesen.txt \
 *           ../girdiler/graf_ornek.txt
 * Eşleri  : cpp/H11_07_bagli_bilesenler.cpp ·
 *           python/H11_07_bagli_bilesenler.py
 * Çıktı   : üç dilde aynı (=); yalnız yönsüz graflar içindir
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

typedef struct {
    long ekleme, inceleme;       /* kuyruğa ekleme, incelenen komşu */
    int bfs_sayisi;
} Sayac;

/* s'nin bileşenini BFS ile 'no' etiketiyle işaretler. q: V'lik kuyruk
 * dizisi; bileşenin köşeleri q[0..dönüş-1]'de BFS sırasıyla kalır.
 * ilk_dongu: ağaç dışı ilk kenar (yoksa -1, -1). */
static int bileseni_etiketle(const Graf *g, int s, int no, int etiket[],
                             int ebeveyn[], int q[], int ilk_dongu[2],
                             Sayac *say)
{
    int bas = 0, son = 0;
    etiket[s] = no;
    ebeveyn[s] = -1;
    q[son++] = s;
    say->ekleme++;
    say->bfs_sayisi++;
    while (bas < son) {
        int u = q[bas++];
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            int v = g->komsu[u].veri[i];
            say->inceleme++;
            if (etiket[v] == -1) {
                etiket[v] = no;
                ebeveyn[v] = u;
                q[son++] = v;
                say->ekleme++;
            } else if (v != ebeveyn[u] && ilk_dongu[0] == -1) {
                ilk_dongu[0] = u;        /* ağaç dışı kenar: döngü */
                ilk_dongu[1] = v;
            }
        }
    }
    return son;
}

static int rapor(const char *ad, const Graf *g)
{
    int *etiket = malloc((size_t)g->V * sizeof(int));
    int *ebeveyn = malloc((size_t)g->V * sizeof(int));
    int *q = malloc((size_t)g->V * sizeof(int));
    int *kose = calloc((size_t)g->V, sizeof(int));     /* bileşen başına */
    long *kenar = calloc((size_t)g->V, sizeof(long));
    int *dongu = malloc(2 * (size_t)g->V * sizeof(int));
    Sayac say = {0, 0, 0};
    int k = 0;
    if (!etiket || !ebeveyn || !q || !kose || !kenar || !dongu) {
        free(etiket); free(ebeveyn); free(q); free(kose); free(kenar);
        free(dongu);
        return 1;
    }
    printf("%s (yönsüz, V = %d, E = %d)\n", ad, g->V, g->E);
    for (int v = 0; v < g->V; v++) {
        etiket[v] = -1;
    }
    for (int s = 0; s < g->V; s++) {
        if (etiket[s] != -1) {
            continue;                    /* zaten bir bileşende */
        }
        dongu[2 * k] = dongu[2 * k + 1] = -1;
        int n = bileseni_etiketle(g, s, k, etiket, ebeveyn, q,
                                  &dongu[2 * k], &say);
        printf("   BFS(%d): bileşen %d = {", s, k);
        for (int i = 0; i < n; i++) {
            printf(i ? " %d" : "%d", q[i]);
        }
        printf("}\n");
        kose[k] = n;
        k++;
    }
    for (int u = 0; u < g->V; u++) {
        kenar[etiket[u]] += (long)g->komsu[u].boyut;   /* her kenar 2 kez */
    }
    printf("   bileşen sayısı = %d\n   etiketler: köşe   ", k);
    for (int v = 0; v < g->V; v++) {
        printf(" %d", v);
    }
    printf("\n              bileşen");
    for (int v = 0; v < g->V; v++) {
        printf(" %d", etiket[v]);
    }
    printf("\n   bileşen  köşe  kenar  ağaç dışı  döngü\n");
    for (int c = 0; c < k; c++) {
        long e = kenar[c] / 2;
        printf("   %7d  %4d  %5ld  %9ld  ", c, kose[c], e, e - kose[c] + 1);
        if (e >= kose[c]) {
            printf("var (ör. kenar %d-%d)\n", dongu[2 * c],
                   dongu[2 * c + 1]);
        } else {
            printf("yok (%s)\n", kose[c] == 1 ? "yalnız köşe" : "ağaç");
        }
    }
    printf("   sayaçlar: BFS çağrısı = %d, kuyruğa ekleme = %ld (= V), "
           "kenar inceleme = %ld (= 2E)\n", say.bfs_sayisi, say.ekleme,
           say.inceleme);
    int a[2][2] = {{0, g->V - 2}, {1, g->V - 1}};
    printf("   aynı bileşende mi (etiket karşılaştırması, O(1)):");
    for (int i = 0; i < 2; i++) {
        int x = a[i][0], y = a[i][1];
        printf(" %d ve %d: %s%s", x, y,
               etiket[x] == etiket[y] ? "evet" : "hayır", i ? "\n" : ";");
    }
    free(etiket); free(ebeveyn); free(q); free(kose); free(kenar);
    free(dongu);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_07_bagli_bilesenler GRAF [GRAF2 ...]\n");
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (graf_yukle(argv[i], &g) != 0) {
            return 1;
        }
        if (g.yonlu || g.V < 2) {
            fprintf(stderr, "%s: yönsüz ve V >= 2 bir graf gerekir\n",
                    taban_ad(argv[i]));
            graf_birak(&g);
            return 1;
        }
        printf("%d) ", i);
        int sonuc = rapor(taban_ad(argv[i]), &g);
        graf_birak(&g);
        if (sonuc != 0) {
            return 1;
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * connected_components); Python — yok (networkx.connected_components
 * yalnız doğrulama için). Birleşim–bul (H12) ikinci bir yoldur. */

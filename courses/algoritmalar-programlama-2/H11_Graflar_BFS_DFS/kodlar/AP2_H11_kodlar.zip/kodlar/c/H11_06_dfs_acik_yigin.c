/* H11_06_dfs_acik_yigin.c — AP-2 Hafta 11 · Örnek 6 (★★)
 * Amaç    : Özyinelemesiz DFS (açık yığın). Özyinelemeli sürümle AYNI
 *           sırayı vermenin iki yolu: (A) yığında (köşe, sıradaki komşu
 *           indisi) çerçeveleri — keşif/bitiş ve kenar sınıfları da aynı;
 *           (B) komşular TERS sırada itilir, işaret ÇIKARIRKEN konur —
 *           ziyaret sırası aynı, yığına fazladan öğe girer. (C) artan
 *           sırada itmek başka bir sıra verir. Kâhin: özyinelemeli DFS.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_06_dfs_acik_yigin.c -o H11_06_dfs_acik_yigin
 * Çalıştır: ./H11_06_dfs_acik_yigin ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_yonlu.txt
 * Eşleri  : cpp/H11_06_dfs_acik_yigin.cpp · python/H11_06_dfs_acik_yigin.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

enum { BEYAZ, GRI, SIYAH };
enum { AGAC, GERI, ILERI, CAPRAZ };

typedef struct {
    int *renk, *kesif, *bitis;
    int *sira, adim;                 /* ziyaret (keşif) sırası */
    int *tur, tur_sayisi;            /* yönlüde kenar sınıfları */
    int zaman;
} Dfs;

typedef struct {
    int u;                           /* köşe */
    size_t i;                        /* sıradaki komşunun indisi */
} Cerceve;

/* Sahiplik: d'nin dizileri çağıranındır (dfs_birak). 0 / -1 */
static int dfs_hazirla(const Graf *g, Dfs *d)
{
    size_t V = (size_t)g->V;
    d->renk = malloc(V * sizeof(int));
    d->kesif = malloc(V * sizeof(int));
    d->bitis = malloc(V * sizeof(int));
    d->sira = malloc(V * sizeof(int));
    d->tur = malloc(((size_t)g->E + 1) * sizeof(int));
    if (!d->renk || !d->kesif || !d->bitis || !d->sira || !d->tur) {
        return -1;
    }
    for (int u = 0; u < g->V; u++) {
        d->renk[u] = BEYAZ;
        d->kesif[u] = d->bitis[u] = 0;
    }
    d->adim = d->tur_sayisi = d->zaman = 0;
    return 0;
}

static void dfs_birak(Dfs *d)
{
    free(d->renk);
    free(d->kesif);
    free(d->bitis);
    free(d->sira);
    free(d->tur);
}

/* (u, v) kenarının sınıfı; v'nin rengi değişmeden ÖNCE çağrılır */
static int sinif(const Dfs *d, int u, int v)
{
    if (d->renk[v] == BEYAZ) {
        return AGAC;
    }
    if (d->renk[v] == GRI) {
        return GERI;
    }
    return d->kesif[u] < d->kesif[v] ? ILERI : CAPRAZ;
}

static void kesfet(Dfs *d, int u)
{
    d->renk[u] = GRI;
    d->kesif[u] = ++d->zaman;
    d->sira[d->adim++] = u;
}

/* Kâhin: Örnek 5'teki özyinelemeli DFS */
static void ozy_ziyaret(const Graf *g, int u, Dfs *d)
{
    kesfet(d, u);
    for (size_t i = 0; i < g->komsu[u].boyut; i++) {
        int v = g->komsu[u].veri[i];
        if (g->yonlu) {
            d->tur[d->tur_sayisi++] = sinif(d, u, v);
        }
        if (d->renk[v] == BEYAZ) {
            ozy_ziyaret(g, v, d);
        }
    }
    d->renk[u] = SIYAH;
    d->bitis[u] = ++d->zaman;
}

static void cerceve_yaz(const Cerceve y[], int n)
{
    printf("yığın: [");
    for (int k = 0; k < n; k++) {
        printf(k ? " %d:%zu" : "%d:%zu", y[k].u, y[k].i);
    }
    printf("]\n");
}

/* (A) Çerçeve yığını: tepedeki (u, i) çerçevesi u'nun i. komşusuyla
 * sürer; komşu kalmayınca u biter ve çerçeve çıkarılır. Özyinelemeli
 * çağrının yerel değişkenleri (u, i) burada açıkça saklanır. */
static int dfs_cerceve(const Graf *g, int kok, Dfs *d, int iz)
{
    Cerceve *y = malloc((size_t)g->V * sizeof *y);  /* köşe başına 1 */
    int n = 0;
    if (y == NULL) {
        return -1;
    }
    kesfet(d, kok);
    y[n++] = (Cerceve){kok, 0};
    if (iz) {
        printf("   it %d          ", kok);
        cerceve_yaz(y, n);
    }
    while (n > 0) {
        Cerceve *c = &y[n - 1];
        if (c->i < g->komsu[c->u].boyut) {
            int v = g->komsu[c->u].veri[c->i++];
            if (g->yonlu) {
                d->tur[d->tur_sayisi++] = sinif(d, c->u, v);
            }
            if (d->renk[v] == BEYAZ) {
                kesfet(d, v);
                y[n++] = (Cerceve){v, 0};
                if (iz) {
                    printf("   it %d          ", v);
                    cerceve_yaz(y, n);
                }
            }
        } else {
            d->renk[c->u] = SIYAH;
            d->bitis[c->u] = ++d->zaman;
            n--;
            if (iz) {
                printf("   çıkar %d (%2d)  ", y[n].u, d->bitis[y[n].u]);
                cerceve_yaz(y, n);
            }
        }
    }
    free(y);
    return 0;
}

static void yigin_yaz(const int y[], int n)
{
    printf("yığın: [");
    for (int k = 0; k < n; k++) {
        printf(k ? " %d" : "%d", y[k]);
    }
    printf("]\n");
}

/* (B) ters ve (C) artan sırada itme: işaret ÇIKARIRKEN konur, zaten
 * ziyaret edilmiş öğe atlanır. Bir köşe yığına birden çok kez girebilir
 * (en çok derecesi kadar): kapasite V + 2E yeter. */
static int dfs_itmeli(const Graf *g, int kok, int ters, int sira[],
                      long *itme, long *atlanan, int iz)
{
    int *y = malloc(((size_t)g->V + 2 * (size_t)g->E) * sizeof *y);
    char *ziyaret = calloc((size_t)g->V, 1);
    int n = 0, adim = 0;
    if (y == NULL || ziyaret == NULL) {
        free(y);
        free(ziyaret);
        return -1;
    }
    *itme = 1;
    *atlanan = 0;
    y[n++] = kok;
    while (n > 0) {
        int u = y[--n];
        if (ziyaret[u]) {
            (*atlanan)++;
            if (iz) {
                printf("   çıkar %d: zaten ziyaretli, atla;  ", u);
                yigin_yaz(y, n);
            }
            continue;
        }
        ziyaret[u] = 1;
        sira[adim++] = u;
        if (iz) {
            printf("   çıkar %d: ziyaret (%d.), it:", u, adim);
        }
        size_t k = g->komsu[u].boyut;
        int itilen = 0;
        for (size_t j = 0; j < k; j++) {
            int v = g->komsu[u].veri[ters ? k - 1 - j : j];
            if (!ziyaret[v]) {
                y[n++] = v;
                (*itme)++;
                itilen++;
                if (iz) {
                    printf(" %d", v);
                }
            }
        }
        if (iz) {
            printf("%s;  ", itilen ? "" : " -");
            yigin_yaz(y, n);
        }
    }
    free(y);
    free(ziyaret);
    return adim;
}

static void sira_yaz(const char *baslik, const int a[], int n)
{
    printf("%s", baslik);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

static int ayni_mi(const int a[], const int b[], int n)
{
    return memcmp(a, b, (size_t)n * sizeof(int)) == 0;
}

/* Yönsüz graf: (A), (B), (C) izleri ve özyinelemeliyle karşılaştırma */
static int yonsuz_rapor(const Graf *g, const Dfs *ozy)
{
    Dfs a;
    long itme, atlanan;
    int *sira = malloc((size_t)g->V * sizeof(int));
    int sonuc = -1;
    if (sira != NULL && dfs_hazirla(g, &a) == 0) {
        printf("   (A) çerçeve yığını, u:i = köşe:sıradaki komşu indisi; "
               "çıkarken (bitiş zamanı)\n");
        sonuc = dfs_cerceve(g, 0, &a, 1);
    }
    if (sonuc == 0) {
        sira_yaz("   (A) ziyaret sırası:", a.sira, a.adim);
        printf("   (A) özyinelemeliyle aynı mı: sıra %s, keşif %s, bitiş "
               "%s\n", ayni_mi(a.sira, ozy->sira, g->V) ? "evet" : "HAYIR",
               ayni_mi(a.kesif, ozy->kesif, g->V) ? "evet" : "HAYIR",
               ayni_mi(a.bitis, ozy->bitis, g->V) ? "evet" : "HAYIR");
        printf("   (B) komşular TERS sırada itilir, işaret çıkarırken:\n");
        int n = dfs_itmeli(g, 0, 1, sira, &itme, &atlanan, 1);
        sonuc = n < 0 ? -1 : 0;
        if (n >= 0) {
            sira_yaz("   (B) ziyaret sırası:", sira, n);
            printf("   (B) yığına ekleme = %ld (V = %d), atlanan = %ld; "
                   "özyinelemeliyle aynı sıra mı: %s\n", itme, g->V,
                   atlanan, ayni_mi(sira, ozy->sira, n) ? "evet" : "HAYIR");
            n = dfs_itmeli(g, 0, 0, sira, &itme, &atlanan, 0);
            sonuc = n < 0 ? -1 : 0;
        }
        if (n >= 0) {
            sira_yaz("   (C) artan sırada itilirse:", sira, n);
            printf("   (C) özyinelemeliyle aynı sıra mı: %s (en son itilen "
                   "en BÜYÜK komşu önce çıkar)\n",
                   ayni_mi(sira, ozy->sira, n) ? "evet" : "hayır");
        }
    }
    if (sira != NULL) {
        dfs_birak(&a);
    }
    free(sira);
    return sonuc;
}

/* Yönlü graf: (A) ile DFS ormanı; zamanlar ve kenar sınıfları */
static int yonlu_rapor(const Graf *g, const Dfs *ozy)
{
    Dfs a;
    int sayi[4] = {0, 0, 0, 0};
    if (dfs_hazirla(g, &a) != 0) {
        dfs_birak(&a);
        return -1;
    }
    for (int r = 0; r < g->V; r++) {
        if (a.renk[r] == BEYAZ && dfs_cerceve(g, r, &a, 0) != 0) {
            dfs_birak(&a);
            return -1;
        }
    }
    for (int k = 0; k < a.tur_sayisi; k++) {
        sayi[a.tur[k]]++;
    }
    sira_yaz("   (A) ziyaret sırası:", a.sira, a.adim);
    printf("   (A) keşif/bitiş:");
    for (int u = 0; u < g->V; u++) {
        printf(" %d:%d/%d", u, a.kesif[u], a.bitis[u]);
    }
    printf("\n   (A) özyinelemeliyle aynı mı: sıra %s, keşif %s, bitiş %s, "
           "kenar sınıfları %s\n",
           ayni_mi(a.sira, ozy->sira, g->V) ? "evet" : "HAYIR",
           ayni_mi(a.kesif, ozy->kesif, g->V) ? "evet" : "HAYIR",
           ayni_mi(a.bitis, ozy->bitis, g->V) ? "evet" : "HAYIR",
           a.tur_sayisi == ozy->tur_sayisi &&
           ayni_mi(a.tur, ozy->tur, a.tur_sayisi) ? "evet" : "HAYIR");
    printf("   kenar sınıfları: ağaç %d, geri %d, ileri %d, çapraz %d\n",
           sayi[AGAC], sayi[GERI], sayi[ILERI], sayi[CAPRAZ]);
    dfs_birak(&a);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_06_dfs_acik_yigin GRAF [GRAF2 ...]\n");
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        Dfs ozy;
        int sonuc = -1;
        if (graf_yukle(argv[i], &g) != 0) {
            return 1;
        }
        if (dfs_hazirla(&g, &ozy) == 0) {
            for (int r = 0; r < g.V; r++) {
                if (ozy.renk[r] == BEYAZ) {
                    ozy_ziyaret(&g, r, &ozy);   /* kâhin */
                }
            }
            printf("%d) %s (%s, V = %d, E = %d)\n", i, taban_ad(argv[i]),
                   g.yonlu ? "yönlü" : "yönsüz", g.V, g.E);
            sira_yaz("   özyinelemeli DFS (kâhin) sırası:", ozy.sira,
                     ozy.adim);
            sonuc = g.yonlu ? yonlu_rapor(&g, &ozy) : yonsuz_rapor(&g, &ozy);
        }
        dfs_birak(&ozy);
        graf_birak(&g);
        if (sonuc != 0) {
            return 1;
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (yığın elle, H9); C++ — yok (std::stack
 * yalnız yığın; Boost.Graph depth_first_search); Python — yok (list
 * yığın olarak; networkx.dfs_preorder_nodes yalnız doğrulama için). */

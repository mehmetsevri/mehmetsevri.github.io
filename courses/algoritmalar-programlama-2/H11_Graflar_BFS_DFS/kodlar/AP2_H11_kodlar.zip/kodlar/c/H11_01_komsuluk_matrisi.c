/* H11_01_komsuluk_matrisi.c — AP-2 Hafta 11 · Örnek 1 (★)
 * Amaç    : Komşuluk matrisi (AP-1 H11 2B dizisi): yönsüz G ve yönlü G3;
 *           derece, giriş/çıkış derecesi, el sıkışma lemması denetimi;
 *           satır taramasıyla komşu bulma (her köşe için V hücre okunur)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_01_komsuluk_matrisi.c -o H11_01_komsuluk_matrisi
 * Çalıştır: ./H11_01_komsuluk_matrisi
 * Eşleri  : cpp/H11_01_komsuluk_matrisi.cpp ·
 *           python/H11_01_komsuluk_matrisi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_V 16

/* Haftanın örnek grafı G (girdiler/graf_ornek.txt ile aynı kenarlar) */
static const int G_KENAR[][2] = {
    {4, 5}, {0, 2}, {6, 7}, {1, 3}, {0, 1},
    {4, 6}, {2, 4}, {3, 5}, {5, 7}, {1, 4},
};
/* Yönlü G3 (girdiler/graf_yonlu.txt ile aynı kenarlar): u -> v */
static const int G3_KENAR[][2] = {
    {4, 5}, {2, 0}, {0, 1}, {5, 6}, {7, 5}, {2, 3},
    {0, 4}, {6, 4}, {3, 1}, {1, 2}, {4, 3}, {0, 2},
};

static int matris[MAKS_V][MAKS_V];  /* matris[u][v] = 1: u -> v kenarı */
static long okunan_hucre = 0;       /* satır taramasında okunan hücre */

static void matris_kur(int V, const int kenar[][2], int E, int yonlu)
{
    for (int u = 0; u < V; u++) {
        for (int v = 0; v < V; v++) {
            matris[u][v] = 0;
        }
    }
    for (int i = 0; i < E; i++) {
        int u = kenar[i][0], v = kenar[i][1];
        matris[u][v] = 1;
        if (!yonlu) {
            matris[v][u] = 1;       /* yönsüz: iki yönde de */
        }
    }
}

static void matris_yaz(int V)
{
    printf("       ");
    for (int v = 0; v < V; v++) {
        printf(" %d", v);
    }
    printf("\n");
    for (int u = 0; u < V; u++) {
        printf("    %d: ", u);
        for (int v = 0; v < V; v++) {
            printf(" %d", matris[u][v]);
        }
        printf("\n");
    }
}

/* Simetrikse -1, değilse ilk asimetrik hücrenin u * V + v değeri */
static int asimetri(int V)
{
    for (int u = 0; u < V; u++) {
        for (int v = u + 1; v < V; v++) {
            if (matris[u][v] != matris[v][u]) {
                return u * V + v;
            }
        }
    }
    return -1;
}

/* u'nun komşuları: satır u baştan sona taranır (V hücre) */
static int komsulari_bul(int V, int u, int komsu[])
{
    int k = 0;
    for (int v = 0; v < V; v++) {
        okunan_hucre++;
        if (matris[u][v] != 0) {
            komsu[k++] = v;
        }
    }
    return k;
}

static void yonsuz_bolum(void)
{
    const int V = 8;
    const int E = (int)(sizeof G_KENAR / sizeof G_KENAR[0]);
    int derece[MAKS_V], komsu[MAKS_V];
    int toplam = 0, bir_olan = 0;
    matris_kur(V, G_KENAR, E, 0);
    printf("1) Yönsüz G: V = %d, E = %d; matris[u][v] = matris[v][u] = 1\n",
           V, E);
    matris_yaz(V);
    printf("   simetrik mi: %s\n", asimetri(V) < 0 ? "evet" : "hayır");
    printf("   komşular (satır taraması) ve derece:\n");
    okunan_hucre = 0;
    for (int u = 0; u < V; u++) {
        int k = komsulari_bul(V, u, komsu);
        derece[u] = k;
        toplam += k;
        printf("    %d: derece %d, komşular:", u, k);
        for (int i = 0; i < k; i++) {
            printf(" %d", komsu[i]);
        }
        printf("\n");
    }
    for (int u = 0; u < V; u++) {
        for (int v = 0; v < V; v++) {
            bir_olan += matris[u][v];
        }
    }
    printf("   okunan hücre = %ld = V² = %d (komşu sayısından bağımsız)\n",
           okunan_hucre, V * V);
    printf("   el sıkışma lemması: Σ derece = %d, 2E = %d -> %s\n", toplam,
           2 * E, toplam == 2 * E ? "doğru" : "YANLIŞ");
    printf("   1 olan hücre = %d / %d (her kenar iki hücrede)\n", bir_olan,
           V * V);
    int en = 0;
    for (int u = 1; u < V; u++) {
        if (derece[u] > derece[en]) {
            en = u;                 /* eşitlikte küçük numara kalır */
        }
    }
    printf("   en büyük derece: köşe %d (%d)\n\n", en, derece[en]);
}

/* d[u] == 0 olan köşeleri yazar; hiç yoksa " yok" */
static void sifirlari_yaz(int V, const int d[])
{
    int sayi = 0;
    for (int u = 0; u < V; u++) {
        if (d[u] == 0) {
            printf(" %d", u);
            sayi++;
        }
    }
    if (sayi == 0) {
        printf(" yok");
    }
}

static void yonlu_bolum(void)
{
    const int V = 8;
    const int E = (int)(sizeof G3_KENAR / sizeof G3_KENAR[0]);
    int cikis[MAKS_V], giris[MAKS_V];
    int top_cikis = 0, top_giris = 0;
    matris_kur(V, G3_KENAR, E, 1);
    printf("2) Yönlü G3: V = %d, E = %d; matris[u][v] = 1: u -> v\n", V, E);
    matris_yaz(V);
    int a = asimetri(V);
    if (a < 0) {
        printf("   simetrik mi: evet\n");
    } else {
        printf("   simetrik mi: hayır (ör. matris[%d][%d] = %d, "
               "matris[%d][%d] = %d)\n", a / V, a % V,
               matris[a / V][a % V], a % V, a / V, matris[a % V][a / V]);
    }
    for (int u = 0; u < V; u++) {
        cikis[u] = giris[u] = 0;
    }
    for (int u = 0; u < V; u++) {
        for (int v = 0; v < V; v++) {
            cikis[u] += matris[u][v];   /* satır toplamı */
            giris[v] += matris[u][v];   /* sütun toplamı */
        }
    }
    printf("   köşe:          ");
    for (int u = 0; u < V; u++) {
        printf(" %d", u);
    }
    printf("\n   çıkış derecesi:");
    for (int u = 0; u < V; u++) {
        printf(" %d", cikis[u]);
        top_cikis += cikis[u];
    }
    printf("\n   giriş derecesi:");
    for (int u = 0; u < V; u++) {
        printf(" %d", giris[u]);
        top_giris += giris[u];
    }
    printf("\n   Σ çıkış = %d, Σ giriş = %d, E = %d -> %s\n", top_cikis,
           top_giris, E,
           top_cikis == E && top_giris == E ? "doğru" : "YANLIŞ");
    printf("   kaynak (giriş 0):");
    sifirlari_yaz(V, giris);
    printf("; kuyu (çıkış 0):");
    sifirlari_yaz(V, cikis);
    printf("\n\n");
}

int main(void)
{
    yonsuz_bolum();
    yonlu_bolum();
    printf("3) Matris belleği V² hücredir (1 bayt/hücre varsayımıyla):\n");
    long long vler[] = {8, 1000, 100000};
    for (int i = 0; i < 3; i++) {
        long long v = vler[i];
        printf("   V = %7lld -> V² = %12lld hücre\n", v, v * v);
    }
    printf("   (V = 100000 için 10^10 hücre ≈ 10 GB: bkz. Kaputun Altında)\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (2B dizi elle); C++ — yok (std::vector
 * ile 2B dizi; Boost.Graph adjacency_matrix); Python — yok (liste
 * listesi; networkx.to_numpy_array yalnız doğrulama için). */

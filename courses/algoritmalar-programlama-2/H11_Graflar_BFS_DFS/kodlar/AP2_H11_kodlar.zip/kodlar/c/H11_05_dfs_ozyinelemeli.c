/* H11_05_dfs_ozyinelemeli.c — AP-2 Hafta 11 · Örnek 5 (★★)
 * Amaç    : Özyinelemeli derinlik öncelikli arama (DFS): ziyaret sırası,
 *           keşif/bitiş zamanları, üç renk (beyaz/gri/siyah), parantez
 *           yapısı; yönsüzde ağaç ve geri kenarlar; yönlüde ağaç / geri /
 *           ileri / çapraz kenar sınıflaması (DFS ormanı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_05_dfs_ozyinelemeli.c -o H11_05_dfs_ozyinelemeli
 * Çalıştır: ./H11_05_dfs_ozyinelemeli ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_yonlu.txt
 * Eşleri  : cpp/H11_05_dfs_ozyinelemeli.cpp ·
 *           python/H11_05_dfs_ozyinelemeli.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

enum { BEYAZ, GRI, SIYAH };              /* keşfedilmedi / yolda / bitti */
enum { AGAC, GERI, ILERI, CAPRAZ };
static const char *const RENK_ADI[] = {"beyaz", "gri", "siyah"};
static const char *const SINIF_ADI[] = {"ağaç", "geri", "ileri", "çapraz"};

typedef struct {
    int *renk, *kesif, *bitis, *ebeveyn;
    int *sira, adim;                     /* ziyaret (keşif) sırası */
    int *olay, olay_sayisi;              /* u: "(u", -1 - u: "u)" */
    int *ku, *kv, *ktur, kenar_sayisi;   /* sınıflanan kenarlar */
    int *kv_renk;                        /* incelenirken v'nin rengi */
    int zaman, derinlik, en_derin;
} Dfs;

static void kenar_kaydet(Dfs *d, int u, int v, int tur)
{
    d->ku[d->kenar_sayisi] = u;
    d->kv[d->kenar_sayisi] = v;
    d->ktur[d->kenar_sayisi] = tur;
    d->kv_renk[d->kenar_sayisi] = d->renk[v];
    d->kenar_sayisi++;
}

/* Özyinelemeli DFS: u gri olur, beyaz komşulara inilir, u siyah olur */
static void dfs_ziyaret(const Graf *g, int u, Dfs *d)
{
    d->renk[u] = GRI;
    d->kesif[u] = ++d->zaman;
    d->sira[d->adim++] = u;
    d->olay[d->olay_sayisi++] = u;
    if (++d->derinlik > d->en_derin) {
        d->en_derin = d->derinlik;
    }
    for (size_t i = 0; i < g->komsu[u].boyut; i++) {
        int v = g->komsu[u].veri[i];
        if (d->renk[v] == BEYAZ) {
            kenar_kaydet(d, u, v, AGAC);
            d->ebeveyn[v] = u;
            dfs_ziyaret(g, v, d);
        } else if (g->yonlu) {
            kenar_kaydet(d, u, v, d->renk[v] == GRI ? GERI :
                         d->kesif[u] < d->kesif[v] ? ILERI : CAPRAZ);
        } else if (d->renk[v] == GRI && v != d->ebeveyn[u]) {
            kenar_kaydet(d, u, v, GERI);  /* yönsüz: atasına kenar */
        }
    }
    d->derinlik--;
    d->renk[u] = SIYAH;
    d->bitis[u] = ++d->zaman;
    d->olay[d->olay_sayisi++] = -1 - u;
}

static void dfs_birak(Dfs *d)
{
    int **diziler[] = {&d->renk, &d->kesif, &d->bitis, &d->ebeveyn,
                       &d->sira, &d->olay, &d->ku, &d->kv, &d->ktur,
                       &d->kv_renk};
    for (size_t i = 0; i < sizeof diziler / sizeof diziler[0]; i++) {
        free(*diziler[i]);
        *diziler[i] = NULL;
    }
}

/* Sahiplik: d'nin dizileri çağıranındır (dfs_birak). 0 / -1 bellek */
static int dfs_hazirla(const Graf *g, Dfs *d)
{
    size_t V = (size_t)g->V, E = (size_t)g->E + 1;
    size_t boy[] = {V, V, V, V, V, 2 * V, E, E, E, E};
    int **diziler[] = {&d->renk, &d->kesif, &d->bitis, &d->ebeveyn,
                       &d->sira, &d->olay, &d->ku, &d->kv, &d->ktur,
                       &d->kv_renk};
    int tamam = 1;
    for (size_t i = 0; i < sizeof diziler / sizeof diziler[0]; i++) {
        *diziler[i] = malloc(boy[i] * sizeof(int));
        tamam = tamam && *diziler[i] != NULL;
    }
    if (!tamam) {
        dfs_birak(d);
        return -1;
    }
    for (int u = 0; u < g->V; u++) {
        d->renk[u] = BEYAZ;
        d->ebeveyn[u] = -1;
    }
    d->adim = d->olay_sayisi = d->kenar_sayisi = 0;
    d->zaman = d->derinlik = d->en_derin = 0;
    return 0;
}

static void tablo_yaz(const Graf *g, const Dfs *d)
{
    printf("   ziyaret sırası (keşif):");
    for (int i = 0; i < d->adim; i++) {
        printf(" %d", d->sira[i]);
    }
    printf("\n   köşe  keşif  bitiş  ebeveyn\n");
    for (int u = 0; u < g->V; u++) {
        printf("   %4d  %5d  %5d  %7d\n", u, d->kesif[u], d->bitis[u],
               d->ebeveyn[u]);
    }
    printf("   parantez yapısı:");
    for (int i = 0; i < d->olay_sayisi; i++) {
        int x = d->olay[i];
        if (x >= 0) {
            printf(" (%d", x);
        } else {
            printf(" %d)", -1 - x);
        }
    }
    printf("\n");
}

/* DFS ormanı: her beyaz köşeden (artan sırada) yeni bir ağaç. Kökleri
 * yazar; ağaç sayısını döndürür. */
static int dfs_orman(const Graf *g, Dfs *d)
{
    int agac = 0;
    printf("DFS ormanı, kökler artan sırada:");
    for (int r = 0; r < g->V; r++) {
        if (d->renk[r] == BEYAZ) {
            printf(" %d", r);
            dfs_ziyaret(g, r, d);
            agac++;
        }
    }
    printf("\n");
    return agac;
}

static void yonsuz_rapor(const Graf *g, Dfs *d)
{
    int agac = dfs_orman(g, d);
    tablo_yaz(g, d);
    for (int tur = AGAC; tur <= GERI; tur++) {
        int sayi = 0;
        for (int i = 0; i < d->kenar_sayisi; i++) {
            sayi += d->ktur[i] == tur;
        }
        printf("   %s kenarları (%d = %s %d):", SINIF_ADI[tur], sayi,
               tur == AGAC ? "V -" : "E - V +", agac);
        for (int i = 0; i < d->kenar_sayisi; i++) {
            if (d->ktur[i] == tur) {
                printf(" %d-%d", d->ku[i], d->kv[i]);
            }
        }
        printf("\n");
    }
    printf("   (yönsüz DFS'de ileri ve çapraz kenar olmaz; siyah komşuya "
           "giden kenar zaten geri kenar olarak sayıldı)\n");
    printf("   en büyük özyineleme derinliği = %d\n", d->en_derin);
}

static void yonlu_rapor(const Graf *g, Dfs *d)
{
    int sayi[4] = {0, 0, 0, 0};
    dfs_orman(g, d);
    tablo_yaz(g, d);
    printf("   kenarlar (incelenme sırasıyla):\n");
    for (int i = 0; i < d->kenar_sayisi; i++) {
        int u = d->ku[i], v = d->kv[i];
        sayi[d->ktur[i]]++;
        printf("   %2d) %d->%d: v %s", i + 1, u, v, RENK_ADI[d->kv_renk[i]]);
        if (d->kv_renk[i] == SIYAH) {
            printf(", keşif[%d] = %d %c keşif[%d] = %d", u, d->kesif[u],
                   d->kesif[u] < d->kesif[v] ? '<' : '>', v, d->kesif[v]);
        }
        printf(" -> %s\n", SINIF_ADI[d->ktur[i]]);
    }
    printf("   sayılar: ağaç %d, geri %d, ileri %d, çapraz %d (toplam %d = "
           "E)\n", sayi[AGAC], sayi[GERI], sayi[ILERI], sayi[CAPRAZ],
           d->kenar_sayisi);
    printf("   geri kenar %s: yönlü döngü %s (bkz. Örnek 12)\n",
           sayi[GERI] > 0 ? "var" : "yok", sayi[GERI] > 0 ? "var" : "yok");
    printf("   en büyük özyineleme derinliği = %d\n", d->en_derin);
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_05_dfs_ozyinelemeli GRAF [GRAF2 ...]\n");
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        Dfs d;
        if (graf_yukle(argv[i], &g) != 0) {
            return 1;
        }
        if (dfs_hazirla(&g, &d) != 0) {
            graf_birak(&g);
            return 1;
        }
        printf("%d) %s (%s, V = %d, E = %d): ", i, taban_ad(argv[i]),
               g.yonlu ? "yönlü" : "yönsüz", g.V, g.E);
        if (g.yonlu) {
            yonlu_rapor(&g, &d);
        } else {
            yonsuz_rapor(&g, &d);
        }
        dfs_birak(&d);
        graf_birak(&g);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * depth_first_search + ziyaretçi olayları tree_edge/back_edge/
 * forward_or_cross_edge); Python — yok (networkx.dfs_preorder_nodes,
 * dfs_labeled_edges yalnız doğrulama için). */

/* H11_09_tasma_doldurma.c — AP-2 Hafta 11 · Örnek 9 (★★)
 * Amaç    : Örtük graf: ızgaranın her hücresi bir köşe, komşu hücreler
 *           kenar (kenarlar saklanmaz, hesaplanır). Taşkın doldurma (BFS
 *           dalgası) ve ada sayma; 4 ve 8 komşuluk (AP-1 H11 di/dj
 *           dizileri). Sınır denetimi komşuya ERİŞMEDEN ÖNCE yapılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_09_tasma_doldurma.c -o H11_09_tasma_doldurma
 * Çalıştır: ./H11_09_tasma_doldurma < ../girdiler/H11_09_tasma_doldurma.txt
 *           (ilk satır "S Y r0 c0", sonra S satır: '#' kara, '.' su)
 * Eşleri  : cpp/H11_09_tasma_doldurma.cpp ·
 *           python/H11_09_tasma_doldurma.py
 * Çıktı   : üç dilde aynı (=); yön sırası yukarı, aşağı, sol, sağ; hata: kod 1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS 100

/* İlk 4: yukarı, aşağı, sol, sağ (4-komşuluk); son 4: çaprazlar */
static const int di[8] = {-1, 1, 0, 0, -1, -1, 1, 1};
static const int dj[8] = {0, 0, -1, 1, -1, 1, -1, 1};

static int S, Y;                       /* satır ve sütun sayısı */
static long deneme = 0, sinir_disi = 0;

/* (i, j) ızgarada mı? Hücreye erişmeden ÖNCE çağrılır. */
static int icinde(int i, int j)
{
    return i >= 0 && i < S && j >= 0 && j < Y;
}

/* (i0, j0)'dan başlayıp 'eski' karakterli hücreleri 'yeni' yapar (BFS).
 * yon: 4 ya da 8. q: S * Y'lik kuyruk. katman != NULL ise her hücrenin
 * dalga numarası yazılır. Dönüş: değiştirilen hücre sayısı. */
static int doldur(char *iz, int i0, int j0, char eski, char yeni, int yon,
                  int q[], int katman[])
{
    int bas = 0, son = 0;
    iz[i0 * Y + j0] = yeni;               /* işaret kuyruğa EKLERKEN */
    q[son++] = i0 * Y + j0;
    if (katman != NULL) {
        katman[i0 * Y + j0] = 0;
    }
    while (bas < son) {
        int h = q[bas++], i = h / Y, j = h % Y;
        for (int k = 0; k < yon; k++) {
            int ni = i + di[k], nj = j + dj[k];
            deneme++;
            if (!icinde(ni, nj)) {
                sinir_disi++;              /* erişilmeden reddedildi */
                continue;
            }
            if (iz[ni * Y + nj] == eski) {
                iz[ni * Y + nj] = yeni;
                q[son++] = ni * Y + nj;
                if (katman != NULL) {
                    katman[ni * Y + nj] = katman[h] + 1;
                }
            }
        }
    }
    return son;
}

static void izgara_yaz(const char *iz)
{
    for (int i = 0; i < S; i++) {
        printf("   %.*s\n", Y, iz + (size_t)i * Y);
    }
}

/* Adaları (kara '#') yon-komşulukla A, B, C, ... harfleriyle boyar.
 * etiket[h] = ada numarası (karada) ya da -1. Dönüş: ada sayısı. */
static int adalari_say(const char *harita, char *iz, int yon, int q[],
                       int etiket[], int boyut[])
{
    int ada = 0;
    memcpy(iz, harita, (size_t)S * Y);
    for (int h = 0; h < S * Y; h++) {
        etiket[h] = -1;
    }
    for (int h = 0; h < S * Y; h++) {
        if (iz[h] != '#') {
            continue;
        }
        char harf = ada < 26 ? (char)('A' + ada) : '*';
        int n = doldur(iz, h / Y, h % Y, '#', harf, yon, q, NULL);
        for (int k = 0; k < n; k++) {
            etiket[q[k]] = ada;           /* q[0..n-1] adanın hücreleri */
        }
        boyut[ada++] = n;
    }
    return ada;
}

static void boyut_yaz(const int boyut[], int ada)
{
    printf("   boyutlar:");
    for (int a = 0; a < ada; a++) {
        printf(" %c=%d", a < 26 ? 'A' + a : '*', boyut[a]);
    }
    printf("\n");
}

/* İlk satır "S Y r0 c0", sonra S satır; yalnız '#' ve '.' */
static char *izgara_oku(int *r0, int *c0)
{
    char satir[MAKS + 3];
    long x[4];
    if (fgets(satir, sizeof satir, stdin) == NULL) {
        return NULL;
    }
    char *p = satir;
    for (int k = 0; k < 4; k++) {
        char *son;
        x[k] = strtol(p, &son, 10);
        if (son == p) {
            return NULL;
        }
        p = son;
    }
    if (x[0] < 1 || x[0] > MAKS || x[1] < 1 || x[1] > MAKS || x[2] < 0 ||
        x[2] >= x[0] || x[3] < 0 || x[3] >= x[1]) {
        return NULL;
    }
    S = (int)x[0];
    Y = (int)x[1];
    *r0 = (int)x[2];
    *c0 = (int)x[3];
    char *harita = malloc((size_t)S * Y);
    if (harita == NULL) {
        return NULL;
    }
    for (int i = 0; i < S; i++) {
        if (fgets(satir, sizeof satir, stdin) == NULL) {
            free(harita);
            return NULL;
        }
        satir[strcspn(satir, "\r\n")] = '\0';
        if ((int)strlen(satir) != Y ||
            strspn(satir, "#.") != (size_t)Y) {
            free(harita);
            return NULL;
        }
        memcpy(harita + (size_t)i * Y, satir, (size_t)Y);
    }
    return harita;
}

int main(void)
{
    int r0, c0;
    char *harita = izgara_oku(&r0, &c0);
    if (harita == NULL) {
        fprintf(stderr, "Hatalı ızgara girdisi\n");
        return 1;
    }
    size_t n = (size_t)S * Y;
    char *iz = malloc(n);
    int *q = malloc(n * sizeof(int));
    int *katman = malloc(n * sizeof(int));
    int *etiket4 = malloc(n * sizeof(int));
    int *etiket8 = malloc(n * sizeof(int));
    int *boyut = malloc(n * sizeof(int));
    if (!iz || !q || !katman || !etiket4 || !etiket8 || !boyut) {
        free(harita); free(iz); free(q); free(katman); free(etiket4);
        free(etiket8); free(boyut);
        return 1;
    }
    printf("Izgara %d x %d ('#' kara, '.' su); taşkın başlangıcı (%d, %d)\n",
           S, Y, r0, c0);
    memcpy(iz, harita, n);
    if (iz[r0 * Y + c0] != '.') {
        printf("1) Başlangıç hücresi su değil: doldurma yapılmadı\n");
    } else {
        int dolan = doldur(iz, r0, c0, '.', '~', 4, q, katman);
        int kalan = 0;
        for (size_t h = 0; h < n; h++) {
            kalan += iz[h] == '.';
        }
        printf("1) Taşkın doldurma (BFS, 4-komşuluk): (%d, %d)'dan "
               "ulaşılan su '~'\n", r0, c0);
        izgara_yaz(iz);
        printf("   doldurulan hücre = %d, dalga sayısı = %d (en uzak "
               "hücre %d adımda)\n", dolan, katman[q[dolan - 1]] + 1,
               katman[q[dolan - 1]]);
        printf("   komşu denemesi = %ld, sınır dışı = %ld (komşuya "
               "ERİŞMEDEN reddedildi)\n", deneme, sinir_disi);
        printf("   doldurulmayan su hücresi = %d (çevresi kara: göl)\n",
               kalan);
        printf("   dalga numaraları (mod 10; '#' kara, '.' ulaşılmayan):\n");
        for (int i = 0; i < S; i++) {
            printf("   ");
            for (int j = 0; j < Y; j++) {
                char k = iz[i * Y + j];
                putchar(k == '~' ? '0' + katman[i * Y + j] % 10 : k);
            }
            printf("\n");
        }
    }
    int ada4 = adalari_say(harita, iz, 4, q, etiket4, boyut);
    printf("2) Ada sayma, 4-komşuluk (yalnız dik yönler): %d ada\n", ada4);
    izgara_yaz(iz);
    boyut_yaz(boyut, ada4);
    int ada8 = adalari_say(harita, iz, 8, q, etiket8, boyut);
    printf("3) Ada sayma, 8-komşuluk (çaprazlar da): %d ada\n", ada8);
    izgara_yaz(iz);
    boyut_yaz(boyut, ada8);
    printf("   8-komşulukta birleşenler (4-komşuluk adaları):");
    int birlesme = 0;
    for (int b = 0; b < ada8; b++) {
        int uyeler[26], m = 0;
        for (int a = 0; a < ada4 && a < 26; a++) {
            for (size_t h = 0; h < n; h++) {
                if (etiket4[h] == a) {        /* adanın ilk hücresi */
                    if (etiket8[h] == b) {
                        uyeler[m++] = a;
                    }
                    break;
                }
            }
        }
        if (m > 1) {
            printf(birlesme++ ? ";" : "");
            for (int k = 0; k < m; k++) {
                printf(k ? "+%c" : " %c", 'A' + uyeler[k]);
            }
            printf(" -> %c", b < 26 ? 'A' + b : '*');
        }
    }
    printf("%s\n", birlesme ? "" : " yok");
    free(harita); free(iz); free(q); free(katman); free(etiket4);
    free(etiket8); free(boyut);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok; Python — yok
 * (scipy.ndimage.label ve OpenCV floodFill/connectedComponents görüntü
 * işlemede aynı işi yapar; ders dışı). */

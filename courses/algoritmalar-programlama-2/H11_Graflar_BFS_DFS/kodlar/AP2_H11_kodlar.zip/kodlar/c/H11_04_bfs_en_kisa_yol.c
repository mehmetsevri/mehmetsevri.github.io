/* H11_04_bfs_en_kisa_yol.c — AP-2 Hafta 11 · Örnek 4 (★★)
 * Amaç    : BFS ile ağırlıksız en kısa yol: uzaklık (kenar sayısı) ve
 *           ebeveyn dizileri; yolun ebeveyn dizisinden GERİ ÇIKARILMASI;
 *           ulaşılamayan köşe sözleşmesi: uzaklık = -1, ebeveyn = -1;
 *           kenar koşuluyla doğrulama (|d[u] - d[v]| <= 1)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_04_bfs_en_kisa_yol.c -o H11_04_bfs_en_kisa_yol
 * Çalıştır: ./H11_04_bfs_en_kisa_yol ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_bilesen.txt
 * Eşleri  : cpp/H11_04_bfs_en_kisa_yol.cpp ·
 *           python/H11_04_bfs_en_kisa_yol.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

/* BFS(s): uzak[v] = en az kenar sayısı, ebeveyn[v] = BFS ağacında v'yi
 * keşfeden köşe; ulaşılamayan v için ikisi de -1. Kuyruk: H9 dizi
 * kuyruğu (her köşe en çok bir kez girer). Dönüş: ulaşılan sayısı. */
static int bfs_uzaklik(const Graf *g, int s, int uzak[], int ebeveyn[])
{
    int *q = malloc((size_t)g->V * sizeof *q);
    int bas = 0, son = 0;
    if (q == NULL) {
        return -1;
    }
    for (int v = 0; v < g->V; v++) {
        uzak[v] = -1;
        ebeveyn[v] = -1;
    }
    uzak[s] = 0;
    q[son++] = s;
    while (bas < son) {
        int u = q[bas++];
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            int v = g->komsu[u].veri[i];
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                ebeveyn[v] = u;          /* v'ye ilk u'dan ulaşıldı */
                q[son++] = v;
            }
        }
    }
    free(q);
    return son;
}

/* s'den t'ye yolu ebeveyn zincirinden geri çıkarır: yol[0..k] = s..t.
 * Dönüş: yoldaki kenar sayısı k; yol yoksa -1. */
static int yol_cikar(const int ebeveyn[], int s, int t, int yol[])
{
    int k = 0;
    if (t != s && ebeveyn[t] == -1) {
        return -1;                       /* ulaşılamaz */
    }
    for (int v = t; v != -1; v = ebeveyn[v]) {
        yol[k++] = v;                    /* t, ebeveyn[t], ..., s */
    }
    for (int i = 0, j = k - 1; i < j; i++, j--) {
        int gecici = yol[i];             /* ters çevir: s .. t */
        yol[i] = yol[j];
        yol[j] = gecici;
    }
    return k - 1;
}

/* Kâhin: ulaşılan her u'nun her komşusu v de ulaşılmıştır ve
 * d[v] <= d[u] + 1 (yönsüzde iki yönden: |d[u] - d[v]| <= 1); ulaşılan
 * her v != s için d[v] = d[ebeveyn[v]] + 1. */
static int dogrula(const Graf *g, int s, const int uzak[],
                   const int ebeveyn[])
{
    for (int u = 0; u < g->V; u++) {
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            int v = g->komsu[u].veri[i];
            if (uzak[u] != -1 && (uzak[v] == -1 || uzak[v] > uzak[u] + 1)) {
                return 0;
            }
        }
        if (u != s && uzak[u] != -1 && uzak[u] != uzak[ebeveyn[u]] + 1) {
            return 0;
        }
    }
    return 1;
}

static int rapor(const char *yol_adi, const Graf *g, int s)
{
    int *uzak = malloc((size_t)g->V * sizeof(int));
    int *ebeveyn = malloc((size_t)g->V * sizeof(int));
    int *yol = malloc((size_t)g->V * sizeof(int));
    int ulasilan = -1;
    if (uzak != NULL && ebeveyn != NULL && yol != NULL) {
        ulasilan = bfs_uzaklik(g, s, uzak, ebeveyn);
    }
    if (ulasilan >= 0) {
        printf("%s (V = %d, E = %d): kaynak %d\n", yol_adi, g->V, g->E, s);
        printf("   köşe  uzaklık  ebeveyn  en kısa yol\n");
        int en_uzak = s;
        for (int t = 0; t < g->V; t++) {
            int k = yol_cikar(ebeveyn, s, t, yol);
            printf("   %4d  %7d  %7d  ", t, uzak[t], ebeveyn[t]);
            if (k < 0) {
                printf("ulaşılamaz (yol yok)\n");
                continue;
            }
            for (int i = 0; i <= k; i++) {
                printf(i == 0 ? "%d" : " -> %d", yol[i]);
            }
            printf("\n");
            if (uzak[t] > uzak[en_uzak]) {
                en_uzak = t;
            }
        }
        printf("   ulaşılan = %d / %d; en uzak köşe %d (%d kenar)\n",
               ulasilan, g->V, en_uzak, uzak[en_uzak]);
        printf("   kâhin (kenar koşulu + ebeveyn tutarlılığı): %s\n",
               dogrula(g, s, uzak, ebeveyn) ? "geçti" : "KALDI");
    }
    free(uzak);
    free(ebeveyn);
    free(yol);
    return ulasilan >= 0 ? 0 : 1;
}

int main(int argc, char *argv[])
{
    Graf g;
    int sonuc = 0;
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_04_bfs_en_kisa_yol GRAF [GRAF2 ...]\n");
        return 2;
    }
    for (int i = 1; i < argc && sonuc == 0; i++) {
        if (graf_yukle(argv[i], &g) != 0) {
            return 1;
        }
        printf("%d) ", i);
        sonuc = rapor(taban_ad(argv[i]), &g, 0);
        graf_birak(&g);
    }
    return sonuc;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * breadth_first_search + predecessor ziyaretçisi); Python — yok
 * (networkx.single_source_shortest_path yalnız doğrulama için). */

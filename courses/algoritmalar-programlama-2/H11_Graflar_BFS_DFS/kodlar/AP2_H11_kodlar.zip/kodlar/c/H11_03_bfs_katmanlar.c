/* H11_03_bfs_katmanlar.c — AP-2 Hafta 11 · Örnek 3 (★★)
 * Amaç    : Genişlik öncelikli arama (BFS): kuyrukla dolaşma, ziyaret
 *           işareti kuyruğa EKLERKEN konur; adım adım kuyruk içeriği,
 *           ziyaret sırası, katmanlar; ekleme/inceleme sayaçları
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_03_bfs_katmanlar.c -o H11_03_bfs_katmanlar
 * Çalıştır: ./H11_03_bfs_katmanlar ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_yonlu.txt
 * Eşleri  : cpp/H11_03_bfs_katmanlar.cpp · python/H11_03_bfs_katmanlar.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

/* H9 dizi kuyruğu: her köşe kuyruğa en çok bir kez girdiği için kapasite
 * V yeter, sarma gerekmez. Dolu bölge veri[bas..son-1]. */
typedef struct {
    int *veri;               /* sahiplik: kuyruğundur (free) */
    int bas, son;
} Kuyruk;

typedef struct {
    long ekleme;             /* kuyruğa ekleme */
    long inceleme;           /* incelenen komşu (kenar ucu) */
    int en_uzun;             /* en uzun kuyruk */
} Sayac;

static void kuyruk_yaz(const Kuyruk *q)
{
    printf("[");
    for (int i = q->bas; i < q->son; i++) {
        printf(i > q->bas ? " %d" : "%d", q->veri[i]);
    }
    printf("]");
}

/* BFS(s): katman[v] = s'den v'ye en az kenar sayısı (ulaşılamayan -1),
 * sira[0..] ziyaret sırası; dönüş: ulaşılan köşe sayısı (-1: bellek yok).
 * ayrinti != 0 ise her adım yazdırılır. */
static int bfs(const Graf *g, int s, int katman[], int sira[], Sayac *say,
               int ayrinti)
{
    Kuyruk q = {malloc((size_t)g->V * sizeof(int)), 0, 0};
    int adim = 0;
    if (q.veri == NULL) {
        return -1;
    }
    for (int v = 0; v < g->V; v++) {
        katman[v] = -1;                     /* -1: henüz görülmedi */
    }
    say->inceleme = 0;
    katman[s] = 0;                          /* işaret EKLERKEN */
    q.veri[q.son++] = s;
    say->ekleme = say->en_uzun = 1;
    if (ayrinti) {
        printf("   başlangıç: %d kuyruğa eklendi; kuyruk: ", s);
        kuyruk_yaz(&q);
        printf("\n");
    }
    while (q.bas < q.son) {
        int u = q.veri[q.bas++];            /* kuyruğun başından çıkar */
        sira[adim++] = u;
        if (ayrinti) {
            printf("   adım %d: çıkan %d (katman %d); eklenen:", adim, u,
                   katman[u]);
        }
        int eklenen = 0;
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            int v = g->komsu[u].veri[i];
            say->inceleme++;
            if (katman[v] == -1) {
                katman[v] = katman[u] + 1;  /* işaret EKLERKEN */
                q.veri[q.son++] = v;
                say->ekleme++;
                eklenen++;
                if (ayrinti) {
                    printf(" %d", v);
                }
            }
        }
        if (q.son - q.bas > say->en_uzun) {
            say->en_uzun = q.son - q.bas;
        }
        if (ayrinti) {
            printf("%s; kuyruk: ", eklenen ? "" : " -");
            kuyruk_yaz(&q);
            printf("\n");
        }
    }
    free(q.veri);
    return adim;
}

static void sira_yaz(const char *baslik, const int a[], int n)
{
    printf("%s", baslik);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

/* Katmanları ziyaret sırasıyla yazar: katman k = s'den k kenar uzakta */
static void katmanlari_yaz(const int katman[], const int sira[], int n,
                           int satir_satir)
{
    int en_derin = n > 0 ? katman[sira[n - 1]] : -1;
    if (!satir_satir) {
        printf("   katmanlar:");
    }
    for (int k = 0; k <= en_derin; k++) {
        printf(satir_satir ? "   katman %d:" : " [", k);
        int ilk = 1;
        for (int i = 0; i < n; i++) {
            if (katman[sira[i]] == k) {
                printf(satir_satir || !ilk ? " %d" : "%d", sira[i]);
                ilk = 0;
            }
        }
        printf(satir_satir ? "\n" : "]");
    }
    if (!satir_satir) {
        printf("\n");
    }
}

static void sayac_yaz(const Sayac *say, const char *ek_not)
{
    printf("   sayaçlar: kuyruğa ekleme = %ld, kenar inceleme = %ld%s, en "
           "uzun kuyruk = %d\n", say->ekleme, say->inceleme, ek_not,
           say->en_uzun);
}

/* Kısa rapor: ziyaret sırası, katmanlar, ulaşılamayanlar, sayaçlar */
static int kisa_bfs(const Graf *g, int s, const char *ek_not)
{
    int *katman = malloc((size_t)g->V * sizeof(int));
    int *sira = malloc((size_t)g->V * sizeof(int));
    Sayac say;
    int n = -1;
    if (katman != NULL && sira != NULL) {
        n = bfs(g, s, katman, sira, &say, 0);
    }
    if (n >= 0) {
        sira_yaz("   ziyaret sırası:", sira, n);
        katmanlari_yaz(katman, sira, n, 0);
        if (n < g->V) {
            printf("   ulaşılamayan:");
            for (int v = 0; v < g->V; v++) {
                if (katman[v] == -1) {
                    printf(" %d", v);
                }
            }
            printf("\n");
        }
        sayac_yaz(&say, ek_not);
    }
    free(katman);
    free(sira);
    return n >= 0 ? 0 : 1;
}

/* Ayrıntılı rapor: her adımda çıkan köşe, eklenenler ve kuyruk */
static int ayrintili_bfs(const Graf *g, int s)
{
    int *katman = malloc((size_t)g->V * sizeof(int));
    int *sira = malloc((size_t)g->V * sizeof(int));
    Sayac say;
    int n = -1;
    if (katman != NULL && sira != NULL) {
        printf("1) BFS(%d): ziyaret işareti kuyruğa EKLERKEN konur\n", s);
        n = bfs(g, s, katman, sira, &say, 1);
    }
    if (n >= 0) {
        sira_yaz("   ziyaret sırası:", sira, n);
        katmanlari_yaz(katman, sira, n, 1);
        sayac_yaz(&say, g->yonlu ? "" : " (= 2E: her kenar iki uçtan)");
    }
    free(katman);
    free(sira);
    return n >= 0 ? 0 : 1;
}

int main(int argc, char *argv[])
{
    Graf g;
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_03_bfs_katmanlar GRAF [GRAF2]\n");
        return 2;
    }
    if (graf_yukle(argv[1], &g) != 0) {
        return 1;
    }
    printf("Graf: %s (V = %d, E = %d, %s)\n", taban_ad(argv[1]), g.V, g.E,
           g.yonlu ? "yönlü" : "yönsüz");
    int sonuc = ayrintili_bfs(&g, 0);
    if (sonuc == 0) {
        printf("2) BFS(%d): aynı graf, başka kaynak\n", g.V - 1);
        sonuc = kisa_bfs(&g, g.V - 1, "");
    }
    graf_birak(&g);
    if (sonuc == 0 && argc > 2) {
        if (graf_yukle(argv[2], &g) != 0) {
            return 1;
        }
        printf("3) %s (%s, V = %d, E = %d): BFS(0)\n", taban_ad(argv[2]),
               g.yonlu ? "yönlü" : "yönsüz", g.V, g.E);
        sonuc = kisa_bfs(&g, 0, g.yonlu ? " (ulaşılan köşelerin çıkış "
                                          "dereceleri toplamı)" : "");
        graf_birak(&g);
    }
    return sonuc;
}

/* Kütüphane karşılığı: C — yok (kuyruk elle, H9); C++ — yok (std::queue
 * yalnız kuyruk; Boost.Graph breadth_first_search); Python — yok
 * (collections.deque yalnız kuyruk; networkx.bfs_layers doğrulama için). */

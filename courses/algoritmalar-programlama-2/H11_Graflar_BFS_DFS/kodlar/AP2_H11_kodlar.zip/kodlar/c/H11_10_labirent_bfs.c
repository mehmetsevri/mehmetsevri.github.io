/* H11_10_labirent_bfs.c — AP-2 Hafta 11 · Örnek 10 (★★★)
 * Amaç    : Labirentte en kısa yol: ızgara BFS (H3 ile aynı yön sırası:
 *           sağ, aşağı, sol, yukarı); ebeveyn dizisinden yol. AYNI
 *           labirentte H3 Örnek 11'in geri izleme çözümüyle karşılaştırma:
 *           bulunan yol uzunluğu ve ziyaret edilen hücre sayısı. Ek olarak
 *           açık bir odada geri izlemenin uzun yol bulduğu durum.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_10_labirent_bfs.c -o H11_10_labirent_bfs
 * Çalıştır: ./H11_10_labirent_bfs < ../girdiler/H11_10_labirent_bfs.txt
 *           (girdi, H3'ün H03_11_labirent.txt dosyasının aynısıdır)
 * Eşleri  : cpp/H11_10_labirent_bfs.cpp · python/H11_10_labirent_bfs.py
 * Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_SATIR 40
#define MAKS_SUTUN 80

typedef struct {
    char h[MAKS_SATIR][MAKS_SUTUN + 2];     /* + '\n' ve '\0' */
    int S, Y;                               /* satır, sütun sayısı */
    int sr, sc, er, ec;                     /* S ve E konumları */
} Labirent;

static const int DR[4] = {0, 1, 0, -1};     /* sağ, aşağı, sol, yukarı */
static const int DC[4] = {1, 0, -1, 0};

/* Açık oda: geri izlemenin en kısa yolu kaçırdığı küçük örnek */
static const char *const ODA[] = {
    "#########", "#S......#", "#.......#", "#E......#", "#########",
};

typedef struct {
    int uzunluk;          /* yoldaki adım (kenar) sayısı; yoksa -1 */
    long ziyaret;         /* BFS: kuyruktan çıkan; geri izleme: çağrı */
    long eklenen;         /* BFS: kuyruğa eklenen */
    long geri_donulen;    /* geri izleme: çıkmaz hücre */
} Sonuc;

static int acik_mi(const Labirent *L, int r, int c)
{
    return r >= 0 && r < L->S && c >= 0 && c < L->Y && L->h[r][c] != '#';
}

/* Izgara BFS: S'den başlar, E kuyruktan çıkınca durur. Yol '*', işlenen
 * öteki hücreler 'o', kuyrukta kalan (sınır) hücreler '+' ile işaretlenir
 * (L değiştirilir). */
static Sonuc bfs_labirent(Labirent *L)
{
    Sonuc s = {-1, 0, 0, 0};
    int n = L->S * L->Y;
    int *ebeveyn = malloc((size_t)n * sizeof(int));
    int *q = malloc((size_t)n * sizeof(int));
    int bas = 0, son = 0;
    if (ebeveyn == NULL || q == NULL) {
        free(ebeveyn);
        free(q);
        return s;
    }
    for (int i = 0; i < n; i++) {
        ebeveyn[i] = -2;                    /* -2: görülmedi */
    }
    int kaynak = L->sr * L->Y + L->sc, hedef = L->er * L->Y + L->ec;
    ebeveyn[kaynak] = -1;
    q[son++] = kaynak;
    while (bas < son) {
        int h = q[bas++], r = h / L->Y, c = h % L->Y;
        if (h == hedef) {
            break;                          /* E kuyruktan çıktı */
        }
        for (int d = 0; d < 4; d++) {
            int yr = r + DR[d], yc = c + DC[d];
            if (acik_mi(L, yr, yc) && ebeveyn[yr * L->Y + yc] == -2) {
                ebeveyn[yr * L->Y + yc] = h;
                q[son++] = yr * L->Y + yc;
            }
        }
    }
    s.ziyaret = bas;
    s.eklenen = son;
    for (int i = 0; i < son; i++) {         /* işlenen ve sınır */
        int r = q[i] / L->Y, c = q[i] % L->Y;
        if (L->h[r][c] == '.') {
            L->h[r][c] = i < bas ? 'o' : '+';
        }
    }
    if (ebeveyn[hedef] != -2) {
        s.uzunluk = 0;
        for (int h = ebeveyn[hedef]; h != kaynak; h = ebeveyn[h]) {
            L->h[h / L->Y][h % L->Y] = '*'; /* ebeveyn zinciri: yol */
            s.uzunluk++;
        }
        s.uzunluk++;                        /* son adım: E'ye giriş */
    }
    free(ebeveyn);
    free(q);
    return s;
}

/* H3 Örnek 11'in geri izlemesi (aynı kod): (r, c)'den çıkışa yol ara */
static int yol_bul(Labirent *L, int r, int c, Sonuc *s)
{
    s->ziyaret++;
    if (L->h[r][c] == 'E') {
        return 1;                           /* çıkışa ulaşıldı */
    }
    if (L->h[r][c] != 'S') {
        L->h[r][c] = '*';                   /* seç: hücre yola eklenir */
    }
    for (int d = 0; d < 4; d++) {
        int yr = r + DR[d], yc = c + DC[d];
        if (yr >= 0 && yr < L->S && yc >= 0 && yc < L->Y &&
            (L->h[yr][yc] == '.' || L->h[yr][yc] == 'E') &&
            yol_bul(L, yr, yc, s)) {
            return 1;                       /* yol bulundu: '*'lar kalır */
        }
    }
    if (L->h[r][c] != 'S') {
        L->h[r][c] = 'x';                   /* geri al: buradan çıkış yok */
    }
    s->geri_donulen++;
    return 0;
}

static Sonuc geri_izleme(Labirent *L)
{
    Sonuc s = {-1, 0, 0, 0};
    if (yol_bul(L, L->sr, L->sc, &s)) {
        s.uzunluk = 1;
        for (int r = 0; r < L->S; r++) {
            for (int c = 0; c < L->Y; c++) {
                s.uzunluk += L->h[r][c] == '*';
            }
        }
    }
    return s;
}

static void yaz(const Labirent *L)
{
    for (int r = 0; r < L->S; r++) {
        printf("   %s\n", L->h[r]);
    }
}

/* S ve E'yi bulur; tam bir S ve bir E yoksa 0 */
static int konumlari_bul(Labirent *L)
{
    int s_sayisi = 0, e_sayisi = 0;
    for (int r = 0; r < L->S; r++) {
        for (int c = 0; c < L->Y; c++) {
            if (L->h[r][c] == 'S') {
                s_sayisi++;
                L->sr = r;
                L->sc = c;
            } else if (L->h[r][c] == 'E') {
                e_sayisi++;
                L->er = r;
                L->ec = c;
            } else if (L->h[r][c] != '#' && L->h[r][c] != '.') {
                return 0;
            }
        }
    }
    return s_sayisi == 1 && e_sayisi == 1;
}

/* H3 ile aynı girdi biçimi: ilk satır "satır sütun", ardından ızgara */
static int labirent_oku(Labirent *L)
{
    char satir[64];
    char *son;
    if (fgets(satir, sizeof satir, stdin) == NULL) {
        return 0;
    }
    long r = strtol(satir, &son, 10);
    char *p = son;
    long c = strtol(p, &son, 10);
    if (son == p || r < 1 || r > MAKS_SATIR || c < 1 || c > MAKS_SUTUN) {
        return 0;
    }
    L->S = (int)r;
    L->Y = (int)c;
    for (int i = 0; i < L->S; i++) {
        if (fgets(L->h[i], sizeof L->h[i], stdin) == NULL) {
            return 0;
        }
        L->h[i][strcspn(L->h[i], "\r\n")] = '\0';
        if ((int)strlen(L->h[i]) != L->Y) {
            return 0;
        }
    }
    return konumlari_bul(L);
}

static void karsilastir(const Labirent *asil)
{
    Labirent a = *asil, b = *asil;          /* yapı kopyası */
    Sonuc s1 = bfs_labirent(&a);
    Sonuc s2 = geri_izleme(&b);
    int acik = 0;
    for (int r = 0; r < asil->S; r++) {
        for (int c = 0; c < asil->Y; c++) {
            acik += asil->h[r][c] != '#';
        }
    }
    printf("   BFS (kuyruk; E kuyruktan çıkınca durur): yol = %d adım, "
           "işlenen = %ld, kuyruğa eklenen = %ld, açık hücre = %d\n",
           s1.uzunluk, s1.ziyaret, s1.eklenen, acik);
    yaz(&a);
    printf("   (* yol, o işlenen, + kuyrukta kalan sınır hücresi)\n");
    printf("   Geri izleme (H3 Örnek 11): yol = %d adım, ziyaret = %ld "
           "çağrı, geri dönülen = %ld\n", s2.uzunluk, s2.ziyaret,
           s2.geri_donulen);
    yaz(&b);
    printf("   (* yol, x denenip geri dönülen hücre)\n");
    printf("   yöntem            yol (adım)  ziyaret  en kısa mı?\n");
    printf("   BFS               %10d  %7ld  evet (her zaman: katman "
           "sırası)\n", s1.uzunluk, s1.ziyaret);
    printf("   geri izleme (H3)  %10d  %7ld  %s\n", s2.uzunluk, s2.ziyaret,
           s2.uzunluk == s1.uzunluk ? "bu labirentte evet (güvence yok)"
                                    : "HAYIR (ilk bulunan yol)");
}

int main(void)
{
    Labirent L, oda;
    if (!labirent_oku(&L)) {
        fprintf(stderr, "Hatalı labirent girdisi\n");
        return 1;
    }
    printf("1) Labirent %d x %d (H3 ile aynı dosya), S = (%d, %d), "
           "E = (%d, %d)\n", L.S, L.Y, L.sr, L.sc, L.er, L.ec);
    printf("   yön sırası (H3 ile aynı): sağ, aşağı, sol, yukarı\n");
    karsilastir(&L);
    oda.S = (int)(sizeof ODA / sizeof ODA[0]);
    oda.Y = (int)strlen(ODA[0]);
    for (int r = 0; r < oda.S; r++) {
        strcpy(oda.h[r], ODA[r]);
    }
    konumlari_bul(&oda);
    printf("2) Açık oda %d x %d (programa gömülü), S = (%d, %d), "
           "E = (%d, %d)\n", oda.S, oda.Y, oda.sr, oda.sc, oda.er, oda.ec);
    karsilastir(&oda);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Izgarada en kısa yol için
 * ağırlıklı durumda Dijkstra (H12); oyunlarda sezgisel A* kullanılır. */

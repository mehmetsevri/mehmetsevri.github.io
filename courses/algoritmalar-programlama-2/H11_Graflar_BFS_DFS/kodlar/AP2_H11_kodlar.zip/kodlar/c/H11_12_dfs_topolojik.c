/* H11_12_dfs_topolojik.c — AP-2 Hafta 11 · Örnek 12 (★★★)
 * Amaç    : DFS ile topolojik sıralama ve yönlü döngü tespiti (üç renk):
 *           köşe bitince (siyah) bitiş listesine eklenir; listenin TERSİ
 *           topolojik sıradır. Gri bir köşeye giden kenar (geri kenar)
 *           döngüdür: o anki gri yol (özyineleme yığını) döngüyü verir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_12_dfs_topolojik.c -o H11_12_dfs_topolojik
 * Çalıştır: ./H11_12_dfs_topolojik ../girdiler/dersler_dag.txt \
 *           ../girdiler/dersler_dongulu.txt
 * Eşleri  : cpp/H11_12_dfs_topolojik.cpp · python/H11_12_dfs_topolojik.py
 * Çıktı   : üç dilde aynı (=); yalnız yönlü graflar içindir
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

enum { BEYAZ, GRI, SIYAH };              /* keşfedilmedi / yolda / bitti */

typedef struct {
    int *renk, *kesif, *bitis;
    int *bitis_sirasi, nb;               /* siyaha dönüş sırası */
    int *gri_yol, ng;                    /* kökten şimdiki köşeye yol */
    int zaman, dongu_u, dongu_v;         /* bulunan geri kenar (u -> v) */
} Topo;

/* Üç renkli DFS. Olayları "(u" ve "u)" olarak yazar. Gri komşu = geri
 * kenar = döngü: kenar kaydedilir, 1 döner ve bütün DFS durur. */
static int dfs_topo(const Graf *g, int u, Topo *t)
{
    t->renk[u] = GRI;
    t->kesif[u] = ++t->zaman;
    t->gri_yol[t->ng++] = u;
    printf(" (%d", u);
    for (size_t i = 0; i < g->komsu[u].boyut; i++) {
        int v = g->komsu[u].veri[i];
        if (t->renk[v] == GRI) {
            t->dongu_u = u;              /* geri kenar: döngü */
            t->dongu_v = v;
            return 1;
        }
        if (t->renk[v] == BEYAZ && dfs_topo(g, v, t)) {
            return 1;
        }
    }
    t->ng--;                             /* u gri yoldan çıkar */
    t->renk[u] = SIYAH;
    t->bitis[u] = ++t->zaman;
    t->bitis_sirasi[t->nb++] = u;        /* bütün ardılları bitti */
    printf(" %d)", u);
    return 0;
}

static void dizi_yaz(const char *baslik, const int a[], int n)
{
    printf("%s", baslik);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

static int rapor(const Graf *g)
{
    Topo t;
    int V = g->V, dongu = 0;
    t.renk = malloc((size_t)V * sizeof(int));
    t.kesif = malloc((size_t)V * sizeof(int));
    t.bitis = malloc((size_t)V * sizeof(int));
    t.bitis_sirasi = malloc((size_t)V * sizeof(int));
    t.gri_yol = malloc((size_t)V * sizeof(int));
    int *sira = malloc((size_t)V * sizeof(int));
    int *konum = malloc((size_t)V * sizeof(int));
    if (!t.renk || !t.kesif || !t.bitis || !t.bitis_sirasi || !t.gri_yol ||
        !sira || !konum) {
        free(t.renk); free(t.kesif); free(t.bitis); free(t.bitis_sirasi);
        free(t.gri_yol); free(sira); free(konum);
        return 1;
    }
    for (int u = 0; u < V; u++) {
        t.renk[u] = BEYAZ;
    }
    t.nb = t.ng = t.zaman = 0;
    t.dongu_u = t.dongu_v = -1;
    printf("   olaylar ('(u' gri oldu, 'u)' siyah oldu):");
    for (int r = 0; r < V && !dongu; r++) {
        if (t.renk[r] == BEYAZ) {
            dongu = dfs_topo(g, r, &t);
        }
    }
    printf("\n");
    if (dongu) {
        int bas = 0;
        while (t.gri_yol[bas] != t.dongu_v) {
            bas++;                       /* döngü v'den başlar */
        }
        printf("   %d->%d kenarında %d GRİ: geri kenar\n", t.dongu_u,
               t.dongu_v, t.dongu_v);
        dizi_yaz("   gri yol (özyineleme yığını) o anda:", t.gri_yol, t.ng);
        printf("   döngü:");
        for (int i = bas; i < t.ng; i++) {
            printf(" %d ->", t.gri_yol[i]);
        }
        printf(" %d (uzunluk %d)\n", t.dongu_v, t.ng - bas);
        printf("   SONUÇ: döngü var — topolojik sıra yok; o ana dek biten "
               "(siyah) köşeler:");
        for (int i = 0; i < t.nb; i++) {
            printf(" %d", t.bitis_sirasi[i]);
        }
        printf("\n");
    } else {
        dizi_yaz("   bitiş sırası (siyaha dönüş):", t.bitis_sirasi, t.nb);
        for (int i = 0; i < V; i++) {
            sira[i] = t.bitis_sirasi[V - 1 - i];      /* ters çevir */
            konum[sira[i]] = i;
        }
        dizi_yaz("   topolojik sıra (bitiş sırasının tersi):", sira, V);
        int gecerli = 1;
        for (int u = 0; u < V; u++) {
            for (size_t i = 0; i < g->komsu[u].boyut; i++) {
                gecerli = gecerli && konum[u] < konum[g->komsu[u].veri[i]];
            }
        }
        printf("   kâhin: her kenar u->v için konum[u] < konum[v]: %s "
               "(%d kenar)\n", gecerli ? "evet" : "HAYIR", g->E);
        printf("   keşif/bitiş:");
        for (int u = 0; u < V; u++) {
            printf(" %d:%d/%d", u, t.kesif[u], t.bitis[u]);
        }
        printf("\n   neden doğru: u->v kenarında v ya beyazdır (u'dan önce "
               "biter) ya siyahtır (zaten bitmiş); gri olamaz (döngü olurdu)."
               " Her durumda bitiş[v] < bitiş[u].\n");
    }
    free(t.renk); free(t.kesif); free(t.bitis); free(t.bitis_sirasi);
    free(t.gri_yol); free(sira); free(konum);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_12_dfs_topolojik GRAF [GRAF2 ...]\n");
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (graf_yukle(argv[i], &g) != 0) {
            return 1;
        }
        if (!g.yonlu) {
            fprintf(stderr, "%s: yönlü bir graf gerekir\n",
                    taban_ad(argv[i]));
            graf_birak(&g);
            return 1;
        }
        printf("%d) %s (yönlü, V = %d, E = %d): DFS, üç renk, kökler artan "
               "sırada\n", i, taban_ad(argv[i]), g.V, g.E);
        int sonuc = rapor(&g);
        graf_birak(&g);
        if (sonuc != 0) {
            return 1;
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * topological_sort; döngüde not_a_dag istisnası); Python —
 * graphlib.TopologicalSorter (CycleError; yalnız kâhin) ve
 * networkx.topological_sort / find_cycle (doğrulama için). */

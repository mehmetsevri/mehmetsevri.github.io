/* H11_08_iki_parcali.c — AP-2 Hafta 11 · Örnek 8 (★★)
 * Amaç    : İki parçalılık sınaması: BFS ile 2-renklendirme (komşunun
 *           rengi = 1 - renk). Aynı renkli iki komşu ÇELİŞKİDİR: graf iki
 *           parçalı değildir ve BFS ağacından tek uzunluklu bir döngü
 *           çıkarılır (iki ucun ortak atası üzerinden)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_08_iki_parcali.c -o H11_08_iki_parcali
 * Çalıştır: ./H11_08_iki_parcali ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_tek_dongu.txt
 * Eşleri  : cpp/H11_08_iki_parcali.cpp · python/H11_08_iki_parcali.py
 * Çıktı   : üç dilde aynı (=); yönsüz graf; kökler ve komşular artan sırada
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_KOSE 1000000L
#define MAKS_KENAR 10000000L
#define SATIR_UZ 256
#define AYRAC " \t\r\n\v\f"

/* H8 dinamik dizisi: bir köşenin komşuları */
typedef struct {
    int *veri;               /* öbekte; sahiplik: bu dizinindir */
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int V, E, yonlu;         /* yonlu: 1 yönlü, 0 yönsüz */
    KomsuDizisi *komsu;      /* V dizi; sahiplik: grafındır */
} Graf;

/* x'i sona ekler; doluysa kapasite × 2. 0: başarı, -1: bellek yok */
static int dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

static void graf_birak(Graf *g)
{
    if (g->komsu != NULL) {
        for (int u = 0; u < g->V; u++) {
            free(g->komsu[u].veri);
        }
        free(g->komsu);
        g->komsu = NULL;
    }
}

static int int_karsilastir(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

/* Yolun son bileşeni: stdout'a mutlak yol yazılmaz */
static const char *taban_ad(const char *yol)
{
    const char *p = strrchr(yol, '/');
    return p != NULL ? p + 1 : yol;
}

/* s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok */
static int tamsayi_coz(const char *s, long *x)
{
    const char *p = s + (s[0] == '-');
    size_t n = strlen(p);
    if (n == 0 || n > 9 || strspn(p, "0123456789") != n) {
        return 0;
    }
    *x = strtol(s, NULL, 10);
    return 1;
}

/* Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar.
 * 0: başarı; 1: biçim hatası; -1: bellek yok */
static int baslik_isle(char *bel[], int n, Graf *g)
{
    long V, E;
    if (!tamsayi_coz(bel[0], &V) || !tamsayi_coz(bel[1], &E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && strcmp(bel[2], "yonlu") != 0 &&
         strcmp(bel[2], "yonsuz") != 0)) {
        return 1;
    }
    g->komsu = malloc((size_t)V * sizeof *g->komsu);
    if (g->komsu == NULL) {
        return -1;
    }
    g->V = (int)V;
    g->E = (int)E;
    g->yonlu = n == 3 && strcmp(bel[2], "yonlu") == 0;
    for (int u = 0; u < g->V; u++) {
        g->komsu[u].veri = NULL;
        g->komsu[u].boyut = g->komsu[u].kapasite = 0;
    }
    return 0;
}

/* Kenar satırı "u v [w]" (w okunur ama kullanılmaz). 0 / 1 / -1 */
static int kenar_isle(char *bel[], int n, Graf *g)
{
    long x[3] = {0, 0, 0};
    for (int i = 0; i < n; i++) {
        if (!tamsayi_coz(bel[i], &x[i])) {
            return 1;
        }
    }
    if (x[0] < 0 || x[0] >= g->V || x[1] < 0 || x[1] >= g->V) {
        return 1;
    }
    if (dd_ekle(&g->komsu[x[0]], (int)x[1]) != 0 ||
        (!g->yonlu && dd_ekle(&g->komsu[x[1]], (int)x[0]) != 0)) {
        return -1;
    }
    return 0;
}

/* Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
 * dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
 * artan sıraya dizilir (belirli sıra). Sahiplik: başarıda g çağıranındır
 * (graf_birak). Hata: stderr'e ileti, dönüş 1. */
static int graf_yukle(const char *yol, Graf *g)
{
    char satir[SATIR_UZ], *bel[4];
    int no = 0, okunan = -1, durum = 0;     /* okunan -1: başlık yok */
    FILE *f = fopen(yol, "r");
    g->V = g->E = 0;
    g->komsu = NULL;
    if (f == NULL) {
        fprintf(stderr, "%s: dosya açılamadı\n", taban_ad(yol));
        return 1;
    }
    while (durum == 0 && fgets(satir, sizeof satir, f) != NULL) {
        int n = 0;
        no++;
        if (strchr(satir, '\n') == NULL && strlen(satir) == SATIR_UZ - 1) {
            durum = 1;                      /* satır çok uzun */
            break;
        }
        for (char *p = strtok(satir, AYRAC); p != NULL && n < 4;
             p = strtok(NULL, AYRAC)) {
            bel[n++] = p;
        }
        if (n == 0 || bel[0][0] == '#') {
            continue;                       /* boş satır ya da yorum */
        }
        if (n < 2 || n > 3 || okunan == g->E) {
            durum = 1;
        } else if (okunan < 0) {
            durum = baslik_isle(bel, n, g);
            okunan = 0;
        } else {
            durum = kenar_isle(bel, n, g);
            okunan++;
        }
    }
    fclose(f);
    if (durum == 0 && okunan < g->E) {
        fprintf(stderr, "%s: başlık ya da kenar eksik\n", taban_ad(yol));
    } else if (durum != 0) {
        fprintf(stderr, "%s: satır %d: %s (bkz. Örnek 2)\n", taban_ad(yol),
                no, durum < 0 ? "bellek yetersiz" : "biçim hatası");
    } else {
        for (int u = 0; u < g->V; u++) {
            if (g->komsu[u].boyut > 1) {
                qsort(g->komsu[u].veri, g->komsu[u].boyut, sizeof(int),
                      int_karsilastir);
            }
        }
        return 0;
    }
    graf_birak(g);
    return 1;
}

typedef struct {
    int *renk, *uzak, *ebeveyn, *q;      /* renk -1: boyanmadı */
    int cu, cv;                          /* çelişkili kenar; yoksa -1 */
} Boyama;

/* s'nin bileşenini BFS ile boyar; her adımı yazar. Çelişkide durur:
 * b->cu, b->cv kenarı kaydedilir, 0 döner; çelişkisizse 1. */
static int bfs_boya(const Graf *g, int s, Boyama *b)
{
    int bas = 0, son = 0;
    b->renk[s] = 0;
    b->uzak[s] = 0;
    b->ebeveyn[s] = -1;
    b->q[son++] = s;
    printf("   kök %d -> renk 0\n", s);
    while (bas < son) {
        int u = b->q[bas++];
        printf("   çıkan %d (renk %d):", u, b->renk[u]);
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            int v = g->komsu[u].veri[i];
            if (b->renk[v] == -1) {
                b->renk[v] = 1 - b->renk[u];      /* karşı renk */
                b->uzak[v] = b->uzak[u] + 1;
                b->ebeveyn[v] = u;
                b->q[son++] = v;
                printf(" %d -> %d", v, b->renk[v]);
            } else if (b->renk[v] == b->renk[u]) {
                printf(" %d ÇELİŞKİ\n", v);
                b->cu = u;
                b->cv = v;
                return 0;
            } else {
                printf(" %d uygun", v);
            }
            printf(i + 1 < g->komsu[u].boyut ? "," : "");
        }
        printf("\n");
    }
    return 1;
}

/* Çelişkili (u, v) kenarı ve BFS ağacından tek döngü: u -> .. -> ata
 * -> .. -> v (-> u). Uçların derinlikleri aynı paritededir (aynı renk),
 * bu yüzden döngünün uzunluğu (iki yol + 1 kenar) tektir. */
static void tek_dongu_yaz(const Boyama *b, int V)
{
    int *ya = malloc((size_t)V * sizeof(int));
    int *yb = malloc((size_t)V * sizeof(int));
    int na = 0, nb = 0, a = b->cu, c = b->cv;
    if (ya == NULL || yb == NULL) {
        free(ya);
        free(yb);
        return;
    }
    ya[na++] = a;
    yb[nb++] = c;
    while (b->uzak[a] > b->uzak[c]) {
        a = b->ebeveyn[a];
        ya[na++] = a;
    }
    while (b->uzak[c] > b->uzak[a]) {
        c = b->ebeveyn[c];
        yb[nb++] = c;
    }
    while (a != c) {                     /* ortak ataya birlikte çık */
        a = b->ebeveyn[a];
        c = b->ebeveyn[c];
        ya[na++] = a;
        yb[nb++] = c;
    }
    printf("   tek uzunluklu döngü:");
    for (int i = 0; i < na; i++) {
        printf(" %d ->", ya[i]);         /* u .. ata */
    }
    for (int i = nb - 2; i >= 0; i--) {
        printf(" %d ->", yb[i]);         /* ata'nın altından v'ye */
    }
    printf(" %d (uzunluk %d = %d + %d + 1; ortak ata %d)\n", b->cu,
           na + nb - 1, na - 1, nb - 1, a);
    free(ya);
    free(yb);
}

static int rapor(const char *ad, const Graf *g)
{
    Boyama b;
    int iki_parcali = 1, kenar = 0;
    b.renk = malloc((size_t)g->V * sizeof(int));
    b.uzak = malloc((size_t)g->V * sizeof(int));
    b.ebeveyn = malloc((size_t)g->V * sizeof(int));
    b.q = malloc((size_t)g->V * sizeof(int));
    b.cu = b.cv = -1;
    if (!b.renk || !b.uzak || !b.ebeveyn || !b.q) {
        free(b.renk);
        free(b.uzak);
        free(b.ebeveyn);
        free(b.q);
        return 1;
    }
    printf("%s (yönsüz, V = %d, E = %d)\n", ad, g->V, g->E);
    for (int v = 0; v < g->V; v++) {
        b.renk[v] = -1;
    }
    for (int s = 0; s < g->V && iki_parcali; s++) {
        if (b.renk[s] == -1) {
            iki_parcali = bfs_boya(g, s, &b);
        }
    }
    if (iki_parcali) {
        printf("   renkler: köşe");
        for (int v = 0; v < g->V; v++) {
            printf(" %d", v);
        }
        printf("\n            renk");
        for (int v = 0; v < g->V; v++) {
            printf(" %d", b.renk[v]);
        }
        for (int r = 0; r < 2; r++) {
            printf(r == 0 ? "\n   iki parçalı: evet; A = {" : "}, B = {");
            int ilk = 1;
            for (int v = 0; v < g->V; v++) {
                if (b.renk[v] == r) {
                    printf(ilk ? "%d" : " %d", v);
                    ilk = 0;
                }
            }
        }
        for (int u = 0; u < g->V; u++) {
            for (size_t i = 0; i < g->komsu[u].boyut; i++) {
                kenar += b.renk[u] != b.renk[g->komsu[u].veri[i]];
            }
        }
        printf("}\n   denetim: iki ucu farklı renkte olan kenar = %d / "
               "%d\n", kenar / 2, g->E);
    } else {
        printf("   çelişki: kenar (%d, %d), iki ucu da renk %d\n", b.cu,
               b.cv, b.renk[b.cu]);
        tek_dongu_yaz(&b, g->V);
        printf("   iki parçalı: hayır (tek uzunluklu döngü içeren graf "
               "2 renkle boyanamaz)\n");
    }
    free(b.renk);
    free(b.uzak);
    free(b.ebeveyn);
    free(b.q);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H11_08_iki_parcali GRAF [GRAF2 ...]\n");
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (graf_yukle(argv[i], &g) != 0) {
            return 1;
        }
        if (g.yonlu) {
            fprintf(stderr, "%s: yönsüz bir graf gerekir\n",
                    taban_ad(argv[i]));
            graf_birak(&g);
            return 1;
        }
        printf("%d) ", i);
        int sonuc = rapor(taban_ad(argv[i]), &g);
        graf_birak(&g);
        if (sonuc != 0) {
            return 1;
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * is_bipartite); Python — yok (networkx.is_bipartite yalnız doğrulama
 * için). */

"""H11_HA5_dongu_denetimsiz_duzeltilmis.py — AP-2 Hafta 11 · Hata Avcısı 5
Düzeltme: üç renk (beyaz/gri/siyah). Gri bir köşeye giden kenar geri
          kenardır: döngü vardır, sıra üretilmez; döngü gri yoldan
          yazdırılır (Örnek 12).
Çalıştır: python3 H11_HA5_dongu_denetimsiz_duzeltilmis.py
Hatalı  : H11_HA5_dongu_denetimsiz.py
"""

AD = ["ALG", "AP1", "AP2", "AYR", "MAT1", "MAT2", "NYP", "VY", "YZ"]
# dersler_dongulu.txt: 0 -> 2 kenarı AP2 -> VY -> ALG -> AP2 döngüsü kurar
KENAR = [(4, 5), (4, 3), (1, 2), (2, 7), (3, 7), (2, 6), (7, 0), (5, 0),
         (0, 8), (6, 8), (0, 2)]


BEYAZ, GRI, SIYAH = 0, 1, 2


def topolojik(V, komsu):
    """Dönüş: (sıra, None) ya da (None, döngü listesi)"""
    renk = [BEYAZ] * V
    bitis, gri_yol = [], []

    def dfs(u):
        renk[u] = GRI
        gri_yol.append(u)
        for v in komsu[u]:
            if renk[v] == GRI:          # geri kenar: döngü
                return gri_yol[gri_yol.index(v):] + [v]
            if renk[v] == BEYAZ:
                dongu = dfs(v)
                if dongu is not None:
                    return dongu
        gri_yol.pop()
        renk[u] = SIYAH
        bitis.append(u)
        return None

    for r in range(V):
        if renk[r] == BEYAZ:
            dongu = dfs(r)
            if dongu is not None:
                return None, dongu
    return bitis[::-1], None


def main():
    V = len(AD)
    komsu = [[] for _ in range(V)]
    for u, v in KENAR:
        komsu[u].append(v)
    for liste in komsu:
        liste.sort()
    sira, dongu = topolojik(V, komsu)
    if dongu is not None:
        print("HATA: önkoşullarda döngü var, ders planı yok: "
              + " -> ".join(AD[v] for v in dongu))
        return 1
    print("Ders planı: " + " ".join(AD[v] for v in sira))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""H11_HA7_derin_ozyineleme_duzeltilmis.py — AP-2 Hafta 11 · Hata Avcısı 7
Düzeltme: açık yığınlı DFS (Örnek 6, yöntem A): çerçeveler bir listede;
          Python'un özyineleme sınırı devreye girmez. sys.setrecursionlimit
          ile sınırı büyütmek C yığınını taşırıp yorumlayıcıyı ÇÖKERTEBİLİR
          (kavram K05); doğru çözüm açık yığındır.
Çalıştır: python3 H11_HA7_derin_ozyineleme_duzeltilmis.py [n]
Hatalı  : H11_HA7_derin_ozyineleme.py
"""
import sys


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 500
    ziyaret = [False] * n
    ziyaret_sayisi = en_derin = 0
    y = [[0, 0]]                        # [köşe, sıradaki komşu]
    ziyaret[0] = True
    ziyaret_sayisi = 1
    print(f"zincir n = {n}, özyineleme sınırı = {sys.getrecursionlimit()}")
    while y:
        en_derin = max(en_derin, len(y))
        c = y[-1]
        if c[1] == 2:
            y.pop()                     # komşu kalmadı: çık
            continue
        v = c[0] - 1 if c[1] == 0 else c[0] + 1
        c[1] += 1
        if 0 <= v < n and not ziyaret[v]:
            ziyaret[v] = True
            ziyaret_sayisi += 1
            y.append([v, 0])
    print(f"bitti: ziyaret = {ziyaret_sayisi}, en büyük açık yığın "
          f"derinliği = {en_derin}")


if __name__ == "__main__":
    main()

/* H11_HA7_derin_ozyineleme_duzeltilmis.c — AP-2 Hafta 11 · Hata Avcısı 7
 * Düzeltme: açık yığınlı DFS (Örnek 6, yöntem A): çerçeveler öbekte
 *           (malloc) tutulur; çağrı yığını büyümez. Yığın en çok n çerçeve
 *           tutar (n * 16 bayt); n = 10^6 için ~16 MB öbek belleği.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H11_HA7_derin_ozyineleme_duzeltilmis.c \
 *           -o H11_HA7_derin_ozyineleme_duzeltilmis
 * Çalıştır: ./H11_HA7_derin_ozyineleme_duzeltilmis [n]   (varsayılan 1000)
 * Hatalı  : H11_HA7_derin_ozyineleme.c
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    long u;          /* köşe */
    int i;           /* sıradaki komşu: 0 -> u - 1, 1 -> u + 1, 2 bitti */
} Cerceve;

int main(int argc, char *argv[])
{
    long n = argc > 1 ? strtol(argv[1], NULL, 10) : 1000;
    long ziyaret_sayisi = 0, en_derin = 0, top = 0;
    if (n < 1 || n > 100000000) {
        fprintf(stderr, "n 1..100000000 olmalı\n");
        return 2;
    }
    char *ziyaret = calloc((size_t)n, 1);
    Cerceve *y = malloc((size_t)n * sizeof *y);   /* en çok n çerçeve */
    if (ziyaret == NULL || y == NULL) {
        free(ziyaret);
        free(y);
        return 1;
    }
    printf("zincir n = %ld, açık yığınlı DFS(0) başlıyor...\n", n);
    ziyaret[0] = 1;
    ziyaret_sayisi = 1;
    y[top++] = (Cerceve){0, 0};
    while (top > 0) {
        Cerceve *c = &y[top - 1];
        if (top > en_derin) {
            en_derin = top;
        }
        if (c->i == 2) {
            top--;                           /* komşu kalmadı: çık */
            continue;
        }
        long v = c->i == 0 ? c->u - 1 : c->u + 1;
        c->i++;
        if (v >= 0 && v < n && !ziyaret[v]) {
            ziyaret[v] = 1;
            ziyaret_sayisi++;
            y[top++] = (Cerceve){v, 0};      /* öbekte, çağrı yığını değil */
        }
    }
    printf("bitti: ziyaret = %ld, en büyük açık yığın derinliği = %ld\n",
           ziyaret_sayisi, en_derin);
    free(ziyaret);
    free(y);
    return 0;
}

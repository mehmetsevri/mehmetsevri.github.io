/* H11_HA2_tek_yonlu_kenar_duzeltilmis.cpp — AP-2 Hafta 11 · Hata Avcısı 2
 * Düzeltme: yönsüz grafta her kenar İKİ listeye eklenir (u -> v ve
 *           v -> u). Σ derece = 2E (el sıkışma lemması) ve BFS(7) bütün
 *           köşelere ulaşır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_HA2_tek_yonlu_kenar_duzeltilmis.cpp \
 *           -o H11_HA2_tek_yonlu_kenar_duzeltilmis
 * Hatalı  : H11_HA2_tek_yonlu_kenar.cpp
 */
#include <iostream>
#include <queue>
#include <utility>
#include <vector>

// Haftanın örnek grafı G (yönsüz), kenarlar küçük uç önce
static const std::vector<std::pair<int, int>> G_KENAR = {
    {0, 1}, {0, 2}, {1, 3}, {1, 4}, {2, 4},
    {3, 5}, {4, 5}, {4, 6}, {5, 7}, {6, 7},
};

static std::vector<std::vector<int>> graf_kur(int V)
{
    std::vector<std::vector<int>> komsu(V);
    for (const auto& [u, v] : G_KENAR) {
        komsu[u].push_back(v);
        komsu[v].push_back(u);           // yönsüz: iki yönde de
    }
    return komsu;
}

static void bfs_yaz(const std::vector<std::vector<int>>& komsu, int s)
{
    std::vector<int> uzak(komsu.size(), -1);
    std::queue<int> q;
    uzak[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : komsu[u]) {
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q.push(v);
            }
        }
    }
    std::cout << "   BFS(" << s << ") uzaklıkları:";
    for (int d : uzak) {
        std::cout << ' ' << d;
    }
    std::cout << '\n';
}

int main()
{
    const int V = 8;
    std::vector<std::vector<int>> komsu = graf_kur(V);
    std::size_t toplam = 0;
    std::cout << "Yönsüz G (V = 8, E = " << G_KENAR.size()
              << "); komşuluk listesi:\n";
    for (int u = 0; u < V; u++) {
        std::cout << "   " << u << ':';
        for (int v : komsu[u]) {
            std::cout << ' ' << v;
        }
        std::cout << '\n';
        toplam += komsu[u].size();
    }
    std::cout << "   Σ derece = " << toplam << " (yönsüzde 2E = "
              << 2 * G_KENAR.size() << " olmalı)\n";
    bfs_yaz(komsu, 0);
    bfs_yaz(komsu, 7);
    return 0;
}

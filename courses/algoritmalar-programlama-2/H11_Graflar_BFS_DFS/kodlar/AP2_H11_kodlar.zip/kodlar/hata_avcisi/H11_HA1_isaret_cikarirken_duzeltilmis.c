/* H11_HA1_isaret_cikarirken_duzeltilmis.c — AP-2 Hafta 11 · Hata Avcısı 1
 * Düzeltme: ziyaret işareti kuyruğa EKLERKEN konur; her köşe kuyruğa en
 *           çok bir kez girer (ekleme = ulaşılan köşe sayısı), kapasite V
 *           yeter. Aynı tablolar hatalı sürümle karşılaştırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_HA1_isaret_cikarirken_duzeltilmis.c \
 *           -o H11_HA1_isaret_cikarirken_duzeltilmis
 * Çalıştır: ./H11_HA1_isaret_cikarirken_duzeltilmis [k_ust]
 *           (ızgara k = 3..k_ust; varsayılan 8)
 * Hatalı  : H11_HA1_isaret_cikarirken.c
 */
#include <stdio.h>
#include <stdlib.h>

#define MAKS_V 400

static int komsu[MAKS_V][4], derece[MAKS_V];

/* Büyüyen kuyruk (H8 dinamik dizisi): bas..son-1 dolu */
typedef struct {
    int *veri;
    long bas, son, kap;
} Kuyruk;

static void ekle(Kuyruk *q, int x)
{
    if (q->son == q->kap) {
        long yeni = 2 * q->kap;
        int *gecici = realloc(q->veri, (size_t)yeni * sizeof(int));
        if (gecici == NULL) {
            fprintf(stderr, "bellek yetersiz\n");
            exit(1);
        }
        q->veri = gecici;
        q->kap = yeni;
    }
    q->veri[q->son++] = x;
}

/* DOĞRU BFS: işaret EKLERKEN konur. sira NULL değilse işlenme sırası
 * yazılır. Dönüş: kuyruğa ekleme sayısı. */
static long bfs_dogru(int V, int s, long *en_uzun, long *islenme,
                       int sira[])
{
    char *ziyaret = calloc((size_t)V, 1);
    Kuyruk q = {malloc(16 * sizeof(int)), 0, 0, 16};
    long ekleme = 1;
    if (q.veri == NULL || ziyaret == NULL) {
        exit(1);
    }
    ziyaret[s] = 1;                          /* işaret EKLERKEN */
    ekle(&q, s);
    *en_uzun = 1;
    *islenme = 0;
    while (q.bas < q.son) {
        int u = q.veri[q.bas++];
        if (sira != NULL) {
            sira[*islenme] = u;
        }
        (*islenme)++;
        for (int i = 0; i < derece[u]; i++) {
            int v = komsu[u][i];
            if (!ziyaret[v]) {
                ziyaret[v] = 1;              /* işaret EKLERKEN */
                ekle(&q, v);
                ekleme++;
            }
        }
        if (q.son - q.bas > *en_uzun) {
            *en_uzun = q.son - q.bas;
        }
    }
    free(q.veri);
    free(ziyaret);
    return ekleme;
}

static void kenar(int u, int v)
{
    komsu[u][derece[u]++] = v;
    komsu[v][derece[v]++] = u;
}

int main(int argc, char *argv[])
{
    static const int G[][2] = {{0, 1}, {0, 2}, {1, 3}, {1, 4}, {2, 4},
                               {3, 5}, {4, 5}, {4, 6}, {5, 7}, {6, 7}};
    long k_ust = argc > 1 ? strtol(argv[1], NULL, 10) : 8;
    int sira[64];
    long en_uzun, islenme, kac_kez = 0;
    if (k_ust < 3 || k_ust > 20) {
        k_ust = 8;
    }
    for (int i = 0; i < 10; i++) {
        kenar(G[i][0], G[i][1]);             /* artan sırada verildi */
    }
    printf("DOĞRU BFS: ziyaret işareti kuyruğa EKLERKEN konur\n");
    long ekleme = bfs_dogru(8, 0, &en_uzun, &islenme, sira);
    printf("1) Örnek graf G (V = 8, E = 10), BFS(0)\n   işlenme sırası:");
    for (long i = 0; i < islenme; i++) {
        printf(" %d", sira[i]);
        kac_kez += sira[i] == 7;
    }
    printf("\n   kuyruğa ekleme = %ld (V = 8), en uzun kuyruk = %ld, "
           "işlenme = %ld; 7 köşesi %ld kez işlendi\n", ekleme, en_uzun,
           islenme, kac_kez);
    printf("2) k x k ızgara (4-komşuluk), köşe hücreden BFS\n");
    printf("     k     V   kuyruğa ekleme   en uzun kuyruk\n");
    for (int k = 3; k <= k_ust && k * k <= MAKS_V; k++) {
        for (int h = 0; h < k * k; h++) {
            derece[h] = 0;
        }
        for (int i = 0; i < k; i++) {
            for (int j = 0; j < k; j++) {
                if (j + 1 < k) {
                    kenar(i * k + j, i * k + j + 1);
                }
                if (i + 1 < k) {
                    kenar(i * k + j, (i + 1) * k + j);
                }
            }
        }
        ekleme = bfs_dogru(k * k, 0, &en_uzun, &islenme, NULL);
        printf("   %3d  %4d  %15ld  %15ld\n", k, k * k, ekleme, en_uzun);
    }
    return 0;
}

/* H11_HA7_derin_ozyineleme.c — AP-2 Hafta 11 · Hata Avcısı 7
 * BU DOSYA KASITLI HATA İÇERİR — isteğe bağlı argümanla ÇÖKER
 * Hata    : özyinelemeli DFS, n köşelik bir zincirde (0 - 1 - ... - n-1)
 *           n derinliğe iner; her çağrı çağrı yığınında bir çerçeve
 *           kaplar. Yığın sınırı (Linux'ta tipik ulimit -s 8192 KB) aşılınca
 *           süreç "Segmentation fault" (SIGSEGV) ile çöker. Varsayılan
 *           n = 1000 güvenlidir; çökme için: ./H11_HA7_derin_ozyineleme 1000000
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H11_HA7_derin_ozyineleme.c -o H11_HA7_derin_ozyineleme
 * Düzeltme: H11_HA7_derin_ozyineleme_duzeltilmis.c (açık yığın)
 */
#include <stdio.h>
#include <stdlib.h>

static char *ziyaret;
static long n, ziyaret_sayisi = 0, en_derin = 0;

/* Zincir: u'nun komşuları u - 1 ve u + 1 (örtük graf) */
static void dfs(long u, long derinlik)
{
    ziyaret[u] = 1;
    ziyaret_sayisi++;
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    for (long v = u - 1; v <= u + 1; v += 2) {
        if (v >= 0 && v < n && !ziyaret[v]) {
            dfs(v, derinlik + 1);            /* her kenar bir çerçeve */
        }
    }
}

int main(int argc, char *argv[])
{
    n = argc > 1 ? strtol(argv[1], NULL, 10) : 1000;
    if (n < 1 || n > 100000000) {
        fprintf(stderr, "n 1..100000000 olmalı\n");
        return 2;
    }
    ziyaret = calloc((size_t)n, 1);
    if (ziyaret == NULL) {
        return 1;
    }
    printf("zincir n = %ld, özyinelemeli DFS(0) başlıyor...\n", n);
    fflush(stdout);                          /* çökmeden önce görünsün */
    dfs(0, 1);
    printf("bitti: ziyaret = %ld, en büyük özyineleme derinliği = %ld\n",
           ziyaret_sayisi, en_derin);
    free(ziyaret);
    return 0;
}

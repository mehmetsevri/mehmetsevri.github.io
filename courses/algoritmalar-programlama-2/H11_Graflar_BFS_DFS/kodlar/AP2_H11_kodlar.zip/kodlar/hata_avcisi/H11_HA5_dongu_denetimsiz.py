"""H11_HA5_dongu_denetimsiz.py — AP-2 Hafta 11 · Hata Avcısı 5 (Python)
BU DOSYA KASITLI HATA İÇERİR
Hata    : DFS ile topolojik sıralamada yalnız "ziyaret edildi mi?" (iki
          durum) tutuluyor; gri (yolda) ile siyah (bitti) ayrılmadığı için
          geri kenar fark edilmez. Döngülü grafta da BÜTÜN dersleri içeren
          bir "sıra" üretilir ama sıra bazı önkoşulları çiğner.
Çalıştır: python3 H11_HA5_dongu_denetimsiz.py
Düzeltme: H11_HA5_dongu_denetimsiz_duzeltilmis.py
"""

AD = ["ALG", "AP1", "AP2", "AYR", "MAT1", "MAT2", "NYP", "VY", "YZ"]
# dersler_dongulu.txt: 0 -> 2 kenarı AP2 -> VY -> ALG -> AP2 döngüsü kurar
KENAR = [(4, 5), (4, 3), (1, 2), (2, 7), (3, 7), (2, 6), (7, 0), (5, 0),
         (0, 8), (6, 8), (0, 2)]


def topolojik(V, komsu):
    ziyaret = [False] * V
    bitis = []

    def dfs(u):
        ziyaret[u] = True               # HATA: gri ve siyah ayrılmıyor
        for v in komsu[u]:
            if not ziyaret[v]:
                dfs(v)
        bitis.append(u)

    for r in range(V):
        if not ziyaret[r]:
            dfs(r)
    return bitis[::-1]


def main():
    V = len(AD)
    komsu = [[] for _ in range(V)]
    for u, v in KENAR:
        komsu[u].append(v)
    for liste in komsu:
        liste.sort()
    sira = topolojik(V, komsu)
    print("Ders planı: " + " ".join(AD[v] for v in sira))
    konum = {v: i for i, v in enumerate(sira)}
    for u, v in KENAR:                  # kâhin: çiğnenen önkoşullar
        if konum[u] > konum[v]:
            print(f"  ÇİĞNENEN önkoşul: {AD[u]} -> {AD[v]} (planda "
                  f"{AD[v]} önce, {AD[u]} sonra)")


if __name__ == "__main__":
    main()

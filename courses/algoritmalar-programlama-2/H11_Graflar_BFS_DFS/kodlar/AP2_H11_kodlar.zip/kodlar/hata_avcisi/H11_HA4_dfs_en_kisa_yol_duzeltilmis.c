/* H11_HA4_dfs_en_kisa_yol_duzeltilmis.c — AP-2 Hafta 11 · Hata Avcısı 4
 * Düzeltme: en kısa yol BFS ile: köşeler kaynağa uzaklık sırasıyla
 *           (katman katman) keşfedilir; v'ye ilk ulaşıldığı anda uzak[v]
 *           kesinleşmiştir. Doğrulama: DFS'nin değerleri de yazdırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_HA4_dfs_en_kisa_yol_duzeltilmis.c \
 *           -o H11_HA4_dfs_en_kisa_yol_duzeltilmis
 * Hatalı  : H11_HA4_dfs_en_kisa_yol.c
 */
#include <stdio.h>

#define V 8

/* Haftanın örnek grafı G, komşular artan sırada */
static const int KOMSU[V][4] = {{1, 2}, {0, 3, 4}, {0, 4}, {1, 5},
                                {1, 2, 5, 6}, {3, 4, 7}, {4, 7}, {5, 6}};
static const int DERECE[V] = {2, 3, 2, 2, 4, 3, 2, 2};
static int uzak[V], ebeveyn[V], dfs_derinlik[V];

/* Karşılaştırma için: DFS ağacındaki derinlik (uzaklık DEĞİLDİR) */
static void dfs_derinligi(int u)
{
    for (int i = 0; i < DERECE[u]; i++) {
        int v = KOMSU[u][i];
        if (dfs_derinlik[v] == -1) {
            dfs_derinlik[v] = dfs_derinlik[u] + 1;
            dfs_derinligi(v);
        }
    }
}

/* DOĞRU: BFS, kuyruk; işaret eklerken */
static void bfs_uzaklik(int s)
{
    int q[V], bas = 0, son = 0;
    uzak[s] = 0;
    q[son++] = s;
    while (bas < son) {
        int u = q[bas++];
        for (int i = 0; i < DERECE[u]; i++) {
            int v = KOMSU[u][i];
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                ebeveyn[v] = u;
                q[son++] = v;
            }
        }
    }
}

static void yol_yaz(int t)
{
    if (ebeveyn[t] != -1) {
        yol_yaz(ebeveyn[t]);
        printf(" -> ");
    }
    printf("%d", t);
}

int main(void)
{
    for (int v = 0; v < V; v++) {
        uzak[v] = ebeveyn[v] = dfs_derinlik[v] = -1;
    }
    dfs_derinlik[0] = 0;
    dfs_derinligi(0);
    bfs_uzaklik(0);
    printf("BFS ile en kısa uzaklıklar (kaynak 0):\n");
    for (int t = 0; t < V; t++) {
        printf("   %d: uzaklık %d (DFS derinliği %d), yol ", t, uzak[t],
               dfs_derinlik[t]);
        yol_yaz(t);
        printf("\n");
    }
    return 0;
}

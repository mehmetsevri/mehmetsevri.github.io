"""H11_HA6_degisken_varsayilan.py — AP-2 Hafta 11 · Hata Avcısı 6 (Python)
BU DOSYA KASITLI HATA İÇERİR
Hata    : def dfs(g, u, ziyaret=[]): varsayılan argüman fonksiyon
          TANIMLANIRKEN bir kez oluşturulur ve bütün çağrılarda AYNI liste
          kullanılır. İlk çağrının ziyaret listesi ikinci çağrıya taşınır:
          ikinci DFS hiçbir şeyi "yeni" bulmaz ya da eksik bulur.
Çalıştır: python3 H11_HA6_degisken_varsayilan.py
Düzeltme: H11_HA6_degisken_varsayilan_duzeltilmis.py
"""

# İki ayrı küçük graf (komşuluk listesi)
G1 = [[1, 2], [0, 3], [0], [1]]                 # 0-1-3, 0-2
G2 = [[1], [0, 2], [1, 3], [2], [5], [4]]       # 0-1-2-3 ve 4-5


def dfs(g, u, ziyaret=[]):                      # HATA: değiştirilebilir
    ziyaret.append(u)                           # varsayılan argüman
    for v in g[u]:
        if v not in ziyaret:
            dfs(g, v, ziyaret)
    return ziyaret


def main():
    print("1. çağrı, G1, kaynak 0:", dfs(G1, 0))
    print("2. çağrı, G2, kaynak 0:", dfs(G2, 0))
    print("3. çağrı, G2, kaynak 4:", dfs(G2, 4))
    print("varsayılan liste şimdi:", dfs.__defaults__[0])


if __name__ == "__main__":
    main()

"""H11_HA6_degisken_varsayilan_duzeltilmis.py — AP-2 Hafta 11 · HA 6
Düzeltme: varsayılan değer None; liste fonksiyonun İÇİNDE, her dış
          çağrıda yeniden oluşturulur. (Ayrıca "v not in ziyaret" listede
          doğrusal aramadır; ziyaret dizisi [False] * V ile O(1) olur.)
Çalıştır: python3 H11_HA6_degisken_varsayilan_duzeltilmis.py
Hatalı  : H11_HA6_degisken_varsayilan.py
"""

# İki ayrı küçük graf (komşuluk listesi)
G1 = [[1, 2], [0, 3], [0], [1]]                 # 0-1-3, 0-2
G2 = [[1], [0, 2], [1, 3], [2], [5], [4]]       # 0-1-2-3 ve 4-5


def dfs(g, u, ziyaret=None):
    if ziyaret is None:                         # her dış çağrıda yeni
        ziyaret = []
    ziyaret.append(u)
    for v in g[u]:
        if v not in ziyaret:
            dfs(g, v, ziyaret)
    return ziyaret


def main():
    print("1. çağrı, G1, kaynak 0:", dfs(G1, 0))
    print("2. çağrı, G2, kaynak 0:", dfs(G2, 0))
    print("3. çağrı, G2, kaynak 4:", dfs(G2, 4))
    print("varsayılan değer şimdi:", dfs.__defaults__[0])


if __name__ == "__main__":
    main()

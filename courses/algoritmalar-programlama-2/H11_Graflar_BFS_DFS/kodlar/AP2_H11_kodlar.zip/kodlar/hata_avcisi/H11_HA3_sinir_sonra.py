"""H11_HA3_sinir_sonra.py — AP-2 Hafta 11 · Hata Avcısı 3 (Python)
BU DOSYA KASITLI HATA İÇERİR
Hata    : komşu hücre ÖNCE okunuyor, sınır denetimi SONRA yapılıyor:
          iz[ni * Y + nj] == "#" and icinde(ni, nj). Python'da negatif
          indis hata VERMEZ, listenin SONUNDAN okur (üst satırdan yukarı
          çıkınca sessizce başka hücreye bakılır); alt satırın altındaki
          indis ise listenin boyunu aşar: IndexError.
Çalıştır: python3 H11_HA3_sinir_sonra.py
Düzeltme: H11_HA3_sinir_sonra_duzeltilmis.py
"""
from collections import deque

HARITA = ["##..#.", "#...##", "..#...", ".##..#"]
di = (-1, 1, 0, 0)                      # yukarı, aşağı, sol, sağ
dj = (0, 0, -1, 1)
S, Y = len(HARITA), len(HARITA[0])
negatif_okuma = 0


def icinde(i, j):
    return 0 <= i < S and 0 <= j < Y


def ada_sil(iz, i0, j0):
    """(i0, j0)'ın adasını '.' yapar (BFS); hücre sayısını döndürür"""
    global negatif_okuma
    q = deque([i0 * Y + j0])
    iz[i0 * Y + j0] = "."
    n = 0
    while q:
        h = q.popleft()
        n += 1
        i, j = h // Y, h % Y
        for k in range(4):
            ni, nj = i + di[k], j + dj[k]
            if ni * Y + nj < 0:
                negatif_okuma += 1      # Python sessizce sondan okur
            if iz[ni * Y + nj] == "#" and icinde(ni, nj):   # HATA
                iz[ni * Y + nj] = "."
                q.append(ni * Y + nj)
    return n


def main():
    iz = list("".join(HARITA))
    for satir in HARITA:
        print("   " + satir)
    ada = 0
    for h in range(S * Y):
        if iz[h] == "#":
            n = ada_sil(iz, h // Y, h % Y)
            ada += 1
            print(f"ada {ada}: ({h // Y}, {h % Y}) hücresinden, {n} hücre "
                  f"(şimdiye dek negatif indisle okuma: {negatif_okuma})")
    print(f"ada sayısı (4-komşuluk) = {ada}")


if __name__ == "__main__":
    main()

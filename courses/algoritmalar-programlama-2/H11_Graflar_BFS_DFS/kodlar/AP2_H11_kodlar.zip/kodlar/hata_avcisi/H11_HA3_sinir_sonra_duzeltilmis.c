/* H11_HA3_sinir_sonra_duzeltilmis.c — AP-2 Hafta 11 · Hata Avcısı 3
 * Düzeltme: sınır denetimi komşuya ERİŞMEDEN ÖNCE: icinde(ni, nj) &&
 *           iz[ni * Y + nj] == '#'. && soldan sağa değerlendirilir ve
 *           kısa devre yapar: sınır dışı hücre hiç okunmaz (ASan temiz).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_HA3_sinir_sonra_duzeltilmis.c \
 *           -o H11_HA3_sinir_sonra_duzeltilmis
 * Hatalı  : H11_HA3_sinir_sonra.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *HARITA[] = {"##..#.", "#...##", "..#...", ".##..#"};
static const int di[4] = {-1, 1, 0, 0};      /* yukarı, aşağı, sol, sağ */
static const int dj[4] = {0, 0, -1, 1};
static int S, Y;

static int icinde(int i, int j)
{
    return i >= 0 && i < S && j >= 0 && j < Y;
}

/* (i0, j0)'ın adasını '.' yapar (BFS); q: S * Y'lik kuyruk */
static int ada_sil(char *iz, int i0, int j0, int q[])
{
    int bas = 0, son = 0;
    iz[i0 * Y + j0] = '.';
    q[son++] = i0 * Y + j0;
    while (bas < son) {
        int h = q[bas++], i = h / Y, j = h % Y;
        for (int k = 0; k < 4; k++) {
            int ni = i + di[k], nj = j + dj[k];
            if (icinde(ni, nj) && iz[ni * Y + nj] == '#') {  /* önce sınır */
                iz[ni * Y + nj] = '.';
                q[son++] = ni * Y + nj;
            }
        }
    }
    return son;
}

int main(void)
{
    S = (int)(sizeof HARITA / sizeof HARITA[0]);
    Y = (int)strlen(HARITA[0]);
    char *iz = malloc((size_t)S * Y);       /* öbekte: ASan izler */
    int *q = malloc((size_t)S * Y * sizeof(int));
    int ada = 0;
    if (iz == NULL || q == NULL) {
        return 1;
    }
    for (int i = 0; i < S; i++) {
        memcpy(iz + (size_t)i * Y, HARITA[i], (size_t)Y);
        printf("   %s\n", HARITA[i]);
    }
    for (int h = 0; h < S * Y; h++) {
        if (iz[h] == '#') {
            int n = ada_sil(iz, h / Y, h % Y, q);
            printf("ada %d: (%d, %d) hücresinden, %d hücre\n", ada + 1,
                   h / Y, h % Y, n);
            ada++;
        }
    }
    printf("ada sayısı (4-komşuluk) = %d\n", ada);
    free(iz);
    free(q);
    return 0;
}

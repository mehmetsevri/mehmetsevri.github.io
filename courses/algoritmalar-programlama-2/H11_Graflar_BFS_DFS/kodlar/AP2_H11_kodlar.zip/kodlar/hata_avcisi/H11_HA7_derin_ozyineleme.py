"""H11_HA7_derin_ozyineleme.py — AP-2 Hafta 11 · Hata Avcısı 7 (Python)
BU DOSYA KASITLI HATA İÇERİR — isteğe bağlı argümanla HATA verir
Hata    : özyinelemeli DFS, n köşelik zincirde n derinliğe iner. CPython
          özyinelemeyi sys.getrecursionlimit() ile sınırlar (varsayılan
          1000): sınır aşılınca RecursionError. Varsayılan n = 500
          güvenlidir; hata için: python3 H11_HA7_derin_ozyineleme.py 2000
Düzeltme: H11_HA7_derin_ozyineleme_duzeltilmis.py (açık yığın)
"""
import sys


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 500
    ziyaret = [False] * n
    sayac = [0, 0]                      # ziyaret, en büyük derinlik

    def dfs(u, derinlik):
        ziyaret[u] = True
        sayac[0] += 1
        sayac[1] = max(sayac[1], derinlik)
        for v in (u - 1, u + 1):        # zincir: örtük graf
            if 0 <= v < n and not ziyaret[v]:
                dfs(v, derinlik + 1)

    print(f"zincir n = {n}, özyineleme sınırı = {sys.getrecursionlimit()}")
    dfs(0, 1)
    print(f"bitti: ziyaret = {sayac[0]}, en büyük derinlik = {sayac[1]}")


if __name__ == "__main__":
    main()

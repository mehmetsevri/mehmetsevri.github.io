/* H11_HA5_dongu_denetimsiz.c — AP-2 Hafta 11 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR
 * Hata    : Kahn algoritmasında sonuçtaki köşe sayısı denetlenmiyor.
 *           Döngülü önkoşul grafında döngüdeki (ve ondan sonraki) dersler
 *           hiç giriş derecesi 0'a inmez, sıraya girmez; program eksik
 *           planı SESSİZCE "ders planı" diye yazar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_HA5_dongu_denetimsiz.c -o H11_HA5_dongu_denetimsiz
 * Düzeltme: H11_HA5_dongu_denetimsiz_duzeltilmis.c
 */
#include <stdio.h>

#define V 9

/* dersler_dongulu.txt: 0 ALG, 1 AP1, 2 AP2, 3 AYR, 4 MAT1, 5 MAT2,
 * 6 NYP, 7 VY, 8 YZ; 0 -> 2 kenarı AP2 -> VY -> ALG -> AP2 döngüsü kurar */
static const char *const AD[V] = {"ALG", "AP1", "AP2", "AYR", "MAT1",
                                  "MAT2", "NYP", "VY", "YZ"};
static const int KENAR[][2] = {{4, 5}, {4, 3}, {1, 2}, {2, 7}, {3, 7},
                               {2, 6}, {7, 0}, {5, 0}, {0, 8}, {6, 8},
                               {0, 2}};
#define E ((int)(sizeof KENAR / sizeof KENAR[0]))

int main(void)
{
    int derece[V] = {0}, q[V], bas = 0, son = 0;
    for (int i = 0; i < E; i++) {
        derece[KENAR[i][1]]++;
    }
    for (int v = 0; v < V; v++) {
        if (derece[v] == 0) {
            q[son++] = v;                    /* FIFO kuyruk */
        }
    }
    while (bas < son) {
        int u = q[bas++];
        for (int i = 0; i < E; i++) {        /* kenar listesi taraması */
            if (KENAR[i][0] == u && --derece[KENAR[i][1]] == 0) {
                q[son++] = KENAR[i][1];
            }
        }
    }
    printf("Ders planı:");                   /* HATA: son == V mi? */
    for (int i = 0; i < son; i++) {
        printf(" %s", AD[q[i]]);
    }
    printf("\n");
    return 0;
}

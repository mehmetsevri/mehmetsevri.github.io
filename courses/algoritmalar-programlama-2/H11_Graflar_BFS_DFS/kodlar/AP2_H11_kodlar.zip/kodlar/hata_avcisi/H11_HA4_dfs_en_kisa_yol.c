/* H11_HA4_dfs_en_kisa_yol.c — AP-2 Hafta 11 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR
 * Hata    : ağırlıksız grafta "en kısa yol" DFS ile aranıyor: uzak[v] =
 *           DFS ağacındaki derinlik. DFS bir dalda olabildiğince derine
 *           iner; bir köşeye İLK ulaştığı yol en kısa yol olmak zorunda
 *           değildir. (Geri izlemeyle bütün yolları denemek doğru ama
 *           üstel zamanlıdır; doğrusu BFS, Θ(V + E).)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_HA4_dfs_en_kisa_yol.c -o H11_HA4_dfs_en_kisa_yol
 * Düzeltme: H11_HA4_dfs_en_kisa_yol_duzeltilmis.c
 */
#include <stdio.h>

#define V 8

/* Haftanın örnek grafı G, komşular artan sırada */
static const int KOMSU[V][4] = {{1, 2}, {0, 3, 4}, {0, 4}, {1, 5},
                                {1, 2, 5, 6}, {3, 4, 7}, {4, 7}, {5, 6}};
static const int DERECE[V] = {2, 3, 2, 2, 4, 3, 2, 2};
static int uzak[V], ebeveyn[V];

/* HATALI: DFS derinliği uzaklık sanılıyor */
static void dfs_uzaklik(int u)
{
    for (int i = 0; i < DERECE[u]; i++) {
        int v = KOMSU[u][i];
        if (uzak[v] == -1) {
            uzak[v] = uzak[u] + 1;           /* HATA: ilk yol en kısa mı? */
            ebeveyn[v] = u;
            dfs_uzaklik(v);
        }
    }
}

static void yol_yaz(int t)
{
    if (ebeveyn[t] != -1) {
        yol_yaz(ebeveyn[t]);
        printf(" -> ");
    }
    printf("%d", t);
}

int main(void)
{
    for (int v = 0; v < V; v++) {
        uzak[v] = ebeveyn[v] = -1;
    }
    uzak[0] = 0;
    dfs_uzaklik(0);
    printf("DFS ile 'en kısa' uzaklıklar (kaynak 0):\n");
    for (int t = 0; t < V; t++) {
        printf("   %d: uzaklık %d, yol ", t, uzak[t]);
        yol_yaz(t);
        printf("\n");
    }
    return 0;
}

"""H11_11_kahn.py — AP-2 Hafta 11 · Örnek 11 (★★★)
Amaç    : Topolojik sıralama, Kahn algoritması: giriş dereceleri; giriş
          derecesi 0 olan köşelerden EN KÜÇÜK numaralısı seçilir (en
          küçük öbek, H7); "en erken dönem" katmanları; döngü varsa
          sıralanan < V: raporlanır. Karşılaştırma: FIFO kuyrukla Kahn
          ve geçerli sıraların sayısı (birden çok doğru yanıt vardır)
Çalıştır: python3 H11_11_kahn.py ../girdiler/dersler_dag.txt \\
          ../girdiler/dersler_dongulu.txt
Eşleri  : c/H11_11_kahn.c · cpp/H11_11_kahn.cpp
Çıktı   : üç dilde aynı (=); yalnız yönlü graflar içindir
"""
import heapq
import sys
from collections import deque

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


def obek_metni(h):
    """Öbek içeriği küçükten büyüğe (yalnız gösterim için sıralanır)"""
    return "[" + " ".join(str(x) for x in sorted(h)) + "]"


def kahn(g, fifo, iz):
    """Kahn: fifo False ise en küçük öbek (heapq), True ise FIFO kuyruk
    (giriş derecesi 0 olanlar artan sırada eklenir). Dönüş: (sıra,
    donem, derece); sıranın boyu < V ise döngü var; donem[v] = v'nin en
    erken dönemi; derece: sonunda kalan giriş dereceleri."""
    h = []                              # en küçük öbek (H7)
    q = deque()
    sira = []
    derece = [0] * g.V
    donem = [1] * g.V
    for u in range(g.V):
        for v in g.komsu[u]:
            derece[v] += 1
    if iz:
        print("   giriş dereceleri:"
              + "".join(f" {v}:{derece[v]}" for v in range(g.V)))
    for v in range(g.V):
        if derece[v] == 0:
            if fifo:
                q.append(v)
            else:
                heapq.heappush(h, v)
    if iz:
        print("   başlangıç öbeği (giriş derecesi 0): " + obek_metni(h))
    while (q if fifo else h):
        u = q.popleft() if fifo else heapq.heappop(h)
        sira.append(u)
        parcalar = []
        for v in g.komsu[u]:
            donem[v] = max(donem[v], donem[u] + 1)  # en uzun zincir
            derece[v] -= 1
            parcalar.append(f" {v}: {derece[v] + 1}->{derece[v]}"
                            + (" (öbeğe)" if derece[v] == 0 else ""))
            if derece[v] == 0:
                if fifo:
                    q.append(v)
                else:
                    heapq.heappush(h, v)
        if iz:
            print(f"   adım {len(sira)}: çıkan {u} (dönem {donem[u]});"
                  + ",".join(parcalar) + (";" if parcalar else "")
                  + " öbek: " + obek_metni(h))
    return sira, donem, derece


def gecerli_mi(g, sira):
    """Kâhin: her kenar u -> v için konum[u] < konum[v] mi?"""
    if len(sira) != g.V:
        return False
    konum = [0] * g.V
    for i, v in enumerate(sira):
        konum[v] = i
    for u in range(g.V):
        for v in g.komsu[u]:
            if konum[u] >= konum[v]:
                return False
    return True


def sira_say(g, derece, kullanildi, kalan):
    """Bütün geçerli topolojik sıraları sayar (H3 geri izleme): her
    adımda giriş derecesi 0 olan, kullanılmamış her köşe denenir."""
    if kalan == 0:
        return 1
    toplam = 0
    for u in range(g.V):
        if not kullanildi[u] and derece[u] == 0:
            kullanildi[u] = True                    # seç
            for v in g.komsu[u]:
                derece[v] -= 1
            toplam += sira_say(g, derece, kullanildi, kalan - 1)
            for v in g.komsu[u]:
                derece[v] += 1                      # geri al
            kullanildi[u] = False
    return toplam


def rapor(g):
    sira, donem, derece = kahn(g, False, True)
    n = len(sira)
    if n < g.V:
        print("   sıralanan köşeler:" + "".join(f" {v}" for v in sira)
              + f" ({n} / {g.V})")
        print("   sıralanamayan (giriş derecesi > 0 kaldı):"
              + "".join(f" {v}:{derece[v]}" for v in range(g.V)
                        if derece[v] > 0))
        print("   SONUÇ: döngü var — geçerli bir sıra (ders planı) yok; "
              "döngüdeki ya da döngüye bağlı köşeler hiç 0'a inmez")
        return
    print("   topolojik sıra (en küçük öbek):"
          + "".join(f" {v}" for v in sira))
    print("   kâhin: her kenar u->v için konum[u] < konum[v]: "
          + ("evet" if gecerli_mi(g, sira) else "HAYIR") + f" ({g.E} kenar)")
    print("   en erken dönem:"
          + "".join(f" {v}:{donem[v]}" for v in range(g.V)))
    en_son = 1
    for v in range(g.V):
        en_son = max(en_son, donem[v])
    parcalar = []
    for d in range(1, en_son + 1):
        parcalar.append(f" dönem {d}:"
                        + "".join(f" {v}" for v in sira if donem[v] == d))
    print("  " + ";".join(parcalar))
    sira2, _, _ = kahn(g, True, False)
    print("   FIFO kuyrukla Kahn:" + "".join(f" {v}" for v in sira2)
          + " (geçerli: " + ("evet" if gecerli_mi(g, sira2) else "HAYIR")
          + "; en küçük öbek sırasından "
          + ("farklı" if sira != sira2 else "farksız") + ")")
    derece3 = [0] * g.V
    for u in range(g.V):
        for v in g.komsu[u]:
            derece3[v] += 1
    print("   geçerli topolojik sıra sayısı (geri izlemeyle, H3): "
          f"{sira_say(g, derece3, [False] * g.V, g.V)}")


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_11_kahn GRAF [GRAF2 ...]", file=sys.stderr)
        return 2
    for i in range(1, len(sys.argv)):
        g = graf_yukle(sys.argv[i])
        if g is None:
            return 1
        if not g.yonlu:
            print(f"{taban_ad(sys.argv[i])}: yönlü bir graf gerekir",
                  file=sys.stderr)
            return 1
        print(f"{i}) {taban_ad(sys.argv[i])} (yönlü, V = {g.V}, E = {g.E}): "
              "Kahn, en küçük öbekle")
        rapor(g)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
# topological_sort, DFS tabanlı); Python — graphlib.TopologicalSorter
# (3.9+, standart kütüphane; yalnız kâhin) ve networkx.topological_sort
# (doğrulama için).

"""H11_02_komsuluk_listesi.py — AP-2 Hafta 11 · Örnek 2 (★★)
Amaç    : Dosyadan kenar listesi okuma (ortak graf biçimi, denetimli);
          komşuluk listesi = dinamik dizilerden (H8) oluşan dizi; ekleme
          sırası ve artan sıra; liste ↔ matris ↔ kenar listesi dönüşümü;
          biçim hatası iletileri (üç dilde aynı)
Çalıştır: python3 H11_02_komsuluk_listesi.py GRAF [GRAF2 ...]
          (ilk dosya ayrıntılı; sonrakiler özet ya da hata iletisi)
Eşleri  : c/H11_02_komsuluk_listesi.c ·
          cpp/H11_02_komsuluk_listesi.cpp
Çıktı   : üç dilde aynı (=); ilk dosyada biçim hatası: çıkış kodu 1
"""
import sys

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class KenarListesi:
    __slots__ = ("V", "E", "yonlu", "kenar")

    def __init__(self, V, E, yonlu):
        self.V, self.E, self.yonlu = V, E, yonlu
        self.kenar = []             # (u, v, w) demetleri, dosya sırasıyla


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def graf_dosyasi_oku(yol):
    """(KenarListesi, None) ya da (None, hata iletisi) döndürür"""
    ad = taban_ad(yol)
    try:
        f = open(yol, "rb")
    except OSError:
        return None, f"{ad}: dosya açılamadı"
    kl = None
    with f:
        for no, satir in enumerate(f, 1):
            yer = f"{ad}: satır {no}: "
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                return None, yer + "satır çok uzun"
            bel = satir.split()[:4]   # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if kl is None:
                V = tamsayi_coz(bel[0]) if 2 <= n <= 3 else None
                E = tamsayi_coz(bel[1]) if 2 <= n <= 3 else None
                if V is None or E is None:
                    return None, (yer + 'başlık "V E [yonlu|yonsuz]" '
                                  'bekleniyor')
                if V < 1 or V > MAKS_KOSE:
                    return None, yer + f"V = {V} geçersiz (1..{MAKS_KOSE})"
                if E < 0 or E > MAKS_KENAR:
                    return None, yer + f"E = {E} geçersiz (0..{MAKS_KENAR})"
                if n == 3 and bel[2] not in (b"yonlu", b"yonsuz"):
                    tur = bel[2].decode("utf-8", "replace")
                    return None, (yer + f'tür "{tur}" tanınmıyor '
                                  '(yonlu ya da yonsuz)')
                kl = KenarListesi(V, E, n == 3 and bel[2] == b"yonlu")
                continue
            x = [tamsayi_coz(b) for b in bel] if 2 <= n <= 3 else [None]
            if len(kl.kenar) == kl.E:
                return None, yer + f"fazladan kenar (başlıkta E = {kl.E})"
            if None in x:
                return None, yer + 'kenar "u v [w]" bekleniyor'
            if not (0 <= x[0] < kl.V and 0 <= x[1] < kl.V):
                kotu = x[0] if not 0 <= x[0] < kl.V else x[1]
                return None, (yer + f"köşe {kotu} aralık dışı "
                              f"(0..{kl.V - 1})")
            kl.kenar.append((x[0], x[1], x[2] if n == 3 else 1))
    if kl is None:
        return None, f"{ad}: dosya boş (başlık yok)"
    if len(kl.kenar) < kl.E:
        return None, (f"{ad}: kenar eksik: E = {kl.E}, okunan "
                      f"{len(kl.kenar)}")
    return kl, None


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")


def graf_kur(kl):
    """Kenarlar dosya sırasıyla eklenir (yönsüzde iki yöne)"""
    g = Graf()
    g.V, g.E, g.yonlu = kl.V, kl.E, kl.yonlu
    g.komsu = [[] for _ in range(g.V)]
    for u, v, _ in kl.kenar:
        g.komsu[u].append(v)
        if not g.yonlu:
            g.komsu[v].append(u)
    return g


def graf_sirala(g):
    """Komşu listeleri artan köşe numarasına (belirli sıra)"""
    for liste in g.komsu:
        liste.sort()


def listeleri_yaz(g):
    for u in range(g.V):
        print(f"    {u}:" + "".join(f" {v}" for v in g.komsu[u]))


def listeden_matris(g):
    """V × V matris (satır satır tek bytearray'de)"""
    m = bytearray(g.V * g.V)
    for u in range(g.V):
        for v in g.komsu[u]:
            m[u * g.V + v] = 1
    return m


def matristen_kenarlar(m, V, yonlu, E_ust):
    """Matristen kenar listesi (yönsüzde u < v); metni de döndürür"""
    kl = KenarListesi(V, 0, yonlu)
    metin = ""
    for u in range(V):
        for v in range(0 if yonlu else u + 1, V):
            if m[u * V + v] and len(kl.kenar) < E_ust:
                metin += f" ({u},{v})"
                kl.kenar.append((u, v, 1))
    kl.E = len(kl.kenar)
    return kl, metin


def donusumler(g):
    """4) liste -> matris -> kenar listesi -> liste"""
    V = g.V
    m = listeden_matris(g)
    print("4) Dönüşümler\n   liste -> matris (satır u: matris[u][0..V-1]):")
    for u in range(V):
        print(f"    {u}: " + "".join(str(m[u * V + v]) for v in range(V)))
    kl2, metin = matristen_kenarlar(m, V, g.yonlu, g.E)
    print("   matris -> kenar listesi ("
          + ("u -> v" if g.yonlu else "u < v") + "):" + metin)
    print(f"   kenar sayısı = {kl2.E} (E = {g.E})")
    g2 = graf_kur(kl2)
    graf_sirala(g2)
    ayni = g2.komsu == g.komsu      # listelerin == karşılaştırması
    print("   kenar listesi -> liste: 3) ile aynı mı: "
          + ("evet" if ayni else "HAYIR"))


def ayrintili(yol):
    kl, hata = graf_dosyasi_oku(yol)
    if hata is not None:
        print(hata, file=sys.stderr)
        return 1
    g = graf_kur(kl)
    print(f"1) Dosya: {taban_ad(yol)} -> V = {kl.V}, E = {kl.E}, "
          + ("yönlü" if kl.yonlu else "yönsüz"))
    print("   kenar listesi (dosya sırası):"
          + "".join(f" ({u},{v})" for u, v, _ in kl.kenar))
    print("2) Komşuluk listesi: dinamik dizilerden oluşan dizi "
          "(ekleme sırası)")
    listeleri_yaz(g)
    graf_sirala(g)
    print("3) Listeler artan sıraya dizildi (dolaşma bu sırayla):")
    listeleri_yaz(g)
    toplam = 0
    for liste in g.komsu:
        toplam += len(liste)
    print(f"   toplam liste öğesi = {toplam} = "
          + ("E (yönlü)" if g.yonlu
             else "2E (yönsüz: her kenar iki listede)"))
    donusumler(g)
    print(f"   öğe sayısı: matris V² = {g.V * g.V} hücre; liste V + "
          + ("E" if g.yonlu else "2E")
          + f" = {g.V + toplam}; kenar listesi 2E = {2 * g.E} sayı")
    return 0


def ozet(yol):
    kl, hata = graf_dosyasi_oku(yol)
    if hata is not None:
        print("   " + hata)
        return
    g = graf_kur(kl)
    graf_sirala(g)
    print(f"   {taban_ad(yol)}: V = {kl.V}, E = {kl.E}, "
          + ("yönlü" if kl.yonlu else "yönsüz") + "; sıralı listeler:")
    listeleri_yaz(g)


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_02_komsuluk_listesi GRAF [GRAF2 ...]",
              file=sys.stderr)
        return 2
    if ayrintili(sys.argv[1]) != 0:
        return 1
    if len(sys.argv) > 2:
        print("5) Öteki dosyalar (okuyucunun iletisi üç dilde aynıdır):")
    for yol in sys.argv[2:]:
        ozet(yol)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (dinamik dizilerden oluşan dizi elle;
# eşdeğeri int ** + boyut dizisi); C++ — std::vector<std::vector<int>>;
# Python — liste listesi (ya da dict); hazır graf türü yalnız Boost.Graph
# ve networkx'te (doğrulama için).

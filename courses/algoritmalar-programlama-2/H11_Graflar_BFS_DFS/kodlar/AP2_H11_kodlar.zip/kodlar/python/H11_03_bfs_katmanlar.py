"""H11_03_bfs_katmanlar.py — AP-2 Hafta 11 · Örnek 3 (★★)
Amaç    : Genişlik öncelikli arama (BFS): kuyrukla dolaşma, ziyaret
          işareti kuyruğa EKLERKEN konur; adım adım kuyruk içeriği,
          ziyaret sırası, katmanlar; ekleme/inceleme sayaçları
Çalıştır: python3 H11_03_bfs_katmanlar.py ../girdiler/graf_ornek.txt \\
          ../girdiler/graf_yonlu.txt
Eşleri  : c/H11_03_bfs_katmanlar.c · cpp/H11_03_bfs_katmanlar.cpp
Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
"""
import sys
from collections import deque

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


class Sayac:
    __slots__ = ("ekleme", "inceleme", "en_uzun")

    def __init__(self):
        self.ekleme = 0             # kuyruğa ekleme
        self.inceleme = 0           # incelenen komşu (kenar ucu)
        self.en_uzun = 0            # en uzun kuyruk


def kuyruk_metni(q):
    return "[" + " ".join(str(x) for x in q) + "]"


def bfs(g, s, say, ayrinti):
    """BFS(s): (katman, sira); katman[v] = s'den v'ye en az kenar sayısı
    (ulaşılamayan -1). ayrinti ise her adım yazdırılır."""
    q = deque()
    katman = [-1] * g.V             # -1: henüz görülmedi
    sira = []
    katman[s] = 0                   # işaret EKLERKEN
    q.append(s)
    say.ekleme = say.en_uzun = 1
    if ayrinti:
        print(f"   başlangıç: {s} kuyruğa eklendi; kuyruk: "
              + kuyruk_metni(q))
    while q:
        u = q.popleft()             # kuyruğun başından çıkar
        sira.append(u)
        eklenen = []
        for v in g.komsu[u]:
            say.inceleme += 1
            if katman[v] == -1:
                katman[v] = katman[u] + 1   # işaret EKLERKEN
                q.append(v)
                say.ekleme += 1
                eklenen.append(v)
        say.en_uzun = max(say.en_uzun, len(q))
        if ayrinti:
            print(f"   adım {len(sira)}: çıkan {u} (katman {katman[u]}); "
                  "eklenen:" + ("".join(f" {v}" for v in eklenen)
                                if eklenen else " -")
                  + "; kuyruk: " + kuyruk_metni(q))
    return katman, sira


def sira_yaz(baslik, a):
    print(baslik + "".join(f" {x}" for x in a))


def katmanlari_yaz(katman, sira, satir_satir):
    """Katmanları ziyaret sırasıyla yazar: katman k = s'den k kenar uzakta"""
    en_derin = katman[sira[-1]] if sira else -1
    parcalar = []
    for k in range(en_derin + 1):
        uyeler = [v for v in sira if katman[v] == k]
        if satir_satir:
            print(f"   katman {k}:" + "".join(f" {v}" for v in uyeler))
        else:
            parcalar.append("[" + " ".join(str(v) for v in uyeler) + "]")
    if not satir_satir:
        print("   katmanlar: " + " ".join(parcalar))


def sayac_yaz(say, ek_not):
    print(f"   sayaçlar: kuyruğa ekleme = {say.ekleme}, kenar inceleme = "
          f"{say.inceleme}{ek_not}, en uzun kuyruk = {say.en_uzun}")


def kisa_bfs(g, s, ek_not):
    """Kısa rapor: ziyaret sırası, katmanlar, ulaşılamayanlar, sayaçlar"""
    say = Sayac()
    katman, sira = bfs(g, s, say, False)
    sira_yaz("   ziyaret sırası:", sira)
    katmanlari_yaz(katman, sira, False)
    if len(sira) < g.V:
        print("   ulaşılamayan:"
              + "".join(f" {v}" for v in range(g.V) if katman[v] == -1))
    sayac_yaz(say, ek_not)


def ayrintili_bfs(g, s):
    """Ayrıntılı rapor: her adımda çıkan köşe, eklenenler ve kuyruk"""
    say = Sayac()
    print(f"1) BFS({s}): ziyaret işareti kuyruğa EKLERKEN konur")
    katman, sira = bfs(g, s, say, True)
    sira_yaz("   ziyaret sırası:", sira)
    katmanlari_yaz(katman, sira, True)
    sayac_yaz(say, "" if g.yonlu else " (= 2E: her kenar iki uçtan)")


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_03_bfs_katmanlar GRAF [GRAF2]", file=sys.stderr)
        return 2
    g = graf_yukle(sys.argv[1])
    if g is None:
        return 1
    print(f"Graf: {taban_ad(sys.argv[1])} (V = {g.V}, E = {g.E}, "
          + ("yönlü" if g.yonlu else "yönsüz") + ")")
    ayrintili_bfs(g, 0)
    print(f"2) BFS({g.V - 1}): aynı graf, başka kaynak")
    kisa_bfs(g, g.V - 1, "")
    if len(sys.argv) > 2:
        g = graf_yukle(sys.argv[2])
        if g is None:
            return 1
        print(f"3) {taban_ad(sys.argv[2])} ("
              + ("yönlü" if g.yonlu else "yönsüz")
              + f", V = {g.V}, E = {g.E}): BFS(0)")
        kisa_bfs(g, 0, " (ulaşılan köşelerin çıkış dereceleri toplamı)"
                 if g.yonlu else "")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (kuyruk elle, H9); C++ — yok (std::queue
# yalnız kuyruk; Boost.Graph breadth_first_search); Python — yok
# (collections.deque yalnız kuyruk; networkx.bfs_layers doğrulama için).

"""H11_13_ortak_yazarlik.py — AP-2 Hafta 11 · Örnek 13 (★★★)
Amaç    : KURGUSAL bir ortak yazarlık ağında "kaç adım uzakta?" (Erdős
          sayısı benzeri "Erdem sayısı"): ad -> köşe eşlemesi sıralı
          dizi + ikili arama (H4) ile; makaledeki her yazar çifti kenar;
          BFS uzaklıkları, ulaşılamayanlar (∞) ve en uzak yazarlara yol.
          2. bölüm: ortak LCG ile üretilen yapay ağda uzaklık dağılımı.
Çalıştır: python3 H11_13_ortak_yazarlik.py ../girdiler/ortak_yazarlik.txt \\
          [N M]   (N yazar, M makale; varsayılan 2000 3000)
Eşleri  : c/H11_13_ortak_yazarlik.c ·
          cpp/H11_13_ortak_yazarlik.cpp
Çıktı   : üç dilde aynı (=); adlar uydurmadır (girdi dosyasına bakınız)
"""
import sys
from collections import deque

from ortak_rastgele import rastgele_aralik, rastgele_tohum

MERKEZ = "Erdem".encode()               # adlar bayt olarak karşılaştırılır


def taban_ad(yol):
    return yol[yol.rfind("/") + 1:]


def ikili_ara(ad, x, sayac):
    """Sıralı ad içinde x'in indisi; yoksa -1. sayac[0]: karşılaştırma"""
    lo, hi = 0, len(ad) - 1
    while lo <= hi:
        mid = lo + (hi - lo) // 2
        sayac[0] += 1
        if ad[mid] == x:
            return mid
        if ad[mid] < x:                 # bytes: bayt sırası
            lo = mid + 1
        else:
            hi = mid - 1
    return -1


def listeleri_duzenle(komsu):
    """Komşu listelerini sıralar ve yinelenenleri atar (aynı çift birden
    çok makalede). Dönüş: atılan liste öğesi sayısı."""
    atilan = 0
    for liste in komsu:
        liste.sort()
        k = 0
        for i in range(len(liste)):
            if k == 0 or liste[i] != liste[k - 1]:
                liste[k] = liste[i]
                k += 1
        atilan += len(liste) - k
        del liste[k:]
    return atilan


def bfs(komsu, s):
    """BFS: (uzak, ebeveyn, ulaşılan, inceleme); ulaşılamayan -1"""
    q = deque()
    uzak = [-1] * len(komsu)
    ebeveyn = [-1] * len(komsu)
    ulasilan = inceleme = 0
    uzak[s] = 0
    q.append(s)
    while q:
        u = q.popleft()
        ulasilan += 1
        for v in komsu[u]:
            inceleme += 1
            if uzak[v] == -1:
                uzak[v] = uzak[u] + 1
                ebeveyn[v] = u
                q.append(v)
    return uzak, ebeveyn, ulasilan, inceleme


def makale_ekle(komsu, yazar):
    """Makaledeki yazarlar (köşe numaraları) arasında her çifte kenar"""
    for i in range(len(yazar)):
        for j in range(i + 1, len(yazar)):
            komsu[yazar[i]].append(yazar[j])
            komsu[yazar[j]].append(yazar[i])


def makaleleri_oku(yol):
    """Her satır bir makale (adlar boşlukla ayrılır); '#' satırı yorum.
    Dönüş: makale listesi (her biri bayt ad listesi) ya da None"""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    makale = []
    with f:
        for satir in f:
            yazar = satir.split()
            if yazar and yazar[0][:1] != b"#":
                makale.append(yazar)
    return makale


def ad_yaz(a):
    return a.decode("utf-8")


def uzak_yollari_yaz(ad, uzak, ebeveyn, en):
    """En uzak köşelere yolları ebeveyn zincirinden geri çıkarıp yazar"""
    print(f"   en uzaktakiler ({en} adım):")
    for v in range(len(ad)):
        if uzak[v] != en:
            continue
        yol = []
        x = v
        while x != -1:
            yol.append(x)
            x = ebeveyn[x]
        print(f"     {ad_yaz(ad[v])}: "
              + " -> ".join(ad_yaz(ad[x]) for x in reversed(yol)))


def gruplari_yaz(ad, uzak, en):
    """Uzaklığa göre gruplar: 0, 1, ..., en ve ∞ (ulaşılamayan)"""
    m = ad_yaz(MERKEZ)
    print(f"   {m} sayısı ({m}'den BFS; komşular ad sırasıyla):")
    for d in range(en + 2):
        hedef = d if d <= en else -1
        uyeler = [ad_yaz(ad[v]) for v in range(len(ad)) if uzak[v] == hedef]
        if uyeler:
            print(f"     {d if d <= en else '∞'}: " + " ".join(uyeler)
                  + ("" if d <= en else " (zincir yok)"))


def kurgusal_ag(yol):
    """1. bölüm: kurgusal ağ. ad -> köşe eşlemesi, graf, BFS"""
    makale = makaleleri_oku(yol)
    if makale is None:
        return False
    tum = []                            # bütün adlar, dosya sırasıyla
    for m in makale:
        tum.extend(m)
    sirali = sorted(tum)                # sıralama burada araçtır
    ad = []
    for a in sirali:                    # yinelenenleri at
        if not ad or a != ad[-1]:
            ad.append(a)
    V = len(ad)
    karsilastirma = [0]
    indeks = [[ikili_ara(ad, a, karsilastirma) for a in m] for m in makale]
    s = ikili_ara(ad, MERKEZ, [0])      # eşleme sayacı dışı
    if s < 0:
        print(f"{taban_ad(yol)}: ağda {ad_yaz(MERKEZ)} yok", file=sys.stderr)
        return False
    print(f"1) {taban_ad(yol)}: {len(makale)} makale, {len(tum)} yazar adı "
          f"(yinelemeli), {V} farklı yazar")
    print(f"   ad -> köşe: sıralı dizi + ikili arama (H4); {len(tum)} "
          f"aramada {karsilastirma[0]} karşılaştırma")
    print("   köşeler:"
          + "".join(f" {v}={ad_yaz(ad[v])}" for v in range(V)))
    komsu = [[] for _ in range(V)]
    for yazar in indeks:
        makale_ekle(komsu, yazar)
    atilan = listeleri_duzenle(komsu)
    liste = 0
    for l in komsu:
        liste += len(l)
    uzak, ebeveyn, ulasilan, inceleme = bfs(komsu, s)
    en = 0
    for d in uzak:
        en = max(en, d)
    print(f"   kenar (ortak yazar çifti) = {liste // 2}; yinelenen çift "
          f"atıldı: {atilan // 2} kez (aynı ikili birden çok makalede)")
    gruplari_yaz(ad, uzak, en)
    uzak_yollari_yaz(ad, uzak, ebeveyn, en)
    print(f"   sayaçlar: ulaşılan = {ulasilan} / {V}, kenar inceleme = "
          f"{inceleme} (ulaşılan köşelerin dereceleri toplamı)")
    return True


def oran(pay, payda):
    """İki ondalıklı yuvarlanmış oran (tamsayı aritmetiği)"""
    yuz = (100 * pay + payda // 2) // payda
    return f"{yuz // 100}.{yuz % 100:02d}"


def yapay_ag(N, M):
    """2. bölüm: ortak LCG ile N yazarlı, M makaleli yapay ağ. Makale
    başına 2..4 yazar; makalelerin yaklaşık %10'unun ilk yazarı merkez."""
    komsu = [[] for _ in range(N)]
    rastgele_tohum(2026)
    for _ in range(M):
        k = rastgele_aralik(2, 4)
        yazar = [0 if rastgele_aralik(0, 9) == 0
                 else rastgele_aralik(0, N - 1)]
        while len(yazar) < k:
            a = rastgele_aralik(0, N - 1)
            if a not in yazar:
                yazar.append(a)         # aynı makalede yinelenen yazar yok
        makale_ekle(komsu, yazar)
    listeleri_duzenle(komsu)
    liste = 0
    for l in komsu:
        liste += len(l)
    uzak, _, ulasilan, _ = bfs(komsu, 0)
    dagilim = [0] * (N + 1)
    toplam = en = 0
    for d in uzak:
        if d >= 0:
            dagilim[d] += 1
            toplam += d
            en = max(en, d)
    print(f"2) Yapay ağ (ortak LCG, tohum 2026): N = {N} yazar, M = {M} "
          "makale (2-4 yazar)")
    print(f"   kenar = {liste // 2}, merkezin (0) derecesi = {len(komsu[0])}"
          f", ortalama derece = {oran(liste, N)}")
    print("   merkezden uzaklık dağılımı:"
          + "".join(f" {d}:{dagilim[d]}" for d in range(en + 1))
          + f" ∞:{N - ulasilan}")
    print(f"   ulaşılan = {ulasilan} / {N}, ortalama uzaklık = "
          f"{oran(toplam, ulasilan)}, en büyük = {en}")


def main():
    N, M = 2000, 3000
    if len(sys.argv) not in (2, 4):
        print("Kullanım: H11_13_ortak_yazarlik AG_DOSYASI [N M]",
              file=sys.stderr)
        return 2
    if len(sys.argv) == 4:
        try:
            N, M = int(sys.argv[2]), int(sys.argv[3])
        except ValueError:
            N = -1
        if not (5 <= N <= 1000000 and 1 <= M <= 5000000):
            print("N 5..1000000, M 1..5000000 olmalı", file=sys.stderr)
            return 2
    if not kurgusal_ag(sys.argv[1]):
        return 1
    yapay_ag(N, M)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle; ikili arama için bsearch); C++ —
# yok (std::lower_bound, std::unordered_map ad -> köşe); Python — yok
# (bisect, dict; networkx.shortest_path_length yalnız doğrulama için).

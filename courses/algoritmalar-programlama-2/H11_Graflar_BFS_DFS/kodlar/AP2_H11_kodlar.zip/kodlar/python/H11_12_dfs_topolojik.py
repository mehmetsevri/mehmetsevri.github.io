"""H11_12_dfs_topolojik.py — AP-2 Hafta 11 · Örnek 12 (★★★)
Amaç    : DFS ile topolojik sıralama ve yönlü döngü tespiti (üç renk):
          köşe bitince (siyah) bitiş listesine eklenir; listenin TERSİ
          topolojik sıradır. Gri bir köşeye giden kenar (geri kenar)
          döngüdür: o anki gri yol (özyineleme yığını) döngüyü verir.
Çalıştır: python3 H11_12_dfs_topolojik.py ../girdiler/dersler_dag.txt \\
          ../girdiler/dersler_dongulu.txt
Eşleri  : c/H11_12_dfs_topolojik.c · cpp/H11_12_dfs_topolojik.cpp
Çıktı   : üç dilde aynı (=); yalnız yönlü graflar içindir
"""
import sys

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


BEYAZ, GRI, SIYAH = 0, 1, 2             # keşfedilmedi / yolda / bitti


class Topo:
    __slots__ = ("renk", "kesif", "bitis", "bitis_sirasi", "gri_yol",
                 "zaman", "dongu_u", "dongu_v")

    def __init__(self, V):
        self.renk = [BEYAZ] * V
        self.kesif = [0] * V
        self.bitis = [0] * V
        self.bitis_sirasi = []          # siyaha dönüş sırası
        self.gri_yol = []               # kökten şimdiki köşeye yol
        self.zaman = 0
        self.dongu_u = self.dongu_v = -1    # bulunan geri kenar


def dfs_topo(g, u, t):
    """Üç renkli DFS. Olayları "(u" ve "u)" olarak yazar. Gri komşu =
    geri kenar = döngü: kenar kaydedilir, True döner, bütün DFS durur."""
    t.renk[u] = GRI
    t.zaman += 1
    t.kesif[u] = t.zaman
    t.gri_yol.append(u)
    print(f" ({u}", end="")
    for v in g.komsu[u]:
        if t.renk[v] == GRI:
            t.dongu_u, t.dongu_v = u, v     # geri kenar: döngü
            return True
        if t.renk[v] == BEYAZ and dfs_topo(g, v, t):
            return True
    t.gri_yol.pop()                     # u gri yoldan çıkar
    t.renk[u] = SIYAH
    t.zaman += 1
    t.bitis[u] = t.zaman
    t.bitis_sirasi.append(u)            # bütün ardılları bitti
    print(f" {u})", end="")
    return False


def dizi_yaz(baslik, a):
    print(baslik + "".join(f" {x}" for x in a))


def rapor(g):
    t = Topo(g.V)
    dongu = False
    print("   olaylar ('(u' gri oldu, 'u)' siyah oldu):", end="")
    for r in range(g.V):
        if dongu:
            break
        if t.renk[r] == BEYAZ:
            dongu = dfs_topo(g, r, t)
    print()
    if dongu:
        bas = t.gri_yol.index(t.dongu_v)    # döngü v'den başlar
        print(f"   {t.dongu_u}->{t.dongu_v} kenarında {t.dongu_v} GRİ: "
              "geri kenar")
        dizi_yaz("   gri yol (özyineleme yığını) o anda:", t.gri_yol)
        print("   döngü:" + "".join(f" {x} ->" for x in t.gri_yol[bas:])
              + f" {t.dongu_v} (uzunluk {len(t.gri_yol) - bas})")
        print("   SONUÇ: döngü var — topolojik sıra yok; o ana dek biten "
              "(siyah) köşeler:" + "".join(f" {u}" for u in t.bitis_sirasi))
        return
    dizi_yaz("   bitiş sırası (siyaha dönüş):", t.bitis_sirasi)
    sira = t.bitis_sirasi[::-1]         # ters çevir
    konum = [0] * g.V
    for i, v in enumerate(sira):
        konum[v] = i
    dizi_yaz("   topolojik sıra (bitiş sırasının tersi):", sira)
    gecerli = True
    for u in range(g.V):
        for v in g.komsu[u]:
            gecerli = gecerli and konum[u] < konum[v]
    print("   kâhin: her kenar u->v için konum[u] < konum[v]: "
          + ("evet" if gecerli else "HAYIR") + f" ({g.E} kenar)")
    print("   keşif/bitiş:" + "".join(
        f" {u}:{t.kesif[u]}/{t.bitis[u]}" for u in range(g.V)))
    print("   neden doğru: u->v kenarında v ya beyazdır (u'dan önce biter) "
          "ya siyahtır (zaten bitmiş); gri olamaz (döngü olurdu). Her "
          "durumda bitiş[v] < bitiş[u].")


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_12_dfs_topolojik GRAF [GRAF2 ...]",
              file=sys.stderr)
        return 2
    for i in range(1, len(sys.argv)):
        g = graf_yukle(sys.argv[i])
        if g is None:
            return 1
        if not g.yonlu:
            print(f"{taban_ad(sys.argv[i])}: yönlü bir graf gerekir",
                  file=sys.stderr)
            return 1
        print(f"{i}) {taban_ad(sys.argv[i])} (yönlü, V = {g.V}, E = {g.E}): "
              "DFS, üç renk, kökler artan sırada")
        rapor(g)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
# topological_sort; döngüde not_a_dag istisnası); Python —
# graphlib.TopologicalSorter (CycleError; yalnız kâhin) ve
# networkx.topological_sort / find_cycle (doğrulama için).

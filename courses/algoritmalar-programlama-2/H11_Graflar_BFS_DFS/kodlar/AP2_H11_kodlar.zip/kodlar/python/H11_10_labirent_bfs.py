"""H11_10_labirent_bfs.py — AP-2 Hafta 11 · Örnek 10 (★★★)
Amaç    : Labirentte en kısa yol: ızgara BFS (H3 ile aynı yön sırası:
          sağ, aşağı, sol, yukarı); ebeveyn dizisinden yol. AYNI
          labirentte H3 Örnek 11'in geri izleme çözümüyle karşılaştırma:
          bulunan yol uzunluğu ve ziyaret edilen hücre sayısı. Ek olarak
          açık bir odada geri izlemenin uzun yol bulduğu durum.
Çalıştır: python3 H11_10_labirent_bfs.py < ../girdiler/H11_10_labirent_bfs.txt
          (girdi, H3'ün H03_11_labirent.txt dosyasının aynısıdır)
Eşleri  : c/H11_10_labirent_bfs.c · cpp/H11_10_labirent_bfs.cpp
Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
"""
import sys

MAKS_SATIR = 40
MAKS_SUTUN = 80
DR = (0, 1, 0, -1)                      # sağ, aşağı, sol, yukarı
DC = (1, 0, -1, 0)

# Açık oda: geri izlemenin en kısa yolu kaçırdığı küçük örnek
ODA = ["#########", "#S......#", "#.......#", "#E......#", "#########"]


class Labirent:
    __slots__ = ("h", "S", "Y", "sr", "sc", "er", "ec")

    def __init__(self, satirlar):
        self.h = [list(s) for s in satirlar]   # karakter listeleri
        self.S, self.Y = len(satirlar), len(satirlar[0])
        self.sr = self.sc = self.er = self.ec = 0

    def kopya(self):
        k = Labirent(["".join(s) for s in self.h])
        k.sr, k.sc, k.er, k.ec = self.sr, self.sc, self.er, self.ec
        return k


class Sonuc:
    __slots__ = ("uzunluk", "ziyaret", "eklenen", "geri_donulen")

    def __init__(self):
        self.uzunluk = -1               # yoldaki adım sayısı; yoksa -1
        self.ziyaret = 0                # BFS: kuyruktan çıkan; GI: çağrı
        self.eklenen = 0                # BFS: kuyruğa eklenen
        self.geri_donulen = 0           # geri izleme: çıkmaz hücre


def acik_mi(L, r, c):
    return 0 <= r < L.S and 0 <= c < L.Y and L.h[r][c] != "#"


def bfs_labirent(L):
    """Izgara BFS: S'den başlar, E kuyruktan çıkınca durur. Yol '*',
    işlenen öteki hücreler 'o', kuyrukta kalan (sınır) hücreler '+' ile
    işaretlenir (L değiştirilir). Kuyruk: liste + baş indisi (sınırı
    sonradan yazdırabilmek için deque yerine)."""
    s = Sonuc()
    ebeveyn = [-2] * (L.S * L.Y)        # -2: görülmedi
    q = []
    bas = 0
    kaynak, hedef = L.sr * L.Y + L.sc, L.er * L.Y + L.ec
    ebeveyn[kaynak] = -1
    q.append(kaynak)
    while bas < len(q):
        h = q[bas]
        bas += 1
        r, c = h // L.Y, h % L.Y
        if h == hedef:
            break                       # E kuyruktan çıktı
        for d in range(4):
            yr, yc = r + DR[d], c + DC[d]
            if acik_mi(L, yr, yc) and ebeveyn[yr * L.Y + yc] == -2:
                ebeveyn[yr * L.Y + yc] = h
                q.append(yr * L.Y + yc)
    s.ziyaret, s.eklenen = bas, len(q)
    for i, h in enumerate(q):           # işlenen ve sınır
        if L.h[h // L.Y][h % L.Y] == ".":
            L.h[h // L.Y][h % L.Y] = "o" if i < bas else "+"
    if ebeveyn[hedef] != -2:
        s.uzunluk = 0
        h = ebeveyn[hedef]
        while h != kaynak:
            L.h[h // L.Y][h % L.Y] = "*"    # ebeveyn zinciri: yol
            s.uzunluk += 1
            h = ebeveyn[h]
        s.uzunluk += 1                  # son adım: E'ye giriş
    return s


def yol_bul(L, r, c, s):
    """H3 Örnek 11'in geri izlemesi (aynı kod): (r, c)'den çıkışa yol"""
    s.ziyaret += 1
    if L.h[r][c] == "E":
        return True                     # çıkışa ulaşıldı
    if L.h[r][c] != "S":
        L.h[r][c] = "*"                 # seç: hücre yola eklenir
    for d in range(4):
        yr, yc = r + DR[d], c + DC[d]
        if (0 <= yr < L.S and 0 <= yc < L.Y
                and L.h[yr][yc] in (".", "E") and yol_bul(L, yr, yc, s)):
            return True                 # yol bulundu: '*'lar kalır
    if L.h[r][c] != "S":
        L.h[r][c] = "x"                 # geri al: buradan çıkış yok
    s.geri_donulen += 1
    return False


def geri_izleme(L):
    s = Sonuc()
    if yol_bul(L, L.sr, L.sc, s):
        s.uzunluk = 1
        for satir in L.h:
            s.uzunluk += satir.count("*")
    return s


def yaz(L):
    for satir in L.h:
        print("   " + "".join(satir))


def konumlari_bul(L):
    """S ve E'yi bulur; tam bir S ve bir E yoksa False"""
    s_sayisi = e_sayisi = 0
    for r in range(L.S):
        for c in range(L.Y):
            k = L.h[r][c]
            if k == "S":
                s_sayisi += 1
                L.sr, L.sc = r, c
            elif k == "E":
                e_sayisi += 1
                L.er, L.ec = r, c
            elif k not in "#.":
                return False
    return s_sayisi == 1 and e_sayisi == 1


def labirent_oku():
    """H3 ile aynı girdi biçimi: ilk satır "satır sütun", ardından ızgara"""
    satirlar = sys.stdin.read().split("\n")
    try:
        r, c = (int(t) for t in satirlar[0].split()[:2])
    except ValueError:
        return None
    if not (1 <= r <= MAKS_SATIR and 1 <= c <= MAKS_SUTUN):
        return None
    izgara = [s.rstrip("\r") for s in satirlar[1:r + 1]]
    if len(izgara) != r or any(len(s) != c for s in izgara):
        return None
    L = Labirent(izgara)
    return L if konumlari_bul(L) else None


def karsilastir(asil):
    a, b = asil.kopya(), asil.kopya()
    s1 = bfs_labirent(a)
    s2 = geri_izleme(b)
    acik = 0
    for satir in asil.h:
        for k in satir:
            acik += k != "#"
    print(f"   BFS (kuyruk; E kuyruktan çıkınca durur): yol = {s1.uzunluk} "
          f"adım, işlenen = {s1.ziyaret}, kuyruğa eklenen = {s1.eklenen}, "
          f"açık hücre = {acik}")
    yaz(a)
    print("   (* yol, o işlenen, + kuyrukta kalan sınır hücresi)")
    print(f"   Geri izleme (H3 Örnek 11): yol = {s2.uzunluk} adım, ziyaret "
          f"= {s2.ziyaret} çağrı, geri dönülen = {s2.geri_donulen}")
    yaz(b)
    print("   (* yol, x denenip geri dönülen hücre)")
    print("   yöntem            yol (adım)  ziyaret  en kısa mı?")
    print(f"   BFS               {s1.uzunluk:10d}  {s1.ziyaret:7d}  "
          "evet (her zaman: katman sırası)")
    print(f"   geri izleme (H3)  {s2.uzunluk:10d}  {s2.ziyaret:7d}  "
          + ("bu labirentte evet (güvence yok)" if s2.uzunluk == s1.uzunluk
             else "HAYIR (ilk bulunan yol)"))


def main():
    L = labirent_oku()
    if L is None:
        print("Hatalı labirent girdisi", file=sys.stderr)
        return 1
    print(f"1) Labirent {L.S} x {L.Y} (H3 ile aynı dosya), S = ({L.sr}, "
          f"{L.sc}), E = ({L.er}, {L.ec})")
    print("   yön sırası (H3 ile aynı): sağ, aşağı, sol, yukarı")
    karsilastir(L)
    oda = Labirent(ODA)
    konumlari_bul(oda)
    print(f"2) Açık oda {oda.S} x {oda.Y} (programa gömülü), S = ({oda.sr}, "
          f"{oda.sc}), E = ({oda.er}, {oda.ec})")
    karsilastir(oda)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: yok (C, C++, Python). Izgarada en kısa yol için
# ağırlıklı durumda Dijkstra (H12); oyunlarda sezgisel A* kullanılır.

"""H11_04_bfs_en_kisa_yol.py — AP-2 Hafta 11 · Örnek 4 (★★)
Amaç    : BFS ile ağırlıksız en kısa yol: uzaklık (kenar sayısı) ve
          ebeveyn dizileri; yolun ebeveyn dizisinden GERİ ÇIKARILMASI;
          ulaşılamayan köşe sözleşmesi: uzaklık = -1, ebeveyn = -1;
          kenar koşuluyla doğrulama (|d[u] - d[v]| <= 1)
Çalıştır: python3 H11_04_bfs_en_kisa_yol.py ../girdiler/graf_ornek.txt \\
          ../girdiler/graf_bilesen.txt
Eşleri  : c/H11_04_bfs_en_kisa_yol.c ·
          cpp/H11_04_bfs_en_kisa_yol.cpp
Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
"""
import sys
from collections import deque

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


def bfs_uzaklik(g, s):
    """BFS(s): (uzak, ebeveyn, ulaşılan); uzak[v] = en az kenar sayısı,
    ebeveyn[v] = BFS ağacında v'yi keşfeden köşe; ulaşılamayan v için -1."""
    q = deque()
    uzak = [-1] * g.V
    ebeveyn = [-1] * g.V
    ulasilan = 0
    uzak[s] = 0
    q.append(s)
    while q:
        u = q.popleft()
        ulasilan += 1
        for v in g.komsu[u]:
            if uzak[v] == -1:
                uzak[v] = uzak[u] + 1
                ebeveyn[v] = u          # v'ye ilk u'dan ulaşıldı
                q.append(v)
    return uzak, ebeveyn, ulasilan


def yol_cikar(ebeveyn, s, t):
    """s'den t'ye yolu ebeveyn zincirinden geri çıkarır: [s, .., t];
    yol yoksa boş liste."""
    yol = []
    if t != s and ebeveyn[t] == -1:
        return yol                      # ulaşılamaz
    v = t
    while v != -1:
        yol.append(v)                   # t, ebeveyn[t], ..., s
        v = ebeveyn[v]
    yol.reverse()                       # s .. t
    return yol


def dogrula(g, s, uzak, ebeveyn):
    """Kâhin: ulaşılan her u'nun her komşusu v de ulaşılmıştır ve
    d[v] <= d[u] + 1 (yönsüzde iki yönden: |d[u] - d[v]| <= 1); ulaşılan
    her v != s için d[v] = d[ebeveyn[v]] + 1."""
    for u in range(g.V):
        for v in g.komsu[u]:
            if uzak[u] != -1 and (uzak[v] == -1 or uzak[v] > uzak[u] + 1):
                return False
        if u != s and uzak[u] != -1 and uzak[u] != uzak[ebeveyn[u]] + 1:
            return False
    return True


def rapor(yol_adi, g, s):
    uzak, ebeveyn, ulasilan = bfs_uzaklik(g, s)
    print(f"{yol_adi} (V = {g.V}, E = {g.E}): kaynak {s}")
    print("   köşe  uzaklık  ebeveyn  en kısa yol")
    en_uzak = s
    for t in range(g.V):
        yol = yol_cikar(ebeveyn, s, t)
        bas = f"   {t:4d}  {uzak[t]:7d}  {ebeveyn[t]:7d}  "
        if not yol:
            print(bas + "ulaşılamaz (yol yok)")
            continue
        print(bas + " -> ".join(str(v) for v in yol))
        if uzak[t] > uzak[en_uzak]:
            en_uzak = t
    print(f"   ulaşılan = {ulasilan} / {g.V}; en uzak köşe {en_uzak} "
          f"({uzak[en_uzak]} kenar)")
    print("   kâhin (kenar koşulu + ebeveyn tutarlılığı): "
          + ("geçti" if dogrula(g, s, uzak, ebeveyn) else "KALDI"))


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_04_bfs_en_kisa_yol GRAF [GRAF2 ...]",
              file=sys.stderr)
        return 2
    for i in range(1, len(sys.argv)):
        g = graf_yukle(sys.argv[i])
        if g is None:
            return 1
        print(f"{i}) ", end="")
        rapor(taban_ad(sys.argv[i]), g, 0)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
# breadth_first_search + predecessor ziyaretçisi); Python — yok
# (networkx.single_source_shortest_path yalnız doğrulama için).

"""H11_07_bagli_bilesenler.py — AP-2 Hafta 11 · Örnek 7 (★★)
Amaç    : Bağlı bileşenler: her etiketsiz köşeden (artan sırada) bir
          BFS; bileşen sayısı ve etiketleri; bileşen başına köşe/kenar
          sayısı ve yönsüz grafta döngü (kenar >= köşe <=> ağaç değil);
          "aynı bileşende mi?" sorusu etiket karşılaştırmasıyla O(1)
Çalıştır: python3 H11_07_bagli_bilesenler.py ../girdiler/graf_bilesen.txt \\
          ../girdiler/graf_ornek.txt
Eşleri  : c/H11_07_bagli_bilesenler.c ·
          cpp/H11_07_bagli_bilesenler.cpp
Çıktı   : üç dilde aynı (=); yalnız yönsüz graflar içindir
"""
import sys
from collections import deque

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


class Sayac:
    __slots__ = ("ekleme", "inceleme", "bfs_sayisi")

    def __init__(self):
        self.ekleme = self.inceleme = 0     # kuyruğa ekleme, incelenen
        self.bfs_sayisi = 0


def bileseni_etiketle(g, s, no, etiket, ebeveyn, say):
    """s'nin bileşenini BFS ile 'no' etiketiyle işaretler. Dönüş:
    (bileşenin köşeleri BFS sırasıyla, ağaç dışı ilk kenar ya da
    (-1, -1))"""
    q = deque()
    uyeler = []
    ilk_dongu = (-1, -1)
    etiket[s] = no
    ebeveyn[s] = -1
    q.append(s)
    say.ekleme += 1
    say.bfs_sayisi += 1
    while q:
        u = q.popleft()
        uyeler.append(u)
        for v in g.komsu[u]:
            say.inceleme += 1
            if etiket[v] == -1:
                etiket[v] = no
                ebeveyn[v] = u
                q.append(v)
                say.ekleme += 1
            elif v != ebeveyn[u] and ilk_dongu[0] == -1:
                ilk_dongu = (u, v)      # ağaç dışı kenar: döngü
    return uyeler, ilk_dongu


def rapor(ad, g):
    etiket = [-1] * g.V
    ebeveyn = [-1] * g.V
    kose = []                           # bileşen başına köşe sayısı
    dongu = []
    say = Sayac()
    print(f"{ad} (yönsüz, V = {g.V}, E = {g.E})")
    for s in range(g.V):
        if etiket[s] != -1:
            continue                    # zaten bir bileşende
        k = len(kose)
        uyeler, ilk = bileseni_etiketle(g, s, k, etiket, ebeveyn, say)
        dongu.append(ilk)
        print(f"   BFS({s}): bileşen {k} = {{"
              + " ".join(str(v) for v in uyeler) + "}")
        kose.append(len(uyeler))
    k = len(kose)
    kenar = [0] * k
    for u in range(g.V):
        kenar[etiket[u]] += len(g.komsu[u])
    print(f"   bileşen sayısı = {k}")
    print("   etiketler: köşe   " + "".join(f" {v}" for v in range(g.V)))
    print("              bileşen" + "".join(f" {x}" for x in etiket))
    print("   bileşen  köşe  kenar  ağaç dışı  döngü")
    for c in range(k):
        e = kenar[c] // 2               # her kenar iki listede
        bas = f"   {c:7d}  {kose[c]:4d}  {e:5d}  {e - kose[c] + 1:9d}  "
        if e >= kose[c]:
            print(bas + f"var (ör. kenar {dongu[c][0]}-{dongu[c][1]})")
        else:
            print(bas + "yok (" + ("yalnız köşe" if kose[c] == 1 else "ağaç")
                  + ")")
    print(f"   sayaçlar: BFS çağrısı = {say.bfs_sayisi}, kuyruğa ekleme = "
          f"{say.ekleme} (= V), kenar inceleme = {say.inceleme} (= 2E)")
    parcalar = []
    for x, y in ((0, g.V - 2), (1, g.V - 1)):
        parcalar.append(f" {x} ve {y}: "
                        + ("evet" if etiket[x] == etiket[y] else "hayır"))
    print("   aynı bileşende mi (etiket karşılaştırması, O(1)):"
          + ";".join(parcalar))


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_07_bagli_bilesenler GRAF [GRAF2 ...]",
              file=sys.stderr)
        return 2
    for i in range(1, len(sys.argv)):
        g = graf_yukle(sys.argv[i])
        if g is None:
            return 1
        if g.yonlu or g.V < 2:
            print(f"{taban_ad(sys.argv[i])}: yönsüz ve V >= 2 bir graf "
                  "gerekir", file=sys.stderr)
            return 1
        print(f"{i}) ", end="")
        rapor(taban_ad(sys.argv[i]), g)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
# connected_components); Python — yok (networkx.connected_components
# yalnız doğrulama için). Birleşim–bul (H12) ikinci bir yoldur.

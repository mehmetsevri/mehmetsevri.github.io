"""H11_09_tasma_doldurma.py — AP-2 Hafta 11 · Örnek 9 (★★)
Amaç    : Örtük graf: ızgaranın her hücresi bir köşe, komşu hücreler
          kenar (kenarlar saklanmaz, hesaplanır). Taşkın doldurma (BFS
          dalgası) ve ada sayma; 4 ve 8 komşuluk (AP-1 H11 di/dj
          dizileri). Sınır denetimi komşuya ERİŞMEDEN ÖNCE yapılır.
Çalıştır: python3 H11_09_tasma_doldurma.py \\
          < ../girdiler/H11_09_tasma_doldurma.txt
          (ilk satır "S Y r0 c0", sonra S satır: '#' kara, '.' su)
Eşleri  : c/H11_09_tasma_doldurma.c ·
          cpp/H11_09_tasma_doldurma.cpp
Çıktı   : üç dilde aynı (=); yön sırası yukarı, aşağı, sol, sağ; hata: kod 1
"""
import sys
from collections import deque

MAKS = 100

# İlk 4: yukarı, aşağı, sol, sağ (4-komşuluk); son 4: çaprazlar
di = (-1, 1, 0, 0, -1, -1, 1, 1)
dj = (0, 0, -1, 1, -1, 1, -1, 1)

S = Y = 0                               # satır ve sütun sayısı
deneme = sinir_disi = 0


def icinde(i, j):
    """(i, j) ızgarada mı? Hücreye erişmeden ÖNCE çağrılır."""
    return 0 <= i < S and 0 <= j < Y


def doldur(iz, i0, j0, eski, yeni, yon, katman=None):
    """(i0, j0)'dan başlayıp 'eski' karakterli hücreleri 'yeni' yapar
    (BFS). iz: karakter listesi; yon: 4 ya da 8. Dönüş: değiştirilen
    hücreler (BFS sırasıyla). katman verilirse dalga numaraları yazılır."""
    global deneme, sinir_disi
    q = deque()
    sira = []
    iz[i0 * Y + j0] = yeni              # işaret kuyruğa EKLERKEN
    q.append(i0 * Y + j0)
    if katman is not None:
        katman[i0 * Y + j0] = 0
    while q:
        h = q.popleft()
        i, j = h // Y, h % Y
        sira.append(h)
        for k in range(yon):
            ni, nj = i + di[k], j + dj[k]
            deneme += 1
            if not icinde(ni, nj):
                sinir_disi += 1         # erişilmeden reddedildi
                continue
            if iz[ni * Y + nj] == eski:
                iz[ni * Y + nj] = yeni
                q.append(ni * Y + nj)
                if katman is not None:
                    katman[ni * Y + nj] = katman[h] + 1
    return sira


def izgara_yaz(iz):
    for i in range(S):
        print("   " + "".join(iz[i * Y:(i + 1) * Y]))


def adalari_say(harita, yon):
    """Adaları (kara '#') yon-komşulukla A, B, C, ... harfleriyle boyar.
    Dönüş: (boyanmış ızgara, etiket listesi, ada boyutları)"""
    iz = list(harita)
    etiket = [-1] * len(harita)
    boyut = []
    for h in range(S * Y):
        if iz[h] != "#":
            continue
        ada = len(boyut)
        harf = chr(ord("A") + ada) if ada < 26 else "*"
        hucre = doldur(iz, h // Y, h % Y, "#", harf, yon)
        for x in hucre:
            etiket[x] = ada
        boyut.append(len(hucre))
    return iz, etiket, boyut


def boyut_yaz(boyut):
    print("   boyutlar:" + "".join(
        f" {chr(ord('A') + a) if a < 26 else '*'}={boyut[a]}"
        for a in range(len(boyut))))


def izgara_oku():
    """İlk satır "S Y r0 c0", sonra S satır; yalnız '#' ve '.'.
    Dönüş: (harita metni, r0, c0) ya da None"""
    global S, Y
    satirlar = sys.stdin.read().split("\n")
    try:
        x = [int(t) for t in satirlar[0].split()[:4]]
    except ValueError:
        return None
    if (len(x) < 4 or not 1 <= x[0] <= MAKS or not 1 <= x[1] <= MAKS
            or not 0 <= x[2] < x[0] or not 0 <= x[3] < x[1]):
        return None
    S, Y = x[0], x[1]
    harita = ""
    for i in range(1, S + 1):
        if i >= len(satirlar):
            return None
        satir = satirlar[i].rstrip("\r")
        if len(satir) != Y or satir.strip("#.") != "":
            return None
        harita += satir
    return harita, x[2], x[3]


def main():
    sonuc = izgara_oku()
    if sonuc is None:
        print("Hatalı ızgara girdisi", file=sys.stderr)
        return 1
    harita, r0, c0 = sonuc
    print(f"Izgara {S} x {Y} ('#' kara, '.' su); taşkın başlangıcı "
          f"({r0}, {c0})")
    iz = list(harita)
    if iz[r0 * Y + c0] != ".":
        print("1) Başlangıç hücresi su değil: doldurma yapılmadı")
    else:
        katman = [0] * len(harita)
        dolan = doldur(iz, r0, c0, ".", "~", 4, katman)
        kalan = iz.count(".")
        en_uzak = katman[dolan[-1]]
        print(f"1) Taşkın doldurma (BFS, 4-komşuluk): ({r0}, {c0})'dan "
              "ulaşılan su '~'")
        izgara_yaz(iz)
        print(f"   doldurulan hücre = {len(dolan)}, dalga sayısı = "
              f"{en_uzak + 1} (en uzak hücre {en_uzak} adımda)")
        print(f"   komşu denemesi = {deneme}, sınır dışı = {sinir_disi} "
              "(komşuya ERİŞMEDEN reddedildi)")
        print(f"   doldurulmayan su hücresi = {kalan} (çevresi kara: göl)")
        print("   dalga numaraları (mod 10; '#' kara, '.' ulaşılmayan):")
        for i in range(S):
            print("   " + "".join(
                str(katman[i * Y + j] % 10) if iz[i * Y + j] == "~"
                else iz[i * Y + j] for j in range(Y)))
    iz, etiket4, boyut4 = adalari_say(harita, 4)
    print(f"2) Ada sayma, 4-komşuluk (yalnız dik yönler): {len(boyut4)} ada")
    izgara_yaz(iz)
    boyut_yaz(boyut4)
    iz, etiket8, boyut8 = adalari_say(harita, 8)
    print(f"3) Ada sayma, 8-komşuluk (çaprazlar da): {len(boyut8)} ada")
    izgara_yaz(iz)
    boyut_yaz(boyut8)
    parcalar = []
    for b in range(len(boyut8)):
        uyeler = []
        for a in range(min(len(boyut4), 26)):
            h = etiket4.index(a)        # adanın ilk hücresi
            if etiket8[h] == b:
                uyeler.append(chr(ord("A") + a))
        if len(uyeler) > 1:
            harf = chr(ord("A") + b) if b < 26 else "*"
            parcalar.append(" " + "+".join(uyeler) + " -> " + harf)
    print("   8-komşulukta birleşenler (4-komşuluk adaları):"
          + (";".join(parcalar) if parcalar else " yok"))
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok; Python — yok
# (scipy.ndimage.label ve OpenCV floodFill/connectedComponents görüntü
# işlemede aynı işi yapar; ders dışı).

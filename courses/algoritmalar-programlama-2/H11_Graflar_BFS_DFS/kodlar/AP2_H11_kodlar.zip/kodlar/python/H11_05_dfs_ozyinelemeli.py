"""H11_05_dfs_ozyinelemeli.py — AP-2 Hafta 11 · Örnek 5 (★★)
Amaç    : Özyinelemeli derinlik öncelikli arama (DFS): ziyaret sırası,
          keşif/bitiş zamanları, üç renk (beyaz/gri/siyah), parantez
          yapısı; yönsüzde ağaç ve geri kenarlar; yönlüde ağaç / geri /
          ileri / çapraz kenar sınıflaması (DFS ormanı)
Çalıştır: python3 H11_05_dfs_ozyinelemeli.py ../girdiler/graf_ornek.txt \\
          ../girdiler/graf_yonlu.txt
Eşleri  : c/H11_05_dfs_ozyinelemeli.c ·
          cpp/H11_05_dfs_ozyinelemeli.cpp
Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
"""
import sys

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


BEYAZ, GRI, SIYAH = 0, 1, 2             # keşfedilmedi / yolda / bitti
AGAC, GERI, ILERI, CAPRAZ = 0, 1, 2, 3
RENK_ADI = ("beyaz", "gri", "siyah")
SINIF_ADI = ("ağaç", "geri", "ileri", "çapraz")


class Dfs:
    __slots__ = ("renk", "kesif", "bitis", "ebeveyn", "sira", "olay",
                 "kenar", "zaman", "derinlik", "en_derin")

    def __init__(self, V):
        self.renk = [BEYAZ] * V
        self.kesif = [0] * V
        self.bitis = [0] * V
        self.ebeveyn = [-1] * V
        self.sira = []                  # ziyaret (keşif) sırası
        self.olay = []                  # u: "(u", -1 - u: "u)"
        self.kenar = []                 # (u, v, tür, v'nin rengi)
        self.zaman = self.derinlik = self.en_derin = 0


def kenar_kaydet(d, u, v, tur):
    d.kenar.append((u, v, tur, d.renk[v]))


def dfs_ziyaret(g, u, d):
    """Özyinelemeli DFS: u gri olur, beyaz komşulara inilir, u siyah olur"""
    d.renk[u] = GRI
    d.zaman += 1
    d.kesif[u] = d.zaman
    d.sira.append(u)
    d.olay.append(u)
    d.derinlik += 1
    d.en_derin = max(d.en_derin, d.derinlik)
    for v in g.komsu[u]:
        if d.renk[v] == BEYAZ:
            kenar_kaydet(d, u, v, AGAC)
            d.ebeveyn[v] = u
            dfs_ziyaret(g, v, d)
        elif g.yonlu:
            kenar_kaydet(d, u, v, GERI if d.renk[v] == GRI else
                         ILERI if d.kesif[u] < d.kesif[v] else CAPRAZ)
        elif d.renk[v] == GRI and v != d.ebeveyn[u]:
            kenar_kaydet(d, u, v, GERI)     # yönsüz: atasına kenar
    d.derinlik -= 1
    d.renk[u] = SIYAH
    d.zaman += 1
    d.bitis[u] = d.zaman
    d.olay.append(-1 - u)


def tablo_yaz(g, d):
    print("   ziyaret sırası (keşif):" + "".join(f" {u}" for u in d.sira))
    print("   köşe  keşif  bitiş  ebeveyn")
    for u in range(g.V):
        print(f"   {u:4d}  {d.kesif[u]:5d}  {d.bitis[u]:5d}  "
              f"{d.ebeveyn[u]:7d}")
    print("   parantez yapısı:" + "".join(
        f" ({x}" if x >= 0 else f" {-1 - x})" for x in d.olay))


def dfs_orman(g, d):
    """DFS ormanı: her beyaz köşeden (artan sırada) yeni bir ağaç. Kökleri
    yazar; ağaç sayısını döndürür."""
    agac = 0
    print("DFS ormanı, kökler artan sırada:", end="")
    for r in range(g.V):
        if d.renk[r] == BEYAZ:
            print(f" {r}", end="")
            dfs_ziyaret(g, r, d)
            agac += 1
    print()
    return agac


def yonsuz_rapor(g, d):
    agac = dfs_orman(g, d)
    tablo_yaz(g, d)
    for tur in (AGAC, GERI):
        secilen = [k for k in d.kenar if k[2] == tur]
        print(f"   {SINIF_ADI[tur]} kenarları ({len(secilen)} = "
              + ("V -" if tur == AGAC else "E - V +") + f" {agac}):"
              + "".join(f" {u}-{v}" for u, v, _, _ in secilen))
    print("   (yönsüz DFS'de ileri ve çapraz kenar olmaz; siyah komşuya "
          "giden kenar zaten geri kenar olarak sayıldı)")
    print(f"   en büyük özyineleme derinliği = {d.en_derin}")


def yonlu_rapor(g, d):
    sayi = [0, 0, 0, 0]
    dfs_orman(g, d)
    tablo_yaz(g, d)
    print("   kenarlar (incelenme sırasıyla):")
    for i, (u, v, tur, v_renk) in enumerate(d.kenar, 1):
        sayi[tur] += 1
        metin = f"   {i:2d}) {u}->{v}: v {RENK_ADI[v_renk]}"
        if v_renk == SIYAH:
            isaret = "<" if d.kesif[u] < d.kesif[v] else ">"
            metin += (f", keşif[{u}] = {d.kesif[u]} {isaret} "
                      f"keşif[{v}] = {d.kesif[v]}")
        print(metin + f" -> {SINIF_ADI[tur]}")
    print(f"   sayılar: ağaç {sayi[AGAC]}, geri {sayi[GERI]}, ileri "
          f"{sayi[ILERI]}, çapraz {sayi[CAPRAZ]} (toplam {len(d.kenar)} = E)")
    var = "var" if sayi[GERI] > 0 else "yok"
    print(f"   geri kenar {var}: yönlü döngü {var} (bkz. Örnek 12)")
    print(f"   en büyük özyineleme derinliği = {d.en_derin}")


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_05_dfs_ozyinelemeli GRAF [GRAF2 ...]",
              file=sys.stderr)
        return 2
    for i in range(1, len(sys.argv)):
        g = graf_yukle(sys.argv[i])
        if g is None:
            return 1
        d = Dfs(g.V)
        print(f"{i}) {taban_ad(sys.argv[i])} ("
              + ("yönlü" if g.yonlu else "yönsüz")
              + f", V = {g.V}, E = {g.E}): ", end="")
        if g.yonlu:
            yonlu_rapor(g, d)
        else:
            yonsuz_rapor(g, d)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
# depth_first_search + ziyaretçi olayları tree_edge/back_edge/
# forward_or_cross_edge); Python — yok (networkx.dfs_preorder_nodes,
# dfs_labeled_edges yalnız doğrulama için).

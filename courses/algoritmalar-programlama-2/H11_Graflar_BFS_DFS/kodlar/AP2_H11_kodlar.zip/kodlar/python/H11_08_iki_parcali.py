"""H11_08_iki_parcali.py — AP-2 Hafta 11 · Örnek 8 (★★)
Amaç    : İki parçalılık sınaması: BFS ile 2-renklendirme (komşunun
          rengi = 1 - renk). Aynı renkli iki komşu ÇELİŞKİDİR: graf iki
          parçalı değildir ve BFS ağacından tek uzunluklu bir döngü
          çıkarılır (iki ucun ortak atası üzerinden)
Çalıştır: python3 H11_08_iki_parcali.py ../girdiler/graf_ornek.txt \\
          ../girdiler/graf_tek_dongu.txt
Eşleri  : c/H11_08_iki_parcali.c · cpp/H11_08_iki_parcali.cpp
Çıktı   : üç dilde aynı (=); yönsüz graf; kökler ve komşular artan sırada
"""
import sys
from collections import deque

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


class Boyama:
    __slots__ = ("renk", "uzak", "ebeveyn", "cu", "cv")

    def __init__(self, V):
        self.renk = [-1] * V            # -1: boyanmadı
        self.uzak = [0] * V
        self.ebeveyn = [-1] * V
        self.cu = self.cv = -1          # çelişkili kenar


def bfs_boya(g, s, b):
    """s'nin bileşenini BFS ile boyar; her adımı yazar. Çelişkide durur:
    b.cu, b.cv kenarı kaydedilir, False döner."""
    q = deque()
    b.renk[s] = 0
    b.uzak[s] = 0
    b.ebeveyn[s] = -1
    q.append(s)
    print(f"   kök {s} -> renk 0")
    while q:
        u = q.popleft()
        parcalar = []
        for v in g.komsu[u]:
            if b.renk[v] == -1:
                b.renk[v] = 1 - b.renk[u]       # karşı renk
                b.uzak[v] = b.uzak[u] + 1
                b.ebeveyn[v] = u
                q.append(v)
                parcalar.append(f" {v} -> {b.renk[v]}")
            elif b.renk[v] == b.renk[u]:
                parcalar.append(f" {v} ÇELİŞKİ")
                print(f"   çıkan {u} (renk {b.renk[u]}):"
                      + ",".join(parcalar))
                b.cu, b.cv = u, v
                return False
            else:
                parcalar.append(f" {v} uygun")
        print(f"   çıkan {u} (renk {b.renk[u]}):" + ",".join(parcalar))
    return True


def tek_dongu_yaz(b):
    """Çelişkili (u, v) kenarı ve BFS ağacından tek döngü: u -> .. -> ata
    -> .. -> v (-> u). Uçların derinlikleri aynı paritededir (aynı renk),
    bu yüzden döngünün uzunluğu (iki yol + 1 kenar) tektir."""
    ya, yb = [b.cu], [b.cv]
    a, c = b.cu, b.cv
    while b.uzak[a] > b.uzak[c]:
        a = b.ebeveyn[a]
        ya.append(a)
    while b.uzak[c] > b.uzak[a]:
        c = b.ebeveyn[c]
        yb.append(c)
    while a != c:                       # ortak ataya birlikte çık
        a, c = b.ebeveyn[a], b.ebeveyn[c]
        ya.append(a)
        yb.append(c)
    yol = ya + yb[-2::-1]               # u .. ata, ata'nın altından v'ye
    na, nb = len(ya), len(yb)
    print("   tek uzunluklu döngü:" + "".join(f" {x} ->" for x in yol)
          + f" {b.cu} (uzunluk {na + nb - 1} = {na - 1} + {nb - 1} + 1; "
          f"ortak ata {a})")


def rapor(ad, g):
    b = Boyama(g.V)
    iki_parcali = True
    print(f"{ad} (yönsüz, V = {g.V}, E = {g.E})")
    for s in range(g.V):
        if not iki_parcali:
            break
        if b.renk[s] == -1:
            iki_parcali = bfs_boya(g, s, b)
    if not iki_parcali:
        print(f"   çelişki: kenar ({b.cu}, {b.cv}), iki ucu da renk "
              f"{b.renk[b.cu]}")
        tek_dongu_yaz(b)
        print("   iki parçalı: hayır (tek uzunluklu döngü içeren graf "
              "2 renkle boyanamaz)")
        return
    print("   renkler: köşe" + "".join(f" {v}" for v in range(g.V)))
    print("            renk" + "".join(f" {r}" for r in b.renk))
    A = " ".join(str(v) for v in range(g.V) if b.renk[v] == 0)
    B = " ".join(str(v) for v in range(g.V) if b.renk[v] == 1)
    print(f"   iki parçalı: evet; A = {{{A}}}, B = {{{B}}}")
    kenar = 0
    for u in range(g.V):
        for v in g.komsu[u]:
            kenar += b.renk[u] != b.renk[v]
    print(f"   denetim: iki ucu farklı renkte olan kenar = {kenar // 2} / "
          f"{g.E}")


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_08_iki_parcali GRAF [GRAF2 ...]",
              file=sys.stderr)
        return 2
    for i in range(1, len(sys.argv)):
        g = graf_yukle(sys.argv[i])
        if g is None:
            return 1
        if g.yonlu:
            print(f"{taban_ad(sys.argv[i])}: yönsüz bir graf gerekir",
                  file=sys.stderr)
            return 1
        print(f"{i}) ", end="")
        rapor(taban_ad(sys.argv[i]), g)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
# is_bipartite); Python — yok (networkx.is_bipartite yalnız doğrulama
# için).

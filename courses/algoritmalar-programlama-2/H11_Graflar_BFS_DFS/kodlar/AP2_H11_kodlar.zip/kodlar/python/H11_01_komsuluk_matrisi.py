"""H11_01_komsuluk_matrisi.py — AP-2 Hafta 11 · Örnek 1 (★)
Amaç    : Komşuluk matrisi (AP-1 H11 2B dizisi): yönsüz G ve yönlü G3;
          derece, giriş/çıkış derecesi, el sıkışma lemması denetimi;
          satır taramasıyla komşu bulma (her köşe için V hücre okunur)
Çalıştır: python3 H11_01_komsuluk_matrisi.py
Eşleri  : c/H11_01_komsuluk_matrisi.c ·
          cpp/H11_01_komsuluk_matrisi.cpp
Çıktı   : üç dilde aynı (=)
"""

# Haftanın örnek grafı G (girdiler/graf_ornek.txt ile aynı kenarlar)
G_KENAR = [
    (4, 5), (0, 2), (6, 7), (1, 3), (0, 1),
    (4, 6), (2, 4), (3, 5), (5, 7), (1, 4),
]
# Yönlü G3 (girdiler/graf_yonlu.txt ile aynı kenarlar): u -> v
G3_KENAR = [
    (4, 5), (2, 0), (0, 1), (5, 6), (7, 5), (2, 3),
    (0, 4), (6, 4), (3, 1), (1, 2), (4, 3), (0, 2),
]

okunan_hucre = 0                    # satır taramasında okunan hücre


def matris_kur(V, kenar, yonlu):
    matris = [[0] * V for _ in range(V)]
    for u, v in kenar:
        matris[u][v] = 1
        if not yonlu:
            matris[v][u] = 1        # yönsüz: iki yönde de
    return matris


def matris_yaz(matris):
    V = len(matris)
    print("       " + "".join(f" {v}" for v in range(V)))
    for u in range(V):
        print(f"    {u}: " + "".join(f" {x}" for x in matris[u]))


def asimetri(matris):
    """Simetrikse -1, değilse ilk asimetrik hücrenin u * V + v değeri"""
    V = len(matris)
    for u in range(V):
        for v in range(u + 1, V):
            if matris[u][v] != matris[v][u]:
                return u * V + v
    return -1


def komsulari_bul(matris, u):
    """u'nun komşuları: satır u baştan sona taranır (V hücre)"""
    global okunan_hucre
    komsu = []
    for v in range(len(matris)):
        okunan_hucre += 1
        if matris[u][v] != 0:
            komsu.append(v)
    return komsu


def yonsuz_bolum():
    global okunan_hucre
    V = 8
    E = len(G_KENAR)
    derece = [0] * V
    toplam = 0
    matris = matris_kur(V, G_KENAR, False)
    print(f"1) Yönsüz G: V = {V}, E = {E}; "
          f"matris[u][v] = matris[v][u] = 1")
    matris_yaz(matris)
    print("   simetrik mi: " + ("evet" if asimetri(matris) < 0 else "hayır"))
    print("   komşular (satır taraması) ve derece:")
    okunan_hucre = 0
    for u in range(V):
        komsu = komsulari_bul(matris, u)
        k = len(komsu)
        derece[u] = k
        toplam += k
        print(f"    {u}: derece {k}, komşular:"
              + "".join(f" {v}" for v in komsu))
    bir_olan = 0
    for u in range(V):
        for v in range(V):
            bir_olan += matris[u][v]
    print(f"   okunan hücre = {okunan_hucre} = V² = {V * V} "
          f"(komşu sayısından bağımsız)")
    print(f"   el sıkışma lemması: Σ derece = {toplam}, 2E = {2 * E} -> "
          + ("doğru" if toplam == 2 * E else "YANLIŞ"))
    print(f"   1 olan hücre = {bir_olan} / {V * V} (her kenar iki hücrede)")
    en = 0
    for u in range(1, V):
        if derece[u] > derece[en]:
            en = u                  # eşitlikte küçük numara kalır
    print(f"   en büyük derece: köşe {en} ({derece[en]})\n")


def sifirlari_yaz(d):
    """d[u] == 0 olan köşeler; hiç yoksa " yok" (metin döndürür)"""
    metin = "".join(f" {u}" for u in range(len(d)) if d[u] == 0)
    return metin if metin else " yok"


def yonlu_bolum():
    V = 8
    E = len(G3_KENAR)
    cikis = [0] * V
    giris = [0] * V
    matris = matris_kur(V, G3_KENAR, True)
    print(f"2) Yönlü G3: V = {V}, E = {E}; matris[u][v] = 1: u -> v")
    matris_yaz(matris)
    a = asimetri(matris)
    if a < 0:
        print("   simetrik mi: evet")
    else:
        u, v = a // V, a % V
        print(f"   simetrik mi: hayır (ör. matris[{u}][{v}] = "
              f"{matris[u][v]}, matris[{v}][{u}] = {matris[v][u]})")
    for u in range(V):
        for v in range(V):
            cikis[u] += matris[u][v]    # satır toplamı
            giris[v] += matris[u][v]    # sütun toplamı
    top_cikis = top_giris = 0
    for u in range(V):
        top_cikis += cikis[u]
        top_giris += giris[u]
    print("   köşe:          " + "".join(f" {u}" for u in range(V)))
    print("   çıkış derecesi:" + "".join(f" {x}" for x in cikis))
    print("   giriş derecesi:" + "".join(f" {x}" for x in giris))
    print(f"   Σ çıkış = {top_cikis}, Σ giriş = {top_giris}, E = {E} -> "
          + ("doğru" if top_cikis == E and top_giris == E else "YANLIŞ"))
    print("   kaynak (giriş 0):" + sifirlari_yaz(giris)
          + "; kuyu (çıkış 0):" + sifirlari_yaz(cikis) + "\n")


def main():
    yonsuz_bolum()
    yonlu_bolum()
    print("3) Matris belleği V² hücredir (1 bayt/hücre varsayımıyla):")
    for v in (8, 1000, 100000):
        print(f"   V = {v:7d} -> V² = {v * v:12d} hücre")
    print("   (V = 100000 için 10^10 hücre ≈ 10 GB: bkz. Kaputun Altında)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (2B dizi elle); C++ — yok (std::vector
# ile 2B dizi; Boost.Graph adjacency_matrix); Python — yok (liste
# listesi; networkx.to_numpy_array yalnız doğrulama için).

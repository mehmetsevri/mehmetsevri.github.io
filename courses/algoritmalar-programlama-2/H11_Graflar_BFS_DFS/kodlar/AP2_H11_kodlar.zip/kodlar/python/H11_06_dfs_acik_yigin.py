"""H11_06_dfs_acik_yigin.py — AP-2 Hafta 11 · Örnek 6 (★★)
Amaç    : Özyinelemesiz DFS (açık yığın). Özyinelemeli sürümle AYNI
          sırayı vermenin iki yolu: (A) yığında (köşe, sıradaki komşu
          indisi) çerçeveleri — keşif/bitiş ve kenar sınıfları da aynı;
          (B) komşular TERS sırada itilir, işaret ÇIKARIRKEN konur —
          ziyaret sırası aynı, yığına fazladan öğe girer. (C) artan
          sırada itmek başka bir sıra verir. Kâhin: özyinelemeli DFS.
Çalıştır: python3 H11_06_dfs_acik_yigin.py ../girdiler/graf_ornek.txt \\
          ../girdiler/graf_yonlu.txt
Eşleri  : c/H11_06_dfs_acik_yigin.c · cpp/H11_06_dfs_acik_yigin.cpp
Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
"""
import sys

MAKS_KOSE = 1000000
MAKS_KENAR = 10000000
SATIR_UZ = 256


class Graf:
    """Komşuluk listesi: liste listesi (dinamik dizi dizisi)"""
    __slots__ = ("V", "E", "yonlu", "komsu")

    def __init__(self):
        self.V, self.E, self.yonlu, self.komsu = 0, 0, False, []


def taban_ad(yol):
    """Yolun son bileşeni: stdout'a mutlak yol yazılmaz"""
    return yol[yol.rfind("/") + 1:]


def tamsayi_coz(s):
    """s (bytes): isteğe bağlı '-' ve 1..9 rakam; değilse None"""
    p = s[1:] if s[:1] == b"-" else s
    if len(p) == 0 or len(p) > 9:
        return None
    for b in p:
        if b < 48 or b > 57:        # '0'..'9' dışında
            return None
    return int(s)


def baslik_isle(bel, g):
    """Başlık "V E [yonlu|yonsuz]": geçerliyse boş graf kurar"""
    V, E = tamsayi_coz(bel[0]), tamsayi_coz(bel[1])
    if (V is None or E is None or V < 1 or V > MAKS_KOSE or E < 0
            or E > MAKS_KENAR
            or (len(bel) == 3 and bel[2] not in (b"yonlu", b"yonsuz"))):
        return False
    g.V, g.E = V, E
    g.yonlu = len(bel) == 3 and bel[2] == b"yonlu"
    g.komsu = [[] for _ in range(V)]
    return True


def kenar_isle(bel, g):
    """Kenar satırı "u v [w]" (w okunur ama kullanılmaz)"""
    x = [tamsayi_coz(b) for b in bel]
    if None in x or not (0 <= x[0] < g.V and 0 <= x[1] < g.V):
        return False
    g.komsu[x[0]].append(x[1])
    if not g.yonlu:
        g.komsu[x[1]].append(x[0])
    return True


def graf_yukle(yol):
    """Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler
    (ortak dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra
    her liste artan sıraya dizilir (belirli sıra). Hata: stderr, None."""
    try:
        f = open(yol, "rb")
    except OSError:
        print(f"{taban_ad(yol)}: dosya açılamadı", file=sys.stderr)
        return None
    g = Graf()
    no, okunan, hata = 0, -1, False     # okunan -1: başlık yok
    with f:
        for satir in f:
            no += 1
            uzunluk = len(satir) - (1 if satir.endswith(b"\n") else 0)
            if uzunluk >= SATIR_UZ - 1:
                hata = True             # satır çok uzun
                break
            bel = satir.split()[:4]     # en çok 4 belirteç (4 = fazla)
            n = len(bel)
            if n == 0 or bel[0][:1] == b"#":
                continue                # boş satır ya da yorum
            if n < 2 or n > 3 or okunan == g.E:
                hata = True
            elif okunan < 0:
                hata = not baslik_isle(bel, g)
                okunan = 0
            else:
                hata = not kenar_isle(bel, g)
                okunan += 1
            if hata:
                break
    if hata:
        print(f"{taban_ad(yol)}: satır {no}: biçim hatası (bkz. Örnek 2)",
              file=sys.stderr)
        return None
    if okunan < g.E:
        print(f"{taban_ad(yol)}: başlık ya da kenar eksik", file=sys.stderr)
        return None
    for liste in g.komsu:
        liste.sort()
    return g


BEYAZ, GRI, SIYAH = 0, 1, 2
AGAC, GERI, ILERI, CAPRAZ = 0, 1, 2, 3


class Dfs:
    __slots__ = ("renk", "kesif", "bitis", "sira", "tur", "zaman")

    def __init__(self, V):
        self.renk = [BEYAZ] * V
        self.kesif = [0] * V
        self.bitis = [0] * V
        self.sira = []                  # ziyaret (keşif) sırası
        self.tur = []                   # yönlüde kenar sınıfları
        self.zaman = 0


def sinif(d, u, v):
    """(u, v) kenarının sınıfı; v'nin rengi değişmeden ÖNCE çağrılır"""
    if d.renk[v] == BEYAZ:
        return AGAC
    if d.renk[v] == GRI:
        return GERI
    return ILERI if d.kesif[u] < d.kesif[v] else CAPRAZ


def kesfet(d, u):
    d.renk[u] = GRI
    d.zaman += 1
    d.kesif[u] = d.zaman
    d.sira.append(u)


def ozy_ziyaret(g, u, d):
    """Kâhin: Örnek 5'teki özyinelemeli DFS"""
    kesfet(d, u)
    for v in g.komsu[u]:
        if g.yonlu:
            d.tur.append(sinif(d, u, v))
        if d.renk[v] == BEYAZ:
            ozy_ziyaret(g, v, d)
    d.renk[u] = SIYAH
    d.zaman += 1
    d.bitis[u] = d.zaman


def cerceve_metni(y):
    return "yığın: [" + " ".join(f"{u}:{i}" for u, i in y) + "]"


def dfs_cerceve(g, kok, d, iz):
    """(A) Çerçeve yığını: tepedeki [u, i] çerçevesi u'nun i. komşusuyla
    sürer; komşu kalmayınca u biter ve çerçeve çıkarılır. Özyinelemeli
    çağrının yerel değişkenleri (u, i) burada açıkça saklanır."""
    y = []                              # list yığın olarak
    kesfet(d, kok)
    y.append([kok, 0])
    if iz:
        print(f"   it {kok}          " + cerceve_metni(y))
    while y:
        c = y[-1]
        u = c[0]
        if c[1] < len(g.komsu[u]):
            v = g.komsu[u][c[1]]
            c[1] += 1
            if g.yonlu:
                d.tur.append(sinif(d, u, v))
            if d.renk[v] == BEYAZ:
                kesfet(d, v)
                y.append([v, 0])
                if iz:
                    print(f"   it {v}          " + cerceve_metni(y))
        else:
            d.renk[u] = SIYAH
            d.zaman += 1
            d.bitis[u] = d.zaman
            y.pop()
            if iz:
                print(f"   çıkar {u} ({d.bitis[u]:2d})  " + cerceve_metni(y))


def yigin_metni(y):
    return "yığın: [" + " ".join(str(x) for x in y) + "]"


def dfs_itmeli(g, kok, ters, iz):
    """(B) ters ve (C) artan sırada itme: işaret ÇIKARIRKEN konur, zaten
    ziyaret edilmiş öğe atlanır. Bir köşe yığına birden çok kez girebilir.
    Dönüş: (sıra, itme, atlanan)"""
    y, sira = [], []
    ziyaret = [False] * g.V
    itme, atlanan = 1, 0
    y.append(kok)
    while y:
        u = y.pop()
        if ziyaret[u]:
            atlanan += 1
            if iz:
                print(f"   çıkar {u}: zaten ziyaretli, atla;  "
                      + yigin_metni(y))
            continue
        ziyaret[u] = True
        sira.append(u)
        k = len(g.komsu[u])
        itilen = []
        for j in range(k):
            v = g.komsu[u][k - 1 - j if ters else j]
            if not ziyaret[v]:
                y.append(v)
                itme += 1
                itilen.append(v)
        if iz:
            print(f"   çıkar {u}: ziyaret ({len(sira)}.), it:"
                  + ("".join(f" {v}" for v in itilen) if itilen else " -")
                  + ";  " + yigin_metni(y))
    return sira, itme, atlanan


def sira_yaz(baslik, a):
    print(baslik + "".join(f" {x}" for x in a))


def evet(b, hayir="HAYIR"):
    return "evet" if b else hayir


def yonsuz_rapor(g, ozy):
    """Yönsüz graf: (A), (B), (C) izleri ve özyinelemeliyle karşılaştırma"""
    a = Dfs(g.V)
    print("   (A) çerçeve yığını, u:i = köşe:sıradaki komşu indisi; "
          "çıkarken (bitiş zamanı)")
    dfs_cerceve(g, 0, a, True)
    sira_yaz("   (A) ziyaret sırası:", a.sira)
    print(f"   (A) özyinelemeliyle aynı mı: sıra {evet(a.sira == ozy.sira)}, "
          f"keşif {evet(a.kesif == ozy.kesif)}, "
          f"bitiş {evet(a.bitis == ozy.bitis)}")
    print("   (B) komşular TERS sırada itilir, işaret çıkarırken:")
    sira, itme, atlanan = dfs_itmeli(g, 0, True, True)
    sira_yaz("   (B) ziyaret sırası:", sira)
    print(f"   (B) yığına ekleme = {itme} (V = {g.V}), atlanan = {atlanan}; "
          f"özyinelemeliyle aynı sıra mı: {evet(sira == ozy.sira)}")
    sira, itme, atlanan = dfs_itmeli(g, 0, False, False)
    sira_yaz("   (C) artan sırada itilirse:", sira)
    print("   (C) özyinelemeliyle aynı sıra mı: "
          + evet(sira == ozy.sira, "hayır")
          + " (en son itilen en BÜYÜK komşu önce çıkar)")


def yonlu_rapor(g, ozy):
    """Yönlü graf: (A) ile DFS ormanı; zamanlar ve kenar sınıfları"""
    a = Dfs(g.V)
    sayi = [0, 0, 0, 0]
    for r in range(g.V):
        if a.renk[r] == BEYAZ:
            dfs_cerceve(g, r, a, False)
    for t in a.tur:
        sayi[t] += 1
    sira_yaz("   (A) ziyaret sırası:", a.sira)
    print("   (A) keşif/bitiş:" + "".join(
        f" {u}:{a.kesif[u]}/{a.bitis[u]}" for u in range(g.V)))
    print(f"   (A) özyinelemeliyle aynı mı: sıra {evet(a.sira == ozy.sira)}, "
          f"keşif {evet(a.kesif == ozy.kesif)}, "
          f"bitiş {evet(a.bitis == ozy.bitis)}, "
          f"kenar sınıfları {evet(a.tur == ozy.tur)}")
    print(f"   kenar sınıfları: ağaç {sayi[AGAC]}, geri {sayi[GERI]}, "
          f"ileri {sayi[ILERI]}, çapraz {sayi[CAPRAZ]}")


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H11_06_dfs_acik_yigin GRAF [GRAF2 ...]",
              file=sys.stderr)
        return 2
    for i in range(1, len(sys.argv)):
        g = graf_yukle(sys.argv[i])
        if g is None:
            return 1
        ozy = Dfs(g.V)
        for r in range(g.V):
            if ozy.renk[r] == BEYAZ:
                ozy_ziyaret(g, r, ozy)  # kâhin
        print(f"{i}) {taban_ad(sys.argv[i])} ("
              + ("yönlü" if g.yonlu else "yönsüz")
              + f", V = {g.V}, E = {g.E})")
        sira_yaz("   özyinelemeli DFS (kâhin) sırası:", ozy.sira)
        if g.yonlu:
            yonlu_rapor(g, ozy)
        else:
            yonsuz_rapor(g, ozy)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok (yığın elle, H9); C++ — yok (std::stack
# yalnız yığın; Boost.Graph depth_first_search); Python — yok (list
# yığın olarak; networkx.dfs_preorder_nodes yalnız doğrulama için).

/* H11_07_bagli_bilesenler.cpp — AP-2 Hafta 11 · Örnek 7 (★★)
 * Amaç    : Bağlı bileşenler: her etiketsiz köşeden (artan sırada) bir
 *           BFS; bileşen sayısı ve etiketleri; bileşen başına köşe/kenar
 *           sayısı ve yönsüz grafta döngü (kenar >= köşe <=> ağaç değil);
 *           "aynı bileşende mi?" sorusu etiket karşılaştırmasıyla O(1)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_07_bagli_bilesenler.cpp -o H11_07_bagli_bilesenler
 * Çalıştır: ./H11_07_bagli_bilesenler ../girdiler/graf_bilesen.txt \
 *           ../girdiler/graf_ornek.txt
 * Eşleri  : c/H11_07_bagli_bilesenler.c ·
 *           python/H11_07_bagli_bilesenler.py
 * Çıktı   : üç dilde aynı (=); yalnız yönsüz graflar içindir
 */
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <string>
#include <utility>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

struct Sayac {
    long ekleme = 0, inceleme = 0;   // kuyruğa ekleme, incelenen komşu
    int bfs_sayisi = 0;
};

// s'nin bileşenini BFS ile 'no' etiketiyle işaretler; bileşenin köşeleri
// BFS sırasıyla döner. ilk_dongu: ağaç dışı ilk kenar (yoksa -1, -1).
static std::vector<int> bileseni_etiketle(const Graf& g, int s, int no,
                                          std::vector<int>& etiket,
                                          std::vector<int>& ebeveyn,
                                          std::pair<int, int>& ilk_dongu,
                                          Sayac& say)
{
    std::queue<int> q;
    std::vector<int> uyeler;
    etiket[s] = no;
    ebeveyn[s] = -1;
    q.push(s);
    say.ekleme++;
    say.bfs_sayisi++;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        uyeler.push_back(u);
        for (int v : g.komsu[u]) {
            say.inceleme++;
            if (etiket[v] == -1) {
                etiket[v] = no;
                ebeveyn[v] = u;
                q.push(v);
                say.ekleme++;
            } else if (v != ebeveyn[u] && ilk_dongu.first == -1) {
                ilk_dongu = {u, v};      // ağaç dışı kenar: döngü
            }
        }
    }
    return uyeler;
}

static void rapor(const std::string& ad, const Graf& g)
{
    std::vector<int> etiket(g.V, -1), ebeveyn(g.V, -1);
    std::vector<int> kose;               // bileşen başına köşe sayısı
    std::vector<std::pair<int, int>> dongu;
    Sayac say;
    std::cout << ad << " (yönsüz, V = " << g.V << ", E = " << g.E << ")\n";
    for (int s = 0; s < g.V; s++) {
        if (etiket[s] != -1) {
            continue;                    // zaten bir bileşende
        }
        int k = static_cast<int>(kose.size());
        dongu.push_back({-1, -1});
        std::vector<int> uyeler =
            bileseni_etiketle(g, s, k, etiket, ebeveyn, dongu.back(), say);
        std::cout << "   BFS(" << s << "): bileşen " << k << " = {";
        for (std::size_t i = 0; i < uyeler.size(); i++) {
            std::cout << (i ? " " : "") << uyeler[i];
        }
        std::cout << "}\n";
        kose.push_back(static_cast<int>(uyeler.size()));
    }
    int k = static_cast<int>(kose.size());
    std::vector<long> kenar(k, 0);
    for (int u = 0; u < g.V; u++) {
        kenar[etiket[u]] += static_cast<long>(g.komsu[u].size());
    }
    std::cout << "   bileşen sayısı = " << k << "\n   etiketler: köşe   ";
    for (int v = 0; v < g.V; v++) {
        std::cout << ' ' << v;
    }
    std::cout << "\n              bileşen";
    for (int v = 0; v < g.V; v++) {
        std::cout << ' ' << etiket[v];
    }
    std::cout << "\n   bileşen  köşe  kenar  ağaç dışı  döngü\n";
    for (int c = 0; c < k; c++) {
        long e = kenar[c] / 2;           // her kenar iki listede
        std::cout << "   " << std::setw(7) << c << "  " << std::setw(4)
                  << kose[c] << "  " << std::setw(5) << e << "  "
                  << std::setw(9) << e - kose[c] + 1 << "  ";
        if (e >= kose[c]) {
            std::cout << "var (ör. kenar " << dongu[c].first << '-'
                      << dongu[c].second << ")\n";
        } else {
            std::cout << "yok (" << (kose[c] == 1 ? "yalnız köşe" : "ağaç")
                      << ")\n";
        }
    }
    std::cout << "   sayaçlar: BFS çağrısı = " << say.bfs_sayisi
              << ", kuyruğa ekleme = " << say.ekleme
              << " (= V), kenar inceleme = " << say.inceleme << " (= 2E)\n";
    const int a[2][2] = {{0, g.V - 2}, {1, g.V - 1}};
    std::cout << "   aynı bileşende mi (etiket karşılaştırması, O(1)):";
    for (int i = 0; i < 2; i++) {
        int x = a[i][0], y = a[i][1];
        std::cout << ' ' << x << " ve " << y << ": "
                  << (etiket[x] == etiket[y] ? "evet" : "hayır")
                  << (i ? "\n" : ";");
    }
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cerr << "Kullanım: H11_07_bagli_bilesenler GRAF [GRAF2 ...]\n";
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (!graf_yukle(argv[i], g)) {
            return 1;
        }
        if (g.yonlu || g.V < 2) {
            std::cerr << taban_ad(argv[i])
                      << ": yönsüz ve V >= 2 bir graf gerekir\n";
            return 1;
        }
        std::cout << i << ") ";
        rapor(taban_ad(argv[i]), g);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * connected_components); Python — yok (networkx.connected_components
 * yalnız doğrulama için). Birleşim–bul (H12) ikinci bir yoldur. */

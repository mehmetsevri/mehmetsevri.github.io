/* H11_13_ortak_yazarlik.cpp — AP-2 Hafta 11 · Örnek 13 (★★★)
 * Amaç    : KURGUSAL bir ortak yazarlık ağında "kaç adım uzakta?" (Erdős
 *           sayısı benzeri "Erdem sayısı"): ad -> köşe eşlemesi sıralı
 *           dizi + ikili arama (H4) ile; makaledeki her yazar çifti kenar;
 *           BFS uzaklıkları, ulaşılamayanlar (∞) ve en uzak yazarlara yol.
 *           2. bölüm: ortak LCG ile üretilen yapay ağda uzaklık dağılımı.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_13_ortak_yazarlik.cpp -o H11_13_ortak_yazarlik
 * Çalıştır: ./H11_13_ortak_yazarlik ../girdiler/ortak_yazarlik.txt [N M]
 *           (N yazar, M makale; varsayılan 2000 3000)
 * Eşleri  : c/H11_13_ortak_yazarlik.c ·
 *           python/H11_13_ortak_yazarlik.py
 * Çıktı   : üç dilde aynı (=); adlar uydurmadır (girdi dosyasına bakınız)
 */
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <queue>
#include <sstream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const std::string MERKEZ = "Erdem";

using Komsu = std::vector<std::vector<int>>;

static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// Sıralı ad içinde x'in indisi; yoksa -1. sayac: karşılaştırma
static int ikili_ara(const std::vector<std::string>& ad, const std::string& x,
                     long& sayac)
{
    int lo = 0, hi = static_cast<int>(ad.size()) - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        int k = ad[mid].compare(x);      // bayt sırası (unsigned char)
        sayac++;
        if (k == 0) {
            return mid;
        }
        if (k < 0) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

// Komşu listelerini sıralar ve yinelenenleri atar (aynı çift birden çok
// makalede). Dönüş: atılan liste öğesi sayısı.
static long listeleri_duzenle(Komsu& komsu)
{
    long atilan = 0;
    for (std::vector<int>& liste : komsu) {
        std::sort(liste.begin(), liste.end());
        std::size_t k = 0;
        for (std::size_t i = 0; i < liste.size(); i++) {
            if (k == 0 || liste[i] != liste[k - 1]) {
                liste[k++] = liste[i];
            }
        }
        atilan += static_cast<long>(liste.size() - k);
        liste.resize(k);
    }
    return atilan;
}

// BFS: uzak (ulaşılamayan -1) ve ebeveyn; dönüş: ulaşılan köşe sayısı
static int bfs(const Komsu& komsu, int s, std::vector<int>& uzak,
               std::vector<int>& ebeveyn, long& inceleme)
{
    std::queue<int> q;
    int ulasilan = 0;
    uzak.assign(komsu.size(), -1);
    ebeveyn.assign(komsu.size(), -1);
    uzak[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        ulasilan++;
        for (int v : komsu[u]) {
            inceleme++;
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                ebeveyn[v] = u;
                q.push(v);
            }
        }
    }
    return ulasilan;
}

// Makaledeki yazarlar (köşe numaraları) arasında her çifte kenar
static void makale_ekle(Komsu& komsu, const std::vector<int>& yazar)
{
    for (std::size_t i = 0; i < yazar.size(); i++) {
        for (std::size_t j = i + 1; j < yazar.size(); j++) {
            komsu[yazar[i]].push_back(yazar[j]);
            komsu[yazar[j]].push_back(yazar[i]);
        }
    }
}

// Her satır bir makale (adlar boşlukla ayrılır); '#' satırı yorum
static bool makaleleri_oku(const std::string& yol,
                           std::vector<std::vector<std::string>>& makale)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir, p;
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (std::getline(f, satir)) {
        std::istringstream ss(satir);    // boşluklarda böler
        std::vector<std::string> yazar;
        while (ss >> p) {
            yazar.push_back(p);
        }
        if (!yazar.empty() && yazar[0][0] != '#') {
            makale.push_back(yazar);
        }
    }
    return true;
}

// En uzak köşelere yolları ebeveyn zincirinden geri çıkarıp yazar
static void uzak_yollari_yaz(const std::vector<std::string>& ad,
                             const std::vector<int>& uzak,
                             const std::vector<int>& ebeveyn, int en)
{
    std::cout << "   en uzaktakiler (" << en << " adım):\n";
    for (std::size_t v = 0; v < ad.size(); v++) {
        if (uzak[v] != en) {
            continue;
        }
        std::vector<int> yol;
        for (int x = static_cast<int>(v); x != -1; x = ebeveyn[x]) {
            yol.push_back(x);
        }
        std::cout << "     " << ad[v] << ':';
        for (int i = static_cast<int>(yol.size()) - 1; i >= 0; i--) {
            std::cout << ' ' << ad[yol[i]] << (i ? " ->" : "\n");
        }
    }
}

// Uzaklığa göre gruplar: 0, 1, ..., en ve ∞ (ulaşılamayan)
static void gruplari_yaz(const std::vector<std::string>& ad,
                         const std::vector<int>& uzak, int en)
{
    std::cout << "   " << MERKEZ << " sayısı (" << MERKEZ
              << "'den BFS; komşular ad sırasıyla):\n";
    for (int d = 0; d <= en + 1; d++) {
        int hedef = d <= en ? d : -1;
        bool ilk = true;
        for (std::size_t v = 0; v < ad.size(); v++) {
            if (uzak[v] == hedef) {
                if (ilk) {
                    std::cout << "     " << (d <= en ? std::to_string(d)
                                                     : std::string("∞"))
                              << ':';
                    ilk = false;
                }
                std::cout << ' ' << ad[v];
            }
        }
        if (!ilk) {
            std::cout << (d <= en ? "" : " (zincir yok)") << '\n';
        }
    }
}

// 1. bölüm: kurgusal ağ. ad -> köşe eşlemesi, graf, BFS
static bool kurgusal_ag(const std::string& yol)
{
    std::vector<std::vector<std::string>> makale;
    if (!makaleleri_oku(yol, makale)) {
        return false;
    }
    std::vector<std::string> ad;         // bütün adlar, dosya sırasıyla
    for (const auto& m : makale) {
        ad.insert(ad.end(), m.begin(), m.end());
    }
    std::size_t n_tum = ad.size();
    std::sort(ad.begin(), ad.end());
    ad.erase(std::unique(ad.begin(), ad.end()), ad.end());   // yinelenen
    int V = static_cast<int>(ad.size());
    long karsilastirma = 0, merkez_arama = 0, inceleme = 0, liste = 0;
    std::vector<std::vector<int>> indeks;
    for (const auto& m : makale) {
        std::vector<int> yazar;
        for (const std::string& a : m) {
            yazar.push_back(ikili_ara(ad, a, karsilastirma));
        }
        indeks.push_back(yazar);
    }
    int s = ikili_ara(ad, MERKEZ, merkez_arama);   // eşleme sayacı dışı
    if (s < 0) {
        std::cerr << taban_ad(yol) << ": ağda " << MERKEZ << " yok\n";
        return false;
    }
    std::cout << "1) " << taban_ad(yol) << ": " << makale.size()
              << " makale, " << n_tum << " yazar adı (yinelemeli), " << V
              << " farklı yazar\n";
    std::cout << "   ad -> köşe: sıralı dizi + ikili arama (H4); " << n_tum
              << " aramada " << karsilastirma
              << " karşılaştırma\n   köşeler:";
    for (int v = 0; v < V; v++) {
        std::cout << ' ' << v << '=' << ad[v];
    }
    std::cout << '\n';
    Komsu komsu(V);
    for (const auto& yazar : indeks) {
        makale_ekle(komsu, yazar);
    }
    long atilan = listeleri_duzenle(komsu);
    for (const auto& l : komsu) {
        liste += static_cast<long>(l.size());
    }
    std::vector<int> uzak, ebeveyn;
    int ulasilan = bfs(komsu, s, uzak, ebeveyn, inceleme);
    int en = 0;
    for (int d : uzak) {
        en = std::max(en, d);
    }
    std::cout << "   kenar (ortak yazar çifti) = " << liste / 2
              << "; yinelenen çift atıldı: " << atilan / 2
              << " kez (aynı ikili birden çok makalede)\n";
    gruplari_yaz(ad, uzak, en);
    uzak_yollari_yaz(ad, uzak, ebeveyn, en);
    std::cout << "   sayaçlar: ulaşılan = " << ulasilan << " / " << V
              << ", kenar inceleme = " << inceleme
              << " (ulaşılan köşelerin dereceleri toplamı)\n";
    return true;
}

// İki ondalıklı yuvarlanmış oran: pay / payda (tamsayı aritmetiği)
static std::string oran(long pay, long payda)
{
    long yuz = (100 * pay + payda / 2) / payda;
    char tampon[32];
    std::snprintf(tampon, sizeof tampon, "%ld.%02ld", yuz / 100, yuz % 100);
    return tampon;
}

// 2. bölüm: ortak LCG ile N yazarlı, M makaleli yapay ağ. Makale başına
// 2..4 yazar; makalelerin yaklaşık %10'unun ilk yazarı merkez (0).
static void yapay_ag(int N, int M)
{
    Komsu komsu(N);
    rastgele_tohum(2026);
    for (int m = 0; m < M; m++) {
        int k = rastgele_aralik(2, 4);
        std::vector<int> yazar;
        yazar.push_back(rastgele_aralik(0, 9) == 0 ? 0
                        : rastgele_aralik(0, N - 1));
        while (static_cast<int>(yazar.size()) < k) {
            int a = rastgele_aralik(0, N - 1);
            if (std::find(yazar.begin(), yazar.end(), a) == yazar.end()) {
                yazar.push_back(a);  // aynı makalede yinelenen yazar yok
            }
        }
        makale_ekle(komsu, yazar);
    }
    long liste = 0, inceleme = 0, toplam = 0;
    listeleri_duzenle(komsu);
    for (const auto& l : komsu) {
        liste += static_cast<long>(l.size());
    }
    std::vector<int> uzak, ebeveyn;
    int ulasilan = bfs(komsu, 0, uzak, ebeveyn, inceleme);
    int en = 0;
    std::vector<long> dagilim(N + 1, 0);
    for (int d : uzak) {
        if (d >= 0) {
            dagilim[d]++;
            toplam += d;
            en = std::max(en, d);
        }
    }
    std::cout << "2) Yapay ağ (ortak LCG, tohum 2026): N = " << N
              << " yazar, M = " << M << " makale (2-4 yazar)\n";
    std::cout << "   kenar = " << liste / 2 << ", merkezin (0) derecesi = "
              << komsu[0].size() << ", ortalama derece = " << oran(liste, N)
              << '\n';
    std::cout << "   merkezden uzaklık dağılımı:";
    for (int d = 0; d <= en; d++) {
        std::cout << ' ' << d << ':' << dagilim[d];
    }
    std::cout << " ∞:" << N - ulasilan << '\n';
    std::cout << "   ulaşılan = " << ulasilan << " / " << N
              << ", ortalama uzaklık = " << oran(toplam, ulasilan)
              << ", en büyük = " << en << '\n';
}

int main(int argc, char *argv[])
{
    long N = 2000, M = 3000;
    if (argc < 2 || argc == 3 || argc > 4) {
        std::cerr << "Kullanım: H11_13_ortak_yazarlik AG_DOSYASI [N M]\n";
        return 2;
    }
    if (argc == 4) {
        try {
            std::size_t s1, s2;
            N = std::stol(argv[2], &s1);
            M = std::stol(argv[3], &s2);
            if (argv[2][s1] != '\0' || argv[3][s2] != '\0') {
                N = -1;
            }
        } catch (const std::exception&) {
            N = -1;
        }
        if (N < 5 || N > 1000000 || M < 1 || M > 5000000) {
            std::cerr << "N 5..1000000, M 1..5000000 olmalı\n";
            return 2;
        }
    }
    if (!kurgusal_ag(argv[1])) {
        return 1;
    }
    yapay_ag(static_cast<int>(N), static_cast<int>(M));
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; ikili arama için bsearch); C++ —
 * yok (std::lower_bound, std::unordered_map ad -> köşe); Python — yok
 * (bisect, dict; networkx.shortest_path_length yalnız doğrulama için). */

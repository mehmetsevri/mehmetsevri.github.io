/* H11_08_iki_parcali.cpp — AP-2 Hafta 11 · Örnek 8 (★★)
 * Amaç    : İki parçalılık sınaması: BFS ile 2-renklendirme (komşunun
 *           rengi = 1 - renk). Aynı renkli iki komşu ÇELİŞKİDİR: graf iki
 *           parçalı değildir ve BFS ağacından tek uzunluklu bir döngü
 *           çıkarılır (iki ucun ortak atası üzerinden)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_08_iki_parcali.cpp -o H11_08_iki_parcali
 * Çalıştır: ./H11_08_iki_parcali ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_tek_dongu.txt
 * Eşleri  : c/H11_08_iki_parcali.c · python/H11_08_iki_parcali.py
 * Çıktı   : üç dilde aynı (=); yönsüz graf; kökler ve komşular artan sırada
 */
#include <algorithm>
#include <fstream>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

struct Boyama {
    std::vector<int> renk, uzak, ebeveyn;    // renk -1: boyanmadı
    int cu = -1, cv = -1;                    // çelişkili kenar

    explicit Boyama(int V) : renk(V, -1), uzak(V, 0), ebeveyn(V, -1) {}
};

// s'nin bileşenini BFS ile boyar; her adımı yazar. Çelişkide durur:
// b.cu, b.cv kenarı kaydedilir, false döner.
static bool bfs_boya(const Graf& g, int s, Boyama& b)
{
    std::queue<int> q;
    b.renk[s] = 0;
    b.uzak[s] = 0;
    b.ebeveyn[s] = -1;
    q.push(s);
    std::cout << "   kök " << s << " -> renk 0\n";
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        std::cout << "   çıkan " << u << " (renk " << b.renk[u] << "):";
        for (std::size_t i = 0; i < g.komsu[u].size(); i++) {
            int v = g.komsu[u][i];
            if (b.renk[v] == -1) {
                b.renk[v] = 1 - b.renk[u];        // karşı renk
                b.uzak[v] = b.uzak[u] + 1;
                b.ebeveyn[v] = u;
                q.push(v);
                std::cout << ' ' << v << " -> " << b.renk[v];
            } else if (b.renk[v] == b.renk[u]) {
                std::cout << ' ' << v << " ÇELİŞKİ\n";
                b.cu = u;
                b.cv = v;
                return false;
            } else {
                std::cout << ' ' << v << " uygun";
            }
            std::cout << (i + 1 < g.komsu[u].size() ? "," : "");
        }
        std::cout << '\n';
    }
    return true;
}

// Çelişkili (u, v) kenarı ve BFS ağacından tek döngü: u -> .. -> ata
// -> .. -> v (-> u). Uçların derinlikleri aynı paritededir (aynı renk),
// bu yüzden döngünün uzunluğu (iki yol + 1 kenar) tektir.
static void tek_dongu_yaz(const Boyama& b)
{
    std::vector<int> ya{b.cu}, yb{b.cv};
    int a = b.cu, c = b.cv;
    while (b.uzak[a] > b.uzak[c]) {
        a = b.ebeveyn[a];
        ya.push_back(a);
    }
    while (b.uzak[c] > b.uzak[a]) {
        c = b.ebeveyn[c];
        yb.push_back(c);
    }
    while (a != c) {                     // ortak ataya birlikte çık
        a = b.ebeveyn[a];
        c = b.ebeveyn[c];
        ya.push_back(a);
        yb.push_back(c);
    }
    std::cout << "   tek uzunluklu döngü:";
    for (int x : ya) {
        std::cout << ' ' << x << " ->";  // u .. ata
    }
    for (int i = static_cast<int>(yb.size()) - 2; i >= 0; i--) {
        std::cout << ' ' << yb[i] << " ->";   // ata'nın altından v'ye
    }
    int na = static_cast<int>(ya.size()), nb = static_cast<int>(yb.size());
    std::cout << ' ' << b.cu << " (uzunluk " << na + nb - 1 << " = "
              << na - 1 << " + " << nb - 1 << " + 1; ortak ata " << a
              << ")\n";
}

static void rapor(const std::string& ad, const Graf& g)
{
    Boyama b(g.V);
    bool iki_parcali = true;
    std::cout << ad << " (yönsüz, V = " << g.V << ", E = " << g.E << ")\n";
    for (int s = 0; s < g.V && iki_parcali; s++) {
        if (b.renk[s] == -1) {
            iki_parcali = bfs_boya(g, s, b);
        }
    }
    if (!iki_parcali) {
        std::cout << "   çelişki: kenar (" << b.cu << ", " << b.cv
                  << "), iki ucu da renk " << b.renk[b.cu] << '\n';
        tek_dongu_yaz(b);
        std::cout << "   iki parçalı: hayır (tek uzunluklu döngü içeren "
                     "graf 2 renkle boyanamaz)\n";
        return;
    }
    std::cout << "   renkler: köşe";
    for (int v = 0; v < g.V; v++) {
        std::cout << ' ' << v;
    }
    std::cout << "\n            renk";
    for (int r : b.renk) {
        std::cout << ' ' << r;
    }
    for (int r = 0; r < 2; r++) {
        std::cout << (r == 0 ? "\n   iki parçalı: evet; A = {" : "}, B = {");
        bool ilk = true;
        for (int v = 0; v < g.V; v++) {
            if (b.renk[v] == r) {
                std::cout << (ilk ? "" : " ") << v;
                ilk = false;
            }
        }
    }
    int kenar = 0;
    for (int u = 0; u < g.V; u++) {
        for (int v : g.komsu[u]) {
            kenar += b.renk[u] != b.renk[v];
        }
    }
    std::cout << "}\n   denetim: iki ucu farklı renkte olan kenar = "
              << kenar / 2 << " / " << g.E << '\n';
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cerr << "Kullanım: H11_08_iki_parcali GRAF [GRAF2 ...]\n";
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (!graf_yukle(argv[i], g)) {
            return 1;
        }
        if (g.yonlu) {
            std::cerr << taban_ad(argv[i]) << ": yönsüz bir graf gerekir\n";
            return 1;
        }
        std::cout << i << ") ";
        rapor(taban_ad(argv[i]), g);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * is_bipartite); Python — yok (networkx.is_bipartite yalnız doğrulama
 * için). */

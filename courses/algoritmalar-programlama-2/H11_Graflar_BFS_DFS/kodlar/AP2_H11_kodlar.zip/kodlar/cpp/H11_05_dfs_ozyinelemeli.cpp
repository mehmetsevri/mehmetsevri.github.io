/* H11_05_dfs_ozyinelemeli.cpp — AP-2 Hafta 11 · Örnek 5 (★★)
 * Amaç    : Özyinelemeli derinlik öncelikli arama (DFS): ziyaret sırası,
 *           keşif/bitiş zamanları, üç renk (beyaz/gri/siyah), parantez
 *           yapısı; yönsüzde ağaç ve geri kenarlar; yönlüde ağaç / geri /
 *           ileri / çapraz kenar sınıflaması (DFS ormanı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_05_dfs_ozyinelemeli.cpp -o H11_05_dfs_ozyinelemeli
 * Çalıştır: ./H11_05_dfs_ozyinelemeli ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_yonlu.txt
 * Eşleri  : c/H11_05_dfs_ozyinelemeli.c ·
 *           python/H11_05_dfs_ozyinelemeli.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

enum { BEYAZ, GRI, SIYAH };              // keşfedilmedi / yolda / bitti
enum { AGAC, GERI, ILERI, CAPRAZ };
static const char *const RENK_ADI[] = {"beyaz", "gri", "siyah"};
static const char *const SINIF_ADI[] = {"ağaç", "geri", "ileri", "çapraz"};

struct SinifliKenar {
    int u, v, tur, v_renk;               // v_renk: incelenirken v'nin rengi
};

struct Dfs {
    std::vector<int> renk, kesif, bitis, ebeveyn;
    std::vector<int> sira;               // ziyaret (keşif) sırası
    std::vector<int> olay;               // u: "(u", -1 - u: "u)"
    std::vector<SinifliKenar> kenar;     // sınıflanan kenarlar
    int zaman = 0, derinlik = 0, en_derin = 0;

    explicit Dfs(int V)
        : renk(V, BEYAZ), kesif(V, 0), bitis(V, 0), ebeveyn(V, -1) {}
};

static void kenar_kaydet(Dfs& d, int u, int v, int tur)
{
    d.kenar.push_back({u, v, tur, d.renk[v]});
}

// Özyinelemeli DFS: u gri olur, beyaz komşulara inilir, u siyah olur
static void dfs_ziyaret(const Graf& g, int u, Dfs& d)
{
    d.renk[u] = GRI;
    d.kesif[u] = ++d.zaman;
    d.sira.push_back(u);
    d.olay.push_back(u);
    d.en_derin = std::max(d.en_derin, ++d.derinlik);
    for (int v : g.komsu[u]) {
        if (d.renk[v] == BEYAZ) {
            kenar_kaydet(d, u, v, AGAC);
            d.ebeveyn[v] = u;
            dfs_ziyaret(g, v, d);
        } else if (g.yonlu) {
            kenar_kaydet(d, u, v, d.renk[v] == GRI ? GERI :
                         d.kesif[u] < d.kesif[v] ? ILERI : CAPRAZ);
        } else if (d.renk[v] == GRI && v != d.ebeveyn[u]) {
            kenar_kaydet(d, u, v, GERI);  // yönsüz: atasına kenar
        }
    }
    d.derinlik--;
    d.renk[u] = SIYAH;
    d.bitis[u] = ++d.zaman;
    d.olay.push_back(-1 - u);
}

static void tablo_yaz(const Graf& g, const Dfs& d)
{
    std::cout << "   ziyaret sırası (keşif):";
    for (int u : d.sira) {
        std::cout << ' ' << u;
    }
    std::cout << "\n   köşe  keşif  bitiş  ebeveyn\n";
    for (int u = 0; u < g.V; u++) {
        std::cout << "   " << std::setw(4) << u << "  " << std::setw(5)
                  << d.kesif[u] << "  " << std::setw(5) << d.bitis[u]
                  << "  " << std::setw(7) << d.ebeveyn[u] << '\n';
    }
    std::cout << "   parantez yapısı:";
    for (int x : d.olay) {
        if (x >= 0) {
            std::cout << " (" << x;
        } else {
            std::cout << ' ' << -1 - x << ')';
        }
    }
    std::cout << '\n';
}

// DFS ormanı: her beyaz köşeden (artan sırada) yeni bir ağaç. Kökleri
// yazar; ağaç sayısını döndürür.
static int dfs_orman(const Graf& g, Dfs& d)
{
    int agac = 0;
    std::cout << "DFS ormanı, kökler artan sırada:";
    for (int r = 0; r < g.V; r++) {
        if (d.renk[r] == BEYAZ) {
            std::cout << ' ' << r;
            dfs_ziyaret(g, r, d);
            agac++;
        }
    }
    std::cout << '\n';
    return agac;
}

static void yonsuz_rapor(const Graf& g, Dfs& d)
{
    int agac = dfs_orman(g, d);
    tablo_yaz(g, d);
    for (int tur = AGAC; tur <= GERI; tur++) {
        int sayi = 0;
        for (const SinifliKenar& k : d.kenar) {
            sayi += k.tur == tur;
        }
        std::cout << "   " << SINIF_ADI[tur] << " kenarları (" << sayi
                  << " = " << (tur == AGAC ? "V -" : "E - V +") << ' '
                  << agac << "):";
        for (const SinifliKenar& k : d.kenar) {
            if (k.tur == tur) {
                std::cout << ' ' << k.u << '-' << k.v;
            }
        }
        std::cout << '\n';
    }
    std::cout << "   (yönsüz DFS'de ileri ve çapraz kenar olmaz; siyah "
                 "komşuya giden kenar zaten geri kenar olarak sayıldı)\n";
    std::cout << "   en büyük özyineleme derinliği = " << d.en_derin << '\n';
}

static void yonlu_rapor(const Graf& g, Dfs& d)
{
    int sayi[4] = {0, 0, 0, 0};
    dfs_orman(g, d);
    tablo_yaz(g, d);
    std::cout << "   kenarlar (incelenme sırasıyla):\n";
    for (std::size_t i = 0; i < d.kenar.size(); i++) {
        const SinifliKenar& k = d.kenar[i];
        sayi[k.tur]++;
        std::cout << "   " << std::setw(2) << i + 1 << ") " << k.u << "->"
                  << k.v << ": v " << RENK_ADI[k.v_renk];
        if (k.v_renk == SIYAH) {
            std::cout << ", keşif[" << k.u << "] = " << d.kesif[k.u] << ' '
                      << (d.kesif[k.u] < d.kesif[k.v] ? '<' : '>')
                      << " keşif[" << k.v << "] = " << d.kesif[k.v];
        }
        std::cout << " -> " << SINIF_ADI[k.tur] << '\n';
    }
    std::cout << "   sayılar: ağaç " << sayi[AGAC] << ", geri " << sayi[GERI]
              << ", ileri " << sayi[ILERI] << ", çapraz " << sayi[CAPRAZ]
              << " (toplam " << d.kenar.size() << " = E)\n";
    const char *var = sayi[GERI] > 0 ? "var" : "yok";
    std::cout << "   geri kenar " << var << ": yönlü döngü " << var
              << " (bkz. Örnek 12)\n";
    std::cout << "   en büyük özyineleme derinliği = " << d.en_derin << '\n';
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cerr << "Kullanım: H11_05_dfs_ozyinelemeli GRAF [GRAF2 ...]\n";
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (!graf_yukle(argv[i], g)) {
            return 1;
        }
        Dfs d(g.V);
        std::cout << i << ") " << taban_ad(argv[i]) << " ("
                  << (g.yonlu ? "yönlü" : "yönsüz") << ", V = " << g.V
                  << ", E = " << g.E << "): ";
        if (g.yonlu) {
            yonlu_rapor(g, d);
        } else {
            yonsuz_rapor(g, d);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * depth_first_search + ziyaretçi olayları tree_edge/back_edge/
 * forward_or_cross_edge); Python — yok (networkx.dfs_preorder_nodes,
 * dfs_labeled_edges yalnız doğrulama için). */

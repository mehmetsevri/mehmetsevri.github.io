/* H11_02_komsuluk_listesi.cpp — AP-2 Hafta 11 · Örnek 2 (★★)
 * Amaç    : Dosyadan kenar listesi okuma (ortak graf biçimi, denetimli);
 *           komşuluk listesi = dinamik dizilerden (H8) oluşan dizi; ekleme
 *           sırası ve artan sıra; liste ↔ matris ↔ kenar listesi dönüşümü;
 *           biçim hatası iletileri (üç dilde aynı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_02_komsuluk_listesi.cpp -o H11_02_komsuluk_listesi
 * Çalıştır: ./H11_02_komsuluk_listesi GRAF [GRAF2 ...]
 *           (ilk dosya ayrıntılı; sonrakiler özet ya da hata iletisi)
 * Eşleri  : c/H11_02_komsuluk_listesi.c ·
 *           python/H11_02_komsuluk_listesi.py
 * Çıktı   : üç dilde aynı (=); ilk dosyada biçim hatası: çıkış kodu 1
 */
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

struct Kenar {
    int u, v, w;
};

struct KenarListesi {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<Kenar> kenar;   // E kenar, dosyadaki sırayla
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Dönüş: boş dizgi = başarı; değilse hata iletisi
static std::string graf_dosyasi_oku(const std::string& yol,
                                    KenarListesi& kl)
{
    const std::string ad = taban_ad(yol);
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    long V = 0, E = 0, x[3] = {0, 0, 0};
    int no = 0;
    bool baslik = false;
    kl.kenar.clear();
    if (!f) {
        return ad + ": dosya açılamadı";
    }
    while (std::getline(f, satir)) {
        no++;
        const std::string yer = ad + ": satır " + std::to_string(no) + ": ";
        if (satir.size() >= SATIR_UZ - 1) {
            return yer + "satır çok uzun";
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (!baslik) {
            if (n < 2 || n > 3 || !tamsayi_coz(bel[0], V) ||
                !tamsayi_coz(bel[1], E)) {
                return yer + "başlık \"V E [yonlu|yonsuz]\" bekleniyor";
            } else if (V < 1 || V > MAKS_KOSE) {
                return yer + "V = " + std::to_string(V) + " geçersiz (1.." +
                       std::to_string(MAKS_KOSE) + ")";
            } else if (E < 0 || E > MAKS_KENAR) {
                return yer + "E = " + std::to_string(E) + " geçersiz (0.." +
                       std::to_string(MAKS_KENAR) + ")";
            } else if (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz") {
                return yer + "tür \"" + bel[2] +
                       "\" tanınmıyor (yonlu ya da yonsuz)";
            }
            kl.V = static_cast<int>(V);
            kl.E = static_cast<int>(E);
            kl.yonlu = n == 3 && bel[2] == "yonlu";
            kl.kenar.reserve(static_cast<std::size_t>(E));
            baslik = true;
            continue;
        }
        if (static_cast<long>(kl.kenar.size()) == E) {
            return yer + "fazladan kenar (başlıkta E = " +
                   std::to_string(E) + ")";
        } else if (n < 2 || n > 3 || !tamsayi_coz(bel[0], x[0]) ||
                   !tamsayi_coz(bel[1], x[1]) ||
                   (n == 3 && !tamsayi_coz(bel[2], x[2]))) {
            return yer + "kenar \"u v [w]\" bekleniyor";
        } else if (x[0] < 0 || x[0] >= V || x[1] < 0 || x[1] >= V) {
            long kotu = (x[0] < 0 || x[0] >= V) ? x[0] : x[1];
            return yer + "köşe " + std::to_string(kotu) +
                   " aralık dışı (0.." + std::to_string(V - 1) + ")";
        }
        kl.kenar.push_back({static_cast<int>(x[0]), static_cast<int>(x[1]),
                            n == 3 ? static_cast<int>(x[2]) : 1});
    }
    if (!baslik) {
        return ad + ": dosya boş (başlık yok)";
    }
    if (static_cast<long>(kl.kenar.size()) < E) {
        return ad + ": kenar eksik: E = " + std::to_string(E) +
               ", okunan " + std::to_string(kl.kenar.size());
    }
    return "";
}

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Kenarlar dosya sırasıyla eklenir (yönsüzde iki yöne)
static Graf graf_kur(const KenarListesi& kl)
{
    Graf g;
    g.V = kl.V;
    g.E = kl.E;
    g.yonlu = kl.yonlu;
    g.komsu.assign(g.V, std::vector<int>());
    for (const Kenar& k : kl.kenar) {
        g.komsu[k.u].push_back(k.v);
        if (!g.yonlu) {
            g.komsu[k.v].push_back(k.u);
        }
    }
    return g;
}

// Komşu listeleri artan köşe numarasına (belirli sıra)
static void graf_sirala(Graf& g)
{
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
}

static void listeleri_yaz(const Graf& g)
{
    for (int u = 0; u < g.V; u++) {
        std::cout << "    " << u << ':';
        for (int v : g.komsu[u]) {
            std::cout << ' ' << v;
        }
        std::cout << '\n';
    }
}

// V × V matris (satır satır tek vektörde)
static std::vector<unsigned char> listeden_matris(const Graf& g)
{
    std::vector<unsigned char> m(static_cast<std::size_t>(g.V) * g.V, 0);
    for (int u = 0; u < g.V; u++) {
        for (int v : g.komsu[u]) {
            m[static_cast<std::size_t>(u) * g.V + v] = 1;
        }
    }
    return m;
}

// Matristen kenar listesi (yönsüzde u < v); kenarları yazdırır
static KenarListesi matristen_kenarlar(const std::vector<unsigned char>& m,
                                       int V, bool yonlu, int E_ust)
{
    KenarListesi kl;
    kl.V = V;
    kl.yonlu = yonlu;
    for (int u = 0; u < V; u++) {
        for (int v = yonlu ? 0 : u + 1; v < V; v++) {
            if (m[static_cast<std::size_t>(u) * V + v] &&
                static_cast<int>(kl.kenar.size()) < E_ust) {
                std::cout << " (" << u << ',' << v << ')';
                kl.kenar.push_back({u, v, 1});
            }
        }
    }
    kl.E = static_cast<int>(kl.kenar.size());
    return kl;
}

// 4) liste -> matris -> kenar listesi -> liste
static void donusumler(const Graf& g)
{
    int V = g.V;
    std::vector<unsigned char> m = listeden_matris(g);
    std::cout << "4) Dönüşümler\n   liste -> matris (satır u: "
                 "matris[u][0..V-1]):\n";
    for (int u = 0; u < V; u++) {
        std::cout << "    " << u << ": ";
        for (int v = 0; v < V; v++) {
            std::cout << static_cast<int>(m[static_cast<std::size_t>(u) * V
                                            + v]);
        }
        std::cout << '\n';
    }
    std::cout << "   matris -> kenar listesi ("
              << (g.yonlu ? "u -> v" : "u < v") << "):";
    KenarListesi kl2 = matristen_kenarlar(m, V, g.yonlu, g.E);
    std::cout << "\n   kenar sayısı = " << kl2.E << " (E = " << g.E << ")\n";
    Graf g2 = graf_kur(kl2);
    graf_sirala(g2);
    bool ayni = g2.komsu == g.komsu;    // vektörlerin == karşılaştırması
    std::cout << "   kenar listesi -> liste: 3) ile aynı mı: "
              << (ayni ? "evet" : "HAYIR") << '\n';
}

static int ayrintili(const std::string& yol)
{
    KenarListesi kl;
    std::string hata = graf_dosyasi_oku(yol, kl);
    if (!hata.empty()) {
        std::cerr << hata << '\n';
        return 1;
    }
    Graf g = graf_kur(kl);
    std::cout << "1) Dosya: " << taban_ad(yol) << " -> V = " << kl.V
              << ", E = " << kl.E << ", " << (kl.yonlu ? "yönlü" : "yönsüz")
              << "\n   kenar listesi (dosya sırası):";
    for (const Kenar& k : kl.kenar) {
        std::cout << " (" << k.u << ',' << k.v << ')';
    }
    std::cout << "\n2) Komşuluk listesi: dinamik dizilerden oluşan dizi "
                 "(ekleme sırası)\n";
    listeleri_yaz(g);
    graf_sirala(g);
    std::cout << "3) Listeler artan sıraya dizildi (dolaşma bu sırayla):\n";
    listeleri_yaz(g);
    long toplam = 0;
    for (const std::vector<int>& liste : g.komsu) {
        toplam += static_cast<long>(liste.size());
    }
    std::cout << "   toplam liste öğesi = " << toplam << " = "
              << (g.yonlu ? "E (yönlü)" : "2E (yönsüz: her kenar iki listede)")
              << '\n';
    donusumler(g);
    std::cout << "   öğe sayısı: matris V² = "
              << static_cast<long>(g.V) * g.V << " hücre; liste V + "
              << (g.yonlu ? "E" : "2E") << " = " << g.V + toplam
              << "; kenar listesi 2E = " << 2 * g.E << " sayı\n";
    return 0;
}

static void ozet(const std::string& yol)
{
    KenarListesi kl;
    std::string hata = graf_dosyasi_oku(yol, kl);
    if (!hata.empty()) {
        std::cout << "   " << hata << '\n';
        return;
    }
    Graf g = graf_kur(kl);
    graf_sirala(g);
    std::cout << "   " << taban_ad(yol) << ": V = " << kl.V << ", E = "
              << kl.E << ", " << (kl.yonlu ? "yönlü" : "yönsüz")
              << "; sıralı listeler:\n";
    listeleri_yaz(g);
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cerr << "Kullanım: H11_02_komsuluk_listesi GRAF [GRAF2 ...]\n";
        return 2;
    }
    if (ayrintili(argv[1]) != 0) {
        return 1;
    }
    if (argc > 2) {
        std::cout << "5) Öteki dosyalar (okuyucunun iletisi üç dilde "
                     "aynıdır):\n";
    }
    for (int i = 2; i < argc; i++) {
        ozet(argv[i]);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (dinamik dizilerden oluşan dizi elle;
 * eşdeğeri int ** + boyut dizisi); C++ — std::vector<std::vector<int>>;
 * Python — liste listesi (ya da dict); hazır graf türü yalnız Boost.Graph
 * ve networkx'te (doğrulama için). */

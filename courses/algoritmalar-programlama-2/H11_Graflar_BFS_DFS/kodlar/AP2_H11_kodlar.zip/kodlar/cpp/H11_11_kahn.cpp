/* H11_11_kahn.cpp — AP-2 Hafta 11 · Örnek 11 (★★★)
 * Amaç    : Topolojik sıralama, Kahn algoritması: giriş dereceleri; giriş
 *           derecesi 0 olan köşelerden EN KÜÇÜK numaralısı seçilir (en
 *           küçük öbek, H7); "en erken dönem" katmanları; döngü varsa
 *           sıralanan < V: raporlanır. Karşılaştırma: FIFO kuyrukla Kahn
 *           ve geçerli sıraların sayısı (birden çok doğru yanıt vardır)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_11_kahn.cpp -o H11_11_kahn
 * Çalıştır: ./H11_11_kahn ../girdiler/dersler_dag.txt \
 *           ../girdiler/dersler_dongulu.txt
 * Eşleri  : c/H11_11_kahn.c · python/H11_11_kahn.py
 * Çıktı   : üç dilde aynı (=); yalnız yönlü graflar içindir
 */
#include <algorithm>
#include <fstream>
#include <functional>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

// En küçük öbek (H7): std::priority_queue + std::greater
using Obek = std::priority_queue<int, std::vector<int>, std::greater<int>>;

// Öbek içeriğini küçükten büyüğe yazar (kopyadan çıkararak)
static void obek_yaz(Obek h)
{
    std::cout << '[';
    for (bool ilk = true; !h.empty(); h.pop(), ilk = false) {
        std::cout << (ilk ? "" : " ") << h.top();
    }
    std::cout << ']';
}

// Kahn: fifo = false ise en küçük öbek, true ise FIFO kuyruk (giriş
// derecesi 0 olanlar artan sırada eklenir). Dönüş: sıra (boyutu < V ise
// döngü var); donem[v] = v'nin en erken dönemi; derece sonunda kalan
// giriş dereceleri. iz: adımları yazdır.
static std::vector<int> kahn(const Graf& g, bool fifo, bool iz,
                             std::vector<int>& donem,
                             std::vector<int>& derece)
{
    Obek h;
    std::queue<int> q;
    std::vector<int> sira;
    derece.assign(g.V, 0);
    donem.assign(g.V, 1);
    for (int u = 0; u < g.V; u++) {
        for (int v : g.komsu[u]) {
            derece[v]++;
        }
    }
    if (iz) {
        std::cout << "   giriş dereceleri:";
        for (int v = 0; v < g.V; v++) {
            std::cout << ' ' << v << ':' << derece[v];
        }
        std::cout << '\n';
    }
    for (int v = 0; v < g.V; v++) {
        if (derece[v] == 0) {
            if (fifo) {
                q.push(v);
            } else {
                h.push(v);
            }
        }
    }
    if (iz) {
        std::cout << "   başlangıç öbeği (giriş derecesi 0): ";
        obek_yaz(h);
        std::cout << '\n';
    }
    while (fifo ? !q.empty() : !h.empty()) {
        int u;
        if (fifo) {
            u = q.front();
            q.pop();
        } else {
            u = h.top();
            h.pop();
        }
        sira.push_back(u);
        if (iz) {
            std::cout << "   adım " << sira.size() << ": çıkan " << u
                      << " (dönem " << donem[u] << ");";
        }
        for (std::size_t i = 0; i < g.komsu[u].size(); i++) {
            int v = g.komsu[u][i];
            donem[v] = std::max(donem[v], donem[u] + 1);  // en uzun zincir
            derece[v]--;
            if (iz) {
                std::cout << (i ? "," : "") << ' ' << v << ": "
                          << derece[v] + 1 << "->" << derece[v]
                          << (derece[v] == 0 ? " (öbeğe)" : "");
            }
            if (derece[v] == 0) {
                if (fifo) {
                    q.push(v);
                } else {
                    h.push(v);
                }
            }
        }
        if (iz) {
            std::cout << (g.komsu[u].empty() ? "" : ";") << " öbek: ";
            obek_yaz(h);
            std::cout << '\n';
        }
    }
    return sira;
}

// Kâhin: her kenar u -> v için konum[u] < konum[v] mi?
static bool gecerli_mi(const Graf& g, const std::vector<int>& sira)
{
    if (static_cast<int>(sira.size()) != g.V) {
        return false;
    }
    std::vector<int> konum(g.V);
    for (int i = 0; i < g.V; i++) {
        konum[sira[i]] = i;
    }
    for (int u = 0; u < g.V; u++) {
        for (int v : g.komsu[u]) {
            if (konum[u] >= konum[v]) {
                return false;
            }
        }
    }
    return true;
}

// Bütün geçerli topolojik sıraları sayar (H3 geri izleme): her adımda
// giriş derecesi 0 olan, kullanılmamış her köşe denenir.
static long sira_say(const Graf& g, std::vector<int>& derece,
                     std::vector<char>& kullanildi, int kalan)
{
    long toplam = 0;
    if (kalan == 0) {
        return 1;
    }
    for (int u = 0; u < g.V; u++) {
        if (!kullanildi[u] && derece[u] == 0) {
            kullanildi[u] = 1;                         // seç
            for (int v : g.komsu[u]) {
                derece[v]--;
            }
            toplam += sira_say(g, derece, kullanildi, kalan - 1);
            for (int v : g.komsu[u]) {
                derece[v]++;                           // geri al
            }
            kullanildi[u] = 0;
        }
    }
    return toplam;
}

static void dizi_yaz(const char *baslik, const std::vector<int>& a)
{
    std::cout << baslik;
    for (int x : a) {
        std::cout << ' ' << x;
    }
}

static void rapor(const Graf& g)
{
    std::vector<int> donem, derece;
    std::vector<int> sira = kahn(g, false, true, donem, derece);
    int n = static_cast<int>(sira.size());
    if (n < g.V) {
        dizi_yaz("   sıralanan köşeler:", sira);
        std::cout << " (" << n << " / " << g.V
                  << ")\n   sıralanamayan (giriş derecesi > 0 kaldı):";
        for (int v = 0; v < g.V; v++) {
            if (derece[v] > 0) {
                std::cout << ' ' << v << ':' << derece[v];
            }
        }
        std::cout << "\n   SONUÇ: döngü var — geçerli bir sıra (ders planı) "
                     "yok; döngüdeki ya da döngüye bağlı köşeler hiç 0'a "
                     "inmez\n";
        return;
    }
    dizi_yaz("   topolojik sıra (en küçük öbek):", sira);
    std::cout << "\n   kâhin: her kenar u->v için konum[u] < konum[v]: "
              << (gecerli_mi(g, sira) ? "evet" : "HAYIR") << " (" << g.E
              << " kenar)\n   en erken dönem:";
    int en_son = 1;
    for (int v = 0; v < g.V; v++) {
        std::cout << ' ' << v << ':' << donem[v];
        en_son = std::max(en_son, donem[v]);
    }
    std::cout << "\n  ";
    for (int d = 1; d <= en_son; d++) {
        std::cout << " dönem " << d << ':';
        for (int v : sira) {
            if (donem[v] == d) {
                std::cout << ' ' << v;
            }
        }
        std::cout << (d < en_son ? ";" : "\n");
    }
    std::vector<int> donem2, derece2;
    std::vector<int> sira2 = kahn(g, true, false, donem2, derece2);
    dizi_yaz("   FIFO kuyrukla Kahn:", sira2);
    std::cout << " (geçerli: " << (gecerli_mi(g, sira2) ? "evet" : "HAYIR")
              << "; en küçük öbek sırasından "
              << (sira != sira2 ? "farklı" : "farksız") << ")\n";
    std::vector<int> derece3(g.V, 0);
    std::vector<char> kullanildi(g.V, 0);
    for (int u = 0; u < g.V; u++) {
        for (int v : g.komsu[u]) {
            derece3[v]++;
        }
    }
    std::cout << "   geçerli topolojik sıra sayısı (geri izlemeyle, H3): "
              << sira_say(g, derece3, kullanildi, g.V) << '\n';
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cerr << "Kullanım: H11_11_kahn GRAF [GRAF2 ...]\n";
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (!graf_yukle(argv[i], g)) {
            return 1;
        }
        if (!g.yonlu) {
            std::cerr << taban_ad(argv[i]) << ": yönlü bir graf gerekir\n";
            return 1;
        }
        std::cout << i << ") " << taban_ad(argv[i]) << " (yönlü, V = "
                  << g.V << ", E = " << g.E << "): Kahn, en küçük öbekle\n";
        rapor(g);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * topological_sort, DFS tabanlı); Python — graphlib.TopologicalSorter
 * (3.9+, standart kütüphane; yalnız kâhin) ve networkx.topological_sort
 * (doğrulama için). */

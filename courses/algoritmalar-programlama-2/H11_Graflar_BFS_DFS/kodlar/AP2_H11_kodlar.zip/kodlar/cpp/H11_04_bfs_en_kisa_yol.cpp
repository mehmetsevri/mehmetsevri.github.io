/* H11_04_bfs_en_kisa_yol.cpp — AP-2 Hafta 11 · Örnek 4 (★★)
 * Amaç    : BFS ile ağırlıksız en kısa yol: uzaklık (kenar sayısı) ve
 *           ebeveyn dizileri; yolun ebeveyn dizisinden GERİ ÇIKARILMASI;
 *           ulaşılamayan köşe sözleşmesi: uzaklık = -1, ebeveyn = -1;
 *           kenar koşuluyla doğrulama (|d[u] - d[v]| <= 1)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_04_bfs_en_kisa_yol.cpp -o H11_04_bfs_en_kisa_yol
 * Çalıştır: ./H11_04_bfs_en_kisa_yol ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_bilesen.txt
 * Eşleri  : c/H11_04_bfs_en_kisa_yol.c ·
 *           python/H11_04_bfs_en_kisa_yol.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

// BFS(s): uzak[v] = en az kenar sayısı, ebeveyn[v] = BFS ağacında v'yi
// keşfeden köşe; ulaşılamayan v için ikisi de -1. Dönüş: ulaşılan sayısı.
static int bfs_uzaklik(const Graf& g, int s, std::vector<int>& uzak,
                       std::vector<int>& ebeveyn)
{
    std::queue<int> q;
    int ulasilan = 0;
    uzak.assign(g.V, -1);
    ebeveyn.assign(g.V, -1);
    uzak[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        ulasilan++;
        for (int v : g.komsu[u]) {
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                ebeveyn[v] = u;          // v'ye ilk u'dan ulaşıldı
                q.push(v);
            }
        }
    }
    return ulasilan;
}

// s'den t'ye yolu ebeveyn zincirinden geri çıkarır: yol = s .. t.
// Yol yoksa boş vektör.
static std::vector<int> yol_cikar(const std::vector<int>& ebeveyn, int s,
                                  int t)
{
    std::vector<int> yol;
    if (t != s && ebeveyn[t] == -1) {
        return yol;                      // ulaşılamaz
    }
    for (int v = t; v != -1; v = ebeveyn[v]) {
        yol.push_back(v);                // t, ebeveyn[t], ..., s
    }
    std::reverse(yol.begin(), yol.end());   // s .. t
    return yol;
}

// Kâhin: ulaşılan her u'nun her komşusu v de ulaşılmıştır ve
// d[v] <= d[u] + 1 (yönsüzde iki yönden: |d[u] - d[v]| <= 1); ulaşılan
// her v != s için d[v] = d[ebeveyn[v]] + 1.
static bool dogrula(const Graf& g, int s, const std::vector<int>& uzak,
                    const std::vector<int>& ebeveyn)
{
    for (int u = 0; u < g.V; u++) {
        for (int v : g.komsu[u]) {
            if (uzak[u] != -1 && (uzak[v] == -1 || uzak[v] > uzak[u] + 1)) {
                return false;
            }
        }
        if (u != s && uzak[u] != -1 && uzak[u] != uzak[ebeveyn[u]] + 1) {
            return false;
        }
    }
    return true;
}

static void rapor(const std::string& yol_adi, const Graf& g, int s)
{
    std::vector<int> uzak, ebeveyn;
    int ulasilan = bfs_uzaklik(g, s, uzak, ebeveyn);
    std::cout << yol_adi << " (V = " << g.V << ", E = " << g.E
              << "): kaynak " << s << '\n';
    std::cout << "   köşe  uzaklık  ebeveyn  en kısa yol\n";
    int en_uzak = s;
    for (int t = 0; t < g.V; t++) {
        std::vector<int> yol = yol_cikar(ebeveyn, s, t);
        std::cout << "   " << std::setw(4) << t << "  " << std::setw(7)
                  << uzak[t] << "  " << std::setw(7) << ebeveyn[t] << "  ";
        if (yol.empty()) {
            std::cout << "ulaşılamaz (yol yok)\n";
            continue;
        }
        for (std::size_t i = 0; i < yol.size(); i++) {
            std::cout << (i == 0 ? "" : " -> ") << yol[i];
        }
        std::cout << '\n';
        if (uzak[t] > uzak[en_uzak]) {
            en_uzak = t;
        }
    }
    std::cout << "   ulaşılan = " << ulasilan << " / " << g.V
              << "; en uzak köşe " << en_uzak << " (" << uzak[en_uzak]
              << " kenar)\n";
    std::cout << "   kâhin (kenar koşulu + ebeveyn tutarlılığı): "
              << (dogrula(g, s, uzak, ebeveyn) ? "geçti" : "KALDI") << '\n';
}

int main(int argc, char *argv[])
{
    Graf g;
    if (argc < 2) {
        std::cerr << "Kullanım: H11_04_bfs_en_kisa_yol GRAF [GRAF2 ...]\n";
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        if (!graf_yukle(argv[i], g)) {
            return 1;
        }
        std::cout << i << ") ";
        rapor(taban_ad(argv[i]), g, 0);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * breadth_first_search + predecessor ziyaretçisi); Python — yok
 * (networkx.single_source_shortest_path yalnız doğrulama için). */

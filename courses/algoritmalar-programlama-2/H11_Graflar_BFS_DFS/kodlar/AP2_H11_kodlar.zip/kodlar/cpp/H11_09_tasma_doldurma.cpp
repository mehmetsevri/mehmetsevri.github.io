/* H11_09_tasma_doldurma.cpp — AP-2 Hafta 11 · Örnek 9 (★★)
 * Amaç    : Örtük graf: ızgaranın her hücresi bir köşe, komşu hücreler
 *           kenar (kenarlar saklanmaz, hesaplanır). Taşkın doldurma (BFS
 *           dalgası) ve ada sayma; 4 ve 8 komşuluk (AP-1 H11 di/dj
 *           dizileri). Sınır denetimi komşuya ERİŞMEDEN ÖNCE yapılır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_09_tasma_doldurma.cpp -o H11_09_tasma_doldurma
 * Çalıştır: ./H11_09_tasma_doldurma < ../girdiler/H11_09_tasma_doldurma.txt
 *           (ilk satır "S Y r0 c0", sonra S satır: '#' kara, '.' su)
 * Eşleri  : c/H11_09_tasma_doldurma.c ·
 *           python/H11_09_tasma_doldurma.py
 * Çıktı   : üç dilde aynı (=); yön sırası yukarı, aşağı, sol, sağ; hata: kod 1
 */
#include <iostream>
#include <queue>
#include <sstream>
#include <string>
#include <vector>

const int MAKS = 100;

// İlk 4: yukarı, aşağı, sol, sağ (4-komşuluk); son 4: çaprazlar
static const int di[8] = {-1, 1, 0, 0, -1, -1, 1, 1};
static const int dj[8] = {0, 0, -1, 1, -1, 1, -1, 1};

static int S, Y;                       // satır ve sütun sayısı
static long deneme = 0, sinir_disi = 0;

// (i, j) ızgarada mı? Hücreye erişmeden ÖNCE çağrılır.
static bool icinde(int i, int j)
{
    return i >= 0 && i < S && j >= 0 && j < Y;
}

// (i0, j0)'dan başlayıp 'eski' karakterli hücreleri 'yeni' yapar (BFS).
// yon: 4 ya da 8. Dönüş: değiştirilen hücreler (BFS sırasıyla). katman
// boş değilse her hücrenin dalga numarası yazılır.
static std::vector<int> doldur(std::string& iz, int i0, int j0, char eski,
                               char yeni, int yon, std::vector<int>* katman)
{
    std::queue<int> q;
    std::vector<int> sira;
    iz[i0 * Y + j0] = yeni;               // işaret kuyruğa EKLERKEN
    q.push(i0 * Y + j0);
    if (katman != nullptr) {
        (*katman)[i0 * Y + j0] = 0;
    }
    while (!q.empty()) {
        int h = q.front(), i = h / Y, j = h % Y;
        q.pop();
        sira.push_back(h);
        for (int k = 0; k < yon; k++) {
            int ni = i + di[k], nj = j + dj[k];
            deneme++;
            if (!icinde(ni, nj)) {
                sinir_disi++;              // erişilmeden reddedildi
                continue;
            }
            if (iz[ni * Y + nj] == eski) {
                iz[ni * Y + nj] = yeni;
                q.push(ni * Y + nj);
                if (katman != nullptr) {
                    (*katman)[ni * Y + nj] = (*katman)[h] + 1;
                }
            }
        }
    }
    return sira;
}

static void izgara_yaz(const std::string& iz)
{
    for (int i = 0; i < S; i++) {
        std::cout << "   " << iz.substr(static_cast<std::size_t>(i) * Y, Y)
                  << '\n';
    }
}

// Adaları (kara '#') yon-komşulukla A, B, C, ... harfleriyle boyar.
// etiket[h] = ada numarası (karada) ya da -1. Dönüş: ada boyutları.
static std::vector<int> adalari_say(const std::string& harita,
                                    std::string& iz, int yon,
                                    std::vector<int>& etiket)
{
    std::vector<int> boyut;
    iz = harita;
    etiket.assign(harita.size(), -1);
    for (int h = 0; h < S * Y; h++) {
        if (iz[h] != '#') {
            continue;
        }
        int ada = static_cast<int>(boyut.size());
        char harf = ada < 26 ? static_cast<char>('A' + ada) : '*';
        std::vector<int> hucre = doldur(iz, h / Y, h % Y, '#', harf, yon,
                                        nullptr);
        for (int x : hucre) {
            etiket[x] = ada;
        }
        boyut.push_back(static_cast<int>(hucre.size()));
    }
    return boyut;
}

static void boyut_yaz(const std::vector<int>& boyut)
{
    std::cout << "   boyutlar:";
    for (std::size_t a = 0; a < boyut.size(); a++) {
        std::cout << ' ' << (a < 26 ? static_cast<char>('A' + a) : '*')
                  << '=' << boyut[a];
    }
    std::cout << '\n';
}

// İlk satır "S Y r0 c0", sonra S satır; yalnız '#' ve '.'
static bool izgara_oku(std::string& harita, int& r0, int& c0)
{
    std::string satir;
    long x[4];
    if (!std::getline(std::cin, satir)) {
        return false;
    }
    std::istringstream ss(satir);
    for (long& v : x) {
        if (!(ss >> v)) {
            return false;
        }
    }
    if (x[0] < 1 || x[0] > MAKS || x[1] < 1 || x[1] > MAKS || x[2] < 0 ||
        x[2] >= x[0] || x[3] < 0 || x[3] >= x[1]) {
        return false;
    }
    S = static_cast<int>(x[0]);
    Y = static_cast<int>(x[1]);
    r0 = static_cast<int>(x[2]);
    c0 = static_cast<int>(x[3]);
    harita.clear();
    for (int i = 0; i < S; i++) {
        if (!std::getline(std::cin, satir)) {
            return false;
        }
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (static_cast<int>(satir.size()) != Y ||
            satir.find_first_not_of("#.") != std::string::npos) {
            return false;
        }
        harita += satir;
    }
    return true;
}

int main()
{
    std::string harita, iz;
    int r0, c0;
    if (!izgara_oku(harita, r0, c0)) {
        std::cerr << "Hatalı ızgara girdisi\n";
        return 1;
    }
    std::cout << "Izgara " << S << " x " << Y
              << " ('#' kara, '.' su); taşkın başlangıcı (" << r0 << ", "
              << c0 << ")\n";
    iz = harita;
    if (iz[r0 * Y + c0] != '.') {
        std::cout << "1) Başlangıç hücresi su değil: doldurma yapılmadı\n";
    } else {
        std::vector<int> katman(harita.size(), 0);
        std::vector<int> dolan = doldur(iz, r0, c0, '.', '~', 4, &katman);
        int kalan = 0;
        for (char k : iz) {
            kalan += k == '.';
        }
        int en_uzak = katman[dolan.back()];
        std::cout << "1) Taşkın doldurma (BFS, 4-komşuluk): (" << r0 << ", "
                  << c0 << ")'dan ulaşılan su '~'\n";
        izgara_yaz(iz);
        std::cout << "   doldurulan hücre = " << dolan.size()
                  << ", dalga sayısı = " << en_uzak + 1
                  << " (en uzak hücre " << en_uzak << " adımda)\n";
        std::cout << "   komşu denemesi = " << deneme << ", sınır dışı = "
                  << sinir_disi << " (komşuya ERİŞMEDEN reddedildi)\n";
        std::cout << "   doldurulmayan su hücresi = " << kalan
                  << " (çevresi kara: göl)\n";
        std::cout << "   dalga numaraları (mod 10; '#' kara, '.' "
                     "ulaşılmayan):\n";
        for (int i = 0; i < S; i++) {
            std::cout << "   ";
            for (int j = 0; j < Y; j++) {
                char k = iz[i * Y + j];
                std::cout << (k == '~' ? static_cast<char>(
                                  '0' + katman[i * Y + j] % 10) : k);
            }
            std::cout << '\n';
        }
    }
    std::vector<int> etiket4, etiket8;
    std::vector<int> boyut4 = adalari_say(harita, iz, 4, etiket4);
    std::cout << "2) Ada sayma, 4-komşuluk (yalnız dik yönler): "
              << boyut4.size() << " ada\n";
    izgara_yaz(iz);
    boyut_yaz(boyut4);
    std::vector<int> boyut8 = adalari_say(harita, iz, 8, etiket8);
    std::cout << "3) Ada sayma, 8-komşuluk (çaprazlar da): " << boyut8.size()
              << " ada\n";
    izgara_yaz(iz);
    boyut_yaz(boyut8);
    std::cout << "   8-komşulukta birleşenler (4-komşuluk adaları):";
    int birlesme = 0;
    for (int b = 0; b < static_cast<int>(boyut8.size()); b++) {
        std::vector<int> uyeler;
        for (int a = 0; a < static_cast<int>(boyut4.size()) && a < 26; a++) {
            for (std::size_t h = 0; h < harita.size(); h++) {
                if (etiket4[h] == a) {        // adanın ilk hücresi
                    if (etiket8[h] == b) {
                        uyeler.push_back(a);
                    }
                    break;
                }
            }
        }
        if (uyeler.size() > 1) {
            std::cout << (birlesme++ ? ";" : "");
            for (std::size_t k = 0; k < uyeler.size(); k++) {
                std::cout << (k ? "+" : " ")
                          << static_cast<char>('A' + uyeler[k]);
            }
            std::cout << " -> " << (b < 26 ? static_cast<char>('A' + b) : '*');
        }
    }
    std::cout << (birlesme ? "" : " yok") << '\n';
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok; Python — yok
 * (scipy.ndimage.label ve OpenCV floodFill/connectedComponents görüntü
 * işlemede aynı işi yapar; ders dışı). */

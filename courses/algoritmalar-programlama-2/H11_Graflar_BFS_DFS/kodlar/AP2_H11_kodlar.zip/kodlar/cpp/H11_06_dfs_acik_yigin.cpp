/* H11_06_dfs_acik_yigin.cpp — AP-2 Hafta 11 · Örnek 6 (★★)
 * Amaç    : Özyinelemesiz DFS (açık yığın). Özyinelemeli sürümle AYNI
 *           sırayı vermenin iki yolu: (A) yığında (köşe, sıradaki komşu
 *           indisi) çerçeveleri — keşif/bitiş ve kenar sınıfları da aynı;
 *           (B) komşular TERS sırada itilir, işaret ÇIKARIRKEN konur —
 *           ziyaret sırası aynı, yığına fazladan öğe girer. (C) artan
 *           sırada itmek başka bir sıra verir. Kâhin: özyinelemeli DFS.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_06_dfs_acik_yigin.cpp -o H11_06_dfs_acik_yigin
 * Çalıştır: ./H11_06_dfs_acik_yigin ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_yonlu.txt
 * Eşleri  : c/H11_06_dfs_acik_yigin.c · python/H11_06_dfs_acik_yigin.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <algorithm>
#include <cstddef>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

enum { BEYAZ, GRI, SIYAH };
enum { AGAC, GERI, ILERI, CAPRAZ };

struct Dfs {
    std::vector<int> renk, kesif, bitis;
    std::vector<int> sira;               // ziyaret (keşif) sırası
    std::vector<int> tur;                // yönlüde kenar sınıfları
    int zaman = 0;

    explicit Dfs(int V) : renk(V, BEYAZ), kesif(V, 0), bitis(V, 0) {}
};

struct Cerceve {
    int u;                               // köşe
    std::size_t i;                       // sıradaki komşunun indisi
};

// (u, v) kenarının sınıfı; v'nin rengi değişmeden ÖNCE çağrılır
static int sinif(const Dfs& d, int u, int v)
{
    if (d.renk[v] == BEYAZ) {
        return AGAC;
    }
    if (d.renk[v] == GRI) {
        return GERI;
    }
    return d.kesif[u] < d.kesif[v] ? ILERI : CAPRAZ;
}

static void kesfet(Dfs& d, int u)
{
    d.renk[u] = GRI;
    d.kesif[u] = ++d.zaman;
    d.sira.push_back(u);
}

// Kâhin: Örnek 5'teki özyinelemeli DFS
static void ozy_ziyaret(const Graf& g, int u, Dfs& d)
{
    kesfet(d, u);
    for (int v : g.komsu[u]) {
        if (g.yonlu) {
            d.tur.push_back(sinif(d, u, v));
        }
        if (d.renk[v] == BEYAZ) {
            ozy_ziyaret(g, v, d);
        }
    }
    d.renk[u] = SIYAH;
    d.bitis[u] = ++d.zaman;
}

static void cerceve_yaz(const std::vector<Cerceve>& y)
{
    std::cout << "yığın: [";
    for (std::size_t k = 0; k < y.size(); k++) {
        std::cout << (k ? " " : "") << y[k].u << ':' << y[k].i;
    }
    std::cout << "]\n";
}

// (A) Çerçeve yığını: tepedeki (u, i) çerçevesi u'nun i. komşusuyla
// sürer; komşu kalmayınca u biter ve çerçeve çıkarılır. Özyinelemeli
// çağrının yerel değişkenleri (u, i) burada açıkça saklanır.
static void dfs_cerceve(const Graf& g, int kok, Dfs& d, bool iz)
{
    std::vector<Cerceve> y;              // std::vector yığın olarak
    kesfet(d, kok);
    y.push_back({kok, 0});
    if (iz) {
        std::cout << "   it " << kok << "          ";
        cerceve_yaz(y);
    }
    while (!y.empty()) {
        Cerceve& c = y.back();
        if (c.i < g.komsu[c.u].size()) {
            int v = g.komsu[c.u][c.i++];
            if (g.yonlu) {
                d.tur.push_back(sinif(d, c.u, v));
            }
            if (d.renk[v] == BEYAZ) {
                kesfet(d, v);
                y.push_back({v, 0});     // c bundan sonra geçersiz olabilir
                if (iz) {
                    std::cout << "   it " << v << "          ";
                    cerceve_yaz(y);
                }
            }
        } else {
            int u = c.u;
            d.renk[u] = SIYAH;
            d.bitis[u] = ++d.zaman;
            y.pop_back();
            if (iz) {
                std::cout << "   çıkar " << u << " ("
                          << (d.bitis[u] < 10 ? " " : "") << d.bitis[u]
                          << ")  ";
                cerceve_yaz(y);
            }
        }
    }
}

static void yigin_yaz(const std::vector<int>& y)
{
    std::cout << "yığın: [";
    for (std::size_t k = 0; k < y.size(); k++) {
        std::cout << (k ? " " : "") << y[k];
    }
    std::cout << "]\n";
}

// (B) ters ve (C) artan sırada itme: işaret ÇIKARIRKEN konur, zaten
// ziyaret edilmiş öğe atlanır. Bir köşe yığına birden çok kez girebilir.
static std::vector<int> dfs_itmeli(const Graf& g, int kok, bool ters,
                                   long& itme, long& atlanan, bool iz)
{
    std::vector<int> y, sira;
    std::vector<char> ziyaret(g.V, 0);
    itme = 1;
    atlanan = 0;
    y.push_back(kok);
    while (!y.empty()) {
        int u = y.back();
        y.pop_back();
        if (ziyaret[u]) {
            atlanan++;
            if (iz) {
                std::cout << "   çıkar " << u
                          << ": zaten ziyaretli, atla;  ";
                yigin_yaz(y);
            }
            continue;
        }
        ziyaret[u] = 1;
        sira.push_back(u);
        if (iz) {
            std::cout << "   çıkar " << u << ": ziyaret (" << sira.size()
                      << ".), it:";
        }
        std::size_t k = g.komsu[u].size();
        int itilen = 0;
        for (std::size_t j = 0; j < k; j++) {
            int v = g.komsu[u][ters ? k - 1 - j : j];
            if (!ziyaret[v]) {
                y.push_back(v);
                itme++;
                itilen++;
                if (iz) {
                    std::cout << ' ' << v;
                }
            }
        }
        if (iz) {
            std::cout << (itilen ? "" : " -") << ";  ";
            yigin_yaz(y);
        }
    }
    return sira;
}

static void sira_yaz(const char *baslik, const std::vector<int>& a)
{
    std::cout << baslik;
    for (int x : a) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';
}

static const char *evet(bool b, const char *hayir = "HAYIR")
{
    return b ? "evet" : hayir;
}

// Yönsüz graf: (A), (B), (C) izleri ve özyinelemeliyle karşılaştırma
static void yonsuz_rapor(const Graf& g, const Dfs& ozy)
{
    Dfs a(g.V);
    long itme, atlanan;
    std::cout << "   (A) çerçeve yığını, u:i = köşe:sıradaki komşu indisi; "
                 "çıkarken (bitiş zamanı)\n";
    dfs_cerceve(g, 0, a, true);
    sira_yaz("   (A) ziyaret sırası:", a.sira);
    std::cout << "   (A) özyinelemeliyle aynı mı: sıra "
              << evet(a.sira == ozy.sira) << ", keşif "
              << evet(a.kesif == ozy.kesif) << ", bitiş "
              << evet(a.bitis == ozy.bitis) << '\n';
    std::cout << "   (B) komşular TERS sırada itilir, işaret çıkarırken:\n";
    std::vector<int> sira = dfs_itmeli(g, 0, true, itme, atlanan, true);
    sira_yaz("   (B) ziyaret sırası:", sira);
    std::cout << "   (B) yığına ekleme = " << itme << " (V = " << g.V
              << "), atlanan = " << atlanan
              << "; özyinelemeliyle aynı sıra mı: "
              << evet(sira == ozy.sira) << '\n';
    sira = dfs_itmeli(g, 0, false, itme, atlanan, false);
    sira_yaz("   (C) artan sırada itilirse:", sira);
    std::cout << "   (C) özyinelemeliyle aynı sıra mı: "
              << evet(sira == ozy.sira, "hayır")
              << " (en son itilen en BÜYÜK komşu önce çıkar)\n";
}

// Yönlü graf: (A) ile DFS ormanı; zamanlar ve kenar sınıfları
static void yonlu_rapor(const Graf& g, const Dfs& ozy)
{
    Dfs a(g.V);
    int sayi[4] = {0, 0, 0, 0};
    for (int r = 0; r < g.V; r++) {
        if (a.renk[r] == BEYAZ) {
            dfs_cerceve(g, r, a, false);
        }
    }
    for (int t : a.tur) {
        sayi[t]++;
    }
    sira_yaz("   (A) ziyaret sırası:", a.sira);
    std::cout << "   (A) keşif/bitiş:";
    for (int u = 0; u < g.V; u++) {
        std::cout << ' ' << u << ':' << a.kesif[u] << '/' << a.bitis[u];
    }
    std::cout << "\n   (A) özyinelemeliyle aynı mı: sıra "
              << evet(a.sira == ozy.sira) << ", keşif "
              << evet(a.kesif == ozy.kesif) << ", bitiş "
              << evet(a.bitis == ozy.bitis) << ", kenar sınıfları "
              << evet(a.tur == ozy.tur) << '\n';
    std::cout << "   kenar sınıfları: ağaç " << sayi[AGAC] << ", geri "
              << sayi[GERI] << ", ileri " << sayi[ILERI] << ", çapraz "
              << sayi[CAPRAZ] << '\n';
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cerr << "Kullanım: H11_06_dfs_acik_yigin GRAF [GRAF2 ...]\n";
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (!graf_yukle(argv[i], g)) {
            return 1;
        }
        Dfs ozy(g.V);
        for (int r = 0; r < g.V; r++) {
            if (ozy.renk[r] == BEYAZ) {
                ozy_ziyaret(g, r, ozy);  // kâhin
            }
        }
        std::cout << i << ") " << taban_ad(argv[i]) << " ("
                  << (g.yonlu ? "yönlü" : "yönsüz") << ", V = " << g.V
                  << ", E = " << g.E << ")\n";
        sira_yaz("   özyinelemeli DFS (kâhin) sırası:", ozy.sira);
        if (g.yonlu) {
            yonlu_rapor(g, ozy);
        } else {
            yonsuz_rapor(g, ozy);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (yığın elle, H9); C++ — yok (std::stack
 * yalnız yığın; Boost.Graph depth_first_search); Python — yok (list
 * yığın olarak; networkx.dfs_preorder_nodes yalnız doğrulama için). */

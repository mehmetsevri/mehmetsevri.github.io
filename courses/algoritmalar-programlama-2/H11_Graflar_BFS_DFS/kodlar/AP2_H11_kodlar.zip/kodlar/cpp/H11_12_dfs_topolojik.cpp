/* H11_12_dfs_topolojik.cpp — AP-2 Hafta 11 · Örnek 12 (★★★)
 * Amaç    : DFS ile topolojik sıralama ve yönlü döngü tespiti (üç renk):
 *           köşe bitince (siyah) bitiş listesine eklenir; listenin TERSİ
 *           topolojik sıradır. Gri bir köşeye giden kenar (geri kenar)
 *           döngüdür: o anki gri yol (özyineleme yığını) döngüyü verir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_12_dfs_topolojik.cpp -o H11_12_dfs_topolojik
 * Çalıştır: ./H11_12_dfs_topolojik ../girdiler/dersler_dag.txt \
 *           ../girdiler/dersler_dongulu.txt
 * Eşleri  : c/H11_12_dfs_topolojik.c · python/H11_12_dfs_topolojik.py
 * Çıktı   : üç dilde aynı (=); yalnız yönlü graflar içindir
 */
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

enum { BEYAZ, GRI, SIYAH };              // keşfedilmedi / yolda / bitti

struct Topo {
    std::vector<int> renk, kesif, bitis;
    std::vector<int> bitis_sirasi;       // siyaha dönüş sırası
    std::vector<int> gri_yol;            // kökten şimdiki köşeye yol
    int zaman = 0, dongu_u = -1, dongu_v = -1;  // bulunan geri kenar

    explicit Topo(int V) : renk(V, BEYAZ), kesif(V, 0), bitis(V, 0) {}
};

// Üç renkli DFS. Olayları "(u" ve "u)" olarak yazar. Gri komşu = geri
// kenar = döngü: kenar kaydedilir, true döner ve bütün DFS durur.
static bool dfs_topo(const Graf& g, int u, Topo& t)
{
    t.renk[u] = GRI;
    t.kesif[u] = ++t.zaman;
    t.gri_yol.push_back(u);
    std::cout << " (" << u;
    for (int v : g.komsu[u]) {
        if (t.renk[v] == GRI) {
            t.dongu_u = u;               // geri kenar: döngü
            t.dongu_v = v;
            return true;
        }
        if (t.renk[v] == BEYAZ && dfs_topo(g, v, t)) {
            return true;
        }
    }
    t.gri_yol.pop_back();                // u gri yoldan çıkar
    t.renk[u] = SIYAH;
    t.bitis[u] = ++t.zaman;
    t.bitis_sirasi.push_back(u);         // bütün ardılları bitti
    std::cout << ' ' << u << ')';
    return false;
}

static void dizi_yaz(const char *baslik, const std::vector<int>& a)
{
    std::cout << baslik;
    for (int x : a) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';
}

static void rapor(const Graf& g)
{
    Topo t(g.V);
    bool dongu = false;
    std::cout << "   olaylar ('(u' gri oldu, 'u)' siyah oldu):";
    for (int r = 0; r < g.V && !dongu; r++) {
        if (t.renk[r] == BEYAZ) {
            dongu = dfs_topo(g, r, t);
        }
    }
    std::cout << '\n';
    if (dongu) {
        auto bas = std::find(t.gri_yol.begin(), t.gri_yol.end(), t.dongu_v);
        std::cout << "   " << t.dongu_u << "->" << t.dongu_v << " kenarında "
                  << t.dongu_v << " GRİ: geri kenar\n";
        dizi_yaz("   gri yol (özyineleme yığını) o anda:", t.gri_yol);
        std::cout << "   döngü:";
        for (auto it = bas; it != t.gri_yol.end(); ++it) {
            std::cout << ' ' << *it << " ->";
        }
        std::cout << ' ' << t.dongu_v << " (uzunluk "
                  << t.gri_yol.end() - bas << ")\n";
        std::cout << "   SONUÇ: döngü var — topolojik sıra yok; o ana dek "
                     "biten (siyah) köşeler:";
        for (int u : t.bitis_sirasi) {
            std::cout << ' ' << u;
        }
        std::cout << '\n';
        return;
    }
    dizi_yaz("   bitiş sırası (siyaha dönüş):", t.bitis_sirasi);
    std::vector<int> sira(t.bitis_sirasi.rbegin(), t.bitis_sirasi.rend());
    std::vector<int> konum(g.V);
    for (int i = 0; i < g.V; i++) {
        konum[sira[i]] = i;
    }
    dizi_yaz("   topolojik sıra (bitiş sırasının tersi):", sira);
    bool gecerli = true;
    for (int u = 0; u < g.V; u++) {
        for (int v : g.komsu[u]) {
            gecerli = gecerli && konum[u] < konum[v];
        }
    }
    std::cout << "   kâhin: her kenar u->v için konum[u] < konum[v]: "
              << (gecerli ? "evet" : "HAYIR") << " (" << g.E << " kenar)\n";
    std::cout << "   keşif/bitiş:";
    for (int u = 0; u < g.V; u++) {
        std::cout << ' ' << u << ':' << t.kesif[u] << '/' << t.bitis[u];
    }
    std::cout << "\n   neden doğru: u->v kenarında v ya beyazdır (u'dan önce "
                 "biter) ya siyahtır (zaten bitmiş); gri olamaz (döngü "
                 "olurdu). Her durumda bitiş[v] < bitiş[u].\n";
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cerr << "Kullanım: H11_12_dfs_topolojik GRAF [GRAF2 ...]\n";
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        Graf g;
        if (!graf_yukle(argv[i], g)) {
            return 1;
        }
        if (!g.yonlu) {
            std::cerr << taban_ad(argv[i]) << ": yönlü bir graf gerekir\n";
            return 1;
        }
        std::cout << i << ") " << taban_ad(argv[i]) << " (yönlü, V = "
                  << g.V << ", E = " << g.E
                  << "): DFS, üç renk, kökler artan sırada\n";
        rapor(g);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (Boost.Graph
 * topological_sort; döngüde not_a_dag istisnası); Python —
 * graphlib.TopologicalSorter (CycleError; yalnız kâhin) ve
 * networkx.topological_sort / find_cycle (doğrulama için). */

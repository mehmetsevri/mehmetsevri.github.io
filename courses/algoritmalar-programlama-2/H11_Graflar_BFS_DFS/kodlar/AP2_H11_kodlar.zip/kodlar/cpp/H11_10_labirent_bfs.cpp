/* H11_10_labirent_bfs.cpp — AP-2 Hafta 11 · Örnek 10 (★★★)
 * Amaç    : Labirentte en kısa yol: ızgara BFS (H3 ile aynı yön sırası:
 *           sağ, aşağı, sol, yukarı); ebeveyn dizisinden yol. AYNI
 *           labirentte H3 Örnek 11'in geri izleme çözümüyle karşılaştırma:
 *           bulunan yol uzunluğu ve ziyaret edilen hücre sayısı. Ek olarak
 *           açık bir odada geri izlemenin uzun yol bulduğu durum.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_10_labirent_bfs.cpp -o H11_10_labirent_bfs
 * Çalıştır: ./H11_10_labirent_bfs < ../girdiler/H11_10_labirent_bfs.txt
 *           (girdi, H3'ün H03_11_labirent.txt dosyasının aynısıdır)
 * Eşleri  : c/H11_10_labirent_bfs.c · python/H11_10_labirent_bfs.py
 * Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
 */
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

const int MAKS_SATIR = 40;
const int MAKS_SUTUN = 80;

struct Labirent {
    std::vector<std::string> h;          // satırlar
    int S = 0, Y = 0;                    // satır, sütun sayısı
    int sr = 0, sc = 0, er = 0, ec = 0;  // S ve E konumları
};

static const int DR[4] = {0, 1, 0, -1};  // sağ, aşağı, sol, yukarı
static const int DC[4] = {1, 0, -1, 0};

// Açık oda: geri izlemenin en kısa yolu kaçırdığı küçük örnek
static const std::vector<std::string> ODA = {
    "#########", "#S......#", "#.......#", "#E......#", "#########",
};

struct Sonuc {
    int uzunluk = -1;         // yoldaki adım (kenar) sayısı; yoksa -1
    long ziyaret = 0;         // BFS: kuyruktan çıkan; geri izleme: çağrı
    long eklenen = 0;         // BFS: kuyruğa eklenen
    long geri_donulen = 0;    // geri izleme: çıkmaz hücre
};

static bool acik_mi(const Labirent& L, int r, int c)
{
    return r >= 0 && r < L.S && c >= 0 && c < L.Y && L.h[r][c] != '#';
}

// Izgara BFS: S'den başlar, E kuyruktan çıkınca durur. Yol '*', işlenen
// öteki hücreler 'o', kuyrukta kalan (sınır) hücreler '+' ile
// işaretlenir (L değiştirilir). Kuyruk: dizi + baş indisi (sınırı
// sonradan yazdırabilmek için std::queue yerine).
static Sonuc bfs_labirent(Labirent& L)
{
    Sonuc s;
    int n = L.S * L.Y;
    std::vector<int> ebeveyn(n, -2), q;  // -2: görülmedi
    std::size_t bas = 0;
    int kaynak = L.sr * L.Y + L.sc, hedef = L.er * L.Y + L.ec;
    ebeveyn[kaynak] = -1;
    q.push_back(kaynak);
    while (bas < q.size()) {
        int h = q[bas++], r = h / L.Y, c = h % L.Y;
        if (h == hedef) {
            break;                       // E kuyruktan çıktı
        }
        for (int d = 0; d < 4; d++) {
            int yr = r + DR[d], yc = c + DC[d];
            if (acik_mi(L, yr, yc) && ebeveyn[yr * L.Y + yc] == -2) {
                ebeveyn[yr * L.Y + yc] = h;
                q.push_back(yr * L.Y + yc);
            }
        }
    }
    s.ziyaret = static_cast<long>(bas);
    s.eklenen = static_cast<long>(q.size());
    for (std::size_t i = 0; i < q.size(); i++) {    // işlenen ve sınır
        char& k = L.h[q[i] / L.Y][q[i] % L.Y];
        if (k == '.') {
            k = i < bas ? 'o' : '+';
        }
    }
    if (ebeveyn[hedef] != -2) {
        s.uzunluk = 0;
        for (int h = ebeveyn[hedef]; h != kaynak; h = ebeveyn[h]) {
            L.h[h / L.Y][h % L.Y] = '*'; // ebeveyn zinciri: yol
            s.uzunluk++;
        }
        s.uzunluk++;                     // son adım: E'ye giriş
    }
    return s;
}

// H3 Örnek 11'in geri izlemesi (aynı kod): (r, c)'den çıkışa yol ara
static bool yol_bul(Labirent& L, int r, int c, Sonuc& s)
{
    s.ziyaret++;
    if (L.h[r][c] == 'E') {
        return true;                     // çıkışa ulaşıldı
    }
    if (L.h[r][c] != 'S') {
        L.h[r][c] = '*';                 // seç: hücre yola eklenir
    }
    for (int d = 0; d < 4; d++) {
        int yr = r + DR[d], yc = c + DC[d];
        if (yr >= 0 && yr < L.S && yc >= 0 && yc < L.Y &&
            (L.h[yr][yc] == '.' || L.h[yr][yc] == 'E') &&
            yol_bul(L, yr, yc, s)) {
            return true;                 // yol bulundu: '*'lar kalır
        }
    }
    if (L.h[r][c] != 'S') {
        L.h[r][c] = 'x';                 // geri al: buradan çıkış yok
    }
    s.geri_donulen++;
    return false;
}

static Sonuc geri_izleme(Labirent& L)
{
    Sonuc s;
    if (yol_bul(L, L.sr, L.sc, s)) {
        s.uzunluk = 1;
        for (const std::string& satir : L.h) {
            for (char k : satir) {
                s.uzunluk += k == '*';
            }
        }
    }
    return s;
}

static void yaz(const Labirent& L)
{
    for (const std::string& satir : L.h) {
        std::cout << "   " << satir << '\n';
    }
}

// S ve E'yi bulur; tam bir S ve bir E yoksa false
static bool konumlari_bul(Labirent& L)
{
    int s_sayisi = 0, e_sayisi = 0;
    for (int r = 0; r < L.S; r++) {
        for (int c = 0; c < L.Y; c++) {
            char k = L.h[r][c];
            if (k == 'S') {
                s_sayisi++;
                L.sr = r;
                L.sc = c;
            } else if (k == 'E') {
                e_sayisi++;
                L.er = r;
                L.ec = c;
            } else if (k != '#' && k != '.') {
                return false;
            }
        }
    }
    return s_sayisi == 1 && e_sayisi == 1;
}

// H3 ile aynı girdi biçimi: ilk satır "satır sütun", ardından ızgara
static bool labirent_oku(Labirent& L)
{
    std::string satir;
    long r, c;
    if (!std::getline(std::cin, satir)) {
        return false;
    }
    std::istringstream ss(satir);
    if (!(ss >> r >> c) || r < 1 || r > MAKS_SATIR || c < 1 ||
        c > MAKS_SUTUN) {
        return false;
    }
    L.S = static_cast<int>(r);
    L.Y = static_cast<int>(c);
    for (int i = 0; i < L.S; i++) {
        if (!std::getline(std::cin, satir)) {
            return false;
        }
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (static_cast<int>(satir.size()) != L.Y) {
            return false;
        }
        L.h.push_back(satir);
    }
    return konumlari_bul(L);
}

static void karsilastir(const Labirent& asil)
{
    Labirent a = asil, b = asil;         // kopyalar
    Sonuc s1 = bfs_labirent(a);
    Sonuc s2 = geri_izleme(b);
    int acik = 0;
    for (const std::string& satir : asil.h) {
        for (char k : satir) {
            acik += k != '#';
        }
    }
    std::cout << "   BFS (kuyruk; E kuyruktan çıkınca durur): yol = "
              << s1.uzunluk << " adım, işlenen = " << s1.ziyaret
              << ", kuyruğa eklenen = " << s1.eklenen << ", açık hücre = "
              << acik << '\n';
    yaz(a);
    std::cout << "   (* yol, o işlenen, + kuyrukta kalan sınır hücresi)\n";
    std::cout << "   Geri izleme (H3 Örnek 11): yol = " << s2.uzunluk
              << " adım, ziyaret = " << s2.ziyaret
              << " çağrı, geri dönülen = " << s2.geri_donulen << '\n';
    yaz(b);
    std::cout << "   (* yol, x denenip geri dönülen hücre)\n";
    std::cout << "   yöntem            yol (adım)  ziyaret  en kısa mı?\n";
    std::cout << "   BFS               " << std::setw(10) << s1.uzunluk
              << "  " << std::setw(7) << s1.ziyaret
              << "  evet (her zaman: katman sırası)\n";
    std::cout << "   geri izleme (H3)  " << std::setw(10) << s2.uzunluk
              << "  " << std::setw(7) << s2.ziyaret << "  "
              << (s2.uzunluk == s1.uzunluk
                      ? "bu labirentte evet (güvence yok)"
                      : "HAYIR (ilk bulunan yol)")
              << '\n';
}

int main()
{
    Labirent L, oda;
    if (!labirent_oku(L)) {
        std::cerr << "Hatalı labirent girdisi\n";
        return 1;
    }
    std::cout << "1) Labirent " << L.S << " x " << L.Y
              << " (H3 ile aynı dosya), S = (" << L.sr << ", " << L.sc
              << "), E = (" << L.er << ", " << L.ec << ")\n";
    std::cout << "   yön sırası (H3 ile aynı): sağ, aşağı, sol, yukarı\n";
    karsilastir(L);
    oda.h = ODA;
    oda.S = static_cast<int>(ODA.size());
    oda.Y = static_cast<int>(ODA[0].size());
    konumlari_bul(oda);
    std::cout << "2) Açık oda " << oda.S << " x " << oda.Y
              << " (programa gömülü), S = (" << oda.sr << ", " << oda.sc
              << "), E = (" << oda.er << ", " << oda.ec << ")\n";
    karsilastir(oda);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Izgarada en kısa yol için
 * ağırlıklı durumda Dijkstra (H12); oyunlarda sezgisel A* kullanılır. */

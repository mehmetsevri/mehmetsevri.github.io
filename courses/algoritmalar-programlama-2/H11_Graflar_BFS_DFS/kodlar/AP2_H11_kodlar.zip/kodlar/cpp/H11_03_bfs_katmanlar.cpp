/* H11_03_bfs_katmanlar.cpp — AP-2 Hafta 11 · Örnek 3 (★★)
 * Amaç    : Genişlik öncelikli arama (BFS): kuyrukla dolaşma, ziyaret
 *           işareti kuyruğa EKLERKEN konur; adım adım kuyruk içeriği,
 *           ziyaret sırası, katmanlar; ekleme/inceleme sayaçları
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_03_bfs_katmanlar.cpp -o H11_03_bfs_katmanlar
 * Çalıştır: ./H11_03_bfs_katmanlar ../girdiler/graf_ornek.txt \
 *           ../girdiler/graf_yonlu.txt
 * Eşleri  : c/H11_03_bfs_katmanlar.c · python/H11_03_bfs_katmanlar.py
 * Çıktı   : üç dilde aynı (=); komşular artan köşe numarasıyla dolaşılır
 */
#include <algorithm>
#include <fstream>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

const long MAKS_KOSE = 1000000L;
const long MAKS_KENAR = 10000000L;
const std::size_t SATIR_UZ = 256;

// Komşuluk listesi: std::vector<std::vector<int>> (dinamik dizi dizisi)
struct Graf {
    int V = 0, E = 0;
    bool yonlu = false;
    std::vector<std::vector<int>> komsu;
};

// Yolun son bileşeni: stdout'a mutlak yol yazılmaz
static std::string taban_ad(const std::string& yol)
{
    std::size_t p = yol.find_last_of('/');
    return p == std::string::npos ? yol : yol.substr(p + 1);
}

// s: isteğe bağlı '-' ve 1..9 rakam; başka karakter yok
static bool tamsayi_coz(const std::string& s, long& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9 ||
        s.find_first_not_of("0123456789", bas) != std::string::npos) {
        return false;
    }
    x = std::stol(s);
    return true;
}

// Satırı boşluklarda böler; en çok 4 belirteç (4 = fazla)
static std::vector<std::string> belirtecle(const std::string& satir)
{
    const char *ayrac = " \t\r\n\v\f";
    std::vector<std::string> bel;
    std::size_t i = satir.find_first_not_of(ayrac);
    while (i != std::string::npos && bel.size() < 4) {
        std::size_t j = satir.find_first_of(ayrac, i);
        bel.push_back(satir.substr(i, j == std::string::npos ? j : j - i));
        i = satir.find_first_not_of(ayrac, j == std::string::npos
                                               ? satir.size() : j);
    }
    return bel;
}

// Başlık satırı "V E [yonlu|yonsuz]": geçerliyse boş graf kurar
static bool baslik_isle(const std::vector<std::string>& bel, Graf& g)
{
    long V, E;
    std::size_t n = bel.size();
    if (!tamsayi_coz(bel[0], V) || !tamsayi_coz(bel[1], E) || V < 1 ||
        V > MAKS_KOSE || E < 0 || E > MAKS_KENAR ||
        (n == 3 && bel[2] != "yonlu" && bel[2] != "yonsuz")) {
        return false;
    }
    g.V = static_cast<int>(V);
    g.E = static_cast<int>(E);
    g.yonlu = n == 3 && bel[2] == "yonlu";
    g.komsu.assign(g.V, std::vector<int>());
    return true;
}

// Kenar satırı "u v [w]" (w okunur ama kullanılmaz)
static bool kenar_isle(const std::vector<std::string>& bel, Graf& g)
{
    long x[3] = {0, 0, 0};
    for (std::size_t i = 0; i < bel.size(); i++) {
        if (!tamsayi_coz(bel[i], x[i])) {
            return false;
        }
    }
    if (x[0] < 0 || x[0] >= g.V || x[1] < 0 || x[1] >= g.V) {
        return false;
    }
    g.komsu[x[0]].push_back(static_cast<int>(x[1]));
    if (!g.yonlu) {
        g.komsu[x[1]].push_back(static_cast<int>(x[0]));
    }
    return true;
}

// Örnek 2'deki okuyucunun kısa sürümü: aynı biçim ve denetimler (ortak
// dosya), tek tip ileti. Kenarlar dosya sırasıyla eklenir, sonra her liste
// artan sıraya dizilir (belirli sıra). Hata: stderr'e ileti, false.
static bool graf_yukle(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    std::string satir;
    int no = 0, okunan = -1;                // okunan -1: başlık yok
    bool hata = false;
    g = Graf();
    if (!f) {
        std::cerr << taban_ad(yol) << ": dosya açılamadı\n";
        return false;
    }
    while (!hata && std::getline(f, satir)) {
        no++;
        if (satir.size() >= SATIR_UZ - 1) {
            hata = true;                    // satır çok uzun
            break;
        }
        std::vector<std::string> bel = belirtecle(satir);
        std::size_t n = bel.size();
        if (n == 0 || bel[0][0] == '#') {
            continue;                       // boş satır ya da yorum
        }
        if (n < 2 || n > 3 || okunan == g.E) {
            hata = true;
        } else if (okunan < 0) {
            hata = !baslik_isle(bel, g);
            okunan = 0;
        } else {
            hata = !kenar_isle(bel, g);
            okunan++;
        }
    }
    if (hata) {
        std::cerr << taban_ad(yol) << ": satır " << no
                  << ": biçim hatası (bkz. Örnek 2)\n";
        return false;
    }
    if (okunan < g.E) {
        std::cerr << taban_ad(yol) << ": başlık ya da kenar eksik\n";
        return false;
    }
    for (std::vector<int>& liste : g.komsu) {
        std::sort(liste.begin(), liste.end());
    }
    return true;
}

struct Sayac {
    long ekleme = 0;         // kuyruğa ekleme
    long inceleme = 0;       // incelenen komşu (kenar ucu)
    int en_uzun = 0;         // en uzun kuyruk
};

// std::queue dolaşılamaz: içerik bir kopyadan çıkarılarak yazdırılır
static void kuyruk_yaz(std::queue<int> q)
{
    std::cout << '[';
    for (bool ilk = true; !q.empty(); q.pop(), ilk = false) {
        std::cout << (ilk ? "" : " ") << q.front();
    }
    std::cout << ']';
}

// BFS(s): katman[v] = s'den v'ye en az kenar sayısı (ulaşılamayan -1),
// sira ziyaret sırası. ayrinti ise her adım yazdırılır.
static void bfs(const Graf& g, int s, std::vector<int>& katman,
                std::vector<int>& sira, Sayac& say, bool ayrinti)
{
    std::queue<int> q;
    katman.assign(g.V, -1);                 // -1: henüz görülmedi
    sira.clear();
    say = Sayac();
    katman[s] = 0;                          // işaret EKLERKEN
    q.push(s);
    say.ekleme = say.en_uzun = 1;
    if (ayrinti) {
        std::cout << "   başlangıç: " << s << " kuyruğa eklendi; kuyruk: ";
        kuyruk_yaz(q);
        std::cout << '\n';
    }
    while (!q.empty()) {
        int u = q.front();                  // kuyruğun başından çıkar
        q.pop();
        sira.push_back(u);
        if (ayrinti) {
            std::cout << "   adım " << sira.size() << ": çıkan " << u
                      << " (katman " << katman[u] << "); eklenen:";
        }
        int eklenen = 0;
        for (int v : g.komsu[u]) {
            say.inceleme++;
            if (katman[v] == -1) {
                katman[v] = katman[u] + 1;  // işaret EKLERKEN
                q.push(v);
                say.ekleme++;
                eklenen++;
                if (ayrinti) {
                    std::cout << ' ' << v;
                }
            }
        }
        say.en_uzun = std::max(say.en_uzun, static_cast<int>(q.size()));
        if (ayrinti) {
            std::cout << (eklenen ? "" : " -") << "; kuyruk: ";
            kuyruk_yaz(q);
            std::cout << '\n';
        }
    }
}

static void sira_yaz(const char *baslik, const std::vector<int>& a)
{
    std::cout << baslik;
    for (int x : a) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';
}

// Katmanları ziyaret sırasıyla yazar: katman k = s'den k kenar uzakta
static void katmanlari_yaz(const std::vector<int>& katman,
                           const std::vector<int>& sira, bool satir_satir)
{
    int en_derin = sira.empty() ? -1 : katman[sira.back()];
    if (!satir_satir) {
        std::cout << "   katmanlar:";
    }
    for (int k = 0; k <= en_derin; k++) {
        if (satir_satir) {
            std::cout << "   katman " << k << ':';
        } else {
            std::cout << " [";
        }
        bool ilk = true;
        for (int v : sira) {
            if (katman[v] == k) {
                std::cout << (satir_satir || !ilk ? " " : "") << v;
                ilk = false;
            }
        }
        std::cout << (satir_satir ? "\n" : "]");
    }
    if (!satir_satir) {
        std::cout << '\n';
    }
}

static void sayac_yaz(const Sayac& say, const char *ek_not)
{
    std::cout << "   sayaçlar: kuyruğa ekleme = " << say.ekleme
              << ", kenar inceleme = " << say.inceleme << ek_not
              << ", en uzun kuyruk = " << say.en_uzun << '\n';
}

// Kısa rapor: ziyaret sırası, katmanlar, ulaşılamayanlar, sayaçlar
static void kisa_bfs(const Graf& g, int s, const char *ek_not)
{
    std::vector<int> katman, sira;
    Sayac say;
    bfs(g, s, katman, sira, say, false);
    sira_yaz("   ziyaret sırası:", sira);
    katmanlari_yaz(katman, sira, false);
    if (static_cast<int>(sira.size()) < g.V) {
        std::cout << "   ulaşılamayan:";
        for (int v = 0; v < g.V; v++) {
            if (katman[v] == -1) {
                std::cout << ' ' << v;
            }
        }
        std::cout << '\n';
    }
    sayac_yaz(say, ek_not);
}

// Ayrıntılı rapor: her adımda çıkan köşe, eklenenler ve kuyruk
static void ayrintili_bfs(const Graf& g, int s)
{
    std::vector<int> katman, sira;
    Sayac say;
    std::cout << "1) BFS(" << s
              << "): ziyaret işareti kuyruğa EKLERKEN konur\n";
    bfs(g, s, katman, sira, say, true);
    sira_yaz("   ziyaret sırası:", sira);
    katmanlari_yaz(katman, sira, true);
    sayac_yaz(say, g.yonlu ? "" : " (= 2E: her kenar iki uçtan)");
}

int main(int argc, char *argv[])
{
    Graf g;
    if (argc < 2) {
        std::cerr << "Kullanım: H11_03_bfs_katmanlar GRAF [GRAF2]\n";
        return 2;
    }
    if (!graf_yukle(argv[1], g)) {
        return 1;
    }
    std::cout << "Graf: " << taban_ad(argv[1]) << " (V = " << g.V
              << ", E = " << g.E << ", " << (g.yonlu ? "yönlü" : "yönsüz")
              << ")\n";
    ayrintili_bfs(g, 0);
    std::cout << "2) BFS(" << g.V - 1 << "): aynı graf, başka kaynak\n";
    kisa_bfs(g, g.V - 1, "");
    if (argc > 2) {
        if (!graf_yukle(argv[2], g)) {
            return 1;
        }
        std::cout << "3) " << taban_ad(argv[2]) << " ("
                  << (g.yonlu ? "yönlü" : "yönsüz") << ", V = " << g.V
                  << ", E = " << g.E << "): BFS(0)\n";
        kisa_bfs(g, 0, g.yonlu ? " (ulaşılan köşelerin çıkış "
                                 "dereceleri toplamı)" : "");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (kuyruk elle, H9); C++ — yok (std::queue
 * yalnız kuyruk; Boost.Graph breadth_first_search); Python — yok
 * (collections.deque yalnız kuyruk; networkx.bfs_layers doğrulama için). */

/* H11_01_komsuluk_matrisi.cpp — AP-2 Hafta 11 · Örnek 1 (★)
 * Amaç    : Komşuluk matrisi (AP-1 H11 2B dizisi): yönsüz G ve yönlü G3;
 *           derece, giriş/çıkış derecesi, el sıkışma lemması denetimi;
 *           satır taramasıyla komşu bulma (her köşe için V hücre okunur)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_01_komsuluk_matrisi.cpp -o H11_01_komsuluk_matrisi
 * Çalıştır: ./H11_01_komsuluk_matrisi
 * Eşleri  : c/H11_01_komsuluk_matrisi.c ·
 *           python/H11_01_komsuluk_matrisi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <utility>
#include <vector>

using Matris = std::vector<std::vector<int>>;
using KenarDizisi = std::vector<std::pair<int, int>>;

// Haftanın örnek grafı G (girdiler/graf_ornek.txt ile aynı kenarlar)
static const KenarDizisi G_KENAR = {
    {4, 5}, {0, 2}, {6, 7}, {1, 3}, {0, 1},
    {4, 6}, {2, 4}, {3, 5}, {5, 7}, {1, 4},
};
// Yönlü G3 (girdiler/graf_yonlu.txt ile aynı kenarlar): u -> v
static const KenarDizisi G3_KENAR = {
    {4, 5}, {2, 0}, {0, 1}, {5, 6}, {7, 5}, {2, 3},
    {0, 4}, {6, 4}, {3, 1}, {1, 2}, {4, 3}, {0, 2},
};

static long okunan_hucre = 0;       // satır taramasında okunan hücre

static Matris matris_kur(int V, const KenarDizisi& kenar, bool yonlu)
{
    Matris matris(V, std::vector<int>(V, 0));
    for (const auto& [u, v] : kenar) {
        matris[u][v] = 1;
        if (!yonlu) {
            matris[v][u] = 1;       // yönsüz: iki yönde de
        }
    }
    return matris;
}

static void matris_yaz(const Matris& matris)
{
    int V = static_cast<int>(matris.size());
    std::cout << "       ";
    for (int v = 0; v < V; v++) {
        std::cout << ' ' << v;
    }
    std::cout << '\n';
    for (int u = 0; u < V; u++) {
        std::cout << "    " << u << ": ";
        for (int v = 0; v < V; v++) {
            std::cout << ' ' << matris[u][v];
        }
        std::cout << '\n';
    }
}

// Simetrikse -1, değilse ilk asimetrik hücrenin u * V + v değeri
static int asimetri(const Matris& matris)
{
    int V = static_cast<int>(matris.size());
    for (int u = 0; u < V; u++) {
        for (int v = u + 1; v < V; v++) {
            if (matris[u][v] != matris[v][u]) {
                return u * V + v;
            }
        }
    }
    return -1;
}

// u'nun komşuları: satır u baştan sona taranır (V hücre)
static std::vector<int> komsulari_bul(const Matris& matris, int u)
{
    std::vector<int> komsu;
    int V = static_cast<int>(matris.size());
    for (int v = 0; v < V; v++) {
        okunan_hucre++;
        if (matris[u][v] != 0) {
            komsu.push_back(v);
        }
    }
    return komsu;
}

static void yonsuz_bolum()
{
    const int V = 8;
    const int E = static_cast<int>(G_KENAR.size());
    std::vector<int> derece(V);
    int toplam = 0, bir_olan = 0;
    Matris matris = matris_kur(V, G_KENAR, false);
    std::cout << "1) Yönsüz G: V = " << V << ", E = " << E
              << "; matris[u][v] = matris[v][u] = 1\n";
    matris_yaz(matris);
    std::cout << "   simetrik mi: "
              << (asimetri(matris) < 0 ? "evet" : "hayır") << '\n';
    std::cout << "   komşular (satır taraması) ve derece:\n";
    okunan_hucre = 0;
    for (int u = 0; u < V; u++) {
        std::vector<int> komsu = komsulari_bul(matris, u);
        int k = static_cast<int>(komsu.size());
        derece[u] = k;
        toplam += k;
        std::cout << "    " << u << ": derece " << k << ", komşular:";
        for (int v : komsu) {
            std::cout << ' ' << v;
        }
        std::cout << '\n';
    }
    for (int u = 0; u < V; u++) {
        for (int v = 0; v < V; v++) {
            bir_olan += matris[u][v];
        }
    }
    std::cout << "   okunan hücre = " << okunan_hucre << " = V² = " << V * V
              << " (komşu sayısından bağımsız)\n";
    std::cout << "   el sıkışma lemması: Σ derece = " << toplam << ", 2E = "
              << 2 * E << " -> " << (toplam == 2 * E ? "doğru" : "YANLIŞ")
              << '\n';
    std::cout << "   1 olan hücre = " << bir_olan << " / " << V * V
              << " (her kenar iki hücrede)\n";
    int en = 0;
    for (int u = 1; u < V; u++) {
        if (derece[u] > derece[en]) {
            en = u;                 // eşitlikte küçük numara kalır
        }
    }
    std::cout << "   en büyük derece: köşe " << en << " (" << derece[en]
              << ")\n\n";
}

// d[u] == 0 olan köşeleri yazar; hiç yoksa " yok"
static void sifirlari_yaz(const std::vector<int>& d)
{
    int sayi = 0;
    for (std::size_t u = 0; u < d.size(); u++) {
        if (d[u] == 0) {
            std::cout << ' ' << u;
            sayi++;
        }
    }
    if (sayi == 0) {
        std::cout << " yok";
    }
}

static void yonlu_bolum()
{
    const int V = 8;
    const int E = static_cast<int>(G3_KENAR.size());
    std::vector<int> cikis(V, 0), giris(V, 0);
    int top_cikis = 0, top_giris = 0;
    Matris matris = matris_kur(V, G3_KENAR, true);
    std::cout << "2) Yönlü G3: V = " << V << ", E = " << E
              << "; matris[u][v] = 1: u -> v\n";
    matris_yaz(matris);
    int a = asimetri(matris);
    if (a < 0) {
        std::cout << "   simetrik mi: evet\n";
    } else {
        std::cout << "   simetrik mi: hayır (ör. matris[" << a / V << "]["
                  << a % V << "] = " << matris[a / V][a % V] << ", matris["
                  << a % V << "][" << a / V << "] = "
                  << matris[a % V][a / V] << ")\n";
    }
    for (int u = 0; u < V; u++) {
        for (int v = 0; v < V; v++) {
            cikis[u] += matris[u][v];   // satır toplamı
            giris[v] += matris[u][v];   // sütun toplamı
        }
    }
    std::cout << "   köşe:          ";
    for (int u = 0; u < V; u++) {
        std::cout << ' ' << u;
    }
    std::cout << "\n   çıkış derecesi:";
    for (int u = 0; u < V; u++) {
        std::cout << ' ' << cikis[u];
        top_cikis += cikis[u];
    }
    std::cout << "\n   giriş derecesi:";
    for (int u = 0; u < V; u++) {
        std::cout << ' ' << giris[u];
        top_giris += giris[u];
    }
    std::cout << "\n   Σ çıkış = " << top_cikis << ", Σ giriş = " << top_giris
              << ", E = " << E << " -> "
              << (top_cikis == E && top_giris == E ? "doğru" : "YANLIŞ")
              << '\n';
    std::cout << "   kaynak (giriş 0):";
    sifirlari_yaz(giris);
    std::cout << "; kuyu (çıkış 0):";
    sifirlari_yaz(cikis);
    std::cout << "\n\n";
}

int main()
{
    yonsuz_bolum();
    yonlu_bolum();
    std::cout << "3) Matris belleği V² hücredir (1 bayt/hücre varsayımıyla):\n";
    const long long vler[] = {8, 1000, 100000};
    for (long long v : vler) {
        std::cout << "   V = ";
        std::cout.width(7);
        std::cout << v << " -> V² = ";
        std::cout.width(12);
        std::cout << v * v << " hücre\n";
    }
    std::cout << "   (V = 100000 için 10^10 hücre ≈ 10 GB: bkz. Kaputun "
                 "Altında)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (2B dizi elle); C++ — yok (std::vector
 * ile 2B dizi; Boost.Graph adjacency_matrix); Python — yok (liste
 * listesi; networkx.to_numpy_array yalnız doğrulama için). */

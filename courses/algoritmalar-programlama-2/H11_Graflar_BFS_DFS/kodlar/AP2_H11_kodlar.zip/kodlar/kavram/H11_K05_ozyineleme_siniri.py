"""H11_K05_ozyineleme_siniri.py — AP-2 Hafta 11 · Kavram K05 (Dil Penceresi)
Amaç    : CPython'un özyineleme sınırı: sys.getrecursionlimit() (varsayılan
          1000). Zincirde özyinelemeli DFS sınırı aşınca RecursionError.
          sys.setrecursionlimit ile sınır büyütülebilir; ama Python
          belgeleri "çok yüksek bir sınır çökmeye yol açabilir" der (C
          yığını taşabilir). Bu dosya sınırı YALNIZ gösterim için büyütür;
          doğru çözüm açık yığındır (Örnek 6, Hata Avcısı 7).
Çalıştır: python3 H11_K05_ozyineleme_siniri.py
"""
import sys


def zincir_dfs(n):
    """0 - 1 - ... - n-1 zincirinde özyinelemeli DFS; derinlik = n"""
    ziyaret = [False] * n

    def dfs(u):
        ziyaret[u] = True
        for v in (u - 1, u + 1):
            if 0 <= v < n and not ziyaret[v]:
                dfs(v)

    dfs(0)
    return sum(ziyaret)


def dene(n):
    try:
        return f"{zincir_dfs(n)} köşe ziyaret edildi"
    except RecursionError as e:
        return f"RecursionError: {e}"


def main():
    print(f"Python {sys.version.split()[0]} (bu çalıştırmada)")
    print(f"varsayılan sınır: sys.getrecursionlimit() = "
          f"{sys.getrecursionlimit()}")
    for n in (500, 990, 1000, 5000):
        print(f"  n = {n:5d}: {dene(n)}")
    eski = sys.getrecursionlimit()
    sys.setrecursionlimit(20000)        # YALNIZ gösterim; tehlikeli olabilir
    print(f"sys.setrecursionlimit(20000) sonrası:")
    for n in (5000, 15000, 25000):
        print(f"  n = {n:5d}: {dene(n)}")
    sys.setrecursionlimit(eski)
    print(f"sınır geri alındı: {sys.getrecursionlimit()}")
    print("Not: sınırın üstündeki hata Python'un kendi korumasıdır; sınır "
          "çok büyütülürse süreç C yığınında çökebilir. Açık yığın bu "
          "sınırdan bağımsızdır.")


if __name__ == "__main__":
    main()

"""H11_K01_matris_bellek.py — AP-2 Hafta 11 · Kavram K01 (Kaputun Altında)
Amaç    : Komşuluk matrisinin bellek patlaması (C sürümüyle aynı hesap) ve
          Python'da gerçek boyutlar: liste listesinde her hücre 8 baytlık
          bir başvurudur (0 ve 1 küçük tamsayı nesneleri paylaşılır);
          bytearray satırı hücre başına 1 bayttır. sys.getsizeof değerleri
          CPython sürümüne bağlıdır (bu çalıştırmada).
Çalıştır: python3 H11_K01_matris_bellek.py
"""
import sys


def bayt_metni(b):
    if b >= 1e9:
        return f" {b / 1e9:9.2f} GB"
    if b >= 1e6:
        return f" {b / 1e6:9.2f} MB"
    return f" {b / 1e3:9.2f} kB"


def main():
    print("Komşuluk matrisi: V² hücre; seyrek graf E = 4V için liste ve CSR")
    print(f"{'V':>9} {'V² (hücre)':>16} {'1 bit':>12} {'1 bayt':>12} "
          f"{'4 bayt':>12} {'liste':>12} {'CSR':>12}")
    for V in (1000, 10000, 100000, 1000000):
        E = 4 * V
        print(f"{V:9d} {V * V:16d}" + bayt_metni(V * V / 8)
              + bayt_metni(V * V) + bayt_metni(4.0 * V * V)
              + bayt_metni(24.0 * V + 8.0 * E)
              + bayt_metni(4.0 * (V + 1) + 8.0 * E))
    V = 1000
    liste_satiri = [0] * V
    bytearray_satiri = bytearray(V)
    print(f"\nPython (CPython {sys.version.split()[0]}, bu çalıştırmada):")
    print(f"  [0] * {V} satırı     : {sys.getsizeof(liste_satiri)} bayt "
          f"(hücre başına ≈ {sys.getsizeof(liste_satiri) / V:.2f})")
    print(f"  bytearray({V}) satırı: {sys.getsizeof(bytearray_satiri)} bayt "
          f"(hücre başına ≈ {sys.getsizeof(bytearray_satiri) / V:.2f})")
    print(f"  V = {V} matris: liste listesi ≈ "
          f"{V * sys.getsizeof(liste_satiri) / 1e6:.2f} MB, bytearray "
          f"satırları ≈ {V * sys.getsizeof(bytearray_satiri) / 1e6:.2f} MB")
    print("  V = 100000 için liste listesi ≈ "
          f"{100000 * 100000 * 8 / 1e9:.0f} GB yalnız başvurular için")


if __name__ == "__main__":
    main()

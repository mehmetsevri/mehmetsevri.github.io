"""H11_K02_csr_kurulumu.py — AP-2 Hafta 11 · Kavram K02 (Merak kutusu)
Amaç    : CSR (sıkıştırılmış seyrek satır) kurulumu üç adımda: derece say,
          önek toplamıyla bas[], kenarları yerlerine yaz. C sürümüyle aynı
          çıktı. (Python listesi başvuru tutar; gerçek bitişik tamsayı
          dizisi için array('i') gerekir — önbellek kazancı C'deki gibi
          değildir.)
Çalıştır: python3 H11_K02_csr_kurulumu.py
Eşleri  : H11_K02_csr_kurulumu.c · H11_K02_csr_kurulumu.cpp
"""

# Haftanın örnek grafı G (yönsüz), girdiler/graf_ornek.txt sırasıyla
KENAR = [(4, 5), (0, 2), (6, 7), (1, 3), (0, 1),
         (4, 6), (2, 4), (3, 5), (5, 7), (1, 4)]


def dizi_yaz(ad, a):
    print(f"{ad:<8}:" + "".join(f" {x}" for x in a))


def main():
    V, E = 8, len(KENAR)
    derece = [0] * V
    for u, v in KENAR:                  # (1) say
        derece[u] += 1
        derece[v] += 1
    dizi_yaz("derece", derece)
    bas = [0] * (V + 1)
    for u in range(V):                  # (2) önek toplamı
        bas[u + 1] = bas[u] + derece[u]
    dizi_yaz("bas", bas)
    yer = bas[:-1]
    komsu = [0] * (2 * E)
    for u, v in KENAR:                  # (3) yerleştir
        komsu[yer[u]] = v
        yer[u] += 1
        komsu[yer[v]] = u
        yer[v] += 1
    dizi_yaz("komsu", komsu)
    for u in range(V):                  # her listeyi sırala
        for i in range(bas[u] + 1, bas[u + 1]):
            x, j = komsu[i], i - 1      # araya ekleme (H5)
            while j >= bas[u] and komsu[j] > x:
                komsu[j + 1] = komsu[j]
                j -= 1
            komsu[j + 1] = x
    dizi_yaz("sıralı", komsu)
    for u in range(V):
        print(f"  {u}: komsu[{bas[u]}..{bas[u + 1] - 1}] ="
              + "".join(f" {komsu[i]}" for i in range(bas[u], bas[u + 1])))
    print(f"bellek: (V + 1) + 2E = {V + 1} + {2 * E} = {V + 1 + 2 * E} int; "
          f"matris V² = {V * V} hücre")


if __name__ == "__main__":
    main()

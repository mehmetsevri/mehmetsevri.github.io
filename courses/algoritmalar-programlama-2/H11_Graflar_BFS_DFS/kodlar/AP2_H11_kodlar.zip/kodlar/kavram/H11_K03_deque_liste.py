"""H11_K03_deque_liste.py — AP-2 Hafta 11 · Kavram K03 (Dil Penceresi)
Amaç    : BFS kuyruğu Python'da neden collections.deque? list.pop(0) baştaki
          öğeyi çıkarınca kalan bütün öğeleri bir sola kaydırır: O(n);
          deque.popleft() O(1). Aynı işlem dizisi (n ekleme, n çıkarma)
          iki yapıyla; süreler bu çalıştırmada ölçülür (stdout'a yazılır,
          çıktı "bu çalıştırmada" etiketlidir).
Çalıştır: python3 H11_K03_deque_liste.py
"""
import os
import sys
from collections import deque

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from zamanlayici import olc_ortanca  # noqa: E402  (ortak modül)


def liste_kuyruk(n):
    q = []
    for i in range(n):
        q.append(i)
    toplam = 0
    while q:
        toplam += q.pop(0)              # baştan çıkar: O(n) kaydırma
    return toplam


def deque_kuyruk(n):
    q = deque()
    for i in range(n):
        q.append(i)
    toplam = 0
    while q:
        toplam += q.popleft()           # baştan çıkar: O(1)
    return toplam


def main():
    print("n ekleme + n baştan çıkarma (ortanca, 1 ısınma + 5 tekrar; bu "
          "çalıştırmada)")
    print(f"{'n':>8} {'list.pop(0) ms':>16} {'deque.popleft ms':>18} "
          f"{'kat':>8}")
    olcum = []
    for n in (10000, 20000, 40000, 80000):
        assert liste_kuyruk(n) == deque_kuyruk(n)
        t1 = olc_ortanca(lambda: liste_kuyruk(n), 5) * 1000
        t2 = olc_ortanca(lambda: deque_kuyruk(n), 5) * 1000
        olcum.append((t1, t2))
        print(f"{n:8d} {t1:16.2f} {t2:18.2f} {t1 / t2:8.1f}")
    (l0, d0), (l3, d3) = olcum[0], olcum[-1]
    print(f"n 8 katına çıkınca: list süresi x {l3 / l0:.1f} (karesel: 64), "
          f"deque süresi x {d3 / d0:.1f} (doğrusal: 8)")


if __name__ == "__main__":
    main()

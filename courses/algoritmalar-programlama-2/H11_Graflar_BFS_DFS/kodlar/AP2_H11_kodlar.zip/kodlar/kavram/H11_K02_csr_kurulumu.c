/* H11_K02_csr_kurulumu.c — AP-2 Hafta 11 · Kavram K02 (Merak kutusu)
 * Amaç    : CSR (sıkıştırılmış seyrek satır) kurulumu üç adımda:
 *           (1) her köşenin derecesini say, (2) önek toplamıyla bas[]
 *           dizisini kur (u'nun komşuları komsu[bas[u] .. bas[u+1]-1]),
 *           (3) kenarları yerlerine yaz. Bütün komşular TEK bitişik
 *           dizidedir: dolaşma bellekte ileri doğru akar (önbellek dostu).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_K02_csr_kurulumu.c -o H11_K02_csr_kurulumu
 * Eşleri  : H11_K02_csr_kurulumu.cpp · H11_K02_csr_kurulumu.py
 */
#include <stdio.h>

#define V 8
#define E 10

/* Haftanın örnek grafı G (yönsüz), girdiler/graf_ornek.txt sırasıyla */
static const int KENAR[E][2] = {{4, 5}, {0, 2}, {6, 7}, {1, 3}, {0, 1},
                                {4, 6}, {2, 4}, {3, 5}, {5, 7}, {1, 4}};

static void dizi_yaz(const char *ad, const int a[], int n)
{
    printf("%-8s:", ad);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

int main(void)
{
    int derece[V] = {0}, bas[V + 1] = {0}, yer[V], komsu[2 * E];
    for (int i = 0; i < E; i++) {                 /* (1) say */
        derece[KENAR[i][0]]++;
        derece[KENAR[i][1]]++;
    }
    dizi_yaz("derece", derece, V);
    for (int u = 0; u < V; u++) {                 /* (2) önek toplamı */
        bas[u + 1] = bas[u] + derece[u];
        yer[u] = bas[u];
    }
    dizi_yaz("bas", bas, V + 1);
    for (int i = 0; i < E; i++) {                 /* (3) yerleştir */
        int u = KENAR[i][0], v = KENAR[i][1];
        komsu[yer[u]++] = v;
        komsu[yer[v]++] = u;
    }
    dizi_yaz("komsu", komsu, 2 * E);
    for (int u = 0; u < V; u++) {                 /* her listeyi sırala */
        for (int i = bas[u] + 1; i < bas[u + 1]; i++) {
            int x = komsu[i], j = i - 1;          /* araya ekleme (H5) */
            while (j >= bas[u] && komsu[j] > x) {
                komsu[j + 1] = komsu[j];
                j--;
            }
            komsu[j + 1] = x;
        }
    }
    dizi_yaz("sıralı  ", komsu, 2 * E);       /* %-8s bayt sayar */
    for (int u = 0; u < V; u++) {
        printf("  %d: komsu[%d..%d] =", u, bas[u], bas[u + 1] - 1);
        for (int i = bas[u]; i < bas[u + 1]; i++) {
            printf(" %d", komsu[i]);
        }
        printf("\n");
    }
    printf("bellek: (V + 1) + 2E = %d + %d = %d int; matris V² = %d hücre\n",
           V + 1, 2 * E, V + 1 + 2 * E, V * V);
    return 0;
}

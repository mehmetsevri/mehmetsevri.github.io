"""H11_K04_networkx_dogrulama.py — AP-2 Hafta 11 · Kavram K04 (doğrulama)
Amaç    : Merdivendeki Python örneklerinin sonuçlarını networkx ile
          DOĞRULAR (networkx yalnız kâhindir; örneklerde kullanılmaz).
          networkx kurulu değilse doğrulama atlanır (çıkış kodu 0).
          Örnek modülleri ../python/ klasöründen içe aktarılır; girdiler
          ../girdiler/ klasöründendir.
Çalıştır: python3 H11_K04_networkx_dogrulama.py
"""
import importlib
import os
import sys

KOK = os.path.dirname(os.path.abspath(__file__))
GIRDI = os.path.join(KOK, "..", "girdiler")
sys.path.insert(0, os.path.join(KOK, "..", "python"))


def modul(ad):
    return importlib.import_module(ad)


def nx_graf(nx, g):
    """Bizim Graf'tan networkx grafı: köşeler 0..V-1, kenarlar (u, v)
    sıralı eklenir; böylece networkx komşuları artan sırada dolaşır."""
    G = nx.DiGraph() if g.yonlu else nx.Graph()
    G.add_nodes_from(range(g.V))
    kenarlar = sorted({(u, v) if g.yonlu else (min(u, v), max(u, v))
                       for u in range(g.V) for v in g.komsu[u]})
    G.add_edges_from(kenarlar)
    return G


def denetle(ad, kosul, sayac):
    sayac[0] += 1
    sayac[1] += 0 if kosul else 1
    print(f"  {'evet ' if kosul else 'HAYIR'}  {ad}")


def main():
    try:
        import networkx as nx
    except ImportError:
        print("networkx kurulu değil: doğrulama atlandı (pip install "
              "networkx)")
        return 0
    print(f"networkx {nx.__version__} ile doğrulama (bu çalıştırmada)")
    s = [0, 0]
    yol = lambda f: os.path.join(GIRDI, f)   # noqa: E731
    o4, o5, o7 = (modul("H11_04_bfs_en_kisa_yol"),
                  modul("H11_05_dfs_ozyinelemeli"),
                  modul("H11_07_bagli_bilesenler"))
    o8, o11, o12 = (modul("H11_08_iki_parcali"), modul("H11_11_kahn"),
                    modul("H11_12_dfs_topolojik"))
    for f in ("graf_ornek.txt", "graf_bilesen.txt", "graf_yonlu.txt"):
        g = o4.graf_yukle(yol(f))
        G = nx_graf(nx, g)
        uzak, _, _ = o4.bfs_uzaklik(g, 0)
        nx_uzak = nx.single_source_shortest_path_length(G, 0)
        denetle(f"{f}: BFS uzaklıkları (Örnek 4) = shortest_path_length",
                all(uzak[v] == nx_uzak.get(v, -1) for v in range(g.V)), s)
        d = o5.Dfs(g.V)
        for r in range(g.V):
            if d.renk[r] == o5.BEYAZ:
                o5.dfs_ziyaret(g, r, d)
        denetle(f"{f}: DFS sırası (Örnek 5) = dfs_preorder_nodes",
                d.sira == list(nx.dfs_preorder_nodes(G)), s)
    g = o7.graf_yukle(yol("graf_bilesen.txt"))
    G = nx_graf(nx, g)
    etiket = [-1] * g.V
    ebeveyn = [-1] * g.V
    say = o7.Sayac()
    biz = []
    for r in range(g.V):
        if etiket[r] == -1:
            uyeler, _ = o7.bileseni_etiketle(g, r, len(biz), etiket,
                                              ebeveyn, say)
            biz.append(sorted(uyeler))
    denetle("graf_bilesen.txt: bileşenler (Örnek 7) = connected_components",
            sorted(biz) == sorted(sorted(c) for c in
                                  nx.connected_components(G)), s)
    for f in ("graf_ornek.txt", "graf_tek_dongu.txt"):
        g = o8.graf_yukle(yol(f))
        b = o8.Boyama(g.V)
        sonuc = True
        stdout = sys.stdout
        sys.stdout = open(os.devnull, "w")  # adım izini gizle
        try:
            for r in range(g.V):
                if b.renk[r] == -1 and sonuc:
                    sonuc = o8.bfs_boya(g, r, b)
        finally:
            sys.stdout.close()
            sys.stdout = stdout
        denetle(f"{f}: iki parçalı mı (Örnek 8) = is_bipartite "
                f"({sonuc})", sonuc == nx.is_bipartite(nx_graf(nx, g)), s)
    g = o11.graf_yukle(yol("dersler_dag.txt"))
    G = nx_graf(nx, g)
    sira, _, _ = o11.kahn(g, False, False)
    denetle("dersler_dag.txt: Kahn en küçük öbek sırası (Örnek 11) = "
            "lexicographical_topological_sort",
            sira == list(nx.lexicographical_topological_sort(G)), s)
    denetle("dersler_dag.txt: geçerli sıra sayısı 108 = "
            "all_topological_sorts", sum(1 for _ in
                                         nx.all_topological_sorts(G)) == 108,
            s)
    t = o12.Topo(g.V)
    stdout = sys.stdout
    sys.stdout = open(os.devnull, "w")
    try:
        for r in range(g.V):
            if t.renk[r] == o12.BEYAZ:
                o12.dfs_topo(g, r, t)
    finally:
        sys.stdout.close()
        sys.stdout = stdout
    sira = t.bitis_sirasi[::-1]
    konum = {v: i for i, v in enumerate(sira)}
    denetle("dersler_dag.txt: DFS topolojik sırası (Örnek 12) geçerli",
            all(konum[u] < konum[v] for u, v in G.edges), s)
    g = o11.graf_yukle(yol("dersler_dongulu.txt"))
    G = nx_graf(nx, g)
    dongu = [u for u, _ in nx.find_cycle(G, source=0)]
    denetle(f"dersler_dongulu.txt: döngü var (find_cycle: {dongu}) ve "
            "is_directed_acyclic_graph = False",
            not nx.is_directed_acyclic_graph(G) and sorted(dongu) ==
            [0, 2, 7], s)
    print(f"{s[0]} denetim, {s[1]} hata")
    return 0 if s[1] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

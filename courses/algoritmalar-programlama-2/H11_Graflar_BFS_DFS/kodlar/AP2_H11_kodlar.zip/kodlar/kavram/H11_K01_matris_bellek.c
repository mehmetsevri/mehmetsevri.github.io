/* H11_K01_matris_bellek.c — AP-2 Hafta 11 · Kavram K01 (Kaputun Altında)
 * Amaç    : Komşuluk matrisinin bellek patlaması: V² hücre. 1 bayt, 1 bit
 *           ve 4 bayt (int) hücreyle gereken bellek; seyrek grafta
 *           (E = 4V) komşuluk listesi ve CSR ile karşılaştırma. Ölçüm
 *           değil HESAP: 1 GB = 10^9 bayt, 1 GiB = 2^30 bayt.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_K01_matris_bellek.c -o H11_K01_matris_bellek
 * Çalıştır: ./H11_K01_matris_bellek
 */
#include <stdio.h>

static void bayt_yaz(double b)
{
    if (b >= 1e9) {
        printf(" %9.2f GB", b / 1e9);
    } else if (b >= 1e6) {
        printf(" %9.2f MB", b / 1e6);
    } else {
        printf(" %9.2f kB", b / 1e3);
    }
}

int main(void)
{
    const long long vler[] = {1000, 10000, 100000, 1000000};
    printf("Komşuluk matrisi: V² hücre; seyrek graf E = 4V için liste ve "
           "CSR\n");
    /* başlık elle hizalı: %16s bayt sayar, "²" ve "ü" ikişer bayttır */
    printf("        V       V² (hücre)        1 bit       1 bayt       "
           "4 bayt        liste          CSR\n");
    for (int i = 0; i < 4; i++) {
        long long V = vler[i], E = 4 * V;
        printf("%9lld %16lld", V, V * V);
        bayt_yaz((double)V * V / 8);
        bayt_yaz((double)V * V);
        bayt_yaz(4.0 * V * V);
        bayt_yaz(24.0 * V + 8.0 * E);    /* V baş (24 B) + 2E int */
        bayt_yaz(4.0 * (V + 1) + 8.0 * E);
        printf("\n");
    }
    long long V = 100000;
    printf("\nV = 100000: 10^10 hücre; 1 bayt/hücre ile 10^10 bayt = "
           "%.2f GB = %.2f GiB\n", (double)V * V / 1e9,
           (double)V * V / 1073741824.0);
    printf("aynı grafta (E = 4V) liste %.2f MB, CSR %.2f MB: matris "
           "listenin %.0f katı\n", (24.0 * V + 32.0 * V) / 1e6,
           (4.0 * (V + 1) + 32.0 * V) / 1e6,
           (double)V * V / (24.0 * V + 32.0 * V));
    printf("matrisle BFS her köşe için satırın tamamını okur: V² = "
           "%lld okuma;\nlisteyle V + 2E = %lld okuma\n", V * V,
           V + 8 * V);
    return 0;
}

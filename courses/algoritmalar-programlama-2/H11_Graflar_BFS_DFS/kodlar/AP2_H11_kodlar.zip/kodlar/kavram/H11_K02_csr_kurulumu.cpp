/* H11_K02_csr_kurulumu.cpp — AP-2 Hafta 11 · Kavram K02 (Merak kutusu)
 * Amaç    : CSR (sıkıştırılmış seyrek satır) kurulumu üç adımda: derece
 *           say, önek toplamıyla bas[], kenarları yerlerine yaz. C sürümüyle
 *           aynı çıktı; diziler std::vector.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_K02_csr_kurulumu.cpp -o H11_K02_csr_kurulumu
 * Eşleri  : H11_K02_csr_kurulumu.c · H11_K02_csr_kurulumu.py
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

// Haftanın örnek grafı G (yönsüz), girdiler/graf_ornek.txt sırasıyla
static const std::vector<std::pair<int, int>> KENAR = {
    {4, 5}, {0, 2}, {6, 7}, {1, 3}, {0, 1},
    {4, 6}, {2, 4}, {3, 5}, {5, 7}, {1, 4},
};

static void dizi_yaz(const std::string& ad, const std::vector<int>& a)
{
    std::cout << ad << std::string(ad.size() < 8 ? 8 - ad.size() : 0, ' ')
              << ':';
    for (int x : a) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';
}

int main()
{
    const int V = 8, E = static_cast<int>(KENAR.size());
    std::vector<int> derece(V, 0), bas(V + 1, 0), komsu(2 * E);
    for (const auto& [u, v] : KENAR) {            // (1) say
        derece[u]++;
        derece[v]++;
    }
    dizi_yaz("derece", derece);
    for (int u = 0; u < V; u++) {                 // (2) önek toplamı
        bas[u + 1] = bas[u] + derece[u];
    }
    dizi_yaz("bas", bas);
    std::vector<int> yer(bas.begin(), bas.end() - 1);
    for (const auto& [u, v] : KENAR) {            // (3) yerleştir
        komsu[yer[u]++] = v;
        komsu[yer[v]++] = u;
    }
    dizi_yaz("komsu", komsu);
    for (int u = 0; u < V; u++) {                 // her listeyi sırala
        for (int i = bas[u] + 1; i < bas[u + 1]; i++) {
            int x = komsu[i], j = i - 1;          // araya ekleme (H5)
            while (j >= bas[u] && komsu[j] > x) {
                komsu[j + 1] = komsu[j];
                j--;
            }
            komsu[j + 1] = x;
        }
    }
    std::cout << "sıralı  :";
    for (int x : komsu) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';
    for (int u = 0; u < V; u++) {
        std::cout << "  " << u << ": komsu[" << bas[u] << ".."
                  << bas[u + 1] - 1 << "] =";
        for (int i = bas[u]; i < bas[u + 1]; i++) {
            std::cout << ' ' << komsu[i];
        }
        std::cout << '\n';
    }
    std::cout << "bellek: (V + 1) + 2E = " << V + 1 << " + " << 2 * E
              << " = " << V + 1 + 2 * E << " int; matris V² = " << V * V
              << " hücre\n";
    return 0;
}

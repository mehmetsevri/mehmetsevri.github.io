"""H11_K07_dict_komsuluk.py — AP-2 Hafta 11 · Kavram K07 (Dil Penceresi)
Amaç    : Python'da adlı köşeler için komşuluk "listesi" bir dict olabilir:
          anahtar köşe adı, değer komşu adları listesi. BFS aynıdır;
          ziyaret işareti için set, kuyruk için deque kullanılır. (C'de
          ad -> numara eşlemesi gerekir: Örnek 13.) Kurgusal küçük bir
          mahalle yol ağı.
Çalıştır: python3 H11_K07_dict_komsuluk.py
"""
from collections import deque

YOLLAR = [("Merkez", "Liman"), ("Merkez", "Çarşı"), ("Merkez", "Kale"),
          ("Liman", "İskele"), ("Liman", "Köprü"), ("Çarşı", "Kale"),
          ("Köprü", "Kale"), ("İskele", "Yayla")]


def main():
    komsu = {}                          # dict: ad -> komşu adları
    for a, b in YOLLAR:
        komsu.setdefault(a, []).append(b)
        komsu.setdefault(b, []).append(a)
    for ad in komsu:
        komsu[ad].sort()                # belirlenimci dolaşma sırası
    uzak = {"Merkez": 0}                  # ziyaret + uzaklık birlikte
    q = deque(["Merkez"])
    while q:
        u = q.popleft()
        for v in komsu[u]:
            if v not in uzak:           # dict üyeliği: ortalama O(1)
                uzak[v] = uzak[u] + 1
                q.append(v)
    for ad in sorted(uzak, key=lambda x: (uzak[x], x)):
        print(f"{ad:10} {uzak[ad]} adım")
    print("(kurgusal mahalle adları ve yollar)")


if __name__ == "__main__":
    main()

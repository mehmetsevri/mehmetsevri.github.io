/* H11_K06_cagri_cercevesi.c — AP-2 Hafta 11 · Kavram K06 (Kaputun Altında)
 * Amaç    : Özyinelemeli DFS'nin her çağrısı çağrı yığınında bir çerçeve
 *           kaplar. İki ardışık çağrıdaki yerel değişkenlerin adres FARKI
 *           çerçeve boyunu verir (adresin kendisi yazdırılmaz: ASLR). Yığın
 *           sınırı getrlimit(RLIMIT_STACK) ile okunur (POSIX); sınır /
 *           çerçeve ≈ çökmeden inilebilecek en büyük derinlik.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H11_K06_cagri_cercevesi.c -o H11_K06_cagri_cercevesi
 *           (-O0: her çağrı gerçek bir çerçevedir. -O2'de derleyici bu
 *           kısa özyinelemeyi açabilir/satır içine alabilir; adres farkı
 *           anlamını yitirir — gerçek eşik deney (b)'de ölçülür. Değerler
 *           derleyiciye, bayraklara ve makineye bağlıdır.)
 */
#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <sys/resource.h>

static uintptr_t adres[3];
static char ziyaret[8];

/* Örnek 5'teki DFS'nin iskeleti: zincirde 3 derinlik iner */
static void dfs(int u, int derinlik)
{
    int yerel = u;                       /* çerçevedeki bir değişken */
    adres[derinlik] = (uintptr_t)&yerel;
    ziyaret[u] = 1;
    if (derinlik < 2 && !ziyaret[u + 1]) {
        dfs(u + 1, derinlik + 1);
    }
}

int main(void)
{
    struct rlimit r;
    dfs(0, 0);
    long fark1 = (long)(adres[0] - adres[1]);
    long fark2 = (long)(adres[1] - adres[2]);
    printf("çerçeve boyu (ardışık çağrıların adres farkı): %ld ve %ld "
           "bayt\n", fark1, fark2);
    if (fark1 <= 0 || fark1 != fark2) {
        printf("ölçülemedi: derleyici çağrıyı açmış olabilir (-O0 ile "
               "derleyin)\n");
        return 0;
    }
    printf("yığın aşağı doğru büyür: evet (önceki çağrının adresi daha "
           "büyük)\n");
    if (getrlimit(RLIMIT_STACK, &r) == 0 && r.rlim_cur != RLIM_INFINITY) {
        printf("yığın sınırı (ulimit -s): %lu KB\n",
               (unsigned long)(r.rlim_cur / 1024));
        printf("kestirilen en büyük derinlik ≈ %lu / %ld ≈ %lu çağrı\n",
               (unsigned long)r.rlim_cur, fark1,
               (unsigned long)(r.rlim_cur / (unsigned long)fark1));
    } else {
        printf("yığın sınırı: sınırsız ya da okunamadı\n");
    }
    printf("(bu derleyicide, bu bayraklarla; deney (b)'nin ölçtüğü eşikle "
           "karşılaştırın)\n");
    return 0;
}

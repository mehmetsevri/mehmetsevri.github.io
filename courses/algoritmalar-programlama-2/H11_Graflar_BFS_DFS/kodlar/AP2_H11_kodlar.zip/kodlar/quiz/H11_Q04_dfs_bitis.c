/* H11_Q04_dfs_bitis.c — AP-2 Hafta 11 · Quiz sorusu 4
 * Amaç    : DFS bitiş sırası ve topolojik sıra (yönlü döngüsüz graf;
 *           komşular artan sırada). Çıktıyı çalıştırmadan tahmin edin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_Q04_dfs_bitis.c -o H11_Q04_dfs_bitis
 */
#include <stdio.h>

#define V 5

/* yönlü kenarlar: 0->1 0->2 1->3 2->3 3->4 */
static const int m[V][V] = {{0, 1, 1, 0, 0}, {0, 0, 0, 1, 0},
                            {0, 0, 0, 1, 0}, {0, 0, 0, 0, 1},
                            {0, 0, 0, 0, 0}};
static int gorulen[V], bitis[V], nb = 0;

static void dfs(int u)
{
    gorulen[u] = 1;
    for (int v = 0; v < V; v++) {
        if (m[u][v] && !gorulen[v]) {
            dfs(v);
        }
    }
    bitis[nb++] = u;                    /* u bitti */
}

int main(void)
{
    dfs(0);
    for (int i = nb - 1; i >= 0; i--) {
        printf("%d ", bitis[i]);
    }
    printf("\n");
    return 0;
}

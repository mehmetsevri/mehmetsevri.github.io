"""H11_Q06_varsayilan.py — AP-2 Hafta 11 · Quiz sorusu 6
Amaç    : Python'da değiştirilebilir varsayılan argüman. Çıktıyı
          çalıştırmadan tahmin edin.
Çalıştır: python3 H11_Q06_varsayilan.py
"""


def ziyaret_et(g, u, gorulen=set()):
    gorulen.add(u)
    for v in g[u]:
        if v not in gorulen:
            ziyaret_et(g, v, gorulen)
    return len(gorulen)


def main():
    G = [[1], [0, 2], [1], [4], [3]]    # 0-1-2 ve 3-4
    print(ziyaret_et(G, 0), ziyaret_et(G, 3))


if __name__ == "__main__":
    main()

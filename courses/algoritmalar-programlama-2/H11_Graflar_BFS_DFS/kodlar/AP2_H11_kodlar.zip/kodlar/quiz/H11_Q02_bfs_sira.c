/* H11_Q02_bfs_sira.c — AP-2 Hafta 11 · Quiz sorusu 2
 * Amaç    : BFS ziyaret sırası (yönsüz graf, komşuluk listesi; listeler
 *           artan sırada). Çıktıyı çalıştırmadan tahmin edin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_Q02_bfs_sira.c -o H11_Q02_bfs_sira
 */
#include <stdio.h>

#define V 6

int main(void)
{
    /* yönsüz kenarlar: 0-2 0-4 1-3 2-3 2-5 4-5 */
    const int komsu[V][3] = {{2, 4, -1}, {3, -1, -1}, {0, 3, 5},
                             {1, 2, -1}, {0, 5, -1}, {2, 4, -1}};
    int gorulen[V] = {0}, q[V], bas = 0, son = 0;
    gorulen[0] = 1;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        printf("%d ", u);
        for (int k = 0; k < 3 && komsu[u][k] != -1; k++) {
            int v = komsu[u][k];
            if (!gorulen[v]) {
                gorulen[v] = 1;
                q[son++] = v;
            }
        }
    }
    printf("\n");
    return 0;
}

"""H11_Q07_matris_takma.py — AP-2 Hafta 11 · Quiz sorusu 7
Amaç    : Komşuluk matrisini Python'da kurmak: * ile satır çoğaltma.
          Çıktıyı çalıştırmadan tahmin edin.
Çalıştır: python3 H11_Q07_matris_takma.py
"""


def main():
    V = 3
    m = [[0] * V] * V
    m[0][1] = 1                         # yalnız 0 -> 1 kenarı mı?
    print(sum(sum(satir) for satir in m))


if __name__ == "__main__":
    main()

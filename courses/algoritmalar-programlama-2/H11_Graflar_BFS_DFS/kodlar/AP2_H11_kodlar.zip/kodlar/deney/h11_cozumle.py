#!/usr/bin/env python3
"""h11_cozumle.py — AP-2 Hafta 11 · Haftanın Deneyi çözümlemesi

Ham CSV'lerden (h11_olcum_calistir.py) özet tabloları, katları, log–log
eğimlerini, kestirimleri ve denetimleri HESAPLAR (elle sayı yok):
  sonuclar/h11_ozet_temsil.csv  dil, yoğunluk, V başına matris / liste /
                                CSR süresi (işlemci ms) ve bayt; katlar
  sonuclar/h11_ozet_derin.csv   (b) süreler ve eşikler
  sonuclar/h11_ozet.json        bütün özet + eğimler + kestirimler
  sonuclar/h11_denetim.json     üç dil / üç temsil aynı BFS sonucu mu vb.
Süre ölçütü: işlemci zamanı ortancası (makinede başka işler çalışıyordu).
Kullanım: python3 h11_cozumle.py
"""
import csv
import json
import math
import os
import statistics
import sys

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def egim(noktalar):
    """log–log en küçük kareler eğimi; noktalar (x, y), y > 0"""
    if len(noktalar) < 2:
        return None
    lx = [math.log(x) for x, _ in noktalar]
    ly = [math.log(y) for _, y in noktalar]
    mx, my = statistics.fmean(lx), statistics.fmean(ly)
    pay = sum((a - mx) * (b - my) for a, b in zip(lx, ly))
    payda = sum((a - mx) ** 2 for a in lx)
    return pay / payda


def main():
    temsil = oku("h11_deney_temsil.csv")
    tekrar = oku("h11_deney_csr_tekrar.csv")
    olculmeyen = oku("h11_deney_olculmeyen.csv")
    derin = oku("h11_deney_derin.csv")
    esik = oku("h11_deney_esik.csv")
    denetim = {}

    # --- (a) özet tablo ---------------------------------------------------
    anahtar = {}
    for r in temsil:
        k = (r["dil"], r["yogunluk"], int(r["V"]))
        d = anahtar.setdefault(k, {"E": int(r["E"])})
        d[r["kip"]] = {"ms": float(r["ortanca_islemci_ms"]),
                       "duvar_ms": float(r["ortanca_duvar_ms"]),
                       "bayt": int(r["bayt"]),
                       "ulasilan": int(r["ulasilan"]),
                       "toplam": int(r["uzaklik_toplami"])}
    # denetim: aynı (yoğunluk, V) için bütün dil ve kiplerde aynı sonuç
    gruplar = {}
    for (dil, yog, V), d in anahtar.items():
        for kip in ("matris", "liste", "csr"):
            if kip in d:
                gruplar.setdefault((yog, V), set()).add(
                    (d["E"], d[kip]["ulasilan"], d[kip]["toplam"]))
    denetim["bfs_sonucu_uc_dil_uc_temsil_ayni"] = all(
        len(s) == 1 for s in gruplar.values())
    denetim["bfs_sonucu_grup_sayisi"] = len(gruplar)
    satirlar = []
    for (dil, yog, V), d in sorted(anahtar.items(),
                                   key=lambda x: (x[0][0], x[0][1],
                                                  x[0][2])):
        s = {"dil": dil, "yogunluk": yog, "V": V, "E": d["E"]}
        for kip in ("matris", "liste", "csr"):
            s[f"{kip}_ms"] = d[kip]["ms"] if kip in d else None
            s[f"{kip}_bayt"] = d[kip]["bayt"] if kip in d else None
        s["matris_liste_sure_kati"] = (s["matris_ms"] / s["liste_ms"]
                                       if s["matris_ms"] and s["liste_ms"]
                                       else None)
        s["liste_csr_sure_kati"] = (s["liste_ms"] / s["csr_ms"]
                                    if s["liste_ms"] and s["csr_ms"]
                                    else None)
        s["matris_liste_bayt_kati"] = (s["matris_bayt"] / s["liste_bayt"]
                                       if s["matris_bayt"] and
                                       s["liste_bayt"] else None)
        s["liste_csr_bayt_kati"] = (s["liste_bayt"] / s["csr_bayt"]
                                    if s["liste_bayt"] and s["csr_bayt"]
                                    else None)
        s["bayt_per_E_liste"] = (s["liste_bayt"] / d["E"]
                                 if s["liste_bayt"] else None)
        satirlar.append(s)
    alanlar = list(satirlar[0].keys())
    with open(os.path.join(SONUC, "h11_ozet_temsil.csv"), "w",
              encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join("" if s[a] is None else
                             (f"{s[a]:.4f}" if isinstance(s[a], float)
                              else str(s[a])) for a in alanlar) + "\n")

    # log–log eğimler (süre ≥ 0,05 ms noktaları)
    egimler = {}
    for dil in ("c", "cpp", "py"):
        for yog in ("seyrek", "yogun"):
            for kip in ("matris", "liste", "csr"):
                nok = [(s["V"], s[f"{kip}_ms"]) for s in satirlar
                       if s["dil"] == dil and s["yogunluk"] == yog and
                       s[f"{kip}_ms"] and s[f"{kip}_ms"] >= 0.05 and
                       s["V"] <= 100000]
                e = egim(nok)
                if e is not None:
                    egimler[f"{dil}/{yog}/{kip}"] = {
                        "egim": round(e, 3),
                        "V_aralik": [nok[0][0], nok[-1][0]],
                        "nokta": len(nok)}

    # kestirimler: ölçülmeyen durumlar (bellek HESAP; Python süre c·n²)
    kestirim = []
    for r in olculmeyen:
        dil, yog, V, kip = r["dil"], r["yogunluk"], int(r["V"]), r["kip"]
        k = {"dil": dil, "yogunluk": yog, "V": V, "kip": kip,
             "gerekli_bayt": int(r["gerekli_bayt"]),
             "gerekli_GB": int(r["gerekli_bayt"]) / 1e9,
             "neden": r["neden"]}
        olc = [s for s in satirlar if s["dil"] == dil and
               s["yogunluk"] == yog and s[f"{kip}_ms"]]
        if olc:
            son = max(olc, key=lambda s: s["V"])
            if kip == "matris" or yog == "yogun":
                k["sure_kestirim_ms"] = son[f"{kip}_ms"] * (V / son["V"]) ** 2
                k["kestirim_tabani"] = f"c·V², V0 = {son['V']}"
            else:
                k["sure_kestirim_ms"] = son[f"{kip}_ms"] * V / son["V"]
                k["kestirim_tabani"] = f"c·V, V0 = {son['V']}"
        kestirim.append(k)

    # --- (c) CSR: üç serinin ortancası ------------------------------------
    seriler = {}
    for r in temsil:
        if r["yogunluk"] == "seyrek" and int(r["V"]) >= 100000 and \
                r["dil"] in ("c", "cpp"):
            seriler.setdefault((r["dil"], int(r["V"]), r["kip"]),
                               []).append(float(r["ortanca_islemci_ms"]))
    for r in tekrar:
        seriler.setdefault((r["dil"], int(r["V"]), r["kip"]),
                           []).append(float(r["ortanca_islemci_ms"]))
    csr = []
    for (dil, V, kip), v in sorted(seriler.items()):
        if kip != "liste":
            continue
        c = seriler[(dil, V, "csr")]
        csr.append({"dil": dil, "V": V, "liste_ms_seriler": v,
                    "csr_ms_seriler": c,
                    "liste_ms": statistics.median(v),
                    "csr_ms": statistics.median(c),
                    "kat": statistics.median(v) / statistics.median(c),
                    "seri_katlari": [a / b for a, b in zip(v, c)]})
    for s in satirlar:                   # Python ve küçük V: tek seri
        if s["yogunluk"] == "seyrek" and s["liste_csr_sure_kati"] and \
                (s["dil"] == "py" or s["V"] < 100000):
            csr.append({"dil": s["dil"], "V": s["V"],
                        "liste_ms": s["liste_ms"], "csr_ms": s["csr_ms"],
                        "kat": s["liste_csr_sure_kati"], "tek_seri": True})
    csr.sort(key=lambda x: (x["dil"], x["V"]))

    # --- (b) derin zincir -------------------------------------------------
    derin_ozet = [{"dil": r["dil"], "kip": r["kip"], "n": int(r["n"]),
                   "ms": float(r["ortanca_islemci_ms"]),
                   "duvar_ms": float(r["ortanca_duvar_ms"]),
                   "ns_kose": float(r["ortanca_islemci_ms"]) * 1e6 /
                   int(r["n"])} for r in derin]
    derin_egim = {}
    for dil in ("c", "cpp", "py"):
        nok = [(d["n"], d["ms"]) for d in derin_ozet
               if d["dil"] == dil and d["kip"] == "yigin" and d["ms"] > 0]
        derin_egim[dil] = round(egim(nok), 3)
    esik_ozet = []
    for r in esik:
        esik_ozet.append({"dil": r["dil"], "derleme": r["derleme"],
                          "ulimit_kb": int(r["ulimit_kb"]),
                          "deneme": int(r["deneme"]),
                          "basarili_n": int(r["esik_basarili_n"]),
                          "ilk_basarisiz_n": int(r["ilk_basarisiz_n"]),
                          "cikis": r["cikis"],
                          "cerceve_bayt": float(r["cerceve_bayt_kestirim"])})
    oran = {}
    for e in esik_ozet:
        if e["ulimit_kb"] == 65536:
            k = [x for x in esik_ozet if x["dil"] == e["dil"] and
                 x["derleme"] == e["derleme"] and x["ulimit_kb"] == 8192]
            oran[f"{e['dil']}{e['derleme']}"] = (
                e["ilk_basarisiz_n"] / statistics.median(
                    x["ilk_basarisiz_n"] for x in k))
    denetim["esik_ulimit_8_kat_orani"] = {k: round(v, 3)
                                          for k, v in oran.items()}
    denetim["derin_ziyaret_n"] = all(int(r["ziyaret"]) == int(r["n"]) ==
                                     int(r["en_derin"]) for r in derin)
    with open(os.path.join(SONUC, "h11_ozet_derin.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;kip;n;islemci_ms;duvar_ms;ns_kose\n")
        for d in derin_ozet:
            f.write(f"{d['dil']};{d['kip']};{d['n']};{d['ms']:.4f};"
                    f"{d['duvar_ms']:.4f};{d['ns_kose']:.2f}\n")

    ozet = {"temsil": satirlar, "egimler": egimler, "kestirim": kestirim,
            "csr": csr, "derin": derin_ozet, "derin_egim": derin_egim,
            "esik": esik_ozet}
    json.dump(ozet, open(os.path.join(SONUC, "h11_ozet.json"), "w",
                         encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(denetim, open(os.path.join(SONUC, "h11_denetim.json"), "w",
                            encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(denetim, ensure_ascii=False))
    print("eğimler:", {k: v["egim"] for k, v in egimler.items()})
    return 0


if __name__ == "__main__":
    sys.exit(main())

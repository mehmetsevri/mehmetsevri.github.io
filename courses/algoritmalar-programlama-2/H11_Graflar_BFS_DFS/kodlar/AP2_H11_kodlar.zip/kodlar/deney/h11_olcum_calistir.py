#!/usr/bin/env python3
"""h11_olcum_calistir.py — AP-2 Hafta 11 · Haftanın Deneyi sürücüsü

Derler, çalıştırır ve ham sonuçları sonuclar/*.csv dosyalarına yazar:
  (a) h11_deney_temsil.csv   komşuluk matrisi / listesi / CSR ile BFS(0):
                             seyrek (E ≈ 4V) V = 10^3 … 10^5 ve yoğun
                             (E ≈ V²/4) V = 10^3 … 10^4; süre + bayt
      h11_deney_olculmeyen.csv  bellek bütçesini (süreç başına 1,5 GB)
                             aşan ya da Python süre bütçesini aşan
                             durumlar: gerekli bellek HESAPLANIR
  (c) aynı CSV'de V = 3·10^5 ve 10^6 (liste ve CSR; Python 3·10^5'e dek)
      h11_deney_csr_tekrar.csv  C ve C++'ta V = 10^5 … 10^6 iki seri daha
                             (gürültülü makinede tutarlılık denetimi)
  (b) h11_deney_derin.csv    zincirde özyinelemeli / açık yığınlı DFS süresi
      h11_deney_esik.csv     özyinelemeli DFS'nin çöktüğü en küçük n:
                             C ve C++ (-O0, -O2) × ulimit -s 8192 / 65536 KB
                             (ikili arama, her n ayrı süreç); Python'da
                             RecursionError sınırı
Ölçüm: 1 ısınma + 5 tekrar, ortanca; duvar saati ve işlemci zamanı.
Ortam bilgisi: OLCUM_ORTAMI.txt; denetimler: sonuclar/h11_denetim.json.
Kullanım: python3 h11_olcum_calistir.py      (≈ 3–4 dk)
Sonra   : python3 h11_cozumle.py ; python3 ../../gorseller/kaynak/
          h11_deney_grafik.py
"""
import datetime
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import tempfile
import time

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]
TEKRAR = 5
BUTCE = 1.5e9                            # süreç başına bellek bütçesi
SEYREK = [1000, 2000, 5000, 10000, 20000, 50000, 100000]
YOGUN = [1000, 2000, 5000, 10000, 20000, 50000, 100000]
CSR_EK = [300000, 1000000]
PY_SEYREK_MATRIS = 5000                  # Python süre bütçesi sınırları
PY_YOGUN = 2000
PY_CSR_EK = [300000]
DERIN = [1000, 10000, 100000, 1000000]
BASLIK_TEMSIL = ("dil;derleme;yogunluk;V;E;kip;bayt;tekrar;ortanca_duvar_ms;"
                 "ortanca_islemci_ms;ulasilan;uzaklik_toplami\n")
BASLIK_DERIN = ("dil;derleme;kip;n;tekrar;ortanca_duvar_ms;"
                "ortanca_islemci_ms;ziyaret;en_derin\n")


def kabuk(komut, **kw):
    return subprocess.run(komut, capture_output=True, text=True, **kw)


def derle(gecici):
    ikili = {}
    for ad in ("H11_deney_temsil", "H11_deney_derin"):
        for bayrak in ("-O2", "-O0"):
            hedef = os.path.join(gecici, f"{ad}_c{bayrak}")
            p = kabuk(C + [bayrak, f'-DDERLEME="{bayrak}"',
                           os.path.join(KOK, "c", ad + ".c"),
                           os.path.join(KOK, "c", "ortak_rastgele.c"),
                           os.path.join(KOK, "c", "zamanlayici.c"),
                           "-o", hedef])
            assert p.returncode == 0 and not p.stderr.strip(), p.stderr
            ikili[(ad, "c", bayrak)] = [hedef]
            hedef = os.path.join(gecici, f"{ad}_cpp{bayrak}")
            p = kabuk(CPP + [bayrak, os.path.join(KOK, "cpp", ad + ".cpp"),
                             "-o", hedef])
            assert p.returncode == 0 and not p.stderr.strip(), p.stderr
            ikili[(ad, "cpp", bayrak)] = [hedef]
        ikili[(ad, "py", "-")] = [sys.executable,
                                  os.path.join(KOK, "python", ad + ".py")]
    return ikili


def calistir(komut, ulimit=None):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
    if ulimit is not None:
        komut = ["bash", "-c", f"ulimit -s {ulimit} && exec \"$@\"", "_"] + \
            komut
    p = subprocess.run(komut, capture_output=True, text=True, env=env,
                       timeout=600)
    return p.returncode, p.stdout, p.stderr


YOGUN_UST = 10000                        # yoğunda kenar dizisi + temsil


def gerekli_bayt(V, yog, kip):
    """Temsilin kuramsal bayt sayısı (int = 4, matris hücresi = 1 bayt,
    liste başı = 24 bayt; liste kapasite artığı hariç)"""
    E = V * (V - 1) // 4 if yog == "yogun" else 4 * V
    return {"matris": V * V, "liste": V * 24 + 2 * E * 4,
            "csr": 4 * (V + 1) + 8 * E}[kip]


def plan(dil, yog, V):
    """Ölçülecek kipler ve ölçülmeyenler (kip, neden)"""
    ek = V in CSR_EK
    kipler, atla = [], []
    adaylar = ["liste", "csr"] if ek else ["matris", "liste", "csr"]
    for kip in adaylar:
        if yog == "yogun" and V > YOGUN_UST:
            atla.append((kip, "bellek bütçesi: kenar dizisi (E·8 bayt) + "
                         "temsil 1,5 GB'ı aşar"))
        elif kip == "matris" and gerekli_bayt(V, yog, kip) > BUTCE:
            atla.append((kip, "bellek bütçesi (1,5 GB) aşılır"))
        elif dil == "py" and ((kip == "matris" and V > PY_SEYREK_MATRIS)
                              or (yog == "yogun" and V > PY_YOGUN)):
            atla.append((kip, "Python süre bütçesi (kestirim)"))
        else:
            kipler.append(kip)
    return kipler, atla


def temsil_olc(ikili, csv, olculmeyen, gunluk):
    for dil, derleme in (("c", "-O2"), ("cpp", "-O2"), ("py", "-")):
        prog = ikili[("H11_deney_temsil", dil, derleme)]
        for yog, Vs in (("seyrek", SEYREK + CSR_EK), ("yogun", YOGUN)):
            for V in Vs:
                if dil == "py" and V in CSR_EK and V not in PY_CSR_EK:
                    continue
                kipler, atla = plan(dil, yog, V)
                for kip, neden in atla:
                    olculmeyen.append((dil, yog, V, kip,
                                       gerekli_bayt(V, yog, kip), neden))
                if not kipler:
                    continue
                kod, out, err = calistir(prog + [str(V), yog,
                                                 ",".join(kipler),
                                                 str(TEKRAR), csv])
                gunluk.append(f"temsil {dil} {yog} {V} {kipler}: kod {kod}")
                gunluk += ["  " + s for s in out.strip().split("\n")]
                assert kod == 0, err


def csr_tekrar_olc(ikili, gecici, gunluk):
    """(c) gürültüye karşı: C ve C++'ta V = 10^5, 3·10^5, 10^6 için liste
    ve CSR iki kez daha ölçülür (seri 2 ve 3); seri 1 ana CSV'dedir."""
    hedef = os.path.join(SONUC, "h11_deney_csr_tekrar.csv")
    with open(hedef, "w", encoding="utf-8") as f:
        f.write("seri;" + BASLIK_TEMSIL)
    for seri in (2, 3):
        for dil in ("c", "cpp"):
            prog = ikili[("H11_deney_temsil", dil, "-O2")]
            for V in [100000] + CSR_EK:
                ara = os.path.join(gecici, "csr.csv")
                if os.path.exists(ara):
                    os.remove(ara)
                kod, out, err = calistir(prog + [str(V), "seyrek",
                                                 "liste,csr", str(TEKRAR),
                                                 ara])
                assert kod == 0, err
                with open(hedef, "a", encoding="utf-8") as f:
                    for satir in open(ara, encoding="utf-8"):
                        f.write(f"{seri};{satir}")
                gunluk.append(f"csr tekrar {seri} {dil} {V}: kod {kod}")


def derin_olc(ikili, csv, gunluk):
    for dil, derleme in (("c", "-O2"), ("cpp", "-O2"), ("py", "-")):
        prog = ikili[("H11_deney_derin", dil, derleme)]
        for kip in ("yigin", "ozyinelemeli"):
            for n in DERIN:
                if kip == "ozyinelemeli" and (n > 100000 or
                                              (dil == "py" and n > 500)):
                    continue             # eşik üstü: aşağıda ayrıca
                kod, out, err = calistir(prog + [kip, str(n), str(TEKRAR),
                                                 csv])
                gunluk.append(f"derin {dil} {kip} {n}: kod {kod} "
                              + out.strip())
                assert kod == 0, err
    # Python: varsayılan sınırın altında bir özyinelemeli ölçüm (n = 500)
    prog = ikili[("H11_deney_derin", "py", "-")]
    kod, out, err = calistir(prog + ["ozyinelemeli", "500", str(TEKRAR),
                                     csv])
    assert kod == 0, err


def basarili_mi(prog, n, ulimit):
    kod, _, err = calistir(prog + ["ozyinelemeli", str(n), "0"], ulimit)
    return kod == 0, kod, ("RecursionError" in err)


def esik_bul(prog, ulimit, alt=1000, ust_bas=100000, ust_sinir=40000000):
    """En büyük başarılı n ve ilk başarısız n (ikili arama)."""
    ust = ust_bas
    while basarili_mi(prog, ust, ulimit)[0]:
        alt = ust
        ust *= 2
        if ust > ust_sinir:
            return alt, None, 0
    kod = basarili_mi(prog, ust, ulimit)[1]
    while ust - alt > 1:
        orta = (alt + ust) // 2
        if basarili_mi(prog, orta, ulimit)[0]:
            alt = orta
        else:
            ust = orta
    return alt, ust, kod


def esik_olc(ikili, gunluk):
    satir = ["dil;derleme;ulimit_kb;deneme;esik_basarili_n;ilk_basarisiz_n;"
             "cikis;cerceve_bayt_kestirim\n"]
    for dil in ("c", "cpp"):
        for derleme in ("-O0", "-O2"):
            prog = ikili[("H11_deney_derin", dil, derleme)]
            for ulimit, denemeler in ((8192, 2), (65536, 1)):
                for d in range(1, denemeler + 1):
                    alt, ust, kod = esik_bul(prog, ulimit)
                    cerceve = ulimit * 1024 / ust if ust else 0
                    satir.append(f"{dil};{derleme};{ulimit};{d};{alt};{ust};"
                                 f"{kod};{cerceve:.1f}\n")
                    gunluk.append(f"eşik {dil} {derleme} ulimit {ulimit} "
                                  f"deneme {d}: başarılı {alt}, ilk "
                                  f"başarısız {ust} (çıkış {kod})")
    prog = ikili[("H11_deney_derin", "py", "-")]
    alt, ust = 100, 5000
    while ust - alt > 1:
        orta = (alt + ust) // 2
        if basarili_mi(prog, orta, None)[0]:
            alt = orta
        else:
            ust = orta
    hata = basarili_mi(prog, ust, None)
    satir.append(f"py;-;8192;1;{alt};{ust};"
                 f"{'RecursionError' if hata[2] else hata[1]};0\n")
    gunluk.append(f"eşik py: başarılı {alt}, ilk başarısız {ust}")
    with open(os.path.join(SONUC, "h11_deney_esik.csv"), "w",
              encoding="utf-8") as f:
        f.writelines(satir)


def ortam_bilgisi(bas, son, yuk_once, yuk_sonra, evre, maks_rss):
    model = "?"
    for s in kabuk(["lscpu"]).stdout.splitlines():
        if s.startswith("Model name:"):
            model = s.split(":", 1)[1].strip()
    gcc = kabuk(["gcc", "--version"]).stdout.splitlines()[0]
    gpp = kabuk(["g++", "--version"]).stdout.splitlines()[0]
    yigin = kabuk(["bash", "-c", "ulimit -s"]).stdout.strip()
    toplam = (son - bas).total_seconds()
    satir = [
        "AP-2 Hafta 11 · Haftanın Deneyi — ölçüm ortamı",
        f"Tarih          : {bas:%Y-%m-%d %H:%M} – {son:%H:%M}",
        f"İşlemci        : {model}",
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine)",
        f"Yük ortalaması : önce {yuk_once} · sonra {yuk_sonra} "
        "(/proc/loadavg: 1, 5, 15 dk)",
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})",
        f"C derleyicisi  : {gcc}",
        f"C++ derleyicisi: {gpp}",
        f"Python         : Python {platform.python_version()}",
        "Bayraklar      : -std=c17 / -std=c++17 -Wall -Wextra -pedantic "
        "-O2 (eşik aramasında ayrıca -O0)",
        "Yöntem         : 1 ısınma + 5 tekrar, ortanca; duvar saati ve "
        "işlemci zamanı birlikte kaydedildi",
        "Saat           : duvar C timespec_get, C++ steady_clock, Python "
        "time.perf_counter; işlemci C/C++ clock(), Python "
        "time.process_time",
        "Bellek (temsil): C ayrılan bayt sayacı (calloc/realloc); C++ "
        "vektör kapasitelerinden hesaplanan; Python tracemalloc "
        "(temsil kurulurken; CPython 3.11)",
        f"Yığın sınırı   : ulimit -s = {yigin} KB (varsayılan); eşik "
        "aramasında 8192 ve 65536 KB",
        f"Tepe RSS       : en büyük alt sürecin tepe yerleşik belleği "
        f"{maks_rss / 1024:.0f} MB (getrusage RUSAGE_CHILDREN, ru_maxrss)",
        f"Toplam süre    : {toplam:.1f} s (sürücünün duvar saati)",
        "Evre süreleri  : " + " · ".join(f"{a} {b:.1f} s"
                                          for a, b in evre),
        "Not            : ölçüm sırasında makinede başka işler de "
        "çalışıyordu (yük ortalamasına bakınız);",
        "                 çözümlemede işlemci zamanı kullanılır.",
    ]
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(satir) + "\n")


def main():
    os.makedirs(SONUC, exist_ok=True)
    bas = datetime.datetime.now()
    t0 = time.time()
    yuk_once = open("/proc/loadavg").read().split()[:3]
    gecici = tempfile.mkdtemp(prefix="h11_deney_")
    gunluk, olculmeyen, evre = [], [], []
    csv_t = os.path.join(SONUC, "h11_deney_temsil.csv")
    csv_d = os.path.join(SONUC, "h11_deney_derin.csv")
    for yol, baslik in ((csv_t, BASLIK_TEMSIL), (csv_d, BASLIK_DERIN)):
        with open(yol, "w", encoding="utf-8") as f:
            f.write(baslik)
    try:
        ikili = derle(gecici)
        evre.append(("derleme", time.time() - t0))
        t = time.time()
        temsil_olc(ikili, csv_t, olculmeyen, gunluk)
        evre.append(("(a)+(c) temsil", time.time() - t))
        t = time.time()
        csr_tekrar_olc(ikili, gecici, gunluk)
        evre.append(("(c) tekrar", time.time() - t))
        t = time.time()
        derin_olc(ikili, csv_d, gunluk)
        evre.append(("(b) süre", time.time() - t))
        t = time.time()
        esik_olc(ikili, gunluk)
        evre.append(("(b) eşik", time.time() - t))
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    with open(os.path.join(SONUC, "h11_deney_olculmeyen.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;yogunluk;V;kip;gerekli_bayt;neden\n")
        for s in olculmeyen:
            f.write(";".join(str(x) for x in s) + "\n")
    yuk_sonra = open("/proc/loadavg").read().split()[:3]
    maks = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    ortam_bilgisi(bas, datetime.datetime.now(), " ".join(yuk_once),
                  " ".join(yuk_sonra), evre, maks)
    with open(os.path.join(SONUC, "h11_olcum_gunlugu.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(gunluk) + "\n")
    print(f"bitti: {time.time() - t0:.1f} s; " +
          ", ".join(f"{a} {b:.1f} s" for a, b in evre))
    return 0


if __name__ == "__main__":
    sys.exit(main())

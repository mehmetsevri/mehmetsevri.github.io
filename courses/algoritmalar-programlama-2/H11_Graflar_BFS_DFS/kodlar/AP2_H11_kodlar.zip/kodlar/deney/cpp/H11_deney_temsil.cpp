/* H11_deney_temsil.cpp — AP-2 Hafta 11 · Haftanın Deneyi (a) ve (c)
 * Amaç    : Aynı graf (ortak LCG) üç temsilde: komşuluk matrisi (V × V
 *           bayt), komşuluk listesi (std::vector<std::vector<int>>) ve CSR
 *           (tek bitişik dizi). Her temsilde BFS(0) süresi (1 ısınma +
 *           TEKRAR, ortanca) ve bellek: vektör kapasitelerinden HESAPLANAN
 *           bayt (V * sizeof(std::vector<int>) + Σ capacity * 4).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_deney_temsil.cpp -o H11_deney_temsil
 * Çalıştır: ./H11_deney_temsil V seyrek|yogun matris,liste,csr TEKRAR CSV
 * Çıktı   : stdout deterministik; süreler yalnız CSV dosyasına
 */
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

struct Kenar {
    int u, v;
    bool operator<(const Kenar& o) const
    {
        return u != o.u ? u < o.u : v < o.v;
    }
    bool operator==(const Kenar& o) const { return u == o.u && v == o.v; }
};

// Kenar listesi (u < v, tekil, sıralı)
static std::vector<Kenar> graf_uret(int V, bool yogun)
{
    std::vector<Kenar> k;
    rastgele_tohum(42);
    if (yogun) {
        for (int u = 0; u < V; u++) {
            for (int v = u + 1; v < V; v++) {
                if (rastgele_sayi() % 2 == 1) {
                    k.push_back({u, v});
                }
            }
        }
        return k;
    }
    for (int v = 1; v < V; v++) {            // kapsayan ağaç: bağlı
        k.push_back({rastgele_aralik(0, v - 1), v});
    }
    for (long i = 0; i < 3L * V; i++) {
        int a = rastgele_aralik(0, V - 1), b = rastgele_aralik(0, V - 1);
        if (a != b) {
            k.push_back({std::min(a, b), std::max(a, b)});
        }
    }
    std::sort(k.begin(), k.end());
    k.erase(std::unique(k.begin(), k.end()), k.end());
    return k;
}

struct Temsil {
    int V = 0;
    std::vector<unsigned char> matris;           // V × V
    std::vector<std::vector<int>> liste;
    std::vector<int> csr_bas, csr_komsu;         // V + 1 ve 2E
};

static std::vector<int> uzak, q;
static long sonuc_ulasilan;
static long long sonuc_toplam;

static void bfs_bitir(int son)
{
    long long t = 0;
    for (int i = 0; i < son; i++) {
        t += uzak[q[i]];
    }
    sonuc_ulasilan = son;
    sonuc_toplam = t;
}

// Matris: her çıkan köşe için satırın TAMAMI taranır: Θ(V²)
static void bfs_matris(const Temsil& t)
{
    int V = t.V, bas = 0, son = 0;
    std::fill(uzak.begin(), uzak.end(), -1);
    uzak[0] = 0;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        const unsigned char *satir = &t.matris[std::size_t(u) * V];
        for (int v = 0; v < V; v++) {
            if (satir[v] && uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q[son++] = v;
            }
        }
    }
    bfs_bitir(son);
}

// Liste: yalnız gerçek komşular: Θ(V + E)
static void bfs_liste(const Temsil& t)
{
    int bas = 0, son = 0;
    std::fill(uzak.begin(), uzak.end(), -1);
    uzak[0] = 0;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        for (int v : t.liste[u]) {
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q[son++] = v;
            }
        }
    }
    bfs_bitir(son);
}

// CSR: u'nun komşuları csr_komsu[csr_bas[u] .. csr_bas[u + 1] - 1]
static void bfs_csr(const Temsil& t)
{
    int bas = 0, son = 0;
    std::fill(uzak.begin(), uzak.end(), -1);
    uzak[0] = 0;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        for (int i = t.csr_bas[u]; i < t.csr_bas[u + 1]; i++) {
            int v = t.csr_komsu[i];
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q[son++] = v;
            }
        }
    }
    bfs_bitir(son);
}

static void bfs_calistir(const Temsil& t, const std::string& kip)
{
    if (kip == "matris") {
        bfs_matris(t);
    } else if (kip == "liste") {
        bfs_liste(t);
    } else {
        bfs_csr(t);
    }
}

// Temsili kurar; hesaplanan bayt sayısını döndürür
static long long kur(Temsil& t, const std::string& kip,
                     const std::vector<Kenar>& k)
{
    int V = t.V;
    if (kip == "matris") {
        t.matris.assign(std::size_t(V) * V, 0);
        for (const Kenar& e : k) {
            t.matris[std::size_t(e.u) * V + e.v] = 1;
            t.matris[std::size_t(e.v) * V + e.u] = 1;
        }
        return static_cast<long long>(t.matris.capacity());
    }
    if (kip == "liste") {
        t.liste.assign(V, std::vector<int>());
        for (const Kenar& e : k) {
            t.liste[e.u].push_back(e.v);
            t.liste[e.v].push_back(e.u);
        }
        long long bayt = static_cast<long long>(V) *
                         static_cast<long long>(sizeof(std::vector<int>));
        for (const auto& l : t.liste) {
            bayt += static_cast<long long>(l.capacity() * sizeof(int));
        }
        return bayt;
    }
    t.csr_bas.assign(V + 1, 0);              // say, önek topla, doldur
    t.csr_komsu.assign(2 * k.size(), 0);
    for (const Kenar& e : k) {
        t.csr_bas[e.u + 1]++;
        t.csr_bas[e.v + 1]++;
    }
    for (int u = 0; u < V; u++) {
        t.csr_bas[u + 1] += t.csr_bas[u];
    }
    std::vector<int> yer(t.csr_bas.begin(), t.csr_bas.end() - 1);
    for (const Kenar& e : k) {
        t.csr_komsu[yer[e.u]++] = e.v;
        t.csr_komsu[yer[e.v]++] = e.u;
    }
    return static_cast<long long>((t.csr_bas.capacity() +
                                   t.csr_komsu.capacity()) * sizeof(int));
}

int main(int argc, char *argv[])
{
    if (argc != 6) {
        std::cerr << "Kullanım: H11_deney_temsil V seyrek|yogun "
                     "matris,liste,csr TEKRAR CSV\n";
        return 2;
    }
    long V = std::strtol(argv[1], nullptr, 10);
    long tekrar = std::strtol(argv[4], nullptr, 10);
    std::string yogunluk = argv[2];
    if (V < 2 || V > 2000000 || tekrar < 1 || tekrar > 101 ||
        (yogunluk != "seyrek" && yogunluk != "yogun")) {
        std::cerr << "geçersiz argüman\n";
        return 2;
    }
    std::vector<Kenar> k = graf_uret(static_cast<int>(V),
                                     yogunluk == "yogun");
    std::ofstream csv(argv[5], std::ios::app);
    uzak.assign(V, 0);
    q.assign(V, 0);
    std::stringstream kipler(argv[3]);
    std::string kip;
    while (std::getline(kipler, kip, ',')) {
        Temsil t;
        t.V = static_cast<int>(V);
        long long bayt = kur(t, kip, k);
        std::vector<double> duvar, islemci;
        bfs_calistir(t, kip);                // ısınma
        for (long r = 0; r < tekrar; r++) {
            double t0 = zaman_sn(), c0 = islemci_sn();
            bfs_calistir(t, kip);
            duvar.push_back(zaman_sn() - t0);
            islemci.push_back(islemci_sn() - c0);
        }
        std::cout << "V = " << V << ", " << yogunluk << ", E = " << k.size()
                  << ", " << kip << ": ulaşılan = " << sonuc_ulasilan
                  << ", uzaklık toplamı = " << sonuc_toplam
                  << ", bayt = " << bayt << '\n';
        csv << "cpp;-O2;" << yogunluk << ';' << V << ';' << k.size() << ';'
            << kip << ';' << bayt << ';' << tekrar << ';' << std::fixed
            << std::setprecision(4) << ortanca(duvar) * 1000.0 << ';'
            << ortanca(islemci) * 1000.0 << ';' << sonuc_ulasilan << ';'
            << sonuc_toplam << '\n';
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — Boost.Graph adjacency_list,
 * adjacency_matrix, compressed_sparse_row_graph; Python — scipy.sparse
 * csr_matrix ve networkx (ders dışı; yalnız karşılaştırma için). */

/* H11_deney_derin.cpp — AP-2 Hafta 11 · Haftanın Deneyi (b)
 * Amaç    : n köşelik zincirde (0 - 1 - ... - n-1; CSR ile saklanır) DFS:
 *           özyinelemeli sürüm n derinliğe iner (çağrı yığını, ulimit -s
 *           ile sınırlı); açık yığınlı sürüm çerçeveleri std::vector'de
 *           (öbekte) tutar. TEKRAR = 0: tek çalıştırma (çökme eşiği için).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_deney_derin.cpp -o H11_deney_derin
 * Çalıştır: ./H11_deney_derin ozyinelemeli|yigin n TEKRAR [CSV]
 * Çıktı   : stdout: ziyaret ve en büyük derinlik; süreler yalnız CSV'ye
 */
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "zamanlayici.hpp"

static std::vector<int> bas, komsu;      // CSR: zincir
static std::vector<char> ziyaret;
static long ziyaret_sayisi, en_derin;

static void dfs_ozy(int u, long derinlik)
{
    ziyaret[u] = 1;
    ziyaret_sayisi++;
    en_derin = std::max(en_derin, derinlik);
    for (int i = bas[u]; i < bas[u + 1]; i++) {
        int v = komsu[i];
        if (!ziyaret[v]) {
            dfs_ozy(v, derinlik + 1);    // her çağrı bir yığın çerçevesi
        }
    }
}

struct Cerceve {
    int u, i;                            // köşe, sıradaki komşu indisi
};

static void dfs_yigin(int kok)
{
    std::vector<Cerceve> yigin;          // öbekte büyür
    ziyaret[kok] = 1;
    ziyaret_sayisi = 1;
    yigin.push_back({kok, bas[kok]});
    while (!yigin.empty()) {
        en_derin = std::max(en_derin, static_cast<long>(yigin.size()));
        Cerceve& c = yigin.back();
        if (c.i == bas[c.u + 1]) {
            yigin.pop_back();            // komşu kalmadı
            continue;
        }
        int v = komsu[c.i++];
        if (!ziyaret[v]) {
            ziyaret[v] = 1;
            ziyaret_sayisi++;
            yigin.push_back({v, bas[v]});
        }
    }
}

int main(int argc, char *argv[])
{
    if (argc < 4 || argc > 5) {
        std::cerr << "Kullanım: H11_deney_derin ozyinelemeli|yigin n "
                     "TEKRAR [CSV]\n";
        return 2;
    }
    std::string kip = argv[1];
    long n = std::strtol(argv[2], nullptr, 10);
    long tekrar = std::strtol(argv[3], nullptr, 10);
    if (n < 2 || n > 50000000 || tekrar < 0 || tekrar > 101) {
        std::cerr << "geçersiz argüman\n";
        return 2;
    }
    for (int u = 0; u < n; u++) {        // zincir: u - 1 ve u + 1
        bas.push_back(static_cast<int>(komsu.size()));
        if (u > 0) {
            komsu.push_back(u - 1);
        }
        if (u + 1 < n) {
            komsu.push_back(u + 1);
        }
    }
    bas.push_back(static_cast<int>(komsu.size()));
    auto calistir = [&]() {
        ziyaret.assign(n, 0);
        ziyaret_sayisi = en_derin = 0;
        if (kip == "ozyinelemeli") {
            dfs_ozy(0, 1);
        } else {
            dfs_yigin(0);
        }
    };
    if (tekrar == 0) {
        std::cout << kip << " n = " << n << " başlıyor" << std::endl;
        calistir();
    } else {
        std::vector<double> duvar, islemci;
        calistir();                      // ısınma
        for (long r = 0; r < tekrar; r++) {
            double t0 = zaman_sn(), c0 = islemci_sn();
            calistir();
            duvar.push_back(zaman_sn() - t0);
            islemci.push_back(islemci_sn() - c0);
        }
        if (argc == 5) {
            std::ofstream csv(argv[4], std::ios::app);
            csv << "cpp;-O2;" << kip << ';' << n << ';' << tekrar << ';'
                << std::fixed << std::setprecision(4)
                << ortanca(duvar) * 1000.0 << ';'
                << ortanca(islemci) * 1000.0 << ';' << ziyaret_sayisi
                << ';' << en_derin << '\n';
        }
    }
    std::cout << kip << " n = " << n << ": ziyaret = " << ziyaret_sayisi
              << ", en büyük derinlik = " << en_derin << '\n';
    return 0;
}

/* Kütüphane karşılığı: yok. Not: yığın boyutu Linux'ta ulimit -s ile
 * değiştirilebilir; üretim kodunda derin özyineleme yerine açık yığın
 * tercih edilir. */

/* H11_deney_derin.c — AP-2 Hafta 11 · Haftanın Deneyi (b)
 * Amaç    : n köşelik zincirde (0 - 1 - ... - n-1; CSR ile saklanır) DFS:
 *           özyinelemeli sürüm n derinliğe iner (çağrı yığını, ulimit -s
 *           ile sınırlı); açık yığınlı sürüm çerçeveleri öbekte tutar.
 *           TEKRAR = 0: tek çalıştırma, süre yok (çökme eşiği aramak için;
 *           sürücü ulimit -s ve n'yi değiştirerek çağırır).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H11_deney_derin.c \
 *           zamanlayici.c -o H11_deney_derin
 * Çalıştır: ./H11_deney_derin ozyinelemeli|yigin n TEKRAR [CSV]
 * Çıktı   : stdout: ziyaret ve en büyük derinlik; süreler yalnız CSV'ye
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "zamanlayici.h"

#ifndef DERLEME
#define DERLEME "-O2"
#endif

static int n;
static int *bas, *komsu;                 /* CSR: zincir */
static char *ziyaret;
static long ziyaret_sayisi, en_derin;

static void dfs_ozy(int u, long derinlik)
{
    ziyaret[u] = 1;
    ziyaret_sayisi++;
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    for (int i = bas[u]; i < bas[u + 1]; i++) {
        int v = komsu[i];
        if (!ziyaret[v]) {
            dfs_ozy(v, derinlik + 1);    /* her çağrı bir yığın çerçevesi */
        }
    }
}

typedef struct {
    int u, i;                            /* köşe, sıradaki komşu indisi */
} Cerceve;

static Cerceve *yigin;

static void dfs_yigin(int kok)
{
    long top = 0;
    ziyaret[kok] = 1;
    ziyaret_sayisi = 1;
    yigin[top++] = (Cerceve){kok, bas[kok]};
    while (top > 0) {
        Cerceve *c = &yigin[top - 1];
        if (top > en_derin) {
            en_derin = top;
        }
        if (c->i == bas[c->u + 1]) {
            top--;                       /* komşu kalmadı */
            continue;
        }
        int v = komsu[c->i++];
        if (!ziyaret[v]) {
            ziyaret[v] = 1;
            ziyaret_sayisi++;
            yigin[top++] = (Cerceve){v, bas[v]};
        }
    }
}

static int ozyinelemeli;

static void calistir(void *veri)
{
    (void)veri;
    memset(ziyaret, 0, (size_t)n);
    ziyaret_sayisi = en_derin = 0;
    if (ozyinelemeli) {
        dfs_ozy(0, 1);
    } else {
        dfs_yigin(0);
    }
}

int main(int argc, char *argv[])
{
    if (argc < 4 || argc > 5) {
        fprintf(stderr, "Kullanım: H11_deney_derin ozyinelemeli|yigin n "
                "TEKRAR [CSV]\n");
        return 2;
    }
    ozyinelemeli = strcmp(argv[1], "ozyinelemeli") == 0;
    long nn = strtol(argv[2], NULL, 10), tekrar = strtol(argv[3], NULL, 10);
    if (nn < 2 || nn > 50000000 || tekrar < 0 || tekrar > 101) {
        fprintf(stderr, "geçersiz argüman\n");
        return 2;
    }
    n = (int)nn;
    bas = malloc(((size_t)n + 1) * sizeof(int));
    komsu = malloc(2 * (size_t)n * sizeof(int));
    ziyaret = malloc((size_t)n);
    yigin = malloc((size_t)n * sizeof(Cerceve));
    if (!bas || !komsu || !ziyaret || !yigin) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    int k = 0;
    for (int u = 0; u < n; u++) {        /* zincir: u - 1 ve u + 1 */
        bas[u] = k;
        if (u > 0) {
            komsu[k++] = u - 1;
        }
        if (u + 1 < n) {
            komsu[k++] = u + 1;
        }
    }
    bas[n] = k;
    if (tekrar == 0) {
        printf("%s n = %d başlıyor\n", argv[1], n);
        fflush(stdout);                  /* çökerse bu satır görünsün */
        calistir(NULL);
    } else {
        double duvar[101], islemci[101];
        calistir(NULL);                  /* ısınma */
        for (long r = 0; r < tekrar; r++) {
            double t0 = zaman_sn(), c0 = islemci_sn();
            calistir(NULL);
            duvar[r] = zaman_sn() - t0;
            islemci[r] = islemci_sn() - c0;
        }
        if (argc == 5) {
            FILE *csv = fopen(argv[4], "a");
            if (csv != NULL) {
                fprintf(csv, "c;%s;%s;%d;%ld;%.4f;%.4f;%ld;%ld\n", DERLEME,
                        argv[1], n, tekrar,
                        ortanca(duvar, (int)tekrar) * 1000.0,
                        ortanca(islemci, (int)tekrar) * 1000.0,
                        ziyaret_sayisi, en_derin);
                fclose(csv);
            }
        }
    }
    printf("%s n = %d: ziyaret = %ld, en büyük derinlik = %ld\n", argv[1],
           n, ziyaret_sayisi, en_derin);
    free(bas);
    free(komsu);
    free(ziyaret);
    free(yigin);
    return 0;
}

/* Kütüphane karşılığı: yok. Not: yığın boyutu Linux'ta ulimit -s ile
 * (ya da setrlimit/pthread_attr_setstacksize ile) değiştirilebilir;
 * üretim kodunda derin özyineleme yerine açık yığın tercih edilir. */

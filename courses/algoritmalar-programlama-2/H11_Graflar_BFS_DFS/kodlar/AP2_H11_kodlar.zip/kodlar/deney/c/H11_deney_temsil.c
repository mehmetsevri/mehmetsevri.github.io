/* H11_deney_temsil.c — AP-2 Hafta 11 · Haftanın Deneyi (a) ve (c)
 * Amaç    : Aynı graf (ortak LCG) üç temsilde: komşuluk matrisi (V × V
 *           bayt), komşuluk listesi (H8 dinamik dizileri) ve CSR (tek
 *           bitişik dizi). Her temsilde BFS(0) süresi (1 ısınma + TEKRAR,
 *           ortanca; duvar ve işlemci) ve temsilin ayrılan bayt sayısı.
 *           seyrek: rastgele kapsayan ağaç + 3V rastgele kenar (E ≈ 4V);
 *           yogun : her u < v çifti 1/2 olasılıkla (E ≈ V²/4).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H11_deney_temsil.c \
 *           ortak_rastgele.c zamanlayici.c -o H11_deney_temsil
 * Çalıştır: ./H11_deney_temsil V seyrek|yogun matris,liste,csr TEKRAR CSV
 * Çıktı   : stdout deterministik (E, ulaşılan, uzaklık toplamı, bayt);
 *           süreler yalnız CSV dosyasına (sona eklenir)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#ifndef DERLEME
#define DERLEME "-O2"
#endif

typedef struct {
    int u, v;
} Kenar;

typedef struct {
    int *veri;
    size_t boyut, kapasite;
} KomsuDizisi;

static long long ayrilan_bayt = 0;       /* temsilin bayt sayacı */

static void bellek_yok(void)
{
    fprintf(stderr, "bellek yetersiz\n");
    exit(1);
}

static void *sayacli_ayir(size_t bayt)
{
    void *p = calloc(bayt ? bayt : 1, 1);
    if (p == NULL) {
        bellek_yok();
    }
    ayrilan_bayt += (long long)bayt;
    return p;
}

static void dd_ekle(KomsuDizisi *d, int x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite ? 2 * d->kapasite : 2;
        int *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            bellek_yok();
        }
        ayrilan_bayt += (long long)((yeni - d->kapasite) * sizeof(int));
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
}

static int kenar_karsilastir(const void *a, const void *b)
{
    const Kenar *x = a, *y = b;
    if (x->u != y->u) {
        return (x->u > y->u) - (x->u < y->u);
    }
    return (x->v > y->v) - (x->v < y->v);
}

/* Kenar listesi (u < v, tekil, sıralı). Sahiplik: çağıranın (free). */
static Kenar *graf_uret(int V, int yogun, long *E)
{
    size_t kap = yogun ? (size_t)V * (V - 1) / 4 + (size_t)V + 16
                       : 4 * (size_t)V + 16;
    Kenar *k = malloc(kap * sizeof *k);
    long n = 0;
    if (k == NULL) {
        bellek_yok();
    }
    rastgele_tohum(42);
    if (yogun) {
        for (int u = 0; u < V; u++) {
            for (int v = u + 1; v < V; v++) {
                if (rastgele_sayi() % 2 == 1) {
                    if ((size_t)n == kap) {
                        kap *= 2;
                        Kenar *g = realloc(k, kap * sizeof *k);
                        if (g == NULL) {
                            bellek_yok();
                        }
                        k = g;
                    }
                    k[n++] = (Kenar){u, v};
                }
            }
        }
    } else {
        for (int v = 1; v < V; v++) {        /* kapsayan ağaç: bağlı */
            int u = rastgele_aralik(0, v - 1);
            k[n++] = (Kenar){u, v};
        }
        for (long i = 0; i < 3L * V; i++) {
            int a = rastgele_aralik(0, V - 1), b = rastgele_aralik(0, V - 1);
            if (a != b) {
                k[n++] = (Kenar){a < b ? a : b, a < b ? b : a};
            }
        }
        qsort(k, (size_t)n, sizeof *k, kenar_karsilastir);
        long m = 0;
        for (long i = 0; i < n; i++) {       /* yinelenen kenarları at */
            if (m == 0 || k[i].u != k[m - 1].u || k[i].v != k[m - 1].v) {
                k[m++] = k[i];
            }
        }
        n = m;
    }
    *E = n;
    return k;
}

typedef struct {
    int V;
    unsigned char *matris;               /* V × V */
    KomsuDizisi *liste;                  /* V dinamik dizi */
    int *csr_bas, *csr_komsu;            /* V + 1 ve 2E */
} Temsil;

static int *uzak, *q;                    /* BFS çalışma dizileri */
static long sonuc_ulasilan;
static long long sonuc_toplam;

static void bfs_bitir(int son)
{
    long long t = 0;
    for (int i = 0; i < son; i++) {
        t += uzak[q[i]];
    }
    sonuc_ulasilan = son;
    sonuc_toplam = t;
}

/* Matris: her çıkan köşe için satırın TAMAMI taranır: Θ(V²) */
static void bfs_matris(void *veri)
{
    const Temsil *t = veri;
    int V = t->V, bas = 0, son = 0;
    for (int v = 0; v < V; v++) {
        uzak[v] = -1;
    }
    uzak[0] = 0;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        const unsigned char *satir = t->matris + (size_t)u * V;
        for (int v = 0; v < V; v++) {
            if (satir[v] && uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q[son++] = v;
            }
        }
    }
    bfs_bitir(son);
}

/* Liste: yalnız gerçek komşular: Θ(V + E) */
static void bfs_liste(void *veri)
{
    const Temsil *t = veri;
    int V = t->V, bas = 0, son = 0;
    for (int v = 0; v < V; v++) {
        uzak[v] = -1;
    }
    uzak[0] = 0;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        const KomsuDizisi *d = &t->liste[u];
        for (size_t i = 0; i < d->boyut; i++) {
            int v = d->veri[i];
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q[son++] = v;
            }
        }
    }
    bfs_bitir(son);
}

/* CSR: u'nun komşuları csr_komsu[csr_bas[u] .. csr_bas[u + 1] - 1] */
static void bfs_csr(void *veri)
{
    const Temsil *t = veri;
    int V = t->V, bas = 0, son = 0;
    for (int v = 0; v < V; v++) {
        uzak[v] = -1;
    }
    uzak[0] = 0;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        for (int i = t->csr_bas[u]; i < t->csr_bas[u + 1]; i++) {
            int v = t->csr_komsu[i];
            if (uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q[son++] = v;
            }
        }
    }
    bfs_bitir(son);
}

static void kur(Temsil *t, const char *kip, const Kenar *k, long E)
{
    int V = t->V;
    ayrilan_bayt = 0;
    if (strcmp(kip, "matris") == 0) {
        t->matris = sayacli_ayir((size_t)V * V);
        for (long i = 0; i < E; i++) {
            t->matris[(size_t)k[i].u * V + k[i].v] = 1;
            t->matris[(size_t)k[i].v * V + k[i].u] = 1;
        }
    } else if (strcmp(kip, "liste") == 0) {
        t->liste = sayacli_ayir((size_t)V * sizeof *t->liste);
        for (long i = 0; i < E; i++) {
            dd_ekle(&t->liste[k[i].u], k[i].v);
            dd_ekle(&t->liste[k[i].v], k[i].u);
        }
    } else {                                 /* csr: say, önek topla, doldur */
        t->csr_bas = sayacli_ayir(((size_t)V + 1) * sizeof(int));
        t->csr_komsu = sayacli_ayir(2 * (size_t)E * sizeof(int));
        int *yer = malloc((size_t)V * sizeof(int));    /* geçici */
        if (yer == NULL) {
            bellek_yok();
        }
        for (long i = 0; i < E; i++) {
            t->csr_bas[k[i].u + 1]++;
            t->csr_bas[k[i].v + 1]++;
        }
        for (int u = 0; u < V; u++) {
            t->csr_bas[u + 1] += t->csr_bas[u];
            yer[u] = t->csr_bas[u];
        }
        for (long i = 0; i < E; i++) {
            t->csr_komsu[yer[k[i].u]++] = k[i].v;
            t->csr_komsu[yer[k[i].v]++] = k[i].u;
        }
        free(yer);
    }
}

static void birak(Temsil *t)
{
    free(t->matris);
    if (t->liste != NULL) {
        for (int u = 0; u < t->V; u++) {
            free(t->liste[u].veri);
        }
        free(t->liste);
    }
    free(t->csr_bas);
    free(t->csr_komsu);
    t->matris = NULL;
    t->liste = NULL;
    t->csr_bas = t->csr_komsu = NULL;
}

int main(int argc, char *argv[])
{
    if (argc != 6) {
        fprintf(stderr, "Kullanım: H11_deney_temsil V seyrek|yogun "
                "matris,liste,csr TEKRAR CSV\n");
        return 2;
    }
    long V = strtol(argv[1], NULL, 10), tekrar = strtol(argv[4], NULL, 10);
    int yogun = strcmp(argv[2], "yogun") == 0;
    if (V < 2 || V > 2000000 || tekrar < 1 || tekrar > 101 ||
        (!yogun && strcmp(argv[2], "seyrek") != 0)) {
        fprintf(stderr, "geçersiz argüman\n");
        return 2;
    }
    long E;
    Kenar *k = graf_uret((int)V, yogun, &E);
    FILE *csv = fopen(argv[5], "a");
    uzak = malloc((size_t)V * sizeof(int));
    q = malloc((size_t)V * sizeof(int));
    if (csv == NULL || uzak == NULL || q == NULL) {
        bellek_yok();
    }
    char kipler[64];
    snprintf(kipler, sizeof kipler, "%s", argv[3]);
    for (char *kip = strtok(kipler, ","); kip != NULL;
         kip = strtok(NULL, ",")) {
        Temsil t = {(int)V, NULL, NULL, NULL, NULL};
        void (*bfs)(void *) = strcmp(kip, "matris") == 0 ? bfs_matris
                              : strcmp(kip, "liste") == 0 ? bfs_liste
                                                          : bfs_csr;
        kur(&t, kip, k, E);
        double duvar[101], islemci[101];
        bfs(&t);                             /* ısınma */
        for (long r = 0; r < tekrar; r++) {
            double t0 = zaman_sn(), c0 = islemci_sn();
            bfs(&t);
            duvar[r] = zaman_sn() - t0;
            islemci[r] = islemci_sn() - c0;
        }
        double od = ortanca(duvar, (int)tekrar) * 1000.0;
        double oi = ortanca(islemci, (int)tekrar) * 1000.0;
        printf("V = %ld, %s, E = %ld, %s: ulaşılan = %ld, uzaklık toplamı = "
               "%lld, bayt = %lld\n", V, argv[2], E, kip, sonuc_ulasilan,
               sonuc_toplam, ayrilan_bayt);
        fprintf(csv, "c;%s;%s;%ld;%ld;%s;%lld;%ld;%.4f;%.4f;%ld;%lld\n",
                DERLEME, argv[2], V, E, kip, ayrilan_bayt, tekrar, od, oi,
                sonuc_ulasilan, sonuc_toplam);
        birak(&t);
    }
    fclose(csv);
    free(uzak);
    free(q);
    free(k);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — Boost.Graph adjacency_list,
 * adjacency_matrix, compressed_sparse_row_graph; Python — scipy.sparse
 * csr_matrix ve networkx (ders dışı; yalnız karşılaştırma için). */

"""H11_deney_temsil.py — AP-2 Hafta 11 · Haftanın Deneyi (a) ve (c)
Amaç    : Aynı graf (ortak LCG) üç temsilde: komşuluk matrisi (V tane
          bytearray satırı), komşuluk listesi (liste listesi) ve CSR (iki
          liste). Her temsilde BFS(0) süresi (1 ısınma + TEKRAR, ortanca)
          ve bellek: temsil KURULURKEN tracemalloc ile ölçülen bayt
          (CPython sürümüne bağlı; tamsayı nesneleri kenar listesinde
          zaten var olduğu için sayılmaz — yalnız listeler/bytearray'ler).
Çalıştır: python3 H11_deney_temsil.py V seyrek|yogun matris,liste,csr \\
          TEKRAR CSV
Çıktı   : stdout: E, ulaşılan, uzaklık toplamı; bayt ve süreler CSV'ye
"""
import sys
import tracemalloc

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn


def graf_uret(V, yogun):
    """Kenar listesi (u < v, tekil, sıralı)"""
    k = []
    rastgele_tohum(42)
    if yogun:
        for u in range(V):
            for v in range(u + 1, V):
                if rastgele_sayi() % 2 == 1:
                    k.append((u, v))
        return k
    for v in range(1, V):               # kapsayan ağaç: bağlı
        k.append((rastgele_aralik(0, v - 1), v))
    for _ in range(3 * V):
        a, b = rastgele_aralik(0, V - 1), rastgele_aralik(0, V - 1)
        if a != b:
            k.append((min(a, b), max(a, b)))
    k.sort()
    tekil = []
    for e in k:                         # yinelenen kenarları at
        if not tekil or e != tekil[-1]:
            tekil.append(e)
    return tekil


def kur(V, kip, k):
    if kip == "matris":
        m = [bytearray(V) for _ in range(V)]
        for u, v in k:
            m[u][v] = 1
            m[v][u] = 1
        return m
    if kip == "liste":
        liste = [[] for _ in range(V)]
        for u, v in k:
            liste[u].append(v)
            liste[v].append(u)
        return liste
    bas = [0] * (V + 1)                 # csr: say, önek topla, doldur
    komsu = [0] * (2 * len(k))
    for u, v in k:
        bas[u + 1] += 1
        bas[v + 1] += 1
    for u in range(V):
        bas[u + 1] += bas[u]
    yer = bas[:-1]
    for u, v in k:
        komsu[yer[u]] = v
        yer[u] += 1
        komsu[yer[v]] = u
        yer[v] += 1
    return bas, komsu


def bfs_matris(V, m):
    """Her çıkan köşe için satırın TAMAMI taranır: Θ(V²)"""
    uzak = [-1] * V
    q = [0]
    uzak[0] = 0
    bas = 0
    while bas < len(q):
        u = q[bas]
        bas += 1
        satir = m[u]
        for v in range(V):
            if satir[v] and uzak[v] == -1:
                uzak[v] = uzak[u] + 1
                q.append(v)
    return uzak, q


def bfs_liste(V, liste):
    """Yalnız gerçek komşular: Θ(V + E)"""
    uzak = [-1] * V
    q = [0]
    uzak[0] = 0
    bas = 0
    while bas < len(q):
        u = q[bas]
        bas += 1
        for v in liste[u]:
            if uzak[v] == -1:
                uzak[v] = uzak[u] + 1
                q.append(v)
    return uzak, q


def bfs_csr(V, csr):
    bas_dizi, komsu = csr
    uzak = [-1] * V
    q = [0]
    uzak[0] = 0
    bas = 0
    while bas < len(q):
        u = q[bas]
        bas += 1
        for i in range(bas_dizi[u], bas_dizi[u + 1]):
            v = komsu[i]
            if uzak[v] == -1:
                uzak[v] = uzak[u] + 1
                q.append(v)
    return uzak, q


def main():
    if len(sys.argv) != 6:
        print("Kullanım: H11_deney_temsil V seyrek|yogun matris,liste,csr "
              "TEKRAR CSV", file=sys.stderr)
        return 2
    V, tekrar = int(sys.argv[1]), int(sys.argv[4])
    yogunluk = sys.argv[2]
    k = graf_uret(V, yogunluk == "yogun")
    bfs = {"matris": bfs_matris, "liste": bfs_liste, "csr": bfs_csr}
    with open(sys.argv[5], "a", encoding="utf-8") as csv:
        for kip in sys.argv[3].split(","):
            tracemalloc.start()
            temsil = kur(V, kip, k)
            bayt, _ = tracemalloc.get_traced_memory()
            tracemalloc.stop()          # ölçüm süreleri etkilemesin
            uzak, q = bfs[kip](V, temsil)               # ısınma
            duvar, islemci = [], []
            for _ in range(tekrar):
                t0, c0 = zaman_sn(), islemci_sn()
                uzak, q = bfs[kip](V, temsil)
                duvar.append(zaman_sn() - t0)
                islemci.append(islemci_sn() - c0)
            toplam = 0
            for v in q:
                toplam += uzak[v]
            print(f"V = {V}, {yogunluk}, E = {len(k)}, {kip}: ulaşılan = "
                  f"{len(q)}, uzaklık toplamı = {toplam}")
            csv.write(f"py;-;{yogunluk};{V};{len(k)};{kip};{bayt};{tekrar};"
                      f"{ortanca(duvar) * 1000:.4f};"
                      f"{ortanca(islemci) * 1000:.4f};{len(q)};{toplam}\n")
            del temsil
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok; C++ — Boost.Graph adjacency_list,
# adjacency_matrix, compressed_sparse_row_graph; Python — scipy.sparse
# csr_matrix ve networkx (ders dışı; yalnız karşılaştırma için).

"""H11_deney_derin.py — AP-2 Hafta 11 · Haftanın Deneyi (b)
Amaç    : n köşelik zincirde (0 - 1 - ... - n-1; CSR listeleriyle) DFS:
          özyinelemeli sürüm n derinliğe iner; CPython özyinelemeyi
          sys.getrecursionlimit() ile sınırlar (varsayılan 1000) ve
          aşılınca RecursionError verir. Açık yığınlı sürüm sınırsızdır.
          TEKRAR = 0: tek çalıştırma (eşik araması için).
Çalıştır: python3 H11_deney_derin.py ozyinelemeli|yigin n TEKRAR [CSV]
Çıktı   : stdout: ziyaret ve en büyük derinlik; süreler yalnız CSV'ye
"""
import sys

from zamanlayici import islemci_sn, ortanca, zaman_sn


def main():
    if not 4 <= len(sys.argv) <= 5:
        print("Kullanım: H11_deney_derin ozyinelemeli|yigin n TEKRAR [CSV]",
              file=sys.stderr)
        return 2
    kip, n, tekrar = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    bas, komsu = [], []
    for u in range(n):                  # zincir: u - 1 ve u + 1
        bas.append(len(komsu))
        if u > 0:
            komsu.append(u - 1)
        if u + 1 < n:
            komsu.append(u + 1)
    bas.append(len(komsu))
    durum = {}

    def dfs_ozy(u, derinlik):
        ziyaret[u] = True
        durum["ziyaret"] += 1
        durum["derin"] = max(durum["derin"], derinlik)
        for i in range(bas[u], bas[u + 1]):
            v = komsu[i]
            if not ziyaret[v]:
                dfs_ozy(v, derinlik + 1)

    def dfs_yigin(kok):
        yigin = [[kok, bas[kok]]]       # [köşe, sıradaki komşu indisi]
        ziyaret[kok] = True
        durum["ziyaret"] = 1
        while yigin:
            durum["derin"] = max(durum["derin"], len(yigin))
            c = yigin[-1]
            if c[1] == bas[c[0] + 1]:
                yigin.pop()             # komşu kalmadı
                continue
            v = komsu[c[1]]
            c[1] += 1
            if not ziyaret[v]:
                ziyaret[v] = True
                durum["ziyaret"] += 1
                yigin.append([v, bas[v]])

    ziyaret = [False] * n

    def calistir():
        for i in range(n):
            ziyaret[i] = False
        durum["ziyaret"] = durum["derin"] = 0
        if kip == "ozyinelemeli":
            dfs_ozy(0, 1)
        else:
            dfs_yigin(0)

    if tekrar == 0:
        print(f"{kip} n = {n} başlıyor (özyineleme sınırı "
              f"{sys.getrecursionlimit()})", flush=True)
        calistir()
    else:
        calistir()                      # ısınma
        duvar, islemci = [], []
        for _ in range(tekrar):
            t0, c0 = zaman_sn(), islemci_sn()
            calistir()
            duvar.append(zaman_sn() - t0)
            islemci.append(islemci_sn() - c0)
        if len(sys.argv) == 5:
            with open(sys.argv[4], "a", encoding="utf-8") as csv:
                csv.write(f"py;-;{kip};{n};{tekrar};"
                          f"{ortanca(duvar) * 1000:.4f};"
                          f"{ortanca(islemci) * 1000:.4f};"
                          f"{durum['ziyaret']};{durum['derin']}\n")
    print(f"{kip} n = {n}: ziyaret = {durum['ziyaret']}, en büyük derinlik "
          f"= {durum['derin']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: yok. sys.setrecursionlimit yalnız kavram K05'te,
# açıklamasıyla kullanılır; doğru çözüm açık yığındır.

# Hafta 11 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı ve beklenen çıktısıyla ve gösterildiği yerlerle (ders notu bölümü ya da sayfası, slayt, web kutusu) aşağıdadır. Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11.15 (örnekler 3.10 uyumludur).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] -o program` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. Graf dosyası okuyan örnekler dosya yollarını argüman olarak alır (`./program ../girdiler/graf_ornek.txt`); Örnek 9 ve 10 standart girdiden okur (`./program < ../girdiler/KÖK.txt`).

Graf dosyası biçimi (H11–H12 ortak): `#` ile başlayan satırlar yorum; ilk satır `V E [yonlu|yonsuz]`, ardından E satır `u v [w]`. Hatalı dosyada ileti stderr'e, çıkış kodu 1; kullanım hatasında 2. Çıktılarda yalnız dosya adı (yol değil) yazılır. Komşular artan köşe numarasıyla dolaşılır (listeler okunduktan sonra sıralanır).

Eşdeğerlik: `python3 esdeger_test.py .` → **13/13 GEÇTİ** (13 “=”: üç dilde bayt bayt aynı stdout), uyarı 0; `--asan` (AddressSanitizer + UBSan + LeakSanitizer) ile **13/13 GEÇTİ** (hatalı 0). Valgrind: 50/50 program temiz (0 hata, 0 bayt kayıp) (`BELLEK_DENETIMI.txt`).


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H11_01_komsuluk_matrisi` | ★ | = | evet | Komşuluk matrisiyle graf ve derece hesabı: yönsüz G ve yönlü G3, giriş/çıkış derecesi, el sıkışma lemması, satır taraması (V² hücre) | — | Bölüm 3.3; Ek A.1; metin s. 3, 5, 6, 7, 8, 30 … | slayt kod: 15; metin: 11, 12 | örnek kutusu (üç dil), metin |
| `H11_02_komsuluk_listesi` | ★★ | = | — | Komşuluk listesi (dinamik dizilerle) ve dosyadan kenar listesi okuma: ekleme sırası ve artan sıra, liste ↔ matris ↔ kenar listesi, biçim hatası iletileri | `girdiler/graf_ornek.txt girdiler/graf_yonlu.txt girdiler/hatali_baslik.txt girdiler/hatali_tur.txt girdiler/hatali_kose.txt girdiler/hatali_sayi.txt girdiler/hatali_eksik.txt girdiler/hatali_fazla.txt girdiler/yok.txt` | Bölüm 3.3; Ek A.2; metin s. 3, 8, 9, 50 | slayt metin: 11 | örnek kutusu (üç dil), metin |
| `H11_03_bfs_katmanlar` | ★★ | = | evet | BFS: kuyrukla dolaşma, ziyaret işareti kuyruğa eklerken; adım adım kuyruk, ziyaret sırası ve katmanlar | `girdiler/graf_ornek.txt girdiler/graf_yonlu.txt` | Ek A.3; metin s. 3, 5, 9, 11, 12, 30 … | slayt metin: 17 | örnek kutusu (üç dil), metin |
| `H11_04_bfs_en_kisa_yol` | ★★ | = | evet | BFS ile en kısa yol uzaklıkları ve yolun ebeveyn dizisinden geri çıkarılması; ulaşılamayan köşe sözleşmesi (-1) | `girdiler/graf_ornek.txt girdiler/graf_bilesen.txt` | Bölüm 4.1; Bölüm 4.2; Ek A.4; metin s. 3, 12, 13, 49, 51 | slayt kod: 20 | örnek kutusu (üç dil), metin |
| `H11_05_dfs_ozyinelemeli` | ★★ | = | evet | Özyinelemeli DFS: ziyaret sırası, keşif/bitiş zamanları, parantez yapısı; yönlüde ağaç/geri/ileri/çapraz kenar sınıflaması | `girdiler/graf_ornek.txt girdiler/graf_yonlu.txt` | Bölüm 4.3; Ek A.5; metin s. 3, 5, 15, 16, 17, 49 … | slayt kod: 26 | örnek kutusu (üç dil), metin |
| `H11_06_dfs_acik_yigin` | ★★ | = | evet | Açık yığınlı DFS: (A) yineleyici indeksli çerçeve yığını, (B) ters sırada itme; özyinelemeli sürümle aynı sıra (kâhin) | `girdiler/graf_ornek.txt girdiler/graf_yonlu.txt` | Bölüm 4.4; Ek A.6; metin s. 3, 17, 18, 19, 42, 45 … | slayt kod: 27, 31; metin: 30, 49 | örnek kutusu (üç dil), metin |
| `H11_07_bagli_bilesenler` | ★★ | = | evet | Bağlı bileşen sayısı ve etiketleri: her etiketsiz köşeden bir BFS; bileşen başına köşe/kenar ve yönsüz grafta döngü | `girdiler/graf_bilesen.txt girdiler/graf_ornek.txt` | Bölüm 4.5; Ek A.7; metin s. 3, 21, 36, 54 | slayt metin: 32 | örnek kutusu (üç dil), metin |
| `H11_08_iki_parcali` | ★★ | = | — | İki parçalılık: BFS ile 2-renklendirme; çelişkili kenar ve BFS ağacından tek uzunluklu döngü | `girdiler/graf_ornek.txt girdiler/graf_tek_dongu.txt` | Bölüm 4.6; Ek A.8; metin s. 3, 5, 6, 23, 56 | slayt metin: 33 | örnek kutusu (üç dil), metin |
| `H11_09_tasma_doldurma` | ★★ | = | — | Izgarada taşkın doldurma ve ada sayma: örtük graf, 4 ve 8 komşuluk, sınır denetimi erişimden önce | `< girdiler/H11_09_tasma_doldurma.txt` | Bölüm 5.1; Ek A.9; metin s. 2, 3, 5, 6, 7, 13 … | slayt metin: 34 | örnek kutusu (üç dil), metin |
| `H11_10_labirent_bfs` | ★★★ | = | — | Labirentte en kısa yol (ızgara BFS) — aynı labirentte H3 geri izleme çözümüyle karşılaştırma: yol uzunluğu ve ziyaret edilen hücre | `< girdiler/H11_10_labirent_bfs.txt` | Bölüm 5.2; Ek A.10; metin s. 2, 3, 4, 5, 14, 31 … | slayt metin: 4, 7, 36 | örnek kutusu (üç dil), metin |
| `H11_11_kahn` | ★★★ | = | evet | Topolojik sıralama — Kahn algoritması: giriş derecesi 0 olan en küçük köşe (en küçük öbek), en erken dönem, döngü raporu, FIFO karşılaştırması | `girdiler/dersler_dag.txt girdiler/dersler_dongulu.txt` | Bölüm 4.7; Ek A.11; metin s. 3, 5, 25, 26, 30, 31 … | slayt kod: 41, 43; metin: 4, 38 | örnek kutusu (üç dil), metin |
| `H11_12_dfs_topolojik` | ★★★ | = | evet | Topolojik sıralama — DFS bitiş sırası ve yönlü döngü tespiti (üç renk); döngünün gri yoldan yazdırılması | `girdiler/dersler_dag.txt girdiler/dersler_dongulu.txt` | Bölüm 4.8; Ek A.12; metin s. 3, 29, 49, 61 | slayt metin: 44 | örnek kutusu (üç dil), metin |
| `H11_13_ortak_yazarlik` | ★★★ | = | — | Küçük bir kurgusal ortak yazarlık ağında “kaç adım uzakta?” (Erdős sayısı benzeri): ad → köşe ikili aramayla, BFS uzaklıkları | `girdiler/ortak_yazarlik.txt` | Ek A.13; metin s. 2, 3, 5, 14, 32, 38 … | slayt metin: 37 | örnek kutusu (üç dil), metin |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt`. C++/Python'da C'den anlam olarak farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`.

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py` (13 Ekim 2026 sürümü). ortak_rastgele kullanan: Örnek 13; zamanlayici merdivende kullanılmaz (deney ve kavram K03).


## 2. Kavram programları (kavram/)

Merdiven dışı küçük programlar (Kaputun Altında, Dil Penceresi, doğrulama). Çıktılar `kavram/ciktilar/` (ortam satırı, derleme ve çalıştırma komutu ile); “bu çalıştırmada” etiketli değerler (süreler, çerçeve boyu) eşdeğerlik kapsamı dışındadır. K04 `networkx` yüklüyse çalışır, değilse atlar; merdivende kütüphane kullanılmaz.

| Dosya | Dil | Amaç | Çıktı | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H11_K01_matris_bellek.c` | C | Komşuluk matrisinin bellek patlaması: V² hücre. 1 bayt, 1 bit ve 4 bayt (int) hücreyle gereken bellek; seyrek grafta (E = 4V) komşuluk listesi ve CSR ile karşılaştırma. Ölçüm değil HESAP: 1 GB = 10^9 bayt, 1 GiB = 2^30 bayt. | `ciktilar/H11_K01_matris_bellek_c.txt` | metin s. 9, 10 | slayt metin: 14 | metin |
| `kavram/H11_K01_matris_bellek.py` | Python | Komşuluk matrisinin bellek patlaması (C sürümüyle aynı hesap) ve Python'da gerçek boyutlar: liste listesinde her hücre 8 baytlık bir başvurudur (0 ve 1 küçük tamsayı nesneleri paylaşılır); bytearray satırı hücre başına 1 bayttır. sys.getsizeof değerleri CPython sürümüne bağlıdır (bu çalıştırmada). | `ciktilar/H11_K01_matris_bellek_py.txt` | metin s. 9, 10 | slayt metin: 14 | metin |
| `kavram/H11_K02_csr_kurulumu.c` | C | CSR (sıkıştırılmış seyrek satır) kurulumu üç adımda: (1) her köşenin derecesini say, (2) önek toplamıyla bas[] dizisini kur (u'nun komşuları komsu[bas[u] .. bas[u+1]-1]), (3) kenarları yerlerine yaz. Bütün komşular TEK bitişik dizidedir: dolaşma bellekte ileri doğru akar (önbellek dostu). | `ciktilar/H11_K02_csr_kurulumu_c.txt` | metin s. 10 | slayt metin: 53 | metin |
| `kavram/H11_K02_csr_kurulumu.cpp` | C++ | CSR (sıkıştırılmış seyrek satır) kurulumu üç adımda: derece say, önek toplamıyla bas[], kenarları yerlerine yaz. C sürümüyle aynı çıktı; diziler std::vector. | `ciktilar/H11_K02_csr_kurulumu_cpp.txt` | metin s. 10 | slayt metin: 53 | metin |
| `kavram/H11_K02_csr_kurulumu.py` | Python | CSR (sıkıştırılmış seyrek satır) kurulumu üç adımda: derece say, önek toplamıyla bas[], kenarları yerlerine yaz. C sürümüyle aynı çıktı. (Python listesi başvuru tutar; gerçek bitişik tamsayı dizisi için array('i') gerekir — önbellek kazancı C'deki gibi değildir.) | `ciktilar/H11_K02_csr_kurulumu_py.txt` | metin s. 10 | slayt metin: 53 | metin |
| `kavram/H11_K03_deque_liste.py` | Python | BFS kuyruğu Python'da neden collections.deque? list.pop(0) baştaki öğeyi çıkarınca kalan bütün öğeleri bir sola kaydırır: O(n); deque.popleft() O(1). Aynı işlem dizisi (n ekleme, n çıkarma) iki yapıyla; süreler bu çalıştırmada ölçülür (stdout'a yazılır, çıktı "bu çalıştırmada" etiketlidir). | `ciktilar/H11_K03_deque_liste_py.txt` | metin s. 12, 38 | — | metin |
| `kavram/H11_K04_networkx_dogrulama.py` | Python | Merdivendeki Python örneklerinin sonuçlarını networkx ile DOĞRULAR (networkx yalnız kâhindir; örneklerde kullanılmaz). networkx kurulu değilse doğrulama atlanır (çıkış kodu 0). Örnek modülleri ../python/ klasöründen içe aktarılır; girdiler ../girdiler/ klasöründendir. | `ciktilar/H11_K04_networkx_dogrulama_py.txt` | metin s. 13, 17, 22, 24, 28, 30 … | — | — |
| `kavram/H11_K05_ozyineleme_siniri.py` | Python | CPython'un özyineleme sınırı: sys.getrecursionlimit() (varsayılan 1000). Zincirde özyinelemeli DFS sınırı aşınca RecursionError. sys.setrecursionlimit ile sınır büyütülebilir; ama Python belgeleri "çok yüksek bir sınır çökmeye yol açabilir" der (C yığını taşabilir). Bu dosya sınırı YALNIZ gösterim için büyütür; doğru çözüm açık yığındır (Örnek 6, Hata Avcısı 7). | `ciktilar/H11_K05_ozyineleme_siniri_py.txt` | metin s. 20 | — | — |
| `kavram/H11_K06_cagri_cercevesi.c` | C | Özyinelemeli DFS'nin her çağrısı çağrı yığınında bir çerçeve kaplar. İki ardışık çağrıdaki yerel değişkenlerin adres FARKI çerçeve boyunu verir (adresin kendisi yazdırılmaz: ASLR). Yığın sınırı getrlimit(RLIMIT_STACK) ile okunur (POSIX); sınır / çerçeve ≈ çökmeden inilebilecek en büyük derinlik. | `ciktilar/H11_K06_cagri_cercevesi_c.txt` | metin s. 20, 34 | — | metin |
| `kavram/H11_K07_dict_komsuluk.py` | Python | Python'da adlı köşeler için komşuluk "listesi" bir dict olabilir: anahtar köşe adı, değer komşu adları listesi. BFS aynıdır; ziyaret işareti için set, kuyruk için deque kullanılır. (C'de ad -> numara eşlemesi gerekir: Örnek 13.) Kurgusal küçük bir mahalle yol ağı. | `ciktilar/H11_K07_dict_komsuluk_py.txt` | metin s. 6, 38 | — | metin |


## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir. Belirtiler bu makinede, bu çalıştırmada gözlenmiştir (`hata_avcisi/ciktilar/`; ASan raporları adres/PID/yol sadeleştirilmiş, yinelenen yığın çerçeveleri özetlenmiş olarak). Hata Avcısı 3 ve 7 C ve Python, 5 C (Kahn) ve Python (iki durumlu DFS) sürümleriyle verilir. Düzeltilmiş sürümler ASan + UBSan ve Valgrind altında temizdir.

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H11_HA1_isaret_cikarirken.c` | C | kasıtlı hata | BFS'de ziyaret işareti kuyruğa EKLERKEN değil, kuyruktan ÇIKARIRKEN konuyor. İşaretlenmemiş bir köşe, işlenmeden önce birden çok komşusu tarafından kuyruğa eklenir: kuyruk şişer ve aynı köşe defalarca işlenir. Izgarada ekleme sayısı ÜSTEL büyür. (Kapasitesi V olan bir kuyruk burada taşardı; gösterim güvenli olsun diye kuyruk gerektikçe büyütülür.) | `ciktilar/H11_HA1_isaret_cikarirken.txt` `ciktilar/H11_HA1_isaret_cikarirken_k12.txt` | metin s. 11, 36, 42 | slayt metin: 50 | metin |
| `hata_avcisi/H11_HA1_isaret_cikarirken_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H11_HA1_isaret_cikarirken_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H11_HA2_tek_yonlu_kenar.cpp` | C++ | kasıtlı hata | YÖNSÜZ grafta her kenar yalnız u -> v yönünde ekleniyor (v -> u unutuldu). Kaynak 0'dan BFS "doğru" görünür, çünkü kenarlar dosyada küçük numaradan büyüğe yazılmıştır; ama 7'den hiçbir köşeye ulaşılamaz ve derece toplamı 2E değil E çıkar. | `ciktilar/H11_HA2_tek_yonlu_kenar.txt` | — | — | — |
| `hata_avcisi/H11_HA2_tek_yonlu_kenar_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H11_HA2_tek_yonlu_kenar_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H11_HA3_sinir_sonra.c` | C | kasıtlı hata | ızgarada komşu hücre ÖNCE okunuyor, sınır denetimi SONRA yapılıyor: iz[ni * Y + nj] == '#' && icinde(ni, nj). && kısa devresi sonucu kurtarır gibi görünür (sınır dışı değer kullanılmaz), ama okumanın KENDİSİ dizi dışına erişimdir: tanımsız davranış. ASan bunu "heap-buffer-overflow READ" diye yakalar; ASan'sız çalıştırmada çıktı doğru görünebilir. | `ciktilar/H11_HA3_sinir_sonra_asan.txt` `ciktilar/H11_HA3_sinir_sonra_c.txt` | Bölüm 7; metin s. 6, 30, 35, 36, 58 | — | satır içi kod, metin |
| `hata_avcisi/H11_HA3_sinir_sonra.py` | Python | kasıtlı hata | komşu hücre ÖNCE okunuyor, sınır denetimi SONRA yapılıyor: iz[ni * Y + nj] == "#" and icinde(ni, nj). Python'da negatif indis hata VERMEZ, listenin SONUNDAN okur (üst satırdan yukarı çıkınca sessizce başka hücreye bakılır); alt satırın altındaki indis ise listenin boyunu aşar: IndexError. | `ciktilar/H11_HA3_sinir_sonra_py.txt` | metin s. 6, 30, 35, 36, 58 | — | metin |
| `hata_avcisi/H11_HA3_sinir_sonra_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H11_HA3_sinir_sonra_duzeltilmis_c.txt` | — | — | — |
| `hata_avcisi/H11_HA3_sinir_sonra_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H11_HA3_sinir_sonra_duzeltilmis_py.txt` | — | — | — |
| `hata_avcisi/H11_HA4_dfs_en_kisa_yol.c` | C | kasıtlı hata | ağırlıksız grafta "en kısa yol" DFS ile aranıyor: uzak[v] = DFS ağacındaki derinlik. DFS bir dalda olabildiğince derine iner; bir köşeye İLK ulaştığı yol en kısa yol olmak zorunda değildir. (Geri izlemeyle bütün yolları denemek doğru ama üstel zamanlıdır; doğrusu BFS, Θ(V + E).) | `ciktilar/H11_HA4_dfs_en_kisa_yol.txt` | metin s. 16 | — | — |
| `hata_avcisi/H11_HA4_dfs_en_kisa_yol_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H11_HA4_dfs_en_kisa_yol_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H11_HA5_dongu_denetimsiz.c` | C | kasıtlı hata | Kahn algoritmasında sonuçtaki köşe sayısı denetlenmiyor. Döngülü önkoşul grafında döngüdeki (ve ondan sonraki) dersler hiç giriş derecesi 0'a inmez, sıraya girmez; program eksik planı SESSİZCE "ders planı" diye yazar. | `ciktilar/H11_HA5_dongu_denetimsiz_c.txt` | metin s. 26, 28, 37 | — | — |
| `hata_avcisi/H11_HA5_dongu_denetimsiz.py` | Python | kasıtlı hata | DFS ile topolojik sıralamada yalnız "ziyaret edildi mi?" (iki durum) tutuluyor; gri (yolda) ile siyah (bitti) ayrılmadığı için geri kenar fark edilmez. Döngülü grafta da BÜTÜN dersleri içeren bir "sıra" üretilir ama sıra bazı önkoşulları çiğner. | `ciktilar/H11_HA5_dongu_denetimsiz_py.txt` | metin s. 26, 28, 37 | — | — |
| `hata_avcisi/H11_HA5_dongu_denetimsiz_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H11_HA5_dongu_denetimsiz_duzeltilmis_c.txt` | — | — | — |
| `hata_avcisi/H11_HA5_dongu_denetimsiz_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H11_HA5_dongu_denetimsiz_duzeltilmis_py.txt` | — | — | — |
| `hata_avcisi/H11_HA6_degisken_varsayilan.py` | Python | kasıtlı hata | def dfs(g, u, ziyaret=[]): varsayılan argüman fonksiyon TANIMLANIRKEN bir kez oluşturulur ve bütün çağrılarda AYNI liste kullanılır. İlk çağrının ziyaret listesi ikinci çağrıya taşınır: ikinci DFS hiçbir şeyi "yeni" bulmaz ya da eksik bulur. | `ciktilar/H11_HA6_degisken_varsayilan.txt` | Bölüm 7; metin s. 6, 37 | — | satır içi kod, metin |
| `hata_avcisi/H11_HA6_degisken_varsayilan_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H11_HA6_degisken_varsayilan_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H11_HA7_derin_ozyineleme.c` | C | kasıtlı hata | özyinelemeli DFS, n köşelik bir zincirde (0 - 1 - ... - n-1) n derinliğe iner; her çağrı çağrı yığınında bir çerçeve kaplar. Yığın sınırı (Linux'ta tipik ulimit -s 8192 KB) aşılınca süreç "Segmentation fault" (SIGSEGV) ile çöker. Varsayılan n = 1000 güvenlidir; çökme için: ./H11_HA7_derin_ozyineleme 1000000 | `ciktilar/H11_HA7_derin_ozyineleme_asan.txt` `ciktilar/H11_HA7_derin_ozyineleme_c.txt` `ciktilar/H11_HA7_derin_ozyineleme_c_1e6.txt` | metin s. 20, 53 | — | — |
| `hata_avcisi/H11_HA7_derin_ozyineleme.py` | Python | kasıtlı hata | özyinelemeli DFS, n köşelik zincirde n derinliğe iner. CPython özyinelemeyi sys.getrecursionlimit() ile sınırlar (varsayılan 1000): sınır aşılınca RecursionError. Varsayılan n = 500 güvenlidir; hata için: python3 H11_HA7_derin_ozyineleme.py 2000 | `ciktilar/H11_HA7_derin_ozyineleme_py.txt` `ciktilar/H11_HA7_derin_ozyineleme_py_2000.txt` | metin s. 20, 53 | — | — |
| `hata_avcisi/H11_HA7_derin_ozyineleme_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H11_HA7_derin_ozyineleme_duzeltilmis_c_1e6.txt` | — | — | — |
| `hata_avcisi/H11_HA7_derin_ozyineleme_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H11_HA7_derin_ozyineleme_duzeltilmis_py_2000.txt` | — | — | — |


## 4. Alıştırmalar ve atölyeler (alistirmalar/)

Alıştırma dosyaları ders notunun 11. bölümündeki numaralarla anılır (A01 → Alıştırma 11.1). Hata bulma dosyaları kasıtlı hatalıdır ama uyarısız derlenir; Parsons dosyası (A10) karıştırılmış satırlar içerdiği için bu hâliyle derlenmez. Çıktılar `alistirmalar/ciktilar/` altındadır (ZIP'e girmez); çözümler öğretim üyesindedir.

| Dosya | Dil | Yer | Amaç | Çıktı | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `alistirmalar/H11_A01_cikti_tahmini.c` | C | Alıştırma 11.1 | BFS ve DFS sırası: çıktıyı ÇALIŞTIRMADAN tahmin edin, sonra derleyip karşılaştırın (yönsüz graf, komşuluk matrisi; komşular artan köşe numarasıyla dolaşılır) | `ciktilar/H11_A01_cikti_tahmini.txt` | Alıştırma 11.1; metin s. 41 | slayt metin: 52 | satır içi kod, metin |
| `alistirmalar/H11_A08_hata_bul_bfs.c` | C | Alıştırma 11.8 | Hata bulma: BFS ile uzaklık ve ebeveyn dizisi | `ciktilar/H11_A08_hata_bul_bfs.txt` | Alıştırma 11.8; metin s. 43 | — | satır içi kod, metin |
| `alistirmalar/H11_A09_hata_bul_izgara.py` | Python | Alıştırma 11.9 | Hata bulma (Python): ızgarada BFS ile taşkın doldurma | `ciktilar/H11_A09_hata_bul_izgara.txt` | Alıştırma 11.9; metin s. 43 | — | satır içi kod, metin |
| `alistirmalar/H11_A10_parsons_kahn.c` | C | Alıştırma 11.10 | Parsons: FIFO kuyruklu Kahn'ın ana döngüsünün karıştırılmış satırları (iki satır fazla; bu hâliyle derlenmez) | — | Alıştırma 11.10; metin s. 43 | — | metin |
| `alistirmalar/H11_A14_oncelik_kuyrugu.cpp` | C++ | Alıştırma 11.14 | Diller arası okuma: Kahn algoritması, giriş derecesi 0 olan köşeler bir öncelik kuyruğunda (ders DAG'ı, dersler_dag.txt'nin kenarları) | `ciktilar/H11_A14_oncelik_kuyrugu_cpp.txt` `ciktilar/H11_A14_oncelik_kuyrugu_py.txt` | Alıştırma 11.14; metin s. 27, 44 | — | satır içi kod, metin |
| `alistirmalar/H11_A14_oncelik_kuyrugu.py` | Python | Alıştırma 11.14 | Diller arası okuma: Kahn algoritması, giriş derecesi 0 olan köşeler bir öncelik kuyruğunda (ders DAG'ı, dersler_dag.txt'nin kenarları) | `ciktilar/H11_A14_oncelik_kuyrugu_cpp.txt` `ciktilar/H11_A14_oncelik_kuyrugu_py.txt` | metin s. 27, 44 | — | metin |
| `alistirmalar/H11_A17_labirent_yarismasi.c` | C | Atölye 2 (11.9) | Labirent çözücü yarışması | `ciktilar/H11_A17_labirent_yarismasi_c.txt` `ciktilar/H11_A17_labirent_yarismasi_py.txt` | metin s. 45 | — | metin |
| `alistirmalar/H11_A17_labirent_yarismasi.py` | Python | Atölye 2 (11.9) | Labirent çözücü yarışması | `ciktilar/H11_A17_labirent_yarismasi_c.txt` `ciktilar/H11_A17_labirent_yarismasi_py.txt` | metin s. 45 | — | metin |
| `alistirmalar/H11_A18_ders_planlayici.py` | Python | Atölye 3 (11.10) | Ders planlayıcı | `ciktilar/H11_A18_ders_planlayici.txt` | metin s. 46 | — | metin |


## 5. Quiz (quiz/)

Web sayfasındaki haftalık quiz'in kodlu soruları; önce çalıştırmadan yanıtlanır. Çıktılar `quiz/ciktilar/` altındadır (ZIP'e girmez).

| Dosya | Dil | Amaç | Web |
|---|---|---|---|
| `quiz/H11_Q02_bfs_sira.c` | C | BFS ziyaret sırası (yönsüz graf, komşuluk listesi; listeler artan sırada) | satır içi kod |
| `quiz/H11_Q04_dfs_bitis.c` | C | DFS bitiş sırası ve topolojik sıra (yönlü döngüsüz graf; komşular artan sırada) | satır içi kod |
| `quiz/H11_Q06_varsayilan.py` | Python | Python'da değiştirilebilir varsayılan argüman | satır içi kod |
| `quiz/H11_Q07_matris_takma.py` | Python | Komşuluk matrisini Python'da kurmak: * ile satır çoğaltma | satır içi kod |


## 6. Haftanın Deneyi (deney/)

Sürücü `python3 deney/h11_olcum_calistir.py` (derler, çalıştırır, ham CSV'leri, ölçüm günlüğünü ve `OLCUM_ORTAMI.txt`'yi yazar; süreç başına bellek bütçesi 1,5 GB — aşacak durumlar ÖLÇÜLMEZ, gerekli bellek hesaplanıp `h11_deney_olculmeyen.csv`'ye yazılır), çözümleme `python3 deney/h11_cozumle.py` (özet CSV/JSON: katlar, log–log eğimleri, kestirimler, denetimler), grafikler `python3 ../gorseller/kaynak/h11_deney_grafik.py`. Ortak modüllerin kopyaları `deney/{c,cpp,python}/` içindedir.

| Dosya | Dil | Amaç | Argüman |
|---|---|---|---|
| `deney/c/H11_deney_derin.c` | C | n köşelik zincirde (0 - 1 - ... - n-1; CSR ile saklanır) DFS: özyinelemeli sürüm n derinliğe iner (çağrı yığını, ulimit -s ile sınırlı); açık yığınlı sürüm çerçeveleri öbekte tutar. TEKRAR = 0: tek çalıştırma, süre yok (çökme eşiği aramak için; sürücü ulimit -s ve n'yi değiştirerek çağırır). | ozyinelemeli\|yigin n TEKRAR [CSV] |
| `deney/c/H11_deney_temsil.c` | C | Aynı graf (ortak LCG) üç temsilde: komşuluk matrisi (V × V bayt), komşuluk listesi (H8 dinamik dizileri) ve CSR (tek bitişik dizi). Her temsilde BFS(0) süresi (1 ısınma + TEKRAR, ortanca; duvar ve işlemci) ve temsilin ayrılan bayt sayısı. seyrek: rastgele kapsayan ağaç + 3V rastgele kenar (E ≈ 4V); yogun : her u < v çifti 1/2 olasılıkla (E ≈ V²/4). | V seyrek\|yogun matris,liste,csr TEKRAR CSV |
| `deney/cpp/H11_deney_derin.cpp` | C++ | n köşelik zincirde (0 - 1 - ... - n-1; CSR ile saklanır) DFS: özyinelemeli sürüm n derinliğe iner (çağrı yığını, ulimit -s ile sınırlı); açık yığınlı sürüm çerçeveleri std::vector'de (öbekte) tutar. TEKRAR = 0: tek çalıştırma (çökme eşiği için). | ozyinelemeli\|yigin n TEKRAR [CSV] |
| `deney/cpp/H11_deney_temsil.cpp` | C++ | Aynı graf (ortak LCG) üç temsilde: komşuluk matrisi (V × V bayt), komşuluk listesi (std::vector<std::vector<int>>) ve CSR (tek bitişik dizi). Her temsilde BFS(0) süresi (1 ısınma + TEKRAR, ortanca) ve bellek: vektör kapasitelerinden HESAPLANAN bayt (V * sizeof(std::vector<int>) + Σ capacity * 4). | V seyrek\|yogun matris,liste,csr TEKRAR CSV |
| `deney/python/H11_deney_derin.py` | Python | n köşelik zincirde (0 - 1 - ... - n-1; CSR listeleriyle) DFS: özyinelemeli sürüm n derinliğe iner; CPython özyinelemeyi sys.getrecursionlimit() ile sınırlar (varsayılan 1000) ve aşılınca RecursionError verir. Açık yığınlı sürüm sınırsızdır. TEKRAR = 0: tek çalıştırma (eşik araması için). | ozyinelemeli\|yigin n TEKRAR [CSV] |
| `deney/python/H11_deney_temsil.py` | Python | Aynı graf (ortak LCG) üç temsilde: komşuluk matrisi (V tane bytearray satırı), komşuluk listesi (liste listesi) ve CSR (iki liste). Her temsilde BFS(0) süresi (1 ısınma + TEKRAR, ortanca) ve bellek: temsil KURULURKEN tracemalloc ile ölçülen bayt (CPython sürümüne bağlı; tamsayı nesneleri kenar listesinde zaten var olduğu için sayılmaz — yalnız listeler/bytearray'ler). | V seyrek\|yogun matris,liste,csr TEKRAR CSV |
| `deney/h11_olcum_calistir.py` | Python | AP-2 Hafta 11 · Haftanın Deneyi sürücüsü | — |
| `deney/h11_cozumle.py` | Python | AP-2 Hafta 11 · Haftanın Deneyi çözümlemesi | — |

Ham ve özet veriler (`deney/sonuclar/`): `h11_denetim.json`, `h11_deney_csr_tekrar.csv`, `h11_deney_derin.csv`, `h11_deney_esik.csv`, `h11_deney_olculmeyen.csv`, `h11_deney_temsil.csv`, `h11_olcum_gunlugu.txt`, `h11_ozet.json`, `h11_ozet_derin.csv`, `h11_ozet_temsil.csv`; ölçüm ortamı `deney/OLCUM_ORTAMI.txt`.


## 7. Girdiler (girdiler/)

| Dosya | Açıklama |
|---|---|
| `girdiler/H11_09_tasma_doldurma.txt` | Örnek 9 ızgarası (8 × 14, '#' kara, '.' su; ilk satır S Y i0 j0) |
| `girdiler/H11_10_labirent_bfs.txt` | Örnek 10 labirenti: H3'ün H03_11_labirent.txt dosyasının birebir kopyası |
| `girdiler/H11_A17_oda.txt` | Atölye 2: açık oda (Örnek 10'un gömülü odasıyla aynı; geri izlemenin uzun yol bulduğu durum) |
| `girdiler/H11_A18_onkosul_ornek.txt` | Atölye 3: kurgusal 13 derslik önkoşul listesi (“ÖNKOŞUL DERS” satırları) |
| `girdiler/dersler_dag.txt` | Kurgusal ders önkoşul DAG'ı (V = 9, E = 10; yorumda köşe ↔ ders kodu) |
| `girdiler/dersler_dongulu.txt` | Aynı DAG + 0 -> 2 kenarı (döngü 0 -> 2 -> 7 -> 0) |
| `girdiler/graf_bilesen.txt` | Yönsüz, 4 bileşenli graf (V = 10, E = 7) |
| `girdiler/graf_ornek.txt` | Haftanın küçük örnek grafı G (yönsüz, V = 8, E = 10; kenarlar karışık sırada) |
| `girdiler/graf_tek_dongu.txt` | G + (5, 6) kenarı: tek uzunluklu döngü, iki parçalı değil |
| `girdiler/graf_yonlu.txt` | Yönlü G3 (V = 8, E = 12; dört kenar sınıfı, döngülü) |
| `girdiler/hatali_baslik.txt` | Okuyucu denetimi (Örnek 2); beklenen ileti: `satır 2: başlık "V E [yonlu\|yonsuz]" bekleniyor` |
| `girdiler/hatali_eksik.txt` | Okuyucu denetimi (Örnek 2); beklenen ileti: `kenar eksik: E = 5, okunan 4` |
| `girdiler/hatali_fazla.txt` | Okuyucu denetimi (Örnek 2); beklenen ileti: `satır 4: fazladan kenar (başlıkta E = 2)` |
| `girdiler/hatali_kose.txt` | Okuyucu denetimi (Örnek 2); beklenen ileti: `satır 5: köşe 9 aralık dışı (0..7)` |
| `girdiler/hatali_sayi.txt` | Okuyucu denetimi (Örnek 2); beklenen ileti: `satır 3: kenar "u v [w]" bekleniyor` |
| `girdiler/hatali_tur.txt` | Okuyucu denetimi (Örnek 2); beklenen ileti: `satır 1: tür "yonsz" tanınmıyor (yonlu ya da yonsuz)` |
| `girdiler/ortak_yazarlik.txt` | Kurgusal 16 makalelik ortak yazarlık listesi (Örnek 13; merkez "Erdem") |


## 8. Diğer

- `BELLEK_DENETIMI.txt` — Valgrind (ve ASan) bellek denetimi sonuçları (betikle üretildi; doğrulama kanıtıdır).
- `ornekler.json` — örnek üst verisi (başlık, düzey, çıktı türü, argümanlar, fark satırları, Dil Penceresi notu).
- `esdeger_test.py` — eşdeğerlik testi (ortak; değiştirilmedi).

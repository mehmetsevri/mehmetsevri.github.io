"""H11_A14_oncelik_kuyrugu.py — AP-2 Hafta 11 · Alıştırma 11.14 (★★)
Amaç    : Diller arası okuma: Kahn algoritması, giriş derecesi 0 olan
          köşeler bir öncelik kuyruğunda (ders DAG'ı, dersler_dag.txt'nin
          kenarları). C++ eşi: H11_A14_oncelik_kuyrugu.cpp
Çalıştır: python3 H11_A14_oncelik_kuyrugu.py
"""
import heapq


def main():
    V = 9
    kenar = [(4, 5), (4, 3), (1, 2), (2, 7), (3, 7),
             (2, 6), (7, 0), (5, 0), (0, 8), (6, 8)]
    komsu = [[] for _ in range(V)]
    derece = [0] * V
    for u, v in kenar:
        komsu[u].append(v)
        derece[v] += 1
    h = []
    for v in range(V):
        if derece[v] == 0:
            heapq.heappush(h, v)
    sira = []
    while h:
        u = heapq.heappop(h)
        sira.append(u)
        for v in komsu[u]:
            derece[v] -= 1
            if derece[v] == 0:
                heapq.heappush(h, v)
    print("sıra:", *sira)


if __name__ == "__main__":
    main()

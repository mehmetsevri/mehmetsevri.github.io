/* H11_A08_hata_bul_bfs.c — AP-2 Hafta 11 · Alıştırma 11.8 (★★)
 * Amaç    : Hata bulma: BFS ile uzaklık ve ebeveyn dizisi. Program örnek
 *           graf G'de (V = 8, E = 10) çalışıyor ve sonlanıyor, ama bir
 *           değer yanlış. Hatalı satırı bulun ve düzeltin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_A08_hata_bul_bfs.c -o H11_A08_hata_bul_bfs
 * Çalıştır: ./H11_A08_hata_bul_bfs
 */
#include <stdio.h>

#define V 8
#define MAKS 64

static const int KENAR[][2] = {
    {4, 5}, {0, 2}, {6, 7}, {1, 3}, {0, 1},
    {4, 6}, {2, 4}, {3, 5}, {5, 7}, {1, 4},
};

int main(void)
{
    int m[V][V] = {{0}};
    int uzak[V], ebeveyn[V], q[MAKS], bas = 0, son = 0;
    for (size_t k = 0; k < sizeof KENAR / sizeof KENAR[0]; k++) {
        m[KENAR[k][0]][KENAR[k][1]] = 1;
        m[KENAR[k][1]][KENAR[k][0]] = 1;
    }
    for (int v = 0; v < V; v++) {
        uzak[v] = -1;
        ebeveyn[v] = -1;
    }
    uzak[0] = 0;
    q[son++] = 0;
    while (bas < son) {
        int u = q[bas++];
        for (int v = 0; v < V; v++) {
            if (m[u][v] && ebeveyn[v] == -1) {
                uzak[v] = uzak[u] + 1;
                ebeveyn[v] = u;
                q[son++] = v;
            }
        }
    }
    printf("kuyruğa eklenen: %d\n", son);
    printf("köşe   :");
    for (int v = 0; v < V; v++) {
        printf(" %2d", v);
    }
    printf("\nuzak   :");
    for (int v = 0; v < V; v++) {
        printf(" %2d", uzak[v]);
    }
    printf("\nebeveyn:");
    for (int v = 0; v < V; v++) {
        printf(" %2d", ebeveyn[v]);
    }
    printf("\n");
    return 0;
}

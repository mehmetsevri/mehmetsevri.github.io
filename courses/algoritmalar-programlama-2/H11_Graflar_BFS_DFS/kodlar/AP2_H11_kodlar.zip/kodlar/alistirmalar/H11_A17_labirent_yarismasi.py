"""H11_A17_labirent_yarismasi.py — AP-2 Hafta 11 · Atölye 2 (şablon)
Amaç    : Labirent çözücü yarışması. Aynı labirentte üç strateji: BFS
          (Örnek 10), geri izleme (H3 Örnek 11) ve açık yığınlı DFS
          (dfs_labirent: SİZ yazacaksınız). Her yöntem için bulunan yolun
          adım sayısı ve ziyaret edilen hücre sayısı yazdırılır.
Çalıştır: python3 H11_A17_labirent_yarismasi.py \
          < ../girdiler/H11_A17_oda.txt
Girdi   : ilk satır "satır sütun", ardından ızgara ('#' duvar, '.' boş,
          tek 'S' ve tek 'E'); yön sırası: sağ, aşağı, sol, yukarı
"""
import sys

DR = (0, 1, 0, -1)                      # sağ, aşağı, sol, yukarı
DC = (1, 0, -1, 0)


def acik_mi(h, r, c):
    return 0 <= r < len(h) and 0 <= c < len(h[0]) and h[r][c] != "#"


def bfs_say(h, s, e):
    """BFS (Örnek 10): ziyaret = kuyruktan çıkan hücre; E çıkınca durur."""
    S, Y = len(h), len(h[0])
    ebeveyn = [-2] * (S * Y)
    kaynak, hedef = s[0] * Y + s[1], e[0] * Y + e[1]
    ebeveyn[kaynak] = -1
    q = [kaynak]
    bas = 0
    while bas < len(q):
        x = q[bas]
        bas += 1
        if x == hedef:
            break
        r, c = divmod(x, Y)
        for d in range(4):
            yr, yc = r + DR[d], c + DC[d]
            if acik_mi(h, yr, yc) and ebeveyn[yr * Y + yc] == -2:
                ebeveyn[yr * Y + yc] = x
                q.append(yr * Y + yc)
    yol = -1
    if ebeveyn[hedef] != -2:
        yol = 0
        x = hedef
        while x != kaynak:
            yol += 1
            x = ebeveyn[x]
    return yol, bas


def yol_bul(h, r, c, cagri):
    """Geri izleme (H3 Örnek 11); cagri[0] çağrı sayacı"""
    cagri[0] += 1
    if h[r][c] == "E":
        return True
    if h[r][c] != "S":
        h[r][c] = "*"
    for d in range(4):
        yr, yc = r + DR[d], c + DC[d]
        if 0 <= yr < len(h) and 0 <= yc < len(h[0]) and \
                h[yr][yc] in ".E" and yol_bul(h, yr, yc, cagri):
            return True
    if h[r][c] != "S":
        h[r][c] = "x"
    return False


def geri_izleme_say(h, s):
    k = [satir[:] for satir in h]
    cagri = [0]
    if yol_bul(k, s[0], s[1], cagri):
        return 1 + sum(satir.count("*") for satir in k), cagri[0]
    return -1, cagri[0]


def dfs_labirent(h, s, e):
    """DFS (açık yığın) — ATÖLYE GÖREVİ. Örnek 6'nın çerçeve yığınını
    ızgaraya uyarlayın: çerçeve = [hücre, sıradaki yön]. Hücreyi yığına
    iterken işaretleyin; E yığına girince durun. ziyaret = yığına giren
    hücre sayısı (S dahil); yol = o andaki yığın derinliği - 1."""
    return -1, -1


def satir_yaz(ad, yol, ziyaret):
    """ad: 18 karakterlik (önceden boşlukla doldurulmuş) yöntem adı"""
    if ziyaret < 0:
        print(f"{ad} {'-':>5} {'-':>8}   (henüz yazılmadı)")
    elif yol < 0:
        print(f"{ad} {'-':>5} {ziyaret:8d}   (yol yok)")
    else:
        print(f"{ad} {yol:5d} {ziyaret:8d}")


def main():
    satirlar = sys.stdin.read().split("\n")
    try:
        S, Y = (int(x) for x in satirlar[0].split()[:2])
    except (ValueError, IndexError):
        print("Hatalı labirent girdisi", file=sys.stderr)
        sys.exit(1)
    h = [list(x.rstrip("\r")) for x in satirlar[1:1 + S]]
    if len(h) != S or any(len(x) != Y for x in h) or \
            any(ch not in "#.SE" for x in h for ch in x):
        print("Hatalı labirent girdisi", file=sys.stderr)
        sys.exit(1)
    bas = [(r, c) for r in range(S) for c in range(Y) if h[r][c] == "S"]
    son = [(r, c) for r in range(S) for c in range(Y) if h[r][c] == "E"]
    if len(bas) != 1 or len(son) != 1:
        print("Hatalı labirent girdisi", file=sys.stderr)
        sys.exit(1)
    s, e = bas[0], son[0]
    acik = sum(ch != "#" for x in h for ch in x)
    print(f"labirent {S} x {Y}, S = ({s[0]}, {s[1]}), E = ({e[0]}, {e[1]}),"
          f" açık hücre = {acik}")
    print("yöntem               yol  ziyaret")
    satir_yaz("BFS               ", *bfs_say(h, s, e))
    satir_yaz("geri izleme (H3)  ", *geri_izleme_say(h, s))
    satir_yaz("DFS (açık yığın)  ", *dfs_labirent(h, s, e))


if __name__ == "__main__":
    main()

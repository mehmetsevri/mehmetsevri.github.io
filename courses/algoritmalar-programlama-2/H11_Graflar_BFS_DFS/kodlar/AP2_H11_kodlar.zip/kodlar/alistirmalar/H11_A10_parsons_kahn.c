/* H11_A10_parsons_kahn.c — AP-2 Hafta 11 · Alıştırma 11.10 (★★)
 * Parsons: tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar Kahn
 * algoritmasının (FIFO kuyruklu) ana döngüsünün KARIŞTIRILMIŞ satırlarıdır
 * (iki satır fazladır: kullanılmayacak). Başlangıçta derece[] giriş
 * dereceleriyle dolu, giriş derecesi 0 olan köşeler q[0..son-1]'dedir.
 * Doğru sıraya dizin, girintiyi düzeltin; dönüş sıralanan köşe sayısıdır.
 */
            if (derece[v] == 0) {
        sira[n++] = u;
    return n;
            derece[u]--;
        int u = q[bas++];
                q[son++] = v;
    while (bas < son) {
        for (size_t i = 0; i < g->komsu[u].boyut; i++) {
            derece[v]--;
            if (derece[v] == 1) {
            int v = g->komsu[u].veri[i];
            }
        }
    }

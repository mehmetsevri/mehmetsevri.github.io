/* H11_A14_oncelik_kuyrugu.cpp — AP-2 Hafta 11 · Alıştırma 11.14 (★★)
 * Amaç    : Diller arası okuma: Kahn algoritması, giriş derecesi 0 olan
 *           köşeler bir öncelik kuyruğunda (ders DAG'ı, dersler_dag.txt'nin
 *           kenarları). Python eşi: H11_A14_oncelik_kuyrugu.py
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H11_A14_oncelik_kuyrugu.cpp -o H11_A14_oncelik_kuyrugu
 * Çalıştır: ./H11_A14_oncelik_kuyrugu
 */
#include <cstdio>
#include <queue>
#include <vector>

int main()
{
    const int V = 9;
    const int kenar[][2] = {{4, 5}, {4, 3}, {1, 2}, {2, 7}, {3, 7},
                            {2, 6}, {7, 0}, {5, 0}, {0, 8}, {6, 8}};
    std::vector<std::vector<int>> komsu(V);
    std::vector<int> derece(V, 0);
    for (const auto& k : kenar) {
        komsu[k[0]].push_back(k[1]);
        derece[k[1]]++;
    }
    std::priority_queue<int> h;
    for (int v = 0; v < V; v++) {
        if (derece[v] == 0) {
            h.push(v);
        }
    }
    std::printf("sıra:");
    while (!h.empty()) {
        int u = h.top();
        h.pop();
        std::printf(" %d", u);
        for (int v : komsu[u]) {
            if (--derece[v] == 0) {
                h.push(v);
            }
        }
    }
    std::printf("\n");
    return 0;
}

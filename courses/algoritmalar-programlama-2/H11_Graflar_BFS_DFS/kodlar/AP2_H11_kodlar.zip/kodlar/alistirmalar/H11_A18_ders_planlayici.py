"""H11_A18_ders_planlayici.py — AP-2 Hafta 11 · Atölye 3 (araç)
Amaç    : Ders planlayıcı. Önkoşul listesinden yönlü graf (DAG) kurar;
          Kahn ile geçerli bir ders planı (eşitlikte alfabede önce gelen
          ders), her dersin en erken dönemi (1 + önkoşulların en büyük
          dönemi) ve döngü varsa döngüdeki dersler (üç renkli DFS, açık
          yığın). Elle bulduğunuz sırayı bu araçla denetleyin.
Çalıştır: python3 H11_A18_ders_planlayici.py \
          ../girdiler/H11_A18_onkosul_ornek.txt
Girdi   : her satır "ÖNKOŞUL DERS" ya da tek "DERS"; '#' satırları yorum
"""
import heapq
import sys

BEYAZ, GRI, SIYAH = 0, 1, 2


def oku(yol):
    """(ders adları, kenarlar); biçim hatasında sys.exit(1)"""
    adlar, kenarlar = set(), []
    with open(yol, encoding="utf-8") as f:
        for no, satir in enumerate(f, 1):
            p = satir.split()
            if not p or p[0].startswith("#"):
                continue
            if len(p) > 2:
                print(f"satır {no}: en çok iki ders kodu bekleniyor",
                      file=sys.stderr)
                sys.exit(1)
            adlar.update(p)
            if len(p) == 2:
                kenarlar.append((p[0], p[1]))
    return sorted(adlar), kenarlar


def dongu_bul(V, komsu):
    """Üç renkli DFS (açık yığın): ilk geri kenarın kapattığı döngü"""
    renk = [BEYAZ] * V
    for kok in range(V):
        if renk[kok] != BEYAZ:
            continue
        renk[kok] = GRI
        yigin = [[kok, 0]]
        while yigin:
            u, i = yigin[-1]
            if i < len(komsu[u]):
                yigin[-1][1] += 1
                v = komsu[u][i]
                if renk[v] == GRI:          # geri kenar: döngü
                    yol = [c[0] for c in yigin]
                    return yol[yol.index(v):] + [v]
                if renk[v] == BEYAZ:
                    renk[v] = GRI
                    yigin.append([v, 0])
            else:
                renk[u] = SIYAH
                yigin.pop()
    return []


def main():
    if len(sys.argv) != 2:
        print("Kullanım: python3 H11_A18_ders_planlayici.py DOSYA",
              file=sys.stderr)
        sys.exit(2)
    adlar, kenarlar = oku(sys.argv[1])
    V = len(adlar)
    no = {a: i for i, a in enumerate(adlar)}    # ad -> köşe (alfabe sırası)
    komsu = [[] for _ in range(V)]
    derece = [0] * V
    for a, b in kenarlar:
        komsu[no[a]].append(no[b])
        derece[no[b]] += 1
    for k in komsu:
        k.sort()
    print(f"{V} ders, {len(kenarlar)} önkoşul")
    donem = [1] * V
    h = [v for v in range(V) if derece[v] == 0]
    heapq.heapify(h)
    sira = []
    while h:
        u = heapq.heappop(h)
        sira.append(u)
        for v in komsu[u]:
            donem[v] = max(donem[v], donem[u] + 1)
            derece[v] -= 1
            if derece[v] == 0:
                heapq.heappush(h, v)
    if len(sira) < V:
        print(f"DÖNGÜ VAR: {len(sira)}/{V} ders sıraya girdi; planlanamayan:",
              " ".join(adlar[v] for v in range(V) if derece[v] > 0))
        print("döngü:", " -> ".join(adlar[v] for v in dongu_bul(V, komsu)))
        sys.exit(1)
    print("ders planı:", " ".join(adlar[v] for v in sira))
    for d in range(1, max(donem) + 1):
        print(f"dönem {d}:", " ".join(adlar[v] for v in range(V)
                                      if donem[v] == d))


if __name__ == "__main__":
    main()

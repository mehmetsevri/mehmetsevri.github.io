"""H11_A09_hata_bul_izgara.py — AP-2 Hafta 11 · Alıştırma 11.9 (★★)
Amaç    : Hata bulma (Python): ızgarada BFS ile taşkın doldurma. Program
          sonlanıyor ama (0, 0)'dan ulaşılabilen su hücrelerinin bir kısmını
          bulamıyor. Hatalı satırı bulun; C'de aynı hata yapılabilir mi?
Çalıştır: python3 H11_A09_hata_bul_izgara.py
"""
from collections import deque

IZGARA = ["..#...",
          ".##.#.",
          "....#.",
          "###..."]


def main():
    S, Y = len(IZGARA), len(IZGARA[0])
    gorulen = [[False] * Y] * S
    q = deque([(0, 0)])
    gorulen[0][0] = True
    doldurulan = 0
    while q:
        i, j = q.popleft()
        doldurulan += 1
        for di, dj in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            ni, nj = i + di, j + dj
            if 0 <= ni < S and 0 <= nj < Y and IZGARA[ni][nj] == "." \
                    and not gorulen[ni][nj]:
                gorulen[ni][nj] = True
                q.append((ni, nj))
    su = sum(satir.count(".") for satir in IZGARA)
    print("su hücresi:", su)
    print("(0, 0)'dan doldurulan:", doldurulan)


if __name__ == "__main__":
    main()

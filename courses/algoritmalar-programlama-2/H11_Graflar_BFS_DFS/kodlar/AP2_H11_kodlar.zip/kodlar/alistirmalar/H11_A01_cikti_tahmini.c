/* H11_A01_cikti_tahmini.c — AP-2 Hafta 11 · Alıştırma 11.1 (★)
 * Amaç    : BFS ve DFS sırası: çıktıyı ÇALIŞTIRMADAN tahmin edin, sonra
 *           derleyip karşılaştırın (yönsüz graf, komşuluk matrisi; komşular
 *           artan köşe numarasıyla dolaşılır)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_A01_cikti_tahmini.c -o H11_A01_cikti_tahmini
 * Çalıştır: ./H11_A01_cikti_tahmini
 */
#include <stdio.h>

#define V 7

static int m[V][V];                     /* komşuluk matrisi (AP-1 H11) */
static int gorulen[V];

static void kenar(int u, int v)
{
    m[u][v] = m[v][u] = 1;              /* yönsüz: iki hücre */
}

static void dfs(int u)
{
    gorulen[u] = 1;
    printf(" %d", u);
    for (int v = 0; v < V; v++) {
        if (m[u][v] && !gorulen[v]) {
            dfs(v);
        }
    }
}

int main(void)
{
    int q[V], uzak[V], bas = 0, son = 0;
    kenar(0, 1);
    kenar(0, 3);
    kenar(1, 2);
    kenar(1, 4);
    kenar(3, 4);
    kenar(4, 5);
    kenar(2, 6);
    kenar(5, 6);
    for (int v = 0; v < V; v++) {
        uzak[v] = -1;
    }
    uzak[0] = 0;
    q[son++] = 0;
    printf("BFS(0) sırası:");
    while (bas < son) {
        int u = q[bas++];
        printf(" %d", u);
        for (int v = 0; v < V; v++) {
            if (m[u][v] && uzak[v] == -1) {
                uzak[v] = uzak[u] + 1;
                q[son++] = v;
            }
        }
    }
    printf("\nuzak:");
    for (int v = 0; v < V; v++) {
        printf(" %d", uzak[v]);
    }
    printf("\nDFS(0) sırası:");
    dfs(0);
    printf("\n");
    return 0;
}

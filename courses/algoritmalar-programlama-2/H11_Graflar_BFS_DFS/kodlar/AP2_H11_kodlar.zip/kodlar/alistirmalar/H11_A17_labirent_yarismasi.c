/* H11_A17_labirent_yarismasi.c — AP-2 Hafta 11 · Atölye 2 (şablon)
 * Amaç    : Labirent çözücü yarışması. Aynı labirentte üç strateji: BFS
 *           (Örnek 10), geri izleme (H3 Örnek 11) ve açık yığınlı DFS
 *           (dfs_labirent: SİZ yazacaksınız). Her yöntem için bulunan yolun
 *           adım sayısı ve ziyaret edilen hücre sayısı yazdırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H11_A17_labirent_yarismasi.c -o H11_A17_labirent_yarismasi
 * Çalıştır: ./H11_A17_labirent_yarismasi \
 *           < ../girdiler/H11_10_labirent_bfs.txt
 *           ./H11_A17_labirent_yarismasi < ../girdiler/H11_A17_oda.txt
 * Girdi   : ilk satır "satır sütun", ardından ızgara ('#' duvar, '.' boş,
 *           tek 'S' ve tek 'E'); yön sırası: sağ, aşağı, sol, yukarı
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_SATIR 40
#define MAKS_SUTUN 80

typedef struct {
    char h[MAKS_SATIR][MAKS_SUTUN + 2];
    int S, Y, sr, sc, er, ec;
} Labirent;

typedef struct {
    int yol;              /* bulunan yolun adım (kenar) sayısı; yoksa -1 */
    long ziyaret;         /* ziyaret edilen hücre; yazılmadıysa -1 */
} Sonuc;

static const int DR[4] = {0, 1, 0, -1};     /* sağ, aşağı, sol, yukarı */
static const int DC[4] = {1, 0, -1, 0};

static int acik_mi(const Labirent *L, int r, int c)
{
    return r >= 0 && r < L->S && c >= 0 && c < L->Y && L->h[r][c] != '#';
}

/* BFS (Örnek 10): ziyaret = kuyruktan çıkan (işlenen) hücre; E kuyruktan
 * çıkınca durur. Yol ebeveyn zincirinden sayılır. */
static Sonuc bfs_say(const Labirent *L)
{
    Sonuc s = {-1, 0};
    int n = L->S * L->Y, bas = 0, son = 0;
    int *ebeveyn = malloc((size_t)n * sizeof(int));
    int *q = malloc((size_t)n * sizeof(int));
    if (ebeveyn == NULL || q == NULL) {
        free(ebeveyn);
        free(q);
        return s;
    }
    for (int i = 0; i < n; i++) {
        ebeveyn[i] = -2;
    }
    int kaynak = L->sr * L->Y + L->sc, hedef = L->er * L->Y + L->ec;
    ebeveyn[kaynak] = -1;
    q[son++] = kaynak;
    while (bas < son) {
        int h = q[bas++], r = h / L->Y, c = h % L->Y;
        if (h == hedef) {
            break;
        }
        for (int d = 0; d < 4; d++) {
            int yr = r + DR[d], yc = c + DC[d];
            if (acik_mi(L, yr, yc) && ebeveyn[yr * L->Y + yc] == -2) {
                ebeveyn[yr * L->Y + yc] = h;
                q[son++] = yr * L->Y + yc;
            }
        }
    }
    s.ziyaret = bas;
    if (ebeveyn[hedef] != -2) {
        s.yol = 0;
        for (int h = hedef; h != kaynak; h = ebeveyn[h]) {
            s.yol++;
        }
    }
    free(ebeveyn);
    free(q);
    return s;
}

/* Geri izleme (H3 Örnek 11): ziyaret = çağrı sayısı */
static int yol_bul(Labirent *L, int r, int c, long *cagri)
{
    (*cagri)++;
    if (L->h[r][c] == 'E') {
        return 1;
    }
    if (L->h[r][c] != 'S') {
        L->h[r][c] = '*';
    }
    for (int d = 0; d < 4; d++) {
        int yr = r + DR[d], yc = c + DC[d];
        if (yr >= 0 && yr < L->S && yc >= 0 && yc < L->Y &&
            (L->h[yr][yc] == '.' || L->h[yr][yc] == 'E') &&
            yol_bul(L, yr, yc, cagri)) {
            return 1;
        }
    }
    if (L->h[r][c] != 'S') {
        L->h[r][c] = 'x';
    }
    return 0;
}

static Sonuc geri_izleme_say(const Labirent *asil)
{
    Labirent L = *asil;
    Sonuc s = {-1, 0};
    if (yol_bul(&L, L.sr, L.sc, &s.ziyaret)) {
        s.yol = 1;
        for (int r = 0; r < L.S; r++) {
            for (int c = 0; c < L.Y; c++) {
                s.yol += L.h[r][c] == '*';
            }
        }
    }
    return s;
}

/* DFS (açık yığın) — ATÖLYE GÖREVİ. Örnek 6'nın çerçeve yığınını ızgaraya
 * uyarlayın: çerçeve = (hücre, sıradaki yön). Hücreyi yığına iterken
 * işaretleyin; E yığına girince durun. ziyaret = yığına giren hücre
 * sayısı (S dahil); yol = o andaki yığın derinliği - 1. */
static Sonuc dfs_labirent(const Labirent *L)
{
    Sonuc s = {-1, -1};
    (void)L;
    return s;
}

static int labirent_oku(Labirent *L)
{
    char satir[64];
    char *son;
    int s_sayisi = 0, e_sayisi = 0;
    if (fgets(satir, sizeof satir, stdin) == NULL) {
        return 0;
    }
    long r = strtol(satir, &son, 10);
    char *p = son;
    long c = strtol(p, &son, 10);
    if (son == p || r < 1 || r > MAKS_SATIR || c < 1 || c > MAKS_SUTUN) {
        return 0;
    }
    L->S = (int)r;
    L->Y = (int)c;
    for (int i = 0; i < L->S; i++) {
        if (fgets(L->h[i], sizeof L->h[i], stdin) == NULL) {
            return 0;
        }
        L->h[i][strcspn(L->h[i], "\r\n")] = '\0';
        if ((int)strlen(L->h[i]) != L->Y) {
            return 0;
        }
        for (int j = 0; j < L->Y; j++) {
            if (L->h[i][j] == 'S') {
                s_sayisi++;
                L->sr = i;
                L->sc = j;
            } else if (L->h[i][j] == 'E') {
                e_sayisi++;
                L->er = i;
                L->ec = j;
            } else if (L->h[i][j] != '#' && L->h[i][j] != '.') {
                return 0;
            }
        }
    }
    return s_sayisi == 1 && e_sayisi == 1;
}

/* ad: 18 karakterlik (önceden boşlukla doldurulmuş) yöntem adı */
static void satir_yaz(const char *ad, Sonuc s)
{
    if (s.ziyaret < 0) {
        printf("%s %5s %8s   (henüz yazılmadı)\n", ad, "-", "-");
    } else if (s.yol < 0) {
        printf("%s %5s %8ld   (yol yok)\n", ad, "-", s.ziyaret);
    } else {
        printf("%s %5d %8ld\n", ad, s.yol, s.ziyaret);
    }
}

int main(void)
{
    Labirent L;
    int acik = 0;
    if (!labirent_oku(&L)) {
        fprintf(stderr, "Hatalı labirent girdisi\n");
        return 1;
    }
    for (int r = 0; r < L.S; r++) {
        for (int c = 0; c < L.Y; c++) {
            acik += L.h[r][c] != '#';
        }
    }
    printf("labirent %d x %d, S = (%d, %d), E = (%d, %d), açık hücre = %d\n",
           L.S, L.Y, L.sr, L.sc, L.er, L.ec, acik);
    printf("yöntem               yol  ziyaret\n");
    satir_yaz("BFS               ", bfs_say(&L));
    satir_yaz("geri izleme (H3)  ", geri_izleme_say(&L));
    satir_yaz("DFS (açık yığın)  ", dfs_labirent(&L));
    return 0;
}

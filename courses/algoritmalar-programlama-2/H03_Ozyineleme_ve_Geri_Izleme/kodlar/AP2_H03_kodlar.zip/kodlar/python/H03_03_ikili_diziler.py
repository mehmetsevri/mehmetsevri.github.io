"""H03_03_ikili_diziler.py — AP-2 Hafta 3 · Örnek 3 (★)
Amaç    : n bitlik tüm ikili dizileri özyinelemeyle üretmek; her bitte
          iki dal (0: dahil etme, 1: dahil et); 2^n yaprak, 2^(n+1) − 1 çağrı
Çalıştır: python3 H03_03_ikili_diziler.py
Eşleri  : c/H03_03_ikili_diziler.c · cpp/H03_03_ikili_diziler.cpp
Çıktı   : üç dilde aynı (=)
"""

dizi = []               # üretilmekte olan dizi (karakter listesi)
cagri_sayisi = 0
dizi_sayisi = 0         # üretilen (yaprak) dizi sayısı
yazdir_mi = True


def ikili_uret(k, n):
    """dizi[0..k-1] belirlendi; dizi[k..n-1] için iki seçeneği dene"""
    global cagri_sayisi, dizi_sayisi
    cagri_sayisi += 1
    if k == n:                      # yaprak: dizi tamamlandı
        dizi_sayisi += 1
        if yazdir_mi:
            print("".join(dizi))
        return
    dizi[k] = "0"                   # sol dal: k. bit 0
    ikili_uret(k + 1, n)
    dizi[k] = "1"                   # sağ dal: k. bit 1
    ikili_uret(k + 1, n)


def main():
    global dizi, cagri_sayisi, dizi_sayisi, yazdir_mi
    print("1) n = 3 için tüm ikili diziler (sözlük sırası)")
    dizi = ["0"] * 3
    ikili_uret(0, 3)
    print(f"dizi = {dizi_sayisi}   çağrı = {cagri_sayisi}")

    print("\n2) Sayım: dizi = 2^n, çağrı = 2^(n+1) - 1")
    print("  n      dizi       2^n     çağrı  2^(n+1)-1  eşit")
    yazdir_mi = False
    for n in range(1, 17):
        cagri_sayisi = 0
        dizi_sayisi = 0
        dizi = ["0"] * n
        ikili_uret(0, n)
        iki_n = 1 << n
        esit = dizi_sayisi == iki_n and cagri_sayisi == 2 * iki_n - 1
        print(f"{n:3d} {dizi_sayisi:9d} {iki_n:9d} {cagri_sayisi:9d} "
              f"{2 * iki_n - 1:10d}  " + ("evet" if esit else "HAYIR"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (std::bitset yalnızca gösterim);
# Python — itertools.product("01", repeat=n) (yalnızca kâhin olarak).

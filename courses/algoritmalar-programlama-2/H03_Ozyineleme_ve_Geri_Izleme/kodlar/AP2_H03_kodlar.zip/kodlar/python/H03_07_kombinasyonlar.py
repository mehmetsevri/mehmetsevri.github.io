"""H03_07_kombinasyonlar.py — AP-2 Hafta 3 · Örnek 7 (★★)
Amaç    : k-kombinasyonlar: başlangıç indisiyle tekrarsız üretim (her küme
          artan indisle bir kez); üretilen sayının C(n, k) ile doğrulanması
Çalıştır: python3 H03_07_kombinasyonlar.py
Eşleri  : c/H03_07_kombinasyonlar.c · cpp/H03_07_kombinasyonlar.cpp
Çıktı   : üç dilde aynı (=)
"""

a = []                  # elemanlar: 1, 2, ..., n
n = 0
yol = []                # seçilenler (artan indisle)
cagri_sayisi = 0
komb_sayisi = 0
yazdir_mi = True


def komb_isle():
    global komb_sayisi
    komb_sayisi += 1
    if yazdir_mi:
        print("{", end="")
        for j in range(len(yol)):
            print((", " if j > 0 else "") + str(yol[j]), end="")
        print("}\n" if komb_sayisi % 5 == 0 else "}  ", end="")


def kombinasyon(bas, k):
    """a[bas..n-1] içinden k - len(yol) eleman daha seç"""
    global cagri_sayisi
    cagri_sayisi += 1
    uzunluk = len(yol)
    if uzunluk == k:                # k eleman seçildi
        komb_isle()
        return
    # i en çok n - (k - uzunluk): sağda yeterli eleman kalmalı
    for i in range(bas, n - (k - uzunluk) + 1):
        yol.append(a[i])            # seç
        kombinasyon(i + 1, k)       # dene: yalnızca i'den sonrakiler
        yol.pop()                   # geri al


def kombinasyon_sayisi(m, k):
    """C(m, k) = m! / (k! (m-k)!), çarpımsal formülle (her adım tam bölünür)"""
    c = 1
    for i in range(1, k + 1):
        c = c * (m - k + i) // i    # c = C(m-k+i, i); // tamsayı bölmesi
    return c


def calistir(boyut, k):
    global n, a, cagri_sayisi, komb_sayisi
    n = boyut
    a = [i + 1 for i in range(n)]
    yol.clear()
    cagri_sayisi = 0
    komb_sayisi = 0
    kombinasyon(0, k)


def satir_yaz(boyut, k):
    c = kombinasyon_sayisi(boyut, k)
    print(f"{boyut:3d} {k:3d} {komb_sayisi:10d} {c:9d} {cagri_sayisi:9d}  "
          + ("evet" if komb_sayisi == c else "HAYIR"))


def main():
    global yazdir_mi
    print("1) n = 5, k = 3: {1..5} içinden 3'lü seçimler")
    calistir(5, 3)
    print(f"kombinasyon = {komb_sayisi}   C(5, 3) = "
          f"{kombinasyon_sayisi(5, 3)}   çağrı = {cagri_sayisi}")

    print("\n2) n = 10 için her k: üretilen = C(n, k)?")
    print("  n   k   üretilen    C(n,k)     çağrı  eşit")
    yazdir_mi = False
    for k in range(11):
        calistir(10, k)
        satir_yaz(10, k)
    calistir(20, 10)
    satir_yaz(20, 10)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (std::next_permutation ile bir
# bool maskesi dolaşılabilir); Python — itertools.combinations, math.comb
# (yalnızca kâhin).

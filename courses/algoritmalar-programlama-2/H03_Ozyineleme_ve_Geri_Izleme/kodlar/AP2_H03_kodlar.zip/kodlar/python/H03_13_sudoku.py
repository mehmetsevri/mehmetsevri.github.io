"""H03_13_sudoku.py — AP-2 Hafta 3 · Örnek 13 (★★★, meydan okuma)
Amaç    : Sudoku çözücüsü: kısıt yayılımı olmadan geri izleme. İlk boş
          kareye uygun her rakamı dene; çıkmazda geri al; düğümler sayılır.
Çalıştır: python3 H03_13_sudoku.py < ../girdiler/H03_13_sudoku.txt
Eşleri  : c/H03_13_sudoku.c · cpp/H03_13_sudoku.cpp
Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1; süre stderr
"""

import sys

from zamanlayici import zaman_sn

tablo = [[0] * 9 for _ in range(9)]     # 0 = boş kare
ipucu = [[0] * 9 for _ in range(9)]     # başlangıçtaki rakamlar
satir_var = [[False] * 10 for _ in range(9)]   # r. satırda d var mı?
sutun_var = [[False] * 10 for _ in range(9)]
kutu_var = [[False] * 10 for _ in range(9)]    # 3x3 kutular: 0..8
dugum_sayisi = 0


def kutu_no(r, c):
    return (r // 3) * 3 + c // 3


def uygun_mu(r, c, d):
    return (not satir_var[r][d] and not sutun_var[c][d]
            and not kutu_var[kutu_no(r, c)][d])


def koy(r, c, d, var):
    """var = True: d rakamını (r, c)'ye koy; var = False: kaldır"""
    tablo[r][c] = d if var else 0
    satir_var[r][d] = var
    sutun_var[c][d] = var
    kutu_var[kutu_no(r, c)][d] = var


def coz(k):
    """k = 0..80 (satır öncelikli kare no); k'dan sonraki ilk boş kareyi
    doldur"""
    global dugum_sayisi
    dugum_sayisi += 1
    while k < 81 and tablo[k // 9][k % 9] != 0:
        k += 1                      # dolu kareleri atla
    if k == 81:
        return True                 # boş kare kalmadı: çözüldü
    r, c = k // 9, k % 9
    for d in range(1, 10):
        if uygun_mu(r, c, d):
            koy(r, c, d, True)      # seç
            if coz(k + 1):          # dene
                return True         # tek çözüm yeter: dur
            koy(r, c, d, False)     # geri al
    return False                    # hiçbir rakam olmadı: geri dön


def bulmaca_oku():
    """9 satır, her biri 9 karakter: '1'..'9' ya da '.'/'0' (boş)"""
    satirlar = sys.stdin.read().splitlines()
    if len(satirlar) < 9:
        return False
    for r in range(9):
        satir = satirlar[r]
        if len(satir) != 9:
            return False
        for c in range(9):
            k = satir[c]
            d = int(k) if "1" <= k <= "9" else 0
            if d == 0 and k not in (".", "0"):
                return False
            if d != 0:
                if not uygun_mu(r, c, d):
                    return False    # ipuçları çelişiyor
                koy(r, c, d, True)
            ipucu[r][c] = d
    return True


def tablo_yaz():
    for r in range(9):
        if r > 0 and r % 3 == 0:
            print("------+-------+------")
        for c in range(9):
            if c > 0:
                print(" | " if c % 3 == 0 else " ", end="")
            print(str(tablo[r][c]) if tablo[r][c] else ".", end="")
        print()


def dogrula():
    """Her satır, sütun ve kutuda 1..9 tam bir kez mi; ipuçları yerinde mi?"""
    for i in range(9):
        s, t, k = [0] * 10, [0] * 10, [0] * 10
        for j in range(9):
            s[tablo[i][j]] += 1
            t[tablo[j][i]] += 1
            k[tablo[(i // 3) * 3 + j // 3][(i % 3) * 3 + j % 3]] += 1
        for d in range(1, 10):
            if s[d] != 1 or t[d] != 1 or k[d] != 1:
                return False
    for r in range(9):
        for c in range(9):
            if ipucu[r][c] != 0 and ipucu[r][c] != tablo[r][c]:
                return False
    return True


def main():
    if not bulmaca_oku():
        print("Hatalı Sudoku girdisi", file=sys.stderr)
        sys.exit(1)
    ipucu_sayisi = 0
    for satir in ipucu:
        for d in satir:
            ipucu_sayisi += 1 if d != 0 else 0
    print(f"Bulmaca ({ipucu_sayisi} ipucu):")
    tablo_yaz()
    t0 = zaman_sn()
    cozuldu = coz(0)
    sure = zaman_sn() - t0
    if not cozuldu:
        print(f"\nÇözüm yok (ziyaret edilen düğüm = {dugum_sayisi})")
        return
    print(f"\nÇözüm (ziyaret edilen düğüm = {dugum_sayisi}):")
    tablo_yaz()
    print("doğrulama: " + ("geçerli" if dogrula() else "GEÇERSİZ"))
    print(f"çözme süresi: {sure * 1e3:.3f} ms", file=sys.stderr)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Gerçek çözücüler kısıt
# yayılımı ve "en az seçenekli kare önce" sezgisiyle düğüm sayısını azaltır.

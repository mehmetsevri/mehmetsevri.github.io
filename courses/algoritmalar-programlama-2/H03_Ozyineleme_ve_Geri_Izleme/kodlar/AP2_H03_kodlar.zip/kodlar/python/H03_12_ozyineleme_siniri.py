"""H03_12_ozyineleme_siniri.py — AP-2 Hafta 3 · Örnek 12 (★★)
Amaç    : Aynı özyinelemeli toplam(n) C'de 10 000 derinlikte sorunsuz;
          Python'da 1000 civarında RecursionError. Python'un sınırı yapay
          bir korumadır: sys.getrecursionlimit() (varsayılan 1000).
Çalıştır: python3 H03_12_ozyineleme_siniri.py [n]  (n verilirse sınır
          n + 100'e yükseltilir ve yalnız toplam(n) hesaplanır)
Eşleri  : c/H03_12_ozyineleme_siniri.c · cpp/H03_12_ozyineleme_siniri.cpp
Çıktı   : Δ — dile özgü (C/C++ derinlikleri aynı, Python farklı)
"""

import sys


# 1 + 2 + ... + n; her çağrı bir çerçeve açar
def toplam(n):
    if n == 0:
        return 0
    return n + toplam(n - 1)


def main():
    if len(sys.argv) > 1:               # isteğe bağlı: tek derinlik
        try:
            n = int(sys.argv[1])
        except ValueError:
            n = -1
        if n < 0:
            print(f"kullanım: {sys.argv[0]} [n >= 0]", file=sys.stderr)
            sys.exit(2)
        sys.setrecursionlimit(n + 100)  # sınırı bilerek yükselt
        print(f"toplam({n}) = {toplam(n)}")
        return
    derinlikler = [900, 1000, 10000]
    print("Özyineleme sınırı deneyi — Python")
    print("toplam(n) = n + toplam(n - 1), toplam(0) = 0")
    print(f"sys.getrecursionlimit() = {sys.getrecursionlimit()}")
    for n in derinlikler:
        try:
            print(f"derinlik {n:6d}: toplam = {toplam(n)}")
        except RecursionError as hata:
            print(f"derinlik {n:6d}: RecursionError yakalandı")
            print(f"  ileti: {hata}", file=sys.stderr)
    print("Python'da sınır yorumlayıcının koruma sayacıdır; aşılınca\n"
          "RecursionError fırlatılır ve program yakalayıp sürdürebilir.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok. Derinlik sınırı: Python'da
# sys.getrecursionlimit()/sys.setrecursionlimit(); C/C++'ta yığın boyutu
# işletim sistemi (ulimit -s) ve bağlayıcı (ör. MinGW -Wl,--stack) ayarıdır.

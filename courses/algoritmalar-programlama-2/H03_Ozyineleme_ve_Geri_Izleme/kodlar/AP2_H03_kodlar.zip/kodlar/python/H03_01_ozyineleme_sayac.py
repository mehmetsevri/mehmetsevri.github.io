"""H03_01_ozyineleme_sayac.py — AP-2 Hafta 3 · Örnek 1 (★)
Amaç    : Özyinelemeli toplam ve Fibonacci'de çağrı sayacı ve derinlik;
          fib(5) çağrı ağacının girintili çizimi; çağrı = 2·F(n+1) − 1
Çalıştır: python3 H03_01_ozyineleme_sayac.py
Eşleri  : c/H03_01_ozyineleme_sayac.c · cpp/H03_01_ozyineleme_sayac.cpp
Çıktı   : üç dilde aynı (=)
"""

cagri_sayisi = 0          # toplam çağrı sayısı
en_buyuk_derinlik = 0     # aynı anda açık en çok çerçeve
goruldu = [False] * 64    # fib(k) daha önce çağrıldı mı?


def sayaclari_sifirla():
    global cagri_sayisi, en_buyuk_derinlik
    cagri_sayisi = 0
    en_buyuk_derinlik = 0


def toplam(n, d):
    """1 + 2 + ... + n; d: bu çağrının derinliği (kök = 1)"""
    global cagri_sayisi, en_buyuk_derinlik
    cagri_sayisi += 1
    if d > en_buyuk_derinlik:
        en_buyuk_derinlik = d
    if n == 0:
        return 0                        # temel durum
    return n + toplam(n - 1, d + 1)     # özyinelemeli adım


def fib(n, d):
    """n. Fibonacci sayısı: F(0) = 0, F(1) = 1"""
    global cagri_sayisi, en_buyuk_derinlik
    cagri_sayisi += 1
    if d > en_buyuk_derinlik:
        en_buyuk_derinlik = d
    if n < 2:
        return n                        # temel durum
    return fib(n - 1, d + 1) + fib(n - 2, d + 1)


def fib_agac(n, d):
    """fib ile aynı çağrılar; her çağrıyı girintiyle yazar (ağaç çizimi)"""
    global cagri_sayisi, en_buyuk_derinlik
    cagri_sayisi += 1
    if d > en_buyuk_derinlik:
        en_buyuk_derinlik = d
    print("  " * (d - 1), end="")       # girinti = derinlik
    print(f"fib({n})" + ("  (tekrar)" if goruldu[n] else ""))
    goruldu[n] = True
    if n < 2:
        return n
    return fib_agac(n - 1, d + 1) + fib_agac(n - 2, d + 1)


def fib_dongu(n):
    """Kâhin: döngüyle F(n)"""
    onceki, simdiki = 0, 1
    if n == 0:
        return 0
    for _ in range(2, n + 1):
        onceki, simdiki = simdiki, onceki + simdiki
    return simdiki


def main():
    toplam_n = [5, 100]
    fib_n = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25]

    print("1) toplam(n) = 1 + 2 + ... + n")
    for n in toplam_n:
        sayaclari_sifirla()
        t = toplam(n, 1)
        print(f"toplam({n}) = {t}   çağrı = {cagri_sayisi}   "
              f"en büyük derinlik = {en_buyuk_derinlik}")

    print("\n2) fib(5) çağrı ağacı (ön sıra; girinti = derinlik)")
    sayaclari_sifirla()
    f5 = fib_agac(5, 1)
    print(f"fib(5) = {f5}   çağrı = {cagri_sayisi}   "
          f"en büyük derinlik = {en_buyuk_derinlik}")
    farkli = 0
    for k in range(6):
        farkli += 1 if goruldu[k] else 0
    print(f"farklı alt problem = {farkli}   "
          f"tekrarlanan çağrı = {cagri_sayisi - farkli}")

    print("\n3) fib(n): çağrı sayısı = 2*F(n+1) - 1 mi?")
    print("  n     fib(n)     çağrı  2*F(n+1)-1  derinlik  eşit")
    for n in fib_n:
        sayaclari_sifirla()
        f = fib(n, 1)
        beklenen = 2 * fib_dongu(n + 1) - 1
        print(f"{n:3d} {f:10d} {cagri_sayisi:9d} {beklenen:11d} "
              f"{en_buyuk_derinlik:9d}  "
              + ("evet" if cagri_sayisi == beklenen else "HAYIR"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok — özyineleme dilin kendisidir. (Python'da
# functools.lru_cache tekrarlanan çağrıları önler; H13'te memoization.)

"""H03_11_labirent.py — AP-2 Hafta 3 · Örnek 11 (★★)
Amaç    : Labirentte yol bulma: ızgarada geri izleme (sağ, aşağı, sol,
          yukarı); yol '*', denenip geri dönülen hücre 'x' ile işaretlenir
Çalıştır: python3 H03_11_labirent.py < ../girdiler/H03_11_labirent.txt
Eşleri  : c/H03_11_labirent.c · cpp/H03_11_labirent.cpp
Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
"""

import sys

MAKS_SATIR = 40
MAKS_SUTUN = 80

izgara = []             # satır başına bir karakter listesi
satir_sayisi = 0
sutun_sayisi = 0
ziyaret = 0             # yol_bul çağrısı
geri_donulen = 0        # çıkmaz olduğu anlaşılan hücre
DR = [0, 1, 0, -1]      # sağ, aşağı, sol, yukarı
DC = [1, 0, -1, 0]


def gecilebilir(r, c):
    """(r, c) ızgarada ve henüz denenmemiş bir boş hücre ya da çıkış mı?"""
    return (0 <= r < satir_sayisi and 0 <= c < sutun_sayisi
            and izgara[r][c] in (".", "E"))


def yol_bul(r, c):
    """(r, c)'den çıkışa yol ara; bulunursa True döner"""
    global ziyaret, geri_donulen
    ziyaret += 1
    if izgara[r][c] == "E":
        return True                     # çıkışa ulaşıldı
    if izgara[r][c] != "S":
        izgara[r][c] = "*"              # seç: hücre yola eklenir
    for d in range(4):
        yr, yc = r + DR[d], c + DC[d]
        if gecilebilir(yr, yc) and yol_bul(yr, yc):
            return True                 # yol bulundu: '*'lar kalır
    if izgara[r][c] != "S":
        izgara[r][c] = "x"              # geri al: buradan çıkış yok
    geri_donulen += 1
    return False


def labirent_oku():
    """İlk satır "satır sütun", ardından ızgara; tam bir S ve bir E olmalı.
    Başarıda (bas_r, bas_c), hatada None döner"""
    global izgara, satir_sayisi, sutun_sayisi
    satirlar = sys.stdin.read().splitlines()
    if not satirlar:
        return None
    parca = satirlar[0].split()
    try:
        r, c = int(parca[0]), int(parca[1])
    except (ValueError, IndexError):
        return None
    if not (1 <= r <= MAKS_SATIR and 1 <= c <= MAKS_SUTUN):
        return None
    if len(satirlar) < r + 1:
        return None
    satir_sayisi, sutun_sayisi = r, c
    izgara = [list(satirlar[i + 1]) for i in range(r)]
    s_sayisi = e_sayisi = 0
    bas = None
    for i in range(satir_sayisi):
        if len(izgara[i]) != sutun_sayisi:
            return None
        for j in range(sutun_sayisi):
            k = izgara[i][j]
            if k == "S":
                s_sayisi += 1
                bas = (i, j)
            elif k == "E":
                e_sayisi += 1
            elif k not in ("#", "."):
                return None
    return bas if s_sayisi == 1 and e_sayisi == 1 else None


def main():
    bas = labirent_oku()
    if bas is None:
        print("Hatalı labirent girdisi", file=sys.stderr)
        sys.exit(1)
    bas_r, bas_c = bas
    print(f"Labirent {satir_sayisi} x {sutun_sayisi}, "
          f"giriş S = ({bas_r}, {bas_c})")
    print("Yön sırası: sağ, aşağı, sol, yukarı")
    bulundu = yol_bul(bas_r, bas_c)
    yol_hucre = 0
    for s in izgara:
        for k in s:
            yol_hucre += 1 if k == "*" else 0
    if bulundu:
        print(f"Sonuç: yol bulundu, uzunluk = {yol_hucre + 1} adım")
    else:
        print("Sonuç: yol yok")
    print(f"ziyaret edilen hücre = {ziyaret}   "
          f"geri dönülen hücre = {geri_donulen}")
    for s in izgara:
        print("".join(s))
    print("İşaretler: * yol, x denenip geri dönülen hücre")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). En kısa yol için H11'deki
# genişlik öncelikli arama (BFS) kullanılır; bu yol en kısa olmayabilir.

"""H03_05_bit_maskesi.py — AP-2 Hafta 3 · Örnek 5 (★★)
Amaç    : Alt kümeleri özyinelemesiz üretmek: maske = 0 … 2^n − 1; bitler
          hangi elemanın alındığını söyler. Örnek 4 ile karşılaştırma
Çalıştır: python3 H03_05_bit_maskesi.py
Eşleri  : c/H03_05_bit_maskesi.c · cpp/H03_05_bit_maskesi.cpp
Çıktı   : üç dilde aynı (=)
"""

MAKS_N = 16

a = [0] * MAKS_N            # küme elemanları
sira = []                   # özyinelemenin ürettiği maskeler
goruldu = [0] * (1 << MAKS_N)


def bit_no(i, n, a0_solda):
    """Eşleme: a0_solda True ise a[i] ↔ bit (n-1-i) (a[0] en soldaki bit);
    False ise a[i] ↔ bit i (a[0] en sağdaki bit)"""
    return n - 1 - i if a0_solda else i


def kume_metni(maske, n, a0_solda):
    """maskenin gösterdiği alt kümeyi metin olarak döndürür: "{1, 3}" """
    metin = "{"
    ilk = True
    for i in range(n):
        if (maske >> bit_no(i, n, a0_solda)) & 1:
            metin += ("" if ilk else ", ") + str(a[i])
            ilk = False
    return metin + "}"


def maske_ile_uret(n):
    """Bit maskesiyle üretim: her maske bir alt küme"""
    print("maske  ikili  a[0] soldaki bit  a[0] sağdaki bit")
    for maske in range(1 << n):
        print(f"{maske:5d}  ", end="")
        for b in range(n - 1, -1, -1):
            print("1" if (maske >> b) & 1 else "0", end="")
        print(f"    {kume_metni(maske, n, True):<16}  "
              f"{kume_metni(maske, n, False)}")


def ozyinelemeli_maskeler(i, n, a0_solda, maske):
    """Örnek 4'teki dahil etme / dahil et özyinelemesi; her yaprakta
    alt kümeyi maske olarak kaydeder"""
    if i == n:
        sira.append(maske)
        return
    bit = 1 << bit_no(i, n, a0_solda)
    ozyinelemeli_maskeler(i + 1, n, a0_solda, maske)         # dahil etme
    ozyinelemeli_maskeler(i + 1, n, a0_solda, maske | bit)   # dahil et


def ayni_sira(n):
    """Özyinelemenin k. yaprağı k maskesi mi? (aynı sıra)"""
    for k in range(1 << n):
        if sira[k] != k:
            return False
    return True


def her_kume_bir_kez(n):
    """Her maske tam bir kez üretildi mi? (aynı küme ailesi)"""
    for k in range(1 << n):
        goruldu[k] = 0
    for m in sira:
        goruldu[m] += 1
    for k in range(1 << n):
        if goruldu[k] != 1:
            return False
    return True


def main():
    print("1) a = {1, 2, 3}: maske = 0 ... 2^3 - 1")
    for i in range(MAKS_N):
        a[i] = i + 1
    maske_ile_uret(3)

    print("\n2) Özyineleme (Örnek 4) ile bit maskesi aynı kümeleri mi "
          "üretir?")
    print("  n      küme   a[0] solda: aynı sıra"
          " | a[0] sağda: aynı sıra / aynı aile")
    for n in range(1, MAKS_N + 1):
        sira.clear()
        ozyinelemeli_maskeler(0, n, True, 0)
        solda_sira = ayni_sira(n)
        sira.clear()
        ozyinelemeli_maskeler(0, n, False, 0)
        sagda_sira = ayni_sira(n)
        sagda_aile = her_kume_bir_kez(n)
        print(f"{n:3d} {len(sira):9d}   "
              + ("evet" if solda_sira else "hayır") + " | "
              + ("evet" if sagda_sira else "hayır") + " / "
              + ("evet" if sagda_aile else "hayır"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::bitset<N>(maske) yalnızca
# gösterim; Python — itertools.product([0, 1], repeat=n) (yalnızca kâhin).

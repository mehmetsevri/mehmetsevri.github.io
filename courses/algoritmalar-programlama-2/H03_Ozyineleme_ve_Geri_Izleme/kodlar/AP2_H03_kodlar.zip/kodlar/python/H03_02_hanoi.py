"""H03_02_hanoi.py — AP-2 Hafta 3 · Örnek 2 (★)
Amaç    : Hanoi Kuleleri; T(n) = 2T(n−1) + 1 bağıntısının yerine koyma
          ile açılımı ve hamle sayacıyla 2^n − 1 sonucunun doğrulanması
Çalıştır: python3 H03_02_hanoi.py
Eşleri  : c/H03_02_hanoi.c · cpp/H03_02_hanoi.cpp
Çıktı   : üç dilde aynı (=)
"""

hamle_sayisi = 0     # yapılan hamle sayısı
listele = False      # True ise her hamle yazdırılır


def hanoi(n, kaynak, hedef, yardimci):
    """n diski kaynak çubuğundan hedef çubuğuna taşır"""
    global hamle_sayisi
    if n == 0:
        return                               # temel durum: disk yok
    hanoi(n - 1, kaynak, yardimci, hedef)    # üstteki n-1 disk
    hamle_sayisi += 1                        # en büyük disk
    if listele:
        print(f"{hamle_sayisi:2d}. hamle: disk {n}  {kaynak} -> {hedef}")
    hanoi(n - 1, yardimci, hedef, kaynak)    # n-1 disk yeniden


def main():
    global hamle_sayisi, listele
    print("1) n = 3 için hamleler")
    listele = True
    hanoi(3, "A", "C", "B")
    listele = False

    print("\n2) Yerine koyma: T(n) = 2T(n-1) + 1, T(0) = 0")
    n = 5
    katsayi, ek = 1, 0                       # T(n) = katsayi*T(n-k) + ek
    print(f"T({n})", end="")
    for k in range(1, n + 1):
        katsayi *= 2
        ek = 2 * ek + 1
        print(f" = {katsayi}T({n - k}) + {ek}", end="")
        if k % 2 == 0:
            print("\n    ", end="")
    print(f" = {ek}")

    print("\n3) Hamle sayacı ve 2^n - 1")
    print("  n       hamle  2T(n-1)+1       2^n-1  eşit")
    t_onceki = 0                             # T(n-1), bağıntıdan
    for n in range(1, 21):
        hamle_sayisi = 0
        hanoi(n, "A", "C", "B")
        t_bagint = 2 * t_onceki + 1
        kapali = (1 << n) - 1
        esit = hamle_sayisi == kapali and t_bagint == kapali
        print(f"{n:3d} {hamle_sayisi:11d} {t_bagint:10d} {kapali:11d}  "
              + ("evet" if esit else "HAYIR"))
        t_onceki = t_bagint


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (algoritmanın kendisi; standart kütüphanelerde
# Hanoi çözücüsü bulunmaz).

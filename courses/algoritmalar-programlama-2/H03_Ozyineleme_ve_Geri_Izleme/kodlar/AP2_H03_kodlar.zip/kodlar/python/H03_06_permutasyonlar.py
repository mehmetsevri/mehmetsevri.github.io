"""H03_06_permutasyonlar.py — AP-2 Hafta 3 · Örnek 6 (★★)
Amaç    : Tüm permütasyonlar — kullanildi dizisiyle, sözlük sırasında
          (seç → dene → geri al); takasla üretimle sıra karşılaştırması
Çalıştır: python3 H03_06_permutasyonlar.py
Eşleri  : c/H03_06_permutasyonlar.c · cpp/H03_06_permutasyonlar.cpp
Çıktı   : üç dilde aynı (=)
"""

a = []                  # sıralı elemanlar: 1, 2, ..., n
n = 0
yol = []                # kurulmakta olan permütasyon
kullanildi = []         # a[i] yol'da mı?
onceki = []             # bir önceki permütasyon
cagri_sayisi = 0
perm_sayisi = 0
sozluk_sirali = True    # her permütasyon öncekinden büyük mü?
yazdir_mi = True


def perm_isle(p):
    """Bir permütasyon tamamlandı: say, sırayı denetle, (istenirse) yaz"""
    global perm_sayisi, sozluk_sirali, onceki
    perm_sayisi += 1
    if perm_sayisi > 1:
        k = 0
        while k < n and p[k] == onceki[k]:
            k += 1                  # ilk farklı konum
        if k == n or p[k] < onceki[k]:
            sozluk_sirali = False
    onceki = p[:]                   # kopya (yalnız onceki = p yetmez)
    if yazdir_mi:
        for k in range(n):
            print(p[k], end="")
        print("\n" if perm_sayisi % 6 == 0 else " ", end="")


# yol[0..k-1] dolu; k. konuma kullanılmamış her elemanı dene
def permutasyon(k):
    global cagri_sayisi
    cagri_sayisi += 1
    if k == n:             # yaprak
        perm_isle(yol)
        return
    for i in range(n):
        if not kullanildi[i]:
            kullanildi[i] = True   # seç
            yol[k] = a[i]
            permutasyon(k + 1)     # dene
            kullanildi[i] = False  # geri al


def permutasyon_takas(k):
    """Takasla üretim: a[k..n-1] içinden her elemanı k. konuma getir"""
    global cagri_sayisi
    cagri_sayisi += 1
    if k == n:
        perm_isle(a)
        return
    for i in range(k, n):
        a[k], a[i] = a[i], a[k]     # seç
        permutasyon_takas(k + 1)    # dene
        a[k], a[i] = a[i], a[k]     # geri al


def baslat(boyut):
    global n, a, yol, kullanildi, cagri_sayisi, perm_sayisi, sozluk_sirali
    n = boyut
    a = [i + 1 for i in range(n)]
    yol = [0] * n
    kullanildi = [False] * n
    cagri_sayisi = 0
    perm_sayisi = 0
    sozluk_sirali = True


def main():
    global yazdir_mi
    print("1) n = 3, kullanildi dizisiyle:")
    baslat(3)
    permutasyon(0)
    print(f"permütasyon = {perm_sayisi}   çağrı = {cagri_sayisi}   "
          "sözlük sırasında: " + ("evet" if sozluk_sirali else "hayır"))

    print("\n2) n = 3, takasla:")
    baslat(3)
    permutasyon_takas(0)
    print(f"permütasyon = {perm_sayisi}   çağrı = {cagri_sayisi}   "
          "sözlük sırasında: " + ("evet" if sozluk_sirali else "hayır"))

    print("\n3) kullanildi dizisiyle sayım: çağrı / n! -> e = 2.71828...")
    print("  n      perm     çağrı  çağrı/n!  perm = n!  sözlük")
    yazdir_mi = False
    faktoriyel = 1
    for boyut in range(1, 9):
        faktoriyel *= boyut
        baslat(boyut)
        permutasyon(0)
        oran = cagri_sayisi / faktoriyel
        esit = "evet" if perm_sayisi == faktoriyel else "HAYIR"
        print(f"{boyut:3d} {perm_sayisi:9d} {cagri_sayisi:9d} {oran:9.4f}  "
              f"{esit:<9}  " + ("evet" if sozluk_sirali else "hayır"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::next_permutation (sözlük
# sırasında sonraki); Python — itertools.permutations (yalnızca kâhin).

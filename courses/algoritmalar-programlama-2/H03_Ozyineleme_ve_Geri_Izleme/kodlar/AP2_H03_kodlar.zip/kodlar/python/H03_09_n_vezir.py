"""H03_09_n_vezir.py — AP-2 Hafta 3 · Örnek 9 (★★★)
Amaç    : N-vezir: satır satır geri izleme (her satıra bir vezir; güvenli
          sütunları dene); N = 1…10 için çözüm ve ziyaret edilen düğüm sayısı
Çalıştır: python3 H03_09_n_vezir.py
Eşleri  : c/H03_09_n_vezir.c · cpp/H03_09_n_vezir.cpp
Çıktı   : üç dilde aynı (=)
"""

n = 0
sutun = []              # sutun[r]: r. satırdaki vezirin sütunu
cozum_sayisi = 0
dugum_sayisi = 0        # ziyaret edilen düğüm (çağrı)
yazilacak = 0           # ilk kaç çözüm tahta olarak yazılsın


def guvenli_mi(r, c):
    """(r, c) karesi, 0..r-1 satırlarındaki vezirlerle çakışmıyor mu?"""
    for i in range(r):
        fark = sutun[i] - c
        if fark == 0 or fark == r - i or fark == i - r:
            return False            # aynı sütun ya da aynı köşegen
    return True


def tahta_yaz():
    for r in range(n):
        for c in range(n):
            print((" " if c > 0 else "") + ("V" if sutun[r] == c else "."),
                  end="")
        print()


def yerlestir(r):
    """0..r-1 satırlarına vezir yerleşti; r. satır için sütun ara"""
    global cozum_sayisi, dugum_sayisi
    dugum_sayisi += 1
    if r == n:                      # n vezir yerleşti: çözüm
        cozum_sayisi += 1
        if cozum_sayisi <= yazilacak:
            print(f"çözüm {cozum_sayisi}: sütunlar =", end="")
            for i in range(n):
                print(f" {sutun[i]}", end="")
            print()
            tahta_yaz()
        return
    for c in range(n):
        if guvenli_mi(r, c):
            sutun[r] = c            # seç
            yerlestir(r + 1)        # dene
        # geri al: sutun[r] bir sonraki c ile yeniden yazılır


def coz(boyut, yaz):
    global n, sutun, yazilacak, cozum_sayisi, dugum_sayisi
    n = boyut
    sutun = [0] * n
    yazilacak = yaz
    cozum_sayisi = 0
    dugum_sayisi = 0
    yerlestir(0)


def main():
    bilinen = [0, 1, 0, 0, 2, 10, 4, 40, 92, 352, 724]

    print("1) N = 4: tüm çözümler")
    coz(4, 2)
    print(f"çözüm = {cozum_sayisi}   ziyaret edilen düğüm = {dugum_sayisi}")

    print("\n2) N = 8: ilk çözüm (sözlük sırasında)")
    coz(8, 1)
    print(f"çözüm = {cozum_sayisi}   ziyaret edilen düğüm = {dugum_sayisi}")

    print("\n3) N = 1..10")
    print("  N   çözüm   bilinen    düğüm")
    for boyut in range(1, 11):
        coz(boyut, 0)
        print(f"{boyut:3d} {cozum_sayisi:7d} {bilinen[boyut]:9d} "
              f"{dugum_sayisi:8d}"
              + ("" if cozum_sayisi == bilinen[boyut] else "  HATA"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Kâhin: N ≤ 8 için tüm
# permütasyonları deneyen kaba kuvvet (Python'da itertools.permutations).

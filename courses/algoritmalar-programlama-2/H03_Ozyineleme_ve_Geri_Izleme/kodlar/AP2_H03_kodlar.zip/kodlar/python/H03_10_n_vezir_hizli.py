"""H03_10_n_vezir_hizli.py — AP-2 Hafta 3 · Örnek 10 (★★★)
Amaç    : N-vezirde güvenlik denetimi: önceki satırları tarama (O(r)) ve
          sütun/köşegen dizileriyle O(1) denetim; sayaçlar ve süreler
Çalıştır: python3 H03_10_n_vezir_hizli.py [N_ust=10] [tekrar=1]
Eşleri  : c/H03_10_n_vezir_hizli.c · cpp/H03_10_n_vezir_hizli.cpp
Çıktı   : üç dilde aynı (=) — süreler yalnızca stderr'e yazılır
"""

import sys

from zamanlayici import olc_ortanca

MAKS_N = 14

n = 0
sutun = [0] * MAKS_N                    # tarama: r. satırın sütunu
sutun_dolu = [False] * MAKS_N           # c sütununda vezir var mı?
kosegen1 = [False] * (2 * MAKS_N - 1)   # r + c sabit
kosegen2 = [False] * (2 * MAKS_N - 1)   # r - c + n - 1 sabit
cozum_sayisi = 0
dugum_sayisi = 0
denetim_sayisi = 0                      # karşılaştırma / dizi denetimi


def guvenli_mi_tarama(r, c):
    """A) Tarama: (r, c) için önceki r vezirle tek tek karşılaştır — O(r)"""
    global denetim_sayisi
    for i in range(r):
        denetim_sayisi += 1
        fark = sutun[i] - c
        if fark == 0 or fark == r - i or fark == i - r:
            return False
    return True


def yerlestir_tarama(r):
    global dugum_sayisi, cozum_sayisi
    dugum_sayisi += 1
    if r == n:
        cozum_sayisi += 1
        return
    for c in range(n):
        if guvenli_mi_tarama(r, c):
            sutun[r] = c
            yerlestir_tarama(r + 1)


# B) Dizilerle O(1) denetim: sütun ve iki köşegen dolu mu?
def bos_mu(r, c):
    global denetim_sayisi
    denetim_sayisi += 1
    return (not sutun_dolu[c]
            and not kosegen1[r + c]
            and not kosegen2[r - c + n - 1])


def isaretle(r, c, deger):
    sutun_dolu[c] = deger
    kosegen1[r + c] = deger
    kosegen2[r - c + n - 1] = deger


def yerlestir_dizi(r):
    global dugum_sayisi, cozum_sayisi
    dugum_sayisi += 1
    if r == n:
        cozum_sayisi += 1
        return
    for c in range(n):
        if bos_mu(r, c):
            isaretle(r, c, True)    # seç
            yerlestir_dizi(r + 1)   # dene
            isaretle(r, c, False)   # geri al


def sifirla(boyut):
    global n, cozum_sayisi, dugum_sayisi, denetim_sayisi
    n = boyut
    cozum_sayisi = 0
    dugum_sayisi = 0
    denetim_sayisi = 0
    for i in range(2 * MAKS_N - 1):
        kosegen1[i] = False
        kosegen2[i] = False
        if i < MAKS_N:
            sutun_dolu[i] = False


def tarama_gorevi(boyut):
    """zamanlayici için görevler"""
    sifirla(boyut)
    yerlestir_tarama(0)


def dizi_gorevi(boyut):
    sifirla(boyut)
    yerlestir_dizi(0)


def arguman_oku(s, alt, ust):
    """"123" gibi bir argümanı [alt, ust] aralığında tamsayıya çevirir;
    geçersizse None"""
    try:
        deger = int(s)
    except ValueError:
        return None
    return deger if alt <= deger <= ust else None


def main():
    n_ust, tekrar = 10, 1
    if len(sys.argv) > 1:
        n_ust = arguman_oku(sys.argv[1], 4, MAKS_N)
    if len(sys.argv) > 2:
        tekrar = arguman_oku(sys.argv[2], 1, 101)
    if n_ust is None or tekrar is None:
        print(f"kullanım: {sys.argv[0]} [N_ust 4..{MAKS_N}] "
              "[tekrar 1..101]", file=sys.stderr)
        sys.exit(2)
    print("  N   çözüm    düğüm  tarama karşılaştırma  dizi denetimi")
    for boyut in range(4, n_ust + 1):
        # her ölçüm sayaçları sıfırlar; son çalıştırmanın sayaçları kalır
        t1 = olc_ortanca(lambda: tarama_gorevi(boyut), tekrar)
        c1, d1 = cozum_sayisi, dugum_sayisi
        tarama = denetim_sayisi
        t2 = olc_ortanca(lambda: dizi_gorevi(boyut), tekrar)
        ayni = c1 == cozum_sayisi and d1 == dugum_sayisi
        print(f"{boyut:3d} {cozum_sayisi:7d} {dugum_sayisi:8d} "
              f"{tarama:21d} {denetim_sayisi:14d}"
              + ("" if ayni else "  FARK"))
        print(f"  N = {boyut:2d}: tarama {t1 * 1e3:9.3f} ms   "
              f"dizi {t2 * 1e3:9.3f} ms   oran {t1 / t2:.2f}",
              file=sys.stderr)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). C++'ta std::vector<bool>
# ya da std::bitset ile aynı diziler bit düzeyinde tutulabilir.

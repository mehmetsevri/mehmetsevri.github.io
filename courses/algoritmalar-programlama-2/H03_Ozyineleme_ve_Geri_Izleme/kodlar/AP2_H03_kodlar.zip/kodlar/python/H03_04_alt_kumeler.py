"""H03_04_alt_kumeler.py — AP-2 Hafta 3 · Örnek 4 (★★)
Amaç    : Bir kümenin tüm alt kümeleri — özyinelemeli üretme şablonu:
          a[i] için "dahil etme" ve "dahil et" (seç → dene → geri al)
Çalıştır: python3 H03_04_alt_kumeler.py
Eşleri  : c/H03_04_alt_kumeler.c · cpp/H03_04_alt_kumeler.cpp
Çıktı   : üç dilde aynı (=)
"""

a = []                  # küme elemanları
n = 0                   # eleman sayısı
yol = []                # şu ana kadar seçilenler
cagri_sayisi = 0
kume_sayisi = 0
eleman_toplami = 0      # üretilen kümelerin boyları toplamı
yazdir_mi = True


def kume_isle():
    """Bir alt küme tamamlandı: say ve (istenirse) yaz"""
    global kume_sayisi, eleman_toplami
    kume_sayisi += 1
    eleman_toplami += len(yol)
    if yazdir_mi:
        print(f"{kume_sayisi:2d}: {{", end="")
        for j in range(len(yol)):
            print((", " if j > 0 else "") + str(yol[j]), end="")
        print("}")


# a[0..i-1] için karar verildi; a[i..n-1] için devam et
def alt_kumeler(i):
    global cagri_sayisi
    cagri_sayisi += 1
    if i == n:             # yaprak
        kume_isle()
        return
    alt_kumeler(i + 1)     # a[i] yok
    yol.append(a[i])       # seç
    alt_kumeler(i + 1)     # dene
    yol.pop()              # geri al


def main():
    global a, n, cagri_sayisi, kume_sayisi, eleman_toplami, yazdir_mi
    print("1) a = {1, 2, 3} kümesinin alt kümeleri")
    n = 3
    a = [1, 2, 3]
    alt_kumeler(0)
    print(f"küme = {kume_sayisi}   çağrı = {cagri_sayisi}")

    print("\n2) Sayım: küme = 2^n, çağrı = 2^(n+1) - 1,"
          " eleman toplamı = n*2^(n-1)")
    print("  n     küme     çağrı  eleman toplamı  n*2^(n-1)  eşit")
    yazdir_mi = False
    for n in range(1, 17):
        a = [i + 1 for i in range(n)]
        cagri_sayisi = 0
        kume_sayisi = 0
        eleman_toplami = 0
        alt_kumeler(0)
        iki_n = 1 << n
        beklenen = n * (iki_n // 2)
        esit = (kume_sayisi == iki_n and cagri_sayisi == 2 * iki_n - 1
                and eleman_toplami == beklenen)
        print(f"{n:3d} {kume_sayisi:8d} {cagri_sayisi:9d} "
              f"{eleman_toplami:15d} {beklenen:10d}  "
              + ("evet" if esit else "HAYIR"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok; Python — itertools.combinations
# ile her r için birleştirme ya da itertools.product (yalnızca kâhin).

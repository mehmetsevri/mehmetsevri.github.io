"""H03_08_alt_kume_toplami.py — AP-2 Hafta 3 · Örnek 8 (★★)
Amaç    : Alt küme toplamı: kaba kuvvet (ağacın tamamı) ve budamalı geri
          izleme ("toplam aşıldı"; sıralı girdiyle ek budama); düğüm sayısı
Çalıştır: python3 H03_08_alt_kume_toplami.py
Eşleri  : c/H03_08_alt_kume_toplami.c · cpp/H03_08_alt_kume_toplami.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

a = []                  # pozitif tamsayılar
n = 0
hedef = 0
b = []                  # a'nın artan sıralı kopyası
kalan = []              # kalan[i] = b[i] + ... + b[n-1]
yol = []
ziyaret = 0             # ziyaret edilen düğüm (çağrı)
budanan = 0             # budanan düğüm
cozum_sayisi = 0
yazdir_mi = False


def cozum_isle():
    global cozum_sayisi
    cozum_sayisi += 1
    if yazdir_mi:
        print("    {" + ", ".join(str(x) for x in yol) + "}")


def kaba_kuvvet(i, toplam):
    """1) Kaba kuvvet: ağacın tamamı; yalnızca yaprakta denetim"""
    global ziyaret
    ziyaret += 1
    if i == n:
        if toplam == hedef:
            cozum_isle()
        return
    kaba_kuvvet(i + 1, toplam)              # a[i] alınmaz
    yol.append(a[i])                        # seç
    kaba_kuvvet(i + 1, toplam + a[i])       # a[i] alınır
    yol.pop()                               # geri al


def budamali(i, toplam):
    """2) Geri izleme: toplam hedefi aştıysa dur (her a[i] > 0 olduğu için)"""
    global ziyaret, budanan
    ziyaret += 1
    if toplam > hedef:
        budanan += 1                        # torunların hepsi de aşar
        return
    if i == n:
        if toplam == hedef:
            cozum_isle()
        return
    budamali(i + 1, toplam)
    yol.append(a[i])
    budamali(i + 1, toplam + a[i])
    yol.pop()


def sirali_budamali(i, toplam):
    """3) Sıralı girdi (b artan) ile iki sınır daha"""
    global ziyaret, budanan, cozum_sayisi
    ziyaret += 1
    if toplam == hedef:                     # kalanlar eklenemez: çözüm
        cozum_sayisi += 1
        return
    if i == n:
        return
    if toplam + b[i] > hedef or toplam + kalan[i] < hedef:
        budanan += 1    # en küçük kalan sığmıyor ya da hepsi yetmiyor
        return
    sirali_budamali(i + 1, toplam)
    sirali_budamali(i + 1, toplam + b[i])


def siraliyi_hazirla():
    """b = a'nın artan sıralı kopyası (araya ekleme) ve sonek toplamları"""
    global b, kalan
    b = [0] * n
    for i in range(n):
        x = a[i]
        j = i - 1
        while j >= 0 and b[j] > x:
            b[j + 1] = b[j]
            j -= 1
        b[j + 1] = x
    kalan = [0] * (n + 1)
    for i in range(n - 1, -1, -1):
        kalan[i] = kalan[i + 1] + b[i]


def yontem_calistir(yontem):
    global ziyaret, budanan, cozum_sayisi
    ziyaret = 0
    budanan = 0
    cozum_sayisi = 0
    yol.clear()
    if yontem == 1:
        kaba_kuvvet(0, 0)
    elif yontem == 2:
        budamali(0, 0)
    else:
        sirali_budamali(0, 0)


def tablo():
    ad = ["", "kaba kuvvet    ", "toplam aşıldı  ", "sıralı + sınır "]
    siraliyi_hazirla()
    for y in range(1, 4):
        yontem_calistir(y)
        print(f"  {ad[y]} {cozum_sayisi:8d} {ziyaret:10d} {budanan:10d}")


def main():
    global a, n, hedef, yazdir_mi
    a = [5, 4, 3, 2]
    n = 4
    hedef = 7
    print("1) a = {5, 4, 3, 2}, hedef = 7; çözümler (kaba kuvvet):")
    yazdir_mi = True
    yontem_calistir(1)
    yazdir_mi = False
    print("  yöntem             çözüm    ziyaret    budanan")
    tablo()

    n = 18
    rastgele_tohum(42)
    a = rastgele_dizi(n, 1, 40)
    toplam_a = 0
    print(f"\n2) n = {n}, a (tohum 42, 1..40) =", end="")
    for i in range(n):
        print(f" {a[i]}", end="")
        toplam_a += a[i]
    print(f"\n   toplam = {toplam_a}; tam ağaç 2^(n+1) - 1 = "
          f"{(1 << (n + 1)) - 1} düğüm")
    for h in [50, toplam_a // 2]:
        hedef = h
        print(f"hedef = {hedef}")
        print("  yöntem             çözüm    ziyaret    budanan")
        tablo()


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Kâhin: bit maskesiyle
# 0 … 2^n − 1 tarama (Örnek 5); H13'te dinamik programlama.

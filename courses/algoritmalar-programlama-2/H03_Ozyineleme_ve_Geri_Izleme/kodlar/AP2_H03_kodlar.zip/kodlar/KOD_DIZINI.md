# Hafta 3 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, çıktı türü, amacı ve derleme durumuyla aşağıdadır. **Ders notu / Sunum / Web** sütunları dosyanın kodunun gösterildiği yerleri verir: ders notu bölümü (Ek A: C++ ve Python karşılıkları), slayt numarası, web sayfasındaki bölüm kimliği. Ortam: gcc/g++ 13.3 (x86-64 Linux, glibc), Python 3.11.15 (örnekler 3.10 uyumludur; 3.10.20, 3.12 ve 3.13 ile de aynı stdout doğrulandı).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c | zamanlayici.c] -o program` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. İstisna: Örnek 12 **-O0** ile derlenir (`ornekler.json` → `bayrak: "-O0"`).

Eşdeğerlik: `python3 esdeger_test.py .` → **13/13 GEÇTİ** (12 “=”, 1 “Δ”), derleyici uyarısı 0, sütun aşımı 0; `--asan` (AddressSanitizer + UBSan) ile de 13/13 GEÇTİ.


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Girdi | Derleme | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|---|
| `H03_01_ozyineleme_sayac` | ★ | = | — | Özyinelemeli toplam ve Fibonacci'de çağrı sayaçları; fib(5) çağrı ağacı | — | sıfır uyarı (3 dil) | 3.1, A.1 | — | `#h03-agac` |
| `H03_02_hanoi` | ★ | = | — | Hanoi Kuleleri: T(n) = 2T(n−1) + 1 bağıntısının hamle sayacıyla doğrulanması | — | sıfır uyarı (3 dil) | 3.2, A.2 | slayt 12 | `#h03-bagintilar` |
| `H03_03_ikili_diziler` | ★ | = | — | n bitlik tüm ikili diziler: dahil et/etme ağacı | — | sıfır uyarı (3 dil) | 3.3, A.3 | — | `#h03-arama-uzayi` |
| `H03_04_alt_kumeler` | ★★ | = | evet | Bir kümenin tüm alt kümeleri (özyinelemeli üretme şablonu) | — | sıfır uyarı (3 dil) | 4.1, A.4 | slayt 19, 41 | `#h03-alt-kume` |
| `H03_05_bit_maskesi` | ★★ | = | — | Aynı problem bit maskesiyle (0 … 2ⁿ − 1); Örnek 4 ile aynı küme ailesi ve sıra | — | sıfır uyarı (3 dil) | 5.1, A.5 | — | `#h03-alt-kume` |
| `H03_06_permutasyonlar` | ★★ | = | evet | Tüm permütasyonlar — kullanildi dizisiyle, sözlük sırasında; takasla üretim | — | sıfır uyarı (3 dil) | 4.2, A.6 | slayt 25 | `#h03-permutasyon` |
| `H03_07_kombinasyonlar` | ★★ | = | — | k-kombinasyonlar: başlangıç indisiyle tekrarsız üretim ve C(n, k) sayımı | — | sıfır uyarı (3 dil) | 5.2, A.7 | — | `#h03-permutasyon` |
| `H03_08_alt_kume_toplami` | ★★ | = | evet | Alt küme toplamı: kaba kuvvet ve budamalı geri izleme (ziyaret edilen düğüm) | — | sıfır uyarı (3 dil) | 4.3, A.8 | slayt 30 | `#h03-alt-kume-toplami` |
| `H03_09_n_vezir` | ★★★ | = | evet | N-vezir: geri izleme ve N = 1…10 için çözüm sayıları (N = 8 için 92) | — | sıfır uyarı (3 dil) | 4.4, A.9 | — | `#h03-n-vezir` |
| `H03_10_n_vezir_hizli` | ★★★ | = | evet | N-vezir: sütun/köşegen dizileriyle O(1) güvenlik denetimi ve süre karşılaştırması | — | sıfır uyarı (3 dil) | 4.4, A.10 | slayt 39 | `#h03-n-vezir` |
| `H03_11_labirent` | ★★ | = | — | Labirentte yol bulma: ızgarada geri izleme ve yolun işaretlenmesi | `girdiler/H03_11_labirent.txt` | sıfır uyarı (3 dil) | 5.3, A.11 | — | `#h03-labirent` |
| `H03_12_ozyineleme_siniri` | ★★ | Δ | — | Özyineleme sınırı deneyi: Python RecursionError ve C'de yığın taşması | — | sıfır uyarı (3 dil) · -O0 | 8, A.12 | slayt 48 | `#h03-dil` |
| `H03_13_sudoku` | ★★★ | = | — | Sudoku çözücüsü (meydan okuma): kısıt yayılımı olmadan geri izleme | `girdiler/H03_13_sudoku.txt` | sıfır uyarı (3 dil) | 5.4, A.13 | — | `#h03-labirent` |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`. Beklenen çıktılar: `ciktilar/KÖK.txt` (“=”), Örnek 12 için `ciktilar/H03_12_ozyineleme_siniri_{c,cpp,py}.txt` (Δ). C++/Python’da öğretilen dil farkı satırları ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`.

Ortak modüller (90_Ortak_Varliklar/kod_ortak kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`. Kullananlar: Örnek 8 (ortak_rastgele), Örnek 10 ve 13 (zamanlayici).


## 2. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir (hata mantıksaldır ya da tanımsız davranıştır). Gerçek belirtiler (derleme komutu, çıktı, çıkış kodu/sinyal) `hata_avcisi/ciktilar/` altındadır.

| Dosya | Dil | Tür | Hata / belirti | Derleme | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `hata_avcisi/H03_HA1_geri_alma_unutma.c` | C | kasıtlı hata | Geri izlemede seçimi geri almayı unutmak (durum kirlenmesi): 6 yerine 1 permütasyon | sıfır uyarı | `ciktilar/H03_HA1_geri_alma_unutma.txt` | 7 | slayt 46 | `#h03-hata-avcisi` |
| `hata_avcisi/H03_HA1_geri_alma_unutma_duzeltilmis.c` | C | düzeltilmiş | — | sıfır uyarı | `ciktilar/H03_HA1_geri_alma_unutma_duzeltilmis.txt` | — | slayt 46 | `#h03-hata-avcisi` |
| `hata_avcisi/H03_HA2_ilk_cozumde_donmek.c` | C | kasıtlı hata | Tüm çözümler istenirken ilk çözümde dönmek: 92 yerine 1 çözüm; düzeltilmişte tek çözüm için 114, tümü için 2057 düğüm | sıfır uyarı | `ciktilar/H03_HA2_ilk_cozumde_donmek.txt` | — | — | — |
| `hata_avcisi/H03_HA2_ilk_cozumde_donmek_duzeltilmis.c` | C | düzeltilmiş | — | sıfır uyarı | `ciktilar/H03_HA2_ilk_cozumde_donmek_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H03_HA3_tekrarli_permutasyon.cpp` | C++ | kasıtlı hata | Tekrar eden elemanlı dizide (1, 1, 2) yinelenen permütasyonlar: 3 yerine 6 | sıfır uyarı | `ciktilar/H03_HA3_tekrarli_permutasyon.txt` | — | — | — |
| `hata_avcisi/H03_HA3_tekrarli_permutasyon_duzeltilmis.cpp` | C++ | düzeltilmiş | — | sıfır uyarı | `ciktilar/H03_HA3_tekrarli_permutasyon_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H03_HA4_negatif_budama.c` | C | kasıtlı hata | “Toplam aşıldı” budamasının negatif sayıda uygulanması: 2 yerine 1 çözüm | sıfır uyarı | `ciktilar/H03_HA4_negatif_budama.txt` | 7 | — | `#h03-hata-avcisi` |
| `hata_avcisi/H03_HA4_negatif_budama_duzeltilmis.c` | C | düzeltilmiş | — | sıfır uyarı | `ciktilar/H03_HA4_negatif_budama_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H03_HA5_eksik_temel_durum.c` | C | kasıtlı hata | Eksik temel durum (n == 0, tek n): Python RecursionError; C -O0 SIGSEGV, -O2 sonsuz döngü (korumalı varsayılan çalıştırma) | sıfır uyarı (-O0; -O2 karşılaştırması) | `ciktilar/H03_HA5_eksik_temel_durum_c.txt` | — | — | — |
| `hata_avcisi/H03_HA5_eksik_temel_durum_duzeltilmis.c` | C | düzeltilmiş | — | sıfır uyarı | `ciktilar/H03_HA5_eksik_temel_durum_duzeltilmis_c.txt` | — | — | — |
| `hata_avcisi/H03_HA5_eksik_temel_durum.py` | Python | kasıtlı hata | Eksik temel durum (n == 0, tek n): Python RecursionError; C -O0 SIGSEGV, -O2 sonsuz döngü (korumalı varsayılan çalıştırma) | — | `ciktilar/H03_HA5_eksik_temel_durum_py.txt` | 7 | — | — |
| `hata_avcisi/H03_HA5_eksik_temel_durum_duzeltilmis.py` | Python | düzeltilmiş | — | — | `ciktilar/H03_HA5_eksik_temel_durum_duzeltilmis_py.txt` | — | — | — |
| `hata_avcisi/H03_HA6_bit_kaydirma.c` | C | kasıtlı hata | 1 << n'nin n ≥ 31 için taşması (tanımsız davranış); UBSan iletisi; düzeltme 1ULL << n | sıfır uyarı (+ -fsanitize=undefined) | `ciktilar/H03_HA6_bit_kaydirma.txt` | 7 | — | — |
| `hata_avcisi/H03_HA6_bit_kaydirma_duzeltilmis.c` | C | düzeltilmiş | — | sıfır uyarı (+ -fsanitize=undefined) | `ciktilar/H03_HA6_bit_kaydirma_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H03_HA7_liste_kopyasi.py` | Python | kasıtlı hata | Python'da sonuc.append(yol): paylaşılan liste, 8 boş küme; düzeltme yol[:] | — | `ciktilar/H03_HA7_liste_kopyasi.txt` | 7 | slayt 47 | `#h03-hata-avcisi` |
| `hata_avcisi/H03_HA7_liste_kopyasi_duzeltilmis.py` | Python | düzeltilmiş | — | — | `ciktilar/H03_HA7_liste_kopyasi_duzeltilmis.txt` | — | slayt 47 | `#h03-hata-avcisi` |

## 3. Haftanın Deneyi (deney/)

| Dosya | Tür | Açıklama |
|---|---|---|
| `deney/c/H03_deney_n_vezir.c` (+ `zamanlayici.h/.c`) | deney programı (C) | `budamali` ya da `budamasiz`, `N [tekrar] [--csv]`; sayaçlar stdout, süreler stderr/CSV; sıfır uyarı |
| `deney/cpp/H03_deney_n_vezir.cpp` (+ `zamanlayici.hpp`) | deney programı (C++) | aynı arayüz; sıfır uyarı |
| `deney/python/H03_deney_n_vezir.py` (+ `zamanlayici.py`) | deney programı (Python) | aynı arayüz |
| `deney/olcum_calistir.py` | ölçüm sürücüsü | derler, ölçer (1 ısınma + tekrar, ortanca; tutarsızsa yineler), `sonuclar/h03_deney_olcum.csv` ve `OLCUM_ORTAMI.txt` yazar (bu makinede 42,5 s) |
| `deney/kestirim.py` | çözümleme | `h03_deney_uzay.csv`, `h03_deney_kestirim.csv` (düğüm oranı modeli + sınama), `h03_deney_oran.csv` |
| `deney/sonuclar/*.csv` | ham veri | `;` ayraçlı, başlık satırlı; birimler sütun adında (`ortanca_ms`) |
| `deney/OLCUM_ORTAMI.txt` | ortam | işlemci, çekirdek, derleyici/yorumlayıcı sürümleri, tarih, yöntem |

## 4. Girdiler ve diğerleri

- `girdiler/H03_11_labirent.txt` — 11 × 17 labirent (ilk satır `satır sütun`; `#` duvar, `.` boş, `S` giriş, `E` çıkış).
- `girdiler/H03_13_sudoku.txt` — 23 ipuçlu Sudoku (9 satır; `.` boş). Tek çözümlüdür (çözüm sayacıyla doğrulandı).
- `ornekler.json` — örnek üst verisi (başlık, düzey, tür, amiral, bayrak, farklar satır numaraları, dil_notu).
- `kavram/`, `alistirmalar/`, `quiz/` — Bölüm 5.

## 5. Kavram, alıştırma ve quiz programları (kavram/, alistirmalar/, quiz/)

Ders notunda, sunumda ya da web sayfasında gösterilen ve merdivende olmayan her kod parçası buradaki küçük, derlenip çalışan programlardandır. Çıktılar `<klasör>/ciktilar/` altındadır (ilk satır ortam bilgisi). Kasıtlı hatalı alıştırmaların başlığında “BU DOSYA KASITLI HATA İÇERİR”, Parsons dosyasında “tamamlanacak; bu hâliyle derlenmez” yazar.

| Dosya | Tür | Amaç | Derleme | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `alistirmalar/H03_A01_cikti_tahmini.c` | alıştırma | Çıktı tahmini ve çağrı sayısı: iki özyinelemeli çağrının arasında yazdırma (ağacı çizerek izleyin, sonra çalıştırın) | sıfır uyarı | Alıştırma 3.1 | — | `#h03-quiz`, `#h03-alistirmalar` |
| `alistirmalar/H03_A02_hata_bul_kombinasyon.c` | alıştırma | Kasıtlı hata: n = 5, k = 3 için C(5, 3) = 10 kombinasyon beklenirken daha azı üretiliyor. Hatayı bulun (Örnek 7 ile karşılaştırın). | sıfır uyarı | Alıştırma 3.7 | — | `#h03-alistirmalar` |
| `alistirmalar/H03_A03_hata_bul_budama.c` | alıştırma | Kasıtlı hata: a = {5, 4, 3, 2}, hedef = 7 için iki çözüm ({4, 3} ve {5, 2}) beklenirken program hiç çözüm bulmuyor. Budama koşulundaki hatayı bulun ve düzeltin (Örnek 8 ile karşılaştırın). | sıfır uyarı | Alıştırma 3.8 | — | `#h03-alistirmalar` |
| `alistirmalar/H03_A04_parsons_takas.c` | alıştırma | Tamamlanacak (derlenmez): aşağıdaki satırlar takasla permütasyon üreten fonksiyonun KARIŞTIRILMIŞ satırlarıdır. Doğru sıraya dizin (girintiyi de düzeltin); çıktı Örnek 6'daki takas sırası olmalı. | tamamlanacak (derlenmez) | Alıştırma 3.9 | — | `#h03-alistirmalar` |
| `alistirmalar/H03_A05_uretec_okuma.py` | alıştırma | Diller arası okuma: üreteç (yield) kaldığı yerden sürer. Çalıştırmadan önce iki print satırının çıktısını tahmin edin. | — | Alıştırma 3.13 | — | `#h03-alistirmalar` |
| `alistirmalar/H03_A06_kopya.cpp` | alıştırma | Diller arası okuma: push_back(yol) bir KOPYA ekler. Python eşi H03_A06_kopya.py ile çıktıyı karşılaştırın. | sıfır uyarı | Alıştırma 3.14 | — | `#h03-alistirmalar` |
| `alistirmalar/H03_A06_kopya.py` | alıştırma | Diller arası okuma: append(yol) bir BAŞVURU ekler. C++ eşi H03_A06_kopya.cpp ile çıktıyı karşılaştırın. | — | Alıştırma 3.14 | — | `#h03-alistirmalar` |
| `kavram/H03_K01_uretec_alt_kume.py` | kavram programı | Python üreteçleriyle (yield) alt küme ve permütasyon üretimi; tembel (lazy) üretim ve itertools ile kâhin karşılaştırması | — | 8 | — | `#h03-dil` |
| `kavram/H03_K02_next_permutation.cpp` | kavram programı | Kütüphane karşılığı std::next_permutation: sözlük sırasında sonraki permütasyon; tekrar eden elemanlarda her diziliş bir kez | sıfır uyarı | — | — | `#h03-dil` |
| `kavram/H03_K03_faktoriyel_bagintisi.c` | kavram programı | İki yineleme bağıntısı: faktöriyelde T(n) = T(n−1) + c (n + 1 çağrı) ve permütasyon sayısında P(n) = n·P(n−1) (= n!) | sıfır uyarı | — | — | — |
| `kavram/H03_K04_acik_yigin.c` | kavram programı | Örnek 3'ün özyinelemesini açık bir yığınla (dizi + tepe) yazmak: aynı 2^n dizi, aynı sıra; yığın en çok n + 1 kayıt | sıfır uyarı | — | — | — |
| `kavram/H03_K05_vector_bool.cpp` | kavram programı | std::vector<bool> özel bir bit kabıdır: v[i] bir bool& değil, "vekil" (proxy) nesne döndürür — benzer sözdizimi, farklı anlam | sıfır uyarı | — | — | — |
| `kavram/H03_K06_kuyruk_ozyineleme.c` | kavram programı | Aynı toplamın iki özyinelemeli biçimi: toplam(n) (toplama çağrıdan SONRA) ve toplam_kuyruk(n, birikim) (çağrı son iş: kuyruk özyineleme). -O0'da ikisi de her çağrıda çerçeve açar; GCC 13 -O2 ikisini de döngüye çevirdi (bu makinede ölçüldü). | sıfır uyarı | — | — | — |
| `kavram/H03_K07_python_cerceve.py` | kavram programı | Python'da her çağrı bir çerçeve (frame) nesnesidir: f_back ile çağırana bağlanır, yerel adlar f_locals'ta görünür | — | — | — | — |
| `quiz/H03_Q01_dahil_et_once.c` | quiz | Örnek 4'ün dalları yer değiştirirse üretim sırası ne olur? (önce "dahil et", sonra "dahil etme") | sıfır uyarı | — | — | `#h03-quiz` |

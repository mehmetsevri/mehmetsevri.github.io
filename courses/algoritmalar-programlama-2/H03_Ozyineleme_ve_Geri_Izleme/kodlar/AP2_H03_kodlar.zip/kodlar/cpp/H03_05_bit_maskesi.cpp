/* H03_05_bit_maskesi.cpp — AP-2 Hafta 3 · Örnek 5 (★★)
 * Amaç    : Alt kümeleri özyinelemesiz üretmek: maske = 0 … 2^n − 1; bitler
 *           hangi elemanın alındığını söyler. Örnek 4 ile karşılaştırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_05_bit_maskesi.cpp -o H03_05_bit_maskesi
 * Çalıştır: ./H03_05_bit_maskesi
 * Eşleri  : c/H03_05_bit_maskesi.c · python/H03_05_bit_maskesi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

constexpr int MAKS_N = 16;

static std::vector<int> a(MAKS_N);     // küme elemanları
static std::vector<unsigned> sira;     // özyinelemenin ürettiği maskeler
static std::vector<int> goruldu(1u << MAKS_N);

// Eşleme: a0_solda = true ise a[i] ↔ bit (n-1-i) (a[0] en soldaki bit);
//         a0_solda = false ise a[i] ↔ bit i  (a[0] en sağdaki bit)
static int bit_no(int i, int n, bool a0_solda)
{
    return a0_solda ? n - 1 - i : i;
}

// maskenin gösterdiği alt kümeyi metin olarak döndürür: "{1, 3}"
static std::string kume_metni(unsigned maske, int n, bool a0_solda)
{
    std::string metin = "{";
    bool ilk = true;
    for (int i = 0; i < n; i++) {
        if ((maske >> bit_no(i, n, a0_solda)) & 1u) {
            metin += (ilk ? "" : ", ") + std::to_string(a[i]);
            ilk = false;
        }
    }
    return metin + "}";
}

// Bit maskesiyle üretim: her maske bir alt küme
static void maske_ile_uret(int n)
{
    std::cout << "maske  ikili  a[0] soldaki bit  a[0] sağdaki bit\n";
    for (unsigned maske = 0; maske < (1u << n); maske++) {
        std::cout << std::setw(5) << maske << "  ";
        for (int b = n - 1; b >= 0; b--) {
            std::cout << (((maske >> b) & 1u) ? '1' : '0');
        }
        std::cout << "    " << std::left << std::setw(16)
                  << kume_metni(maske, n, true) << std::right << "  "
                  << kume_metni(maske, n, false) << "\n";
    }
}

// Örnek 4'teki dahil etme / dahil et özyinelemesi; her yaprakta
// alt kümeyi maske olarak kaydeder
static void ozyinelemeli_maskeler(int i, int n, bool a0_solda,
                                  unsigned maske)
{
    if (i == n) {
        sira.push_back(maske);
        return;
    }
    unsigned bit = 1u << bit_no(i, n, a0_solda);
    ozyinelemeli_maskeler(i + 1, n, a0_solda, maske);        // dahil etme
    ozyinelemeli_maskeler(i + 1, n, a0_solda, maske | bit);  // dahil et
}

// Özyinelemenin k. yaprağı k maskesi mi? (aynı sıra)
static bool ayni_sira(int n)
{
    for (unsigned k = 0; k < (1u << n); k++) {
        if (sira[k] != k) {
            return false;
        }
    }
    return true;
}

// Her maske tam bir kez üretildi mi? (aynı küme ailesi)
static bool her_kume_bir_kez(int n)
{
    for (unsigned k = 0; k < (1u << n); k++) {
        goruldu[k] = 0;
    }
    for (unsigned m : sira) {
        goruldu[m]++;
    }
    for (unsigned k = 0; k < (1u << n); k++) {
        if (goruldu[k] != 1) {
            return false;
        }
    }
    return true;
}

int main()
{
    std::cout << "1) a = {1, 2, 3}: maske = 0 ... 2^3 - 1\n";
    for (int i = 0; i < MAKS_N; i++) {
        a[i] = i + 1;
    }
    maske_ile_uret(3);

    std::cout << "\n2) Özyineleme (Örnek 4) ile bit maskesi aynı kümeleri mi "
                 "üretir?\n";
    std::cout << "  n      küme   a[0] solda: aynı sıra"
                 " | a[0] sağda: aynı sıra / aynı aile\n";
    for (int n = 1; n <= MAKS_N; n++) {
        sira.clear();
        ozyinelemeli_maskeler(0, n, true, 0u);
        bool solda_sira = ayni_sira(n);
        sira.clear();
        ozyinelemeli_maskeler(0, n, false, 0u);
        bool sagda_sira = ayni_sira(n);
        bool sagda_aile = her_kume_bir_kez(n);
        std::cout << std::setw(3) << n << " " << std::setw(9) << sira.size()
                  << "   " << (solda_sira ? "evet" : "hayır") << " | "
                  << (sagda_sira ? "evet" : "hayır") << " / "
                  << (sagda_aile ? "evet" : "hayır") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::bitset<N>(maske) yalnızca
 * gösterim; Python — itertools.product([0, 1], repeat=n) (yalnızca kâhin). */

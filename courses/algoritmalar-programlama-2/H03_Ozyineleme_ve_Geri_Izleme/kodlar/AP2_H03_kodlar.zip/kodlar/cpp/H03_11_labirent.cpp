/* H03_11_labirent.cpp — AP-2 Hafta 3 · Örnek 11 (★★)
 * Amaç    : Labirentte yol bulma: ızgarada geri izleme (sağ, aşağı, sol,
 *           yukarı); yol '*', denenip geri dönülen hücre 'x' ile işaretlenir
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_11_labirent.cpp -o H03_11_labirent
 * Çalıştır: ./H03_11_labirent < ../girdiler/H03_11_labirent.txt
 * Eşleri  : c/H03_11_labirent.c · python/H03_11_labirent.py
 * Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
 */
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

constexpr int MAKS_SATIR = 40;
constexpr int MAKS_SUTUN = 80;

static std::vector<std::string> izgara;
static int satir_sayisi, sutun_sayisi;
static long long ziyaret = 0;          // yol_bul çağrısı
static long long geri_donulen = 0;     // çıkmaz olduğu anlaşılan hücre
static const int DR[4] = {0, 1, 0, -1};    // sağ, aşağı, sol, yukarı
static const int DC[4] = {1, 0, -1, 0};

// (r, c) ızgarada ve henüz denenmemiş bir boş hücre ya da çıkış mı?
static bool gecilebilir(int r, int c)
{
    return r >= 0 && r < satir_sayisi && c >= 0 && c < sutun_sayisi
           && (izgara[r][c] == '.' || izgara[r][c] == 'E');
}

// (r, c)'den çıkışa yol ara; bulunursa true döner
static bool yol_bul(int r, int c)
{
    ziyaret++;
    if (izgara[r][c] == 'E') {
        return true;                    // çıkışa ulaşıldı
    }
    if (izgara[r][c] != 'S') {
        izgara[r][c] = '*';             // seç: hücre yola eklenir
    }
    for (int d = 0; d < 4; d++) {
        int yr = r + DR[d], yc = c + DC[d];
        if (gecilebilir(yr, yc) && yol_bul(yr, yc)) {
            return true;                // yol bulundu: '*'lar kalır
        }
    }
    if (izgara[r][c] != 'S') {
        izgara[r][c] = 'x';             // geri al: buradan çıkış yok
    }
    geri_donulen++;
    return false;
}

// İlk satır "satır sütun", ardından ızgara; tam bir S ve bir E olmalı
static bool labirent_oku(int& bas_r, int& bas_c)
{
    std::string satir;
    if (!std::getline(std::cin, satir)) {
        return false;
    }
    std::istringstream akis(satir);
    long r = 0, c = 0;
    if (!(akis >> r >> c) || r < 1 || r > MAKS_SATIR || c < 1
        || c > MAKS_SUTUN) {
        return false;
    }
    satir_sayisi = static_cast<int>(r);
    sutun_sayisi = static_cast<int>(c);
    int s_sayisi = 0, e_sayisi = 0;
    izgara.assign(satir_sayisi, "");
    for (int i = 0; i < satir_sayisi; i++) {
        if (!std::getline(std::cin, izgara[i])) {
            return false;
        }
        if (!izgara[i].empty() && izgara[i].back() == '\r') {
            izgara[i].pop_back();
        }
        if (static_cast<int>(izgara[i].size()) != sutun_sayisi) {
            return false;
        }
        for (int j = 0; j < sutun_sayisi; j++) {
            char k = izgara[i][j];
            if (k == 'S') {
                s_sayisi++;
                bas_r = i;
                bas_c = j;
            } else if (k == 'E') {
                e_sayisi++;
            } else if (k != '#' && k != '.') {
                return false;
            }
        }
    }
    return s_sayisi == 1 && e_sayisi == 1;
}

int main()
{
    int bas_r = 0, bas_c = 0;
    if (!labirent_oku(bas_r, bas_c)) {
        std::cerr << "Hatalı labirent girdisi\n";
        return 1;
    }
    std::cout << "Labirent " << satir_sayisi << " x " << sutun_sayisi
              << ", giriş S = (" << bas_r << ", " << bas_c << ")\n";
    std::cout << "Yön sırası: sağ, aşağı, sol, yukarı\n";
    bool bulundu = yol_bul(bas_r, bas_c);
    int yol_hucre = 0;
    for (const std::string& s : izgara) {
        for (char k : s) {
            yol_hucre += (k == '*') ? 1 : 0;
        }
    }
    if (bulundu) {
        std::cout << "Sonuç: yol bulundu, uzunluk = " << yol_hucre + 1
                  << " adım\n";
    } else {
        std::cout << "Sonuç: yol yok\n";
    }
    std::cout << "ziyaret edilen hücre = " << ziyaret
              << "   geri dönülen hücre = " << geri_donulen << "\n";
    for (const std::string& s : izgara) {
        std::cout << s << "\n";
    }
    std::cout << "İşaretler: * yol, x denenip geri dönülen hücre\n";
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). En kısa yol için H11'deki
 * genişlik öncelikli arama (BFS) kullanılır; bu yol en kısa olmayabilir. */

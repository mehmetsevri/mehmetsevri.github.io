/* H03_06_permutasyonlar.cpp — AP-2 Hafta 3 · Örnek 6 (★★)
 * Amaç    : Tüm permütasyonlar — kullanildi dizisiyle, sözlük sırasında
 *           (seç → dene → geri al); takasla üretimle sıra karşılaştırması
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_06_permutasyonlar.cpp -o H03_06_permutasyonlar
 * Çalıştır: ./H03_06_permutasyonlar
 * Eşleri  : c/H03_06_permutasyonlar.c · python/H03_06_permutasyonlar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

static std::vector<int> a;            // sıralı elemanlar: 1, 2, ..., n
static int n;
static std::vector<int> yol;          // kurulmakta olan permütasyon
static std::vector<bool> kullanildi;  // a[i] yol'da mı?
static std::vector<int> onceki;       // bir önceki permütasyon
static long long cagri_sayisi = 0;
static long long perm_sayisi = 0;
static bool sozluk_sirali = true;     // her permütasyon öncekinden büyük mü?
static bool yazdir_mi = true;

// Bir permütasyon tamamlandı: say, sırayı denetle, (istenirse) yaz
static void perm_isle(const std::vector<int>& p)
{
    perm_sayisi++;
    if (perm_sayisi > 1) {
        int k = 0;
        while (k < n && p[k] == onceki[k]) {
            k++;                   // ilk farklı konum
        }
        if (k == n || p[k] < onceki[k]) {
            sozluk_sirali = false;
        }
    }
    onceki = p;                    // vektör ataması: kopya
    if (yazdir_mi) {
        for (int k = 0; k < n; k++) {
            std::cout << p[k];
        }
        std::cout << (perm_sayisi % 6 == 0 ? "\n" : " ");
    }
}

// yol[0..k-1] dolu; k. konuma kullanılmamış her elemanı dene
static void permutasyon(int k)
{
    cagri_sayisi++;
    if (k == n) {          // yaprak
        perm_isle(yol);
        return;
    }
    for (int i = 0; i < n; i++) {
        if (!kullanildi[i]) {
            kullanildi[i] = true;  // seç
            yol[k] = a[i];
            permutasyon(k + 1);    // dene
            kullanildi[i] = false; // geri al
        }
    }
}

// Takasla üretim: a[k..n-1] içinden her elemanı k. konuma getir
static void permutasyon_takas(int k)
{
    cagri_sayisi++;
    if (k == n) {
        perm_isle(a);
        return;
    }
    for (int i = k; i < n; i++) {
        std::swap(a[k], a[i]);     // seç
        permutasyon_takas(k + 1);  // dene
        std::swap(a[k], a[i]);     // geri al
    }
}

static void baslat(int boyut)
{
    n = boyut;
    a.assign(n, 0);
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }
    yol.assign(n, 0);
    kullanildi.assign(n, false);
    cagri_sayisi = 0;
    perm_sayisi = 0;
    sozluk_sirali = true;
}

int main()
{
    std::cout << "1) n = 3, kullanildi dizisiyle:\n";
    baslat(3);
    permutasyon(0);
    std::cout << "permütasyon = " << perm_sayisi << "   çağrı = "
              << cagri_sayisi << "   sözlük sırasında: "
              << (sozluk_sirali ? "evet" : "hayır") << "\n";

    std::cout << "\n2) n = 3, takasla:\n";
    baslat(3);
    permutasyon_takas(0);
    std::cout << "permütasyon = " << perm_sayisi << "   çağrı = "
              << cagri_sayisi << "   sözlük sırasında: "
              << (sozluk_sirali ? "evet" : "hayır") << "\n";

    std::cout << "\n3) kullanildi dizisiyle sayım: çağrı / n! -> "
                 "e = 2.71828...\n";
    std::cout << "  n      perm     çağrı  çağrı/n!  perm = n!  sözlük\n";
    yazdir_mi = false;
    long long faktoriyel = 1;
    for (int boyut = 1; boyut <= 8; boyut++) {
        faktoriyel *= boyut;
        baslat(boyut);
        permutasyon(0);
        double oran = static_cast<double>(cagri_sayisi) /
                      static_cast<double>(faktoriyel);
        std::cout << std::setw(3) << boyut << " " << std::setw(9)
                  << perm_sayisi << " " << std::setw(9) << cagri_sayisi
                  << " " << std::fixed << std::setprecision(4)
                  << std::setw(9) << oran << "  " << std::left
                  << std::setw(9)
                  << (perm_sayisi == faktoriyel ? "evet" : "HAYIR")
                  << std::right << "  " << (sozluk_sirali ? "evet" : "hayır")
                  << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::next_permutation (sözlük
 * sırasında sonraki); Python — itertools.permutations (yalnızca kâhin). */

/* H03_08_alt_kume_toplami.cpp — AP-2 Hafta 3 · Örnek 8 (★★)
 * Amaç    : Alt küme toplamı: kaba kuvvet (ağacın tamamı) ve budamalı geri
 *           izleme ("toplam aşıldı"; sıralı girdiyle ek budama); düğüm sayısı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_08_alt_kume_toplami.cpp -o H03_08_alt_kume_toplami
 * Çalıştır: ./H03_08_alt_kume_toplami
 * Eşleri  : c/H03_08_alt_kume_toplami.c · python/H03_08_alt_kume_toplami.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

static std::vector<int> a;         // pozitif tamsayılar
static int n;
static long long hedef;
static std::vector<int> b;         // a'nın artan sıralı kopyası
static std::vector<long long> kalan; // kalan[i] = b[i] + ... + b[n-1]
static std::vector<int> yol;
static long long ziyaret = 0;      // ziyaret edilen düğüm (çağrı)
static long long budanan = 0;      // budanan düğüm
static long long cozum_sayisi = 0;
static bool yazdir_mi = false;

static void cozum_isle()
{
    cozum_sayisi++;
    if (yazdir_mi) {
        std::cout << "    {";
        for (std::size_t j = 0; j < yol.size(); j++) {
            std::cout << (j > 0 ? ", " : "") << yol[j];
        }
        std::cout << "}\n";
    }
}

// 1) Kaba kuvvet: ağacın tamamı; yalnızca yaprakta denetim
static void kaba_kuvvet(int i, long long toplam)
{
    ziyaret++;
    if (i == n) {
        if (toplam == hedef) {
            cozum_isle();
        }
        return;
    }
    kaba_kuvvet(i + 1, toplam);             // a[i] alınmaz
    yol.push_back(a[i]);                    // seç
    kaba_kuvvet(i + 1, toplam + a[i]);      // a[i] alınır
    yol.pop_back();                         // geri al
}

// 2) Geri izleme: toplam hedefi aştıysa dur (her a[i] > 0 olduğu için)
static void budamali(int i, long long toplam)
{
    ziyaret++;
    if (toplam > hedef) {
        budanan++;                          // torunların hepsi de aşar
        return;
    }
    if (i == n) {
        if (toplam == hedef) {
            cozum_isle();
        }
        return;
    }
    budamali(i + 1, toplam);
    yol.push_back(a[i]);
    budamali(i + 1, toplam + a[i]);
    yol.pop_back();
}

// 3) Sıralı girdi (b artan) ile iki sınır daha
static void sirali_budamali(int i, long long toplam)
{
    ziyaret++;
    if (toplam == hedef) {                  // kalanlar eklenemez: çözüm
        cozum_sayisi++;
        return;
    }
    if (i == n) {
        return;
    }
    if (toplam + b[i] > hedef || toplam + kalan[i] < hedef) {
        budanan++;      // en küçük kalan sığmıyor ya da hepsi yetmiyor
        return;
    }
    sirali_budamali(i + 1, toplam);
    sirali_budamali(i + 1, toplam + b[i]);
}

// b = a'nın artan sıralı kopyası (araya ekleme) ve sonek toplamları
static void siraliyi_hazirla()
{
    b.assign(n, 0);
    for (int i = 0; i < n; i++) {
        int x = a[i];
        int j = i - 1;
        while (j >= 0 && b[j] > x) {
            b[j + 1] = b[j];
            j--;
        }
        b[j + 1] = x;
    }
    kalan.assign(n + 1, 0);
    for (int i = n - 1; i >= 0; i--) {
        kalan[i] = kalan[i + 1] + b[i];
    }
}

static void yontem_calistir(int yontem)
{
    ziyaret = 0;
    budanan = 0;
    cozum_sayisi = 0;
    yol.clear();
    if (yontem == 1) {
        kaba_kuvvet(0, 0);
    } else if (yontem == 2) {
        budamali(0, 0);
    } else {
        sirali_budamali(0, 0);
    }
}

static void tablo()
{
    const std::string ad[] = {"", "kaba kuvvet    ", "toplam aşıldı  ",
                              "sıralı + sınır "};
    siraliyi_hazirla();
    for (int y = 1; y <= 3; y++) {
        yontem_calistir(y);
        std::cout << "  " << ad[y] << " " << std::setw(8) << cozum_sayisi
                  << " " << std::setw(10) << ziyaret << " " << std::setw(10)
                  << budanan << "\n";
    }
}

int main()
{
    a = {5, 4, 3, 2};
    n = 4;
    hedef = 7;
    std::cout << "1) a = {5, 4, 3, 2}, hedef = 7; çözümler (kaba kuvvet):\n";
    yazdir_mi = true;
    yontem_calistir(1);
    yazdir_mi = false;
    std::cout << "  yöntem             çözüm    ziyaret    budanan\n";
    tablo();

    n = 18;
    rastgele_tohum(42);
    a = rastgele_dizi(n, 1, 40);
    long long toplam_a = 0;
    std::cout << "\n2) n = " << n << ", a (tohum 42, 1..40) =";
    for (int i = 0; i < n; i++) {
        std::cout << " " << a[i];
        toplam_a += a[i];
    }
    std::cout << "\n   toplam = " << toplam_a << "; tam ağaç 2^(n+1) - 1 = "
              << (1LL << (n + 1)) - 1 << " düğüm\n";
    const long long hedefler[] = {50, toplam_a / 2};
    for (long long h : hedefler) {
        hedef = h;
        std::cout << "hedef = " << hedef << "\n";
        std::cout << "  yöntem             çözüm    ziyaret    budanan\n";
        tablo();
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: bit maskesiyle
 * 0 … 2^n − 1 tarama (Örnek 5); H13'te dinamik programlama. */

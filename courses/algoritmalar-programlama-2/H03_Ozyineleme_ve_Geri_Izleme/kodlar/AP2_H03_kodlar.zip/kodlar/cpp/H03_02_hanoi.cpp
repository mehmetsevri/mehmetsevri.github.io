/* H03_02_hanoi.cpp — AP-2 Hafta 3 · Örnek 2 (★)
 * Amaç    : Hanoi Kuleleri; T(n) = 2T(n−1) + 1 bağıntısının yerine koyma
 *           ile açılımı ve hamle sayacıyla 2^n − 1 sonucunun doğrulanması
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_02_hanoi.cpp -o H03_02_hanoi
 * Çalıştır: ./H03_02_hanoi
 * Eşleri  : c/H03_02_hanoi.c · python/H03_02_hanoi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>

static long long hamle_sayisi = 0;  // yapılan hamle sayısı
static bool listele = false;        // true ise her hamle yazdırılır

// n diski kaynak çubuğundan hedef çubuğuna taşır
static void hanoi(int n, char kaynak, char hedef, char yardimci)
{
    if (n == 0) {
        return;                              // temel durum: disk yok
    }
    hanoi(n - 1, kaynak, yardimci, hedef);   // üstteki n-1 disk
    hamle_sayisi++;                          // en büyük disk
    if (listele) {
        std::cout << std::setw(2) << hamle_sayisi << ". hamle: disk " << n
                  << "  " << kaynak << " -> " << hedef << "\n";
    }
    hanoi(n - 1, yardimci, hedef, kaynak);   // n-1 disk yeniden
}

int main()
{
    std::cout << "1) n = 3 için hamleler\n";
    listele = true;
    hanoi(3, 'A', 'C', 'B');
    listele = false;

    std::cout << "\n2) Yerine koyma: T(n) = 2T(n-1) + 1, T(0) = 0\n";
    int n = 5;
    long long katsayi = 1, ek = 0;           // T(n) = katsayi*T(n-k) + ek
    std::cout << "T(" << n << ")";
    for (int k = 1; k <= n; k++) {
        katsayi *= 2;
        ek = 2 * ek + 1;
        std::cout << " = " << katsayi << "T(" << n - k << ") + " << ek;
        if (k % 2 == 0) {
            std::cout << "\n    ";
        }
    }
    std::cout << " = " << ek << "\n";

    std::cout << "\n3) Hamle sayacı ve 2^n - 1\n";
    std::cout << "  n       hamle  2T(n-1)+1       2^n-1  eşit\n";
    long long t_onceki = 0;                  // T(n-1), bağıntıdan
    for (n = 1; n <= 20; n++) {
        hamle_sayisi = 0;
        hanoi(n, 'A', 'C', 'B');
        long long t_bagint = 2 * t_onceki + 1;
        long long kapali = (1LL << n) - 1;
        std::cout << std::setw(3) << n << " " << std::setw(11)
                  << hamle_sayisi << " " << std::setw(10) << t_bagint << " "
                  << std::setw(11) << kapali << "  "
                  << ((hamle_sayisi == kapali && t_bagint == kapali)
                          ? "evet" : "HAYIR")
                  << "\n";
        t_onceki = t_bagint;
    }
    return 0;
}

/* Kütüphane karşılığı: yok (algoritmanın kendisi; standart kütüphanelerde
 * Hanoi çözücüsü bulunmaz). */

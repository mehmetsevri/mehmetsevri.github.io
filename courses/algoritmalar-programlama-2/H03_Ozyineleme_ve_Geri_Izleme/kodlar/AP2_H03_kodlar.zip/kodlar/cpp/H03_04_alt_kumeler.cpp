/* H03_04_alt_kumeler.cpp — AP-2 Hafta 3 · Örnek 4 (★★)
 * Amaç    : Bir kümenin tüm alt kümeleri — özyinelemeli üretme şablonu:
 *           a[i] için "dahil etme" ve "dahil et" (seç → dene → geri al)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_04_alt_kumeler.cpp -o H03_04_alt_kumeler
 * Çalıştır: ./H03_04_alt_kumeler
 * Eşleri  : c/H03_04_alt_kumeler.c · python/H03_04_alt_kumeler.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <vector>

static std::vector<int> a;          // küme elemanları
static int n;                       // eleman sayısı
static std::vector<int> yol;        // şu ana kadar seçilenler
static long long cagri_sayisi = 0;
static long long kume_sayisi = 0;
static long long eleman_toplami = 0; // üretilen kümelerin boyları toplamı
static bool yazdir_mi = true;

// Bir alt küme tamamlandı: say ve (istenirse) yaz
static void kume_isle()
{
    kume_sayisi++;
    eleman_toplami += static_cast<long long>(yol.size());
    if (yazdir_mi) {
        std::cout << std::setw(2) << kume_sayisi << ": {";
        for (std::size_t j = 0; j < yol.size(); j++) {
            std::cout << (j > 0 ? ", " : "") << yol[j];
        }
        std::cout << "}\n";
    }
}

// a[0..i-1] için karar verildi; a[i..n-1] için devam et
static void alt_kumeler(int i)
{
    cagri_sayisi++;
    if (i == n) {          // yaprak
        kume_isle();
        return;
    }
    alt_kumeler(i + 1);    // a[i] yok
    yol.push_back(a[i]);   // seç
    alt_kumeler(i + 1);    // dene
    yol.pop_back();        // geri al
}

int main()
{
    std::cout << "1) a = {1, 2, 3} kümesinin alt kümeleri\n";
    n = 3;
    a = {1, 2, 3};
    alt_kumeler(0);
    std::cout << "küme = " << kume_sayisi << "   çağrı = " << cagri_sayisi
              << "\n";

    std::cout << "\n2) Sayım: küme = 2^n, çağrı = 2^(n+1) - 1,"
                 " eleman toplamı = n*2^(n-1)\n";
    std::cout << "  n     küme     çağrı  eleman toplamı  n*2^(n-1)  eşit\n";
    yazdir_mi = false;
    for (n = 1; n <= 16; n++) {
        a.assign(n, 0);
        for (int i = 0; i < n; i++) {
            a[i] = i + 1;
        }
        cagri_sayisi = 0;
        kume_sayisi = 0;
        eleman_toplami = 0;
        alt_kumeler(0);
        long long iki_n = 1LL << n;
        long long beklenen = static_cast<long long>(n) * (iki_n / 2);
        bool esit = kume_sayisi == iki_n && cagri_sayisi == 2 * iki_n - 1
                    && eleman_toplami == beklenen;
        std::cout << std::setw(3) << n << " " << std::setw(8) << kume_sayisi
                  << " " << std::setw(9) << cagri_sayisi << " "
                  << std::setw(15) << eleman_toplami << " " << std::setw(10)
                  << beklenen << "  " << (esit ? "evet" : "HAYIR") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — itertools.combinations
 * ile her r için birleştirme ya da itertools.product (yalnızca kâhin). */

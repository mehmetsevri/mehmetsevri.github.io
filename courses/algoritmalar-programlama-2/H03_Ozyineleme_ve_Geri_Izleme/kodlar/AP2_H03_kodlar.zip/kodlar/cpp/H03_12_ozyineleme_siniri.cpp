/* H03_12_ozyineleme_siniri.cpp — AP-2 Hafta 3 · Örnek 12 (★★)
 * Amaç    : Aynı özyinelemeli toplam(n) C++'ta 10 000 derinlikte sorunsuz;
 *           Python'da 1000 civarında RecursionError. C++'ın sınırı yığındır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O0 \
 *           H03_12_ozyineleme_siniri.cpp -o H03_12_ozyineleme_siniri
 *           (-O0 bilerek: -O2'de GCC bu özyinelemeyi döngüye çevirir)
 * Çalıştır: ./H03_12_ozyineleme_siniri [n]   (n verilirse yalnız toplam(n);
 *           ör. n = 1000000 Linux'ta 8 MB yığını aşar: Segmentation fault)
 * Eşleri  : c/H03_12_ozyineleme_siniri.c · python/H03_12_ozyineleme_siniri.py
 * Çıktı   : Δ — dile özgü (C/C++ derinlikleri aynı, Python farklı)
 */
#include <iomanip>
#include <iostream>
#include <string>

// 1 + 2 + ... + n; her çağrı yığında bir çerçeve açar
static long long toplam(long long n)
{
    if (n == 0) {
        return 0;
    }
    return n + toplam(n - 1);
}

int main(int argc, char* argv[])
{
    if (argc > 1) {                     // isteğe bağlı: tek derinlik
        long long n = -1;
        try {
            std::size_t son = 0;
            n = std::stoll(argv[1], &son);
            if (son != std::string(argv[1]).size()) {
                n = -1;
            }
        } catch (const std::exception&) {
            n = -1;
        }
        if (n < 0) {
            std::cerr << "kullanım: " << argv[0] << " [n >= 0]\n";
            return 2;
        }
        std::cout << "toplam(" << n << ") = " << toplam(n) << "\n";
        return 0;
    }
    const long long derinlikler[] = {900, 1000, 10000};
    std::cout << "Özyineleme sınırı deneyi — C++\n";
    std::cout << "toplam(n) = n + toplam(n - 1), toplam(0) = 0\n";
    std::cout << "dilin koyduğu derinlik sınırı: yok\n";
    for (long long n : derinlikler) {
        std::cout << "derinlik " << std::setw(6) << n << ": toplam = "
                  << toplam(n) << "\n";
    }
    std::cout << "C++'ta sınır iş parçacığının yığın boyutudur (Linux'ta "
                 "tipik\nolarak 8 MB; ulimit -s). Aşılırsa dil uyarmaz; "
                 "Linux'ta süreç\ngenellikle SIGSEGV (Segmentation fault) "
                 "ile sonlanır.\n";
    return 0;
}

/* Kütüphane karşılığı: yok. Derinlik sınırı: Python'da
 * sys.getrecursionlimit()/sys.setrecursionlimit(); C/C++'ta yığın boyutu
 * işletim sistemi (ulimit -s) ve bağlayıcı (ör. MinGW -Wl,--stack) ayarıdır. */

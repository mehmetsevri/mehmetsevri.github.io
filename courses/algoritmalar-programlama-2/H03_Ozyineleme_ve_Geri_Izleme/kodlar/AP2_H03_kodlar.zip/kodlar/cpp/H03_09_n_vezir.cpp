/* H03_09_n_vezir.cpp — AP-2 Hafta 3 · Örnek 9 (★★★)
 * Amaç    : N-vezir: satır satır geri izleme (her satıra bir vezir; güvenli
 *           sütunları dene); N = 1…10 için çözüm ve ziyaret edilen düğüm sayısı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_09_n_vezir.cpp -o H03_09_n_vezir
 * Çalıştır: ./H03_09_n_vezir
 * Eşleri  : c/H03_09_n_vezir.c · python/H03_09_n_vezir.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <vector>

static int n;
static std::vector<int> sutun;     // sutun[r]: r. satırdaki vezirin sütunu
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0; // ziyaret edilen düğüm (çağrı)
static int yazilacak = 0;          // ilk kaç çözüm tahta olarak yazılsın

// (r, c) karesi, 0..r-1 satırlarındaki vezirlerle çakışmıyor mu?
static bool guvenli_mi(int r, int c)
{
    for (int i = 0; i < r; i++) {
        int fark = sutun[i] - c;
        if (fark == 0 || fark == r - i || fark == i - r) {
            return false;          // aynı sütun ya da aynı köşegen
        }
    }
    return true;
}

static void tahta_yaz()
{
    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            std::cout << (c > 0 ? " " : "") << (sutun[r] == c ? 'V' : '.');
        }
        std::cout << "\n";
    }
}

// 0..r-1 satırlarına vezir yerleşti; r. satır için sütun ara
static void yerlestir(int r)
{
    dugum_sayisi++;
    if (r == n) {                  // n vezir yerleşti: çözüm
        cozum_sayisi++;
        if (cozum_sayisi <= yazilacak) {
            std::cout << "çözüm " << cozum_sayisi << ": sütunlar =";
            for (int i = 0; i < n; i++) {
                std::cout << " " << sutun[i];
            }
            std::cout << "\n";
            tahta_yaz();
        }
        return;
    }
    for (int c = 0; c < n; c++) {
        if (guvenli_mi(r, c)) {
            sutun[r] = c;          // seç
            yerlestir(r + 1);      // dene
        }                          // geri al: sutun[r] yeniden yazılır
    }
}

static void coz(int boyut, int yaz)
{
    n = boyut;
    sutun.assign(n, 0);
    yazilacak = yaz;
    cozum_sayisi = 0;
    dugum_sayisi = 0;
    yerlestir(0);
}

int main()
{
    const std::vector<long long> bilinen = {0, 1, 0, 0, 2, 10, 4, 40, 92,
                                            352, 724};

    std::cout << "1) N = 4: tüm çözümler\n";
    coz(4, 2);
    std::cout << "çözüm = " << cozum_sayisi << "   ziyaret edilen düğüm = "
              << dugum_sayisi << "\n";

    std::cout << "\n2) N = 8: ilk çözüm (sözlük sırasında)\n";
    coz(8, 1);
    std::cout << "çözüm = " << cozum_sayisi << "   ziyaret edilen düğüm = "
              << dugum_sayisi << "\n";

    std::cout << "\n3) N = 1..10\n";
    std::cout << "  N   çözüm   bilinen    düğüm\n";
    for (int boyut = 1; boyut <= 10; boyut++) {
        coz(boyut, 0);
        std::cout << std::setw(3) << boyut << " " << std::setw(7)
                  << cozum_sayisi << " " << std::setw(9) << bilinen[boyut]
                  << " " << std::setw(8) << dugum_sayisi
                  << (cozum_sayisi == bilinen[boyut] ? "" : "  HATA") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: N ≤ 8 için tüm
 * permütasyonları deneyen kaba kuvvet (Python'da itertools.permutations). */

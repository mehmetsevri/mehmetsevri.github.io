/* H03_10_n_vezir_hizli.cpp — AP-2 Hafta 3 · Örnek 10 (★★★)
 * Amaç    : N-vezirde güvenlik denetimi: önceki satırları tarama (O(r)) ve
 *           sütun/köşegen dizileriyle O(1) denetim; sayaçlar ve süreler
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_10_n_vezir_hizli.cpp -o H03_10_n_vezir_hizli
 * Çalıştır: ./H03_10_n_vezir_hizli [N_ust=10] [tekrar=1]   (süreler stderr)
 * Eşleri  : c/H03_10_n_vezir_hizli.c · python/H03_10_n_vezir_hizli.py
 * Çıktı   : üç dilde aynı (=) — süreler yalnızca stderr'e yazılır
 */
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "zamanlayici.hpp"

constexpr int MAKS_N = 14;

static int n;
static std::vector<int> sutun(MAKS_N);          // tarama: r. satırın sütunu
static std::vector<bool> sutun_dolu(MAKS_N);    // c sütununda vezir var mı?
static std::vector<bool> kosegen1(2 * MAKS_N - 1); // r + c sabit
static std::vector<bool> kosegen2(2 * MAKS_N - 1); // r - c + n - 1 sabit
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0;
static long long denetim_sayisi = 0;    // karşılaştırma / dizi denetimi

// A) Tarama: (r, c) için önceki r vezirle tek tek karşılaştır — O(r)
static bool guvenli_mi_tarama(int r, int c)
{
    for (int i = 0; i < r; i++) {
        denetim_sayisi++;
        int fark = sutun[i] - c;
        if (fark == 0 || fark == r - i || fark == i - r) {
            return false;
        }
    }
    return true;
}

static void yerlestir_tarama(int r)
{
    dugum_sayisi++;
    if (r == n) {
        cozum_sayisi++;
        return;
    }
    for (int c = 0; c < n; c++) {
        if (guvenli_mi_tarama(r, c)) {
            sutun[r] = c;
            yerlestir_tarama(r + 1);
        }
    }
}

// B) Dizilerle O(1) denetim: sütun ve iki köşegen dolu mu?
static bool bos_mu(int r, int c)
{
    denetim_sayisi++;
    return !sutun_dolu[c] && !kosegen1[r + c]
           && !kosegen2[r - c + n - 1];
}

static void isaretle(int r, int c, bool deger)
{
    sutun_dolu[c] = deger;
    kosegen1[r + c] = deger;
    kosegen2[r - c + n - 1] = deger;
}

static void yerlestir_dizi(int r)
{
    dugum_sayisi++;
    if (r == n) {
        cozum_sayisi++;
        return;
    }
    for (int c = 0; c < n; c++) {
        if (bos_mu(r, c)) {
            isaretle(r, c, true);  // seç
            yerlestir_dizi(r + 1); // dene
            isaretle(r, c, false); // geri al
        }
    }
}

static void sifirla(int boyut)
{
    n = boyut;
    cozum_sayisi = 0;
    dugum_sayisi = 0;
    denetim_sayisi = 0;
    sutun_dolu.assign(MAKS_N, false);
    kosegen1.assign(2 * MAKS_N - 1, false);
    kosegen2.assign(2 * MAKS_N - 1, false);
}

// zamanlayici için görevler
static void tarama_gorevi(int boyut)
{
    sifirla(boyut);
    yerlestir_tarama(0);
}

static void dizi_gorevi(int boyut)
{
    sifirla(boyut);
    yerlestir_dizi(0);
}

// "123" gibi bir argümanı [alt, ust] aralığında tamsayıya çevirir
static bool arguman_oku(const std::string& s, int alt, int ust, int& sonuc)
{
    try {
        std::size_t son = 0;
        int deger = std::stoi(s, &son);
        if (son != s.size() || deger < alt || deger > ust) {
            return false;
        }
        sonuc = deger;
        return true;
    } catch (const std::exception&) {   // sayı değil ya da taşma
        return false;
    }
}

int main(int argc, char* argv[])
{
    int n_ust = 10, tekrar = 1;
    if ((argc > 1 && !arguman_oku(argv[1], 4, MAKS_N, n_ust))
        || (argc > 2 && !arguman_oku(argv[2], 1, 101, tekrar))) {
        std::cerr << "kullanım: " << argv[0] << " [N_ust 4.." << MAKS_N
                  << "] [tekrar 1..101]\n";
        return 2;
    }
    std::cout << "  N   çözüm    düğüm  tarama karşılaştırma  dizi denetimi\n";
    for (int boyut = 4; boyut <= n_ust; boyut++) {
        // her ölçüm sayaçları sıfırlar; son çalıştırmanın sayaçları kalır
        double t1 = olc_ortanca([&] { tarama_gorevi(boyut); }, tekrar);
        long long c1 = cozum_sayisi, d1 = dugum_sayisi;
        long long tarama = denetim_sayisi;
        double t2 = olc_ortanca([&] { dizi_gorevi(boyut); }, tekrar);
        std::cout << std::setw(3) << boyut << " " << std::setw(7)
                  << cozum_sayisi << " " << std::setw(8) << dugum_sayisi
                  << " " << std::setw(21) << tarama << " " << std::setw(14)
                  << denetim_sayisi
                  << ((c1 == cozum_sayisi && d1 == dugum_sayisi) ? ""
                                                                : "  FARK")
                  << "\n";
        std::fprintf(stderr, "  N = %2d: tarama %9.3f ms   dizi %9.3f ms   "
                     "oran %.2f\n", boyut, t1 * 1e3, t2 * 1e3, t1 / t2);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). C++'ta std::vector<bool>
 * ya da std::bitset ile aynı diziler bit düzeyinde tutulabilir. */

/* H03_03_ikili_diziler.cpp — AP-2 Hafta 3 · Örnek 3 (★)
 * Amaç    : n bitlik tüm ikili dizileri özyinelemeyle üretmek; her bitte
 *           iki dal (0: dahil etme, 1: dahil et); 2^n yaprak, 2^(n+1) − 1 çağrı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_03_ikili_diziler.cpp -o H03_03_ikili_diziler
 * Çalıştır: ./H03_03_ikili_diziler
 * Eşleri  : c/H03_03_ikili_diziler.c · python/H03_03_ikili_diziler.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>

static std::string dizi;            // üretilmekte olan dizi
static long long cagri_sayisi = 0;
static long long dizi_sayisi = 0;   // üretilen (yaprak) dizi sayısı
static bool yazdir_mi = true;

// dizi[0..k-1] belirlendi; dizi[k..n-1] için iki seçeneği dene
static void ikili_uret(int k, int n)
{
    cagri_sayisi++;
    if (k == n) {                   // yaprak: dizi tamamlandı
        dizi_sayisi++;
        if (yazdir_mi) {
            std::cout << dizi << "\n";
        }
        return;
    }
    dizi[k] = '0';                  // sol dal: k. bit 0
    ikili_uret(k + 1, n);
    dizi[k] = '1';                  // sağ dal: k. bit 1
    ikili_uret(k + 1, n);
}

int main()
{
    std::cout << "1) n = 3 için tüm ikili diziler (sözlük sırası)\n";
    dizi.assign(3, '0');
    ikili_uret(0, 3);
    std::cout << "dizi = " << dizi_sayisi << "   çağrı = " << cagri_sayisi
              << "\n";

    std::cout << "\n2) Sayım: dizi = 2^n, çağrı = 2^(n+1) - 1\n";
    std::cout << "  n      dizi       2^n     çağrı  2^(n+1)-1  eşit\n";
    yazdir_mi = false;
    for (int n = 1; n <= 16; n++) {
        cagri_sayisi = 0;
        dizi_sayisi = 0;
        dizi.assign(n, '0');
        ikili_uret(0, n);
        long long iki_n = 1LL << n;
        bool esit = dizi_sayisi == iki_n && cagri_sayisi == 2 * iki_n - 1;
        std::cout << std::setw(3) << n << " " << std::setw(9) << dizi_sayisi
                  << " " << std::setw(9) << iki_n << " " << std::setw(9)
                  << cagri_sayisi << " " << std::setw(10) << 2 * iki_n - 1
                  << "  " << (esit ? "evet" : "HAYIR") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::bitset yalnızca gösterim);
 * Python — itertools.product("01", repeat=n) (yalnızca kâhin olarak). */

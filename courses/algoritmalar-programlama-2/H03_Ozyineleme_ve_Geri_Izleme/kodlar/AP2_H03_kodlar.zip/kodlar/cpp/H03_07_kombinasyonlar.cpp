/* H03_07_kombinasyonlar.cpp — AP-2 Hafta 3 · Örnek 7 (★★)
 * Amaç    : k-kombinasyonlar: başlangıç indisiyle tekrarsız üretim (her küme
 *           artan indisle bir kez); üretilen sayının C(n, k) ile doğrulanması
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_07_kombinasyonlar.cpp -o H03_07_kombinasyonlar
 * Çalıştır: ./H03_07_kombinasyonlar
 * Eşleri  : c/H03_07_kombinasyonlar.c · python/H03_07_kombinasyonlar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <vector>

static std::vector<int> a;         // elemanlar: 1, 2, ..., n
static int n;
static std::vector<int> yol;       // seçilenler (artan indisle)
static long long cagri_sayisi = 0;
static long long komb_sayisi = 0;
static bool yazdir_mi = true;

static void komb_isle()
{
    komb_sayisi++;
    if (yazdir_mi) {
        std::cout << "{";
        for (std::size_t j = 0; j < yol.size(); j++) {
            std::cout << (j > 0 ? ", " : "") << yol[j];
        }
        std::cout << (komb_sayisi % 5 == 0 ? "}\n" : "}  ");
    }
}

// a[bas..n-1] içinden k - yol.size() eleman daha seç
static void kombinasyon(int bas, int k)
{
    cagri_sayisi++;
    int uzunluk = static_cast<int>(yol.size());
    if (uzunluk == k) {            // k eleman seçildi
        komb_isle();
        return;
    }
    // i en çok n - (k - uzunluk): sağda yeterli eleman kalmalı
    for (int i = bas; i <= n - (k - uzunluk); i++) {
        yol.push_back(a[i]);       // seç
        kombinasyon(i + 1, k);     // dene: yalnızca i'den sonrakiler
        yol.pop_back();            // geri al
    }
}

// C(m, k) = m! / (k! (m-k)!), çarpımsal formülle (her adım tam bölünür)
static long long kombinasyon_sayisi(int m, int k)
{
    long long c = 1;
    for (int i = 1; i <= k; i++) {
        c = c * (m - k + i) / i;   // c = C(m-k+i, i)
    }
    return c;
}

static void calistir(int boyut, int k)
{
    n = boyut;
    a.assign(n, 0);
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }
    yol.clear();
    cagri_sayisi = 0;
    komb_sayisi = 0;
    kombinasyon(0, k);
}

static void satir_yaz(int boyut, int k)
{
    long long c = kombinasyon_sayisi(boyut, k);
    std::cout << std::setw(3) << boyut << " " << std::setw(3) << k << " "
              << std::setw(10) << komb_sayisi << " " << std::setw(9) << c
              << " " << std::setw(9) << cagri_sayisi << "  "
              << (komb_sayisi == c ? "evet" : "HAYIR") << "\n";
}

int main()
{
    std::cout << "1) n = 5, k = 3: {1..5} içinden 3'lü seçimler\n";
    calistir(5, 3);
    std::cout << "kombinasyon = " << komb_sayisi << "   C(5, 3) = "
              << kombinasyon_sayisi(5, 3) << "   çağrı = " << cagri_sayisi
              << "\n";

    std::cout << "\n2) n = 10 için her k: üretilen = C(n, k)?\n";
    std::cout << "  n   k   üretilen    C(n,k)     çağrı  eşit\n";
    yazdir_mi = false;
    for (int k = 0; k <= 10; k++) {
        calistir(10, k);
        satir_yaz(10, k);
    }
    calistir(20, 10);
    satir_yaz(20, 10);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::next_permutation ile bir
 * bool maskesi dolaşılabilir); Python — itertools.combinations, math.comb
 * (yalnızca kâhin). */

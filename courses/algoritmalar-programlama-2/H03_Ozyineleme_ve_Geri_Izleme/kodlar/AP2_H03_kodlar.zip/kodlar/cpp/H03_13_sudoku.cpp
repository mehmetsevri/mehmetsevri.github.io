/* H03_13_sudoku.cpp — AP-2 Hafta 3 · Örnek 13 (★★★, meydan okuma)
 * Amaç    : Sudoku çözücüsü: kısıt yayılımı olmadan geri izleme. İlk boş
 *           kareye uygun her rakamı dene; çıkmazda geri al; düğümler sayılır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_13_sudoku.cpp -o H03_13_sudoku
 * Çalıştır: ./H03_13_sudoku < ../girdiler/H03_13_sudoku.txt   (süre stderr)
 * Eşleri  : c/H03_13_sudoku.c · python/H03_13_sudoku.py
 * Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
 */
#include <array>
#include <cstdio>
#include <iostream>
#include <string>

#include "zamanlayici.hpp"

using Izgara = std::array<std::array<int, 9>, 9>;
using Var = std::array<std::array<bool, 10>, 9>;

static Izgara tablo{};              // 0 = boş kare
static Izgara ipucu{};              // başlangıçtaki rakamlar
static Var satir_var{};             // satir_var[r][d]: r. satırda d var mı?
static Var sutun_var{};
static Var kutu_var{};              // 3x3 kutular: 0..8
static long long dugum_sayisi = 0;

static int kutu_no(int r, int c)
{
    return (r / 3) * 3 + c / 3;
}

static bool uygun_mu(int r, int c, int d)
{
    return !satir_var[r][d] && !sutun_var[c][d]
           && !kutu_var[kutu_no(r, c)][d];
}

// var = true: d rakamını (r, c)'ye koy; var = false: kaldır
static void koy(int r, int c, int d, bool var)
{
    tablo[r][c] = var ? d : 0;
    satir_var[r][d] = var;
    sutun_var[c][d] = var;
    kutu_var[kutu_no(r, c)][d] = var;
}

// k = 0..80 (satır öncelikli kare no); k'dan sonraki ilk boş kareyi doldur
static bool coz(int k)
{
    dugum_sayisi++;
    while (k < 81 && tablo[k / 9][k % 9] != 0) {
        k++;                        // dolu kareleri atla
    }
    if (k == 81) {
        return true;                // boş kare kalmadı: çözüldü
    }
    int r = k / 9, c = k % 9;
    for (int d = 1; d <= 9; d++) {
        if (uygun_mu(r, c, d)) {
            koy(r, c, d, true);     // seç
            if (coz(k + 1)) {       // dene
                return true;        // tek çözüm yeter: dur
            }
            koy(r, c, d, false);    // geri al
        }
    }
    return false;                   // hiçbir rakam olmadı: geri dön
}

// 9 satır, her biri 9 karakter: '1'..'9' ya da '.'/'0' (boş)
static bool bulmaca_oku()
{
    std::string satir;
    for (int r = 0; r < 9; r++) {
        if (!std::getline(std::cin, satir)) {
            return false;
        }
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (satir.size() != 9) {
            return false;
        }
        for (int c = 0; c < 9; c++) {
            char k = satir[c];
            int d = (k >= '1' && k <= '9') ? k - '0' : 0;
            if (d == 0 && k != '.' && k != '0') {
                return false;
            }
            if (d != 0) {
                if (!uygun_mu(r, c, d)) {
                    return false;   // ipuçları çelişiyor
                }
                koy(r, c, d, true);
            }
            ipucu[r][c] = d;
        }
    }
    return true;
}

static void tablo_yaz()
{
    for (int r = 0; r < 9; r++) {
        if (r > 0 && r % 3 == 0) {
            std::cout << "------+-------+------\n";
        }
        for (int c = 0; c < 9; c++) {
            if (c > 0) {
                std::cout << (c % 3 == 0 ? " | " : " ");
            }
            std::cout << (tablo[r][c] ? static_cast<char>('0' + tablo[r][c])
                                      : '.');
        }
        std::cout << "\n";
    }
}

// Her satır, sütun ve kutuda 1..9 tam bir kez mi; ipuçları yerinde mi?
static bool dogrula()
{
    for (int i = 0; i < 9; i++) {
        std::array<int, 10> s{}, t{}, k{};
        for (int j = 0; j < 9; j++) {
            s[tablo[i][j]]++;
            t[tablo[j][i]]++;
            k[tablo[(i / 3) * 3 + j / 3][(i % 3) * 3 + j % 3]]++;
        }
        for (int d = 1; d <= 9; d++) {
            if (s[d] != 1 || t[d] != 1 || k[d] != 1) {
                return false;
            }
        }
    }
    for (int r = 0; r < 9; r++) {
        for (int c = 0; c < 9; c++) {
            if (ipucu[r][c] != 0 && ipucu[r][c] != tablo[r][c]) {
                return false;
            }
        }
    }
    return true;
}

int main()
{
    if (!bulmaca_oku()) {
        std::cerr << "Hatalı Sudoku girdisi\n";
        return 1;
    }
    int ipucu_sayisi = 0;
    for (const auto& satir : ipucu) {
        for (int d : satir) {
            ipucu_sayisi += (d != 0) ? 1 : 0;
        }
    }
    std::cout << "Bulmaca (" << ipucu_sayisi << " ipucu):\n";
    tablo_yaz();
    double t0 = zaman_sn();
    bool cozuldu = coz(0);
    double sure = zaman_sn() - t0;
    if (!cozuldu) {
        std::cout << "\nÇözüm yok (ziyaret edilen düğüm = " << dugum_sayisi
                  << ")\n";
        return 0;
    }
    std::cout << "\nÇözüm (ziyaret edilen düğüm = " << dugum_sayisi << "):\n";
    tablo_yaz();
    std::cout << "doğrulama: " << (dogrula() ? "geçerli" : "GEÇERSİZ")
              << "\n";
    std::fprintf(stderr, "çözme süresi: %.3f ms\n", sure * 1e3);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Gerçek çözücüler kısıt
 * yayılımı ve "en az seçenekli kare önce" sezgisiyle düğüm sayısını azaltır. */

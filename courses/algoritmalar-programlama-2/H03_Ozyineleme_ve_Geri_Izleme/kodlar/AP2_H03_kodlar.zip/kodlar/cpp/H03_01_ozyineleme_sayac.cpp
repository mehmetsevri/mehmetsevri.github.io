/* H03_01_ozyineleme_sayac.cpp — AP-2 Hafta 3 · Örnek 1 (★)
 * Amaç    : Özyinelemeli toplam ve Fibonacci'de çağrı sayacı ve derinlik;
 *           fib(5) çağrı ağacının girintili çizimi; çağrı = 2·F(n+1) − 1
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_01_ozyineleme_sayac.cpp -o H03_01_ozyineleme_sayac
 * Çalıştır: ./H03_01_ozyineleme_sayac
 * Eşleri  : c/H03_01_ozyineleme_sayac.c · python/H03_01_ozyineleme_sayac.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

static long long cagri_sayisi = 0;     // toplam çağrı sayısı
static int en_buyuk_derinlik = 0;      // aynı anda açık en çok çerçeve
static std::vector<bool> goruldu(64);  // fib(k) daha önce çağrıldı mı?

static void sayaclari_sifirla()
{
    cagri_sayisi = 0;
    en_buyuk_derinlik = 0;
}

// 1 + 2 + ... + n; d: bu çağrının derinliği (kök = 1)
static long long toplam(int n, int d)
{
    cagri_sayisi++;
    if (d > en_buyuk_derinlik) {
        en_buyuk_derinlik = d;
    }
    if (n == 0) {
        return 0;                       // temel durum
    }
    return n + toplam(n - 1, d + 1);    // özyinelemeli adım
}

// n. Fibonacci sayısı: F(0) = 0, F(1) = 1
static long long fib(int n, int d)
{
    cagri_sayisi++;
    if (d > en_buyuk_derinlik) {
        en_buyuk_derinlik = d;
    }
    if (n < 2) {
        return n;                       // temel durum
    }
    return fib(n - 1, d + 1) + fib(n - 2, d + 1);
}

// fib ile aynı çağrılar; her çağrıyı girintiyle yazar (ağaç çizimi)
static long long fib_agac(int n, int d)
{
    cagri_sayisi++;
    if (d > en_buyuk_derinlik) {
        en_buyuk_derinlik = d;
    }
    std::cout << std::string(2 * (d - 1), ' ');   // girinti = derinlik
    std::cout << "fib(" << n << ")" << (goruldu[n] ? "  (tekrar)" : "")
              << "\n";
    goruldu[n] = true;
    if (n < 2) {
        return n;
    }
    return fib_agac(n - 1, d + 1) + fib_agac(n - 2, d + 1);
}

// Kâhin: döngüyle F(n)
static long long fib_dongu(int n)
{
    long long onceki = 0, simdiki = 1;
    if (n == 0) {
        return 0;
    }
    for (int i = 2; i <= n; i++) {
        long long sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

int main()
{
    const std::vector<int> toplam_n = {5, 100};
    const std::vector<int> fib_n = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                                    15, 20, 25};

    std::cout << "1) toplam(n) = 1 + 2 + ... + n\n";
    for (int n : toplam_n) {
        sayaclari_sifirla();
        long long t = toplam(n, 1);
        std::cout << "toplam(" << n << ") = " << t << "   çağrı = "
                  << cagri_sayisi << "   en büyük derinlik = "
                  << en_buyuk_derinlik << "\n";
    }

    std::cout << "\n2) fib(5) çağrı ağacı (ön sıra; girinti = derinlik)\n";
    sayaclari_sifirla();
    long long f5 = fib_agac(5, 1);
    std::cout << "fib(5) = " << f5 << "   çağrı = " << cagri_sayisi
              << "   en büyük derinlik = " << en_buyuk_derinlik << "\n";
    int farkli = 0;
    for (int k = 0; k <= 5; k++) {
        farkli += goruldu[k] ? 1 : 0;
    }
    std::cout << "farklı alt problem = " << farkli
              << "   tekrarlanan çağrı = " << cagri_sayisi - farkli << "\n";

    std::cout << "\n3) fib(n): çağrı sayısı = 2*F(n+1) - 1 mi?\n";
    std::cout << "  n     fib(n)     çağrı  2*F(n+1)-1  derinlik  eşit\n";
    for (int n : fib_n) {
        sayaclari_sifirla();
        long long f = fib(n, 1);
        long long beklenen = 2 * fib_dongu(n + 1) - 1;
        std::cout << std::setw(3) << n << " " << std::setw(10) << f << " "
                  << std::setw(9) << cagri_sayisi << " " << std::setw(11)
                  << beklenen << " " << std::setw(9) << en_buyuk_derinlik
                  << "  " << (cagri_sayisi == beklenen ? "evet" : "HAYIR")
                  << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: yok — özyineleme dilin kendisidir. (Python'da
 * functools.lru_cache tekrarlanan çağrıları önler; H13'te memoization.) */

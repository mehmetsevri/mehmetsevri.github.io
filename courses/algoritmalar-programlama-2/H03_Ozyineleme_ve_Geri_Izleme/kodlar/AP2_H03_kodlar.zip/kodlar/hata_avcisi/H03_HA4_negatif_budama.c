/* H03_HA4_negatif_budama.c — AP-2 Hafta 3 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR: "toplam > hedef ise dur" budaması, dizide
 * NEGATİF sayı (-3) varken de uygulanıyor. Budama yalnızca tüm elemanlar
 * negatif değilken güvenlidir; burada çözüm kaçırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA4_negatif_budama.c -o H03_HA4_negatif_budama
 * Beklenen: 2 çözüm ({4, 2} ve {5, 4, -3}) · Gözlenen: bkz. ciktilar/
 * Düzeltme: H03_HA4_negatif_budama_duzeltilmis.c
 */
#include <stdio.h>

#define N 4

static const int a[N] = {5, 4, -3, 2};
static const int hedef = 6;
static int yol[N];
static int uzunluk = 0;
static int cozum_sayisi = 0;

static void cozum_yaz(void)
{
    cozum_sayisi++;
    printf("  {");
    for (int j = 0; j < uzunluk; j++) {
        printf(j > 0 ? ", %d" : "%d", yol[j]);
    }
    printf("}\n");
}

static void budamali(int i, int toplam)
{
    if (toplam > hedef) {
        return;                    /* HATA: -3 eklenince toplam azalabilir */
    }
    if (i == N) {
        if (toplam == hedef) {
            cozum_yaz();
        }
        return;
    }
    budamali(i + 1, toplam);
    yol[uzunluk++] = a[i];
    budamali(i + 1, toplam + a[i]);
    uzunluk--;
}

int main(void)
{
    printf("a = {5, 4, -3, 2}, hedef = 6\n");
    budamali(0, 0);
    printf("bulunan çözüm = %d (beklenen 2)\n", cozum_sayisi);
    return 0;
}

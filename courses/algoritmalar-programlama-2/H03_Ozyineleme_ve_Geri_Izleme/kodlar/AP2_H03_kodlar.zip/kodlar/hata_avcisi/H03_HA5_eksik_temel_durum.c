/* H03_HA5_eksik_temel_durum.c — AP-2 Hafta 3 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR: temel durum yalnızca n == 0; tek n için
 * (7, 5, 3, 1, -1, ...) n hiçbir zaman 0 olmaz → sonsuz özyineleme.
 * Güvenli gösterim: derinlik sayacı 100 000'i aşınca program durur.
 * Korumasız (gerçek belirti): ./H03_HA5_eksik_temel_durum korumasiz
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H03_HA5_eksik_temel_durum.c -o H03_HA5_eksik_temel_durum
 * Düzeltme: H03_HA5_eksik_temel_durum_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SINIR 100000

static long long derinlik = 0;
static int korumali = 1;

/* n + (n - 2) + (n - 4) + ... (ikişer azalan toplam) */
static long long ikiser_toplam(long long n)
{
    if (korumali && ++derinlik > SINIR) {   /* yalnızca gösterim koruması */
        fprintf(stderr, "derinlik %d aşıldı: temel duruma ulaşılamıyor\n",
                SINIR);
        exit(1);
    }
    if (n == 0) {            /* HATA: tek n için 0 atlanır (n <= 0 olmalı) */
        return 0;
    }
    return n + ikiser_toplam(n - 2);
}

int main(int argc, char *argv[])
{
    if (argc > 1 && strcmp(argv[1], "korumasiz") == 0) {
        korumali = 0;
    }
    derinlik = 0;
    printf("ikiser_toplam(6) = %lld\n", ikiser_toplam(6));
    fflush(stdout);
    derinlik = 0;
    printf("ikiser_toplam(7) = %lld\n", ikiser_toplam(7));
    return 0;
}

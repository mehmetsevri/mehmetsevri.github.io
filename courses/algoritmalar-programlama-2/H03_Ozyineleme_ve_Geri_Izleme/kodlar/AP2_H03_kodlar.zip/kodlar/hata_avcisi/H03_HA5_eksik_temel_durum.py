"""H03_HA5_eksik_temel_durum.py — AP-2 Hafta 3 · Hata Avcısı 5 (Python)
BU DOSYA KASITLI HATA İÇERİR: temel durum yalnızca n == 0; tek n için
(7, 5, 3, 1, -1, ...) n hiçbir zaman 0 olmaz → sonsuz özyineleme.
Python'da güvenlidir: yorumlayıcı ~1000 çerçevede RecursionError fırlatır.
Çalıştır: python3 H03_HA5_eksik_temel_durum.py
Düzeltme: H03_HA5_eksik_temel_durum_duzeltilmis.py
"""


def ikiser_toplam(n):
    """n + (n - 2) + (n - 4) + ... (ikişer azalan toplam)"""
    if n == 0:              # HATA: tek n için 0 atlanır (n <= 0 olmalı)
        return 0
    return n + ikiser_toplam(n - 2)


def main():
    print(f"ikiser_toplam(6) = {ikiser_toplam(6)}")
    print(f"ikiser_toplam(7) = {ikiser_toplam(7)}")


if __name__ == "__main__":
    main()

"""H03_HA5_eksik_temel_durum_duzeltilmis.py — AP-2 Hafta 3 · Hata Avcısı 5
(düzeltilmiş, Python): temel durum n <= 0; adım 2 olduğundan n hem 0'a
hem -1'e inebilir.
Çalıştır: python3 H03_HA5_eksik_temel_durum_duzeltilmis.py
"""


def ikiser_toplam(n):
    """n + (n - 2) + (n - 4) + ... (ikişer azalan toplam)"""
    if n <= 0:              # 0 ve negatif değerler: temel durum
        return 0
    return n + ikiser_toplam(n - 2)


def main():
    print(f"ikiser_toplam(6) = {ikiser_toplam(6)}")
    print(f"ikiser_toplam(7) = {ikiser_toplam(7)}")


if __name__ == "__main__":
    main()

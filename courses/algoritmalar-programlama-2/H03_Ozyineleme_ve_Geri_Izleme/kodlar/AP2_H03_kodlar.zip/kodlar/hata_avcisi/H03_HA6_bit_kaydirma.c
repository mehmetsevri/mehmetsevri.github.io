/* H03_HA6_bit_kaydirma.c — AP-2 Hafta 3 · Hata Avcısı 6
 * BU DOSYA KASITLI HATA İÇERİR: alt küme sayısı 2^n, int türündeki
 * 1 << n ile hesaplanıyor. n = 31'de sonuç int'e sığmaz, n >= 32'de
 * kaydırma miktarı türün genişliğine ulaşır: ikisi de TANIMSIZ DAVRANIŞ.
 * Derleyici uyarı vermez (n bir değişken). Gözlenen: bkz. ciktilar/
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA6_bit_kaydirma.c -o H03_HA6_bit_kaydirma
 * Denetim : aynı komuta -fsanitize=undefined eklenirse çalışma anında
 *           "shift exponent" / "left shift" iletileri görülür
 * Düzeltme: H03_HA6_bit_kaydirma_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

/* n elemanlı kümenin alt küme sayısı */
static long long alt_kume_sayisi(int n)
{
    return 1 << n;                 /* HATA: int'te 1 << 31 ve 1 << 32 */
}

int main(int argc, char *argv[])
{
    /* üst sınır komut satırından: derleyici n'yi önceden bilemesin */
    int ust = argc > 1 ? (int)strtol(argv[1], NULL, 10) : 33;
    for (int n = 29; n <= ust; n++) {
        printf("n = %d: 2^n = %lld\n", n, alt_kume_sayisi(n));
    }
    return 0;
}

/* H03_HA2_ilk_cozumde_donmek_duzeltilmis.c — AP-2 Hafta 3 · Hata Avcısı 2
 * (düzeltilmiş): iki ayrı sözleşme, iki ayrı fonksiyon. tum_cozumler()
 * hiçbir zaman erken dönmez ve ağacın tamamını dolaşır; ilk_cozum() ise
 * çözümü bulduğu anda 1 döndürür ve bu sonuç yukarı doğru iletilerek
 * arama durdurulur (tek çözüm yeterken ağacın tamamını dolaşmak israftır).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA2_ilk_cozumde_donmek_duzeltilmis.c \
 *           -o H03_HA2_ilk_cozumde_donmek_duzeltilmis
 */
#include <stdio.h>

#define N 8

static int sutun[N];
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0;
static long long denetlenen_kare = 0;  /* guvenli_mi çağrısı */

static int guvenli_mi(int r, int c)
{
    denetlenen_kare++;
    for (int i = 0; i < r; i++) {
        int fark = sutun[i] - c;
        if (fark == 0 || fark == r - i || fark == i - r) {
            return 0;
        }
    }
    return 1;
}

/* Tüm çözümler: erken dönüş yok */
static void tum_cozumler(int r)
{
    dugum_sayisi++;
    if (r == N) {
        cozum_sayisi++;
        return;
    }
    for (int c = 0; c < N; c++) {
        if (guvenli_mi(r, c)) {
            sutun[r] = c;
            tum_cozumler(r + 1);
        }
    }
}

/* Tek çözüm yeter: bulununca 1 döner ve arama durur */
static int ilk_cozum(int r)
{
    dugum_sayisi++;
    if (r == N) {
        return 1;
    }
    for (int c = 0; c < N; c++) {
        if (guvenli_mi(r, c)) {
            sutun[r] = c;
            if (ilk_cozum(r + 1)) {
                return 1;
            }
        }
    }
    return 0;
}

int main(void)
{
    tum_cozumler(0);
    printf("N = %d: çözüm sayısı = %lld (beklenen 92)\n", N, cozum_sayisi);
    printf("tüm çözümler: ziyaret edilen düğüm = %lld, denetlenen kare = "
           "%lld\n", dugum_sayisi, denetlenen_kare);
    dugum_sayisi = 0;
    denetlenen_kare = 0;
    ilk_cozum(0);
    printf("ilk çözüm: sütunlar =");
    for (int r = 0; r < N; r++) {
        printf(" %d", sutun[r]);
    }
    printf("\nilk çözüm: ziyaret edilen düğüm = %lld, denetlenen kare = "
           "%lld\n", dugum_sayisi, denetlenen_kare);
    return 0;
}

"""H03_HA7_liste_kopyasi.py — AP-2 Hafta 3 · Hata Avcısı 7 (Python)
BU DOSYA KASITLI HATA İÇERİR: alt kümeler bir listeye toplanırken
sonuc.append(yol) yazılmış. Eklenen, yol listesinin KOPYASI değil, aynı
listeye bir başvurudur (referans); geri izleme yol'u boşalttıkça
sonuc'taki bütün öğeler de "değişir".
Çalıştır: python3 H03_HA7_liste_kopyasi.py
Düzeltme: H03_HA7_liste_kopyasi_duzeltilmis.py
"""

a = [1, 2, 3]
yol = []
sonuc = []


def alt_kumeler(i):
    if i == len(a):
        sonuc.append(yol)           # HATA: kopya değil, aynı liste
        return
    alt_kumeler(i + 1)
    yol.append(a[i])
    alt_kumeler(i + 1)
    yol.pop()


def main():
    alt_kumeler(0)
    print(f"üretilen = {len(sonuc)}")
    print(f"sonuc = {sonuc}")
    print(f"aynı nesne mi? {sonuc[0] is sonuc[7]}")


if __name__ == "__main__":
    main()

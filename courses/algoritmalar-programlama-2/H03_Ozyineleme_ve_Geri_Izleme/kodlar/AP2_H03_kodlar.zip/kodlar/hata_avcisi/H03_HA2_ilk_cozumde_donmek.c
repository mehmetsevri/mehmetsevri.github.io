/* H03_HA2_ilk_cozumde_donmek.c — AP-2 Hafta 3 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR: TÜM çözümler sayılmak istenirken
 * yerlestir() ilk çözümde 1 döndürüp aramayı kesiyor ("tek çözüm"
 * kalıbı yanlış yerde kullanılmış).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA2_ilk_cozumde_donmek.c -o H03_HA2_ilk_cozumde_donmek
 * Beklenen: N = 8 için 92 çözüm · Gözlenen: bkz. ciktilar/
 * Düzeltme: H03_HA2_ilk_cozumde_donmek_duzeltilmis.c
 */
#include <stdio.h>

#define N 8

static int sutun[N];
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0;

static int guvenli_mi(int r, int c)
{
    for (int i = 0; i < r; i++) {
        int fark = sutun[i] - c;
        if (fark == 0 || fark == r - i || fark == i - r) {
            return 0;
        }
    }
    return 1;
}

/* Amaç: TÜM çözümleri saymak */
static int yerlestir(int r)
{
    dugum_sayisi++;
    if (r == N) {
        cozum_sayisi++;
        return 1;                  /* çözüm bulundu */
    }
    for (int c = 0; c < N; c++) {
        if (guvenli_mi(r, c)) {
            sutun[r] = c;
            if (yerlestir(r + 1)) {
                return 1;          /* HATA: ilk çözümde arama kesiliyor */
            }
        }
    }
    return 0;
}

int main(void)
{
    yerlestir(0);
    printf("N = %d: çözüm sayısı = %lld (beklenen 92)\n", N, cozum_sayisi);
    printf("ziyaret edilen düğüm = %lld\n", dugum_sayisi);
    return 0;
}

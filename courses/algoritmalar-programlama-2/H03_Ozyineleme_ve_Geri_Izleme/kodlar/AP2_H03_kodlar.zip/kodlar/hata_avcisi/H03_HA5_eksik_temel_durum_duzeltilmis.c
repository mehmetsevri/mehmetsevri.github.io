/* H03_HA5_eksik_temel_durum_duzeltilmis.c — AP-2 Hafta 3 · Hata Avcısı 5
 * (düzeltilmiş): temel durum, özyinelemenin ULAŞABİLECEĞİ her son değeri
 * kapsamalıdır. Adım 2 olduğundan n hem 0'a hem -1'e inebilir: koşul
 * n <= 0 olur. Denetim sorusu: "her çağrı temel duruma yaklaşıyor mu ve
 * temel duruma mutlaka varıyor mu?"
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA5_eksik_temel_durum_duzeltilmis.c \
 *           -o H03_HA5_eksik_temel_durum_duzeltilmis
 */
#include <stdio.h>

/* n + (n - 2) + (n - 4) + ... (ikişer azalan toplam) */
static long long ikiser_toplam(long long n)
{
    if (n <= 0) {            /* 0 ve negatif değerler: temel durum */
        return 0;
    }
    return n + ikiser_toplam(n - 2);
}

int main(void)
{
    printf("ikiser_toplam(6) = %lld\n", ikiser_toplam(6));
    printf("ikiser_toplam(7) = %lld\n", ikiser_toplam(7));
    return 0;
}

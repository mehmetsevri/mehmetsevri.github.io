"""H03_HA7_liste_kopyasi_duzeltilmis.py — AP-2 Hafta 3 · Hata Avcısı 7
(düzeltilmiş, Python): yaprakta yol'un o anki KOPYASI saklanır:
sonuc.append(yol[:]) (ya da list(yol), yol.copy()). C++'ta
sonuc.push_back(yol) zaten kopyalar (değer anlamı); benzer sözdizimi,
farklı anlam.
Çalıştır: python3 H03_HA7_liste_kopyasi_duzeltilmis.py
"""

a = [1, 2, 3]
yol = []
sonuc = []


def alt_kumeler(i):
    if i == len(a):
        sonuc.append(yol[:])        # o anki durumun kopyası
        return
    alt_kumeler(i + 1)
    yol.append(a[i])
    alt_kumeler(i + 1)
    yol.pop()


def main():
    alt_kumeler(0)
    print(f"üretilen = {len(sonuc)}")
    print(f"sonuc = {sonuc}")
    print(f"aynı nesne mi? {sonuc[0] is sonuc[7]}")


if __name__ == "__main__":
    main()

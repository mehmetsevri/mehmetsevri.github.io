/* H03_HA3_tekrarli_permutasyon_duzeltilmis.cpp — AP-2 Hafta 3
 * Hata Avcısı 3 (düzeltilmiş): girdi SIRALI olmalıdır. Eşit elemanlardan
 * yalnızca "soldaki kullanılmışsa" sağdaki seçilebilir; böylece eşit
 * elemanlar hep aynı sırada yerleşir ve her permütasyon bir kez üretilir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA3_tekrarli_permutasyon_duzeltilmis.cpp \
 *           -o H03_HA3_tekrarli_permutasyon_duzeltilmis
 */
#include <iostream>
#include <vector>

static const std::vector<int> a = {1, 1, 2};   // sıralı girdi
static std::vector<int> yol(a.size());
static std::vector<bool> kullanildi(a.size());
static int perm_sayisi = 0;

static void permutasyon(std::size_t k)
{
    if (k == a.size()) {
        perm_sayisi++;
        for (int x : yol) {
            std::cout << x;
        }
        std::cout << "\n";
        return;
    }
    for (std::size_t i = 0; i < a.size(); i++) {
        if (kullanildi[i]) {
            continue;
        }
        if (i > 0 && a[i] == a[i - 1] && !kullanildi[i - 1]) {
            continue;              // eşit eleman: soldaki önce kullanılmalı
        }
        kullanildi[i] = true;
        yol[k] = a[i];
        permutasyon(k + 1);
        kullanildi[i] = false;
    }
}

int main()
{
    permutasyon(0);
    std::cout << "üretilen = " << perm_sayisi << " (beklenen 3)\n";
    return 0;
}

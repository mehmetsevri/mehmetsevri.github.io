/* H03_HA6_bit_kaydirma_duzeltilmis.c — AP-2 Hafta 3 · Hata Avcısı 6
 * (düzeltilmiş): kaydırılan değer, sonucu taşıyabilecek genişlikte ve
 * işaretsiz olmalıdır: 1ULL << n (n <= 63). Maske döngüsünde de
 * unsigned long long kullanılır. (Not: n = 33 için 2^33 maskeyi tek tek
 * dolaşmak, sayı doğru olsa bile uygulanabilir değildir.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA6_bit_kaydirma_duzeltilmis.c \
 *           -o H03_HA6_bit_kaydirma_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

/* n elemanlı kümenin alt küme sayısı (0 <= n <= 63) */
static unsigned long long alt_kume_sayisi(int n)
{
    return 1ULL << n;
}

int main(int argc, char *argv[])
{
    int ust = argc > 1 ? (int)strtol(argv[1], NULL, 10) : 33;
    for (int n = 29; n <= ust && n <= 63; n++) {
        printf("n = %d: 2^n = %llu\n", n, alt_kume_sayisi(n));
    }
    return 0;
}

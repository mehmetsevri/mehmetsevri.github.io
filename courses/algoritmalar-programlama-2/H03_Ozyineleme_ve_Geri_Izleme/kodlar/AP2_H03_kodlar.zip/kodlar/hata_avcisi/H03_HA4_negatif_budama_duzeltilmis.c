/* H03_HA4_negatif_budama_duzeltilmis.c — AP-2 Hafta 3 · Hata Avcısı 4
 * (düzeltilmiş): budama koşulu, "bu düğümün hiçbir torunu çözüm olamaz"
 * önermesini KANITLAYAN bir koşul olmalıdır. Negatif sayı varken
 * toplam > hedef bunu kanıtlamaz; bu yüzden budama yalnızca dizideki tüm
 * elemanlar negatif değilse etkinleştirilir (aksi hâlde ağacın tamamı).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA4_negatif_budama_duzeltilmis.c \
 *           -o H03_HA4_negatif_budama_duzeltilmis
 */
#include <stdio.h>

#define N 4

static const int a[N] = {5, 4, -3, 2};
static const int hedef = 6;
static int yol[N];
static int uzunluk = 0;
static int cozum_sayisi = 0;
static int budama_guvenli = 1;     /* tüm a[i] >= 0 ise 1 */

static void cozum_yaz(void)
{
    cozum_sayisi++;
    printf("  {");
    for (int j = 0; j < uzunluk; j++) {
        printf(j > 0 ? ", %d" : "%d", yol[j]);
    }
    printf("}\n");
}

static void budamali(int i, int toplam)
{
    if (budama_guvenli && toplam > hedef) {
        return;                    /* yalnızca negatif olmayan girdide */
    }
    if (i == N) {
        if (toplam == hedef) {
            cozum_yaz();
        }
        return;
    }
    budamali(i + 1, toplam);
    yol[uzunluk++] = a[i];
    budamali(i + 1, toplam + a[i]);
    uzunluk--;
}

int main(void)
{
    for (int i = 0; i < N; i++) {
        if (a[i] < 0) {
            budama_guvenli = 0;
        }
    }
    printf("a = {5, 4, -3, 2}, hedef = 6 (budama %s)\n",
           budama_guvenli ? "açık" : "kapalı: negatif eleman var");
    budamali(0, 0);
    printf("bulunan çözüm = %d (beklenen 2)\n", cozum_sayisi);
    return 0;
}

/* H03_HA1_geri_alma_unutma_duzeltilmis.c — AP-2 Hafta 3 · Hata Avcısı 1
 * (düzeltilmiş): her "seç" adımının özyinelemeli çağrıdan sonra simetrik
 * bir "geri al" adımı vardır; çağrı döndüğünde durum, çağrıdan önceki
 * hâline getirilir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_HA1_geri_alma_unutma_duzeltilmis.c \
 *           -o H03_HA1_geri_alma_unutma_duzeltilmis
 */
#include <stdio.h>

#define N 3

static int a[N] = {1, 2, 3};
static int yol[N];
static int kullanildi[N];
static int perm_sayisi = 0;

static void permutasyon(int k)
{
    if (k == N) {
        perm_sayisi++;
        printf("%d%d%d\n", yol[0], yol[1], yol[2]);
        return;
    }
    for (int i = 0; i < N; i++) {
        if (!kullanildi[i]) {
            kullanildi[i] = 1;     /* seç */
            yol[k] = a[i];
            permutasyon(k + 1);    /* dene */
            kullanildi[i] = 0;     /* geri al */
        }
    }
}

int main(void)
{
    permutasyon(0);
    printf("permütasyon sayısı = %d (beklenen 6)\n", perm_sayisi);
    printf("kullanildi = {%d, %d, %d}\n", kullanildi[0], kullanildi[1],
           kullanildi[2]);
    return 0;
}

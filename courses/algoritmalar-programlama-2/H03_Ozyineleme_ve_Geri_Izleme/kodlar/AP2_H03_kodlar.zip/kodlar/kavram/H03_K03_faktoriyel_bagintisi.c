/* H03_K03_faktoriyel_bagintisi.c — AP-2 Hafta 3 · Kavram 3
 * Amaç    : İki yineleme bağıntısı: faktöriyelde T(n) = T(n−1) + c
 *           (n + 1 çağrı) ve permütasyon sayısında P(n) = n·P(n−1) (= n!)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_K03_faktoriyel_bagintisi.c -o H03_K03_faktoriyel_bagintisi
 * Çalıştır: ./H03_K03_faktoriyel_bagintisi
 */
#include <stdio.h>

static long long cagri_sayisi = 0;

/* n! = n · (n − 1)!, 0! = 1 — her çağrıda sabit iş: T(n) = T(n − 1) + c */
static long long faktoriyel(int n)
{
    cagri_sayisi++;
    if (n == 0) {
        return 1;
    }
    return n * faktoriyel(n - 1);
}

/* n elemanın permütasyon sayısı: ilk konum için n seçenek, kalan n − 1
 * eleman için P(n − 1) permütasyon → P(n) = n · P(n − 1), P(0) = 1 */
static long long perm_sayisi(int n)
{
    return n == 0 ? 1 : n * perm_sayisi(n - 1);
}

int main(void)
{
    printf("  n          n!   çağrı (n+1)   P(n) = n*P(n-1)\n");
    for (int n = 0; n <= 20; n += 4) {
        cagri_sayisi = 0;
        long long f = faktoriyel(n);
        printf("%3d %19lld %6lld %22lld\n", n, f, cagri_sayisi,
               perm_sayisi(n));
    }
    printf("Açılım: T(n) = T(n-1) + c = T(n-2) + 2c = ... = T(0) + n*c\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (tgamma(n + 1) kayan noktalı yaklaşık değer);
 * C++ — std::tgamma; Python — math.factorial(n), math.perm(n). */

"""H03_K07_python_cerceve.py — AP-2 Hafta 3 · Kavram 7 (Kaputun Altında)
Amaç    : Python'da her çağrı bir çerçeve (frame) nesnesidir: f_back ile
          çağırana bağlanır, yerel adlar f_locals'ta görünür
Çalıştır: python3 H03_K07_python_cerceve.py
Not     : sys._getframe CPython'a özgüdür; yalnızca gözlem içindir.
"""

import sys


def cerceve_zinciri():
    """Çağıranın çerçevesinden başlayıp f_back zincirini dolaşır"""
    f = sys._getframe(1)
    adlar = []
    while f is not None:
        ad = f.f_code.co_name
        n = f.f_locals.get("n")
        adlar.append(ad if n is None else f"{ad}(n={n})")
        f = f.f_back
    return adlar


def toplam(n):
    if n == 0:
        zincir = cerceve_zinciri()
        print("en derindeki an, tepe solda:")
        print("  " + " <- ".join(zincir))
        print(f"  açık çerçeve sayısı = {len(zincir)}")
        return 0
    return n + toplam(n - 1)


def main():
    print(f"toplam(3) = {toplam(3)}")
    print(f"sys.getrecursionlimit() = {sys.getrecursionlimit()}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: inspect.stack() aynı zinciri ayrıntılı listeler.

"""H03_K01_uretec_alt_kume.py — AP-2 Hafta 3 · Kavram 1 (Dil Penceresi)
Amaç    : Python üreteçleriyle (yield) alt küme ve permütasyon üretimi;
          tembel (lazy) üretim ve itertools ile kâhin karşılaştırması
Çalıştır: python3 H03_K01_uretec_alt_kume.py
Not     : Algoritma Örnek 4 ve 6 ile aynıdır (önce "dahil etme");
          itertools yalnızca kâhin olarak kullanılır.
"""

import itertools


def alt_kumeler_uret(a, i=0, yol=None):
    """a[i..] için karar ver; her yaprakta yol'un kopyasını ver"""
    if yol is None:
        yol = []
    if i == len(a):
        yield tuple(yol)               # kopya: yol değişmeye devam eder
        return
    yield from alt_kumeler_uret(a, i + 1, yol)    # a[i] yok
    yol.append(a[i])                               # seç
    yield from alt_kumeler_uret(a, i + 1, yol)    # dene
    yol.pop()                                      # geri al


def permutasyonlar_uret(a, yol=None, kullanildi=None):
    """kullanildi dizisiyle sözlük sırasında permütasyonlar"""
    if yol is None:
        yol, kullanildi = [], [False] * len(a)
    if len(yol) == len(a):
        yield tuple(yol)
        return
    for i in range(len(a)):
        if not kullanildi[i]:
            kullanildi[i] = True       # seç
            yol.append(a[i])
            yield from permutasyonlar_uret(a, yol, kullanildi)   # dene
            yol.pop()                  # geri al
            kullanildi[i] = False


def kume_metni(k):
    return "{" + ", ".join(str(x) for x in k) + "}"


def main():
    print("1) Üreteçle alt kümeler, a = [1, 2, 3]:")
    print(" ".join(kume_metni(k) for k in alt_kumeler_uret([1, 2, 3])))

    print("\n2) Tembel üretim: n = 30 için yalnız ilk 4 küme istenir")
    g = alt_kumeler_uret(list(range(1, 31)))
    for k in itertools.islice(g, 4):
        print("  ", kume_metni(k))
    print("   (2^30 kümenin geri kalanı hiç üretilmedi)")

    print("\n3) Kâhin: itertools.product ile aynı sıra mı?")
    ayni = True
    for n in range(1, 11):
        a = list(range(1, n + 1))
        bizim = list(alt_kumeler_uret(a))
        kahin = [tuple(x for x, b in zip(a, bitler) if b)
                 for bitler in itertools.product([0, 1], repeat=n)]
        ayni = ayni and bizim == kahin
    print("   n = 1..10:", "evet" if ayni else "HAYIR")

    print("\n4) Permütasyon üreteci, a = [1, 2, 3]:")
    perms = list(permutasyonlar_uret([1, 2, 3]))
    print("  ", " ".join("".join(map(str, p)) for p in perms))
    ayni = all(list(permutasyonlar_uret(list(range(n))))
               == list(itertools.permutations(range(n)))
               for n in range(1, 8))
    print("   itertools.permutations ile aynı sıra (n = 1..7):",
          "evet" if ayni else "HAYIR")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: itertools.product([0, 1], repeat=n),
# itertools.combinations(a, r), itertools.permutations(a) — yalnızca kâhin.

/* H03_K05_vector_bool.cpp — AP-2 Hafta 3 · Kavram 5 (Dil Penceresi)
 * Amaç    : std::vector<bool> özel bir bit kabıdır: v[i] bir bool& değil,
 *           "vekil" (proxy) nesne döndürür — benzer sözdizimi, farklı anlam
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_K05_vector_bool.cpp -o H03_K05_vector_bool
 * Çalıştır: ./H03_K05_vector_bool
 */
#include <iostream>
#include <vector>

int main()
{
    std::vector<int> sayilar(3, 0);
    auto x = sayilar[0];        // int kopyası
    x = 7;                      // vektör değişmez
    std::cout << "vector<int>  : auto x = v[0]; x = 7;    -> x = " << x
              << ", v[0] = " << sayilar[0] << "\n";

    std::vector<bool> kullanildi(3, false);
    auto y = kullanildi[0];     // vekil nesne: v[0]'ın bitine bağlı
    y = true;                   // vektör DEĞİŞİR
    std::cout << "vector<bool> : auto y = v[0]; y = true; -> y = " << y
              << ", v[0] = " << kullanildi[0] << "\n";

    std::vector<char> isaret(3, 0);   // bayt başına bir öğe (deney kodu)
    auto z = isaret[0];
    z = 1;
    std::cout << "vector<char> : auto z = v[0]; z = 1;    -> z = "
              << static_cast<int>(z) << ", v[0] = "
              << static_cast<int>(isaret[0]) << "\n";
    return 0;
}

/* Kütüphane karşılığı: std::bitset<N> (sabit boyut), std::vector<char>
 * (bayt başına öğe). C'de int/char dizisi; Python'da bool listesi. */

/* H03_K02_next_permutation.cpp — AP-2 Hafta 3 · Kavram 2 (Dil Penceresi)
 * Amaç    : Kütüphane karşılığı std::next_permutation: sözlük sırasında
 *           sonraki permütasyon; tekrar eden elemanlarda her diziliş bir kez
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_K02_next_permutation.cpp -o H03_K02_next_permutation
 * Çalıştır: ./H03_K02_next_permutation
 * Not     : Yalnızca kâhin/karşılaştırma; derste algoritma elle yazılır.
 */
#include <algorithm>
#include <iostream>
#include <vector>

// p'nin (artan sıralı başlayarak) tüm permütasyonlarını yazar, sayar
static int hepsini_yaz(std::vector<int> p)
{
    int sayi = 0;
    do {
        for (int x : p) {
            std::cout << x;
        }
        std::cout << " ";
        sayi++;
    } while (std::next_permutation(p.begin(), p.end()));
    std::cout << "\n";
    return sayi;
}

int main()
{
    std::cout << "{1, 2, 3}: ";
    int s1 = hepsini_yaz({1, 2, 3});
    std::cout << "sayı = " << s1 << " (3! = 6)\n";
    std::cout << "{1, 1, 2}: ";
    int s2 = hepsini_yaz({1, 1, 2});
    std::cout << "sayı = " << s2 << " (3! / 2! = 3)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::next_permutation (bu dosya);
 * Python — itertools.permutations (tekrarlı elemanda yinelenenleri de
 * verir). */

/* H03_K04_acik_yigin.c — AP-2 Hafta 3 · Kavram 4 (H9'a köprü)
 * Amaç    : Örnek 3'ün özyinelemesini açık bir yığınla (dizi + tepe)
 *           yazmak: aynı 2^n dizi, aynı sıra; yığın en çok n + 1 kayıt
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_K04_acik_yigin.c -o H03_K04_acik_yigin
 * Çalıştır: ./H03_K04_acik_yigin
 */
#include <stdio.h>

#define MAKS_N 20

typedef struct {
    int k;       /* dizi[0..k-1] belirlendi */
    int adim;    /* 0: sol dala gir, 1: sağ dala gir, 2: bitti */
} Cerceve;

int main(void)
{
    const int n = 3;
    char dizi[MAKS_N + 1];
    Cerceve yigin[MAKS_N + 2];          /* çağrı yığınının elle karşılığı */
    int tepe = 0, en_cok = 0;
    yigin[tepe++] = (Cerceve){0, 0};    /* ilk "çağrı" */
    while (tepe > 0) {
        if (tepe > en_cok) {
            en_cok = tepe;
        }
        Cerceve *c = &yigin[tepe - 1];
        if (c->k == n) {                /* yaprak */
            dizi[n] = '\0';
            printf("%s\n", dizi);
            tepe--;                     /* "return" */
        } else if (c->adim < 2) {
            dizi[c->k] = (char)('0' + c->adim);
            c->adim++;
            yigin[tepe++] = (Cerceve){c->k + 1, 0};   /* "çağrı" */
        } else {
            tepe--;                     /* iki dal da bitti */
        }
    }
    printf("yığındaki en çok kayıt = %d (n + 1)\n", en_cok);
    return 0;
}

/* Kütüphane karşılığı: yok. H9'da yığın soyut veri tipi olarak işlenir;
 * C++'ta std::stack, Python'da list (append/pop) aynı işi görür. */

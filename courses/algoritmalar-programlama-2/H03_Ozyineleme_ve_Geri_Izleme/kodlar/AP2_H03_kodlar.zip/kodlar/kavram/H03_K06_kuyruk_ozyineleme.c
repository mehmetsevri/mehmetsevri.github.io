/* H03_K06_kuyruk_ozyineleme.c — AP-2 Hafta 3 · Kavram 6 (Kaputun Altında)
 * Amaç    : Aynı toplamın iki özyinelemeli biçimi: toplam(n) (toplama
 *           çağrıdan SONRA) ve toplam_kuyruk(n, birikim) (çağrı son iş:
 *           kuyruk özyineleme). -O0'da ikisi de her çağrıda çerçeve açar;
 *           GCC 13 -O2 ikisini de döngüye çevirdi (bu makinede ölçüldü).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H03_K06_kuyruk_ozyineleme.c -o H03_K06_kuyruk_ozyineleme
 * Çalıştır: ./H03_K06_kuyruk_ozyineleme [n=10000] [k]
 *           (k verilirse yalnız toplam_kuyruk çalışır)
 */
#include <stdio.h>
#include <stdlib.h>

static long long toplam(long long n)
{
    if (n == 0) {
        return 0;
    }
    return n + toplam(n - 1);           /* çağrıdan sonra toplama var */
}

static long long toplam_kuyruk(long long n, long long birikim)
{
    if (n == 0) {
        return birikim;
    }
    return toplam_kuyruk(n - 1, birikim + n);   /* çağrı son iş */
}

int main(int argc, char *argv[])
{
    long long n = 10000;
    if (argc > 1) {
        char *son;
        n = strtoll(argv[1], &son, 10);
        if (son == argv[1] || *son != '\0' || n < 0) {
            fprintf(stderr, "kullanım: %s [n >= 0] [k]\n", argv[0]);
            return 2;
        }
    }
    if (argc <= 2) {
        printf("toplam(%lld)           = %lld\n", n, toplam(n));
    }
    printf("toplam_kuyruk(%lld, 0) = %lld\n", n, toplam_kuyruk(n, 0));
    return 0;
}

/* Kütüphane karşılığı: yok. C standardı kuyruk çağrısı eniyilemesini
 * GÜVENCE ETMEZ; derleyiciye ve eniyileme düzeyine bağlıdır. */

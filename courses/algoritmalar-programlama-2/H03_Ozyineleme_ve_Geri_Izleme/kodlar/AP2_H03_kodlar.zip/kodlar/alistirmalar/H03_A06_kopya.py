"""H03_A06_kopya.py — AP-2 Hafta 3 · Alıştırma 3.14 (★★)
Amaç    : Diller arası okuma: append(yol) bir BAŞVURU ekler.
          C++ eşi H03_A06_kopya.cpp ile çıktıyı karşılaştırın.
Çalıştır: python3 H03_A06_kopya.py
"""


def main():
    sonuc = []
    yol = [1, 2]
    sonuc.append(yol)
    yol.pop()
    sonuc.append(yol)
    print(sonuc)


if __name__ == "__main__":
    main()

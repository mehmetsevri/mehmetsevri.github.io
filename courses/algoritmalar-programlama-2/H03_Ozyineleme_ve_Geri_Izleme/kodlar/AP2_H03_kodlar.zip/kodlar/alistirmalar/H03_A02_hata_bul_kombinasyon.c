/* H03_A02_hata_bul_kombinasyon.c — AP-2 Hafta 3 · Alıştırma 3.7 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: n = 5, k = 3 için C(5, 3) = 10 kombinasyon
 * beklenirken daha azı üretiliyor. Hatayı bulun (Örnek 7 ile karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_A02_hata_bul_kombinasyon.c -o H03_A02_hata_bul_kombinasyon
 * Çalıştır: ./H03_A02_hata_bul_kombinasyon
 */
#include <stdio.h>

#define N 5

static int yol[N];
static int uzunluk = 0;
static int sayi = 0;

static void kombinasyon(int bas, int k)
{
    if (uzunluk == k) {
        sayi++;
        printf("{%d, %d, %d} ", yol[0], yol[1], yol[2]);
        return;
    }
    for (int i = bas; i < N - (k - uzunluk); i++) {
        yol[uzunluk++] = i + 1;
        kombinasyon(i + 1, k);
        uzunluk--;
    }
}

int main(void)
{
    kombinasyon(0, 3);
    printf("\nüretilen = %d (beklenen 10)\n", sayi);
    return 0;
}

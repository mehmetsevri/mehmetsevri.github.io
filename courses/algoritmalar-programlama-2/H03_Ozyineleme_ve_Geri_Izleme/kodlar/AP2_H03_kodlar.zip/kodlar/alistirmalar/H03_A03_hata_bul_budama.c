/* H03_A03_hata_bul_budama.c — AP-2 Hafta 3 · Alıştırma 3.8 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: a = {5, 4, 3, 2}, hedef = 7 için iki çözüm
 * ({4, 3} ve {5, 2}) beklenirken program hiç çözüm bulmuyor. Budama
 * koşulundaki hatayı bulun ve düzeltin (Örnek 8 ile karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_A03_hata_bul_budama.c -o H03_A03_hata_bul_budama
 * Çalıştır: ./H03_A03_hata_bul_budama
 */
#include <stdio.h>

#define N 4

static const int a[N] = {5, 4, 3, 2};
static const int hedef = 7;
static int cozum_sayisi = 0;

static void budamali(int i, int toplam)
{
    if (toplam >= hedef) {
        return;                    /* "hedef aşıldı" budaması */
    }
    if (i == N) {
        if (toplam == hedef) {
            cozum_sayisi++;
        }
        return;
    }
    budamali(i + 1, toplam);
    budamali(i + 1, toplam + a[i]);
}

int main(void)
{
    budamali(0, 0);
    printf("çözüm = %d (beklenen 2)\n", cozum_sayisi);
    return 0;
}

"""H03_A05_uretec_okuma.py — AP-2 Hafta 3 · Alıştırma 3.13 (★★)
Amaç    : Diller arası okuma: üreteç (yield) kaldığı yerden sürer.
          Çalıştırmadan önce iki print satırının çıktısını tahmin edin.
Çalıştır: python3 H03_A05_uretec_okuma.py
"""


def ikili(n, on_ek=""):
    if n == 0:
        yield on_ek
        return
    yield from ikili(n - 1, on_ek + "0")
    yield from ikili(n - 1, on_ek + "1")


def main():
    g = ikili(3)
    print(next(g), next(g))
    print(list(g))


if __name__ == "__main__":
    main()

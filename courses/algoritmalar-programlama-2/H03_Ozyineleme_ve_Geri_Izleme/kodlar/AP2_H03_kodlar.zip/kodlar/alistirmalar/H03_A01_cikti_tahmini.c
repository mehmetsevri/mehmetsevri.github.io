/* H03_A01_cikti_tahmini.c — AP-2 Hafta 3 · Alıştırma 3.1 (★)
 * Amaç    : Çıktı tahmini ve çağrı sayısı: iki özyinelemeli çağrının
 *           arasında yazdırma (ağacı çizerek izleyin, sonra çalıştırın)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_A01_cikti_tahmini.c -o H03_A01_cikti_tahmini
 * Çalıştır: ./H03_A01_cikti_tahmini
 */
#include <stdio.h>

static int cagri_sayisi = 0;

static void g(int n)
{
    cagri_sayisi++;
    if (n <= 0) {
        return;
    }
    g(n - 1);
    printf("%d ", n);
    g(n - 2);
}

int main(void)
{
    g(3);
    printf("\nçağrı = %d\n", cagri_sayisi);
    return 0;
}

/* Kütüphane karşılığı: yok (izleme alıştırması). */

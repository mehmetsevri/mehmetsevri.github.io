/* H03_A06_kopya.cpp — AP-2 Hafta 3 · Alıştırma 3.14 (★★)
 * Amaç    : Diller arası okuma: push_back(yol) bir KOPYA ekler.
 *           Python eşi H03_A06_kopya.py ile çıktıyı karşılaştırın.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_A06_kopya.cpp -o H03_A06_kopya
 * Çalıştır: ./H03_A06_kopya
 */
#include <iostream>
#include <vector>

int main()
{
    std::vector<std::vector<int>> sonuc;
    std::vector<int> yol = {1, 2};
    sonuc.push_back(yol);
    yol.pop_back();
    sonuc.push_back(yol);
    for (const auto& k : sonuc) {
        std::cout << "[";
        for (std::size_t j = 0; j < k.size(); j++) {
            std::cout << (j > 0 ? ", " : "") << k[j];
        }
        std::cout << "] ";
    }
    std::cout << "\n";
    return 0;
}

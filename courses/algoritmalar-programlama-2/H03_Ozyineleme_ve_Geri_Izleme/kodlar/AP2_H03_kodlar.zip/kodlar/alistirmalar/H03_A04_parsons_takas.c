/* H03_A04_parsons_takas.c — AP-2 Hafta 3 · Alıştırma 3.9 (★★) — Parsons
 * Tamamlanacak; bu hâliyle derlenmez: aşağıdaki satırlar takasla
 * permütasyon üreten fonksiyonun KARIŞTIRILMIŞ satırlarıdır. Doğru sıraya
 * dizin (girintiyi de düzeltin); çıktı Örnek 6'daki takas sırası olmalı.
 */
        takas(&a[k], &a[i]);       /* geri al */
    if (k == n) {
static void permutasyon_takas(int k)
        permutasyon_takas(k + 1);  /* dene */
        return;
    }
{
    for (int i = k; i < n; i++) {
        perm_isle(a);
        takas(&a[k], &a[i]);       /* seç */
    }
}

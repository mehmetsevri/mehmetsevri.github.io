/* H03_10_n_vezir_hizli.c — AP-2 Hafta 3 · Örnek 10 (★★★)
 * Amaç    : N-vezirde güvenlik denetimi: önceki satırları tarama (O(r)) ve
 *           sütun/köşegen dizileriyle O(1) denetim; sayaçlar ve süreler
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_10_n_vezir_hizli.c zamanlayici.c -o H03_10_n_vezir_hizli
 * Çalıştır: ./H03_10_n_vezir_hizli [N_ust=10] [tekrar=1]   (süreler stderr)
 * Eşleri  : cpp/H03_10_n_vezir_hizli.cpp · python/H03_10_n_vezir_hizli.py
 * Çıktı   : üç dilde aynı (=) — süreler yalnızca stderr'e yazılır
 */
#include <stdio.h>
#include <stdlib.h>

#include "zamanlayici.h"

#define MAKS_N 14

static int n;
static int sutun[MAKS_N];               /* tarama sürümü: r. satırın sütunu */
static int sutun_dolu[MAKS_N];          /* c sütununda vezir var mı? */
static int kosegen1[2 * MAKS_N - 1];    /* r + c sabit olan köşegen */
static int kosegen2[2 * MAKS_N - 1];    /* r - c + n - 1 sabit olan köşegen */
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0;
static long long denetim_sayisi = 0;    /* karşılaştırma / dizi denetimi */

/* A) Tarama: (r, c) için önceki r vezirle tek tek karşılaştır — O(r) */
static int guvenli_mi_tarama(int r, int c)
{
    for (int i = 0; i < r; i++) {
        denetim_sayisi++;
        int fark = sutun[i] - c;
        if (fark == 0 || fark == r - i || fark == i - r) {
            return 0;
        }
    }
    return 1;
}

static void yerlestir_tarama(int r)
{
    dugum_sayisi++;
    if (r == n) {
        cozum_sayisi++;
        return;
    }
    for (int c = 0; c < n; c++) {
        if (guvenli_mi_tarama(r, c)) {
            sutun[r] = c;
            yerlestir_tarama(r + 1);
        }
    }
}

/* B) Dizilerle O(1) denetim: sütun ve iki köşegen dolu mu? */
static int bos_mu(int r, int c)
{
    denetim_sayisi++;
    return !sutun_dolu[c] && !kosegen1[r + c]
           && !kosegen2[r - c + n - 1];
}

static void isaretle(int r, int c, int deger)
{
    sutun_dolu[c] = deger;
    kosegen1[r + c] = deger;
    kosegen2[r - c + n - 1] = deger;
}

static void yerlestir_dizi(int r)
{
    dugum_sayisi++;
    if (r == n) {
        cozum_sayisi++;
        return;
    }
    for (int c = 0; c < n; c++) {
        if (bos_mu(r, c)) {
            isaretle(r, c, 1); /* seç */
            yerlestir_dizi(r + 1); /* dene */
            isaretle(r, c, 0); /* geri al */
        }
    }
}

static void sifirla(int boyut)
{
    n = boyut;
    cozum_sayisi = 0;
    dugum_sayisi = 0;
    denetim_sayisi = 0;
    for (int i = 0; i < 2 * MAKS_N - 1; i++) {
        kosegen1[i] = 0;
        kosegen2[i] = 0;
        if (i < MAKS_N) {
            sutun_dolu[i] = 0;
        }
    }
}

/* zamanlayici için görevler (veri: int boyut) */
static void tarama_gorevi(void *veri)
{
    sifirla(*(int *)veri);
    yerlestir_tarama(0);
}

static void dizi_gorevi(void *veri)
{
    sifirla(*(int *)veri);
    yerlestir_dizi(0);
}

/* "123" gibi bir argümanı [alt, ust] aralığında tamsayıya çevirir */
static int arguman_oku(const char *s, int alt, int ust, int *sonuc)
{
    char *son;
    long deger = strtol(s, &son, 10);
    if (son == s || *son != '\0' || deger < alt || deger > ust) {
        return 0;
    }
    *sonuc = (int)deger;
    return 1;
}

int main(int argc, char *argv[])
{
    int n_ust = 10, tekrar = 1;
    if ((argc > 1 && !arguman_oku(argv[1], 4, MAKS_N, &n_ust))
        || (argc > 2 && !arguman_oku(argv[2], 1, 101, &tekrar))) {
        fprintf(stderr, "kullanım: %s [N_ust 4..%d] [tekrar 1..101]\n",
                argv[0], MAKS_N);
        return 2;
    }
    printf("  N   çözüm    düğüm  tarama karşılaştırma  dizi denetimi\n");
    for (int boyut = 4; boyut <= n_ust; boyut++) {
        /* her ölçüm sayaçları sıfırlar; son çalıştırmanın sayaçları kalır */
        double t1 = olc_ortanca(tarama_gorevi, &boyut, tekrar);
        long long c1 = cozum_sayisi, d1 = dugum_sayisi;
        long long tarama = denetim_sayisi;
        double t2 = olc_ortanca(dizi_gorevi, &boyut, tekrar);
        printf("%3d %7lld %8lld %21lld %14lld%s\n", boyut, cozum_sayisi,
               dugum_sayisi, tarama, denetim_sayisi,
               (c1 == cozum_sayisi && d1 == dugum_sayisi) ? "" : "  FARK");
        fprintf(stderr, "  N = %2d: tarama %9.3f ms   dizi %9.3f ms   "
                "oran %.2f\n", boyut, t1 * 1e3, t2 * 1e3, t1 / t2);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). C++'ta std::vector<bool>
 * ya da std::bitset ile aynı diziler bit düzeyinde tutulabilir. */

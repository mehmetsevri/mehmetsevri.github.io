/* H03_13_sudoku.c — AP-2 Hafta 3 · Örnek 13 (★★★, meydan okuma)
 * Amaç    : Sudoku çözücüsü: kısıt yayılımı olmadan geri izleme. İlk boş
 *           kareye uygun her rakamı dene; çıkmazda geri al; düğümler sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_13_sudoku.c zamanlayici.c -o H03_13_sudoku
 * Çalıştır: ./H03_13_sudoku < ../girdiler/H03_13_sudoku.txt   (süre stderr)
 * Eşleri  : cpp/H03_13_sudoku.cpp · python/H03_13_sudoku.py
 * Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
 */
#include <stdio.h>
#include <string.h>

#include "zamanlayici.h"

static int tablo[9][9];             /* 0 = boş kare */
static int ipucu[9][9];             /* başlangıçtaki rakamlar */
static int satir_var[9][10];        /* satir_var[r][d]: r. satırda d var mı? */
static int sutun_var[9][10];
static int kutu_var[9][10];         /* 3x3 kutular: 0..8 */
static long long dugum_sayisi = 0;

static int kutu_no(int r, int c)
{
    return (r / 3) * 3 + c / 3;
}

static int uygun_mu(int r, int c, int d)
{
    return !satir_var[r][d] && !sutun_var[c][d]
           && !kutu_var[kutu_no(r, c)][d];
}

/* var = 1: d rakamını (r, c)'ye koy; var = 0: kaldır */
static void koy(int r, int c, int d, int var)
{
    tablo[r][c] = var ? d : 0;
    satir_var[r][d] = var;
    sutun_var[c][d] = var;
    kutu_var[kutu_no(r, c)][d] = var;
}

/* k = 0..80 (satır öncelikli kare no); k'dan sonraki ilk boş kareyi doldur */
static int coz(int k)
{
    dugum_sayisi++;
    while (k < 81 && tablo[k / 9][k % 9] != 0) {
        k++;                        /* dolu kareleri atla */
    }
    if (k == 81) {
        return 1;                   /* boş kare kalmadı: çözüldü */
    }
    int r = k / 9, c = k % 9;
    for (int d = 1; d <= 9; d++) {
        if (uygun_mu(r, c, d)) {
            koy(r, c, d, 1);        /* seç */
            if (coz(k + 1)) {       /* dene */
                return 1;           /* tek çözüm yeter: dur */
            }
            koy(r, c, d, 0);        /* geri al */
        }
    }
    return 0;                       /* hiçbir rakam olmadı: geri dön */
}

/* 9 satır, her biri 9 karakter: '1'..'9' ya da '.'/'0' (boş) */
static int bulmaca_oku(void)
{
    char satir[64];
    for (int r = 0; r < 9; r++) {
        if (fgets(satir, sizeof satir, stdin) == NULL) {
            return 0;
        }
        satir[strcspn(satir, "\r\n")] = '\0';
        if (strlen(satir) != 9) {
            return 0;
        }
        for (int c = 0; c < 9; c++) {
            char k = satir[c];
            int d = (k >= '1' && k <= '9') ? k - '0' : 0;
            if (d == 0 && k != '.' && k != '0') {
                return 0;
            }
            if (d != 0) {
                if (!uygun_mu(r, c, d)) {
                    return 0;       /* ipuçları çelişiyor */
                }
                koy(r, c, d, 1);
            }
            ipucu[r][c] = d;
        }
    }
    return 1;
}

static void tablo_yaz(void)
{
    for (int r = 0; r < 9; r++) {
        if (r > 0 && r % 3 == 0) {
            printf("------+-------+------\n");
        }
        for (int c = 0; c < 9; c++) {
            if (c > 0) {
                printf(c % 3 == 0 ? " | " : " ");
            }
            printf("%c", tablo[r][c] ? '0' + tablo[r][c] : '.');
        }
        printf("\n");
    }
}

/* Her satır, sütun ve kutuda 1..9 tam bir kez mi; ipuçları yerinde mi? */
static int dogrula(void)
{
    for (int i = 0; i < 9; i++) {
        int s[10] = {0}, t[10] = {0}, k[10] = {0};
        for (int j = 0; j < 9; j++) {
            s[tablo[i][j]]++;
            t[tablo[j][i]]++;
            k[tablo[(i / 3) * 3 + j / 3][(i % 3) * 3 + j % 3]]++;
        }
        for (int d = 1; d <= 9; d++) {
            if (s[d] != 1 || t[d] != 1 || k[d] != 1) {
                return 0;
            }
        }
    }
    for (int r = 0; r < 9; r++) {
        for (int c = 0; c < 9; c++) {
            if (ipucu[r][c] != 0 && ipucu[r][c] != tablo[r][c]) {
                return 0;
            }
        }
    }
    return 1;
}

int main(void)
{
    if (!bulmaca_oku()) {
        fprintf(stderr, "Hatalı Sudoku girdisi\n");
        return 1;
    }
    int ipucu_sayisi = 0;
    for (int r = 0; r < 9; r++) {
        for (int c = 0; c < 9; c++) {
            ipucu_sayisi += ipucu[r][c] != 0;
        }
    }
    printf("Bulmaca (%d ipucu):\n", ipucu_sayisi);
    tablo_yaz();
    double t0 = zaman_sn();
    int cozuldu = coz(0);
    double sure = zaman_sn() - t0;
    if (!cozuldu) {
        printf("\nÇözüm yok (ziyaret edilen düğüm = %lld)\n", dugum_sayisi);
        return 0;
    }
    printf("\nÇözüm (ziyaret edilen düğüm = %lld):\n", dugum_sayisi);
    tablo_yaz();
    printf("doğrulama: %s\n", dogrula() ? "geçerli" : "GEÇERSİZ");
    fprintf(stderr, "çözme süresi: %.3f ms\n", sure * 1e3);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Gerçek çözücüler kısıt
 * yayılımı ve "en az seçenekli kare önce" sezgisiyle düğüm sayısını azaltır. */

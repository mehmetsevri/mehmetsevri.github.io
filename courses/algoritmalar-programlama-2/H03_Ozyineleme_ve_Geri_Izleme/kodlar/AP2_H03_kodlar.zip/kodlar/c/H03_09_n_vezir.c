/* H03_09_n_vezir.c — AP-2 Hafta 3 · Örnek 9 (★★★)
 * Amaç    : N-vezir: satır satır geri izleme (her satıra bir vezir; güvenli
 *           sütunları dene); N = 1…10 için çözüm ve ziyaret edilen düğüm sayısı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_09_n_vezir.c -o H03_09_n_vezir
 * Çalıştır: ./H03_09_n_vezir
 * Eşleri  : cpp/H03_09_n_vezir.cpp · python/H03_09_n_vezir.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_N 12

static int n;
static int sutun[MAKS_N];          /* sutun[r]: r. satırdaki vezirin sütunu */
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0; /* ziyaret edilen düğüm (çağrı) */
static int yazilacak = 0;          /* ilk kaç çözüm tahta olarak yazılsın */

/* (r, c) karesi, 0..r-1 satırlarındaki vezirlerle çakışmıyor mu? */
static int guvenli_mi(int r, int c)
{
    for (int i = 0; i < r; i++) {
        int fark = sutun[i] - c;
        if (fark == 0 || fark == r - i || fark == i - r) {
            return 0;              /* aynı sütun ya da aynı köşegen */
        }
    }
    return 1;
}

static void tahta_yaz(void)
{
    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            printf(c > 0 ? " %c" : "%c", sutun[r] == c ? 'V' : '.');
        }
        printf("\n");
    }
}

/* 0..r-1 satırlarına vezir yerleşti; r. satır için sütun ara */
static void yerlestir(int r)
{
    dugum_sayisi++;
    if (r == n) {                  /* n vezir yerleşti: çözüm */
        cozum_sayisi++;
        if (cozum_sayisi <= yazilacak) {
            printf("çözüm %lld: sütunlar =", cozum_sayisi);
            for (int i = 0; i < n; i++) {
                printf(" %d", sutun[i]);
            }
            printf("\n");
            tahta_yaz();
        }
        return;
    }
    for (int c = 0; c < n; c++) {
        if (guvenli_mi(r, c)) {
            sutun[r] = c;          /* seç */
            yerlestir(r + 1);      /* dene */
        }                          /* geri al: sutun[r] yeniden yazılır */
    }
}

static void coz(int boyut, int yaz)
{
    n = boyut;
    yazilacak = yaz;
    cozum_sayisi = 0;
    dugum_sayisi = 0;
    yerlestir(0);
}

int main(void)
{
    const long long bilinen[] = {0, 1, 0, 0, 2, 10, 4, 40, 92, 352, 724};

    printf("1) N = 4: tüm çözümler\n");
    coz(4, 2);
    printf("çözüm = %lld   ziyaret edilen düğüm = %lld\n",
           cozum_sayisi, dugum_sayisi);

    printf("\n2) N = 8: ilk çözüm (sözlük sırasında)\n");
    coz(8, 1);
    printf("çözüm = %lld   ziyaret edilen düğüm = %lld\n",
           cozum_sayisi, dugum_sayisi);

    printf("\n3) N = 1..10\n");
    printf("  N   çözüm   bilinen    düğüm\n");
    for (int boyut = 1; boyut <= 10; boyut++) {
        coz(boyut, 0);
        printf("%3d %7lld %9lld %8lld%s\n", boyut, cozum_sayisi,
               bilinen[boyut], dugum_sayisi,
               cozum_sayisi == bilinen[boyut] ? "" : "  HATA");
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: N ≤ 8 için tüm
 * permütasyonları deneyen kaba kuvvet (Python'da itertools.permutations). */

/* H03_12_ozyineleme_siniri.c — AP-2 Hafta 3 · Örnek 12 (★★)
 * Amaç    : Aynı özyinelemeli toplam(n) C'de 10 000 derinlikte sorunsuz;
 *           Python'da 1000 civarında RecursionError. C'nin sınırı yığındır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H03_12_ozyineleme_siniri.c -o H03_12_ozyineleme_siniri
 *           (-O0 bilerek: -O2'de GCC bu özyinelemeyi döngüye çevirir)
 * Çalıştır: ./H03_12_ozyineleme_siniri [n]   (n verilirse yalnız toplam(n);
 *           ör. n = 1000000 Linux'ta 8 MB yığını aşar: Segmentation fault)
 * Eşleri  : cpp/H03_12_ozyineleme_siniri.cpp ·
 *           python/H03_12_ozyineleme_siniri.py
 * Çıktı   : Δ — dile özgü (C/C++ derinlikleri aynı, Python farklı)
 */
#include <stdio.h>
#include <stdlib.h>

/* 1 + 2 + ... + n; her çağrı yığında bir çerçeve açar */
static long long toplam(long long n)
{
    if (n == 0) {
        return 0;
    }
    return n + toplam(n - 1);
}

int main(int argc, char *argv[])
{
    if (argc > 1) {                     /* isteğe bağlı: tek derinlik */
        char *son;
        long long n = strtoll(argv[1], &son, 10);
        if (son == argv[1] || *son != '\0' || n < 0) {
            fprintf(stderr, "kullanım: %s [n >= 0]\n", argv[0]);
            return 2;
        }
        printf("toplam(%lld) = %lld\n", n, toplam(n));
        return 0;
    }
    const long long derinlikler[] = {900, 1000, 10000};
    printf("Özyineleme sınırı deneyi — C\n");
    printf("toplam(n) = n + toplam(n - 1), toplam(0) = 0\n");
    printf("dilin koyduğu derinlik sınırı: yok\n");
    for (int k = 0; k < 3; k++) {
        long long n = derinlikler[k];
        printf("derinlik %6lld: toplam = %lld\n", n, toplam(n));
    }
    printf("C'de sınır iş parçacığının yığın boyutudur (Linux'ta tipik\n"
           "olarak 8 MB; ulimit -s). Aşılırsa dil uyarmaz; Linux'ta süreç\n"
           "genellikle SIGSEGV (Segmentation fault) ile sonlanır.\n");
    return 0;
}

/* Kütüphane karşılığı: yok. Derinlik sınırı: Python'da
 * sys.getrecursionlimit()/sys.setrecursionlimit(); C/C++'ta yığın boyutu
 * işletim sistemi (ulimit -s) ve bağlayıcı (ör. MinGW -Wl,--stack) ayarıdır. */

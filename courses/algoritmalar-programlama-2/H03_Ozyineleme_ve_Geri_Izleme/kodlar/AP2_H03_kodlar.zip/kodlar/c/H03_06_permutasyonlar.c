/* H03_06_permutasyonlar.c — AP-2 Hafta 3 · Örnek 6 (★★)
 * Amaç    : Tüm permütasyonlar — kullanildi dizisiyle, sözlük sırasında
 *           (seç → dene → geri al); takasla üretimle sıra karşılaştırması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_06_permutasyonlar.c -o H03_06_permutasyonlar
 * Çalıştır: ./H03_06_permutasyonlar
 * Eşleri  : cpp/H03_06_permutasyonlar.cpp · python/H03_06_permutasyonlar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_N 10

static int a[MAKS_N];              /* sıralı elemanlar: 1, 2, ..., n */
static int n;
static int yol[MAKS_N];            /* kurulmakta olan permütasyon */
static int kullanildi[MAKS_N];     /* a[i] yol'da mı? */
static int onceki[MAKS_N];         /* bir önceki permütasyon */
static long long cagri_sayisi = 0;
static long long perm_sayisi = 0;
static int sozluk_sirali = 1;      /* her permütasyon öncekinden büyük mü? */
static int yazdir_mi = 1;

/* Bir permütasyon tamamlandı: say, sırayı denetle, (istenirse) yaz */
static void perm_isle(const int *p)
{
    perm_sayisi++;
    if (perm_sayisi > 1) {
        int k = 0;
        while (k < n && p[k] == onceki[k]) {
            k++;                   /* ilk farklı konum */
        }
        if (k == n || p[k] < onceki[k]) {
            sozluk_sirali = 0;
        }
    }
    for (int k = 0; k < n; k++) {
        onceki[k] = p[k];
    }
    if (yazdir_mi) {
        for (int k = 0; k < n; k++) {
            printf("%d", p[k]);
        }
        printf(perm_sayisi % 6 == 0 ? "\n" : " ");
    }
}

/* yol[0..k-1] dolu; k. konuma kullanılmamış her elemanı dene */
static void permutasyon(int k)
{
    cagri_sayisi++;
    if (k == n) {          /* yaprak */
        perm_isle(yol);
        return;
    }
    for (int i = 0; i < n; i++) {
        if (!kullanildi[i]) {
            kullanildi[i] = 1; /* seç */
            yol[k] = a[i];
            permutasyon(k + 1); /* dene */
            kullanildi[i] = 0; /* geri al */
        }
    }
}

static void takas(int *x, int *y)
{
    int gecici = *x;
    *x = *y;
    *y = gecici;
}

/* Takasla üretim: a[k..n-1] içinden her elemanı k. konuma getir */
static void permutasyon_takas(int k)
{
    cagri_sayisi++;
    if (k == n) {
        perm_isle(a);
        return;
    }
    for (int i = k; i < n; i++) {
        takas(&a[k], &a[i]);       /* seç */
        permutasyon_takas(k + 1);  /* dene */
        takas(&a[k], &a[i]);       /* geri al */
    }
}

static void baslat(int boyut)
{
    n = boyut;
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
        kullanildi[i] = 0;
    }
    cagri_sayisi = 0;
    perm_sayisi = 0;
    sozluk_sirali = 1;
}

int main(void)
{
    printf("1) n = 3, kullanildi dizisiyle:\n");
    baslat(3);
    permutasyon(0);
    printf("permütasyon = %lld   çağrı = %lld   sözlük sırasında: %s\n",
           perm_sayisi, cagri_sayisi, sozluk_sirali ? "evet" : "hayır");

    printf("\n2) n = 3, takasla:\n");
    baslat(3);
    permutasyon_takas(0);
    printf("permütasyon = %lld   çağrı = %lld   sözlük sırasında: %s\n",
           perm_sayisi, cagri_sayisi, sozluk_sirali ? "evet" : "hayır");

    printf("\n3) kullanildi dizisiyle sayım: çağrı / n! -> e = 2.71828...\n");
    printf("  n      perm     çağrı  çağrı/n!  perm = n!  sözlük\n");
    yazdir_mi = 0;
    long long faktoriyel = 1;
    for (int boyut = 1; boyut <= 8; boyut++) {
        faktoriyel *= boyut;
        baslat(boyut);
        permutasyon(0);
        printf("%3d %9lld %9lld %9.4f  %-9s  %s\n", boyut, perm_sayisi,
               cagri_sayisi, (double)cagri_sayisi / (double)faktoriyel,
               perm_sayisi == faktoriyel ? "evet" : "HAYIR",
               sozluk_sirali ? "evet" : "hayır");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::next_permutation (sözlük
 * sırasında sonraki); Python — itertools.permutations (yalnızca kâhin). */

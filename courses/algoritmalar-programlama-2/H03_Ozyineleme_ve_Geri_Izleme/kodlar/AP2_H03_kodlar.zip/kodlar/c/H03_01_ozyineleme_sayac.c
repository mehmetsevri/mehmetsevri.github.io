/* H03_01_ozyineleme_sayac.c — AP-2 Hafta 3 · Örnek 1 (★)
 * Amaç    : Özyinelemeli toplam ve Fibonacci'de çağrı sayacı ve derinlik;
 *           fib(5) çağrı ağacının girintili çizimi; çağrı = 2·F(n+1) − 1
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_01_ozyineleme_sayac.c -o H03_01_ozyineleme_sayac
 * Çalıştır: ./H03_01_ozyineleme_sayac
 * Eşleri  : cpp/H03_01_ozyineleme_sayac.cpp · python/H03_01_ozyineleme_sayac.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

static long long cagri_sayisi = 0;   /* toplam çağrı sayısı */
static int en_buyuk_derinlik = 0;    /* aynı anda açık en çok çerçeve */
static int goruldu[64];              /* fib(k) daha önce çağrıldı mı? */

static void sayaclari_sifirla(void)
{
    cagri_sayisi = 0;
    en_buyuk_derinlik = 0;
}

/* 1 + 2 + ... + n; d: bu çağrının derinliği (kök = 1) */
static long long toplam(int n, int d)
{
    cagri_sayisi++;
    if (d > en_buyuk_derinlik) {
        en_buyuk_derinlik = d;
    }
    if (n == 0) {
        return 0;                       /* temel durum */
    }
    return n + toplam(n - 1, d + 1);    /* özyinelemeli adım */
}

/* n. Fibonacci sayısı: F(0) = 0, F(1) = 1 */
static long long fib(int n, int d)
{
    cagri_sayisi++;
    if (d > en_buyuk_derinlik) {
        en_buyuk_derinlik = d;
    }
    if (n < 2) {
        return n;                       /* temel durum */
    }
    return fib(n - 1, d + 1) + fib(n - 2, d + 1);
}

/* fib ile aynı çağrılar; her çağrıyı girintiyle yazar (ağaç çizimi) */
static long long fib_agac(int n, int d)
{
    cagri_sayisi++;
    if (d > en_buyuk_derinlik) {
        en_buyuk_derinlik = d;
    }
    for (int i = 1; i < d; i++) {
        printf("  ");                   /* girinti = derinlik */
    }
    printf("fib(%d)%s\n", n, goruldu[n] ? "  (tekrar)" : "");
    goruldu[n] = 1;
    if (n < 2) {
        return n;
    }
    return fib_agac(n - 1, d + 1) + fib_agac(n - 2, d + 1);
}

/* Kâhin: döngüyle F(n) */
static long long fib_dongu(int n)
{
    long long onceki = 0, simdiki = 1;
    if (n == 0) {
        return 0;
    }
    for (int i = 2; i <= n; i++) {
        long long sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

int main(void)
{
    const int toplam_n[] = {5, 100};
    const int fib_n[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25};

    printf("1) toplam(n) = 1 + 2 + ... + n\n");
    for (int k = 0; k < 2; k++) {
        sayaclari_sifirla();
        long long t = toplam(toplam_n[k], 1);
        printf("toplam(%d) = %lld   çağrı = %lld   en büyük derinlik = %d\n",
               toplam_n[k], t, cagri_sayisi, en_buyuk_derinlik);
    }

    printf("\n2) fib(5) çağrı ağacı (ön sıra; girinti = derinlik)\n");
    sayaclari_sifirla();
    long long f5 = fib_agac(5, 1);
    printf("fib(5) = %lld   çağrı = %lld   en büyük derinlik = %d\n",
           f5, cagri_sayisi, en_buyuk_derinlik);
    int farkli = 0;
    for (int k = 0; k <= 5; k++) {
        farkli += goruldu[k];
    }
    printf("farklı alt problem = %d   tekrarlanan çağrı = %lld\n",
           farkli, cagri_sayisi - farkli);

    printf("\n3) fib(n): çağrı sayısı = 2*F(n+1) - 1 mi?\n");
    printf("  n     fib(n)     çağrı  2*F(n+1)-1  derinlik  eşit\n");
    for (int k = 0; k < 14; k++) {
        int n = fib_n[k];
        sayaclari_sifirla();
        long long f = fib(n, 1);
        long long beklenen = 2 * fib_dongu(n + 1) - 1;
        printf("%3d %10lld %9lld %11lld %9d  %s\n", n, f, cagri_sayisi,
               beklenen, en_buyuk_derinlik,
               cagri_sayisi == beklenen ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: yok — özyineleme dilin kendisidir. (Python'da
 * functools.lru_cache tekrarlanan çağrıları önler; H13'te memoization.) */

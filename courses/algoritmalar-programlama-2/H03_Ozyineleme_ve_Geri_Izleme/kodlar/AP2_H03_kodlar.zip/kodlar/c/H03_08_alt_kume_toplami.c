/* H03_08_alt_kume_toplami.c — AP-2 Hafta 3 · Örnek 8 (★★)
 * Amaç    : Alt küme toplamı: kaba kuvvet (ağacın tamamı) ve budamalı geri
 *           izleme ("toplam aşıldı"; sıralı girdiyle ek budama); düğüm sayısı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_08_alt_kume_toplami.c ortak_rastgele.c \
 *           -o H03_08_alt_kume_toplami
 * Çalıştır: ./H03_08_alt_kume_toplami
 * Eşleri  : cpp/H03_08_alt_kume_toplami.cpp · python/H03_08_alt_kume_toplami.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#include "ortak_rastgele.h"

#define MAKS_N 30

static int a[MAKS_N];              /* pozitif tamsayılar */
static int n;
static long long hedef;
static int b[MAKS_N];              /* a'nın artan sıralı kopyası */
static long long kalan[MAKS_N + 1]; /* kalan[i] = b[i] + ... + b[n-1] */
static int yol[MAKS_N];
static int uzunluk = 0;
static long long ziyaret = 0;      /* ziyaret edilen düğüm (çağrı) */
static long long budanan = 0;      /* budanan düğüm */
static long long cozum_sayisi = 0;
static int yazdir_mi = 0;

static void cozum_isle(void)
{
    cozum_sayisi++;
    if (yazdir_mi) {
        printf("    {");
        for (int j = 0; j < uzunluk; j++) {
            printf(j > 0 ? ", %d" : "%d", yol[j]);
        }
        printf("}\n");
    }
}

/* 1) Kaba kuvvet: ağacın tamamı; yalnızca yaprakta denetim */
static void kaba_kuvvet(int i, long long toplam)
{
    ziyaret++;
    if (i == n) {
        if (toplam == hedef) {
            cozum_isle();
        }
        return;
    }
    kaba_kuvvet(i + 1, toplam);             /* a[i] alınmaz */
    yol[uzunluk++] = a[i];                  /* seç */
    kaba_kuvvet(i + 1, toplam + a[i]);      /* a[i] alınır */
    uzunluk--;                              /* geri al */
}

/* 2) Geri izleme: toplam hedefi aştıysa dur (her a[i] > 0 olduğu için) */
static void budamali(int i, long long toplam)
{
    ziyaret++;
    if (toplam > hedef) {
        budanan++;                          /* torunların hepsi de aşar */
        return;
    }
    if (i == n) {
        if (toplam == hedef) {
            cozum_isle();
        }
        return;
    }
    budamali(i + 1, toplam);
    yol[uzunluk++] = a[i];
    budamali(i + 1, toplam + a[i]);
    uzunluk--;
}

/* 3) Sıralı girdi (b artan) ile iki sınır daha */
static void sirali_budamali(int i, long long toplam)
{
    ziyaret++;
    if (toplam == hedef) {                  /* kalanlar eklenemez: çözüm */
        cozum_sayisi++;
        return;
    }
    if (i == n) {
        return;
    }
    if (toplam + b[i] > hedef || toplam + kalan[i] < hedef) {
        budanan++;      /* en küçük kalan sığmıyor ya da hepsi yetmiyor */
        return;
    }
    sirali_budamali(i + 1, toplam);
    sirali_budamali(i + 1, toplam + b[i]);
}

/* b = a'nın artan sıralı kopyası (araya ekleme) ve sonek toplamları */
static void siraliyi_hazirla(void)
{
    for (int i = 0; i < n; i++) {
        int x = a[i];
        int j = i - 1;
        while (j >= 0 && b[j] > x) {
            b[j + 1] = b[j];
            j--;
        }
        b[j + 1] = x;
    }
    kalan[n] = 0;
    for (int i = n - 1; i >= 0; i--) {
        kalan[i] = kalan[i + 1] + b[i];
    }
}

static void yontem_calistir(int yontem)
{
    ziyaret = 0;
    budanan = 0;
    cozum_sayisi = 0;
    uzunluk = 0;
    if (yontem == 1) {
        kaba_kuvvet(0, 0);
    } else if (yontem == 2) {
        budamali(0, 0);
    } else {
        sirali_budamali(0, 0);
    }
}

static void tablo(void)
{
    const char *ad[] = {"", "kaba kuvvet    ", "toplam aşıldı  ",
                        "sıralı + sınır "};
    siraliyi_hazirla();
    for (int y = 1; y <= 3; y++) {
        yontem_calistir(y);
        printf("  %s %8lld %10lld %10lld\n", ad[y], cozum_sayisi, ziyaret,
               budanan);
    }
}

int main(void)
{
    const int kucuk[] = {5, 4, 3, 2};
    n = 4;
    hedef = 7;
    for (int i = 0; i < n; i++) {
        a[i] = kucuk[i];
    }
    printf("1) a = {5, 4, 3, 2}, hedef = 7; çözümler (kaba kuvvet):\n");
    yazdir_mi = 1;
    yontem_calistir(1);
    yazdir_mi = 0;
    printf("  yöntem             çözüm    ziyaret    budanan\n");
    tablo();

    n = 18;
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 1, 40);
    long long toplam_a = 0;
    printf("\n2) n = %d, a (tohum 42, 1..40) =", n);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
        toplam_a += a[i];
    }
    printf("\n   toplam = %lld; tam ağaç 2^(n+1) - 1 = %lld düğüm\n",
           toplam_a, (1LL << (n + 1)) - 1);
    const long long hedefler[] = {50, toplam_a / 2};
    for (int h = 0; h < 2; h++) {
        hedef = hedefler[h];
        printf("hedef = %lld\n", hedef);
        printf("  yöntem             çözüm    ziyaret    budanan\n");
        tablo();
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: bit maskesiyle
 * 0 … 2^n − 1 tarama (Örnek 5); H13'te dinamik programlama. */

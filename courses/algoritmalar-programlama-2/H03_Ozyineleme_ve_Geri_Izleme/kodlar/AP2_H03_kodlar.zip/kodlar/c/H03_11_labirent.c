/* H03_11_labirent.c — AP-2 Hafta 3 · Örnek 11 (★★)
 * Amaç    : Labirentte yol bulma: ızgarada geri izleme (sağ, aşağı, sol,
 *           yukarı); yol '*', denenip geri dönülen hücre 'x' ile işaretlenir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_11_labirent.c -o H03_11_labirent
 * Çalıştır: ./H03_11_labirent < ../girdiler/H03_11_labirent.txt
 * Eşleri  : cpp/H03_11_labirent.cpp · python/H03_11_labirent.py
 * Çıktı   : üç dilde aynı (=); hatalı girdide çıkış kodu 1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_SATIR 40
#define MAKS_SUTUN 80

static char izgara[MAKS_SATIR][MAKS_SUTUN + 2];  /* + '\n' ve '\0' */
static int satir_sayisi, sutun_sayisi;
static long long ziyaret = 0;          /* yol_bul çağrısı */
static long long geri_donulen = 0;     /* çıkmaz olduğu anlaşılan hücre */
static const int DR[4] = {0, 1, 0, -1};    /* sağ, aşağı, sol, yukarı */
static const int DC[4] = {1, 0, -1, 0};

/* (r, c) ızgarada ve henüz denenmemiş bir boş hücre ya da çıkış mı? */
static int gecilebilir(int r, int c)
{
    return r >= 0 && r < satir_sayisi && c >= 0 && c < sutun_sayisi
           && (izgara[r][c] == '.' || izgara[r][c] == 'E');
}

/* (r, c)'den çıkışa yol ara; bulunursa 1 döner */
static int yol_bul(int r, int c)
{
    ziyaret++;
    if (izgara[r][c] == 'E') {
        return 1;                       /* çıkışa ulaşıldı */
    }
    if (izgara[r][c] != 'S') {
        izgara[r][c] = '*';             /* seç: hücre yola eklenir */
    }
    for (int d = 0; d < 4; d++) {
        int yr = r + DR[d], yc = c + DC[d];
        if (gecilebilir(yr, yc) && yol_bul(yr, yc)) {
            return 1;                   /* yol bulundu: '*'lar kalır */
        }
    }
    if (izgara[r][c] != 'S') {
        izgara[r][c] = 'x';             /* geri al: buradan çıkış yok */
    }
    geri_donulen++;
    return 0;
}

/* İlk satır "satır sütun", ardından ızgara; tam bir S ve bir E olmalı */
static int labirent_oku(int *bas_r, int *bas_c)
{
    char satir[64];
    char *son;
    if (fgets(satir, sizeof satir, stdin) == NULL) {
        return 0;
    }
    long r = strtol(satir, &son, 10);
    char *p = son;
    long c = strtol(p, &son, 10);
    if (son == p || r < 1 || r > MAKS_SATIR || c < 1 || c > MAKS_SUTUN) {
        return 0;
    }
    satir_sayisi = (int)r;
    sutun_sayisi = (int)c;
    int s_sayisi = 0, e_sayisi = 0;
    for (int i = 0; i < satir_sayisi; i++) {
        if (fgets(izgara[i], sizeof izgara[i], stdin) == NULL) {
            return 0;
        }
        izgara[i][strcspn(izgara[i], "\r\n")] = '\0';
        if ((int)strlen(izgara[i]) != sutun_sayisi) {
            return 0;
        }
        for (int j = 0; j < sutun_sayisi; j++) {
            char k = izgara[i][j];
            if (k == 'S') {
                s_sayisi++;
                *bas_r = i;
                *bas_c = j;
            } else if (k == 'E') {
                e_sayisi++;
            } else if (k != '#' && k != '.') {
                return 0;
            }
        }
    }
    return s_sayisi == 1 && e_sayisi == 1;
}

int main(void)
{
    int bas_r = 0, bas_c = 0;
    if (!labirent_oku(&bas_r, &bas_c)) {
        fprintf(stderr, "Hatalı labirent girdisi\n");
        return 1;
    }
    printf("Labirent %d x %d, giriş S = (%d, %d)\n", satir_sayisi,
           sutun_sayisi, bas_r, bas_c);
    printf("Yön sırası: sağ, aşağı, sol, yukarı\n");
    int bulundu = yol_bul(bas_r, bas_c);
    int yol_hucre = 0;
    for (int i = 0; i < satir_sayisi; i++) {
        for (int j = 0; j < sutun_sayisi; j++) {
            yol_hucre += izgara[i][j] == '*';
        }
    }
    if (bulundu) {
        printf("Sonuç: yol bulundu, uzunluk = %d adım\n", yol_hucre + 1);
    } else {
        printf("Sonuç: yol yok\n");
    }
    printf("ziyaret edilen hücre = %lld   geri dönülen hücre = %lld\n",
           ziyaret, geri_donulen);
    for (int i = 0; i < satir_sayisi; i++) {
        printf("%s\n", izgara[i]);
    }
    printf("İşaretler: * yol, x denenip geri dönülen hücre\n");
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). En kısa yol için H11'deki
 * genişlik öncelikli arama (BFS) kullanılır; bu yol en kısa olmayabilir. */

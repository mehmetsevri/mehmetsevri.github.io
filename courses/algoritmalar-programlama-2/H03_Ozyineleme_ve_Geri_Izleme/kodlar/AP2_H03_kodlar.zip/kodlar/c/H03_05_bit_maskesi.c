/* H03_05_bit_maskesi.c — AP-2 Hafta 3 · Örnek 5 (★★)
 * Amaç    : Alt kümeleri özyinelemesiz üretmek: maske = 0 … 2^n − 1; bitler
 *           hangi elemanın alındığını söyler. Örnek 4 ile karşılaştırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_05_bit_maskesi.c -o H03_05_bit_maskesi
 * Çalıştır: ./H03_05_bit_maskesi
 * Eşleri  : cpp/H03_05_bit_maskesi.cpp · python/H03_05_bit_maskesi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_N 16

static int a[MAKS_N];                  /* küme elemanları */
static unsigned sira[1u << MAKS_N];    /* özyinelemenin ürettiği maskeler */
static int sira_uzunluk = 0;
static int goruldu[1u << MAKS_N];

/* Eşleme: a0_solda = 1 ise a[i] ↔ bit (n-1-i) (a[0] en soldaki bit);
 *         a0_solda = 0 ise a[i] ↔ bit i     (a[0] en sağdaki bit) */
static int bit_no(int i, int n, int a0_solda)
{
    return a0_solda ? n - 1 - i : i;
}

/* maskenin gösterdiği alt kümeyi metin olarak yazar: "{1, 3}" */
static void kume_metni(unsigned maske, int n, int a0_solda, char *metin)
{
    int k = sprintf(metin, "{");
    int ilk = 1;
    for (int i = 0; i < n; i++) {
        if ((maske >> bit_no(i, n, a0_solda)) & 1u) {
            k += sprintf(metin + k, ilk ? "%d" : ", %d", a[i]);
            ilk = 0;
        }
    }
    sprintf(metin + k, "}");
}

/* Bit maskesiyle üretim: her maske bir alt küme */
static void maske_ile_uret(int n)
{
    char m1[64], m2[64];
    printf("maske  ikili  a[0] soldaki bit  a[0] sağdaki bit\n");
    for (unsigned maske = 0; maske < (1u << n); maske++) {
        printf("%5u  ", maske);
        for (int b = n - 1; b >= 0; b--) {
            putchar((maske >> b) & 1u ? '1' : '0');
        }
        kume_metni(maske, n, 1, m1);
        kume_metni(maske, n, 0, m2);
        printf("    %-16s  %s\n", m1, m2);
    }
}

/* Örnek 4'teki dahil etme / dahil et özyinelemesi; her yaprakta
 * alt kümeyi maske olarak kaydeder */
static void ozyinelemeli_maskeler(int i, int n, int a0_solda,
                                  unsigned maske)
{
    if (i == n) {
        sira[sira_uzunluk++] = maske;
        return;
    }
    unsigned bit = 1u << bit_no(i, n, a0_solda);
    ozyinelemeli_maskeler(i + 1, n, a0_solda, maske);        /* dahil etme */
    ozyinelemeli_maskeler(i + 1, n, a0_solda, maske | bit);  /* dahil et */
}

/* Özyinelemenin k. yaprağı k maskesi mi? (aynı sıra) */
static int ayni_sira(int n)
{
    for (unsigned k = 0; k < (1u << n); k++) {
        if (sira[k] != k) {
            return 0;
        }
    }
    return 1;
}

/* Her maske tam bir kez üretildi mi? (aynı küme ailesi) */
static int her_kume_bir_kez(int n)
{
    for (unsigned k = 0; k < (1u << n); k++) {
        goruldu[k] = 0;
    }
    for (int k = 0; k < sira_uzunluk; k++) {
        goruldu[sira[k]]++;
    }
    for (unsigned k = 0; k < (1u << n); k++) {
        if (goruldu[k] != 1) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    printf("1) a = {1, 2, 3}: maske = 0 ... 2^3 - 1\n");
    for (int i = 0; i < MAKS_N; i++) {
        a[i] = i + 1;
    }
    maske_ile_uret(3);

    printf("\n2) Özyineleme (Örnek 4) ile bit maskesi aynı kümeleri mi "
           "üretir?\n");
    printf("  n      küme   a[0] solda: aynı sıra"
           " | a[0] sağda: aynı sıra / aynı aile\n");
    for (int n = 1; n <= MAKS_N; n++) {
        sira_uzunluk = 0;
        ozyinelemeli_maskeler(0, n, 1, 0u);
        int solda_sira = ayni_sira(n);
        sira_uzunluk = 0;
        ozyinelemeli_maskeler(0, n, 0, 0u);
        int sagda_sira = ayni_sira(n);
        int sagda_aile = her_kume_bir_kez(n);
        printf("%3d %9d   %s | %s / %s\n", n, sira_uzunluk,
               solda_sira ? "evet" : "hayır", sagda_sira ? "evet" : "hayır",
               sagda_aile ? "evet" : "hayır");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::bitset<N>(maske) yalnızca
 * gösterim; Python — itertools.product([0, 1], repeat=n) (yalnızca kâhin). */

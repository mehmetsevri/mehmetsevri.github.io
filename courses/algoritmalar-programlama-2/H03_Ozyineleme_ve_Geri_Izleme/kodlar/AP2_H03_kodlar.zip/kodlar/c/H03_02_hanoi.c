/* H03_02_hanoi.c — AP-2 Hafta 3 · Örnek 2 (★)
 * Amaç    : Hanoi Kuleleri; T(n) = 2T(n−1) + 1 bağıntısının yerine koyma
 *           ile açılımı ve hamle sayacıyla 2^n − 1 sonucunun doğrulanması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_02_hanoi.c -o H03_02_hanoi
 * Çalıştır: ./H03_02_hanoi
 * Eşleri  : cpp/H03_02_hanoi.cpp · python/H03_02_hanoi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

static long long hamle_sayisi = 0;  /* yapılan hamle sayısı */
static int listele = 0;             /* 1 ise her hamle yazdırılır */

/* n diski kaynak çubuğundan hedef çubuğuna taşır */
static void hanoi(int n, char kaynak, char hedef, char yardimci)
{
    if (n == 0) {
        return;                              /* temel durum: disk yok */
    }
    hanoi(n - 1, kaynak, yardimci, hedef);   /* üstteki n-1 disk */
    hamle_sayisi++;                          /* en büyük disk */
    if (listele) {
        printf("%2lld. hamle: disk %d  %c -> %c\n",
               hamle_sayisi, n, kaynak, hedef);
    }
    hanoi(n - 1, yardimci, hedef, kaynak);   /* n-1 disk yeniden */
}

int main(void)
{
    printf("1) n = 3 için hamleler\n");
    listele = 1;
    hanoi(3, 'A', 'C', 'B');
    listele = 0;

    printf("\n2) Yerine koyma: T(n) = 2T(n-1) + 1, T(0) = 0\n");
    int n = 5;
    long long katsayi = 1, ek = 0;           /* T(n) = katsayi*T(n-k) + ek */
    printf("T(%d)", n);
    for (int k = 1; k <= n; k++) {
        katsayi *= 2;
        ek = 2 * ek + 1;
        printf(" = %lldT(%d) + %lld", katsayi, n - k, ek);
        if (k % 2 == 0) {
            printf("\n    ");
        }
    }
    printf(" = %lld\n", ek);

    printf("\n3) Hamle sayacı ve 2^n - 1\n");
    printf("  n       hamle  2T(n-1)+1       2^n-1  eşit\n");
    long long t_onceki = 0;                  /* T(n-1), bağıntıdan */
    for (n = 1; n <= 20; n++) {
        hamle_sayisi = 0;
        hanoi(n, 'A', 'C', 'B');
        long long t_bagint = 2 * t_onceki + 1;
        long long kapali = (1LL << n) - 1;
        printf("%3d %11lld %10lld %11lld  %s\n", n, hamle_sayisi,
               t_bagint, kapali,
               (hamle_sayisi == kapali && t_bagint == kapali)
                   ? "evet" : "HAYIR");
        t_onceki = t_bagint;
    }
    return 0;
}

/* Kütüphane karşılığı: yok (algoritmanın kendisi; standart kütüphanelerde
 * Hanoi çözücüsü bulunmaz). */

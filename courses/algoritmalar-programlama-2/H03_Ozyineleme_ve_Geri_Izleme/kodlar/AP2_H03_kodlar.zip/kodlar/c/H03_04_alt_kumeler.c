/* H03_04_alt_kumeler.c — AP-2 Hafta 3 · Örnek 4 (★★)
 * Amaç    : Bir kümenin tüm alt kümeleri — özyinelemeli üretme şablonu:
 *           a[i] için "dahil etme" ve "dahil et" (seç → dene → geri al)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_04_alt_kumeler.c -o H03_04_alt_kumeler
 * Çalıştır: ./H03_04_alt_kumeler
 * Eşleri  : cpp/H03_04_alt_kumeler.cpp · python/H03_04_alt_kumeler.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_N 20

static int a[MAKS_N];               /* küme elemanları */
static int n;                       /* eleman sayısı */
static int yol[MAKS_N];             /* şu ana kadar seçilenler */
static int uzunluk = 0;             /* yol'daki eleman sayısı */
static long long cagri_sayisi = 0;
static long long kume_sayisi = 0;
static long long eleman_toplami = 0; /* üretilen kümelerin boyları toplamı */
static int yazdir_mi = 1;

/* Bir alt küme tamamlandı: say ve (istenirse) yaz */
static void kume_isle(void)
{
    kume_sayisi++;
    eleman_toplami += uzunluk;
    if (yazdir_mi) {
        printf("%2lld: {", kume_sayisi);
        for (int j = 0; j < uzunluk; j++) {
            printf(j > 0 ? ", %d" : "%d", yol[j]);
        }
        printf("}\n");
    }
}

/* a[0..i-1] için karar verildi; a[i..n-1] için devam et */
static void alt_kumeler(int i)
{
    cagri_sayisi++;
    if (i == n) {          /* yaprak */
        kume_isle();
        return;
    }
    alt_kumeler(i + 1);    /* a[i] yok */
    yol[uzunluk++] = a[i]; /* seç */
    alt_kumeler(i + 1);    /* dene */
    uzunluk--;             /* geri al */
}

int main(void)
{
    printf("1) a = {1, 2, 3} kümesinin alt kümeleri\n");
    n = 3;
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }
    alt_kumeler(0);
    printf("küme = %lld   çağrı = %lld\n", kume_sayisi, cagri_sayisi);

    printf("\n2) Sayım: küme = 2^n, çağrı = 2^(n+1) - 1,"
           " eleman toplamı = n*2^(n-1)\n");
    printf("  n     küme     çağrı  eleman toplamı  n*2^(n-1)  eşit\n");
    yazdir_mi = 0;
    for (n = 1; n <= 16; n++) {
        for (int i = 0; i < n; i++) {
            a[i] = i + 1;
        }
        cagri_sayisi = 0;
        kume_sayisi = 0;
        eleman_toplami = 0;
        alt_kumeler(0);
        long long iki_n = 1LL << n;
        long long beklenen = (long long)n * (iki_n / 2);
        int esit = kume_sayisi == iki_n && cagri_sayisi == 2 * iki_n - 1
                   && eleman_toplami == beklenen;
        printf("%3d %8lld %9lld %15lld %10lld  %s\n", n, kume_sayisi,
               cagri_sayisi, eleman_toplami, beklenen,
               esit ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — itertools.combinations
 * ile her r için birleştirme ya da itertools.product (yalnızca kâhin). */

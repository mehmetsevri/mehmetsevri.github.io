/* H03_03_ikili_diziler.c — AP-2 Hafta 3 · Örnek 3 (★)
 * Amaç    : n bitlik tüm ikili dizileri özyinelemeyle üretmek; her bitte
 *           iki dal (0: dahil etme, 1: dahil et); 2^n yaprak, 2^(n+1) − 1 çağrı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_03_ikili_diziler.c -o H03_03_ikili_diziler
 * Çalıştır: ./H03_03_ikili_diziler
 * Eşleri  : cpp/H03_03_ikili_diziler.cpp · python/H03_03_ikili_diziler.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_N 20

static char dizi[MAKS_N + 1];       /* üretilmekte olan dizi */
static long long cagri_sayisi = 0;
static long long dizi_sayisi = 0;   /* üretilen (yaprak) dizi sayısı */
static int yazdir_mi = 1;

/* dizi[0..k-1] belirlendi; dizi[k..n-1] için iki seçeneği dene */
static void ikili_uret(int k, int n)
{
    cagri_sayisi++;
    if (k == n) {                   /* yaprak: dizi tamamlandı */
        dizi_sayisi++;
        if (yazdir_mi) {
            dizi[n] = '\0';
            printf("%s\n", dizi);
        }
        return;
    }
    dizi[k] = '0';                  /* sol dal: k. bit 0 */
    ikili_uret(k + 1, n);
    dizi[k] = '1';                  /* sağ dal: k. bit 1 */
    ikili_uret(k + 1, n);
}

int main(void)
{
    printf("1) n = 3 için tüm ikili diziler (sözlük sırası)\n");
    ikili_uret(0, 3);
    printf("dizi = %lld   çağrı = %lld\n", dizi_sayisi, cagri_sayisi);

    printf("\n2) Sayım: dizi = 2^n, çağrı = 2^(n+1) - 1\n");
    printf("  n      dizi       2^n     çağrı  2^(n+1)-1  eşit\n");
    yazdir_mi = 0;
    for (int n = 1; n <= 16; n++) {
        cagri_sayisi = 0;
        dizi_sayisi = 0;
        ikili_uret(0, n);
        long long iki_n = 1LL << n;
        printf("%3d %9lld %9lld %9lld %10lld  %s\n", n, dizi_sayisi,
               iki_n, cagri_sayisi, 2 * iki_n - 1,
               (dizi_sayisi == iki_n && cagri_sayisi == 2 * iki_n - 1)
                   ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::bitset yalnızca gösterim);
 * Python — itertools.product("01", repeat=n) (yalnızca kâhin olarak). */

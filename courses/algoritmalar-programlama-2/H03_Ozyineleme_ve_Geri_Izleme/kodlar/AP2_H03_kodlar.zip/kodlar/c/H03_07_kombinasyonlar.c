/* H03_07_kombinasyonlar.c — AP-2 Hafta 3 · Örnek 7 (★★)
 * Amaç    : k-kombinasyonlar: başlangıç indisiyle tekrarsız üretim (her küme
 *           artan indisle bir kez); üretilen sayının C(n, k) ile doğrulanması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_07_kombinasyonlar.c -o H03_07_kombinasyonlar
 * Çalıştır: ./H03_07_kombinasyonlar
 * Eşleri  : cpp/H03_07_kombinasyonlar.cpp · python/H03_07_kombinasyonlar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_N 24

static int a[MAKS_N];              /* elemanlar: 1, 2, ..., n */
static int n;
static int yol[MAKS_N];            /* seçilenler (artan indisle) */
static int uzunluk = 0;
static long long cagri_sayisi = 0;
static long long komb_sayisi = 0;
static int yazdir_mi = 1;

static void komb_isle(void)
{
    komb_sayisi++;
    if (yazdir_mi) {
        printf("{");
        for (int j = 0; j < uzunluk; j++) {
            printf(j > 0 ? ", %d" : "%d", yol[j]);
        }
        printf(komb_sayisi % 5 == 0 ? "}\n" : "}  ");
    }
}

/* a[bas..n-1] içinden k - uzunluk eleman daha seç */
static void kombinasyon(int bas, int k)
{
    cagri_sayisi++;
    if (uzunluk == k) {            /* k eleman seçildi */
        komb_isle();
        return;
    }
    /* i en çok n - (k - uzunluk): sağda yeterli eleman kalmalı */
    for (int i = bas; i <= n - (k - uzunluk); i++) {
        yol[uzunluk] = a[i];       /* seç */
        uzunluk++;
        kombinasyon(i + 1, k);     /* dene: yalnızca i'den sonrakiler */
        uzunluk--;                 /* geri al */
    }
}

/* C(m, k) = m! / (k! (m-k)!), çarpımsal formülle (her adım tam bölünür) */
static long long kombinasyon_sayisi(int m, int k)
{
    long long c = 1;
    for (int i = 1; i <= k; i++) {
        c = c * (m - k + i) / i;   /* c = C(m-k+i, i) */
    }
    return c;
}

static void calistir(int boyut, int k)
{
    n = boyut;
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }
    uzunluk = 0;
    cagri_sayisi = 0;
    komb_sayisi = 0;
    kombinasyon(0, k);
}

static void satir_yaz(int boyut, int k)
{
    long long c = kombinasyon_sayisi(boyut, k);
    printf("%3d %3d %10lld %9lld %9lld  %s\n", boyut, k, komb_sayisi, c,
           cagri_sayisi, komb_sayisi == c ? "evet" : "HAYIR");
}

int main(void)
{
    printf("1) n = 5, k = 3: {1..5} içinden 3'lü seçimler\n");
    calistir(5, 3);
    printf("kombinasyon = %lld   C(5, 3) = %lld   çağrı = %lld\n",
           komb_sayisi, kombinasyon_sayisi(5, 3), cagri_sayisi);

    printf("\n2) n = 10 için her k: üretilen = C(n, k)?\n");
    printf("  n   k   üretilen    C(n,k)     çağrı  eşit\n");
    yazdir_mi = 0;
    for (int k = 0; k <= 10; k++) {
        calistir(10, k);
        satir_yaz(10, k);
    }
    calistir(20, 10);
    satir_yaz(20, 10);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::next_permutation ile bir
 * bool maskesi dolaşılabilir); Python — itertools.combinations, math.comb
 * (yalnızca kâhin). */

#!/usr/bin/env python3
"""olcum_calistir.py — AP-2 Hafta 3 · Haftanın Deneyi: ölçüm sürücüsü

N-vezirde budamanın etkisini üç dilde ölçer ve ham sonuçları
sonuclar/h03_deney_olcum.csv dosyasına, makine bilgisini OLCUM_ORTAMI.txt
dosyasına yazar.

Düzen (AP-2 Ajan Rehberi, Bölüm 3):
  * C ve C++ -O2 ile; karşılaştırma için C ayrıca -O0 ile derlenir.
  * Her ölçüm: 1 ısınma + tekrar (çoğunlukla 5) çalıştırma; ORTANCA.
  * Tutarsız ölçüm (en_cok / en_az > 1,5 ve ortanca > 2 ms) en çok iki kez
    yinelenir; yayılımı en küçük olan deneme tutulur, deneme sayısı
    CSV'ye yazılır.
  * Budamasız arama C/C++'ta N <= 8, Python'da N <= 7 ölçülür. Kestirim
    yöntemini sınamak için birer "dogrulama" ölçümü daha alınır
    (C -O2: N = 9; Python: N = 8; tek tekrar).
Kullanım (deney/ klasöründe):  python3 olcum_calistir.py
Toplam süre bu makinede yaklaşık 1–1,5 dakikadır.
"""
import datetime
import os
import platform
import subprocess
import sys
import tempfile

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C_DERLE = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP_DERLE = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]


def derle(gecici):
    """İkilileri derler; {(dil, derleme): komut önü} döndürür."""
    c = os.path.join(KOK, "c")
    cpp = os.path.join(KOK, "cpp")
    ikili = {}
    for bayrak in ("-O2", "-O0"):
        hedef = os.path.join(gecici, f"deney_c{bayrak}")
        kaynak = [os.path.join(c, "H03_deney_n_vezir.c"),
                  os.path.join(c, "zamanlayici.c")]
        subprocess.run(C_DERLE + [bayrak] + kaynak + ["-o", hedef],
                       check=True)
        ikili[("C", bayrak)] = [hedef]
    hedef = os.path.join(gecici, "deney_cpp")
    subprocess.run(CPP_DERLE + ["-O2", os.path.join(cpp,
                                                    "H03_deney_n_vezir.cpp"),
                                "-o", hedef], check=True)
    ikili[("C++", "-O2")] = [hedef]
    ikili[("Python", "-")] = [sys.executable, os.path.join(
        KOK, "python", "H03_deney_n_vezir.py")]
    return ikili


def olc(komut, yontem, n, tekrar):
    p = subprocess.run(komut + [yontem, str(n), str(tekrar), "--csv"],
                       capture_output=True, text=True, check=True)
    y, nn, cozum, dugum, tk, orta, az, cok = p.stdout.strip().split(";")
    return {"yontem": y, "N": int(nn), "cozum": int(cozum),
            "dugum": int(dugum), "tekrar": int(tk), "ortanca_ms": float(orta),
            "en_az_ms": float(az), "en_cok_ms": float(cok)}


def olc_tutarli(komut, yontem, n, tekrar):
    en_iyi, deneme = None, 0
    for deneme in range(1, 4):
        s = olc(komut, yontem, n, tekrar)
        yayilim = s["en_cok_ms"] / max(s["en_az_ms"], 1e-9)
        if en_iyi is None or yayilim < en_iyi[0]:
            en_iyi = (yayilim, s)
        if yayilim <= 1.5 or s["ortanca_ms"] <= 2.0 or tekrar == 1:
            break
    sonuc = dict(en_iyi[1])
    sonuc["deneme"] = deneme
    return sonuc


def plan():
    """(dil, derleme, yontem, N, tekrar, tur) listesi"""
    p = []
    for dil, der in (("C", "-O2"), ("C++", "-O2"), ("C", "-O0")):
        for n in range(4, 9):
            p.append((dil, der, "budamasiz", n, 5 if n < 8 else 3, "olcum"))
        for n in range(4, 13):
            p.append((dil, der, "budamali", n, 5, "olcum"))
    p.append(("C", "-O2", "budamasiz", 9, 1, "dogrulama"))
    for n in range(4, 8):
        p.append(("Python", "-", "budamasiz", n, 5 if n < 7 else 3, "olcum"))
    p.append(("Python", "-", "budamasiz", 8, 1, "dogrulama"))
    for n in range(4, 13):
        p.append(("Python", "-", "budamali", n, 5 if n < 12 else 3, "olcum"))
    return p


def ortam_yaz(sure_sn):
    def ilk(komut):
        try:
            return subprocess.run(komut, capture_output=True, text=True
                                  ).stdout.strip().splitlines()[0]
        except (OSError, IndexError):
            return "?"
    model = "?"
    for satir in subprocess.run(["lscpu"], capture_output=True, text=True
                                ).stdout.splitlines():
        if satir.startswith("Model name:"):
            model = satir.split(":", 1)[1].strip()
    metin = (
        "AP-2 Hafta 3 · Haftanın Deneyi — ölçüm ortamı\n"
        f"Tarih          : {datetime.date.today().isoformat()}\n"
        f"İşlemci        : {model}\n"
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine; başka süreçler "
        "de çalışıyordu)\n"
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})\n"
        f"C derleyicisi  : {ilk(['gcc', '--version'])}\n"
        f"C++ derleyicisi: {ilk(['g++', '--version'])}\n"
        f"Python         : {ilk([sys.executable, '--version'])}\n"
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra "
        "-pedantic -O2 (C ayrıca -O0)\n"
        "Yöntem         : 1 ısınma + tekrar (çoğunlukla 5) çalıştırma, "
        "ortanca; en_cok/en_az > 1,5 ise en çok 2 kez yineleme\n"
        "Saat           : C timespec_get (duvar saati), C++ steady_clock, "
        "Python time.perf_counter\n"
        f"Toplam deney süresi: {sure_sn:.1f} s\n")
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)
    print(metin)


def main():
    os.makedirs(SONUC, exist_ok=True)
    baslangic = datetime.datetime.now()
    with tempfile.TemporaryDirectory(prefix="h03_deney_") as gecici:
        ikili = derle(gecici)
        satirlar = []
        for dil, der, yontem, n, tekrar, tur in plan():
            s = olc_tutarli(ikili[(dil, der)], yontem, n, tekrar)
            s.update(dil=dil, derleme=der, tur=tur)
            satirlar.append(s)
            print(f"{dil:<6} {der:<3} {yontem:<9} N={n:2d} "
                  f"düğüm={s['dugum']:>10} çözüm={s['cozum']:>6} "
                  f"ortanca={s['ortanca_ms']:12.4f} ms "
                  f"[{s['en_az_ms']:.4f} … {s['en_cok_ms']:.4f}] "
                  f"deneme={s['deneme']}", flush=True)
    alanlar = ["N", "dil", "derleme", "yontem", "tur", "cozum", "dugum",
               "tekrar", "deneme", "ortanca_ms", "en_az_ms", "en_cok_ms"]
    with open(os.path.join(SONUC, "h03_deney_olcum.csv"), "w",
              encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join(f"{s[a]:.4f}" if isinstance(s[a], float)
                             else str(s[a]) for a in alanlar) + "\n")
    ortam_yaz((datetime.datetime.now() - baslangic).total_seconds())


if __name__ == "__main__":
    main()

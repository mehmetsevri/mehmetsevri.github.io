#!/usr/bin/env python3
"""kestirim.py — AP-2 Hafta 3 · Haftanın Deneyi: çözümleme

sonuclar/h03_deney_olcum.csv dosyasını okur ve üç dosya yazar:
  h03_deney_uzay.csv     N için arama uzayı büyüklükleri (kesin sayılar):
                         C(N², N) (tahtaya N vezir), N^N (satır başına bir),
                         N! (satır ve sütun başına bir), budamasız ağacın
                         düğüm sayısı (N^0 + … + N^N), budamalı ağacın ölçülen
                         düğüm sayısı ve çözüm sayısı
  h03_deney_kestirim.csv ölçülmeyen (dil, yöntem, N) için süre KESTİRİMİ:
                         t(N) = t(N0) · düğüm(N) / düğüm(N0)
                         (N0: o seride ölçülen en büyük N; "düğüm başına süre
                         sabit" varsayımı). Yöntem, doğrulama ölçümleriyle
                         sınanır (hata yüzdesi dosyaya yazılır).
  h03_deney_oran.csv     aynı N'de diller arası süre oranları (ortanca/ortanca)
Kullanım (deney/ klasöründe):  python3 kestirim.py
"""
import csv
import os

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")


def oku():
    with open(os.path.join(SONUC, "h03_deney_olcum.csv"),
              encoding="utf-8") as f:
        satirlar = list(csv.DictReader(f, delimiter=";"))
    for s in satirlar:
        for a in ("N", "cozum", "dugum", "tekrar", "deneme"):
            s[a] = int(s[a])
        for a in ("ortanca_ms", "en_az_ms", "en_cok_ms"):
            s[a] = float(s[a])
    return satirlar


def budamasiz_dugum(n):
    """1 + N + N^2 + ... + N^N"""
    return sum(n ** d for d in range(n + 1))


def kombinasyon(m, k):
    c = 1
    for i in range(1, k + 1):
        c = c * (m - k + i) // i
    return c


def faktoriyel(n):
    f = 1
    for i in range(2, n + 1):
        f *= i
    return f


def yaz(ad, alanlar, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join(str(s[a]) for a in alanlar) + "\n")
    print(f"yazıldı: sonuclar/{ad} ({len(satirlar)} satır)")


def sure_metni(ms):
    s = ms / 1000
    if s < 60:
        return f"{s:.3g} s"
    if s < 3600:
        return f"{s / 60:.3g} dk"
    if s < 86400:
        return f"{s / 3600:.3g} sa"
    if s < 365 * 86400:
        return f"{s / 86400:.3g} gün"
    return f"{s / (365 * 86400):.3g} yıl"


def main():
    olcum = oku()
    seri = {}
    for s in olcum:
        seri.setdefault((s["dil"], s["derleme"], s["yontem"]), {})[s["N"]] = s

    # 1) Arama uzayı
    budamali = {s["N"]: s for s in olcum if s["yontem"] == "budamali"
                and s["dil"] == "C" and s["derleme"] == "-O2"}
    uzay = []
    for n in range(4, 13):
        uzay.append({"N": n, "kare_secimi_C(N2,N)": kombinasyon(n * n, n),
                     "satir_basina_N^N": n ** n, "permutasyon_N!":
                     faktoriyel(n), "budamasiz_dugum": budamasiz_dugum(n),
                     "budamali_dugum": budamali[n]["dugum"],
                     "cozum": budamali[n]["cozum"],
                     "budama_kazanci": "%.1f" % (budamasiz_dugum(n)
                                                 / budamali[n]["dugum"])})
    yaz("h03_deney_uzay.csv", list(uzay[0].keys()), uzay)

    # 2) Kestirim ve doğrulama
    kestirim = []
    for (dil, der, yontem), s in sorted(seri.items()):
        if yontem != "budamasiz":
            continue
        olculen = {n: v for n, v in s.items() if v["tur"] == "olcum"}
        dogrulama = {n: v for n, v in s.items() if v["tur"] == "dogrulama"}
        # doğrulama: olcum serisinin en büyüğünden doğrulama N'sine
        n0 = max(olculen)
        for n, v in dogrulama.items():
            tahmin = olculen[n0]["ortanca_ms"] * budamasiz_dugum(n) / \
                budamasiz_dugum(n0)
            hata = 100 * (tahmin - v["ortanca_ms"]) / v["ortanca_ms"]
            kestirim.append({"dil": dil, "derleme": der, "yontem": yontem,
                             "N": n, "dugum": budamasiz_dugum(n),
                             "taban_N": n0, "kestirim_ms": f"{tahmin:.1f}",
                             "kestirim_okunur": sure_metni(tahmin),
                             "olculen_ms": f"{v['ortanca_ms']:.1f}",
                             "hata_yuzde": f"{hata:+.1f}",
                             "tur": "kestirim sınaması"})
        # kestirim: en büyük ölçülen (doğrulama dahil) N'den 12'ye kadar
        hepsi = dict(olculen)
        hepsi.update(dogrulama)
        n0 = max(hepsi)
        for n in range(n0 + 1, 13):
            tahmin = hepsi[n0]["ortanca_ms"] * budamasiz_dugum(n) / \
                budamasiz_dugum(n0)
            kestirim.append({"dil": dil, "derleme": der, "yontem": yontem,
                             "N": n, "dugum": budamasiz_dugum(n),
                             "taban_N": n0, "kestirim_ms": f"{tahmin:.1f}",
                             "kestirim_okunur": sure_metni(tahmin),
                             "olculen_ms": "", "hata_yuzde": "",
                             "tur": "kestirim"})
    yaz("h03_deney_kestirim.csv", list(kestirim[0].keys()), kestirim)

    # 3) Diller arası oranlar (aynı N, aynı yöntem; C -O2 taban)
    oran = []
    for yontem in ("budamasiz", "budamali"):
        taban = seri[("C", "-O2", yontem)]
        for n in sorted(taban):
            t = taban[n]["ortanca_ms"]
            if t < 0.05:          # 50 µs altı: saat çözünürlüğü/gürültü
                continue
            satir = {"yontem": yontem, "N": n, "C_O2_ms": f"{t:.4f}"}
            karsilastirma = (("C++", "-O2", "Cpp_C"),
                             ("C", "-O0", "C_O0_C_O2"),
                             ("Python", "-", "Python_C"))
            for dil, der, ad in karsilastirma:
                v = seri[(dil, der, yontem)].get(n)
                satir[ad] = f"{v['ortanca_ms'] / t:.2f}" if v else ""
            oran.append(satir)
    yaz("h03_deney_oran.csv", list(oran[0].keys()), oran)

    print("\nKestirim sınaması (düğüm oranı modeli):")
    for k in kestirim:
        if k["tur"] == "kestirim sınaması":
            print(f"  {k['dil']} {k['derleme']} N={k['N']} (taban N="
                  f"{k['taban_N']}): kestirim {k['kestirim_ms']} ms, "
                  f"ölçülen {k['olculen_ms']} ms, hata {k['hata_yuzde']} %")
    print("\nN = 12 için budamasız kestirimler:")
    for k in kestirim:
        if k["N"] == 12:
            print(f"  {k['dil']} {k['derleme']}: {k['kestirim_okunur']}")


if __name__ == "__main__":
    main()

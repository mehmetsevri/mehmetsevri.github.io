"""H03_deney_n_vezir.py — AP-2 Hafta 3 · Haftanın Deneyi
Amaç    : N-vezirde budamanın etkisi. budamasiz: her satıra bir vezir,
          N^N yerleşimin tamamı üretilir, denetim yalnızca yaprakta;
          budamali: geri izleme, sütun/köşegen dizileriyle O(1) denetim
Çalıştır: python3 H03_deney_n_vezir.py budamali|budamasiz N [tekrar=5]
          [--csv]  stdout: sayaçlar (deterministik); stderr: süreler
          --csv: stdout'a tek satır
          yontem;N;cozum;dugum;tekrar;ortanca_ms;en_az_ms;en_cok_ms
Eşleri  : ../c/H03_deney_n_vezir.c · ../cpp/H03_deney_n_vezir.cpp
"""

import sys

from zamanlayici import ortanca, zaman_sn

MAKS_N = 16

n = 0
sutun = [0] * MAKS_N
sutun_dolu = [False] * MAKS_N
kosegen1 = [False] * (2 * MAKS_N - 1)
kosegen2 = [False] * (2 * MAKS_N - 1)
cozum_sayisi = 0
dugum_sayisi = 0


def gecerli_mi():
    """Tam yerleşim geçerli mi? (yalnızca yaprakta; tüm vezir çiftleri)"""
    for i in range(n):
        for j in range(i + 1, n):
            fark = sutun[i] - sutun[j]
            if fark == 0 or fark == j - i or fark == i - j:
                return False
    return True


def budamasiz(r):
    """Budamasız: her satırda her sütun denenir; N^0 + ... + N^N düğüm"""
    global dugum_sayisi, cozum_sayisi
    dugum_sayisi += 1
    if r == n:
        if gecerli_mi():
            cozum_sayisi += 1
        return
    for c in range(n):
        sutun[r] = c                # denetim yok
        budamasiz(r + 1)


def isaretle(r, c, deger):
    sutun_dolu[c] = deger
    kosegen1[r + c] = deger
    kosegen2[r - c + n - 1] = deger


def budamali(r):
    """Budamalı geri izleme: çakışan kareye hiç inilmez"""
    global dugum_sayisi, cozum_sayisi
    dugum_sayisi += 1
    if r == n:
        cozum_sayisi += 1
        return
    for c in range(n):
        if (not sutun_dolu[c] and not kosegen1[r + c]
                and not kosegen2[r - c + n - 1]):
            isaretle(r, c, True)
            budamali(r + 1)
            isaretle(r, c, False)


def main():
    global n
    if len(sys.argv) < 3 or sys.argv[1] not in ("budamali", "budamasiz"):
        print(f"kullanım: {sys.argv[0]} budamali|budamasiz N [tekrar] "
              "[--csv]", file=sys.stderr)
        sys.exit(2)
    yontem = sys.argv[1]
    tekrar, csv = 5, False
    try:
        n = int(sys.argv[2])
        for arg in sys.argv[3:]:
            if arg == "--csv":
                csv = True
            else:
                tekrar = int(arg)
    except ValueError:
        n = -1
    if not (1 <= n <= MAKS_N and 1 <= tekrar <= 101):
        print(f"N: 1..{MAKS_N}, tekrar: 1..101", file=sys.stderr)
        sys.exit(2)

    def gorev():
        global cozum_sayisi, dugum_sayisi
        cozum_sayisi = 0
        dugum_sayisi = 0
        if yontem == "budamali":
            budamali(0)
        else:
            budamasiz(0)

    gorev()                         # ısınma
    sureler = []
    for _ in range(tekrar):
        t0 = zaman_sn()
        gorev()
        sureler.append((zaman_sn() - t0) * 1e3)
    orta = ortanca(sureler)
    en_az, en_cok = min(sureler), max(sureler)
    if csv:
        print(f"{yontem};{n};{cozum_sayisi};{dugum_sayisi};{tekrar};"
              f"{orta:.4f};{en_az:.4f};{en_cok:.4f}")
    else:
        print(f"yontem={yontem} N={n} cozum={cozum_sayisi} "
              f"dugum={dugum_sayisi}")
        print(f"ortanca={orta:.4f} ms en_az={en_az:.4f} ms "
              f"en_cok={en_cok:.4f} ms (tekrar={tekrar})", file=sys.stderr)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok. Ölçüm: zamanlayici (1 ısınma + tekrar,
# ortanca). min/max yalnızca ölçüm yayılımını raporlamak içindir.

/* H03_deney_n_vezir.c — AP-2 Hafta 3 · Haftanın Deneyi
 * Amaç    : N-vezirde budamanın etkisi. budamasiz: her satıra bir vezir,
 *           N^N yerleşimin tamamı üretilir, denetim yalnızca yaprakta;
 *           budamali: geri izleme, sütun/köşegen dizileriyle O(1) denetim
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_deney_n_vezir.c zamanlayici.c -o H03_deney_n_vezir
 * Çalıştır: ./H03_deney_n_vezir budamali|budamasiz N [tekrar=5] [--csv]
 *           stdout: sayaçlar (deterministik); stderr: süreler
 *           --csv: stdout'a tek satır
 *           yontem;N;cozum;dugum;tekrar;ortanca_ms;en_az_ms;en_cok_ms
 * Eşleri  : ../cpp/H03_deney_n_vezir.cpp · ../python/H03_deney_n_vezir.py
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "zamanlayici.h"

#define MAKS_N 16

static int n;
static int sutun[MAKS_N];
static int sutun_dolu[MAKS_N];
static int kosegen1[2 * MAKS_N - 1];
static int kosegen2[2 * MAKS_N - 1];
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0;

/* Tam yerleşim geçerli mi? (yalnızca yaprakta; tüm vezir çiftleri) */
static int gecerli_mi(void)
{
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            int fark = sutun[i] - sutun[j];
            if (fark == 0 || fark == j - i || fark == i - j) {
                return 0;
            }
        }
    }
    return 1;
}

/* Budamasız: her satırda her sütun denenir; ağaçta N^0 + ... + N^N düğüm */
static void budamasiz(int r)
{
    dugum_sayisi++;
    if (r == n) {
        if (gecerli_mi()) {
            cozum_sayisi++;
        }
        return;
    }
    for (int c = 0; c < n; c++) {
        sutun[r] = c;              /* denetim yok */
        budamasiz(r + 1);
    }
}

static void isaretle(int r, int c, int deger)
{
    sutun_dolu[c] = deger;
    kosegen1[r + c] = deger;
    kosegen2[r - c + n - 1] = deger;
}

/* Budamalı geri izleme: çakışan kareye hiç inilmez */
static void budamali(int r)
{
    dugum_sayisi++;
    if (r == n) {
        cozum_sayisi++;
        return;
    }
    for (int c = 0; c < n; c++) {
        if (!sutun_dolu[c] && !kosegen1[r + c] && !kosegen2[r - c + n - 1]) {
            isaretle(r, c, 1);
            budamali(r + 1);
            isaretle(r, c, 0);
        }
    }
}

static int yontem_budamali = 1;

static void gorev(void *veri)
{
    (void)veri;
    cozum_sayisi = 0;
    dugum_sayisi = 0;
    if (yontem_budamali) {
        budamali(0);
    } else {
        budamasiz(0);
    }
}

int main(int argc, char *argv[])
{
    int tekrar = 5, csv = 0;
    char *son;
    if (argc < 3) {
        fprintf(stderr, "kullanım: %s budamali|budamasiz N [tekrar] "
                "[--csv]\n", argv[0]);
        return 2;
    }
    if (strcmp(argv[1], "budamali") == 0) {
        yontem_budamali = 1;
    } else if (strcmp(argv[1], "budamasiz") == 0) {
        yontem_budamali = 0;
    } else {
        fprintf(stderr, "yöntem: budamali ya da budamasiz\n");
        return 2;
    }
    long deger = strtol(argv[2], &son, 10);
    if (*son != '\0' || deger < 1 || deger > MAKS_N) {
        fprintf(stderr, "N: 1..%d\n", MAKS_N);
        return 2;
    }
    n = (int)deger;
    for (int i = 3; i < argc; i++) {
        if (strcmp(argv[i], "--csv") == 0) {
            csv = 1;
        } else {
            deger = strtol(argv[i], &son, 10);
            if (*son != '\0' || deger < 1 || deger > 101) {
                fprintf(stderr, "tekrar: 1..101\n");
                return 2;
            }
            tekrar = (int)deger;
        }
    }
    double sureler[101];
    gorev(NULL);                   /* ısınma */
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn();
        gorev(NULL);
        sureler[k] = (zaman_sn() - t0) * 1e3;
    }
    double en_az = sureler[0], en_cok = sureler[0];
    for (int k = 1; k < tekrar; k++) {
        en_az = sureler[k] < en_az ? sureler[k] : en_az;
        en_cok = sureler[k] > en_cok ? sureler[k] : en_cok;
    }
    double orta = ortanca(sureler, tekrar);
    if (csv) {
        printf("%s;%d;%lld;%lld;%d;%.4f;%.4f;%.4f\n", argv[1], n,
               cozum_sayisi, dugum_sayisi, tekrar, orta, en_az, en_cok);
    } else {
        printf("yontem=%s N=%d cozum=%lld dugum=%lld\n", argv[1], n,
               cozum_sayisi, dugum_sayisi);
        fprintf(stderr, "ortanca=%.4f ms en_az=%.4f ms en_cok=%.4f ms "
                "(tekrar=%d)\n", orta, en_az, en_cok, tekrar);
    }
    return 0;
}

/* Kütüphane karşılığı: yok. Ölçüm: zamanlayici (1 ısınma + tekrar,
 * ortanca). */

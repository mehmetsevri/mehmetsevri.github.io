/* H03_deney_n_vezir.cpp — AP-2 Hafta 3 · Haftanın Deneyi
 * Amaç    : N-vezirde budamanın etkisi. budamasiz: her satıra bir vezir,
 *           N^N yerleşimin tamamı üretilir, denetim yalnızca yaprakta;
 *           budamali: geri izleme, sütun/köşegen dizileriyle O(1) denetim
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H03_deney_n_vezir.cpp -o H03_deney_n_vezir
 * Çalıştır: ./H03_deney_n_vezir budamali|budamasiz N [tekrar=5] [--csv]
 *           stdout: sayaçlar (deterministik); stderr: süreler
 *           --csv: stdout'a tek satır
 *           yontem;N;cozum;dugum;tekrar;ortanca_ms;en_az_ms;en_cok_ms
 * Eşleri  : ../c/H03_deney_n_vezir.c · ../python/H03_deney_n_vezir.py
 */
#include <cstdio>
#include <string>
#include <vector>

#include "zamanlayici.hpp"

constexpr int MAKS_N = 16;

static int n;
static std::vector<int> sutun(MAKS_N);
static std::vector<char> sutun_dolu(MAKS_N);      // char: bayt başına bir
static std::vector<char> kosegen1(2 * MAKS_N - 1);
static std::vector<char> kosegen2(2 * MAKS_N - 1);
static long long cozum_sayisi = 0;
static long long dugum_sayisi = 0;

// Tam yerleşim geçerli mi? (yalnızca yaprakta; tüm vezir çiftleri)
static bool gecerli_mi()
{
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            int fark = sutun[i] - sutun[j];
            if (fark == 0 || fark == j - i || fark == i - j) {
                return false;
            }
        }
    }
    return true;
}

// Budamasız: her satırda her sütun denenir; ağaçta N^0 + ... + N^N düğüm
static void budamasiz(int r)
{
    dugum_sayisi++;
    if (r == n) {
        if (gecerli_mi()) {
            cozum_sayisi++;
        }
        return;
    }
    for (int c = 0; c < n; c++) {
        sutun[r] = c;              // denetim yok
        budamasiz(r + 1);
    }
}

static void isaretle(int r, int c, char deger)
{
    sutun_dolu[c] = deger;
    kosegen1[r + c] = deger;
    kosegen2[r - c + n - 1] = deger;
}

// Budamalı geri izleme: çakışan kareye hiç inilmez
static void budamali(int r)
{
    dugum_sayisi++;
    if (r == n) {
        cozum_sayisi++;
        return;
    }
    for (int c = 0; c < n; c++) {
        if (!sutun_dolu[c] && !kosegen1[r + c] && !kosegen2[r - c + n - 1]) {
            isaretle(r, c, 1);
            budamali(r + 1);
            isaretle(r, c, 0);
        }
    }
}

int main(int argc, char* argv[])
{
    int tekrar = 5;
    bool csv = false;
    if (argc < 3) {
        std::fprintf(stderr, "kullanım: %s budamali|budamasiz N [tekrar] "
                     "[--csv]\n", argv[0]);
        return 2;
    }
    const std::string yontem = argv[1];
    if (yontem != "budamali" && yontem != "budamasiz") {
        std::fprintf(stderr, "yöntem: budamali ya da budamasiz\n");
        return 2;
    }
    try {
        n = std::stoi(argv[2]);
        for (int i = 3; i < argc; i++) {
            if (std::string(argv[i]) == "--csv") {
                csv = true;
            } else {
                tekrar = std::stoi(argv[i]);
            }
        }
    } catch (const std::exception&) {
        n = -1;
    }
    if (n < 1 || n > MAKS_N || tekrar < 1 || tekrar > 101) {
        std::fprintf(stderr, "N: 1..%d, tekrar: 1..101\n", MAKS_N);
        return 2;
    }
    auto gorev = [&] {
        cozum_sayisi = 0;
        dugum_sayisi = 0;
        if (yontem == "budamali") {
            budamali(0);
        } else {
            budamasiz(0);
        }
    };
    std::vector<double> sureler;
    gorev();                       // ısınma
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn();
        gorev();
        sureler.push_back((zaman_sn() - t0) * 1e3);
    }
    double en_az = sureler[0], en_cok = sureler[0];
    for (double s : sureler) {
        en_az = s < en_az ? s : en_az;
        en_cok = s > en_cok ? s : en_cok;
    }
    double orta = ortanca(sureler);
    if (csv) {
        std::printf("%s;%d;%lld;%lld;%d;%.4f;%.4f;%.4f\n", yontem.c_str(), n,
                    cozum_sayisi, dugum_sayisi, tekrar, orta, en_az, en_cok);
    } else {
        std::printf("yontem=%s N=%d cozum=%lld dugum=%lld\n", yontem.c_str(),
                    n, cozum_sayisi, dugum_sayisi);
        std::fprintf(stderr, "ortanca=%.4f ms en_az=%.4f ms en_cok=%.4f ms "
                     "(tekrar=%d)\n", orta, en_az, en_cok, tekrar);
    }
    return 0;
}

/* Kütüphane karşılığı: yok. Ölçüm: zamanlayici (1 ısınma + tekrar,
 * ortanca). */

/* H03_Q01_dahil_et_once.c — AP-2 Hafta 3 · Quiz sorusu 2
 * Amaç    : Örnek 4'ün dalları yer değiştirirse üretim sırası ne olur?
 *           (önce "dahil et", sonra "dahil etme")
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H03_Q01_dahil_et_once.c -o H03_Q01_dahil_et_once
 * Çalıştır: ./H03_Q01_dahil_et_once
 */
#include <stdio.h>

static const int a[3] = {1, 2, 3};
static int yol[3];
static int uzunluk = 0;

static void alt_kumeler(int i)
{
    if (i == 3) {
        printf("{");
        for (int j = 0; j < uzunluk; j++) {
            printf(j > 0 ? ", %d" : "%d", yol[j]);
        }
        printf("} ");
        return;
    }
    yol[uzunluk++] = a[i];  /* önce dahil et */
    alt_kumeler(i + 1);
    uzunluk--;
    alt_kumeler(i + 1);     /* sonra dahil etme */
}

int main(void)
{
    alt_kumeler(0);
    printf("\n");
    return 0;
}

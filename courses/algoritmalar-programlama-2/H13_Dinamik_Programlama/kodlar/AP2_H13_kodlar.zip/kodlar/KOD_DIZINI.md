# Hafta 13 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı ve beklenen çıktısıyla aşağıdadır. **Ders notu**, **Sunum** ve **Web** sütunları kodun gösterildiği yeri (bölüm, slayt, web kutusu) ve görünür metindeki anışları (PDF sayfası, slayt) verir. Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11.15 (örnekler 3.10 uyumludur).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. Standart girdiden okuyan örnekler (9, 14) `girdiler/KÖK.txt` dosyasını bekler: `./program < girdiler/KÖK.txt`.

Eşdeğerlik: `python3 esdeger_test.py .` → **15/15 GEÇTİ** (14 “=”: üç dilde bayt bayt aynı stdout), uyarı 0; `--asan` (AddressSanitizer + UBSan + LeakSanitizer) ile **15/15 GEÇTİ** (hatalı 0). Valgrind: 66/66 program temiz (0 hata, 0 bayt kayıp) (`BELLEK_DENETIMI.txt`).


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H13_01_fibonacci` | ★ | = | evet | Fibonacci: saf özyineleme (çağrı = 2·F(n+1) − 1), memo (−1 = hesaplanmadı), tablo ve iki değişken; uint64_t sınırı ve mod 10⁹ + 7 | — | Bölüm 4.1; Ek A.1; metin s. 3, 5, 6, 7, 12, 36 … | slayt kod: 11; metin: 4, 9 | örnek kutusu (üç dil), metin |
| `H13_02_merdiven` | ★ | = | — | Merdiven çıkma (1 ya da 2 basamak): ilk durum–geçiş tanımı; yol[n] = F(n+1); bütün yolların listelenmesi; {1, 2, 3} değişkesi | — | Bölüm 3.4; Ek A.2; metin s. 3, 9, 44, 51 | slayt kod: 14 | örnek kutusu (üç dil), metin |
| `H13_03_bozuk_para_en_az` | ★★ | = | evet | Bozuk para, en az para: H12'nin karşı örneği ({1, 3, 4}, tutar 6: açgözlü 3, DP 2 para); geri çıkarma; ulaşılamayan tutar için ∞ (taşma korumalı); kanonik sistemde açgözlü = DP | — | Bölüm 4.2; Ek A.3; metin s. 3, 5, 6, 8, 10, 14 … | slayt kod: 19; metin: 13 | örnek kutusu (üç dil), metin |
| `H13_04_bozuk_para_yollar` | ★★ | = | — | Bozuk para, kaç farklı yol: dış döngü para → kombinasyon, dış döngü tutar → permütasyon; aynı girdide 4 ve 9; listelemeyle doğrulama | — | Bölüm 4.2; Ek A.4; metin s. 3, 6, 10, 16, 35, 50 … | slayt kod: 23; metin: 4, 16, 22 | örnek kutusu (üç dil), metin |
| `H13_05_izgara` | ★★ | = | — | Izgarada yol sayısı (mod 10⁹ + 7, tek satır tamponu), engelli ızgarada yol sayısı ve en küçük maliyetli yol; yolun geri çıkarılması | — | Ek A.5; metin s. 2, 3, 28, 29, 53 | slayt metin: 24 | örnek kutusu (üç dil), metin |
| `H13_06_tablo_kurma` | ★★ | Δ | — | 2B tablo kurma: C'de tek malloc bloğu (t[i * m + j]), C++'ta vector<vector<int>>, Python'da [[0] * m] * n tuzağı ve doğru biçim; aynı tabloyla Pascal üçgeni | — | Bölüm 5.2; Ek A.6; metin s. 2, 3, 20, 25, 28, 29 … | slayt metin: 25 | örnek kutusu (üç dil), metin |
| `H13_07_lis_n2` | ★★ | = | evet | En uzun artan alt dizi O(n²): uz ve ebeveyn dizileri, eşitlikte en küçük indis; geri çıkarma; kâhin 2^n alt küme | — | Bölüm 4.3; Ek A.7; metin s. 3, 6, 17, 46, 56 | slayt kod: 27; metin: 26 | örnek kutusu (üç dil), metin |
| `H13_08_lcs` | ★★★ | = | evet | LCS: tablo, ortak alt dizinin geri çıkarılması (eşitlikte önce yukarı), satır düzeyinde diff ve rastgele DNA | — | Bölüm 4.4; Ek A.8; metin s. 3, 19, 26, 40, 57 | slayt kod: 30 | örnek kutusu (üç dil), metin |
| `H13_09_duzenleme_uzakligi` | ★★★ | = | evet | Düzenleme (Levenshtein) uzaklığı: tablo, işlem dizisi; bayt ve kod noktası düzeyi; "Bunu mu demek istediniz?" (Türkçe sözlük, k = 3) | < girdiler/H13_09_duzenleme_uzakligi.txt | Bölüm 4.5; Ek A.9; metin s. 3, 22, 30, 41, 57 | slayt kod: 34 | örnek kutusu (üç dil), metin |
| `H13_10_sirt_cantasi` | ★★★ | = | evet | 0/1 sırt çantası: tam tablo ve seçilen nesneler; değer/ağırlık açgözlüsünün yanılması; 12 ders, 30 AKTS, kâhin 2^12 alt küme | — | Bölüm 4.6; Ek A.10; metin s. 3, 24, 58 | slayt kod: 36; metin: 38 | örnek kutusu (üç dil), metin |
| `H13_11_sirt_tek_satir` | ★★★ | = | — | 0/1 sırt çantası tek satırla: kapasite TERS sırada; artan sırada sınırsız sırt çantasına dönüşür (90 ve 150); bellek ve geri çıkarma bedeli | — | Ek A.11; metin s. 3, 6, 25, 26, 35, 41 … | slayt metin: 4, 40 | örnek kutusu (üç dil), metin |
| `H13_12_alt_kume_toplami` | ★★ | = | — | Alt küme toplamı: H3 budamalı geri izleme (düğüm) ile DP bool + sayım tablosu (hücre); aynı çözüm sayıları; n'ye göre karşılaştırma | — | Bölüm 4.7; Ek A.12; metin s. 3, 6, 27, 45, 60 | slayt metin: 43 | örnek kutusu (üç dil), metin |
| `H13_13_lis_nlogn` | ★★★ | = | — | LIS O(n log n) (merak): sabır sıralaması, tails dizisi ve H4 lower_bound; uzunluk Örnek 7 ile aynı; tails_idx + ebeveynle geri çıkarma | — | Ek A.13; metin s. 3, 10, 18, 28, 46, 47 … | slayt metin: 28, 51 | örnek kutusu (üç dil), metin |
| `H13_14_kelime_bolme` | ★★★ | = | — | Kelime bölme (önek DP'si, meydan okuma): Türkçe sözlükle bölünebilirlik, bölme sayısı, bir bölmenin geri çıkarılması ve bütün bölmeler | < girdiler/H13_14_kelime_bolme.txt | Bölüm 5.3; Ek A.14; metin s. 2, 4, 28, 30, 31, 50 … | slayt metin: 51 | örnek kutusu (üç dil), metin |
| `H13_15_matris_zinciri` | ★★★ | = | — | Matris zinciri çarpımı (aralık DP'si, meydan okuma): m ve s tabloları, parantezlemenin geri çıkarılması; kaba kuvvet 3^(n−1) çağrı | — | Bölüm 5.4; Ek A.15; metin s. 2, 4, 28, 31, 32, 43 … | slayt metin: 51 | örnek kutusu (üç dil), metin |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt`. C++/Python'da C'den anlam olarak farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`.

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py` (13 Ekim 2026 sürümü). Kullananlar: ortak_rastgele — Örnek 7, 8, 10, 11, 12, 13, 15; zamanlayici — Örnek — (süreler yalnızca stderr'e).


## 2. Kavram programları (kavram/)

Merdiven dışı küçük programlar (Kaputun Altında, Dil Penceresi, DAG köprüsü). Çıktılar `kavram/ciktilar/`; “bu çalıştırmada” etiketli değerler (süre, özyineleme sınırı) eşdeğerlik kapsamı dışındadır. `kavram/` içinde derlenir: `-I../c ../c/ortak_rastgele.c [../c/zamanlayici.c]`.

| Dosya | Dil | Amaç | Çıktı | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H13_K01_iki_satir.c` | C | Düzenleme uzaklığı ve LCS İKİ SATIRLA: D[i][·] yalnız D[i−1][·] satırına bağlı olduğundan iki satır yeter; kısa dizgi sütun yapılırsa bellek O(min(n, m)). Değer tam tabloyla aynıdır ama çözüm GERİ ÇIKARILAMAZ: geri çıkarma (n, m)'den başlayıp her i için D[i−1][·] satırını ister; o satırlar üzerine yazıldı. | `ciktilar/H13_K01_iki_satir_c.txt` | metin s. 11, 36 | slayt metin: 45 | metin |
| `kavram/H13_K01_iki_satir.py` | Python | Düzenleme uzaklığı ve LCS İKİ SATIRLA: D[i][·] yalnız D[i−1][·] satırına bağlı olduğundan iki satır yeter; kısa dizgi sütun yapılırsa bellek O(min(n, m)). Değer tam tabloyla aynıdır ama çözüm GERİ ÇIKARILAMAZ: geri çıkarma her i için D[i−1][·] satırını ister; o satırlar üzerine yazıldı. (C sürümüyle aynı hesaplar; Python'da n = 3000 yerine 1000 — süre bütçesi.) | `ciktilar/H13_K01_iki_satir_py.txt` | metin s. 11, 36 | slayt metin: 45 | metin |
| `kavram/H13_K02_lru_cache.py` | Python | Python'da memoization'ı dekoratör yapar: functools.cache (3.9+) ve functools.lru_cache(maxsize=None). Ama yukarıdan aşağıya memo ÖZYİNELEMELİDİR: derin bir zincir (fib(n) → fib(n−1) → …) varsayılan özyineleme sınırına (sys.getrecursionlimit(), çoğunlukla 1000) takılır ve RecursionError verir. Bu yorumlayıcıda (CPython 3.11) dekoratörlü fonksiyonun her düzeyi iki sayılır; sınıra elle memodan çok daha erken ulaşılır. Çare: tablolama (döngü, yığın kullanmaz). sys.setrecursionlimit YALNIZ bu açıklamalı programda gösterilir: sınırı yükseltmek C yığınını taşırıp süreci çökertebilir. | `ciktilar/H13_K02_lru_cache.txt` | metin s. 11 | — | metin |
| `kavram/H13_K03_uint64_tasmasi.c` | C | Büyük sayımlar: uint64_t aritmetiği 2^64'te SARAR (işaretsiz taşma TANIMLIDIR, uyarı yoktur): F(94) ve 40 × 40 ızgaradaki yol sayısı yanlış (mod 2^64) çıkar. Aynı sayımlar mod 10^9 + 7 ile üç dilde aynı. Python tam sonucu verir (eş dosya: .py); C++ C ile aynı çıktıyı verir (eş dosya: .cpp). | `ciktilar/H13_K03_uint64_tasmasi_c.txt` | metin s. 36 | — | metin |
| `kavram/H13_K03_uint64_tasmasi.cpp` | C++ | Büyük sayımlar: std::uint64_t aritmetiği 2^64'te SARAR (işaretsiz taşma tanımlıdır, uyarı yoktur): F(94) ve 40 × 40 ızgaradaki yol sayısı yanlış (mod 2^64) çıkar; mod 10^9 + 7 sürümü üç dilde aynı. Çıktı C sürümüyle aynıdır; Python tam sonucu verir (eş dosya: .py). | `ciktilar/H13_K03_uint64_tasmasi_cpp.txt` | metin s. 36 | — | metin |
| `kavram/H13_K03_uint64_tasmasi.py` | Python | Python tamsayısı taşmaz: F(94), F(100) ve 40 × 40 ızgaradaki yol sayısının TAM değeri. C/C++'taki uint64_t sonucunu elde etmek için her toplamadan sonra & (2^64 − 1) maskesi uygulanır — sonuç C ile birebir aynıdır (sarma bilinçli yapılır). mod 10^9 + 7 sürümü üç dilde aynı. | `ciktilar/H13_K03_uint64_tasmasi_py.txt` | metin s. 36 | — | metin |
| `kavram/H13_K04_sozde_polinom.c` | C | Sözde polinom zaman: 0/1 sırt çantası DP'si Θ(n·W) hücre işler; W bir SAYININ DEĞERİDİR, girdi uzunluğu ise W'nin bit sayısı b ile ölçülür (W ≈ 2^b). b iki katına çıkınca (girdi yalnız b bit uzar) hücre sayısı KARESİNE çıkar: zaman b'ye göre üsteldir. Hücreler stdout'a, süreler stderr'e (bu çalıştırmada). | `ciktilar/H13_K04_sozde_polinom_c.txt` | metin s. 26 | slayt metin: 41 | metin |
| `kavram/H13_K04_sozde_polinom.py` | Python | Sözde polinom zaman: 0/1 sırt çantası DP'si Θ(n·W) hücre işler; W bir SAYININ DEĞERİDİR, girdi uzunluğu ise W'nin bit sayısı b ile ölçülür (W ≈ 2^b). b iki katına çıkınca hücre sayısı KARESİNE çıkar. C sürümüyle aynı girdiler (tohum 5); Python'da b <= 16 (süre bütçesi). Süreler stderr'e (bu çalıştırmada). | `ciktilar/H13_K04_sozde_polinom_py.txt` | metin s. 26 | slayt metin: 41 | metin |
| `kavram/H13_K05_kadane_dp.c` | C | H2 Örnek 13'ün Kadane algoritması aslında bir DP'dir: durum biten[i] = a[i] ile BİTEN en büyük toplamlı alt dizi; geçiş biten[i] = max(a[i], biten[i−1] + a[i]) (ya yeni başla ya uzat); temel biten[0] = a[0]; sıra i artan; cevap max biten[i]. Tablonun yalnız son hücresi gerektiğinden tek değişkene iner (O(1) bellek) — Fibonacci'nin iki değişkenli sürümüyle aynı fikir. Eşitlikte H2 gibi uzatılır. | `ciktilar/H13_K05_kadane_dp_c.txt` | metin s. 10 | — | metin |
| `kavram/H13_K05_kadane_dp.py` | Python | H2 Örnek 13'ün Kadane algoritması bir DP'dir: durum biten[i] = a[i] ile BİTEN en büyük toplamlı alt dizi; geçiş biten[i] = max(a[i], biten[i−1] + a[i]); temel biten[0] = a[0]; cevap max biten[i]. Yalnız son hücre gerektiğinden tek değişkene iner (O(1) bellek). Çıktı C sürümüyle aynıdır. | `ciktilar/H13_K05_kadane_dp_py.txt` | metin s. 10 | — | metin |
| `kavram/H13_K06_karma_memo.c` | C | Memo için iki araç: (1) DİZİ: durum (i, t) → memo[i·(T+1)+t], bütün (n+1)(T+1) hücre baştan ayrılır, "hesaplanmadı" = −1; (2) KARMA TABLOSU (H10): yalnız gerçekten ziyaret edilen durumlar saklanır. Durum uzayı seyrek ya da sınırları bilinmiyor ise karma tablosu bellek kazandırır; yoğunsa dizi daha hızlı ve yalındır. C'de doğrusal yoklamalı küçük bir tablo (H10 Örnek 4), C++'ta std::unordered_map, Python'da dict (eş dosyalar). | `ciktilar/H13_K06_karma_memo_c.txt` | metin s. 9, 10, 36 | slayt metin: 15 | metin |
| `kavram/H13_K06_karma_memo.cpp` | C++ | Memo için iki araç: (1) DİZİ (std::vector, bütün hücreler baştan, −1 = hesaplanmadı); (2) std::unordered_map (H10'un kütüphane karşılığı): yalnız ziyaret edilen durumlar saklanır. Çıktı C ve Python sürümleriyle aynıdır. | `ciktilar/H13_K06_karma_memo_cpp.txt` | metin s. 9, 10, 36 | slayt metin: 15 | metin |
| `kavram/H13_K06_karma_memo.py` | Python | Memo için iki araç: (1) DİZİ (liste, bütün hücreler baştan, −1 = hesaplanmadı); (2) dict (H10'un kütüphane karşılığı; anahtar (i, t) demeti): yalnız ziyaret edilen durumlar saklanır. Çıktı C ve C++ sürümleriyle aynıdır. functools.cache de bir dict kullanır (Kavram 2). | `ciktilar/H13_K06_karma_memo_py.txt` | metin s. 9, 10, 36 | slayt metin: 15 | metin |
| `kavram/H13_K07_dag_yol.c` | C | DP = alt problem DAG'ında en kısa / en uzun yol. (1) Bozuk para {1, 3, 4}, tutar 6: düğüm t, kenar t → t + c (ağırlık 1). Düğümler topolojik sırayla (t artan) ele alınır ve H12'deki gibi kenarlar GEVŞETİLİR ("itme"); sonuç Örnek 3'ün "çekme" biçimli enaz tablosuyla aynıdır. (2) LIS: düğüm i, kenar j → i (j < i, a[j] < a[i]); en uzun yol = Örnek 7'nin uz dizisi. | `ciktilar/H13_K07_dag_yol.txt` | — | slayt metin: 16 | metin |


## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir. Belirtiler bu makinede, bu çalıştırmada gözlenmiştir (`hata_avcisi/ciktilar/`). HA5 tanımsız davranıştır: -O0 ve -O2 çıktıları farklıdır, UBSan raporu `H13_HA5_sonsuz_tasmasi_ubsan.txt` (yol sadeleştirilmiş).

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H13_HA1_temel_durum.c` | C | kasıtlı hata | en az para DP'sinde temel durumlar yanlış başlatılıyor. (a) Bütün tablo 0 ile başlıyor ("diğerleri ∞" unutulmuş): min hiç güncellenmez, her tutar "0 para" çıkar. (b) Tablo ∞ ile başlıyor ama enaz[0] = 0 unutulmuş: hiçbir tutar ulaşılamaz. | `ciktilar/H13_HA1_temel_durum.txt` | metin s. 8 | slayt metin: 48 | — |
| `hata_avcisi/H13_HA1_temel_durum_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H13_HA1_temel_durum_duzeltilmis.txt` | metin s. 8 | slayt metin: 48 | — |
| `hata_avcisi/H13_HA2_doldurma_sirasi.py` | Python | kasıtlı hata | matris zinciri tablosu satır satır (i artan, j artan) dolduruluyor. Oysa m[i][j], m[k+1][j]'ye (k+1 > i: DAHA AŞAĞIDAKİ bir satıra) bağlıdır; o hücre henüz 0'dır. Bağımlılıklara aykırı sıra sessizce yanlış (çok küçük) sonuç verir; hata vermez. | `ciktilar/H13_HA2_doldurma_sirasi.txt` | metin s. 8, 31, 35 | slayt metin: 48 | metin |
| `hata_avcisi/H13_HA2_doldurma_sirasi_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H13_HA2_doldurma_sirasi_duzeltilmis.txt` | metin s. 8, 31, 35 | slayt metin: 48 | metin |
| `hata_avcisi/H13_HA3_dongu_sirasi.cpp` | C++ | kasıtlı hata | soru "5 kuruş {1, 2, 5} paralarla kaç farklı para KÜMESİYLE ödenir?" (sıra önemsiz: 2+2+1 ile 1+2+2 aynı). Kod dış döngüde TUTARI dolaşıyor: her tutarda her para son para olabilir, yani aynı küme farklı sıralarla yeniden sayılır (permütasyon sayımı). | `ciktilar/H13_HA3_dongu_sirasi.txt` | metin s. 16 | slayt metin: 48 | metin |
| `hata_avcisi/H13_HA3_dongu_sirasi_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H13_HA3_dongu_sirasi_duzeltilmis.txt` | metin s. 16 | slayt metin: 48 | metin |
| `hata_avcisi/H13_HA4_artan_dolasma.c` | C | kasıtlı hata | tek satırlı 0/1 sırt çantasında kapasite ARTAN sırada dolaşılıyor. dp[w − a_i] bu turda aynı nesneyle zaten güncellenmiş olabildiği için nesne birden çok kez alınır: sonuç 0/1 değil, sınırsız sırt çantasının sonucudur (ve kapasiteyi aşmadan "olanaksız" bir değer raporlanır). | `ciktilar/H13_HA4_artan_dolasma.txt` | metin s. 25, 41 | slayt metin: 48 | metin |
| `hata_avcisi/H13_HA4_artan_dolasma_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H13_HA4_artan_dolasma_duzeltilmis.txt` | Bölüm 4.6; metin s. 25, 41 | slayt metin: 48 | metin |
| `hata_avcisi/H13_HA5_sonsuz_tasmasi.c` | C | kasıtlı hata | ∞ olarak INT_MAX seçilmiş ama geçişte enaz[t − c] + 1 hesaplanmadan önce ∞ denetimi YOK. Ulaşılamayan bir alt tutarda INT_MAX + 1 hesaplanır: işaretli taşma C'de TANIMSIZ DAVRANIŞTIR. Bu derleyicide, bu çalıştırmada sonuç genellikle INT_MIN'e sarar ve "−2147483648 para" gibi anlamsız değerler min'i kazanır. UBSan (-fsanitize=undefined) taşmayı çalışma anında yakalar. | `ciktilar/H13_HA5_sonsuz_tasmasi.txt` `ciktilar/H13_HA5_sonsuz_tasmasi_ubsan.txt` | Bölüm 7; metin s. 15, 29, 35, 36 | slayt kod: 49; metin: 48 | satır içi kod, metin |
| `hata_avcisi/H13_HA5_sonsuz_tasmasi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H13_HA5_sonsuz_tasmasi_duzeltilmis.txt` | metin s. 15, 29, 35, 36 | slayt kod: 49; metin: 48 | metin |
| `hata_avcisi/H13_HA6_memo_anahtari.py` | Python | kasıtlı hata | 0/1 sırt çantasının memo'lu (yukarıdan aşağıya) sürümünde alt problem (i, w) çiftidir, ama memo sözlüğünün anahtarı yalnız i. Aynı i için farklı kapasitelerle gelen çağrılar, ilk hesaplanan kapasitenin sonucunu "not alınmış" diye geri alır: sonuç sessizce yanlıştır. | `ciktilar/H13_HA6_memo_anahtari.txt` | metin s. 8, 10, 36 | slayt metin: 48 | satır içi kod, metin |
| `hata_avcisi/H13_HA6_memo_anahtari_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H13_HA6_memo_anahtari_duzeltilmis.txt` | metin s. 8, 10, 36 | slayt metin: 48 | metin |


## 4. Haftanın Deneyi (deney/)

Sürücü `python3 deney/h13_olcum_calistir.py` (derler, çalıştırır, ham CSV'leri ve `OLCUM_ORTAMI.txt`'yi yazar), çözümleme `python3 deney/h13_cozumle.py` (özet CSV/JSON: oranlar, katlar, eğimler, işaretli kestirimler), grafikler `python3 ../gorseller/kaynak/h13_deney_grafik.py`. Ortak modüllerin kopyaları `deney/{c,cpp,python}/` içindedir.

| Dosya | Dil | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `deney/c/H13_deney_doldurma.c` | C | Büyük LCS tablosunun SATIR öncelikli (i dışta, j içte) ve SÜTUN öncelikli (j dışta, i içte) doldurulması. İki sıra da bağımlılıklara uyar (L[i−1][j], L[i][j−1], L[i−1][j−1] önce hesaplanır) ve aynı tabloyu verir; tablo bellekte satır öncelikli (tek blok, L[i * (n+1) + j]) olduğundan sütun öncelikli dolaşma her adımda (n+1) * 4 bayt atlar (AP-1 H11). | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/c/H13_deney_strateji.c` | C | Fibonacci ve alt küme toplamında kaba kuvvet / geri izleme / memoization / tablolama: deterministik sayaçlar (çağrı, hücre, en büyük özyineleme derinliği, ayrılan bayt) stdout'a; süreler (1 ısınma + tekrar, ortanca) stderr'e | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/cpp/H13_deney_doldurma.cpp` | C++ | Büyük LCS tablosunun SATIR öncelikli (i dışta, j içte) ve SÜTUN öncelikli (j dışta, i içte) doldurulması. İki sıra da bağımlılıklara uyar ve aynı tabloyu verir; tablo tek bir std::vector<int> (satır öncelikli, L[i * (n+1) + j]) olduğundan sütun öncelikli dolaşma her adımda (n+1) * 4 bayt atlar. | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/cpp/H13_deney_strateji.cpp` | C++ | Fibonacci ve alt küme toplamında kaba kuvvet / geri izleme / memoization / tablolama: deterministik sayaçlar (çağrı, hücre, en büyük özyineleme derinliği, tablo verisi baytı) stdout'a; süreler (1 ısınma + tekrar, ortanca) stderr'e | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/python/H13_deney_doldurma.py` | Python | Büyük LCS tablosunun SATIR öncelikli (i dışta, j içte) ve SÜTUN öncelikli (j dışta, i içte) doldurulması. İki sıra da bağımlılıklara uyar ve aynı tabloyu verir. Python'da tablo, satırları ayrı listeler (Örnek 6); öğeler nesne başvurularıdır, bu yüzden önbellek etkisi yorumlayıcı maliyetinin altında kalır. | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/python/H13_deney_lru.py` | Python | functools.lru_cache / functools.cache ile elle yazılmış memo tablosunun (liste ve sözlük) karşılaştırılması: (1) özyineleme derinliği sınırı: varsayılan sys.getrecursionlimit() altında RecursionError vermeden hesaplanabilen en büyük n; (2) süre: soğuk önbellekle fib(450) (iki sınırın da altında) ve alt küme toplamı memo'su (1 ısınma + TEKRAR, ortanca); (3) bellek: tracemalloc tepe değeri ve önbellekteki girdi sayısı. lru_cache yalnız bu deneyde ve Dil Penceresi'nde kullanılır. | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/python/H13_deney_strateji.py` | Python | Fibonacci ve alt küme toplamında kaba kuvvet / geri izleme / memoization / tablolama: deterministik sayaçlar (çağrı, hücre, en büyük özyineleme derinliği, C eşdeğeri tablo baytı) stdout'a; süreler (1 ısınma + tekrar, ortanca) stderr'e. "bellek" 5. argümanıyla bir kez daha tracemalloc altında çalışıp Python'un gerçek tepe bellek kullanımını stderr'e yazar (CPython'a özgü). | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/h13_olcum_calistir.py` | Python | AP-2 Hafta 13 · Haftanın Deneyi sürücüsü | metin s. 32 | slayt metin: 46, 47 | metin |
| `deney/h13_cozumle.py` | Python | AP-2 Hafta 13 · Haftanın Deneyi çözümlemesi | metin s. 32 | slayt metin: 46, 47 | metin |

Ham ve özet veriler (`deney/sonuclar/`): `h13_denetim.json`, `h13_deney_doldurma.csv`, `h13_deney_lru.csv`, `h13_deney_strateji.csv`, `h13_ozet.json`, `h13_ozet_altkume.csv`, `h13_ozet_doldurma.csv`, `h13_ozet_fib.csv`; ölçüm ortamı `deney/OLCUM_ORTAMI.txt`.


## 5. Girdiler (girdiler/)

Kaynak ve telif bilgisi: `girdiler/KAYNAK_NOTU.txt`.

| Dosya | Açıklama |
|---|---|
| `girdiler/H13_09_duzenleme_uzakligi.txt` | Örnek 9 standart girdisi: kelime listesi, bayt sırasında, satır başına bir sözcük (30092 bayt) |
| `girdiler/H13_14_kelime_bolme.txt` | Örnek 14 standart girdisi: kelime listesi, bayt sırasında, satır başına bir sözcük (30092 bayt) |
| `girdiler/KAYNAK_NOTU.txt` | Girdilerin kaynağı, telif durumu ve yapılan dönüşümler |
| `girdiler/kelime_listesi_uret.py` | Örnek 9 ("Bunu mu demek istediniz?") ve Örnek 14 (kelime bölme) için sözlük. Kaynak, Hafta 10'un kamu malı Ömer Seyfettin metinleridir (omer_seyfettin_uc_oyku.txt; ayrıntı KAYNAK_NOTU.txt). |
| `girdiler/omer_seyfettin_uc_oyku.txt` | Ömer Seyfettin'in üç öyküsü (Diyet, Ferman, Forsa; kamu malı), kelime listesinin kaynağı |


## 6. Alıştırma ve quiz programları (alistirmalar/, quiz/)

Alıştırmaların ve quiz sorularının kodlu dosyaları. Çıktıları (`alistirmalar/ciktilar/`, `quiz/ciktilar/`) yanıt olduğu için öğrenci ZIP'inde yoktur. Parsons bulmacası (A10) bilerek derlenmez; “hata bul” dosyaları (A08, A09) kasıtlı mantık hatası içerir ama bellek açısından temizdir (ASan + Valgrind, `BELLEK_DENETIMI.txt`).

| Dosya | Dil | Kullanım | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `alistirmalar/H13_A01_merdiven_13.c` | C | Alıştırma 13.1 | Çıktı tahmini: her adımda 1 ya da 3 basamak çıkılan merdiven. Programı çalıştırmadan çıktının iki satırını yazın. | Alıştırma 13.1; metin s. 9, 39 | — | satır içi kod, metin |
| `alistirmalar/H13_A05_gizemli.c` | C | Alıştırma 13.5 | Karmaşıklık belirleme: iki "gizemli" fonksiyonun iç işlem sayısını n'ye göre kestirin; sayaçlarla doğrulayın. | Alıştırma 13.5; metin s. 40 | — | satır içi kod, metin |
| `alistirmalar/H13_A08_hata_bul_lcs.c` | C | Alıştırma 13.8 | LCS uzunluğu bazı girdilerde yanlış çıkıyor. Hatalı satırı bulun, çıktıdaki her yanlış değeri açıklayın ve düzeltin (Örnek 8'in lcs_tablo fonksiyonuyla karşılaştırın). | Alıştırma 13.8; metin s. 41 | — | satır içi kod, metin |
| `alistirmalar/H13_A09_hata_bul_memo.c` | C | Alıştırma 13.9 | engelli ızgarada (yalnız sağa ya da aşağı) hedefe giden yol sayısı memoization ile hesaplanıyor. Sonuçlar doğru, ama ikinci ızgarada çağrı sayısı beklenenin çok üstünde. Hatalı satırı bulun, nedenini açıklayın ve düzeltin; düzeltilmiş sürümün iki ızgarada kaç çağrı yapacağını önceden kestirin. | Alıştırma 13.9; metin s. 13, 36, 42 | — | satır içi kod, metin |
| `alistirmalar/H13_A10_parsons_lis.c` | C | Alıştırma 13.10 | Parsons: tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar en uzun (kesin) artan alt dizinin O(n²) DP fonksiyonunun KARIŞTIRILMIŞ satırlarıdır; iki satır fazladır (kullanılmayacak). Doğru sıraya dizin, girintiyi düzeltin; a = {5, 2, 8, 6, 3, 6, 9, 7} için dönen son indisin uzunluğu 4 olmalı (Örnek 7). | Alıştırma 13.10; metin s. 42 | — | satır içi kod, metin |
| `alistirmalar/H13_A15_satir_paylasimi.cpp` | C++ | Alıştırma 13.15 | Diller arası okuma: Python eşinin (H13_A15_satir_paylasimi.py) C++ karşılığı. Çalıştırmadan çıktıyı yazın. | metin s. 36, 43 | — | metin |
| `alistirmalar/H13_A15_satir_paylasimi.py` | Python | Alıştırma 13.15 | Diller arası okuma: aynı 2B tablo işlemleri Python'da ve C++'ta (eş dosya: H13_A15_satir_paylasimi.cpp). Çalıştırmadan iki programın çıktısını yazın. | Alıştırma 13.15; metin s. 36, 43 | — | satır içi kod, metin |
| `alistirmalar/H13_A16_buyuk_sayi.c` | C | Alıştırma 13.16 | Diller arası okuma: Pascal üçgeninin tek satırlık DP'si (C(n, k) = C(n−1, k−1) + C(n−1, k)) 32 bitlik işaretsiz tamsayıyla; eş dosya H13_A16_buyuk_sayi.py aynı hesabı Python tamsayısıyla yapar. Çalıştırmadan iki çıktının hangi satırlarda ayrılacağını kestirin. | Alıştırma 13.16; metin s. 44 | — | satır içi kod, metin |
| `alistirmalar/H13_A16_buyuk_sayi.py` | Python | Alıştırma 13.16 | Diller arası okuma: eş dosya H13_A16_buyuk_sayi.c'nin Python karşılığı (aynı tek satırlık Pascal DP'si, Python tamsayısıyla). Çalıştırmadan çıktıyı yazın. | metin s. 44 | — | metin |
| `alistirmalar/H13_A17_yazim_duzeltici.c` | C | Atölye 2 | "Bunu mu demek istediniz?": stdin'den sözlük (satır başına bir sözcük), komut satırından sorgular. Her sorgu için düzenleme (Levenshtein) uzaklığı en küçük k sözcük; eşitlikte bayt sırasında önce gelen. Uzaklık kod noktası düzeyinde (--bayt ile bayt düzeyinde); DP iki satırlık tamponla, Θ(m) bellek. Atölyede genişletilecek (budama, eşik, sayaçlar). | metin s. 3, 23, 45 | — | metin |
| `quiz/H13_Q02_dongu_sirasi.c` | C | web quiz sorusu 2 | Sayma DP'sinde döngü sırası (paralar {1, 2}, tutar 4) | — | — | satır içi kod |
| `quiz/H13_Q05_satir_paylasimi.py` | Python | web quiz sorusu 5 | 2B listenin [[0] * 3] * 2 ile kurulması | — | — | satır içi kod |
| `quiz/H13_Q06_tek_satir.c` | C | web quiz sorusu 6 | Tek satırlı sırt çantası, tek nesne (ağırlık 2, değer 3), W = 6 | — | — | satır içi kod |
| `quiz/H13_Q09_uint64.c` | C | web quiz sorusu 9 | uint64_t ile iki değişkenli Fibonacci, denetimsiz toplama | — | — | satır içi kod |


## 7. Diğer

- `BELLEK_DENETIMI.txt` — Valgrind (ve ASan) bellek denetimi sonuçları (betikle üretildi; doğrulama kanıtıdır).
- `ornekler.json` — örnek üst verisi (başlık, düzey, çıktı türü, fark satırları, Dil Penceresi notu).
- `esdeger_test.py` — eşdeğerlik testi (ortak; değiştirilmedi).

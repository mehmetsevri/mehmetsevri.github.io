/* H13_Q06_tek_satir.c — AP-2 Hafta 13 · Quiz 6
 * Amaç    : Tek satırlı sırt çantası, tek nesne (ağırlık 2, değer 3),
 *           W = 6
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_Q06_tek_satir.c -o H13_Q06_tek_satir
 */
#include <stdio.h>

int main(void)
{
    int dp[7] = {0};
    const int a = 2, d = 3, W = 6;
    for (int w = a; w <= W; w++) {
        if (dp[w - a] + d > dp[w]) {
            dp[w] = dp[w - a] + d;
        }
    }
    printf("%d\n", dp[W]);
    return 0;
}

"""H13_Q05_satir_paylasimi.py — AP-2 Hafta 13 · Quiz 5
Amaç    : 2B listenin [[0] * 3] * 2 ile kurulması
Çalıştır: python3 H13_Q05_satir_paylasimi.py
"""


def main():
    t = [[0] * 3] * 2
    t[1][0] = 9
    print(t)


if __name__ == "__main__":
    main()

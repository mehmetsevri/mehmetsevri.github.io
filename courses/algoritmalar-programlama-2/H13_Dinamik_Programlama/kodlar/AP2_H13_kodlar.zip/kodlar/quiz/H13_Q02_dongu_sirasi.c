/* H13_Q02_dongu_sirasi.c — AP-2 Hafta 13 · Quiz 2
 * Amaç    : Sayma DP'sinde döngü sırası (paralar {1, 2}, tutar 4)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_Q02_dongu_sirasi.c -o H13_Q02_dongu_sirasi
 */
#include <stdio.h>

int main(void)
{
    const int paralar[] = {1, 2};
    long long yol[5] = {1, 0, 0, 0, 0};
    for (int t = 1; t <= 4; t++) {
        for (int i = 0; i < 2; i++) {
            if (paralar[i] <= t) {
                yol[t] += yol[t - paralar[i]];
            }
        }
    }
    printf("%lld\n", yol[4]);
    return 0;
}

/* H13_Q09_uint64.c — AP-2 Hafta 13 · Quiz 9
 * Amaç    : uint64_t ile iki değişkenli Fibonacci, denetimsiz toplama
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_Q09_uint64.c -o H13_Q09_uint64
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    uint64_t onceki = 0, simdiki = 1;
    for (int i = 2; i <= 94; i++) {
        uint64_t sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    printf("%" PRIu64 " %d\n", simdiki, simdiki < onceki);
    return 0;
}

"""H13_HA2_doldurma_sirasi_duzeltilmis.py — AP-2 Hafta 13 · Hata Avcısı 2
Düzeltilmiş: hücre, bağımlı olduğu bütün hücrelerden SONRA doldurulur.
(1) Zincir uzunluğu l = 2..n: m[i][k] ve m[k+1][j] daha kısa aralıklardır.
(2) i AZALAN, j artan: m[k+1][j] aşağıdaki satırdadır (önce dolar),
m[i][k] aynı satırda soldadır (önce dolar). İkisi aynı sonucu verir.
Çalıştır: python3 H13_HA2_doldurma_sirasi_duzeltilmis.py
"""

SONSUZ = (1 << 63) - 1


def uzunluga_gore(p):
    n = len(p) - 1
    m = [[0] * (n + 1) for _ in range(n + 1)]
    for l in range(2, n + 1):              # kısa aralıklar önce
        for i in range(1, n - l + 2):
            j = i + l - 1
            m[i][j] = SONSUZ
            for k in range(i, j):
                q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j]
                if q < m[i][j]:
                    m[i][j] = q
    return m[1][n]


def i_azalan(p):
    n = len(p) - 1
    m = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(n, 0, -1):              # i AZALAN
        for j in range(i + 1, n + 1):      # j artan
            m[i][j] = SONSUZ
            for k in range(i, j):
                q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j]
                if q < m[i][j]:
                    m[i][j] = q
    return m[1][n]


def main():
    p = [30, 35, 15, 5, 10, 20, 25]
    print("p = {30, 35, 15, 5, 10, 20, 25} (Örnek 15; doğrusu 15125)")
    print(f"zincir uzunluğuna göre : m[1][6] = {uzunluga_gore(p)}")
    print(f"i azalan, j artan      : m[1][6] = {i_azalan(p)}")


if __name__ == "__main__":
    main()

/* H13_HA3_dongu_sirasi_duzeltilmis.cpp — AP-2 Hafta 13 · Hata Avcısı 3
 * Düzeltilmiş: dış döngü PARA. c parası işlenirken yol[t] yalnız ilk
 * paralarla (c dahil) yapılan ödemeleri sayar; böylece her küme paraların
 * dış döngüdeki sırasıyla TEK bir kez oluşur (kombinasyon sayımı).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_HA3_dongu_sirasi_duzeltilmis.cpp \
 *           -o H13_HA3_dongu_sirasi_duzeltilmis
 */
#include <iostream>
#include <vector>

int main()
{
    const std::vector<int> paralar = {1, 2, 5};
    const int S = 5;
    std::vector<long long> yol(S + 1, 0);
    yol[0] = 1;
    for (int c : paralar) {                // dış döngü para
        for (int t = c; t <= S; t++) {
            yol[t] += yol[t - c];
        }
    }
    std::cout << "paralar {1, 2, 5}, tutar 5: farklı para kümesi sayısı = "
              << yol[S] << " (doğrusu 4: 5, 2+2+1, 2+1+1+1, 1+1+1+1+1)\n";
    return 0;
}

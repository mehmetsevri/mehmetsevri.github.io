"""H13_HA6_memo_anahtari.py — AP-2 Hafta 13 · Hata Avcısı 6
BU DOSYA KASITLI HATA İÇERİR: 0/1 sırt çantasının memo'lu (yukarıdan
aşağıya) sürümünde alt problem (i, w) çiftidir, ama memo sözlüğünün
anahtarı yalnız i. Aynı i için farklı kapasitelerle gelen çağrılar, ilk
hesaplanan kapasitenin sonucunu "not alınmış" diye geri alır: sonuç
sessizce yanlıştır.
Doğrusu: anahtar durumun TAMAMI, (i, w) (bkz. _duzeltilmis.py).
Çalıştır: python3 H13_HA6_memo_anahtari.py
"""

a = [5, 4, 6, 3]                    # ağırlıklar (Örnek 10)
d = [10, 40, 30, 50]                # değerler
memo = {}


def en_iyi(i, w):
    """i..n-1 nesneleriyle w kapasitede en büyük değer"""
    if i == len(a):
        return 0
    if i in memo:                   # HATA: w anahtarda yok
        return memo[i]
    sonuc = en_iyi(i + 1, w)        # i'yi alma
    if a[i] <= w:                   # i'yi al
        al = d[i] + en_iyi(i + 1, w - a[i])
        if al > sonuc:
            sonuc = al
    memo[i] = sonuc
    return sonuc


def main():
    print("A(5, 10) B(4, 40) C(6, 30) D(3, 50), W = 10 (doğrusu 90)")
    print(f"memo anahtarı yalnız i: en büyük değer = {en_iyi(0, 10)}")
    print(f"memo içeriği (i -> değer): {dict(sorted(memo.items()))}")


if __name__ == "__main__":
    main()

/* H13_HA5_sonsuz_tasmasi.c — AP-2 Hafta 13 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR: ∞ olarak INT_MAX seçilmiş ama geçişte
 * enaz[t − c] + 1 hesaplanmadan önce ∞ denetimi YOK. Ulaşılamayan bir
 * alt tutarda INT_MAX + 1 hesaplanır: işaretli taşma C'de TANIMSIZ
 * DAVRANIŞTIR. Bu derleyicide, bu çalıştırmada sonuç genellikle INT_MIN'e
 * sarar ve "−2147483648 para" gibi anlamsız değerler min'i kazanır.
 * UBSan (-fsanitize=undefined) taşmayı çalışma anında yakalar.
 * Doğrusu: enaz[t − c] != SONSUZ denetimi (bkz. _duzeltilmis.c).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H13_HA5_sonsuz_tasmasi.c -o H13_HA5_sonsuz_tasmasi
 */
#include <limits.h>
#include <stdio.h>

#define S 12
#define SONSUZ INT_MAX

int main(void)
{
    const int paralar[] = {4, 6};
    int enaz[S + 1];
    enaz[0] = 0;
    for (int t = 1; t <= S; t++) {
        enaz[t] = SONSUZ;
        for (int i = 0; i < 2; i++) {
            int c = paralar[i];
            if (c <= t && enaz[t - c] + 1 < enaz[t]) {  /* HATA: ∞ + 1 */
                enaz[t] = enaz[t - c] + 1;
            }
        }
    }
    printf("paralar {4, 6}; tek tutarlar ulaşılamaz olmalı (∞)\n");
    for (int t = 0; t <= S; t++) {
        if (enaz[t] == SONSUZ) {
            printf("  enaz[%2d] = ∞\n", t);
        } else {
            printf("  enaz[%2d] = %d\n", t, enaz[t]);
        }
    }
    return 0;
}

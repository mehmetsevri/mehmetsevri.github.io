/* H13_HA1_temel_durum.c — AP-2 Hafta 13 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR: en az para DP'sinde temel durumlar
 * yanlış başlatılıyor. (a) Bütün tablo 0 ile başlıyor ("diğerleri ∞"
 * unutulmuş): min hiç güncellenmez, her tutar "0 para" çıkar. (b) Tablo
 * ∞ ile başlıyor ama enaz[0] = 0 unutulmuş: hiçbir tutar ulaşılamaz.
 * Doğrusu: enaz[0] = 0, diğerleri ∞ (bkz. _duzeltilmis.c).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_HA1_temel_durum.c -o H13_HA1_temel_durum
 */
#include <limits.h>
#include <stdio.h>

#define S 6
#define SONSUZ INT_MAX

static const int paralar[] = {1, 3, 4};

static void doldur(int enaz[])
{
    for (int t = 1; t <= S; t++) {
        for (int i = 0; i < 3; i++) {
            int c = paralar[i];
            if (c <= t && enaz[t - c] != SONSUZ &&
                enaz[t - c] + 1 < enaz[t]) {
                enaz[t] = enaz[t - c] + 1;
            }
        }
    }
}

static void yaz(const char *ad, const int enaz[])
{
    printf("%s:", ad);
    for (int t = 0; t <= S; t++) {
        if (enaz[t] == SONSUZ) {
            printf("  ∞");
        } else {
            printf(" %2d", enaz[t]);
        }
    }
    printf("   -> tutar 6 için en az para: ");
    if (enaz[S] == SONSUZ) {
        printf("ulaşılamaz\n");
    } else {
        printf("%d\n", enaz[S]);
    }
}

int main(void)
{
    int enaz[S + 1];
    printf("paralar {1, 3, 4}, t = 0..6 (doğrusu: 0 1 2 1 1 2 2)\n");

    for (int t = 0; t <= S; t++) {
        enaz[t] = 0;               /* HATA (a): diğerleri ∞ olmalıydı */
    }
    doldur(enaz);
    yaz("(a) hepsi 0     ", enaz);

    for (int t = 0; t <= S; t++) {
        enaz[t] = SONSUZ;          /* HATA (b): enaz[0] = 0 unutuldu */
    }
    doldur(enaz);
    yaz("(b) enaz[0] = ∞ ", enaz);
    return 0;
}

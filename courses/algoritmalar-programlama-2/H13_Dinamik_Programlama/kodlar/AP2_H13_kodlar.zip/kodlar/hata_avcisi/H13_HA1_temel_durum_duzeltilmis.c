/* H13_HA1_temel_durum_duzeltilmis.c — AP-2 Hafta 13 · Hata Avcısı 1
 * Düzeltilmiş: temel durum enaz[0] = 0 (sıfır tutar sıfır parayla
 * ödenir), diğer bütün hücreler ∞ (henüz ulaşılamadı) ile başlar; min
 * ancak gerçek bir adayla küçülür.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_HA1_temel_durum_duzeltilmis.c \
 *           -o H13_HA1_temel_durum_duzeltilmis
 */
#include <limits.h>
#include <stdio.h>

#define S 6
#define SONSUZ INT_MAX

static const int paralar[] = {1, 3, 4};

static void doldur(int enaz[])
{
    for (int t = 1; t <= S; t++) {
        for (int i = 0; i < 3; i++) {
            int c = paralar[i];
            if (c <= t && enaz[t - c] != SONSUZ &&
                enaz[t - c] + 1 < enaz[t]) {
                enaz[t] = enaz[t - c] + 1;
            }
        }
    }
}

static void yaz(const char *ad, const int enaz[])
{
    printf("%s:", ad);
    for (int t = 0; t <= S; t++) {
        if (enaz[t] == SONSUZ) {
            printf("  ∞");
        } else {
            printf(" %2d", enaz[t]);
        }
    }
    printf("   -> tutar 6 için en az para: ");
    if (enaz[S] == SONSUZ) {
        printf("ulaşılamaz\n");
    } else {
        printf("%d\n", enaz[S]);
    }
}

int main(void)
{
    int enaz[S + 1];
    printf("paralar {1, 3, 4}, t = 0..6 (doğrusu: 0 1 2 1 1 2 2)\n");
    enaz[0] = 0;                   /* temel durum */
    for (int t = 1; t <= S; t++) {
        enaz[t] = SONSUZ;          /* diğerleri ∞ */
    }
    doldur(enaz);
    yaz("doğru başlatma  ", enaz);
    return 0;
}

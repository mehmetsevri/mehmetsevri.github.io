/* H13_HA3_dongu_sirasi.cpp — AP-2 Hafta 13 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR: soru "5 kuruş {1, 2, 5} paralarla kaç
 * farklı para KÜMESİYLE ödenir?" (sıra önemsiz: 2+2+1 ile 1+2+2 aynı).
 * Kod dış döngüde TUTARI dolaşıyor: her tutarda her para son para olabilir,
 * yani aynı küme farklı sıralarla yeniden sayılır (permütasyon sayımı).
 * Doğrusu: dış döngü PARA, iç döngü tutar (bkz. _duzeltilmis.cpp).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_HA3_dongu_sirasi.cpp -o H13_HA3_dongu_sirasi
 */
#include <iostream>
#include <vector>

int main()
{
    const std::vector<int> paralar = {1, 2, 5};
    const int S = 5;
    std::vector<long long> yol(S + 1, 0);
    yol[0] = 1;
    for (int t = 1; t <= S; t++) {         // HATA: dış döngü tutar
        for (int c : paralar) {
            if (c <= t) {
                yol[t] += yol[t - c];
            }
        }
    }
    std::cout << "paralar {1, 2, 5}, tutar 5: farklı para kümesi sayısı = "
              << yol[S] << " (doğrusu 4: 5, 2+2+1, 2+1+1+1, 1+1+1+1+1)\n";
    return 0;
}

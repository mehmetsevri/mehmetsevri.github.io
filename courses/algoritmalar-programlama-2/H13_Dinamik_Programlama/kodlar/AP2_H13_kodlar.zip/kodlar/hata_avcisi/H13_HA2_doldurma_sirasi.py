"""H13_HA2_doldurma_sirasi.py — AP-2 Hafta 13 · Hata Avcısı 2
BU DOSYA KASITLI HATA İÇERİR: matris zinciri tablosu satır satır (i artan,
j artan) dolduruluyor. Oysa m[i][j], m[k+1][j]'ye (k+1 > i: DAHA AŞAĞIDAKİ
bir satıra) bağlıdır; o hücre henüz 0'dır. Bağımlılıklara aykırı sıra
sessizce yanlış (çok küçük) sonuç verir; hata vermez.
Doğrusu: zincir uzunluğu l = 2..n (kısa aralıklar önce) ya da i AZALAN,
j artan (bkz. _duzeltilmis.py).
Çalıştır: python3 H13_HA2_doldurma_sirasi.py
"""

SONSUZ = (1 << 63) - 1


def matris_zinciri(p):
    n = len(p) - 1
    m = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):              # HATA: i artan
        for j in range(i + 1, n + 1):
            m[i][j] = SONSUZ
            for k in range(i, j):
                # m[k + 1][j] (k + 1 > i) henüz hesaplanmadı: 0 okunur
                q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j]
                if q < m[i][j]:
                    m[i][j] = q
    return m[1][n]


def main():
    p = [30, 35, 15, 5, 10, 20, 25]
    print("p = {30, 35, 15, 5, 10, 20, 25} (Örnek 15; doğrusu 15125)")
    print(f"satır satır doldurulan tablo: m[1][6] = {matris_zinciri(p)}")


if __name__ == "__main__":
    main()

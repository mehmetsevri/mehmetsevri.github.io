/* H13_HA4_artan_dolasma_duzeltilmis.c — AP-2 Hafta 13 · Hata Avcısı 4
 * Düzeltilmiş: kapasite TERS sırada (W..a_i) dolaşılır; dp[w − a_i] daha
 * küçük bir kapasitedir ve bu turda henüz güncellenmemiştir, yani tam
 * tablonun önceki satırıdır: her nesne en çok bir kez alınır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_HA4_artan_dolasma_duzeltilmis.c \
 *           -o H13_HA4_artan_dolasma_duzeltilmis
 */
#include <stdio.h>

#define W 10

int main(void)
{
    const int a[] = {5, 4, 6, 3}, d[] = {10, 40, 30, 50};
    int dp[W + 1] = {0};
    for (int i = 0; i < 4; i++) {
        for (int w = W; w >= a[i]; w--) {  /* ters */
            if (dp[w - a[i]] + d[i] > dp[w]) {
                dp[w] = dp[w - a[i]] + d[i];
            }
        }
    }
    printf("A(5, 10) B(4, 40) C(6, 30) D(3, 50), W = 10\n");
    printf("tek satır, ters dolaşma: en büyük değer = %d (doğrusu 90: "
           "B + D)\n", dp[W]);
    printf("dp[9] = %d: her nesne en çok bir kez\n", dp[9]);
    return 0;
}

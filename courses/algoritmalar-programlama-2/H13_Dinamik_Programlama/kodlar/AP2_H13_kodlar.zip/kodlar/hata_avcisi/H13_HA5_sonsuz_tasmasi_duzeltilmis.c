/* H13_HA5_sonsuz_tasmasi_duzeltilmis.c — AP-2 Hafta 13 · Hata Avcısı 5
 * Düzeltilmiş: ∞ hücreye 1 EKLENMEZ — önce enaz[t − c] != SONSUZ
 * denetlenir (kısa devre: && sağ tarafı yalnız sol doğruysa hesaplanır).
 * Başka bir çözüm SONSUZ = INT_MAX / 2 seçmektir (∞ + 1 taşmaz), ama
 * toplamaların birikmediğinden emin olmak gerekir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *           H13_HA5_sonsuz_tasmasi_duzeltilmis.c \
 *           -o H13_HA5_sonsuz_tasmasi_duzeltilmis
 */
#include <limits.h>
#include <stdio.h>

#define S 12
#define SONSUZ INT_MAX

int main(void)
{
    const int paralar[] = {4, 6};
    int enaz[S + 1];
    enaz[0] = 0;
    for (int t = 1; t <= S; t++) {
        enaz[t] = SONSUZ;
        for (int i = 0; i < 2; i++) {
            int c = paralar[i];
            if (c <= t && enaz[t - c] != SONSUZ &&
                enaz[t - c] + 1 < enaz[t]) {
                enaz[t] = enaz[t - c] + 1;
            }
        }
    }
    printf("paralar {4, 6}; tek tutarlar ulaşılamaz olmalı (∞)\n");
    for (int t = 0; t <= S; t++) {
        if (enaz[t] == SONSUZ) {
            printf("  enaz[%2d] = ∞\n", t);
        } else {
            printf("  enaz[%2d] = %d\n", t, enaz[t]);
        }
    }
    return 0;
}

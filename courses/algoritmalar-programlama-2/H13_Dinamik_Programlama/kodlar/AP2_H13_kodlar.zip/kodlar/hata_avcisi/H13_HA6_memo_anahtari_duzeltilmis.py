"""H13_HA6_memo_anahtari_duzeltilmis.py — AP-2 Hafta 13 · Hata Avcısı 6
Düzeltilmiş: memo anahtarı durumun TAMAMI, (i, w) demeti. Demet
değiştirilemez (immutable) olduğu için sözlük anahtarı olabilir (H10).
Kural: fonksiyonun sonucunu etkileyen her parametre anahtarda olmalıdır.
Çalıştır: python3 H13_HA6_memo_anahtari_duzeltilmis.py
"""

a = [5, 4, 6, 3]                    # ağırlıklar (Örnek 10)
d = [10, 40, 30, 50]                # değerler
memo = {}


def en_iyi(i, w):
    """i..n-1 nesneleriyle w kapasitede en büyük değer"""
    if i == len(a):
        return 0
    if (i, w) in memo:              # anahtar: durumun tamamı
        return memo[(i, w)]
    sonuc = en_iyi(i + 1, w)        # i'yi alma
    if a[i] <= w:                   # i'yi al
        al = d[i] + en_iyi(i + 1, w - a[i])
        if al > sonuc:
            sonuc = al
    memo[(i, w)] = sonuc
    return sonuc


def main():
    print("A(5, 10) B(4, 40) C(6, 30) D(3, 50), W = 10 (doğrusu 90)")
    print(f"memo anahtarı (i, w): en büyük değer = {en_iyi(0, 10)}")
    print(f"memo'daki farklı durum sayısı = {len(memo)}")


if __name__ == "__main__":
    main()

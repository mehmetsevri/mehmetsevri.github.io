/* H13_HA4_artan_dolasma.c — AP-2 Hafta 13 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR: tek satırlı 0/1 sırt çantasında kapasite
 * ARTAN sırada dolaşılıyor. dp[w − a_i] bu turda aynı nesneyle zaten
 * güncellenmiş olabildiği için nesne birden çok kez alınır: sonuç 0/1
 * değil, sınırsız sırt çantasının sonucudur (ve kapasiteyi aşmadan
 * "olanaksız" bir değer raporlanır).
 * Doğrusu: w = W, W−1, …, a_i (TERS) (bkz. _duzeltilmis.c).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_HA4_artan_dolasma.c -o H13_HA4_artan_dolasma
 */
#include <stdio.h>

#define W 10

int main(void)
{
    const int a[] = {5, 4, 6, 3}, d[] = {10, 40, 30, 50};
    int dp[W + 1] = {0};
    for (int i = 0; i < 4; i++) {
        for (int w = a[i]; w <= W; w++) {  /* HATA: artan */
            if (dp[w - a[i]] + d[i] > dp[w]) {
                dp[w] = dp[w - a[i]] + d[i];
            }
        }
    }
    printf("A(5, 10) B(4, 40) C(6, 30) D(3, 50), W = 10\n");
    printf("tek satır, artan dolaşma: en büyük değer = %d (doğrusu 90: "
           "B + D)\n", dp[W]);
    printf("dp[9] = %d: D üç kez alınmış (3 + 3 + 3 = 9, 50 * 3)\n",
           dp[9]);
    return 0;
}

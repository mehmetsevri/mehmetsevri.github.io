"""H13_08_lcs.py — AP-2 Hafta 13 · Örnek 8 (★★★)
Amaç    : En uzun ortak alt dizi (LCS): tablo, ortak alt dizinin geri
          çıkarılması (yol çizimi), satır düzeyinde diff (LCS dışında
          kalan satırlar silinir/eklenir) ve rastgele DNA dizileri
DP      : durum L[i][j] = a[0..i) ile b[0..j)'nin LCS uzunluğu · geçiş
          a[i−1] = b[j−1] ise L[i−1][j−1] + 1, değilse max(L[i−1][j],
          L[i][j−1]) · temel L[0][j] = L[i][0] = 0 · sıra satır
          öncelikli (i artan, j artan) · cevap L[n][m] · geri çıkarma
          (n, m)'den: eşitse ÇAPRAZ; değilse L[i−1][j] >= L[i][j−1]
          ise YUKARI, yoksa SOL (eşitlikte önce yukarı)
Çalıştır: python3 H13_08_lcs.py
Eşleri  : c/H13_08_lcs.c · cpp/H13_08_lcs.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


def lcs_tablo(a, b):
    """L[i][j] tablosu; her satır ayrı liste (Örnek 6)"""
    n, m = len(a), len(b)
    L = [[0] * (m + 1) for _ in range(n + 1)]  # L[0][j] = L[i][0] = 0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if a[i - 1] == b[j - 1]:
                L[i][j] = L[i - 1][j - 1] + 1
            elif L[i - 1][j] >= L[i][j - 1]:
                L[i][j] = L[i - 1][j]
            else:
                L[i][j] = L[i][j - 1]
    return L


def lcs_geri_cikar(L, a, b, yol):
    """Geri çıkarma: ortak alt dizi; yol hücre işaretleri (0 yok,
    1 çapraz, 2 yukarı, 3 sol), None olabilir"""
    i, j = len(a), len(b)
    cikti = []
    while i > 0 and j > 0:
        if a[i - 1] == b[j - 1]:
            cikti.append(a[i - 1])
            if yol is not None:
                yol[i][j] = 1
            i -= 1
            j -= 1
        elif L[i - 1][j] >= L[i][j - 1]:
            if yol is not None:
                yol[i][j] = 2       # önce yukarı
            i -= 1
        else:
            if yol is not None:
                yol[i][j] = 3
            j -= 1
    cikti.reverse()
    return "".join(cikti)


def alt_dizi_mi(x, y):
    """x, y'nin alt dizisi mi? (iki işaretçi)"""
    k = 0
    for c in y:
        if k < len(x) and x[k] == c:
            k += 1
    return k == len(x)


def satir_diff(eski, yeni):
    """Satır diff: satırlar üzerinde aynı DP (eşitlik = str ==)"""
    n, m = len(eski), len(yeni)
    L = lcs_tablo(eski, yeni)
    islem, satir = [], []
    i, j = n, m                     # sondan başa
    while i > 0 or j > 0:
        if i > 0 and j > 0 and eski[i - 1] == yeni[j - 1]:
            i -= 1
            j -= 1
            islem.append(" ")
            satir.append(i)
        elif i > 0 and (j == 0 or L[i - 1][j] >= L[i][j - 1]):
            i -= 1
            islem.append("-")
            satir.append(i)
        else:
            j -= 1
            islem.append("+")
            satir.append(j)
    print(f"  ortak satır = L[{n}][{m}] = {L[n][m]}; silinen "
          f"{n - L[n][m]}, eklenen {m - L[n][m]}")
    for x in range(len(islem) - 1, -1, -1):     # baştan sona yaz
        metin = yeni[satir[x]] if islem[x] == "+" else eski[satir[x]]
        print(f"    {islem[x]} {metin}")


def main():
    a, b = "ABCBDAB", "BDCABA"
    n, m = len(a), len(b)
    print(f"1) a = \"{a}\", b = \"{b}\" (Cormen vd. örneği)")
    L = lcs_tablo(a, b)
    yol = [[0] * (m + 1) for _ in range(n + 1)]
    lcs = lcs_geri_cikar(L, a, b, yol)
    print("  L tablosu (satır: a'nın önekleri; sütun: b'nin önekleri)")
    print("     \"\"" + "".join(f"  {c}" for c in b))
    for i in range(n + 1):
        bas = "  \"\"" if i == 0 else f"   {a[i - 1]}"
        print(bas + "".join(f" {L[i][j]:2d}" for j in range(m + 1)))
    print(f"  LCS uzunluğu = L[{n}][{m}] = {len(lcs)}; hücre = (n+1)(m+1) = "
          f"{(n + 1) * (m + 1)}")
    print("  geri çıkarma yolu (↖ eşleşme, ↑ yukarı, ← sol; eşitlikte ↑):")
    ok = [" .", " ↖", " ↑", " ←"]
    for i in range(n + 1):
        print("    " + "".join(" " + ok[yol[i][j]] for j in range(m + 1)))
    print(f"  ortak alt dizi = \"{lcs}\"; a'nın alt dizisi: "
          f"{'evet' if alt_dizi_mi(lcs, a) else 'HAYIR'}, b'nin: "
          f"{'evet' if alt_dizi_mi(lcs, b) else 'HAYIR'}")

    print("\n2) Satır düzeyinde diff (LCS'de olmayan: - silinen, + eklenen)")
    eski = ["Rize çayı demlenir.", "Su kaynatılır.", "Demlik ısıtılır.",
            "Çay demliğe konur.", "On beş dakika beklenir."]
    yeni = ["Su kaynatılır.", "Demlik ısıtılır.", "Çay demliğe konur.",
            "Üstüne kaynar su eklenir.", "On beş dakika beklenir.",
            "İnce belli bardakta sunulur."]
    satir_diff(eski, yeni)

    print("\n3) Rastgele DNA (A C G T; tohum 7), n = m = 300")
    harf = "ACGT"
    rastgele_tohum(7)
    x = "".join(harf[rastgele_aralik(0, 3)] for _ in range(300))
    y = "".join(harf[rastgele_aralik(0, 3)] for _ in range(300))
    D = lcs_tablo(x, y)
    ortak = lcs_geri_cikar(D, x, y, None)
    print(f"  x[0..39] = {x[:40]}\n  y[0..39] = {y[:40]}")
    print(f"  LCS uzunluğu = {len(ortak)} (oran {len(ortak) / 300.0:.4f}); "
          f"hücre = {301 * 301}")
    iki = alt_dizi_mi(ortak, x) and alt_dizi_mi(ortak, y)
    print(f"  LCS[0..39] = {ortak[:40]}; x'in ve y'nin alt dizisi: "
          f"{'evet' if iki else 'HAYIR'}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++); Python — difflib.SequenceMatcher
# LCS değil (Ratcliff/Obershelp benzeri) eşleme yapar; diff aracı Hunt ve
# McIlroy'un (1976) LCS tabanlı yöntemine dayanır.

"""H13_15_matris_zinciri.py — AP-2 Hafta 13 · Örnek 15 (★★★, meydan okuma)
Amaç    : Matris zinciri çarpımı (aralık DP'si): A1·A2·…·An çarpımı için
          skaler çarpım sayısını en aza indiren parantezleme; m ve s
          tabloları, parantezlemenin geri çıkarılması; kaba kuvvet
          özyinelemeyle (3^(n−1) çağrı) ve soldan sağa çarpımla kıyas
DP      : durum m[i][j] = Ai..Aj çarpımının en az skaler çarpımı (Ai:
          p[i−1] × p[i]) · geçiş m[i][j] = min_{i<=k<j} m[i][k] +
          m[k+1][j] + p[i−1]·p[k]·p[j] · temel m[i][i] = 0 · sıra
          zincir uzunluğu l = 2..n (kısa aralıklar önce), i artan ·
          cevap m[1][n] · geri çıkarma s[i][j] = en iyi k (eşitlikte EN
          KÜÇÜK k); parantez(i, j) = (parantez(i, s) parantez(s+1, j))
Çalıştır: python3 H13_15_matris_zinciri.py
Eşleri  : c/H13_15_matris_zinciri.c · cpp/H13_15_matris_zinciri.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_dizi, rastgele_tohum

SONSUZ = (1 << 63) - 1              # C'deki LLONG_MAX
m, s = [], []
denenen_k = 0                       # iç döngü adımı
cagri = 0                           # kaba kuvvet çağrısı


def matris_zinciri(p):
    """Aralık DP'si: m[1..n][1..n], s[1..n][1..n]"""
    global m, s, denenen_k
    n = len(p) - 1
    m = [[0] * (n + 1) for _ in range(n + 1)]     # m[i][i] = 0
    s = [[0] * (n + 1) for _ in range(n + 1)]
    for l in range(2, n + 1):       # zincir uzunluğu
        for i in range(1, n - l + 2):
            j = i + l - 1
            m[i][j] = SONSUZ
            for k in range(i, j):
                denenen_k += 1
                q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j]
                if q < m[i][j]:     # eşitlikte küçük k
                    m[i][j] = q
                    s[i][j] = k
    return m[1][n]


def parantez(i, j):
    if i == j:
        return f"A{i}"
    return "(" + parantez(i, s[i][j]) + parantez(s[i][j] + 1, j) + ")"


def kaba(p, i, j):
    """Kâhin: kaba kuvvet özyineleme — bütün bölme noktaları, not yok"""
    global cagri
    cagri += 1
    if i == j:
        return 0
    en = SONSUZ
    for k in range(i, j):
        q = kaba(p, i, k) + kaba(p, k + 1, j) + p[i - 1] * p[k] * p[j]
        if q < en:
            en = q
    return en


def soldan_saga(p):
    """Soldan sağa: (((A1 A2) A3) ...) maliyeti"""
    toplam = 0
    for k in range(2, len(p)):
        toplam += p[0] * p[k - 1] * p[k]
    return toplam


def parantezleme_sayisi(n):
    """P(n) = Σ P(k) P(n−k) (Catalan sayısı C(n−1))"""
    P = [0] * (n + 1)
    P[1] = 1
    for t in range(2, n + 1):
        for k in range(1, t):
            P[t] += P[k] * P[t - k]
    return P[n]


def coz_ve_yaz(p, tablolari_yaz):
    global denenen_k, cagri
    n = len(p) - 1
    denenen_k = 0
    en = matris_zinciri(p)
    if tablolari_yaz:
        print("  m[i][j] (en az skaler çarpım; i > j boş)")
        print("    i\\j" + "".join(f" {j:7d}" for j in range(1, n + 1)))
        for i in range(1, n + 1):
            print(f"  {i:4d} " + "".join(
                "        " if j < i else f" {m[i][j]:7d}"
                for j in range(1, n + 1)))
        print("  s[i][j] (en iyi bölme k)")
        print("    i\\j" + "".join(f" {j:3d}" for j in range(2, n + 1)))
        for i in range(1, n):
            print(f"  {i:4d} " + "".join(
                "    " if j <= i else f" {s[i][j]:3d}"
                for j in range(2, n + 1)))
    sol = soldan_saga(p)
    print(f"  en az = m[1][{n}] = {en}; parantezleme: {parantez(1, n)}")
    print(f"  soldan sağa çarpım = {sol} ({sol / en:.2f} kat)")
    print(f"  DP: hücre (i <= j) = {n * (n + 1) // 2}, denenen k = "
          f"{denenen_k} = (n^3 - n)/6")
    cagri = 0
    k = kaba(p, 1, n)
    print(f"  kaba kuvvet: {cagri} çağrı (= 3^(n-1)), sonuç {k} "
          f"({'aynı' if k == en else 'FARKLI'}); parantezleme sayısı = "
          f"{parantezleme_sayisi(n)}")


def main():
    p1 = [30, 35, 15, 5, 10, 20, 25]
    print("1) p = {30, 35, 15, 5, 10, 20, 25} (Cormen vd.): A1..A6, "
          "Ai = p[i-1] x p[i]")
    coz_ve_yaz(p1, True)

    rastgele_tohum(9)
    p2 = rastgele_dizi(13, 5, 50)
    print("\n2) 12 matris, boyutlar (tohum 9, 5..50): p = "
          + " ".join(str(x) for x in p2))
    coz_ve_yaz(p2, False)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). NumPy'nin
# numpy.linalg.multi_dot'u aynı DP ile çarpma sırası seçer (ders dışı;
# yalnız standart kütüphane kullanılır).

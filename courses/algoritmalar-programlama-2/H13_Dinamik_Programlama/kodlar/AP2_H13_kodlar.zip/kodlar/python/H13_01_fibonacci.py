"""H13_01_fibonacci.py — AP-2 Hafta 13 · Örnek 1 (★)
Amaç    : Fibonacci'nin dört sürümü: saf özyineleme (çağrı sayısı
          2·F(n+1) − 1, denetlenir), memo ("hesaplanmadı" = −1), tablo
          ve iki değişken; büyük n için uint64_t sınırı ve mod 10^9 + 7
DP      : durum F(i) · geçiş F(i) = F(i−1) + F(i−2) · temel F(0) = 0,
          F(1) = 1 · sıra i = 2, 3, …, n (artan) · cevap tablo[n]
Çalıştır: python3 H13_01_fibonacci.py
Eşleri  : c/H13_01_fibonacci.c · cpp/H13_01_fibonacci.cpp
Çıktı   : üç dilde aynı (=)
"""

MAKS_N = 100
MOD = 1000000007
UINT64_MAX = (1 << 64) - 1          # Python tamsayısı taşmaz: sınır elle

cagri = 0                           # fonksiyon çağrısı sayacı
hesaplanan = 0                      # memo'ya ilk kez yazılan hücre
memo = [-1] * (MAKS_N + 1)


def fib_saf(n):
    """1) Saf özyineleme: aynı alt problemler tekrar tekrar çözülür"""
    global cagri
    cagri += 1
    if n < 2:
        return n                    # temel durum
    return fib_saf(n - 1) + fib_saf(n - 2)


def fib_memo(i):
    """2) Memo (yukarıdan aşağıya): memo[i] == -1 "hesaplanmadı" demektir"""
    global cagri, hesaplanan
    cagri += 1
    if memo[i] != -1:
        return memo[i]              # not alınmış: yeniden çözme
    if i < 2:
        memo[i] = i
    else:
        memo[i] = fib_memo(i - 1) + fib_memo(i - 2)
    hesaplanan += 1
    return memo[i]


def fib_tablo(n):
    """3) Tablo (aşağıdan yukarıya): tablo[0..n], Θ(n) zaman ve bellek"""
    tablo = [0] * (n + 2)
    tablo[0] = 0
    tablo[1] = 1
    for i in range(2, n + 1):
        tablo[i] = tablo[i - 1] + tablo[i - 2]
    return tablo


def fib_iki(n):
    """4) İki değişken: yalnız son iki değer tutulur, O(1) bellek"""
    onceki, simdiki = 0, 1          # F(0), F(1)
    if n == 0:
        return 0
    for _ in range(2, n + 1):
        onceki, simdiki = simdiki, onceki + simdiki
    return simdiki


def fib_u64(n):
    """uint64_t ile F(n) benzetimi; taşacaksa (0, True) döndürür"""
    onceki, simdiki = 0, 1
    if n == 0:
        return 0, False
    for _ in range(2, n + 1):
        if onceki > UINT64_MAX - simdiki:   # toplamadan ÖNCE denetim
            return 0, True
        onceki, simdiki = simdiki, onceki + simdiki
    return simdiki, False


def fib_mod(n):
    """F(n) mod 10^9 + 7, iki değişkenle: her toplamadan sonra mod"""
    onceki, simdiki = 0, 1
    if n == 0:
        return 0
    for _ in range(2, n + 1):
        onceki, simdiki = simdiki, (onceki + simdiki) % MOD
    return simdiki


def memo_sifirla(n):
    global cagri, hesaplanan
    for i in range(n + 1):
        memo[i] = -1
    cagri = 0
    hesaplanan = 0


def main():
    global cagri
    ns = [0, 1, 2, 5, 10, 15, 20, 25]
    tablo = fib_tablo(MAKS_N - 10)

    print("1) Saf özyineleme: çağrı sayısı = 2·F(n+1) − 1 mi?")
    print("   n       F(n)      çağrı  2·F(n+1)−1  eşit")
    for n in ns:
        cagri = 0
        f = fib_saf(n)
        beklenen = 2 * tablo[n + 1] - 1
        print(f"  {n:2d} {f:10d} {cagri:10d} {beklenen:11d}  "
              f"{'evet' if cagri == beklenen else 'HAYIR'}")
    cagri = 0
    fib_saf(24)
    onceki_cagri = cagri
    cagri = 0
    fib_saf(25)
    print(f"  çağrı(25) / çağrı(24) = {cagri / onceki_cagri:.4f}  "
          f"(φ ≈ 1.6180: Θ(φ^n) büyüme)")

    print("\n2) Memo (yukarıdan aşağıya), \"hesaplanmadı\" = -1")
    print("   n       F(n)  çağrı  hesaplanan  not isabeti")
    for n in ns[2:]:
        memo_sifirla(n)
        f = fib_memo(n)
        print(f"  {n:2d} {f:10d} {cagri:6d} {hesaplanan:11d} "
              f"{cagri - hesaplanan:12d}")
    memo_sifirla(6)
    fib_memo(6)
    print("  fib_memo(6) sonrası memo[0..6] =", end="")
    for i in range(7):
        print(f" {memo[i]}", end="")
    print("\n  (n >= 2 için çağrı = 2n − 1, hesaplanan = n + 1)")

    print("\n3) Tablo (aşağıdan yukarıya): tablo[i] = tablo[i-1] + "
          "tablo[i-2]\n  i   :", end="")
    for i in range(16):
        print(f" {i:4d}", end="")
    print("\n  F(i):", end="")
    for i in range(16):
        print(f" {tablo[i]:4d}", end="")
    print(f"\n  n = 25: hücre = n + 1 = 26, F(25) = {tablo[25]}")

    print(f"\n4) İki değişken (O(1) bellek): F(25) = {fib_iki(25)}, "
          f"F(90) = {fib_iki(90)}")
    dogru = True
    for n in range(91):
        if fib_iki(n) != tablo[n]:
            dogru = False
    print(f"  n = 0..90 için iki değişken = tablo: "
          f"{'evet' if dogru else 'HAYIR'}")

    print(f"\n5) Büyük n: uint64_t sınırı (2^64 − 1 = {UINT64_MAX})")
    for n in range(92, 95):
        f, tasti = fib_u64(n)
        if tasti:
            print(f"  F({n}): uint64_t'ye SIĞMAZ (toplama öncesi denetim)")
        else:
            print(f"  F({n}) = {f}")

    print("\n6) mod 10^9 + 7 ile (iki değişken, her adımda mod)")
    for n in (94, 100, 1000, 1000000):
        print(f"  F({n}) mod 1000000007 = {fib_mod(n)}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C). C++ — yok; Python — functools.cache /
# lru_cache dekoratörü memo'yu kendisi tutar (Dil Penceresi, kavram/).

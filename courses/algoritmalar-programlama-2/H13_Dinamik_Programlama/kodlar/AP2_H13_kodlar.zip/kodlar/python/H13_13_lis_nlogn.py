"""H13_13_lis_nlogn.py — AP-2 Hafta 13 · Örnek 13 (★★★, merak)
Amaç    : En uzun artan alt dizi O(n log n): "sabır sıralaması" fikri.
          tails[k] = uzunluğu k+1 olan artan alt dizilerin EN KÜÇÜK son
          değeri; her x için H4'ün lower_bound'u (ilk tails[k] >= x)
          ile yeri bulunur. Uzunluk Örnek 7 ile aynı; dizinin geri
          çıkarılması için tails_idx ve ebeveyn dizileri
DP      : durum tails[0..L) (artan sıralı kalır: değişmez) · geçiş
          k = lower_bound(tails, x); tails[k] = x (k = L ise L++) ·
          temel L = 0 · sıra i = 0..n−1 · cevap L · geri çıkarma
          ebeveyn[i] = tails_idx[k−1] (k > 0), zincir tails_idx[L−1]'den
Çalıştır: python3 H13_13_lis_nlogn.py
Eşleri  : c/H13_13_lis_nlogn.c · cpp/H13_13_lis_nlogn.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_dizi, rastgele_tohum

yoklama = 0                         # incelenen tails[mid] sayısı
karsilastirma = 0


def alt_sinir(t, n, x):
    """H4 Örnek 7: lower_bound — ilk t[i] >= x konumu; hepsi < x ise n.
    Değişmez: t[0..lo-1] < x <= t[hi..n-1]"""
    global yoklama
    lo, hi = 0, n
    while lo < hi:
        mid = lo + (hi - lo) // 2
        yoklama += 1
        if t[mid] < x:
            lo = mid + 1
        else:
            hi = mid
    return lo


def liste_yaz(x, L):
    return "[" + ", ".join(str(v) for v in x[:L]) + "]"


def lis_nlogn(a, iz):
    """Sabır sıralaması; iz ise her adımı yazar.
    Dönen: (L, tails, tails_idx, ebeveyn)"""
    n = len(a)
    tails = [0] * n
    tails_idx = [0] * n
    ebeveyn = [-1] * n
    L = 0
    for i in range(n):
        k = alt_sinir(tails, L, a[i])
        tails[k] = a[i]             # yeni deste ya da üstüne
        tails_idx[k] = i
        ebeveyn[i] = tails_idx[k - 1] if k > 0 else -1
        if k == L:
            L += 1
        if iz:
            print(f"  x = {a[i]} -> konum {k}: tails {liste_yaz(tails, L)}, "
                  f"tails_idx {liste_yaz(tails_idx, L)}, "
                  f"ebeveyn[{i}] = {ebeveyn[i]}")
    return L, tails, tails_idx, ebeveyn


def geri_cikar_yaz(a, tails_idx, ebeveyn, L):
    """Zinciri tails_idx[L-1]'den izler; değerleri BAŞTAN SONA yazar"""
    indis = [0] * L
    k = L
    i = tails_idx[L - 1] if L > 0 else -1
    while i != -1:
        k -= 1
        indis[k] = i
        i = ebeveyn[i]
    satir = "  alt dizi:" + "".join(f" {a[j]}" for j in indis[:12])
    if L > 12:
        satir += " ... (ilk 12)"
    print(satir)
    artan = True
    for x in range(1, L):
        if not (indis[x - 1] < indis[x] and a[indis[x - 1]] < a[indis[x]]):
            artan = False
    print("  denetim: indisler ve değerler kesin artan: "
          + ("evet" if artan else "HAYIR"))


def lis_n2_uzunluk(a):
    """Örnek 7'nin O(n^2) DP'si (yalnız uzunluk; kâhin)"""
    global karsilastirma
    n = len(a)
    uz = [1] * n
    en = 0
    for i in range(n):
        for j in range(i):
            karsilastirma += 1
            if a[j] < a[i] and uz[j] + 1 > uz[i]:
                uz[i] = uz[j] + 1
        if uz[i] > en:
            en = uz[i]
    return en


def main():
    global yoklama, karsilastirma
    a1 = [5, 2, 8, 6, 3, 6, 9, 7]
    print("1) a = {5, 2, 8, 6, 3, 6, 9, 7} (Örnek 7 ile aynı)")
    print("  (konum = lower_bound(tails, x); tails[konum] = x)")
    yoklama = 0
    L, tails, idx, eb = lis_nlogn(a1, True)
    print(f"  uzunluk L = {L}; yoklama (lower_bound adımı) = {yoklama}")
    geri_cikar_yaz(a1, idx, eb, L)

    rastgele_tohum(42)
    a2 = rastgele_dizi(16, 1, 50)
    print("\n2) Örnek 7'nin rastgele dizisi (tohum 42, n = 16, 1..50)")
    yoklama = 0
    L, tails, idx, eb = lis_nlogn(a2, False)
    y2 = yoklama
    l2 = lis_n2_uzunluk(a2)
    print(f"  uzunluk L = {L} (Örnek 7: O(n^2) DP ile {l2}); yoklama = {y2}")
    print(f"  son tails = {liste_yaz(tails, L)}  (bir artan alt dizi DEĞİL; "
          f"yalnız deste üstleri)")
    geri_cikar_yaz(a2, idx, eb, L)

    print("\n3) Büyük n (tohum 42, 1..1000000)")
    for n in (1000, 100000):
        rastgele_tohum(42)
        a = rastgele_dizi(n, 1, 1000000)
        yoklama = 0
        L, tails, idx, eb = lis_nlogn(a, False)
        satir = f"  n = {n:6d}: L = {L}, yoklama = {yoklama}"
        if n <= 1000:
            karsilastirma = 0
            lb = lis_n2_uzunluk(a)
            satir += (f"; O(n^2): L = {lb}, karşılaştırma = {karsilastirma} "
                      f"({'aynı' if lb == L else 'FARKLI'})")
        else:
            satir += (f"; O(n^2) olsaydı n(n-1)/2 = {n * (n - 1) // 2} "
                      f"karşılaştırma")
        print(satir)
        geri_cikar_yaz(a, idx, eb, L)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: lower_bound — C: yok (elle; bsearch eşit öğeyi
# bulur, konum vermez); C++: std::lower_bound; Python: bisect.bisect_left
# (yalnız kâhin). LIS'in kendisinin kütüphane karşılığı yok.

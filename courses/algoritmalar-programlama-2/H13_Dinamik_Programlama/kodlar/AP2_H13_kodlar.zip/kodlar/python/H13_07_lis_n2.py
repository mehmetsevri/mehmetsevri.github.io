"""H13_07_lis_n2.py — AP-2 Hafta 13 · Örnek 7 (★★)
Amaç    : En uzun (kesin) artan alt dizi, O(n²) DP; ebeveyn dizisiyle
          dizinin geri çıkarılması; kâhin: bütün alt kümeler (2^n)
DP      : durum uz[i] = a[i] ile BİTEN en uzun artan alt dizinin
          uzunluğu · geçiş uz[i] = 1 + max{uz[j] : j < i, a[j] < a[i]}
          · temel uz[i] = 1, ebeveyn[i] = −1 · sıra i = 0..n−1 artan,
          içte j = 0..i−1 · cevap max uz[i] · geri çıkarma ebeveyn
          zinciri. Eşitlik: j artan dolaşılır, yalnız KESİN büyükte
          güncellenir (en küçük j); sonda en küçük i seçilir
Çalıştır: python3 H13_07_lis_n2.py
Eşleri  : c/H13_07_lis_n2.c · cpp/H13_07_lis_n2.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_dizi, rastgele_tohum

karsilastirma = 0


def lis_n2(a, uz, ebeveyn):
    """uz ve ebeveyn doldurulur; dönen: en uzun alt dizinin son indisi"""
    global karsilastirma
    n = len(a)
    uz[:] = [1] * n                 # temel: yalnız a[i]
    ebeveyn[:] = [-1] * n
    son = 0
    for i in range(n):
        for j in range(i):
            karsilastirma += 1
            if a[j] < a[i] and uz[j] + 1 > uz[i]:
                uz[i] = uz[j] + 1
                ebeveyn[i] = j
        if uz[i] > uz[son]:         # eşitlikte küçük i
            son = i
    return son


def geri_cikar(ebeveyn, son):
    """Ebeveyn zincirini izleyip indisleri BAŞTAN SONA döndürür"""
    indis = []
    i = son
    while i != -1:
        indis.append(i)
        i = ebeveyn[i]
    indis.reverse()                 # ters çevir
    return indis


def kahin(a):
    """Kâhin: 2^n bit maskesi (H3 Örnek 5), kesin artan en uzun alt küme"""
    n = len(a)
    en_iyi = 0
    for maske in range(1, 1 << n):
        onceki, uzunluk, artan = 0, 0, True
        for i in range(n):
            if not artan:
                break
            if maske & (1 << i):
                if uzunluk > 0 and a[i] <= onceki:
                    artan = False
                onceki = a[i]
                uzunluk += 1
        if artan and uzunluk > en_iyi:
            en_iyi = uzunluk
    return en_iyi


def yaz_satir(ad, x):
    print(f"  {ad:<8}:" + "".join(f" {v:3d}" for v in x))


def coz_ve_yaz(a, ayrintili):
    global karsilastirma
    n = len(a)
    uz, ebeveyn = [], []
    karsilastirma = 0
    son = lis_n2(a, uz, ebeveyn)
    if ayrintili:
        yaz_satir("i", list(range(n)))
        yaz_satir("a[i]", a)
        yaz_satir("uz[i]", uz)
        yaz_satir("ebeveyn", ebeveyn)
    indis = geri_cikar(ebeveyn, son)
    print(f"  en uzun: uz = {uz[son]}, son indis {son} "
          f"(eşitlikte en küçük indis)")
    print("  geri çıkarma (ebeveyn zinciri): "
          + " -> ".join(str(i) for i in reversed(indis)))
    print("  alt dizi: " + " ".join(str(a[i]) for i in indis)
          + "   (indisler: " + " ".join(str(i) for i in indis) + ")")
    print(f"  karşılaştırma = {karsilastirma} = n(n-1)/2 = "
          f"{n * (n - 1) // 2}")
    return uz[son]


def main():
    a1 = [5, 2, 8, 6, 3, 6, 9, 7]
    print("1) a = {5, 2, 8, 6, 3, 6, 9, 7} (n = 8)")
    coz_ve_yaz(a1, True)

    rastgele_tohum(42)
    a2 = rastgele_dizi(16, 1, 50)
    print("\n2) Rastgele a (tohum 42, n = 16, 1..50): "
          + " ".join(str(v) for v in a2))
    uzunluk = coz_ve_yaz(a2, True)
    k = kahin(a2)
    print(f"  kâhin (2^16 alt küme taraması): {k} -> "
          f"{'aynı' if k == uzunluk else 'FARKLI'}")

    print("\n3) Sınır durumları (n = 8)")
    artan = [i + 1 for i in range(8)]
    azalan = [8 - i for i in range(8)]
    esit = [5] * 8
    uz, eb = [], []
    s1 = lis_n2(artan, uz, eb)
    print(f"  artan 1..8      : uz = {uz[s1]}")
    s2 = lis_n2(azalan, uz, eb)
    print(f"  azalan 8..1     : uz = {uz[s2]}")
    s3 = lis_n2(esit, uz, eb)
    print(f"  hepsi 5 (eşit)  : uz = {uz[s3]} (KESİN artan: a[j] < a[i])")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). O(n log n) sürüm: Örnek 13
# (H4 lower_bound ile "sabır sıralaması").

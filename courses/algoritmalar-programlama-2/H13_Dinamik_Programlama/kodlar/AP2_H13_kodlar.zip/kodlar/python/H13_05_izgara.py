"""H13_05_izgara.py — AP-2 Hafta 13 · Örnek 5 (★★)
Amaç    : 2B DP: (1) ızgarada sol üstten sağ alta (yalnız sağa / aşağı)
          yol sayısı, büyük ızgarada mod 10^9 + 7; (2) engelli ızgarada
          yol sayısı; (3) engelli ızgarada en küçük maliyetli yol ve
          yolun geri çıkarılması
DP      : (1)(2) durum yol[i][j] = (0,0)'dan (i,j)'ye yol sayısı ·
          geçiş yol[i][j] = yol[i−1][j] + yol[i][j−1] (engelde 0) ·
          temel yol[0][0] = 1 · (3) durum m[i][j] = (i,j)'ye en küçük
          toplam maliyet · geçiş m[i][j] = a[i][j] + min(m[i−1][j],
          m[i][j−1]) · temel m[0][0] = a[0][0]; engel ve ulaşılamayan
          = ∞ · sıra satır öncelikli (i artan, j artan) · cevap
          [R−1][C−1] · geri çıkarma: eşitlikte YUKARIDAN gelinir
Çalıştır: python3 H13_05_izgara.py
Eşleri  : c/H13_05_izgara.c · cpp/H13_05_izgara.cpp
Çıktı   : üç dilde aynı (=)
"""

R = 5
C = 6
ENGEL = -1
SONSUZ = 2147483647                 # C'deki INT_MAX
MOD = 1000000007

# maliyet ızgarası; ENGEL = geçilemez hücre
a = [
    [1, 3, 1, 2, 8, 1],
    [1, 5, ENGEL, 1, 1, 2],
    [4, 2, 1, ENGEL, 3, 1],
    [ENGEL, 1, 9, 1, 1, 2],
    [2, 1, 2, 4, ENGEL, 1],
]


def yol_sayisi_tablo(r, c):
    """(1) engelsiz r x c ızgara: tam tablo; cevap yol[r-1][c-1]"""
    yol = [[0] * c for _ in range(r)]
    for i in range(r):
        for j in range(c):
            if i == 0 or j == 0:
                yol[i][j] = 1       # ilk satır ve sütun
            else:
                yol[i][j] = yol[i - 1][j] + yol[i][j - 1]
    return yol


def yol_sayisi_mod(n):
    """Büyük n x n: tek satır tamponu (satır öncelikli doldurma; yol[j]
    soldaki hücreyi bu satırdan, yukarıdakini önceki satırdan tutar)"""
    yol = [1] * n                   # ilk satır
    for _ in range(1, n):
        for j in range(1, n):
            yol[j] = (yol[j] + yol[j - 1]) % MOD    # yukarı + sol
    return yol[n - 1]


def binom(n, k):
    """C(n, k) tam değer (küçük n için kâhin): her adımda tam bölünür"""
    sonuc = 1
    for i in range(1, k + 1):
        sonuc = sonuc * (n - k + i) // i
    return sonuc


def engelli_yol_sayisi():
    """(2) engelli ızgara: engel hücresinde yol 0"""
    yol = [[0] * C for _ in range(R)]
    for i in range(R):
        for j in range(C):
            if a[i][j] == ENGEL:
                yol[i][j] = 0
            elif i == 0 and j == 0:
                yol[i][j] = 1       # temel durum
            else:
                ust = yol[i - 1][j] if i > 0 else 0
                sol = yol[i][j - 1] if j > 0 else 0
                yol[i][j] = ust + sol
    return yol[R - 1][C - 1], yol


def en_kucuk_maliyet():
    """(3) en küçük maliyet; m[i][j] = SONSUZ: engel ya da ulaşılamaz"""
    m = [[0] * C for _ in range(R)]
    for i in range(R):
        for j in range(C):
            if a[i][j] == ENGEL:
                m[i][j] = SONSUZ
                continue
            if i == 0 and j == 0:
                m[i][j] = a[0][0]   # temel durum
                continue
            ust = m[i - 1][j] if i > 0 else SONSUZ
            sol = m[i][j - 1] if j > 0 else SONSUZ
            enk = ust if ust <= sol else sol    # eşitlikte yukarı
            m[i][j] = SONSUZ if enk == SONSUZ else enk + a[i][j]
    return m[R - 1][C - 1], m


def yolu_geri_cikar(m):
    """Yolu sağ alttan geri çıkarır; (i, j) çiftleri BAŞTAN SONA"""
    yol = [None] * (R + C - 1)
    i, j = R - 1, C - 1
    for k in range(R + C - 2, -1, -1):
        yol[k] = (i, j)
        if i == 0:
            j -= 1
        elif j == 0:
            i -= 1
        elif m[i - 1][j] <= m[i][j - 1]:
            i -= 1                  # eşitlikte yukarı
        else:
            j -= 1
    return yol


def yaz_hucre(v, engel_mi):
    return "    #" if engel_mi else f" {v:4d}"


def main():
    print("1) Izgarada yol sayısı (yalnız sağa ya da aşağı), 3 x 4")
    print("  yol[i][j] = yol[i-1][j] + yol[i][j-1]; ilk satır ve sütun 1")
    yol = yol_sayisi_tablo(3, 4)
    for i in range(3):
        print(" " + "".join(yaz_hucre(yol[i][j], False) for j in range(4)))
    print(f"  cevap yol[2][3] = {yol[2][3]} = C(5, 2) = {binom(5, 2)}")

    print("\n2) n x n ızgara: yol = C(2n-2, n-1); tek satır tamponu, "
          "mod 10^9 + 7")
    for n in (16, 30, 100, 500):
        v = yol_sayisi_mod(n)
        if n <= 30:
            b = binom(2 * n - 2, n - 1)     # tam değer
            print(f"  n = {n:3d}: {v}  (tam C({2 * n - 2}, {n - 1}) = {b}; "
                  f"tam mod p = {b % MOD})")
        else:
            print(f"  n = {n:3d}: {v}  (mod 1000000007)")

    print(f"\n3) Engelli ızgara (# = engel), {R} x {C}\n  maliyetler:")
    for i in range(R):
        print(" " + "".join(yaz_hucre(a[i][j], a[i][j] == ENGEL)
                            for j in range(C)))
    es, yol = engelli_yol_sayisi()
    print("  yol sayısı tablosu (engelde 0):")
    for i in range(R):
        print(" " + "".join(yaz_hucre(yol[i][j], a[i][j] == ENGEL)
                            for j in range(C)))
    print(f"  engelli yol sayısı = {es} (engelsiz 5 x 6: "
          f"{binom(R + C - 2, R - 1)})")

    enk, m = en_kucuk_maliyet()
    print("\n4) En küçük maliyetli yol: m[i][j] = a[i][j] + "
          "min(m[i-1][j], m[i][j-1])")
    for i in range(R):
        satir = " "
        for j in range(C):
            if a[i][j] == ENGEL:
                satir += "    #"
            elif m[i][j] == SONSUZ:
                satir += "    ∞"
            else:
                satir += f" {m[i][j]:4d}"
        print(satir)
    if enk == SONSUZ:
        print("  sağ alt hücre ulaşılamaz")
        return
    yolu = yolu_geri_cikar(m)
    print(f"  en küçük maliyet = {enk}; yol (eşitlikte yukarıdan):")
    toplam = 0
    parcalar = []
    for i, j in yolu:
        toplam += a[i][j]
        parcalar.append(f"({i},{j})")
    print("  " + " -> ".join(parcalar))
    print(f"  yol üzerindeki maliyet toplamı = {toplam} "
          f"({'tutarlı' if toplam == enk else 'TUTARSIZ'})")
    print("  yol çizimi (* = yol, # = engel):")
    for i in range(R):
        satir = "   "
        for j in range(C):
            ch = "#" if a[i][j] == ENGEL else "."
            if (i, j) in yolu:
                ch = "*"
            satir += " " + ch
        print(satir)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Kombinatorik kâhin: C(n, k)
# — Python math.comb (yalnız doğrulama).

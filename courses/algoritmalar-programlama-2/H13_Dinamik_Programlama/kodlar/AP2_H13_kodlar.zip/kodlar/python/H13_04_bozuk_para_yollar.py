"""H13_04_bozuk_para_yollar.py — AP-2 Hafta 13 · Örnek 4 (★★)
Amaç    : Bozuk para: tutar kaç farklı yolla ödenir? Sayma DP'si ve döngü
          sırası tuzağı: dış döngü PARA → kombinasyon (sıra önemsiz),
          dış döngü TUTAR → permütasyon (sıra önemli). Aynı girdide
          farklı sayılar; listelemeyle doğrulama; büyük tutar mod 10^9+7
DP      : durum yol[t] = t tutarının ödeniş sayısı · geçiş yol[t] +=
          yol[t−c] · temel yol[0] = 1 (boş ödeme), diğerleri 0 · sıra
          KOMBİNASYON: her para c için t = c..S artan (para dışta);
          PERMÜTASYON: t = 1..S artan, içte her para (tutar dışta) ·
          cevap yol[S]
Çalıştır: python3 H13_04_bozuk_para_yollar.py
Eşleri  : c/H13_04_bozuk_para_yollar.c · cpp/H13_04_bozuk_para_yollar.cpp
Çıktı   : üç dilde aynı (=)
"""

MAKS_S = 1000
MOD = 1000000007

yol = [0] * (MAKS_S + 1)
secilen = []                        # listelemede o anki paralar


def yaz_satir(S):
    return "".join(f" {yol[t]:3d}" for t in range(S + 1))


def kombinasyon(paralar, S, satirlari_yaz):
    """Kombinasyon: dış döngü para. c parası işlenirken yol[t], yalnız ilk
    paralarla (c dahil) yapılan ödemeleri sayar: sıra önemsiz."""
    yol[0] = 1                      # temel durum
    for t in range(1, S + 1):
        yol[t] = 0
    for c in paralar:               # DIŞ: para
        for t in range(c, S + 1):   # İÇ: tutar
            yol[t] = (yol[t] + yol[t - c]) % MOD
        if satirlari_yaz:
            print(f"  para {c} sonrası:" + yaz_satir(S))
    return yol[S]


def permutasyon(paralar, S):
    """Permütasyon: dış döngü tutar. yol[t] her paranın SON adım olabildiği
    bütün dizileri sayar: 1+2 ile 2+1 ayrı sayılır."""
    yol[0] = 1                      # temel durum
    for t in range(1, S + 1):       # DIŞ: tutar
        yol[t] = 0
        for c in paralar:           # İÇ: para
            if c <= t:
                yol[t] = (yol[t] + yol[t - c]) % MOD
    return yol[S]


def yaz_secilen():
    print("    " + "+".join(str(c) for c in secilen))


def kombinasyon_listele(paralar, en_buyuk_i, kalan):
    """Doğrulama 1: kombinasyonlar — paralar artmayan sırada (en büyük
    önce), en_buyuk_i: kullanılabilecek en büyük para indisi"""
    if kalan == 0:
        yaz_secilen()
        return 1
    say = 0
    for i in range(en_buyuk_i, -1, -1):
        if paralar[i] <= kalan:
            secilen.append(paralar[i])
            say += kombinasyon_listele(paralar, i, kalan - paralar[i])
            secilen.pop()
    return say


def permutasyon_listele(paralar, kalan):
    """Doğrulama 2: permütasyonlar — her adımda her para denenir"""
    if kalan == 0:
        yaz_secilen()
        return 1
    say = 0
    for c in paralar:
        if c <= kalan:
            secilen.append(c)
            say += permutasyon_listele(paralar, kalan - c)
            secilen.pop()
    return say


def main():
    p1 = [1, 2, 5]
    S = 5
    print(f"1) Paralar {{1, 2, 5}}, tutar {S}: aynı geçiş, farklı döngü "
          f"sırası")
    print("  t             :" + "".join(f" {t:3d}" for t in range(S + 1)))
    print("  KOMBİNASYON (dış döngü para):")
    kom = kombinasyon(p1, S, True)
    per = permutasyon(p1, S)
    print("  PERMÜTASYON (dış döngü tutar):")
    print("  yol[t]        :" + yaz_satir(S))
    print(f"  kombinasyon = {kom}, permütasyon = {per}  (sıra önemli mi?)")

    print("\n2) Doğrulama: kombinasyonlar (büyük para önce)")
    ks = kombinasyon_listele(p1, 2, S)
    print(f"  listelenen = {ks}")
    print("  permütasyonlar (her sıra ayrı)")
    ps = permutasyon_listele(p1, S)
    print(f"  listelenen = {ps}; tablo ile aynı: "
          f"{'evet' if ks == kom and ps == per else 'HAYIR'}")

    print("\n3) Tutar 0..10 için iki sayım (paralar {1, 2, 5})")
    print("  t          :" + "".join(f" {t:4d}" for t in range(11)))
    print("  kombinasyon:" + "".join(f" {kombinasyon(p1, t, False):4d}"
                                    for t in range(11)))
    print("  permütasyon:" + "".join(f" {permutasyon(p1, t):4d}"
                                    for t in range(11)))

    p2 = [1, 5, 10, 25, 50, 100]
    print("\n4) Büyük tutar, iki sayım da mod p = 10^9 + 7: paralar "
          "{1, 5, 10, 25, 50, 100} kuruş")
    for t in (100, 500, 1000):
        kb = kombinasyon(p2, t, False)
        pm = permutasyon(p2, t)
        print(f"  tutar {t:4d}: kombinasyon = {kb}, permütasyon = {pm}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python); sayma DP'si elle.

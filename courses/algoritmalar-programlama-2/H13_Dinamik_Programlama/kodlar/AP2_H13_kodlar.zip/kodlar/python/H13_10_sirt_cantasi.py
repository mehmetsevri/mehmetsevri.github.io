"""H13_10_sirt_cantasi.py — AP-2 Hafta 13 · Örnek 10 (★★★)
Amaç    : 0/1 sırt çantası: (n + 1) × (W + 1) tam tablo ve seçilen
          nesnelerin geri çıkarılması; değer/ağırlık oranına göre
          açgözlünün (H12) 0/1'de yanılması; 12 dersten AKTS sınırı
          altında en yüksek tercih puanı, kâhin: 2^n alt küme
DP      : durum K[i][w] = ilk i nesneyle, w kapasitede en büyük değer ·
          geçiş K[i][w] = max(K[i−1][w], K[i−1][w − a_i] + d_i) (a_i <=
          w ise) · temel K[0][w] = 0 · sıra i = 1..n, w = 0..W
          (satır öncelikli) · cevap K[n][W] · geri çıkarma i = n..1:
          K[i][w] != K[i−1][w] ise i alındı, w −= a_i (eşitlikte
          ALINMADI sayılır; ilk i−1 nesneyle aynı değer elde edilir)
Çalıştır: python3 H13_10_sirt_cantasi.py
Eşleri  : c/H13_10_sirt_cantasi.c · cpp/H13_10_sirt_cantasi.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

hucre = 0


def sirt_cantasi(a, d, W):
    """(n+1) x (W+1) tablo; her satır ayrı liste (Örnek 6)"""
    global hucre
    n = len(a)
    K = [[0] * (W + 1) for _ in range(n + 1)]  # temel: nesne yok
    for i in range(1, n + 1):
        for w in range(W + 1):
            al_ma = K[i - 1][w]
            en_iyi = al_ma
            if a[i - 1] <= w:
                al = K[i - 1][w - a[i - 1]] + d[i - 1]
                if al > en_iyi:
                    en_iyi = al
            K[i][w] = en_iyi
            hucre += 1
    return K


def secilenler(K, a, W):
    """Seçilen nesneleri geri çıkarır; (secildi listesi, toplam ağırlık)"""
    n = len(a)
    w, agirlik = W, 0
    secildi = [False] * n
    for i in range(n, 0, -1):
        if K[i][w] != K[i - 1][w]:  # eşitlikte alınmadı
            secildi[i - 1] = True
            w -= a[i - 1]
            agirlik += a[i - 1]
    return secildi, agirlik


def acgozlu(a, d, W):
    """Açgözlü (H12 kesirli sırt çantası sırası): d/a oranı azalan; sığanı
    al. Oran karşılaştırması tamsayıyla: d_i * a_j > d_j * a_i"""
    n = len(a)
    sira = list(range(n))
    secildi = [False] * n
    for i in range(1, n):           # araya ekleme (H5)
        x, j = sira[i], i - 1
        while j >= 0 and d[x] * a[sira[j]] > d[sira[j]] * a[x]:
            sira[j + 1] = sira[j]
            j -= 1
        sira[j + 1] = x
    deger = 0
    for i in sira:
        if a[i] <= W:
            W -= a[i]
            deger += d[i]
            secildi[i] = True
    return deger, secildi


def kahin(a, d, W):
    """Kâhin: 2^n alt küme; en büyük değer"""
    n = len(a)
    en_iyi = 0
    for maske in range(1 << n):
        agirlik = deger = 0
        for i in range(n):
            if maske & (1 << i):
                agirlik += a[i]
                deger += d[i]
        if agirlik <= W and deger > en_iyi:
            en_iyi = deger
    return en_iyi


def yaz_secim(ad, secildi):
    return "{" + ", ".join(ad[i] for i in range(len(ad)) if secildi[i]) + "}"


def main():
    global hucre
    ad1 = ["A", "B", "C", "D"]
    a1, d1 = [5, 4, 6, 3], [10, 40, 30, 50]
    W1 = 10
    print("1) Nesneler (ağırlık, değer): A(5, 10) B(4, 40) C(6, 30) "
          f"D(3, 50); W = {W1}")
    hucre = 0
    K = sirt_cantasi(a1, d1, W1)
    print("  K[i][w]   w:" + "".join(f" {w:3d}" for w in range(W1 + 1)))
    for i in range(5):
        etiket = "-" if i == 0 else ad1[i - 1]
        print(f"  i = {i} {etiket:<5}:"
              + "".join(f" {K[i][w]:3d}" for w in range(W1 + 1)))
    secildi, ag = secilenler(K, a1, W1)
    print(f"  en büyük değer = K[4][{W1}] = {K[4][W1]}; seçilen "
          f"{yaz_secim(ad1, secildi)}, ağırlık {ag} / {W1}")
    parcalar = []
    w = W1
    for i in range(4, 0, -1):
        al = K[i][w] != K[i - 1][w]
        parcalar.append(ad1[i - 1] + ("+" if al else "-"))
        if al:
            w -= a1[i - 1]
    print("  geri çıkarma: i = 4..1, K[i][w] != K[i-1][w] ise alındı: "
          + " ".join(parcalar))
    print(f"  hücre = n * (W + 1) = {hucre}")

    print("\n2) Açgözlü (değer/ağırlık oranı, H12) 0/1'de yanılır")
    ad2 = ["X", "Y", "Z"]
    a2, d2 = [10, 20, 30], [60, 100, 120]
    print("  X(10, 60) Y(20, 100) Z(30, 120); W = 50; oranlar 6 > 5 > 4")
    dg, secildi = acgozlu(a2, d2, 50)
    print(f"  açgözlü: {yaz_secim(ad2, secildi)} = {dg}")
    K = sirt_cantasi(a2, d2, 50)
    secildi, _ = secilenler(K, a2, 50)
    print(f"  DP     : {yaz_secim(ad2, secildi)} = {K[3][50]}")

    print("\n3) 12 ders: AKTS (ağırlık) 2..8, tercih puanı (değer) 1..20, "
          "tohum 4; üst sınır 30 AKTS")
    ad3 = [f"D{i + 1:02d}" for i in range(12)]
    a3, d3 = [0] * 12, [0] * 12
    rastgele_tohum(4)
    for i in range(12):
        a3[i] = rastgele_aralik(2, 8)
        d3[i] = rastgele_aralik(1, 20)
    ogeler = [f"{ad3[i]}({a3[i]}, {d3[i]})" for i in range(12)]
    print("  " + " ".join(ogeler[:6]) + "\n  " + " ".join(ogeler[6:]))
    hucre = 0
    K = sirt_cantasi(a3, d3, 30)
    en = K[12][30]
    secildi, ag = secilenler(K, a3, 30)
    print(f"  DP: puan = {en}, AKTS = {ag}; seçilen "
          f"{yaz_secim(ad3, secildi)}")
    kh = kahin(a3, d3, 30)
    print(f"  hücre = {hucre}; kâhin (2^12 = 4096 alt küme) = {kh} -> "
          f"{'aynı' if kh == en else 'FARKLI'}")
    dg, secildi = acgozlu(a3, d3, 30)
    print(f"  açgözlü (oran): puan = {dg} "
          f"({'bu girdide en iyi' if dg == en else 'en iyiden düşük'})")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python); DP tablosu elle doldurulur.
# Tek satırlı sürüm: Örnek 11.

"""H13_02_merdiven.py — AP-2 Hafta 13 · Örnek 2 (★)
Amaç    : Merdiven çıkma: her adımda 1 ya da 2 basamak; n. basamağa kaç
          farklı yolla çıkılır? İlk durum–geçiş tanımı; yol[n] = F(n+1);
          bütün yolların listelenmesiyle doğrulama; {1, 2, 3} değişkesi
DP      : durum yol[i] = i. basamağa çıkma yolu sayısı · geçiş
          yol[i] = yol[i−1] + yol[i−2] (son adım 1 ya da 2) · temel
          yol[0] = 1 (hiç adım atmamak bir yoldur), yol[1] = 1 · sıra
          i = 2..n artan · cevap yol[n]
Çalıştır: python3 H13_02_merdiven.py
Eşleri  : c/H13_02_merdiven.c · cpp/H13_02_merdiven.cpp
Çıktı   : üç dilde aynı (=)
"""

MAKS_N = 40
MOD = 1000000007

yol = [0] * (MAKS_N + 1)
adimlar = []                        # listelemede o anki yol (yığın gibi)
listelenen = 0


def merdiven_tablo(n):
    """yol[0..n] tablosunu doldurur (1 ya da 2 basamak)"""
    yol[0] = 1                      # temel durum
    yol[1] = 1
    for i in range(2, n + 1):
        yol[i] = yol[i - 1] + yol[i - 2]    # son adım 1 ya da 2


def yollari_listele(kalan):
    """Doğrulama: kalan basamağa bütün adım dizilerini yazar"""
    global listelenen
    if kalan == 0:
        listelenen += 1
        print("    " + "+".join(str(a) for a in adimlar))
        return
    for adim in (1, 2):
        if adim <= kalan:
            adimlar.append(adim)
            yollari_listele(kalan - adim)
            adimlar.pop()


def merdiven_uclu(n):
    """Değişke: 1, 2 ya da 3 basamak; yol3[i] = yol3[i−1] + yol3[i−2] +
    yol3[i−3] (i − k >= 0 olan terimler)"""
    yol3 = [0] * (n + 1)
    yol3[0] = 1
    for i in range(1, n + 1):
        yol3[i] = 0
        for k in (1, 2, 3):
            if i - k >= 0:
                yol3[i] += yol3[i - k]
    return yol3[n]


def merdiven_mod(n):
    """Büyük n: iki değişken + mod 10^9 + 7"""
    onceki, simdiki = 1, 1          # yol[0], yol[1]
    for _ in range(2, n + 1):
        onceki, simdiki = simdiki, (onceki + simdiki) % MOD
    return simdiki


def main():
    print("1) Durum ve geçiş")
    print("  durum : yol[i] = i. basamağa çıkmanın yol sayısı")
    print("  geçiş : yol[i] = yol[i-1] + yol[i-2]  (son adım 1 ya da 2)")
    print("  temel : yol[0] = 1, yol[1] = 1;  cevap: yol[n]")

    merdiven_tablo(MAKS_N)
    fib = [0] * (MAKS_N + 2)
    fib[0], fib[1] = 0, 1
    for i in range(2, MAKS_N + 2):
        fib[i] = fib[i - 1] + fib[i - 2]
    print("\n2) Tablo ve Fibonacci ilişkisi: yol[n] = F(n+1)")
    print("  n      :" + "".join(f" {n:3d}" for n in range(11)))
    print("  yol[n] :" + "".join(f" {yol[n]:3d}" for n in range(11)))
    print("  F(n+1) :" + "".join(f" {fib[n + 1]:3d}" for n in range(11)))
    esit = True
    for n in range(MAKS_N + 1):
        if yol[n] != fib[n + 1]:
            esit = False
    print(f"  n = 0..{MAKS_N} için yol[n] = F(n+1): "
          f"{'evet' if esit else 'HAYIR'}; yol[{MAKS_N}] = {yol[MAKS_N]}")

    print("\n3) Doğrulama: n = 5 için bütün yollar (önce 1, sonra 2)")
    yollari_listele(5)
    print(f"  listelenen = {listelenen}, tablo yol[5] = {yol[5]}: "
          f"{'aynı' if listelenen == yol[5] else 'FARKLI'}")

    print("\n4) Değişke: 1, 2 ya da 3 basamak "
          "(yol3[i] = yol3[i-1] + yol3[i-2] + yol3[i-3])")
    print("  yol3   :" + "".join(f" {merdiven_uclu(n):3d}"
                                for n in range(11)))

    print("\n5) Büyük n: yol[n] mod 10^9 + 7 (iki değişken)")
    for n in (40, 1000, 100000):
        print(f"  yol[{n}] mod 1000000007 = {merdiven_mod(n)}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python); tablo elle doldurulur.

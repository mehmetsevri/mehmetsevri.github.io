"""H13_06_tablo_kurma.py — AP-2 Hafta 13 · Örnek 6 (★★, Dil Penceresi)
Amaç    : 2B DP tablosu kurma: Python'da [[0] * m] * n TUZAĞI — dış liste
          AYNI satır nesnesine n başvuru tutar; bir hücreyi değiştirmek
          bütün satırları değiştirir ve DP yanlış çıkar. Doğru biçim:
          [[0] * m for _ in range(n)]. Aynı tabloyla Pascal üçgeni.
          C'de tek malloc bloğu, C++'ta vector<vector<int>> (eş dosyalar)
DP      : durum t[i][j] = C(i, j) · geçiş C(i, j) = C(i−1, j−1) +
          C(i−1, j) · temel C(i, 0) = C(i, i) = 1 · sıra i artan (satır
          öncelikli), j = 1..i−1 · cevap t[n−1][k]
Çalıştır: python3 H13_06_tablo_kurma.py
Eşleri  : c/H13_06_tablo_kurma.c · cpp/H13_06_tablo_kurma.cpp
Çıktı   : Δ — dile özgü (bölüm 1 her dilde farklı; bölüm 2 aynı);
          bkz. Dil Penceresi
"""


def tablo_kur_tuzak(n, m):
    """YANLIŞ: [0] * m bir kez oluşur; * n aynı listeye n başvuru koyar"""
    return [[0] * m] * n


def tablo_kur(n, m):
    """DOĞRU: liste üreteci her satır için YENİ bir liste oluşturur"""
    return [[0] * m for _ in range(n)]


def pascal_doldur(t, n):
    """Pascal üçgeni: t[i][j] = C(i, j), 0 <= j <= i < n"""
    for i in range(n):
        t[i][0] = 1                 # C(i, 0) = 1
        t[i][i] = 1                 # C(i, i) = 1
        for j in range(1, i):
            t[i][j] = t[i - 1][j - 1] + t[i - 1][j]


def pascal_yaz(t, n):
    for i in range(n):
        print("   " + "".join(f" {t[i][j]:4d}" for j in range(i + 1)))


def main():
    n, m = 6, 6
    print(f"1) 2B tablo, Python: TUZAK t = [[0] * m] * n (n = {n}, m = {m})")
    t = tablo_kur_tuzak(n, m)
    t[0][0] = 7
    print("  t[0][0] = 7: öteki satırların ilk hücreleri: "
          + " ".join(str(t[i][0]) for i in range(1, n)))
    print(f"  t[0] is t[5]: {t[0] is t[5]}  (AYNI satır nesnesi {n} kez "
          f"paylaşılıyor)")
    t[0][0] = 0
    pascal_doldur(t, n)
    print("  bu tabloyla Pascal üçgeni (YANLIŞ):")
    pascal_yaz(t, n)
    print(f"  C(5, 2) = {t[5][2]} (doğrusu 10): satır i-1 diye okunan, "
          f"aynı satırın bu turda değişmiş hâli")
    print("  doğru biçim: t = [[0] * m for _ in range(n)]")
    t = tablo_kur(n, m)
    t[0][0] = 7
    print("  t[0][0] = 7: öteki satırların ilk hücreleri: "
          + " ".join(str(t[i][0]) for i in range(1, n))
          + f";  t[0] is t[5]: {t[0] is t[5]}")
    t[0][0] = 0

    print("\n2) Pascal üçgeni (DP): C(i, j) = C(i-1, j-1) + C(i-1, j); "
          "C(i, 0) = C(i, i) = 1")
    pascal_doldur(t, n)
    pascal_yaz(t, n)
    print(f"  C(5, 2) = {t[5][2]}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (tek blok + indis hesabı elle); C++ —
# std::vector<std::vector<int>> ya da std::vector<int>(n * m); Python —
# [[0] * m for _ in range(n)].

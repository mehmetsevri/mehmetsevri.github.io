"""H13_14_kelime_bolme.py — AP-2 Hafta 13 · Örnek 14 (★★★, meydan okuma)
Amaç    : Kelime bölme (önek DP'si): boşluksuz yazılmış bir dizgi
          sözlükteki sözcüklere bölünebilir mi, kaç yolla, hangi
          bölmeyle? Sözlük: Ömer Seyfettin metinlerinden çıkarılmış
          liste (stdin, Örnek 9 ile aynı); arama set (H10, karma kümesi)
DP      : durum ok[i] = s[0..i) sözcüklere bölünebilir mi; say[i] = kaç
          yolla · geçiş ok[i] = VAR j: ok[j] VE s[j..i) sözlükte
          (i − j <= en uzun sözcük); say[i] = Σ say[j] · temel ok[0] =
          doğru, say[0] = 1 · sıra i = 1..n artan, içte j artan · cevap
          ok[n], say[n] · geri çıkarma son[i] = koşulu sağlayan EN KÜÇÜK
          j (son sözcük en uzun olan); i = n, son[n], … 0
          Konumlar BAYT: dizgi UTF-8 bytes olarak işlenir (C ile aynı)
Çalıştır: python3 H13_14_kelime_bolme.py \\
          < ../girdiler/H13_14_kelime_bolme.txt
Eşleri  : c/H13_14_kelime_bolme.c · cpp/H13_14_kelime_bolme.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

sozluk = set()                      # H10: karma kümesi (bytes)
en_uzun = 0                         # en uzun sözcük (bayt)
sorgu = 0                           # sözlük sorgusu sayısı


def sozlukte_mi(s, j, uzunluk):
    """Sözlükte var mı? (karma tablosu araması)"""
    global sorgu
    sorgu += 1
    return s[j:j + uzunluk] in sozluk


ok, son, say = [], [], []


def kelime_bol(s):
    """Önek DP'si: ok, son, say doldurulur"""
    global ok, son, say
    n = len(s)
    ok = [False] * (n + 1)
    son = [-1] * (n + 1)
    say = [0] * (n + 1)
    ok[0] = True                    # boş önek
    say[0] = 1
    for i in range(1, n + 1):
        j0 = i - en_uzun if i - en_uzun > 0 else 0
        for j in range(j0, i):
            if ok[j] and sozlukte_mi(s, j, i - j):
                if not ok[i]:
                    son[i] = j      # en küçük j
                ok[i] = True
                say[i] += say[j]
    return ok[n]


def bolme_metni(s, kes):
    """kes: bitiş konumları SONDAN başa; parçaları baştan sona birleştirir"""
    parcalar = []
    bas = 0
    for t in range(len(kes) - 1, -1, -1):
        parcalar.append(s[bas:kes[t]].decode("utf-8"))
        bas = kes[t]
    return " + ".join(parcalar)


def bolme_yaz(s):
    """son[] zincirini izleyip bölmeyi baştan sona döndürür"""
    kes = []
    i = len(s)
    while i > 0:
        kes.append(i)
        i = son[i]
    return bolme_metni(s, kes)


kesimler = []


def hepsini_listele(s, i):
    """Bütün bölmeler (küçük sayılar için): i'ye biten son sözcükten"""
    if i == 0:
        print("    " + bolme_metni(s, kesimler))
        return
    j0 = i - en_uzun if i - en_uzun > 0 else 0
    for j in range(j0, i):
        if ok[j] and sozlukte_mi(s, j, i - j):
            kesimler.append(i)
            hepsini_listele(s, j)
            kesimler.pop()


def main():
    global en_uzun, sorgu
    for satir in sys.stdin.buffer.read().split(b"\n"):
        satir = satir.rstrip(b"\r")
        if satir:
            sozluk.add(satir)
            if len(satir) > en_uzun:
                en_uzun = len(satir)
    if not sozluk:
        print("sözlük boş (girdi: kelime listesi)", file=sys.stderr)
        sys.exit(1)
    print(f"1) Sözlük: {len(sozluk)} sözcük (stdin), en uzun sözcük "
          f"{en_uzun} bayt")
    print(f"  ok[i] = VAR j: ok[j] ve s[j..i) sözlükte (i - j <= {en_uzun}); "
          f"konumlar BAYT")

    metin = "karanlıkiniçinde"
    s = metin.encode("utf-8")
    n = len(s)
    sorgu = 0
    b = kelime_bol(s)
    print(f"\n2) s = \"{metin}\" ({n} bayt)")
    print("  ok[i] doğru olan i (son[i]):"
          + "".join(f" {i}({son[i]})" for i in range(n + 1) if ok[i]))
    print(f"  bölünebilir: {'evet' if b else 'HAYIR'}; bölme sayısı "
          f"say[{n}] = {say[n]}; sözlük sorgusu = {sorgu}")
    print("  seçilen (son[] zinciri, son sözcük en uzun): " + bolme_yaz(s))
    print("  bütün bölmeler:")
    hepsini_listele(s, n)

    print("\n3) Başka dizgiler")
    for d in ("gecegündüzçalışan", "dükkânındatekbaşına", "bugünbirdiyetvar",
              "padişahferman", "kılıçlarınıçekti"):
        s = d.encode("utf-8")
        sorgu = 0
        b = kelime_bol(s)
        if b:
            sonuc = f"{say[len(s)]} bölme; " + bolme_yaz(s)
        else:
            sonuc = "BÖLÜNEMEZ"
        print(f"  {d}: {sonuc}  (sorgu = {sorgu})")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Sözlük araması C'de elle
# ikili arama (H4); C++'ta std::unordered_set, Python'da set (H10).

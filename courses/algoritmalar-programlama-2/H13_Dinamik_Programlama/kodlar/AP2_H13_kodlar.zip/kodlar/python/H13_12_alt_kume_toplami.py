"""H13_12_alt_kume_toplami.py — AP-2 Hafta 13 · Örnek 12 (★★)
Amaç    : Alt küme toplamı iki stratejiyle: H3'ün budamalı geri izlemesi
          (düğüm sayısı) ve DP (bool tablo + sayım tablosu; hücre
          sayısı). Aynı girdi (H3 Örnek 8: n = 18, tohum 42, 1..40);
          çözüm sayıları birebir aynı; n ve hedefe göre karşılaştırma
DP      : durum var[i][t] = ilk i sayının bir alt kümesinin toplamı t
          olabilir mi; say[i][t] = kaç alt küme · geçiş var[i][t] =
          var[i−1][t] VEYA (a_i <= t VE var[i−1][t − a_i]); say[i][t] =
          say[i−1][t] + say[i−1][t − a_i] · temel var[0][0] = 1,
          say[0][0] = 1, diğerleri 0 · sıra i artan, t artan · cevap
          var[n][T], say[n][T] · geri çıkarma i = n..1: var[i−1][t]
          doğruysa a_i ALINMAZ (eşitlikte almadan), yoksa alınır
Çalıştır: python3 H13_12_alt_kume_toplami.py
Eşleri  : c/H13_12_alt_kume_toplami.c · cpp/H13_12_alt_kume_toplami.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_dizi, rastgele_tohum

# --- H3 Örnek 8: budamalı geri izleme ("toplam aşıldı") ----------------
a = []
hedef = 0
ziyaret = 0                         # ziyaret edilen düğüm (çağrı)
cozum_sayisi = 0


def budamali(i, toplam):
    global ziyaret, cozum_sayisi
    ziyaret += 1
    if toplam > hedef:
        return                      # torunların hepsi de aşar (a_i > 0)
    if i == len(a):
        if toplam == hedef:
            cozum_sayisi += 1
        return
    budamali(i + 1, toplam)
    budamali(i + 1, toplam + a[i])


# --- DP: bool tablo + sayım tablosu (satır i: ilk i sayı) ---------------
var_t = []                          # (n+1) x (T+1)
say_t = []
hucre = 0


def dp_doldur(T):
    global var_t, say_t, hucre
    n = len(a)
    var_t = [[False] * (T + 1) for _ in range(n + 1)]
    say_t = [[0] * (T + 1) for _ in range(n + 1)]
    var_t[0][0] = True              # boş küme: toplam 0
    say_t[0][0] = 1
    hucre = T + 1                   # satır 0
    for i in range(1, n + 1):
        x = a[i - 1]
        for t in range(T + 1):
            var_t[i][t] = var_t[i - 1][t]               # almadan
            say_t[i][t] = say_t[i - 1][t]
            if x <= t:                                  # alarak
                var_t[i][t] = var_t[i][t] or var_t[i - 1][t - x]
                say_t[i][t] += say_t[i - 1][t - x]
            hucre += 1


def geri_cikar(T):
    """Bir çözüm: i = n..1; var[i-1][t] doğruysa almadan"""
    secilen = []                    # sondan başa sıralı
    t = T
    for i in range(len(a), 0, -1):
        if not var_t[i - 1][t]:
            secilen.append(a[i - 1])
            t -= a[i - 1]
    return secilen


def dizi_kur(adet, tohum):
    global a
    rastgele_tohum(tohum)
    a = rastgele_dizi(adet, 1, 40)


def yaz_kume(secilen):
    return "{" + ", ".join(str(x) for x in reversed(secilen)) + "}"


def main():
    global a, hedef, ziyaret, cozum_sayisi
    a = [5, 4, 3, 2]
    hedef = 7
    print("1) a = {5, 4, 3, 2}, hedef = 7 (H3 Örnek 8)")
    dp_doldur(7)
    print("  var[i][t] (1 = ilk i sayıyla t toplamı yapılabilir)")
    print("  t        :" + "".join(f" {t:2d}" for t in range(8)))
    for i in range(len(a) + 1):
        bas = "  i = 0    :" if i == 0 else f"  i = {i} ({a[i - 1]}):"
        print(bas + "".join(f" {int(var_t[i][t]):2d}" for t in range(8)))
    secilen = geri_cikar(7)
    print(f"  say[4][7] = {say_t[4][7]} alt küme; bir çözüm (eşitlikte "
          f"almadan): {yaz_kume(secilen)}")
    dp_hucre = hucre
    ziyaret = 0
    cozum_sayisi = 0
    budamali(0, 0)
    print(f"  geri izleme: {cozum_sayisi} çözüm, {ziyaret} düğüm; DP: "
          f"{dp_hucre} hücre")

    dizi_kur(18, 42)
    toplam_a = 0
    for x in a:
        toplam_a += x
    print("\n2) H3'ün girdisi: n = 18, a (tohum 42, 1..40) = "
          + " ".join(str(x) for x in a))
    print(f"   toplam = {toplam_a}")
    print("  hedef  yöntem             çözüm  düğüm/hücre  bir çözüm")
    for h in (50, toplam_a // 2):
        hedef = h
        ziyaret = 0
        cozum_sayisi = 0
        budamali(0, 0)
        print(f"  {hedef:5d}  geri izleme (H3)  {cozum_sayisi:6d}  "
              f"{ziyaret:11d}")
        dp_doldur(hedef)
        secilen = geri_cikar(hedef)
        print(f"  {hedef:5d}  DP (var + say)    {say_t[len(a)][hedef]:6d}  "
              f"{hucre:11d}  {yaz_kume(secilen)}")

    print("\n3) n'ye göre (hedef = toplam / 2; a: aynı LCG dizisinin ilk n "
          "öğesi)")
    print("   n  toplam  hedef  kaba kuvvet düğümü  geri izleme düğümü  "
          "DP hücresi  çözüm")
    for adet in range(10, 19, 2):
        dizi_kur(adet, 42)
        toplam_a = 0
        for x in a:
            toplam_a += x
        hedef = toplam_a // 2
        ziyaret = 0
        cozum_sayisi = 0
        budamali(0, 0)
        dp_doldur(hedef)
        dp_say = say_t[len(a)][hedef]
        print(f"  {adet:2d}  {toplam_a:6d}  {hedef:5d}  "
              f"{(1 << (adet + 1)) - 1:18d}  {ziyaret:18d}  {hucre:10d}  "
              f"{cozum_sayisi:5d}" + ("" if dp_say == cozum_sayisi
                                      else " FARKLI"))
    print("  (kaba kuvvet düğümü = 2^(n+1) - 1; DP hücresi = "
          "(n+1)(hedef+1))")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Kâhin: H3 Örnek 5'in bit
# maskesi taraması; burada iki bağımsız yöntemin sayımları karşılaştırılır.

"""H13_09_duzenleme_uzakligi.py — AP-2 Hafta 13 · Örnek 9 (★★★)
Amaç    : Düzenleme (Levenshtein) uzaklığı: tablo ve işlem dizisinin
          geri çıkarılması; UTF-8'de bayt ve KOD NOKTASI düzeyi farkı;
          "Bunu mu demek istediniz?": Ömer Seyfettin metinlerinden
          çıkarılmış sözlükte (stdin) en yakın k = 3 öneri
DP      : durum D[i][j] = a[0..i)'yı b[0..j)'ye çeviren en az işlem ·
          geçiş D[i][j] = min(D[i−1][j] + 1 silme, D[i][j−1] + 1 ekleme,
          D[i−1][j−1] + [a[i−1] != b[j−1]] değiştirme/eşleşme) · temel
          D[i][0] = i, D[0][j] = j · sıra satır öncelikli · cevap
          D[n][m] · geri çıkarma (n, m)'den; eşitlikte öncelik:
          eşleşme > silme > ekleme > değiştirme. Öneriler kod noktası
          düzeyinde; eşit uzaklıkta bayt sırası (sözlük sırası)
Çalıştır: python3 H13_09_duzenleme_uzakligi.py \\
          < ../girdiler/H13_09_duzenleme_uzakligi.txt
Eşleri  : c/H13_09_duzenleme_uzakligi.c ·
          cpp/H13_09_duzenleme_uzakligi.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

K = 3                               # öneri sayısı

D = []
hucre = 0                           # hesaplanan tablo hücresi


def utf8_coz(s):
    """UTF-8 çözücü: bytes → kod noktaları (elle; C ile aynı kurallar);
    geçersiz bayt tek başına kod noktası sayılır"""
    cp = []
    i = 0
    while i < len(s):
        b = s[i]
        ek = 3 if b >= 0xF0 else 2 if b >= 0xE0 else 1 if b >= 0xC0 else 0
        deger = (b & 0x07 if ek == 3 else b & 0x0F if ek == 2
                 else b & 0x1F if ek == 1 else b)
        if ek > 0 and i + ek >= len(s):
            ek = 0                  # yarım dizi
            deger = b
        for t in range(1, ek + 1):
            deger = (deger << 6) | (s[i + t] & 0x3F)
        cp.append(deger)
        i += ek + 1
    return cp


def baytlar(s):
    """Bayt düzeyi: her bayt bir "karakter" (bytes öğeleri 0..255)"""
    return list(s)


def uzaklik(a, b):
    """D tablosunu doldurur (satır öncelikli)"""
    global D, hucre
    n, m = len(a), len(b)
    D = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        D[i][0] = i                 # i silme
    for j in range(m + 1):
        D[0][j] = j                 # j ekleme
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            sil = D[i - 1][j] + 1
            ekle = D[i][j - 1] + 1
            degis = D[i - 1][j - 1] + (a[i - 1] != b[j - 1])
            enk = sil if sil < ekle else ekle
            D[i][j] = degis if degis < enk else enk
    hucre += (n + 1) * (m + 1)
    return D[n][m]


def islemleri_yaz(a, b):
    """İşlem dizisini geri çıkarıp BAŞTAN SONA yazar (D dolu olmalı)"""
    tur, x, y = [], [], []          # E, S, K, D
    i, j = len(a), len(b)
    while i > 0 or j > 0:
        d = D[i][j]
        if i > 0 and j > 0 and a[i - 1] == b[j - 1] and d == D[i - 1][j - 1]:
            tur.append("E")         # eşleşme
            i -= 1
            j -= 1
        elif i > 0 and d == D[i - 1][j] + 1:
            tur.append("S")         # silme
            i -= 1
        elif j > 0 and d == D[i][j - 1] + 1:
            tur.append("K")         # ekleme
            j -= 1
        else:
            tur.append("D")         # değiştirme
            i -= 1
            j -= 1
        x.append(i)
        y.append(j)
    sayi = [0, 0, 0, 0]
    parcalar = []
    for t in range(len(tur) - 1, -1, -1):
        if tur[t] == "E":
            sayi[0] += 1
            parcalar.append("eşleş " + chr(a[x[t]]))
        elif tur[t] == "S":
            sayi[1] += 1
            parcalar.append("sil " + chr(a[x[t]]))
        elif tur[t] == "K":
            sayi[2] += 1
            parcalar.append("ekle " + chr(b[y[t]]))
        else:
            sayi[3] += 1
            parcalar.append("değiştir " + chr(a[x[t]]) + "→" + chr(b[y[t]]))
    print("  işlemler: " + ", ".join(parcalar))
    print(f"  (eşleşme {sayi[0]}, silme {sayi[1]}, ekleme {sayi[2]}, "
          f"değiştirme {sayi[3]})")


def uzaklik_metin(a, b, kod_noktasi):
    if kod_noktasi:
        return uzaklik(utf8_coz(a), utf8_coz(b))
    return uzaklik(baytlar(a), baytlar(b))


def oner(sorgu, sozluk, kod_noktasi):
    """En yakın K sözcük; eşit uzaklıkta sözlükte önce gelen (bayt sırası)"""
    en_iyi_i = [-1] * K
    en_iyi_d = [2147483647] * K
    for w, sozcuk in enumerate(sozluk):
        d = uzaklik_metin(sorgu, sozcuk, kod_noktasi)
        if d >= en_iyi_d[K - 1]:
            continue                # KESİN küçük olmalı
        p = K - 1
        while p > 0 and en_iyi_d[p - 1] > d:    # araya ekleme (H5)
            en_iyi_d[p] = en_iyi_d[p - 1]
            en_iyi_i[p] = en_iyi_i[p - 1]
            p -= 1
        en_iyi_d[p] = d
        en_iyi_i[p] = w
    return en_iyi_i, en_iyi_d


def tablo_yaz(a, b):
    print("         " + "".join(f"  {c}" for c in b))
    for i in range(len(a) + 1):
        print("     " + (" " if i == 0 else a[i - 1])
              + "".join(f" {D[i][j]:2d}" for j in range(len(b) + 1)))


def main():
    print("1) a = \"kitten\", b = \"sitting\" (ASCII: bayt = karakter)")
    x, y = baytlar(b"kitten"), baytlar(b"sitting")
    d = uzaklik(x, y)
    tablo_yaz("kitten", "sitting")
    print(f"  uzaklık = D[6][7] = {d}; hücre = 7 * 8 = 56")
    print("  (eşitlikte öncelik: eşleşme > silme > ekleme > değiştirme)")
    islemleri_yaz(x, y)

    print("\n2) UTF-8: bayt mı, kod noktası mı? (Türkçe harfler 2 bayt)")
    ciftler = [("gunduz", "gündüz"), ("sehre", "şehre"), ("kılç", "kılıç"),
               ("kılç", "hıç"), ("ş", "ğ")]
    for s1, s2 in ciftler:
        b1, b2 = s1.encode("utf-8"), s2.encode("utf-8")
        db = uzaklik_metin(b1, b2, False)
        dk = uzaklik_metin(b1, b2, True)
        print(f"  {s1} / {s2}: bayt = {db}, kod noktası = {dk}")
    x = utf8_coz("gunduz".encode("utf-8"))
    y = utf8_coz("gündüz".encode("utf-8"))
    uzaklik(x, y)
    print("  gunduz -> gündüz, kod noktası düzeyinde:")
    islemleri_yaz(x, y)

    sozluk = []
    for satir in sys.stdin.buffer.read().split(b"\n"):
        satir = satir.rstrip(b"\r")
        if satir:
            sozluk.append(satir)
    if not sozluk:
        print("sözlük boş (girdi: kelime listesi)", file=sys.stderr)
        sys.exit(1)
    sozluk.sort()                   # bayt sırası (araç)

    print(f"\n3) \"Bunu mu demek istediniz?\" — sözlük: {len(sozluk)} "
          f"sözcük (stdin), k = {K}")
    print("  öneri: kod noktası düzeyinde; eşit uzaklıkta bayt sırası")
    sorgular = ["gunduz", "sehre", "kılç", "padisah", "gozleri", "usda",
                "esir"]
    global hucre
    hucre = 0
    for q in sorgular:
        qb = q.encode("utf-8")
        ii, dd = oner(qb, sozluk, True)
        kn_hucre = hucre
        bi, bd = oner(qb, sozluk, False)
        hucre = kn_hucre
        satir = f"  {q} ->"
        if dd[0] == 0:
            satir += " sözlükte VAR"
        else:
            satir += ",".join(f" {sozluk[ii[t]].decode('utf-8')} ({dd[t]})"
                              for t in range(K))
        satir += (f" | bayt düzeyinde 1.: {sozluk[bi[0]].decode('utf-8')} "
                  f"({bd[0]})")
        print(satir)
    print(f"  kod noktası düzeyinde hesaplanan hücre: {hucre} (7 sorgu x "
          f"{len(sozluk)} sözcük)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++); Python — difflib.get_close_matches
# benzerlik oranıyla öneri verir (Levenshtein değil). Kâhin olarak
# kullanılmaz.

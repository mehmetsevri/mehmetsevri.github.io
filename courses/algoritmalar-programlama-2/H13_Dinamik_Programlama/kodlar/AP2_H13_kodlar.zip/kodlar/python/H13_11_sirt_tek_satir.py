"""H13_11_sirt_tek_satir.py — AP-2 Hafta 13 · Örnek 11 (★★★)
Amaç    : 0/1 sırt çantası tek satırla (bellek O(W)): kapasite TERS
          sırada dolaşılır. Yan yana: ARTAN sırada dolaşınca aynı nesne
          birden çok kez alınır — sınırsız sırt çantası olur. Her
          nesneden sonra satır; tam tablo ve sınırsız DP ile denetim
DP      : durum dp[w] = şimdiye dek işlenen nesnelerle w kapasitede en
          büyük değer (tam tablonun i. satırı yerinde) · geçiş dp[w] =
          max(dp[w], dp[w − a_i] + d_i) · temel dp[w] = 0 · sıra nesne
          i dışta; w = W, W−1, …, a_i (TERS: dp[w − a_i] henüz bu
          nesneyle güncellenmemiştir, yani "önceki satır") · cevap
          dp[W] · geri çıkarma YOK (önceki satırlar üzerine yazıldı)
Çalıştır: python3 H13_11_sirt_tek_satir.py
Eşleri  : c/H13_11_sirt_tek_satir.c · cpp/H13_11_sirt_tek_satir.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

iz_nesne = -1                       # güncellemeleri yazılacak nesne


def satir_yaz(etiket, dp):
    print(f"  {etiket:<6}:" + "".join(f" {v:3d}" for v in dp))


def guncelleme_yaz(w, eski, yeni, kaynak):
    print(f"      dp[{w}]: {eski} -> {yeni}  (dp[{kaynak}] + d)")


def tek_satir_ters(a, d, ad, W, satirlari_yaz):
    """0/1: w TERS sırada; satirlari_yaz ise her nesneden sonra satır"""
    dp = [0] * (W + 1)              # temel
    for i in range(len(a)):
        for w in range(W, a[i] - 1, -1):        # TERS
            if dp[w - a[i]] + d[i] > dp[w]:
                if i == iz_nesne:
                    guncelleme_yaz(w, dp[w], dp[w - a[i]] + d[i], w - a[i])
                dp[w] = dp[w - a[i]] + d[i]
        if satirlari_yaz:
            satir_yaz("+" + ad[i], dp)
    return dp[W], dp


def tek_satir_artan(a, d, ad, W, satirlari_yaz):
    """YANLIŞ (0/1 için): w ARTAN sırada; dp[w − a_i] bu turda güncellenmiş
    olabilir → aynı nesne yeniden alınır (sınırsız sırt çantası)"""
    dp = [0] * (W + 1)
    for i in range(len(a)):
        for w in range(a[i], W + 1):            # ARTAN
            if dp[w - a[i]] + d[i] > dp[w]:
                if i == iz_nesne:
                    guncelleme_yaz(w, dp[w], dp[w - a[i]] + d[i], w - a[i])
                dp[w] = dp[w - a[i]] + d[i]
        if satirlari_yaz:
            satir_yaz("+" + ad[i], dp)
    return dp[W], dp


def tam_tablo_son(a, d, W):
    """Denetim 1: tam tablonun son satırı (Örnek 10)"""
    n = len(a)
    K = [[0] * (W + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for w in range(W + 1):
            K[i][w] = K[i - 1][w]
            if a[i - 1] <= w:
                al = K[i - 1][w - a[i - 1]] + d[i - 1]
                if al > K[i][w]:
                    K[i][w] = al
    return K[n][W], K[n]


def sinirsiz(a, d, W):
    """Denetim 2: sınırsız sırt çantası, kapasite dışta: u[w] =
    max(u[w − a_i] + d_i) — her nesne istenen sayıda"""
    u = [0] * (W + 1)
    for w in range(1, W + 1):
        for i in range(len(a)):
            if a[i] <= w and u[w - a[i]] + d[i] > u[w]:
                u[w] = u[w - a[i]] + d[i]
    return u[W]


def main():
    global iz_nesne
    ad = ["A", "B", "C", "D"]
    a, d = [5, 4, 6, 3], [10, 40, 30, 50]
    n, W = 4, 10
    print("1) Örnek 10'un nesneleri: A(5, 10) B(4, 40) C(6, 30) D(3, 50); "
          f"W = {W}")
    print("  (+X: X nesnesi işlendikten sonra tek satır dp[0..W])")
    print(f"  {'w':<6}:" + "".join(f" {w:3d}" for w in range(W + 1)))
    print("  TERS (w = W..a_i) — doğru 0/1:")
    ters, dp = tek_satir_ters(a, d, ad, W, True)
    print("  ARTAN (w = a_i..W) — YANLIŞ: sınırsız sırt çantası:")
    artan, _ = tek_satir_artan(a, d, ad, W, True)
    print(f"  ters: dp[W] = {ters}; artan: dp[W] = {artan}")

    print("\n2) Neden? D(3, 50) işlenirken dp güncellemeleri")
    iz_nesne = 3
    print("  TERS : dp[w - 3] önceki satırdan (D henüz yok)")
    tek_satir_ters(a, d, ad, W, False)
    print("  ARTAN: dp[w - 3] bu turda D ile güncellenmiş olabilir")
    tek_satir_artan(a, d, ad, W, False)
    iz_nesne = -1
    print("  (artan: dp[6] = dp[3] + 50 -> D ikinci kez; dp[9] = dp[6] + "
          "50 -> üçüncü kez)")

    tam, son = tam_tablo_son(a, d, W)
    dp_ayni = dp == son             # liste karşılaştırması
    u = sinirsiz(a, d, W)
    print("\n3) Denetim")
    print("  ters satır = tam tablonun son satırı K[n][0..W]: "
          f"{'evet' if dp_ayni else 'HAYIR'} (K[n][W] = {tam})")
    print(f"  artan sonuç = sınırsız sırt çantası DP'si ({u}): "
          f"{'evet' if u == artan else 'HAYIR'}")

    print("\n4) Bellek: hücre sayısı")
    print(f"  bu örnek: tam tablo (n+1)(W+1) = {(n + 1) * (W + 1)}, "
          f"tek satır W+1 = {W + 1}")
    print(f"  n = 100, W = 100000: tam tablo = {101 * 100001}, tek satır = "
          f"{100001}")
    print("  bedel: seçilen nesneler geri çıkarılamaz (önceki satırlar "
          "silindi)")

    ad3 = [f"D{i + 1:02d}" for i in range(12)]
    a3, d3 = [0] * 12, [0] * 12
    rastgele_tohum(4)
    for i in range(12):
        a3[i] = rastgele_aralik(2, 8)
        d3[i] = rastgele_aralik(1, 20)
    t3, _ = tek_satir_ters(a3, d3, ad3, 30, False)
    k3, _ = tam_tablo_son(a3, d3, 30)
    y3, _ = tek_satir_artan(a3, d3, ad3, 30, False)
    print(f"\n5) Örnek 10'un 12 dersi (tohum 4, W = 30): tek satır = {t3}, "
          f"tam tablo = {k3}; artan (yanlış) = {y3}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python); tek satır elle.

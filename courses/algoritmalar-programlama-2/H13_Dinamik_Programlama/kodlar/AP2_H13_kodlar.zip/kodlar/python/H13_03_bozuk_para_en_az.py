"""H13_03_bozuk_para_en_az.py — AP-2 Hafta 13 · Örnek 3 (★★)
Amaç    : En az para sayısı: H12'nin karşı örneği ({1, 3, 4}, tutar 6:
          açgözlü 3 para, DP 2 para); kullanılan paraların geri
          çıkarılması; ulaşılamayan tutar için ∞ sözleşmesi (taşma
          korumalı); kanonik sistemde açgözlü = DP
DP      : durum enaz[t] = t tutarı için en az para · geçiş
          enaz[t] = min{enaz[t−c] + 1 : c <= t, enaz[t−c] != ∞} ·
          temel enaz[0] = 0, diğerleri ∞ (SONSUZ = INT_MAX) · sıra
          t = 1..S artan · cevap enaz[S] · geri çıkarma secim[t] = son
          para, t -= secim[t]; paralar artan denenir, yalnız KESİN
          küçükte güncellenir (eşitlikte küçük para kalır)
Çalıştır: python3 H13_03_bozuk_para_en_az.py
Eşleri  : c/H13_03_bozuk_para_en_az.c · cpp/H13_03_bozuk_para_en_az.cpp
Çıktı   : üç dilde aynı (=)
"""

MAKS_S = 1000
SONSUZ = 2147483647                 # C'deki INT_MAX: "ulaşılamaz"

enaz = [0] * (MAKS_S + 1)
secim = [0] * (MAKS_S + 1)          # enaz[t]'yi veren son para (0: yok)


def en_az_para(paralar, S):
    """paralar ARTAN sıralı; enaz[0..S] ve secim[0..S] doldurulur"""
    enaz[0] = 0                     # temel durum
    secim[0] = 0
    for t in range(1, S + 1):
        enaz[t] = SONSUZ            # henüz ulaşılamadı
        secim[t] = 0
        for c in paralar:
            if (c <= t and enaz[t - c] != SONSUZ
                    and enaz[t - c] + 1 < enaz[t]):
                enaz[t] = enaz[t - c] + 1
                secim[t] = c


def acgozlu(paralar, t, alinan):
    """Açgözlü (H12): en büyük sığan parayı al; para sayısı ya da -1"""
    alinan.clear()
    for c in reversed(paralar):
        while c <= t:
            t -= c
            alinan.append(c)
    return len(alinan) if t == 0 else -1


def geri_cikar(t, alinan):
    """DP çözümünü geri çıkarır: t, t - secim[t], ...; para sayısı"""
    alinan.clear()
    while t > 0:
        alinan.append(secim[t])
        t -= secim[t]
    return len(alinan)


def yaz_paralar(alinan):
    return " + ".join(str(c) for c in alinan)


def yaz_kume(paralar):
    return "{" + ", ".join(str(c) for c in paralar) + "}"


def main():
    alinan = []
    p1 = [1, 3, 4]
    en_az_para(p1, 20)

    print("1) H12'nin karşı örneği: paralar {1, 3, 4}, tutar 6")
    sayi = acgozlu(p1, 6, alinan)
    print(f"  açgözlü (en büyük sığan para): {yaz_paralar(alinan)} = "
          f"{sayi} para")
    sayi = geri_cikar(6, alinan)
    print(f"  DP (en az para)              : {yaz_paralar(alinan)} = "
          f"{sayi} para")

    print("\n2) Tablo: enaz[t] = min(enaz[t-c] + 1); enaz[0] = 0, "
          "diğerleri ∞")
    print("   t  enaz  secim  adaylar c:enaz[t-c]+1")
    for t in range(7):
        satir = f"  {t:2d}  {enaz[t]:4d}  "
        satir += "    -" if secim[t] == 0 else f"{secim[t]:5d}"
        for i, c in enumerate(p1):
            if c <= t:
                satir += ("   " if i == 0 else "  ") + f"{c}:{enaz[t - c] + 1}"
        print(satir)

    satir = "\n3) Geri çıkarma: t = 6"
    t = 6
    while t > 0:
        satir += f" -> {t - secim[t]} (secim {secim[t]})"
        t -= secim[t]
    print(satir)

    print("\n4) Açgözlü ile DP, paralar {1, 3, 4}, t = 1..20: farklı "
          "olanlar")
    print("   t  açgözlü  DP  açgözlü paralar / DP paraları")
    fark = 0
    for t in range(1, 21):
        ag, dp = [], []
        na = acgozlu(p1, t, ag)
        nd = geri_cikar(t, dp)
        if na != nd:
            fark += 1
            print(f"  {t:2d}  {na:7d}  {nd:2d}  {yaz_paralar(ag)} / "
                  f"{yaz_paralar(dp)}")
    print(f"  farklı tutar sayısı: {fark} / 20")

    p2 = [4, 6]
    en_az_para(p2, 12)
    print(f"\n5) Ulaşılamayan tutar: paralar {yaz_kume(p2)}, "
          f"SONSUZ = INT_MAX = {SONSUZ}")
    print("  t   :" + "".join(f" {t:2d}" for t in range(13)))
    satir = "  enaz:"
    for t in range(13):
        satir += "  ∞" if enaz[t] == SONSUZ else f" {enaz[t]:2d}"
    print(satir)
    print("  tutar 7: "
          + ("ulaşılamaz (enaz = ∞)" if enaz[7] == SONSUZ else "ulaşılır")
          + "; açgözlü: "
          + ("çözüm bulamaz" if acgozlu(p2, 7, alinan) < 0 else "çözüm"))
    print("  (enaz[t-c] != SONSUZ denetimi olmasa INT_MAX + 1 taşardı: "
          "Hata Avcısı)")

    p3 = [1, 5, 10, 25, 50, 100]
    en_az_para(p3, MAKS_S)
    esit = 0
    for t in range(1, MAKS_S + 1):
        if acgozlu(p3, t, alinan) == enaz[t]:
            esit += 1
    print(f"\n6) Kanonik sistem {yaz_kume(p3)} (kuruş): t = 1..{MAKS_S} "
          f"için açgözlü = DP: {esit} / {MAKS_S}")
    sayi = geri_cikar(289, alinan)
    print(f"  t = 289: DP {yaz_paralar(alinan)} = {sayi} para")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python); DP tablosu elle doldurulur.
# H12'de açgözlü yalnız kanonik para sistemlerinde en iyidir.

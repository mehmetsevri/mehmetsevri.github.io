"""kelime_listesi_uret.py — AP-2 Hafta 13 · Türkçe kelime listesi üreticisi

Amaç    : Örnek 9 ("Bunu mu demek istediniz?") ve Örnek 14 (kelime bölme)
          için sözlük. Kaynak, Hafta 10'un kamu malı Ömer Seyfettin
          metinleridir (omer_seyfettin_uc_oyku.txt; ayrıntı KAYNAK_NOTU.txt).
Tanım   : Hafta 10 Örnek 7 ile aynı, BAYT DÜZEYİNDE: sözcük = harf
          baytlarının en uzun dizisi; harf = ASCII A–Z, a–z ya da bayt
          >= 0x80 (UTF-8 Türkçe harfler). ASCII büyük harf elle küçültülür
          (A–Z -> +32); ASCII dışı baytlar olduğu gibi kalır.
Süzgeç  : (1) Türkçe büyük harf (Ç Ğ İ Ö Ş Ü) içeren sözcükler atılır:
          bayt düzeyinde küçültülemezler, çoğu cümle başı ya da özel addır;
          (2) tek karakterlik sözcükler atılır.
Çıktı   : Benzersiz sözcükler BAYT SIRASIYLA (unsigned char karşılaştırması;
          C strcmp, C++ std::string, Python bytes ile aynı sıra), satır
          başına bir sözcük, UTF-8, LF. İki dosyaya aynı içerik yazılır:
          H13_09_duzenleme_uzakligi.txt ve H13_14_kelime_bolme.txt
          (esdeger_test.py her örneğe girdiler/KÖK.txt dosyasını verir).
Kullanım: python3 kelime_listesi_uret.py      (bu klasörde çalıştırın)
Not     : Sıralama ve küme burada yalnızca veri hazırlama aracıdır; ders
          örneklerinin algoritması değildir.
"""
import os

KLASOR = os.path.dirname(os.path.abspath(__file__))
KAYNAK = os.path.join(KLASOR, "omer_seyfettin_uc_oyku.txt")
HEDEFLER = ("H13_09_duzenleme_uzakligi.txt", "H13_14_kelime_bolme.txt")
TR_BUYUK = (b"\xc3\x87", b"\xc4\x9e", b"\xc4\xb0", b"\xc3\x96", b"\xc5\x9e",
            b"\xc3\x9c")


def harf_mi(b):
    return 65 <= b <= 90 or 97 <= b <= 122 or b >= 0x80


def sozcukler(metin):
    sozcuk = bytearray()
    for b in metin + b" ":
        if harf_mi(b):
            sozcuk.append(b + 32 if 65 <= b <= 90 else b)
        elif sozcuk:
            yield bytes(sozcuk)
            sozcuk = bytearray()


def karakter_sayisi(s):
    """UTF-8 kod noktası sayısı: devam baytları (10xxxxxx) sayılmaz"""
    return sum(1 for b in s if b & 0xC0 != 0x80)


def main():
    with open(KAYNAK, "rb") as f:
        metin = f.read()
    tum = list(sozcukler(metin))
    secilen = sorted({s for s in tum
                      if karakter_sayisi(s) >= 2
                      and not any(t in s for t in TR_BUYUK)})
    veri = b"".join(s + b"\n" for s in secilen)
    for ad in HEDEFLER:
        with open(os.path.join(KLASOR, ad), "wb") as f:
            f.write(veri)
    print(f"kaynak: {len(metin)} bayt, {len(tum)} sözcük, "
          f"{len(set(tum))} farklı")
    print(f"liste : {len(secilen)} sözcük, {len(veri)} bayt -> "
          + ", ".join(HEDEFLER))


if __name__ == "__main__":
    main()

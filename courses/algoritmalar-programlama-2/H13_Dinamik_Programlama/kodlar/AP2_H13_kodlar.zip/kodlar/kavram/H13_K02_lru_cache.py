"""H13_K02_lru_cache.py — AP-2 Hafta 13 · Kavram 2 (Dil Penceresi)
Amaç    : Python'da memoization'ı dekoratör yapar: functools.cache (3.9+)
          ve functools.lru_cache(maxsize=None). Ama yukarıdan aşağıya memo
          ÖZYİNELEMELİDİR: derin bir zincir (fib(n) → fib(n−1) → …)
          varsayılan özyineleme sınırına (sys.getrecursionlimit(), çoğunlukla
          1000) takılır ve RecursionError verir. Bu yorumlayıcıda (CPython
          3.11) dekoratörlü fonksiyonun her düzeyi iki sayılır; sınıra elle
          memodan çok daha erken ulaşılır. Çare: tablolama (döngü, yığın
          kullanmaz). sys.setrecursionlimit YALNIZ bu açıklamalı programda
          gösterilir: sınırı yükseltmek C yığınını taşırıp süreci
          çökertebilir.
Çalıştır: python3 H13_K02_lru_cache.py
Çıktı   : sınır değerleri Python sürümüne bağlıdır ("Python 3.11.x'te").
"""
import functools
import platform
import sys


@functools.cache
def fib_cache(n):
    return n if n < 2 else fib_cache(n - 1) + fib_cache(n - 2)


@functools.lru_cache(maxsize=None)
def fib_lru(n):
    return n if n < 2 else fib_lru(n - 1) + fib_lru(n - 2)


memo = {}


def fib_elle(n):
    if n not in memo:
        memo[n] = n if n < 2 else fib_elle(n - 1) + fib_elle(n - 2)
    return memo[n]


def fib_tablo_mod(n, mod=1000000007):
    onceki, simdiki = 0, 1
    for _ in range(n):
        onceki, simdiki = simdiki, (onceki + simdiki) % mod
    return onceki


def dene(ad, fonk, n, temizle):
    temizle()
    try:
        f = fonk(n)
        print(f"  {ad:<22} n = {n:4d}: tamam ({f.bit_length()} bitlik "
              f"sonuç)")
    except RecursionError as e:
        print(f"  {ad:<22} n = {n:4d}: RecursionError ({e})")


def main():
    print(f"Python {platform.python_version()}; "
          f"sys.getrecursionlimit() = {sys.getrecursionlimit()}")
    print("\n1) Dekoratör: önbellek istatistiği (fib_cache(30), soğuk)")
    fib_cache.cache_clear()
    fib_cache(30)
    print(f"  {fib_cache.cache_info()}")
    print("  misses = 31 farklı alt problem (0..30); hits = tekrar eden "
          "çağrılar")

    print("\n2) Derin zincir: soğuk önbellekle fib(n)")
    for n in (400, 600, 900):
        dene("functools.cache", fib_cache, n, fib_cache.cache_clear)
        dene("lru_cache(None)", fib_lru, n, fib_lru.cache_clear)
        dene("elle sözlük memo", fib_elle, n, memo.clear)

    print("\n3) Çare 1 — tablolama (döngü): özyineleme yok")
    print(f"  fib(100000) mod 10^9 + 7 = {fib_tablo_mod(100000)}")
    print("\n4) Çare 2 — önbelleği küçükten büyüğe ısıtmak: her çağrı en "
          "çok bir düzey iner")
    fib_cache.cache_clear()
    for k in range(0, 901, 100):
        fib_cache(k)
    print(f"  fib_cache(900): {fib_cache(900).bit_length()} bit, "
          f"{fib_cache.cache_info().currsize} girdi")

    print("\n5) sys.setrecursionlimit(3000) (yalnız gösterim; büyük "
          "değerler C yığınını taşırabilir)")
    eski = sys.getrecursionlimit()
    sys.setrecursionlimit(3000)
    dene("functools.cache", fib_cache, 900, fib_cache.cache_clear)
    sys.setrecursionlimit(eski)
    print(f"  sınır geri alındı: {sys.getrecursionlimit()}")


if __name__ == "__main__":
    main()

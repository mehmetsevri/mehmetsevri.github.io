/* H13_K03_uint64_tasmasi.c — AP-2 Hafta 13 · Kavram 3 (Dil Penceresi, Δ)
 * Amaç    : Büyük sayımlar: uint64_t aritmetiği 2^64'te SARAR (işaretsiz
 *           taşma TANIMLIDIR, uyarı yoktur): F(94) ve 40 × 40 ızgaradaki yol
 *           sayısı yanlış (mod 2^64) çıkar. Aynı sayımlar mod 10^9 + 7 ile
 *           üç dilde aynı. Python tam sonucu verir (eş dosya: .py); C++
 *           C ile aynı çıktıyı verir (eş dosya: .cpp).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_K03_uint64_tasmasi.c -o H13_K03_uint64_tasmasi
 * Çalıştır: ./H13_K03_uint64_tasmasi
 */
#include <inttypes.h>
#include <stdio.h>

#define MOD 1000000007ULL

int main(void)
{
    printf("1) Fibonacci, uint64_t (denetimsiz toplama: 2^64'te sarar)\n");
    uint64_t onceki = 0, simdiki = 1;              /* F(0), F(1) */
    for (int n = 2; n <= 100; n++) {
        uint64_t sonraki = onceki + simdiki;       /* sarabilir */
        onceki = simdiki;
        simdiki = sonraki;
        if (n == 93 || n == 94 || n == 100) {
            printf("  F(%d) = %" PRIu64 "%s\n", n, simdiki,
                   n >= 94 ? "   <- YANLIŞ (mod 2^64)" : "");
        }
    }

    printf("\n2) Izgarada yol sayısı (tek satır tamponu), n x n\n");
    const int ns[] = {30, 34, 40};
    for (int k = 0; k < 3; k++) {
        int n = ns[k];
        uint64_t yol[64];
        uint64_t yol_mod[64];
        for (int j = 0; j < n; j++) {
            yol[j] = 1;
            yol_mod[j] = 1;
        }
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < n; j++) {
                yol[j] = yol[j] + yol[j - 1];      /* sarabilir */
                yol_mod[j] = (yol_mod[j] + yol_mod[j - 1]) % MOD;
            }
        }
        printf("  n = %d: uint64_t = %" PRIu64 ", mod 10^9+7 = %" PRIu64
               "\n", n, yol[n - 1], yol_mod[n - 1]);
    }
    printf("  (C(58, 29) ≈ 3,0e16 sığar; C(66, 33) ≈ 7,2e18 sığar; "
           "C(78, 39) ≈ 2,7e22 > 2^64 ≈ 1,8e19 SARAR)\n");
    return 0;
}

/* Kütüphane karşılığı: C/C++ — yerleşik büyük tamsayı yok (GMP gibi
 * kütüphaneler ders dışı); Python — int sınırsızdır. */

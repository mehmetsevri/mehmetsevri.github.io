/* H13_K03_uint64_tasmasi.cpp — AP-2 Hafta 13 · Kavram 3 (Dil Penceresi, Δ)
 * Amaç    : Büyük sayımlar: std::uint64_t aritmetiği 2^64'te SARAR
 *           (işaretsiz taşma tanımlıdır, uyarı yoktur): F(94) ve 40 × 40
 *           ızgaradaki yol sayısı yanlış (mod 2^64) çıkar; mod 10^9 + 7
 *           sürümü üç dilde aynı. Çıktı C sürümüyle aynıdır; Python tam
 *           sonucu verir (eş dosya: .py).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_K03_uint64_tasmasi.cpp -o H13_K03_uint64_tasmasi
 * Çalıştır: ./H13_K03_uint64_tasmasi
 */
#include <cstdint>
#include <iostream>
#include <vector>

const std::uint64_t MOD = 1000000007ULL;

int main()
{
    std::cout << "1) Fibonacci, uint64_t (denetimsiz toplama: 2^64'te "
                 "sarar)\n";
    std::uint64_t onceki = 0, simdiki = 1;          // F(0), F(1)
    for (int n = 2; n <= 100; n++) {
        std::uint64_t sonraki = onceki + simdiki;   // sarabilir
        onceki = simdiki;
        simdiki = sonraki;
        if (n == 93 || n == 94 || n == 100) {
            std::cout << "  F(" << n << ") = " << simdiki
                      << (n >= 94 ? "   <- YANLIŞ (mod 2^64)" : "") << '\n';
        }
    }

    std::cout << "\n2) Izgarada yol sayısı (tek satır tamponu), n x n\n";
    for (int n : {30, 34, 40}) {
        std::vector<std::uint64_t> yol(n, 1), yol_mod(n, 1);
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < n; j++) {
                yol[j] = yol[j] + yol[j - 1];       // sarabilir
                yol_mod[j] = (yol_mod[j] + yol_mod[j - 1]) % MOD;
            }
        }
        std::cout << "  n = " << n << ": uint64_t = " << yol[n - 1]
                  << ", mod 10^9+7 = " << yol_mod[n - 1] << '\n';
    }
    std::cout << "  (C(58, 29) ≈ 3,0e16 sığar; C(66, 33) ≈ 7,2e18 sığar; "
                 "C(78, 39) ≈ 2,7e22 > 2^64 ≈ 1,8e19 SARAR)\n";
    return 0;
}

// Kütüphane karşılığı: C/C++ — yerleşik büyük tamsayı yok (GMP gibi
// kütüphaneler ders dışı); Python — int sınırsızdır.

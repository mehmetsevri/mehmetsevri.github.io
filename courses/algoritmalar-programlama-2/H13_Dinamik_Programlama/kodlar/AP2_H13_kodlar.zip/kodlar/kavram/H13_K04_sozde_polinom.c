/* H13_K04_sozde_polinom.c — AP-2 Hafta 13 · Kavram 4 (Kaputun Altında)
 * Amaç    : Sözde polinom zaman: 0/1 sırt çantası DP'si Θ(n·W) hücre
 *           işler; W bir SAYININ DEĞERİDİR, girdi uzunluğu ise W'nin bit
 *           sayısı b ile ölçülür (W ≈ 2^b). b iki katına çıkınca (girdi
 *           yalnız b bit uzar) hücre sayısı KARESİNE çıkar: zaman b'ye
 *           göre üsteldir. Hücreler stdout'a, süreler stderr'e (bu
 *           çalıştırmada).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_K04_sozde_polinom.c ../c/ortak_rastgele.c \
 *           ../c/zamanlayici.c -I../c -o H13_K04_sozde_polinom
 * Çalıştır: ./H13_K04_sozde_polinom
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define N 20

/* Tek satırlı 0/1 sırt çantası (Örnek 11); işlenen hücre sayısı *hucre */
static long long sirt(const long long a[], const long long d[], long long W,
                      long long *hucre)
{
    long long *dp = calloc((size_t)(W + 1), sizeof *dp);
    if (dp == NULL) {
        return -1;
    }
    *hucre = 0;
    for (int i = 0; i < N; i++) {
        for (long long w = W; w >= a[i]; w--) {
            if (dp[w - a[i]] + d[i] > dp[w]) {
                dp[w] = dp[w - a[i]] + d[i];
            }
        }
        *hucre += W + 1;                       /* tam tablonun bir satırı */
    }
    long long sonuc = dp[W];
    free(dp);
    return sonuc;
}

int main(void)
{
    printf("n = %d nesne; W = 2^b; ağırlıklar [W/8, W/2], değerler 1..100 "
           "(ortak LCG, tohum 5)\n", N);
    printf("   b             W   girdi biti ~ n*b      hücre n*(W+1)   "
           "en iyi değer\n");
    for (int b = 4; b <= 24; b += 4) {
        long long W = 1LL << b;
        long long a[N], d[N];
        rastgele_tohum(5);
        for (int i = 0; i < N; i++) {
            a[i] = W / 8 + rastgele_sayi() % (W / 2 - W / 8 + 1);
            d[i] = rastgele_aralik(1, 100);
        }
        long long hucre = 0;
        double t0 = zaman_sn();
        long long en = sirt(a, d, W, &hucre);
        double ms = (zaman_sn() - t0) * 1000.0;
        printf("  %2d %13lld %18d %18lld %14lld\n", b, W, N * b, hucre, en);
        fprintf(stderr, "  b = %2d: %.3f ms (bu çalıştırmada)\n", b, ms);
    }
    printf("  b: 8 -> 16 (girdi 2 kat): hücre %lld -> %lld (%.1f kat)\n",
           (long long)N * 257, (long long)N * 65537, 65537.0 / 257.0);
    printf("  Sonuç: Θ(n·W) = Θ(n·2^b) — W'nin değerinde polinom, bit "
           "uzunluğunda üstel.\n");
    return 0;
}

/* Kütüphane karşılığı: yok. 0/1 sırt çantasının karar sürümü NP-tamdır;
 * sözde polinom DP, W küçükken pratiktir (H14: hesaplama karmaşıklığı). */

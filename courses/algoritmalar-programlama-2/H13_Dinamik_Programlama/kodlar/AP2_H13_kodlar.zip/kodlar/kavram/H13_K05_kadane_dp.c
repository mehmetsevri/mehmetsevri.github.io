/* H13_K05_kadane_dp.c — AP-2 Hafta 13 · Kavram 5 (H2'ye DP gözüyle bakış)
 * Amaç    : H2 Örnek 13'ün Kadane algoritması aslında bir DP'dir:
 *           durum biten[i] = a[i] ile BİTEN en büyük toplamlı alt dizi;
 *           geçiş biten[i] = max(a[i], biten[i−1] + a[i]) (ya yeni başla
 *           ya uzat); temel biten[0] = a[0]; sıra i artan; cevap
 *           max biten[i]. Tablonun yalnız son hücresi gerektiğinden tek
 *           değişkene iner (O(1) bellek) — Fibonacci'nin iki değişkenli
 *           sürümüyle aynı fikir. Eşitlikte H2 gibi uzatılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_K05_kadane_dp.c -o H13_K05_kadane_dp
 * Çalıştır: ./H13_K05_kadane_dp
 */
#include <stdio.h>

#define N 9

int main(void)
{
    const int a[N] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};   /* H2 "Klasik" */
    long long biten[N];
    int bas[N];                                /* biten[i]'nin başlangıcı */
    biten[0] = a[0];
    bas[0] = 0;
    for (int i = 1; i < N; i++) {
        long long uzat = biten[i - 1] + a[i];
        if (uzat < a[i]) {                     /* yeni başla */
            biten[i] = a[i];
            bas[i] = i;
        } else {                               /* uzat (eşitlikte de) */
            biten[i] = uzat;
            bas[i] = bas[i - 1];
        }
    }
    int son = 0;
    for (int i = 1; i < N; i++) {
        if (biten[i] > biten[son]) {
            son = i;
        }
    }
    printf("a        :");
    for (int i = 0; i < N; i++) {
        printf(" %3d", a[i]);
    }
    printf("\nbiten[i] :");
    for (int i = 0; i < N; i++) {
        printf(" %3lld", biten[i]);
    }
    printf("\nbas[i]   :");
    for (int i = 0; i < N; i++) {
        printf(" %3d", bas[i]);
    }
    printf("\ncevap = max biten[i] = %lld, aralık a[%d..%d] (H2 Örnek 13: "
           "6 [3..6])\n", biten[son], bas[son], son);

    long long simdiki = a[0], en_iyi = a[0];   /* O(1) bellek: Kadane */
    for (int i = 1; i < N; i++) {
        long long uzat = simdiki + a[i];
        simdiki = uzat < a[i] ? a[i] : uzat;
        en_iyi = simdiki > en_iyi ? simdiki : en_iyi;
    }
    printf("tek değişkenli sürüm (Kadane) = %lld\n", en_iyi);
    return 0;
}

/* Kütüphane karşılığı: yok. */

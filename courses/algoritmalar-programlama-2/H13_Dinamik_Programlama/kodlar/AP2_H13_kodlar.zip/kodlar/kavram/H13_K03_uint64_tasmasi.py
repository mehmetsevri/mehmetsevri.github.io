"""H13_K03_uint64_tasmasi.py — AP-2 Hafta 13 · Kavram 3 (Dil Penceresi, Δ)
Amaç    : Python tamsayısı taşmaz: F(94), F(100) ve 40 × 40 ızgaradaki yol
          sayısının TAM değeri. C/C++'taki uint64_t sonucunu elde etmek
          için her toplamadan sonra & (2^64 − 1) maskesi uygulanır — sonuç
          C ile birebir aynıdır (sarma bilinçli yapılır). mod 10^9 + 7
          sürümü üç dilde aynı.
Çalıştır: python3 H13_K03_uint64_tasmasi.py
"""

MOD = 1000000007
MASKE64 = (1 << 64) - 1


def main():
    print("1) Fibonacci: Python tam değer ve C'deki uint64_t karşılığı")
    onceki, simdiki = 0, 1
    for n in range(2, 101):
        onceki, simdiki = simdiki, onceki + simdiki
        if n in (93, 94, 100):
            print(f"  F({n}) = {simdiki}  ({simdiki.bit_length()} bit; "
                  f"& (2^64 - 1) = {simdiki & MASKE64})")
    print(f"  2^64 = {1 << 64}")

    print("\n2) Izgarada yol sayısı (tek satır tamponu), n x n")
    for n in (30, 34, 40):
        yol = [1] * n
        yol64 = [1] * n
        yol_mod = [1] * n
        for _ in range(1, n):
            for j in range(1, n):
                yol[j] = yol[j] + yol[j - 1]                  # tam
                yol64[j] = (yol64[j] + yol64[j - 1]) & MASKE64  # C gibi
                yol_mod[j] = (yol_mod[j] + yol_mod[j - 1]) % MOD
        print(f"  n = {n}: tam = {yol[n - 1]}, uint64_t benzetimi = "
              f"{yol64[n - 1]}, mod 10^9+7 = {yol_mod[n - 1]}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: Python — int sınırsızdır; math.comb(2n−2, n−1) ile
# doğrulanabilir (yalnız kâhin).

"""H13_K05_kadane_dp.py — AP-2 Hafta 13 · Kavram 5 (H2'ye DP gözüyle)
Amaç    : H2 Örnek 13'ün Kadane algoritması bir DP'dir: durum biten[i] =
          a[i] ile BİTEN en büyük toplamlı alt dizi; geçiş biten[i] =
          max(a[i], biten[i−1] + a[i]); temel biten[0] = a[0]; cevap
          max biten[i]. Yalnız son hücre gerektiğinden tek değişkene iner
          (O(1) bellek). Çıktı C sürümüyle aynıdır.
Çalıştır: python3 H13_K05_kadane_dp.py
"""

N = 9


def main():
    a = [-2, 1, -3, 4, -1, 2, 1, -5, 4]     # H2 "Klasik"
    biten = [0] * N
    bas = [0] * N                   # biten[i]'nin başlangıcı
    biten[0] = a[0]
    for i in range(1, N):
        uzat = biten[i - 1] + a[i]
        if uzat < a[i]:             # yeni başla
            biten[i], bas[i] = a[i], i
        else:                       # uzat (eşitlikte de)
            biten[i], bas[i] = uzat, bas[i - 1]
    son = 0
    for i in range(1, N):
        if biten[i] > biten[son]:
            son = i
    print("a        :" + "".join(f" {x:3d}" for x in a))
    print("biten[i] :" + "".join(f" {x:3d}" for x in biten))
    print("bas[i]   :" + "".join(f" {x:3d}" for x in bas))
    print(f"cevap = max biten[i] = {biten[son]}, aralık a[{bas[son]}..{son}] "
          f"(H2 Örnek 13: 6 [3..6])")
    simdiki = en_iyi = a[0]         # O(1) bellek: Kadane
    for i in range(1, N):
        uzat = simdiki + a[i]
        simdiki = a[i] if uzat < a[i] else uzat
        en_iyi = simdiki if simdiki > en_iyi else en_iyi
    print(f"tek değişkenli sürüm (Kadane) = {en_iyi}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok.

/* H13_K01_iki_satir.c — AP-2 Hafta 13 · Kavram 1 (Kaputun Altında)
 * Amaç    : Düzenleme uzaklığı ve LCS İKİ SATIRLA: D[i][·] yalnız D[i−1][·]
 *           satırına bağlı olduğundan iki satır yeter; kısa dizgi sütun
 *           yapılırsa bellek O(min(n, m)). Değer tam tabloyla aynıdır ama
 *           çözüm GERİ ÇIKARILAMAZ: geri çıkarma (n, m)'den başlayıp her
 *           i için D[i−1][·] satırını ister; o satırlar üzerine yazıldı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_K01_iki_satir.c ../c/ortak_rastgele.c -I../c \
 *           -o H13_K01_iki_satir
 * Çalıştır: ./H13_K01_iki_satir
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

/* Tam tablo (karşılaştırma için): (n+1)(m+1) hücre */
static int uzaklik_tam(const char *a, int n, const char *b, int m)
{
    int s = m + 1;
    int *D = malloc((size_t)(n + 1) * (size_t)s * sizeof *D);
    if (D == NULL) {
        return -1;
    }
    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            if (i == 0 || j == 0) {
                D[i * s + j] = i + j;
            } else {
                int sil = D[(i - 1) * s + j] + 1;
                int ekle = D[i * s + j - 1] + 1;
                int degis = D[(i - 1) * s + j - 1] + (a[i - 1] != b[j - 1]);
                int enk = sil < ekle ? sil : ekle;
                D[i * s + j] = degis < enk ? degis : enk;
            }
        }
    }
    int d = D[n * s + m];
    free(D);
    return d;
}

/* İki satır: onceki = D[i-1][·], simdi = D[i][·]; b kısa olmalı */
static int uzaklik_iki_satir(const char *a, int n, const char *b, int m)
{
    int *onceki = malloc((size_t)(m + 1) * sizeof *onceki);
    int *simdi = malloc((size_t)(m + 1) * sizeof *simdi);
    if (onceki == NULL || simdi == NULL) {
        free(onceki);
        free(simdi);
        return -1;
    }
    for (int j = 0; j <= m; j++) {
        onceki[j] = j;                         /* D[0][j] */
    }
    for (int i = 1; i <= n; i++) {
        simdi[0] = i;                          /* D[i][0] */
        for (int j = 1; j <= m; j++) {
            int sil = onceki[j] + 1;
            int ekle = simdi[j - 1] + 1;
            int degis = onceki[j - 1] + (a[i - 1] != b[j - 1]);
            int enk = sil < ekle ? sil : ekle;
            simdi[j] = degis < enk ? degis : enk;
        }
        int *g = onceki;                       /* satırları değiştir */
        onceki = simdi;
        simdi = g;
    }
    int d = onceki[m];
    free(onceki);
    free(simdi);
    return d;
}

/* LCS, iki satır: yalnız uzunluk */
static int lcs_iki_satir(const char *a, int n, const char *b, int m)
{
    int *onceki = calloc((size_t)(m + 1), sizeof *onceki);
    int *simdi = calloc((size_t)(m + 1), sizeof *simdi);
    if (onceki == NULL || simdi == NULL) {
        free(onceki);
        free(simdi);
        return -1;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (a[i - 1] == b[j - 1]) {
                simdi[j] = onceki[j - 1] + 1;
            } else {
                simdi[j] = onceki[j] >= simdi[j - 1] ? onceki[j]
                                                     : simdi[j - 1];
            }
        }
        int *g = onceki;
        onceki = simdi;
        simdi = g;
    }
    int L = onceki[m];
    free(onceki);
    free(simdi);
    return L;
}

int main(void)
{
    printf("1) Düzenleme uzaklığı: tam tablo ile iki satır\n");
    const char *ciftler[][2] = {{"kitten", "sitting"},
                                {"sunday", "saturday"},
                                {"ABCBDAB", "BDCABA"}};
    for (int c = 0; c < 3; c++) {
        const char *a = ciftler[c][0], *b = ciftler[c][1];
        int n = (int)strlen(a), m = (int)strlen(b);
        if (m > n) {                           /* kısa olan sütun olsun */
            const char *g = a;
            a = b;
            b = g;
            int t = n;
            n = m;
            m = t;
        }
        printf("  %s / %s: tam = %d (%d hücre), iki satır = %d (%d hücre)\n",
               ciftler[c][0], ciftler[c][1], uzaklik_tam(a, n, b, m),
               (n + 1) * (m + 1), uzaklik_iki_satir(a, n, b, m),
               2 * (m + 1));
    }

    printf("\n2) LCS uzunluğu, rastgele DNA (Örnek 8: tohum 7, n = m)\n");
    const char harf[] = "ACGT";
    const int boylar[] = {300, 3000, 20000};
    for (int k = 0; k < 3; k++) {
        int n = boylar[k];
        char *x = malloc((size_t)n), *y = malloc((size_t)n);
        if (x == NULL || y == NULL) {
            free(x);
            free(y);
            return 1;
        }
        rastgele_tohum(7);
        for (int i = 0; i < n; i++) {
            x[i] = harf[rastgele_aralik(0, 3)];
        }
        for (int i = 0; i < n; i++) {
            y[i] = harf[rastgele_aralik(0, 3)];
        }
        long long tam = (long long)(n + 1) * (n + 1) * 4;
        long long iki = 2LL * (n + 1) * 4;
        printf("  n = %5d: LCS = %d; tam tablo %lld bayt, iki satır %lld "
               "bayt (%lld kat az)\n", n, lcs_iki_satir(x, n, y, n), tam,
               iki, tam / iki);
        free(x);
        free(y);
    }
    printf("  (n = 300 için LCS Örnek 8 ile aynı olmalı: 199)\n");

    printf("\n3) Geri çıkarma neden kaybolur?\n");
    printf("  (n, m)'den geri giderken her adım D[i-1][j], D[i][j-1], "
           "D[i-1][j-1]'e bakar;\n");
    printf("  iki satırlı sürümde döngü bittiğinde yalnız D[n-1][·] ve "
           "D[n][·] kalmıştır.\n");
    printf("  i = n - 1'in altına inildiği an gereken satırlar silinmiştir: "
           "değer var, yol yok.\n");
    printf("  Çare: tam tablo (O(nm) bellek) ya da Hirschberg (1975) böl ve "
           "fethet yöntemi.\n");
    return 0;
}

/* Kütüphane karşılığı: yok. */

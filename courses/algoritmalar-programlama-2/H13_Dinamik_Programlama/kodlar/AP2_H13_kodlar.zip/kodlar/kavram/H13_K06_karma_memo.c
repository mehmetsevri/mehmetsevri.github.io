/* H13_K06_karma_memo.c — AP-2 Hafta 13 · Kavram 6 (Dil Penceresi)
 * Amaç    : Memo için iki araç: (1) DİZİ: durum (i, t) → memo[i·(T+1)+t],
 *           bütün (n+1)(T+1) hücre baştan ayrılır, "hesaplanmadı" = −1;
 *           (2) KARMA TABLOSU (H10): yalnız gerçekten ziyaret edilen
 *           durumlar saklanır. Durum uzayı seyrek ya da sınırları bilinmiyor
 *           ise karma tablosu bellek kazandırır; yoğunsa dizi daha hızlı ve
 *           yalındır. C'de doğrusal yoklamalı küçük bir tablo (H10 Örnek 4),
 *           C++'ta std::unordered_map, Python'da dict (eş dosyalar).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_K06_karma_memo.c ../c/ortak_rastgele.c -I../c \
 *           -o H13_K06_karma_memo
 * Çalıştır: ./H13_K06_karma_memo
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define MAKS_N 40

static int a[MAKS_N], n;
static long long hedef;

/* --- (1) dizi memo -------------------------------------------------- */
static long long *dizi;
static long long dizi_hesaplanan = 0;

static long long say_dizi(int i, long long t)
{
    if (t > hedef) {
        return 0;
    }
    long long *h = &dizi[(long long)i * (hedef + 1) + t];
    if (*h == -1) {
        *h = i == n ? (t == hedef) : say_dizi(i + 1, t) +
                                     say_dizi(i + 1, t + a[i]);
        dizi_hesaplanan++;
    }
    return *h;
}

/* --- (2) karma tablosu memo: açık adresleme, doğrusal yoklama -------- */
typedef struct {
    uint64_t *anahtar;             /* 0 = boş; anahtar = durum kodu + 1 */
    long long *deger;
    uint32_t p;                    /* m = 2^p */
    long long adet;
} Karma;

static uint32_t karma(uint64_t k, uint32_t p)  /* çarpma yöntemi (H10) */
{
    return (uint32_t)((k * 11400714819323198485ULL) >> (64 - p));
}

/* yer: anahtarın hücresi ya da ilk boş hücre */
static uint32_t yer_bul(const Karma *m, uint64_t k)
{
    uint32_t maske = (1u << m->p) - 1u, i = karma(k, m->p);
    while (m->anahtar[i] != 0 && m->anahtar[i] != k) {
        i = (i + 1u) & maske;
    }
    return i;
}

static Karma tablo;

static long long say_karma(int i, long long t)
{
    if (t > hedef) {
        return 0;
    }
    uint64_t k = (uint64_t)i * (uint64_t)(hedef + 1) + (uint64_t)t + 1;
    uint32_t y = yer_bul(&tablo, k);
    if (tablo.anahtar[y] == k) {
        return tablo.deger[y];             /* not alınmış */
    }
    long long s = i == n ? (t == hedef) : say_karma(i + 1, t) +
                                          say_karma(i + 1, t + a[i]);
    y = yer_bul(&tablo, k);                /* özyineleme tabloyu değiştirdi */
    tablo.anahtar[y] = k;
    tablo.deger[y] = s;
    tablo.adet++;
    return s;
}

int main(void)
{
    n = 30;
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 1, 40);
    long long toplam = 0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
    }
    hedef = toplam / 2;
    printf("alt küme toplamı (Örnek 12 girdisi, n = %d, hedef = %lld): "
           "durum (i, t)\n", n, hedef);

    long long hucre = (long long)(n + 1) * (hedef + 1);
    dizi = malloc((size_t)hucre * sizeof *dizi);
    tablo.p = 16;                          /* 65536 yuva: α < 1/2 */
    tablo.anahtar = calloc((size_t)1 << tablo.p, sizeof *tablo.anahtar);
    tablo.deger = malloc(((size_t)1 << tablo.p) * sizeof *tablo.deger);
    if (dizi == NULL || tablo.anahtar == NULL || tablo.deger == NULL) {
        free(dizi);
        free(tablo.anahtar);
        free(tablo.deger);
        return 1;
    }
    for (long long k = 0; k < hucre; k++) {
        dizi[k] = -1;
    }
    long long s1 = say_dizi(0, 0);
    long long s2 = say_karma(0, 0);
    printf("  dizi memo   : sonuç %lld; ayrılan hücre %lld, hesaplanan "
           "%lld (%.1f %%)\n", s1, hucre, dizi_hesaplanan,
           100.0 * (double)dizi_hesaplanan / (double)hucre);
    printf("  karma memo  : sonuç %lld; saklanan durum %lld (yalnız "
           "ziyaret edilenler)\n", s2, tablo.adet);
    printf("  aynı sonuç: %s; aynı durum sayısı: %s\n",
           s1 == s2 ? "evet" : "HAYIR",
           dizi_hesaplanan == tablo.adet ? "evet" : "HAYIR");
    free(dizi);
    free(tablo.anahtar);
    free(tablo.deger);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle karma tablosu, H10); C++ —
 * std::unordered_map; Python — dict ya da functools.cache. */

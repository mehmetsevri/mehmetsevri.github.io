"""H13_K04_sozde_polinom.py — AP-2 Hafta 13 · Kavram 4 (Kaputun Altında)
Amaç    : Sözde polinom zaman: 0/1 sırt çantası DP'si Θ(n·W) hücre işler;
          W bir SAYININ DEĞERİDİR, girdi uzunluğu ise W'nin bit sayısı b
          ile ölçülür (W ≈ 2^b). b iki katına çıkınca hücre sayısı KARESİNE
          çıkar. C sürümüyle aynı girdiler (tohum 5); Python'da b <= 16
          (süre bütçesi). Süreler stderr'e (bu çalıştırmada).
Çalıştır: python3 H13_K04_sozde_polinom.py   (kodlar/kavram içinde)
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import (rastgele_aralik, rastgele_sayi,  # noqa: E402
                            rastgele_tohum)
from zamanlayici import zaman_sn  # noqa: E402

N = 20


def sirt(a, d, W):
    """Tek satırlı 0/1 sırt çantası (Örnek 11); (sonuç, hücre)"""
    dp = [0] * (W + 1)
    hucre = 0
    for i in range(N):
        for w in range(W, a[i] - 1, -1):
            if dp[w - a[i]] + d[i] > dp[w]:
                dp[w] = dp[w - a[i]] + d[i]
        hucre += W + 1              # tam tablonun bir satırı
    return dp[W], hucre


def main():
    print(f"n = {N} nesne; W = 2^b; ağırlıklar [W/8, W/2], değerler 1..100 "
          f"(ortak LCG, tohum 5)")
    print("   b             W   girdi biti ~ n*b      hücre n*(W+1)   "
          "en iyi değer")
    for b in (4, 8, 12, 16):
        W = 1 << b
        a, d = [0] * N, [0] * N
        rastgele_tohum(5)
        for i in range(N):
            a[i] = W // 8 + rastgele_sayi() % (W // 2 - W // 8 + 1)
            d[i] = rastgele_aralik(1, 100)
        t0 = zaman_sn()
        en, hucre = sirt(a, d, W)
        ms = (zaman_sn() - t0) * 1000.0
        print(f"  {b:2d} {W:13d} {N * b:18d} {hucre:18d} {en:14d}")
        print(f"  b = {b:2d}: {ms:.3f} ms (bu çalıştırmada)", file=sys.stderr)
    print(f"  b: 8 -> 16 (girdi 2 kat): hücre {N * 257} -> {N * 65537} "
          f"({65537 / 257:.1f} kat)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok.

"""H13_K06_karma_memo.py — AP-2 Hafta 13 · Kavram 6 (Dil Penceresi)
Amaç    : Memo için iki araç: (1) DİZİ (liste, bütün hücreler baştan,
          −1 = hesaplanmadı); (2) dict (H10'un kütüphane karşılığı; anahtar
          (i, t) demeti): yalnız ziyaret edilen durumlar saklanır. Çıktı C ve
          C++ sürümleriyle aynıdır. functools.cache de bir dict kullanır
          (Kavram 2).
Çalıştır: python3 H13_K06_karma_memo.py   (kodlar/kavram içinde)
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_dizi, rastgele_tohum  # noqa: E402

a, n, hedef = [], 0, 0
dizi = []
dizi_hesaplanan = 0
memo = {}                           # anahtar: (i, t) demeti


def say_dizi(i, t):
    global dizi_hesaplanan
    if t > hedef:
        return 0
    k = i * (hedef + 1) + t
    if dizi[k] == -1:
        dizi[k] = ((1 if t == hedef else 0) if i == n
                   else say_dizi(i + 1, t) + say_dizi(i + 1, t + a[i]))
        dizi_hesaplanan += 1
    return dizi[k]


def say_karma(i, t):
    if t > hedef:
        return 0
    if (i, t) in memo:
        return memo[(i, t)]         # not alınmış
    s = ((1 if t == hedef else 0) if i == n
         else say_karma(i + 1, t) + say_karma(i + 1, t + a[i]))
    memo[(i, t)] = s
    return s


def main():
    global a, n, hedef, dizi
    n = 30
    rastgele_tohum(42)
    a = rastgele_dizi(n, 1, 40)
    toplam = 0
    for x in a:
        toplam += x
    hedef = toplam // 2
    print(f"alt küme toplamı (Örnek 12 girdisi, n = {n}, hedef = {hedef}): "
          f"durum (i, t)")
    hucre = (n + 1) * (hedef + 1)
    dizi = [-1] * hucre
    s1 = say_dizi(0, 0)
    s2 = say_karma(0, 0)
    print(f"  dizi memo   : sonuç {s1}; ayrılan hücre {hucre}, hesaplanan "
          f"{dizi_hesaplanan} ({100.0 * dizi_hesaplanan / hucre:.1f} %)")
    print(f"  karma memo  : sonuç {s2}; saklanan durum {len(memo)} (yalnız "
          f"ziyaret edilenler)")
    print(f"  aynı sonuç: {'evet' if s1 == s2 else 'HAYIR'}; aynı durum "
          f"sayısı: {'evet' if dizi_hesaplanan == len(memo) else 'HAYIR'}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle karma tablosu, H10); C++ —
# std::unordered_map; Python — dict ya da functools.cache.

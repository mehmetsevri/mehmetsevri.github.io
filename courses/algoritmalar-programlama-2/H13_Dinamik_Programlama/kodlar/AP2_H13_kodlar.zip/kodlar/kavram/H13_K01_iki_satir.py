"""H13_K01_iki_satir.py — AP-2 Hafta 13 · Kavram 1 (Kaputun Altında)
Amaç    : Düzenleme uzaklığı ve LCS İKİ SATIRLA: D[i][·] yalnız D[i−1][·]
          satırına bağlı olduğundan iki satır yeter; kısa dizgi sütun
          yapılırsa bellek O(min(n, m)). Değer tam tabloyla aynıdır ama
          çözüm GERİ ÇIKARILAMAZ: geri çıkarma her i için D[i−1][·]
          satırını ister; o satırlar üzerine yazıldı. (C sürümüyle aynı
          hesaplar; Python'da n = 3000 yerine 1000 — süre bütçesi.)
Çalıştır: python3 H13_K01_iki_satir.py   (kodlar/kavram içinde;
          ortak_rastgele ../python klasöründen alınır)
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402


def uzaklik_tam(a, b):
    """Tam tablo (karşılaştırma için): (n+1)(m+1) hücre"""
    n, m = len(a), len(b)
    D = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        for j in range(m + 1):
            if i == 0 or j == 0:
                D[i][j] = i + j
            else:
                D[i][j] = min(D[i - 1][j] + 1, D[i][j - 1] + 1,
                              D[i - 1][j - 1] + (a[i - 1] != b[j - 1]))
    return D[n][m]


def uzaklik_iki_satir(a, b):
    """İki satır: onceki = D[i-1][·], simdi = D[i][·]; b kısa olmalı"""
    m = len(b)
    onceki = list(range(m + 1))     # D[0][j]
    simdi = [0] * (m + 1)
    for i in range(1, len(a) + 1):
        simdi[0] = i                # D[i][0]
        for j in range(1, m + 1):
            simdi[j] = min(onceki[j] + 1, simdi[j - 1] + 1,
                           onceki[j - 1] + (a[i - 1] != b[j - 1]))
        onceki, simdi = simdi, onceki          # satırları değiştir
    return onceki[m]


def lcs_iki_satir(a, b):
    m = len(b)
    onceki, simdi = [0] * (m + 1), [0] * (m + 1)
    for i in range(1, len(a) + 1):
        for j in range(1, m + 1):
            if a[i - 1] == b[j - 1]:
                simdi[j] = onceki[j - 1] + 1
            else:
                simdi[j] = (onceki[j] if onceki[j] >= simdi[j - 1]
                            else simdi[j - 1])
        onceki, simdi = simdi, onceki
    return onceki[m]


def main():
    print("1) Düzenleme uzaklığı: tam tablo ile iki satır")
    for a0, b0 in (("kitten", "sitting"), ("sunday", "saturday"),
                   ("ABCBDAB", "BDCABA")):
        a, b = (a0, b0) if len(a0) >= len(b0) else (b0, a0)
        n, m = len(a), len(b)
        print(f"  {a0} / {b0}: tam = {uzaklik_tam(a, b)} "
              f"({(n + 1) * (m + 1)} hücre), iki satır = "
              f"{uzaklik_iki_satir(a, b)} ({2 * (m + 1)} hücre)")
    print("\n2) LCS uzunluğu, rastgele DNA (Örnek 8: tohum 7, n = m)")
    harf = "ACGT"
    for n in (300, 1000):
        rastgele_tohum(7)
        x = "".join(harf[rastgele_aralik(0, 3)] for _ in range(n))
        y = "".join(harf[rastgele_aralik(0, 3)] for _ in range(n))
        tam, iki = (n + 1) * (n + 1) * 4, 2 * (n + 1) * 4
        print(f"  n = {n:5d}: LCS = {lcs_iki_satir(x, y)}; tam tablo {tam} "
              f"bayt, iki satır {iki} bayt ({tam // iki} kat az; C int "
              f"eşdeğeri)")
    print("  (n = 300 için LCS Örnek 8 ile aynı olmalı: 199)")
    print("\n3) Geri çıkarma neden kaybolur? Döngü bittiğinde yalnız "
          "D[n-1][·] ve D[n][·] kalır;")
    print("  geri giderken gereken daha üstteki satırlar silinmiştir: değer "
          "var, yol yok.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok. (min burada üç sayının küçüğü; algoritmanın
# kendisi değil, dile özgü deyiş.)

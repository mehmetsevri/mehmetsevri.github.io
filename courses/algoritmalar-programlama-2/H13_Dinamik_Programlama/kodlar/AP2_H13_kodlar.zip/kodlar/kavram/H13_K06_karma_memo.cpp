/* H13_K06_karma_memo.cpp — AP-2 Hafta 13 · Kavram 6 (Dil Penceresi)
 * Amaç    : Memo için iki araç: (1) DİZİ (std::vector, bütün hücreler
 *           baştan, −1 = hesaplanmadı); (2) std::unordered_map (H10'un
 *           kütüphane karşılığı): yalnız ziyaret edilen durumlar saklanır.
 *           Çıktı C ve Python sürümleriyle aynıdır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_K06_karma_memo.cpp -I../cpp -o H13_K06_karma_memo
 * Çalıştır: ./H13_K06_karma_memo
 */
#include <cstdio>
#include <unordered_map>
#include <vector>

#include "ortak_rastgele.hpp"

static std::vector<int> a;
static int n;
static long long hedef;

static std::vector<long long> dizi;
static long long dizi_hesaplanan = 0;

static long long say_dizi(int i, long long t)
{
    if (t > hedef) {
        return 0;
    }
    long long& h = dizi[static_cast<long long>(i) * (hedef + 1) + t];
    if (h == -1) {
        h = i == n ? (t == hedef) : say_dizi(i + 1, t) +
                                    say_dizi(i + 1, t + a[i]);
        dizi_hesaplanan++;
    }
    return h;
}

static std::unordered_map<long long, long long> memo;   // anahtar: durum

static long long say_karma(int i, long long t)
{
    if (t > hedef) {
        return 0;
    }
    const long long k = static_cast<long long>(i) * (hedef + 1) + t;
    auto it = memo.find(k);
    if (it != memo.end()) {
        return it->second;                  // not alınmış
    }
    long long s = i == n ? (t == hedef) : say_karma(i + 1, t) +
                                          say_karma(i + 1, t + a[i]);
    memo[k] = s;                            // özyinelemeden SONRA ekle
    return s;
}

int main()
{
    n = 30;
    rastgele_tohum(42);
    a = rastgele_dizi(n, 1, 40);
    long long toplam = 0;
    for (int x : a) {
        toplam += x;
    }
    hedef = toplam / 2;
    std::printf("alt küme toplamı (Örnek 12 girdisi, n = %d, hedef = %lld): "
                "durum (i, t)\n", n, hedef);
    const long long hucre = static_cast<long long>(n + 1) * (hedef + 1);
    dizi.assign(hucre, -1);
    long long s1 = say_dizi(0, 0);
    long long s2 = say_karma(0, 0);
    std::printf("  dizi memo   : sonuç %lld; ayrılan hücre %lld, hesaplanan "
                "%lld (%.1f %%)\n", s1, hucre, dizi_hesaplanan,
                100.0 * static_cast<double>(dizi_hesaplanan) / hucre);
    std::printf("  karma memo  : sonuç %lld; saklanan durum %lld (yalnız "
                "ziyaret edilenler)\n", s2,
                static_cast<long long>(memo.size()));
    std::printf("  aynı sonuç: %s; aynı durum sayısı: %s\n",
                s1 == s2 ? "evet" : "HAYIR",
                dizi_hesaplanan == static_cast<long long>(memo.size())
                    ? "evet" : "HAYIR");
    return 0;
}

// Kütüphane karşılığı: C — yok (elle karma tablosu, H10); C++ —
// std::unordered_map; Python — dict ya da functools.cache.

/* H13_K07_dag_yol.c — AP-2 Hafta 13 · Kavram 7
 * Amaç    : DP = alt problem DAG'ında en kısa / en uzun yol. (1) Bozuk para
 *           {1, 3, 4}, tutar 6: düğüm t, kenar t → t + c (ağırlık 1).
 *           Düğümler topolojik sırayla (t artan) ele alınır ve H12'deki
 *           gibi kenarlar GEVŞETİLİR ("itme"); sonuç Örnek 3'ün "çekme"
 *           biçimli enaz tablosuyla aynıdır. (2) LIS: düğüm i, kenar j → i
 *           (j < i, a[j] < a[i]); en uzun yol = Örnek 7'nin uz dizisi.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_K07_dag_yol.c -o H13_K07_dag_yol
 * Çalıştır: ./H13_K07_dag_yol
 */
#include <limits.h>
#include <stdio.h>

#define S 6
#define SONSUZ INT_MAX

int main(void)
{
    const int paralar[] = {1, 3, 4};
    int d[S + 1], kenar = 0, gevsetme = 0;
    d[0] = 0;
    for (int t = 1; t <= S; t++) {
        d[t] = SONSUZ;
    }
    for (int u = 0; u <= S; u++) {            /* topolojik sıra: u artan */
        for (int i = 0; i < 3; i++) {
            int v = u + paralar[i];
            if (v > S) {
                continue;
            }
            kenar++;
            if (d[u] != SONSUZ && d[u] + 1 < d[v]) {
                d[v] = d[u] + 1;                /* gevşetme (H12) */
                gevsetme++;
            }
        }
    }
    printf("1) Bozuk para {1, 3, 4}, S = %d: DAG'da 0'dan t'ye en kısa yol\n",
           S);
    printf("  t       :");
    for (int t = 0; t <= S; t++) {
        printf(" %2d", t);
    }
    printf("\n  uzaklık :");
    for (int t = 0; t <= S; t++) {
        printf(" %2d", d[t]);
    }
    printf("\n  kenar = %d, başarılı gevşetme = %d (Örnek 3: 0 1 2 1 1 2 2)\n",
           kenar, gevsetme);

    const int a[] = {5, 2, 8, 6, 3, 6, 9, 7};
    int n = 8, uz[8], en = 0;
    kenar = 0;
    for (int i = 0; i < n; i++) {             /* topolojik sıra: i artan */
        uz[i] = 1;
        for (int j = 0; j < i; j++) {
            if (a[j] < a[i]) {
                kenar++;
                if (uz[j] + 1 > uz[i]) {
                    uz[i] = uz[j] + 1;
                }
            }
        }
        if (uz[i] > en) {
            en = uz[i];
        }
    }
    printf("\n2) LIS: a = {5, 2, 8, 6, 3, 6, 9, 7}; DAG'da en uzun yol "
           "(düğüm sayısı)\n  uz      :");
    for (int i = 0; i < n; i++) {
        printf(" %2d", uz[i]);
    }
    printf("\n  kenar (j < i, a[j] < a[i]) = %d, en uzun yol = %d düğüm "
           "(Örnek 7: 4)\n", kenar, en);
    return 0;
}

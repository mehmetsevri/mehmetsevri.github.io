/* H13_04_bozuk_para_yollar.c — AP-2 Hafta 13 · Örnek 4 (★★)
 * Amaç    : Bozuk para: tutar kaç farklı yolla ödenir? Sayma DP'si ve döngü
 *           sırası tuzağı: dış döngü PARA → kombinasyon (sıra önemsiz),
 *           dış döngü TUTAR → permütasyon (sıra önemli). Aynı girdide
 *           farklı sayılar; listelemeyle doğrulama; büyük tutar mod 10^9+7
 * DP      : durum yol[t] = t tutarının ödeniş sayısı · geçiş yol[t] +=
 *           yol[t−c] · temel yol[0] = 1 (boş ödeme), diğerleri 0 · sıra
 *           KOMBİNASYON: her para c için t = c..S artan (para dışta);
 *           PERMÜTASYON: t = 1..S artan, içte her para (tutar dışta) ·
 *           cevap yol[S]
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_04_bozuk_para_yollar.c -o H13_04_bozuk_para_yollar
 * Çalıştır: ./H13_04_bozuk_para_yollar
 * Eşleri  : cpp/H13_04_bozuk_para_yollar.cpp ·
 *           python/H13_04_bozuk_para_yollar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_S 1000
#define MOD 1000000007LL

static long long yol[MAKS_S + 1];
static int secilen[MAKS_S];        /* listelemede o anki paralar */
static int secilen_sayi = 0;

static void yaz_satir(int S)
{
    for (int t = 0; t <= S; t++) {
        printf(" %3lld", yol[t]);
    }
    printf("\n");
}

/* Kombinasyon: dış döngü para. c parası işlenirken yol[t], yalnız ilk
 * paralarla (c dahil) yapılan ödemeleri sayar: sıra önemsiz. */
static long long kombinasyon(const int paralar[], int k, int S,
                             int satirlari_yaz)
{
    yol[0] = 1;                            /* temel durum */
    for (int t = 1; t <= S; t++) {
        yol[t] = 0;
    }
    for (int i = 0; i < k; i++) {          /* DIŞ: para */
        int c = paralar[i];
        for (int t = c; t <= S; t++) {     /* İÇ: tutar */
            yol[t] = (yol[t] + yol[t - c]) % MOD;
        }
        if (satirlari_yaz) {
            printf("  para %d sonrası:", c);
            yaz_satir(S);
        }
    }
    return yol[S];
}

/* Permütasyon: dış döngü tutar. yol[t] her paranın SON adım olabildiği
 * bütün dizileri sayar: 1+2 ile 2+1 ayrı sayılır. */
static long long permutasyon(const int paralar[], int k, int S)
{
    yol[0] = 1;                            /* temel durum */
    for (int t = 1; t <= S; t++) {         /* DIŞ: tutar */
        yol[t] = 0;
        for (int i = 0; i < k; i++) {      /* İÇ: para */
            if (paralar[i] <= t) {
                yol[t] = (yol[t] + yol[t - paralar[i]]) % MOD;
            }
        }
    }
    return yol[S];
}

static void yaz_secilen(void)
{
    printf("    ");
    for (int i = 0; i < secilen_sayi; i++) {
        printf(i > 0 ? "+%d" : "%d", secilen[i]);
    }
    printf("\n");
}

/* Doğrulama 1: kombinasyonlar — paralar artmayan sırada (en büyük önce),
 * en_buyuk_i: kullanılabilecek en büyük para indisi */
static long long kombinasyon_listele(const int paralar[], int en_buyuk_i,
                                     int kalan)
{
    if (kalan == 0) {
        yaz_secilen();
        return 1;
    }
    long long say = 0;
    for (int i = en_buyuk_i; i >= 0; i--) {
        if (paralar[i] <= kalan) {
            secilen[secilen_sayi++] = paralar[i];
            say += kombinasyon_listele(paralar, i, kalan - paralar[i]);
            secilen_sayi--;
        }
    }
    return say;
}

/* Doğrulama 2: permütasyonlar — her adımda her para denenir */
static long long permutasyon_listele(const int paralar[], int k, int kalan)
{
    if (kalan == 0) {
        yaz_secilen();
        return 1;
    }
    long long say = 0;
    for (int i = 0; i < k; i++) {
        if (paralar[i] <= kalan) {
            secilen[secilen_sayi++] = paralar[i];
            say += permutasyon_listele(paralar, k, kalan - paralar[i]);
            secilen_sayi--;
        }
    }
    return say;
}

int main(void)
{
    const int p1[] = {1, 2, 5};
    const int S = 5;
    printf("1) Paralar {1, 2, 5}, tutar %d: aynı geçiş, farklı döngü "
           "sırası\n", S);
    printf("  t             :");
    for (int t = 0; t <= S; t++) {
        printf(" %3d", t);
    }
    printf("\n  KOMBİNASYON (dış döngü para):\n");
    long long kom = kombinasyon(p1, 3, S, 1);
    long long per = permutasyon(p1, 3, S);
    printf("  PERMÜTASYON (dış döngü tutar):\n  yol[t]        :");
    yaz_satir(S);
    printf("  kombinasyon = %lld, permütasyon = %lld  (sıra önemli mi?)\n",
           kom, per);

    printf("\n2) Doğrulama: kombinasyonlar (büyük para önce)\n");
    long long ks = kombinasyon_listele(p1, 2, S);
    printf("  listelenen = %lld\n", ks);
    printf("  permütasyonlar (her sıra ayrı)\n");
    long long ps = permutasyon_listele(p1, 3, S);
    printf("  listelenen = %lld; tablo ile aynı: %s\n", ps,
           ks == kom && ps == per ? "evet" : "HAYIR");

    printf("\n3) Tutar 0..10 için iki sayım (paralar {1, 2, 5})\n");
    printf("  t          :");
    for (int t = 0; t <= 10; t++) {
        printf(" %4d", t);
    }
    printf("\n  kombinasyon:");
    for (int t = 0; t <= 10; t++) {
        printf(" %4lld", kombinasyon(p1, 3, t, 0));
    }
    printf("\n  permütasyon:");
    for (int t = 0; t <= 10; t++) {
        printf(" %4lld", permutasyon(p1, 3, t));
    }
    printf("\n");

    const int p2[] = {1, 5, 10, 25, 50, 100};
    printf("\n4) Büyük tutar, iki sayım da mod p = 10^9 + 7: paralar "
           "{1, 5, 10, 25, 50, 100} kuruş\n");
    const int tutarlar[] = {100, 500, 1000};
    for (int k = 0; k < 3; k++) {
        int t = tutarlar[k];
        long long kb = kombinasyon(p2, 6, t, 0);
        long long pm = permutasyon(p2, 6, t);
        printf("  tutar %4d: kombinasyon = %lld, permütasyon = %lld\n", t,
               kb, pm);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python); sayma DP'si elle. */

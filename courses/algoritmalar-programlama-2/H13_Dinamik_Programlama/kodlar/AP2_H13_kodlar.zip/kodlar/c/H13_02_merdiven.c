/* H13_02_merdiven.c — AP-2 Hafta 13 · Örnek 2 (★)
 * Amaç    : Merdiven çıkma: her adımda 1 ya da 2 basamak; n. basamağa kaç
 *           farklı yolla çıkılır? İlk durum–geçiş tanımı; yol[n] = F(n+1);
 *           bütün yolların listelenmesiyle doğrulama; {1, 2, 3} değişkesi
 * DP      : durum yol[i] = i. basamağa çıkma yolu sayısı · geçiş
 *           yol[i] = yol[i−1] + yol[i−2] (son adım 1 ya da 2) · temel
 *           yol[0] = 1 (hiç adım atmamak bir yoldur), yol[1] = 1 · sıra
 *           i = 2..n artan · cevap yol[n]
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_02_merdiven.c -o H13_02_merdiven
 * Çalıştır: ./H13_02_merdiven
 * Eşleri  : cpp/H13_02_merdiven.cpp · python/H13_02_merdiven.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define MAKS_N 40
#define MOD 1000000007LL

static long long yol[MAKS_N + 1];
static int adimlar[MAKS_N];        /* listelemede o anki yol */
static int adim_sayisi = 0;
static long long listelenen = 0;

/* yol[0..n] tablosunu doldurur (1 ya da 2 basamak) */
static void merdiven_tablo(int n)
{
    yol[0] = 1;                            /* temel durum */
    yol[1] = 1;
    for (int i = 2; i <= n; i++) {
        yol[i] = yol[i - 1] + yol[i - 2]; /* son adım 1 ya da 2 */
    }
}

/* Doğrulama: kalan basamağa bütün adım dizilerini yazar (önce 1, sonra 2) */
static void yollari_listele(int kalan)
{
    if (kalan == 0) {
        listelenen++;
        printf("    ");
        for (int k = 0; k < adim_sayisi; k++) {
            printf(k > 0 ? "+%d" : "%d", adimlar[k]);
        }
        printf("\n");
        return;
    }
    for (int adim = 1; adim <= 2; adim++) {
        if (adim <= kalan) {
            adimlar[adim_sayisi++] = adim;
            yollari_listele(kalan - adim);
            adim_sayisi--;
        }
    }
}

/* Değişke: 1, 2 ya da 3 basamak; yol3[i] = yol3[i−1] + yol3[i−2] +
 * yol3[i−3] (i − k >= 0 olan terimler) */
static long long merdiven_uclu(int n)
{
    long long yol3[MAKS_N + 1];
    yol3[0] = 1;
    for (int i = 1; i <= n; i++) {
        yol3[i] = 0;
        for (int k = 1; k <= 3; k++) {
            if (i - k >= 0) {
                yol3[i] += yol3[i - k];
            }
        }
    }
    return yol3[n];
}

/* Büyük n: iki değişken + mod 10^9 + 7 */
static long long merdiven_mod(int n)
{
    long long onceki = 1, simdiki = 1;     /* yol[0], yol[1] */
    for (int i = 2; i <= n; i++) {
        long long sonraki = (onceki + simdiki) % MOD;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

int main(void)
{
    printf("1) Durum ve geçiş\n");
    printf("  durum : yol[i] = i. basamağa çıkmanın yol sayısı\n");
    printf("  geçiş : yol[i] = yol[i-1] + yol[i-2]  (son adım 1 ya da 2)\n");
    printf("  temel : yol[0] = 1, yol[1] = 1;  cevap: yol[n]\n");

    merdiven_tablo(MAKS_N);
    long long fib[MAKS_N + 2];
    fib[0] = 0;
    fib[1] = 1;
    for (int i = 2; i <= MAKS_N + 1; i++) {
        fib[i] = fib[i - 1] + fib[i - 2];
    }
    printf("\n2) Tablo ve Fibonacci ilişkisi: yol[n] = F(n+1)\n");
    printf("  n      :");
    for (int n = 0; n <= 10; n++) {
        printf(" %3d", n);
    }
    printf("\n  yol[n] :");
    for (int n = 0; n <= 10; n++) {
        printf(" %3lld", yol[n]);
    }
    printf("\n  F(n+1) :");
    for (int n = 0; n <= 10; n++) {
        printf(" %3lld", fib[n + 1]);
    }
    int esit = 1;
    for (int n = 0; n <= MAKS_N; n++) {
        if (yol[n] != fib[n + 1]) {
            esit = 0;
        }
    }
    printf("\n  n = 0..%d için yol[n] = F(n+1): %s; yol[%d] = %lld\n",
           MAKS_N, esit ? "evet" : "HAYIR", MAKS_N, yol[MAKS_N]);

    printf("\n3) Doğrulama: n = 5 için bütün yollar (önce 1, sonra 2)\n");
    yollari_listele(5);
    printf("  listelenen = %lld, tablo yol[5] = %lld: %s\n", listelenen,
           yol[5], listelenen == yol[5] ? "aynı" : "FARKLI");

    printf("\n4) Değişke: 1, 2 ya da 3 basamak "
           "(yol3[i] = yol3[i-1] + yol3[i-2] + yol3[i-3])\n  yol3   :");
    for (int n = 0; n <= 10; n++) {
        printf(" %3lld", merdiven_uclu(n));
    }
    printf("\n");

    printf("\n5) Büyük n: yol[n] mod 10^9 + 7 (iki değişken)\n");
    const int buyuk[] = {40, 1000, 100000};
    for (int k = 0; k < 3; k++) {
        printf("  yol[%d] mod 1000000007 = %lld\n", buyuk[k],
               merdiven_mod(buyuk[k]));
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python); tablo elle doldurulur. */

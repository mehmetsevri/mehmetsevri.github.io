/* H13_15_matris_zinciri.c — AP-2 Hafta 13 · Örnek 15 (★★★, meydan okuma)
 * Amaç    : Matris zinciri çarpımı (aralık DP'si): A1·A2·…·An çarpımı için
 *           skaler çarpım sayısını en aza indiren parantezleme; m ve s
 *           tabloları, parantezlemenin geri çıkarılması; kaba kuvvet
 *           özyinelemeyle (3^(n−1) çağrı) ve soldan sağa çarpımla kıyas
 * DP      : durum m[i][j] = Ai..Aj çarpımının en az skaler çarpımı (Ai:
 *           p[i−1] × p[i]) · geçiş m[i][j] = min_{i<=k<j} m[i][k] +
 *           m[k+1][j] + p[i−1]·p[k]·p[j] · temel m[i][i] = 0 · sıra
 *           zincir uzunluğu l = 2..n (kısa aralıklar önce), i artan ·
 *           cevap m[1][n] · geri çıkarma s[i][j] = en iyi k (eşitlikte EN
 *           KÜÇÜK k); parantez(i, j) = (parantez(i, s) parantez(s+1, j))
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_15_matris_zinciri.c ortak_rastgele.c \
 *           -o H13_15_matris_zinciri
 * Çalıştır: ./H13_15_matris_zinciri
 * Eşleri  : cpp/H13_15_matris_zinciri.cpp · python/H13_15_matris_zinciri.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stdio.h>

#include "ortak_rastgele.h"

#define MAKS_N 16

static long long m[MAKS_N + 1][MAKS_N + 1];
static int s[MAKS_N + 1][MAKS_N + 1];
static long long denenen_k = 0;    /* iç döngü adımı */
static long long cagri = 0;        /* kaba kuvvet çağrısı */

/* Aralık DP'si: m[1..n][1..n], s[1..n][1..n] */
static long long matris_zinciri(const int p[], int n)
{
    for (int i = 1; i <= n; i++) {
        m[i][i] = 0;                           /* temel: tek matris */
    }
    for (int l = 2; l <= n; l++) {             /* zincir uzunluğu */
        for (int i = 1; i + l - 1 <= n; i++) {
            int j = i + l - 1;
            m[i][j] = LLONG_MAX;
            for (int k = i; k < j; k++) {
                denenen_k++;
                long long q = m[i][k] + m[k + 1][j] +
                              (long long)p[i - 1] * p[k] * p[j];
                if (q < m[i][j]) {             /* eşitlikte küçük k */
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }
    return m[1][n];
}

static void parantez_yaz(int i, int j)
{
    if (i == j) {
        printf("A%d", i);
        return;
    }
    printf("(");
    parantez_yaz(i, s[i][j]);
    parantez_yaz(s[i][j] + 1, j);
    printf(")");
}

/* Kâhin: kaba kuvvet özyineleme — bütün bölme noktaları, not alma yok */
static long long kaba(const int p[], int i, int j)
{
    cagri++;
    if (i == j) {
        return 0;
    }
    long long en = LLONG_MAX;
    for (int k = i; k < j; k++) {
        long long q = kaba(p, i, k) + kaba(p, k + 1, j) +
                      (long long)p[i - 1] * p[k] * p[j];
        if (q < en) {
            en = q;
        }
    }
    return en;
}

/* Soldan sağa: (((A1 A2) A3) ...) maliyeti */
static long long soldan_saga(const int p[], int n)
{
    long long toplam = 0;
    for (int k = 2; k <= n; k++) {
        toplam += (long long)p[0] * p[k - 1] * p[k];
    }
    return toplam;
}

/* Parantezleme sayısı P(n) = Σ P(k) P(n−k) (Catalan sayısı C(n−1)) */
static long long parantezleme_sayisi(int n)
{
    long long P[MAKS_N + 1];
    P[1] = 1;
    for (int t = 2; t <= n; t++) {
        P[t] = 0;
        for (int k = 1; k < t; k++) {
            P[t] += P[k] * P[t - k];
        }
    }
    return P[n];
}

static void coz_ve_yaz(const int p[], int n, int tablolari_yaz)
{
    denenen_k = 0;
    long long en = matris_zinciri(p, n);
    if (tablolari_yaz) {
        printf("  m[i][j] (en az skaler çarpım; i > j boş)\n    i\\j");
        for (int j = 1; j <= n; j++) {
            printf(" %7d", j);
        }
        printf("\n");
        for (int i = 1; i <= n; i++) {
            printf("  %4d ", i);
            for (int j = 1; j <= n; j++) {
                if (j < i) {
                    printf("        ");
                } else {
                    printf(" %7lld", m[i][j]);
                }
            }
            printf("\n");
        }
        printf("  s[i][j] (en iyi bölme k)\n    i\\j");
        for (int j = 2; j <= n; j++) {
            printf(" %3d", j);
        }
        printf("\n");
        for (int i = 1; i < n; i++) {
            printf("  %4d ", i);
            for (int j = 2; j <= n; j++) {
                if (j <= i) {
                    printf("    ");
                } else {
                    printf(" %3d", s[i][j]);
                }
            }
            printf("\n");
        }
    }
    long long sol = soldan_saga(p, n);
    printf("  en az = m[1][%d] = %lld; parantezleme: ", n, en);
    parantez_yaz(1, n);
    printf("\n  soldan sağa çarpım = %lld (%.2f kat)\n", sol,
           (double)sol / (double)en);
    printf("  DP: hücre (i <= j) = %d, denenen k = %lld = (n^3 - n)/6\n",
           n * (n + 1) / 2, denenen_k);
    cagri = 0;
    long long k = kaba(p, 1, n);
    printf("  kaba kuvvet: %lld çağrı (= 3^(n-1)), sonuç %lld (%s); "
           "parantezleme sayısı = %lld\n", cagri, k,
           k == en ? "aynı" : "FARKLI", parantezleme_sayisi(n));
}

int main(void)
{
    const int p1[] = {30, 35, 15, 5, 10, 20, 25};
    printf("1) p = {30, 35, 15, 5, 10, 20, 25} (Cormen vd.): A1..A6, "
           "Ai = p[i-1] x p[i]\n");
    coz_ve_yaz(p1, 6, 1);

    int p2[13];
    rastgele_tohum(9);
    rastgele_dizi(p2, 13, 5, 50);
    printf("\n2) 12 matris, boyutlar (tohum 9, 5..50): p =");
    for (int i = 0; i <= 12; i++) {
        printf(" %d", p2[i]);
    }
    printf("\n");
    coz_ve_yaz(p2, 12, 0);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). NumPy'nin
 * numpy.linalg.multi_dot'u aynı DP ile çarpma sırası seçer (ders dışı;
 * yalnız standart kütüphane kullanılır). */

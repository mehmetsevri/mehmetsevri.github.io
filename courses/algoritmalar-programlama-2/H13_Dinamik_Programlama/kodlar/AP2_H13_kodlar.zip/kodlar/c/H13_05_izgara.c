/* H13_05_izgara.c — AP-2 Hafta 13 · Örnek 5 (★★)
 * Amaç    : 2B DP: (1) ızgarada sol üstten sağ alta (yalnız sağa / aşağı)
 *           yol sayısı, büyük ızgarada mod 10^9 + 7; (2) engelli ızgarada
 *           yol sayısı; (3) engelli ızgarada en küçük maliyetli yol ve
 *           yolun geri çıkarılması
 * DP      : (1)(2) durum yol[i][j] = (0,0)'dan (i,j)'ye yol sayısı ·
 *           geçiş yol[i][j] = yol[i−1][j] + yol[i][j−1] (engelde 0) ·
 *           temel yol[0][0] = 1 · (3) durum m[i][j] = (i,j)'ye en küçük
 *           toplam maliyet · geçiş m[i][j] = a[i][j] + min(m[i−1][j],
 *           m[i][j−1]) · temel m[0][0] = a[0][0]; engel ve ulaşılamayan
 *           = ∞ · sıra satır öncelikli (i artan, j artan) · cevap
 *           [R−1][C−1] · geri çıkarma: eşitlikte YUKARIDAN gelinir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_05_izgara.c -o H13_05_izgara
 * Çalıştır: ./H13_05_izgara
 * Eşleri  : cpp/H13_05_izgara.cpp · python/H13_05_izgara.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stdio.h>

#define R 5
#define C 6
#define ENGEL (-1)
#define SONSUZ INT_MAX
#define MOD 1000000007LL
#define MAKS_N 500

/* maliyet ızgarası; ENGEL = geçilemez hücre */
static const int a[R][C] = {
    {1, 3, 1, 2, 8, 1},
    {1, 5, ENGEL, 1, 1, 2},
    {4, 2, 1, ENGEL, 3, 1},
    {ENGEL, 1, 9, 1, 1, 2},
    {2, 1, 2, 4, ENGEL, 1},
};

/* (1) engelsiz r x c ızgara: tam tablo; cevap yol[r-1][c-1] */
static void yol_sayisi_tablo(int r, int c, long long yol[][C])
{
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            if (i == 0 || j == 0) {
                yol[i][j] = 1;                 /* ilk satır ve sütun */
            } else {
                yol[i][j] = yol[i - 1][j] + yol[i][j - 1];
            }
        }
    }
}

/* Büyük n x n: tek satır tamponu (satır öncelikli doldurma; yol[j]
 * soldaki hücreyi bu satırdan, yukarıdakini önceki satırdan tutar) */
static long long yol_sayisi_mod(int n)
{
    long long yol[MAKS_N];
    if (n < 1 || n > MAKS_N) {
        return 0;
    }
    for (int j = 0; j < n; j++) {
        yol[j] = 1;                            /* ilk satır */
    }
    for (int i = 1; i < n; i++) {
        for (int j = 1; j < n; j++) {
            yol[j] = (yol[j] + yol[j - 1]) % MOD;  /* yukarı + sol */
        }
    }
    return yol[n - 1];
}

/* C(n, k) tam değer (küçük n için kâhin): çarp-böl her adımda tam bölünür */
static long long binom(int n, int k)
{
    long long sonuc = 1;
    for (int i = 1; i <= k; i++) {
        sonuc = sonuc * (n - k + i) / i;
    }
    return sonuc;
}

/* (2) engelli ızgara: engel hücresinde yol 0 */
static long long engelli_yol_sayisi(long long yol[R][C])
{
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (a[i][j] == ENGEL) {
                yol[i][j] = 0;
            } else if (i == 0 && j == 0) {
                yol[i][j] = 1;                 /* temel durum */
            } else {
                long long ust = i > 0 ? yol[i - 1][j] : 0;
                long long sol = j > 0 ? yol[i][j - 1] : 0;
                yol[i][j] = ust + sol;
            }
        }
    }
    return yol[R - 1][C - 1];
}

/* (3) en küçük maliyet; m[i][j] = SONSUZ: engel ya da ulaşılamaz */
static int en_kucuk_maliyet(int m[R][C])
{
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (a[i][j] == ENGEL) {
                m[i][j] = SONSUZ;
                continue;
            }
            if (i == 0 && j == 0) {
                m[i][j] = a[0][0];             /* temel durum */
                continue;
            }
            int ust = i > 0 ? m[i - 1][j] : SONSUZ;
            int sol = j > 0 ? m[i][j - 1] : SONSUZ;
            int enk = ust <= sol ? ust : sol;  /* eşitlikte yukarı */
            m[i][j] = enk == SONSUZ ? SONSUZ : enk + a[i][j];
        }
    }
    return m[R - 1][C - 1];
}

/* Yolu sağ alttan geri çıkarır; yol_i/yol_j'ye BAŞTAN SONA yazar */
static int yolu_geri_cikar(int m[R][C], int yol_i[], int yol_j[])
{
    int uzunluk = R + C - 1;
    int i = R - 1, j = C - 1;
    for (int k = uzunluk - 1; k >= 0; k--) {
        yol_i[k] = i;
        yol_j[k] = j;
        if (i == 0) {
            j--;
        } else if (j == 0) {
            i--;
        } else if (m[i - 1][j] <= m[i][j - 1]) {
            i--;                               /* eşitlikte yukarı */
        } else {
            j--;
        }
    }
    return uzunluk;
}

static void yaz_hucre_ll(long long v, int engel_mi)
{
    if (engel_mi) {
        printf("    #");
    } else {
        printf(" %4lld", v);
    }
}

int main(void)
{
    long long yol[R][C];
    printf("1) Izgarada yol sayısı (yalnız sağa ya da aşağı), 3 x 4\n");
    printf("  yol[i][j] = yol[i-1][j] + yol[i][j-1]; ilk satır ve sütun "
           "1\n");
    yol_sayisi_tablo(3, 4, yol);
    for (int i = 0; i < 3; i++) {
        printf(" ");
        for (int j = 0; j < 4; j++) {
            yaz_hucre_ll(yol[i][j], 0);
        }
        printf("\n");
    }
    printf("  cevap yol[2][3] = %lld = C(5, 2) = %lld\n", yol[2][3],
           binom(5, 2));

    printf("\n2) n x n ızgara: yol = C(2n-2, n-1); tek satır tamponu, "
           "mod 10^9 + 7\n");
    const int ns[] = {16, 30, 100, 500};
    for (int k = 0; k < 4; k++) {
        int n = ns[k];
        long long v = yol_sayisi_mod(n);
        if (n <= 30) {
            long long b = binom(2 * n - 2, n - 1);   /* tam değer */
            printf("  n = %3d: %lld  (tam C(%d, %d) = %lld; tam mod p = "
                   "%lld)\n", n, v, 2 * n - 2, n - 1, b, b % MOD);
        } else {
            printf("  n = %3d: %lld  (mod 1000000007)\n", n, v);
        }
    }

    printf("\n3) Engelli ızgara (# = engel), %d x %d\n  maliyetler:\n", R,
           C);
    for (int i = 0; i < R; i++) {
        printf(" ");
        for (int j = 0; j < C; j++) {
            yaz_hucre_ll(a[i][j], a[i][j] == ENGEL);
        }
        printf("\n");
    }
    long long es = engelli_yol_sayisi(yol);
    printf("  yol sayısı tablosu (engelde 0):\n");
    for (int i = 0; i < R; i++) {
        printf(" ");
        for (int j = 0; j < C; j++) {
            yaz_hucre_ll(yol[i][j], a[i][j] == ENGEL);
        }
        printf("\n");
    }
    printf("  engelli yol sayısı = %lld (engelsiz 5 x 6: %lld)\n", es,
           binom(R + C - 2, R - 1));

    int m[R][C];
    int enk = en_kucuk_maliyet(m);
    printf("\n4) En küçük maliyetli yol: m[i][j] = a[i][j] + "
           "min(m[i-1][j], m[i][j-1])\n");
    for (int i = 0; i < R; i++) {
        printf(" ");
        for (int j = 0; j < C; j++) {
            if (a[i][j] == ENGEL) {
                printf("    #");
            } else if (m[i][j] == SONSUZ) {
                printf("    ∞");
            } else {
                printf(" %4d", m[i][j]);
            }
        }
        printf("\n");
    }
    if (enk == SONSUZ) {
        printf("  sağ alt hücre ulaşılamaz\n");
        return 0;
    }
    int yi[R + C], yj[R + C];
    int uz = yolu_geri_cikar(m, yi, yj);
    printf("  en küçük maliyet = %d; yol (eşitlikte yukarıdan):\n  ", enk);
    int toplam = 0;
    for (int k = 0; k < uz; k++) {
        toplam += a[yi[k]][yj[k]];
        printf(k > 0 ? " -> (%d,%d)" : "(%d,%d)", yi[k], yj[k]);
    }
    printf("\n  yol üzerindeki maliyet toplamı = %d (%s)\n", toplam,
           toplam == enk ? "tutarlı" : "TUTARSIZ");
    printf("  yol çizimi (* = yol, # = engel):\n");
    for (int i = 0; i < R; i++) {
        printf("   ");
        for (int j = 0; j < C; j++) {
            char ch = a[i][j] == ENGEL ? '#' : '.';
            for (int k = 0; k < uz; k++) {
                if (yi[k] == i && yj[k] == j) {
                    ch = '*';
                }
            }
            printf(" %c", ch);
        }
        printf("\n");
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kombinatorik kâhin: C(n, k)
 * — Python math.comb (yalnız doğrulama). */

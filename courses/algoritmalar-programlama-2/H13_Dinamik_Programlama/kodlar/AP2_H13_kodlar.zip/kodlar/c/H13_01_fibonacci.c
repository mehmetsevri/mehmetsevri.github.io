/* H13_01_fibonacci.c — AP-2 Hafta 13 · Örnek 1 (★)
 * Amaç    : Fibonacci'nin dört sürümü: saf özyineleme (çağrı sayısı
 *           2·F(n+1) − 1, denetlenir), memo ("hesaplanmadı" = −1), tablo
 *           ve iki değişken; büyük n için uint64_t sınırı ve mod 10^9 + 7
 * DP      : durum F(i) · geçiş F(i) = F(i−1) + F(i−2) · temel F(0) = 0,
 *           F(1) = 1 · sıra i = 2, 3, …, n (artan) · cevap tablo[n]
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_01_fibonacci.c -o H13_01_fibonacci
 * Çalıştır: ./H13_01_fibonacci
 * Eşleri  : cpp/H13_01_fibonacci.cpp · python/H13_01_fibonacci.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define MAKS_N 100
#define MOD 1000000007ULL

static long long cagri = 0;        /* fonksiyon çağrısı sayacı */
static long long hesaplanan = 0;   /* memo'ya ilk kez yazılan hücre */
static long long memo[MAKS_N + 1];

/* 1) Saf özyineleme: aynı alt problemler tekrar tekrar çözülür */
static long long fib_saf(int n)
{
    cagri++;
    if (n < 2) {
        return n;                          /* temel durum */
    }
    return fib_saf(n - 1) + fib_saf(n - 2);
}

/* 2) Memo (yukarıdan aşağıya): memo[i] == -1 "hesaplanmadı" demektir */
static long long fib_memo(int i)
{
    cagri++;
    if (memo[i] != -1) {
        return memo[i];                    /* not alınmış: yeniden çözme */
    }
    if (i < 2) {
        memo[i] = i;
    } else {
        memo[i] = fib_memo(i - 1) + fib_memo(i - 2);
    }
    hesaplanan++;
    return memo[i];
}

/* 3) Tablo (aşağıdan yukarıya): tablo[0..n], Θ(n) zaman ve bellek.
 * Sahiplik: tablo çağıranındır (free ile bırakılır). */
static long long *fib_tablo(int n)
{
    long long *tablo = malloc((size_t)(n + 2) * sizeof *tablo);
    if (tablo == NULL) {
        return NULL;
    }
    tablo[0] = 0;
    tablo[1] = 1;
    for (int i = 2; i <= n; i++) {
        tablo[i] = tablo[i - 1] + tablo[i - 2];
    }
    return tablo;
}

/* 4) İki değişken: yalnız son iki değer tutulur, O(1) bellek */
static long long fib_iki(int n)
{
    long long onceki = 0, simdiki = 1;     /* F(0), F(1) */
    if (n == 0) {
        return 0;
    }
    for (int i = 2; i <= n; i++) {
        long long sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

/* uint64_t ile F(n); taşacaksa 0 döndürür ve *tasti = 1 yapar */
static uint64_t fib_u64(int n, int *tasti)
{
    uint64_t onceki = 0, simdiki = 1;
    *tasti = 0;
    if (n == 0) {
        return 0;
    }
    for (int i = 2; i <= n; i++) {
        if (onceki > UINT64_MAX - simdiki) {   /* toplamadan ÖNCE denetim */
            *tasti = 1;
            return 0;
        }
        uint64_t sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

/* F(n) mod 10^9 + 7, iki değişkenle: her toplamadan sonra mod */
static uint64_t fib_mod(long n)
{
    uint64_t onceki = 0, simdiki = 1;
    if (n == 0) {
        return 0;
    }
    for (long i = 2; i <= n; i++) {
        uint64_t sonraki = (onceki + simdiki) % MOD;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

static void memo_sifirla(int n)
{
    for (int i = 0; i <= n; i++) {
        memo[i] = -1;
    }
    cagri = 0;
    hesaplanan = 0;
}

int main(void)
{
    const int ns[] = {0, 1, 2, 5, 10, 15, 20, 25};
    const int adet = (int)(sizeof ns / sizeof ns[0]);
    long long *tablo = fib_tablo(MAKS_N - 10);
    if (tablo == NULL) {
        fprintf(stderr, "bellek ayrılamadı\n");
        return 1;
    }

    printf("1) Saf özyineleme: çağrı sayısı = 2·F(n+1) − 1 mi?\n");
    printf("   n       F(n)      çağrı  2·F(n+1)−1  eşit\n");
    long long onceki_cagri = 0;
    for (int k = 0; k < adet; k++) {
        int n = ns[k];
        cagri = 0;
        long long f = fib_saf(n);
        long long beklenen = 2 * tablo[n + 1] - 1;
        printf("  %2d %10lld %10lld %11lld  %s\n", n, f, cagri, beklenen,
               cagri == beklenen ? "evet" : "HAYIR");
    }
    cagri = 0;
    fib_saf(24);
    onceki_cagri = cagri;
    cagri = 0;
    fib_saf(25);
    printf("  çağrı(25) / çağrı(24) = %.4f  (φ ≈ 1.6180: Θ(φ^n) büyüme)\n",
           (double)cagri / (double)onceki_cagri);

    printf("\n2) Memo (yukarıdan aşağıya), \"hesaplanmadı\" = -1\n");
    printf("   n       F(n)  çağrı  hesaplanan  not isabeti\n");
    for (int k = 2; k < adet; k++) {
        int n = ns[k];
        memo_sifirla(n);
        long long f = fib_memo(n);
        printf("  %2d %10lld %6lld %11lld %12lld\n", n, f, cagri,
               hesaplanan, cagri - hesaplanan);
    }
    memo_sifirla(6);
    fib_memo(6);
    printf("  fib_memo(6) sonrası memo[0..6] =");
    for (int i = 0; i <= 6; i++) {
        printf(" %lld", memo[i]);
    }
    printf("\n  (n >= 2 için çağrı = 2n − 1, hesaplanan = n + 1)\n");

    printf("\n3) Tablo (aşağıdan yukarıya): tablo[i] = tablo[i-1] + "
           "tablo[i-2]\n  i   :");
    for (int i = 0; i <= 15; i++) {
        printf(" %4d", i);
    }
    printf("\n  F(i):");
    for (int i = 0; i <= 15; i++) {
        printf(" %4lld", tablo[i]);
    }
    printf("\n  n = 25: hücre = n + 1 = 26, F(25) = %lld\n", tablo[25]);

    printf("\n4) İki değişken (O(1) bellek): F(25) = %lld, F(90) = %lld\n",
           fib_iki(25), fib_iki(90));
    int dogru = 1;
    for (int n = 0; n <= 90; n++) {
        if (fib_iki(n) != tablo[n]) {
            dogru = 0;
        }
    }
    printf("  n = 0..90 için iki değişken = tablo: %s\n",
           dogru ? "evet" : "HAYIR");

    printf("\n5) Büyük n: uint64_t sınırı (2^64 − 1 = %llu)\n",
           (unsigned long long)UINT64_MAX);
    for (int n = 92; n <= 94; n++) {
        int tasti;
        uint64_t f = fib_u64(n, &tasti);
        if (tasti) {
            printf("  F(%d): uint64_t'ye SIĞMAZ (toplama öncesi "
                   "denetim)\n", n);
        } else {
            printf("  F(%d) = %llu\n", n, (unsigned long long)f);
        }
    }

    printf("\n6) mod 10^9 + 7 ile (iki değişken, her adımda mod)\n");
    const long buyuk[] = {94, 100, 1000, 1000000};
    for (int k = 0; k < 4; k++) {
        printf("  F(%ld) mod 1000000007 = %llu\n", buyuk[k],
               (unsigned long long)fib_mod(buyuk[k]));
    }
    free(tablo);
    return 0;
}

/* Kütüphane karşılığı: yok (C). C++ — yok; Python — functools.cache /
 * lru_cache dekoratörü memo'yu kendisi tutar (Dil Penceresi, kavram/). */

/* H13_09_duzenleme_uzakligi.c — AP-2 Hafta 13 · Örnek 9 (★★★)
 * Amaç    : Düzenleme (Levenshtein) uzaklığı: tablo ve işlem dizisinin
 *           geri çıkarılması; UTF-8'de bayt ve KOD NOKTASI düzeyi farkı;
 *           "Bunu mu demek istediniz?": Ömer Seyfettin metinlerinden
 *           çıkarılmış sözlükte (stdin) en yakın k = 3 öneri
 * DP      : durum D[i][j] = a[0..i)'yı b[0..j)'ye çeviren en az işlem ·
 *           geçiş D[i][j] = min(D[i−1][j] + 1 silme, D[i][j−1] + 1 ekleme,
 *           D[i−1][j−1] + [a[i−1] != b[j−1]] değiştirme/eşleşme) · temel
 *           D[i][0] = i, D[0][j] = j · sıra satır öncelikli · cevap
 *           D[n][m] · geri çıkarma (n, m)'den; eşitlikte öncelik:
 *           eşleşme > silme > ekleme > değiştirme. Öneriler kod noktası
 *           düzeyinde; eşit uzaklıkta bayt sırası (sözlük sırası)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_09_duzenleme_uzakligi.c -o H13_09_duzenleme_uzakligi
 * Çalıştır: ./H13_09_duzenleme_uzakligi \
 *           < ../girdiler/H13_09_duzenleme_uzakligi.txt
 * Eşleri  : cpp/H13_09_duzenleme_uzakligi.cpp ·
 *           python/H13_09_duzenleme_uzakligi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_UZ 64                 /* bir sözcükte en çok karakter */
#define K 3                        /* öneri sayısı */

static int D[(MAKS_UZ + 1) * (MAKS_UZ + 1)];
static long long hucre = 0;        /* hesaplanan tablo hücresi */

/* UTF-8 çözücü: s[0..uzunluk) → kod noktaları; geçersiz bayt tek başına
 * kod noktası sayılır. Dönen: kod noktası sayısı (en çok MAKS_UZ) */
static int utf8_coz(const unsigned char *s, int uzunluk, int cp[])
{
    int k = 0;
    for (int i = 0; i < uzunluk && k < MAKS_UZ;) {
        unsigned char b = s[i];
        int ek = b >= 0xF0 ? 3 : b >= 0xE0 ? 2 : b >= 0xC0 ? 1 : 0;
        int deger = ek == 3 ? b & 0x07 : ek == 2 ? b & 0x0F
                  : ek == 1 ? b & 0x1F : b;
        if (ek > 0 && i + ek >= uzunluk) {
            ek = 0;                            /* yarım dizi */
            deger = b;
        }
        for (int t = 1; t <= ek; t++) {
            deger = (deger << 6) | (s[i + t] & 0x3F);
        }
        cp[k++] = deger;
        i += ek + 1;
    }
    return k;
}

/* Bayt düzeyi: her bayt bir "karakter" */
static int baytlar(const unsigned char *s, int uzunluk, int cp[])
{
    int k = 0;
    for (; k < uzunluk && k < MAKS_UZ; k++) {
        cp[k] = s[k];
    }
    return k;
}

/* D tablosunu doldurur (satır öncelikli); D[i * (m+1) + j] */
static int uzaklik(const int a[], int n, const int b[], int m)
{
    int s = m + 1;
    for (int i = 0; i <= n; i++) {
        D[i * s] = i;                          /* i silme */
    }
    for (int j = 0; j <= m; j++) {
        D[j] = j;                              /* j ekleme */
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            int sil = D[(i - 1) * s + j] + 1;
            int ekle = D[i * s + j - 1] + 1;
            int degis = D[(i - 1) * s + j - 1] + (a[i - 1] != b[j - 1]);
            int enk = sil < ekle ? sil : ekle;
            D[i * s + j] = degis < enk ? degis : enk;
        }
    }
    hucre += (long long)(n + 1) * s;
    return D[n * s + m];
}

static void cp_yaz(int c)
{
    if (c < 0x80) {
        putchar(c);
    } else if (c < 0x800) {
        putchar(0xC0 | (c >> 6));
        putchar(0x80 | (c & 0x3F));
    } else if (c < 0x10000) {
        putchar(0xE0 | (c >> 12));
        putchar(0x80 | ((c >> 6) & 0x3F));
        putchar(0x80 | (c & 0x3F));
    } else {
        putchar(0xF0 | (c >> 18));
        putchar(0x80 | ((c >> 12) & 0x3F));
        putchar(0x80 | ((c >> 6) & 0x3F));
        putchar(0x80 | (c & 0x3F));
    }
}

/* İşlem dizisini geri çıkarıp BAŞTAN SONA yazar (D dolu olmalı) */
static void islemleri_yaz(const int a[], int n, const int b[], int m)
{
    int s = m + 1;
    char tur[2 * MAKS_UZ];                     /* E, S, K, D */
    int x[2 * MAKS_UZ], y[2 * MAKS_UZ];
    int k = 0, i = n, j = m;
    while (i > 0 || j > 0) {
        int d = D[i * s + j];
        if (i > 0 && j > 0 && a[i - 1] == b[j - 1] &&
            d == D[(i - 1) * s + j - 1]) {
            tur[k] = 'E';                      /* eşleşme */
            i--;
            j--;
        } else if (i > 0 && d == D[(i - 1) * s + j] + 1) {
            tur[k] = 'S';                      /* silme */
            i--;
        } else if (j > 0 && d == D[i * s + j - 1] + 1) {
            tur[k] = 'K';                      /* ekleme */
            j--;
        } else {
            tur[k] = 'D';                      /* değiştirme */
            i--;
            j--;
        }
        x[k] = i;
        y[k] = j;
        k++;
    }
    int sayi[4] = {0, 0, 0, 0};
    printf("  işlemler:");
    for (int t = k - 1; t >= 0; t--) {
        printf(t < k - 1 ? ", " : " ");
        if (tur[t] == 'E') {
            sayi[0]++;
            printf("eşleş ");
            cp_yaz(a[x[t]]);
        } else if (tur[t] == 'S') {
            sayi[1]++;
            printf("sil ");
            cp_yaz(a[x[t]]);
        } else if (tur[t] == 'K') {
            sayi[2]++;
            printf("ekle ");
            cp_yaz(b[y[t]]);
        } else {
            sayi[3]++;
            printf("değiştir ");
            cp_yaz(a[x[t]]);
            printf("→");
            cp_yaz(b[y[t]]);
        }
    }
    printf("\n  (eşleşme %d, silme %d, ekleme %d, değiştirme %d)\n",
           sayi[0], sayi[1], sayi[2], sayi[3]);
}

static int uzaklik_metin(const char *a, const char *b, int kod_noktasi)
{
    int x[MAKS_UZ], y[MAKS_UZ];
    int (*donustur)(const unsigned char *, int, int[]) =
        kod_noktasi ? utf8_coz : baytlar;
    int n = donustur((const unsigned char *)a, (int)strlen(a), x);
    int m = donustur((const unsigned char *)b, (int)strlen(b), y);
    return uzaklik(x, n, y, m);
}

/* --- sözlük: stdin'den satır satır (sahiplik: metin ve dizi main'de) */
static char *hepsini_oku(FILE *f, size_t *uzunluk)
{
    size_t kap = 1 << 16, n = 0;
    char *tampon = malloc(kap + 1);
    if (tampon == NULL) {
        return NULL;
    }
    size_t okunan;
    while ((okunan = fread(tampon + n, 1, kap - n, f)) > 0) {
        n += okunan;
        if (n == kap) {
            char *yeni = realloc(tampon, 2 * kap + 1);
            if (yeni == NULL) {
                free(tampon);
                return NULL;
            }
            tampon = yeni;
            kap *= 2;
        }
    }
    tampon[n] = '\0';
    *uzunluk = n;
    return tampon;
}

static int karsilastir(const void *p, const void *q)
{
    return strcmp(*(char *const *)p, *(char *const *)q);  /* bayt sırası */
}

/* En yakın K sözcük; eşit uzaklıkta sözlükte önce gelen (bayt sırası) */
static void oner(const char *sorgu, char *sozluk[], int adet,
                 int kod_noktasi, int en_iyi_i[], int en_iyi_d[])
{
    for (int t = 0; t < K; t++) {
        en_iyi_i[t] = -1;
        en_iyi_d[t] = INT_MAX;
    }
    for (int w = 0; w < adet; w++) {
        int d = uzaklik_metin(sorgu, sozluk[w], kod_noktasi);
        if (d >= en_iyi_d[K - 1]) {
            continue;                          /* KESİN küçük olmalı */
        }
        int p = K - 1;
        while (p > 0 && en_iyi_d[p - 1] > d) { /* araya ekleme (H5) */
            en_iyi_d[p] = en_iyi_d[p - 1];
            en_iyi_i[p] = en_iyi_i[p - 1];
            p--;
        }
        en_iyi_d[p] = d;
        en_iyi_i[p] = w;
    }
}

static void tablo_yaz(const char *a, const char *b)
{
    int n = (int)strlen(a), m = (int)strlen(b), s = m + 1;
    printf("         ");
    for (int j = 0; j < m; j++) {
        printf("  %c", b[j]);
    }
    printf("\n");
    for (int i = 0; i <= n; i++) {
        printf("     %c", i == 0 ? ' ' : a[i - 1]);
        for (int j = 0; j <= m; j++) {
            printf(" %2d", D[i * s + j]);
        }
        printf("\n");
    }
}

int main(void)
{
    printf("1) a = \"kitten\", b = \"sitting\" (ASCII: bayt = karakter)\n");
    int x[MAKS_UZ], y[MAKS_UZ];
    int n = baytlar((const unsigned char *)"kitten", 6, x);
    int m = baytlar((const unsigned char *)"sitting", 7, y);
    int d = uzaklik(x, n, y, m);
    tablo_yaz("kitten", "sitting");
    printf("  uzaklık = D[6][7] = %d; hücre = 7 * 8 = 56\n", d);
    printf("  (eşitlikte öncelik: eşleşme > silme > ekleme > "
           "değiştirme)\n");
    islemleri_yaz(x, n, y, m);

    printf("\n2) UTF-8: bayt mı, kod noktası mı? (Türkçe harfler 2 "
           "bayt)\n");
    const char *ciftler[][2] = {{"gunduz", "gündüz"}, {"sehre", "şehre"},
                                {"kılç", "kılıç"}, {"kılç", "hıç"},
                                {"ş", "ğ"}};
    for (int c = 0; c < 5; c++) {
        printf("  %s / %s: bayt = %d, kod noktası = %d\n", ciftler[c][0],
               ciftler[c][1], uzaklik_metin(ciftler[c][0], ciftler[c][1], 0),
               uzaklik_metin(ciftler[c][0], ciftler[c][1], 1));
    }
    const char *g1 = "gunduz", *g2 = "gündüz";
    n = utf8_coz((const unsigned char *)g1, (int)strlen(g1), x);
    m = utf8_coz((const unsigned char *)g2, (int)strlen(g2), y);
    uzaklik(x, n, y, m);
    printf("  gunduz -> gündüz, kod noktası düzeyinde:\n");
    islemleri_yaz(x, n, y, m);

    size_t uzunluk = 0;
    char *metin = hepsini_oku(stdin, &uzunluk);
    if (metin == NULL) {
        fprintf(stderr, "girdi okunamadı\n");
        return 1;
    }
    int adet = 0;
    for (size_t i = 0; i < uzunluk; i++) {
        adet += metin[i] == '\n';
    }
    char **sozluk = malloc((size_t)(adet + 1) * sizeof *sozluk);
    if (sozluk == NULL) {
        free(metin);
        return 1;
    }
    adet = 0;
    for (char *p = strtok(metin, "\r\n"); p != NULL;
         p = strtok(NULL, "\r\n")) {
        sozluk[adet++] = p;
    }
    if (adet == 0) {
        fprintf(stderr, "sözlük boş (girdi: kelime listesi)\n");
        free(sozluk);
        free(metin);
        return 1;
    }
    qsort(sozluk, (size_t)adet, sizeof *sozluk, karsilastir);

    printf("\n3) \"Bunu mu demek istediniz?\" — sözlük: %d sözcük (stdin), "
           "k = %d\n", adet, K);
    printf("  öneri: kod noktası düzeyinde; eşit uzaklıkta bayt sırası\n");
    const char *sorgular[] = {"gunduz", "sehre", "kılç", "padisah",
                              "gozleri", "usda", "esir"};
    hucre = 0;
    for (int q = 0; q < 7; q++) {
        int ii[K], dd[K], bi[K], bd[K];
        oner(sorgular[q], sozluk, adet, 1, ii, dd);
        long long kn_hucre = hucre;
        oner(sorgular[q], sozluk, adet, 0, bi, bd);
        hucre = kn_hucre;
        printf("  %s ->", sorgular[q]);
        if (dd[0] == 0) {
            printf(" sözlükte VAR");
        } else {
            for (int t = 0; t < K; t++) {
                printf("%s %s (%d)", t > 0 ? "," : "", sozluk[ii[t]], dd[t]);
            }
        }
        printf(" | bayt düzeyinde 1.: %s (%d)\n", sozluk[bi[0]], bd[0]);
    }
    printf("  kod noktası düzeyinde hesaplanan hücre: %lld (7 sorgu x %d "
           "sözcük)\n", hucre, adet);
    free(sozluk);
    free(metin);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++); Python — difflib.get_close_matches
 * benzerlik oranıyla öneri verir (Levenshtein değil). Kâhin olarak
 * kullanılmaz. */

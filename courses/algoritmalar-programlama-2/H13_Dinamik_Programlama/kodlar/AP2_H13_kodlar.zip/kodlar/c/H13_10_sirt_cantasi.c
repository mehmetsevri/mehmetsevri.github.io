/* H13_10_sirt_cantasi.c — AP-2 Hafta 13 · Örnek 10 (★★★)
 * Amaç    : 0/1 sırt çantası: (n + 1) × (W + 1) tam tablo ve seçilen
 *           nesnelerin geri çıkarılması; değer/ağırlık oranına göre
 *           açgözlünün (H12) 0/1'de yanılması; 12 dersten AKTS sınırı
 *           altında en yüksek tercih puanı, kâhin: 2^n alt küme
 * DP      : durum K[i][w] = ilk i nesneyle, w kapasitede en büyük değer ·
 *           geçiş K[i][w] = max(K[i−1][w], K[i−1][w − a_i] + d_i) (a_i <=
 *           w ise) · temel K[0][w] = 0 · sıra i = 1..n, w = 0..W
 *           (satır öncelikli) · cevap K[n][W] · geri çıkarma i = n..1:
 *           K[i][w] != K[i−1][w] ise i alındı, w −= a_i (eşitlikte
 *           ALINMADI sayılır; ilk i−1 nesneyle aynı değer elde edilir)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_10_sirt_cantasi.c ortak_rastgele.c -o H13_10_sirt_cantasi
 * Çalıştır: ./H13_10_sirt_cantasi
 * Eşleri  : cpp/H13_10_sirt_cantasi.cpp · python/H13_10_sirt_cantasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define MAKS_NESNE 16

static long long hucre = 0;

/* Sahiplik: dönen (n+1)(W+1) tablo çağıranındır (free). K[i*(W+1)+w] */
static int *sirt_cantasi(const int a[], const int d[], int n, int W)
{
    int s = W + 1;
    int *K = malloc((size_t)(n + 1) * (size_t)s * sizeof *K);
    if (K == NULL) {
        return NULL;
    }
    for (int w = 0; w <= W; w++) {
        K[w] = 0;                              /* temel: nesne yok */
    }
    for (int i = 1; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            int al_ma = K[(i - 1) * s + w];
            int en_iyi = al_ma;
            if (a[i - 1] <= w) {
                int al = K[(i - 1) * s + w - a[i - 1]] + d[i - 1];
                if (al > en_iyi) {
                    en_iyi = al;
                }
            }
            K[i * s + w] = en_iyi;
            hucre++;
        }
    }
    return K;
}

/* Seçilen nesneleri geri çıkarır (secildi[i] = 1); toplam ağırlık */
static int secilenler(const int *K, const int a[], int n, int W,
                      int secildi[])
{
    int s = W + 1, w = W, agirlik = 0;
    for (int i = n; i >= 1; i--) {
        secildi[i - 1] = 0;
        if (K[i * s + w] != K[(i - 1) * s + w]) {   /* eşitlikte alınmadı */
            secildi[i - 1] = 1;
            w -= a[i - 1];
            agirlik += a[i - 1];
        }
    }
    return agirlik;
}

/* Açgözlü (H12 kesirli sırt çantası sırası): d/a oranı azalan; sığanı al.
 * Oran karşılaştırması tamsayıyla: d_i * a_j > d_j * a_i */
static int acgozlu(const int a[], const int d[], int n, int W, int secildi[])
{
    int sira[MAKS_NESNE];
    for (int i = 0; i < n; i++) {
        sira[i] = i;
        secildi[i] = 0;
    }
    for (int i = 1; i < n; i++) {              /* araya ekleme (H5) */
        int x = sira[i], j = i - 1;
        while (j >= 0 && d[x] * a[sira[j]] > d[sira[j]] * a[x]) {
            sira[j + 1] = sira[j];
            j--;
        }
        sira[j + 1] = x;
    }
    int deger = 0;
    for (int k = 0; k < n; k++) {
        int i = sira[k];
        if (a[i] <= W) {
            W -= a[i];
            deger += d[i];
            secildi[i] = 1;
        }
    }
    return deger;
}

/* Kâhin: 2^n alt küme; en büyük değer */
static int kahin(const int a[], const int d[], int n, int W)
{
    int en_iyi = 0;
    for (long maske = 0; maske < (1L << n); maske++) {
        int agirlik = 0, deger = 0;
        for (int i = 0; i < n; i++) {
            if (maske & (1L << i)) {
                agirlik += a[i];
                deger += d[i];
            }
        }
        if (agirlik <= W && deger > en_iyi) {
            en_iyi = deger;
        }
    }
    return en_iyi;
}

static void yaz_secim(const char *ad[], const int secildi[], int n)
{
    int ilk = 1;
    printf("{");
    for (int i = 0; i < n; i++) {
        if (secildi[i]) {
            printf(ilk ? "%s" : ", %s", ad[i]);
            ilk = 0;
        }
    }
    printf("}");
}

int main(void)
{
    int secildi[MAKS_NESNE];
    const char *ad1[] = {"A", "B", "C", "D"};
    const int a1[] = {5, 4, 6, 3}, d1[] = {10, 40, 30, 50};
    const int W1 = 10;
    printf("1) Nesneler (ağırlık, değer): A(5, 10) B(4, 40) C(6, 30) "
           "D(3, 50); W = %d\n", W1);
    hucre = 0;
    int *K = sirt_cantasi(a1, d1, 4, W1);
    if (K == NULL) {
        fprintf(stderr, "bellek ayrılamadı\n");
        return 1;
    }
    printf("  K[i][w]   w:");
    for (int w = 0; w <= W1; w++) {
        printf(" %3d", w);
    }
    printf("\n");
    for (int i = 0; i <= 4; i++) {
        printf("  i = %d %-5s:", i, i == 0 ? "-" : ad1[i - 1]);
        for (int w = 0; w <= W1; w++) {
            printf(" %3d", K[i * (W1 + 1) + w]);
        }
        printf("\n");
    }
    int ag = secilenler(K, a1, 4, W1, secildi);
    printf("  en büyük değer = K[4][%d] = %d; seçilen ", W1,
           K[4 * (W1 + 1) + W1]);
    yaz_secim(ad1, secildi, 4);
    printf(", ağırlık %d / %d\n", ag, W1);
    printf("  geri çıkarma: i = 4..1, K[i][w] != K[i-1][w] ise alındı:");
    for (int i = 4, w = W1; i >= 1; i--) {
        int al = K[i * (W1 + 1) + w] != K[(i - 1) * (W1 + 1) + w];
        printf(" %s%s", ad1[i - 1], al ? "+" : "-");
        if (al) {
            w -= a1[i - 1];
        }
    }
    printf("\n  hücre = n * (W + 1) = %lld\n", hucre);
    free(K);

    printf("\n2) Açgözlü (değer/ağırlık oranı, H12) 0/1'de yanılır\n");
    const char *ad2[] = {"X", "Y", "Z"};
    const int a2[] = {10, 20, 30}, d2[] = {60, 100, 120};
    printf("  X(10, 60) Y(20, 100) Z(30, 120); W = 50; oranlar 6 > 5 > 4\n");
    int dg = acgozlu(a2, d2, 3, 50, secildi);
    printf("  açgözlü: ");
    yaz_secim(ad2, secildi, 3);
    printf(" = %d\n", dg);
    K = sirt_cantasi(a2, d2, 3, 50);
    if (K == NULL) {
        return 1;
    }
    secilenler(K, a2, 3, 50, secildi);
    printf("  DP     : ");
    yaz_secim(ad2, secildi, 3);
    printf(" = %d\n", K[3 * 51 + 50]);
    free(K);

    printf("\n3) 12 ders: AKTS (ağırlık) 2..8, tercih puanı (değer) 1..20, "
           "tohum 4; üst sınır 30 AKTS\n");
    const char *ad3[] = {"D01", "D02", "D03", "D04", "D05", "D06",
                         "D07", "D08", "D09", "D10", "D11", "D12"};
    int a3[12], d3[12];
    rastgele_tohum(4);
    for (int i = 0; i < 12; i++) {
        a3[i] = rastgele_aralik(2, 8);
        d3[i] = rastgele_aralik(1, 20);
    }
    printf("  ");
    for (int i = 0; i < 12; i++) {
        printf("%s(%d, %d)%s", ad3[i], a3[i], d3[i], i == 5 ? "\n  " :
                                                      i < 11 ? " " : "\n");
    }
    hucre = 0;
    K = sirt_cantasi(a3, d3, 12, 30);
    if (K == NULL) {
        return 1;
    }
    int en = K[12 * 31 + 30];
    ag = secilenler(K, a3, 12, 30, secildi);
    printf("  DP: puan = %d, AKTS = %d; seçilen ", en, ag);
    yaz_secim(ad3, secildi, 12);
    int kh = kahin(a3, d3, 12, 30);
    printf("\n  hücre = %lld; kâhin (2^12 = 4096 alt küme) = %d -> %s\n",
           hucre, kh, kh == en ? "aynı" : "FARKLI");
    dg = acgozlu(a3, d3, 12, 30, secildi);
    printf("  açgözlü (oran): puan = %d (%s)\n", dg,
           dg == en ? "bu girdide en iyi" : "en iyiden düşük");
    free(K);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python); DP tablosu elle doldurulur.
 * Tek satırlı sürüm: Örnek 11. */

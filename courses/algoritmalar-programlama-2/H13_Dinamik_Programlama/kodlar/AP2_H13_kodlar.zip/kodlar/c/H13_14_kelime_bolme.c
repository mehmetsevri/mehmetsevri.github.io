/* H13_14_kelime_bolme.c — AP-2 Hafta 13 · Örnek 14 (★★★, meydan okuma)
 * Amaç    : Kelime bölme (önek DP'si): boşluksuz yazılmış bir dizgi
 *           sözlükteki sözcüklere bölünebilir mi, kaç yolla, hangi
 *           bölmeyle? Sözlük: Ömer Seyfettin metinlerinden çıkarılmış
 *           liste (stdin, Örnek 9 ile aynı); arama H4 ikili araması
 * DP      : durum ok[i] = s[0..i) sözcüklere bölünebilir mi; say[i] = kaç
 *           yolla · geçiş ok[i] = VAR j: ok[j] VE s[j..i) sözlükte
 *           (i − j <= en uzun sözcük); say[i] = Σ say[j] · temel ok[0] =
 *           doğru, say[0] = 1 · sıra i = 1..n artan, içte j artan · cevap
 *           ok[n], say[n] · geri çıkarma son[i] = koşulu sağlayan EN KÜÇÜK
 *           j (son sözcük en uzun olan); i = n, son[n], … 0
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_14_kelime_bolme.c -o H13_14_kelime_bolme
 * Çalıştır: ./H13_14_kelime_bolme \
 *           < ../girdiler/H13_14_kelime_bolme.txt
 * Eşleri  : cpp/H13_14_kelime_bolme.cpp · python/H13_14_kelime_bolme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_N 128                 /* dizgi uzunluğu (bayt) */

static char **sozluk = NULL;
static int adet = 0;
static int en_uzun = 0;            /* en uzun sözcük (bayt) */
static long long sorgu = 0;        /* sözlük sorgusu sayısı */

/* s[0..uzunluk) parçasını w ile bayt sırasında karşılaştırır (strcmp ile
 * aynı sıra: unsigned char, kısa olan önce) */
static int parca_karsilastir(const char *s, int uzunluk, const char *w)
{
    int wl = (int)strlen(w);
    int k = memcmp(s, w, (size_t)(uzunluk < wl ? uzunluk : wl));
    if (k != 0) {
        return k;
    }
    return uzunluk - wl;
}

/* Sözlükte var mı? H4 ikili arama (lower_bound + eşitlik denetimi) */
static int sozlukte_mi(const char *s, int uzunluk)
{
    sorgu++;
    int lo = 0, hi = adet;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (parca_karsilastir(s, uzunluk, sozluk[mid]) > 0) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo < adet && parca_karsilastir(s, uzunluk, sozluk[lo]) == 0;
}

static int ok[MAKS_N + 1];
static int son[MAKS_N + 1];
static long long say[MAKS_N + 1];

/* Önek DP'si: ok, son, say doldurulur; n = strlen(s) */
static int kelime_bol(const char *s, int n)
{
    ok[0] = 1;                                 /* boş önek */
    say[0] = 1;
    son[0] = -1;
    for (int i = 1; i <= n; i++) {
        ok[i] = 0;
        say[i] = 0;
        son[i] = -1;
        int j0 = i - en_uzun > 0 ? i - en_uzun : 0;
        for (int j = j0; j < i; j++) {
            if (ok[j] && sozlukte_mi(s + j, i - j)) {
                if (!ok[i]) {
                    son[i] = j;                /* en küçük j */
                }
                ok[i] = 1;
                say[i] += say[j];
            }
        }
    }
    return ok[n];
}

static void parca_yaz(const char *s, int j, int i)
{
    fwrite(s + j, 1, (size_t)(i - j), stdout);
}

/* son[] zincirini izleyip bölmeyi baştan sona yazar */
static void bolme_yaz(const char *s, int n)
{
    int kes[MAKS_N + 1], k = 0;
    for (int i = n; i > 0; i = son[i]) {
        kes[k++] = i;
    }
    int bas = 0;
    for (int t = k - 1; t >= 0; t--) {
        if (t < k - 1) {
            printf(" + ");
        }
        parca_yaz(s, bas, kes[t]);
        bas = kes[t];
    }
}

/* Bütün bölmeler (küçük sayılar için): i'ye biten son sözcükten geriye */
static int kesimler[MAKS_N + 1];
static void hepsini_listele(const char *s, int i, int derinlik)
{
    if (i == 0) {
        printf("    ");
        int bas = 0;
        for (int t = derinlik - 1; t >= 0; t--) {
            if (t < derinlik - 1) {
                printf(" + ");
            }
            parca_yaz(s, bas, kesimler[t]);
            bas = kesimler[t];
        }
        printf("\n");
        return;
    }
    int j0 = i - en_uzun > 0 ? i - en_uzun : 0;
    for (int j = j0; j < i; j++) {
        if (ok[j] && sozlukte_mi(s + j, i - j)) {
            kesimler[derinlik] = i;
            hepsini_listele(s, j, derinlik + 1);
        }
    }
}

static char *hepsini_oku(FILE *f, size_t *uzunluk)
{
    size_t kap = 1 << 16, n = 0;
    char *tampon = malloc(kap + 1);
    if (tampon == NULL) {
        return NULL;
    }
    size_t okunan;
    while ((okunan = fread(tampon + n, 1, kap - n, f)) > 0) {
        n += okunan;
        if (n == kap) {
            char *yeni = realloc(tampon, 2 * kap + 1);
            if (yeni == NULL) {
                free(tampon);
                return NULL;
            }
            tampon = yeni;
            kap *= 2;
        }
    }
    tampon[n] = '\0';
    *uzunluk = n;
    return tampon;
}

static int karsilastir(const void *p, const void *q)
{
    return strcmp(*(char *const *)p, *(char *const *)q);  /* bayt sırası */
}

int main(void)
{
    size_t uzunluk = 0;
    char *metin = hepsini_oku(stdin, &uzunluk);
    if (metin == NULL) {
        fprintf(stderr, "girdi okunamadı\n");
        return 1;
    }
    int satir = 0;
    for (size_t i = 0; i < uzunluk; i++) {
        satir += metin[i] == '\n';
    }
    sozluk = malloc((size_t)(satir + 1) * sizeof *sozluk);
    if (sozluk == NULL) {
        free(metin);
        return 1;
    }
    for (char *p = strtok(metin, "\r\n"); p != NULL;
         p = strtok(NULL, "\r\n")) {
        sozluk[adet++] = p;
        if ((int)strlen(p) > en_uzun) {
            en_uzun = (int)strlen(p);
        }
    }
    if (adet == 0) {
        fprintf(stderr, "sözlük boş (girdi: kelime listesi)\n");
        free(sozluk);
        free(metin);
        return 1;
    }
    qsort(sozluk, (size_t)adet, sizeof *sozluk, karsilastir);
    printf("1) Sözlük: %d sözcük (stdin), en uzun sözcük %d "
           "bayt\n", adet, en_uzun);
    printf("  ok[i] = VAR j: ok[j] ve s[j..i) sözlükte (i - j <= %d); "
           "konumlar BAYT\n", en_uzun);

    const char *s = "karanlıkiniçinde";
    int n = (int)strlen(s);
    sorgu = 0;
    int b = kelime_bol(s, n);
    printf("\n2) s = \"%s\" (%d bayt)\n", s, n);
    printf("  ok[i] doğru olan i (son[i]):");
    for (int i = 0; i <= n; i++) {
        if (ok[i]) {
            printf(" %d(%d)", i, son[i]);
        }
    }
    printf("\n  bölünebilir: %s; bölme sayısı say[%d] = %lld; sözlük "
           "sorgusu = %lld\n", b ? "evet" : "HAYIR", n, say[n], sorgu);
    printf("  seçilen (son[] zinciri, son sözcük en uzun): ");
    bolme_yaz(s, n);
    printf("\n  bütün bölmeler:\n");
    hepsini_listele(s, n, 0);

    printf("\n3) Başka dizgiler\n");
    const char *dizgiler[] = {"gecegündüzçalışan", "dükkânındatekbaşına",
                              "bugünbirdiyetvar", "padişahferman",
                              "kılıçlarınıçekti"};
    for (int d = 0; d < 5; d++) {
        s = dizgiler[d];
        n = (int)strlen(s);
        sorgu = 0;
        b = kelime_bol(s, n);
        printf("  %s: ", s);
        if (b) {
            printf("%lld bölme; ", say[n]);
            bolme_yaz(s, n);
        } else {
            printf("BÖLÜNEMEZ");
        }
        printf("  (sorgu = %lld)\n", sorgu);
    }
    free(sozluk);
    free(metin);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Sözlük araması C'de elle
 * ikili arama (H4); C++'ta std::unordered_set, Python'da set (H10). */

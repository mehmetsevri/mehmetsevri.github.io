/* H13_13_lis_nlogn.c — AP-2 Hafta 13 · Örnek 13 (★★★, merak)
 * Amaç    : En uzun artan alt dizi O(n log n): "sabır sıralaması" fikri.
 *           tails[k] = uzunluğu k+1 olan artan alt dizilerin EN KÜÇÜK son
 *           değeri; her x için H4'ün lower_bound'u (ilk tails[k] >= x)
 *           ile yeri bulunur. Uzunluk Örnek 7 ile aynı; dizinin geri
 *           çıkarılması için tails_idx ve ebeveyn dizileri
 * DP      : durum tails[0..L) (artan sıralı kalır: değişmez) · geçiş
 *           k = lower_bound(tails, x); tails[k] = x (k = L ise L++) ·
 *           temel L = 0 · sıra i = 0..n−1 · cevap L · geri çıkarma
 *           ebeveyn[i] = tails_idx[k−1] (k > 0), zincir tails_idx[L−1]'den
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_13_lis_nlogn.c ortak_rastgele.c -o H13_13_lis_nlogn
 * Çalıştır: ./H13_13_lis_nlogn
 * Eşleri  : cpp/H13_13_lis_nlogn.cpp · python/H13_13_lis_nlogn.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long yoklama = 0;      /* incelenen tails[mid] sayısı */
static long long karsilastirma = 0;

/* H4 Örnek 7: lower_bound — ilk t[i] >= x konumu; hepsi < x ise n.
 * Değişmez: t[0..lo-1] < x <= t[hi..n-1] */
static int alt_sinir(const int t[], int n, int x)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        yoklama++;
        if (t[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

/* Sabır sıralaması. tails, tails_idx, ebeveyn çağıranın dizileridir
 * (en az n öğe). iz ise her adımı yazar. Dönen: L (LIS uzunluğu) */
static int lis_nlogn(const int a[], int n, int tails[], int tails_idx[],
                     int ebeveyn[], int iz)
{
    int L = 0;
    for (int i = 0; i < n; i++) {
        int k = alt_sinir(tails, L, a[i]);
        tails[k] = a[i];                       /* yeni deste ya da üstüne */
        tails_idx[k] = i;
        ebeveyn[i] = k > 0 ? tails_idx[k - 1] : -1;
        if (k == L) {
            L++;
        }
        if (iz) {
            printf("  x = %d -> konum %d: tails [", a[i], k);
            for (int t = 0; t < L; t++) {
                printf(t > 0 ? ", %d" : "%d", tails[t]);
            }
            printf("], tails_idx [");
            for (int t = 0; t < L; t++) {
                printf(t > 0 ? ", %d" : "%d", tails_idx[t]);
            }
            printf("], ebeveyn[%d] = %d\n", i, ebeveyn[i]);
        }
    }
    return L;
}

/* Zinciri tails_idx[L-1]'den izler; değerleri BAŞTAN SONA yazar */
static void geri_cikar_yaz(const int a[], const int tails_idx[],
                           const int ebeveyn[], int L)
{
    int *indis = malloc((size_t)(L > 0 ? L : 1) * sizeof *indis);
    if (indis == NULL) {
        return;
    }
    int k = L;
    for (int i = L > 0 ? tails_idx[L - 1] : -1; i != -1; i = ebeveyn[i]) {
        indis[--k] = i;
    }
    printf("  alt dizi:");
    for (int x = 0; x < L && x < 12; x++) {
        printf(" %d", a[indis[x]]);
    }
    if (L > 12) {
        printf(" ... (ilk 12)");
    }
    int artan = 1;
    for (int x = 1; x < L; x++) {
        if (!(indis[x - 1] < indis[x] && a[indis[x - 1]] < a[indis[x]])) {
            artan = 0;
        }
    }
    printf("\n  denetim: indisler ve değerler kesin artan: %s\n",
           artan ? "evet" : "HAYIR");
    free(indis);
}

/* Örnek 7'nin O(n^2) DP'si (yalnız uzunluk; kâhin) */
static int lis_n2_uzunluk(const int a[], int n)
{
    int *uz = malloc((size_t)n * sizeof *uz);
    if (uz == NULL) {
        return -1;
    }
    int en = 0;
    for (int i = 0; i < n; i++) {
        uz[i] = 1;
        for (int j = 0; j < i; j++) {
            karsilastirma++;
            if (a[j] < a[i] && uz[j] + 1 > uz[i]) {
                uz[i] = uz[j] + 1;
            }
        }
        if (uz[i] > en) {
            en = uz[i];
        }
    }
    free(uz);
    return en;
}

/* Sahiplik: dönen dört dizi çağıranındır (free); NULL: bellek yok */
static int *diziler_ayir(int n, int **tails, int **idx, int **eb)
{
    int *a = malloc((size_t)n * sizeof *a);
    *tails = malloc((size_t)n * sizeof **tails);
    *idx = malloc((size_t)n * sizeof **idx);
    *eb = malloc((size_t)n * sizeof **eb);
    if (a == NULL || *tails == NULL || *idx == NULL || *eb == NULL) {
        free(a);
        free(*tails);
        free(*idx);
        free(*eb);
        return NULL;
    }
    return a;
}

int main(void)
{
    int tails[16], idx[16], eb[16];
    const int a1[] = {5, 2, 8, 6, 3, 6, 9, 7};
    printf("1) a = {5, 2, 8, 6, 3, 6, 9, 7} (Örnek 7 ile aynı)\n");
    printf("  (konum = lower_bound(tails, x); tails[konum] = x)\n");
    yoklama = 0;
    int L = lis_nlogn(a1, 8, tails, idx, eb, 1);
    printf("  uzunluk L = %d; yoklama (lower_bound adımı) = %lld\n", L,
           yoklama);
    geri_cikar_yaz(a1, idx, eb, L);

    int a2[16];
    rastgele_tohum(42);
    rastgele_dizi(a2, 16, 1, 50);
    printf("\n2) Örnek 7'nin rastgele dizisi (tohum 42, n = 16, 1..50)\n");
    yoklama = 0;
    L = lis_nlogn(a2, 16, tails, idx, eb, 0);
    printf("  uzunluk L = %d (Örnek 7: O(n^2) DP ile %d); yoklama = %lld\n",
           L, lis_n2_uzunluk(a2, 16), yoklama);
    printf("  son tails = [");
    for (int t = 0; t < L; t++) {
        printf(t > 0 ? ", %d" : "%d", tails[t]);
    }
    printf("]  (bir artan alt dizi DEĞİL; yalnız deste üstleri)\n");
    geri_cikar_yaz(a2, idx, eb, L);

    printf("\n3) Büyük n (tohum 42, 1..1000000)\n");
    const int ns[] = {1000, 100000};
    for (int k = 0; k < 2; k++) {
        int n = ns[k];
        int *ta, *ix, *ebv;
        int *a = diziler_ayir(n, &ta, &ix, &ebv);
        if (a == NULL) {
            fprintf(stderr, "bellek ayrılamadı\n");
            return 1;
        }
        rastgele_tohum(42);
        rastgele_dizi(a, (size_t)n, 1, 1000000);
        yoklama = 0;
        L = lis_nlogn(a, n, ta, ix, ebv, 0);
        printf("  n = %6d: L = %d, yoklama = %lld", n, L, yoklama);
        if (n <= 1000) {
            karsilastirma = 0;
            int l2 = lis_n2_uzunluk(a, n);
            printf("; O(n^2): L = %d, karşılaştırma = %lld (%s)\n", l2,
                   karsilastirma, l2 == L ? "aynı" : "FARKLI");
        } else {
            printf("; O(n^2) olsaydı n(n-1)/2 = %lld karşılaştırma\n",
                   (long long)n * (n - 1) / 2);
        }
        geri_cikar_yaz(a, ix, ebv, L);
        free(a);
        free(ta);
        free(ix);
        free(ebv);
    }
    return 0;
}

/* Kütüphane karşılığı: lower_bound — C: yok (elle; bsearch eşit öğeyi
 * bulur, konum vermez); C++: std::lower_bound; Python: bisect.bisect_left
 * (yalnız kâhin). LIS'in kendisinin kütüphane karşılığı yok. */

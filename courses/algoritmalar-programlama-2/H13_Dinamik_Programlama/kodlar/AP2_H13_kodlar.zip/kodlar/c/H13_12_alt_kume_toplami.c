/* H13_12_alt_kume_toplami.c — AP-2 Hafta 13 · Örnek 12 (★★)
 * Amaç    : Alt küme toplamı iki stratejiyle: H3'ün budamalı geri izlemesi
 *           (düğüm sayısı) ve DP (bool tablo + sayım tablosu; hücre
 *           sayısı). Aynı girdi (H3 Örnek 8: n = 18, tohum 42, 1..40);
 *           çözüm sayıları birebir aynı; n ve hedefe göre karşılaştırma
 * DP      : durum var[i][t] = ilk i sayının bir alt kümesinin toplamı t
 *           olabilir mi; say[i][t] = kaç alt küme · geçiş var[i][t] =
 *           var[i−1][t] VEYA (a_i <= t VE var[i−1][t − a_i]); say[i][t] =
 *           say[i−1][t] + say[i−1][t − a_i] · temel var[0][0] = 1,
 *           say[0][0] = 1, diğerleri 0 · sıra i artan, t artan · cevap
 *           var[n][T], say[n][T] · geri çıkarma i = n..1: var[i−1][t]
 *           doğruysa a_i ALINMAZ (eşitlikte almadan), yoksa alınır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_12_alt_kume_toplami.c ortak_rastgele.c \
 *           -o H13_12_alt_kume_toplami
 * Çalıştır: ./H13_12_alt_kume_toplami
 * Eşleri  : cpp/H13_12_alt_kume_toplami.cpp ·
 *           python/H13_12_alt_kume_toplami.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define MAKS_N 30

/* --- H3 Örnek 8: budamalı geri izleme ("toplam aşıldı") ------------- */
static int a[MAKS_N];
static int n;
static long long hedef;
static long long ziyaret = 0;      /* ziyaret edilen düğüm (çağrı) */
static long long cozum_sayisi = 0;

static void budamali(int i, long long toplam)
{
    ziyaret++;
    if (toplam > hedef) {
        return;                    /* torunların hepsi de aşar (a_i > 0) */
    }
    if (i == n) {
        if (toplam == hedef) {
            cozum_sayisi++;
        }
        return;
    }
    budamali(i + 1, toplam);
    budamali(i + 1, toplam + a[i]);
}

/* --- DP: bool tablo + sayım tablosu (satır i: ilk i sayı) ------------ */
static unsigned char *var_t = NULL;    /* (n+1) x (T+1) */
static long long *say_t = NULL;
static long long hucre = 0;

/* Sahiplik: var_t ve say_t bu modülündür; dp_birak ile bırakılır.
 * Dönen: 0 başarı, -1 bellek yok */
static int dp_doldur(int T)
{
    int s = T + 1;
    size_t boyut = (size_t)(n + 1) * (size_t)s;
    var_t = calloc(boyut, 1);
    say_t = calloc(boyut, sizeof *say_t);
    if (var_t == NULL || say_t == NULL) {
        return -1;
    }
    var_t[0] = 1;                              /* boş küme: toplam 0 */
    say_t[0] = 1;
    hucre = s;                                 /* satır 0 */
    for (int i = 1; i <= n; i++) {
        int x = a[i - 1];
        for (int t = 0; t <= T; t++) {
            var_t[i * s + t] = var_t[(i - 1) * s + t];        /* almadan */
            say_t[i * s + t] = say_t[(i - 1) * s + t];
            if (x <= t) {                                     /* alarak */
                var_t[i * s + t] |= var_t[(i - 1) * s + t - x];
                say_t[i * s + t] += say_t[(i - 1) * s + t - x];
            }
            hucre++;
        }
    }
    return 0;
}

static void dp_birak(void)
{
    free(var_t);
    free(say_t);
    var_t = NULL;
    say_t = NULL;
}

/* Bir çözüm: i = n..1; var[i-1][t] doğruysa almadan (eşitlikte almadan) */
static int geri_cikar(int T, int secilen[])
{
    int s = T + 1, t = T, k = 0;
    for (int i = n; i >= 1; i--) {
        if (!var_t[(i - 1) * s + t]) {
            secilen[k++] = a[i - 1];
            t -= a[i - 1];
        }
    }
    return k;                                  /* sondan başa sıralı */
}

static void dizi_kur(int adet, int tohum)
{
    n = adet;
    rastgele_tohum((uint64_t)tohum);
    rastgele_dizi(a, (size_t)n, 1, 40);
}

int main(void)
{
    const int kucuk[] = {5, 4, 3, 2};
    n = 4;
    for (int i = 0; i < n; i++) {
        a[i] = kucuk[i];
    }
    hedef = 7;
    printf("1) a = {5, 4, 3, 2}, hedef = 7 (H3 Örnek 8)\n");
    if (dp_doldur(7) != 0) {
        dp_birak();
        return 1;
    }
    printf("  var[i][t] (1 = ilk i sayıyla t toplamı yapılabilir)\n");
    printf("  t        :");
    for (int t = 0; t <= 7; t++) {
        printf(" %2d", t);
    }
    printf("\n");
    for (int i = 0; i <= n; i++) {
        if (i == 0) {
            printf("  i = 0    :");
        } else {
            printf("  i = %d (%d):", i, a[i - 1]);
        }
        for (int t = 0; t <= 7; t++) {
            printf(" %2d", var_t[i * 8 + t]);
        }
        printf("\n");
    }
    int secilen[MAKS_N];
    int k = geri_cikar(7, secilen);
    printf("  say[4][7] = %lld alt küme; bir çözüm (eşitlikte almadan): {",
           say_t[4 * 8 + 7]);
    for (int x = k - 1; x >= 0; x--) {
        printf(x < k - 1 ? ", %d" : "%d", secilen[x]);
    }
    printf("}\n");
    long long dp_hucre = hucre;
    dp_birak();
    ziyaret = 0;
    cozum_sayisi = 0;
    budamali(0, 0);
    printf("  geri izleme: %lld çözüm, %lld düğüm; DP: %lld hücre\n",
           cozum_sayisi, ziyaret, dp_hucre);

    dizi_kur(18, 42);
    long long toplam_a = 0;
    printf("\n2) H3'ün girdisi: n = 18, a (tohum 42, 1..40) =");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
        toplam_a += a[i];
    }
    printf("\n   toplam = %lld\n", toplam_a);
    printf("  hedef  yöntem             çözüm  düğüm/hücre  bir çözüm\n");
    const long long hedefler[] = {50, toplam_a / 2};
    for (int h = 0; h < 2; h++) {
        hedef = hedefler[h];
        ziyaret = 0;
        cozum_sayisi = 0;
        budamali(0, 0);
        printf("  %5lld  geri izleme (H3)  %6lld  %11lld\n", hedef,
               cozum_sayisi, ziyaret);
        if (dp_doldur((int)hedef) != 0) {
            dp_birak();
            return 1;
        }
        int s = (int)hedef + 1;
        k = geri_cikar((int)hedef, secilen);
        printf("  %5lld  DP (var + say)    %6lld  %11lld  {", hedef,
               say_t[n * s + (int)hedef], hucre);
        for (int x = k - 1; x >= 0; x--) {
            printf(x < k - 1 ? ", %d" : "%d", secilen[x]);
        }
        printf("}\n");
        dp_birak();
    }

    printf("\n3) n'ye göre (hedef = toplam / 2; a: aynı LCG dizisinin ilk n "
           "öğesi)\n");
    printf("   n  toplam  hedef  kaba kuvvet düğümü  geri izleme düğümü  "
           "DP hücresi  çözüm\n");
    for (int adet = 10; adet <= 18; adet += 2) {
        dizi_kur(adet, 42);
        toplam_a = 0;
        for (int i = 0; i < n; i++) {
            toplam_a += a[i];
        }
        hedef = toplam_a / 2;
        ziyaret = 0;
        cozum_sayisi = 0;
        budamali(0, 0);
        if (dp_doldur((int)hedef) != 0) {
            dp_birak();
            return 1;
        }
        long long dp_say = say_t[n * ((int)hedef + 1) + (int)hedef];
        printf("  %2d  %6lld  %5lld  %18lld  %18lld  %10lld  %5lld%s\n", n,
               toplam_a, hedef, (1LL << (n + 1)) - 1, ziyaret, hucre,
               cozum_sayisi, dp_say == cozum_sayisi ? "" : " FARKLI");
        dp_birak();
    }
    printf("  (kaba kuvvet düğümü = 2^(n+1) - 1; DP hücresi = (n+1)(hedef+1)"
           ")\n");
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: H3 Örnek 5'in bit
 * maskesi taraması; burada iki bağımsız yöntemin sayımları karşılaştırılır.
 */

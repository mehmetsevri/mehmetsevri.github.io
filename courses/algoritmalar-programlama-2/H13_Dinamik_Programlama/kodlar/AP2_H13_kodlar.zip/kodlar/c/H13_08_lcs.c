/* H13_08_lcs.c — AP-2 Hafta 13 · Örnek 8 (★★★)
 * Amaç    : En uzun ortak alt dizi (LCS): tablo, ortak alt dizinin geri
 *           çıkarılması (yol çizimi), satır düzeyinde diff (LCS dışında
 *           kalan satırlar silinir/eklenir) ve rastgele DNA dizileri
 * DP      : durum L[i][j] = a[0..i) ile b[0..j)'nin LCS uzunluğu · geçiş
 *           a[i−1] = b[j−1] ise L[i−1][j−1] + 1, değilse max(L[i−1][j],
 *           L[i][j−1]) · temel L[0][j] = L[i][0] = 0 · sıra satır
 *           öncelikli (i artan, j artan) · cevap L[n][m] · geri çıkarma
 *           (n, m)'den: eşitse ÇAPRAZ; değilse L[i−1][j] >= L[i][j−1]
 *           ise YUKARI, yoksa SOL (eşitlikte önce yukarı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_08_lcs.c ortak_rastgele.c -o H13_08_lcs
 * Çalıştır: ./H13_08_lcs
 * Eşleri  : cpp/H13_08_lcs.cpp · python/H13_08_lcs.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

/* Sahiplik: dönen (n+1)(m+1) blok çağıranındır (free). L[i*(m+1)+j] */
static int *lcs_tablo(const char *a, int n, const char *b, int m)
{
    int s = m + 1;                                 /* satır uzunluğu */
    int *L = malloc((size_t)(n + 1) * (size_t)s * sizeof *L);
    if (L == NULL) {
        return NULL;
    }
    for (int j = 0; j <= m; j++) {
        L[j] = 0;                                  /* L[0][j] = 0 */
    }
    for (int i = 1; i <= n; i++) {
        L[i * s] = 0;                              /* L[i][0] = 0 */
        for (int j = 1; j <= m; j++) {
            if (a[i - 1] == b[j - 1]) {
                L[i * s + j] = L[(i - 1) * s + j - 1] + 1;
            } else if (L[(i - 1) * s + j] >= L[i * s + j - 1]) {
                L[i * s + j] = L[(i - 1) * s + j];
            } else {
                L[i * s + j] = L[i * s + j - 1];
            }
        }
    }
    return L;
}

/* Geri çıkarma: ortak alt diziyi cikti'ya yazar; yol[] hücre işaretleri
 * (0 yok, 1 çapraz, 2 yukarı, 3 sol), NULL olabilir. Dönen: uzunluk */
static int lcs_geri_cikar(const int *L, const char *a, int n, const char *b,
                          int m, char *cikti, unsigned char *yol)
{
    int s = m + 1;
    int k = L[n * s + m];
    cikti[k] = '\0';
    int i = n, j = m;
    while (i > 0 && j > 0) {
        if (a[i - 1] == b[j - 1]) {
            cikti[--k] = a[i - 1];
            if (yol) {
                yol[i * s + j] = 1;
            }
            i--;
            j--;
        } else if (L[(i - 1) * s + j] >= L[i * s + j - 1]) {
            if (yol) {
                yol[i * s + j] = 2;                /* önce yukarı */
            }
            i--;
        } else {
            if (yol) {
                yol[i * s + j] = 3;
            }
            j--;
        }
    }
    return L[n * s + m];
}

/* x, y'nin alt dizisi mi? (iki işaretçi) */
static int alt_dizi_mi(const char *x, const char *y)
{
    for (; *y != '\0' && *x != '\0'; y++) {
        if (*x == *y) {
            x++;
        }
    }
    return *x == '\0';
}

/* Satır diff: satırlar üzerinde aynı DP (eşitlik = strcmp) */
static void satir_diff(const char *eski[], int n, const char *yeni[], int m)
{
    int s = m + 1;
    int *L = malloc((size_t)(n + 1) * (size_t)s * sizeof *L);
    char *islem = malloc((size_t)(n + m));
    int *satir = malloc((size_t)(n + m) * sizeof *satir);
    if (L == NULL || islem == NULL || satir == NULL) {
        free(L);
        free(islem);
        free(satir);
        return;
    }
    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            if (i == 0 || j == 0) {
                L[i * s + j] = 0;
            } else if (strcmp(eski[i - 1], yeni[j - 1]) == 0) {
                L[i * s + j] = L[(i - 1) * s + j - 1] + 1;
            } else if (L[(i - 1) * s + j] >= L[i * s + j - 1]) {
                L[i * s + j] = L[(i - 1) * s + j];
            } else {
                L[i * s + j] = L[i * s + j - 1];
            }
        }
    }
    int k = 0, i = n, j = m;                       /* sondan başa */
    while (i > 0 || j > 0) {
        if (i > 0 && j > 0 && strcmp(eski[i - 1], yeni[j - 1]) == 0) {
            islem[k] = ' ';
            satir[k++] = --i;
            j--;
        } else if (i > 0 && (j == 0 || L[(i - 1) * s + j] >=
                                           L[i * s + j - 1])) {
            islem[k] = '-';
            satir[k++] = --i;
        } else {
            islem[k] = '+';
            satir[k++] = --j;
        }
    }
    printf("  ortak satır = L[%d][%d] = %d; silinen %d, eklenen %d\n", n, m,
           L[n * s + m], n - L[n * s + m], m - L[n * s + m]);
    for (int x = k - 1; x >= 0; x--) {             /* baştan sona yaz */
        const char *metin = islem[x] == '+' ? yeni[satir[x]]
                                            : eski[satir[x]];
        printf("    %c %s\n", islem[x], metin);
    }
    free(L);
    free(islem);
    free(satir);
}

int main(void)
{
    const char *a = "ABCBDAB", *b = "BDCABA";
    int n = (int)strlen(a), m = (int)strlen(b), s = m + 1;
    printf("1) a = \"%s\", b = \"%s\" (Cormen vd. örneği)\n", a, b);
    int *L = lcs_tablo(a, n, b, m);
    unsigned char *yol = calloc((size_t)(n + 1) * (size_t)s, 1);
    char lcs[64];
    if (L == NULL || yol == NULL) {
        free(L);
        free(yol);
        fprintf(stderr, "bellek ayrılamadı\n");
        return 1;
    }
    int uzunluk = lcs_geri_cikar(L, a, n, b, m, lcs, yol);
    printf("  L tablosu (satır: a'nın önekleri; sütun: b'nin önekleri)\n");
    printf("     \"\"");
    for (int j = 0; j < m; j++) {
        printf("  %c", b[j]);
    }
    printf("\n");
    for (int i = 0; i <= n; i++) {
        if (i == 0) {
            printf("  \"\"");
        } else {
            printf("   %c", a[i - 1]);
        }
        for (int j = 0; j <= m; j++) {
            printf(" %2d", L[i * s + j]);
        }
        printf("\n");
    }
    printf("  LCS uzunluğu = L[%d][%d] = %d; hücre = (n+1)(m+1) = %d\n", n,
           m, uzunluk, (n + 1) * s);
    printf("  geri çıkarma yolu (↖ eşleşme, ↑ yukarı, ← sol; eşitlikte "
           "↑):\n");
    const char *ok[] = {" .", " ↖", " ↑", " ←"};
    for (int i = 0; i <= n; i++) {
        printf("    ");
        for (int j = 0; j <= m; j++) {
            printf(" %s", ok[yol[i * s + j]]);
        }
        printf("\n");
    }
    printf("  ortak alt dizi = \"%s\"; a'nın alt dizisi: %s, b'nin: %s\n",
           lcs, alt_dizi_mi(lcs, a) ? "evet" : "HAYIR",
           alt_dizi_mi(lcs, b) ? "evet" : "HAYIR");
    free(L);
    free(yol);

    printf("\n2) Satır düzeyinde diff (LCS'de olmayan: - silinen, + "
           "eklenen)\n");
    const char *eski[] = {"Rize çayı demlenir.", "Su kaynatılır.",
                          "Demlik ısıtılır.", "Çay demliğe konur.",
                          "On beş dakika beklenir."};
    const char *yeni[] = {"Su kaynatılır.", "Demlik ısıtılır.",
                          "Çay demliğe konur.", "Üstüne kaynar su eklenir.",
                          "On beş dakika beklenir.",
                          "İnce belli bardakta sunulur."};
    satir_diff(eski, 5, yeni, 6);

    printf("\n3) Rastgele DNA (A C G T; tohum 7), n = m = 300\n");
    char x[301], y[301], ortak[301];
    const char harf[] = "ACGT";
    rastgele_tohum(7);
    for (int i = 0; i < 300; i++) {
        x[i] = harf[rastgele_aralik(0, 3)];
    }
    for (int i = 0; i < 300; i++) {
        y[i] = harf[rastgele_aralik(0, 3)];
    }
    x[300] = y[300] = '\0';
    L = lcs_tablo(x, 300, y, 300);
    if (L == NULL) {
        fprintf(stderr, "bellek ayrılamadı\n");
        return 1;
    }
    uzunluk = lcs_geri_cikar(L, x, 300, y, 300, ortak, NULL);
    printf("  x[0..39] = %.40s\n  y[0..39] = %.40s\n", x, y);
    printf("  LCS uzunluğu = %d (oran %.4f); hücre = %d\n", uzunluk,
           uzunluk / 300.0, 301 * 301);
    printf("  LCS[0..39] = %.40s; x'in ve y'nin alt dizisi: %s\n", ortak,
           alt_dizi_mi(ortak, x) && alt_dizi_mi(ortak, y) ? "evet"
                                                          : "HAYIR");
    free(L);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++); Python — difflib.SequenceMatcher
 * LCS değil (Ratcliff/Obershelp benzeri) eşleme yapar; diff aracı Hunt ve
 * McIlroy'un (1976) LCS tabanlı yöntemine dayanır. */

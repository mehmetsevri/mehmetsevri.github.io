/* H13_11_sirt_tek_satir.c — AP-2 Hafta 13 · Örnek 11 (★★★)
 * Amaç    : 0/1 sırt çantası tek satırla (bellek O(W)): kapasite TERS
 *           sırada dolaşılır. Yan yana: ARTAN sırada dolaşınca aynı nesne
 *           birden çok kez alınır — sınırsız sırt çantası olur. Her
 *           nesneden sonra satır; tam tablo ve sınırsız DP ile denetim
 * DP      : durum dp[w] = şimdiye dek işlenen nesnelerle w kapasitede en
 *           büyük değer (tam tablonun i. satırı yerinde) · geçiş dp[w] =
 *           max(dp[w], dp[w − a_i] + d_i) · temel dp[w] = 0 · sıra nesne
 *           i dışta; w = W, W−1, …, a_i (TERS: dp[w − a_i] henüz bu
 *           nesneyle güncellenmemiştir, yani "önceki satır") · cevap
 *           dp[W] · geri çıkarma YOK (önceki satırlar üzerine yazıldı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_11_sirt_tek_satir.c ortak_rastgele.c \
 *           -o H13_11_sirt_tek_satir
 * Çalıştır: ./H13_11_sirt_tek_satir
 * Eşleri  : cpp/H13_11_sirt_tek_satir.cpp · python/H13_11_sirt_tek_satir.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#include "ortak_rastgele.h"

#define MAKS_W 64
#define MAKS_N 16

static int iz_nesne = -1;          /* güncellemeleri yazılacak nesne */

static void satir_yaz(const char *etiket, const int dp[], int W)
{
    printf("  %-6s:", etiket);
    for (int w = 0; w <= W; w++) {
        printf(" %3d", dp[w]);
    }
    printf("\n");
}

static void guncelleme_yaz(int w, int eski, int yeni, int kaynak)
{
    printf("      dp[%d]: %d -> %d  (dp[%d] + d)\n", w, eski, yeni, kaynak);
}

/* 0/1: w TERS sırada; satirlari_yaz ise her nesneden sonra satır */
static int tek_satir_ters(const int a[], const int d[], const char *ad[],
                          int n, int W, int satirlari_yaz, int dp[])
{
    for (int w = 0; w <= W; w++) {
        dp[w] = 0;                             /* temel */
    }
    for (int i = 0; i < n; i++) {
        for (int w = W; w >= a[i]; w--) {      /* TERS */
            if (dp[w - a[i]] + d[i] > dp[w]) {
                if (i == iz_nesne) {
                    guncelleme_yaz(w, dp[w], dp[w - a[i]] + d[i], w - a[i]);
                }
                dp[w] = dp[w - a[i]] + d[i];
            }
        }
        if (satirlari_yaz) {
            char etiket[16];
            snprintf(etiket, sizeof etiket, "+%s", ad[i]);
            satir_yaz(etiket, dp, W);
        }
    }
    return dp[W];
}

/* YANLIŞ (0/1 için): w ARTAN sırada; dp[w − a_i] bu turda güncellenmiş
 * olabilir → aynı nesne yeniden alınır (sınırsız sırt çantası) */
static int tek_satir_artan(const int a[], const int d[], const char *ad[],
                           int n, int W, int satirlari_yaz, int dp[])
{
    for (int w = 0; w <= W; w++) {
        dp[w] = 0;
    }
    for (int i = 0; i < n; i++) {
        for (int w = a[i]; w <= W; w++) {      /* ARTAN */
            if (dp[w - a[i]] + d[i] > dp[w]) {
                if (i == iz_nesne) {
                    guncelleme_yaz(w, dp[w], dp[w - a[i]] + d[i], w - a[i]);
                }
                dp[w] = dp[w - a[i]] + d[i];
            }
        }
        if (satirlari_yaz) {
            char etiket[16];
            snprintf(etiket, sizeof etiket, "+%s", ad[i]);
            satir_yaz(etiket, dp, W);
        }
    }
    return dp[W];
}

/* Denetim 1: tam tablonun son satırı (Örnek 10) */
static int tam_tablo_son(const int a[], const int d[], int n, int W,
                         int son[])
{
    int K[MAKS_N + 1][MAKS_W + 1];
    for (int w = 0; w <= W; w++) {
        K[0][w] = 0;
    }
    for (int i = 1; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            K[i][w] = K[i - 1][w];
            if (a[i - 1] <= w) {
                int al = K[i - 1][w - a[i - 1]] + d[i - 1];
                if (al > K[i][w]) {
                    K[i][w] = al;
                }
            }
        }
    }
    for (int w = 0; w <= W; w++) {
        son[w] = K[n][w];
    }
    return K[n][W];
}

/* Denetim 2: sınırsız sırt çantası, kapasite dışta: u[w] = max(u[w − a_i]
 * + d_i) — her nesne istenen sayıda */
static int sinirsiz(const int a[], const int d[], int n, int W)
{
    int u[MAKS_W + 1];
    u[0] = 0;
    for (int w = 1; w <= W; w++) {
        u[w] = 0;
        for (int i = 0; i < n; i++) {
            if (a[i] <= w && u[w - a[i]] + d[i] > u[w]) {
                u[w] = u[w - a[i]] + d[i];
            }
        }
    }
    return u[W];
}

int main(void)
{
    const char *ad[] = {"A", "B", "C", "D"};
    const int a[] = {5, 4, 6, 3}, d[] = {10, 40, 30, 50};
    const int n = 4, W = 10;
    int dp[MAKS_W + 1], dp2[MAKS_W + 1];
    printf("1) Örnek 10'un nesneleri: A(5, 10) B(4, 40) C(6, 30) D(3, 50); "
           "W = %d\n", W);
    printf("  (+X: X nesnesi işlendikten sonra tek satır dp[0..W])\n");
    printf("  %-6s:", "w");
    for (int w = 0; w <= W; w++) {
        printf(" %3d", w);
    }
    printf("\n  TERS (w = W..a_i) — doğru 0/1:\n");
    int ters = tek_satir_ters(a, d, ad, n, W, 1, dp);
    printf("  ARTAN (w = a_i..W) — YANLIŞ: sınırsız sırt çantası:\n");
    int artan = tek_satir_artan(a, d, ad, n, W, 1, dp2);
    printf("  ters: dp[W] = %d; artan: dp[W] = %d\n", ters, artan);

    printf("\n2) Neden? D(3, 50) işlenirken dp güncellemeleri\n");
    iz_nesne = 3;
    printf("  TERS : dp[w - 3] önceki satırdan (D henüz yok)\n");
    tek_satir_ters(a, d, ad, n, W, 0, dp2);
    printf("  ARTAN: dp[w - 3] bu turda D ile güncellenmiş olabilir\n");
    tek_satir_artan(a, d, ad, n, W, 0, dp2);
    iz_nesne = -1;
    printf("  (artan: dp[6] = dp[3] + 50 -> D ikinci kez; dp[9] = dp[6] + "
           "50 -> üçüncü kez)\n");

    int son[MAKS_W + 1];
    int tam = tam_tablo_son(a, d, n, W, son);
    int dp_ayni = 1;
    for (int w = 0; w <= W; w++) {
        if (dp[w] != son[w]) {
            dp_ayni = 0;
        }
    }
    int u = sinirsiz(a, d, n, W);
    printf("\n3) Denetim\n");
    printf("  ters satır = tam tablonun son satırı K[n][0..W]: %s "
           "(K[n][W] = %d)\n", dp_ayni ? "evet" : "HAYIR", tam);
    printf("  artan sonuç = sınırsız sırt çantası DP'si (%d): %s\n", u,
           u == artan ? "evet" : "HAYIR");

    printf("\n4) Bellek: hücre sayısı\n");
    printf("  bu örnek: tam tablo (n+1)(W+1) = %d, tek satır W+1 = %d\n",
           (n + 1) * (W + 1), W + 1);
    printf("  n = 100, W = 100000: tam tablo = %lld, tek satır = %lld\n",
           101LL * 100001LL, 100001LL);
    printf("  bedel: seçilen nesneler geri çıkarılamaz (önceki satırlar "
           "silindi)\n");

    const char *ad3[] = {"D01", "D02", "D03", "D04", "D05", "D06",
                         "D07", "D08", "D09", "D10", "D11", "D12"};
    int a3[12], d3[12];
    rastgele_tohum(4);
    for (int i = 0; i < 12; i++) {
        a3[i] = rastgele_aralik(2, 8);
        d3[i] = rastgele_aralik(1, 20);
    }
    int t3 = tek_satir_ters(a3, d3, ad3, 12, 30, 0, dp);
    int k3 = tam_tablo_son(a3, d3, 12, 30, son);
    int y3 = tek_satir_artan(a3, d3, ad3, 12, 30, 0, dp2);
    printf("\n5) Örnek 10'un 12 dersi (tohum 4, W = 30): tek satır = %d, "
           "tam tablo = %d; artan (yanlış) = %d\n", t3, k3, y3);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python); tek satır elle. */

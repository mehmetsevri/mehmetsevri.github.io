/* H13_03_bozuk_para_en_az.c — AP-2 Hafta 13 · Örnek 3 (★★)
 * Amaç    : En az para sayısı: H12'nin karşı örneği ({1, 3, 4}, tutar 6:
 *           açgözlü 3 para, DP 2 para); kullanılan paraların geri
 *           çıkarılması; ulaşılamayan tutar için ∞ sözleşmesi (taşma
 *           korumalı); kanonik sistemde açgözlü = DP
 * DP      : durum enaz[t] = t tutarı için en az para · geçiş
 *           enaz[t] = min{enaz[t−c] + 1 : c <= t, enaz[t−c] != ∞} ·
 *           temel enaz[0] = 0, diğerleri ∞ (SONSUZ = INT_MAX) · sıra
 *           t = 1..S artan · cevap enaz[S] · geri çıkarma secim[t] = son
 *           para, t -= secim[t]; paralar artan denenir, yalnız KESİN
 *           küçükte güncellenir (eşitlikte küçük para kalır)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_03_bozuk_para_en_az.c -o H13_03_bozuk_para_en_az
 * Çalıştır: ./H13_03_bozuk_para_en_az
 * Eşleri  : cpp/H13_03_bozuk_para_en_az.cpp ·
 *           python/H13_03_bozuk_para_en_az.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stdio.h>

#define MAKS_S 1000
#define SONSUZ INT_MAX             /* "ulaşılamaz" */

static int enaz[MAKS_S + 1];
static int secim[MAKS_S + 1];      /* enaz[t]'yi veren son para (0: yok) */

/* paralar[0..k-1] ARTAN sıralı; enaz[0..S] ve secim[0..S] doldurulur */
static void en_az_para(const int paralar[], int k, int S)
{
    enaz[0] = 0;                           /* temel durum */
    secim[0] = 0;
    for (int t = 1; t <= S; t++) {
        enaz[t] = SONSUZ;                  /* henüz ulaşılamadı */
        secim[t] = 0;
        for (int i = 0; i < k; i++) {
            int c = paralar[i];
            if (c <= t && enaz[t - c] != SONSUZ &&    /* taşma koruması */
                enaz[t - c] + 1 < enaz[t]) {
                enaz[t] = enaz[t - c] + 1;
                secim[t] = c;
            }
        }
    }
}

/* Açgözlü (H12): en büyük sığan parayı al; para sayısı ya da -1 */
static int acgozlu(const int paralar[], int k, int t, int alinan[])
{
    int sayi = 0;
    for (int i = k - 1; i >= 0; i--) {
        while (paralar[i] <= t) {
            t -= paralar[i];
            alinan[sayi++] = paralar[i];
        }
    }
    return t == 0 ? sayi : -1;
}

/* DP çözümünü geri çıkarır: t, t - secim[t], ...; para sayısı */
static int geri_cikar(int t, int alinan[])
{
    int sayi = 0;
    while (t > 0) {
        alinan[sayi++] = secim[t];
        t -= secim[t];
    }
    return sayi;
}

static void yaz_paralar(const int alinan[], int sayi)
{
    for (int i = 0; i < sayi; i++) {
        printf(i > 0 ? " + %d" : "%d", alinan[i]);
    }
}

static void yaz_kume(const int paralar[], int k)
{
    printf("{");
    for (int i = 0; i < k; i++) {
        printf(i > 0 ? ", %d" : "%d", paralar[i]);
    }
    printf("}");
}

int main(void)
{
    int alinan[MAKS_S];
    const int p1[] = {1, 3, 4};
    en_az_para(p1, 3, 20);

    printf("1) H12'nin karşı örneği: paralar {1, 3, 4}, tutar 6\n");
    int sayi = acgozlu(p1, 3, 6, alinan);
    printf("  açgözlü (en büyük sığan para): ");
    yaz_paralar(alinan, sayi);
    printf(" = %d para\n", sayi);
    sayi = geri_cikar(6, alinan);
    printf("  DP (en az para)              : ");
    yaz_paralar(alinan, sayi);
    printf(" = %d para\n", sayi);

    printf("\n2) Tablo: enaz[t] = min(enaz[t-c] + 1); enaz[0] = 0, "
           "diğerleri ∞\n");
    printf("   t  enaz  secim  adaylar c:enaz[t-c]+1\n");
    for (int t = 0; t <= 6; t++) {
        printf("  %2d  %4d  ", t, enaz[t]);
        if (secim[t] == 0) {
            printf("    -");
        } else {
            printf("%5d", secim[t]);
        }
        for (int i = 0; i < 3; i++) {
            if (p1[i] <= t) {
                printf(i == 0 ? "   %d:%d" : "  %d:%d", p1[i],
                       enaz[t - p1[i]] + 1);
            }
        }
        printf("\n");
    }

    printf("\n3) Geri çıkarma: t = 6");
    for (int t = 6; t > 0; t -= secim[t]) {
        printf(" -> %d (secim %d)", t - secim[t], secim[t]);
    }
    printf("\n");

    printf("\n4) Açgözlü ile DP, paralar {1, 3, 4}, t = 1..20: farklı "
           "olanlar\n");
    printf("   t  açgözlü  DP  açgözlü paralar / DP paraları\n");
    int fark = 0;
    for (int t = 1; t <= 20; t++) {
        int ag[MAKS_S], dp[MAKS_S];
        int na = acgozlu(p1, 3, t, ag);
        int nd = geri_cikar(t, dp);
        if (na != nd) {
            fark++;
            printf("  %2d  %7d  %2d  ", t, na, nd);
            yaz_paralar(ag, na);
            printf(" / ");
            yaz_paralar(dp, nd);
            printf("\n");
        }
    }
    printf("  farklı tutar sayısı: %d / 20\n", fark);

    const int p2[] = {4, 6};
    en_az_para(p2, 2, 12);
    printf("\n5) Ulaşılamayan tutar: paralar ");
    yaz_kume(p2, 2);
    printf(", SONSUZ = INT_MAX = %d\n", SONSUZ);
    printf("  t   :");
    for (int t = 0; t <= 12; t++) {
        printf(" %2d", t);
    }
    printf("\n  enaz:");
    for (int t = 0; t <= 12; t++) {
        if (enaz[t] == SONSUZ) {
            printf("  ∞");
        } else {
            printf(" %2d", enaz[t]);
        }
    }
    printf("\n  tutar 7: %s; açgözlü: %s\n",
           enaz[7] == SONSUZ ? "ulaşılamaz (enaz = ∞)" : "ulaşılır",
           acgozlu(p2, 2, 7, alinan) < 0 ? "çözüm bulamaz" : "çözüm");
    printf("  (enaz[t-c] != SONSUZ denetimi olmasa INT_MAX + 1 taşardı: "
           "Hata Avcısı)\n");

    const int p3[] = {1, 5, 10, 25, 50, 100};
    en_az_para(p3, 6, MAKS_S);
    int esit = 0;
    for (int t = 1; t <= MAKS_S; t++) {
        if (acgozlu(p3, 6, t, alinan) == enaz[t]) {
            esit++;
        }
    }
    printf("\n6) Kanonik sistem ");
    yaz_kume(p3, 6);
    printf(" (kuruş): t = 1..%d için açgözlü = DP: %d / %d\n", MAKS_S,
           esit, MAKS_S);
    printf("  t = 289: DP ");
    sayi = geri_cikar(289, alinan);
    yaz_paralar(alinan, sayi);
    printf(" = %d para\n", sayi);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python); DP tablosu elle doldurulur.
 * H12'de açgözlü yalnız kanonik para sistemlerinde en iyidir. */

/* H13_07_lis_n2.c — AP-2 Hafta 13 · Örnek 7 (★★)
 * Amaç    : En uzun (kesin) artan alt dizi, O(n²) DP; ebeveyn dizisiyle
 *           dizinin geri çıkarılması; kâhin: bütün alt kümeler (2^n)
 * DP      : durum uz[i] = a[i] ile BİTEN en uzun artan alt dizinin
 *           uzunluğu · geçiş uz[i] = 1 + max{uz[j] : j < i, a[j] < a[i]}
 *           · temel uz[i] = 1, ebeveyn[i] = −1 · sıra i = 0..n−1 artan,
 *           içte j = 0..i−1 · cevap max uz[i] · geri çıkarma ebeveyn
 *           zinciri. Eşitlik: j artan dolaşılır, yalnız KESİN büyükte
 *           güncellenir (en küçük j); sonda en küçük i seçilir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_07_lis_n2.c ortak_rastgele.c -o H13_07_lis_n2
 * Çalıştır: ./H13_07_lis_n2
 * Eşleri  : cpp/H13_07_lis_n2.cpp · python/H13_07_lis_n2.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#include "ortak_rastgele.h"

#define MAKS_N 64

static long long karsilastirma = 0;

/* uz[] ve ebeveyn[] doldurulur; dönen: en uzun alt dizinin son indisi */
static int lis_n2(const int a[], int n, int uz[], int ebeveyn[])
{
    int son = 0;
    for (int i = 0; i < n; i++) {
        uz[i] = 1;                             /* temel: yalnız a[i] */
        ebeveyn[i] = -1;
        for (int j = 0; j < i; j++) {
            karsilastirma++;
            if (a[j] < a[i] && uz[j] + 1 > uz[i]) {
                uz[i] = uz[j] + 1;
                ebeveyn[i] = j;
            }
        }
        if (uz[i] > uz[son]) {                 /* eşitlikte küçük i */
            son = i;
        }
    }
    return son;
}

/* Ebeveyn zincirini izleyip indisleri BAŞTAN SONA yazar; uzunluk */
static int geri_cikar(const int ebeveyn[], int son, int indis[])
{
    int k = 0;
    for (int i = son; i != -1; i = ebeveyn[i]) {
        indis[k++] = i;
    }
    for (int x = 0, y = k - 1; x < y; x++, y--) {  /* ters çevir */
        int g = indis[x];
        indis[x] = indis[y];
        indis[y] = g;
    }
    return k;
}

/* Kâhin: 2^n bit maskesi (H3 Örnek 5), kesin artan en uzun alt küme */
static int kahin(const int a[], int n)
{
    int en_iyi = 0;
    for (long maske = 1; maske < (1L << n); maske++) {
        int onceki = 0, uzunluk = 0, artan = 1;
        for (int i = 0; i < n && artan; i++) {
            if (maske & (1L << i)) {
                if (uzunluk > 0 && a[i] <= onceki) {
                    artan = 0;
                }
                onceki = a[i];
                uzunluk++;
            }
        }
        if (artan && uzunluk > en_iyi) {
            en_iyi = uzunluk;
        }
    }
    return en_iyi;
}

static void yaz_satir(const char *ad, const int x[], int n)
{
    printf("  %-8s:", ad);
    for (int i = 0; i < n; i++) {
        printf(" %3d", x[i]);
    }
    printf("\n");
}

static int coz_ve_yaz(const int a[], int n, int ayrintili)
{
    int uz[MAKS_N], ebeveyn[MAKS_N], indis[MAKS_N], sira[MAKS_N];
    karsilastirma = 0;
    int son = lis_n2(a, n, uz, ebeveyn);
    if (ayrintili) {
        for (int i = 0; i < n; i++) {
            sira[i] = i;
        }
        yaz_satir("i", sira, n);
        yaz_satir("a[i]", a, n);
        yaz_satir("uz[i]", uz, n);
        yaz_satir("ebeveyn", ebeveyn, n);
    }
    int k = geri_cikar(ebeveyn, son, indis);
    printf("  en uzun: uz = %d, son indis %d (eşitlikte en küçük indis)\n",
           uz[son], son);
    printf("  geri çıkarma (ebeveyn zinciri):");
    for (int x = k - 1; x >= 0; x--) {
        printf(x < k - 1 ? " -> %d" : " %d", indis[x]);
    }
    printf("\n  alt dizi:");
    for (int x = 0; x < k; x++) {
        printf(" %d", a[indis[x]]);
    }
    printf("   (indisler:");
    for (int x = 0; x < k; x++) {
        printf(" %d", indis[x]);
    }
    printf(")\n  karşılaştırma = %lld = n(n-1)/2 = %d\n", karsilastirma,
           n * (n - 1) / 2);
    return uz[son];
}

int main(void)
{
    const int a1[] = {5, 2, 8, 6, 3, 6, 9, 7};
    printf("1) a = {5, 2, 8, 6, 3, 6, 9, 7} (n = 8)\n");
    coz_ve_yaz(a1, 8, 1);

    int a2[16];
    rastgele_tohum(42);
    rastgele_dizi(a2, 16, 1, 50);
    printf("\n2) Rastgele a (tohum 42, n = 16, 1..50):");
    for (int i = 0; i < 16; i++) {
        printf(" %d", a2[i]);
    }
    printf("\n");
    int uzunluk = coz_ve_yaz(a2, 16, 1);
    int k = kahin(a2, 16);
    printf("  kâhin (2^16 alt küme taraması): %d -> %s\n", k,
           k == uzunluk ? "aynı" : "FARKLI");

    printf("\n3) Sınır durumları (n = 8)\n");
    int artan[8], azalan[8], esit[8];
    for (int i = 0; i < 8; i++) {
        artan[i] = i + 1;
        azalan[i] = 8 - i;
        esit[i] = 5;
    }
    int uz[MAKS_N], eb[MAKS_N];
    int s1 = lis_n2(artan, 8, uz, eb);
    printf("  artan 1..8      : uz = %d\n", uz[s1]);
    int s2 = lis_n2(azalan, 8, uz, eb);
    printf("  azalan 8..1     : uz = %d\n", uz[s2]);
    int s3 = lis_n2(esit, 8, uz, eb);
    printf("  hepsi 5 (eşit)  : uz = %d (KESİN artan: a[j] < a[i])\n",
           uz[s3]);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). O(n log n) sürüm: Örnek 13
 * (H4 lower_bound ile "sabır sıralaması"). */

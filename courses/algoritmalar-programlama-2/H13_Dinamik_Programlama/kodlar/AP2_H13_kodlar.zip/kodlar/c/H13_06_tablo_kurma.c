/* H13_06_tablo_kurma.c — AP-2 Hafta 13 · Örnek 6 (★★, Dil Penceresi)
 * Amaç    : 2B DP tablosu kurma: C'de tek malloc bloğu ve t[i * m + j]
 *           indeksleme (satırlar bitişik, satır öncelikli düzen — AP-1
 *           H11); aynı tabloyla Pascal üçgeni. C++'ta vector<vector<int>>,
 *           Python'da [[0] * m] * n tuzağı ve doğru biçim (eş dosyalar)
 * DP      : durum t[i][j] = C(i, j) · geçiş C(i, j) = C(i−1, j−1) +
 *           C(i−1, j) · temel C(i, 0) = C(i, i) = 1 · sıra i artan (satır
 *           öncelikli), j = 1..i−1 · cevap t[n−1][k]
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_06_tablo_kurma.c -o H13_06_tablo_kurma
 * Çalıştır: ./H13_06_tablo_kurma
 * Eşleri  : cpp/H13_06_tablo_kurma.cpp · python/H13_06_tablo_kurma.py
 * Çıktı   : Δ — dile özgü (bölüm 1 her dilde farklı; bölüm 2 aynı);
 *           bkz. Dil Penceresi
 */
#include <stdio.h>
#include <stdlib.h>

/* Sahiplik: dönen blok çağıranındır; free ile bırakılır. NULL: yer yok */
static int *tablo_kur(int n, int m)
{
    size_t hucre = (size_t)n * (size_t)m;
    int *t = malloc(hucre * sizeof *t);        /* TEK blok: n * m hücre */
    if (t == NULL) {
        return NULL;
    }
    for (size_t k = 0; k < hucre; k++) {
        t[k] = 0;
    }
    return t;
}

/* Pascal üçgeni: t[i * m + j] = C(i, j), 0 <= j <= i < n */
static void pascal_doldur(int *t, int n, int m)
{
    for (int i = 0; i < n; i++) {
        t[i * m + 0] = 1;                          /* C(i, 0) = 1 */
        t[i * m + i] = 1;                          /* C(i, i) = 1 */
        for (int j = 1; j < i; j++) {
            t[i * m + j] = t[(i - 1) * m + (j - 1)] + t[(i - 1) * m + j];
        }
    }
}

static void pascal_yaz(const int *t, int n, int m)
{
    for (int i = 0; i < n; i++) {
        printf("   ");
        for (int j = 0; j <= i; j++) {
            printf(" %4d", t[i * m + j]);
        }
        printf("\n");
    }
}

int main(void)
{
    const int n = 6, m = 6;
    printf("1) 2B tablo, C: tek malloc bloğu, t[i * m + j] (n = %d, m = %d)"
           "\n", n, m);
    int *t = tablo_kur(n, m);
    if (t == NULL) {
        fprintf(stderr, "bellek ayrılamadı\n");
        return 1;
    }
    printf("  malloc(n * m * sizeof(int)): %d hücre TEK parça\n", n * m);
    printf("  hücre (i, j) -> indis i * m + j: (0,0)->%d (0,5)->%d "
           "(1,0)->%d (5,5)->%d\n", 0 * m + 0, 0 * m + 5, 1 * m + 0,
           5 * m + 5);
    printf("  satır başları:");
    for (int i = 0; i < n; i++) {
        printf(" %d", i * m);
    }
    printf("  (satır i, satır i-1'in hemen ardından)\n");
    t[0 * m + 0] = 7;
    printf("  t[0 * m + 0] = 7: öteki satırların ilk hücreleri:");
    for (int i = 1; i < n; i++) {
        printf(" %d", t[i * m + 0]);
    }
    printf("\n  (her satır ayrı hücrelerdir; paylaşım yok)\n");
    t[0] = 0;

    printf("\n2) Pascal üçgeni (DP): C(i, j) = C(i-1, j-1) + C(i-1, j); "
           "C(i, 0) = C(i, i) = 1\n");
    pascal_doldur(t, n, m);
    pascal_yaz(t, n, m);
    printf("  C(5, 2) = %d\n", t[5 * m + 2]);
    free(t);
    return 0;
}

/* Kütüphane karşılığı: C — yok (tek blok + indis hesabı elle); C++ —
 * std::vector<std::vector<int>> ya da std::vector<int>(n * m); Python —
 * [[0] * m for _ in range(n)]. */

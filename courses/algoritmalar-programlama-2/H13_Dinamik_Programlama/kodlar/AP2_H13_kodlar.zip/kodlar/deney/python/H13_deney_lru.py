"""H13_deney_lru.py — AP-2 Hafta 13 · Haftanın Deneyi (b) — yalnız Python
Amaç    : functools.lru_cache / functools.cache ile elle yazılmış memo
          tablosunun (liste ve sözlük) karşılaştırılması:
          (1) özyineleme derinliği sınırı: varsayılan sys.getrecursionlimit()
              altında RecursionError vermeden hesaplanabilen en büyük n;
          (2) süre: soğuk önbellekle fib(450) (iki sınırın da altında) ve
              alt küme toplamı memo'su (1 ısınma + TEKRAR, ortanca);
          (3) bellek: tracemalloc tepe değeri ve önbellekteki girdi sayısı.
          lru_cache yalnız bu deneyde ve Dil Penceresi'nde kullanılır.
Kullanım: python3 H13_deney_lru.py [TEKRAR]      (varsayılan 5)
Çıktı   : stdout CSV (;): deney;yontem;n;ortanca_ms;en_az_ms;en_cok_ms;
          tepe_bayt;girdi;sinir_n  — süreler ve sınırlar Python sürümüne
          ve makineye bağlıdır ("bu çalıştırmada").
"""
import functools
import sys
import tracemalloc

from ortak_rastgele import rastgele_dizi, rastgele_tohum
from zamanlayici import ortanca, zaman_sn


# --- Fibonacci: dört memo biçimi -------------------------------------------
def fib_liste_kur(n):
    memo = [-1] * (n + 1)

    def fib(i):
        if memo[i] == -1:
            memo[i] = i if i < 2 else fib(i - 1) + fib(i - 2)
        return memo[i]
    return fib, lambda: sum(1 for v in memo if v != -1)


def fib_sozluk_kur(n):
    memo = {}

    def fib(i):
        if i not in memo:
            memo[i] = i if i < 2 else fib(i - 1) + fib(i - 2)
        return memo[i]
    return fib, lambda: len(memo)


def fib_lru_kur(n):
    @functools.lru_cache(maxsize=None)
    def fib(i):
        return i if i < 2 else fib(i - 1) + fib(i - 2)
    return fib, lambda: fib.cache_info().currsize


def fib_cache_kur(n):
    @functools.cache
    def fib(i):
        return i if i < 2 else fib(i - 1) + fib(i - 2)
    return fib, lambda: fib.cache_info().currsize


FIB = [("elle_liste", fib_liste_kur), ("elle_sozluk", fib_sozluk_kur),
       ("lru_cache", fib_lru_kur), ("cache", fib_cache_kur)]


def basarili_mi(kur, n):
    fib, _ = kur(n)                 # her denemede SOĞUK önbellek
    try:
        fib(n)
        return True
    except RecursionError:
        return False


def sinir_bul(kur):
    """RecursionError vermeyen en büyük n (ikili arama, 1..20000)"""
    lo, hi = 1, 20000               # lo başarılı, hi başarısız varsayımı
    if basarili_mi(kur, hi):
        return hi
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if basarili_mi(kur, mid):
            lo = mid
        else:
            hi = mid
    return lo


def olc(gorev, tekrar):
    gorev()                         # ısınma
    sureler = []
    for _ in range(tekrar):
        t0 = zaman_sn()
        gorev()
        sureler.append((zaman_sn() - t0) * 1000.0)
    en_az, en_cok = sureler[0], sureler[0]
    for s in sureler:
        en_az = s if s < en_az else en_az
        en_cok = s if s > en_cok else en_cok
    return ortanca(sureler), en_az, en_cok


def tepe_bellek(gorev):
    tracemalloc.start()
    sonuc = gorev()
    _, tepe = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return tepe, sonuc


# --- Alt küme toplamı: durum (i, toplam) ------------------------------------
def altkume_kur(yontem, a, hedef):
    n = len(a)
    if yontem == "elle_liste":
        memo = [-1] * ((n + 1) * (hedef + 1))

        def say(i, t):
            if t > hedef:
                return 0
            k = i * (hedef + 1) + t
            if memo[k] == -1:
                memo[k] = ((1 if t == hedef else 0) if i == n
                           else say(i + 1, t) + say(i + 1, t + a[i]))
            return memo[k]
        return say, lambda: sum(1 for v in memo if v != -1)
    if yontem == "elle_sozluk":
        memo = {}

        def say(i, t):
            if t > hedef:
                return 0
            if (i, t) not in memo:
                memo[(i, t)] = ((1 if t == hedef else 0) if i == n
                                else say(i + 1, t) + say(i + 1, t + a[i]))
            return memo[(i, t)]
        return say, lambda: len(memo)

    @functools.lru_cache(maxsize=None)
    def say(i, t):
        if t > hedef:
            return 0
        if i == n:
            return 1 if t == hedef else 0
        return say(i + 1, t) + say(i + 1, t + a[i])
    return say, lambda: say.cache_info().currsize


def main():
    tekrar = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    print("deney;yontem;n;ortanca_ms;en_az_ms;en_cok_ms;tepe_bayt;girdi;"
          "sinir_n")
    limit = sys.getrecursionlimit()
    for ad, kur in FIB:
        print(f"sinir;{ad};;;;;;;{sinir_bul(kur)}")
    print(f"recursionlimit;;{limit};;;;;;")
    n = 450                         # iki sınırın da altında
    for ad, kur in FIB:
        def gorev(kur=kur):
            fib, _ = kur(n)
            return fib(n)
        ort, en_az, en_cok = olc(gorev, tekrar)

        def bellek_gorevi(kur=kur):
            fib, girdi = kur(n)
            fib(n)
            return girdi()
        tepe, girdi = tepe_bellek(bellek_gorevi)
        print(f"fib;{ad};{n};{ort:.6f};{en_az:.6f};{en_cok:.6f};{tepe};"
              f"{girdi};")
    for n in (30, 40):
        rastgele_tohum(42)
        a = rastgele_dizi(n, 1, 40)
        toplam = 0
        for x in a:
            toplam += x
        hedef = toplam // 2
        for ad in ("elle_liste", "elle_sozluk", "lru_cache"):
            def gorev(ad=ad):
                say, _ = altkume_kur(ad, a, hedef)
                return say(0, 0)
            ort, en_az, en_cok = olc(gorev, tekrar)

            def bellek_gorevi(ad=ad):
                say, girdi = altkume_kur(ad, a, hedef)
                say(0, 0)
                return girdi()
            tepe, girdi = tepe_bellek(bellek_gorevi)
            print(f"altkume;{ad};{n};{ort:.6f};{en_az:.6f};{en_cok:.6f};"
                  f"{tepe};{girdi};")


if __name__ == "__main__":
    main()

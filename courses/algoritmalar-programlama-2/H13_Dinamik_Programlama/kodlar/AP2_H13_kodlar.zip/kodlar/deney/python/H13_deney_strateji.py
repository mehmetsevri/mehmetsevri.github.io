"""H13_deney_strateji.py — AP-2 Hafta 13 · Haftanın Deneyi (a)
Amaç    : Fibonacci ve alt küme toplamında kaba kuvvet / geri izleme /
          memoization / tablolama: deterministik sayaçlar (çağrı, hücre,
          en büyük özyineleme derinliği, C eşdeğeri tablo baytı) stdout'a;
          süreler (1 ısınma + tekrar, ortanca) stderr'e. "bellek" 5.
          argümanıyla bir kez daha tracemalloc altında çalışıp Python'un
          gerçek tepe bellek kullanımını stderr'e yazar (CPython'a özgü).
Kullanım: python3 H13_deney_strateji.py fib     N saf|memo|tablo|iki TEKRAR
          python3 H13_deney_strateji.py altkume N kaba|geri|memo|tablo \\
                  TEKRAR [bellek]
Çıktı   : stdout: problem;n;yontem;sonuc;cagri;hucre;derinlik;bayt
          stderr: sure;ortanca_ms;en_az_ms;en_cok_ms;islemci_ortanca_ms
                  bellek;tracemalloc_tepe_bayt   (yalnız "bellek" ile)
"""
import sys
import tracemalloc

from ortak_rastgele import rastgele_dizi, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

cagri = hucre = bayt = 0
derinlik = en_derin = 0


# --- Fibonacci --------------------------------------------------------------
def fib_saf(n):
    global cagri, derinlik, en_derin
    cagri += 1
    derinlik += 1
    if derinlik > en_derin:
        en_derin = derinlik
    f = n if n < 2 else fib_saf(n - 1) + fib_saf(n - 2)
    derinlik -= 1
    return f


memo1 = []


def fib_memo(i):
    global cagri, hucre, derinlik, en_derin
    cagri += 1
    derinlik += 1
    if derinlik > en_derin:
        en_derin = derinlik
    if memo1[i] == -1:
        memo1[i] = i if i < 2 else fib_memo(i - 1) + fib_memo(i - 2)
        hucre += 1
    derinlik -= 1
    return memo1[i]


def fib_calistir(n, yontem):
    global memo1, bayt, hucre
    if yontem == "saf":
        return fib_saf(n)
    if yontem == "memo":
        memo1 = [-1] * (n + 1)
        bayt += 8 * (n + 1)
        return fib_memo(n)
    if yontem == "tablo":
        t = [0] * (n + 2)
        bayt += 8 * (n + 2)
        t[0], t[1] = 0, 1
        hucre = 2
        for i in range(2, n + 1):
            t[i] = t[i - 1] + t[i - 2]
            hucre += 1
        return t[n]
    onceki, simdiki = 0, 1          # iki değişken
    for _ in range(2, n + 1):
        onceki, simdiki = simdiki, onceki + simdiki
    return 0 if n == 0 else simdiki


# --- Alt küme toplamı (çözüm SAYISI) ----------------------------------------
a = []
hedef = 0


def kaba(i, toplam):
    """H3: tam ağaç"""
    global cagri, derinlik, en_derin
    cagri += 1
    derinlik += 1
    if derinlik > en_derin:
        en_derin = derinlik
    if i == len(a):
        s = 1 if toplam == hedef else 0
    else:
        s = kaba(i + 1, toplam) + kaba(i + 1, toplam + a[i])
    derinlik -= 1
    return s


def geri(i, toplam):
    """H3: toplam aşıldı budaması"""
    global cagri, derinlik, en_derin
    cagri += 1
    derinlik += 1
    if derinlik > en_derin:
        en_derin = derinlik
    if toplam > hedef:
        s = 0
    elif i == len(a):
        s = 1 if toplam == hedef else 0
    else:
        s = geri(i + 1, toplam) + geri(i + 1, toplam + a[i])
    derinlik -= 1
    return s


memo2 = []                          # (n+1) x (hedef+1), düz liste


def memolu(i, toplam):
    global cagri, hucre, derinlik, en_derin
    cagri += 1
    derinlik += 1
    if derinlik > en_derin:
        en_derin = derinlik
    if toplam > hedef:
        s = 0
    else:
        k = i * (hedef + 1) + toplam
        if memo2[k] == -1:          # hesaplanmadı
            if i == len(a):
                memo2[k] = 1 if toplam == hedef else 0
            else:
                memo2[k] = memolu(i + 1, toplam) + memolu(i + 1,
                                                          toplam + a[i])
            hucre += 1
        s = memo2[k]
    derinlik -= 1
    return s


def altkume_calistir(yontem):
    global memo2, bayt, hucre
    if yontem == "kaba":
        return kaba(0, 0)
    if yontem == "geri":
        return geri(0, 0)
    n = len(a)
    boyut = (n + 1) * (hedef + 1)
    bayt += 8 * boyut
    if yontem == "memo":
        memo2 = [-1] * boyut
        return memolu(0, 0)
    T = hedef                       # tablo (Örnek 12)
    t = [0] * boyut
    t[0] = 1
    hucre = T + 1
    for i in range(1, n + 1):
        x = a[i - 1]
        for u in range(T + 1):
            v = t[(i - 1) * (T + 1) + u]
            if x <= u:
                v += t[(i - 1) * (T + 1) + u - x]
            t[i * (T + 1) + u] = v
            hucre += 1
    return t[n * (T + 1) + T]


def main():
    global a, hedef, cagri, hucre, bayt, derinlik, en_derin
    if len(sys.argv) not in (5, 6):
        print("kullanım: H13_deney_strateji.py fib|altkume N yöntem TEKRAR "
              "[bellek]", file=sys.stderr)
        sys.exit(2)
    problem, yontem = sys.argv[1], sys.argv[3]
    try:
        n = int(sys.argv[2])
        tekrar = int(sys.argv[4])
    except ValueError:
        print("geçersiz sayı", file=sys.stderr)
        sys.exit(2)
    if not 0 <= n <= 92 or not 1 <= tekrar <= 101:
        print("geçersiz N ya da TEKRAR", file=sys.stderr)
        sys.exit(2)
    if problem == "altkume":
        rastgele_tohum(42)
        a = rastgele_dizi(n, 1, 40)
        toplam = 0
        for x in a:
            toplam += x
        hedef = toplam // 2
    elif problem != "fib":
        print("geçersiz problem", file=sys.stderr)
        sys.exit(2)
    sonuc = [0]

    def calistir():
        global cagri, hucre, bayt, derinlik, en_derin
        cagri = hucre = bayt = 0
        derinlik = en_derin = 0
        sonuc[0] = (fib_calistir(n, yontem) if problem == "fib"
                    else altkume_calistir(yontem))

    duvar, islemci = [], []
    calistir()                      # ısınma
    for _ in range(tekrar):
        t0, c0 = zaman_sn(), islemci_sn()
        calistir()
        duvar.append((zaman_sn() - t0) * 1000.0)
        islemci.append((islemci_sn() - c0) * 1000.0)
    en_az, en_cok = duvar[0], duvar[0]
    for d in duvar:
        en_az = d if d < en_az else en_az
        en_cok = d if d > en_cok else en_cok
    print(f"{problem};{n};{yontem};{sonuc[0]};{cagri};{hucre};{en_derin};"
          f"{bayt}")
    print(f"sure;{ortanca(duvar):.6f};{en_az:.6f};{en_cok:.6f};"
          f"{ortanca(islemci):.6f}", file=sys.stderr)
    if len(sys.argv) == 6 and sys.argv[5] == "bellek":
        tracemalloc.start()
        calistir()
        _, tepe = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        print(f"bellek;{tepe}", file=sys.stderr)


if __name__ == "__main__":
    main()

"""H13_deney_doldurma.py — AP-2 Hafta 13 · Haftanın Deneyi (c, merak)
Amaç    : Büyük LCS tablosunun SATIR öncelikli (i dışta, j içte) ve SÜTUN
          öncelikli (j dışta, i içte) doldurulması. İki sıra da
          bağımlılıklara uyar ve aynı tabloyu verir. Python'da tablo,
          satırları ayrı listeler (Örnek 6); öğeler nesne başvurularıdır,
          bu yüzden önbellek etkisi yorumlayıcı maliyetinin altında kalır.
Kullanım: python3 H13_deney_doldurma.py N satir|sutun TEKRAR
Çıktı   : stdout: doldurma;n;sira;lcs;hucre;bayt  (bayt: C eşdeğeri, int32)
          stderr: sure;ortanca_ms;en_az_ms;en_cok_ms;islemci_ortanca_ms
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn


def doldur(x, y, L, sutun_mu):
    n = len(x)
    for k in range(n + 1):
        L[0][k] = 0                 # satır 0
        L[k][0] = 0                 # sütun 0
    if not sutun_mu:
        for i in range(1, n + 1):   # SATIR öncelikli
            for j in range(1, n + 1):
                if x[i - 1] == y[j - 1]:
                    L[i][j] = L[i - 1][j - 1] + 1
                else:
                    u, sol = L[i - 1][j], L[i][j - 1]
                    L[i][j] = u if u >= sol else sol
    else:
        for j in range(1, n + 1):   # SÜTUN öncelikli
            for i in range(1, n + 1):
                if x[i - 1] == y[j - 1]:
                    L[i][j] = L[i - 1][j - 1] + 1
                else:
                    u, sol = L[i - 1][j], L[i][j - 1]
                    L[i][j] = u if u >= sol else sol


def main():
    if len(sys.argv) != 4 or sys.argv[2] not in ("satir", "sutun"):
        print("kullanım: H13_deney_doldurma.py N satir|sutun TEKRAR",
              file=sys.stderr)
        sys.exit(2)
    try:
        n, tekrar = int(sys.argv[1]), int(sys.argv[3])
    except ValueError:
        sys.exit(2)
    if not 1 <= n <= 20000 or not 1 <= tekrar <= 101:
        sys.exit(2)
    harf = "ACGT"
    rastgele_tohum(7)
    x = "".join(harf[rastgele_aralik(0, 3)] for _ in range(n))
    y = "".join(harf[rastgele_aralik(0, 3)] for _ in range(n))
    L = [[0] * (n + 1) for _ in range(n + 1)]
    sutun_mu = sys.argv[2] == "sutun"
    duvar, islemci = [], []
    doldur(x, y, L, sutun_mu)       # ısınma
    for _ in range(tekrar):
        t0, c0 = zaman_sn(), islemci_sn()
        doldur(x, y, L, sutun_mu)
        duvar.append((zaman_sn() - t0) * 1000.0)
        islemci.append((islemci_sn() - c0) * 1000.0)
    en_az, en_cok = duvar[0], duvar[0]
    for d in duvar:
        en_az = d if d < en_az else en_az
        en_cok = d if d > en_cok else en_cok
    hucre = (n + 1) * (n + 1)
    print(f"doldurma;{n};{sys.argv[2]};{L[n][n]};{hucre};{4 * hucre}")
    print(f"sure;{ortanca(duvar):.6f};{en_az:.6f};{en_cok:.6f};"
          f"{ortanca(islemci):.6f}", file=sys.stderr)


if __name__ == "__main__":
    main()

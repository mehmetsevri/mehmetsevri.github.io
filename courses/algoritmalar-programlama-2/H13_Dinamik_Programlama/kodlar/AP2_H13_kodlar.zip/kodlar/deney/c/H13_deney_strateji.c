/* H13_deney_strateji.c — AP-2 Hafta 13 · Haftanın Deneyi (a)
 * Amaç    : Fibonacci ve alt küme toplamında kaba kuvvet / geri izleme /
 *           memoization / tablolama: deterministik sayaçlar (çağrı, hücre,
 *           en büyük özyineleme derinliği, ayrılan bayt) stdout'a; süreler
 *           (1 ısınma + tekrar, ortanca) stderr'e
 * Kullanım: ./H13_deney_strateji fib     N saf|memo|tablo|iki    TEKRAR
 *           ./H13_deney_strateji altkume N kaba|geri|memo|tablo  TEKRAR
 *           alt küme girdisi: ortak LCG tohum 42, 1..40, ilk N öğe;
 *           hedef = toplam / 2 (Örnek 12 ile aynı)
 * Çıktı   : stdout: problem;n;yontem;sonuc;cagri;hucre;derinlik;bayt
 *           stderr: sure;ortanca_ms;en_az_ms;en_cok_ms;islemci_ortanca_ms
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H13_deney_strateji.c \
 *           ortak_rastgele.c zamanlayici.c -o H13_deney_strateji
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define MAKS_N 64

static long long cagri, hucre, bayt;
static int derinlik, en_derin;

/* Sahiplik: ayir ile alınan blok çağıranındır (free); bayt sayacı artar */
static void *ayir(size_t boyut)
{
    bayt += (long long)boyut;
    return malloc(boyut);
}

/* --- Fibonacci ---------------------------------------------------------- */
static long long fib_saf(int n)
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long f = n < 2 ? n : fib_saf(n - 1) + fib_saf(n - 2);
    derinlik--;
    return f;
}

static long long *memo1;
static long long fib_memo(int i)
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (memo1[i] == -1) {
        memo1[i] = i < 2 ? i : fib_memo(i - 1) + fib_memo(i - 2);
        hucre++;
    }
    derinlik--;
    return memo1[i];
}

static long long fib_calistir(int n, const char *yontem)
{
    if (strcmp(yontem, "saf") == 0) {
        return fib_saf(n);
    }
    if (strcmp(yontem, "memo") == 0) {
        memo1 = ayir((size_t)(n + 1) * sizeof *memo1);
        if (memo1 == NULL) {
            return -1;
        }
        for (int i = 0; i <= n; i++) {
            memo1[i] = -1;
        }
        long long f = fib_memo(n);
        free(memo1);
        return f;
    }
    if (strcmp(yontem, "tablo") == 0) {
        long long *t = ayir((size_t)(n + 2) * sizeof *t);
        if (t == NULL) {
            return -1;
        }
        t[0] = 0;
        t[1] = 1;
        hucre = 2;
        for (int i = 2; i <= n; i++) {
            t[i] = t[i - 1] + t[i - 2];
            hucre++;
        }
        long long f = t[n];
        free(t);
        return f;
    }
    long long onceki = 0, simdiki = 1;             /* iki değişken */
    for (int i = 2; i <= n; i++) {
        long long s = onceki + simdiki;
        onceki = simdiki;
        simdiki = s;
    }
    return n == 0 ? 0 : simdiki;
}

/* --- Alt küme toplamı (çözüm SAYISI) ------------------------------------ */
static int a[MAKS_N];
static int n_ak;
static long long hedef;

static long long kaba(int i, long long toplam)     /* H3: tam ağaç */
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long s;
    if (i == n_ak) {
        s = toplam == hedef;
    } else {
        s = kaba(i + 1, toplam) + kaba(i + 1, toplam + a[i]);
    }
    derinlik--;
    return s;
}

static long long geri(int i, long long toplam)     /* H3: toplam aşıldı */
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long s;
    if (toplam > hedef) {
        s = 0;
    } else if (i == n_ak) {
        s = toplam == hedef;
    } else {
        s = geri(i + 1, toplam) + geri(i + 1, toplam + a[i]);
    }
    derinlik--;
    return s;
}

static long long *memo2;                           /* (n+1) x (hedef+1) */
static long long memolu(int i, long long toplam)
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long s;
    if (toplam > hedef) {
        s = 0;
    } else {
        long long *h = &memo2[(long long)i * (hedef + 1) + toplam];
        if (*h == -1) {                            /* hesaplanmadı */
            if (i == n_ak) {
                *h = toplam == hedef;
            } else {
                *h = memolu(i + 1, toplam) + memolu(i + 1, toplam + a[i]);
            }
            hucre++;
        }
        s = *h;
    }
    derinlik--;
    return s;
}

static long long altkume_calistir(const char *yontem)
{
    if (strcmp(yontem, "kaba") == 0) {
        return kaba(0, 0);
    }
    if (strcmp(yontem, "geri") == 0) {
        return geri(0, 0);
    }
    size_t boyut = (size_t)(n_ak + 1) * (size_t)(hedef + 1);
    long long *t = ayir(boyut * sizeof *t);
    if (t == NULL) {
        return -1;
    }
    long long s;
    if (strcmp(yontem, "memo") == 0) {
        for (size_t k = 0; k < boyut; k++) {
            t[k] = -1;
        }
        memo2 = t;
        s = memolu(0, 0);
    } else {                                       /* tablo (Örnek 12) */
        long long T = hedef;
        for (size_t k = 0; k < boyut; k++) {
            t[k] = 0;
        }
        t[0] = 1;
        hucre = T + 1;
        for (int i = 1; i <= n_ak; i++) {
            for (long long u = 0; u <= T; u++) {
                long long v = t[(i - 1) * (T + 1) + u];
                if (a[i - 1] <= u) {
                    v += t[(i - 1) * (T + 1) + u - a[i - 1]];
                }
                t[i * (T + 1) + u] = v;
                hucre++;
            }
        }
        s = t[n_ak * (T + 1) + T];
    }
    free(t);
    return s;
}

/* --- ölçüm ------------------------------------------------------------- */
static const char *problem, *yontem;
static int n_arg;
static long long sonuc;

static void sifirla(void)
{
    cagri = hucre = bayt = 0;
    derinlik = en_derin = 0;
}

static void calistir(void)
{
    sifirla();
    if (strcmp(problem, "fib") == 0) {
        sonuc = fib_calistir(n_arg, yontem);
    } else {
        sonuc = altkume_calistir(yontem);
    }
}

int main(int argc, char *argv[])
{
    if (argc != 5) {
        fprintf(stderr, "kullanım: %s fib|altkume N yöntem TEKRAR\n",
                argv[0]);
        return 2;
    }
    problem = argv[1];
    char *son;
    n_arg = (int)strtol(argv[2], &son, 10);
    if (*son != '\0' || n_arg < 0 || n_arg > 92) {
        fprintf(stderr, "geçersiz N\n");
        return 2;
    }
    yontem = argv[3];
    int tekrar = (int)strtol(argv[4], &son, 10);
    if (*son != '\0' || tekrar < 1 || tekrar > 101) {
        fprintf(stderr, "geçersiz TEKRAR\n");
        return 2;
    }
    if (strcmp(problem, "altkume") == 0) {
        if (n_arg > MAKS_N) {
            return 2;
        }
        n_ak = n_arg;
        rastgele_tohum(42);
        rastgele_dizi(a, (size_t)n_ak, 1, 40);
        long long toplam = 0;
        for (int i = 0; i < n_ak; i++) {
            toplam += a[i];
        }
        hedef = toplam / 2;
    } else if (strcmp(problem, "fib") != 0) {
        fprintf(stderr, "geçersiz problem\n");
        return 2;
    }
    double duvar[101], islemci[101];
    calistir();                                    /* ısınma */
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn(), c0 = islemci_sn();
        calistir();
        duvar[k] = (zaman_sn() - t0) * 1000.0;
        islemci[k] = (islemci_sn() - c0) * 1000.0;
    }
    double en_az = duvar[0], en_cok = duvar[0];
    for (int k = 1; k < tekrar; k++) {
        en_az = duvar[k] < en_az ? duvar[k] : en_az;
        en_cok = duvar[k] > en_cok ? duvar[k] : en_cok;
    }
    printf("%s;%d;%s;%lld;%lld;%lld;%d;%lld\n", problem, n_arg, yontem,
           sonuc, cagri, hucre, en_derin, bayt);
    fprintf(stderr, "sure;%.6f;%.6f;%.6f;%.6f\n", ortanca(duvar, tekrar),
            en_az, en_cok, ortanca(islemci, tekrar));
    return 0;
}

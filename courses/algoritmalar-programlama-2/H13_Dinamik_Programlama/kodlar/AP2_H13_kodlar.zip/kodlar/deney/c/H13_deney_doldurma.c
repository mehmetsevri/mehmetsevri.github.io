/* H13_deney_doldurma.c — AP-2 Hafta 13 · Haftanın Deneyi (c, merak)
 * Amaç    : Büyük LCS tablosunun SATIR öncelikli (i dışta, j içte) ve
 *           SÜTUN öncelikli (j dışta, i içte) doldurulması. İki sıra da
 *           bağımlılıklara uyar (L[i−1][j], L[i][j−1], L[i−1][j−1] önce
 *           hesaplanır) ve aynı tabloyu verir; tablo bellekte satır
 *           öncelikli (tek blok, L[i * (n+1) + j]) olduğundan sütun
 *           öncelikli dolaşma her adımda (n+1) * 4 bayt atlar (AP-1 H11).
 * Kullanım: ./H13_deney_doldurma N satir|sutun TEKRAR
 *           dizgiler: ortak LCG tohum 7, ACGT, uzunluk N (Örnek 8 gibi)
 * Çıktı   : stdout: doldurma;n;sira;lcs;hucre;bayt
 *           stderr: sure;ortanca_ms;en_az_ms;en_cok_ms;islemci_ortanca_ms
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H13_deney_doldurma.c \
 *           ortak_rastgele.c zamanlayici.c -o H13_deney_doldurma
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

static char *x, *y;
static int *L;                     /* (n+1) x (n+1), satır öncelikli */
static int n, sutun_mu;

static void doldur(void)
{
    const int s = n + 1;
    for (int k = 0; k < s; k++) {
        L[k] = 0;                                  /* satır 0 */
        L[k * s] = 0;                              /* sütun 0 */
    }
    if (!sutun_mu) {
        for (int i = 1; i <= n; i++) {             /* SATIR öncelikli */
            for (int j = 1; j <= n; j++) {
                int v;
                if (x[i - 1] == y[j - 1]) {
                    v = L[(i - 1) * s + j - 1] + 1;
                } else {
                    int u = L[(i - 1) * s + j], l = L[i * s + j - 1];
                    v = u >= l ? u : l;
                }
                L[i * s + j] = v;
            }
        }
    } else {
        for (int j = 1; j <= n; j++) {             /* SÜTUN öncelikli */
            for (int i = 1; i <= n; i++) {
                int v;
                if (x[i - 1] == y[j - 1]) {
                    v = L[(i - 1) * s + j - 1] + 1;
                } else {
                    int u = L[(i - 1) * s + j], l = L[i * s + j - 1];
                    v = u >= l ? u : l;
                }
                L[i * s + j] = v;
            }
        }
    }
}

int main(int argc, char *argv[])
{
    if (argc != 4 || (strcmp(argv[2], "satir") != 0 &&
                      strcmp(argv[2], "sutun") != 0)) {
        fprintf(stderr, "kullanım: %s N satir|sutun TEKRAR\n", argv[0]);
        return 2;
    }
    char *son;
    n = (int)strtol(argv[1], &son, 10);
    int tekrar = (int)strtol(argv[3], &son, 10);
    if (n < 1 || n > 20000 || tekrar < 1 || tekrar > 101) {
        fprintf(stderr, "geçersiz N ya da TEKRAR\n");
        return 2;
    }
    sutun_mu = strcmp(argv[2], "sutun") == 0;
    const char harf[] = "ACGT";
    x = malloc((size_t)n);
    y = malloc((size_t)n);
    size_t hucre = (size_t)(n + 1) * (size_t)(n + 1);
    L = malloc(hucre * sizeof *L);                 /* sahiplik: main */
    if (x == NULL || y == NULL || L == NULL) {
        fprintf(stderr, "bellek ayrılamadı\n");
        free(x);
        free(y);
        free(L);
        return 1;
    }
    rastgele_tohum(7);
    for (int i = 0; i < n; i++) {
        x[i] = harf[rastgele_aralik(0, 3)];
    }
    for (int i = 0; i < n; i++) {
        y[i] = harf[rastgele_aralik(0, 3)];
    }
    double duvar[101], islemci[101];
    doldur();                                      /* ısınma */
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn(), c0 = islemci_sn();
        doldur();
        duvar[k] = (zaman_sn() - t0) * 1000.0;
        islemci[k] = (islemci_sn() - c0) * 1000.0;
    }
    double en_az = duvar[0], en_cok = duvar[0];
    for (int k = 1; k < tekrar; k++) {
        en_az = duvar[k] < en_az ? duvar[k] : en_az;
        en_cok = duvar[k] > en_cok ? duvar[k] : en_cok;
    }
    printf("doldurma;%d;%s;%d;%zu;%zu\n", n, argv[2],
           L[(size_t)n * (size_t)(n + 1) + (size_t)n], hucre,
           hucre * sizeof *L);
    fprintf(stderr, "sure;%.6f;%.6f;%.6f;%.6f\n", ortanca(duvar, tekrar),
            en_az, en_cok, ortanca(islemci, tekrar));
    free(x);
    free(y);
    free(L);
    return 0;
}

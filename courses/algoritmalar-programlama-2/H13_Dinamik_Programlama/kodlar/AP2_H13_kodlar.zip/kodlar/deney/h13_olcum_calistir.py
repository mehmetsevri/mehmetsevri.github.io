#!/usr/bin/env python3
"""h13_olcum_calistir.py — AP-2 Hafta 13 · Haftanın Deneyi sürücüsü

Derler, çalıştırır ve ham sonuçları sonuclar/*.csv dosyalarına yazar:
  (a) h13_deney_strateji.csv  Fibonacci (saf / memo / tablo / iki
      değişken) ve alt küme toplamı (kaba kuvvet / geri izleme / memo /
      tablo): çağrı, hücre, derinlik, bayt (deterministik; üç dilde aynı
      olmalı) + süre; Python'da ayrıca tracemalloc tepe belleği.
      Üstel yöntemler SÜRE BÜTÇESİYLE ölçülür: bir sonraki n için öngörülen
      tek çalıştırma süresi bütçeyi aşarsa ölçülmez, KESTİRİLİR
      (olcum = "kestirim"; yöntem CSV'de "kestirim_yontemi" sütununda).
  (b) h13_deney_lru.csv       Python: lru_cache / cache / elle memo
      (özyineleme sınırı, süre, tracemalloc)
  (c) h13_deney_doldurma.csv  büyük LCS tablosu satır / sütun öncelikli
      doldurma (C -O2 ve -O0, C++ -O2, Python)
Ölçüm: 1 ısınma + 5 tekrar, ortanca (programların içinde); duvar saati ve
işlemci zamanı birlikte. Ortam: OLCUM_ORTAMI.txt; denetimler:
sonuclar/h13_denetim.json.
Kullanım: python3 h13_olcum_calistir.py      (≈ 3–4 dk)
Sonra   : python3 h13_cozumle.py ; python3 ../../gorseller/kaynak/
          h13_deney_grafik.py
"""
import csv
import datetime
import json
import os
import platform
import re
import resource
import shutil
import subprocess
import sys
import tempfile
import time

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]
TEKRAR = 5
BUTCE_MS = {"c": 500.0, "cpp": 500.0, "py": 700.0}   # tek çalıştırma

FIB_N = [10, 15, 20, 25, 30, 35, 40]
FIB_N_POLI = [50, 70, 90]          # yalnız memo / tablo / iki değişken
AK_N = list(range(10, 41, 2))
DOLDURMA_N = {"c": [500, 1000, 2000, 3000, 4000, 6000],
              "cpp": [500, 1000, 2000, 3000, 4000, 6000],
              "py": [250, 500, 1000, 1500]}


def kabuk(komut, **kw):
    return subprocess.run(komut, capture_output=True, text=True, check=True,
                          **kw)


def derle(gecici):
    ikili = {}
    for ad in ("H13_deney_strateji", "H13_deney_doldurma"):
        for bayrak in ("-O2", "-O0"):
            hedef = os.path.join(gecici, f"{ad}_c{bayrak}")
            p = kabuk(C + [bayrak, os.path.join(KOK, "c", ad + ".c"),
                           os.path.join(KOK, "c", "ortak_rastgele.c"),
                           os.path.join(KOK, "c", "zamanlayici.c"),
                           "-o", hedef])
            assert not p.stderr.strip(), p.stderr
            ikili[(ad, "c", bayrak)] = [hedef]
        hedef = os.path.join(gecici, f"{ad}_cpp")
        p = kabuk(CPP + ["-O2", "-I" + os.path.join(KOK, "cpp"),
                         os.path.join(KOK, "cpp", ad + ".cpp"), "-o", hedef])
        assert not p.stderr.strip(), p.stderr
        ikili[(ad, "cpp", "-O2")] = [hedef]
        ikili[(ad, "py", "-")] = [sys.executable,
                                  os.path.join(KOK, "python", ad + ".py")]
    return ikili


def calistir(komut):
    """stdout (deterministik) satırı ve stderr'deki süre/bellek alanları"""
    p = subprocess.run(komut, capture_output=True, text=True,
                       env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    if p.returncode != 0:
        raise RuntimeError(f"{komut}: {p.stderr}")
    sure = re.search(r"sure;([\d.]+);([\d.]+);([\d.]+);([\d.]+)", p.stderr)
    bellek = re.search(r"bellek;(\d+)", p.stderr)
    return (p.stdout.strip().split(";"), [float(x) for x in sure.groups()],
            int(bellek.group(1)) if bellek else "")


def fib_sayisi(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def ongorulen_dugum(yontem, problem, n, olculen):
    """Ölçülmemiş n için çağrı sayısı: kesin formül ya da geometrik
    büyüme kestirimi. olculen: [(n, cagri)] artan"""
    if problem == "fib" and yontem == "saf":
        return 2 * fib_sayisi(n + 1) - 1, "formül 2·F(n+1) − 1"
    if problem == "altkume" and yontem == "kaba":
        return 2 ** (n + 1) - 1, "formül 2^(n+1) − 1"
    (n1, c1), (n2, c2) = olculen[-2], olculen[-1]
    oran = (c2 / c1) ** (1.0 / (n2 - n1))
    return int(round(c2 * oran ** (n - n2))), (
        f"geometrik: son iki ölçümün oranı (n başına ×{oran:.3f})")


def strateji(ikili, yazici, denetim):
    satirlar = []
    for problem, nler, yontemler in (
            ("fib", FIB_N + FIB_N_POLI, ["saf", "memo", "tablo", "iki"]),
            ("altkume", AK_N, ["kaba", "geri", "memo", "tablo"])):
        for dil, derleme in (("c", "-O2"), ("cpp", "-O2"), ("py", "-")):
            for yontem in yontemler:
                ustel = yontem in ("saf", "kaba", "geri")
                olculen = []           # (n, cagri, ms/çağrı)
                durdu = False
                for n in nler:
                    if problem == "fib" and ustel and n not in FIB_N:
                        continue
                    if ustel and len(olculen) >= 2 and not durdu:
                        tahmin, _ = ongorulen_dugum(
                            yontem, problem, n,
                            [(a, b) for a, b, _ in olculen])
                        if tahmin * olculen[-1][2] > BUTCE_MS[dil]:
                            durdu = True
                    if durdu:
                        tahmin, nasil = ongorulen_dugum(
                            yontem, problem, n,
                            [(a, b) for a, b, _ in olculen])
                        ms = tahmin * olculen[-1][2]
                        satir = [problem, n, yontem, dil, derleme,
                                 "kestirim", "", tahmin, "", "", "",
                                 f"{ms:.3f}", "", "", "", "", nasil, ""]
                        satirlar.append((satir, None))
                        continue
                    komut = ikili[("H13_deney_strateji", dil, derleme)] + \
                        [problem, str(n), yontem, str(TEKRAR)]
                    if dil == "py":
                        komut.append("bellek")
                    alan, sure, tepe = calistir(komut)
                    anahtar = ";".join(alan)
                    denetim.setdefault(anahtar.split(";", 3)[0] + ";" +
                                       ";".join(alan[1:3]), set()).add(
                        anahtar)
                    cagri = int(alan[4])
                    if ustel:
                        olculen.append((n, cagri, sure[0] / max(cagri, 1)))
                    satir = [problem, n, yontem, dil, derleme, "olcum",
                             alan[3], alan[4], alan[5], alan[6], alan[7],
                             f"{sure[0]:.6f}", f"{sure[1]:.6f}",
                             f"{sure[2]:.6f}", f"{sure[3]:.6f}", tepe, "",
                             ""]
                    satirlar.append((satir, komut))
                print(f"  (a) {problem} {dil} {yontem}: "
                      f"{len(olculen) if ustel else len(nler)} ölçüm",
                      flush=True)
    sivri_duzelt(satirlar, 11, (0, 2, 3, 4))
    for satir, _ in satirlar:
        yazici.writerow(satir)
    return satirlar


def sivri_duzelt(satirlar, sutun, seri_anahtari):
    """Tutarsız ölçümü tekrarla (rehber 3): aynı serideki ölçülmüş bir
    noktanın süresi iki komşusunun büyüğünün 1,5 katını aşıyorsa (sivri)
    ya da öncekinden küçükse (n artarken süre düşmüş) nokta bir kez daha
    ölçülür; yeni değer yazılır, ilk değer "not" sütununda kalır."""
    seriler = {}
    for i, (satir, komut) in enumerate(satirlar):
        if komut is not None:
            seriler.setdefault(tuple(satir[k] for k in seri_anahtari),
                               []).append(i)
    for indisler in seriler.values():
        for k, i in enumerate(indisler):
            t = float(satirlar[i][0][sutun])
            onceki = float(satirlar[indisler[k - 1]][0][sutun]) if k else None
            sonraki = (float(satirlar[indisler[k + 1]][0][sutun])
                       if k + 1 < len(indisler) else None)
            komsu = [x for x in (onceki, sonraki) if x is not None]
            sivri = komsu and t > 1.5 * max(komsu)
            dusus = onceki is not None and t < onceki and t > 0.05
            if not (sivri or dusus):
                continue
            satir, komut = satirlar[i]
            _, sure, _ = calistir(komut)
            satir[-1] = (f"yeniden ölçüldü (ilk ortanca {t:.6f} ms; "
                         + ("sivri" if sivri else "düşüş") + ")")
            satir[sutun:sutun + 4] = [f"{x:.6f}" for x in sure]


def doldurma(ikili, yazici, denetim):
    satirlar = []
    for dil, derleme in (("c", "-O2"), ("c", "-O0"), ("cpp", "-O2"),
                         ("py", "-")):
        for n in DOLDURMA_N[dil]:
            for sira in ("satir", "sutun"):
                komut = ikili[("H13_deney_doldurma", dil, derleme)] + \
                    [str(n), sira, str(TEKRAR)]
                alan, sure, _ = calistir(komut)
                denetim.setdefault(f"doldurma;{n}", set()).add(
                    ";".join([alan[1], alan[3], alan[4], alan[5]]))
                satirlar.append(([n, sira, dil, derleme, alan[3], alan[4],
                                  alan[5], f"{sure[0]:.6f}",
                                  f"{sure[1]:.6f}", f"{sure[2]:.6f}",
                                  f"{sure[3]:.6f}", ""], komut))
        print(f"  (c) doldurma {dil} {derleme} tamam", flush=True)
    sivri_duzelt(satirlar, 7, (1, 2, 3))
    for satir, _ in satirlar:
        yazici.writerow(satir)


def ortam_metni(bas, son, yuk_once, yuk_sonra, sure, evreler):
    lscpu = kabuk(["lscpu"]).stdout
    model = re.search(r"Model name:\s*(.+)", lscpu)
    return "\n".join([
        "AP-2 Hafta 13 · Haftanın Deneyi — ölçüm ortamı",
        f"Tarih          : {bas:%Y-%m-%d %H:%M} – {son:%H:%M}",
        f"İşlemci        : {model.group(1).strip() if model else '?'}",
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine)",
        f"Yük ortalaması : önce {yuk_once} · sonra {yuk_sonra} "
        "(/proc/loadavg: 1, 5, 15 dk)",
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})",
        "C derleyicisi  : " + kabuk(["gcc", "--version"]).stdout
        .splitlines()[0],
        "C++ derleyicisi: " + kabuk(["g++", "--version"]).stdout
        .splitlines()[0],
        f"Python         : Python {platform.python_version()}",
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra -pedantic "
        "-O2 (doldurma deneyinde C ayrıca -O0)",
        f"Yöntem         : 1 ısınma + {TEKRAR} tekrar, ortanca; duvar saati "
        "ve işlemci zamanı birlikte kaydedildi",
        "Saat           : duvar C timespec_get, C++ steady_clock, Python "
        "time.perf_counter; işlemci C/C++ clock(), Python time.process_time",
        "Bütçe          : üstel yöntemlerde öngörülen tek çalıştırma süresi "
        f"C/C++ {BUTCE_MS['c']:.0f} ms, Python {BUTCE_MS['py']:.0f} ms'yi "
        "aşarsa ölçülmez, kestirilir",
        "Bellek         : C ayrılan bayt sayacı (malloc sarmalayıcısı), C++ "
        "vektörlere istenen bayt, Python tracemalloc tepe değeri; en büyük "
        "alt süreç tepe yerleşik belleği "
        f"{resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024:.0f}"
        " MB (getrusage RUSAGE_CHILDREN, ru_maxrss)",
        f"Toplam süre    : {sure:.1f} s (sürücünün duvar saati)",
        "Evre süreleri  : " + " · ".join(f"{a} {b:.1f} s" for a, b in evreler),
        "Not            : ölçüm sırasında makinede başka ajanlar da "
        "çalışıyordu (yük ortalamasına bakınız);",
        "                 süreler bu makineye ve bu ana özgüdür; sayaçlar "
        "(çağrı, hücre) makineden bağımsızdır.",
        ""])


def main():
    os.makedirs(SONUC, exist_ok=True)
    bas = datetime.datetime.now()
    t_bas = time.time()
    yuk_once = open("/proc/loadavg").read().split()[:3]
    gecici = tempfile.mkdtemp(prefix="h13_deney_")
    evreler = []
    denetim = {}
    try:
        t0 = time.time()
        ikili = derle(gecici)
        evreler.append(("derleme", time.time() - t0))

        t0 = time.time()
        with open(os.path.join(SONUC, "h13_deney_strateji.csv"), "w",
                  newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["problem", "n", "yontem", "dil", "derleme", "olcum",
                        "sonuc", "cagri", "hucre", "derinlik", "bayt",
                        "ortanca_ms", "en_az_ms", "en_cok_ms",
                        "islemci_ortanca_ms", "tracemalloc_tepe_bayt",
                        "kestirim_yontemi", "not"])
            strateji(ikili, w, denetim)
        evreler.append(("(a) strateji", time.time() - t0))

        t0 = time.time()
        p = subprocess.run([sys.executable,
                            os.path.join(KOK, "python", "H13_deney_lru.py"),
                            str(TEKRAR)], capture_output=True, text=True,
                           check=True,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        with open(os.path.join(SONUC, "h13_deney_lru.csv"), "w",
                  encoding="utf-8") as f:
            f.write(p.stdout)
        evreler.append(("(b) lru_cache", time.time() - t0))
        print("  (b) lru_cache tamam", flush=True)

        t0 = time.time()
        with open(os.path.join(SONUC, "h13_deney_doldurma.csv"), "w",
                  newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["n", "sira", "dil", "derleme", "lcs", "hucre",
                        "bayt", "ortanca_ms", "en_az_ms", "en_cok_ms",
                        "islemci_ortanca_ms", "not"])
            doldurma(ikili, w, denetim)
        evreler.append(("(c) doldurma", time.time() - t0))
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    yuk_sonra = open("/proc/loadavg").read().split()[:3]
    son = datetime.datetime.now()
    sure = time.time() - t_bas
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(ortam_metni(bas, son, " ".join(yuk_once),
                            " ".join(yuk_sonra), sure, evreler))
    sonuc = {k: len(v) == 1 for k, v in sorted(denetim.items())}
    with open(os.path.join(SONUC, "h13_denetim.json"), "w",
              encoding="utf-8") as f:
        json.dump({"aciklama": "aynı (problem, n, yöntem) için C/C++/Python "
                   "deterministik alanları aynı mı (doldurmada C -O0/-O2, "
                   "C++, Python aynı LCS ve hücre)",
                   "hepsi_ayni": all(sonuc.values()), "ayrinti": sonuc}, f,
                  ensure_ascii=False, indent=1)
    print(f"toplam {sure:.1f} s; denetim hepsi aynı: {all(sonuc.values())}")


if __name__ == "__main__":
    main()

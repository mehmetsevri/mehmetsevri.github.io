/* H13_deney_doldurma.cpp — AP-2 Hafta 13 · Haftanın Deneyi (c, merak)
 * Amaç    : Büyük LCS tablosunun SATIR öncelikli (i dışta, j içte) ve
 *           SÜTUN öncelikli (j dışta, i içte) doldurulması. İki sıra da
 *           bağımlılıklara uyar ve aynı tabloyu verir; tablo tek bir
 *           std::vector<int> (satır öncelikli, L[i * (n+1) + j]) olduğundan
 *           sütun öncelikli dolaşma her adımda (n+1) * 4 bayt atlar.
 * Kullanım: ./H13_deney_doldurma N satir|sutun TEKRAR
 * Çıktı   : stdout: doldurma;n;sira;lcs;hucre;bayt
 *           stderr: sure;ortanca_ms;en_az_ms;en_cok_ms;islemci_ortanca_ms
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_deney_doldurma.cpp -o H13_deney_doldurma
 */
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static void doldur(const std::string& x, const std::string& y,
                   std::vector<int>& L, bool sutun_mu)
{
    const int n = static_cast<int>(x.size()), s = n + 1;
    for (int k = 0; k < s; k++) {
        L[k] = 0;                                 // satır 0
        L[k * s] = 0;                             // sütun 0
    }
    auto hucre = [&](int i, int j) {
        int v;
        if (x[i - 1] == y[j - 1]) {
            v = L[(i - 1) * s + j - 1] + 1;
        } else {
            int u = L[(i - 1) * s + j], l = L[i * s + j - 1];
            v = u >= l ? u : l;
        }
        L[i * s + j] = v;
    };
    if (!sutun_mu) {
        for (int i = 1; i <= n; i++) {            // SATIR öncelikli
            for (int j = 1; j <= n; j++) {
                hucre(i, j);
            }
        }
    } else {
        for (int j = 1; j <= n; j++) {            // SÜTUN öncelikli
            for (int i = 1; i <= n; i++) {
                hucre(i, j);
            }
        }
    }
}

int main(int argc, char* argv[])
{
    if (argc != 4) {
        std::fprintf(stderr, "kullanım: %s N satir|sutun TEKRAR\n",
                     argv[0]);
        return 2;
    }
    const std::string sira = argv[2];
    char* son;
    int n = static_cast<int>(std::strtol(argv[1], &son, 10));
    int tekrar = static_cast<int>(std::strtol(argv[3], &son, 10));
    if ((sira != "satir" && sira != "sutun") || n < 1 || n > 20000 ||
        tekrar < 1 || tekrar > 101) {
        std::fprintf(stderr, "geçersiz argüman\n");
        return 2;
    }
    const std::string harf = "ACGT";
    std::string x, y;
    rastgele_tohum(7);
    for (int i = 0; i < n; i++) {
        x += harf[rastgele_aralik(0, 3)];
    }
    for (int i = 0; i < n; i++) {
        y += harf[rastgele_aralik(0, 3)];
    }
    const std::size_t hucre = static_cast<std::size_t>(n + 1) * (n + 1);
    std::vector<int> L(hucre);
    const bool sutun_mu = sira == "sutun";
    std::vector<double> duvar, islemci;
    doldur(x, y, L, sutun_mu);                    // ısınma
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn(), c0 = islemci_sn();
        doldur(x, y, L, sutun_mu);
        duvar.push_back((zaman_sn() - t0) * 1000.0);
        islemci.push_back((islemci_sn() - c0) * 1000.0);
    }
    double en_az = duvar[0], en_cok = duvar[0];
    for (double d : duvar) {
        en_az = d < en_az ? d : en_az;
        en_cok = d > en_cok ? d : en_cok;
    }
    std::printf("doldurma;%d;%s;%d;%zu;%zu\n", n, sira.c_str(),
                L[static_cast<std::size_t>(n) * (n + 1) + n], hucre,
                hucre * sizeof(int));
    std::fprintf(stderr, "sure;%.6f;%.6f;%.6f;%.6f\n", ortanca(duvar), en_az,
                 en_cok, ortanca(islemci));
    return 0;
}

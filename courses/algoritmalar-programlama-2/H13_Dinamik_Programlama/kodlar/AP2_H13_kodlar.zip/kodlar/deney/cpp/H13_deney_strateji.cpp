/* H13_deney_strateji.cpp — AP-2 Hafta 13 · Haftanın Deneyi (a)
 * Amaç    : Fibonacci ve alt küme toplamında kaba kuvvet / geri izleme /
 *           memoization / tablolama: deterministik sayaçlar (çağrı, hücre,
 *           en büyük özyineleme derinliği, tablo verisi baytı) stdout'a;
 *           süreler (1 ısınma + tekrar, ortanca) stderr'e
 * Kullanım: ./H13_deney_strateji fib     N saf|memo|tablo|iki    TEKRAR
 *           ./H13_deney_strateji altkume N kaba|geri|memo|tablo  TEKRAR
 * Çıktı   : stdout: problem;n;yontem;sonuc;cagri;hucre;derinlik;bayt
 *           stderr: sure;ortanca_ms;en_az_ms;en_cok_ms;islemci_ortanca_ms
 *           (bayt = vektörlere istenen veri baytı, C'deki malloc ile aynı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_deney_strateji.cpp -o H13_deney_strateji
 */
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static long long cagri, hucre, bayt;
static int derinlik, en_derin;

// --- Fibonacci ------------------------------------------------------------
static long long fib_saf(int n)
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long f = n < 2 ? n : fib_saf(n - 1) + fib_saf(n - 2);
    derinlik--;
    return f;
}

static std::vector<long long> memo1;
static long long fib_memo(int i)
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (memo1[i] == -1) {
        memo1[i] = i < 2 ? i : fib_memo(i - 1) + fib_memo(i - 2);
        hucre++;
    }
    derinlik--;
    return memo1[i];
}

static long long fib_calistir(int n, const std::string& yontem)
{
    if (yontem == "saf") {
        return fib_saf(n);
    }
    if (yontem == "memo") {
        memo1.assign(n + 1, -1);
        bayt += static_cast<long long>(sizeof(long long)) * (n + 1);
        return fib_memo(n);
    }
    if (yontem == "tablo") {
        std::vector<long long> t(n + 2);
        bayt += static_cast<long long>(sizeof(long long)) * (n + 2);
        t[0] = 0;
        t[1] = 1;
        hucre = 2;
        for (int i = 2; i <= n; i++) {
            t[i] = t[i - 1] + t[i - 2];
            hucre++;
        }
        return t[n];
    }
    long long onceki = 0, simdiki = 1;            // iki değişken
    for (int i = 2; i <= n; i++) {
        long long s = onceki + simdiki;
        onceki = simdiki;
        simdiki = s;
    }
    return n == 0 ? 0 : simdiki;
}

// --- Alt küme toplamı (çözüm SAYISI) --------------------------------------
static std::vector<int> a;
static long long hedef;

static long long kaba(std::size_t i, long long toplam)    // H3: tam ağaç
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long s;
    if (i == a.size()) {
        s = toplam == hedef;
    } else {
        s = kaba(i + 1, toplam) + kaba(i + 1, toplam + a[i]);
    }
    derinlik--;
    return s;
}

static long long geri(std::size_t i, long long toplam)    // H3: aşıldı
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long s;
    if (toplam > hedef) {
        s = 0;
    } else if (i == a.size()) {
        s = toplam == hedef;
    } else {
        s = geri(i + 1, toplam) + geri(i + 1, toplam + a[i]);
    }
    derinlik--;
    return s;
}

static std::vector<long long> memo2;              // (n+1) x (hedef+1)
static long long memolu(std::size_t i, long long toplam)
{
    cagri++;
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    long long s;
    if (toplam > hedef) {
        s = 0;
    } else {
        long long& h = memo2[i * (hedef + 1) + toplam];
        if (h == -1) {                            // hesaplanmadı
            if (i == a.size()) {
                h = toplam == hedef;
            } else {
                h = memolu(i + 1, toplam) + memolu(i + 1, toplam + a[i]);
            }
            hucre++;
        }
        s = h;
    }
    derinlik--;
    return s;
}

static long long altkume_calistir(const std::string& yontem)
{
    if (yontem == "kaba") {
        return kaba(0, 0);
    }
    if (yontem == "geri") {
        return geri(0, 0);
    }
    const std::size_t n = a.size();
    const std::size_t boyut = (n + 1) * static_cast<std::size_t>(hedef + 1);
    bayt += static_cast<long long>(sizeof(long long) * boyut);
    if (yontem == "memo") {
        memo2.assign(boyut, -1);
        return memolu(0, 0);
    }
    const long long T = hedef;                    // tablo (Örnek 12)
    std::vector<long long> t(boyut, 0);
    t[0] = 1;
    hucre = T + 1;
    for (std::size_t i = 1; i <= n; i++) {
        for (long long u = 0; u <= T; u++) {
            long long v = t[(i - 1) * (T + 1) + u];
            if (a[i - 1] <= u) {
                v += t[(i - 1) * (T + 1) + u - a[i - 1]];
            }
            t[i * (T + 1) + u] = v;
            hucre++;
        }
    }
    return t[n * (T + 1) + T];
}

// --- ölçüm -----------------------------------------------------------------
int main(int argc, char* argv[])
{
    if (argc != 5) {
        std::fprintf(stderr, "kullanım: %s fib|altkume N yöntem TEKRAR\n",
                     argv[0]);
        return 2;
    }
    const std::string problem = argv[1], yontem = argv[3];
    char* son;
    int n = static_cast<int>(std::strtol(argv[2], &son, 10));
    if (*son != '\0' || n < 0 || n > 92) {
        std::fprintf(stderr, "geçersiz N\n");
        return 2;
    }
    int tekrar = static_cast<int>(std::strtol(argv[4], &son, 10));
    if (*son != '\0' || tekrar < 1 || tekrar > 101) {
        std::fprintf(stderr, "geçersiz TEKRAR\n");
        return 2;
    }
    if (problem == "altkume") {
        rastgele_tohum(42);
        a = rastgele_dizi(n, 1, 40);
        long long toplam = 0;
        for (int x : a) {
            toplam += x;
        }
        hedef = toplam / 2;
    } else if (problem != "fib") {
        std::fprintf(stderr, "geçersiz problem\n");
        return 2;
    }
    long long sonuc = 0;
    auto calistir = [&] {
        cagri = hucre = bayt = 0;
        derinlik = en_derin = 0;
        sonuc = problem == "fib" ? fib_calistir(n, yontem)
                                 : altkume_calistir(yontem);
    };
    std::vector<double> duvar, islemci;
    calistir();                                   // ısınma
    for (int k = 0; k < tekrar; k++) {
        double t0 = zaman_sn(), c0 = islemci_sn();
        calistir();
        duvar.push_back((zaman_sn() - t0) * 1000.0);
        islemci.push_back((islemci_sn() - c0) * 1000.0);
    }
    double en_az = duvar[0], en_cok = duvar[0];
    for (double d : duvar) {
        en_az = d < en_az ? d : en_az;
        en_cok = d > en_cok ? d : en_cok;
    }
    std::printf("%s;%d;%s;%lld;%lld;%lld;%d;%lld\n", problem.c_str(), n,
                yontem.c_str(), sonuc, cagri, hucre, en_derin, bayt);
    std::fprintf(stderr, "sure;%.6f;%.6f;%.6f;%.6f\n", ortanca(duvar), en_az,
                 en_cok, ortanca(islemci));
    return 0;
}

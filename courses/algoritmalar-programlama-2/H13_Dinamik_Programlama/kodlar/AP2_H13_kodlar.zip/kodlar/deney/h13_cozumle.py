#!/usr/bin/env python3
"""h13_cozumle.py — AP-2 Hafta 13 · Haftanın Deneyi çözümlemesi

Girdi : sonuclar/h13_deney_{strateji,lru,doldurma}.csv
Çıktı : sonuclar/h13_ozet_fib.csv, h13_ozet_altkume.csv,
        h13_ozet_doldurma.csv, h13_ozet.json (belge ve kartlar için sayılar)
Bütün oranlar, katlar ve büyüme çarpanları burada CSV'den hesaplanır;
elle yazılmış sayı yoktur. Süre ölçütü: duvar saati ortancası (ms).
Deterministik denetimler: Fibonacci saf çağrı = 2·F(n+1) − 1, memo çağrı =
2n − 1, tablo hücre = n + 1; alt kümede kaba düğüm = 2^(n+1) − 1, tablo
hücre = (n + 1)(hedef + 1); aynı n'de bütün yöntemlerin çözüm sayısı eşit.
Kullanım: python3 h13_cozumle.py
"""
import csv
import json
import math
import os

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
PHI = (1 + 5 ** 0.5) / 2


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def yaz(ad, basliklar, satirlar):
    with open(os.path.join(SONUC, ad), "w", newline="",
              encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(basliklar)
        w.writerows(satirlar)


def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def egim(xs, ys):
    """log–log en küçük kareler eğimi"""
    lx = [math.log(x) for x in xs]
    ly = [math.log(y) for y in ys]
    mx, my = sum(lx) / len(lx), sum(ly) / len(ly)
    pay = sum((a - mx) * (b - my) for a, b in zip(lx, ly))
    payda = sum((a - mx) ** 2 for a in lx)
    return pay / payda


def main():
    st = oku("h13_deney_strateji.csv")
    denetim = {}
    ozet = {"sure_olcutu": "duvar saati ortancası (ms), 1 ısınma + 5 tekrar"}

    def bul(problem, n, yontem, dil):
        for s in st:
            if (s["problem"], int(s["n"]), s["yontem"], s["dil"]) == \
                    (problem, n, yontem, dil):
                return s
        return None

    # --- Fibonacci -----------------------------------------------------------
    fib_satir = []
    nler = sorted({int(s["n"]) for s in st if s["problem"] == "fib"})
    for dil in ("c", "cpp", "py"):
        for n in nler:
            saf = bul("fib", n, "saf", dil)
            memo = bul("fib", n, "memo", dil)
            tablo = bul("fib", n, "tablo", dil)
            iki = bul("fib", n, "iki", dil)
            if saf:
                denetim[f"fib saf çağrı = 2F(n+1)-1 ({dil}, n={n})"] = \
                    int(saf["cagri"]) == 2 * fib(n + 1) - 1
            denetim[f"fib memo çağrı = 2n-1 ({dil}, n={n})"] = \
                int(memo["cagri"]) == 2 * n - 1
            denetim[f"fib tablo hücre = n+1 ({dil}, n={n})"] = \
                int(tablo["hucre"]) == n + 1
            ms = {k: float(v["ortanca_ms"]) for k, v in
                  (("saf", saf), ("memo", memo), ("tablo", tablo),
                   ("iki", iki)) if v}
            fib_satir.append([
                n, dil, saf["olcum"] if saf else "",
                saf["cagri"] if saf else "", memo["cagri"], tablo["hucre"],
                f"{ms['saf']:.6f}" if saf else "", f"{ms['memo']:.6f}",
                f"{ms['tablo']:.6f}", f"{ms['iki']:.6f}",
                f"{ms['saf'] / ms['memo']:.1f}" if saf else "",
                f"{ms['saf'] / ms['tablo']:.1f}" if saf else "",
                memo["tracemalloc_tepe_bayt"], tablo["tracemalloc_tepe_bayt"],
                memo["bayt"], tablo["bayt"]])
    yaz("h13_ozet_fib.csv",
        ["n", "dil", "saf_olcum", "saf_cagri", "memo_cagri", "tablo_hucre",
         "saf_ms", "memo_ms", "tablo_ms", "iki_ms", "kat_saf_memo",
         "kat_saf_tablo", "memo_tracemalloc_bayt", "tablo_tracemalloc_bayt",
         "memo_veri_bayt", "tablo_veri_bayt"], fib_satir)
    # saf özyineleme süresinin n + 5 başına büyüme çarpanı (ölçülen noktalar)
    buyume = {}
    for dil in ("c", "cpp", "py"):
        noktalar = [(int(s["n"]), float(s["ortanca_ms"])) for s in st
                    if s["problem"] == "fib" and s["yontem"] == "saf"
                    and s["dil"] == dil and s["olcum"] == "olcum"
                    and float(s["ortanca_ms"]) >= 0.05]
        buyume[dil] = [(b[0], round(b[1] / a[1], 2))
                       for a, b in zip(noktalar, noktalar[1:])]
    ozet["fib"] = {
        "phi_5": round(PHI ** 5, 2),
        "saf_buyume_n_arti_5": buyume,
        "en_buyuk_olculen_saf": {
            dil: max(int(s["n"]) for s in st if s["problem"] == "fib" and
                     s["yontem"] == "saf" and s["dil"] == dil and
                     s["olcum"] == "olcum") for dil in ("c", "cpp", "py")},
        "n35_c": {k: bul("fib", 35, k, "c")["ortanca_ms"]
                  for k in ("saf", "memo", "tablo", "iki")},
        "n30_py": {k: bul("fib", 30, k, "py")["ortanca_ms"]
                   for k in ("saf", "memo", "tablo", "iki")},
        "kat_saf_tablo_c_n35": round(
            float(bul("fib", 35, "saf", "c")["ortanca_ms"]) /
            float(bul("fib", 35, "tablo", "c")["ortanca_ms"]), 0),
        "kat_saf_tablo_py_n30": round(
            float(bul("fib", 30, "saf", "py")["ortanca_ms"]) /
            float(bul("fib", 30, "tablo", "py")["ortanca_ms"]), 0),
        "kestirim_n40": {dil: bul("fib", 40, "saf", dil)["ortanca_ms"]
                         for dil in ("c", "cpp", "py")
                         if bul("fib", 40, "saf", dil)["olcum"] ==
                         "kestirim"},
    }

    # --- Alt küme toplamı ---------------------------------------------------
    ak = []
    nler = sorted({int(s["n"]) for s in st if s["problem"] == "altkume"})
    for dil in ("c", "cpp", "py"):
        for n in nler:
            r = {y: bul("altkume", n, y, dil)
                 for y in ("kaba", "geri", "memo", "tablo")}
            denetim[f"altkume kaba düğüm = 2^(n+1)-1 ({dil}, n={n})"] = \
                int(r["kaba"]["cagri"]) == 2 ** (n + 1) - 1
            hedef_hucre = int(r["tablo"]["hucre"])
            sonuc = {r[y]["sonuc"] for y in r if r[y]["olcum"] == "olcum"}
            denetim[f"altkume çözüm sayısı yöntemlerde aynı ({dil}, n={n})"] \
                = len(sonuc) == 1
            ms = {y: float(r[y]["ortanca_ms"]) for y in r}
            ak.append([
                n, dil, r["kaba"]["olcum"], r["geri"]["olcum"],
                r["memo"]["sonuc"], r["kaba"]["cagri"], r["geri"]["cagri"],
                r["memo"]["cagri"], r["memo"]["hucre"], hedef_hucre,
                f"{ms['kaba']:.6f}", f"{ms['geri']:.6f}",
                f"{ms['memo']:.6f}", f"{ms['tablo']:.6f}",
                f"{ms['kaba'] / ms['tablo']:.1f}",
                f"{ms['geri'] / ms['tablo']:.1f}",
                f"{ms['memo'] / ms['tablo']:.2f}",
                r["memo"]["bayt"], r["memo"]["tracemalloc_tepe_bayt"],
                r["tablo"]["tracemalloc_tepe_bayt"]])
    yaz("h13_ozet_altkume.csv",
        ["n", "dil", "kaba_olcum", "geri_olcum", "cozum_sayisi",
         "kaba_dugum", "geri_dugum", "memo_cagri", "memo_hesaplanan",
         "tablo_hucre", "kaba_ms", "geri_ms", "memo_ms", "tablo_ms",
         "kat_kaba_tablo", "kat_geri_tablo", "kat_memo_tablo",
         "memo_tablo_veri_bayt", "memo_tracemalloc_bayt",
         "tablo_tracemalloc_bayt"], ak)

    def deger(n, y, dil, alan="ortanca_ms"):
        return float(bul("altkume", n, y, dil)[alan])
    geri_carpan = []
    olculen_geri = [int(s["n"]) for s in st if s["problem"] == "altkume" and
                    s["yontem"] == "geri" and s["dil"] == "c" and
                    s["olcum"] == "olcum"]
    for a, b in zip(olculen_geri, olculen_geri[1:]):
        geri_carpan.append(round(deger(b, "geri", "c", "cagri") /
                                 deger(a, "geri", "c", "cagri"), 3))
    tablo_n = [n for n in nler]
    ozet["altkume"] = {
        "olculen_ust_n": {
            f"{y}_{dil}": max(int(s["n"]) for s in st
                              if s["problem"] == "altkume" and
                              s["yontem"] == y and s["dil"] == dil and
                              s["olcum"] == "olcum")
            for y in ("kaba", "geri") for dil in ("c", "cpp", "py")},
        "geri_dugum_carpani_n_arti_2_c": geri_carpan,
        "tablo_hucre_egim_loglog": round(egim(
            tablo_n, [deger(n, "tablo", "c", "hucre") for n in tablo_n]), 3),
        "memo_hesaplanan_oran_n40": round(
            deger(40, "memo", "c", "hucre") / deger(40, "tablo", "c",
                                                    "hucre"), 3),
        "n18": {y: bul("altkume", 18, y, "c")["cagri"] if y in
                ("kaba", "geri", "memo") else
                bul("altkume", 18, y, "c")["hucre"]
                for y in ("kaba", "geri", "memo", "tablo")},
        "n26_c_ms": {y: bul("altkume", 26, y, "c")["ortanca_ms"]
                     for y in ("kaba", "geri", "memo", "tablo")},
        "kat_n26_c": {
            "kaba_tablo": round(deger(26, "kaba", "c") /
                                deger(26, "tablo", "c"), 0),
            "geri_tablo": round(deger(26, "geri", "c") /
                                deger(26, "tablo", "c"), 0),
            "memo_tablo": round(deger(26, "memo", "c") /
                                deger(26, "tablo", "c"), 2)},
        "n40": {"cozum": bul("altkume", 40, "tablo", "c")["sonuc"],
                "tablo_hucre": bul("altkume", 40, "tablo", "c")["hucre"],
                "memo_hesaplanan": bul("altkume", 40, "memo", "c")["hucre"],
                "kaba_kestirim_ms_c": bul("altkume", 40, "kaba",
                                          "c")["ortanca_ms"],
                "geri_kestirim_ms_c": bul("altkume", 40, "geri",
                                          "c")["ortanca_ms"],
                "tablo_ms_c": bul("altkume", 40, "tablo", "c")["ortanca_ms"],
                "tablo_ms_py": bul("altkume", 40, "tablo",
                                   "py")["ortanca_ms"],
                "memo_ms_py": bul("altkume", 40, "memo", "py")["ortanca_ms"],
                "veri_bayt": bul("altkume", 40, "tablo", "c")["bayt"],
                "tracemalloc_tablo_py": bul("altkume", 40, "tablo",
                                            "py")["tracemalloc_tepe_bayt"],
                "tracemalloc_memo_py": bul("altkume", 40, "memo",
                                           "py")["tracemalloc_tepe_bayt"]},
    }

    # --- lru_cache -----------------------------------------------------------
    lru = oku("h13_deney_lru.csv")
    sinir = {s["yontem"]: int(s["sinir_n"]) for s in lru
             if s["deney"] == "sinir"}
    olcum = {(s["deney"], s["yontem"], s["n"]): s for s in lru
             if s["deney"] in ("fib", "altkume")}
    ozet["lru"] = {
        "recursionlimit": int([s for s in lru
                               if s["deney"] == "recursionlimit"][0]["n"]),
        "sinir": sinir,
        "sinir_orani_lru_elle": round(sinir["lru_cache"] /
                                      sinir["elle_liste"], 3),
        "olcumler": {f"{k[0]} {k[1]} n={k[2]}": {
            "ms": float(v["ortanca_ms"]), "tepe_bayt": int(v["tepe_bayt"]),
            "girdi": int(v["girdi"])} for k, v in olcum.items()},
    }
    for prob, n in (("fib", "450"), ("altkume", "40")):
        taban = float(olcum[(prob, "elle_liste", n)]["ortanca_ms"])
        tbayt = int(olcum[(prob, "elle_liste", n)]["tepe_bayt"])
        ozet["lru"][f"{prob}_n{n}_kat_elle_liste"] = {
            y: {"sure": round(float(olcum[(prob, y, n)]["ortanca_ms"]) /
                              taban, 2),
                "bellek": round(int(olcum[(prob, y, n)]["tepe_bayt"]) /
                                tbayt, 2)}
            for y in ("elle_sozluk", "lru_cache")}

    # --- doldurma sırası -------------------------------------------------------
    dl = oku("h13_deney_doldurma.csv")
    ds = []
    kat = {}
    for dil, derleme in (("c", "-O2"), ("c", "-O0"), ("cpp", "-O2"),
                         ("py", "-")):
        for n in sorted({int(s["n"]) for s in dl if s["dil"] == dil and
                         s["derleme"] == derleme}):
            sat = [s for s in dl if (s["dil"], s["derleme"], int(s["n"]),
                                     s["sira"]) == (dil, derleme, n,
                                                    "satir")][0]
            sut = [s for s in dl if (s["dil"], s["derleme"], int(s["n"]),
                                     s["sira"]) == (dil, derleme, n,
                                                    "sutun")][0]
            denetim[f"doldurma aynı LCS ({dil} {derleme} n={n})"] = \
                sat["lcs"] == sut["lcs"]
            k = float(sut["ortanca_ms"]) / float(sat["ortanca_ms"])
            ns_hucre = float(sat["ortanca_ms"]) * 1e6 / int(sat["hucre"])
            ds.append([n, dil, derleme, sat["lcs"], sat["hucre"],
                       sat["bayt"], sat["ortanca_ms"], sut["ortanca_ms"],
                       f"{k:.2f}", f"{ns_hucre:.3f}"])
            kat.setdefault(f"{dil} {derleme}", {})[n] = round(k, 2)
    yaz("h13_ozet_doldurma.csv",
        ["n", "dil", "derleme", "lcs", "hucre", "bayt", "satir_ms",
         "sutun_ms", "kat_sutun_satir", "satir_ns_hucre"], ds)
    ozet["doldurma"] = {"kat_sutun_satir": kat}

    ozet["denetim"] = {"toplam": len(denetim),
                       "dogru": sum(1 for v in denetim.values() if v),
                       "yanlis": [k for k, v in denetim.items() if not v]}
    with open(os.path.join(SONUC, "h13_ozet.json"), "w",
              encoding="utf-8") as f:
        json.dump(ozet, f, ensure_ascii=False, indent=1)
    print(json.dumps(ozet, ensure_ascii=False, indent=1)[:4000])


if __name__ == "__main__":
    main()

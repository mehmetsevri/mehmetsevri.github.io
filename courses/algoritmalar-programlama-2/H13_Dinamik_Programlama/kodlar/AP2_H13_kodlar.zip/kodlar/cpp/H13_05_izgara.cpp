/* H13_05_izgara.cpp — AP-2 Hafta 13 · Örnek 5 (★★)
 * Amaç    : 2B DP: (1) ızgarada sol üstten sağ alta (yalnız sağa / aşağı)
 *           yol sayısı, büyük ızgarada mod 10^9 + 7; (2) engelli ızgarada
 *           yol sayısı; (3) engelli ızgarada en küçük maliyetli yol ve
 *           yolun geri çıkarılması
 * DP      : (1)(2) durum yol[i][j] = (0,0)'dan (i,j)'ye yol sayısı ·
 *           geçiş yol[i][j] = yol[i−1][j] + yol[i][j−1] (engelde 0) ·
 *           temel yol[0][0] = 1 · (3) durum m[i][j] = (i,j)'ye en küçük
 *           toplam maliyet · geçiş m[i][j] = a[i][j] + min(m[i−1][j],
 *           m[i][j−1]) · temel m[0][0] = a[0][0]; engel ve ulaşılamayan
 *           = ∞ · sıra satır öncelikli (i artan, j artan) · cevap
 *           [R−1][C−1] · geri çıkarma: eşitlikte YUKARIDAN gelinir
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_05_izgara.cpp -o H13_05_izgara
 * Çalıştır: ./H13_05_izgara
 * Eşleri  : c/H13_05_izgara.c · python/H13_05_izgara.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <limits>
#include <utility>
#include <vector>

using Tablo = std::vector<std::vector<long long>>;

const int R = 5;
const int C = 6;
const int ENGEL = -1;
const int SONSUZ = std::numeric_limits<int>::max();
const long long MOD = 1000000007LL;

// maliyet ızgarası; ENGEL = geçilemez hücre
static const std::vector<std::vector<int>> a = {
    {1, 3, 1, 2, 8, 1},
    {1, 5, ENGEL, 1, 1, 2},
    {4, 2, 1, ENGEL, 3, 1},
    {ENGEL, 1, 9, 1, 1, 2},
    {2, 1, 2, 4, ENGEL, 1},
};

// (1) engelsiz r x c ızgara: tam tablo; cevap yol[r-1][c-1]
static Tablo yol_sayisi_tablo(int r, int c)
{
    Tablo yol(r, std::vector<long long>(c));
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            if (i == 0 || j == 0) {
                yol[i][j] = 1;                 // ilk satır ve sütun
            } else {
                yol[i][j] = yol[i - 1][j] + yol[i][j - 1];
            }
        }
    }
    return yol;
}

// Büyük n x n: tek satır tamponu (satır öncelikli doldurma; yol[j]
// soldaki hücreyi bu satırdan, yukarıdakini önceki satırdan tutar)
static long long yol_sayisi_mod(int n)
{
    std::vector<long long> yol(n, 1);          // ilk satır
    for (int i = 1; i < n; i++) {
        for (int j = 1; j < n; j++) {
            yol[j] = (yol[j] + yol[j - 1]) % MOD;  // yukarı + sol
        }
    }
    return yol[n - 1];
}

// C(n, k) tam değer (küçük n için kâhin): çarp-böl her adımda tam bölünür
static long long binom(int n, int k)
{
    long long sonuc = 1;
    for (int i = 1; i <= k; i++) {
        sonuc = sonuc * (n - k + i) / i;
    }
    return sonuc;
}

// (2) engelli ızgara: engel hücresinde yol 0
static long long engelli_yol_sayisi(Tablo& yol)
{
    yol.assign(R, std::vector<long long>(C, 0));
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (a[i][j] == ENGEL) {
                yol[i][j] = 0;
            } else if (i == 0 && j == 0) {
                yol[i][j] = 1;                 // temel durum
            } else {
                long long ust = i > 0 ? yol[i - 1][j] : 0;
                long long sol = j > 0 ? yol[i][j - 1] : 0;
                yol[i][j] = ust + sol;
            }
        }
    }
    return yol[R - 1][C - 1];
}

// (3) en küçük maliyet; m[i][j] = SONSUZ: engel ya da ulaşılamaz
static int en_kucuk_maliyet(std::vector<std::vector<int>>& m)
{
    m.assign(R, std::vector<int>(C, 0));
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (a[i][j] == ENGEL) {
                m[i][j] = SONSUZ;
                continue;
            }
            if (i == 0 && j == 0) {
                m[i][j] = a[0][0];             // temel durum
                continue;
            }
            int ust = i > 0 ? m[i - 1][j] : SONSUZ;
            int sol = j > 0 ? m[i][j - 1] : SONSUZ;
            int enk = ust <= sol ? ust : sol;  // eşitlikte yukarı
            m[i][j] = enk == SONSUZ ? SONSUZ : enk + a[i][j];
        }
    }
    return m[R - 1][C - 1];
}

// Yolu sağ alttan geri çıkarır; (i, j) çiftleri BAŞTAN SONA
static std::vector<std::pair<int, int>> yolu_geri_cikar(
    const std::vector<std::vector<int>>& m)
{
    std::vector<std::pair<int, int>> yol(R + C - 1);
    int i = R - 1, j = C - 1;
    for (int k = R + C - 2; k >= 0; k--) {
        yol[k] = {i, j};
        if (i == 0) {
            j--;
        } else if (j == 0) {
            i--;
        } else if (m[i - 1][j] <= m[i][j - 1]) {
            i--;                               // eşitlikte yukarı
        } else {
            j--;
        }
    }
    return yol;
}

static void yaz_hucre_ll(long long v, bool engel_mi)
{
    if (engel_mi) {
        std::cout << "    #";
    } else {
        std::cout << ' ' << std::setw(4) << v;
    }
}

int main()
{
    std::cout << "1) Izgarada yol sayısı (yalnız sağa ya da aşağı), 3 x 4\n";
    std::cout << "  yol[i][j] = yol[i-1][j] + yol[i][j-1]; ilk satır ve "
                 "sütun 1\n";
    Tablo yol = yol_sayisi_tablo(3, 4);
    for (int i = 0; i < 3; i++) {
        std::cout << ' ';
        for (int j = 0; j < 4; j++) {
            yaz_hucre_ll(yol[i][j], false);
        }
        std::cout << '\n';
    }
    std::cout << "  cevap yol[2][3] = " << yol[2][3] << " = C(5, 2) = "
              << binom(5, 2) << '\n';

    std::cout << "\n2) n x n ızgara: yol = C(2n-2, n-1); tek satır tamponu, "
                 "mod 10^9 + 7\n";
    for (int n : {16, 30, 100, 500}) {
        long long v = yol_sayisi_mod(n);
        std::cout << "  n = " << std::setw(3) << n << ": " << v;
        if (n <= 30) {
            long long b = binom(2 * n - 2, n - 1);   // tam değer
            std::cout << "  (tam C(" << 2 * n - 2 << ", " << n - 1
                      << ") = " << b << "; tam mod p = " << b % MOD
                      << ")\n";
        } else {
            std::cout << "  (mod 1000000007)\n";
        }
    }

    std::cout << "\n3) Engelli ızgara (# = engel), " << R << " x " << C
              << "\n  maliyetler:\n";
    for (int i = 0; i < R; i++) {
        std::cout << ' ';
        for (int j = 0; j < C; j++) {
            yaz_hucre_ll(a[i][j], a[i][j] == ENGEL);
        }
        std::cout << '\n';
    }
    long long es = engelli_yol_sayisi(yol);
    std::cout << "  yol sayısı tablosu (engelde 0):\n";
    for (int i = 0; i < R; i++) {
        std::cout << ' ';
        for (int j = 0; j < C; j++) {
            yaz_hucre_ll(yol[i][j], a[i][j] == ENGEL);
        }
        std::cout << '\n';
    }
    std::cout << "  engelli yol sayısı = " << es << " (engelsiz 5 x 6: "
              << binom(R + C - 2, R - 1) << ")\n";

    std::vector<std::vector<int>> m;
    int enk = en_kucuk_maliyet(m);
    std::cout << "\n4) En küçük maliyetli yol: m[i][j] = a[i][j] + "
                 "min(m[i-1][j], m[i][j-1])\n";
    for (int i = 0; i < R; i++) {
        std::cout << ' ';
        for (int j = 0; j < C; j++) {
            if (a[i][j] == ENGEL) {
                std::cout << "    #";
            } else if (m[i][j] == SONSUZ) {
                std::cout << "    ∞";
            } else {
                std::cout << ' ' << std::setw(4) << m[i][j];
            }
        }
        std::cout << '\n';
    }
    if (enk == SONSUZ) {
        std::cout << "  sağ alt hücre ulaşılamaz\n";
        return 0;
    }
    const auto yolu = yolu_geri_cikar(m);
    std::cout << "  en küçük maliyet = " << enk
              << "; yol (eşitlikte yukarıdan):\n  ";
    int toplam = 0;
    for (std::size_t k = 0; k < yolu.size(); k++) {
        const auto& [i, j] = yolu[k];
        toplam += a[i][j];
        std::cout << (k > 0 ? " -> (" : "(") << i << ',' << j << ')';
    }
    std::cout << "\n  yol üzerindeki maliyet toplamı = " << toplam << " ("
              << (toplam == enk ? "tutarlı" : "TUTARSIZ") << ")\n";
    std::cout << "  yol çizimi (* = yol, # = engel):\n";
    for (int i = 0; i < R; i++) {
        std::cout << "   ";
        for (int j = 0; j < C; j++) {
            char ch = a[i][j] == ENGEL ? '#' : '.';
            for (const auto& h : yolu) {
                if (h.first == i && h.second == j) {
                    ch = '*';
                }
            }
            std::cout << ' ' << ch;
        }
        std::cout << '\n';
    }
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python). Kombinatorik kâhin: C(n, k)
// — Python math.comb (yalnız doğrulama).

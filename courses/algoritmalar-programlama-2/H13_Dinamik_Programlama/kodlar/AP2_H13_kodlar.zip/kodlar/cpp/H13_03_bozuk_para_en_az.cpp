/* H13_03_bozuk_para_en_az.cpp — AP-2 Hafta 13 · Örnek 3 (★★)
 * Amaç    : En az para sayısı: H12'nin karşı örneği ({1, 3, 4}, tutar 6:
 *           açgözlü 3 para, DP 2 para); kullanılan paraların geri
 *           çıkarılması; ulaşılamayan tutar için ∞ sözleşmesi (taşma
 *           korumalı); kanonik sistemde açgözlü = DP
 * DP      : durum enaz[t] = t tutarı için en az para · geçiş
 *           enaz[t] = min{enaz[t−c] + 1 : c <= t, enaz[t−c] != ∞} ·
 *           temel enaz[0] = 0, diğerleri ∞ (SONSUZ = INT_MAX) · sıra
 *           t = 1..S artan · cevap enaz[S] · geri çıkarma secim[t] = son
 *           para, t -= secim[t]; paralar artan denenir, yalnız KESİN
 *           küçükte güncellenir (eşitlikte küçük para kalır)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_03_bozuk_para_en_az.cpp -o H13_03_bozuk_para_en_az
 * Çalıştır: ./H13_03_bozuk_para_en_az
 * Eşleri  : c/H13_03_bozuk_para_en_az.c ·
 *           python/H13_03_bozuk_para_en_az.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

const int MAKS_S = 1000;
const int SONSUZ = std::numeric_limits<int>::max();   // "ulaşılamaz"

static std::vector<int> enaz(MAKS_S + 1);
static std::vector<int> secim(MAKS_S + 1);   // enaz[t]'yi veren son para

// paralar ARTAN sıralı; enaz[0..S] ve secim[0..S] doldurulur
static void en_az_para(const std::vector<int>& paralar, int S)
{
    enaz[0] = 0;                           // temel durum
    secim[0] = 0;
    for (int t = 1; t <= S; t++) {
        enaz[t] = SONSUZ;                  // henüz ulaşılamadı
        secim[t] = 0;
        for (int c : paralar) {
            if (c <= t && enaz[t - c] != SONSUZ &&    // taşma koruması
                enaz[t - c] + 1 < enaz[t]) {
                enaz[t] = enaz[t - c] + 1;
                secim[t] = c;
            }
        }
    }
}

// Açgözlü (H12): en büyük sığan parayı al; para sayısı ya da -1
static int acgozlu(const std::vector<int>& paralar, int t,
                   std::vector<int>& alinan)
{
    alinan.clear();
    for (auto it = paralar.rbegin(); it != paralar.rend(); ++it) {
        while (*it <= t) {
            t -= *it;
            alinan.push_back(*it);
        }
    }
    return t == 0 ? static_cast<int>(alinan.size()) : -1;
}

// DP çözümünü geri çıkarır: t, t - secim[t], ...; para sayısı
static int geri_cikar(int t, std::vector<int>& alinan)
{
    alinan.clear();
    while (t > 0) {
        alinan.push_back(secim[t]);
        t -= secim[t];
    }
    return static_cast<int>(alinan.size());
}

static void yaz_paralar(const std::vector<int>& alinan)
{
    for (std::size_t i = 0; i < alinan.size(); i++) {
        std::cout << (i > 0 ? " + " : "") << alinan[i];
    }
}

static void yaz_kume(const std::vector<int>& paralar)
{
    std::cout << '{';
    for (std::size_t i = 0; i < paralar.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << paralar[i];
    }
    std::cout << '}';
}

int main()
{
    std::vector<int> alinan;
    const std::vector<int> p1 = {1, 3, 4};
    en_az_para(p1, 20);

    std::cout << "1) H12'nin karşı örneği: paralar {1, 3, 4}, tutar 6\n";
    int sayi = acgozlu(p1, 6, alinan);
    std::cout << "  açgözlü (en büyük sığan para): ";
    yaz_paralar(alinan);
    std::cout << " = " << sayi << " para\n";
    sayi = geri_cikar(6, alinan);
    std::cout << "  DP (en az para)              : ";
    yaz_paralar(alinan);
    std::cout << " = " << sayi << " para\n";

    std::cout << "\n2) Tablo: enaz[t] = min(enaz[t-c] + 1); enaz[0] = 0, "
                 "diğerleri ∞\n";
    std::cout << "   t  enaz  secim  adaylar c:enaz[t-c]+1\n";
    for (int t = 0; t <= 6; t++) {
        std::cout << "  " << std::setw(2) << t << "  " << std::setw(4)
                  << enaz[t] << "  ";
        if (secim[t] == 0) {
            std::cout << "    -";
        } else {
            std::cout << std::setw(5) << secim[t];
        }
        for (std::size_t i = 0; i < p1.size(); i++) {
            int c = p1[i];
            if (c <= t) {
                std::cout << (i == 0 ? "   " : "  ") << c << ':'
                          << enaz[t - c] + 1;
            }
        }
        std::cout << '\n';
    }

    std::cout << "\n3) Geri çıkarma: t = 6";
    for (int t = 6; t > 0; t -= secim[t]) {
        std::cout << " -> " << t - secim[t] << " (secim " << secim[t] << ')';
    }
    std::cout << '\n';

    std::cout << "\n4) Açgözlü ile DP, paralar {1, 3, 4}, t = 1..20: farklı "
                 "olanlar\n";
    std::cout << "   t  açgözlü  DP  açgözlü paralar / DP paraları\n";
    int fark = 0;
    for (int t = 1; t <= 20; t++) {
        std::vector<int> ag, dp;
        int na = acgozlu(p1, t, ag);
        int nd = geri_cikar(t, dp);
        if (na != nd) {
            fark++;
            std::cout << "  " << std::setw(2) << t << "  " << std::setw(7)
                      << na << "  " << std::setw(2) << nd << "  ";
            yaz_paralar(ag);
            std::cout << " / ";
            yaz_paralar(dp);
            std::cout << '\n';
        }
    }
    std::cout << "  farklı tutar sayısı: " << fark << " / 20\n";

    const std::vector<int> p2 = {4, 6};
    en_az_para(p2, 12);
    std::cout << "\n5) Ulaşılamayan tutar: paralar ";
    yaz_kume(p2);
    std::cout << ", SONSUZ = INT_MAX = " << SONSUZ << '\n';
    std::cout << "  t   :";
    for (int t = 0; t <= 12; t++) {
        std::cout << ' ' << std::setw(2) << t;
    }
    std::cout << "\n  enaz:";
    for (int t = 0; t <= 12; t++) {
        if (enaz[t] == SONSUZ) {
            std::cout << "  ∞";
        } else {
            std::cout << ' ' << std::setw(2) << enaz[t];
        }
    }
    std::cout << "\n  tutar 7: "
              << (enaz[7] == SONSUZ ? "ulaşılamaz (enaz = ∞)" : "ulaşılır")
              << "; açgözlü: "
              << (acgozlu(p2, 7, alinan) < 0 ? "çözüm bulamaz" : "çözüm")
              << '\n';
    std::cout << "  (enaz[t-c] != SONSUZ denetimi olmasa INT_MAX + 1 taşardı: "
                 "Hata Avcısı)\n";

    const std::vector<int> p3 = {1, 5, 10, 25, 50, 100};
    en_az_para(p3, MAKS_S);
    int esit = 0;
    for (int t = 1; t <= MAKS_S; t++) {
        if (acgozlu(p3, t, alinan) == enaz[t]) {
            esit++;
        }
    }
    std::cout << "\n6) Kanonik sistem ";
    yaz_kume(p3);
    std::cout << " (kuruş): t = 1.." << MAKS_S << " için açgözlü = DP: "
              << esit << " / " << MAKS_S << '\n';
    std::cout << "  t = 289: DP ";
    sayi = geri_cikar(289, alinan);
    yaz_paralar(alinan);
    std::cout << " = " << sayi << " para\n";
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python); DP tablosu elle doldurulur.
// H12'de açgözlü yalnız kanonik para sistemlerinde en iyidir.

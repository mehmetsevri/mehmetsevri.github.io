/* H13_13_lis_nlogn.cpp — AP-2 Hafta 13 · Örnek 13 (★★★, merak)
 * Amaç    : En uzun artan alt dizi O(n log n): "sabır sıralaması" fikri.
 *           tails[k] = uzunluğu k+1 olan artan alt dizilerin EN KÜÇÜK son
 *           değeri; her x için H4'ün lower_bound'u (ilk tails[k] >= x)
 *           ile yeri bulunur. Uzunluk Örnek 7 ile aynı; dizinin geri
 *           çıkarılması için tails_idx ve ebeveyn dizileri
 * DP      : durum tails[0..L) (artan sıralı kalır: değişmez) · geçiş
 *           k = lower_bound(tails, x); tails[k] = x (k = L ise L++) ·
 *           temel L = 0 · sıra i = 0..n−1 · cevap L · geri çıkarma
 *           ebeveyn[i] = tails_idx[k−1] (k > 0), zincir tails_idx[L−1]'den
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_13_lis_nlogn.cpp -o H13_13_lis_nlogn
 * Çalıştır: ./H13_13_lis_nlogn
 * Eşleri  : c/H13_13_lis_nlogn.c · python/H13_13_lis_nlogn.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

using Dizi = std::vector<int>;

static long long yoklama = 0;      // incelenen tails[mid] sayısı
static long long karsilastirma = 0;

// H4 Örnek 7: lower_bound — ilk t[i] >= x konumu; hepsi < x ise n.
// Değişmez: t[0..lo-1] < x <= t[hi..n-1]
static int alt_sinir(const Dizi& t, int n, int x)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        yoklama++;
        if (t[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

static void liste_yaz(const Dizi& x, int L)
{
    std::cout << '[';
    for (int t = 0; t < L; t++) {
        std::cout << (t > 0 ? ", " : "") << x[t];
    }
    std::cout << ']';
}

// Sabır sıralaması; tails, tails_idx, ebeveyn n öğeye boyutlanır.
// iz ise her adımı yazar. Dönen: L (LIS uzunluğu)
static int lis_nlogn(const Dizi& a, Dizi& tails, Dizi& tails_idx,
                     Dizi& ebeveyn, bool iz)
{
    const int n = static_cast<int>(a.size());
    tails.assign(n, 0);
    tails_idx.assign(n, 0);
    ebeveyn.assign(n, -1);
    int L = 0;
    for (int i = 0; i < n; i++) {
        int k = alt_sinir(tails, L, a[i]);
        tails[k] = a[i];                       // yeni deste ya da üstüne
        tails_idx[k] = i;
        ebeveyn[i] = k > 0 ? tails_idx[k - 1] : -1;
        if (k == L) {
            L++;
        }
        if (iz) {
            std::cout << "  x = " << a[i] << " -> konum " << k
                      << ": tails ";
            liste_yaz(tails, L);
            std::cout << ", tails_idx ";
            liste_yaz(tails_idx, L);
            std::cout << ", ebeveyn[" << i << "] = " << ebeveyn[i] << '\n';
        }
    }
    return L;
}

// Zinciri tails_idx[L-1]'den izler; değerleri BAŞTAN SONA yazar
static void geri_cikar_yaz(const Dizi& a, const Dizi& tails_idx,
                           const Dizi& ebeveyn, int L)
{
    Dizi indis(L);
    int k = L;
    for (int i = L > 0 ? tails_idx[L - 1] : -1; i != -1; i = ebeveyn[i]) {
        indis[--k] = i;
    }
    std::cout << "  alt dizi:";
    for (int x = 0; x < L && x < 12; x++) {
        std::cout << ' ' << a[indis[x]];
    }
    if (L > 12) {
        std::cout << " ... (ilk 12)";
    }
    bool artan = true;
    for (int x = 1; x < L; x++) {
        if (!(indis[x - 1] < indis[x] && a[indis[x - 1]] < a[indis[x]])) {
            artan = false;
        }
    }
    std::cout << "\n  denetim: indisler ve değerler kesin artan: "
              << (artan ? "evet" : "HAYIR") << '\n';
}

// Örnek 7'nin O(n^2) DP'si (yalnız uzunluk; kâhin)
static int lis_n2_uzunluk(const Dizi& a)
{
    const int n = static_cast<int>(a.size());
    Dizi uz(n, 1);
    int en = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            karsilastirma++;
            if (a[j] < a[i] && uz[j] + 1 > uz[i]) {
                uz[i] = uz[j] + 1;
            }
        }
        if (uz[i] > en) {
            en = uz[i];
        }
    }
    return en;
}

int main()
{
    Dizi tails, idx, eb;
    const Dizi a1 = {5, 2, 8, 6, 3, 6, 9, 7};
    std::cout << "1) a = {5, 2, 8, 6, 3, 6, 9, 7} (Örnek 7 ile aynı)\n";
    std::cout << "  (konum = lower_bound(tails, x); tails[konum] = x)\n";
    yoklama = 0;
    int L = lis_nlogn(a1, tails, idx, eb, true);
    std::cout << "  uzunluk L = " << L << "; yoklama (lower_bound adımı) = "
              << yoklama << '\n';
    geri_cikar_yaz(a1, idx, eb, L);

    rastgele_tohum(42);
    const Dizi a2 = rastgele_dizi(16, 1, 50);
    std::cout << "\n2) Örnek 7'nin rastgele dizisi (tohum 42, n = 16, "
                 "1..50)\n";
    yoklama = 0;
    L = lis_nlogn(a2, tails, idx, eb, false);
    long long y2 = yoklama;
    int l2 = lis_n2_uzunluk(a2);
    std::cout << "  uzunluk L = " << L << " (Örnek 7: O(n^2) DP ile " << l2
              << "); yoklama = " << y2 << '\n';
    std::cout << "  son tails = ";
    liste_yaz(tails, L);
    std::cout << "  (bir artan alt dizi DEĞİL; yalnız deste üstleri)\n";
    geri_cikar_yaz(a2, idx, eb, L);

    std::cout << "\n3) Büyük n (tohum 42, 1..1000000)\n";
    for (int n : {1000, 100000}) {
        rastgele_tohum(42);
        const Dizi a = rastgele_dizi(n, 1, 1000000);
        yoklama = 0;
        L = lis_nlogn(a, tails, idx, eb, false);
        std::cout << "  n = " << std::setw(6) << n << ": L = " << L
                  << ", yoklama = " << yoklama;
        if (n <= 1000) {
            karsilastirma = 0;
            int l = lis_n2_uzunluk(a);
            std::cout << "; O(n^2): L = " << l << ", karşılaştırma = "
                      << karsilastirma << " (" << (l == L ? "aynı" : "FARKLI")
                      << ")\n";
        } else {
            std::cout << "; O(n^2) olsaydı n(n-1)/2 = "
                      << static_cast<long long>(n) * (n - 1) / 2
                      << " karşılaştırma\n";
        }
        geri_cikar_yaz(a, idx, eb, L);
    }
    return 0;
}

// Kütüphane karşılığı: lower_bound — C: yok (elle; bsearch eşit öğeyi
// bulur, konum vermez); C++: std::lower_bound; Python: bisect.bisect_left
// (yalnız kâhin). LIS'in kendisinin kütüphane karşılığı yok.

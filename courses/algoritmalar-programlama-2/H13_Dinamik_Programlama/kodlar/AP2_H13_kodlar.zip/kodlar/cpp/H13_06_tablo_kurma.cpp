/* H13_06_tablo_kurma.cpp — AP-2 Hafta 13 · Örnek 6 (★★, Dil Penceresi)
 * Amaç    : 2B DP tablosu kurma: C++'ta std::vector<std::vector<int>>
 *           (her satır ayrı bir vektör, ayrı blok); tek blok isteyen için
 *           std::vector<int>(n * m). Aynı tabloyla Pascal üçgeni. C'de tek
 *           malloc bloğu, Python'da [[0] * m] * n tuzağı (eş dosyalar)
 * DP      : durum t[i][j] = C(i, j) · geçiş C(i, j) = C(i−1, j−1) +
 *           C(i−1, j) · temel C(i, 0) = C(i, i) = 1 · sıra i artan (satır
 *           öncelikli), j = 1..i−1 · cevap t[n−1][k]
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_06_tablo_kurma.cpp -o H13_06_tablo_kurma
 * Çalıştır: ./H13_06_tablo_kurma
 * Eşleri  : c/H13_06_tablo_kurma.c · python/H13_06_tablo_kurma.py
 * Çıktı   : Δ — dile özgü (bölüm 1 her dilde farklı; bölüm 2 aynı);
 *           bkz. Dil Penceresi
 */
#include <iomanip>
#include <iostream>
#include <vector>

using Tablo = std::vector<std::vector<int>>;

// Her satır kendi belleğini yöneten ayrı bir vektördür (RAII)
static Tablo tablo_kur(int n, int m)
{
    return Tablo(n, std::vector<int>(m, 0));
}

// Pascal üçgeni: t[i][j] = C(i, j), 0 <= j <= i < n
static void pascal_doldur(Tablo& t, int n)
{
    for (int i = 0; i < n; i++) {
        t[i][0] = 1;                               // C(i, 0) = 1
        t[i][i] = 1;                               // C(i, i) = 1
        for (int j = 1; j < i; j++) {
            t[i][j] = t[i - 1][j - 1] + t[i - 1][j];
        }
    }
}

static void pascal_yaz(const Tablo& t, int n)
{
    for (int i = 0; i < n; i++) {
        std::cout << "   ";
        for (int j = 0; j <= i; j++) {
            std::cout << ' ' << std::setw(4) << t[i][j];
        }
        std::cout << '\n';
    }
}

int main()
{
    const int n = 6, m = 6;
    std::cout << "1) 2B tablo, C++: std::vector<std::vector<int>> t(n, "
                 "std::vector<int>(m, 0)) (n = " << n << ", m = " << m
              << ")\n";
    Tablo t = tablo_kur(n, m);
    std::cout << "  t.size() = " << t.size() << " satır, t[0].size() = "
              << t[0].size() << " sütun; her satır AYRI bir vektör\n";
    std::cout << "  (satırlar bellekte bitişik olmak zorunda değil; tek "
                 "blok: std::vector<int> t(n * m), t[i * m + j])\n";
    t[0][0] = 7;
    std::cout << "  t[0][0] = 7: öteki satırların ilk hücreleri:";
    for (int i = 1; i < n; i++) {
        std::cout << ' ' << t[i][0];
    }
    std::cout << "\n  (her satır ayrı hücrelerdir; paylaşım yok)\n";
    t[0][0] = 0;

    std::cout << "\n2) Pascal üçgeni (DP): C(i, j) = C(i-1, j-1) + "
                 "C(i-1, j); C(i, 0) = C(i, i) = 1\n";
    pascal_doldur(t, n);
    pascal_yaz(t, n);
    std::cout << "  C(5, 2) = " << t[5][2] << '\n';
    return 0;
}

// Kütüphane karşılığı: C — yok (tek blok + indis hesabı elle); C++ —
// std::vector<std::vector<int>> ya da std::vector<int>(n * m); Python —
// [[0] * m for _ in range(n)].

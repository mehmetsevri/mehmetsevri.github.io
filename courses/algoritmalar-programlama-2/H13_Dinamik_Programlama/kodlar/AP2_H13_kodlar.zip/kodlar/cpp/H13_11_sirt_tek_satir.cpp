/* H13_11_sirt_tek_satir.cpp — AP-2 Hafta 13 · Örnek 11 (★★★)
 * Amaç    : 0/1 sırt çantası tek satırla (bellek O(W)): kapasite TERS
 *           sırada dolaşılır. Yan yana: ARTAN sırada dolaşınca aynı nesne
 *           birden çok kez alınır — sınırsız sırt çantası olur. Her
 *           nesneden sonra satır; tam tablo ve sınırsız DP ile denetim
 * DP      : durum dp[w] = şimdiye dek işlenen nesnelerle w kapasitede en
 *           büyük değer (tam tablonun i. satırı yerinde) · geçiş dp[w] =
 *           max(dp[w], dp[w − a_i] + d_i) · temel dp[w] = 0 · sıra nesne
 *           i dışta; w = W, W−1, …, a_i (TERS: dp[w − a_i] henüz bu
 *           nesneyle güncellenmemiştir, yani "önceki satır") · cevap
 *           dp[W] · geri çıkarma YOK (önceki satırlar üzerine yazıldı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_11_sirt_tek_satir.cpp -o H13_11_sirt_tek_satir
 * Çalıştır: ./H13_11_sirt_tek_satir
 * Eşleri  : c/H13_11_sirt_tek_satir.c · python/H13_11_sirt_tek_satir.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

using Dizi = std::vector<int>;

static int iz_nesne = -1;          // güncellemeleri yazılacak nesne

static void satir_yaz(const std::string& etiket, const Dizi& dp)
{
    std::cout << "  " << std::left << std::setw(6) << etiket << std::right
              << ':';
    for (int v : dp) {
        std::cout << ' ' << std::setw(3) << v;
    }
    std::cout << '\n';
}

static void guncelleme_yaz(int w, int eski, int yeni, int kaynak)
{
    std::cout << "      dp[" << w << "]: " << eski << " -> " << yeni
              << "  (dp[" << kaynak << "] + d)\n";
}

// 0/1: w TERS sırada; satirlari_yaz ise her nesneden sonra satır
static int tek_satir_ters(const Dizi& a, const Dizi& d,
                          const std::vector<std::string>& ad, int W,
                          bool satirlari_yaz, Dizi& dp)
{
    dp.assign(W + 1, 0);                       // temel
    for (std::size_t i = 0; i < a.size(); i++) {
        for (int w = W; w >= a[i]; w--) {      // TERS
            if (dp[w - a[i]] + d[i] > dp[w]) {
                if (static_cast<int>(i) == iz_nesne) {
                    guncelleme_yaz(w, dp[w], dp[w - a[i]] + d[i], w - a[i]);
                }
                dp[w] = dp[w - a[i]] + d[i];
            }
        }
        if (satirlari_yaz) {
            satir_yaz("+" + ad[i], dp);
        }
    }
    return dp[W];
}

// YANLIŞ (0/1 için): w ARTAN sırada; dp[w − a_i] bu turda güncellenmiş
// olabilir → aynı nesne yeniden alınır (sınırsız sırt çantası)
static int tek_satir_artan(const Dizi& a, const Dizi& d,
                           const std::vector<std::string>& ad, int W,
                           bool satirlari_yaz, Dizi& dp)
{
    dp.assign(W + 1, 0);
    for (std::size_t i = 0; i < a.size(); i++) {
        for (int w = a[i]; w <= W; w++) {      // ARTAN
            if (dp[w - a[i]] + d[i] > dp[w]) {
                if (static_cast<int>(i) == iz_nesne) {
                    guncelleme_yaz(w, dp[w], dp[w - a[i]] + d[i], w - a[i]);
                }
                dp[w] = dp[w - a[i]] + d[i];
            }
        }
        if (satirlari_yaz) {
            satir_yaz("+" + ad[i], dp);
        }
    }
    return dp[W];
}

// Denetim 1: tam tablonun son satırı (Örnek 10)
static int tam_tablo_son(const Dizi& a, const Dizi& d, int W, Dizi& son)
{
    const std::size_t n = a.size();
    std::vector<Dizi> K(n + 1, Dizi(W + 1, 0));
    for (std::size_t i = 1; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            K[i][w] = K[i - 1][w];
            if (a[i - 1] <= w) {
                int al = K[i - 1][w - a[i - 1]] + d[i - 1];
                if (al > K[i][w]) {
                    K[i][w] = al;
                }
            }
        }
    }
    son = K[n];
    return K[n][W];
}

// Denetim 2: sınırsız sırt çantası, kapasite dışta: u[w] = max(u[w − a_i]
// + d_i) — her nesne istenen sayıda
static int sinirsiz(const Dizi& a, const Dizi& d, int W)
{
    Dizi u(W + 1, 0);
    for (int w = 1; w <= W; w++) {
        for (std::size_t i = 0; i < a.size(); i++) {
            if (a[i] <= w && u[w - a[i]] + d[i] > u[w]) {
                u[w] = u[w - a[i]] + d[i];
            }
        }
    }
    return u[W];
}

int main()
{
    const std::vector<std::string> ad = {"A", "B", "C", "D"};
    const Dizi a = {5, 4, 6, 3}, d = {10, 40, 30, 50};
    const int n = 4, W = 10;
    Dizi dp, dp2;
    std::cout << "1) Örnek 10'un nesneleri: A(5, 10) B(4, 40) C(6, 30) "
                 "D(3, 50); W = " << W << '\n';
    std::cout << "  (+X: X nesnesi işlendikten sonra tek satır dp[0..W])\n";
    std::cout << "  " << std::left << std::setw(6) << "w" << std::right
              << ':';
    for (int w = 0; w <= W; w++) {
        std::cout << ' ' << std::setw(3) << w;
    }
    std::cout << "\n  TERS (w = W..a_i) — doğru 0/1:\n";
    int ters = tek_satir_ters(a, d, ad, W, true, dp);
    std::cout << "  ARTAN (w = a_i..W) — YANLIŞ: sınırsız sırt çantası:\n";
    int artan = tek_satir_artan(a, d, ad, W, true, dp2);
    std::cout << "  ters: dp[W] = " << ters << "; artan: dp[W] = " << artan
              << '\n';

    std::cout << "\n2) Neden? D(3, 50) işlenirken dp güncellemeleri\n";
    iz_nesne = 3;
    std::cout << "  TERS : dp[w - 3] önceki satırdan (D henüz yok)\n";
    tek_satir_ters(a, d, ad, W, false, dp2);
    std::cout << "  ARTAN: dp[w - 3] bu turda D ile güncellenmiş olabilir\n";
    tek_satir_artan(a, d, ad, W, false, dp2);
    iz_nesne = -1;
    std::cout << "  (artan: dp[6] = dp[3] + 50 -> D ikinci kez; dp[9] = "
                 "dp[6] + 50 -> üçüncü kez)\n";

    Dizi son;
    int tam = tam_tablo_son(a, d, W, son);
    bool dp_ayni = dp == son;                  // vektör karşılaştırması
    int u = sinirsiz(a, d, W);
    std::cout << "\n3) Denetim\n";
    std::cout << "  ters satır = tam tablonun son satırı K[n][0..W]: "
              << (dp_ayni ? "evet" : "HAYIR") << " (K[n][W] = " << tam
              << ")\n";
    std::cout << "  artan sonuç = sınırsız sırt çantası DP'si (" << u
              << "): " << (u == artan ? "evet" : "HAYIR") << '\n';

    std::cout << "\n4) Bellek: hücre sayısı\n";
    std::cout << "  bu örnek: tam tablo (n+1)(W+1) = " << (n + 1) * (W + 1)
              << ", tek satır W+1 = " << W + 1 << '\n';
    std::cout << "  n = 100, W = 100000: tam tablo = " << 101LL * 100001LL
              << ", tek satır = " << 100001LL << '\n';
    std::cout << "  bedel: seçilen nesneler geri çıkarılamaz (önceki "
                 "satırlar silindi)\n";

    std::vector<std::string> ad3;
    Dizi a3(12), d3(12);
    rastgele_tohum(4);
    for (int i = 0; i < 12; i++) {
        ad3.push_back((i < 9 ? "D0" : "D1") + std::to_string((i + 1) % 10));
        a3[i] = rastgele_aralik(2, 8);
        d3[i] = rastgele_aralik(1, 20);
    }
    int t3 = tek_satir_ters(a3, d3, ad3, 30, false, dp);
    int k3 = tam_tablo_son(a3, d3, 30, son);
    int y3 = tek_satir_artan(a3, d3, ad3, 30, false, dp2);
    std::cout << "\n5) Örnek 10'un 12 dersi (tohum 4, W = 30): tek satır = "
              << t3 << ", tam tablo = " << k3 << "; artan (yanlış) = " << y3
              << '\n';
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python); tek satır elle.

/* H13_08_lcs.cpp — AP-2 Hafta 13 · Örnek 8 (★★★)
 * Amaç    : En uzun ortak alt dizi (LCS): tablo, ortak alt dizinin geri
 *           çıkarılması (yol çizimi), satır düzeyinde diff (LCS dışında
 *           kalan satırlar silinir/eklenir) ve rastgele DNA dizileri
 * DP      : durum L[i][j] = a[0..i) ile b[0..j)'nin LCS uzunluğu · geçiş
 *           a[i−1] = b[j−1] ise L[i−1][j−1] + 1, değilse max(L[i−1][j],
 *           L[i][j−1]) · temel L[0][j] = L[i][0] = 0 · sıra satır
 *           öncelikli (i artan, j artan) · cevap L[n][m] · geri çıkarma
 *           (n, m)'den: eşitse ÇAPRAZ; değilse L[i−1][j] >= L[i][j−1]
 *           ise YUKARI, yoksa SOL (eşitlikte önce yukarı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_08_lcs.cpp -o H13_08_lcs
 * Çalıştır: ./H13_08_lcs
 * Eşleri  : c/H13_08_lcs.c · python/H13_08_lcs.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

using Tablo = std::vector<std::vector<int>>;

// L[i][j] tablosu; satırlar ayrı vektörler (RAII)
template <class Dizi>
static Tablo lcs_tablo(const Dizi& a, const Dizi& b)
{
    const std::size_t n = a.size(), m = b.size();
    Tablo L(n + 1, std::vector<int>(m + 1, 0));   // L[0][j] = L[i][0] = 0
    for (std::size_t i = 1; i <= n; i++) {
        for (std::size_t j = 1; j <= m; j++) {
            if (a[i - 1] == b[j - 1]) {
                L[i][j] = L[i - 1][j - 1] + 1;
            } else if (L[i - 1][j] >= L[i][j - 1]) {
                L[i][j] = L[i - 1][j];
            } else {
                L[i][j] = L[i][j - 1];
            }
        }
    }
    return L;
}

// Geri çıkarma: ortak alt dizi; yol hücre işaretleri (0 yok, 1 çapraz,
// 2 yukarı, 3 sol), nullptr olabilir
static std::string lcs_geri_cikar(const Tablo& L, const std::string& a,
                                  const std::string& b, Tablo* yol)
{
    std::size_t i = a.size(), j = b.size();
    std::string cikti(L[i][j], ' ');
    std::size_t k = cikti.size();
    while (i > 0 && j > 0) {
        if (a[i - 1] == b[j - 1]) {
            cikti[--k] = a[i - 1];
            if (yol) {
                (*yol)[i][j] = 1;
            }
            i--;
            j--;
        } else if (L[i - 1][j] >= L[i][j - 1]) {
            if (yol) {
                (*yol)[i][j] = 2;                  // önce yukarı
            }
            i--;
        } else {
            if (yol) {
                (*yol)[i][j] = 3;
            }
            j--;
        }
    }
    return cikti;
}

// x, y'nin alt dizisi mi? (iki işaretçi)
static bool alt_dizi_mi(const std::string& x, const std::string& y)
{
    std::size_t k = 0;
    for (std::size_t t = 0; t < y.size() && k < x.size(); t++) {
        if (x[k] == y[t]) {
            k++;
        }
    }
    return k == x.size();
}

// Satır diff: satırlar üzerinde aynı DP (eşitlik = std::string ==)
static void satir_diff(const std::vector<std::string>& eski,
                       const std::vector<std::string>& yeni)
{
    const int n = static_cast<int>(eski.size());
    const int m = static_cast<int>(yeni.size());
    const Tablo L = lcs_tablo(eski, yeni);
    std::vector<char> islem;
    std::vector<int> satir;
    int i = n, j = m;                              // sondan başa
    while (i > 0 || j > 0) {
        if (i > 0 && j > 0 && eski[i - 1] == yeni[j - 1]) {
            islem.push_back(' ');
            satir.push_back(--i);
            j--;
        } else if (i > 0 && (j == 0 || L[i - 1][j] >= L[i][j - 1])) {
            islem.push_back('-');
            satir.push_back(--i);
        } else {
            islem.push_back('+');
            satir.push_back(--j);
        }
    }
    std::cout << "  ortak satır = L[" << n << "][" << m << "] = " << L[n][m]
              << "; silinen " << n - L[n][m] << ", eklenen "
              << m - L[n][m] << '\n';
    for (std::size_t x = islem.size(); x-- > 0;) { // baştan sona yaz
        const std::string& metin = islem[x] == '+' ? yeni[satir[x]]
                                                   : eski[satir[x]];
        std::cout << "    " << islem[x] << ' ' << metin << '\n';
    }
}

int main()
{
    const std::string a = "ABCBDAB", b = "BDCABA";
    const std::size_t n = a.size(), m = b.size();
    std::cout << "1) a = \"" << a << "\", b = \"" << b
              << "\" (Cormen vd. örneği)\n";
    const Tablo L = lcs_tablo(a, b);
    Tablo yol(n + 1, std::vector<int>(m + 1, 0));
    const std::string lcs = lcs_geri_cikar(L, a, b, &yol);
    std::cout << "  L tablosu (satır: a'nın önekleri; sütun: b'nin "
                 "önekleri)\n";
    std::cout << "     \"\"";
    for (char c : b) {
        std::cout << "  " << c;
    }
    std::cout << '\n';
    for (std::size_t i = 0; i <= n; i++) {
        if (i == 0) {
            std::cout << "  \"\"";
        } else {
            std::cout << "   " << a[i - 1];
        }
        for (std::size_t j = 0; j <= m; j++) {
            std::cout << ' ' << std::setw(2) << L[i][j];
        }
        std::cout << '\n';
    }
    std::cout << "  LCS uzunluğu = L[" << n << "][" << m << "] = "
              << lcs.size() << "; hücre = (n+1)(m+1) = " << (n + 1) * (m + 1)
              << '\n';
    std::cout << "  geri çıkarma yolu (↖ eşleşme, ↑ yukarı, ← sol; eşitlikte "
                 "↑):\n";
    const char* ok[] = {" .", " ↖", " ↑", " ←"};
    for (std::size_t i = 0; i <= n; i++) {
        std::cout << "    ";
        for (std::size_t j = 0; j <= m; j++) {
            std::cout << ' ' << ok[yol[i][j]];
        }
        std::cout << '\n';
    }
    std::cout << "  ortak alt dizi = \"" << lcs << "\"; a'nın alt dizisi: "
              << (alt_dizi_mi(lcs, a) ? "evet" : "HAYIR") << ", b'nin: "
              << (alt_dizi_mi(lcs, b) ? "evet" : "HAYIR") << '\n';

    std::cout << "\n2) Satır düzeyinde diff (LCS'de olmayan: - silinen, + "
                 "eklenen)\n";
    const std::vector<std::string> eski = {
        "Rize çayı demlenir.", "Su kaynatılır.", "Demlik ısıtılır.",
        "Çay demliğe konur.", "On beş dakika beklenir."};
    const std::vector<std::string> yeni = {
        "Su kaynatılır.", "Demlik ısıtılır.", "Çay demliğe konur.",
        "Üstüne kaynar su eklenir.", "On beş dakika beklenir.",
        "İnce belli bardakta sunulur."};
    satir_diff(eski, yeni);

    std::cout << "\n3) Rastgele DNA (A C G T; tohum 7), n = m = 300\n";
    const std::string harf = "ACGT";
    std::string x, y;
    rastgele_tohum(7);
    for (int i = 0; i < 300; i++) {
        x += harf[rastgele_aralik(0, 3)];
    }
    for (int i = 0; i < 300; i++) {
        y += harf[rastgele_aralik(0, 3)];
    }
    const Tablo D = lcs_tablo(x, y);
    const std::string ortak = lcs_geri_cikar(D, x, y, nullptr);
    std::cout << "  x[0..39] = " << x.substr(0, 40) << "\n  y[0..39] = "
              << y.substr(0, 40) << '\n';
    std::cout << "  LCS uzunluğu = " << ortak.size() << " (oran "
              << std::fixed << std::setprecision(4) << ortak.size() / 300.0
              << "); hücre = " << 301 * 301 << '\n';
    std::cout << "  LCS[0..39] = " << ortak.substr(0, 40)
              << "; x'in ve y'nin alt dizisi: "
              << (alt_dizi_mi(ortak, x) && alt_dizi_mi(ortak, y) ? "evet"
                                                                 : "HAYIR")
              << '\n';
    return 0;
}

// Kütüphane karşılığı: yok (C, C++); Python — difflib.SequenceMatcher
// LCS değil (Ratcliff/Obershelp benzeri) eşleme yapar; diff aracı Hunt ve
// McIlroy'un (1976) LCS tabanlı yöntemine dayanır.

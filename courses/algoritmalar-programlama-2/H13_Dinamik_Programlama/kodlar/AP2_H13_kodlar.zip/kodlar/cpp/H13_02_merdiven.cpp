/* H13_02_merdiven.cpp — AP-2 Hafta 13 · Örnek 2 (★)
 * Amaç    : Merdiven çıkma: her adımda 1 ya da 2 basamak; n. basamağa kaç
 *           farklı yolla çıkılır? İlk durum–geçiş tanımı; yol[n] = F(n+1);
 *           bütün yolların listelenmesiyle doğrulama; {1, 2, 3} değişkesi
 * DP      : durum yol[i] = i. basamağa çıkma yolu sayısı · geçiş
 *           yol[i] = yol[i−1] + yol[i−2] (son adım 1 ya da 2) · temel
 *           yol[0] = 1 (hiç adım atmamak bir yoldur), yol[1] = 1 · sıra
 *           i = 2..n artan · cevap yol[n]
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_02_merdiven.cpp -o H13_02_merdiven
 * Çalıştır: ./H13_02_merdiven
 * Eşleri  : c/H13_02_merdiven.c · python/H13_02_merdiven.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

const int MAKS_N = 40;
const long long MOD = 1000000007LL;

static std::vector<long long> yol(MAKS_N + 1);
static std::vector<int> adimlar;   // listelemede o anki yol (yığın gibi)
static long long listelenen = 0;

// yol[0..n] tablosunu doldurur (1 ya da 2 basamak)
static void merdiven_tablo(int n)
{
    yol[0] = 1;                            // temel durum
    yol[1] = 1;
    for (int i = 2; i <= n; i++) {
        yol[i] = yol[i - 1] + yol[i - 2]; // son adım 1 ya da 2
    }
}

// Doğrulama: kalan basamağa bütün adım dizilerini yazar (önce 1, sonra 2)
static void yollari_listele(int kalan)
{
    if (kalan == 0) {
        listelenen++;
        std::cout << "    ";
        for (std::size_t k = 0; k < adimlar.size(); k++) {
            std::cout << (k > 0 ? "+" : "") << adimlar[k];
        }
        std::cout << '\n';
        return;
    }
    for (int adim = 1; adim <= 2; adim++) {
        if (adim <= kalan) {
            adimlar.push_back(adim);
            yollari_listele(kalan - adim);
            adimlar.pop_back();
        }
    }
}

// Değişke: 1, 2 ya da 3 basamak; yol3[i] = yol3[i−1] + yol3[i−2] +
// yol3[i−3] (i − k >= 0 olan terimler)
static long long merdiven_uclu(int n)
{
    std::vector<long long> yol3(n + 1, 0);
    yol3[0] = 1;
    for (int i = 1; i <= n; i++) {
        yol3[i] = 0;
        for (int k = 1; k <= 3; k++) {
            if (i - k >= 0) {
                yol3[i] += yol3[i - k];
            }
        }
    }
    return yol3[n];
}

// Büyük n: iki değişken + mod 10^9 + 7
static long long merdiven_mod(int n)
{
    long long onceki = 1, simdiki = 1;     // yol[0], yol[1]
    for (int i = 2; i <= n; i++) {
        long long sonraki = (onceki + simdiki) % MOD;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

int main()
{
    std::cout << "1) Durum ve geçiş\n";
    std::cout << "  durum : yol[i] = i. basamağa çıkmanın yol sayısı\n";
    std::cout << "  geçiş : yol[i] = yol[i-1] + yol[i-2]  (son adım 1 ya da "
                 "2)\n";
    std::cout << "  temel : yol[0] = 1, yol[1] = 1;  cevap: yol[n]\n";

    merdiven_tablo(MAKS_N);
    std::vector<long long> fib(MAKS_N + 2);
    fib[0] = 0;
    fib[1] = 1;
    for (int i = 2; i <= MAKS_N + 1; i++) {
        fib[i] = fib[i - 1] + fib[i - 2];
    }
    std::cout << "\n2) Tablo ve Fibonacci ilişkisi: yol[n] = F(n+1)\n";
    std::cout << "  n      :";
    for (int n = 0; n <= 10; n++) {
        std::cout << ' ' << std::setw(3) << n;
    }
    std::cout << "\n  yol[n] :";
    for (int n = 0; n <= 10; n++) {
        std::cout << ' ' << std::setw(3) << yol[n];
    }
    std::cout << "\n  F(n+1) :";
    for (int n = 0; n <= 10; n++) {
        std::cout << ' ' << std::setw(3) << fib[n + 1];
    }
    bool esit = true;
    for (int n = 0; n <= MAKS_N; n++) {
        if (yol[n] != fib[n + 1]) {
            esit = false;
        }
    }
    std::cout << "\n  n = 0.." << MAKS_N << " için yol[n] = F(n+1): "
              << (esit ? "evet" : "HAYIR") << "; yol[" << MAKS_N << "] = "
              << yol[MAKS_N] << '\n';

    std::cout << "\n3) Doğrulama: n = 5 için bütün yollar (önce 1, sonra "
                 "2)\n";
    yollari_listele(5);
    std::cout << "  listelenen = " << listelenen << ", tablo yol[5] = "
              << yol[5] << ": " << (listelenen == yol[5] ? "aynı" : "FARKLI")
              << '\n';

    std::cout << "\n4) Değişke: 1, 2 ya da 3 basamak "
                 "(yol3[i] = yol3[i-1] + yol3[i-2] + yol3[i-3])\n  yol3   :";
    for (int n = 0; n <= 10; n++) {
        std::cout << ' ' << std::setw(3) << merdiven_uclu(n);
    }
    std::cout << '\n';

    std::cout << "\n5) Büyük n: yol[n] mod 10^9 + 7 (iki değişken)\n";
    for (int n : {40, 1000, 100000}) {
        std::cout << "  yol[" << n << "] mod 1000000007 = "
                  << merdiven_mod(n) << '\n';
    }
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python); tablo elle doldurulur.

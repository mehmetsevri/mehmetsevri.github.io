/* H13_01_fibonacci.cpp — AP-2 Hafta 13 · Örnek 1 (★)
 * Amaç    : Fibonacci'nin dört sürümü: saf özyineleme (çağrı sayısı
 *           2·F(n+1) − 1, denetlenir), memo ("hesaplanmadı" = −1), tablo
 *           ve iki değişken; büyük n için uint64_t sınırı ve mod 10^9 + 7
 * DP      : durum F(i) · geçiş F(i) = F(i−1) + F(i−2) · temel F(0) = 0,
 *           F(1) = 1 · sıra i = 2, 3, …, n (artan) · cevap tablo[n]
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_01_fibonacci.cpp -o H13_01_fibonacci
 * Çalıştır: ./H13_01_fibonacci
 * Eşleri  : c/H13_01_fibonacci.c · python/H13_01_fibonacci.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

const int MAKS_N = 100;
const std::uint64_t MOD = 1000000007ULL;

static long long cagri = 0;        // fonksiyon çağrısı sayacı
static long long hesaplanan = 0;   // memo'ya ilk kez yazılan hücre
static std::vector<long long> memo(MAKS_N + 1, -1);

// 1) Saf özyineleme: aynı alt problemler tekrar tekrar çözülür
static long long fib_saf(int n)
{
    cagri++;
    if (n < 2) {
        return n;                          // temel durum
    }
    return fib_saf(n - 1) + fib_saf(n - 2);
}

// 2) Memo (yukarıdan aşağıya): memo[i] == -1 "hesaplanmadı" demektir
static long long fib_memo(int i)
{
    cagri++;
    if (memo[i] != -1) {
        return memo[i];                    // not alınmış: yeniden çözme
    }
    if (i < 2) {
        memo[i] = i;
    } else {
        memo[i] = fib_memo(i - 1) + fib_memo(i - 2);
    }
    hesaplanan++;
    return memo[i];
}

// 3) Tablo (aşağıdan yukarıya): tablo[0..n], Θ(n) zaman ve bellek.
// std::vector belleğini kendisi yönetir (RAII).
static std::vector<long long> fib_tablo(int n)
{
    std::vector<long long> tablo(n + 2);
    tablo[0] = 0;
    tablo[1] = 1;
    for (int i = 2; i <= n; i++) {
        tablo[i] = tablo[i - 1] + tablo[i - 2];
    }
    return tablo;
}

// 4) İki değişken: yalnız son iki değer tutulur, O(1) bellek
static long long fib_iki(int n)
{
    long long onceki = 0, simdiki = 1;     // F(0), F(1)
    if (n == 0) {
        return 0;
    }
    for (int i = 2; i <= n; i++) {
        long long sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

// std::uint64_t ile F(n); taşacaksa 0 döndürür ve tasti = true yapar
static std::uint64_t fib_u64(int n, bool& tasti)
{
    const std::uint64_t UST = std::numeric_limits<std::uint64_t>::max();
    std::uint64_t onceki = 0, simdiki = 1;
    tasti = false;
    if (n == 0) {
        return 0;
    }
    for (int i = 2; i <= n; i++) {
        if (onceki > UST - simdiki) {      // toplamadan ÖNCE denetim
            tasti = true;
            return 0;
        }
        std::uint64_t sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

// F(n) mod 10^9 + 7, iki değişkenle: her toplamadan sonra mod
static std::uint64_t fib_mod(long n)
{
    std::uint64_t onceki = 0, simdiki = 1;
    if (n == 0) {
        return 0;
    }
    for (long i = 2; i <= n; i++) {
        std::uint64_t sonraki = (onceki + simdiki) % MOD;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return simdiki;
}

static void memo_sifirla(int n)
{
    for (int i = 0; i <= n; i++) {
        memo[i] = -1;
    }
    cagri = 0;
    hesaplanan = 0;
}

int main()
{
    const std::vector<int> ns = {0, 1, 2, 5, 10, 15, 20, 25};
    const std::vector<long long> tablo = fib_tablo(MAKS_N - 10);

    std::cout << "1) Saf özyineleme: çağrı sayısı = 2·F(n+1) − 1 mi?\n";
    std::cout << "   n       F(n)      çağrı  2·F(n+1)−1  eşit\n";
    long long onceki_cagri = 0;
    for (int n : ns) {
        cagri = 0;
        long long f = fib_saf(n);
        long long beklenen = 2 * tablo[n + 1] - 1;
        std::cout << "  " << std::setw(2) << n << ' ' << std::setw(10) << f
                  << ' ' << std::setw(10) << cagri << ' ' << std::setw(11)
                  << beklenen << "  " << (cagri == beklenen ? "evet"
                                                          : "HAYIR")
                  << '\n';
    }
    cagri = 0;
    fib_saf(24);
    onceki_cagri = cagri;
    cagri = 0;
    fib_saf(25);
    std::cout << "  çağrı(25) / çağrı(24) = " << std::fixed
              << std::setprecision(4)
              << static_cast<double>(cagri) / onceki_cagri
              << "  (φ ≈ 1.6180: Θ(φ^n) büyüme)\n";

    std::cout << "\n2) Memo (yukarıdan aşağıya), \"hesaplanmadı\" = -1\n";
    std::cout << "   n       F(n)  çağrı  hesaplanan  not isabeti\n";
    for (std::size_t k = 2; k < ns.size(); k++) {
        int n = ns[k];
        memo_sifirla(n);
        long long f = fib_memo(n);
        std::cout << "  " << std::setw(2) << n << ' ' << std::setw(10) << f
                  << ' ' << std::setw(6) << cagri << ' ' << std::setw(11)
                  << hesaplanan << ' ' << std::setw(12)
                  << cagri - hesaplanan << '\n';
    }
    memo_sifirla(6);
    fib_memo(6);
    std::cout << "  fib_memo(6) sonrası memo[0..6] =";
    for (int i = 0; i <= 6; i++) {
        std::cout << ' ' << memo[i];
    }
    std::cout << "\n  (n >= 2 için çağrı = 2n − 1, hesaplanan = n + 1)\n";

    std::cout << "\n3) Tablo (aşağıdan yukarıya): tablo[i] = tablo[i-1] + "
                 "tablo[i-2]\n  i   :";
    for (int i = 0; i <= 15; i++) {
        std::cout << ' ' << std::setw(4) << i;
    }
    std::cout << "\n  F(i):";
    for (int i = 0; i <= 15; i++) {
        std::cout << ' ' << std::setw(4) << tablo[i];
    }
    std::cout << "\n  n = 25: hücre = n + 1 = 26, F(25) = " << tablo[25]
              << '\n';

    std::cout << "\n4) İki değişken (O(1) bellek): F(25) = " << fib_iki(25)
              << ", F(90) = " << fib_iki(90) << '\n';
    bool dogru = true;
    for (int n = 0; n <= 90; n++) {
        if (fib_iki(n) != tablo[n]) {
            dogru = false;
        }
    }
    std::cout << "  n = 0..90 için iki değişken = tablo: "
              << (dogru ? "evet" : "HAYIR") << '\n';

    std::cout << "\n5) Büyük n: uint64_t sınırı (2^64 − 1 = "
              << std::numeric_limits<std::uint64_t>::max() << ")\n";
    for (int n = 92; n <= 94; n++) {
        bool tasti;
        std::uint64_t f = fib_u64(n, tasti);
        if (tasti) {
            std::cout << "  F(" << n << "): uint64_t'ye SIĞMAZ (toplama "
                         "öncesi denetim)\n";
        } else {
            std::cout << "  F(" << n << ") = " << f << '\n';
        }
    }

    std::cout << "\n6) mod 10^9 + 7 ile (iki değişken, her adımda mod)\n";
    for (long n : {94L, 100L, 1000L, 1000000L}) {
        std::cout << "  F(" << n << ") mod 1000000007 = " << fib_mod(n)
                  << '\n';
    }
    return 0;
}

// Kütüphane karşılığı: yok (C). C++ — yok; Python — functools.cache /
// lru_cache dekoratörü memo'yu kendisi tutar (Dil Penceresi, kavram/).

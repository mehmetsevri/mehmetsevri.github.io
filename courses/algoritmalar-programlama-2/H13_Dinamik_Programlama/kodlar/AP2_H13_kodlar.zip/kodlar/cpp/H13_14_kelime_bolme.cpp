/* H13_14_kelime_bolme.cpp — AP-2 Hafta 13 · Örnek 14 (★★★, meydan okuma)
 * Amaç    : Kelime bölme (önek DP'si): boşluksuz yazılmış bir dizgi
 *           sözlükteki sözcüklere bölünebilir mi, kaç yolla, hangi
 *           bölmeyle? Sözlük: Ömer Seyfettin metinlerinden çıkarılmış
 *           liste (stdin, Örnek 9 ile aynı); arama std::unordered_set (H10)
 * DP      : durum ok[i] = s[0..i) sözcüklere bölünebilir mi; say[i] = kaç
 *           yolla · geçiş ok[i] = VAR j: ok[j] VE s[j..i) sözlükte
 *           (i − j <= en uzun sözcük); say[i] = Σ say[j] · temel ok[0] =
 *           doğru, say[0] = 1 · sıra i = 1..n artan, içte j artan · cevap
 *           ok[n], say[n] · geri çıkarma son[i] = koşulu sağlayan EN KÜÇÜK
 *           j (son sözcük en uzun olan); i = n, son[n], … 0
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_14_kelime_bolme.cpp -o H13_14_kelime_bolme
 * Çalıştır: ./H13_14_kelime_bolme \
 *           < ../girdiler/H13_14_kelime_bolme.txt
 * Eşleri  : c/H13_14_kelime_bolme.c · python/H13_14_kelime_bolme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>

static std::unordered_set<std::string> sozluk;   // H10: karma kümesi
static int en_uzun = 0;            // en uzun sözcük (bayt)
static long long sorgu = 0;        // sözlük sorgusu sayısı

// Sözlükte var mı? (karma tablosu araması, ortalama O(uzunluk))
static bool sozlukte_mi(const std::string& s, int j, int uzunluk)
{
    sorgu++;
    return sozluk.count(s.substr(j, uzunluk)) > 0;
}

static std::vector<bool> ok;
static std::vector<int> son;
static std::vector<long long> say;

// Önek DP'si: ok, son, say doldurulur
static bool kelime_bol(const std::string& s)
{
    const int n = static_cast<int>(s.size());
    ok.assign(n + 1, false);
    son.assign(n + 1, -1);
    say.assign(n + 1, 0);
    ok[0] = true;                              // boş önek
    say[0] = 1;
    for (int i = 1; i <= n; i++) {
        int j0 = i - en_uzun > 0 ? i - en_uzun : 0;
        for (int j = j0; j < i; j++) {
            if (ok[j] && sozlukte_mi(s, j, i - j)) {
                if (!ok[i]) {
                    son[i] = j;                // en küçük j
                }
                ok[i] = true;
                say[i] += say[j];
            }
        }
    }
    return ok[n];
}

// son[] zincirini izleyip bölmeyi baştan sona yazar
static void bolme_yaz(const std::string& s)
{
    std::vector<int> kes;
    for (int i = static_cast<int>(s.size()); i > 0; i = son[i]) {
        kes.push_back(i);
    }
    int bas = 0;
    for (std::size_t t = kes.size(); t-- > 0;) {
        if (t + 1 < kes.size()) {
            std::cout << " + ";
        }
        std::cout << s.substr(bas, kes[t] - bas);
        bas = kes[t];
    }
}

// Bütün bölmeler (küçük sayılar için): i'ye biten son sözcükten geriye
static std::vector<int> kesimler;
static void hepsini_listele(const std::string& s, int i)
{
    if (i == 0) {
        std::cout << "    ";
        int bas = 0;
        for (std::size_t t = kesimler.size(); t-- > 0;) {
            if (t + 1 < kesimler.size()) {
                std::cout << " + ";
            }
            std::cout << s.substr(bas, kesimler[t] - bas);
            bas = kesimler[t];
        }
        std::cout << '\n';
        return;
    }
    int j0 = i - en_uzun > 0 ? i - en_uzun : 0;
    for (int j = j0; j < i; j++) {
        if (ok[j] && sozlukte_mi(s, j, i - j)) {
            kesimler.push_back(i);
            hepsini_listele(s, j);
            kesimler.pop_back();
        }
    }
}

int main()
{
    std::string satir;
    while (std::getline(std::cin, satir)) {
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (!satir.empty()) {
            sozluk.insert(satir);
            if (static_cast<int>(satir.size()) > en_uzun) {
                en_uzun = static_cast<int>(satir.size());
            }
        }
    }
    if (sozluk.empty()) {
        std::cerr << "sözlük boş (girdi: kelime listesi)\n";
        return 1;
    }
    std::cout << "1) Sözlük: " << sozluk.size()
              << " sözcük (stdin), en uzun sözcük " << en_uzun
              << " bayt\n";
    std::cout << "  ok[i] = VAR j: ok[j] ve s[j..i) sözlükte (i - j <= "
              << en_uzun << "); konumlar BAYT\n";

    std::string s = "karanlıkiniçinde";
    int n = static_cast<int>(s.size());
    sorgu = 0;
    bool b = kelime_bol(s);
    std::cout << "\n2) s = \"" << s << "\" (" << n << " bayt)\n";
    std::cout << "  ok[i] doğru olan i (son[i]):";
    for (int i = 0; i <= n; i++) {
        if (ok[i]) {
            std::cout << ' ' << i << '(' << son[i] << ')';
        }
    }
    std::cout << "\n  bölünebilir: " << (b ? "evet" : "HAYIR")
              << "; bölme sayısı say[" << n << "] = " << say[n]
              << "; sözlük sorgusu = " << sorgu << '\n';
    std::cout << "  seçilen (son[] zinciri, son sözcük en uzun): ";
    bolme_yaz(s);
    std::cout << "\n  bütün bölmeler:\n";
    hepsini_listele(s, n);

    std::cout << "\n3) Başka dizgiler\n";
    const std::vector<std::string> dizgiler = {
        "gecegündüzçalışan", "dükkânındatekbaşına", "bugünbirdiyetvar",
        "padişahferman", "kılıçlarınıçekti"};
    for (const std::string& d : dizgiler) {
        sorgu = 0;
        b = kelime_bol(d);
        std::cout << "  " << d << ": ";
        if (b) {
            std::cout << say[d.size()] << " bölme; ";
            bolme_yaz(d);
        } else {
            std::cout << "BÖLÜNEMEZ";
        }
        std::cout << "  (sorgu = " << sorgu << ")\n";
    }
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python). Sözlük araması C'de elle
// ikili arama (H4); C++'ta std::unordered_set, Python'da set (H10).

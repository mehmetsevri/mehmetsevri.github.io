/* H13_15_matris_zinciri.cpp — AP-2 Hafta 13 · Örnek 15 (★★★, meydan okuma)
 * Amaç    : Matris zinciri çarpımı (aralık DP'si): A1·A2·…·An çarpımı için
 *           skaler çarpım sayısını en aza indiren parantezleme; m ve s
 *           tabloları, parantezlemenin geri çıkarılması; kaba kuvvet
 *           özyinelemeyle (3^(n−1) çağrı) ve soldan sağa çarpımla kıyas
 * DP      : durum m[i][j] = Ai..Aj çarpımının en az skaler çarpımı (Ai:
 *           p[i−1] × p[i]) · geçiş m[i][j] = min_{i<=k<j} m[i][k] +
 *           m[k+1][j] + p[i−1]·p[k]·p[j] · temel m[i][i] = 0 · sıra
 *           zincir uzunluğu l = 2..n (kısa aralıklar önce), i artan ·
 *           cevap m[1][n] · geri çıkarma s[i][j] = en iyi k (eşitlikte EN
 *           KÜÇÜK k); parantez(i, j) = (parantez(i, s) parantez(s+1, j))
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_15_matris_zinciri.cpp -o H13_15_matris_zinciri
 * Çalıştır: ./H13_15_matris_zinciri
 * Eşleri  : c/H13_15_matris_zinciri.c · python/H13_15_matris_zinciri.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

using Dizi = std::vector<int>;

static std::vector<std::vector<long long>> m;
static std::vector<std::vector<int>> s;
static long long denenen_k = 0;    // iç döngü adımı
static long long cagri = 0;        // kaba kuvvet çağrısı
const long long SONSUZ = std::numeric_limits<long long>::max();

// Aralık DP'si: m[1..n][1..n], s[1..n][1..n]
static long long matris_zinciri(const Dizi& p)
{
    const int n = static_cast<int>(p.size()) - 1;
    m.assign(n + 1, std::vector<long long>(n + 1, 0));   // m[i][i] = 0
    s.assign(n + 1, std::vector<int>(n + 1, 0));
    for (int l = 2; l <= n; l++) {             // zincir uzunluğu
        for (int i = 1; i + l - 1 <= n; i++) {
            int j = i + l - 1;
            m[i][j] = SONSUZ;
            for (int k = i; k < j; k++) {
                denenen_k++;
                long long q = m[i][k] + m[k + 1][j] +
                              static_cast<long long>(p[i - 1]) * p[k] * p[j];
                if (q < m[i][j]) {             // eşitlikte küçük k
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }
    return m[1][n];
}

static std::string parantez(int i, int j)
{
    if (i == j) {
        return "A" + std::to_string(i);
    }
    return "(" + parantez(i, s[i][j]) + parantez(s[i][j] + 1, j) + ")";
}

// Kâhin: kaba kuvvet özyineleme — bütün bölme noktaları, not alma yok
static long long kaba(const Dizi& p, int i, int j)
{
    cagri++;
    if (i == j) {
        return 0;
    }
    long long en = SONSUZ;
    for (int k = i; k < j; k++) {
        long long q = kaba(p, i, k) + kaba(p, k + 1, j) +
                      static_cast<long long>(p[i - 1]) * p[k] * p[j];
        if (q < en) {
            en = q;
        }
    }
    return en;
}

// Soldan sağa: (((A1 A2) A3) ...) maliyeti
static long long soldan_saga(const Dizi& p)
{
    long long toplam = 0;
    for (std::size_t k = 2; k < p.size(); k++) {
        toplam += static_cast<long long>(p[0]) * p[k - 1] * p[k];
    }
    return toplam;
}

// Parantezleme sayısı P(n) = Σ P(k) P(n−k) (Catalan sayısı C(n−1))
static long long parantezleme_sayisi(int n)
{
    std::vector<long long> P(n + 1, 0);
    P[1] = 1;
    for (int t = 2; t <= n; t++) {
        for (int k = 1; k < t; k++) {
            P[t] += P[k] * P[t - k];
        }
    }
    return P[n];
}

static void coz_ve_yaz(const Dizi& p, bool tablolari_yaz)
{
    const int n = static_cast<int>(p.size()) - 1;
    denenen_k = 0;
    long long en = matris_zinciri(p);
    if (tablolari_yaz) {
        std::cout << "  m[i][j] (en az skaler çarpım; i > j boş)\n    i\\j";
        for (int j = 1; j <= n; j++) {
            std::cout << ' ' << std::setw(7) << j;
        }
        std::cout << '\n';
        for (int i = 1; i <= n; i++) {
            std::cout << "  " << std::setw(4) << i << ' ';
            for (int j = 1; j <= n; j++) {
                if (j < i) {
                    std::cout << "        ";
                } else {
                    std::cout << ' ' << std::setw(7) << m[i][j];
                }
            }
            std::cout << '\n';
        }
        std::cout << "  s[i][j] (en iyi bölme k)\n    i\\j";
        for (int j = 2; j <= n; j++) {
            std::cout << ' ' << std::setw(3) << j;
        }
        std::cout << '\n';
        for (int i = 1; i < n; i++) {
            std::cout << "  " << std::setw(4) << i << ' ';
            for (int j = 2; j <= n; j++) {
                if (j <= i) {
                    std::cout << "    ";
                } else {
                    std::cout << ' ' << std::setw(3) << s[i][j];
                }
            }
            std::cout << '\n';
        }
    }
    long long sol = soldan_saga(p);
    std::cout << "  en az = m[1][" << n << "] = " << en << "; parantezleme: "
              << parantez(1, n) << '\n';
    std::cout << "  soldan sağa çarpım = " << sol << " (" << std::fixed
              << std::setprecision(2) << static_cast<double>(sol) / en
              << " kat)\n";
    std::cout << "  DP: hücre (i <= j) = " << n * (n + 1) / 2
              << ", denenen k = " << denenen_k << " = (n^3 - n)/6\n";
    cagri = 0;
    long long k = kaba(p, 1, n);
    std::cout << "  kaba kuvvet: " << cagri << " çağrı (= 3^(n-1)), sonuç "
              << k << " (" << (k == en ? "aynı" : "FARKLI")
              << "); parantezleme sayısı = " << parantezleme_sayisi(n)
              << '\n';
}

int main()
{
    const Dizi p1 = {30, 35, 15, 5, 10, 20, 25};
    std::cout << "1) p = {30, 35, 15, 5, 10, 20, 25} (Cormen vd.): A1..A6, "
                 "Ai = p[i-1] x p[i]\n";
    coz_ve_yaz(p1, true);

    rastgele_tohum(9);
    const Dizi p2 = rastgele_dizi(13, 5, 50);
    std::cout << "\n2) 12 matris, boyutlar (tohum 9, 5..50): p =";
    for (int x : p2) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';
    coz_ve_yaz(p2, false);
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python). NumPy'nin
// numpy.linalg.multi_dot'u aynı DP ile çarpma sırası seçer (ders dışı;
// yalnız standart kütüphane kullanılır).

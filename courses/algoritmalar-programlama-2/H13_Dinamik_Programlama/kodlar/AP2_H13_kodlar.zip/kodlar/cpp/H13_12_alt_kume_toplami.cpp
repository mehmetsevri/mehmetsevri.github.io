/* H13_12_alt_kume_toplami.cpp — AP-2 Hafta 13 · Örnek 12 (★★)
 * Amaç    : Alt küme toplamı iki stratejiyle: H3'ün budamalı geri izlemesi
 *           (düğüm sayısı) ve DP (bool tablo + sayım tablosu; hücre
 *           sayısı). Aynı girdi (H3 Örnek 8: n = 18, tohum 42, 1..40);
 *           çözüm sayıları birebir aynı; n ve hedefe göre karşılaştırma
 * DP      : durum var[i][t] = ilk i sayının bir alt kümesinin toplamı t
 *           olabilir mi; say[i][t] = kaç alt küme · geçiş var[i][t] =
 *           var[i−1][t] VEYA (a_i <= t VE var[i−1][t − a_i]); say[i][t] =
 *           say[i−1][t] + say[i−1][t − a_i] · temel var[0][0] = 1,
 *           say[0][0] = 1, diğerleri 0 · sıra i artan, t artan · cevap
 *           var[n][T], say[n][T] · geri çıkarma i = n..1: var[i−1][t]
 *           doğruysa a_i ALINMAZ (eşitlikte almadan), yoksa alınır
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_12_alt_kume_toplami.cpp -o H13_12_alt_kume_toplami
 * Çalıştır: ./H13_12_alt_kume_toplami
 * Eşleri  : c/H13_12_alt_kume_toplami.c ·
 *           python/H13_12_alt_kume_toplami.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

// --- H3 Örnek 8: budamalı geri izleme ("toplam aşıldı") ---------------
static std::vector<int> a;
static long long hedef;
static long long ziyaret = 0;      // ziyaret edilen düğüm (çağrı)
static long long cozum_sayisi = 0;

static void budamali(std::size_t i, long long toplam)
{
    ziyaret++;
    if (toplam > hedef) {
        return;                    // torunların hepsi de aşar (a_i > 0)
    }
    if (i == a.size()) {
        if (toplam == hedef) {
            cozum_sayisi++;
        }
        return;
    }
    budamali(i + 1, toplam);
    budamali(i + 1, toplam + a[i]);
}

// --- DP: bool tablo + sayım tablosu (satır i: ilk i sayı) --------------
static std::vector<std::vector<bool>> var_t;  // (n+1) x (T+1)
static std::vector<std::vector<long long>> say_t;
static long long hucre = 0;

static void dp_doldur(int T)
{
    const std::size_t n = a.size();
    var_t.assign(n + 1, std::vector<bool>(T + 1, false));
    say_t.assign(n + 1, std::vector<long long>(T + 1, 0));
    var_t[0][0] = true;                        // boş küme: toplam 0
    say_t[0][0] = 1;
    hucre = T + 1;                             // satır 0
    for (std::size_t i = 1; i <= n; i++) {
        int x = a[i - 1];
        for (int t = 0; t <= T; t++) {
            var_t[i][t] = var_t[i - 1][t];                    // almadan
            say_t[i][t] = say_t[i - 1][t];
            if (x <= t) {                                     // alarak
                var_t[i][t] = var_t[i][t] || var_t[i - 1][t - x];
                say_t[i][t] += say_t[i - 1][t - x];
            }
            hucre++;
        }
    }
}

// Bir çözüm: i = n..1; var[i-1][t] doğruysa almadan (eşitlikte almadan)
static std::vector<int> geri_cikar(int T)
{
    std::vector<int> secilen;                  // sondan başa sıralı
    int t = T;
    for (std::size_t i = a.size(); i >= 1; i--) {
        if (!var_t[i - 1][t]) {
            secilen.push_back(a[i - 1]);
            t -= a[i - 1];
        }
    }
    return secilen;
}

static void dizi_kur(int adet, int tohum)
{
    rastgele_tohum(static_cast<std::uint64_t>(tohum));
    a = rastgele_dizi(adet, 1, 40);
}

static void yaz_kume(const std::vector<int>& secilen)
{
    std::cout << '{';
    for (std::size_t x = secilen.size(); x-- > 0;) {
        std::cout << secilen[x] << (x > 0 ? ", " : "");
    }
    std::cout << '}';
}

int main()
{
    a = {5, 4, 3, 2};
    hedef = 7;
    std::cout << "1) a = {5, 4, 3, 2}, hedef = 7 (H3 Örnek 8)\n";
    dp_doldur(7);
    std::cout << "  var[i][t] (1 = ilk i sayıyla t toplamı yapılabilir)\n";
    std::cout << "  t        :";
    for (int t = 0; t <= 7; t++) {
        std::cout << ' ' << std::setw(2) << t;
    }
    std::cout << '\n';
    for (std::size_t i = 0; i <= a.size(); i++) {
        if (i == 0) {
            std::cout << "  i = 0    :";
        } else {
            std::cout << "  i = " << i << " (" << a[i - 1] << "):";
        }
        for (int t = 0; t <= 7; t++) {
            std::cout << ' ' << std::setw(2) << var_t[i][t];
        }
        std::cout << '\n';
    }
    std::vector<int> secilen = geri_cikar(7);
    std::cout << "  say[4][7] = " << say_t[4][7]
              << " alt küme; bir çözüm (eşitlikte almadan): ";
    yaz_kume(secilen);
    std::cout << '\n';
    long long dp_hucre = hucre;
    ziyaret = 0;
    cozum_sayisi = 0;
    budamali(0, 0);
    std::cout << "  geri izleme: " << cozum_sayisi << " çözüm, " << ziyaret
              << " düğüm; DP: " << dp_hucre << " hücre\n";

    dizi_kur(18, 42);
    long long toplam_a = 0;
    std::cout << "\n2) H3'ün girdisi: n = 18, a (tohum 42, 1..40) =";
    for (int x : a) {
        std::cout << ' ' << x;
        toplam_a += x;
    }
    std::cout << "\n   toplam = " << toplam_a << '\n';
    std::cout << "  hedef  yöntem             çözüm  düğüm/hücre  bir "
                 "çözüm\n";
    for (long long h : {50LL, toplam_a / 2}) {
        hedef = h;
        ziyaret = 0;
        cozum_sayisi = 0;
        budamali(0, 0);
        std::cout << "  " << std::setw(5) << hedef << "  geri izleme (H3)  "
                  << std::setw(6) << cozum_sayisi << "  " << std::setw(11)
                  << ziyaret << '\n';
        dp_doldur(static_cast<int>(hedef));
        secilen = geri_cikar(static_cast<int>(hedef));
        std::cout << "  " << std::setw(5) << hedef << "  DP (var + say)    "
                  << std::setw(6) << say_t[a.size()][hedef] << "  "
                  << std::setw(11) << hucre << "  ";
        yaz_kume(secilen);
        std::cout << '\n';
    }

    std::cout << "\n3) n'ye göre (hedef = toplam / 2; a: aynı LCG dizisinin "
                 "ilk n öğesi)\n";
    std::cout << "   n  toplam  hedef  kaba kuvvet düğümü  geri izleme "
                 "düğümü  DP hücresi  çözüm\n";
    for (int adet = 10; adet <= 18; adet += 2) {
        dizi_kur(adet, 42);
        toplam_a = 0;
        for (int x : a) {
            toplam_a += x;
        }
        hedef = toplam_a / 2;
        ziyaret = 0;
        cozum_sayisi = 0;
        budamali(0, 0);
        dp_doldur(static_cast<int>(hedef));
        long long dp_say = say_t[a.size()][hedef];
        std::cout << "  " << std::setw(2) << adet << "  " << std::setw(6)
                  << toplam_a << "  " << std::setw(5) << hedef << "  "
                  << std::setw(18) << (1LL << (adet + 1)) - 1 << "  "
                  << std::setw(18) << ziyaret << "  " << std::setw(10)
                  << hucre << "  " << std::setw(5) << cozum_sayisi
                  << (dp_say == cozum_sayisi ? "" : " FARKLI") << '\n';
    }
    std::cout << "  (kaba kuvvet düğümü = 2^(n+1) - 1; DP hücresi = "
                 "(n+1)(hedef+1))\n";
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python). Kâhin: H3 Örnek 5'in bit
// maskesi taraması; burada iki bağımsız yöntemin sayımları karşılaştırılır.

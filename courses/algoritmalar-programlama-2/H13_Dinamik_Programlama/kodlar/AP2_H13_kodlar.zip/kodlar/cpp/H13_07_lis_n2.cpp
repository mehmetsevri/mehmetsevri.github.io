/* H13_07_lis_n2.cpp — AP-2 Hafta 13 · Örnek 7 (★★)
 * Amaç    : En uzun (kesin) artan alt dizi, O(n²) DP; ebeveyn dizisiyle
 *           dizinin geri çıkarılması; kâhin: bütün alt kümeler (2^n)
 * DP      : durum uz[i] = a[i] ile BİTEN en uzun artan alt dizinin
 *           uzunluğu · geçiş uz[i] = 1 + max{uz[j] : j < i, a[j] < a[i]}
 *           · temel uz[i] = 1, ebeveyn[i] = −1 · sıra i = 0..n−1 artan,
 *           içte j = 0..i−1 · cevap max uz[i] · geri çıkarma ebeveyn
 *           zinciri. Eşitlik: j artan dolaşılır, yalnız KESİN büyükte
 *           güncellenir (en küçük j); sonda en küçük i seçilir
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_07_lis_n2.cpp -o H13_07_lis_n2
 * Çalıştır: ./H13_07_lis_n2
 * Eşleri  : c/H13_07_lis_n2.c · python/H13_07_lis_n2.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0;

// uz ve ebeveyn doldurulur; dönen: en uzun alt dizinin son indisi
static int lis_n2(const std::vector<int>& a, std::vector<int>& uz,
                  std::vector<int>& ebeveyn)
{
    const int n = static_cast<int>(a.size());
    uz.assign(n, 1);                           // temel: yalnız a[i]
    ebeveyn.assign(n, -1);
    int son = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            karsilastirma++;
            if (a[j] < a[i] && uz[j] + 1 > uz[i]) {
                uz[i] = uz[j] + 1;
                ebeveyn[i] = j;
            }
        }
        if (uz[i] > uz[son]) {                 // eşitlikte küçük i
            son = i;
        }
    }
    return son;
}

// Ebeveyn zincirini izleyip indisleri BAŞTAN SONA döndürür
static std::vector<int> geri_cikar(const std::vector<int>& ebeveyn, int son)
{
    std::vector<int> indis;
    for (int i = son; i != -1; i = ebeveyn[i]) {
        indis.push_back(i);
    }
    for (std::size_t x = 0, y = indis.size() - 1; x < y; x++, y--) {
        std::swap(indis[x], indis[y]);         // ters çevir
    }
    return indis;
}

// Kâhin: 2^n bit maskesi (H3 Örnek 5), kesin artan en uzun alt küme
static int kahin(const std::vector<int>& a)
{
    const int n = static_cast<int>(a.size());
    int en_iyi = 0;
    for (long maske = 1; maske < (1L << n); maske++) {
        int onceki = 0, uzunluk = 0;
        bool artan = true;
        for (int i = 0; i < n && artan; i++) {
            if (maske & (1L << i)) {
                if (uzunluk > 0 && a[i] <= onceki) {
                    artan = false;
                }
                onceki = a[i];
                uzunluk++;
            }
        }
        if (artan && uzunluk > en_iyi) {
            en_iyi = uzunluk;
        }
    }
    return en_iyi;
}

static void yaz_satir(const std::string& ad, const std::vector<int>& x)
{
    std::cout << "  " << std::left << std::setw(8) << ad << std::right
              << ':';
    for (int v : x) {
        std::cout << ' ' << std::setw(3) << v;
    }
    std::cout << '\n';
}

static int coz_ve_yaz(const std::vector<int>& a, bool ayrintili)
{
    const int n = static_cast<int>(a.size());
    std::vector<int> uz, ebeveyn;
    karsilastirma = 0;
    int son = lis_n2(a, uz, ebeveyn);
    if (ayrintili) {
        std::vector<int> sira(n);
        for (int i = 0; i < n; i++) {
            sira[i] = i;
        }
        yaz_satir("i", sira);
        yaz_satir("a[i]", a);
        yaz_satir("uz[i]", uz);
        yaz_satir("ebeveyn", ebeveyn);
    }
    const std::vector<int> indis = geri_cikar(ebeveyn, son);
    std::cout << "  en uzun: uz = " << uz[son] << ", son indis " << son
              << " (eşitlikte en küçük indis)\n";
    std::cout << "  geri çıkarma (ebeveyn zinciri):";
    for (std::size_t x = indis.size(); x-- > 0;) {
        std::cout << (x + 1 < indis.size() ? " -> " : " ") << indis[x];
    }
    std::cout << "\n  alt dizi:";
    for (int i : indis) {
        std::cout << ' ' << a[i];
    }
    std::cout << "   (indisler:";
    for (int i : indis) {
        std::cout << ' ' << i;
    }
    std::cout << ")\n  karşılaştırma = " << karsilastirma
              << " = n(n-1)/2 = " << n * (n - 1) / 2 << '\n';
    return uz[son];
}

int main()
{
    const std::vector<int> a1 = {5, 2, 8, 6, 3, 6, 9, 7};
    std::cout << "1) a = {5, 2, 8, 6, 3, 6, 9, 7} (n = 8)\n";
    coz_ve_yaz(a1, true);

    rastgele_tohum(42);
    const std::vector<int> a2 = rastgele_dizi(16, 1, 50);
    std::cout << "\n2) Rastgele a (tohum 42, n = 16, 1..50):";
    for (int v : a2) {
        std::cout << ' ' << v;
    }
    std::cout << '\n';
    int uzunluk = coz_ve_yaz(a2, true);
    int k = kahin(a2);
    std::cout << "  kâhin (2^16 alt küme taraması): " << k << " -> "
              << (k == uzunluk ? "aynı" : "FARKLI") << '\n';

    std::cout << "\n3) Sınır durumları (n = 8)\n";
    std::vector<int> artan(8), azalan(8), esit(8, 5);
    for (int i = 0; i < 8; i++) {
        artan[i] = i + 1;
        azalan[i] = 8 - i;
    }
    std::vector<int> uz, eb;
    int s1 = lis_n2(artan, uz, eb);
    std::cout << "  artan 1..8      : uz = " << uz[s1] << '\n';
    int s2 = lis_n2(azalan, uz, eb);
    std::cout << "  azalan 8..1     : uz = " << uz[s2] << '\n';
    int s3 = lis_n2(esit, uz, eb);
    std::cout << "  hepsi 5 (eşit)  : uz = " << uz[s3]
              << " (KESİN artan: a[j] < a[i])\n";
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python). O(n log n) sürüm: Örnek 13
// (H4 lower_bound ile "sabır sıralaması").

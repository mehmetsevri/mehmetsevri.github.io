/* H13_09_duzenleme_uzakligi.cpp — AP-2 Hafta 13 · Örnek 9 (★★★)
 * Amaç    : Düzenleme (Levenshtein) uzaklığı: tablo ve işlem dizisinin
 *           geri çıkarılması; UTF-8'de bayt ve KOD NOKTASI düzeyi farkı;
 *           "Bunu mu demek istediniz?": Ömer Seyfettin metinlerinden
 *           çıkarılmış sözlükte (stdin) en yakın k = 3 öneri
 * DP      : durum D[i][j] = a[0..i)'yı b[0..j)'ye çeviren en az işlem ·
 *           geçiş D[i][j] = min(D[i−1][j] + 1 silme, D[i][j−1] + 1 ekleme,
 *           D[i−1][j−1] + [a[i−1] != b[j−1]] değiştirme/eşleşme) · temel
 *           D[i][0] = i, D[0][j] = j · sıra satır öncelikli · cevap
 *           D[n][m] · geri çıkarma (n, m)'den; eşitlikte öncelik:
 *           eşleşme > silme > ekleme > değiştirme. Öneriler kod noktası
 *           düzeyinde; eşit uzaklıkta bayt sırası (sözlük sırası)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_09_duzenleme_uzakligi.cpp -o H13_09_duzenleme_uzakligi
 * Çalıştır: ./H13_09_duzenleme_uzakligi \
 *           < ../girdiler/H13_09_duzenleme_uzakligi.txt
 * Eşleri  : c/H13_09_duzenleme_uzakligi.c ·
 *           python/H13_09_duzenleme_uzakligi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

const int K = 3;                   // öneri sayısı

using Tablo = std::vector<std::vector<int>>;

static Tablo D;
static long long hucre = 0;        // hesaplanan tablo hücresi

// UTF-8 çözücü: bayt dizgisi → kod noktaları; geçersiz bayt tek başına
// kod noktası sayılır
static std::vector<int> utf8_coz(const std::string& s)
{
    std::vector<int> cp;
    for (std::size_t i = 0; i < s.size();) {
        unsigned char b = static_cast<unsigned char>(s[i]);
        std::size_t ek = b >= 0xF0 ? 3 : b >= 0xE0 ? 2 : b >= 0xC0 ? 1 : 0;
        int deger = ek == 3 ? b & 0x07 : ek == 2 ? b & 0x0F
                  : ek == 1 ? b & 0x1F : b;
        if (ek > 0 && i + ek >= s.size()) {
            ek = 0;                            // yarım dizi
            deger = b;
        }
        for (std::size_t t = 1; t <= ek; t++) {
            deger = (deger << 6) | (static_cast<unsigned char>(s[i + t])
                                    & 0x3F);
        }
        cp.push_back(deger);
        i += ek + 1;
    }
    return cp;
}

// Bayt düzeyi: her bayt bir "karakter"
static std::vector<int> baytlar(const std::string& s)
{
    std::vector<int> cp;
    for (unsigned char b : s) {
        cp.push_back(b);
    }
    return cp;
}

// D tablosunu doldurur (satır öncelikli)
static int uzaklik(const std::vector<int>& a, const std::vector<int>& b)
{
    const std::size_t n = a.size(), m = b.size();
    D.assign(n + 1, std::vector<int>(m + 1, 0));
    for (std::size_t i = 0; i <= n; i++) {
        D[i][0] = static_cast<int>(i);         // i silme
    }
    for (std::size_t j = 0; j <= m; j++) {
        D[0][j] = static_cast<int>(j);         // j ekleme
    }
    for (std::size_t i = 1; i <= n; i++) {
        for (std::size_t j = 1; j <= m; j++) {
            int sil = D[i - 1][j] + 1;
            int ekle = D[i][j - 1] + 1;
            int degis = D[i - 1][j - 1] + (a[i - 1] != b[j - 1]);
            int enk = sil < ekle ? sil : ekle;
            D[i][j] = degis < enk ? degis : enk;
        }
    }
    hucre += static_cast<long long>((n + 1) * (m + 1));
    return D[n][m];
}

static void cp_yaz(int c)
{
    std::string s;
    if (c < 0x80) {
        s += static_cast<char>(c);
    } else if (c < 0x800) {
        s += static_cast<char>(0xC0 | (c >> 6));
        s += static_cast<char>(0x80 | (c & 0x3F));
    } else if (c < 0x10000) {
        s += static_cast<char>(0xE0 | (c >> 12));
        s += static_cast<char>(0x80 | ((c >> 6) & 0x3F));
        s += static_cast<char>(0x80 | (c & 0x3F));
    } else {
        s += static_cast<char>(0xF0 | (c >> 18));
        s += static_cast<char>(0x80 | ((c >> 12) & 0x3F));
        s += static_cast<char>(0x80 | ((c >> 6) & 0x3F));
        s += static_cast<char>(0x80 | (c & 0x3F));
    }
    std::cout << s;
}

// İşlem dizisini geri çıkarıp BAŞTAN SONA yazar (D dolu olmalı)
static void islemleri_yaz(const std::vector<int>& a,
                          const std::vector<int>& b)
{
    std::vector<char> tur;                     // E, S, K, D
    std::vector<std::size_t> x, y;
    std::size_t i = a.size(), j = b.size();
    while (i > 0 || j > 0) {
        int d = D[i][j];
        if (i > 0 && j > 0 && a[i - 1] == b[j - 1] && d == D[i - 1][j - 1]) {
            tur.push_back('E');                // eşleşme
            i--;
            j--;
        } else if (i > 0 && d == D[i - 1][j] + 1) {
            tur.push_back('S');                // silme
            i--;
        } else if (j > 0 && d == D[i][j - 1] + 1) {
            tur.push_back('K');                // ekleme
            j--;
        } else {
            tur.push_back('D');                // değiştirme
            i--;
            j--;
        }
        x.push_back(i);
        y.push_back(j);
    }
    int sayi[4] = {0, 0, 0, 0};
    std::cout << "  işlemler:";
    for (std::size_t t = tur.size(); t-- > 0;) {
        std::cout << (t + 1 < tur.size() ? ", " : " ");
        if (tur[t] == 'E') {
            sayi[0]++;
            std::cout << "eşleş ";
            cp_yaz(a[x[t]]);
        } else if (tur[t] == 'S') {
            sayi[1]++;
            std::cout << "sil ";
            cp_yaz(a[x[t]]);
        } else if (tur[t] == 'K') {
            sayi[2]++;
            std::cout << "ekle ";
            cp_yaz(b[y[t]]);
        } else {
            sayi[3]++;
            std::cout << "değiştir ";
            cp_yaz(a[x[t]]);
            std::cout << "→";
            cp_yaz(b[y[t]]);
        }
    }
    std::cout << "\n  (eşleşme " << sayi[0] << ", silme " << sayi[1]
              << ", ekleme " << sayi[2] << ", değiştirme " << sayi[3]
              << ")\n";
}

static int uzaklik_metin(const std::string& a, const std::string& b,
                         bool kod_noktasi)
{
    if (kod_noktasi) {
        return uzaklik(utf8_coz(a), utf8_coz(b));
    }
    return uzaklik(baytlar(a), baytlar(b));
}

// En yakın K sözcük; eşit uzaklıkta sözlükte önce gelen (bayt sırası)
static void oner(const std::string& sorgu,
                 const std::vector<std::string>& sozluk, bool kod_noktasi,
                 std::vector<int>& en_iyi_i, std::vector<int>& en_iyi_d)
{
    en_iyi_i.assign(K, -1);
    en_iyi_d.assign(K, std::numeric_limits<int>::max());
    for (std::size_t w = 0; w < sozluk.size(); w++) {
        int d = uzaklik_metin(sorgu, sozluk[w], kod_noktasi);
        if (d >= en_iyi_d[K - 1]) {
            continue;                          // KESİN küçük olmalı
        }
        int p = K - 1;
        while (p > 0 && en_iyi_d[p - 1] > d) { // araya ekleme (H5)
            en_iyi_d[p] = en_iyi_d[p - 1];
            en_iyi_i[p] = en_iyi_i[p - 1];
            p--;
        }
        en_iyi_d[p] = d;
        en_iyi_i[p] = static_cast<int>(w);
    }
}

static void tablo_yaz(const std::string& a, const std::string& b)
{
    std::cout << "         ";
    for (char c : b) {
        std::cout << "  " << c;
    }
    std::cout << '\n';
    for (std::size_t i = 0; i <= a.size(); i++) {
        std::cout << "     " << (i == 0 ? ' ' : a[i - 1]);
        for (std::size_t j = 0; j <= b.size(); j++) {
            std::cout << ' ' << std::setw(2) << D[i][j];
        }
        std::cout << '\n';
    }
}

int main()
{
    std::cout << "1) a = \"kitten\", b = \"sitting\" (ASCII: bayt = "
                 "karakter)\n";
    std::vector<int> x = baytlar("kitten"), y = baytlar("sitting");
    int d = uzaklik(x, y);
    tablo_yaz("kitten", "sitting");
    std::cout << "  uzaklık = D[6][7] = " << d << "; hücre = 7 * 8 = 56\n";
    std::cout << "  (eşitlikte öncelik: eşleşme > silme > ekleme > "
                 "değiştirme)\n";
    islemleri_yaz(x, y);

    std::cout << "\n2) UTF-8: bayt mı, kod noktası mı? (Türkçe harfler 2 "
                 "bayt)\n";
    const std::vector<std::vector<std::string>> ciftler = {
        {"gunduz", "gündüz"}, {"sehre", "şehre"}, {"kılç", "kılıç"},
        {"kılç", "hıç"}, {"ş", "ğ"}};
    for (const auto& c : ciftler) {
        int db = uzaklik_metin(c[0], c[1], false);
        int dk = uzaklik_metin(c[0], c[1], true);
        std::cout << "  " << c[0] << " / " << c[1] << ": bayt = " << db
                  << ", kod noktası = " << dk << '\n';
    }
    x = utf8_coz("gunduz");
    y = utf8_coz("gündüz");
    uzaklik(x, y);
    std::cout << "  gunduz -> gündüz, kod noktası düzeyinde:\n";
    islemleri_yaz(x, y);

    std::vector<std::string> sozluk;
    std::string satir;
    while (std::getline(std::cin, satir)) {
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (!satir.empty()) {
            sozluk.push_back(satir);
        }
    }
    if (sozluk.empty()) {
        std::cerr << "sözlük boş (girdi: kelime listesi)\n";
        return 1;
    }
    std::sort(sozluk.begin(), sozluk.end());   // bayt sırası (araç)

    std::cout << "\n3) \"Bunu mu demek istediniz?\" — sözlük: "
              << sozluk.size() << " sözcük (stdin), k = " << K << '\n';
    std::cout << "  öneri: kod noktası düzeyinde; eşit uzaklıkta bayt "
                 "sırası\n";
    const std::vector<std::string> sorgular = {
        "gunduz", "sehre", "kılç", "padisah", "gozleri", "usda", "esir"};
    hucre = 0;
    for (const std::string& q : sorgular) {
        std::vector<int> ii, dd, bi, bd;
        oner(q, sozluk, true, ii, dd);
        long long kn_hucre = hucre;
        oner(q, sozluk, false, bi, bd);
        hucre = kn_hucre;
        std::cout << "  " << q << " ->";
        if (dd[0] == 0) {
            std::cout << " sözlükte VAR";
        } else {
            for (int t = 0; t < K; t++) {
                std::cout << (t > 0 ? "," : "") << ' ' << sozluk[ii[t]]
                          << " (" << dd[t] << ')';
            }
        }
        std::cout << " | bayt düzeyinde 1.: " << sozluk[bi[0]] << " ("
                  << bd[0] << ")\n";
    }
    std::cout << "  kod noktası düzeyinde hesaplanan hücre: " << hucre
              << " (7 sorgu x " << sozluk.size() << " sözcük)\n";
    return 0;
}

// Kütüphane karşılığı: yok (C, C++); Python — difflib.get_close_matches
// benzerlik oranıyla öneri verir (Levenshtein değil). Kâhin olarak
// kullanılmaz.

/* H13_04_bozuk_para_yollar.cpp — AP-2 Hafta 13 · Örnek 4 (★★)
 * Amaç    : Bozuk para: tutar kaç farklı yolla ödenir? Sayma DP'si ve döngü
 *           sırası tuzağı: dış döngü PARA → kombinasyon (sıra önemsiz),
 *           dış döngü TUTAR → permütasyon (sıra önemli). Aynı girdide
 *           farklı sayılar; listelemeyle doğrulama; büyük tutar mod 10^9+7
 * DP      : durum yol[t] = t tutarının ödeniş sayısı · geçiş yol[t] +=
 *           yol[t−c] · temel yol[0] = 1 (boş ödeme), diğerleri 0 · sıra
 *           KOMBİNASYON: her para c için t = c..S artan (para dışta);
 *           PERMÜTASYON: t = 1..S artan, içte her para (tutar dışta) ·
 *           cevap yol[S]
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_04_bozuk_para_yollar.cpp -o H13_04_bozuk_para_yollar
 * Çalıştır: ./H13_04_bozuk_para_yollar
 * Eşleri  : c/H13_04_bozuk_para_yollar.c ·
 *           python/H13_04_bozuk_para_yollar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

const int MAKS_S = 1000;
const long long MOD = 1000000007LL;

static std::vector<long long> yol(MAKS_S + 1);
static std::vector<int> secilen;   // listelemede o anki paralar

static void yaz_satir(int S)
{
    for (int t = 0; t <= S; t++) {
        std::cout << ' ' << std::setw(3) << yol[t];
    }
    std::cout << '\n';
}

// Kombinasyon: dış döngü para. c parası işlenirken yol[t], yalnız ilk
// paralarla (c dahil) yapılan ödemeleri sayar: sıra önemsiz.
static long long kombinasyon(const std::vector<int>& paralar, int S,
                             bool satirlari_yaz)
{
    yol[0] = 1;                            // temel durum
    for (int t = 1; t <= S; t++) {
        yol[t] = 0;
    }
    for (int c : paralar) {                // DIŞ: para
        for (int t = c; t <= S; t++) {     // İÇ: tutar
            yol[t] = (yol[t] + yol[t - c]) % MOD;
        }
        if (satirlari_yaz) {
            std::cout << "  para " << c << " sonrası:";
            yaz_satir(S);
        }
    }
    return yol[S];
}

// Permütasyon: dış döngü tutar. yol[t] her paranın SON adım olabildiği
// bütün dizileri sayar: 1+2 ile 2+1 ayrı sayılır.
static long long permutasyon(const std::vector<int>& paralar, int S)
{
    yol[0] = 1;                            // temel durum
    for (int t = 1; t <= S; t++) {         // DIŞ: tutar
        yol[t] = 0;
        for (int c : paralar) {            // İÇ: para
            if (c <= t) {
                yol[t] = (yol[t] + yol[t - c]) % MOD;
            }
        }
    }
    return yol[S];
}

static void yaz_secilen()
{
    std::cout << "    ";
    for (std::size_t i = 0; i < secilen.size(); i++) {
        std::cout << (i > 0 ? "+" : "") << secilen[i];
    }
    std::cout << '\n';
}

// Doğrulama 1: kombinasyonlar — paralar artmayan sırada (en büyük önce),
// en_buyuk_i: kullanılabilecek en büyük para indisi
static long long kombinasyon_listele(const std::vector<int>& paralar,
                                     int en_buyuk_i, int kalan)
{
    if (kalan == 0) {
        yaz_secilen();
        return 1;
    }
    long long say = 0;
    for (int i = en_buyuk_i; i >= 0; i--) {
        if (paralar[i] <= kalan) {
            secilen.push_back(paralar[i]);
            say += kombinasyon_listele(paralar, i, kalan - paralar[i]);
            secilen.pop_back();
        }
    }
    return say;
}

// Doğrulama 2: permütasyonlar — her adımda her para denenir
static long long permutasyon_listele(const std::vector<int>& paralar,
                                     int kalan)
{
    if (kalan == 0) {
        yaz_secilen();
        return 1;
    }
    long long say = 0;
    for (int c : paralar) {
        if (c <= kalan) {
            secilen.push_back(c);
            say += permutasyon_listele(paralar, kalan - c);
            secilen.pop_back();
        }
    }
    return say;
}

int main()
{
    const std::vector<int> p1 = {1, 2, 5};
    const int S = 5;
    std::cout << "1) Paralar {1, 2, 5}, tutar " << S
              << ": aynı geçiş, farklı döngü sırası\n";
    std::cout << "  t             :";
    for (int t = 0; t <= S; t++) {
        std::cout << ' ' << std::setw(3) << t;
    }
    std::cout << "\n  KOMBİNASYON (dış döngü para):\n";
    long long kom = kombinasyon(p1, S, true);
    long long per = permutasyon(p1, S);
    std::cout << "  PERMÜTASYON (dış döngü tutar):\n  yol[t]        :";
    yaz_satir(S);
    std::cout << "  kombinasyon = " << kom << ", permütasyon = " << per
              << "  (sıra önemli mi?)\n";

    std::cout << "\n2) Doğrulama: kombinasyonlar (büyük para önce)\n";
    long long ks = kombinasyon_listele(p1, 2, S);
    std::cout << "  listelenen = " << ks << '\n';
    std::cout << "  permütasyonlar (her sıra ayrı)\n";
    long long ps = permutasyon_listele(p1, S);
    std::cout << "  listelenen = " << ps << "; tablo ile aynı: "
              << (ks == kom && ps == per ? "evet" : "HAYIR") << '\n';

    std::cout << "\n3) Tutar 0..10 için iki sayım (paralar {1, 2, 5})\n";
    std::cout << "  t          :";
    for (int t = 0; t <= 10; t++) {
        std::cout << ' ' << std::setw(4) << t;
    }
    std::cout << "\n  kombinasyon:";
    for (int t = 0; t <= 10; t++) {
        std::cout << ' ' << std::setw(4) << kombinasyon(p1, t, false);
    }
    std::cout << "\n  permütasyon:";
    for (int t = 0; t <= 10; t++) {
        std::cout << ' ' << std::setw(4) << permutasyon(p1, t);
    }
    std::cout << '\n';

    const std::vector<int> p2 = {1, 5, 10, 25, 50, 100};
    std::cout << "\n4) Büyük tutar, iki sayım da mod p = 10^9 + 7: paralar "
                 "{1, 5, 10, 25, 50, 100} kuruş\n";
    for (int t : {100, 500, 1000}) {
        long long kb = kombinasyon(p2, t, false);
        long long pm = permutasyon(p2, t);
        std::cout << "  tutar " << std::setw(4) << t << ": kombinasyon = "
                  << kb << ", permütasyon = " << pm << '\n';
    }
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python); sayma DP'si elle.

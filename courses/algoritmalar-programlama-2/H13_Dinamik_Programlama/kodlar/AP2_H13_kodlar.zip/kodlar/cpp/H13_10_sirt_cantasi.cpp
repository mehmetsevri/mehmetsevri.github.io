/* H13_10_sirt_cantasi.cpp — AP-2 Hafta 13 · Örnek 10 (★★★)
 * Amaç    : 0/1 sırt çantası: (n + 1) × (W + 1) tam tablo ve seçilen
 *           nesnelerin geri çıkarılması; değer/ağırlık oranına göre
 *           açgözlünün (H12) 0/1'de yanılması; 12 dersten AKTS sınırı
 *           altında en yüksek tercih puanı, kâhin: 2^n alt küme
 * DP      : durum K[i][w] = ilk i nesneyle, w kapasitede en büyük değer ·
 *           geçiş K[i][w] = max(K[i−1][w], K[i−1][w − a_i] + d_i) (a_i <=
 *           w ise) · temel K[0][w] = 0 · sıra i = 1..n, w = 0..W
 *           (satır öncelikli) · cevap K[n][W] · geri çıkarma i = n..1:
 *           K[i][w] != K[i−1][w] ise i alındı, w −= a_i (eşitlikte
 *           ALINMADI sayılır; ilk i−1 nesneyle aynı değer elde edilir)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_10_sirt_cantasi.cpp -o H13_10_sirt_cantasi
 * Çalıştır: ./H13_10_sirt_cantasi
 * Eşleri  : c/H13_10_sirt_cantasi.c · python/H13_10_sirt_cantasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

using Tablo = std::vector<std::vector<int>>;

static long long hucre = 0;

// (n+1) x (W+1) tablo; satırlar ayrı vektörler (RAII)
static Tablo sirt_cantasi(const std::vector<int>& a,
                          const std::vector<int>& d, int W)
{
    const std::size_t n = a.size();
    Tablo K(n + 1, std::vector<int>(W + 1, 0));   // temel: nesne yok
    for (std::size_t i = 1; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            int al_ma = K[i - 1][w];
            int en_iyi = al_ma;
            if (a[i - 1] <= w) {
                int al = K[i - 1][w - a[i - 1]] + d[i - 1];
                if (al > en_iyi) {
                    en_iyi = al;
                }
            }
            K[i][w] = en_iyi;
            hucre++;
        }
    }
    return K;
}

// Seçilen nesneleri geri çıkarır (secildi[i] = true); toplam ağırlık
static int secilenler(const Tablo& K, const std::vector<int>& a, int W,
                      std::vector<bool>& secildi)
{
    const int n = static_cast<int>(a.size());
    int w = W, agirlik = 0;
    secildi.assign(n, false);
    for (int i = n; i >= 1; i--) {
        if (K[i][w] != K[i - 1][w]) {          // eşitlikte alınmadı
            secildi[i - 1] = true;
            w -= a[i - 1];
            agirlik += a[i - 1];
        }
    }
    return agirlik;
}

// Açgözlü (H12 kesirli sırt çantası sırası): d/a oranı azalan; sığanı al.
// Oran karşılaştırması tamsayıyla: d_i * a_j > d_j * a_i
static int acgozlu(const std::vector<int>& a, const std::vector<int>& d,
                   int W, std::vector<bool>& secildi)
{
    const int n = static_cast<int>(a.size());
    std::vector<int> sira(n);
    secildi.assign(n, false);
    for (int i = 0; i < n; i++) {
        sira[i] = i;
    }
    for (int i = 1; i < n; i++) {              // araya ekleme (H5)
        int x = sira[i], j = i - 1;
        while (j >= 0 && d[x] * a[sira[j]] > d[sira[j]] * a[x]) {
            sira[j + 1] = sira[j];
            j--;
        }
        sira[j + 1] = x;
    }
    int deger = 0;
    for (int i : sira) {
        if (a[i] <= W) {
            W -= a[i];
            deger += d[i];
            secildi[i] = true;
        }
    }
    return deger;
}

// Kâhin: 2^n alt küme; en büyük değer
static int kahin(const std::vector<int>& a, const std::vector<int>& d,
                 int W)
{
    const int n = static_cast<int>(a.size());
    int en_iyi = 0;
    for (long maske = 0; maske < (1L << n); maske++) {
        int agirlik = 0, deger = 0;
        for (int i = 0; i < n; i++) {
            if (maske & (1L << i)) {
                agirlik += a[i];
                deger += d[i];
            }
        }
        if (agirlik <= W && deger > en_iyi) {
            en_iyi = deger;
        }
    }
    return en_iyi;
}

static void yaz_secim(const std::vector<std::string>& ad,
                      const std::vector<bool>& secildi)
{
    bool ilk = true;
    std::cout << '{';
    for (std::size_t i = 0; i < ad.size(); i++) {
        if (secildi[i]) {
            std::cout << (ilk ? "" : ", ") << ad[i];
            ilk = false;
        }
    }
    std::cout << '}';
}

int main()
{
    std::vector<bool> secildi;
    const std::vector<std::string> ad1 = {"A", "B", "C", "D"};
    const std::vector<int> a1 = {5, 4, 6, 3}, d1 = {10, 40, 30, 50};
    const int W1 = 10;
    std::cout << "1) Nesneler (ağırlık, değer): A(5, 10) B(4, 40) C(6, 30) "
                 "D(3, 50); W = " << W1 << '\n';
    hucre = 0;
    Tablo K = sirt_cantasi(a1, d1, W1);
    std::cout << "  K[i][w]   w:";
    for (int w = 0; w <= W1; w++) {
        std::cout << ' ' << std::setw(3) << w;
    }
    std::cout << '\n';
    for (int i = 0; i <= 4; i++) {
        std::cout << "  i = " << i << ' ' << std::left << std::setw(5)
                  << (i == 0 ? "-" : ad1[i - 1]) << std::right << ':';
        for (int w = 0; w <= W1; w++) {
            std::cout << ' ' << std::setw(3) << K[i][w];
        }
        std::cout << '\n';
    }
    int ag = secilenler(K, a1, W1, secildi);
    std::cout << "  en büyük değer = K[4][" << W1 << "] = " << K[4][W1]
              << "; seçilen ";
    yaz_secim(ad1, secildi);
    std::cout << ", ağırlık " << ag << " / " << W1 << '\n';
    std::cout << "  geri çıkarma: i = 4..1, K[i][w] != K[i-1][w] ise "
                 "alındı:";
    for (int i = 4, w = W1; i >= 1; i--) {
        bool al = K[i][w] != K[i - 1][w];
        std::cout << ' ' << ad1[i - 1] << (al ? '+' : '-');
        if (al) {
            w -= a1[i - 1];
        }
    }
    std::cout << "\n  hücre = n * (W + 1) = " << hucre << '\n';

    std::cout << "\n2) Açgözlü (değer/ağırlık oranı, H12) 0/1'de yanılır\n";
    const std::vector<std::string> ad2 = {"X", "Y", "Z"};
    const std::vector<int> a2 = {10, 20, 30}, d2 = {60, 100, 120};
    std::cout << "  X(10, 60) Y(20, 100) Z(30, 120); W = 50; oranlar 6 > 5 "
                 "> 4\n";
    int dg = acgozlu(a2, d2, 50, secildi);
    std::cout << "  açgözlü: ";
    yaz_secim(ad2, secildi);
    std::cout << " = " << dg << '\n';
    K = sirt_cantasi(a2, d2, 50);
    secilenler(K, a2, 50, secildi);
    std::cout << "  DP     : ";
    yaz_secim(ad2, secildi);
    std::cout << " = " << K[3][50] << '\n';

    std::cout << "\n3) 12 ders: AKTS (ağırlık) 2..8, tercih puanı (değer) "
                 "1..20, tohum 4; üst sınır 30 AKTS\n";
    std::vector<std::string> ad3;
    std::vector<int> a3(12), d3(12);
    rastgele_tohum(4);
    for (int i = 0; i < 12; i++) {
        ad3.push_back((i < 9 ? "D0" : "D1") + std::to_string((i + 1) % 10));
        a3[i] = rastgele_aralik(2, 8);
        d3[i] = rastgele_aralik(1, 20);
    }
    std::cout << "  ";
    for (int i = 0; i < 12; i++) {
        std::cout << ad3[i] << '(' << a3[i] << ", " << d3[i] << ')'
                  << (i == 5 ? "\n  " : i < 11 ? " " : "\n");
    }
    hucre = 0;
    K = sirt_cantasi(a3, d3, 30);
    int en = K[12][30];
    ag = secilenler(K, a3, 30, secildi);
    std::cout << "  DP: puan = " << en << ", AKTS = " << ag << "; seçilen ";
    yaz_secim(ad3, secildi);
    int kh = kahin(a3, d3, 30);
    std::cout << "\n  hücre = " << hucre << "; kâhin (2^12 = 4096 alt küme) = "
              << kh << " -> " << (kh == en ? "aynı" : "FARKLI") << '\n';
    dg = acgozlu(a3, d3, 30, secildi);
    std::cout << "  açgözlü (oran): puan = " << dg << " ("
              << (dg == en ? "bu girdide en iyi" : "en iyiden düşük")
              << ")\n";
    return 0;
}

// Kütüphane karşılığı: yok (C, C++, Python); DP tablosu elle doldurulur.
// Tek satırlı sürüm: Örnek 11.

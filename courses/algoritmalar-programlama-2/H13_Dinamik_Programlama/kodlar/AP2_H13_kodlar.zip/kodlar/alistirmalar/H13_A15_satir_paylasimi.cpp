/* H13_A15_satir_paylasimi.cpp — AP-2 Hafta 13 · Alıştırma 13.15 (★★)
 * Amaç    : Diller arası okuma: Python eşinin (H13_A15_satir_paylasimi.py)
 *           C++ karşılığı. Çalıştırmadan çıktıyı yazın.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H13_A15_satir_paylasimi.cpp -o H13_A15_satir_paylasimi
 * Çalıştır: ./H13_A15_satir_paylasimi
 */
#include <iostream>
#include <vector>

using Tablo = std::vector<std::vector<int>>;

static void yaz(const char *ad, const Tablo &t)
{
    std::cout << ad << " =";
    for (const auto &satir : t) {
        std::cout << " [";
        for (std::size_t j = 0; j < satir.size(); j++) {
            std::cout << (j ? ", " : "") << satir[j];
        }
        std::cout << "]";
    }
    std::cout << "\n";
}

int main()
{
    std::vector<int> satir(3, 0);
    Tablo a(2, satir);
    Tablo b = a;
    std::vector<int> &ilk = a[0];
    ilk[1] = 5;
    b[1][2] = 7;
    yaz("a", a);
    yaz("b", b);
    std::cout << (&a[0] == &a[1]) << " " << satir[1] << "\n";
    return 0;
}

/* H13_A10_parsons_lis.c — AP-2 Hafta 13 · Alıştırma 13.10 (★★)
 * Parsons: tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar en uzun
 * (kesin) artan alt dizinin O(n²) DP fonksiyonunun KARIŞTIRILMIŞ
 * satırlarıdır; iki satır fazladır (kullanılmayacak). Doğru sıraya dizin,
 * girintiyi düzeltin; a = {5, 2, 8, 6, 3, 6, 9, 7} için dönen son indisin
 * uzunluğu 4 olmalı (Örnek 7).
 */
            if (a[j] <= a[i] && uz[j] + 1 > uz[i]) {
    }
        if (uz[i] > uz[son]) {
static int lis_n2(const int a[], int n, int uz[], int ebeveyn[])
                ebeveyn[i] = j;
        uz[i] = 1;
    return son;
            son = i;
        for (int j = 0; j < i; j++) {
                uz[i] = uz[j];
{
    int son = 0;
            if (a[j] < a[i] && uz[j] + 1 > uz[i]) {
        ebeveyn[i] = -1;
                uz[i] = uz[j] + 1;
    for (int i = 0; i < n; i++) {
}
        }
            }
        }

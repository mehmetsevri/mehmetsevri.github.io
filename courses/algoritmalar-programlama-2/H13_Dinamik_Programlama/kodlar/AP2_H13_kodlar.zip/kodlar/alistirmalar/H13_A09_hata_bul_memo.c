/* H13_A09_hata_bul_memo.c — AP-2 Hafta 13 · Alıştırma 13.9 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: engelli ızgarada (yalnız sağa ya da aşağı)
 * hedefe giden yol sayısı memoization ile hesaplanıyor. Sonuçlar doğru,
 * ama ikinci ızgarada çağrı sayısı beklenenin çok üstünde. Hatalı satırı
 * bulun, nedenini açıklayın ve düzeltin; düzeltilmiş sürümün iki ızgarada
 * kaç çağrı yapacağını önceden kestirin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_A09_hata_bul_memo.c -o H13_A09_hata_bul_memo
 * Çalıştır: ./H13_A09_hata_bul_memo
 */
#include <stdio.h>
#include <string.h>

#define R 12
#define C 12

static int engel[R][C];
static long long memo[R][C];
static long long cagri = 0;

/* (i, j)'den sağ alt köşeye giden yol sayısı */
static long long yol(int i, int j)
{
    cagri++;
    if (i >= R || j >= C || engel[i][j]) {
        return 0;
    }
    if (i == R - 1 && j == C - 1) {
        return 1;
    }
    if (memo[i][j] != 0) {
        return memo[i][j];
    }
    memo[i][j] = yol(i + 1, j) + yol(i, j + 1);
    return memo[i][j];
}

static void coz(const char *ad)
{
    memset(memo, 0, sizeof memo);
    cagri = 0;
    long long sonuc = yol(0, 0);
    printf("%s: yol sayısı = %lld, çağrı = %lld (hücre %d)\n", ad, sonuc,
           cagri, R * C);
}

int main(void)
{
    engel[5][5] = 1;
    coz("ızgara 1 (ortada bir engel)   ");
    engel[R - 2][C - 1] = 1;
    engel[R - 1][C - 2] = 1;
    coz("ızgara 2 (hedefin iki komşusu)");
    return 0;
}

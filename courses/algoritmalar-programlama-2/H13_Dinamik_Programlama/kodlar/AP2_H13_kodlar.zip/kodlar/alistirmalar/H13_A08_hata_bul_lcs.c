/* H13_A08_hata_bul_lcs.c — AP-2 Hafta 13 · Alıştırma 13.8 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: LCS uzunluğu bazı girdilerde yanlış
 * çıkıyor. Hatalı satırı bulun, çıktıdaki her yanlış değeri açıklayın ve
 * düzeltin (Örnek 8'in lcs_tablo fonksiyonuyla karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_A08_hata_bul_lcs.c -o H13_A08_hata_bul_lcs
 * Çalıştır: ./H13_A08_hata_bul_lcs
 */
#include <stdio.h>
#include <string.h>

#define MAKS 32

static int L[MAKS + 1][MAKS + 1];

static int lcs_uzunluk(const char *a, const char *b)
{
    int n = (int)strlen(a), m = (int)strlen(b);
    for (int i = 0; i <= n; i++) {
        L[i][0] = 0;
    }
    for (int j = 0; j <= m; j++) {
        L[0][j] = 0;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (a[i] == b[j]) {
                L[i][j] = L[i - 1][j - 1] + 1;
            } else if (L[i - 1][j] >= L[i][j - 1]) {
                L[i][j] = L[i - 1][j];
            } else {
                L[i][j] = L[i][j - 1];
            }
        }
    }
    return L[n][m];
}

int main(void)
{
    const char *ciftler[][3] = {{"ABCBDAB", "BDCABA", "4"},
                                {"ABC", "XYZ", "0"},
                                {"XAB", "YAB", "2"},
                                {"KAR", "KAR", "3"}};
    for (int c = 0; c < 4; c++) {
        printf("%-8s %-8s LCS = %d (beklenen %s)\n", ciftler[c][0],
               ciftler[c][1], lcs_uzunluk(ciftler[c][0], ciftler[c][1]),
               ciftler[c][2]);
    }
    return 0;
}

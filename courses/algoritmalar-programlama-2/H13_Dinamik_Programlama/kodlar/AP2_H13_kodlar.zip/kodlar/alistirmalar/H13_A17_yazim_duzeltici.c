/* H13_A17_yazim_duzeltici.c — AP-2 Hafta 13 · Atölye 2 (başlangıç programı)
 * Amaç    : "Bunu mu demek istediniz?": stdin'den sözlük (satır başına bir
 *           sözcük), komut satırından sorgular. Her sorgu için düzenleme
 *           (Levenshtein) uzaklığı en küçük k sözcük; eşitlikte bayt
 *           sırasında önce gelen. Uzaklık kod noktası düzeyinde (--bayt ile
 *           bayt düzeyinde); DP iki satırlık tamponla, Θ(m) bellek.
 *           Atölyede genişletilecek (budama, eşik, sayaçlar).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_A17_yazim_duzeltici.c -o H13_A17_yazim_duzeltici
 * Çalıştır: ./H13_A17_yazim_duzeltici [--k K] [--bayt] SORGU ... \
 *           < ../girdiler/H13_09_duzenleme_uzakligi.txt
 */
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_UZ 64
#define MAKS_K 16

static long long hucre = 0;        /* hesaplanan DP hücresi */
static long long aday = 0;         /* uzaklığı hesaplanan sözcük */

/* UTF-8 → kod noktaları (bayt_duzeyi ise her bayt bir karakter) */
static int coz(const char *metin, int bayt_duzeyi, int cp[])
{
    const unsigned char *s = (const unsigned char *)metin;
    int k = 0;
    for (int i = 0; s[i] != '\0' && k < MAKS_UZ;) {
        int ek = 0, deger = s[i];
        if (!bayt_duzeyi) {
            ek = s[i] >= 0xF0 ? 3 : s[i] >= 0xE0 ? 2 : s[i] >= 0xC0 ? 1 : 0;
            deger = ek == 3 ? s[i] & 0x07 : ek == 2 ? s[i] & 0x0F
                  : ek == 1 ? s[i] & 0x1F : s[i];
            for (int t = 1; t <= ek; t++) {
                if (s[i + t] == '\0') {       /* yarım dizi: bayt say */
                    ek = 0;
                    deger = s[i];
                    break;
                }
                deger = (deger << 6) | (s[i + t] & 0x3F);
            }
        }
        cp[k++] = deger;
        i += ek + 1;
    }
    return k;
}

/* İki satırlık Levenshtein: önceki ve şimdiki satır */
static int uzaklik(const int a[], int n, const int b[], int m)
{
    int onceki[MAKS_UZ + 1], simdiki[MAKS_UZ + 1];
    for (int j = 0; j <= m; j++) {
        onceki[j] = j;
    }
    for (int i = 1; i <= n; i++) {
        simdiki[0] = i;
        for (int j = 1; j <= m; j++) {
            int sil = onceki[j] + 1;
            int ekle = simdiki[j - 1] + 1;
            int degis = onceki[j - 1] + (a[i - 1] != b[j - 1]);
            int enk = sil < ekle ? sil : ekle;
            simdiki[j] = degis < enk ? degis : enk;
        }
        memcpy(onceki, simdiki, (size_t)(m + 1) * sizeof onceki[0]);
    }
    hucre += (long long)(n + 1) * (m + 1);
    aday++;
    return onceki[m];
}

static int karsilastir(const void *p, const void *q)
{
    return strcmp(*(char *const *)p, *(char *const *)q);
}

/* En yakın k sözcük: (uzaklık, sözlük sırası) artan; araya ekleme */
static void oner(const char *sorgu, char *sozluk[], int adet, int k,
                 int bayt_duzeyi)
{
    int q[MAKS_UZ], w[MAKS_UZ], en_i[MAKS_K], en_d[MAKS_K];
    int n = coz(sorgu, bayt_duzeyi, q);
    for (int t = 0; t < k; t++) {
        en_i[t] = -1;
        en_d[t] = INT_MAX;
    }
    hucre = 0;
    aday = 0;
    for (int s = 0; s < adet; s++) {
        int m = coz(sozluk[s], bayt_duzeyi, w);
        int d = uzaklik(q, n, w, m);
        if (d >= en_d[k - 1]) {
            continue;                         /* KESİN küçük olmalı */
        }
        int p = k - 1;
        while (p > 0 && en_d[p - 1] > d) {
            en_d[p] = en_d[p - 1];
            en_i[p] = en_i[p - 1];
            p--;
        }
        en_d[p] = d;
        en_i[p] = s;
    }
    printf("%s ->", sorgu);
    for (int t = 0; t < k && en_i[t] >= 0; t++) {
        printf("%s %s (%d)", t > 0 ? "," : "", sozluk[en_i[t]], en_d[t]);
    }
    printf("  [aday %lld, hücre %lld]\n", aday, hucre);
}

int main(int argc, char *argv[])
{
    int k = 3, bayt_duzeyi = 0, ilk = 1;
    while (ilk < argc && strncmp(argv[ilk], "--", 2) == 0) {
        if (strcmp(argv[ilk], "--bayt") == 0) {
            bayt_duzeyi = 1;
            ilk++;
        } else if (strcmp(argv[ilk], "--k") == 0 && ilk + 1 < argc) {
            char *son;
            long v = strtol(argv[ilk + 1], &son, 10);
            if (*son != '\0' || v < 1 || v > MAKS_K) {
                fprintf(stderr, "k 1..%d olmalı\n", MAKS_K);
                return 2;
            }
            k = (int)v;
            ilk += 2;
        } else {
            break;
        }
    }
    if (ilk >= argc) {
        fprintf(stderr, "Kullanım: %s [--k K] [--bayt] SORGU ... < sözlük\n",
                argv[0]);
        return 2;
    }
    static char metin[1 << 16];
    size_t uzunluk = fread(metin, 1, sizeof metin - 1, stdin);
    metin[uzunluk] = '\0';
    static char *sozluk[1 << 13];
    int adet = 0;
    for (char *p = strtok(metin, "\r\n"); p != NULL && adet < (1 << 13);
         p = strtok(NULL, "\r\n")) {
        sozluk[adet++] = p;
    }
    if (adet == 0) {
        fprintf(stderr, "sözlük boş\n");
        return 1;
    }
    qsort(sozluk, (size_t)adet, sizeof sozluk[0], karsilastir);
    printf("sözlük: %d sözcük; k = %d; %s düzeyinde\n", adet, k,
           bayt_duzeyi ? "bayt" : "kod noktası");
    for (int i = ilk; i < argc; i++) {
        oner(argv[i], sozluk, adet, k, bayt_duzeyi);
    }
    return 0;
}

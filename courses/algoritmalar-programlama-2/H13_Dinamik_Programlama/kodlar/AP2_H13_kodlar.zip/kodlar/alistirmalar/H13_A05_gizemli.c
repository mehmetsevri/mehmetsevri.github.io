/* H13_A05_gizemli.c — AP-2 Hafta 13 · Alıştırma 13.5 (★★)
 * Amaç    : Karmaşıklık belirleme: iki "gizemli" fonksiyonun iç işlem
 *           sayısını n'ye göre kestirin; sayaçlarla doğrulayın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_A05_gizemli.c -o H13_A05_gizemli
 * Çalıştır: ./H13_A05_gizemli
 */
#include <stdio.h>

#define MAKS 64

static long long sayac_a = 0, sayac_b = 0;
static long long memo_b[MAKS][MAKS];

static long long gizemli_a(int n)
{
    long long toplam = 0;
    for (int l = 1; l <= n; l++) {
        for (int i = 0; i + l <= n; i++) {
            for (int k = i; k < i + l; k++) {
                sayac_a++;
                toplam += k - i;
            }
        }
    }
    return toplam;
}

static long long gizemli_b(int i, int j)
{
    sayac_b++;
    if (i >= j) {
        return 0;
    }
    if (memo_b[i][j] != -1) {
        return memo_b[i][j];
    }
    long long x = gizemli_b(i + 1, j);
    long long y = gizemli_b(i, j - 1);
    memo_b[i][j] = (x > y ? x : y) + 1;
    return memo_b[i][j];
}

int main(void)
{
    printf("   n   sayac_a   sayac_b\n");
    for (int n = 10; n <= 40; n *= 2) {
        for (int i = 0; i < MAKS; i++) {
            for (int j = 0; j < MAKS; j++) {
                memo_b[i][j] = -1;
            }
        }
        sayac_a = 0;
        sayac_b = 0;
        gizemli_a(n);
        gizemli_b(0, n - 1);
        printf("%4d %9lld %9lld\n", n, sayac_a, sayac_b);
    }
    return 0;
}

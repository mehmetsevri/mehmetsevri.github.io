/* H13_A16_buyuk_sayi.c — AP-2 Hafta 13 · Alıştırma 13.16 (★★)
 * Amaç    : Diller arası okuma: Pascal üçgeninin tek satırlık DP'si
 *           (C(n, k) = C(n−1, k−1) + C(n−1, k)) 32 bitlik işaretsiz
 *           tamsayıyla; eş dosya H13_A16_buyuk_sayi.py aynı hesabı Python
 *           tamsayısıyla yapar. Çalıştırmadan iki çıktının hangi satırlarda
 *           ayrılacağını kestirin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_A16_buyuk_sayi.c -o H13_A16_buyuk_sayi
 * Çalıştır: ./H13_A16_buyuk_sayi
 */
#include <stdint.h>
#include <stdio.h>

#define MAKS_N 40

int main(void)
{
    uint32_t satir[MAKS_N + 1] = {1};
    for (int n = 1; n <= 36; n++) {
        for (int k = n; k >= 1; k--) {        /* tek satır: k TERS */
            satir[k] = satir[k] + satir[k - 1];
        }
        if (n >= 32) {
            printf("C(%d, %d) = %u\n", n, n / 2, (unsigned)satir[n / 2]);
        }
    }
    return 0;
}

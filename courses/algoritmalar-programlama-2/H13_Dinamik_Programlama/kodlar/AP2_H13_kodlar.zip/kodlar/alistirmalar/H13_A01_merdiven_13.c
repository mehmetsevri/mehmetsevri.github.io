/* H13_A01_merdiven_13.c — AP-2 Hafta 13 · Alıştırma 13.1 (★)
 * Amaç    : Çıktı tahmini: her adımda 1 ya da 3 basamak çıkılan merdiven.
 *           Programı çalıştırmadan çıktının iki satırını yazın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H13_A01_merdiven_13.c -o H13_A01_merdiven_13
 * Çalıştır: ./H13_A01_merdiven_13
 */
#include <stdio.h>

#define N 10

int main(void)
{
    long long yol[N + 1];
    yol[0] = 1;
    for (int i = 1; i <= N; i++) {
        yol[i] = yol[i - 1];
        if (i >= 3) {
            yol[i] += yol[i - 3];
        }
    }
    printf("i     :");
    for (int i = 0; i <= N; i++) {
        printf(" %3d", i);
    }
    printf("\nyol[i]:");
    for (int i = 0; i <= N; i++) {
        printf(" %3lld", yol[i]);
    }
    printf("\n");
    return 0;
}

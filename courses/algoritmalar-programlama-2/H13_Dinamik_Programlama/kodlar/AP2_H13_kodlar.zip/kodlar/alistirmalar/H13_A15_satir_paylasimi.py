"""H13_A15_satir_paylasimi.py — AP-2 Hafta 13 · Alıştırma 13.15 (★★)
Amaç    : Diller arası okuma: aynı 2B tablo işlemleri Python'da ve C++'ta
          (eş dosya: H13_A15_satir_paylasimi.cpp). Çalıştırmadan iki
          programın çıktısını yazın.
Çalıştır: python3 H13_A15_satir_paylasimi.py
"""


def main():
    a = [[0] * 3] * 2
    b = [[0] * 3 for _ in range(2)]
    c = [a[0][:], a[1][:]]
    a[0][1] = 5
    b[0][1] = 5
    c[1][2] = 7
    print("a =", a)
    print("b =", b)
    print("c =", c)
    print(a[0] is a[1], b[0] is b[1], c[0] is a[0])


if __name__ == "__main__":
    main()

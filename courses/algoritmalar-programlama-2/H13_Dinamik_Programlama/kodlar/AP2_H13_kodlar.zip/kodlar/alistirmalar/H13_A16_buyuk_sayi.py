"""H13_A16_buyuk_sayi.py — AP-2 Hafta 13 · Alıştırma 13.16 (★★)
Amaç    : Diller arası okuma: eş dosya H13_A16_buyuk_sayi.c'nin Python
          karşılığı (aynı tek satırlık Pascal DP'si, Python tamsayısıyla).
          Çalıştırmadan çıktıyı yazın.
Çalıştır: python3 H13_A16_buyuk_sayi.py
"""


def main():
    satir = [1] + [0] * 40
    for n in range(1, 37):
        for k in range(n, 0, -1):      # tek satır: k TERS
            satir[k] = satir[k] + satir[k - 1]
        if n >= 32:
            print(f"C({n}, {n // 2}) = {satir[n // 2]}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""kestirim.py — AP-2 Hafta 6 · Haftanın Deneyi: çözümleme ve kestirim

Girdi : sonuclar/h06_deney_olcum*.csv (her dosya planın bir turu: sürücünün
        yazdığı h06_deney_olcum.csv ve varsa önceki turların
        h06_deney_olcum_turK.csv kopyaları; tur 4–5 yalnız Θ(n²)
        yapılandırmaları içerir), sonuclar/h06_deney_esik*.csv
Çıktı : sonuclar/h06_deney_ozet.csv      (yapılandırma başına turların
                                          ortancası, en az / en çok)
        sonuclar/h06_deney_oran.csv      (ardışık n'ler: oran testi, eğim,
                                          T/(n lg n) normalize süre)
        sonuclar/h06_deney_kestirim.csv  (ölçülmeyen n için İŞARETLİ
                                          kestirim + yöntemin sınaması)
        sonuclar/h06_deney_derinlik.csv  (ağaç yüksekliği / yığın derinliği)
        sonuclar/h06_deney_esik_ozet.csv (eşik başına turların ortancası)
Süre ölçütü: işlemci zamanı (islemci_ms, ortanca); birden çok tur varsa
yapılandırma başına turların ortancası alınır. Bu makinede ölçüm
sırasında başka süreçler de çalıştığından duvar saati (ortanca_ms) bekleme
süresini de içerir; iki değer ve oranları CSV'de birlikte verilir.
Kestirim modeli: Θ(n log n) için T(n) = T(n0)·(n lg n)/(n0 lg n0),
Θ(n²) için T(n) = T(n0)·(n/n0)²; n0 = ölçülen en büyük n. Yöntem, ölçülen
en büyük noktanın bir önceki noktadan kestirilmesiyle sınanır (hata %);
çekişme gürültüsü tek yönlü (yalnız yavaşlatır) olduğundan sınama ve oran
testi turların en az değeriyle de verilir (hata_en_az_yuzde, oran_en_az).
Kullanım (deney/ klasöründe):  python3 kestirim.py
"""
import csv
import glob
import math
import os
import re
import statistics

KOK = os.path.dirname(os.path.realpath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
KARESEL = {("araya_ekleme", "rastgele"), ("hizli_ilk", "sirali")}


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def yaz(ad, alanlar, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join(str(s[a]) for a in alanlar) + "\n")


def nlgn(n):
    return n * math.log2(n)


def model(alg, girdi, n, n0, t0):
    if (alg, girdi) in KARESEL:
        return t0 * (n / n0) ** 2
    return t0 * nlgn(n) / nlgn(n0)


def okunur(ms):
    """ms → '3,2 sa' gibi Türkçe okunur süre."""
    s = ms / 1000
    for sinir, bolen, birim in ((1, 1e-3, "ms"), (60, 1, "s"),
                                (3600, 60, "dk"), (86400, 3600, "sa"),
                                (365 * 86400, 86400, "gün")):
        if s < sinir:
            x = s / bolen
            break
    else:
        x, birim = s / (365 * 86400), "yıl"
    metin = f"{x:.0f}" if x >= 10 else f"{x:.1f}".replace(".", ",")
    return f"{metin} {birim}"


def turlari_oku(kok):
    """kok.csv ve kok_turK.csv: her dosya bir tur (ad sırasıyla)."""
    turlar = []
    desen = re.compile(re.escape(kok) + r"(_tur\d+)?\.csv$")
    for yol in sorted(glob.glob(os.path.join(SONUC, kok + "*.csv"))):
        if not desen.match(os.path.basename(yol)):
            continue
        with open(yol, encoding="utf-8") as f:
            turlar.append((os.path.basename(yol),
                           list(csv.DictReader(f, delimiter=";"))))
    return turlar


def birlestir_turlar(turlar):
    """Yapılandırma başına: islemci/ortanca ms'lerin turlar arası ortancası;
    sayaçlar (deterministik) turlar arasında aynı olmalı."""
    gruplar = {}
    for ad, satirlar in turlar:
        for r in satirlar:
            k = (r["dil"], r["derleme"], r["algoritma"], r["girdi"], r["n"])
            gruplar.setdefault(k, []).append(r)
    ozet = []
    for k, rs in gruplar.items():
        for alan in ("karsilastirma", "agac_yuksekligi", "yigin_derinligi"):
            if len({r[alan] for r in rs}) != 1:
                raise SystemExit(f"sayaç turlar arasında farklı: {k} {alan}")
        if any(r["dogru"] != "1" for r in rs):
            raise SystemExit(f"doğrulanmamış ölçüm: {k}")
        cpu = sorted(float(r["islemci_ms"]) for r in rs)
        duvar = sorted(float(r["ortanca_ms"]) for r in rs)
        ozet.append({"dil": k[0], "derleme": k[1], "algoritma": k[2],
                     "girdi": k[3], "n": k[4], "tur_sayisi": len(rs),
                     "islemci_ms": f"{statistics.median(cpu):.4f}",
                     "islemci_en_az": f"{cpu[0]:.4f}",
                     "islemci_en_cok": f"{cpu[-1]:.4f}",
                     "ortanca_ms": f"{statistics.median(duvar):.4f}",
                     "tekrar": rs[0]["tekrar"],
                     "karsilastirma": rs[0]["karsilastirma"],
                     "agac_yuksekligi": rs[0]["agac_yuksekligi"],
                     "yigin_derinligi": rs[0]["yigin_derinligi"],
                     "dogru": "1"})
    return ozet


def seriler(olcum):
    s = {}
    for r in olcum:
        anahtar = (r["dil"], r["derleme"], r["algoritma"], r["girdi"])
        s.setdefault(anahtar, []).append(r)
    for v in s.values():
        v.sort(key=lambda r: int(r["n"]))
    return s


def oran_testi(ser):
    satirlar = []
    for (dil, der, alg, girdi), rs in ser.items():
        for i, r in enumerate(rs):
            n = int(r["n"])
            t = float(r["islemci_ms"])
            d = float(r["ortanca_ms"])
            ea = float(r["islemci_en_az"])
            s = {"dil": dil, "derleme": der, "algoritma": alg, "girdi": girdi,
                 "n": n, "islemci_ms": f"{t:.4f}", "duvar_ms": f"{d:.4f}",
                 "duvar_islemci": f"{d / t:.2f}" if t > 0 else "",
                 "ns_nlgn": f"{t * 1e6 / nlgn(n):.3f}",
                 "ns_n2": f"{t * 1e6 / n ** 2:.5f}",
                 "onceki_n": "", "oran": "", "oran_en_az": "",
                 "kuram_nlogn": "", "kuram_n2": "", "egim": ""}
            if i > 0:
                n0 = int(rs[i - 1]["n"])
                t0 = float(rs[i - 1]["islemci_ms"])
                ea0 = float(rs[i - 1]["islemci_en_az"])
                if t0 > 0 and t > 0:
                    s["onceki_n"] = n0
                    s["oran"] = f"{t / t0:.2f}"
                    if ea0 > 0:
                        s["oran_en_az"] = f"{ea / ea0:.2f}"
                    s["kuram_nlogn"] = f"{nlgn(n) / nlgn(n0):.2f}"
                    s["kuram_n2"] = f"{(n / n0) ** 2:.2f}"
                    s["egim"] = f"{math.log(t / t0) / math.log(n / n0):.3f}"
            satirlar.append(s)
    return satirlar


def kestirimler(ser):
    hedefler = (10**5, 10**6, 10**7)
    satirlar = []
    for (dil, der, alg, girdi), rs in ser.items():
        olculen = {int(r["n"]): float(r["islemci_ms"]) for r in rs}
        en_az = {int(r["n"]): float(r["islemci_en_az"]) for r in rs}
        n0 = max(olculen)
        t0 = olculen[n0]
        if len(rs) >= 2:
            n1 = int(rs[-2]["n"])
            tahmin = model(alg, girdi, n0, n1, olculen[n1])
            tahmin_ea = model(alg, girdi, n0, n1, en_az[n1])
            satirlar.append({
                "dil": dil, "derleme": der, "algoritma": alg, "girdi": girdi,
                "n": n0, "taban_n": n1, "model": "n²" if (alg, girdi) in
                KARESEL else "n lg n", "kestirim_ms": f"{tahmin:.1f}",
                "kestirim_okunur": okunur(tahmin),
                "olculen_ms": f"{t0:.1f}",
                "hata_yuzde": f"{100 * (tahmin - t0) / t0:.1f}",
                "hata_en_az_yuzde":
                f"{100 * (tahmin_ea - en_az[n0]) / en_az[n0]:.1f}",
                "tur": "dogrulama"})
        for n in hedefler:
            if n <= n0 or n in olculen:
                continue
            if der == "-O0":
                continue
            if girdi == "sirali" and alg != "hizli_ilk":
                continue
            t = model(alg, girdi, n, n0, t0)
            satirlar.append({
                "dil": dil, "derleme": der, "algoritma": alg, "girdi": girdi,
                "n": n, "taban_n": n0, "model": "n²" if (alg, girdi) in
                KARESEL else "n lg n", "kestirim_ms": f"{t:.1f}",
                "kestirim_okunur": okunur(t), "olculen_ms": "",
                "hata_yuzde": "", "hata_en_az_yuzde": "", "tur": "kestirim"})
    return satirlar


def derinlikler(olcum):
    satirlar = []
    for r in olcum:
        if r["dil"] != "C" or r["derleme"] != "-O2":
            continue
        if r["algoritma"] in ("kutuphane", "araya_ekleme"):
            continue
        n = int(r["n"])
        a, y = int(r["agac_yuksekligi"]), int(r["yigin_derinligi"])
        satirlar.append({"algoritma": r["algoritma"], "girdi": r["girdi"],
                         "n": n, "agac_yuksekligi": a, "yigin_derinligi": y,
                         "lg_n": f"{math.log2(n):.2f}",
                         "agac_lg_n": f"{a / math.log2(n):.2f}",
                         "karsilastirma": r["karsilastirma"],
                         "karsilastirma_nlgn":
                         f"{int(r['karsilastirma']) / nlgn(n):.3f}"})
    satirlar.sort(key=lambda s: (s["girdi"], s["algoritma"], s["n"]))
    return satirlar


def esik_ozet(esik):
    gruplar = {}
    for r in esik:
        gruplar.setdefault((r["dil"], int(r["esik"])), []).append(r)
    satirlar = []
    for dil in ("C", "C++", "Python"):
        taban = None
        for e in sorted(e for d, e in gruplar if d == dil):
            rs = gruplar[(dil, e)]
            cpu = statistics.median(float(r["islemci_ort_ms"]) for r in rs)
            duvar = statistics.median(float(r["ortanca_ms"]) for r in rs)
            if taban is None:
                taban = cpu
            satirlar.append({"dil": dil, "esik": e, "n": rs[0]["n"],
                             "tur_sayisi": len(rs),
                             "islemci_ms": f"{cpu:.3f}",
                             "duvar_ms": f"{duvar:.3f}",
                             "goreli": f"{cpu / taban:.3f}",
                             "karsilastirma": rs[0]["karsilastirma"],
                             "tasima": rs[0]["tasima"]})
    return satirlar


def main():
    turlar = turlari_oku("h06_deney_olcum")
    olcum = birlestir_turlar(turlar)
    yaz("h06_deney_ozet.csv",
        ["dil", "derleme", "algoritma", "girdi", "n", "tur_sayisi",
         "islemci_ms", "islemci_en_az", "islemci_en_cok", "ortanca_ms",
         "tekrar", "karsilastirma", "agac_yuksekligi", "yigin_derinligi",
         "dogru"], olcum)
    ser = seriler(olcum)
    oran = oran_testi(ser)
    yaz("h06_deney_oran.csv",
        ["dil", "derleme", "algoritma", "girdi", "n", "islemci_ms",
         "duvar_ms", "duvar_islemci", "ns_nlgn", "ns_n2", "onceki_n", "oran",
         "oran_en_az", "kuram_nlogn", "kuram_n2", "egim"], oran)
    kes = kestirimler(ser)
    yaz("h06_deney_kestirim.csv",
        ["dil", "derleme", "algoritma", "girdi", "n", "taban_n", "model",
         "kestirim_ms", "kestirim_okunur", "olculen_ms", "hata_yuzde",
         "hata_en_az_yuzde", "tur"], kes)
    der = derinlikler(olcum)
    yaz("h06_deney_derinlik.csv",
        ["algoritma", "girdi", "n", "agac_yuksekligi", "yigin_derinligi",
         "lg_n", "agac_lg_n", "karsilastirma", "karsilastirma_nlgn"], der)
    esik = [r for _, rs in turlari_oku("h06_deney_esik") for r in rs]
    ozet = esik_ozet(esik)
    yaz("h06_deney_esik_ozet.csv",
        ["dil", "esik", "n", "tur_sayisi", "islemci_ms", "duvar_ms",
         "goreli", "karsilastirma", "tasima"], ozet)
    print(f"turlar: {', '.join(ad for ad, _ in turlar)}")
    print(f"oran: {len(oran)} satır · kestirim: {len(kes)} · derinlik: "
          f"{len(der)} · eşik özeti: {len(ozet)}")
    for s in kes:
        if s["tur"] == "dogrulama":
            print(f"  sınama {s['dil']:<6} {s['derleme']:<3} "
                  f"{s['algoritma']:<15} {s['girdi']:<8} n={s['n']:>8} "
                  f"kestirim {s['kestirim_ms']:>10} ölçülen "
                  f"{s['olculen_ms']:>10} hata {s['hata_yuzde']:>6}% "
                  f"(turların en azıyla {s['hata_en_az_yuzde']}%)")


if __name__ == "__main__":
    main()

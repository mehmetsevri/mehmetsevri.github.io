"""H06_12_buyuk_deney.py — AP-2 Hafta 6 · Örnek 12 (★★★)
Amaç    : Haftanın Deneyi programı: birleştirmeli, hızlı (ilk / rastgele /
          üçün ortancası pivot), kütüphane (list.sort) ve araya ekleme
          sıralaması. Varsayılan çalıştırma küçük ve deterministiktir;
          ölçüm kipi bir yapılandırmayı ölçüp CSV satırı yazar.
Çalıştır: python3 H06_12_buyuk_deney.py   ya da   ... ALGORITMA GIRDI N
          TEKRAR   (ALGORITMA: birlestirmeli, hizli_ilk, hizli_rastgele,
          hizli_ortanca3, kutuphane, araya_ekleme; GIRDI: rastgele, sirali)
Eşleri  : c/H06_12_buyuk_deney.c · cpp/H06_12_buyuk_deney.cpp
Çıktı   : üç dilde aynı (=); süreler stderr'e
"""

import sys

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

(BIRLESTIRMELI, HIZLI_ILK, HIZLI_RASTGELE, HIZLI_ORTANCA3, KUTUPHANE,
 ARAYA_EKLEME, ALGORITMA_SAYISI) = range(7)
ALG_AD = ["birlestirmeli", "hizli_ilk", "hizli_rastgele", "hizli_ortanca3",
          "kutuphane", "araya_ekleme"]
GIRDI_AD = ["rastgele", "sirali"]

karsilastirma = 0
agac_yuksekligi = yigin_derinligi = 0


# --- Birleştirmeli sıralama (Örnek 2; tek tampon) ---
def birlestir(a, yrd, lo, mid, hi):
    global karsilastirma
    i, j, k = lo, mid + 1, lo
    while i <= mid and j <= hi:
        karsilastirma += 1
        if a[i] <= a[j]:
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    while i <= mid:
        yrd[k] = a[i]
        i += 1
        k += 1
    while j <= hi:
        yrd[k] = a[j]
        j += 1
        k += 1
    for k in range(lo, hi + 1):
        a[k] = yrd[k]


def bs_ozyineli(a, yrd, lo, hi, d):
    global agac_yuksekligi, yigin_derinligi
    if d > yigin_derinligi:
        yigin_derinligi = agac_yuksekligi = d
    if lo >= hi:
        return
    mid = lo + (hi - lo) // 2
    bs_ozyineli(a, yrd, lo, mid, d + 1)
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1)
    birlestir(a, yrd, lo, mid, hi)


# --- Hızlı sıralama (Örnek 6; küçük parçaya özyineleme) ---
def ortanca3(a, i, j, k):
    global karsilastirma
    karsilastirma += 2
    if a[i] < a[j]:
        if a[j] < a[k]:
            return j
        karsilastirma += 1
        return k if a[i] < a[k] else i
    if a[i] < a[k]:
        return i
    karsilastirma += 1
    return k if a[j] < a[k] else j


def bolumle(a, lo, hi, alg):
    global karsilastirma
    r = (lo if alg == HIZLI_ILK
         else rastgele_aralik(lo, hi) if alg == HIZLI_RASTGELE
         else ortanca3(a, lo, lo + (hi - lo) // 2, hi))
    a[r], a[hi] = a[hi], a[r]
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        karsilastirma += 1
        if a[j] < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


def hizli_sirala(a, lo, hi, alg, d, t):
    global agac_yuksekligi, yigin_derinligi
    if d > yigin_derinligi:
        yigin_derinligi = d
    while True:
        if t > agac_yuksekligi:
            agac_yuksekligi = t
        if lo >= hi:
            return
        p = bolumle(a, lo, hi, alg)
        if p - lo < hi - p:
            hizli_sirala(a, lo, p - 1, alg, d + 1, t + 1)
            lo = p + 1
        else:
            hizli_sirala(a, p + 1, hi, alg, d + 1, t + 1)
            hi = p - 1
        t += 1


# --- Araya ekleme (H5) ve kütüphane ---
def araya_ekleme(a):
    global karsilastirma
    for i in range(1, len(a)):
        anahtar = a[i]
        j = i - 1
        while j >= 0:
            karsilastirma += 1
            if a[j] <= anahtar:
                break
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = anahtar


# Seçilen algoritmayla a'yı sıralar; yrd: n elemanlık tampon
def sirala(a, yrd, alg):
    global karsilastirma, agac_yuksekligi, yigin_derinligi
    n = len(a)
    karsilastirma = 0
    agac_yuksekligi = yigin_derinligi = 0
    rastgele_tohum(2026)                # rastgele pivot dizisi sabit
    if alg == BIRLESTIRMELI:
        bs_ozyineli(a, yrd, 0, n - 1, 1)
    elif alg == KUTUPHANE:
        a.sort()
    elif alg == ARAYA_EKLEME:
        araya_ekleme(a)
    else:
        hizli_sirala(a, 0, n - 1, alg, 1, 1)


def girdi_uret(n, girdi):
    if girdi == 0:
        rastgele_tohum(42)
        return rastgele_dizi(n, 0, 1000000000)
    return list(range(n))


# Doğruluk: sıralı mı ve eleman toplamı korunmuş mu (ucuz kâhin)
def dogru_mu(a, toplam):
    for k in range(1, len(a)):
        if a[k - 1] > a[k]:
            return False
    return sum(a) == toplam


# Ölçüm kipi: 1 ısınma + tekrar ölçüm; ortanca/en az/en çok duvar saati
# ve ortanca işlemci zamanı (ms)
def olcum(alg, girdi, n, tekrar):
    orijinal = girdi_uret(n, girdi)
    a, yrd = [0] * n, [0] * n
    duvar, islemci = [], []
    toplam = sum(orijinal)
    for r in range(-1, tekrar):         # r = -1: ısınma
        a[:] = orijinal
        t0, c0 = zaman_sn(), islemci_sn()
        sirala(a, yrd, alg)
        t1, c1 = zaman_sn(), islemci_sn()
        if r >= 0:
            duvar.append((t1 - t0) * 1e3)
            islemci.append((c1 - c0) * 1e3)
    k = -1 if alg == KUTUPHANE else karsilastirma
    print(f"{ALG_AD[alg]};{GIRDI_AD[girdi]};{n};{tekrar};"
          f"{ortanca(duvar):.4f};{min(duvar):.4f};{max(duvar):.4f};"
          f"{ortanca(islemci):.4f};{k};{agac_yuksekligi};"
          f"{yigin_derinligi};{1 if dogru_mu(a, toplam) else 0}")
    return 0


def main():
    if len(sys.argv) == 5:
        alg = ALG_AD.index(sys.argv[1]) if sys.argv[1] in ALG_AD else -1
        girdi = (GIRDI_AD.index(sys.argv[2]) if sys.argv[2] in GIRDI_AD
                 else -1)
        try:
            n, tekrar = int(sys.argv[3]), int(sys.argv[4])
        except ValueError:
            n, tekrar = -1, -1
        if (alg < 0 or girdi < 0 or n < 2 or n > 20000000 or tekrar < 1
                or tekrar > 101):
            print("hatalı argüman", file=sys.stderr)
            return 2
        return olcum(alg, girdi, n, tekrar)
    if len(sys.argv) != 1:
        print(f"Kullanım: {sys.argv[0]} [ALGORITMA GIRDI N TEKRAR]",
              file=sys.stderr)
        return 2
    boyutlar = [1000, 10000]
    print("Büyük deney programı: varsayılan küçük çalıştırma "
          "(süreler stderr'de)")
    print("algoritma       girdi         n  karşılaştırma  ağaç  yığın  doğru")
    for girdi in range(2):
        for n in boyutlar:
            if girdi == 1 and n > 1000:
                continue                # hizli_ilk sıralıda Θ(n²)
            orijinal = girdi_uret(n, girdi)
            toplam = sum(orijinal)
            yrd = [0] * n
            for alg in range(ALGORITMA_SAYISI):
                if alg == ARAYA_EKLEME and girdi == 0 and n > 1000:
                    continue            # Θ(n²): ölçüm kipinde
                a = orijinal[:]
                t0 = zaman_sn()
                sirala(a, yrd, alg)
                ms = (zaman_sn() - t0) * 1e3
                print(f"{ALG_AD[alg]:<15} {GIRDI_AD[girdi]:<8} {n:6d}",
                      end="")
                if alg == KUTUPHANE:
                    print(f" {'-':>14} {'-':>5} {'-':>6}", end="")
                else:
                    print(f" {karsilastirma:14d} {agac_yuksekligi:5d} "
                          f"{yigin_derinligi:6d}", end="")
                print("  " + ("evet" if dogru_mu(a, toplam) else "HAYIR"))
                print(f"{ALG_AD[alg]} {GIRDI_AD[girdi]} n={n}: {ms:.3f} ms",
                      file=sys.stderr)
    print("Ölçüm kipi (deney/olcum_calistir.py kullanır):\n"
          "  ALGORITMA GIRDI N TEKRAR → algoritma;girdi;n;tekrar;"
          "ortanca_ms;\n  en_az_ms;en_cok_ms;islemci_ms;karsilastirma;"
          "agac;yigin;dogru")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — qsort (glibc; algoritma standartta yok);
# C++ — std::sort (introsort); Python — list.sort (Timsort)

"""H06_11_melez_siralama.py — AP-2 Hafta 6 · Örnek 11 (★★★)
Amaç    : Melez (hybrid) sıralama: hızlı sıralama (üçün ortancası, küçük
          parçaya özyineleme) boyu <= esik olan parçaları araya ekleme
          sıralamasına (H5) bırakır. Eşik deneyi: sayaçlar stdout'a,
          süreler stderr'e. esik = 1: saf hızlı sıralama.
Çalıştır: python3 H06_11_melez_siralama.py [n [tekrar [--csv]]]
          (varsayılan n = 10000, tekrar = 1; --csv: esik;n;tekrar;
          ortanca_ms;islemci_ort_ms;karsilastirma;tasima)
Eşleri  : c/H06_11_melez_siralama.c · cpp/H06_11_melez_siralama.cpp
Çıktı   : üç dilde aynı (=); süreler stderr'e
"""

import sys

from ortak_rastgele import rastgele_dizi, rastgele_tohum
from zamanlayici import islemci_sn, olc_ortanca

karsilastirma = tasima = araya_ekleme_cagrisi = 0


def kucuk(x, y):
    global karsilastirma
    karsilastirma += 1
    return x < y


def takas(a, i, j):
    global tasima
    a[i], a[j] = a[j], a[i]
    tasima += 1


# Araya ekleme sıralaması (H5): a[lo..hi]
def araya_ekle(a, lo, hi):
    global tasima, araya_ekleme_cagrisi
    araya_ekleme_cagrisi += 1
    for i in range(lo + 1, hi + 1):
        anahtar = a[i]
        j = i - 1
        while j >= lo and kucuk(anahtar, a[j]):
            a[j + 1] = a[j]  # kaydır
            tasima += 1
            j -= 1
        a[j + 1] = anahtar


def ortanca3(a, i, j, k):
    if kucuk(a[i], a[j]):
        if kucuk(a[j], a[k]):
            return j
        return k if kucuk(a[i], a[k]) else i
    if kucuk(a[i], a[k]):
        return i
    return k if kucuk(a[j], a[k]) else j


# Üçün ortancası pivot a[hi]'ye; Lomuto bölümleme (Örnek 6)
def bolumle(a, lo, hi):
    takas(a, ortanca3(a, lo, lo + (hi - lo) // 2, hi), hi)
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        if kucuk(a[j], pivot):
            i += 1
            takas(a, i, j)
    takas(a, i + 1, hi)
    return i + 1


# Parça esik'ten uzunken böl; kısa parçayı araya eklemeyle bitir
def melez_sirala(a, lo, hi, esik):
    while hi - lo + 1 > esik:
        p = bolumle(a, lo, hi)
        if p - lo < hi - p:
            melez_sirala(a, lo, p - 1, esik)
            lo = p + 1
        else:
            melez_sirala(a, p + 1, hi, esik)
            hi = p - 1
    if lo < hi:
        araya_ekle(a, lo, hi)  # kısa parça


def sirali_mi(a):
    for k in range(1, len(a)):
        if a[k - 1] > a[k]:
            return False
    return True


def arguman(s, alt, ust):
    try:
        x = int(s)
    except ValueError:
        x = alt - 1
    if x < alt or x > ust:
        print(f"argüman {alt}..{ust} aralığında olmalı: {s}",
              file=sys.stderr)
        sys.exit(2)
    return x


def main():
    global karsilastirma, tasima, araya_ekleme_cagrisi
    n, tekrar, csv = 10000, 1, False
    if len(sys.argv) > 1:
        n = arguman(sys.argv[1], 2, 10000000)
    if len(sys.argv) > 2:
        tekrar = arguman(sys.argv[2], 1, 101)
    if len(sys.argv) > 3:
        csv = sys.argv[3] == "--csv"
    esikler = [1, 4, 8, 12, 16, 24, 32, 48, 64]
    rastgele_tohum(42)
    orijinal = rastgele_dizi(n, 0, 1000000000)
    calisma = [0] * n
    if csv:
        print("esik;n;tekrar;ortanca_ms;islemci_ort_ms;karsilastirma;"
              "tasima")
    else:
        print(f"Melez sıralama: hızlı + araya ekleme, n = {n} (tohum 42)")
        print(" eşik  karşılaştırma     taşıma  araya ekleme  doğru")
    for esik in esikler:
        def gorev():
            calisma[:] = orijinal       # yerinde kopya
            melez_sirala(calisma, 0, n - 1, esik)
        karsilastirma = tasima = araya_ekleme_cagrisi = 0
        gorev()
        k, t, c = karsilastirma, tasima, araya_ekleme_cagrisi
        dogru = sirali_mi(calisma)
        c0 = islemci_sn()
        sn = olc_ortanca(gorev, tekrar)
        cpu = (islemci_sn() - c0) / (tekrar + 1)
        if csv:
            print(f"{esik};{n};{tekrar};{sn * 1e3:.4f};{cpu * 1e3:.4f};"
                  f"{k};{t}")
        else:
            print(f"{esik:5d} {k:14d} {t:10d} {c:13d}  "
                  + ("evet" if dogru else "HAYIR"))
        print(f"eşik {esik:2d}: {sn * 1e3:.3f} ms (ortanca, {tekrar} tekrar; "
              f"işlemci ort. {cpu * 1e3:.3f} ms)", file=sys.stderr)
    if not csv:
        print("Eşik büyüdükçe karşılaştırma ve taşıma önce biraz azalır, "
              "sonra artar\n(araya ekleme Θ(k²)); özyineleme ve bölümleme "
              "yükü ise azalır: süre\ngenellikle bir ara eşikte en kısadır "
              "(stderr; deneye bakın).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort; C++ — std::sort (libstdc++: introsort
# + 16 elemanlık eşikle araya ekleme); Python — list.sort (Timsort: kısa
# parçalarda ikili araya ekleme)

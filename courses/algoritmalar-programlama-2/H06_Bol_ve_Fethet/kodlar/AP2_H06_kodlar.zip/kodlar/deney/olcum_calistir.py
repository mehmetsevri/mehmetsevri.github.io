#!/usr/bin/env python3
"""olcum_calistir.py — AP-2 Hafta 6 · Haftanın Deneyi: ölçüm sürücüsü

Birleştirmeli, hızlı (ilk / rastgele / üçün ortancası pivot), kütüphane ve
araya ekleme sıralamasını üç dilde ölçer (programlar: */H06_12_buyuk_deney;
melez eşik deneyi: */H06_11_melez_siralama). Ham sonuçlar:
  sonuclar/h06_deney_olcum.csv   (her satır bir yapılandırma)
  sonuclar/h06_deney_esik.csv    (melez sıralama eşik deneyi)
Makine bilgisi: OLCUM_ORTAMI.txt

Düzen (AP-2 Ajan Rehberi, Bölüm 3):
  * C ve C++ -O2; karşılaştırma için C ayrıca -O0 (n = 10^6).
  * Her ölçüm: 1 ısınma + tekrar (çoğunlukla 5) çalıştırma; ORTANCA.
    Duvar saatinin yanında işlemci zamanı da kaydedilir (makine
    paylaşımlıysa duvar saati / işlemci zamanı > 1 olur).
  * Tutarsız (en_cok / en_az > 1,5) ya da çekişmeli (duvar / işlemci >
    1,25) ölçüm en çok iki kez yinelenir; en az çekişmeli deneme tutulur
    (deneme sütunu). Ortanca <= 2 ms ya da > 3 s ise yinelenmez.
  * Θ(n²) yapılandırmalar ve Python'da büyük n daha az tekrarla ölçülür;
    ölçülmeyen büyüklükler kestirim.py ile işaretli kestirimdir.
Kullanım (deney/ klasöründe):  python3 olcum_calistir.py [--devam]
  --devam: h06_deney_olcum.csv'de olan yapılandırmaları atlar (yarıda
  kalan ölçümü sürdürür); satırlar ölçüldükçe dosyaya eklenir.
  --yalniz-esik: yalnızca melez sıralama eşik deneyini yineler.
  --karesel-tur K: yalnızca Θ(n²) yapılandırmaları (araya ekleme/rastgele,
  hızlı-ilk/sıralı; uzun tek çalıştırmalar gürültüye en duyarlı olanlar)
  ölçer ve sonuclar/h06_deney_olcum_turK.csv'ye yazar (ek tur, ~20 s).
Toplam süre boş bir 2 çekirdekli makinede yaklaşık 4–6 dakikadır.
"""
import datetime
import os
import platform
import subprocess
import sys
import tempfile

KOK = os.path.dirname(os.path.realpath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C_DERLE = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP_DERLE = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]
NLOGN = ["birlestirmeli", "hizli_ilk", "hizli_rastgele", "hizli_ortanca3",
         "kutuphane"]
ALANLAR = ["dil", "derleme", "algoritma", "girdi", "n", "tekrar", "deneme",
           "ortanca_ms", "en_az_ms", "en_cok_ms", "islemci_ms",
           "karsilastirma", "agac_yuksekligi", "yigin_derinligi", "dogru"]


def derle(gecici):
    """İkilileri derler; {(dil, derleme, program): komut önü} döndürür."""
    ikili = {}
    for prog in ("H06_12_buyuk_deney", "H06_11_melez_siralama"):
        for bayrak in ("-O2", "-O0"):
            if prog == "H06_11_melez_siralama" and bayrak == "-O0":
                continue
            hedef = os.path.join(gecici, f"{prog}_c{bayrak}")
            kaynak = [os.path.join(KOK, "c", prog + ".c"),
                      os.path.join(KOK, "c", "ortak_rastgele.c"),
                      os.path.join(KOK, "c", "zamanlayici.c")]
            subprocess.run(C_DERLE + [bayrak] + kaynak + ["-o", hedef],
                           check=True)
            ikili[("C", bayrak, prog)] = [hedef]
        hedef = os.path.join(gecici, f"{prog}_cpp")
        subprocess.run(CPP_DERLE + ["-O2", os.path.join(KOK, "cpp",
                                                        prog + ".cpp"),
                                    "-o", hedef], check=True)
        ikili[("C++", "-O2", prog)] = [hedef]
        ikili[("Python", "-", prog)] = [sys.executable, os.path.join(
            KOK, "python", prog + ".py")]
    return ikili


def olc(komut, alg, girdi, n, tekrar):
    p = subprocess.run(komut + [alg, girdi, str(n), str(tekrar)],
                       capture_output=True, text=True, check=True)
    d = p.stdout.strip().split(";")
    return {"algoritma": d[0], "girdi": d[1], "n": int(d[2]),
            "tekrar": int(d[3]), "ortanca_ms": float(d[4]),
            "en_az_ms": float(d[5]), "en_cok_ms": float(d[6]),
            "islemci_ms": float(d[7]), "karsilastirma": int(d[8]),
            "agac_yuksekligi": int(d[9]), "yigin_derinligi": int(d[10]),
            "dogru": int(d[11])}


def olc_tutarli(komut, alg, girdi, n, tekrar):
    """Tutarsız ya da çekişmeli ölçümü en çok iki kez yineler.
    Tutarsız: en_cok / en_az > 1,5; çekişmeli: duvar / işlemci > 1,25
    (başka süreçler işlemciyi paylaşıyor). Ortancası 2 ms'den kısa ya da
    3 s'den uzun ölçümler yinelenmez. En düşük (çekişme, yayılım) tutulur.
    """
    en_iyi, deneme = None, 0
    for deneme in range(1, 4):
        s = olc(komut, alg, girdi, n, tekrar)
        yayilim = s["en_cok_ms"] / max(s["en_az_ms"], 1e-9)
        cekisme = s["ortanca_ms"] / max(s["islemci_ms"], 1e-9)
        puan = (round(max(cekisme, 1.0), 2), yayilim)
        if en_iyi is None or puan < en_iyi[0]:
            en_iyi = (puan, s)
        if ((yayilim <= 1.5 or tekrar == 1) and cekisme <= 1.25) or \
                s["ortanca_ms"] <= 2.0 or s["ortanca_ms"] > 3000:
            break
    sonuc = dict(en_iyi[1])
    sonuc["deneme"] = deneme
    return sonuc


def plan():
    """(dil, derleme, algoritma, girdi, n, tekrar) listesi"""
    p = []
    for dil in ("C", "C++"):
        for n in (10**3, 10**4, 10**5, 10**6, 10**7):
            for alg in NLOGN:
                p.append((dil, "-O2", alg, "rastgele", n, 5))
        for n, t in ((10**3, 5), (3000, 5), (10**4, 5), (30000, 3),
                     (10**5, 1)):
            p.append((dil, "-O2", "araya_ekleme", "rastgele", n, t))
        for n, t in ((2500, 3), (5000, 3), (10000, 3), (20000, 3),
                     (40000, 1)):
            p.append((dil, "-O2", "hizli_ilk", "sirali", n, t))
    for n in (10**3, 10**4, 10**5, 10**6, 10**7):
        for alg in ("birlestirmeli", "hizli_rastgele", "hizli_ortanca3",
                    "kutuphane"):
            p.append(("C", "-O2", alg, "sirali", n, 5))
    for alg in ("birlestirmeli", "hizli_rastgele", "kutuphane"):
        for n in (10**5, 10**6):
            p.append(("C", "-O0", alg, "rastgele", n, 5))
    for n in (10**3, 10**4, 10**5):
        for alg in NLOGN:
            p.append(("Python", "-", alg, "rastgele", n,
                      5 if n < 10**5 else 3))
    for alg, t in (("birlestirmeli", 1), ("hizli_rastgele", 1),
                   ("kutuphane", 5)):
        p.append(("Python", "-", alg, "rastgele", 10**6, t))
    for n, t in ((10**3, 5), (3000, 3), (10**4, 1)):
        p.append(("Python", "-", "araya_ekleme", "rastgele", n, t))
    for n, t in ((500, 3), (1000, 3), (2000, 3), (4000, 1)):
        p.append(("Python", "-", "hizli_ilk", "sirali", n, t))
    return p


def esik_deneyi(ikili, tur_sayisi=3):
    """Eşik taraması üç kez (tur) yinelenir: her turda 1 ısınma + tekrar
    ölçüm; çözümlemede turların ortancası kullanılır (gürültüye karşı)."""
    satirlar = []
    for tur in range(1, tur_sayisi + 1):
        for dil, der, n, tekrar in (("C", "-O2", 10**6, 9),
                                    ("C++", "-O2", 10**6, 9),
                                    ("Python", "-", 20000, 3)):
            komut = ikili[(dil, der, "H06_11_melez_siralama")]
            p = subprocess.run(komut + [str(n), str(tekrar), "--csv"],
                               capture_output=True, text=True, check=True)
            for satir in p.stdout.strip().splitlines()[1:]:
                esik, nn, tk, orta, cpu, k, t = satir.split(";")
                satirlar.append([dil, der, str(tur), esik, nn, tk, orta, cpu,
                                 k, t])
                print(f"eşik tur {tur} {dil:<6} n={nn} eşik={esik:>2} "
                      f"{orta} ms (işlemci ort. {cpu} ms)", flush=True)
    with open(os.path.join(SONUC, "h06_deney_esik.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;derleme;tur;esik;n;tekrar;ortanca_ms;islemci_ort_ms;"
                "karsilastirma;tasima\n")
        for s in satirlar:
            f.write(";".join(s) + "\n")


def ortam_yaz(sure_sn):
    def ilk(komut):
        try:
            return subprocess.run(komut, capture_output=True, text=True
                                  ).stdout.strip().splitlines()[0]
        except (OSError, IndexError):
            return "?"
    model = "?"
    for satir in subprocess.run(["lscpu"], capture_output=True, text=True
                                ).stdout.splitlines():
        if satir.startswith("Model name:"):
            model = satir.split(":", 1)[1].strip()
    glibc = platform.libc_ver()
    bellek_mb = (os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
                 // 2**20)
    metin = (
        "AP-2 Hafta 6 · Haftanın Deneyi — ölçüm ortamı\n"
        f"Tarih          : {datetime.date.today().isoformat()}\n"
        f"İşlemci        : {model}\n"
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine; başka süreçler "
        "de çalışıyordu)\n"
        f"Bellek         : {bellek_mb} MB\n"
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()}); C kitaplığı {glibc[0]} {glibc[1]}\n"
        f"C derleyicisi  : {ilk(['gcc', '--version'])}\n"
        f"C++ derleyicisi: {ilk(['g++', '--version'])}\n"
        f"Python         : {ilk([sys.executable, '--version'])}\n"
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra "
        "-pedantic -O2 (C ayrıca -O0)\n"
        "Yöntem         : 1 ısınma + tekrar (çoğunlukla 5) çalıştırma, "
        "ortanca; en_cok/en_az > 1,5 ya da duvar/işlemci > 1,25 ise "
        "en çok 2 kez yineleme\n"
        "Saat           : C timespec_get (duvar saati) + clock(), C++ "
        "steady_clock + std::clock, Python perf_counter + process_time\n"
        "Girdi          : rastgele = ortak LCG tohum 42, 0..10^9; sirali = "
        "0..n-1; rastgele pivot tohumu 2026\n"
        f"Toplam deney süresi: {sure_sn:.1f} s\n")
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)
    print(metin)


KARESEL = {("araya_ekleme", "rastgele"), ("hizli_ilk", "sirali")}


def main():
    os.makedirs(SONUC, exist_ok=True)
    devam = "--devam" in sys.argv or "--yalniz-esik" in sys.argv
    csv_yol = os.path.join(SONUC, "h06_deney_olcum.csv")
    karesel_tur = None
    if "--karesel-tur" in sys.argv:
        karesel_tur = int(sys.argv[sys.argv.index("--karesel-tur") + 1])
        csv_yol = os.path.join(SONUC, f"h06_deney_olcum_tur{karesel_tur}.csv")
    yapilan = set()
    if devam and os.path.exists(csv_yol):
        with open(csv_yol, encoding="utf-8") as f:
            next(f)
            for satir in f:
                d = satir.rstrip("\n").split(";")
                yapilan.add((d[0], d[1], d[2], d[3], int(d[4])))
    else:
        with open(csv_yol, "w", encoding="utf-8") as f:
            f.write(";".join(ALANLAR) + "\n")
    baslangic = datetime.datetime.now()
    with tempfile.TemporaryDirectory(prefix="h06_deney_") as gecici:
        ikili = derle(gecici)
        if "--yalniz-esik" in sys.argv:
            esik_deneyi(ikili)
            return
        for dil, der, alg, girdi, n, tekrar in plan():
            if (dil, der, alg, girdi, n) in yapilan or (
                    karesel_tur and (alg, girdi) not in KARESEL):
                continue
            komut = ikili[(dil, der, "H06_12_buyuk_deney")]
            s = olc_tutarli(komut, alg, girdi, n, tekrar)
            s.update(dil=dil, derleme=der)
            with open(csv_yol, "a", encoding="utf-8") as f:
                f.write(";".join(f"{s[a]:.4f}" if isinstance(s[a], float)
                                 else str(s[a]) for a in ALANLAR) + "\n")
            print(f"{dil:<6} {der:<3} {alg:<15} {girdi:<8} n={n:>8} "
                  f"ortanca={s['ortanca_ms']:11.3f} ms "
                  f"[{s['en_az_ms']:.3f} … {s['en_cok_ms']:.3f}] "
                  f"işlemci={s['islemci_ms']:.3f} deneme={s['deneme']} "
                  f"doğru={s['dogru']}", flush=True)
        sure = (datetime.datetime.now() - baslangic).total_seconds()
        if karesel_tur:
            print(f"Ek tur {karesel_tur} (yalnız Θ(n²)): {sure:.1f} s")
            return
        esik_deneyi(ikili)
    ortam_yaz((datetime.datetime.now() - baslangic).total_seconds())


if __name__ == "__main__":
    main()

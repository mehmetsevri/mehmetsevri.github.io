/* H06_03_ozyineleme_agaci.cpp — AP-2 Hafta 6 · Örnek 3 (★★)
 * Amaç    : Özyineleme ağacını izlemek: birleştirmeli sıralamada her düzeyin
 *           işi (birleştirilen eleman) n'dir, düzey sayısı ⌈lg n⌉ → n lg n.
 *           Ana teoremin üç durumu: T(n) = a·T(n/b) + n^d düzey işleri.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_03_ozyineleme_agaci.cpp -o H06_03_ozyineleme_agaci
 * Çalıştır: ./H06_03_ozyineleme_agaci
 * Eşleri  : c/H06_03_ozyineleme_agaci.c · python/H06_03_ozyineleme_agaci.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const int MAKS_DUZEY = 64;

static std::vector<long long> duzey_cagri(MAKS_DUZEY), duzey_is(MAKS_DUZEY);
static std::vector<long long> duzey_karsilastirma(MAKS_DUZEY);
static std::vector<int> duzey_en_kucuk(MAKS_DUZEY), duzey_en_buyuk(MAKS_DUZEY);
static int duzey_sayisi = 0;

static void aralik_yaz(const std::vector<int>& a, int lo, int hi)
{
    for (int k = lo; k <= hi; k++) {
        std::cout << " " << a[k];
    }
}

static void girinti(int d)
{
    std::cout << std::string(2 * (d - 1), ' ');
}

// Birleştirme; karşılaştırma sayısını döndürür
static long long birlestir(std::vector<int>& a, std::vector<int>& yrd, int lo,
                           int mid, int hi)
{
    long long karsilastirma = 0;
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
    return karsilastirma;
}

// Birleştirmeli sıralama + düzey sayaçları; yaz = true ise ağacı yazar
static void bs_izle(std::vector<int>& a, std::vector<int>& yrd, int lo,
                    int hi, int d, bool yaz)
{
    int boyut = hi - lo + 1;
    if (d > duzey_sayisi) {
        duzey_sayisi = d;
        duzey_en_kucuk[d] = duzey_en_buyuk[d] = boyut;
    }
    duzey_cagri[d]++;
    if (boyut < duzey_en_kucuk[d]) {
        duzey_en_kucuk[d] = boyut;
    }
    if (boyut > duzey_en_buyuk[d]) {
        duzey_en_buyuk[d] = boyut;
    }
    if (yaz) {
        std::cout << d << "  ";
        girinti(d);
        std::cout << (lo == hi ? "yaprak" : "böl") << " [" << lo << ".."
                  << hi << "]";
        aralik_yaz(a, lo, hi);
        std::cout << "\n";
    }
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_izle(a, yrd, lo, mid, d + 1, yaz);
    bs_izle(a, yrd, mid + 1, hi, d + 1, yaz);
    long long k = birlestir(a, yrd, lo, mid, hi);
    duzey_is[d] += boyut;              // bu düğümün işi: boyut kadar eleman
    duzey_karsilastirma[d] += k;
    if (yaz) {
        std::cout << d << "  ";
        girinti(d);
        std::cout << "birleştir [" << lo << ".." << hi << "] →";
        aralik_yaz(a, lo, hi);
        std::cout << "  (" << k << " karşılaştırma)\n";
    }
}

static void duzeyleri_sifirla()
{
    for (int d = 0; d < MAKS_DUZEY; d++) {
        duzey_cagri[d] = duzey_is[d] = duzey_karsilastirma[d] = 0;
    }
    duzey_sayisi = 0;
}

static int tavan_log2(long long n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

static void duzey_tablosu(std::vector<int>& a, bool yaz)
{
    int n = static_cast<int>(a.size());
    std::vector<int> yrd(a.size());
    duzeyleri_sifirla();
    bs_izle(a, yrd, 0, n - 1, 1, yaz);
    std::cout << "n = " << n
              << "\ndüzey  düğüm   boyut      iş  karşılaştırma\n";
    long long is_top = 0, k_top = 0;
    for (int d = 1; d <= duzey_sayisi; d++) {
        std::string boyut = std::to_string(duzey_en_kucuk[d]);
        if (duzey_en_kucuk[d] != duzey_en_buyuk[d]) {
            boyut += "-" + std::to_string(duzey_en_buyuk[d]);
        }
        std::cout << std::setw(5) << d << " " << std::setw(6)
                  << duzey_cagri[d] << " " << std::setw(7) << boyut << " "
                  << std::setw(7) << duzey_is[d] << " " << std::setw(14)
                  << duzey_karsilastirma[d] << "\n";
        is_top += duzey_is[d];
        k_top += duzey_karsilastirma[d];
    }
    int k = tavan_log2(n);
    std::cout << "toplam iş = " << is_top << " · n·⌈lg n⌉ = " << n << "·" << k
              << " = " << static_cast<long long>(n) * k
              << " · karşılaştırma = " << k_top << "\n\n";
}

// T(n) = a·T(n/b) + n^d, T(1) = 1: her düğüm kendi düzeyine n^d ekler
static long long us(long long x, int d)
{
    long long s = 1;
    for (int k = 0; k < d; k++) {
        s *= x;
    }
    return s;
}

static void yineleme(long long n, int a, int b, int d, int duzey)
{
    if (duzey > duzey_sayisi) {
        duzey_sayisi = duzey;
    }
    duzey_is[duzey] += us(n, d);
    if (n <= 1) {
        return;
    }
    for (int k = 0; k < a; k++) {
        yineleme(n / b, a, b, d, duzey + 1);
    }
}

static void ana_teorem(long long n, int a, int b, int d)
{
    duzeyleri_sifirla();
    yineleme(n, a, b, d, 1);
    long long bd = us(b, d), toplam = 0;
    double logba = std::log(static_cast<double>(a)) /
                   std::log(static_cast<double>(b));
    std::cout << "a=" << a << " b=" << b << " d=" << d << ": ";
    if (a < bd) {
        std::cout << "a < b^d (" << a << " < " << bd
                  << ") → kök baskın: Θ(n^d) = Θ(n^" << d << ")\n";
    } else if (a == bd) {
        std::cout << "a = b^d (" << a << " = " << bd
                  << ") → düzeyler eşit: Θ(n^" << d << " log n)\n";
    } else {
        std::cout << "a > b^d (" << a << " > " << bd
                  << ") → yapraklar baskın: Θ(n^log_b a) = Θ(n^"
                  << std::fixed << std::setprecision(3) << logba << ")\n";
    }
    std::cout << "  düzey işleri:";
    for (int k = 1; k <= duzey_sayisi; k++) {
        std::cout << " " << duzey_is[k];
        toplam += duzey_is[k];
    }
    double nd = static_cast<double>(n);
    double f = a < bd ? std::pow(nd, d)
                      : (a == bd ? std::pow(nd, d) * std::log2(nd)
                                 : std::pow(nd, logba));
    std::cout << "\n  toplam T(" << n << ") = " << toplam
              << " · T(n) / f(n) = " << std::fixed << std::setprecision(3)
              << toplam / f << "\n";
}

int main()
{
    std::vector<int> a = {6, 3, 8, 1, 7, 2, 5, 4};
    std::cout << "Özyineleme ağacı: birleştirmeli sıralama, n = 8\n";
    std::cout << "d  olay\n";
    duzey_tablosu(a, true);

    rastgele_tohum(42);
    std::vector<int> x = rastgele_dizi(1024, 0, 999999);
    duzey_tablosu(x, false);
    rastgele_tohum(42);
    x = rastgele_dizi(1000, 0, 999999);
    duzey_tablosu(x, false);
    std::cout << "Her düzeyde birleştirilen toplam eleman n'dir (son düzey "
                 "eksik\nkalabilir); düzey sayısı ⌈lg n⌉ + 1, iş yapan düzey "
                 "⌈lg n⌉:\nT(n) = 2T(n/2) + n → Θ(n log n).\n\n";

    std::cout << "Ana teorem: T(n) = a·T(n/b) + n^d, T(1) = 1, n = 256\n";
    std::cout << "(düzey işleri kökten yapraklara; f(n) = Θ içindeki terim)\n";
    ana_teorem(256, 2, 2, 1);
    ana_teorem(256, 1, 2, 0);
    ana_teorem(256, 4, 2, 1);
    ana_teorem(256, 2, 2, 2);
    ana_teorem(256, 3, 2, 1);
    return 0;
}

/* Kütüphane karşılığı: yok (izleme ve sayma programı). */

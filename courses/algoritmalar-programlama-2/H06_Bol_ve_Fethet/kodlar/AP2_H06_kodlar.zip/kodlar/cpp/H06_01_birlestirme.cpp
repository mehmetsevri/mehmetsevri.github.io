/* H06_01_birlestirme.cpp — AP-2 Hafta 6 · Örnek 1 (★)
 * Amaç    : İki sıralı dizinin doğrusal zamanda birleştirilmesi; değişmez:
 *           c[0..k-1] sıralıdır ve a[0..i-1] ile b[0..j-1]'in tamamıdır.
 *           Eşitlikte soldan almak (<=) birleştirmeyi kararlı yapar.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_01_birlestirme.cpp -o H06_01_birlestirme
 * Çalıştır: ./H06_01_birlestirme
 * Eşleri  : c/H06_01_birlestirme.c · python/H06_01_birlestirme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Kayit {
    int puan;
    std::string ad;
};

static long long karsilastirma = 0;

// a ve b sıralı; c, ikisinin sıralı birleşimi olur (c.size() = na + nb)
void birlestir(const std::vector<int>& a, const std::vector<int>& b,
               std::vector<int>& c)
{
    std::size_t na = a.size(), nb = b.size();
    std::size_t i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        karsilastirma++;
        if (a[i] <= b[j]) {  // eşitse soldan
            c[k++] = a[i++];
        } else {
            c[k++] = b[j++];
        }
    }
    while (i < na) {  // sol dizinin kalanı
        c[k++] = a[i++];
    }
    while (j < nb) {  // sağ dizinin kalanı
        c[k++] = b[j++];
    }
}

static void dizi_yaz(const std::string& ad, const std::vector<int>& a)
{
    std::cout << ad << " = [";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i ? ", " : "") << a[i];
    }
    std::cout << "]\n";
}

// Aynı algoritma; her adımda i, j ve karşılaştırmayı yazar
static void birlestir_izleyerek(const std::vector<int>& a,
                                const std::vector<int>& b,
                                std::vector<int>& c)
{
    std::size_t na = a.size(), nb = b.size();
    std::size_t i = 0, j = 0, k = 0;
    std::cout << "adım  i  j  karşılaştırma          alınan\n";
    while (i < na && j < nb) {
        bool soldan = a[i] <= b[j];
        std::cout << std::setw(4) << k + 1 << " " << std::setw(2) << i
                  << " " << std::setw(2) << j << "  a[" << i << "]=" << a[i]
                  << (soldan ? " <= " : " >  ") << "b[" << j << "]="
                  << b[j];
        if (soldan) {
            std::cout << "   a'dan " << a[i]
                      << (a[i] == b[j] ? "  (eşitlik: soldan)" : "") << "\n";
            c[k++] = a[i++];
        } else {
            std::cout << "   b'den " << b[j] << "\n";
            c[k++] = b[j++];
        }
    }
    std::cout << "kalan: " << (i < na ? "sol dizi" : "sağ dizi")
              << "; kopyalanan " << (na - i) + (nb - j) << " eleman\n";
    while (i < na) {
        c[k++] = a[i++];
    }
    while (j < nb) {
        c[k++] = b[j++];
    }
}

// Kararlılık gösterimi: kayıtlar yalnızca puana göre birleştirilir
void birlestir_kayit(const std::vector<Kayit>& a, const std::vector<Kayit>& b,
                     std::vector<Kayit>& c)
{
    std::size_t na = a.size(), nb = b.size();
    std::size_t i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        if (a[i].puan <= b[j].puan) {
            c[k++] = a[i++];
        } else {
            c[k++] = b[j++];
        }
    }
    while (i < na) {
        c[k++] = a[i++];
    }
    while (j < nb) {
        c[k++] = b[j++];
    }
}

// Artan sıralı (yinelemeli değerli) rastgele dizi: a[i] = a[i-1] + 0..3
static std::vector<int> sirali_uret(std::size_t n)
{
    std::vector<int> a(n);
    int x = rastgele_aralik(0, 5);
    for (std::size_t i = 0; i < n; i++) {
        x += rastgele_aralik(0, 3);
        a[i] = x;
    }
    return a;
}

int main()
{
    const std::vector<int> a = {2, 5, 7, 9};
    const std::vector<int> b = {1, 5, 6, 10, 12};
    std::vector<int> c(9);
    std::cout << "İki sıralı dizinin birleştirilmesi\n";
    dizi_yaz("a", a);
    dizi_yaz("b", b);
    birlestir_izleyerek(a, b, c);
    dizi_yaz("c", c);
    birlestir(a, b, c);
    std::cout << "karşılaştırma = " << karsilastirma
              << " (en çok na + nb - 1 = " << 4 + 5 - 1 << ")\n\n";

    const std::vector<Kayit> sol = {{55, "Ali"}, {70, "Can"}, {70, "Ece"},
                                    {85, "Naz"}};
    const std::vector<Kayit> sag = {{60, "Bora"}, {70, "Deniz"}, {90, "Ufuk"}};
    std::vector<Kayit> k(7);
    birlestir_kayit(sol, sag, k);
    std::cout << "Kararlılık: puanı 70 olanlar (sol: Can, Ece; sağ: Deniz)\n";
    for (std::size_t i = 0; i < 7; i++) {
        std::cout << (i ? ", " : "") << k[i].puan << " " << k[i].ad;
    }
    std::cout << "\n<= ile eşit puanlılar özgün sırayı korur "
                 "(soldakiler önce)\n\n";

    const std::size_t boyutlar[][2] = {{0, 0}, {0, 3}, {4, 0}, {1, 1},
                                       {5, 5}, {100, 37}, {1000, 1000},
                                       {50000, 70000}};
    rastgele_tohum(42);
    std::cout << "Rastgele sıralı diziler (tohum 42) ve kâhin "
                 "(kütüphane sıralaması)\n";
    std::cout << "    na     nb  karşılaştırma  alt   üst      kâhin\n";
    for (const auto& boyut : boyutlar) {
        std::size_t na = boyut[0], nb = boyut[1], n = na + nb;
        std::vector<int> x = sirali_uret(na);
        std::vector<int> y = sirali_uret(nb);
        std::vector<int> z(n);
        karsilastirma = 0;
        birlestir(x, y, z);
        std::vector<int> d = x;
        d.insert(d.end(), y.begin(), y.end());
        std::sort(d.begin(), d.end());                  // yalnızca kâhin
        bool ayni = z == d;
        std::size_t alt = std::min(na, nb);
        std::size_t ust = (na && nb) ? n - 1 : 0;
        std::cout << std::setw(6) << na << " " << std::setw(6) << nb << " "
                  << std::setw(14) << karsilastirma << " " << std::setw(5)
                  << alt << " " << std::setw(6) << ust << "  "
                  << (ayni ? "aynı" : "FARKLI") << "\n";
    }
    std::cout << "min(na, nb) <= karşılaştırma <= na + nb - 1: "
                 "iş Θ(na + nb)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::merge (kararlı);
 * Python — heapq.merge(a, b) (yineleyici; kararlı) */

/* H06_13_en_buyuk_alt_dizi.cpp — AP-2 Hafta 6 · Örnek 13 (★★★)
 * Amaç    : En büyük alt dizi toplamı böl ve fethet ile: en iyi alt dizi ya
 *           solda, ya sağda ya da ortayı keser. T(n) = 2T(n/2) + Θ(n) →
 *           Θ(n log n). H2'nin Θ(n) Kadane'siyle aynı toplam; sayaç:
 *           toplama sayısı. Sözleşme (H2): alt dizi boş olamaz.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_13_en_buyuk_alt_dizi.cpp -o H06_13_en_buyuk_alt_dizi
 * Çalıştır: ./H06_13_en_buyuk_alt_dizi
 * Eşleri  : c/H06_13_en_buyuk_alt_dizi.c ·
 *           python/H06_13_en_buyuk_alt_dizi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Aralik {
    long long toplam;                   // alt dizi toplamı
    int bas, son;                       // aralık a[bas..son]
};

static long long toplama = 0;
static int en_derin = 0;

// Ortayı kesen en iyi alt dizi: a[i..mid] + a[mid+1..j]
static Aralik kesisen(const std::vector<int>& a, int lo, int mid, int hi)
{
    long long toplam = a[mid], sol_en = a[mid];
    int bas = mid;
    for (int i = mid - 1; i >= lo; i--) {  // sola
        toplam += a[i];
        toplama++;
        if (toplam > sol_en) {
            sol_en = toplam;
            bas = i;
        }
    }
    toplam = a[mid + 1];
    long long sag_en = a[mid + 1];
    int son = mid + 1;
    for (int j = mid + 2; j <= hi; j++) {  // sağa
        toplam += a[j];
        toplama++;
        if (toplam > sag_en) {
            sag_en = toplam;
            son = j;
        }
    }
    toplama++;  // sol_en + sag_en
    return {sol_en + sag_en, bas, son};
}

// a[lo..hi]'nin en büyük alt dizisi; eşitlikte sol, kesişen, sağ sırası
Aralik en_buyuk_bf(const std::vector<int>& a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo == hi) {
        return {a[lo], lo, lo};
    }
    int mid = lo + (hi - lo) / 2;
    Aralik sol = en_buyuk_bf(a, lo, mid, d + 1);
    Aralik sag = en_buyuk_bf(a, mid + 1, hi, d + 1);
    Aralik orta = kesisen(a, lo, mid, hi);
    Aralik en = sol;  // eşitlikte sol, kesişen, sağ
    if (orta.toplam > en.toplam) {
        en = orta;
    }
    if (sag.toplam > en.toplam) {
        en = sag;
    }
    return en;
}

// H2 Örnek 13'teki Kadane (Θ(n)): a[i]'de biten en iyi toplam
Aralik kadane(const std::vector<int>& a, int n)
{
    Aralik s = {a[0], 0, 0};
    long long simdiki = a[0];
    int s_bas = 0;
    for (int i = 1; i < n; i++) {
        long long uzat = simdiki + a[i];
        toplama++;
        if (uzat < a[i]) {
            simdiki = a[i];
            s_bas = i;
        } else {
            simdiki = uzat;
        }
        if (simdiki > s.toplam) {
            s.toplam = simdiki;
            s.bas = s_bas;
            s.son = i;
        }
    }
    return s;
}

static void dizi_coz(const std::string& ad, const std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    toplama = 0;
    en_derin = 0;
    Aralik b = en_buyuk_bf(a, 0, n - 1, 1);
    long long tb = toplama;
    toplama = 0;
    Aralik k = kadane(a, n);
    std::cout << ad << " (n=" << n << "): böl-fethet " << b.toplam << " ["
              << b.bas << ".." << b.son << "] · Kadane " << k.toplam << " ["
              << k.bas << ".." << k.son << "] · toplama " << tb << " / "
              << toplama << "\n";
}

int main()
{
    const std::vector<int> bentley = {31, -41, 59, 26, -53, 58, 97, -93, -23,
                                      84};
    const std::vector<int> negatif = {-3, -1, -2};
    const std::vector<int> tek = {5};
    const std::vector<int> sifir = {0, -1, 0};
    const std::vector<int> klasik = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    const int boyutlar[] = {10, 100, 1000, 1024, 10000, 100000};

    std::cout << "En büyük alt dizi: böl ve fethet ↔ Kadane (H2)\n";
    dizi_coz("Bentley", bentley);
    dizi_coz("Tümü negatif", negatif);
    dizi_coz("Tek eleman", tek);
    dizi_coz("Sıfırlar", sifir);
    dizi_coz("Klasik", klasik);

    rastgele_tohum(42);
    const std::vector<int> a = rastgele_dizi(100000, -100, 100);  // H2 verisi
    std::cout << "\nRastgele a[i] -100..100 (tohum 42, H2 ile aynı); toplama "
                 "sayıları\nW(n) = n⌈lg n⌉ - 2^⌈lg n⌉ + 1 (düğüm başına boy "
                 "- 1; Örnek 2'deki sınır)\n";
    std::cout << "     n  en büyük  böl-fethet        W(n)  Kadane  oran  "
                 "derinlik  aynı\n";
    for (int n : boyutlar) {
        toplama = 0;
        en_derin = 0;
        Aralik b = en_buyuk_bf(a, 0, n - 1, 1);
        long long tb = toplama;
        toplama = 0;
        Aralik k = kadane(a, n);
        int lg = 0;
        while ((1LL << lg) < n) {
            lg++;
        }
        long long w = static_cast<long long>(n) * lg - (1LL << lg) + 1;
        std::cout << std::setw(6) << n << " " << std::setw(9) << b.toplam
                  << " " << std::setw(11) << tb << " " << std::setw(11) << w
                  << " " << std::setw(7) << toplama << " " << std::fixed
                  << std::setprecision(1) << std::setw(5)
                  << static_cast<double>(tb) / toplama << " " << std::setw(9)
                  << en_derin << "  "
                  << (b.toplam == k.toplam ? "evet" : "HAYIR") << "\n";
    }
    std::cout << "Aynı problem, iki strateji: böl ve fethet Θ(n log n) "
                 "toplama ve\nO(log n) yığın; Kadane Θ(n) toplama ve O(1) "
                 "bellek.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — yok
 * (itertools.accumulate önek toplamı verir, en büyük alt diziyi vermez) */

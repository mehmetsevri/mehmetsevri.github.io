/* H06_09_quickselect.cpp — AP-2 Hafta 6 · Örnek 9 (★★★)
 * Amaç    : Quickselect (Hoare'un FIND fikri): k'ıncı en küçük değer ve
 *           ortanca not. Bölümledikten sonra yalnızca k'nın bulunduğu
 *           parçada devam edilir: beklenen Θ(n), yinelemeli, O(1) ek
 *           bellek. Notlarda çok tekrar olduğu için üç yollu bölümleme.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_09_quickselect.cpp -o H06_09_quickselect
 * Çalıştır: ./H06_09_quickselect
 * Eşleri  : c/H06_09_quickselect.c · python/H06_09_quickselect.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0;
static int tur_sayisi = 0;

// Örnek 7: a[lo..lt-1] < p, a[lt..gt] = p, a[gt+1..hi] > p
static std::pair<int, int> uc_yollu_bolumle(std::vector<int>& a, int lo,
                                            int hi, int p)
{
    int lt = lo, i = lo, gt = hi;
    while (i <= gt) {
        karsilastirma++;
        if (a[i] < p) {
            std::swap(a[lt++], a[i++]);
        } else {
            karsilastirma++;
            if (a[i] > p) {
                std::swap(a[i], a[gt--]);
            } else {
                i++;
            }
        }
    }
    return {lt, gt};
}

// k'ıncı en küçük (0 tabanlı); a yeniden düzenlenir
int hizli_sec(std::vector<int>& a, int k)
{
    int lo = 0, hi = static_cast<int>(a.size()) - 1;
    while (lo < hi) {
        tur_sayisi++;
        int p = a[rastgele_aralik(lo, hi)];
        auto [lt, gt] = uc_yollu_bolumle(a, lo, hi, p);
        if (k < lt) {
            hi = lt - 1;  // k soldaki parçada
        } else if (k > gt) {
            lo = gt + 1;  // k sağdaki parçada
        } else {
            return p;  // k, a[lt..gt] içinde
        }
    }
    return a[lo];
}

static void dizi_yaz(const std::vector<int>& a)
{
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

// Aynı algoritma; her turda aralığı, pivotu ve kararı yazar
static int hizli_sec_izle(std::vector<int>& a, int k)
{
    int lo = 0, hi = static_cast<int>(a.size()) - 1, tur = 0;
    std::cout << "tur  lo  hi  pivot  lt  gt  karar\n";
    while (lo < hi) {
        int p = a[rastgele_aralik(lo, hi)];
        auto [lt, gt] = uc_yollu_bolumle(a, lo, hi, p);
        std::cout << std::setw(3) << ++tur << " " << std::setw(3) << lo << " "
                  << std::setw(3) << hi << " " << std::setw(6) << p << " "
                  << std::setw(3) << lt << " " << std::setw(3) << gt << "  ";
        if (k < lt) {
            std::cout << "k = " << k << " < lt: sola  ";
            hi = lt - 1;
        } else if (k > gt) {
            std::cout << "k = " << k << " > gt: sağa  ";
            lo = gt + 1;
        } else {
            std::cout << "lt <= k <= gt: bulundu = " << p << "\n";
            return p;
        }
        dizi_yaz(a);
    }
    std::cout << "lo = hi = " << lo << ": bulundu = " << a[lo] << "\n";
    return a[lo];
}

int main()
{
    std::vector<int> notlar = {72, 45, 88, 61, 95, 53, 77, 61, 84};
    int n = static_cast<int>(notlar.size()), k = n / 2;
    std::cout << "Ortanca not: n = " << n << ", k = n / 2 = " << k
              << " (0 tabanlı)\nnotlar:";
    dizi_yaz(notlar);
    rastgele_tohum(7);
    int ortanca = hizli_sec_izle(notlar, k);
    std::cout << "ortanca = " << ortanca << "\n\n";

    const int boyutlar[] = {101, 1001, 10001, 100001};
    const int tekrar = 5;               // farklı pivot dizileriyle
    for (int tur = 0; tur < 2; tur++) {
        int ust = tur == 0 ? 100 : 1000000000;
        std::cout << (tur == 0 ? "Notlar" : "Farklı değerler")
                  << " (tohum 42, 0.." << (tur == 0 ? "100" : "10^9")
                  << "): " << tekrar << " çalıştırmanın ortalaması\n";
        std::cout << "     n     ortanca  ort. karş.  karş./n  ort. tur   "
                     "lg n  kâhin\n";
        for (int m : boyutlar) {
            rastgele_tohum(42);
            std::vector<int> x = rastgele_dizi(m, 0, ust);
            std::vector<int> y = x;
            std::sort(y.begin(), y.end());                    // kâhin
            karsilastirma = 0;
            tur_sayisi = 0;
            int sonuc = 0;
            bool hepsi_dogru = true;
            for (int r = 0; r < tekrar; r++) {
                std::vector<int> z = x;
                rastgele_tohum(2026 + static_cast<std::uint64_t>(r));
                sonuc = hizli_sec(z, m / 2);
                hepsi_dogru = hepsi_dogru && sonuc == y[m / 2];
            }
            double ort = static_cast<double>(karsilastirma) / tekrar;
            std::cout << std::setw(6) << m << " " << std::setw(11) << sonuc
                      << " " << std::fixed << std::setprecision(0)
                      << std::setw(11) << ort << " " << std::setprecision(2)
                      << std::setw(8) << ort / m << " " << std::setprecision(1)
                      << std::setw(9)
                      << static_cast<double>(tur_sayisi) / tekrar << " "
                      << std::setprecision(2) << std::setw(6)
                      << std::log2(static_cast<double>(m)) << "  "
                      << (hepsi_dogru ? "aynı" : "FARKLI") << "\n";
        }
        std::cout << "\n";
    }
    std::cout << "n 1000 kat büyürken karş./n artmıyor (lg n ise büyüyor): "
                 "beklenen\niş Θ(n). Sıralayıp ortadakini almak Θ(n log n) "
                 "olurdu.\nEn kötü durumda (pivot hep uçta) Θ(n²).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::nth_element (introselect);
 * Python — statistics.median (sıralar: O(n log n)); heapq.nsmallest */

/* H06_05_hoare_bolumleme.cpp — AP-2 Hafta 6 · Örnek 5 (★★)
 * Amaç    : Hoare bölümleme (pivot x = a[lo]; i soldan, j sağdan ilerler)
 *           ve Lomuto ile karşılaştırma/takas sayısı. Dönüş j pivotun son
 *           yeri DEĞİLDİR: a[lo..j] <= x <= a[j+1..hi] demektir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_05_hoare_bolumleme.cpp -o H06_05_hoare_bolumleme
 * Çalıştır: ./H06_05_hoare_bolumleme
 * Eşleri  : c/H06_05_hoare_bolumleme.c · python/H06_05_hoare_bolumleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0, takas_sayisi = 0;
static int en_derin = 0;

static void takas(std::vector<int>& a, int i, int j)
{
    std::swap(a[i], a[j]);
    takas_sayisi++;
}

// Pivot x = a[lo]; dönüş j: a[lo..j] <= x <= a[j+1..hi], lo <= j < hi
int hoare_bolumle(std::vector<int>& a, int lo, int hi)
{
    int x = a[lo];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {  // sağdan: x'ten büyük olmayanı bul
            j--;
            karsilastirma++;
        } while (a[j] > x);
        do {  // soldan: x'ten küçük olmayanı bul
            i++;
            karsilastirma++;
        } while (a[i] < x);
        if (i >= j) {
            return j;
        }
        takas(a, i, j);
    }
}

void hizli_hoare(std::vector<int>& a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = hoare_bolumle(a, lo, hi);
    hizli_hoare(a, lo, p, d + 1);  // p dahil
    hizli_hoare(a, p + 1, hi, d + 1);
}

// Karşılaştırma için Örnek 4'ün Lomuto bölümlemesi (pivot a[hi])
int lomuto_bolumle(std::vector<int>& a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

void hizli_lomuto(std::vector<int>& a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = lomuto_bolumle(a, lo, hi);
    hizli_lomuto(a, lo, p - 1, d + 1);
    hizli_lomuto(a, p + 1, hi, d + 1);
}

static void dizi_yaz(const std::vector<int>& a, int n)
{
    for (int k = 0; k < n; k++) {
        std::cout << " " << a[k];
    }
    std::cout << "\n";
}

// Hoare bölümlemesinin izlenmesi (aynı algoritma + çıktı)
static void hoare_izle(std::vector<int>& a, int lo, int hi)
{
    int x = a[lo];
    int i = lo - 1, j = hi + 1;
    std::cout << "tur  i  j  işlem\n";
    for (int tur = 1;; tur++) {
        do {
            j--;
        } while (a[j] > x);
        do {
            i++;
        } while (a[i] < x);
        std::cout << std::setw(3) << tur << " " << std::setw(2) << i << " "
                  << std::setw(2) << j << "  ";
        if (i >= j) {
            std::cout << "i >= j → dönüş j = " << j << "\n";
            return;
        }
        std::swap(a[i], a[j]);
        std::cout << "takas a[" << i << "] <-> a[" << j << "]:";
        dizi_yaz(a, hi + 1);
    }
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

// yontem 0: Lomuto, 1: Hoare; sayaçları sıfırlayıp a'nın kopyasını sıralar
static bool sirala_say(const std::vector<int>& a, int yontem)
{
    std::vector<int> b = a;
    int n = static_cast<int>(b.size());
    karsilastirma = takas_sayisi = 0;
    en_derin = 0;
    if (yontem == 0) {
        hizli_lomuto(b, 0, n - 1, 1);
    } else {
        hizli_hoare(b, 0, n - 1, 1);
    }
    return sirali_mi(b);
}

int main()
{
    std::vector<int> a = {6, 3, 8, 1, 7, 2, 5, 4};
    std::vector<int> b = a;
    std::cout << "Hoare bölümleme (pivot x = a[lo] = " << a[0]
              << "; i soldan, j sağdan)\n";
    std::cout << "başta:";
    dizi_yaz(a, 8);
    hoare_izle(a, 0, 7);
    karsilastirma = takas_sayisi = 0;
    int x0 = b[0];
    int p = hoare_bolumle(b, 0, 7);
    int yer = 0;
    while (b[yer] != x0) {
        yer++;
    }
    std::cout << "sonuç: a[0.." << p << "] <= " << x0 << " <= a[" << p + 1
              << "..7]; pivot " << x0 << " şimdi a[" << yer << "]'de, a["
              << p << "]'te değil\n";
    std::cout << "Hoare: karşılaştırma = " << karsilastirma << " · takas = "
              << takas_sayisi << "\n";
    std::vector<int> c = {6, 3, 8, 1, 7, 2, 5, 4};
    karsilastirma = takas_sayisi = 0;
    lomuto_bolumle(c, 0, 7);
    std::cout << "Lomuto (aynı dizi, pivot a[hi] = 4): karşılaştırma = "
              << karsilastirma << " · takas = " << takas_sayisi << "\n\n";

    const int boyutlar[] = {100, 1000, 10000, 100000};
    std::cout << "Rastgele girdi (tohum 42, 0..10^9): tam hızlı sıralama\n";
    std::cout << "     n   Lomuto karş.  takas   Hoare karş.  takas  "
                 "takas L/H\n";
    for (int n : boyutlar) {
        rastgele_tohum(42);
        std::vector<int> x = rastgele_dizi(n, 0, 1000000000);
        bool d1 = sirala_say(x, 0);
        long long lk = karsilastirma, lt = takas_sayisi;
        bool d2 = sirala_say(x, 1);
        std::cout << std::setw(6) << n << " " << std::setw(14) << lk << " "
                  << std::setw(7) << lt << " " << std::setw(13)
                  << karsilastirma << " " << std::setw(7) << takas_sayisi
                  << " " << std::fixed << std::setprecision(2)
                  << std::setw(10)
                  << static_cast<double>(lt) / takas_sayisi
                  << (d1 && d2 ? "" : "  HATA") << "\n";
    }

    std::cout << "\nÖzel girdiler (n = 500): karşılaştırma / derinlik\n";
    std::cout << "girdi       Lomuto karş.  derinlik   Hoare karş.  "
                 "derinlik\n";
    for (int tur = 0; tur < 2; tur++) {
        std::vector<int> x(500);
        for (int k = 0; k < 500; k++) {
            x[k] = tur == 0 ? 7 : k;
        }
        bool d1 = sirala_say(x, 0);
        long long lk = karsilastirma;
        int ld = en_derin;
        bool d2 = sirala_say(x, 1);
        std::cout << (tur == 0 ? "tümü eşit" : "sıralı   ") << " "
                  << std::setw(14) << lk << " " << std::setw(9) << ld << " "
                  << std::setw(13) << karsilastirma << " " << std::setw(9)
                  << en_derin << (d1 && d2 ? "" : "  HATA") << "\n";
    }
    std::cout << "Tümü eşit girdide Hoare her eşitte durup takas eder ve "
                 "ortadan böler;\nLomuto (a[j] < pivot) hiçbir elemanı sola "
                 "almaz: Θ(n²). Sıralı girdide\nikisi de (uç pivotla) Θ(n²): "
                 "çözüm pivot seçimi (Örnek 6).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::partition (bölümleme; Hoare'a
 * benzer iki uçlu tarama), std::sort; Python — yok (list.sort Timsort) */

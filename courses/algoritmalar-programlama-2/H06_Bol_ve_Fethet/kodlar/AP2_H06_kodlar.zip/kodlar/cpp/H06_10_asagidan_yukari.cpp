/* H06_10_asagidan_yukari.cpp — AP-2 Hafta 6 · Örnek 10 (★★★)
 * Amaç    : Aşağıdan yukarıya (yinelemeli) birleştirmeli sıralama: önce
 *           1'lik, sonra 2'lik, 4'lük ... komşu blokları birleştir.
 *           Özyineleme yok; ⌈lg n⌉ geçiş. n = 2^k'da yukarıdan aşağıya
 *           sürümle aynı birleştirmeleri yapar.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_10_asagidan_yukari.cpp -o H06_10_asagidan_yukari
 * Çalıştır: ./H06_10_asagidan_yukari
 * Eşleri  : c/H06_10_asagidan_yukari.c · python/H06_10_asagidan_yukari.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0;
static int birlestirme_sayisi = 0;

// Örnek 2'deki birleştirme: a[lo..mid] + a[mid+1..hi], yrd üzerinden
static void birlestir(std::vector<int>& a, std::vector<int>& yrd, int lo,
                      int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    birlestirme_sayisi++;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
}

static void dizi_yaz(const std::vector<int>& a)
{
    for (int x : a) {
        std::cout << " " << x;
    }
}

// gen: blok genişliği 1, 2, 4, ...; yaz = true ise her geçişi yazar
int asagidan_yukari_sirala(std::vector<int>& a, bool yaz)
{
    int n = static_cast<int>(a.size());
    std::vector<int> yrd(a.size());
    int gecis = 0;
    for (int gen = 1; gen < n; gen *= 2) {
        int onceki = birlestirme_sayisi;
        for (int lo = 0; lo < n - gen; lo += 2 * gen) {
            int mid = lo + gen - 1;
            int hi = std::min(lo + 2 * gen - 1, n - 1);
            birlestir(a, yrd, lo, mid, hi);
        }
        gecis++;
        if (yaz) {
            int blok = (n + gen - 1) / gen;
            std::cout << "gen = " << std::setw(2) << gen << " :";
            dizi_yaz(a);
            std::cout << "   (" << birlestirme_sayisi - onceki
                      << " birleştirme";
            if (blok % 2 == 1) {
                std::cout << "; [" << (blok - 1) * gen << ".." << n - 1
                          << "] eşsiz";
            }
            std::cout << ")\n";
        }
    }
    return gecis;
}

// Karşılaştırma için Örnek 2'nin yukarıdan aşağıya sürümü
static void bs_ozyineli(std::vector<int>& a, std::vector<int>& yrd, int lo,
                        int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_ozyineli(a, yrd, lo, mid);
    bs_ozyineli(a, yrd, mid + 1, hi);
    birlestir(a, yrd, lo, mid, hi);
}

static int tavan_log2(int n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

int main()
{
    std::vector<int> a = {6, 3, 8, 1, 7, 2, 5, 4, 9, 0};
    std::cout << "Aşağıdan yukarıya birleştirmeli sıralama "
                 "(özyinelemesiz)\n";
    std::cout << "başta    :";
    dizi_yaz(a);
    std::cout << "\n";
    int gecis = asagidan_yukari_sirala(a, true);
    std::cout << "geçiş = " << gecis << " = ⌈lg 10⌉ · karşılaştırma = "
              << karsilastirma << " · birleştirme = " << birlestirme_sayisi
              << "\n";
    std::cout << "Eşi olmayan son blok o geçişte olduğu gibi kalır.\n\n";

    const int boyutlar[] = {8, 10, 1000, 1024, 4096, 100000};
    std::cout << "Yukarıdan aşağıya (Örnek 2) ile karşılaştırma "
                 "(tohum 42)\n";
    std::cout << "     n  aşağıdan yukarı  yukarıdan aşağı  geçiş  ⌈lg n⌉  "
                 "doğru\n";
    for (int n : boyutlar) {
        rastgele_tohum(42);
        std::vector<int> x = rastgele_dizi(n, 0, 999999);
        std::vector<int> y = x, yrd(x.size());
        karsilastirma = 0;
        gecis = asagidan_yukari_sirala(x, false);
        long long ay = karsilastirma;
        karsilastirma = 0;
        bs_ozyineli(y, yrd, 0, n - 1);
        std::cout << std::setw(6) << n << " " << std::setw(16) << ay << " "
                  << std::setw(16) << karsilastirma << " " << std::setw(6)
                  << gecis << " " << std::setw(7) << tavan_log2(n) << "  "
                  << (sirali_mi(x) && sirali_mi(y) ? "evet" : "HAYIR")
                  << "\n";
    }
    std::cout << "n = 2^k olduğunda iki sürüm aynı blokları birleştirir: "
                 "karşılaştırmalar\neşittir. Diğer n'lerde bölünme sınırları "
                 "farklıdır.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::stable_sort; Python — yok
 * (sorted/Timsort hazır sıralı parçaları (run) aşağıdan yukarıya
 * birleştirir) */

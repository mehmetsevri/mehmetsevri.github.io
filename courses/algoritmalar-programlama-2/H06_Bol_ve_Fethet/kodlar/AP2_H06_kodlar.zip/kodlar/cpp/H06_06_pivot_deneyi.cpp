/* H06_06_pivot_deneyi.cpp — AP-2 Hafta 6 · Örnek 6 (★★)
 * Amaç    : Pivot seçimi: ilk eleman / rastgele (ortak LCG) / üçün ortancası
 *           × sıralı / ters / rastgele girdi → karşılaştırma ve derinlik.
 *           Küçük parçaya özyineleme + büyük parçada döngü (kuyruk çağrısı
 *           eleme fikri): kötü pivotta bile yığın derinliği <= lg n + 1.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_06_pivot_deneyi.cpp -o H06_06_pivot_deneyi
 * Çalıştır: ./H06_06_pivot_deneyi   ya da   ./H06_06_pivot_deneyi naif N
 *           (naif N: sıralı girdide ilk eleman pivotlu İKİ çağrılı sürüm;
 *           derinlik N olur — büyük N'de yığın taşabilir, bkz. Hata Avcısı)
 * Eşleri  : c/H06_06_pivot_deneyi.c · python/H06_06_pivot_deneyi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

enum { ILK = 0, RASTGELE = 1, ORTANCA3 = 2 };
const char* const STRATEJI_AD[] = {"ilk     ", "rastgele", "ortanca3"};
const char* const GIRDI_AD[] = {"sıralı  ", "ters    ", "rastgele"};

static long long karsilastirma = 0;
static int yigin_derinligi = 0, agac_yuksekligi = 0;

static bool kucuk(int x, int y)
{
    karsilastirma++;
    return x < y;
}

// a[i], a[j], a[k] değerlerinin ortancasının indisi (2-3 karşılaştırma)
static int ortanca3(const std::vector<int>& a, int i, int j, int k)
{
    if (kucuk(a[i], a[j])) {
        if (kucuk(a[j], a[k])) {
            return j;  // a[i] < a[j] < a[k]
        }
        return kucuk(a[i], a[k]) ? k : i;
    }
    if (kucuk(a[i], a[k])) {
        return i;  // a[j] <= a[i] < a[k]
    }
    return kucuk(a[j], a[k]) ? k : j;
}

static int pivot_sec(const std::vector<int>& a, int lo, int hi, int strateji)
{
    if (strateji == ILK) {
        return lo;
    }
    if (strateji == RASTGELE) {
        return rastgele_aralik(lo, hi);
    }
    return ortanca3(a, lo, lo + (hi - lo) / 2, hi);
}

// Seçilen pivot a[hi]'ye taşınır; ardından Örnek 4'ün Lomuto bölümlemesi
static int bolumle(std::vector<int>& a, int lo, int hi, int strateji)
{
    std::swap(a[pivot_sec(a, lo, hi, strateji)], a[hi]);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (kucuk(a[j], pivot)) {
            i++;
            std::swap(a[i], a[j]);
        }
    }
    std::swap(a[i + 1], a[hi]);
    return i + 1;
}

// Küçük parçaya özyineleme, büyük parçada döngü. d: gerçek yığın derinliği;
// t: iki çağrılı (naif) sürümdeki çağrının ağaç derinliği
void hizli_sirala(std::vector<int>& a, int lo, int hi, int s, int d, int t)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = d;
    }
    for (;;) {
        if (t > agac_yuksekligi) {
            agac_yuksekligi = t;
        }
        if (lo >= hi) {
            return;
        }
        int p = bolumle(a, lo, hi, s);
        if (p - lo < hi - p) {  // sol küçük
            hizli_sirala(a, lo, p - 1, s, d + 1, t + 1);
            lo = p + 1;  // sağda döngü
        } else {
            hizli_sirala(a, p + 1, hi, s, d + 1, t + 1);
            hi = p - 1;
        }
        t++;
    }
}

// Karşılaştırma için iki çağrılı (naif) sürüm: yığın derinliği = ağaç
void hizli_naif(std::vector<int>& a, int lo, int hi, int s, int d)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = bolumle(a, lo, hi, s);
    hizli_naif(a, lo, p - 1, s, d + 1);
    hizli_naif(a, p + 1, hi, s, d + 1);
}

static std::vector<int> girdi_uret(int n, int tur)
{
    if (tur == 2) {
        rastgele_tohum(42);
        return rastgele_dizi(n, 0, 1000000000);
    }
    std::vector<int> a(n);
    for (int k = 0; k < n; k++) {
        a[k] = tur == 0 ? k : n - k;
    }
    return a;
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

static void sayac_sifirla()
{
    karsilastirma = 0;
    yigin_derinligi = agac_yuksekligi = 0;
    rastgele_tohum(2026);               // rastgele pivot dizisi sabit
}

static int naif_kip(const std::string& arg)
{
    long n = -1;
    try {
        std::size_t son = 0;
        n = std::stol(arg, &son);
        if (son != arg.size()) {
            n = -1;
        }
    } catch (const std::exception&) {
        n = -1;
    }
    if (n < 1 || n > 10000000) {
        std::cerr << "N 1..10000000 olmalı\n";
        return 2;
    }
    std::vector<int> a = girdi_uret(static_cast<int>(n), 0);
    sayac_sifirla();
    std::cout << "naif, sıralı girdi, ilk eleman pivotu, n = " << n
              << std::endl;
    hizli_naif(a, 0, static_cast<int>(n) - 1, ILK, 1);
    std::cout << "bitti: karşılaştırma = " << karsilastirma
              << " · yığın derinliği = " << yigin_derinligi << "\n";
    return 0;
}

int main(int argc, char* argv[])
{
    if (argc == 3 && argv[1][0] == 'n') {
        return naif_kip(argv[2]);
    }
    if (argc != 1) {
        std::cerr << "Kullanım: " << argv[0] << " [naif N]\n";
        return 2;
    }
    const int boyutlar[] = {1000, 2000};
    long long sonuc[2][3][3];
    std::cout << "Pivot deneyi: Lomuto + küçük parçaya özyineleme\n";
    std::cout << "girdi    strateji     n  karşılaştırma  ağaç yük.  yığın  "
                 "doğru\n";
    for (int b = 0; b < 2; b++) {
        int n = boyutlar[b];
        for (int g = 0; g < 3; g++) {
            for (int s = 0; s < 3; s++) {
                std::vector<int> a = girdi_uret(n, g);
                sayac_sifirla();
                hizli_sirala(a, 0, n - 1, s, 1, 1);
                sonuc[b][g][s] = karsilastirma;
                std::cout << GIRDI_AD[g] << " " << STRATEJI_AD[s] << " "
                          << std::setw(5) << n << " " << std::setw(14)
                          << karsilastirma << " " << std::setw(10)
                          << agac_yuksekligi << " " << std::setw(6)
                          << yigin_derinligi << "  "
                          << (sirali_mi(a) ? "evet" : "HAYIR") << "\n";
            }
        }
    }
    std::cout << "\nOran testi: karşılaştırma(2000) / karşılaştırma(1000)\n";
    std::cout << std::fixed << std::setprecision(2)
              << "(Θ(n²) → 4; Θ(n log n) → 2·lg 2000 / lg 1000 = "
              << 2.0 * std::log(2000.0) / std::log(1000.0) << ")\n";
    for (int g = 0; g < 3; g++) {
        std::cout << GIRDI_AD[g] << ":";
        for (int s = 0; s < 3; s++) {
            std::cout << "  " << STRATEJI_AD[s] << " "
                      << static_cast<double>(sonuc[1][g][s]) / sonuc[0][g][s];
        }
        std::cout << "\n";
    }
    std::cout << "n(n-1)/2 (n = 2000) = " << 2000 * 1999 / 2 << "\n\n";

    std::cout << "Doğrulama: naif (iki çağrılı) sürümün yığın derinliği = "
                 "döngülü\nsürümün ağaç yüksekliği (n = 500; deterministik "
                 "pivotlar)\n";
    const int stratejiler[] = {ILK, ORTANCA3};
    for (int g = 0; g < 3; g++) {
        for (int s : stratejiler) {
            std::vector<int> a = girdi_uret(500, g);
            sayac_sifirla();
            hizli_naif(a, 0, 499, s, 1);
            int naif_derinlik = yigin_derinligi;
            long long naif_k = karsilastirma;
            a = girdi_uret(500, g);
            sayac_sifirla();
            hizli_sirala(a, 0, 499, s, 1, 1);
            std::cout << GIRDI_AD[g] << " " << STRATEJI_AD[s]
                      << " naif yığın = " << std::setw(3) << naif_derinlik
                      << " · ağaç yük. = " << std::setw(3) << agac_yuksekligi
                      << " · karşılaştırma "
                      << (naif_k == karsilastirma ? "aynı" : "FARKLI")
                      << "\n";
        }
    }
    std::cout << "Döngülü sürüm aynı ağacı gezer (aynı karşılaştırmalar), "
                 "ama\nbüyük parçayı yeni çağrı açmadan işler: yığın <= lg n "
                 "+ 1.\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (introsort: ortanca
 * pivot + derinlik sınırı aşılınca öbek sıralaması); Python — list.sort */

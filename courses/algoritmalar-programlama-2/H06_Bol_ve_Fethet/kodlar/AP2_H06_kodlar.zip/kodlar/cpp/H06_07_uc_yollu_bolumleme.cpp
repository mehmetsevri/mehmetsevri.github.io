/* H06_07_uc_yollu_bolumleme.cpp — AP-2 Hafta 6 · Örnek 7 (★★★)
 * Amaç    : Üç yollu bölümleme (Dijkstra'nın Hollanda bayrağı problemi):
 *           a[lo..lt-1] < p, a[lt..i-1] = p, a[i..gt] işlenmemiş,
 *           a[gt+1..hi] > p. Çok tekrar eden anahtarlarda iki yollu
 *           (Lomuto) hızlı sıralama Θ(n²)'ye düşer; üç yollu düşmez.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_07_uc_yollu_bolumleme.cpp -o H06_07_uc_yollu_bolumleme
 * Çalıştır: ./H06_07_uc_yollu_bolumleme
 * Eşleri  : c/H06_07_uc_yollu_bolumleme.c ·
 *           python/H06_07_uc_yollu_bolumleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0, takas_sayisi = 0;
static int en_derin = 0, agac_yuksekligi = 0;

static void takas(std::vector<int>& a, int i, int j)
{
    std::swap(a[i], a[j]);
    takas_sayisi++;
}

// p değerine göre üç bölge; dönüş {lt, gt}: eşitler bölgesi a[lt..gt]
std::pair<int, int> uc_yollu_bolumle(std::vector<int>& a, int lo, int hi,
                                     int p)
{
    int lt = lo, i = lo, gt = hi;
    while (i <= gt) {
        karsilastirma++;
        if (a[i] < p) {  // küçük: sola
            takas(a, lt, i);
            lt++;
            i++;
        } else {
            karsilastirma++;
            if (a[i] > p) {  // büyük: sağa
                takas(a, i, gt);
                gt--;
            } else {  // eşit: yerinde kalır
                i++;
            }
        }
    }
    return {lt, gt};
}

// Üç yollu hızlı sıralama; pivot rastgele bir elemanın değeri
void hizli_uc_yollu(std::vector<int>& a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = a[rastgele_aralik(lo, hi)];
    auto [lt, gt] = uc_yollu_bolumle(a, lo, hi, p);
    // a[lt..gt] = p: eşitler bir daha işlenmez
    hizli_uc_yollu(a, lo, lt - 1, d + 1);
    hizli_uc_yollu(a, gt + 1, hi, d + 1);
}

// Karşılaştırma için iki yollu: rastgele pivot + Lomuto (a[j] < pivot);
// yığın güvenliği için küçük parçaya özyineleme (Örnek 6)
static int lomuto_bolumle(std::vector<int>& a, int lo, int hi)
{
    takas(a, rastgele_aralik(lo, hi), hi);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

void hizli_iki_yollu(std::vector<int>& a, int lo, int hi, int d, int t)
{
    if (d > en_derin) {
        en_derin = d;
    }
    for (;;) {
        if (t > agac_yuksekligi) {
            agac_yuksekligi = t;
        }
        if (lo >= hi) {
            return;
        }
        int p = lomuto_bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            hizli_iki_yollu(a, lo, p - 1, d + 1, t + 1);
            lo = p + 1;
        } else {
            hizli_iki_yollu(a, p + 1, hi, d + 1, t + 1);
            hi = p - 1;
        }
        t++;
    }
}

static void dizi_yaz(const std::vector<int>& a)
{
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

// Hollanda bayrağı izlemesi (aynı algoritma + çıktı)
static void bayrak_izle(std::vector<int>& a, int p)
{
    int n = static_cast<int>(a.size());
    int lt = 0, i = 0, gt = n - 1, adim = 0;
    std::cout << "adım lt  i gt  a[i]  işlem\n";
    while (i <= gt) {
        std::cout << std::setw(4) << ++adim << " " << std::setw(2) << lt
                  << " " << std::setw(2) << i << " " << std::setw(2) << gt
                  << " " << std::setw(5) << a[i] << "  ";
        if (a[i] < p) {
            std::cout << "< p: a[" << lt << "] <-> a[" << i
                      << "], lt++, i++  :";
            std::swap(a[lt], a[i]);
            lt++;
            i++;
        } else if (a[i] > p) {
            std::cout << "> p: a[" << i << "] <-> a[" << gt
                      << "], gt--       :";
            std::swap(a[i], a[gt]);
            gt--;
        } else {
            std::cout << "= p: i++                       :";
            i++;
        }
        dizi_yaz(a);
    }
    std::cout << "son: lt = " << lt << ", gt = " << gt << " → a[0.."
              << lt - 1 << "] < p, a[" << lt << ".." << gt << "] = p, a["
              << gt + 1 << ".." << n - 1 << "] > p\n";
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

int main()
{
    std::vector<int> bayrak = {2, 0, 1, 2, 1, 0, 0, 2, 1, 0};
    std::vector<int> b = bayrak;
    std::cout << "Hollanda bayrağı (Dijkstra): 0 = kırmızı, 1 = beyaz, "
                 "2 = mavi; p = 1\n";
    std::cout << "başta:";
    dizi_yaz(bayrak);
    bayrak_izle(bayrak, 1);
    uc_yollu_bolumle(b, 0, 9, 1);
    std::cout << "uc_yollu_bolumle: tek geçiş · karşılaştırma = "
              << karsilastirma << " · takas = " << takas_sayisi << "\n\n";

    const char* const ADLAR[] = {"rastgele 0..10^9", "az farklı 0..9  ",
                                 "ikili 0..1      ", "tümü eşit (7)   "};
    const int ALTLAR[] = {0, 0, 0, 7};
    const int USTLER[] = {1000000000, 9, 1, 7};
    const int n = 2000;
    std::cout << "Hızlı sıralama, n = " << n
              << ", rastgele pivot (iki yollu: Lomuto)\n";
    std::cout << "girdi              yöntem      karşılaştırma   takas  ağaç  "
                 "doğru\n";
    for (int t = 0; t < 4; t++) {
        rastgele_tohum(42);
        std::vector<int> g = rastgele_dizi(n, ALTLAR[t], USTLER[t]);
        for (int y = 0; y < 2; y++) {
            std::vector<int> x = g;
            karsilastirma = takas_sayisi = 0;
            en_derin = agac_yuksekligi = 0;
            rastgele_tohum(2026);
            if (y == 0) {
                hizli_iki_yollu(x, 0, n - 1, 1, 1);
            } else {
                hizli_uc_yollu(x, 0, n - 1, 1);
                agac_yuksekligi = en_derin;
            }
            std::cout << ADLAR[t] << "   " << (y == 0 ? "iki yollu"
                                                       : "üç yollu ")
                      << " " << std::setw(14) << karsilastirma << " "
                      << std::setw(7) << takas_sayisi << " " << std::setw(5)
                      << agac_yuksekligi << "  "
                      << (sirali_mi(x) ? "evet" : "HAYIR") << "\n";
        }
    }
    std::cout << "İki yollu bölümlemede pivota eşit elemanlar hep aynı "
                 "tarafa gider:\nk farklı anahtarda her eşit grup kendi "
                 "içinde karesel sıralanır.\nÜç yollu bölümleme eşitleri tek "
                 "geçişte ortaya toplar ve bir daha\nişlemez: k farklı "
                 "anahtar için beklenen iş O(n log k).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::partition iki kez (ya da
 * std::sort); Python — yok. Bentley ve McIlroy (1993) qsort'u eşitleri
 * ayrı toplayan bölümleme kullanır. */

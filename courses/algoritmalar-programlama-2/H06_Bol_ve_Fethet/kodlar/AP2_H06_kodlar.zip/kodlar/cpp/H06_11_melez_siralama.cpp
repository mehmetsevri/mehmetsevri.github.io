/* H06_11_melez_siralama.cpp — AP-2 Hafta 6 · Örnek 11 (★★★)
 * Amaç    : Melez (hybrid) sıralama: hızlı sıralama (üçün ortancası, küçük
 *           parçaya özyineleme) boyu <= esik olan parçaları araya ekleme
 *           sıralamasına (H5) bırakır. Eşik deneyi: sayaçlar stdout'a,
 *           süreler stderr'e. esik = 1: saf hızlı sıralama.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_11_melez_siralama.cpp -o H06_11_melez_siralama
 * Çalıştır: ./H06_11_melez_siralama [n [tekrar [--csv]]]  (varsayılan
 *           n = 10000, tekrar = 1; --csv: esik;n;tekrar;ortanca_ms;
 *           islemci_ort_ms;karsilastirma;tasima)
 * Eşleri  : c/H06_11_melez_siralama.c · python/H06_11_melez_siralama.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <cstdio>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static long long karsilastirma = 0, tasima = 0, araya_ekleme_cagrisi = 0;

static bool kucuk(int x, int y)
{
    karsilastirma++;
    return x < y;
}

static void takas(std::vector<int>& a, int i, int j)
{
    std::swap(a[i], a[j]);
    tasima++;
}

// Araya ekleme sıralaması (H5): a[lo..hi]
static void araya_ekle(std::vector<int>& a, int lo, int hi)
{
    araya_ekleme_cagrisi++;
    for (int i = lo + 1; i <= hi; i++) {
        int anahtar = a[i];
        int j = i - 1;
        while (j >= lo && kucuk(anahtar, a[j])) {
            a[j + 1] = a[j];  // kaydır
            tasima++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

static int ortanca3(const std::vector<int>& a, int i, int j, int k)
{
    if (kucuk(a[i], a[j])) {
        if (kucuk(a[j], a[k])) {
            return j;
        }
        return kucuk(a[i], a[k]) ? k : i;
    }
    if (kucuk(a[i], a[k])) {
        return i;
    }
    return kucuk(a[j], a[k]) ? k : j;
}

// Üçün ortancası pivot a[hi]'ye; Lomuto bölümleme (Örnek 6)
static int bolumle(std::vector<int>& a, int lo, int hi)
{
    takas(a, ortanca3(a, lo, lo + (hi - lo) / 2, hi), hi);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (kucuk(a[j], pivot)) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

// Parça esik'ten uzunken böl; kısa parçayı araya eklemeyle bitir
void melez_sirala(std::vector<int>& a, int lo, int hi, int esik)
{
    while (hi - lo + 1 > esik) {
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            melez_sirala(a, lo, p - 1, esik);
            lo = p + 1;
        } else {
            melez_sirala(a, p + 1, hi, esik);
            hi = p - 1;
        }
    }
    if (lo < hi) {
        araya_ekle(a, lo, hi);  // kısa parça
    }
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

static long arguman(const std::string& s, long alt, long ust)
{
    long x = alt - 1;
    try {
        std::size_t son = 0;
        x = std::stol(s, &son);
        if (son != s.size()) {
            x = alt - 1;
        }
    } catch (const std::exception&) {
        x = alt - 1;
    }
    if (x < alt || x > ust) {
        std::cerr << "argüman " << alt << ".." << ust
                  << " aralığında olmalı: " << s << "\n";
        std::exit(2);
    }
    return x;
}

int main(int argc, char* argv[])
{
    int n = 10000, tekrar = 1;
    bool csv = false;
    if (argc > 1) {
        n = static_cast<int>(arguman(argv[1], 2, 10000000));
    }
    if (argc > 2) {
        tekrar = static_cast<int>(arguman(argv[2], 1, 101));
    }
    if (argc > 3) {
        csv = std::string(argv[3]) == "--csv";
    }
    const int esikler[] = {1, 4, 8, 12, 16, 24, 32, 48, 64};
    rastgele_tohum(42);
    const std::vector<int> orijinal = rastgele_dizi(n, 0, 1000000000);
    std::vector<int> calisma(orijinal.size());
    if (csv) {
        std::cout << "esik;n;tekrar;ortanca_ms;islemci_ort_ms;"
                     "karsilastirma;tasima\n";
    } else {
        std::cout << "Melez sıralama: hızlı + araya ekleme, n = " << n
                  << " (tohum 42)\n";
        std::cout << " eşik  karşılaştırma     taşıma  araya ekleme  doğru\n";
    }
    for (int esik : esikler) {
        auto gorev = [&] {
            calisma = orijinal;
            melez_sirala(calisma, 0, n - 1, esik);
        };
        karsilastirma = tasima = araya_ekleme_cagrisi = 0;
        gorev();
        long long k = karsilastirma, t = tasima, c = araya_ekleme_cagrisi;
        bool dogru = sirali_mi(calisma);
        double c0 = islemci_sn();
        double sn = olc_ortanca(gorev, tekrar);
        double cpu = (islemci_sn() - c0) / (tekrar + 1);
        if (csv) {
            std::printf("%d;%d;%d;%.4f;%.4f;%lld;%lld\n", esik, n, tekrar,
                        sn * 1e3, cpu * 1e3, k, t);
        } else {
            std::cout << std::setw(5) << esik << " " << std::setw(14) << k
                      << " " << std::setw(10) << t << " " << std::setw(13)
                      << c << "  " << (dogru ? "evet" : "HAYIR") << "\n";
        }
        std::fprintf(stderr, "eşik %2d: %.3f ms (ortanca, %d tekrar; "
                     "işlemci ort. %.3f ms)\n", esik, sn * 1e3, tekrar,
                     cpu * 1e3);
    }
    if (!csv) {
        std::cout << "Eşik büyüdükçe karşılaştırma ve taşıma önce biraz "
                     "azalır, sonra artar\n(araya ekleme Θ(k²)); özyineleme "
                     "ve bölümleme yükü ise azalır: süre\ngenellikle bir ara "
                     "eşikte en kısadır (stderr; deneye bakın).\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (libstdc++: introsort
 * + 16 elemanlık eşikle araya ekleme); Python — list.sort (Timsort: kısa
 * parçalarda ikili araya ekleme) */

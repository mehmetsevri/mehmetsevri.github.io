/* H06_12_buyuk_deney.cpp — AP-2 Hafta 6 · Örnek 12 (★★★)
 * Amaç    : Haftanın Deneyi programı: birleştirmeli, hızlı (ilk / rastgele /
 *           üçün ortancası pivot), kütüphane (std::sort) ve araya ekleme
 *           sıralaması. Varsayılan çalıştırma küçük ve deterministiktir;
 *           ölçüm kipi bir yapılandırmayı ölçüp CSV satırı yazar.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_12_buyuk_deney.cpp -o H06_12_buyuk_deney
 * Çalıştır: ./H06_12_buyuk_deney   ya da   ./H06_12_buyuk_deney ALGORITMA
 *           GIRDI N TEKRAR   (ALGORITMA: birlestirmeli, hizli_ilk,
 *           hizli_rastgele, hizli_ortanca3, kutuphane, araya_ekleme;
 *           GIRDI: rastgele, sirali)
 * Eşleri  : c/H06_12_buyuk_deney.c · python/H06_12_buyuk_deney.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <algorithm>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

enum { BIRLESTIRMELI, HIZLI_ILK, HIZLI_RASTGELE, HIZLI_ORTANCA3, KUTUPHANE,
       ARAYA_EKLEME, ALGORITMA_SAYISI };
const char* const ALG_AD[] = {"birlestirmeli", "hizli_ilk", "hizli_rastgele",
                              "hizli_ortanca3", "kutuphane", "araya_ekleme"};
const char* const GIRDI_AD[] = {"rastgele", "sirali"};

static long long karsilastirma = 0;
static int agac_yuksekligi = 0, yigin_derinligi = 0;

// --- Birleştirmeli sıralama (Örnek 2; tek tampon) ---
static void birlestir(std::vector<int>& a, std::vector<int>& yrd, int lo,
                      int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
}

static void bs_ozyineli(std::vector<int>& a, std::vector<int>& yrd, int lo,
                        int hi, int d)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = agac_yuksekligi = d;
    }
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_ozyineli(a, yrd, lo, mid, d + 1);
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1);
    birlestir(a, yrd, lo, mid, hi);
}

// --- Hızlı sıralama (Örnek 6; küçük parçaya özyineleme) ---
static int ortanca3(const std::vector<int>& a, int i, int j, int k)
{
    karsilastirma += 2;
    if (a[i] < a[j]) {
        if (a[j] < a[k]) {
            return j;
        }
        karsilastirma++;
        return a[i] < a[k] ? k : i;
    }
    if (a[i] < a[k]) {
        return i;
    }
    karsilastirma++;
    return a[j] < a[k] ? k : j;
}

static int bolumle(std::vector<int>& a, int lo, int hi, int alg)
{
    int r = alg == HIZLI_ILK ? lo
          : alg == HIZLI_RASTGELE ? rastgele_aralik(lo, hi)
          : ortanca3(a, lo, lo + (hi - lo) / 2, hi);
    std::swap(a[r], a[hi]);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            std::swap(a[i], a[j]);
        }
    }
    std::swap(a[i + 1], a[hi]);
    return i + 1;
}

static void hizli_sirala(std::vector<int>& a, int lo, int hi, int alg, int d,
                         int t)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = d;
    }
    for (;;) {
        if (t > agac_yuksekligi) {
            agac_yuksekligi = t;
        }
        if (lo >= hi) {
            return;
        }
        int p = bolumle(a, lo, hi, alg);
        if (p - lo < hi - p) {
            hizli_sirala(a, lo, p - 1, alg, d + 1, t + 1);
            lo = p + 1;
        } else {
            hizli_sirala(a, p + 1, hi, alg, d + 1, t + 1);
            hi = p - 1;
        }
        t++;
    }
}

// --- Araya ekleme (H5) ve kütüphane ---
static void araya_ekleme(std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    for (int i = 1; i < n; i++) {
        int anahtar = a[i];
        int j = i - 1;
        while (j >= 0 && (karsilastirma++, a[j] > anahtar)) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

// Seçilen algoritmayla a'yı sıralar; yrd: n elemanlık tampon
static void sirala(std::vector<int>& a, std::vector<int>& yrd, int alg)
{
    int n = static_cast<int>(a.size());
    karsilastirma = 0;
    agac_yuksekligi = yigin_derinligi = 0;
    rastgele_tohum(2026);               // rastgele pivot dizisi sabit
    if (alg == BIRLESTIRMELI) {
        bs_ozyineli(a, yrd, 0, n - 1, 1);
    } else if (alg == KUTUPHANE) {
        std::sort(a.begin(), a.end());
    } else if (alg == ARAYA_EKLEME) {
        araya_ekleme(a);
    } else {
        hizli_sirala(a, 0, n - 1, alg, 1, 1);
    }
}

static std::vector<int> girdi_uret(int n, int girdi)
{
    if (girdi == 0) {
        rastgele_tohum(42);
        return rastgele_dizi(n, 0, 1000000000);
    }
    std::vector<int> a(n);
    for (int k = 0; k < n; k++) {
        a[k] = k;
    }
    return a;
}

// Doğruluk: sıralı mı ve eleman toplamı korunmuş mu (ucuz kâhin)
static bool dogru_mu(const std::vector<int>& a, long long toplam)
{
    long long s = 0;
    for (std::size_t k = 0; k < a.size(); k++) {
        s += a[k];
        if (k > 0 && a[k - 1] > a[k]) {
            return false;
        }
    }
    return s == toplam;
}

static long long toplami(const std::vector<int>& a)
{
    long long s = 0;
    for (int x : a) {
        s += x;
    }
    return s;
}

static int bul(const std::string& s, const char* const* adlar, int sayi)
{
    for (int k = 0; k < sayi; k++) {
        if (s == adlar[k]) {
            return k;
        }
    }
    return -1;
}

// Ölçüm kipi: 1 ısınma + tekrar ölçüm; ortanca/en az/en çok duvar saati
// ve ortanca işlemci zamanı (ms)
static int olcum(int alg, int girdi, int n, int tekrar)
{
    const std::vector<int> orijinal = girdi_uret(n, girdi);
    std::vector<int> a(n), yrd(n);
    std::vector<double> duvar, islemci;
    long long toplam = toplami(orijinal);
    for (int r = -1; r < tekrar; r++) {         // r = -1: ısınma
        a = orijinal;
        double t0 = zaman_sn(), c0 = islemci_sn();
        sirala(a, yrd, alg);
        double t1 = zaman_sn(), c1 = islemci_sn();
        if (r >= 0) {
            duvar.push_back((t1 - t0) * 1e3);
            islemci.push_back((c1 - c0) * 1e3);
        }
    }
    double en_az = *std::min_element(duvar.begin(), duvar.end());
    double en_cok = *std::max_element(duvar.begin(), duvar.end());
    std::printf("%s;%s;%d;%d;%.4f;%.4f;%.4f;%.4f;%lld;%d;%d;%d\n",
                ALG_AD[alg], GIRDI_AD[girdi], n, tekrar, ortanca(duvar),
                en_az, en_cok, ortanca(islemci),
                alg == KUTUPHANE ? -1LL : karsilastirma, agac_yuksekligi,
                yigin_derinligi, dogru_mu(a, toplam) ? 1 : 0);
    return 0;
}

int main(int argc, char* argv[])
{
    if (argc == 5) {
        int alg = bul(argv[1], ALG_AD, ALGORITMA_SAYISI);
        int girdi = bul(argv[2], GIRDI_AD, 2);
        long n = -1, tekrar = -1;
        try {
            n = std::stol(argv[3]);
            tekrar = std::stol(argv[4]);
        } catch (const std::exception&) {
            n = -1;
        }
        if (alg < 0 || girdi < 0 || n < 2 || n > 20000000 || tekrar < 1 ||
            tekrar > 101) {
            std::cerr << "hatalı argüman\n";
            return 2;
        }
        return olcum(alg, girdi, static_cast<int>(n),
                     static_cast<int>(tekrar));
    }
    if (argc != 1) {
        std::cerr << "Kullanım: " << argv[0]
                  << " [ALGORITMA GIRDI N TEKRAR]\n";
        return 2;
    }
    const int boyutlar[] = {1000, 10000};
    std::cout << "Büyük deney programı: varsayılan küçük çalıştırma "
                 "(süreler stderr'de)\n";
    std::cout << "algoritma       girdi         n  karşılaştırma  ağaç  "
                 "yığın  doğru\n";
    for (int girdi = 0; girdi < 2; girdi++) {
        for (int n : boyutlar) {
            if (girdi == 1 && n > 1000) {
                continue;               // hizli_ilk sıralıda Θ(n²)
            }
            const std::vector<int> orijinal = girdi_uret(n, girdi);
            long long toplam = toplami(orijinal);
            std::vector<int> yrd(n);
            for (int alg = 0; alg < ALGORITMA_SAYISI; alg++) {
                if (alg == ARAYA_EKLEME && girdi == 0 && n > 1000) {
                    continue;           // Θ(n²): ölçüm kipinde
                }
                std::vector<int> a = orijinal;
                double t0 = zaman_sn();
                sirala(a, yrd, alg);
                double ms = (zaman_sn() - t0) * 1e3;
                std::cout << std::left << std::setw(15) << ALG_AD[alg] << " "
                          << std::setw(8) << GIRDI_AD[girdi] << std::right
                          << " " << std::setw(6) << n;
                if (alg == KUTUPHANE) {
                    std::cout << " " << std::setw(14) << "-" << " "
                              << std::setw(5) << "-" << " " << std::setw(6)
                              << "-";
                } else {
                    std::cout << " " << std::setw(14) << karsilastirma << " "
                              << std::setw(5) << agac_yuksekligi << " "
                              << std::setw(6) << yigin_derinligi;
                }
                std::cout << "  " << (dogru_mu(a, toplam) ? "evet" : "HAYIR")
                          << "\n";
                std::fprintf(stderr, "%s %s n=%d: %.3f ms\n", ALG_AD[alg],
                             GIRDI_AD[girdi], n, ms);
            }
        }
    }
    std::cout << "Ölçüm kipi (deney/olcum_calistir.py kullanır):\n"
                 "  ALGORITMA GIRDI N TEKRAR → algoritma;girdi;n;tekrar;"
                 "ortanca_ms;\n  en_az_ms;en_cok_ms;islemci_ms;karsilastirma;"
                 "agac;yigin;dogru\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort (glibc; algoritma standartta yok);
 * C++ — std::sort (introsort); Python — list.sort (Timsort) */

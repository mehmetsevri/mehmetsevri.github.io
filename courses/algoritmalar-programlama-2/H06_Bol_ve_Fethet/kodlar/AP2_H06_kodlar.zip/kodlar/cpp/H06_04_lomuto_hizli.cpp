/* H06_04_lomuto_hizli.cpp — AP-2 Hafta 6 · Örnek 4 (★★)
 * Amaç    : Lomuto bölümleme (pivot = a[hi]) ve hızlı sıralama. Değişmez:
 *           a[lo..i] < pivot <= a[i+1..j-1]; a[j..hi-1] işlenmemiş.
 *           Rastgele girdide karşılaştırma ≈ 2(n+1)H(n) - 4n ≈ 1,39 n lg n.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_04_lomuto_hizli.cpp -o H06_04_lomuto_hizli
 * Çalıştır: ./H06_04_lomuto_hizli
 * Eşleri  : c/H06_04_lomuto_hizli.c · python/H06_04_lomuto_hizli.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0, takas_sayisi = 0;
static int en_derin = 0;

static void takas(std::vector<int>& a, int i, int j)
{
    std::swap(a[i], a[j]);
    takas_sayisi++;
}

// Pivot a[hi]; değişmez: a[lo..i] < pivot <= a[i+1..j-1]
int lomuto_bolumle(std::vector<int>& a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);  // pivot son yerine
    return i + 1;
}

// d: özyineleme derinliği (kök = 1)
void hizli_sirala(std::vector<int>& a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = lomuto_bolumle(a, lo, hi);
    hizli_sirala(a, lo, p - 1, d + 1);
    hizli_sirala(a, p + 1, hi, d + 1);
}

static void dizi_yaz(const std::vector<int>& a, int n)
{
    for (int k = 0; k < n; k++) {
        std::cout << " " << a[k];
    }
    std::cout << "\n";
}

// Bölümlemenin adım adım izlenmesi (aynı algoritma + çıktı)
static void lomuto_izle(std::vector<int>& a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    std::cout << " j  a[j]  karar           i  dizi\n";
    for (int j = lo; j < hi; j++) {
        bool kucuk = a[j] < pivot;
        int deger = a[j];
        if (kucuk) {
            i++;
            std::swap(a[i], a[j]);
        }
        std::cout << std::setw(2) << j << " " << std::setw(5) << deger << "  "
                  << (kucuk ? "< pivot, takas " : ">= pivot       ") << " "
                  << std::setw(2) << i << " ";
        dizi_yaz(a, hi + 1);
    }
    std::swap(a[i + 1], a[hi]);
    std::cout << "son takas a[" << i + 1 << "] <-> a[" << hi << "]: p = "
              << i + 1 << "    ";
    dizi_yaz(a, hi + 1);
}

// a'yı hızlı sıralamayla sıralar; kâhinle (std::sort) aynıysa true
static bool sinama(std::vector<int>& a)
{
    std::vector<int> kahin = a;
    std::sort(kahin.begin(), kahin.end());                    // kâhin
    karsilastirma = takas_sayisi = 0;
    en_derin = 0;
    hizli_sirala(a, 0, static_cast<int>(a.size()) - 1, 1);
    return a == kahin;
}

int main()
{
    std::vector<int> a = {6, 3, 8, 1, 7, 2, 5, 4};
    std::vector<int> b = a;
    std::cout << "Lomuto bölümleme (pivot = a[hi] = " << a[7]
              << "); değişmez:\n"
                 "a[lo..i] < pivot <= a[i+1..j-1], a[j..hi-1] işlenmemiş\n";
    std::cout << "başta: i = -1, dizi:";
    dizi_yaz(a, 8);
    lomuto_izle(a, 0, 7);
    karsilastirma = takas_sayisi = 0;
    int p = lomuto_bolumle(b, 0, 7);
    std::cout << "lomuto_bolumle: p = " << p << " · karşılaştırma = "
              << karsilastirma << " · takas = " << takas_sayisi << "\n\n";

    std::vector<int> c = {6, 3, 8, 1, 7, 2, 5, 4};
    sinama(c);
    std::cout << "Hızlı sıralama:";
    dizi_yaz(c, 8);
    std::cout << "karşılaştırma = " << karsilastirma << " · takas = "
              << takas_sayisi << " · en büyük derinlik = " << en_derin
              << "\n\n";

    const int boyutlar[] = {10, 100, 1000, 10000, 100000};
    std::cout << "Rastgele girdi (tohum 42, 0..10^9); beklenen = "
                 "2(n+1)H(n) - 4n\n";
    std::cout << "     n  karşılaştırma    beklenen  oran   takas  derinlik"
                 "  kâhin\n";
    for (int n : boyutlar) {
        rastgele_tohum(42);
        std::vector<int> x = rastgele_dizi(n, 0, 1000000000);
        bool ayni = sinama(x);
        double h = 0.0;
        for (int k = 1; k <= n; k++) {
            h += 1.0 / k;
        }
        double beklenen = 2.0 * (n + 1) * h - 4.0 * n;
        std::cout << std::setw(6) << n << " " << std::setw(14)
                  << karsilastirma << " " << std::fixed
                  << std::setprecision(0) << std::setw(11) << beklenen << " "
                  << std::setprecision(3) << std::setw(5)
                  << karsilastirma / beklenen << " " << std::setw(7)
                  << takas_sayisi << " " << std::setw(9) << en_derin << "  "
                  << (ayni ? "aynı" : "FARKLI") << "\n";
    }

    std::cout << "\nEn kötü durum: sıralı ve ters sıralı girdi (n = 500)\n";
    std::cout << "girdi    karşılaştırma  n(n-1)/2  derinlik  kâhin\n";
    for (int tur = 0; tur < 2; tur++) {
        std::vector<int> x(500);
        for (int k = 0; k < 500; k++) {
            x[k] = tur == 0 ? k : 500 - k;
        }
        bool ayni = sinama(x);
        std::cout << (tur == 0 ? "sıralı" : "ters  ") << " " << std::setw(14)
                  << karsilastirma << " " << std::setw(9) << 500 * 499 / 2
                  << " " << std::setw(9) << en_derin << "  "
                  << (ayni ? "aynı" : "FARKLI") << "\n";
    }
    std::cout << "Pivot hep en büyük/en küçük olunca bölünme n-1 | 0 olur:\n"
                 "T(n) = T(n-1) + n - 1 → Θ(n²), özyineleme derinliği n.\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritma belirtilmez); C++ — std::sort
 * (introsort; kararsız), std::partition (bölümleme); Python — list.sort /
 * sorted (Timsort; hızlı sıralama değildir) */

/* H06_02_birlestirmeli_siralama.cpp — AP-2 Hafta 6 · Örnek 2 (★★)
 * Amaç    : Birleştirmeli sıralama (yukarıdan aşağıya): böl, fethet,
 *           birleştir. Yardımcı tampon BİR KEZ ayrılır ve tüm çağrılarca
 *           paylaşılır. Sayaçlar: karşılaştırma, kopya, çağrı, derinlik.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_02_birlestirmeli_siralama.cpp \
 *           -o H06_02_birlestirmeli_siralama
 * Çalıştır: ./H06_02_birlestirmeli_siralama
 * Eşleri  : c/H06_02_birlestirmeli_siralama.c ·
 *           python/H06_02_birlestirmeli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0, kopya = 0, cagri = 0;
static int en_derin = 0, tampon_ayirma = 0;

// a[lo..mid] ve a[mid+1..hi] sıralı; yrd üzerinden a[lo..hi]'yi birleştirir
static void birlestir(std::vector<int>& a, std::vector<int>& yrd, int lo,
                      int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {  // eşitse soldan
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {  // geri kopyala
        a[k] = yrd[k];
    }
    kopya += 2LL * (hi - lo + 1);
}

// a[lo..hi]'yi sıralar; d: özyineleme derinliği (kök = 1)
static void bs_ozyineli(std::vector<int>& a, std::vector<int>& yrd, int lo,
                        int hi, int d)
{
    cagri++;
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {  // 0 ya da 1 eleman: sıralı
        return;
    }
    int mid = lo + (hi - lo) / 2;
    // böl ve fethet: iki yarıyı ayrı ayrı sırala
    bs_ozyineli(a, yrd, lo, mid, d + 1);
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1);
    birlestir(a, yrd, lo, mid, hi);  // birleştir
}

// Tek tampon: n elemanlık yrd bir kez ayrılır, kapsam sonunda bırakılır
void birlestirmeli_sirala(std::vector<int>& a)
{
    if (a.empty()) {
        return;
    }
    std::vector<int> yrd(a.size());
    tampon_ayirma++;
    int n = static_cast<int>(a.size());
    bs_ozyineli(a, yrd, 0, n - 1, 1);
}

static void dizi_yaz(const std::string& ad, const std::vector<int>& a)
{
    std::cout << ad << ": [";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i ? ", " : "") << a[i];
    }
    std::cout << "]\n";
}

// ⌈lg n⌉ (n >= 1): 2^k >= n olan en küçük k
static int tavan_log2(long long n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

static void sayaclari_sifirla()
{
    karsilastirma = kopya = cagri = 0;
    en_derin = tampon_ayirma = 0;
}

// a'yı sıralar; kâhinle (std::sort) karşılaştırıp true/false döndürür
static bool sinama(std::vector<int>& a)
{
    std::vector<int> kahin = a;
    std::sort(kahin.begin(), kahin.end());              // yalnızca kâhin
    sayaclari_sifirla();
    birlestirmeli_sirala(a);
    return a == kahin;
}

int main()
{
    std::vector<int> a = {6, 3, 8, 1, 7, 2, 5, 4};
    std::cout << "Birleştirmeli sıralama (yukarıdan aşağıya, tek tampon)\n";
    dizi_yaz("önce ", a);
    sayaclari_sifirla();
    birlestirmeli_sirala(a);
    dizi_yaz("sonra", a);
    std::cout << "karşılaştırma = " << karsilastirma << " · kopya = " << kopya
              << " · çağrı = " << cagri << " · derinlik = " << en_derin
              << "\ntampon ayırma = " << tampon_ayirma
              << " (her çağrıda değil, bir kez)\n\n";

    const std::size_t boyutlar[] = {1, 2, 3, 7, 8, 100, 1000, 1024,
                                    10000, 100000};
    std::cout << "Rastgele girdi (tohum 42, 0..999999) · W(n) = n⌈lg n⌉ - "
                 "2^⌈lg n⌉ + 1\n";
    std::cout << "     n  karşılaştırma        W(n)  çağrı  derinlik  kâhin\n";
    for (std::size_t n : boyutlar) {
        rastgele_tohum(42);
        std::vector<int> x = rastgele_dizi(n, 0, 999999);
        bool ayni = sinama(x);
        int k = tavan_log2(static_cast<long long>(n));
        long long w = static_cast<long long>(n) * k - (1LL << k) + 1;
        std::cout << std::setw(6) << n << " " << std::setw(14)
                  << karsilastirma << " " << std::setw(11) << w << " "
                  << std::setw(6) << cagri << " " << std::setw(9) << en_derin
                  << "  " << (ayni ? "aynı" : "FARKLI") << "\n";
    }
    std::cout << "çağrı = 2n - 1 · derinlik = ⌈lg n⌉ + 1 · karşılaştırma "
                 "<= W(n)\n\n";

    std::cout << "Girdi türünün etkisi (n = 1024, lg n = 10)\n";
    std::cout << "girdi      karşılaştırma   kopya  kâhin\n";
    for (int tur = 0; tur < 3; tur++) {
        const char* const adlar[] = {"rastgele", "sıralı  ", "ters    "};
        rastgele_tohum(42);
        std::vector<int> x = rastgele_dizi(1024, 0, 999999);
        for (int i = 0; i < 1024; i++) {
            if (tur == 1) {
                x[i] = i;
            } else if (tur == 2) {
                x[i] = 1024 - i;
            }
        }
        bool ayni = sinama(x);
        std::cout << adlar[tur] << " " << std::setw(15) << karsilastirma
                  << " " << std::setw(7) << kopya << "  "
                  << (ayni ? "aynı" : "FARKLI") << "\n";
    }
    std::cout << "Sıralı girdide bile (n/2)·lg n = " << 1024 / 2 * 10
              << " karşılaştırma ve 2n·lg n = " << 2 * 1024 * 10
              << " kopya:\n";
    std::cout << "birleştirmeli sıralama uyarlanabilir değildir; "
                 "Θ(n log n) her durumda.\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort algoritma belirtmez); C++ —
 * std::stable_sort (kararlı; genellikle birleştirmeli); Python — sorted /
 * list.sort (Timsort: birleştirmeli + araya ekleme melezi, kararlı) */

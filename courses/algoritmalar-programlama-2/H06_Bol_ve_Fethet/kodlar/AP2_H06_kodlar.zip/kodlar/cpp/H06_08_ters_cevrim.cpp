/* H06_08_ters_cevrim.cpp — AP-2 Hafta 6 · Örnek 8 (★★)
 * Amaç    : Ters çevrim (i < j ve a[i] > a[j]) sayısı birleştirmeli
 *           sıralamayla Θ(n log n): sağdan a[j] alınırken soldaki kalan
 *           mid - i + 1 elemanın hepsi a[j]'den büyüktür. Kâhin: H5'teki
 *           Θ(n²) çift taraması.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_08_ters_cevrim.cpp -o H06_08_ters_cevrim
 * Çalıştır: ./H06_08_ters_cevrim
 * Eşleri  : c/H06_08_ters_cevrim.c · python/H06_08_ters_cevrim.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma = 0, karsilastirma_kaba = 0;

// Birleştirirken ters çevrimleri sayar: a[lo..mid], a[mid+1..hi] sıralı
static long long birlestir_say(std::vector<int>& a, std::vector<int>& yrd,
                               int lo, int mid, int hi)
{
    long long sayi = 0;
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {  // eşitse sayılmaz
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
            sayi += mid - i + 1;  // hepsi > a[j]
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
    return sayi;
}

// a[lo..hi] içindeki ters çevrim sayısı; a sıralanmış olarak kalır
static long long ters_cevrim_bs(std::vector<int>& a, std::vector<int>& yrd,
                                int lo, int hi)
{
    if (lo >= hi) {
        return 0;
    }
    int mid = lo + (hi - lo) / 2;
    long long sol = ters_cevrim_bs(a, yrd, lo, mid);
    long long sag = ters_cevrim_bs(a, yrd, mid + 1, hi);
    return sol + sag + birlestir_say(a, yrd, lo, mid, hi);
}

// Girdiyi bozmamak için kopya üzerinde sayar
long long ters_cevrim_say(const std::vector<int>& a)
{
    std::vector<int> b = a;
    std::vector<int> yrd(a.size());
    return ters_cevrim_bs(b, yrd, 0, static_cast<int>(a.size()) - 1);
}

// Kâhin (H5): tüm i < j çiftleri, n(n-1)/2 karşılaştırma
long long ters_cevrim_kaba(const std::vector<int>& a)
{
    long long sayi = 0;
    int n = static_cast<int>(a.size());
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            karsilastirma_kaba++;
            if (a[i] > a[j]) {
                sayi++;
            }
        }
    }
    return sayi;
}

static void ciftleri_yaz(const std::vector<int>& a)
{
    int sayi = 0, n = static_cast<int>(a.size());
    std::cout << "çiftler:";
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                if (sayi > 0 && sayi % 8 == 0) {
                    std::cout << "\n        ";
                }
                std::cout << " (" << a[i] << "," << a[j] << ")";
                sayi++;
            }
        }
    }
    std::cout << "\n";
}

int main()
{
    const std::vector<int> k1 = {2, 4, 1, 3, 5};
    const std::vector<int> k2 = {6, 3, 8, 1, 7, 2, 5, 4};
    std::cout << "Ters çevrim: i < j ve a[i] > a[j]\n";
    std::cout << "[2, 4, 1, 3, 5]: birleştirmeli = " << ters_cevrim_say(k1)
              << " · kaba = " << ters_cevrim_kaba(k1) << "\n";
    ciftleri_yaz(k1);
    karsilastirma = karsilastirma_kaba = 0;
    long long t2 = ters_cevrim_say(k2);
    long long t2_kaba = ters_cevrim_kaba(k2);
    std::cout << "[6, 3, 8, 1, 7, 2, 5, 4]: birleştirmeli = " << t2 << " ("
              << karsilastirma << " karşılaştırma) · kaba = " << t2_kaba
              << " (" << karsilastirma_kaba << ")\n";
    ciftleri_yaz(k2);

    const int boyutlar[] = {10, 100, 1000, 3000};
    std::cout << "\nRastgele girdi (tohum 42, 0..999): birleştirmeli ↔ "
                 "kâhin\n";
    std::cout << "     n  ters çevrim  karş. (bs)  karş. (kaba)  kâhin\n";
    for (int n : boyutlar) {
        rastgele_tohum(42);
        std::vector<int> x = rastgele_dizi(n, 0, 999);
        karsilastirma = karsilastirma_kaba = 0;
        long long bs = ters_cevrim_say(x);
        long long kaba = ters_cevrim_kaba(x);
        std::cout << std::setw(6) << n << " " << std::setw(12) << bs << " "
                  << std::setw(11) << karsilastirma << " " << std::setw(13)
                  << karsilastirma_kaba << "  "
                  << (bs == kaba ? "aynı" : "FARKLI") << "\n";
    }

    const int n = 100000;
    std::cout << "\nn = " << n << " (kaba yöntem "
              << static_cast<long long>(n) * (n - 1) / 2
              << " karşılaştırma isterdi)\n";
    for (int tur = 0; tur < 3; tur++) {
        const char* const adlar[] = {"rastgele", "sıralı  ", "ters    "};
        rastgele_tohum(42);
        std::vector<int> x = rastgele_dizi(n, 0, 999999);
        for (int k = 0; k < n; k++) {
            if (tur == 1) {
                x[k] = k;
            } else if (tur == 2) {
                x[k] = n - k;
            }
        }
        karsilastirma = 0;
        long long bs = ters_cevrim_say(x);
        std::cout << adlar[tur] << " ters çevrim = " << std::setw(11) << bs
                  << " · karşılaştırma = " << karsilastirma << "\n";
    }
    std::cout << "Ters sıralıda n(n-1)/2 = "
              << static_cast<long long>(n) * (n - 1) / 2
              << "; araya ekleme sıralaması tam olarak\nters çevrim sayısı "
                 "kadar kaydırma yapar (H5).\n";
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Ters çevrim sayısı iki
 * sıralama arasındaki Kendall tau uzaklığıdır. */

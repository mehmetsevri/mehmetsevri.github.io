/* H06_K06_kutuphane.c — AP-2 Hafta 6 · Kavram 6 (Dil Penceresi)
 * Amaç    : C'nin tek sıralama aracı qsort: karşılaştırıcı işaretçisiyle
 *           çağrılır; algoritması ve kararlılığı standartta belirtilmez.
 *           Birleştirme ve seçim için C kitaplığında hazır işlev yoktur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_K06_kutuphane.c \
 *           -o H06_K06_kutuphane
 * Çalıştır: ./H06_K06_kutuphane
 * Eşleri  : kavram/H06_K06_kutuphane.cpp · kavram/H06_K06_kutuphane.py
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int puan;
    const char *ad;
} Kayit;

/* yalnız puan: eşit puanlıların sırası qsort'ta belirtilmemiştir */
static int puana_gore(const void *p, const void *q)
{
    const Kayit *x = p, *y = q;
    return (x->puan > y->puan) - (x->puan < y->puan);
}

int main(void)
{
    Kayit k[] = {{70, "Ali"}, {60, "Ece"}, {70, "Can"}, {85, "Naz"},
                 {60, "Ufuk"}};
    size_t n = sizeof k / sizeof k[0];
    qsort(k, n, sizeof k[0], puana_gore);
    printf("qsort:");
    for (size_t i = 0; i < n; i++) {
        printf(" %d %s ", k[i].puan, k[i].ad);
    }
    printf("\n(eşit puanlıların sırası bu C kitaplığına bağlıdır)\n");
    return 0;
}

/* Kütüphane karşılığı: bu dosyanın kendisi kütüphane kullanımını gösterir */

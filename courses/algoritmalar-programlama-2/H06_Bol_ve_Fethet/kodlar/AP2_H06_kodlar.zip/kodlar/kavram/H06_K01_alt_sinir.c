/* H06_K01_alt_sinir.c — AP-2 Hafta 6 · Kavram 1 (karar ağacı, Büyük Soru)
 * Amaç    : Karşılaştırmaya dayalı sıralamanın alt sınırı ⌈lg n!⌉ ile
 *           n lg n ve birleştirmeli sıralamanın en kötü durumu W(n);
 *           n = 10^9 için n² ile n lg n işlem sayısı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_K01_alt_sinir.c \
 *           -o H06_K01_alt_sinir -lm
 * Çalıştır: ./H06_K01_alt_sinir
 * Çıktı   : tek dil (C); lg(n!) = lgamma(n + 1) / ln 2
 */
#include <math.h>
#include <stdio.h>

/* lg(n!): n! sayısının bit uzunluğu (karar ağacı yüksekliğinin alt sınırı) */
static double lg_faktoriyel(double n)
{
    return lgamma(n + 1.0) / log(2.0);
}

static int tavan_log2(long long n)
{
    int k = 0;
    long long p = 1;
    while (p < n) {
        p *= 2;
        k++;
    }
    return k;
}

int main(void)
{
    static const long long ns[] = {3, 4, 8, 16, 1000, 1000000, 1000000000};
    printf("Karar ağacı alt sınırı: en kötü durumda en az ⌈lg n!⌉ "
           "karşılaştırma\n");
    printf("         n          lg(n!)          n·lg n            W(n)"
           "  lg(n!)/(n·lg n)\n");
    for (int t = 0; t < 7; t++) {
        long long n = ns[t];
        int k = tavan_log2(n);
        double lf = lg_faktoriyel((double)n);
        double nlg = (double)n * log2((double)n);
        long long w = n * k - (1LL << k) + 1;  /* birleştirmeli, en kötü */
        printf("%10lld %15.1f %15.1f %15lld  %.3f\n", n, lf, nlg, w,
               lf / nlg);
    }
    printf("\nKüçük n için tamsayı sınır ve birleştirmeli sıralama\n");
    printf("   n   n!          ⌈lg n!⌉  W(n)\n");
    long long f = 1;
    for (int n = 1; n <= 12; n++) {
        f *= n;
        int k = tavan_log2(n);
        printf("%4d   %-10lld  %7d  %4lld\n", n, f,
               (int)ceil(lg_faktoriyel(n) - 1e-9), n * k - (1LL << k) + 1);
    }
    double n = 1e9;
    printf("\nBüyük Soru: n = 10^9 kayıt\n");
    printf("n²     = %.3e işlem\n", n * n);
    printf("n·lg n = %.3e işlem\n", n * log2(n));
    printf("oran n² / (n·lg n) = n / lg n = %.3e\n", n / log2(n));
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::lgamma; Python — math.lgamma */

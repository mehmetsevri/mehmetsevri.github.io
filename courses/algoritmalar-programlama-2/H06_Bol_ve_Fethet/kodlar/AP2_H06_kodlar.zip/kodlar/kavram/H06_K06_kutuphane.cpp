/* H06_K06_kutuphane.cpp — AP-2 Hafta 6 · Kavram 6 (Dil Penceresi)
 * Amaç    : Haftanın algoritmalarının C++ kütüphane karşılıkları:
 *           std::sort (kararsız), std::stable_sort (kararlı), std::merge,
 *           std::nth_element (ortanca, ortalama doğrusal)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H06_K06_kutuphane.cpp \
 *           -o H06_K06_kutuphane
 * Çalıştır: ./H06_K06_kutuphane
 * Eşleri  : kavram/H06_K06_kutuphane.c · kavram/H06_K06_kutuphane.py
 */
#include <algorithm>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

using Kayit = std::pair<int, std::string>;  // (puan, ad)

static void yaz(const std::vector<Kayit>& v)
{
    for (const auto& [puan, ad] : v) {
        std::cout << puan << ' ' << ad << "  ";
    }
    std::cout << '\n';
}

int main()
{
    const std::vector<Kayit> kayitlar = {
        {70, "Ali"}, {60, "Ece"}, {70, "Can"}, {85, "Naz"}, {60, "Ufuk"}};
    auto puana_gore = [](const Kayit& x, const Kayit& y) {
        return x.first < y.first;  // yalnız puan: eşitler ayırt edilmez
    };
    std::vector<Kayit> k1 = kayitlar;
    std::stable_sort(k1.begin(), k1.end(), puana_gore);  // kararlı
    std::cout << "stable_sort: ";
    yaz(k1);

    std::vector<int> a = {2, 5, 7, 9}, b = {1, 5, 6, 10, 12};
    std::vector<int> c(a.size() + b.size());
    std::merge(a.begin(), a.end(), b.begin(), b.end(), c.begin());
    std::cout << "merge:";
    for (int x : c) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';

    std::vector<int> notlar = {72, 45, 88, 61, 95, 53, 77, 61, 84};
    auto orta = notlar.begin() + notlar.size() / 2;
    std::nth_element(notlar.begin(), orta, notlar.end());
    std::cout << "nth_element ortanca: " << *orta << '\n';

    std::vector<int> d = {6, 3, 8, 1, 7, 2, 5, 4};
    std::sort(d.begin(), d.end());  // libstdc++: introsort
    std::cout << "sort:";
    for (int x : d) {
        std::cout << ' ' << x;
    }
    std::cout << '\n';
    return 0;
}

/* Kütüphane karşılığı: bu dosyanın kendisi kütüphane kullanımını gösterir */

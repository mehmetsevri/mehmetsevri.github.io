/* H06_K02_bagintilar.c — AP-2 Hafta 6 · Kavram 2 (yerine koyma yöntemi)
 * Amaç    : Dört yineleme bağıntısını özyinelemeyle hesaplayıp yerine koyma
 *           (açılım) yöntemiyle bulunan kapalı biçimlerle karşılaştırır
 *           (n = 2^k; T(1) = 1)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_K02_bagintilar.c \
 *           -o H06_K02_bagintilar
 * Çalıştır: ./H06_K02_bagintilar
 * Çıktı   : tek dil (C)
 */
#include <stdio.h>

/* birleştirmeli sıralama: iki yarı + doğrusal birleştirme */
static long long t_bs(long long n)
{
    return n <= 1 ? 1 : 2 * t_bs(n / 2) + n;
}

/* en kötü hızlı sıralama: n - 1 | 0 bölünme */
static long long t_zincir(long long n)
{
    return n <= 1 ? 1 : t_zincir(n - 1) + n;
}

/* ikili arama (H4): yarıya in + sabit iş */
static long long t_ikili(long long n)
{
    return n <= 1 ? 1 : t_ikili(n / 2) + 1;
}

/* iki yarı + sabit iş (ör. en büyük elemanı böl ve fethetle bulmak) */
static long long t_iki_sabit(long long n)
{
    return n <= 1 ? 1 : 2 * t_iki_sabit(n / 2) + 1;
}

int main(void)
{
    printf("n = 2^k   2T(n/2)+n  n·k+n   T(n-1)+n  n(n+1)/2  T(n/2)+1  k+1"
           "  2T(n/2)+1  2n-1\n");
    int hepsi = 1;
    for (int k = 0; k <= 12; k++) {
        long long n = 1LL << k;
        long long a = t_bs(n), b = t_zincir(n), c = t_ikili(n);
        long long d = t_iki_sabit(n);
        hepsi = hepsi && a == n * k + n && b == n * (n + 1) / 2
                && c == k + 1 && d == 2 * n - 1;
        printf("%7lld %10lld %6lld %10lld %9lld %9lld %4d %10lld %5lld\n",
               n, a, n * k + n, b, n * (n + 1) / 2, c, k + 1, d, 2 * n - 1);
    }
    printf("kapalı biçimler bağıntılarla %s\n", hepsi ? "aynı" : "FARKLI");
    printf("Sınıflar: Θ(n log n), Θ(n²), Θ(log n), Θ(n)\n");
    return 0;
}

/* Kütüphane karşılığı: yok (yalnızca aritmetik) */

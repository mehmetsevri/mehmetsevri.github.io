"""H06_K05_dilim.py — AP-2 Hafta 6 · Kavram 5 (Dil Penceresi)
Amaç    : Python'da dilim (a[lo:hi]) yeni bir liste kopyalar; ad bağlama
          (c = a) kopyalamaz. Özyineleme sınırı derinliği sınırlar.
Çalıştır: python3 H06_K05_dilim.py
Not     : C/C++'ta (a, lo, hi) indis aralığı ya da işaretçi kopyasızdır.
"""

import sys


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    b = a[2:5]          # yeni liste: 3 eleman kopyalanır
    b[0] = 99           # a etkilenmez
    print("a =", a)
    print("b =", b, "· b is a:", b is a)
    c = a               # aynı listeye ikinci ad: kopya yok
    c[0] = 0
    print("c = a; c[0] = 0 → a =", a)
    print("özyineleme sınırı:", sys.getrecursionlimit())


if __name__ == "__main__":
    main()

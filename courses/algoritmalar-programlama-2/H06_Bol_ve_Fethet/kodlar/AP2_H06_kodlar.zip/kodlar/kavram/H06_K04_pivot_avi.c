/* H06_K04_pivot_avi.c — AP-2 Hafta 6 · Kavram 4 (Atölye 2: pivot avı)
 * Amaç    : Bir girdinin hızlı sıralamayı ne kadar zorladığını ölçer:
 *           Örnek 6'nın Lomuto + küçük parçaya özyineleme sürümü, üç pivot
 *           stratejisiyle (ilk / rastgele / üçün ortancası) karşılaştırma
 *           sayısı ve n(n-1)/2'ye oranı (1,00 = tam karesel)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_K04_pivot_avi.c \
 *           ortak_rastgele.c -o H06_K04_pivot_avi
 * Çalıştır: ./H06_K04_pivot_avi            (hazır desenler, n = 1000)
 *           ./H06_K04_pivot_avi girdi.txt  (kendi deseniniz: boşlukla ayrık)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

enum { ILK = 0, RASTGELE = 1, ORTANCA3 = 2, AZAMI = 100000 };
static long long karsilastirma = 0;

static int kucuk(int x, int y)
{
    karsilastirma++;
    return x < y;
}

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
}

static int ortanca3(const int *a, int i, int j, int k)
{
    if (kucuk(a[i], a[j])) {
        if (kucuk(a[j], a[k])) {
            return j;
        }
        return kucuk(a[i], a[k]) ? k : i;
    }
    if (kucuk(a[i], a[k])) {
        return i;
    }
    return kucuk(a[j], a[k]) ? k : j;
}

static int pivot_sec(const int *a, int lo, int hi, int s)
{
    if (s == ILK) {
        return lo;
    }
    if (s == RASTGELE) {
        return rastgele_aralik(lo, hi);
    }
    return ortanca3(a, lo, lo + (hi - lo) / 2, hi);
}

static int bolumle(int *a, int lo, int hi, int s)
{
    takas(a, pivot_sec(a, lo, hi, s), hi);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (kucuk(a[j], pivot)) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

static void hizli(int *a, int lo, int hi, int s)
{
    while (lo < hi) {
        int p = bolumle(a, lo, hi, s);
        if (p - lo < hi - p) {
            hizli(a, lo, p - 1, s);
            lo = p + 1;
        } else {
            hizli(a, p + 1, hi, s);
            hi = p - 1;
        }
    }
}

static int girdi[AZAMI], calisma[AZAMI];

/* Türkçe harfler UTF-8'de 2 bayttır: genişliği karakter sayısına göre doldur */
static void sola_yasla(const char *s, int genislik)
{
    int n = 0;
    for (const char *p = s; *p; p++) {
        n += ((unsigned char)*p & 0xC0) != 0x80;
    }
    printf("%s%*s", s, genislik > n ? genislik - n : 0, "");
}

static void olc(const char *ad, int n)
{
    double karesel = (double)n * (n - 1) / 2.0;
    sola_yasla(ad, 14);
    printf("%6d", n);
    for (int s = 0; s < 3; s++) {
        for (int i = 0; i < n; i++) {
            calisma[i] = girdi[i];
        }
        karsilastirma = 0;
        rastgele_tohum(2026);
        hizli(calisma, 0, n - 1, s);
        printf(" %10lld %5.2f", karsilastirma,
               karesel > 0 ? karsilastirma / karesel : 0.0);
    }
    printf("\n");
}

int main(int argc, char *argv[])
{
    printf("oran = karşılaştırma / (n(n-1)/2); 1,00 = tam karesel\n");
    printf("desen              n        ilk  oran   rastgele  oran   "
           "ortanca3  oran\n");
    if (argc == 2) {
        FILE *f = fopen(argv[1], "r");
        int n = 0;
        if (f == NULL) {
            fprintf(stderr, "dosya açılamadı: %s\n", argv[1]);
            return 1;
        }
        while (n < AZAMI && fscanf(f, "%d", &girdi[n]) == 1) {
            n++;
        }
        fclose(f);
        olc(argv[1], n);
        return 0;
    }
    const int n = 1000;
    for (int i = 0; i < n; i++) {
        girdi[i] = i;
    }
    olc("sıralı", n);
    for (int i = 0; i < n; i++) {
        girdi[i] = n - i;
    }
    olc("ters", n);
    for (int i = 0; i < n; i++) {
        girdi[i] = i < n / 2 ? i : n - 1 - i;
    }
    olc("organ borusu", n);
    for (int i = 0; i < n; i++) {
        girdi[i] = 7;
    }
    olc("tümü eşit", n);
    rastgele_tohum(42);
    rastgele_dizi(girdi, (size_t)n, 0, 1000000000);
    olc("rastgele", n);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (introsort); Python —
 * list.sort (Timsort; hızlı sıralama değildir) */

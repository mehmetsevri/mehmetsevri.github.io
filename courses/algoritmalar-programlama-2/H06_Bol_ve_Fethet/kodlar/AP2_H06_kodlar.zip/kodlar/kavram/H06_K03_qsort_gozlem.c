/* H06_K03_qsort_gozlem.c — AP-2 Hafta 6 · Kavram 3 (Dil Penceresi, Kaput)
 * Amaç    : Bu makinedeki C kitaplığının qsort'u kaç kez karşılaştırıcı
 *           çağırıyor ve eşit anahtarların sırasını koruyor mu? (gözlem;
 *           C standardı algoritmayı ve kararlılığı belirtmez)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_K03_qsort_gozlem.c \
 *           ortak_rastgele.c -o H06_K03_qsort_gozlem
 * Çalıştır: ./H06_K03_qsort_gozlem
 * Çıktı   : tek dil (C); sonuç C kitaplığına ve sürümüne bağlıdır
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    int anahtar, sira;
} Kayit;

static long long cagri = 0;

static int kars(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    cagri++;
    return (x > y) - (x < y);
}

static int kars_kayit(const void *p, const void *q)
{
    const Kayit *x = p, *y = q;
    return (x->anahtar > y->anahtar) - (x->anahtar < y->anahtar);
}

static int a[100000];
static Kayit b[5000];

int main(void)
{
    static const int ns[] = {8, 1000, 1024, 100000};
    printf("qsort karşılaştırıcı çağrısı (rastgele girdi, tohum 42, "
           "0..999999)\n");
    for (int t = 0; t < 4; t++) {
        rastgele_tohum(42);
        rastgele_dizi(a, (size_t)ns[t], 0, 999999);
        cagri = 0;
        qsort(a, (size_t)ns[t], sizeof a[0], kars);
        printf("n = %6d: %8lld çağrı\n", ns[t], cagri);
    }
    for (int i = 0; i < 1024; i++) {
        a[i] = i;
    }
    cagri = 0;
    qsort(a, 1024, sizeof a[0], kars);
    printf("sıralı n = 1024: %lld çağrı\n", cagri);

    int bozulan = 0;
    rastgele_tohum(7);
    for (int d = 0; d < 200; d++) {
        for (int i = 0; i < 5000; i++) {
            b[i].anahtar = rastgele_aralik(0, 9);
            b[i].sira = i;
        }
        qsort(b, 5000, sizeof b[0], kars_kayit);
        for (int i = 1; i < 5000; i++) {
            if (b[i - 1].anahtar == b[i].anahtar
                && b[i - 1].sira > b[i].sira) {
                bozulan++;
                break;
            }
        }
    }
    printf("200 denemede (n = 5000, anahtar 0..9) eşitlerin sırası "
           "bozulan: %d\n", bozulan);
    return 0;
}

/* Kütüphane karşılığı: C — qsort (gözlenen); C++ — std::sort /
 * std::stable_sort; Python — list.sort (kararlı olduğu belgelenmiştir) */

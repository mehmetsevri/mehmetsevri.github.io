"""H06_K06_kutuphane.py — AP-2 Hafta 6 · Kavram 6 (Dil Penceresi)
Amaç    : Haftanın algoritmalarının Python kütüphane karşılıkları:
          sorted / list.sort (Timsort, kararlı), heapq.merge,
          statistics.median (sıralayarak), heapq.nsmallest
Çalıştır: python3 H06_K06_kutuphane.py
Eşleri  : kavram/H06_K06_kutuphane.c · kavram/H06_K06_kutuphane.cpp
"""

import heapq
import statistics


def main():
    kayitlar = [(70, "Ali"), (60, "Ece"), (70, "Can"), (85, "Naz"),
                (60, "Ufuk")]
    k1 = sorted(kayitlar, key=lambda k: k[0])   # kararlı (Timsort)
    print("sorted:", "  ".join(f"{p} {a}" for p, a in k1))

    a, b = [2, 5, 7, 9], [1, 5, 6, 10, 12]
    print("merge:", *heapq.merge(a, b))          # iki sıralı akış

    notlar = [72, 45, 88, 61, 95, 53, 77, 61, 84]
    print("median ortanca:", statistics.median(notlar))
    print("en küçük 3:", heapq.nsmallest(3, notlar))

    d = [6, 3, 8, 1, 7, 2, 5, 4]
    d.sort()                                     # yerinde
    print("sort:", *d)


if __name__ == "__main__":
    main()

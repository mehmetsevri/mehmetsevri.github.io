/* H06_A06_sort_kararlilik.cpp — AP-2 Hafta 6 · Alıştırma 6.16 (diller arası)
 * Amaç    : std::sort ile std::stable_sort eşit anahtarlarda ne yapar?
 *           n küçükken bozulma görülmemesi std::sort'un kararlı olduğunu
 *           gösterir mi? Önce tahmin edin, sonra çalıştırın.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_A06_sort_kararlilik.cpp -o H06_A06_sort_kararlilik
 * Çalıştır: ./H06_A06_sort_kararlilik
 */
#include <algorithm>
#include <iostream>
#include <utility>
#include <vector>

// (anahtar, giriş sırası); yalnız anahtara göre sıralanır
static int bozulan(int n, bool kararli)
{
    std::vector<std::pair<int, int>> v;
    for (int i = 0; i < n; i++) {
        v.push_back({(i * 7) % 3, i});  // anahtarlar 0, 1, 2 tekrar eder
    }
    auto kars = [](const auto& x, const auto& y) { return x.first < y.first; };
    if (kararli) {
        std::stable_sort(v.begin(), v.end(), kars);
    } else {
        std::sort(v.begin(), v.end(), kars);
    }
    int b = 0;
    for (int i = 1; i < n; i++) {
        b += v[i - 1].first == v[i].first && v[i - 1].second > v[i].second;
    }
    return b;
}

int main()
{
    for (int n : {8, 16, 40, 1000}) {
        std::cout << "n = " << n << ": sort bozulan komşu = "
                  << bozulan(n, false)
                  << " · stable_sort = " << bozulan(n, true) << '\n';
    }
    return 0;
}

"""H06_A05_dilimli_bs.py — AP-2 Hafta 6 · Alıştırma 6.15 (diller arası okuma)
Amaç    : Dilimlerle yazılmış birleştirmeli sıralama: a değişir mi, kaç
          yeni liste oluşur? Önce tahmin edin, sonra çalıştırın.
Çalıştır: python3 H06_A05_dilimli_bs.py
"""

liste_sayisi = 0


def birlestir(x, y):
    global liste_sayisi
    liste_sayisi += 1
    c, i, j = [], 0, 0
    while i < len(x) and j < len(y):
        if x[i] <= y[j]:
            c.append(x[i])
            i += 1
        else:
            c.append(y[j])
            j += 1
    return c + x[i:] + y[j:]


def bs(a):
    global liste_sayisi
    if len(a) <= 1:
        return a
    m = len(a) // 2
    liste_sayisi += 2                  # a[:m] ve a[m:] yeni listelerdir
    return birlestir(bs(a[:m]), bs(a[m:]))


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    s = bs(a)
    print("a =", a)
    print("s =", s)
    print("oluşturulan liste (en az):", liste_sayisi)


if __name__ == "__main__":
    main()

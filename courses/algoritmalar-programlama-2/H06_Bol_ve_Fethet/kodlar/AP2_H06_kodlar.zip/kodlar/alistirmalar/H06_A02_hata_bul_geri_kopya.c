/* H06_A02_hata_bul_geri_kopya.c — AP-2 Hafta 6 · Alıştırma 6.9 (hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: birleştirmeli sıralama bazı girdilerde
 * yanlış sonuç veriyor. Hatalı satırı bulun ve tek karakterle düzeltin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_A02_hata_bul_geri_kopya.c -o H06_A02_hata_bul_geri_kopya
 * Çalıştır: ./H06_A02_hata_bul_geri_kopya
 */
#include <stdio.h>

static void birlestir(int *a, int *yrd, int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k < hi; k++) {  /* geri kopyala */
        a[k] = yrd[k];
    }
}

static void bs(int *a, int *yrd, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs(a, yrd, lo, mid);
    bs(a, yrd, mid + 1, hi);
    birlestir(a, yrd, lo, mid, hi);
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4}, yrd[8];
    bs(a, yrd, 0, 7);
    for (int k = 0; k < 8; k++) {
        printf("%d ", a[k]);
    }
    printf("\n");
    return 0;
}

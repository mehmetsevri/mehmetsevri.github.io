/* H06_A01_cagri_sirasi.c — AP-2 Hafta 6 · Alıştırma 6.1 (çıktı tahmini)
 * Amaç    : Birleştirmeli sıralamanın çağrı ağacında birleştirmelerin
 *           hangi sırayla yapıldığını izleyin (önce tahmin, sonra çalıştır)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_A01_cagri_sirasi.c \
 *           -o H06_A01_cagri_sirasi
 * Çalıştır: ./H06_A01_cagri_sirasi
 */
#include <stdio.h>

static int cagri = 0;

static void bs(int lo, int hi)
{
    cagri++;
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs(lo, mid);
    bs(mid + 1, hi);
    printf("[%d..%d] ", lo, hi);  /* birleştirme burada yapılırdı */
}

int main(void)
{
    bs(0, 5);
    printf("\ncagri = %d\n", cagri);
    return 0;
}

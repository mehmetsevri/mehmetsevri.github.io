/* H06_A03_hata_bul_ters_cevrim.c — AP-2 Hafta 6 · Alıştırma 6.10 (hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: ters çevrim sayısı kâhinden farklı çıkıyor.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_A03_hata_bul_ters_cevrim.c -o H06_A03_hata_bul_ters_cevrim
 * Çalıştır: ./H06_A03_hata_bul_ters_cevrim
 */
#include <stdio.h>

static long long birlestir_say(int *a, int *yrd, int lo, int mid, int hi)
{
    long long sayi = 0;
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
            sayi += mid - i;  /* soldaki kalanlar a[j]'den büyük */
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
    return sayi;
}

static long long ters_cevrim(int *a, int *yrd, int lo, int hi)
{
    if (lo >= hi) {
        return 0;
    }
    int mid = lo + (hi - lo) / 2;
    long long sol = ters_cevrim(a, yrd, lo, mid);
    long long sag = ters_cevrim(a, yrd, mid + 1, hi);
    return sol + sag + birlestir_say(a, yrd, lo, mid, hi);
}

static long long kaba(const int *a, int n)
{
    long long s = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            s += a[i] > a[j];
        }
    }
    return s;
}

int main(void)
{
    int a[] = {2, 4, 1, 3, 5}, yrd[5];
    long long k = kaba(a, 5);
    long long b = ters_cevrim(a, yrd, 0, 4);
    printf("birleştirmeli = %lld · kaba = %lld\n", b, k);
    return 0;
}

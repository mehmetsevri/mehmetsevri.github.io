/* H06_A04_parsons_hoare.c — AP-2 Hafta 6 · Alıştırma 6.11 (Parsons)
 * Hoare bölümlemenin satırları karıştırıldı: tamamlanacak; bu hâliyle
 * derlenmez. Satırları doğru sıraya ve girintiye koyun (pivot x = a[lo];
 * dönüş j: a[lo..j] <= x <= a[j+1..hi]). Sonra Örnek 5 ile karşılaştırın.
 */
int hoare_bolumle(int *a, int lo, int hi)
{
    int x = a[lo];
    int i = lo - 1, j = hi + 1;
        if (i >= j) {
        } while (a[i] < x);
    for (;;) {
            j--;
            return j;
        takas(a, i, j);
        do {
        } while (a[j] > x);
            i++;
        do {
        }
    }
}

/* H06_01_birlestirme.c — AP-2 Hafta 6 · Örnek 1 (★)
 * Amaç    : İki sıralı dizinin doğrusal zamanda birleştirilmesi; değişmez:
 *           c[0..k-1] sıralıdır ve a[0..i-1] ile b[0..j-1]'in tamamıdır.
 *           Eşitlikte soldan almak (<=) birleştirmeyi kararlı yapar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_01_birlestirme.c \
 *           ortak_rastgele.c -o H06_01_birlestirme
 * Çalıştır: ./H06_01_birlestirme
 * Eşleri  : cpp/H06_01_birlestirme.cpp · python/H06_01_birlestirme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    int puan;
    const char *ad;
} Kayit;

static long long karsilastirma = 0;

/* a[0..na-1] ve b[0..nb-1] sıralı; c[0..na+nb-1] sıralı birleşim olur */
void birlestir(const int *a, size_t na, const int *b, size_t nb, int *c)
{
    size_t i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        karsilastirma++;
        if (a[i] <= b[j]) {  /* eşitse soldan */
            c[k++] = a[i++];
        } else {
            c[k++] = b[j++];
        }
    }
    while (i < na) {  /* sol dizinin kalanı */
        c[k++] = a[i++];
    }
    while (j < nb) {  /* sağ dizinin kalanı */
        c[k++] = b[j++];
    }
}

static void dizi_yaz(const char *ad, const int *a, size_t n)
{
    printf("%s = [", ad);
    for (size_t i = 0; i < n; i++) {
        printf("%s%d", i ? ", " : "", a[i]);
    }
    printf("]\n");
}

/* Aynı algoritma; her adımda i, j ve karşılaştırmayı yazar */
static void birlestir_izleyerek(const int *a, size_t na, const int *b,
                                size_t nb, int *c)
{
    size_t i = 0, j = 0, k = 0;
    printf("adım  i  j  karşılaştırma          alınan\n");
    while (i < na && j < nb) {
        int soldan = a[i] <= b[j];
        printf("%4zu %2zu %2zu  a[%zu]=%d %s b[%zu]=%d", k + 1, i, j, i,
               a[i], soldan ? "<=" : "> ", j, b[j]);
        if (soldan) {
            printf("   a'dan %d%s\n", a[i],
                   a[i] == b[j] ? "  (eşitlik: soldan)" : "");
            c[k++] = a[i++];
        } else {
            printf("   b'den %d\n", b[j]);
            c[k++] = b[j++];
        }
    }
    printf("kalan: %s; kopyalanan %zu eleman\n",
           i < na ? "sol dizi" : "sağ dizi", (na - i) + (nb - j));
    while (i < na) {
        c[k++] = a[i++];
    }
    while (j < nb) {
        c[k++] = b[j++];
    }
}

/* Kararlılık gösterimi: kayıtlar yalnızca puana göre birleştirilir */
void birlestir_kayit(const Kayit *a, size_t na, const Kayit *b, size_t nb,
                     Kayit *c)
{
    size_t i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        if (a[i].puan <= b[j].puan) {
            c[k++] = a[i++];
        } else {
            c[k++] = b[j++];
        }
    }
    while (i < na) {
        c[k++] = a[i++];
    }
    while (j < nb) {
        c[k++] = b[j++];
    }
}

/* Artan sıralı (yinelemeli değerli) rastgele dizi: a[i] = a[i-1] + 0..3 */
static void sirali_uret(int *a, size_t n)
{
    int x = rastgele_aralik(0, 5);
    for (size_t i = 0; i < n; i++) {
        x += rastgele_aralik(0, 3);
        a[i] = x;
    }
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

int main(void)
{
    const int a[] = {2, 5, 7, 9};
    const int b[] = {1, 5, 6, 10, 12};
    int c[9];
    printf("İki sıralı dizinin birleştirilmesi\n");
    dizi_yaz("a", a, 4);
    dizi_yaz("b", b, 5);
    birlestir_izleyerek(a, 4, b, 5, c);
    dizi_yaz("c", c, 9);
    birlestir(a, 4, b, 5, c);
    printf("karşılaştırma = %lld (en çok na + nb - 1 = %d)\n\n",
           karsilastirma, 4 + 5 - 1);

    const Kayit sol[] = {{55, "Ali"}, {70, "Can"}, {70, "Ece"}, {85, "Naz"}};
    const Kayit sag[] = {{60, "Bora"}, {70, "Deniz"}, {90, "Ufuk"}};
    Kayit k[7];
    birlestir_kayit(sol, 4, sag, 3, k);
    printf("Kararlılık: puanı 70 olanlar (sol: Can, Ece; sağ: Deniz)\n");
    for (size_t i = 0; i < 7; i++) {
        printf("%s%d %s", i ? ", " : "", k[i].puan, k[i].ad);
    }
    printf("\n<= ile eşit puanlılar özgün sırayı korur (soldakiler önce)\n\n");

    static const size_t boyutlar[][2] = {{0, 0}, {0, 3}, {4, 0}, {1, 1},
                                         {5, 5}, {100, 37}, {1000, 1000},
                                         {50000, 70000}};
    rastgele_tohum(42);
    printf("Rastgele sıralı diziler (tohum 42) ve kâhin "
           "(kütüphane sıralaması)\n");
    printf("    na     nb  karşılaştırma  alt   üst      kâhin\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        size_t na = boyutlar[t][0], nb = boyutlar[t][1], n = na + nb;
        int *x = malloc((na + 1) * sizeof *x);
        int *y = malloc((nb + 1) * sizeof *y);
        int *z = malloc((n + 1) * sizeof *z);
        int *d = malloc((n + 1) * sizeof *d);
        if (x == NULL || y == NULL || z == NULL || d == NULL) {
            fprintf(stderr, "bellek yetersiz\n");
            return 1;
        }
        sirali_uret(x, na);
        sirali_uret(y, nb);
        karsilastirma = 0;
        birlestir(x, na, y, nb, z);
        for (size_t i = 0; i < na; i++) {
            d[i] = x[i];
        }
        for (size_t i = 0; i < nb; i++) {
            d[na + i] = y[i];
        }
        qsort(d, n, sizeof *d, kucukten_buyuge);     /* yalnızca kâhin */
        int ayni = 1;
        for (size_t i = 0; i < n; i++) {
            ayni = ayni && z[i] == d[i];
        }
        size_t alt = na < nb ? na : nb;
        size_t ust = (na && nb) ? n - 1 : 0;
        printf("%6zu %6zu %14lld %5zu %6zu  %s\n", na, nb, karsilastirma,
               alt, ust, ayni ? "aynı" : "FARKLI");
        free(x);
        free(y);
        free(z);
        free(d);
    }
    printf("min(na, nb) <= karşılaştırma <= na + nb - 1: iş Θ(na + nb)\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::merge (kararlı);
 * Python — heapq.merge(a, b) (yineleyici; kararlı) */

/* H06_13_en_buyuk_alt_dizi.c — AP-2 Hafta 6 · Örnek 13 (★★★)
 * Amaç    : En büyük alt dizi toplamı böl ve fethet ile: en iyi alt dizi ya
 *           solda, ya sağda ya da ortayı keser. T(n) = 2T(n/2) + Θ(n) →
 *           Θ(n log n). H2'nin Θ(n) Kadane'siyle aynı toplam; sayaç:
 *           toplama sayısı. Sözleşme (H2): alt dizi boş olamaz.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_13_en_buyuk_alt_dizi.c ortak_rastgele.c \
 *           -o H06_13_en_buyuk_alt_dizi
 * Çalıştır: ./H06_13_en_buyuk_alt_dizi
 * Eşleri  : cpp/H06_13_en_buyuk_alt_dizi.cpp ·
 *           python/H06_13_en_buyuk_alt_dizi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    long long toplam;                   /* alt dizi toplamı */
    int bas, son;                       /* aralık a[bas..son] */
} Aralik;

static long long toplama = 0;
static int en_derin = 0;

/* Ortayı kesen en iyi alt dizi: a[i..mid] + a[mid+1..j] */
static Aralik kesisen(const int *a, int lo, int mid, int hi)
{
    long long toplam = a[mid], sol_en = a[mid];
    int bas = mid;
    for (int i = mid - 1; i >= lo; i--) {  /* sola */
        toplam += a[i];
        toplama++;
        if (toplam > sol_en) {
            sol_en = toplam;
            bas = i;
        }
    }
    toplam = a[mid + 1];
    long long sag_en = a[mid + 1];
    int son = mid + 1;
    for (int j = mid + 2; j <= hi; j++) {  /* sağa */
        toplam += a[j];
        toplama++;
        if (toplam > sag_en) {
            sag_en = toplam;
            son = j;
        }
    }
    toplama++;  /* sol_en + sag_en */
    Aralik s = {sol_en + sag_en, bas, son};
    return s;
}

/* a[lo..hi]'nin en büyük alt dizisi; eşitlikte sol, kesişen, sağ sırası */
Aralik en_buyuk_bf(const int *a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo == hi) {
        Aralik tek = {a[lo], lo, lo};
        return tek;
    }
    int mid = lo + (hi - lo) / 2;
    Aralik sol = en_buyuk_bf(a, lo, mid, d + 1);
    Aralik sag = en_buyuk_bf(a, mid + 1, hi, d + 1);
    Aralik orta = kesisen(a, lo, mid, hi);
    Aralik en = sol;  /* eşitlikte sol, kesişen, sağ */
    if (orta.toplam > en.toplam) {
        en = orta;
    }
    if (sag.toplam > en.toplam) {
        en = sag;
    }
    return en;
}

/* H2 Örnek 13'teki Kadane (Θ(n)): a[i]'de biten en iyi toplam */
Aralik kadane(const int *a, int n)
{
    Aralik s = {a[0], 0, 0};
    long long simdiki = a[0];
    int s_bas = 0;
    for (int i = 1; i < n; i++) {
        long long uzat = simdiki + a[i];
        toplama++;
        if (uzat < a[i]) {
            simdiki = a[i];
            s_bas = i;
        } else {
            simdiki = uzat;
        }
        if (simdiki > s.toplam) {
            s.toplam = simdiki;
            s.bas = s_bas;
            s.son = i;
        }
    }
    return s;
}

static void dizi_coz(const char *ad, const int *a, int n)
{
    toplama = 0;
    en_derin = 0;
    Aralik b = en_buyuk_bf(a, 0, n - 1, 1);
    long long tb = toplama;
    toplama = 0;
    Aralik k = kadane(a, n);
    printf("%s (n=%d): böl-fethet %lld [%d..%d] · Kadane %lld [%d..%d] · "
           "toplama %lld / %lld\n", ad, n, b.toplam, b.bas, b.son, k.toplam,
           k.bas, k.son, tb, toplama);
}

int main(void)
{
    static const int bentley[] = {31, -41, 59, 26, -53, 58, 97, -93, -23,
                                  84};
    static const int negatif[] = {-3, -1, -2};
    static const int tek[] = {5};
    static const int sifir[] = {0, -1, 0};
    static const int klasik[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    static const int boyutlar[] = {10, 100, 1000, 1024, 10000, 100000};

    printf("En büyük alt dizi: böl ve fethet ↔ Kadane (H2)\n");
    dizi_coz("Bentley", bentley, 10);
    dizi_coz("Tümü negatif", negatif, 3);
    dizi_coz("Tek eleman", tek, 1);
    dizi_coz("Sıfırlar", sifir, 3);
    dizi_coz("Klasik", klasik, 9);

    int *a = malloc(100000 * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, 100000, -100, 100);        /* H2 ile aynı veri */
    printf("\nRastgele a[i] -100..100 (tohum 42, H2 ile aynı); toplama "
           "sayıları\nW(n) = n⌈lg n⌉ - 2^⌈lg n⌉ + 1 (düğüm başına boy - 1; "
           "Örnek 2'deki sınır)\n");
    printf("     n  en büyük  böl-fethet        W(n)  Kadane  oran  "
           "derinlik  aynı\n");
    for (int t = 0; t < 6; t++) {
        int n = boyutlar[t];
        toplama = 0;
        en_derin = 0;
        Aralik b = en_buyuk_bf(a, 0, n - 1, 1);
        long long tb = toplama;
        toplama = 0;
        Aralik k = kadane(a, n);
        int lg = 0;
        while ((1LL << lg) < n) {
            lg++;
        }
        long long w = (long long)n * lg - (1LL << lg) + 1;
        printf("%6d %9lld %11lld %11lld %7lld %5.1f %9d  %s\n", n, b.toplam,
               tb, w, toplama, (double)tb / toplama, en_derin,
               b.toplam == k.toplam ? "evet" : "HAYIR");
    }
    printf("Aynı problem, iki strateji: böl ve fethet Θ(n log n) toplama ve\n"
           "O(log n) yığın; Kadane Θ(n) toplama ve O(1) bellek.\n");
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — yok
 * (itertools.accumulate önek toplamı verir, en büyük alt diziyi vermez) */

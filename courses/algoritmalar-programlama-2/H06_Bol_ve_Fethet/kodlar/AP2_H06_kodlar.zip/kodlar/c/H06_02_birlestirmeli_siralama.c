/* H06_02_birlestirmeli_siralama.c — AP-2 Hafta 6 · Örnek 2 (★★)
 * Amaç    : Birleştirmeli sıralama (yukarıdan aşağıya): böl, fethet,
 *           birleştir. Yardımcı tampon BİR KEZ ayrılır ve tüm çağrılarca
 *           paylaşılır. Sayaçlar: karşılaştırma, kopya, çağrı, derinlik.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_02_birlestirmeli_siralama.c ortak_rastgele.c \
 *           -o H06_02_birlestirmeli_siralama
 * Çalıştır: ./H06_02_birlestirmeli_siralama
 * Eşleri  : cpp/H06_02_birlestirmeli_siralama.cpp ·
 *           python/H06_02_birlestirmeli_siralama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma = 0, kopya = 0, cagri = 0;
static int en_derin = 0, tampon_ayirma = 0;

/* a[lo..mid] ve a[mid+1..hi] sıralı; yrd üzerinden a[lo..hi]'yi birleştirir */
static void birlestir(int *a, int *yrd, int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {  /* eşitse soldan */
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {  /* geri kopyala */
        a[k] = yrd[k];
    }
    kopya += 2LL * (hi - lo + 1);
}

/* a[lo..hi]'yi sıralar; d: özyineleme derinliği (kök = 1) */
static void bs_ozyineli(int *a, int *yrd, int lo, int hi, int d)
{
    cagri++;
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {  /* 0 ya da 1 eleman: sıralı */
        return;
    }
    int mid = lo + (hi - lo) / 2;
    /* böl ve fethet: iki yarıyı ayrı ayrı sırala */
    bs_ozyineli(a, yrd, lo, mid, d + 1);
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1);
    birlestir(a, yrd, lo, mid, hi);  /* birleştir */
}

/* Tek tampon: n elemanlık yrd bir kez ayrılır, sonunda bırakılır */
void birlestirmeli_sirala(int *a, size_t n)
{
    if (n == 0) {
        return;
    }
    int *yrd = malloc(n * sizeof *yrd);
    if (yrd == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    tampon_ayirma++;
    bs_ozyineli(a, yrd, 0, (int)n - 1, 1);
    free(yrd);
}

static void dizi_yaz(const char *ad, const int *a, size_t n)
{
    printf("%s: [", ad);
    for (size_t i = 0; i < n; i++) {
        printf("%s%d", i ? ", " : "", a[i]);
    }
    printf("]\n");
}

/* ⌈lg n⌉ (n >= 1): 2^k >= n olan en küçük k */
static int tavan_log2(long long n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

static void sayaclari_sifirla(void)
{
    karsilastirma = kopya = cagri = 0;
    en_derin = tampon_ayirma = 0;
}

/* a'yı sıralar; kâhinle (qsort) karşılaştırıp 1/0 döndürür */
static int sinama(int *a, size_t n)
{
    int *kahin = malloc((n + 1) * sizeof *kahin);
    if (kahin == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    for (size_t i = 0; i < n; i++) {
        kahin[i] = a[i];
    }
    qsort(kahin, n, sizeof *kahin, kucukten_buyuge);    /* yalnızca kâhin */
    sayaclari_sifirla();
    birlestirmeli_sirala(a, n);
    int ayni = 1;
    for (size_t i = 0; i < n; i++) {
        ayni = ayni && a[i] == kahin[i];
    }
    free(kahin);
    return ayni;
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4};
    printf("Birleştirmeli sıralama (yukarıdan aşağıya, tek tampon)\n");
    dizi_yaz("önce ", a, 8);
    sayaclari_sifirla();
    birlestirmeli_sirala(a, 8);
    dizi_yaz("sonra", a, 8);
    printf("karşılaştırma = %lld · kopya = %lld · çağrı = %lld · "
           "derinlik = %d\ntampon ayırma = %d (her çağrıda değil, bir kez)"
           "\n\n", karsilastirma, kopya, cagri, en_derin, tampon_ayirma);

    static const size_t boyutlar[] = {1, 2, 3, 7, 8, 100, 1000, 1024,
                                      10000, 100000};
    int *x = malloc(100000 * sizeof *x);
    if (x == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("Rastgele girdi (tohum 42, 0..999999) · W(n) = n⌈lg n⌉ - "
           "2^⌈lg n⌉ + 1\n");
    printf("     n  karşılaştırma        W(n)  çağrı  derinlik  kâhin\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        size_t n = boyutlar[t];
        rastgele_tohum(42);
        rastgele_dizi(x, n, 0, 999999);
        int ayni = sinama(x, n);
        int k = tavan_log2((long long)n);
        long long w = (long long)n * k - (1LL << k) + 1;
        printf("%6zu %14lld %11lld %6lld %9d  %s\n", n, karsilastirma, w,
               cagri, en_derin, ayni ? "aynı" : "FARKLI");
    }
    printf("çağrı = 2n - 1 · derinlik = ⌈lg n⌉ + 1 · karşılaştırma <= W(n)"
           "\n\n");

    printf("Girdi türünün etkisi (n = 1024, lg n = 10)\n");
    printf("girdi      karşılaştırma   kopya  kâhin\n");
    for (int tur = 0; tur < 3; tur++) {
        static const char *const adlar[] = {"rastgele", "sıralı  ",
                                            "ters    "};
        rastgele_tohum(42);
        rastgele_dizi(x, 1024, 0, 999999);
        for (int i = 0; i < 1024; i++) {
            if (tur == 1) {
                x[i] = i;
            } else if (tur == 2) {
                x[i] = 1024 - i;
            }
        }
        int ayni = sinama(x, 1024);
        printf("%s %15lld %7lld  %s\n", adlar[tur], karsilastirma, kopya,
               ayni ? "aynı" : "FARKLI");
    }
    printf("Sıralı girdide bile (n/2)·lg n = %d karşılaştırma ve "
           "2n·lg n = %d kopya:\n", 1024 / 2 * 10, 2 * 1024 * 10);
    printf("birleştirmeli sıralama uyarlanabilir değildir; "
           "Θ(n log n) her durumda.\n");
    free(x);
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort algoritma belirtmez); C++ —
 * std::stable_sort (kararlı; genellikle birleştirmeli); Python — sorted /
 * list.sort (Timsort: birleştirmeli + araya ekleme melezi, kararlı) */

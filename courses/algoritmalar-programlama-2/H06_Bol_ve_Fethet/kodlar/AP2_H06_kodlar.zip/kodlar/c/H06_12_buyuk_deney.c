/* H06_12_buyuk_deney.c — AP-2 Hafta 6 · Örnek 12 (★★★)
 * Amaç    : Haftanın Deneyi programı: birleştirmeli, hızlı (ilk / rastgele /
 *           üçün ortancası pivot), kütüphane (qsort) ve araya ekleme
 *           sıralaması. Varsayılan çalıştırma küçük ve deterministiktir;
 *           ölçüm kipi bir yapılandırmayı ölçüp CSV satırı yazar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_12_buyuk_deney.c \
 *           ortak_rastgele.c zamanlayici.c -o H06_12_buyuk_deney
 * Çalıştır: ./H06_12_buyuk_deney   ya da   ./H06_12_buyuk_deney ALGORITMA
 *           GIRDI N TEKRAR   (ALGORITMA: birlestirmeli, hizli_ilk,
 *           hizli_rastgele, hizli_ortanca3, kutuphane, araya_ekleme;
 *           GIRDI: rastgele, sirali)
 * Eşleri  : cpp/H06_12_buyuk_deney.cpp · python/H06_12_buyuk_deney.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

enum { BIRLESTIRMELI, HIZLI_ILK, HIZLI_RASTGELE, HIZLI_ORTANCA3, KUTUPHANE,
       ARAYA_EKLEME, ALGORITMA_SAYISI };
static const char *const ALG_AD[] = {"birlestirmeli", "hizli_ilk",
                                     "hizli_rastgele", "hizli_ortanca3",
                                     "kutuphane", "araya_ekleme"};
static const char *const GIRDI_AD[] = {"rastgele", "sirali"};

static long long karsilastirma = 0;
static int agac_yuksekligi = 0, yigin_derinligi = 0;

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
}

/* --- Birleştirmeli sıralama (Örnek 2; tek tampon) --- */
static void birlestir(int *a, int *yrd, int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
}

static void bs_ozyineli(int *a, int *yrd, int lo, int hi, int d)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = agac_yuksekligi = d;
    }
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_ozyineli(a, yrd, lo, mid, d + 1);
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1);
    birlestir(a, yrd, lo, mid, hi);
}

/* --- Hızlı sıralama (Örnek 6; küçük parçaya özyineleme) --- */
static int ortanca3(const int *a, int i, int j, int k)
{
    karsilastirma += 2;
    if (a[i] < a[j]) {
        if (a[j] < a[k]) {
            return j;
        }
        karsilastirma++;
        return a[i] < a[k] ? k : i;
    }
    if (a[i] < a[k]) {
        return i;
    }
    karsilastirma++;
    return a[j] < a[k] ? k : j;
}

static int bolumle(int *a, int lo, int hi, int alg)
{
    int r = alg == HIZLI_ILK ? lo
          : alg == HIZLI_RASTGELE ? rastgele_aralik(lo, hi)
          : ortanca3(a, lo, lo + (hi - lo) / 2, hi);
    takas(a, r, hi);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

static void hizli_sirala(int *a, int lo, int hi, int alg, int d, int t)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = d;
    }
    for (;;) {
        if (t > agac_yuksekligi) {
            agac_yuksekligi = t;
        }
        if (lo >= hi) {
            return;
        }
        int p = bolumle(a, lo, hi, alg);
        if (p - lo < hi - p) {
            hizli_sirala(a, lo, p - 1, alg, d + 1, t + 1);
            lo = p + 1;
        } else {
            hizli_sirala(a, p + 1, hi, alg, d + 1, t + 1);
            hi = p - 1;
        }
        t++;
    }
}

/* --- Araya ekleme (H5) ve kütüphane --- */
static void araya_ekleme(int *a, int n)
{
    for (int i = 1; i < n; i++) {
        int anahtar = a[i];
        int j = i - 1;
        while (j >= 0 && (karsilastirma++, a[j] > anahtar)) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = anahtar;
    }
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

/* Seçilen algoritmayla a[0..n-1]'i sıralar; yrd: n elemanlık tampon */
static void sirala(int *a, int *yrd, int n, int alg)
{
    karsilastirma = 0;
    agac_yuksekligi = yigin_derinligi = 0;
    rastgele_tohum(2026);               /* rastgele pivot dizisi sabit */
    if (alg == BIRLESTIRMELI) {
        bs_ozyineli(a, yrd, 0, n - 1, 1);
    } else if (alg == KUTUPHANE) {
        qsort(a, (size_t)n, sizeof *a, kucukten_buyuge);
    } else if (alg == ARAYA_EKLEME) {
        araya_ekleme(a, n);
    } else {
        hizli_sirala(a, 0, n - 1, alg, 1, 1);
    }
}

static void girdi_uret(int *a, int n, int girdi)
{
    if (girdi == 0) {
        rastgele_tohum(42);
        rastgele_dizi(a, (size_t)n, 0, 1000000000);
    } else {
        for (int k = 0; k < n; k++) {
            a[k] = k;
        }
    }
}

/* Doğruluk: sıralı mı ve eleman toplamı korunmuş mu (ucuz kâhin) */
static int dogru_mu(const int *a, int n, long long toplam)
{
    long long s = 0;
    for (int k = 0; k < n; k++) {
        s += a[k];
        if (k > 0 && a[k - 1] > a[k]) {
            return 0;
        }
    }
    return s == toplam;
}

static int bul(const char *s, const char *const *adlar, int sayi)
{
    for (int k = 0; k < sayi; k++) {
        if (strcmp(s, adlar[k]) == 0) {
            return k;
        }
    }
    return -1;
}

/* Ölçüm kipi: 1 ısınma + tekrar ölçüm; ortanca/en az/en çok duvar saati
 * ve ortanca işlemci zamanı (ms) */
static int olcum(int alg, int girdi, int n, int tekrar)
{
    int *orijinal = malloc((size_t)n * sizeof *orijinal);
    int *a = malloc((size_t)n * sizeof *a);
    int *yrd = malloc((size_t)n * sizeof *yrd);
    double duvar[101], islemci[101];
    if (orijinal == NULL || a == NULL || yrd == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    girdi_uret(orijinal, n, girdi);
    long long toplam = 0;
    for (int k = 0; k < n; k++) {
        toplam += orijinal[k];
    }
    for (int r = -1; r < tekrar; r++) {         /* r = -1: ısınma */
        memcpy(a, orijinal, (size_t)n * sizeof *a);
        double t0 = zaman_sn(), c0 = islemci_sn();
        sirala(a, yrd, n, alg);
        double t1 = zaman_sn(), c1 = islemci_sn();
        if (r >= 0) {
            duvar[r] = (t1 - t0) * 1e3;
            islemci[r] = (c1 - c0) * 1e3;
        }
    }
    double en_az = duvar[0], en_cok = duvar[0];
    for (int r = 1; r < tekrar; r++) {
        en_az = duvar[r] < en_az ? duvar[r] : en_az;
        en_cok = duvar[r] > en_cok ? duvar[r] : en_cok;
    }
    double ort_duvar = ortanca(duvar, tekrar);
    double ort_islemci = ortanca(islemci, tekrar);
    printf("%s;%s;%d;%d;%.4f;%.4f;%.4f;%.4f;%lld;%d;%d;%d\n", ALG_AD[alg],
           GIRDI_AD[girdi], n, tekrar, ort_duvar, en_az, en_cok, ort_islemci,
           alg == KUTUPHANE ? -1LL : karsilastirma, agac_yuksekligi,
           yigin_derinligi, dogru_mu(a, n, toplam));
    free(orijinal);
    free(a);
    free(yrd);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc == 5) {
        int alg = bul(argv[1], ALG_AD, ALGORITMA_SAYISI);
        int girdi = bul(argv[2], GIRDI_AD, 2);
        char *son1, *son2;
        errno = 0;
        long n = strtol(argv[3], &son1, 10);
        long tekrar = strtol(argv[4], &son2, 10);
        if (alg < 0 || girdi < 0 || errno != 0 || *son1 != '\0' ||
            *son2 != '\0' || n < 2 || n > 20000000 || tekrar < 1 ||
            tekrar > 101) {
            fprintf(stderr, "hatalı argüman\n");
            return 2;
        }
        return olcum(alg, girdi, (int)n, (int)tekrar);
    }
    if (argc != 1) {
        fprintf(stderr, "Kullanım: %s [ALGORITMA GIRDI N TEKRAR]\n", argv[0]);
        return 2;
    }
    static const int boyutlar[] = {1000, 10000};
    int *orijinal = malloc(10000 * sizeof *orijinal);
    int *a = malloc(10000 * sizeof *a), *yrd = malloc(10000 * sizeof *yrd);
    if (orijinal == NULL || a == NULL || yrd == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("Büyük deney programı: varsayılan küçük çalıştırma "
           "(süreler stderr'de)\n");
    printf("algoritma       girdi         n  karşılaştırma  ağaç  yığın  "
           "doğru\n");
    for (int girdi = 0; girdi < 2; girdi++) {
        for (int b = 0; b < 2; b++) {
            int n = boyutlar[b];
            if (girdi == 1 && n > 1000) {
                continue;               /* hizli_ilk sıralıda Θ(n²) */
            }
            girdi_uret(orijinal, n, girdi);
            long long toplam = 0;
            for (int k = 0; k < n; k++) {
                toplam += orijinal[k];
            }
            for (int alg = 0; alg < ALGORITMA_SAYISI; alg++) {
                if (alg == ARAYA_EKLEME && girdi == 0 && n > 1000) {
                    continue;           /* Θ(n²): ölçüm kipinde */
                }
                memcpy(a, orijinal, (size_t)n * sizeof *a);
                double t0 = zaman_sn();
                sirala(a, yrd, n, alg);
                double ms = (zaman_sn() - t0) * 1e3;
                printf("%-15s %-8s %6d", ALG_AD[alg], GIRDI_AD[girdi], n);
                if (alg == KUTUPHANE) {
                    printf(" %14s %5s %6s", "-", "-", "-");
                } else {
                    printf(" %14lld %5d %6d", karsilastirma, agac_yuksekligi,
                           yigin_derinligi);
                }
                printf("  %s\n", dogru_mu(a, n, toplam) ? "evet" : "HAYIR");
                fprintf(stderr, "%s %s n=%d: %.3f ms\n", ALG_AD[alg],
                        GIRDI_AD[girdi], n, ms);
            }
        }
    }
    printf("Ölçüm kipi (deney/olcum_calistir.py kullanır):\n"
           "  ALGORITMA GIRDI N TEKRAR → algoritma;girdi;n;tekrar;"
           "ortanca_ms;\n  en_az_ms;en_cok_ms;islemci_ms;karsilastirma;"
           "agac;yigin;dogru\n");
    free(orijinal);
    free(a);
    free(yrd);
    return 0;
}

/* Kütüphane karşılığı: C — qsort (glibc; algoritma standartta yok);
 * C++ — std::sort (introsort); Python — list.sort (Timsort) */

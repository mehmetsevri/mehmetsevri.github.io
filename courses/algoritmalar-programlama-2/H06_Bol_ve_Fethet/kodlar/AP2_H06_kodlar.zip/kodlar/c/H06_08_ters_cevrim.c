/* H06_08_ters_cevrim.c — AP-2 Hafta 6 · Örnek 8 (★★)
 * Amaç    : Ters çevrim (i < j ve a[i] > a[j]) sayısı birleştirmeli
 *           sıralamayla Θ(n log n): sağdan a[j] alınırken soldaki kalan
 *           mid - i + 1 elemanın hepsi a[j]'den büyüktür. Kâhin: H5'teki
 *           Θ(n²) çift taraması.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_08_ters_cevrim.c \
 *           ortak_rastgele.c -o H06_08_ters_cevrim
 * Çalıştır: ./H06_08_ters_cevrim
 * Eşleri  : cpp/H06_08_ters_cevrim.cpp · python/H06_08_ters_cevrim.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma = 0, karsilastirma_kaba = 0;

/* Birleştirirken ters çevrimleri sayar: a[lo..mid], a[mid+1..hi] sıralı */
static long long birlestir_say(int *a, int *yrd, int lo, int mid, int hi)
{
    long long sayi = 0;
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {  /* eşitse sayılmaz */
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
            sayi += mid - i + 1;  /* hepsi > a[j] */
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
    return sayi;
}

/* a[lo..hi] içindeki ters çevrim sayısı; a sıralanmış olarak kalır */
static long long ters_cevrim_bs(int *a, int *yrd, int lo, int hi)
{
    if (lo >= hi) {
        return 0;
    }
    int mid = lo + (hi - lo) / 2;
    long long sol = ters_cevrim_bs(a, yrd, lo, mid);
    long long sag = ters_cevrim_bs(a, yrd, mid + 1, hi);
    return sol + sag + birlestir_say(a, yrd, lo, mid, hi);
}

/* Girdiyi bozmamak için kopya üzerinde sayar */
long long ters_cevrim_say(const int *a, int n)
{
    int *b = malloc(((size_t)n + 1) * sizeof *b);
    int *yrd = malloc(((size_t)n + 1) * sizeof *yrd);
    if (b == NULL || yrd == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    for (int k = 0; k < n; k++) {
        b[k] = a[k];
    }
    long long sonuc = ters_cevrim_bs(b, yrd, 0, n - 1);
    free(b);
    free(yrd);
    return sonuc;
}

/* Kâhin (H5): tüm i < j çiftleri, n(n-1)/2 karşılaştırma */
long long ters_cevrim_kaba(const int *a, int n)
{
    long long sayi = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            karsilastirma_kaba++;
            if (a[i] > a[j]) {
                sayi++;
            }
        }
    }
    return sayi;
}

static void ciftleri_yaz(const int *a, int n)
{
    int sayi = 0;
    printf("çiftler:");
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                if (sayi > 0 && sayi % 8 == 0) {
                    printf("\n        ");
                }
                printf(" (%d,%d)", a[i], a[j]);
                sayi++;
            }
        }
    }
    printf("\n");
}

int main(void)
{
    const int k1[] = {2, 4, 1, 3, 5};
    const int k2[] = {6, 3, 8, 1, 7, 2, 5, 4};
    printf("Ters çevrim: i < j ve a[i] > a[j]\n");
    printf("[2, 4, 1, 3, 5]: birleştirmeli = %lld · kaba = %lld\n",
           ters_cevrim_say(k1, 5), ters_cevrim_kaba(k1, 5));
    ciftleri_yaz(k1, 5);
    karsilastirma = karsilastirma_kaba = 0;
    long long t2 = ters_cevrim_say(k2, 8);
    long long t2_kaba = ters_cevrim_kaba(k2, 8);
    printf("[6, 3, 8, 1, 7, 2, 5, 4]: birleştirmeli = %lld (%lld "
           "karşılaştırma) · kaba = %lld (%lld)\n", t2, karsilastirma,
           t2_kaba, karsilastirma_kaba);
    ciftleri_yaz(k2, 8);

    static const int boyutlar[] = {10, 100, 1000, 3000};
    int *x = malloc(100000 * sizeof *x);
    if (x == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("\nRastgele girdi (tohum 42, 0..999): birleştirmeli ↔ kâhin\n");
    printf("     n  ters çevrim  karş. (bs)  karş. (kaba)  kâhin\n");
    for (int t = 0; t < 4; t++) {
        int n = boyutlar[t];
        rastgele_tohum(42);
        rastgele_dizi(x, (size_t)n, 0, 999);
        karsilastirma = karsilastirma_kaba = 0;
        long long bs = ters_cevrim_say(x, n);
        long long kaba = ters_cevrim_kaba(x, n);
        printf("%6d %12lld %11lld %13lld  %s\n", n, bs, karsilastirma,
               karsilastirma_kaba, bs == kaba ? "aynı" : "FARKLI");
    }

    const int n = 100000;
    printf("\nn = %d (kaba yöntem %lld karşılaştırma isterdi)\n", n,
           (long long)n * (n - 1) / 2);
    for (int tur = 0; tur < 3; tur++) {
        static const char *const adlar[] = {"rastgele", "sıralı  ",
                                            "ters    "};
        rastgele_tohum(42);
        rastgele_dizi(x, (size_t)n, 0, 999999);
        for (int k = 0; k < n; k++) {
            if (tur == 1) {
                x[k] = k;
            } else if (tur == 2) {
                x[k] = n - k;
            }
        }
        karsilastirma = 0;
        long long bs = ters_cevrim_say(x, n);
        printf("%s ters çevrim = %11lld · karşılaştırma = %lld\n",
               adlar[tur], bs, karsilastirma);
    }
    printf("Ters sıralıda n(n-1)/2 = %lld; araya ekleme sıralaması tam "
           "olarak\nters çevrim sayısı kadar kaydırma yapar (H5).\n",
           (long long)n * (n - 1) / 2);
    free(x);
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Ters çevrim sayısı iki
 * sıralama arasındaki Kendall tau uzaklığıdır. */

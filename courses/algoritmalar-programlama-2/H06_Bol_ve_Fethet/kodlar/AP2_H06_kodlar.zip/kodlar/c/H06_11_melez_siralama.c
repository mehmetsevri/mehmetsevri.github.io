/* H06_11_melez_siralama.c — AP-2 Hafta 6 · Örnek 11 (★★★)
 * Amaç    : Melez (hybrid) sıralama: hızlı sıralama (üçün ortancası, küçük
 *           parçaya özyineleme) boyu <= esik olan parçaları araya ekleme
 *           sıralamasına (H5) bırakır. Eşik deneyi: sayaçlar stdout'a,
 *           süreler stderr'e. esik = 1: saf hızlı sıralama.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_11_melez_siralama.c ortak_rastgele.c zamanlayici.c \
 *           -o H06_11_melez_siralama
 * Çalıştır: ./H06_11_melez_siralama [n [tekrar [--csv]]]  (varsayılan
 *           n = 10000, tekrar = 1; --csv: esik;n;tekrar;ortanca_ms;
 *           islemci_ort_ms;karsilastirma;tasima)
 * Eşleri  : cpp/H06_11_melez_siralama.cpp · python/H06_11_melez_siralama.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

static long long karsilastirma = 0, tasima = 0, araya_ekleme_cagrisi = 0;

static int kucuk(int x, int y)
{
    karsilastirma++;
    return x < y;
}

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
    tasima++;
}

/* Araya ekleme sıralaması (H5): a[lo..hi] */
static void araya_ekle(int *a, int lo, int hi)
{
    araya_ekleme_cagrisi++;
    for (int i = lo + 1; i <= hi; i++) {
        int anahtar = a[i];
        int j = i - 1;
        while (j >= lo && kucuk(anahtar, a[j])) {
            a[j + 1] = a[j];  /* kaydır */
            tasima++;
            j--;
        }
        a[j + 1] = anahtar;
    }
}

static int ortanca3(const int *a, int i, int j, int k)
{
    if (kucuk(a[i], a[j])) {
        if (kucuk(a[j], a[k])) {
            return j;
        }
        return kucuk(a[i], a[k]) ? k : i;
    }
    if (kucuk(a[i], a[k])) {
        return i;
    }
    return kucuk(a[j], a[k]) ? k : j;
}

/* Üçün ortancası pivot a[hi]'ye; Lomuto bölümleme (Örnek 6) */
static int bolumle(int *a, int lo, int hi)
{
    takas(a, ortanca3(a, lo, lo + (hi - lo) / 2, hi), hi);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (kucuk(a[j], pivot)) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

/* Parça esik'ten uzunken böl; kısa parçayı araya eklemeyle bitir */
void melez_sirala(int *a, int lo, int hi, int esik)
{
    while (hi - lo + 1 > esik) {
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            melez_sirala(a, lo, p - 1, esik);
            lo = p + 1;
        } else {
            melez_sirala(a, p + 1, hi, esik);
            hi = p - 1;
        }
    }
    if (lo < hi) {
        araya_ekle(a, lo, hi);  /* kısa parça */
    }
}

typedef struct {
    const int *orijinal;
    int *calisma;
    int n, esik;
} Gorev;

static void sirala_gorevi(void *veri)
{
    Gorev *g = veri;
    memcpy(g->calisma, g->orijinal, (size_t)g->n * sizeof *g->calisma);
    melez_sirala(g->calisma, 0, g->n - 1, g->esik);
}

static int sirali_mi(const int *a, int n)
{
    for (int k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

static long arguman(const char *s, long alt, long ust)
{
    char *son;
    errno = 0;
    long x = strtol(s, &son, 10);
    if (errno != 0 || *son != '\0' || x < alt || x > ust) {
        fprintf(stderr, "argüman %ld..%ld aralığında olmalı: %s\n", alt, ust,
                s);
        exit(2);
    }
    return x;
}

int main(int argc, char *argv[])
{
    int n = 10000, tekrar = 1, csv = 0;
    if (argc > 1) {
        n = (int)arguman(argv[1], 2, 10000000);
    }
    if (argc > 2) {
        tekrar = (int)arguman(argv[2], 1, 101);
    }
    if (argc > 3) {
        csv = strcmp(argv[3], "--csv") == 0;
    }
    static const int esikler[] = {1, 4, 8, 12, 16, 24, 32, 48, 64};
    int *orijinal = malloc((size_t)n * sizeof *orijinal);
    int *calisma = malloc((size_t)n * sizeof *calisma);
    if (orijinal == NULL || calisma == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(orijinal, (size_t)n, 0, 1000000000);
    if (csv) {
        printf("esik;n;tekrar;ortanca_ms;islemci_ort_ms;karsilastirma;"
               "tasima\n");
    } else {
        printf("Melez sıralama: hızlı + araya ekleme, n = %d (tohum 42)\n",
               n);
        printf(" eşik  karşılaştırma     taşıma  araya ekleme  doğru\n");
    }
    for (int e = 0; e < 9; e++) {
        Gorev g = {orijinal, calisma, n, esikler[e]};
        karsilastirma = tasima = araya_ekleme_cagrisi = 0;
        sirala_gorevi(&g);
        long long k = karsilastirma, t = tasima, c = araya_ekleme_cagrisi;
        int dogru = sirali_mi(calisma, n);
        double c0 = islemci_sn();
        double sn = olc_ortanca(sirala_gorevi, &g, tekrar);
        double cpu = (islemci_sn() - c0) / (tekrar + 1);
        if (csv) {
            printf("%d;%d;%d;%.4f;%.4f;%lld;%lld\n", esikler[e], n, tekrar,
                   sn * 1e3, cpu * 1e3, k, t);
        } else {
            printf("%5d %14lld %10lld %13lld  %s\n", esikler[e], k, t, c,
                   dogru ? "evet" : "HAYIR");
        }
        fprintf(stderr, "eşik %2d: %.3f ms (ortanca, %d tekrar; işlemci "
                "ort. %.3f ms)\n", esikler[e], sn * 1e3, tekrar, cpu * 1e3);
    }
    if (!csv) {
        printf("Eşik büyüdükçe karşılaştırma ve taşıma önce biraz "
               "azalır, sonra artar\n(araya ekleme Θ(k²)); özyineleme ve "
               "bölümleme yükü ise azalır: süre\ngenellikle bir ara eşikte "
               "en kısadır (stderr; deneye bakın).\n");
    }
    free(orijinal);
    free(calisma);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (libstdc++: introsort
 * + 16 elemanlık eşikle araya ekleme); Python — list.sort (Timsort: kısa
 * parçalarda ikili araya ekleme) */

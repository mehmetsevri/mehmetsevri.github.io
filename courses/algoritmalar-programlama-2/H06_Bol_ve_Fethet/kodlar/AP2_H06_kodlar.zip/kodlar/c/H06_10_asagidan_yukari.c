/* H06_10_asagidan_yukari.c — AP-2 Hafta 6 · Örnek 10 (★★★)
 * Amaç    : Aşağıdan yukarıya (yinelemeli) birleştirmeli sıralama: önce
 *           1'lik, sonra 2'lik, 4'lük ... komşu blokları birleştir.
 *           Özyineleme yok; ⌈lg n⌉ geçiş. n = 2^k'da yukarıdan aşağıya
 *           sürümle aynı birleştirmeleri yapar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_10_asagidan_yukari.c ortak_rastgele.c -o H06_10_asagidan_yukari
 * Çalıştır: ./H06_10_asagidan_yukari
 * Eşleri  : cpp/H06_10_asagidan_yukari.cpp · python/H06_10_asagidan_yukari.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma = 0;
static int birlestirme_sayisi = 0;

/* Örnek 2'deki birleştirme: a[lo..mid] + a[mid+1..hi], yrd üzerinden */
static void birlestir(int *a, int *yrd, int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    birlestirme_sayisi++;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
}

static void dizi_yaz(const int *a, int n)
{
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
}

/* gen: blok genişliği 1, 2, 4, ...; yaz = 1 ise her geçişi yazar */
int asagidan_yukari_sirala(int *a, int n, int yaz)
{
    int *yrd = malloc(((size_t)n + 1) * sizeof *yrd);
    int gecis = 0;
    if (yrd == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    for (int gen = 1; gen < n; gen *= 2) {
        int onceki = birlestirme_sayisi;
        for (int lo = 0; lo < n - gen; lo += 2 * gen) {
            int mid = lo + gen - 1;
            int hi = lo + 2 * gen - 1 < n - 1 ? lo + 2 * gen - 1 : n - 1;
            birlestir(a, yrd, lo, mid, hi);
        }
        gecis++;
        if (yaz) {
            int blok = (n + gen - 1) / gen;
            printf("gen = %2d :", gen);
            dizi_yaz(a, n);
            printf("   (%d birleştirme", birlestirme_sayisi - onceki);
            if (blok % 2 == 1) {
                printf("; [%d..%d] eşsiz", (blok - 1) * gen, n - 1);
            }
            printf(")\n");
        }
    }
    free(yrd);
    return gecis;
}

/* Karşılaştırma için Örnek 2'nin yukarıdan aşağıya sürümü */
static void bs_ozyineli(int *a, int *yrd, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_ozyineli(a, yrd, lo, mid);
    bs_ozyineli(a, yrd, mid + 1, hi);
    birlestir(a, yrd, lo, mid, hi);
}

static int tavan_log2(int n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

static int sirali_mi(const int *a, int n)
{
    for (int k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4, 9, 0};
    printf("Aşağıdan yukarıya birleştirmeli sıralama (özyinelemesiz)\n");
    printf("başta    :");
    dizi_yaz(a, 10);
    printf("\n");
    int gecis = asagidan_yukari_sirala(a, 10, 1);
    printf("geçiş = %d = ⌈lg 10⌉ · karşılaştırma = %lld · birleştirme = %d"
           "\n", gecis, karsilastirma, birlestirme_sayisi);
    printf("Eşi olmayan son blok o geçişte olduğu gibi kalır.\n\n");

    static const int boyutlar[] = {8, 10, 1000, 1024, 4096, 100000};
    int *x = malloc(100000 * sizeof *x), *y = malloc(100000 * sizeof *y);
    int *yrd = malloc(100000 * sizeof *yrd);
    if (x == NULL || y == NULL || yrd == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("Yukarıdan aşağıya (Örnek 2) ile karşılaştırma (tohum 42)\n");
    printf("     n  aşağıdan yukarı  yukarıdan aşağı  geçiş  ⌈lg n⌉  "
           "doğru\n");
    for (int t = 0; t < 6; t++) {
        int n = boyutlar[t];
        rastgele_tohum(42);
        rastgele_dizi(x, (size_t)n, 0, 999999);
        for (int k = 0; k < n; k++) {
            y[k] = x[k];
        }
        karsilastirma = 0;
        gecis = asagidan_yukari_sirala(x, n, 0);
        long long ay = karsilastirma;
        karsilastirma = 0;
        bs_ozyineli(y, yrd, 0, n - 1);
        printf("%6d %16lld %16lld %6d %7d  %s\n", n, ay, karsilastirma,
               gecis, tavan_log2(n),
               sirali_mi(x, n) && sirali_mi(y, n) ? "evet" : "HAYIR");
    }
    printf("n = 2^k olduğunda iki sürüm aynı blokları birleştirir: "
           "karşılaştırmalar\neşittir. Diğer n'lerde bölünme sınırları "
           "farklıdır.\n");
    free(x);
    free(y);
    free(yrd);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::stable_sort; Python — yok
 * (sorted/Timsort hazır sıralı parçaları (run) aşağıdan yukarıya
 * birleştirir) */

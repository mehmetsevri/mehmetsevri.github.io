/* H06_06_pivot_deneyi.c — AP-2 Hafta 6 · Örnek 6 (★★)
 * Amaç    : Pivot seçimi: ilk eleman / rastgele (ortak LCG) / üçün ortancası
 *           × sıralı / ters / rastgele girdi → karşılaştırma ve derinlik.
 *           Küçük parçaya özyineleme + büyük parçada döngü (kuyruk çağrısı
 *           eleme fikri): kötü pivotta bile yığın derinliği <= lg n + 1.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_06_pivot_deneyi.c \
 *           ortak_rastgele.c -o H06_06_pivot_deneyi -lm
 * Çalıştır: ./H06_06_pivot_deneyi   ya da   ./H06_06_pivot_deneyi naif N
 *           (naif N: sıralı girdide ilk eleman pivotlu İKİ çağrılı sürüm;
 *           derinlik N olur — büyük N'de yığın taşabilir, bkz. Hata Avcısı)
 * Eşleri  : cpp/H06_06_pivot_deneyi.cpp · python/H06_06_pivot_deneyi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

enum { ILK = 0, RASTGELE = 1, ORTANCA3 = 2 };
static const char *const STRATEJI_AD[] = {"ilk     ", "rastgele", "ortanca3"};
static const char *const GIRDI_AD[] = {"sıralı  ", "ters    ", "rastgele"};

static long long karsilastirma = 0;
static int yigin_derinligi = 0, agac_yuksekligi = 0;

static int kucuk(int x, int y)
{
    karsilastirma++;
    return x < y;
}

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
}

/* a[i], a[j], a[k] değerlerinin ortancasının indisi (2-3 karşılaştırma) */
static int ortanca3(const int *a, int i, int j, int k)
{
    if (kucuk(a[i], a[j])) {
        if (kucuk(a[j], a[k])) {
            return j;  /* a[i] < a[j] < a[k] */
        }
        return kucuk(a[i], a[k]) ? k : i;
    }
    if (kucuk(a[i], a[k])) {
        return i;  /* a[j] <= a[i] < a[k] */
    }
    return kucuk(a[j], a[k]) ? k : j;
}

static int pivot_sec(const int *a, int lo, int hi, int strateji)
{
    if (strateji == ILK) {
        return lo;
    }
    if (strateji == RASTGELE) {
        return rastgele_aralik(lo, hi);
    }
    return ortanca3(a, lo, lo + (hi - lo) / 2, hi);
}

/* Seçilen pivot a[hi]'ye taşınır; ardından Örnek 4'ün Lomuto bölümlemesi */
static int bolumle(int *a, int lo, int hi, int strateji)
{
    takas(a, pivot_sec(a, lo, hi, strateji), hi);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (kucuk(a[j], pivot)) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

/* Küçük parçaya özyineleme, büyük parçada döngü. d: gerçek yığın derinliği;
 * t: iki çağrılı (naif) sürümdeki çağrının ağaç derinliği */
void hizli_sirala(int *a, int lo, int hi, int s, int d, int t)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = d;
    }
    for (;;) {
        if (t > agac_yuksekligi) {
            agac_yuksekligi = t;
        }
        if (lo >= hi) {
            return;
        }
        int p = bolumle(a, lo, hi, s);
        if (p - lo < hi - p) {  /* sol küçük */
            hizli_sirala(a, lo, p - 1, s, d + 1, t + 1);
            lo = p + 1;  /* sağda döngü */
        } else {
            hizli_sirala(a, p + 1, hi, s, d + 1, t + 1);
            hi = p - 1;
        }
        t++;
    }
}

/* Karşılaştırma için iki çağrılı (naif) sürüm: yığın derinliği = ağaç */
void hizli_naif(int *a, int lo, int hi, int s, int d)
{
    if (d > yigin_derinligi) {
        yigin_derinligi = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = bolumle(a, lo, hi, s);
    hizli_naif(a, lo, p - 1, s, d + 1);
    hizli_naif(a, p + 1, hi, s, d + 1);
}

static void girdi_uret(int *a, int n, int tur)
{
    if (tur == 2) {
        rastgele_tohum(42);
        rastgele_dizi(a, (size_t)n, 0, 1000000000);
        return;
    }
    for (int k = 0; k < n; k++) {
        a[k] = tur == 0 ? k : n - k;
    }
}

static int sirali_mi(const int *a, int n)
{
    for (int k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

static void sayac_sifirla(void)
{
    karsilastirma = 0;
    yigin_derinligi = agac_yuksekligi = 0;
    rastgele_tohum(2026);               /* rastgele pivot dizisi sabit */
}

static int naif_kip(const char *arg)
{
    char *son;
    errno = 0;
    long n = strtol(arg, &son, 10);
    if (errno != 0 || *son != '\0' || n < 1 || n > 10000000) {
        fprintf(stderr, "N 1..10000000 olmalı\n");
        return 2;
    }
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    girdi_uret(a, (int)n, 0);
    sayac_sifirla();
    printf("naif, sıralı girdi, ilk eleman pivotu, n = %ld\n", n);
    fflush(stdout);
    hizli_naif(a, 0, (int)n - 1, ILK, 1);
    printf("bitti: karşılaştırma = %lld · yığın derinliği = %d\n",
           karsilastirma, yigin_derinligi);
    free(a);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc == 3 && argv[1][0] == 'n') {
        return naif_kip(argv[2]);
    }
    if (argc != 1) {
        fprintf(stderr, "Kullanım: %s [naif N]\n", argv[0]);
        return 2;
    }
    static const int boyutlar[] = {1000, 2000};
    long long sonuc[2][3][3];
    int *a = malloc(2000 * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("Pivot deneyi: Lomuto + küçük parçaya özyineleme\n");
    printf("girdi    strateji     n  karşılaştırma  ağaç yük.  yığın  "
           "doğru\n");
    for (int b = 0; b < 2; b++) {
        int n = boyutlar[b];
        for (int g = 0; g < 3; g++) {
            for (int s = 0; s < 3; s++) {
                girdi_uret(a, n, g);
                sayac_sifirla();
                hizli_sirala(a, 0, n - 1, s, 1, 1);
                sonuc[b][g][s] = karsilastirma;
                printf("%s %s %5d %14lld %10d %6d  %s\n", GIRDI_AD[g],
                       STRATEJI_AD[s], n, karsilastirma, agac_yuksekligi,
                       yigin_derinligi, sirali_mi(a, n) ? "evet" : "HAYIR");
            }
        }
    }
    printf("\nOran testi: karşılaştırma(2000) / karşılaştırma(1000)\n");
    printf("(Θ(n²) → 4; Θ(n log n) → 2·lg 2000 / lg 1000 = %.2f)\n",
           2.0 * log(2000.0) / log(1000.0));
    for (int g = 0; g < 3; g++) {
        printf("%s:", GIRDI_AD[g]);
        for (int s = 0; s < 3; s++) {
            printf("  %s %.2f", STRATEJI_AD[s],
                   (double)sonuc[1][g][s] / sonuc[0][g][s]);
        }
        printf("\n");
    }
    printf("n(n-1)/2 (n = 2000) = %d\n\n", 2000 * 1999 / 2);

    printf("Doğrulama: naif (iki çağrılı) sürümün yığın derinliği = döngülü\n"
           "sürümün ağaç yüksekliği (n = 500; deterministik pivotlar)\n");
    static const int stratejiler[] = {ILK, ORTANCA3};
    for (int g = 0; g < 3; g++) {
        for (int k = 0; k < 2; k++) {
            int s = stratejiler[k];
            girdi_uret(a, 500, g);
            sayac_sifirla();
            hizli_naif(a, 0, 499, s, 1);
            int naif_derinlik = yigin_derinligi;
            long long naif_k = karsilastirma;
            girdi_uret(a, 500, g);
            sayac_sifirla();
            hizli_sirala(a, 0, 499, s, 1, 1);
            printf("%s %s naif yığın = %3d · ağaç yük. = %3d · "
                   "karşılaştırma %s\n", GIRDI_AD[g], STRATEJI_AD[s],
                   naif_derinlik, agac_yuksekligi,
                   naif_k == karsilastirma ? "aynı" : "FARKLI");
        }
    }
    printf("Döngülü sürüm aynı ağacı gezer (aynı karşılaştırmalar), ama\n"
           "büyük parçayı yeni çağrı açmadan işler: yığın <= lg n + 1.\n");
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (introsort: ortanca
 * pivot + derinlik sınırı aşılınca öbek sıralaması); Python — list.sort */

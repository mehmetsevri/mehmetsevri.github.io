/* H06_03_ozyineleme_agaci.c — AP-2 Hafta 6 · Örnek 3 (★★)
 * Amaç    : Özyineleme ağacını izlemek: birleştirmeli sıralamada her düzeyin
 *           işi (birleştirilen eleman) n'dir, düzey sayısı ⌈lg n⌉ → n lg n.
 *           Ana teoremin üç durumu: T(n) = a·T(n/b) + n^d düzey işleri.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_03_ozyineleme_agaci.c ortak_rastgele.c \
 *           -o H06_03_ozyineleme_agaci -lm
 * Çalıştır: ./H06_03_ozyineleme_agaci
 * Eşleri  : cpp/H06_03_ozyineleme_agaci.cpp · python/H06_03_ozyineleme_agaci.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define MAKS_DUZEY 64

static long long duzey_cagri[MAKS_DUZEY], duzey_is[MAKS_DUZEY];
static long long duzey_karsilastirma[MAKS_DUZEY];
static int duzey_en_kucuk[MAKS_DUZEY], duzey_en_buyuk[MAKS_DUZEY];
static int duzey_sayisi = 0;

static void aralik_yaz(const int *a, int lo, int hi)
{
    for (int k = lo; k <= hi; k++) {
        printf(" %d", a[k]);
    }
}

static void girinti(int d)
{
    for (int k = 1; k < d; k++) {
        printf("  ");
    }
}

/* Birleştirme; karşılaştırma sayısını döndürür */
static long long birlestir(int *a, int *yrd, int lo, int mid, int hi)
{
    long long karsilastirma = 0;
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        karsilastirma++;
        if (a[i] <= a[j]) {
            yrd[k++] = a[i++];
        } else {
            yrd[k++] = a[j++];
        }
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
    return karsilastirma;
}

/* Birleştirmeli sıralama + düzey sayaçları; yaz = 1 ise ağacı yazar */
static void bs_izle(int *a, int *yrd, int lo, int hi, int d, int yaz)
{
    int boyut = hi - lo + 1;
    if (d > duzey_sayisi) {
        duzey_sayisi = d;
        duzey_en_kucuk[d] = duzey_en_buyuk[d] = boyut;
    }
    duzey_cagri[d]++;
    if (boyut < duzey_en_kucuk[d]) {
        duzey_en_kucuk[d] = boyut;
    }
    if (boyut > duzey_en_buyuk[d]) {
        duzey_en_buyuk[d] = boyut;
    }
    if (yaz) {
        printf("%d  ", d);
        girinti(d);
        printf("%s [%d..%d]", lo == hi ? "yaprak" : "böl", lo, hi);
        aralik_yaz(a, lo, hi);
        printf("\n");
    }
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_izle(a, yrd, lo, mid, d + 1, yaz);
    bs_izle(a, yrd, mid + 1, hi, d + 1, yaz);
    long long k = birlestir(a, yrd, lo, mid, hi);
    duzey_is[d] += boyut;              /* bu düğümün işi: boyut kadar eleman */
    duzey_karsilastirma[d] += k;
    if (yaz) {
        printf("%d  ", d);
        girinti(d);
        printf("birleştir [%d..%d] →", lo, hi);
        aralik_yaz(a, lo, hi);
        printf("  (%lld karşılaştırma)\n", k);
    }
}

static void duzeyleri_sifirla(void)
{
    for (int d = 0; d < MAKS_DUZEY; d++) {
        duzey_cagri[d] = duzey_is[d] = duzey_karsilastirma[d] = 0;
    }
    duzey_sayisi = 0;
}

static int tavan_log2(long long n)
{
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    return k;
}

static void duzey_tablosu(int *a, int n, int yaz)
{
    int *yrd = malloc((size_t)n * sizeof *yrd);
    if (yrd == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    duzeyleri_sifirla();
    bs_izle(a, yrd, 0, n - 1, 1, yaz);
    free(yrd);
    printf("n = %d\ndüzey  düğüm   boyut      iş  karşılaştırma\n", n);
    long long is_top = 0, k_top = 0;
    for (int d = 1; d <= duzey_sayisi; d++) {
        char boyut[32];
        if (duzey_en_kucuk[d] == duzey_en_buyuk[d]) {
            snprintf(boyut, sizeof boyut, "%d", duzey_en_kucuk[d]);
        } else {
            snprintf(boyut, sizeof boyut, "%d-%d", duzey_en_kucuk[d],
                     duzey_en_buyuk[d]);
        }
        printf("%5d %6lld %7s %7lld %14lld\n", d, duzey_cagri[d], boyut,
               duzey_is[d], duzey_karsilastirma[d]);
        is_top += duzey_is[d];
        k_top += duzey_karsilastirma[d];
    }
    int k = tavan_log2(n);
    printf("toplam iş = %lld · n·⌈lg n⌉ = %d·%d = %lld · karşılaştırma = "
           "%lld\n\n", is_top, n, k, (long long)n * k, k_top);
}

/* T(n) = a·T(n/b) + n^d, T(1) = 1: her düğüm kendi düzeyine n^d ekler */
static long long us(long long x, int d)
{
    long long s = 1;
    for (int k = 0; k < d; k++) {
        s *= x;
    }
    return s;
}

static void yineleme(long long n, int a, int b, int d, int duzey)
{
    if (duzey > duzey_sayisi) {
        duzey_sayisi = duzey;
    }
    duzey_is[duzey] += us(n, d);
    if (n <= 1) {
        return;
    }
    for (int k = 0; k < a; k++) {
        yineleme(n / b, a, b, d, duzey + 1);
    }
}

static void ana_teorem(long long n, int a, int b, int d)
{
    duzeyleri_sifirla();
    yineleme(n, a, b, d, 1);
    long long bd = us(b, d), toplam = 0;
    double logba = log((double)a) / log((double)b);
    printf("a=%d b=%d d=%d: ", a, b, d);
    if (a < bd) {
        printf("a < b^d (%d < %lld) → kök baskın: Θ(n^d) = Θ(n^%d)\n", a,
               bd, d);
    } else if (a == bd) {
        printf("a = b^d (%d = %lld) → düzeyler eşit: Θ(n^%d log n)\n", a,
               bd, d);
    } else {
        printf("a > b^d (%d > %lld) → yapraklar baskın: Θ(n^log_b a) = "
               "Θ(n^%.3f)\n", a, bd, logba);
    }
    printf("  düzey işleri:");
    for (int k = 1; k <= duzey_sayisi; k++) {
        printf(" %lld", duzey_is[k]);
        toplam += duzey_is[k];
    }
    double f = a < bd ? pow((double)n, d)
                      : (a == bd ? pow((double)n, d) * log2((double)n)
                                 : pow((double)n, logba));
    printf("\n  toplam T(%lld) = %lld · T(n) / f(n) = %.3f\n", n, toplam,
           toplam / f);
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4};
    printf("Özyineleme ağacı: birleştirmeli sıralama, n = 8\n");
    printf("d  olay\n");
    duzey_tablosu(a, 8, 1);

    int *x = malloc(1024 * sizeof *x);
    if (x == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(x, 1024, 0, 999999);
    duzey_tablosu(x, 1024, 0);
    rastgele_tohum(42);
    rastgele_dizi(x, 1000, 0, 999999);
    duzey_tablosu(x, 1000, 0);
    free(x);
    printf("Her düzeyde birleştirilen toplam eleman n'dir (son düzey eksik\n"
           "kalabilir); düzey sayısı ⌈lg n⌉ + 1, iş yapan düzey ⌈lg n⌉:\n"
           "T(n) = 2T(n/2) + n → Θ(n log n).\n\n");

    printf("Ana teorem: T(n) = a·T(n/b) + n^d, T(1) = 1, n = 256\n");
    printf("(düzey işleri kökten yapraklara; f(n) = Θ içindeki terim)\n");
    ana_teorem(256, 2, 2, 1);
    ana_teorem(256, 1, 2, 0);
    ana_teorem(256, 4, 2, 1);
    ana_teorem(256, 2, 2, 2);
    ana_teorem(256, 3, 2, 1);
    return 0;
}

/* Kütüphane karşılığı: yok (izleme ve sayma programı). */

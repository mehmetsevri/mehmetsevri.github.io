/* H06_04_lomuto_hizli.c — AP-2 Hafta 6 · Örnek 4 (★★)
 * Amaç    : Lomuto bölümleme (pivot = a[hi]) ve hızlı sıralama. Değişmez:
 *           a[lo..i] < pivot <= a[i+1..j-1]; a[j..hi-1] işlenmemiş.
 *           Rastgele girdide karşılaştırma ≈ 2(n+1)H(n) - 4n ≈ 1,39 n lg n.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_04_lomuto_hizli.c \
 *           ortak_rastgele.c -o H06_04_lomuto_hizli
 * Çalıştır: ./H06_04_lomuto_hizli
 * Eşleri  : cpp/H06_04_lomuto_hizli.cpp · python/H06_04_lomuto_hizli.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma = 0, takas_sayisi = 0;
static int en_derin = 0;

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
    takas_sayisi++;
}

/* Pivot a[hi]; değişmez: a[lo..i] < pivot <= a[i+1..j-1] */
int lomuto_bolumle(int *a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);  /* pivot son yerine */
    return i + 1;
}

/* d: özyineleme derinliği (kök = 1) */
void hizli_sirala(int *a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = lomuto_bolumle(a, lo, hi);
    hizli_sirala(a, lo, p - 1, d + 1);
    hizli_sirala(a, p + 1, hi, d + 1);
}

static void dizi_yaz(const int *a, int n)
{
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

/* Bölümlemenin adım adım izlenmesi (aynı algoritma + çıktı) */
static void lomuto_izle(int *a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    printf(" j  a[j]  karar           i  dizi\n");
    for (int j = lo; j < hi; j++) {
        int kucuk = a[j] < pivot;
        int deger = a[j];
        if (kucuk) {
            i++;
            int g = a[i];
            a[i] = a[j];
            a[j] = g;
        }
        printf("%2d %5d  %s %2d ", j, deger,
               kucuk ? "< pivot, takas " : ">= pivot       ", i);
        dizi_yaz(a, hi + 1);
    }
    int g = a[i + 1];
    a[i + 1] = a[hi];
    a[hi] = g;
    printf("son takas a[%d] <-> a[%d]: p = %d    ", i + 1, hi, i + 1);
    dizi_yaz(a, hi + 1);
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

/* a'yı hızlı sıralamayla sıralar; kâhinle (qsort) aynıysa 1 döndürür */
static int sinama(int *a, int n)
{
    int *kahin = malloc(((size_t)n + 1) * sizeof *kahin);
    if (kahin == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    for (int k = 0; k < n; k++) {
        kahin[k] = a[k];
    }
    qsort(kahin, (size_t)n, sizeof *kahin, kucukten_buyuge);  /* kâhin */
    karsilastirma = takas_sayisi = 0;
    en_derin = 0;
    hizli_sirala(a, 0, n - 1, 1);
    int ayni = 1;
    for (int k = 0; k < n; k++) {
        ayni = ayni && a[k] == kahin[k];
    }
    free(kahin);
    return ayni;
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4};
    int b[] = {6, 3, 8, 1, 7, 2, 5, 4};
    printf("Lomuto bölümleme (pivot = a[hi] = %d); değişmez:\n"
           "a[lo..i] < pivot <= a[i+1..j-1], a[j..hi-1] işlenmemiş\n", a[7]);
    printf("başta: i = -1, dizi:");
    dizi_yaz(a, 8);
    lomuto_izle(a, 0, 7);
    karsilastirma = takas_sayisi = 0;
    int p = lomuto_bolumle(b, 0, 7);
    printf("lomuto_bolumle: p = %d · karşılaştırma = %lld · takas = %lld\n\n",
           p, karsilastirma, takas_sayisi);

    int c[] = {6, 3, 8, 1, 7, 2, 5, 4};
    sinama(c, 8);
    printf("Hızlı sıralama:");
    dizi_yaz(c, 8);
    printf("karşılaştırma = %lld · takas = %lld · en büyük derinlik = %d\n\n",
           karsilastirma, takas_sayisi, en_derin);

    static const int boyutlar[] = {10, 100, 1000, 10000, 100000};
    int *x = malloc(100000 * sizeof *x);
    if (x == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("Rastgele girdi (tohum 42, 0..10^9); beklenen = 2(n+1)H(n) - 4n\n");
    printf("     n  karşılaştırma    beklenen  oran   takas  derinlik"
           "  kâhin\n");
    for (int t = 0; t < 5; t++) {
        int n = boyutlar[t];
        rastgele_tohum(42);
        rastgele_dizi(x, (size_t)n, 0, 1000000000);
        int ayni = sinama(x, n);
        double h = 0.0;
        for (int k = 1; k <= n; k++) {
            h += 1.0 / k;
        }
        double beklenen = 2.0 * (n + 1) * h - 4.0 * n;
        printf("%6d %14lld %11.0f %5.3f %7lld %9d  %s\n", n, karsilastirma,
               beklenen, karsilastirma / beklenen, takas_sayisi, en_derin,
               ayni ? "aynı" : "FARKLI");
    }

    printf("\nEn kötü durum: sıralı ve ters sıralı girdi (n = 500)\n");
    printf("girdi    karşılaştırma  n(n-1)/2  derinlik  kâhin\n");
    for (int tur = 0; tur < 2; tur++) {
        for (int k = 0; k < 500; k++) {
            x[k] = tur == 0 ? k : 500 - k;
        }
        int ayni = sinama(x, 500);
        printf("%s %14lld %9d %9d  %s\n", tur == 0 ? "sıralı" : "ters  ",
               karsilastirma, 500 * 499 / 2, en_derin,
               ayni ? "aynı" : "FARKLI");
    }
    printf("Pivot hep en büyük/en küçük olunca bölünme n-1 | 0 olur:\n"
           "T(n) = T(n-1) + n - 1 → Θ(n²), özyineleme derinliği n.\n");
    free(x);
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritma belirtilmez); C++ — std::sort
 * (introsort; kararsız), std::partition (bölümleme); Python — list.sort /
 * sorted (Timsort; hızlı sıralama değildir) */

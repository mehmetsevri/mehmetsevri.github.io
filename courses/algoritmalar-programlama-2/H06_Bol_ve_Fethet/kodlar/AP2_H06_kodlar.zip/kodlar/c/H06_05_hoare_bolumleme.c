/* H06_05_hoare_bolumleme.c — AP-2 Hafta 6 · Örnek 5 (★★)
 * Amaç    : Hoare bölümleme (pivot x = a[lo]; i soldan, j sağdan ilerler)
 *           ve Lomuto ile karşılaştırma/takas sayısı. Dönüş j pivotun son
 *           yeri DEĞİLDİR: a[lo..j] <= x <= a[j+1..hi] demektir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_05_hoare_bolumleme.c ortak_rastgele.c -o H06_05_hoare_bolumleme
 * Çalıştır: ./H06_05_hoare_bolumleme
 * Eşleri  : cpp/H06_05_hoare_bolumleme.cpp · python/H06_05_hoare_bolumleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma = 0, takas_sayisi = 0;
static int en_derin = 0;

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
    takas_sayisi++;
}

/* Pivot x = a[lo]; dönüş j: a[lo..j] <= x <= a[j+1..hi], lo <= j < hi */
int hoare_bolumle(int *a, int lo, int hi)
{
    int x = a[lo];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {  /* sağdan: x'ten büyük olmayanı bul */
            j--;
            karsilastirma++;
        } while (a[j] > x);
        do {  /* soldan: x'ten küçük olmayanı bul */
            i++;
            karsilastirma++;
        } while (a[i] < x);
        if (i >= j) {
            return j;
        }
        takas(a, i, j);
    }
}

void hizli_hoare(int *a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = hoare_bolumle(a, lo, hi);
    hizli_hoare(a, lo, p, d + 1);  /* p dahil */
    hizli_hoare(a, p + 1, hi, d + 1);
}

/* Karşılaştırma için Örnek 4'ün Lomuto bölümlemesi (pivot a[hi]) */
int lomuto_bolumle(int *a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

void hizli_lomuto(int *a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = lomuto_bolumle(a, lo, hi);
    hizli_lomuto(a, lo, p - 1, d + 1);
    hizli_lomuto(a, p + 1, hi, d + 1);
}

static void dizi_yaz(const int *a, int n)
{
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

/* Hoare bölümlemesinin izlenmesi (aynı algoritma + çıktı) */
static void hoare_izle(int *a, int lo, int hi)
{
    int x = a[lo];
    int i = lo - 1, j = hi + 1;
    printf("tur  i  j  işlem\n");
    for (int tur = 1;; tur++) {
        do {
            j--;
        } while (a[j] > x);
        do {
            i++;
        } while (a[i] < x);
        printf("%3d %2d %2d  ", tur, i, j);
        if (i >= j) {
            printf("i >= j → dönüş j = %d\n", j);
            return;
        }
        int g = a[i];
        a[i] = a[j];
        a[j] = g;
        printf("takas a[%d] <-> a[%d]:", i, j);
        dizi_yaz(a, hi + 1);
    }
}

static int sirali_mi(const int *a, int n)
{
    for (int k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

/* yontem 0: Lomuto, 1: Hoare; sayaçları sıfırlayıp a'nın kopyasını sıralar */
static int sirala_say(const int *a, int n, int yontem)
{
    int *b = malloc(((size_t)n + 1) * sizeof *b);
    if (b == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        exit(1);
    }
    for (int k = 0; k < n; k++) {
        b[k] = a[k];
    }
    karsilastirma = takas_sayisi = 0;
    en_derin = 0;
    if (yontem == 0) {
        hizli_lomuto(b, 0, n - 1, 1);
    } else {
        hizli_hoare(b, 0, n - 1, 1);
    }
    int dogru = sirali_mi(b, n);
    free(b);
    return dogru;
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4};
    int b[] = {6, 3, 8, 1, 7, 2, 5, 4};
    printf("Hoare bölümleme (pivot x = a[lo] = %d; i soldan, j sağdan)\n",
           a[0]);
    printf("başta:");
    dizi_yaz(a, 8);
    hoare_izle(a, 0, 7);
    karsilastirma = takas_sayisi = 0;
    int x0 = b[0];
    int p = hoare_bolumle(b, 0, 7);
    int yer = 0;
    while (b[yer] != x0) {
        yer++;
    }
    printf("sonuç: a[0..%d] <= %d <= a[%d..7]; pivot %d şimdi a[%d]'de, "
           "a[%d]'te değil\n", p, x0, p + 1, x0, yer, p);
    printf("Hoare: karşılaştırma = %lld · takas = %lld\n", karsilastirma,
           takas_sayisi);
    int c[] = {6, 3, 8, 1, 7, 2, 5, 4};
    karsilastirma = takas_sayisi = 0;
    lomuto_bolumle(c, 0, 7);
    printf("Lomuto (aynı dizi, pivot a[hi] = 4): karşılaştırma = %lld · "
           "takas = %lld\n\n", karsilastirma, takas_sayisi);

    static const int boyutlar[] = {100, 1000, 10000, 100000};
    int *x = malloc(100000 * sizeof *x);
    if (x == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("Rastgele girdi (tohum 42, 0..10^9): tam hızlı sıralama\n");
    printf("     n   Lomuto karş.  takas   Hoare karş.  takas  "
           "takas L/H\n");
    for (int t = 0; t < 4; t++) {
        int n = boyutlar[t];
        rastgele_tohum(42);
        rastgele_dizi(x, (size_t)n, 0, 1000000000);
        int d1 = sirala_say(x, n, 0);
        long long lk = karsilastirma, lt = takas_sayisi;
        int d2 = sirala_say(x, n, 1);
        printf("%6d %14lld %7lld %13lld %7lld %10.2f%s\n", n, lk, lt,
               karsilastirma, takas_sayisi, (double)lt / takas_sayisi,
               d1 && d2 ? "" : "  HATA");
    }

    printf("\nÖzel girdiler (n = 500): karşılaştırma / derinlik\n");
    printf("girdi       Lomuto karş.  derinlik   Hoare karş.  derinlik\n");
    for (int tur = 0; tur < 2; tur++) {
        for (int k = 0; k < 500; k++) {
            x[k] = tur == 0 ? 7 : k;
        }
        int d1 = sirala_say(x, 500, 0);
        long long lk = karsilastirma;
        int ld = en_derin;
        int d2 = sirala_say(x, 500, 1);
        printf("%s %14lld %9d %13lld %9d%s\n",
               tur == 0 ? "tümü eşit" : "sıralı   ", lk, ld, karsilastirma,
               en_derin, d1 && d2 ? "" : "  HATA");
    }
    printf("Tümü eşit girdide Hoare her eşitte durup takas eder ve ortadan "
           "böler;\nLomuto (a[j] < pivot) hiçbir elemanı sola almaz: "
           "Θ(n²). Sıralı girdide\nikisi de (uç pivotla) Θ(n²): çözüm "
           "pivot seçimi (Örnek 6).\n");
    free(x);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::partition (bölümleme; Hoare'a
 * benzer iki uçlu tarama), std::sort; Python — yok (list.sort Timsort) */

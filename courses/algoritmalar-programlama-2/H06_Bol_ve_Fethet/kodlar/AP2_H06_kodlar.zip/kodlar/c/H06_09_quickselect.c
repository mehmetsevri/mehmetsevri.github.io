/* H06_09_quickselect.c — AP-2 Hafta 6 · Örnek 9 (★★★)
 * Amaç    : Quickselect (Hoare'un FIND fikri): k'ıncı en küçük değer ve
 *           ortanca not. Bölümledikten sonra yalnızca k'nın bulunduğu
 *           parçada devam edilir: beklenen Θ(n), yinelemeli, O(1) ek
 *           bellek. Notlarda çok tekrar olduğu için üç yollu bölümleme.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_09_quickselect.c \
 *           ortak_rastgele.c -o H06_09_quickselect -lm
 * Çalıştır: ./H06_09_quickselect
 * Eşleri  : cpp/H06_09_quickselect.cpp · python/H06_09_quickselect.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma = 0;
static int tur_sayisi = 0;

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
}

/* Örnek 7: a[lo..lt-1] < p, a[lt..gt] = p, a[gt+1..hi] > p */
static void uc_yollu_bolumle(int *a, int lo, int hi, int p, int *lt_c,
                             int *gt_c)
{
    int lt = lo, i = lo, gt = hi;
    while (i <= gt) {
        karsilastirma++;
        if (a[i] < p) {
            takas(a, lt++, i++);
        } else {
            karsilastirma++;
            if (a[i] > p) {
                takas(a, i, gt--);
            } else {
                i++;
            }
        }
    }
    *lt_c = lt;
    *gt_c = gt;
}

/* k'ıncı en küçük (0 tabanlı); a yeniden düzenlenir */
int hizli_sec(int *a, int n, int k)
{
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        tur_sayisi++;
        int p = a[rastgele_aralik(lo, hi)];
        int lt, gt;
        uc_yollu_bolumle(a, lo, hi, p, &lt, &gt);
        if (k < lt) {
            hi = lt - 1;  /* k soldaki parçada */
        } else if (k > gt) {
            lo = gt + 1;  /* k sağdaki parçada */
        } else {
            return p;  /* k, a[lt..gt] içinde */
        }
    }
    return a[lo];
}

static void dizi_yaz(const int *a, int n)
{
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

/* Aynı algoritma; her turda aralığı, pivotu ve kararı yazar */
static int hizli_sec_izle(int *a, int n, int k)
{
    int lo = 0, hi = n - 1, tur = 0;
    printf("tur  lo  hi  pivot  lt  gt  karar\n");
    while (lo < hi) {
        int p = a[rastgele_aralik(lo, hi)];
        int lt, gt;
        uc_yollu_bolumle(a, lo, hi, p, &lt, &gt);
        printf("%3d %3d %3d %6d %3d %3d  ", ++tur, lo, hi, p, lt, gt);
        if (k < lt) {
            printf("k = %d < lt: sola  ", k);
            hi = lt - 1;
        } else if (k > gt) {
            printf("k = %d > gt: sağa  ", k);
            lo = gt + 1;
        } else {
            printf("lt <= k <= gt: bulundu = %d\n", p);
            return p;
        }
        dizi_yaz(a, n);
    }
    printf("lo = hi = %d: bulundu = %d\n", lo, a[lo]);
    return a[lo];
}

static int kucukten_buyuge(const void *p, const void *q)
{
    int x = *(const int *)p, y = *(const int *)q;
    return (x > y) - (x < y);
}

int main(void)
{
    int notlar[] = {72, 45, 88, 61, 95, 53, 77, 61, 84};
    int n = 9, k = n / 2;
    printf("Ortanca not: n = %d, k = n / 2 = %d (0 tabanlı)\nnotlar:", n, k);
    dizi_yaz(notlar, n);
    rastgele_tohum(7);
    int ortanca = hizli_sec_izle(notlar, n, k);
    printf("ortanca = %d\n\n", ortanca);

    static const int boyutlar[] = {101, 1001, 10001, 100001};
    const int tekrar = 5;               /* farklı pivot dizileriyle */
    int *x = malloc(100001 * sizeof *x), *y = malloc(100001 * sizeof *y);
    int *z = malloc(100001 * sizeof *z);
    if (x == NULL || y == NULL || z == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    for (int tur = 0; tur < 2; tur++) {
        int ust = tur == 0 ? 100 : 1000000000;
        printf("%s (tohum 42, 0..%s): %d çalıştırmanın ortalaması\n",
               tur == 0 ? "Notlar" : "Farklı değerler",
               tur == 0 ? "100" : "10^9", tekrar);
        printf("     n     ortanca  ort. karş.  karş./n  ort. tur   lg n  "
               "kâhin\n");
        for (int t = 0; t < 4; t++) {
            int m = boyutlar[t];
            rastgele_tohum(42);
            rastgele_dizi(x, (size_t)m, 0, ust);
            for (int i = 0; i < m; i++) {
                y[i] = x[i];
            }
            qsort(y, (size_t)m, sizeof *y, kucukten_buyuge);  /* kâhin */
            karsilastirma = 0;
            tur_sayisi = 0;
            int sonuc = 0, hepsi_dogru = 1;
            for (int r = 0; r < tekrar; r++) {
                for (int i = 0; i < m; i++) {
                    z[i] = x[i];
                }
                rastgele_tohum(2026 + (uint64_t)r);
                sonuc = hizli_sec(z, m, m / 2);
                hepsi_dogru = hepsi_dogru && sonuc == y[m / 2];
            }
            double ort = (double)karsilastirma / tekrar;
            printf("%6d %11d %11.0f %8.2f %9.1f %6.2f  %s\n", m, sonuc, ort,
                   ort / m, (double)tur_sayisi / tekrar, log2((double)m),
                   hepsi_dogru ? "aynı" : "FARKLI");
        }
        printf("\n");
    }
    printf("n 1000 kat büyürken karş./n artmıyor (lg n ise büyüyor): "
           "beklenen\niş Θ(n). Sıralayıp ortadakini almak Θ(n log n) olurdu."
           "\nEn kötü durumda (pivot hep uçta) Θ(n²).\n");
    free(x);
    free(y);
    free(z);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::nth_element (introselect);
 * Python — statistics.median (sıralar: O(n log n)); heapq.nsmallest */

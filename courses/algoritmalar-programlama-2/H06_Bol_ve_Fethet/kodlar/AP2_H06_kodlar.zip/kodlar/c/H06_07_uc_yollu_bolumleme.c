/* H06_07_uc_yollu_bolumleme.c — AP-2 Hafta 6 · Örnek 7 (★★★)
 * Amaç    : Üç yollu bölümleme (Dijkstra'nın Hollanda bayrağı problemi):
 *           a[lo..lt-1] < p, a[lt..i-1] = p, a[i..gt] işlenmemiş,
 *           a[gt+1..hi] > p. Çok tekrar eden anahtarlarda iki yollu
 *           (Lomuto) hızlı sıralama Θ(n²)'ye düşer; üç yollu düşmez.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_07_uc_yollu_bolumleme.c ortak_rastgele.c \
 *           -o H06_07_uc_yollu_bolumleme
 * Çalıştır: ./H06_07_uc_yollu_bolumleme
 * Eşleri  : cpp/H06_07_uc_yollu_bolumleme.cpp ·
 *           python/H06_07_uc_yollu_bolumleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma = 0, takas_sayisi = 0;
static int en_derin = 0, agac_yuksekligi = 0;

static void takas(int *a, int i, int j)
{
    int gecici = a[i];
    a[i] = a[j];
    a[j] = gecici;
    takas_sayisi++;
}

/* p değerine göre üç bölge; *lt_c, *gt_c: eşitler bölgesi a[lt..gt] */
void uc_yollu_bolumle(int *a, int lo, int hi, int p, int *lt_c, int *gt_c)
{
    int lt = lo, i = lo, gt = hi;
    while (i <= gt) {
        karsilastirma++;
        if (a[i] < p) {  /* küçük: sola */
            takas(a, lt, i);
            lt++;
            i++;
        } else {
            karsilastirma++;
            if (a[i] > p) {  /* büyük: sağa */
                takas(a, i, gt);
                gt--;
            } else {  /* eşit: yerinde kalır */
                i++;
            }
        }
    }
    *lt_c = lt;
    *gt_c = gt;
}

/* Üç yollu hızlı sıralama; pivot rastgele bir elemanın değeri */
void hizli_uc_yollu(int *a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = a[rastgele_aralik(lo, hi)];
    int lt, gt;
    uc_yollu_bolumle(a, lo, hi, p, &lt, &gt);
    /* a[lt..gt] = p: eşitler bir daha işlenmez */
    hizli_uc_yollu(a, lo, lt - 1, d + 1);
    hizli_uc_yollu(a, gt + 1, hi, d + 1);
}

/* Karşılaştırma için iki yollu: rastgele pivot + Lomuto (a[j] < pivot);
 * yığın güvenliği için küçük parçaya özyineleme (Örnek 6) */
static int lomuto_bolumle(int *a, int lo, int hi)
{
    takas(a, rastgele_aralik(lo, hi), hi);
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            i++;
            takas(a, i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

void hizli_iki_yollu(int *a, int lo, int hi, int d, int t)
{
    if (d > en_derin) {
        en_derin = d;
    }
    for (;;) {
        if (t > agac_yuksekligi) {
            agac_yuksekligi = t;
        }
        if (lo >= hi) {
            return;
        }
        int p = lomuto_bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            hizli_iki_yollu(a, lo, p - 1, d + 1, t + 1);
            lo = p + 1;
        } else {
            hizli_iki_yollu(a, p + 1, hi, d + 1, t + 1);
            hi = p - 1;
        }
        t++;
    }
}

static void dizi_yaz(const int *a, int n)
{
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
}

/* Hollanda bayrağı izlemesi (aynı algoritma + çıktı) */
static void bayrak_izle(int *a, int n, int p)
{
    int lt = 0, i = 0, gt = n - 1, adim = 0;
    printf("adım lt  i gt  a[i]  işlem\n");
    while (i <= gt) {
        printf("%4d %2d %2d %2d %5d  ", ++adim, lt, i, gt, a[i]);
        if (a[i] < p) {
            printf("< p: a[%d] <-> a[%d], lt++, i++  :", lt, i);
            int g = a[lt];
            a[lt] = a[i];
            a[i] = g;
            lt++;
            i++;
        } else if (a[i] > p) {
            printf("> p: a[%d] <-> a[%d], gt--       :", i, gt);
            int g = a[i];
            a[i] = a[gt];
            a[gt] = g;
            gt--;
        } else {
            printf("= p: i++                       :");
            i++;
        }
        dizi_yaz(a, n);
    }
    printf("son: lt = %d, gt = %d → a[0..%d] < p, a[%d..%d] = p, "
           "a[%d..%d] > p\n", lt, gt, lt - 1, lt, gt, gt + 1, n - 1);
}

static int sirali_mi(const int *a, int n)
{
    for (int k = 1; k < n; k++) {
        if (a[k - 1] > a[k]) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int bayrak[] = {2, 0, 1, 2, 1, 0, 0, 2, 1, 0};
    int b[] = {2, 0, 1, 2, 1, 0, 0, 2, 1, 0};
    printf("Hollanda bayrağı (Dijkstra): 0 = kırmızı, 1 = beyaz, 2 = mavi; "
           "p = 1\n");
    printf("başta:");
    dizi_yaz(bayrak, 10);
    bayrak_izle(bayrak, 10, 1);
    int lt, gt;
    uc_yollu_bolumle(b, 0, 9, 1, &lt, &gt);
    printf("uc_yollu_bolumle: tek geçiş · karşılaştırma = %lld · takas = "
           "%lld\n\n", karsilastirma, takas_sayisi);

    static const char *const ADLAR[] = {"rastgele 0..10^9", "az farklı 0..9  ",
                                        "ikili 0..1      ", "tümü eşit (7)   "};
    static const int ALTLAR[] = {0, 0, 0, 7};
    static const int USTLER[] = {1000000000, 9, 1, 7};
    const int n = 2000;
    int *g = malloc((size_t)n * sizeof *g), *x = malloc((size_t)n * sizeof *x);
    if (g == NULL || x == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        return 1;
    }
    printf("Hızlı sıralama, n = %d, rastgele pivot (iki yollu: Lomuto)\n", n);
    printf("girdi              yöntem      karşılaştırma   takas  ağaç  "
           "doğru\n");
    for (int t = 0; t < 4; t++) {
        rastgele_tohum(42);
        rastgele_dizi(g, (size_t)n, ALTLAR[t], USTLER[t]);
        for (int y = 0; y < 2; y++) {
            for (int k = 0; k < n; k++) {
                x[k] = g[k];
            }
            karsilastirma = takas_sayisi = 0;
            en_derin = agac_yuksekligi = 0;
            rastgele_tohum(2026);
            if (y == 0) {
                hizli_iki_yollu(x, 0, n - 1, 1, 1);
            } else {
                hizli_uc_yollu(x, 0, n - 1, 1);
                agac_yuksekligi = en_derin;
            }
            printf("%s   %s %14lld %7lld %5d  %s\n", ADLAR[t],
                   y == 0 ? "iki yollu" : "üç yollu ", karsilastirma,
                   takas_sayisi, agac_yuksekligi,
                   sirali_mi(x, n) ? "evet" : "HAYIR");
        }
    }
    printf("İki yollu bölümlemede pivota eşit elemanlar hep aynı tarafa "
           "gider:\nk farklı anahtarda her eşit grup kendi içinde karesel "
           "sıralanır.\nÜç yollu bölümleme eşitleri tek geçişte ortaya "
           "toplar ve bir daha\nişlemez: k farklı anahtar için beklenen "
           "iş O(n log k).\n");
    free(g);
    free(x);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::partition iki kez (ya da
 * std::sort); Python — yok. Bentley ve McIlroy (1993) qsort'u eşitleri
 * ayrı toplayan bölümleme kullanır. */

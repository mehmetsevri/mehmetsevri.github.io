/* H06_HA8_sirali_girdi.c — AP-2 Hafta 6 · Hata Avcısı 8
 * BU DOSYA KASITLI HATA İÇERİR: ilk eleman pivotlu, iki çağrılı (naif)
 * hızlı sıralama. Sıralı ya da ters sıralı girdide her bölümleme n-1 | 0
 * böler: Θ(n²) karşılaştırma ve n derinlikte özyineleme (n yığın
 * çerçevesi). Büyük n'de yığın taşar (Linux: SIGSEGV).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA8_sirali_girdi.c zamanlayici.c -o H06_HA8_sirali_girdi
 * Çalıştır: ./H06_HA8_sirali_girdi             (sıralı; n = 1000, 2000, 4000)
 *           ./H06_HA8_sirali_girdi sirali|ters N
 * Düzeltme: H06_HA8_sirali_girdi_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "zamanlayici.h"

static long long karsilastirma = 0;
static int en_derin = 0;

static void takas(int *a, int i, int j)
{
    int g = a[i];
    a[i] = a[j];
    a[j] = g;
}

static int bolumle(int *a, int lo, int hi)
{
    takas(a, lo, hi);                   /* HATA: pivot hep ilk eleman */
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            takas(a, ++i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

static void hizli_sirala(int *a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int p = bolumle(a, lo, hi);
    hizli_sirala(a, lo, p - 1, d + 1);  /* HATA: iki çağrı, derinlik n */
    hizli_sirala(a, p + 1, hi, d + 1);
}

static void calistir(int n, int ters)
{
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        exit(1);
    }
    for (int k = 0; k < n; k++) {
        a[k] = ters ? n - k : k;
    }
    karsilastirma = 0;
    en_derin = 0;
    double t0 = zaman_sn();
    hizli_sirala(a, 0, n - 1, 1);
    double ms = (zaman_sn() - t0) * 1e3;
    printf("%s n = %6d: karşılaştırma = %11lld (n(n-1)/2 = %11lld) · "
           "derinlik = %d\n", ters ? "ters  " : "sıralı", n, karsilastirma,
           (long long)n * (n - 1) / 2, en_derin);
    fprintf(stderr, "  süre: %.1f ms\n", ms);
    free(a);
}

int main(int argc, char *argv[])
{
    if (argc == 3) {
        char *son;
        long n = strtol(argv[2], &son, 10);
        if (*son != '\0' || n < 2 || n > 10000000) {
            fprintf(stderr, "N 2..10000000 olmalı\n");
            return 2;
        }
        printf("tek çalıştırma: %s girdi, n = %ld\n", argv[1], n);
        fflush(stdout);                 /* çökmeden önce görünsün */
        calistir((int)n, strcmp(argv[1], "ters") == 0);
        return 0;
    }
    for (int n = 1000; n <= 4000; n *= 2) {
        calistir(n, 0);
    }
    printf("n iki katına çıkınca karşılaştırma ≈ 4 katı: Θ(n²)\n");
    return 0;
}

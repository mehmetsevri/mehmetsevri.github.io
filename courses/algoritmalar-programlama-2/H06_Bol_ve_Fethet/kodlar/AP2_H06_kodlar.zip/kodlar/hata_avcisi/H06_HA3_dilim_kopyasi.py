"""H06_HA3_dilim_kopyasi.py — AP-2 Hafta 6 · Hata Avcısı 3
BU DOSYA KASITLI HATA İÇERİR: yerinde hızlı sıralamada alt parçalar
a[:p] ve a[p + 1:] dilimleriyle özyinelemeye veriliyor. Python'da dilim
YENİ bir listedir (O(k) kopya): özyineleme kopyayı sıralar, asıl liste
yalnızca en üstteki bölümlemeyi görür.
Çalıştır: python3 H06_HA3_dilim_kopyasi.py
Düzeltme: H06_HA3_dilim_kopyasi_duzeltilmis.py (indislerle çalışmak)
"""

kopyalanan = 0


def lomuto_bolumle(a):
    pivot = a[-1]
    i = -1
    for j in range(len(a) - 1):
        if a[j] < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[-1] = a[-1], a[i + 1]
    return i + 1


def hizli_sirala(a):
    global kopyalanan
    if len(a) <= 1:
        return
    p = lomuto_bolumle(a)
    kopyalanan += len(a) - 1
    hizli_sirala(a[:p])         # HATA: kopya sıralanır, a değil
    hizli_sirala(a[p + 1:])     # HATA: kopya sıralanır, a değil


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    print("önce :", a)
    hizli_sirala(a)
    print("sonra:", a)
    print("sıralı mı:", "evet" if a == sorted(a) else "HAYIR")
    print("dilimlerle kopyalanan eleman:", kopyalanan)


if __name__ == "__main__":
    main()

/* H06_HA5_hoare_donus.cpp — AP-2 Hafta 6 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR: Hoare bölümlemesinin döndürdüğü j,
 * Lomuto'daki gibi "pivotun son yeri" sanılıyor ve özyineleme
 * [lo..j-1] / [j+1..hi] ile yapılıyor. Hoare'da j yalnızca bir SINIRDIR
 * (a[lo..j] <= x <= a[j+1..hi]); a[j] hiçbir parçaya girmez ve yanlış
 * yerde kalabilir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA5_hoare_donus.cpp -o H06_HA5_hoare_donus
 * Düzeltme: H06_HA5_hoare_donus_duzeltilmis.cpp ([lo..j] / [j+1..hi])
 */
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

int hoare_bolumle(std::vector<int>& a, int lo, int hi)
{
    int x = a[lo];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {
            j--;
        } while (a[j] > x);
        do {
            i++;
        } while (a[i] < x);
        if (i >= j) {
            return j;
        }
        std::swap(a[i], a[j]);
    }
}

void hizli_hoare(std::vector<int>& a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int p = hoare_bolumle(a, lo, hi);
    hizli_hoare(a, lo, p - 1);          // HATA: a[p] dışarıda kalıyor
    hizli_hoare(a, p + 1, hi);
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

int main()
{
    std::vector<int> a = {6, 3, 8, 1, 7, 2, 5, 4};
    hizli_hoare(a, 0, 7);
    std::cout << "sonuç:";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\nsıralı mı: " << (sirali_mi(a) ? "evet" : "HAYIR") << "\n";
    int hatali = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 1000; t++) {
        std::vector<int> x = rastgele_dizi(20, 0, 99);
        hizli_hoare(x, 0, 19);
        hatali += sirali_mi(x) ? 0 : 1;
    }
    std::cout << "1000 rastgele dizinin (n = 20) " << hatali
              << " tanesi sıralı DEĞİL\n";
    return 0;
}

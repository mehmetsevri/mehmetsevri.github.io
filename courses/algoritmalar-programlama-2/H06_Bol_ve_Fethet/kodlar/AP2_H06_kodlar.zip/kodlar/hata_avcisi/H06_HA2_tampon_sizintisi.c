/* H06_HA2_tampon_sizintisi.c — AP-2 Hafta 6 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR: birleştirmeli sıralamada her çağrı kendi
 * yardımcı tamponunu malloc ile ayırıyor ve free ETMİYOR (bellek
 * sızıntısı). Sıralama doğru çıkar; hata ancak bellek denetleyicisiyle
 * (AddressSanitizer/LeakSanitizer ya da valgrind) görülür.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O1 -g \
 *           -fsanitize=address H06_HA2_tampon_sizintisi.c ortak_rastgele.c \
 *           -o H06_HA2_tampon_sizintisi
 * Düzeltme: H06_HA2_tampon_sizintisi_duzeltilmis.c (tek tampon)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long ayirma = 0, bayt = 0;

static void bs_ozyineli(int *a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_ozyineli(a, lo, mid);
    bs_ozyineli(a, mid + 1, hi);
    size_t boy = (size_t)(hi - lo + 1);
    int *yrd = malloc(boy * sizeof *yrd);       /* HATA: her çağrıda */
    if (yrd == NULL) {
        exit(1);
    }
    ayirma++;
    bayt += (long long)(boy * sizeof *yrd);
    int i = lo, j = mid + 1, k = 0;
    while (i <= mid && j <= hi) {
        yrd[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = 0; k < (int)boy; k++) {
        a[lo + k] = yrd[k];
    }
    /* HATA: free(yrd) unutuldu */
}

int main(void)
{
    const int n = 1000;
    int a[1000];
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 0, 999999);
    bs_ozyineli(a, 0, n - 1);
    int sirali = 1;
    for (int k = 1; k < n; k++) {
        sirali = sirali && a[k - 1] <= a[k];
    }
    printf("n = %d · sıralı: %s\n", n, sirali ? "evet" : "HAYIR");
    printf("malloc çağrısı = %lld · ayrılan = %lld bayt · free = 0\n",
           ayirma, bayt);
    fflush(stdout);         /* LeakSanitizer raporu çıkışta stderr'e yazar */
    return 0;
}

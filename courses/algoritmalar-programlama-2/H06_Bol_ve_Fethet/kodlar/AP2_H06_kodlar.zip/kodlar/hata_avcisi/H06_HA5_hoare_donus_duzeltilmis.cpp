/* H06_HA5_hoare_donus_duzeltilmis.cpp — AP-2 Hafta 6 · Hata Avcısı 5
 * Düzeltilmiş: Hoare bölümlemesinde özyineleme [lo..j] ve [j+1..hi]
 * ile yapılır (Örnek 5); j sınırdır, pivotun yeri değildir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA5_hoare_donus_duzeltilmis.cpp \
 *           -o H06_HA5_hoare_donus_duzeltilmis
 */
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

int hoare_bolumle(std::vector<int>& a, int lo, int hi)
{
    int x = a[lo];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {
            j--;
        } while (a[j] > x);
        do {
            i++;
        } while (a[i] < x);
        if (i >= j) {
            return j;
        }
        std::swap(a[i], a[j]);
    }
}

void hizli_hoare(std::vector<int>& a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int p = hoare_bolumle(a, lo, hi);
    hizli_hoare(a, lo, p);              // p dahil
    hizli_hoare(a, p + 1, hi);
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t k = 1; k < a.size(); k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

int main()
{
    std::vector<int> a = {6, 3, 8, 1, 7, 2, 5, 4};
    hizli_hoare(a, 0, 7);
    std::cout << "sonuç:";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\nsıralı mı: " << (sirali_mi(a) ? "evet" : "HAYIR") << "\n";
    int hatali = 0;
    rastgele_tohum(42);
    for (int t = 0; t < 1000; t++) {
        std::vector<int> x = rastgele_dizi(20, 0, 99);
        hizli_hoare(x, 0, 19);
        hatali += sirali_mi(x) ? 0 : 1;
    }
    std::cout << "1000 rastgele dizinin (n = 20) " << hatali
              << " tanesi sıralı DEĞİL\n";
    return 0;
}

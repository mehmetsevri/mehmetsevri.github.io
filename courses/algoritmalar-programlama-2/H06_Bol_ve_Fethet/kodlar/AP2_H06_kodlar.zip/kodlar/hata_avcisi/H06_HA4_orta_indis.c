/* H06_HA4_orta_indis.c — AP-2 Hafta 6 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR: orta nokta YUKARI yuvarlanıyor:
 * mid = (lo + hi + 1) / 2 ve bölme [lo..mid] / [mid+1..hi]. İki elemanlı
 * aralıkta (lo = 0, hi = 1) mid = 1 olur; sol parça [0..1] yine aynı
 * aralıktır → aralık küçülmez, özyineleme sonsuzdur.
 * Güvenli gösterim: derinlik 10 000'i aşınca program durur.
 * Korumasız (gerçek belirti): ./H06_HA4_orta_indis korumasiz
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_HA4_orta_indis.c \
 *           -o H06_HA4_orta_indis
 * Düzeltme: H06_HA4_orta_indis_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SINIR 10000

static int korumali = 1;

static void birlestir(int *a, int *yrd, int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        yrd[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
}

static void bs_ozyineli(int *a, int *yrd, int lo, int hi, int d)
{
    if (korumali && d > SINIR) {        /* yalnızca gösterim koruması */
        fprintf(stderr, "derinlik %d aşıldı: aralık [%d..%d] küçülmüyor\n",
                SINIR, lo, hi);
        exit(1);
    }
    if (lo >= hi) {
        return;
    }
    int mid = (lo + hi + 1) / 2;        /* HATA: yukarı yuvarlama */
    bs_ozyineli(a, yrd, lo, mid, d + 1);
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1);
    birlestir(a, yrd, lo, mid, hi);
}

int main(int argc, char *argv[])
{
    if (argc > 1 && strcmp(argv[1], "korumasiz") == 0) {
        korumali = 0;
    }
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4}, yrd[8];
    printf("çağrı zinciri: [0..7] → [0..4] → [0..2] → [0..1] → [0..1] → "
           "...\n");
    fflush(stdout);
    bs_ozyineli(a, yrd, 0, 7, 1);
    printf("sıralandı (buraya ulaşılmaz)\n");
    return 0;
}

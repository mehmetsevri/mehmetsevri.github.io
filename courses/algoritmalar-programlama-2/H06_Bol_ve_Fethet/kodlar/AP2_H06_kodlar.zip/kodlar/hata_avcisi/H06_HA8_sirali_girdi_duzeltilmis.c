/* H06_HA8_sirali_girdi_duzeltilmis.c — AP-2 Hafta 6 · Hata Avcısı 8
 * Düzeltilmiş: (1) pivot rastgele (ortak LCG) — sıralı/ters girdi artık
 * en kötü durum değildir; (2) küçük parçaya özyineleme, büyük parçada
 * döngü — en kötü pivotta bile yığın derinliği <= lg n + 1 (Örnek 6).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA8_sirali_girdi_duzeltilmis.c ortak_rastgele.c \
 *           zamanlayici.c -o H06_HA8_sirali_girdi_duzeltilmis
 * Çalıştır: ./H06_HA8_sirali_girdi_duzeltilmis [sirali|ters N]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

static long long karsilastirma = 0;
static int en_derin = 0;

static void takas(int *a, int i, int j)
{
    int g = a[i];
    a[i] = a[j];
    a[j] = g;
}

static int bolumle(int *a, int lo, int hi)
{
    takas(a, rastgele_aralik(lo, hi), hi);      /* rastgele pivot */
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        karsilastirma++;
        if (a[j] < pivot) {
            takas(a, ++i, j);
        }
    }
    takas(a, i + 1, hi);
    return i + 1;
}

static void hizli_sirala(int *a, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    while (lo < hi) {
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {                  /* küçüğe özyineleme */
            hizli_sirala(a, lo, p - 1, d + 1);
            lo = p + 1;                         /* büyüğe döngü */
        } else {
            hizli_sirala(a, p + 1, hi, d + 1);
            hi = p - 1;
        }
    }
}

static void calistir(int n, int ters)
{
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        exit(1);
    }
    for (int k = 0; k < n; k++) {
        a[k] = ters ? n - k : k;
    }
    karsilastirma = 0;
    en_derin = 0;
    rastgele_tohum(2026);
    double t0 = zaman_sn();
    hizli_sirala(a, 0, n - 1, 1);
    double ms = (zaman_sn() - t0) * 1e3;
    printf("%s n = %7d: karşılaştırma = %10lld · yığın derinliği = %d\n",
           ters ? "ters  " : "sıralı", n, karsilastirma, en_derin);
    fprintf(stderr, "  süre: %.1f ms\n", ms);
    free(a);
}

int main(int argc, char *argv[])
{
    if (argc == 3) {
        char *son;
        long n = strtol(argv[2], &son, 10);
        if (*son != '\0' || n < 2 || n > 10000000) {
            fprintf(stderr, "N 2..10000000 olmalı\n");
            return 2;
        }
        calistir((int)n, strcmp(argv[1], "ters") == 0);
        return 0;
    }
    for (int n = 1000; n <= 4000; n *= 2) {
        calistir(n, 0);
    }
    calistir(1000000, 0);
    calistir(1000000, 1);
    return 0;
}

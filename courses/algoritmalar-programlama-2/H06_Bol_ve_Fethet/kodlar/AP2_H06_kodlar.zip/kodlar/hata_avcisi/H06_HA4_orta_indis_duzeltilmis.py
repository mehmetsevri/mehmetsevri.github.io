"""H06_HA4_orta_indis_duzeltilmis.py — AP-2 Hafta 6 · Hata Avcısı 4
Düzeltilmiş: mid = lo + (hi - lo) // 2 aşağı yuvarlar; lo < hi iken
lo <= mid < hi olduğundan iki parça da [lo..hi]'den kısadır.
Çalıştır: python3 H06_HA4_orta_indis_duzeltilmis.py
"""


def birlestir(a, yrd, lo, mid, hi):
    i, j, k = lo, mid + 1, lo
    while i <= mid and j <= hi:
        if a[i] <= a[j]:
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    yrd[k:hi + 1] = a[i:mid + 1] + a[j:hi + 1]
    a[lo:hi + 1] = yrd[lo:hi + 1]


def bs_ozyineli(a, yrd, lo, hi):
    if lo >= hi:
        return
    mid = lo + (hi - lo) // 2           # aşağı yuvarlama
    bs_ozyineli(a, yrd, lo, mid)
    bs_ozyineli(a, yrd, mid + 1, hi)
    birlestir(a, yrd, lo, mid, hi)


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    yrd = [0] * len(a)
    bs_ozyineli(a, yrd, 0, len(a) - 1)
    print("sonuç:", a)


if __name__ == "__main__":
    main()

/* H06_HA1_kalan_kopyalama_duzeltilmis.c — AP-2 Hafta 6 · Hata Avcısı 1
 * Düzeltilmiş: ana döngüden sonra soldaki VE sağdaki kalan elemanlar
 * c'ye kopyalanır (en çok biri boş değildir).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA1_kalan_kopyalama_duzeltilmis.c \
 *           -o H06_HA1_kalan_kopyalama_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

/* a[0..na-1] ve b[0..nb-1] sıralı; c'ye birleşimlerini yazar */
static void birlestir(const int *a, size_t na, const int *b, size_t nb,
                      int *c)
{
    size_t i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        if (a[i] <= b[j]) {
            c[k++] = a[i++];
        } else {
            c[k++] = b[j++];
        }
    }
    while (i < na) {                    /* sol dizinin kalanı */
        c[k++] = a[i++];
    }
    while (j < nb) {                    /* sağ dizinin kalanı */
        c[k++] = b[j++];
    }
}

static void yaz(const char *ad, const int *x, size_t n)
{
    printf("%s:", ad);
    for (size_t k = 0; k < n; k++) {
        printf(" %d", x[k]);
    }
    printf("\n");
}

int main(void)
{
    const int a[] = {2, 5, 7, 9};
    const int b[] = {1, 5, 6, 10, 12};
    int *c = calloc(9, sizeof *c);
    if (c == NULL) {
        return 1;
    }
    birlestir(a, 4, b, 5, c);
    yaz("a", a, 4);
    yaz("b", b, 5);
    yaz("c", c, 9);
    printf("beklenen: 1 2 5 5 6 7 9 10 12\n");
    free(c);
    return 0;
}

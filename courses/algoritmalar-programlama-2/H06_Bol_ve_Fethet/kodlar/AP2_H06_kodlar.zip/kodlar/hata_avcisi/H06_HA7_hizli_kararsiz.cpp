/* H06_HA7_hizli_kararsiz.cpp — AP-2 Hafta 6 · Hata Avcısı 7
 * BU DOSYA KASITLI HATA İÇERİR: hızlı sıralamanın kararlı olduğu
 * varsayılıyor. Liste önce ada göre sıralı; puana göre hızlı sıralamadan
 * sonra eşit puanlıların ad sırasının korunacağı sanılıyor. Bölümlemedeki
 * uzak takaslar eşit anahtarların sırasını bozar.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA7_hizli_kararsiz.cpp -o H06_HA7_hizli_kararsiz
 * Düzeltme: H06_HA7_hizli_kararsiz_duzeltilmis.cpp (kararlı birleştirmeli
 *           sıralama ya da (puan, ad) bileşik anahtarı)
 */
#include <iostream>
#include <string>
#include <utility>
#include <vector>

struct Ogrenci {
    int puan;
    std::string ad;
};

// Lomuto (Örnek 4), yalnızca puana göre
static int bolumle(std::vector<Ogrenci>& a, int lo, int hi)
{
    int pivot = a[hi].puan;
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (a[j].puan < pivot) {
            i++;
            std::swap(a[i], a[j]);
        }
    }
    std::swap(a[i + 1], a[hi]);
    return i + 1;
}

static void hizli_sirala(std::vector<Ogrenci>& a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int p = bolumle(a, lo, hi);
    hizli_sirala(a, lo, p - 1);
    hizli_sirala(a, p + 1, hi);
}

int main()
{
    std::vector<Ogrenci> a = {{70, "Ali"}, {85, "Can"}, {70, "Deniz"},
                              {60, "Ece"}, {85, "Naz"}, {70, "Selin"},
                              {60, "Ufuk"}};      // ada göre sıralı
    hizli_sirala(a, 0, static_cast<int>(a.size()) - 1);   // HATA: kararsız
    std::cout << "puana göre:";
    bool korundu = true;
    for (std::size_t k = 0; k < a.size(); k++) {
        std::cout << (k ? ", " : " ") << a[k].puan << " " << a[k].ad;
        if (k > 0 && a[k - 1].puan == a[k].puan && a[k - 1].ad > a[k].ad) {
            korundu = false;
        }
    }
    std::cout << "\neşit puanlılarda ad sırası korundu mu: "
              << (korundu ? "evet" : "HAYIR") << "\n";
    return 0;
}

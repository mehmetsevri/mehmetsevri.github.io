"""H06_HA3_dilim_kopyasi_duzeltilmis.py — AP-2 Hafta 6 · Hata Avcısı 3
Düzeltilmiş: aynı liste ve indis aralığı (lo, hi) özyinelemeye verilir;
kopya yoktur, bölümlemeler asıl listede yapılır (Örnek 4).
Çalıştır: python3 H06_HA3_dilim_kopyasi_duzeltilmis.py
"""


def lomuto_bolumle(a, lo, hi):
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        if a[j] < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


def hizli_sirala(a, lo, hi):
    if lo >= hi:
        return
    p = lomuto_bolumle(a, lo, hi)
    hizli_sirala(a, lo, p - 1)
    hizli_sirala(a, p + 1, hi)


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    print("önce :", a)
    hizli_sirala(a, 0, len(a) - 1)
    print("sonra:", a)
    print("sıralı mı:", "evet" if a == sorted(a) else "HAYIR")
    print("dilimlerle kopyalanan eleman: 0")


if __name__ == "__main__":
    main()

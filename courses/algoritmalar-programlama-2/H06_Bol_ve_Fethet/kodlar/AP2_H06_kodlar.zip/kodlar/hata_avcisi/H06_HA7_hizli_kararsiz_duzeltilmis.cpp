/* H06_HA7_hizli_kararsiz_duzeltilmis.cpp — AP-2 Hafta 6 · Hata Avcısı 7
 * Düzeltilmiş: ikinci ölçüt (ad) gerekiyorsa ya KARARLI bir algoritma
 * (birleştirmeli sıralama, eşitlikte soldan) kullanılır ya da hızlı
 * sıralama bileşik anahtarla (puan, sonra ad) karşılaştırır. İkisi de
 * gösterilir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA7_hizli_kararsiz_duzeltilmis.cpp \
 *           -o H06_HA7_hizli_kararsiz_duzeltilmis
 */
#include <iostream>
#include <string>
#include <utility>
#include <vector>

struct Ogrenci {
    int puan;
    std::string ad;
};

// 1) Kararlı: birleştirmeli sıralama (eşitlikte soldan al)
static void bs(std::vector<Ogrenci>& a, std::vector<Ogrenci>& yrd, int lo,
               int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs(a, yrd, lo, mid);
    bs(a, yrd, mid + 1, hi);
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        yrd[k++] = a[i].puan <= a[j].puan ? a[i++] : a[j++];
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
}

// 2) Bileşik anahtar: puan, eşitse ad
static bool once_mi(const Ogrenci& x, const Ogrenci& y)
{
    return x.puan < y.puan || (x.puan == y.puan && x.ad < y.ad);
}

static void hizli_sirala(std::vector<Ogrenci>& a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    Ogrenci pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (once_mi(a[j], pivot)) {
            i++;
            std::swap(a[i], a[j]);
        }
    }
    std::swap(a[i + 1], a[hi]);
    hizli_sirala(a, lo, i);
    hizli_sirala(a, i + 2, hi);
}

static void yaz(const char* baslik, const std::vector<Ogrenci>& a)
{
    std::cout << baslik;
    for (std::size_t k = 0; k < a.size(); k++) {
        std::cout << (k ? ", " : " ") << a[k].puan << " " << a[k].ad;
    }
    std::cout << "\n";
}

int main()
{
    const std::vector<Ogrenci> liste = {{70, "Ali"}, {85, "Can"},
                                        {70, "Deniz"}, {60, "Ece"},
                                        {85, "Naz"}, {70, "Selin"},
                                        {60, "Ufuk"}};    // ada göre sıralı
    std::vector<Ogrenci> a = liste, yrd(liste.size());
    bs(a, yrd, 0, static_cast<int>(a.size()) - 1);
    yaz("birleştirmeli (kararlı):", a);
    std::vector<Ogrenci> b = liste;
    hizli_sirala(b, 0, static_cast<int>(b.size()) - 1);
    yaz("hızlı + (puan, ad)     :", b);
    return 0;
}

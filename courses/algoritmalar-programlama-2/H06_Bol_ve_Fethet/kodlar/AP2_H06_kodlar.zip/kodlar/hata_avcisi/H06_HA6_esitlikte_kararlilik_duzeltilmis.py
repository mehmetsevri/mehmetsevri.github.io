"""H06_HA6_esitlikte_kararlilik_duzeltilmis.py — AP-2 Hafta 6 · HA 6
Düzeltilmiş: eşitlikte SOLDAN alınır (a[i][0] <= a[j][0]); eşit puanlı
kayıtlar önceki sıralarını korur — birleştirmeli sıralama kararlıdır.
Çalıştır: python3 H06_HA6_esitlikte_kararlilik_duzeltilmis.py
"""


def birlestir(a, yrd, lo, mid, hi):
    i, j, k = lo, mid + 1, lo
    while i <= mid and j <= hi:
        if a[i][0] <= a[j][0]:          # eşitlikte soldaki önce: kararlı
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    yrd[k:hi + 1] = a[i:mid + 1] + a[j:hi + 1]
    a[lo:hi + 1] = yrd[lo:hi + 1]


def bs_ozyineli(a, yrd, lo, hi):
    if lo >= hi:
        return
    mid = lo + (hi - lo) // 2
    bs_ozyineli(a, yrd, lo, mid)
    bs_ozyineli(a, yrd, mid + 1, hi)
    birlestir(a, yrd, lo, mid, hi)


def main():
    # Ada göre sıralı liste; şimdi puana göre (kararlı) sıralanmalı
    kayitlar = [(70, "Ali"), (85, "Can"), (70, "Deniz"), (60, "Ece"),
                (85, "Naz"), (70, "Selin"), (60, "Ufuk")]
    a = kayitlar[:]
    bs_ozyineli(a, [None] * len(a), 0, len(a) - 1)
    print("puana göre:", ", ".join(f"{p} {ad}" for p, ad in a))
    kahin = sorted(kayitlar, key=lambda r: r[0])    # kararlı kâhin
    print("kararlı mı:", "evet" if a == kahin else "HAYIR")
    print("beklenen  :", ", ".join(f"{p} {ad}" for p, ad in kahin))


if __name__ == "__main__":
    main()

/* H06_HA4_orta_indis_duzeltilmis.c — AP-2 Hafta 6 · Hata Avcısı 4
 * Düzeltilmiş: mid = lo + (hi - lo) / 2 aşağı yuvarlar; lo < hi iken
 * lo <= mid < hi olduğundan iki parça da [lo..hi]'den kısadır.
 * (lo + (hi - lo) / 2 biçimi, (lo + hi) / 2'deki taşmayı da önler: H4.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA4_orta_indis_duzeltilmis.c -o H06_HA4_orta_indis_duzeltilmis
 */
#include <stdio.h>

static void birlestir(int *a, int *yrd, int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        yrd[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i <= mid) {
        yrd[k++] = a[i++];
    }
    while (j <= hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k];
    }
}

static int en_derin = 0;

static void bs_ozyineli(int *a, int *yrd, int lo, int hi, int d)
{
    if (d > en_derin) {
        en_derin = d;
    }
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;       /* aşağı yuvarlama */
    bs_ozyineli(a, yrd, lo, mid, d + 1);
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1);
    birlestir(a, yrd, lo, mid, hi);
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4}, yrd[8];
    bs_ozyineli(a, yrd, 0, 7, 1);
    printf("sonuç:");
    for (int k = 0; k < 8; k++) {
        printf(" %d", a[k]);
    }
    printf("\nen büyük derinlik = %d (⌈lg 8⌉ + 1)\n", en_derin);
    return 0;
}

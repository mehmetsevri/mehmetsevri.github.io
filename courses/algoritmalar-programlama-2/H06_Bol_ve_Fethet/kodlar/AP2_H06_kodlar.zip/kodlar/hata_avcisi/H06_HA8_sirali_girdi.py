"""H06_HA8_sirali_girdi.py — AP-2 Hafta 6 · Hata Avcısı 8
BU DOSYA KASITLI HATA İÇERİR: ilk eleman pivotlu, iki çağrılı (naif)
hızlı sıralama. Sıralı girdide Θ(n²) karşılaştırma ve n derinlik:
Python yaklaşık 1000 çerçevede RecursionError fırlatır.
Çalıştır: python3 H06_HA8_sirali_girdi.py
Düzeltme: H06_HA8_sirali_girdi_duzeltilmis.py
"""

karsilastirma = 0
en_derin = 0


def bolumle(a, lo, hi):
    global karsilastirma
    a[lo], a[hi] = a[hi], a[lo]         # HATA: pivot hep ilk eleman
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        karsilastirma += 1
        if a[j] < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


def hizli_sirala(a, lo, hi, d):
    global en_derin
    if d > en_derin:
        en_derin = d
    if lo >= hi:
        return
    p = bolumle(a, lo, hi)
    hizli_sirala(a, lo, p - 1, d + 1)   # HATA: iki çağrı, derinlik n
    hizli_sirala(a, p + 1, hi, d + 1)


def main():
    global karsilastirma, en_derin
    for n in (500, 900, 2000):
        a = list(range(n))
        karsilastirma = en_derin = 0
        print(f"sıralı n = {n}: ", end="", flush=True)
        hizli_sirala(a, 0, n - 1, 1)
        print(f"karşılaştırma = {karsilastirma} "
              f"(n(n-1)/2 = {n * (n - 1) // 2}) · derinlik = {en_derin}")


if __name__ == "__main__":
    main()

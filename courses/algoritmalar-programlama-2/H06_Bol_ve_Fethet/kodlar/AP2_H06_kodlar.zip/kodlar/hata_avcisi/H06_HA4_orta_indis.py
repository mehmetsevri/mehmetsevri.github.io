"""H06_HA4_orta_indis.py — AP-2 Hafta 6 · Hata Avcısı 4
BU DOSYA KASITLI HATA İÇERİR: orta nokta YUKARI yuvarlanıyor:
mid = (lo + hi + 1) // 2 ve bölme [lo..mid] / [mid+1..hi]. İki elemanlı
aralıkta mid = hi olur; sol parça yine aynı aralıktır → sonsuz özyineleme.
Python bunu ~1000 çerçevede RecursionError ile durdurur.
Çalıştır: python3 H06_HA4_orta_indis.py
Düzeltme: H06_HA4_orta_indis_duzeltilmis.py
"""


def birlestir(a, yrd, lo, mid, hi):
    i, j, k = lo, mid + 1, lo
    while i <= mid and j <= hi:
        if a[i] <= a[j]:
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    yrd[k:hi + 1] = a[i:mid + 1] + a[j:hi + 1]
    a[lo:hi + 1] = yrd[lo:hi + 1]


def bs_ozyineli(a, yrd, lo, hi):
    if lo >= hi:
        return
    mid = (lo + hi + 1) // 2            # HATA: yukarı yuvarlama
    bs_ozyineli(a, yrd, lo, mid)
    bs_ozyineli(a, yrd, mid + 1, hi)
    birlestir(a, yrd, lo, mid, hi)


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    yrd = [0] * len(a)
    print("çağrı zinciri: [0..7] → [0..4] → [0..2] → [0..1] → [0..1] → ...",
          flush=True)
    bs_ozyineli(a, yrd, 0, len(a) - 1)
    print("sıralandı (buraya ulaşılmaz)")


if __name__ == "__main__":
    main()

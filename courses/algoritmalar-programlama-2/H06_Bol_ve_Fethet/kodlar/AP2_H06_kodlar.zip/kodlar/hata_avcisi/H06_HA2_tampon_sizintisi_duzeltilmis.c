/* H06_HA2_tampon_sizintisi_duzeltilmis.c — AP-2 Hafta 6 · Hata Avcısı 2
 * Düzeltilmiş: tampon bir kez ayrılır ve sonunda bırakılır (Örnek 2).
 * Ayrıca "her çağrıda malloc + free" sürümünün (sızıntısız ama gereksiz
 * ayırma maliyetli) süresi tek tamponla karşılaştırılır (stderr).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA2_tampon_sizintisi_duzeltilmis.c ortak_rastgele.c \
 *           zamanlayici.c -o H06_HA2_tampon_sizintisi_duzeltilmis
 * Çalıştır: ./H06_HA2_tampon_sizintisi_duzeltilmis [n]   (varsayılan 1000)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

static long long ayirma = 0;

/* yrd[k - ofset] kullanılır: tek tamponda ofset = 0, parça tamponunda lo */
static void birlestir(int *a, int *yrd, int ofset, int lo, int mid, int hi)
{
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        yrd[k++ - ofset] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i <= mid) {
        yrd[k++ - ofset] = a[i++];
    }
    while (j <= hi) {
        yrd[k++ - ofset] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = yrd[k - ofset];
    }
}

/* Doğru: paylaşılan tek tampon */
static void bs_tek_tampon(int *a, int *yrd, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_tek_tampon(a, yrd, lo, mid);
    bs_tek_tampon(a, yrd, mid + 1, hi);
    birlestir(a, yrd, 0, lo, mid, hi);
}

/* Sızıntısız ama yavaş: her çağrıda malloc + free */
static void bs_her_cagrida(int *a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs_her_cagrida(a, lo, mid);
    bs_her_cagrida(a, mid + 1, hi);
    int *yrd = malloc((size_t)(hi - lo + 1) * sizeof *yrd);
    if (yrd == NULL) {
        exit(1);
    }
    ayirma++;
    birlestir(a, yrd, lo, lo, mid, hi);
    free(yrd);
}

typedef struct {
    const int *x;
    int *a, *yrd;
    int n, tek;
} Gorev;

static void gorev(void *v)
{
    Gorev *g = v;
    memcpy(g->a, g->x, (size_t)g->n * sizeof *g->a);
    if (g->tek) {
        bs_tek_tampon(g->a, g->yrd, 0, g->n - 1);
    } else {
        bs_her_cagrida(g->a, 0, g->n - 1);
    }
}

int main(int argc, char *argv[])
{
    long n = 1000;
    if (argc > 1) {
        char *son;
        n = strtol(argv[1], &son, 10);
        if (*son != '\0') {
            n = -1;
        }
    }
    if (n < 2 || n > 10000000) {
        fprintf(stderr, "n 2..10000000 olmalı\n");
        return 2;
    }
    int *x = malloc((size_t)n * sizeof *x), *a = malloc((size_t)n * sizeof *a);
    int *yrd = malloc((size_t)n * sizeof *yrd);
    if (x == NULL || a == NULL || yrd == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(x, (size_t)n, 0, 999999);
    Gorev tek = {x, a, yrd, (int)n, 1}, her = {x, a, yrd, (int)n, 0};
    gorev(&tek);
    int sirali = 1;
    for (int k = 1; k < n; k++) {
        sirali = sirali && a[k - 1] <= a[k];
    }
    ayirma = 0;
    gorev(&her);
    printf("n = %ld · sıralı: %s · tek tampon: 1 malloc + 1 free\n", n,
           sirali ? "evet" : "HAYIR");
    printf("her çağrıda ayırma: %lld malloc + %lld free\n", ayirma, ayirma);
    double t_tek = olc_ortanca(gorev, &tek, 5);
    double t_her = olc_ortanca(gorev, &her, 5);
    fprintf(stderr, "süre (1 ısınma + 5 tekrar, ortanca): tek tampon %.2f ms"
            " · her çağrıda malloc/free %.2f ms (oran %.2f)\n", t_tek * 1e3,
            t_her * 1e3, t_her / t_tek);
    free(x);
    free(a);
    free(yrd);
    return 0;
}

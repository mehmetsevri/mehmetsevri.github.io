/* H06_HA1_kalan_kopyalama.c — AP-2 Hafta 6 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR: birleştirmede dizilerden biri bitince
 * diğerinin KALANI kopyalanmıyor. Döngü yalnızca "ikisinde de eleman
 * varken" çalışır; kalan elemanlar c'ye hiç yazılmaz.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H06_HA1_kalan_kopyalama.c -o H06_HA1_kalan_kopyalama
 * Düzeltme: H06_HA1_kalan_kopyalama_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

/* a[0..na-1] ve b[0..nb-1] sıralı; c'ye birleşimlerini yazar */
static void birlestir(const int *a, size_t na, const int *b, size_t nb,
                      int *c)
{
    size_t i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        if (a[i] <= b[j]) {
            c[k++] = a[i++];
        } else {
            c[k++] = b[j++];
        }
    }
    /* HATA: kalan elemanlar için iki döngü eksik */
}

static void yaz(const char *ad, const int *x, size_t n)
{
    printf("%s:", ad);
    for (size_t k = 0; k < n; k++) {
        printf(" %d", x[k]);
    }
    printf("\n");
}

int main(void)
{
    const int a[] = {2, 5, 7, 9};
    const int b[] = {1, 5, 6, 10, 12};
    int *c = calloc(9, sizeof *c);      /* sıfırlı: belirti belirlenimci */
    if (c == NULL) {
        return 1;
    }
    birlestir(a, 4, b, 5, c);
    yaz("a", a, 4);
    yaz("b", b, 5);
    yaz("c", c, 9);
    printf("beklenen: 1 2 5 5 6 7 9 10 12\n");
    int eksik = 0;
    for (size_t k = 0; k < 9; k++) {
        eksik += c[k] == 0;
    }
    printf("yazılmamış (0 kalan) hücre: %d\n", eksik);
    free(c);
    return 0;
}

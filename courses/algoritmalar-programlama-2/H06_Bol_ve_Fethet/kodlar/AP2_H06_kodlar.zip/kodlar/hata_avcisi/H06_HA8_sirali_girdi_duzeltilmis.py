"""H06_HA8_sirali_girdi_duzeltilmis.py — AP-2 Hafta 6 · Hata Avcısı 8
Düzeltilmiş: rastgele pivot (ortak LCG) + küçük parçaya özyineleme,
büyük parçada döngü: yığın derinliği <= lg n + 1 (Örnek 6).
Çalıştır: python3 H06_HA8_sirali_girdi_duzeltilmis.py
"""

from ortak_rastgele import rastgele_aralik, rastgele_tohum

karsilastirma = 0
en_derin = 0


def bolumle(a, lo, hi):
    global karsilastirma
    r = rastgele_aralik(lo, hi)         # rastgele pivot
    a[r], a[hi] = a[hi], a[r]
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        karsilastirma += 1
        if a[j] < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


def hizli_sirala(a, lo, hi, d):
    global en_derin
    if d > en_derin:
        en_derin = d
    while lo < hi:
        p = bolumle(a, lo, hi)
        if p - lo < hi - p:             # küçüğe özyineleme
            hizli_sirala(a, lo, p - 1, d + 1)
            lo = p + 1                  # büyüğe döngü
        else:
            hizli_sirala(a, p + 1, hi, d + 1)
            hi = p - 1


def main():
    global karsilastirma, en_derin
    for n in (500, 900, 2000, 100000):
        a = list(range(n))
        karsilastirma = en_derin = 0
        rastgele_tohum(2026)
        hizli_sirala(a, 0, n - 1, 1)
        print(f"sıralı n = {n}: karşılaştırma = {karsilastirma} · "
              f"yığın derinliği = {en_derin} · sıralı: "
              + ("evet" if a == sorted(a) else "HAYIR"))


if __name__ == "__main__":
    main()

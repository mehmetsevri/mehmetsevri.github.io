# Hafta 6 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, çıktı türü, amacı ve derleme durumuyla aşağıdadır. **Ders notu / Sunum / Web** sütunları dosyanın kodunun gösterildiği yerleri verir: ders notu bölümü (A.x: Ek A, C++ ve Python karşılıkları), slayt numarası, web sayfasındaki bölüm kimliği; — o materyalde kodun kendisinin gösterilmediği anlamına gelir (çıktısı gösterilmiş olabilir). Ortam: gcc/g++ 13.3 (x86-64 Linux, glibc 2.39), Python 3.11.15 (örnekler 3.10 uyumludur; 3.10, 3.12 ve 3.13 ile de aynı stdout doğrulandı).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program [-lm]` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`.

Eşdeğerlik: `python3 esdeger_test.py .` → **13/13 GEÇTİ** (tümü “=”), derleyici uyarısı 0, sütun aşımı 0; `--asan` ile de geçer.

## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Ortak modül | Derleme | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|---|
| `H06_01_birlestirme` | ★ | = | evet | İki sıralı dizinin birleştirilmesi: birleştirme değişmezi ve eşitlikte soldan alarak kararlılık | ortak_rastgele | sıfır uyarı (3 dil) | A.1 | — | `#h06-birlestirmeli` |
| `H06_02_birlestirmeli_siralama` | ★★ | = | evet | Birleştirmeli sıralama (yukarıdan aşağıya, tek yardımcı tampon): karşılaştırma, kopya, çağrı ve derinlik | ortak_rastgele | sıfır uyarı (3 dil) | 4.1, A.2 | slayt 19, 20, 21, 40 | `#h06-birlestirmeli` |
| `H06_03_ozyineleme_agaci` | ★★ | = | — | Özyineleme ağacı izleme: düzey başına iş sayacı ve ana teoremin üç durumu | ortak_rastgele | sıfır uyarı (3 dil) | A.3 | — | `#h06-bagintilar` |
| `H06_04_lomuto_hizli` | ★★ | = | evet | Lomuto bölümleme (pivot = a[hi]) ve hızlı sıralama: değişmez, izleme ve 2(n+1)H(n) - 4n beklentisi | ortak_rastgele | sıfır uyarı (3 dil) | 4.2, A.4 | slayt 26 | `#h06-hizli` |
| `H06_05_hoare_bolumleme` | ★★ | = | evet | Hoare bölümleme ve Lomuto ile karşılaştırma/takas sayısı; dönüş indisi pivotun yeri değildir | ortak_rastgele | sıfır uyarı (3 dil) | 4.2, A.5 | — | `#h06-hizli` |
| `H06_06_pivot_deneyi` | ★★ | = | evet | Pivot deneyi: ilk eleman / rastgele / üçün ortancası × sıralı, ters, rastgele girdi; ağaç yüksekliği ve yığın derinliği | ortak_rastgele | sıfır uyarı (3 dil) | 4.2, A.6 | — | `#h06-hizli` |
| `H06_07_uc_yollu_bolumleme` | ★★★ | = | evet | Üç yollu bölümleme (Hollanda bayrağı, Dijkstra) ve çok tekrar eden anahtarlarda iki yollu ile karşılaştırma | ortak_rastgele | sıfır uyarı (3 dil) | 4.2, A.7 | slayt 39 | `#h06-hizli` |
| `H06_08_ters_cevrim` | ★★ | = | evet | Ters çevrim sayısı: birleştirmeli sıralamayla Θ(n log n); H5'in Θ(n²) çift taraması kâhin | ortak_rastgele | sıfır uyarı (3 dil) | 4.3, A.8 | — | `#h06-ters-cevrim` |
| `H06_09_quickselect` | ★★★ | = | evet | Quickselect: ortanca not (üç yollu bölümleme, rastgele pivot, yinelemeli); sıralama kâhine karşı | ortak_rastgele | sıfır uyarı (3 dil) | 4.4, A.9 | — | `#h06-quickselect` |
| `H06_10_asagidan_yukari` | ★★★ | = | evet | Aşağıdan yukarıya (yinelemeli) birleştirmeli sıralama: geçişler, eşsiz son blok ve yukarıdan aşağıya ile karşılaştırma | ortak_rastgele | sıfır uyarı (3 dil) | 5.1, A.10 | slayt 38 | `#h06-cozumlu` |
| `H06_11_melez_siralama` | ★★★ | = | — | Melez sıralama: hızlı sıralama + küçük parçalarda araya ekleme; eşik deneyi (4…64; sayaç ve süre) | ortak_rastgele, zamanlayici | sıfır uyarı (3 dil) | 5.2, A.11 | — | `#h06-cozumlu` |
| `H06_12_buyuk_deney` | ★★★ | = | — | Büyük deney programı: birleştirmeli / hızlı (3 pivot) / kütüphane / araya ekleme; varsayılan küçük, ölçüm kipi CSV | ortak_rastgele, zamanlayici | sıfır uyarı (3 dil) | A.12 | — | `#h06-cozumlu` |
| `H06_13_en_buyuk_alt_dizi` | ★★★ | = | evet | Böl ve fethet ile en büyük alt dizi toplamı; H2 Kadane ile aynı sonuç, toplama sayısı karşılaştırması | ortak_rastgele | sıfır uyarı (3 dil) | 4.5, A.13 | — | `#h06-en-buyuk` |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt` (üç dilin ortak çıktısı). Öğretilen dil farkı satırları ve Dil Penceresi notu: `ornekler.json` → `farklar`, `dil_notu`. Örnek 6'nın `naif N` kipi ve Örnek 11–12'nin ölçüm argümanları varsayılan çalıştırmanın dışındadır (dosya başlıklarına bakın).

Ortak modüller (90_Ortak_Varliklar/kod_ortak kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`.

## 2. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir (hata mantıksal ya da bellek/yığın kaynaklıdır). Gerçek belirtiler (derleme komutu, çıktı, çıkış kodu/sinyal) `hata_avcisi/ciktilar/` altındadır. Ortak modüllerin kopyaları da bu klasördedir.

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H06_HA1_kalan_kopyalama.c` | C | kasıtlı hata | Birleştirmede biri bitince diğerinin kalanını kopyalamamak: c'nin son iki hücresi yazılmaz (0 kalır) | `ciktilar/H06_HA1_kalan_kopyalama.txt` | — | — | — |
| `hata_avcisi/H06_HA1_kalan_kopyalama_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H06_HA1_kalan_kopyalama_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H06_HA2_tampon_sizintisi.c` | C | kasıtlı hata | Her özyinelemede tampon ayırıp free etmemek: sıralama doğru, LeakSanitizer 999 ayırmada 39 904 bayt sızıntı bildirir; düzeltilmiş sürüm her çağrıda malloc/free maliyetini tek tamponla karşılaştırır | `ciktilar/H06_HA2_tampon_sizintisi.txt` | — | — | — |
| `hata_avcisi/H06_HA2_tampon_sizintisi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H06_HA2_tampon_sizintisi_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H06_HA3_dilim_kopyasi.py` | Python | kasıtlı hata | Python'da a[:p] dilimini özyinelemeye vermek: kopya sıralanır, asıl liste yalnızca ilk bölümlemeyi görür | `ciktilar/H06_HA3_dilim_kopyasi.txt` | 7 | slayt 46 | `#h06-hata-avcisi` |
| `hata_avcisi/H06_HA3_dilim_kopyasi_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H06_HA3_dilim_kopyasi_duzeltilmis.txt` | — | slayt 46 | `#h06-hata-avcisi` |
| `hata_avcisi/H06_HA4_orta_indis.c` | C | kasıtlı hata | Orta noktayı yukarı yuvarlamak ((lo + hi + 1) / 2) ve [lo..mid] / [mid+1..hi] bölmesi: [0..1] aralığı küçülmez, sonsuz özyineleme (C: derinlik koruması / SIGSEGV; Python: RecursionError) | `ciktilar/H06_HA4_orta_indis_c.txt` | 7 | — | `#h06-hata-avcisi` |
| `hata_avcisi/H06_HA4_orta_indis.py` | Python | kasıtlı hata | Orta noktayı yukarı yuvarlamak ((lo + hi + 1) / 2) ve [lo..mid] / [mid+1..hi] bölmesi: [0..1] aralığı küçülmez, sonsuz özyineleme (C: derinlik koruması / SIGSEGV; Python: RecursionError) | `ciktilar/H06_HA4_orta_indis_py.txt` | — | — | — |
| `hata_avcisi/H06_HA4_orta_indis_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H06_HA4_orta_indis_duzeltilmis_c.txt` | — | — | — |
| `hata_avcisi/H06_HA4_orta_indis_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H06_HA4_orta_indis_duzeltilmis_py.txt` | — | — | — |
| `hata_avcisi/H06_HA5_hoare_donus.cpp` | C++ | kasıtlı hata | Hoare'un döndürdüğü j'yi pivotun yeri sanmak ([lo..j-1] / [j+1..hi]): 1000 rastgele dizinin 999'u sıralı değil | `ciktilar/H06_HA5_hoare_donus.txt` | 7 | slayt 45 | `#h06-hata-avcisi` |
| `hata_avcisi/H06_HA5_hoare_donus_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H06_HA5_hoare_donus_duzeltilmis.txt` | — | slayt 45 | `#h06-hata-avcisi` |
| `hata_avcisi/H06_HA6_esitlikte_kararlilik.py` | Python | kasıtlı hata | Birleştirmede eşitlikte sağdan almak (<= yerine <): puan sırası doğru ama kararlılık bozulur | `ciktilar/H06_HA6_esitlikte_kararlilik.txt` | — | — | — |
| `hata_avcisi/H06_HA6_esitlikte_kararlilik_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H06_HA6_esitlikte_kararlilik_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H06_HA7_hizli_kararsiz.cpp` | C++ | kasıtlı hata | Hızlı sıralamayı kararlı sanmak: ada göre sıralı listede eşit puanlıların ad sırası bozulur | `ciktilar/H06_HA7_hizli_kararsiz.txt` | — | — | — |
| `hata_avcisi/H06_HA7_hizli_kararsiz_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H06_HA7_hizli_kararsiz_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H06_HA8_sirali_girdi.c` | C | kasıtlı hata | Sıralı girdide ilk eleman pivotu: n(n-1)/2 karşılaştırma ve n derinlik; Python'da RecursionError, C'de küçük yığında SIGSEGV (-O2'de sıralı girdide kuyruk çağrısı elenir) | `ciktilar/H06_HA8_sirali_girdi_c.txt` | 7 | — | — |
| `hata_avcisi/H06_HA8_sirali_girdi.py` | Python | kasıtlı hata | Sıralı girdide ilk eleman pivotu: n(n-1)/2 karşılaştırma ve n derinlik; Python'da RecursionError, C'de küçük yığında SIGSEGV (-O2'de sıralı girdide kuyruk çağrısı elenir) | `ciktilar/H06_HA8_sirali_girdi_py.txt` | — | — | — |
| `hata_avcisi/H06_HA8_sirali_girdi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H06_HA8_sirali_girdi_duzeltilmis_c.txt` | — | — | — |
| `hata_avcisi/H06_HA8_sirali_girdi_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H06_HA8_sirali_girdi_duzeltilmis_py.txt` | — | — | — |

## 3. Haftanın Deneyi (deney/)

| Dosya | Açıklama |
|---|---|
| `deney/{c,cpp,python}/H06_12_buyuk_deney.*` | Ölçüm programı (Örnek 12'nin kopyası): `ALGORITMA GIRDI N TEKRAR` → CSV satırı (duvar saati + işlemci zamanı, sayaçlar) |
| `deney/{c,cpp,python}/H06_11_melez_siralama.*` | Eşik deneyi (Örnek 11'in kopyası): `N TEKRAR --csv` |
| `deney/olcum_calistir.py` | Sürücü: derler, ölçer, `sonuclar/h06_deney_olcum.csv`, `h06_deney_esik.csv` ve `OLCUM_ORTAMI.txt` yazar (`--devam`, `--yalniz-esik`, `--karesel-tur K`: yalnız Θ(n²) yapılandırmalarla ek tur) |
| `deney/kestirim.py` | Çözümleme: turları birleştirir (`h06_deney_ozet.csv`: yapılandırma başına turların işlemci süresi ortancası, en az / en çok), `h06_deney_oran.csv` (oran testi, eğim, T/(n lg n)), `h06_deney_kestirim.csv` (işaretli kestirim + sınama), `h06_deney_derinlik.csv`, `h06_deney_esik_ozet.csv` |
| `deney/sonuclar/h06_deney_olcum{_tur1,_tur2,,_tur4,_tur5}.csv` | Ham ölçüm turları: 1–3 tam plan (121 yapılandırma; `h06_deney_olcum.csv` = tur 3), 4–5 yalnız Θ(n²) yapılandırmalar (27); çekişme özeti `OLCUM_ORTAMI.txt` sonunda |
| `deney/sonuclar/h06_deney_esik{_tur2,}.csv` | Eşik deneyinin ham verisi (her dosyada 3 iç tur) |
| `deney/OLCUM_ORTAMI.txt` | Makine, derleyici, yöntem, turlar ve çekişme göstergesi |
| `../gorseller/kaynak/h06_deney_grafik.py` | Deney grafikleri (`gorseller/h06_deney_*_{belge,sunum}.png`) |

## 4. Kavram, alıştırma ve quiz programları (kavram/, alistirmalar/, quiz/)

Ders notunda, sunumda ya da web sayfasında gösterilen ve merdivende olmayan her kod parçası ya da çıktı buradaki küçük, derlenip çalışan programlardandır. Kavram programlarının çıktıları `kavram/ciktilar/` altındadır (ilk satır ortam bilgisi); alıştırma ve quiz programlarının çıktıları yanıt içerdiği için dağıtılmaz: önce tahmin edin, sonra kendiniz çalıştırın. Kasıtlı hatalı alıştırmaların başlığında “BU DOSYA KASITLI HATA İÇERİR”, Parsons dosyasında “tamamlanacak; bu hâliyle derlenmez” yazar. Çözümler öğrenci klasöründe değildir.

| Dosya | Tür | Amaç | Derleme | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `alistirmalar/H06_A01_cagri_sirasi.c` | alıştırma | Birleştirmeli sıralamanın çağrı ağacında birleştirmelerin hangi sırayla yapıldığını izleyin (önce tahmin, sonra çalıştır) | sıfır uyarı | Alıştırma 6.1 | — | `#h06-alistirmalar` |
| `alistirmalar/H06_A02_hata_bul_geri_kopya.c` | alıştırma | Kasıtlı hata: birleştirmeli sıralama bazı girdilerde yanlış sonuç veriyor. Hatalı satırı bulun ve tek karakterle düzeltin. | sıfır uyarı | Alıştırma 6.9 | — | `#h06-alistirmalar` |
| `alistirmalar/H06_A03_hata_bul_ters_cevrim.c` | alıştırma | Kasıtlı hata: ters çevrim sayısı kâhinden farklı çıkıyor. | sıfır uyarı | Alıştırma 6.10 | — | `#h06-alistirmalar` |
| `alistirmalar/H06_A04_parsons_hoare.c` | alıştırma | AP-2 Hafta 6 · Alıştırma 6.11 (Parsons) | tamamlanacak (derlenmez) | Alıştırma 6.11 | — | `#h06-alistirmalar` |
| `alistirmalar/H06_A05_dilimli_bs.py` | alıştırma | Dilimlerle yazılmış birleştirmeli sıralama: a değişir mi, kaç yeni liste oluşur? Önce tahmin edin, sonra çalıştırın. | — | Alıştırma 6.15 | — | `#h06-alistirmalar` |
| `alistirmalar/H06_A06_sort_kararlilik.cpp` | alıştırma | std::sort ile std::stable_sort eşit anahtarlarda ne yapar? n küçükken bozulma görülmemesi std::sort'un kararlı olduğunu gösterir mi? Önce tahmin edin, sonra çalıştırın. | sıfır uyarı | Alıştırma 6.16 | — | `#h06-alistirmalar` |
| `kavram/H06_K01_alt_sinir.c` | kavram programı | Karşılaştırmaya dayalı sıralamanın alt sınırı ⌈lg n!⌉ ile n lg n ve birleştirmeli sıralamanın en kötü durumu W(n); n = 10^9 için n² ile n lg n işlem sayısı | sıfır uyarı | çıktı: 1, 3.5, 11.8 | — | çıktı: `#h06-alt-sinir` |
| `kavram/H06_K02_bagintilar.c` | kavram programı | Dört yineleme bağıntısını özyinelemeyle hesaplayıp yerine koyma (açılım) yöntemiyle bulunan kapalı biçimlerle karşılaştırır (n = 2^k; T(1) = 1) | sıfır uyarı | çıktı: 2, 3.2 | çıktı: slayt 9 | çıktı: `#h06-gecen-hafta` |
| `kavram/H06_K03_qsort_gozlem.c` | kavram programı | Bu makinedeki C kitaplığının qsort'u kaç kez karşılaştırıcı çağırıyor ve eşit anahtarların sırasını koruyor mu? (gözlem; C standardı algoritmayı ve kararlılığı belirtmez) | sıfır uyarı | çıktı: 3.6, 8 | — | çıktı: `#h06-kaput` |
| `kavram/H06_K04_pivot_avi.c` | kavram programı | Bir girdinin hızlı sıralamayı ne kadar zorladığını ölçer: Örnek 6'nın Lomuto + küçük parçaya özyineleme sürümü, üç pivot stratejisiyle (ilk / rastgele / üçün ortancası) karşılaştırma sayısı ve n(n-1)/2'ye oranı (1,00 = tam karesel) | sıfır uyarı | çıktı: 9, 11.9 | çıktı: slayt 48 | çıktı: `#h06-muhendis`, `#h06-alistirmalar` |
| `kavram/H06_K05_dilim.py` | kavram programı | Python'da dilim (a[lo:hi]) yeni bir liste kopyalar; ad bağlama (c = a) kopyalamaz. Özyineleme sınırı derinliği sınırlar. | — | çıktı: 8 | — | çıktı: `#h06-dil` |
| `kavram/H06_K06_kutuphane.c` | kavram programı | C'nin tek sıralama aracı qsort: karşılaştırıcı işaretçisiyle çağrılır; algoritması ve kararlılığı standartta belirtilmez. Birleştirme ve seçim için C kitaplığında hazır işlev yoktur. | sıfır uyarı | çıktı: 8 | — | çıktı: `#h06-dil` |
| `kavram/H06_K06_kutuphane.cpp` | kavram programı | Haftanın algoritmalarının C++ kütüphane karşılıkları: std::sort (kararsız), std::stable_sort (kararlı), std::merge, std::nth_element (ortanca, ortalama doğrusal) | sıfır uyarı | çıktı: 8 | — | çıktı: `#h06-dil` |
| `kavram/H06_K06_kutuphane.py` | kavram programı | Haftanın algoritmalarının Python kütüphane karşılıkları: sorted / list.sort (Timsort, kararlı), heapq.merge, statistics.median (sıralayarak), heapq.nsmallest | — | çıktı: 8 | — | çıktı: `#h06-dil` |
| `quiz/H06_Q01_cagri_sayisi.c` | quiz | Birleştirmeli sıralamanın çağrı sayısı: program ne yazdırır? | sıfır uyarı | — | — | `#h06-quiz` |
| `quiz/H06_Q02_lomuto.py` | quiz | Lomuto bölümleme: program ne yazdırır? | — | — | — | `#h06-quiz` |
| `quiz/H06_Q03_dilim.py` | quiz | Dilim kopyası: program ne yazdırır? | — | — | — | `#h06-quiz` |

Arşiv: `AP2_H06_kodlar.zip` bu klasörün tamamını (çıktılar, girdiler, deney verileri, ortak modüller ve `esdeger_test.py` dahil) içerir; açtığınız klasörde `python3 esdeger_test.py .` ile sınayabilirsiniz.

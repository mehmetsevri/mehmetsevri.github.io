"""H06_Q03_dilim.py — AP-2 Hafta 6 · Quiz sorusu (dil farkı)
Amaç    : Dilim kopyası: program ne yazdırır?
Çalıştır: python3 H06_Q03_dilim.py
"""


def ilk_ikiyi_takasla(a):
    b = a[0:2]
    b[0], b[1] = b[1], b[0]


def main():
    x = [3, 1, 2]
    ilk_ikiyi_takasla(x)
    print(x)


if __name__ == "__main__":
    main()

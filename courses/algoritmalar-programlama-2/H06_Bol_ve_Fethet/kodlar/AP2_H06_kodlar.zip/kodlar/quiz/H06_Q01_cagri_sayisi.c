/* H06_Q01_cagri_sayisi.c — AP-2 Hafta 6 · Quiz sorusu (izleme)
 * Amaç    : Birleştirmeli sıralamanın çağrı sayısı: program ne yazdırır?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H06_Q01_cagri_sayisi.c \
 *           -o H06_Q01_cagri_sayisi
 * Çalıştır: ./H06_Q01_cagri_sayisi
 */
#include <stdio.h>

static int cagri = 0;

static void bs(int lo, int hi)
{
    cagri++;
    if (lo >= hi) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    bs(lo, mid);
    bs(mid + 1, hi);
}

int main(void)
{
    bs(0, 9);
    printf("%d\n", cagri);
    return 0;
}

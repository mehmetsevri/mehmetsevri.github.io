"""H06_Q02_lomuto.py — AP-2 Hafta 6 · Quiz sorusu (izleme)
Amaç    : Lomuto bölümleme: program ne yazdırır?
Çalıştır: python3 H06_Q02_lomuto.py
"""


def lomuto(a, lo, hi):
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        if a[j] < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


def main():
    a = [5, 1, 4, 2, 3]
    p = lomuto(a, 0, len(a) - 1)
    print(p, a)


if __name__ == "__main__":
    main()

"""H06_03_ozyineleme_agaci.py — AP-2 Hafta 6 · Örnek 3 (★★)
Amaç    : Özyineleme ağacını izlemek: birleştirmeli sıralamada her düzeyin
          işi (birleştirilen eleman) n'dir, düzey sayısı ⌈lg n⌉ → n lg n.
          Ana teoremin üç durumu: T(n) = a·T(n/b) + n^d düzey işleri.
Çalıştır: python3 H06_03_ozyineleme_agaci.py
Eşleri  : c/H06_03_ozyineleme_agaci.c · cpp/H06_03_ozyineleme_agaci.cpp
Çıktı   : üç dilde aynı (=)
"""

import math

from ortak_rastgele import rastgele_dizi, rastgele_tohum

MAKS_DUZEY = 64

duzey_cagri = [0] * MAKS_DUZEY
duzey_is = [0] * MAKS_DUZEY
duzey_karsilastirma = [0] * MAKS_DUZEY
duzey_en_kucuk = [0] * MAKS_DUZEY
duzey_en_buyuk = [0] * MAKS_DUZEY
duzey_sayisi = 0


def aralik_yaz(a, lo, hi):
    for k in range(lo, hi + 1):
        print(f" {a[k]}", end="")


def girinti(d):
    print("  " * (d - 1), end="")


# Birleştirme; karşılaştırma sayısını döndürür
def birlestir(a, yrd, lo, mid, hi):
    karsilastirma = 0
    i, j, k = lo, mid + 1, lo
    while i <= mid and j <= hi:
        karsilastirma += 1
        if a[i] <= a[j]:
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    while i <= mid:
        yrd[k] = a[i]
        i += 1
        k += 1
    while j <= hi:
        yrd[k] = a[j]
        j += 1
        k += 1
    for k in range(lo, hi + 1):
        a[k] = yrd[k]
    return karsilastirma


# Birleştirmeli sıralama + düzey sayaçları; yaz = True ise ağacı yazar
def bs_izle(a, yrd, lo, hi, d, yaz):
    global duzey_sayisi
    boyut = hi - lo + 1
    if d > duzey_sayisi:
        duzey_sayisi = d
        duzey_en_kucuk[d] = duzey_en_buyuk[d] = boyut
    duzey_cagri[d] += 1
    if boyut < duzey_en_kucuk[d]:
        duzey_en_kucuk[d] = boyut
    if boyut > duzey_en_buyuk[d]:
        duzey_en_buyuk[d] = boyut
    if yaz:
        print(f"{d}  ", end="")
        girinti(d)
        print(f"{'yaprak' if lo == hi else 'böl'} [{lo}..{hi}]", end="")
        aralik_yaz(a, lo, hi)
        print()
    if lo >= hi:
        return
    mid = lo + (hi - lo) // 2
    bs_izle(a, yrd, lo, mid, d + 1, yaz)
    bs_izle(a, yrd, mid + 1, hi, d + 1, yaz)
    k = birlestir(a, yrd, lo, mid, hi)
    duzey_is[d] += boyut               # bu düğümün işi: boyut kadar eleman
    duzey_karsilastirma[d] += k
    if yaz:
        print(f"{d}  ", end="")
        girinti(d)
        print(f"birleştir [{lo}..{hi}] →", end="")
        aralik_yaz(a, lo, hi)
        print(f"  ({k} karşılaştırma)")


def duzeyleri_sifirla():
    global duzey_sayisi
    for d in range(MAKS_DUZEY):
        duzey_cagri[d] = duzey_is[d] = duzey_karsilastirma[d] = 0
    duzey_sayisi = 0


def tavan_log2(n):
    k = 0
    while (1 << k) < n:
        k += 1
    return k


def duzey_tablosu(a, yaz):
    n = len(a)
    yrd = [0] * n
    duzeyleri_sifirla()
    bs_izle(a, yrd, 0, n - 1, 1, yaz)
    print(f"n = {n}\ndüzey  düğüm   boyut      iş  karşılaştırma")
    is_top = k_top = 0
    for d in range(1, duzey_sayisi + 1):
        boyut = str(duzey_en_kucuk[d])
        if duzey_en_kucuk[d] != duzey_en_buyuk[d]:
            boyut += f"-{duzey_en_buyuk[d]}"
        print(f"{d:5d} {duzey_cagri[d]:6d} {boyut:>7} {duzey_is[d]:7d} "
              f"{duzey_karsilastirma[d]:14d}")
        is_top += duzey_is[d]
        k_top += duzey_karsilastirma[d]
    k = tavan_log2(n)
    print(f"toplam iş = {is_top} · n·⌈lg n⌉ = {n}·{k} = {n * k} · "
          f"karşılaştırma = {k_top}\n")


# T(n) = a·T(n/b) + n^d, T(1) = 1: her düğüm kendi düzeyine n^d ekler
def us(x, d):
    s = 1
    for _ in range(d):
        s *= x
    return s


def yineleme(n, a, b, d, duzey):
    global duzey_sayisi
    if duzey > duzey_sayisi:
        duzey_sayisi = duzey
    duzey_is[duzey] += us(n, d)
    if n <= 1:
        return
    for _ in range(a):
        yineleme(n // b, a, b, d, duzey + 1)


def ana_teorem(n, a, b, d):
    duzeyleri_sifirla()
    yineleme(n, a, b, d, 1)
    bd, toplam = us(b, d), 0
    logba = math.log(a) / math.log(b)
    print(f"a={a} b={b} d={d}: ", end="")
    if a < bd:
        print(f"a < b^d ({a} < {bd}) → kök baskın: Θ(n^d) = Θ(n^{d})")
    elif a == bd:
        print(f"a = b^d ({a} = {bd}) → düzeyler eşit: Θ(n^{d} log n)")
    else:
        print(f"a > b^d ({a} > {bd}) → yapraklar baskın: Θ(n^log_b a) = "
              f"Θ(n^{logba:.3f})")
    print("  düzey işleri:", end="")
    for k in range(1, duzey_sayisi + 1):
        print(f" {duzey_is[k]}", end="")
        toplam += duzey_is[k]
    nd = float(n)
    f = (math.pow(nd, d) if a < bd
         else (math.pow(nd, d) * math.log2(nd) if a == bd
               else math.pow(nd, logba)))
    print(f"\n  toplam T({n}) = {toplam} · T(n) / f(n) = {toplam / f:.3f}")


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    print("Özyineleme ağacı: birleştirmeli sıralama, n = 8")
    print("d  olay")
    duzey_tablosu(a, True)

    rastgele_tohum(42)
    x = rastgele_dizi(1024, 0, 999999)
    duzey_tablosu(x, False)
    rastgele_tohum(42)
    x = rastgele_dizi(1000, 0, 999999)
    duzey_tablosu(x, False)
    print("Her düzeyde birleştirilen toplam eleman n'dir (son düzey eksik\n"
          "kalabilir); düzey sayısı ⌈lg n⌉ + 1, iş yapan düzey ⌈lg n⌉:\n"
          "T(n) = 2T(n/2) + n → Θ(n log n).\n")

    print("Ana teorem: T(n) = a·T(n/b) + n^d, T(1) = 1, n = 256")
    print("(düzey işleri kökten yapraklara; f(n) = Θ içindeki terim)")
    ana_teorem(256, 2, 2, 1)
    ana_teorem(256, 1, 2, 0)
    ana_teorem(256, 4, 2, 1)
    ana_teorem(256, 2, 2, 2)
    ana_teorem(256, 3, 2, 1)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (izleme ve sayma programı).

"""H06_04_lomuto_hizli.py — AP-2 Hafta 6 · Örnek 4 (★★)
Amaç    : Lomuto bölümleme (pivot = a[hi]) ve hızlı sıralama. Değişmez:
          a[lo..i] < pivot <= a[i+1..j-1]; a[j..hi-1] işlenmemiş.
          Rastgele girdide karşılaştırma ≈ 2(n+1)H(n) - 4n ≈ 1,39 n lg n.
Çalıştır: python3 H06_04_lomuto_hizli.py
Eşleri  : c/H06_04_lomuto_hizli.c · cpp/H06_04_lomuto_hizli.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

karsilastirma = takas_sayisi = 0
en_derin = 0


def takas(a, i, j):
    global takas_sayisi
    a[i], a[j] = a[j], a[i]
    takas_sayisi += 1


# Pivot a[hi]; değişmez: a[lo..i] < pivot <= a[i+1..j-1]
def lomuto_bolumle(a, lo, hi):
    global karsilastirma
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        karsilastirma += 1
        if a[j] < pivot:
            i += 1
            takas(a, i, j)
    takas(a, i + 1, hi)  # pivot son yerine
    return i + 1


# d: özyineleme derinliği (kök = 1)
def hizli_sirala(a, lo, hi, d):
    global en_derin
    if d > en_derin:
        en_derin = d
    if lo >= hi:
        return
    p = lomuto_bolumle(a, lo, hi)
    hizli_sirala(a, lo, p - 1, d + 1)
    hizli_sirala(a, p + 1, hi, d + 1)


def dizi_yaz(a, n):
    print("".join(f" {a[k]}" for k in range(n)))


# Bölümlemenin adım adım izlenmesi (aynı algoritma + çıktı)
def lomuto_izle(a, lo, hi):
    pivot = a[hi]
    i = lo - 1
    print(" j  a[j]  karar           i  dizi")
    for j in range(lo, hi):
        kucuk = a[j] < pivot
        deger = a[j]
        if kucuk:
            i += 1
            a[i], a[j] = a[j], a[i]
        print(f"{j:2d} {deger:5d}  "
              f"{'< pivot, takas ' if kucuk else '>= pivot       '} {i:2d} ",
              end="")
        dizi_yaz(a, hi + 1)
    a[i + 1], a[hi] = a[hi], a[i + 1]
    print(f"son takas a[{i + 1}] <-> a[{hi}]: p = {i + 1}    ", end="")
    dizi_yaz(a, hi + 1)


# a'yı hızlı sıralamayla sıralar; kâhinle (sorted) aynıysa True
def sinama(a):
    global karsilastirma, takas_sayisi, en_derin
    kahin = sorted(a)                                         # kâhin
    karsilastirma = takas_sayisi = 0
    en_derin = 0
    hizli_sirala(a, 0, len(a) - 1, 1)
    return a == kahin


def main():
    global karsilastirma, takas_sayisi
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    b = a[:]
    print(f"Lomuto bölümleme (pivot = a[hi] = {a[7]}); değişmez:\n"
          "a[lo..i] < pivot <= a[i+1..j-1], a[j..hi-1] işlenmemiş")
    print("başta: i = -1, dizi:", end="")
    dizi_yaz(a, 8)
    lomuto_izle(a, 0, 7)
    karsilastirma = takas_sayisi = 0
    p = lomuto_bolumle(b, 0, 7)
    print(f"lomuto_bolumle: p = {p} · karşılaştırma = {karsilastirma} · "
          f"takas = {takas_sayisi}\n")

    c = [6, 3, 8, 1, 7, 2, 5, 4]
    sinama(c)
    print("Hızlı sıralama:", end="")
    dizi_yaz(c, 8)
    print(f"karşılaştırma = {karsilastirma} · takas = {takas_sayisi} · "
          f"en büyük derinlik = {en_derin}\n")

    boyutlar = [10, 100, 1000, 10000, 100000]
    print("Rastgele girdi (tohum 42, 0..10^9); beklenen = 2(n+1)H(n) - 4n")
    print("     n  karşılaştırma    beklenen  oran   takas  derinlik"
          "  kâhin")
    for n in boyutlar:
        rastgele_tohum(42)
        x = rastgele_dizi(n, 0, 1000000000)
        ayni = sinama(x)
        h = 0.0
        for k in range(1, n + 1):
            h += 1.0 / k
        beklenen = 2.0 * (n + 1) * h - 4.0 * n
        print(f"{n:6d} {karsilastirma:14d} {beklenen:11.0f} "
              f"{karsilastirma / beklenen:5.3f} {takas_sayisi:7d} "
              f"{en_derin:9d}  " + ("aynı" if ayni else "FARKLI"))

    print("\nEn kötü durum: sıralı ve ters sıralı girdi (n = 500)")
    print("girdi    karşılaştırma  n(n-1)/2  derinlik  kâhin")
    for tur in range(2):
        x = [k if tur == 0 else 500 - k for k in range(500)]
        ayni = sinama(x)
        print(f"{'sıralı' if tur == 0 else 'ters  '} {karsilastirma:14d} "
              f"{500 * 499 // 2:9d} {en_derin:9d}  "
              + ("aynı" if ayni else "FARKLI"))
    print("Pivot hep en büyük/en küçük olunca bölünme n-1 | 0 olur:\n"
          "T(n) = T(n-1) + n - 1 → Θ(n²), özyineleme derinliği n.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort (algoritma belirtilmez); C++ — std::sort
# (introsort; kararsız), std::partition (bölümleme); Python — list.sort /
# sorted (Timsort; hızlı sıralama değildir)

"""H06_01_birlestirme.py — AP-2 Hafta 6 · Örnek 1 (★)
Amaç    : İki sıralı dizinin doğrusal zamanda birleştirilmesi; değişmez:
          c[0..k-1] sıralıdır ve a[0..i-1] ile b[0..j-1]'in tamamıdır.
          Eşitlikte soldan almak (<=) birleştirmeyi kararlı yapar.
Çalıştır: python3 H06_01_birlestirme.py
Eşleri  : c/H06_01_birlestirme.c · cpp/H06_01_birlestirme.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_tohum

karsilastirma = 0


# a ve b sıralı; c, ikisinin sıralı birleşimi olur (len(c) = na + nb)
def birlestir(a, b, c):
    global karsilastirma
    i, j, k, na, nb = 0, 0, 0, len(a), len(b)
    while i < na and j < nb:
        karsilastirma += 1
        if a[i] <= b[j]:  # eşitse soldan
            c[k] = a[i]
            i += 1
        else:
            c[k] = b[j]
            j += 1
        k += 1
    while i < na:  # sol dizinin kalanı
        c[k] = a[i]
        i += 1
        k += 1
    while j < nb:  # sağ dizinin kalanı
        c[k] = b[j]
        j += 1
        k += 1


def dizi_yaz(ad, a):
    print(f"{ad} = [" + ", ".join(str(x) for x in a) + "]")


# Aynı algoritma; her adımda i, j ve karşılaştırmayı yazar
def birlestir_izleyerek(a, b, c):
    i, j, k, na, nb = 0, 0, 0, len(a), len(b)
    print("adım  i  j  karşılaştırma          alınan")
    while i < na and j < nb:
        soldan = a[i] <= b[j]
        print(f"{k + 1:4d} {i:2d} {j:2d}  a[{i}]={a[i]}"
              f"{' <= ' if soldan else ' >  '}b[{j}]={b[j]}", end="")
        if soldan:
            print(f"   a'dan {a[i]}"
                  + ("  (eşitlik: soldan)" if a[i] == b[j] else ""))
            c[k] = a[i]
            i += 1
        else:
            print(f"   b'den {b[j]}")
            c[k] = b[j]
            j += 1
        k += 1
    print(f"kalan: {'sol dizi' if i < na else 'sağ dizi'}; "
          f"kopyalanan {(na - i) + (nb - j)} eleman")
    while i < na:
        c[k] = a[i]
        i += 1
        k += 1
    while j < nb:
        c[k] = b[j]
        j += 1
        k += 1


# Kararlılık gösterimi: kayıtlar (puan, ad) yalnızca puana göre birleştirilir
def birlestir_kayit(a, b, c):
    i, j, k, na, nb = 0, 0, 0, len(a), len(b)
    while i < na and j < nb:
        if a[i][0] <= b[j][0]:
            c[k] = a[i]
            i += 1
        else:
            c[k] = b[j]
            j += 1
        k += 1
    while i < na:
        c[k] = a[i]
        i += 1
        k += 1
    while j < nb:
        c[k] = b[j]
        j += 1
        k += 1


# Artan sıralı (yinelemeli değerli) rastgele dizi: a[i] = a[i-1] + 0..3
def sirali_uret(n):
    a = [0] * n
    x = rastgele_aralik(0, 5)
    for i in range(n):
        x += rastgele_aralik(0, 3)
        a[i] = x
    return a


def main():
    global karsilastirma
    a = [2, 5, 7, 9]
    b = [1, 5, 6, 10, 12]
    c = [0] * 9
    print("İki sıralı dizinin birleştirilmesi")
    dizi_yaz("a", a)
    dizi_yaz("b", b)
    birlestir_izleyerek(a, b, c)
    dizi_yaz("c", c)
    birlestir(a, b, c)
    print(f"karşılaştırma = {karsilastirma} "
          f"(en çok na + nb - 1 = {4 + 5 - 1})\n")

    sol = [(55, "Ali"), (70, "Can"), (70, "Ece"), (85, "Naz")]
    sag = [(60, "Bora"), (70, "Deniz"), (90, "Ufuk")]
    k = [None] * 7
    birlestir_kayit(sol, sag, k)
    print("Kararlılık: puanı 70 olanlar (sol: Can, Ece; sağ: Deniz)")
    print(", ".join(f"{puan} {ad}" for puan, ad in k))
    print("<= ile eşit puanlılar özgün sırayı korur (soldakiler önce)\n")

    boyutlar = [(0, 0), (0, 3), (4, 0), (1, 1), (5, 5), (100, 37),
                (1000, 1000), (50000, 70000)]
    rastgele_tohum(42)
    print("Rastgele sıralı diziler (tohum 42) ve kâhin "
          "(kütüphane sıralaması)")
    print("    na     nb  karşılaştırma  alt   üst      kâhin")
    for na, nb in boyutlar:
        n = na + nb
        x = sirali_uret(na)
        y = sirali_uret(nb)
        z = [0] * n
        karsilastirma = 0
        birlestir(x, y, z)
        d = sorted(x + y)                               # yalnızca kâhin
        ayni = z == d
        alt = min(na, nb)
        ust = n - 1 if (na and nb) else 0
        print(f"{na:6d} {nb:6d} {karsilastirma:14d} {alt:5d} {ust:6d}  "
              + ("aynı" if ayni else "FARKLI"))
    print("min(na, nb) <= karşılaştırma <= na + nb - 1: iş Θ(na + nb)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::merge (kararlı);
# Python — heapq.merge(a, b) (yineleyici; kararlı)

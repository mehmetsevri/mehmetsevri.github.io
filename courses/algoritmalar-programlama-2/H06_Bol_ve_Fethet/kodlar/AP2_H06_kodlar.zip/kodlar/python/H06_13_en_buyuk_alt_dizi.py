"""H06_13_en_buyuk_alt_dizi.py — AP-2 Hafta 6 · Örnek 13 (★★★)
Amaç    : En büyük alt dizi toplamı böl ve fethet ile: en iyi alt dizi ya
          solda, ya sağda ya da ortayı keser. T(n) = 2T(n/2) + Θ(n) →
          Θ(n log n). H2'nin Θ(n) Kadane'siyle aynı toplam; sayaç:
          toplama sayısı. Sözleşme (H2): alt dizi boş olamaz.
Çalıştır: python3 H06_13_en_buyuk_alt_dizi.py
Eşleri  : c/H06_13_en_buyuk_alt_dizi.c · cpp/H06_13_en_buyuk_alt_dizi.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

toplama = 0
en_derin = 0


# Ortayı kesen en iyi alt dizi: a[i..mid] + a[mid+1..j]; (toplam, bas, son)
def kesisen(a, lo, mid, hi):
    global toplama
    toplam = sol_en = a[mid]
    bas = mid
    for i in range(mid - 1, lo - 1, -1):  # sola
        toplam += a[i]
        toplama += 1
        if toplam > sol_en:
            sol_en = toplam
            bas = i
    toplam = a[mid + 1]
    sag_en = a[mid + 1]
    son = mid + 1
    for j in range(mid + 2, hi + 1):  # sağa
        toplam += a[j]
        toplama += 1
        if toplam > sag_en:
            sag_en = toplam
            son = j
    toplama += 1  # sol_en + sag_en
    return (sol_en + sag_en, bas, son)


# a[lo..hi]'nin en büyük alt dizisi; eşitlikte sol, kesişen, sağ sırası
def en_buyuk_bf(a, lo, hi, d):
    global en_derin
    if d > en_derin:
        en_derin = d
    if lo == hi:
        return (a[lo], lo, lo)
    mid = lo + (hi - lo) // 2
    sol = en_buyuk_bf(a, lo, mid, d + 1)
    sag = en_buyuk_bf(a, mid + 1, hi, d + 1)
    orta = kesisen(a, lo, mid, hi)
    en = sol  # eşitlikte sol, kesişen, sağ
    if orta[0] > en[0]:
        en = orta
    if sag[0] > en[0]:
        en = sag
    return en


# H2 Örnek 13'teki Kadane (Θ(n)): a[i]'de biten en iyi toplam
def kadane(a, n):
    global toplama
    s_toplam, s_bas_en, s_son = a[0], 0, 0
    simdiki = a[0]
    s_bas = 0
    for i in range(1, n):
        uzat = simdiki + a[i]
        toplama += 1
        if uzat < a[i]:
            simdiki = a[i]
            s_bas = i
        else:
            simdiki = uzat
        if simdiki > s_toplam:
            s_toplam, s_bas_en, s_son = simdiki, s_bas, i
    return (s_toplam, s_bas_en, s_son)


def dizi_coz(ad, a):
    global toplama, en_derin
    n = len(a)
    toplama = 0
    en_derin = 0
    b = en_buyuk_bf(a, 0, n - 1, 1)
    tb = toplama
    toplama = 0
    k = kadane(a, n)
    print(f"{ad} (n={n}): böl-fethet {b[0]} [{b[1]}..{b[2]}] · Kadane "
          f"{k[0]} [{k[1]}..{k[2]}] · toplama {tb} / {toplama}")


def main():
    global toplama, en_derin
    bentley = [31, -41, 59, 26, -53, 58, 97, -93, -23, 84]
    negatif = [-3, -1, -2]
    tek = [5]
    sifir = [0, -1, 0]
    klasik = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
    boyutlar = [10, 100, 1000, 1024, 10000, 100000]

    print("En büyük alt dizi: böl ve fethet ↔ Kadane (H2)")
    dizi_coz("Bentley", bentley)
    dizi_coz("Tümü negatif", negatif)
    dizi_coz("Tek eleman", tek)
    dizi_coz("Sıfırlar", sifir)
    dizi_coz("Klasik", klasik)

    rastgele_tohum(42)
    a = rastgele_dizi(100000, -100, 100)        # H2 ile aynı veri
    print("\nRastgele a[i] -100..100 (tohum 42, H2 ile aynı); toplama "
          "sayıları\nW(n) = n⌈lg n⌉ - 2^⌈lg n⌉ + 1 (düğüm başına boy - 1; "
          "Örnek 2'deki sınır)")
    print("     n  en büyük  böl-fethet        W(n)  Kadane  oran  "
          "derinlik  aynı")
    for n in boyutlar:
        toplama = 0
        en_derin = 0
        b = en_buyuk_bf(a, 0, n - 1, 1)
        tb = toplama
        toplama = 0
        k = kadane(a, n)
        lg = 0
        while (1 << lg) < n:
            lg += 1
        w = n * lg - (1 << lg) + 1
        print(f"{n:6d} {b[0]:9d} {tb:11d} {w:11d} {toplama:7d} "
              f"{tb / toplama:5.1f} {en_derin:9d}  "
              + ("evet" if b[0] == k[0] else "HAYIR"))
    print("Aynı problem, iki strateji: böl ve fethet Θ(n log n) toplama ve\n"
          "O(log n) yığın; Kadane Θ(n) toplama ve O(1) bellek.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok; Python — yok
# (itertools.accumulate önek toplamı verir, en büyük alt diziyi vermez)

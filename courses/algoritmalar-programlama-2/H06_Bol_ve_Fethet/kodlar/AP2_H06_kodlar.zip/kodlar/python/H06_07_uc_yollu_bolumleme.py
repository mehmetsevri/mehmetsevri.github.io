"""H06_07_uc_yollu_bolumleme.py — AP-2 Hafta 6 · Örnek 7 (★★★)
Amaç    : Üç yollu bölümleme (Dijkstra'nın Hollanda bayrağı problemi):
          a[lo..lt-1] < p, a[lt..i-1] = p, a[i..gt] işlenmemiş,
          a[gt+1..hi] > p. Çok tekrar eden anahtarlarda iki yollu
          (Lomuto) hızlı sıralama Θ(n²)'ye düşer; üç yollu düşmez.
Çalıştır: python3 H06_07_uc_yollu_bolumleme.py
Eşleri  : c/H06_07_uc_yollu_bolumleme.c · cpp/H06_07_uc_yollu_bolumleme.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum

karsilastirma = takas_sayisi = 0
en_derin = agac_yuksekligi = 0


def takas(a, i, j):
    global takas_sayisi
    a[i], a[j] = a[j], a[i]
    takas_sayisi += 1


# p değerine göre üç bölge; dönüş (lt, gt): eşitler bölgesi a[lt..gt]
def uc_yollu_bolumle(a, lo, hi, p):
    global karsilastirma
    lt, i, gt = lo, lo, hi
    while i <= gt:
        karsilastirma += 1
        if a[i] < p:  # küçük: sola
            takas(a, lt, i)
            lt += 1
            i += 1
        else:
            karsilastirma += 1
            if a[i] > p:  # büyük: sağa
                takas(a, i, gt)
                gt -= 1
            else:  # eşit: yerinde kalır
                i += 1
    return lt, gt


# Üç yollu hızlı sıralama; pivot rastgele bir elemanın değeri
def hizli_uc_yollu(a, lo, hi, d):
    global en_derin
    if d > en_derin:
        en_derin = d
    if lo >= hi:
        return
    p = a[rastgele_aralik(lo, hi)]
    lt, gt = uc_yollu_bolumle(a, lo, hi, p)
    # a[lt..gt] = p: eşitler bir daha işlenmez
    hizli_uc_yollu(a, lo, lt - 1, d + 1)
    hizli_uc_yollu(a, gt + 1, hi, d + 1)


# Karşılaştırma için iki yollu: rastgele pivot + Lomuto (a[j] < pivot);
# yığın güvenliği için küçük parçaya özyineleme (Örnek 6)
def lomuto_bolumle(a, lo, hi):
    global karsilastirma
    takas(a, rastgele_aralik(lo, hi), hi)
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        karsilastirma += 1
        if a[j] < pivot:
            i += 1
            takas(a, i, j)
    takas(a, i + 1, hi)
    return i + 1


def hizli_iki_yollu(a, lo, hi, d, t):
    global en_derin, agac_yuksekligi
    if d > en_derin:
        en_derin = d
    while True:
        if t > agac_yuksekligi:
            agac_yuksekligi = t
        if lo >= hi:
            return
        p = lomuto_bolumle(a, lo, hi)
        if p - lo < hi - p:
            hizli_iki_yollu(a, lo, p - 1, d + 1, t + 1)
            lo = p + 1
        else:
            hizli_iki_yollu(a, p + 1, hi, d + 1, t + 1)
            hi = p - 1
        t += 1


def dizi_yaz(a):
    print("".join(f" {x}" for x in a))


# Hollanda bayrağı izlemesi (aynı algoritma + çıktı)
def bayrak_izle(a, p):
    n = len(a)
    lt, i, gt, adim = 0, 0, n - 1, 0
    print("adım lt  i gt  a[i]  işlem")
    while i <= gt:
        adim += 1
        print(f"{adim:4d} {lt:2d} {i:2d} {gt:2d} {a[i]:5d}  ", end="")
        if a[i] < p:
            print(f"< p: a[{lt}] <-> a[{i}], lt++, i++  :", end="")
            a[lt], a[i] = a[i], a[lt]
            lt += 1
            i += 1
        elif a[i] > p:
            print(f"> p: a[{i}] <-> a[{gt}], gt--       :", end="")
            a[i], a[gt] = a[gt], a[i]
            gt -= 1
        else:
            print("= p: i++                       :", end="")
            i += 1
        dizi_yaz(a)
    print(f"son: lt = {lt}, gt = {gt} → a[0..{lt - 1}] < p, a[{lt}..{gt}] "
          f"= p, a[{gt + 1}..{n - 1}] > p")


def sirali_mi(a):
    for k in range(1, len(a)):
        if a[k - 1] > a[k]:
            return False
    return True


def main():
    global karsilastirma, takas_sayisi, en_derin, agac_yuksekligi
    bayrak = [2, 0, 1, 2, 1, 0, 0, 2, 1, 0]
    b = bayrak[:]
    print("Hollanda bayrağı (Dijkstra): 0 = kırmızı, 1 = beyaz, 2 = mavi; "
          "p = 1")
    print("başta:", end="")
    dizi_yaz(bayrak)
    bayrak_izle(bayrak, 1)
    uc_yollu_bolumle(b, 0, 9, 1)
    print(f"uc_yollu_bolumle: tek geçiş · karşılaştırma = {karsilastirma} · "
          f"takas = {takas_sayisi}\n")

    adlar = ["rastgele 0..10^9", "az farklı 0..9  ", "ikili 0..1      ",
             "tümü eşit (7)   "]
    altlar = [0, 0, 0, 7]
    ustler = [1000000000, 9, 1, 7]
    n = 2000
    print(f"Hızlı sıralama, n = {n}, rastgele pivot (iki yollu: Lomuto)")
    print("girdi              yöntem      karşılaştırma   takas  ağaç  doğru")
    for t in range(4):
        rastgele_tohum(42)
        g = rastgele_dizi(n, altlar[t], ustler[t])
        for y in range(2):
            x = g[:]
            karsilastirma = takas_sayisi = 0
            en_derin = agac_yuksekligi = 0
            rastgele_tohum(2026)
            if y == 0:
                hizli_iki_yollu(x, 0, n - 1, 1, 1)
            else:
                hizli_uc_yollu(x, 0, n - 1, 1)
                agac_yuksekligi = en_derin
            print(f"{adlar[t]}   {'iki yollu' if y == 0 else 'üç yollu '} "
                  f"{karsilastirma:14d} {takas_sayisi:7d} "
                  f"{agac_yuksekligi:5d}  "
                  + ("evet" if sirali_mi(x) else "HAYIR"))
    print("İki yollu bölümlemede pivota eşit elemanlar hep aynı tarafa "
          "gider:\nk farklı anahtarda her eşit grup kendi içinde karesel "
          "sıralanır.\nÜç yollu bölümleme eşitleri tek geçişte ortaya "
          "toplar ve bir daha\nişlemez: k farklı anahtar için beklenen "
          "iş O(n log k).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::partition iki kez (ya da
# std::sort); Python — yok. Bentley ve McIlroy (1993) qsort'u eşitleri
# ayrı toplayan bölümleme kullanır.

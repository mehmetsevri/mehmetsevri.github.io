"""H06_05_hoare_bolumleme.py — AP-2 Hafta 6 · Örnek 5 (★★)
Amaç    : Hoare bölümleme (pivot x = a[lo]; i soldan, j sağdan ilerler)
          ve Lomuto ile karşılaştırma/takas sayısı. Dönüş j pivotun son
          yeri DEĞİLDİR: a[lo..j] <= x <= a[j+1..hi] demektir.
Çalıştır: python3 H06_05_hoare_bolumleme.py
Eşleri  : c/H06_05_hoare_bolumleme.c · cpp/H06_05_hoare_bolumleme.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

karsilastirma = takas_sayisi = 0
en_derin = 0


def takas(a, i, j):
    global takas_sayisi
    a[i], a[j] = a[j], a[i]
    takas_sayisi += 1


# Pivot x = a[lo]; dönüş j: a[lo..j] <= x <= a[j+1..hi], lo <= j < hi
def hoare_bolumle(a, lo, hi):
    global karsilastirma
    x = a[lo]
    i, j = lo - 1, hi + 1
    while True:
        j -= 1  # sağdan: x'ten büyük olmayanı bul
        karsilastirma += 1
        while a[j] > x:  # (Python'da do-while yok)
            j -= 1
            karsilastirma += 1
        i += 1  # soldan: x'ten küçük olmayanı bul
        karsilastirma += 1
        while a[i] < x:
            i += 1
            karsilastirma += 1
        if i >= j:
            return j
        takas(a, i, j)


def hizli_hoare(a, lo, hi, d):
    global en_derin
    if d > en_derin:
        en_derin = d
    if lo >= hi:
        return
    p = hoare_bolumle(a, lo, hi)
    hizli_hoare(a, lo, p, d + 1)  # p dahil
    hizli_hoare(a, p + 1, hi, d + 1)


# Karşılaştırma için Örnek 4'ün Lomuto bölümlemesi (pivot a[hi])
def lomuto_bolumle(a, lo, hi):
    global karsilastirma
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        karsilastirma += 1
        if a[j] < pivot:
            i += 1
            takas(a, i, j)
    takas(a, i + 1, hi)
    return i + 1


def hizli_lomuto(a, lo, hi, d):
    global en_derin
    if d > en_derin:
        en_derin = d
    if lo >= hi:
        return
    p = lomuto_bolumle(a, lo, hi)
    hizli_lomuto(a, lo, p - 1, d + 1)
    hizli_lomuto(a, p + 1, hi, d + 1)


def dizi_yaz(a, n):
    print("".join(f" {a[k]}" for k in range(n)))


# Hoare bölümlemesinin izlenmesi (aynı algoritma + çıktı)
def hoare_izle(a, lo, hi):
    x = a[lo]
    i, j = lo - 1, hi + 1
    print("tur  i  j  işlem")
    tur = 1
    while True:
        j -= 1
        while a[j] > x:
            j -= 1
        i += 1
        while a[i] < x:
            i += 1
        print(f"{tur:3d} {i:2d} {j:2d}  ", end="")
        if i >= j:
            print(f"i >= j → dönüş j = {j}")
            return
        a[i], a[j] = a[j], a[i]
        print(f"takas a[{i}] <-> a[{j}]:", end="")
        dizi_yaz(a, hi + 1)
        tur += 1


def sirali_mi(a):
    for k in range(1, len(a)):
        if a[k - 1] > a[k]:
            return False
    return True


# yontem 0: Lomuto, 1: Hoare; sayaçları sıfırlayıp a'nın kopyasını sıralar
def sirala_say(a, yontem):
    global karsilastirma, takas_sayisi, en_derin
    b = a[:]
    n = len(b)
    karsilastirma = takas_sayisi = 0
    en_derin = 0
    if yontem == 0:
        hizli_lomuto(b, 0, n - 1, 1)
    else:
        hizli_hoare(b, 0, n - 1, 1)
    return sirali_mi(b)


def main():
    global karsilastirma, takas_sayisi
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    b = a[:]
    print(f"Hoare bölümleme (pivot x = a[lo] = {a[0]}; i soldan, j sağdan)")
    print("başta:", end="")
    dizi_yaz(a, 8)
    hoare_izle(a, 0, 7)
    karsilastirma = takas_sayisi = 0
    x0 = b[0]
    p = hoare_bolumle(b, 0, 7)
    yer = 0
    while b[yer] != x0:
        yer += 1
    print(f"sonuç: a[0..{p}] <= {x0} <= a[{p + 1}..7]; pivot {x0} şimdi "
          f"a[{yer}]'de, a[{p}]'te değil")
    print(f"Hoare: karşılaştırma = {karsilastirma} · takas = {takas_sayisi}")
    c = [6, 3, 8, 1, 7, 2, 5, 4]
    karsilastirma = takas_sayisi = 0
    lomuto_bolumle(c, 0, 7)
    print(f"Lomuto (aynı dizi, pivot a[hi] = 4): karşılaştırma = "
          f"{karsilastirma} · takas = {takas_sayisi}\n")

    boyutlar = [100, 1000, 10000, 100000]
    print("Rastgele girdi (tohum 42, 0..10^9): tam hızlı sıralama")
    print("     n   Lomuto karş.  takas   Hoare karş.  takas  takas L/H")
    for n in boyutlar:
        rastgele_tohum(42)
        x = rastgele_dizi(n, 0, 1000000000)
        d1 = sirala_say(x, 0)
        lk, lt = karsilastirma, takas_sayisi
        d2 = sirala_say(x, 1)
        print(f"{n:6d} {lk:14d} {lt:7d} {karsilastirma:13d} "
              f"{takas_sayisi:7d} {lt / takas_sayisi:10.2f}"
              + ("" if d1 and d2 else "  HATA"))

    print("\nÖzel girdiler (n = 500): karşılaştırma / derinlik")
    print("girdi       Lomuto karş.  derinlik   Hoare karş.  derinlik")
    for tur in range(2):
        x = [7 if tur == 0 else k for k in range(500)]
        d1 = sirala_say(x, 0)
        lk = karsilastirma
        ld = en_derin
        d2 = sirala_say(x, 1)
        print(f"{'tümü eşit' if tur == 0 else 'sıralı   '} {lk:14d} "
              f"{ld:9d} {karsilastirma:13d} {en_derin:9d}"
              + ("" if d1 and d2 else "  HATA"))
    print("Tümü eşit girdide Hoare her eşitte durup takas eder ve ortadan "
          "böler;\nLomuto (a[j] < pivot) hiçbir elemanı sola almaz: "
          "Θ(n²). Sıralı girdide\nikisi de (uç pivotla) Θ(n²): çözüm "
          "pivot seçimi (Örnek 6).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::partition (bölümleme; Hoare'a
# benzer iki uçlu tarama), std::sort; Python — yok (list.sort Timsort)

"""H06_09_quickselect.py — AP-2 Hafta 6 · Örnek 9 (★★★)
Amaç    : Quickselect (Hoare'un FIND fikri): k'ıncı en küçük değer ve
          ortanca not. Bölümledikten sonra yalnızca k'nın bulunduğu
          parçada devam edilir: beklenen Θ(n), yinelemeli, O(1) ek
          bellek. Notlarda çok tekrar olduğu için üç yollu bölümleme.
Çalıştır: python3 H06_09_quickselect.py
Eşleri  : c/H06_09_quickselect.c · cpp/H06_09_quickselect.cpp
Çıktı   : üç dilde aynı (=)
"""

import math

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum

karsilastirma = 0
tur_sayisi = 0


# Örnek 7: a[lo..lt-1] < p, a[lt..gt] = p, a[gt+1..hi] > p
def uc_yollu_bolumle(a, lo, hi, p):
    global karsilastirma
    lt, i, gt = lo, lo, hi
    while i <= gt:
        karsilastirma += 1
        if a[i] < p:
            a[lt], a[i] = a[i], a[lt]
            lt += 1
            i += 1
        else:
            karsilastirma += 1
            if a[i] > p:
                a[i], a[gt] = a[gt], a[i]
                gt -= 1
            else:
                i += 1
    return lt, gt


# k'ıncı en küçük (0 tabanlı); a yeniden düzenlenir
def hizli_sec(a, k):
    global tur_sayisi
    lo, hi = 0, len(a) - 1
    while lo < hi:
        tur_sayisi += 1
        p = a[rastgele_aralik(lo, hi)]
        lt, gt = uc_yollu_bolumle(a, lo, hi, p)
        if k < lt:
            hi = lt - 1  # k soldaki parçada
        elif k > gt:
            lo = gt + 1  # k sağdaki parçada
        else:
            return p  # k, a[lt..gt] içinde
    return a[lo]


def dizi_yaz(a):
    print("".join(f" {x}" for x in a))


# Aynı algoritma; her turda aralığı, pivotu ve kararı yazar
def hizli_sec_izle(a, k):
    lo, hi, tur = 0, len(a) - 1, 0
    print("tur  lo  hi  pivot  lt  gt  karar")
    while lo < hi:
        p = a[rastgele_aralik(lo, hi)]
        lt, gt = uc_yollu_bolumle(a, lo, hi, p)
        tur += 1
        print(f"{tur:3d} {lo:3d} {hi:3d} {p:6d} {lt:3d} {gt:3d}  ", end="")
        if k < lt:
            print(f"k = {k} < lt: sola  ", end="")
            hi = lt - 1
        elif k > gt:
            print(f"k = {k} > gt: sağa  ", end="")
            lo = gt + 1
        else:
            print(f"lt <= k <= gt: bulundu = {p}")
            return p
        dizi_yaz(a)
    print(f"lo = hi = {lo}: bulundu = {a[lo]}")
    return a[lo]


def main():
    global karsilastirma, tur_sayisi
    notlar = [72, 45, 88, 61, 95, 53, 77, 61, 84]
    n = len(notlar)
    k = n // 2
    print(f"Ortanca not: n = {n}, k = n / 2 = {k} (0 tabanlı)\nnotlar:",
          end="")
    dizi_yaz(notlar)
    rastgele_tohum(7)
    ortanca = hizli_sec_izle(notlar, k)
    print(f"ortanca = {ortanca}\n")

    boyutlar = [101, 1001, 10001, 100001]
    tekrar = 5                          # farklı pivot dizileriyle
    for tur in range(2):
        ust = 100 if tur == 0 else 1000000000
        print(f"{'Notlar' if tur == 0 else 'Farklı değerler'} (tohum 42, "
              f"0..{'100' if tur == 0 else '10^9'}): {tekrar} çalıştırmanın "
              "ortalaması")
        print("     n     ortanca  ort. karş.  karş./n  ort. tur   lg n  "
              "kâhin")
        for m in boyutlar:
            rastgele_tohum(42)
            x = rastgele_dizi(m, 0, ust)
            y = sorted(x)                                     # kâhin
            karsilastirma = 0
            tur_sayisi = 0
            sonuc, hepsi_dogru = 0, True
            for r in range(tekrar):
                z = x[:]
                rastgele_tohum(2026 + r)
                sonuc = hizli_sec(z, m // 2)
                hepsi_dogru = hepsi_dogru and sonuc == y[m // 2]
            ort = karsilastirma / tekrar
            print(f"{m:6d} {sonuc:11d} {ort:11.0f} {ort / m:8.2f} "
                  f"{tur_sayisi / tekrar:9.1f} {math.log2(m):6.2f}  "
                  + ("aynı" if hepsi_dogru else "FARKLI"))
        print()
    print("n 1000 kat büyürken karş./n artmıyor (lg n ise büyüyor): "
          "beklenen\niş Θ(n). Sıralayıp ortadakini almak Θ(n log n) olurdu."
          "\nEn kötü durumda (pivot hep uçta) Θ(n²).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::nth_element (introselect);
# Python — statistics.median (sıralar: O(n log n)); heapq.nsmallest

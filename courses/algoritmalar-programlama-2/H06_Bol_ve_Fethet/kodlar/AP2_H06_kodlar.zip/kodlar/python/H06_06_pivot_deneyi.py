"""H06_06_pivot_deneyi.py — AP-2 Hafta 6 · Örnek 6 (★★)
Amaç    : Pivot seçimi: ilk eleman / rastgele (ortak LCG) / üçün ortancası
          × sıralı / ters / rastgele girdi → karşılaştırma ve derinlik.
          Küçük parçaya özyineleme + büyük parçada döngü (kuyruk çağrısı
          eleme fikri): kötü pivotta bile yığın derinliği <= lg n + 1.
Çalıştır: python3 H06_06_pivot_deneyi.py   ya da   ... naif N
          (naif N: sıralı girdide ilk eleman pivotlu İKİ çağrılı sürüm;
          derinlik N olur — N ≈ 1000'de RecursionError, bkz. Hata Avcısı)
Eşleri  : c/H06_06_pivot_deneyi.c · cpp/H06_06_pivot_deneyi.cpp
Çıktı   : üç dilde aynı (=)
"""

import math
import sys

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum

ILK, RASTGELE, ORTANCA3 = 0, 1, 2
STRATEJI_AD = ["ilk     ", "rastgele", "ortanca3"]
GIRDI_AD = ["sıralı  ", "ters    ", "rastgele"]

karsilastirma = 0
yigin_derinligi = agac_yuksekligi = 0


def kucuk(x, y):
    global karsilastirma
    karsilastirma += 1
    return x < y


# a[i], a[j], a[k] değerlerinin ortancasının indisi (2-3 karşılaştırma)
def ortanca3(a, i, j, k):
    if kucuk(a[i], a[j]):
        if kucuk(a[j], a[k]):
            return j  # a[i] < a[j] < a[k]
        return k if kucuk(a[i], a[k]) else i
    if kucuk(a[i], a[k]):
        return i  # a[j] <= a[i] < a[k]
    return k if kucuk(a[j], a[k]) else j


def pivot_sec(a, lo, hi, strateji):
    if strateji == ILK:
        return lo
    if strateji == RASTGELE:
        return rastgele_aralik(lo, hi)
    return ortanca3(a, lo, lo + (hi - lo) // 2, hi)


# Seçilen pivot a[hi]'ye taşınır; ardından Örnek 4'ün Lomuto bölümlemesi
def bolumle(a, lo, hi, strateji):
    r = pivot_sec(a, lo, hi, strateji)
    a[r], a[hi] = a[hi], a[r]
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        if kucuk(a[j], pivot):
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


# Küçük parçaya özyineleme, büyük parçada döngü. d: gerçek yığın derinliği;
# t: iki çağrılı (naif) sürümdeki çağrının ağaç derinliği
def hizli_sirala(a, lo, hi, s, d, t):
    global yigin_derinligi, agac_yuksekligi
    if d > yigin_derinligi:
        yigin_derinligi = d
    while True:
        if t > agac_yuksekligi:
            agac_yuksekligi = t
        if lo >= hi:
            return
        p = bolumle(a, lo, hi, s)
        if p - lo < hi - p:  # sol küçük
            hizli_sirala(a, lo, p - 1, s, d + 1, t + 1)
            lo = p + 1  # sağda döngü
        else:
            hizli_sirala(a, p + 1, hi, s, d + 1, t + 1)
            hi = p - 1
        t += 1


# Karşılaştırma için iki çağrılı (naif) sürüm: yığın derinliği = ağaç
def hizli_naif(a, lo, hi, s, d):
    global yigin_derinligi
    if d > yigin_derinligi:
        yigin_derinligi = d
    if lo >= hi:
        return
    p = bolumle(a, lo, hi, s)
    hizli_naif(a, lo, p - 1, s, d + 1)
    hizli_naif(a, p + 1, hi, s, d + 1)


def girdi_uret(n, tur):
    if tur == 2:
        rastgele_tohum(42)
        return rastgele_dizi(n, 0, 1000000000)
    return [k if tur == 0 else n - k for k in range(n)]


def sirali_mi(a):
    for k in range(1, len(a)):
        if a[k - 1] > a[k]:
            return False
    return True


def sayac_sifirla():
    global karsilastirma, yigin_derinligi, agac_yuksekligi
    karsilastirma = 0
    yigin_derinligi = agac_yuksekligi = 0
    rastgele_tohum(2026)                # rastgele pivot dizisi sabit


def naif_kip(arg):
    try:
        n = int(arg)
    except ValueError:
        n = -1
    if n < 1 or n > 10000000:
        print("N 1..10000000 olmalı", file=sys.stderr)
        return 2
    a = girdi_uret(n, 0)
    sayac_sifirla()
    print(f"naif, sıralı girdi, ilk eleman pivotu, n = {n}", flush=True)
    try:
        hizli_naif(a, 0, n - 1, ILK, 1)
    except RecursionError:
        print(f"RecursionError: sys.getrecursionlimit() = "
              f"{sys.getrecursionlimit()} aşıldı (ulaşılan derinlik "
              f"{yigin_derinligi})")
        return 1
    print(f"bitti: karşılaştırma = {karsilastirma} · yığın derinliği = "
          f"{yigin_derinligi}")
    return 0


def main():
    if len(sys.argv) == 3 and sys.argv[1].startswith("n"):
        return naif_kip(sys.argv[2])
    if len(sys.argv) != 1:
        print(f"Kullanım: {sys.argv[0]} [naif N]", file=sys.stderr)
        return 2
    boyutlar = [1000, 2000]
    sonuc = [[[0] * 3 for _ in range(3)] for _ in range(2)]
    print("Pivot deneyi: Lomuto + küçük parçaya özyineleme")
    print("girdi    strateji     n  karşılaştırma  ağaç yük.  yığın  doğru")
    for b in range(2):
        n = boyutlar[b]
        for g in range(3):
            for s in range(3):
                a = girdi_uret(n, g)
                sayac_sifirla()
                hizli_sirala(a, 0, n - 1, s, 1, 1)
                sonuc[b][g][s] = karsilastirma
                print(f"{GIRDI_AD[g]} {STRATEJI_AD[s]} {n:5d} "
                      f"{karsilastirma:14d} {agac_yuksekligi:10d} "
                      f"{yigin_derinligi:6d}  "
                      + ("evet" if sirali_mi(a) else "HAYIR"))
    print("\nOran testi: karşılaştırma(2000) / karşılaştırma(1000)")
    print("(Θ(n²) → 4; Θ(n log n) → 2·lg 2000 / lg 1000 = "
          f"{2.0 * math.log(2000.0) / math.log(1000.0):.2f})")
    for g in range(3):
        print(f"{GIRDI_AD[g]}:", end="")
        for s in range(3):
            print(f"  {STRATEJI_AD[s]} {sonuc[1][g][s] / sonuc[0][g][s]:.2f}",
                  end="")
        print()
    print(f"n(n-1)/2 (n = 2000) = {2000 * 1999 // 2}\n")

    print("Doğrulama: naif (iki çağrılı) sürümün yığın derinliği = döngülü\n"
          "sürümün ağaç yüksekliği (n = 500; deterministik pivotlar)")
    for g in range(3):
        for s in (ILK, ORTANCA3):
            a = girdi_uret(500, g)
            sayac_sifirla()
            hizli_naif(a, 0, 499, s, 1)
            naif_derinlik = yigin_derinligi
            naif_k = karsilastirma
            a = girdi_uret(500, g)
            sayac_sifirla()
            hizli_sirala(a, 0, 499, s, 1, 1)
            print(f"{GIRDI_AD[g]} {STRATEJI_AD[s]} naif yığın = "
                  f"{naif_derinlik:3d} · ağaç yük. = {agac_yuksekligi:3d} · "
                  "karşılaştırma "
                  + ("aynı" if naif_k == karsilastirma else "FARKLI"))
    print("Döngülü sürüm aynı ağacı gezer (aynı karşılaştırmalar), ama\n"
          "büyük parçayı yeni çağrı açmadan işler: yığın <= lg n + 1.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — qsort; C++ — std::sort (introsort: ortanca
# pivot + derinlik sınırı aşılınca öbek sıralaması); Python — list.sort

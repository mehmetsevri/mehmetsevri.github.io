"""H06_10_asagidan_yukari.py — AP-2 Hafta 6 · Örnek 10 (★★★)
Amaç    : Aşağıdan yukarıya (yinelemeli) birleştirmeli sıralama: önce
          1'lik, sonra 2'lik, 4'lük ... komşu blokları birleştir.
          Özyineleme yok; ⌈lg n⌉ geçiş. n = 2^k'da yukarıdan aşağıya
          sürümle aynı birleştirmeleri yapar.
Çalıştır: python3 H06_10_asagidan_yukari.py
Eşleri  : c/H06_10_asagidan_yukari.c · cpp/H06_10_asagidan_yukari.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

karsilastirma = 0
birlestirme_sayisi = 0


# Örnek 2'deki birleştirme: a[lo..mid] + a[mid+1..hi], yrd üzerinden
def birlestir(a, yrd, lo, mid, hi):
    global karsilastirma, birlestirme_sayisi
    i, j, k = lo, mid + 1, lo
    birlestirme_sayisi += 1
    while i <= mid and j <= hi:
        karsilastirma += 1
        if a[i] <= a[j]:
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    while i <= mid:
        yrd[k] = a[i]
        i += 1
        k += 1
    while j <= hi:
        yrd[k] = a[j]
        j += 1
        k += 1
    for k in range(lo, hi + 1):
        a[k] = yrd[k]


def dizi_yaz(a):
    print("".join(f" {x}" for x in a), end="")


# gen: blok genişliği 1, 2, 4, ...; yaz = True ise her geçişi yazar
def asagidan_yukari_sirala(a, yaz):
    n = len(a)
    yrd = [0] * n
    gecis = 0
    gen = 1
    while gen < n:
        onceki = birlestirme_sayisi
        for lo in range(0, n - gen, 2 * gen):
            mid = lo + gen - 1
            hi = min(lo + 2 * gen - 1, n - 1)
            birlestir(a, yrd, lo, mid, hi)
        gecis += 1
        if yaz:
            blok = (n + gen - 1) // gen
            print(f"gen = {gen:2d} :", end="")
            dizi_yaz(a)
            print(f"   ({birlestirme_sayisi - onceki} birleştirme", end="")
            if blok % 2 == 1:
                print(f"; [{(blok - 1) * gen}..{n - 1}] eşsiz", end="")
            print(")")
        gen *= 2
    return gecis


# Karşılaştırma için Örnek 2'nin yukarıdan aşağıya sürümü
def bs_ozyineli(a, yrd, lo, hi):
    if lo >= hi:
        return
    mid = lo + (hi - lo) // 2
    bs_ozyineli(a, yrd, lo, mid)
    bs_ozyineli(a, yrd, mid + 1, hi)
    birlestir(a, yrd, lo, mid, hi)


def tavan_log2(n):
    k = 0
    while (1 << k) < n:
        k += 1
    return k


def sirali_mi(a):
    for k in range(1, len(a)):
        if a[k - 1] > a[k]:
            return False
    return True


def main():
    global karsilastirma
    a = [6, 3, 8, 1, 7, 2, 5, 4, 9, 0]
    print("Aşağıdan yukarıya birleştirmeli sıralama (özyinelemesiz)")
    print("başta    :", end="")
    dizi_yaz(a)
    print()
    gecis = asagidan_yukari_sirala(a, True)
    print(f"geçiş = {gecis} = ⌈lg 10⌉ · karşılaştırma = {karsilastirma} · "
          f"birleştirme = {birlestirme_sayisi}")
    print("Eşi olmayan son blok o geçişte olduğu gibi kalır.\n")

    boyutlar = [8, 10, 1000, 1024, 4096, 100000]
    print("Yukarıdan aşağıya (Örnek 2) ile karşılaştırma (tohum 42)")
    print("     n  aşağıdan yukarı  yukarıdan aşağı  geçiş  ⌈lg n⌉  doğru")
    for n in boyutlar:
        rastgele_tohum(42)
        x = rastgele_dizi(n, 0, 999999)
        y, yrd = x[:], [0] * n
        karsilastirma = 0
        gecis = asagidan_yukari_sirala(x, False)
        ay = karsilastirma
        karsilastirma = 0
        bs_ozyineli(y, yrd, 0, n - 1)
        print(f"{n:6d} {ay:16d} {karsilastirma:16d} {gecis:6d} "
              f"{tavan_log2(n):7d}  "
              + ("evet" if sirali_mi(x) and sirali_mi(y) else "HAYIR"))
    print("n = 2^k olduğunda iki sürüm aynı blokları birleştirir: "
          "karşılaştırmalar\neşittir. Diğer n'lerde bölünme sınırları "
          "farklıdır.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::stable_sort; Python — yok
# (sorted/Timsort hazır sıralı parçaları (run) aşağıdan yukarıya
# birleştirir)

"""H06_08_ters_cevrim.py — AP-2 Hafta 6 · Örnek 8 (★★)
Amaç    : Ters çevrim (i < j ve a[i] > a[j]) sayısı birleştirmeli
          sıralamayla Θ(n log n): sağdan a[j] alınırken soldaki kalan
          mid - i + 1 elemanın hepsi a[j]'den büyüktür. Kâhin: H5'teki
          Θ(n²) çift taraması.
Çalıştır: python3 H06_08_ters_cevrim.py
Eşleri  : c/H06_08_ters_cevrim.c · cpp/H06_08_ters_cevrim.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

karsilastirma = karsilastirma_kaba = 0


# Birleştirirken ters çevrimleri sayar: a[lo..mid], a[mid+1..hi] sıralı
def birlestir_say(a, yrd, lo, mid, hi):
    global karsilastirma
    sayi = 0
    i, j, k = lo, mid + 1, lo
    while i <= mid and j <= hi:
        karsilastirma += 1
        if a[i] <= a[j]:  # eşitse sayılmaz
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
            sayi += mid - i + 1  # hepsi > a[j]
        k += 1
    while i <= mid:
        yrd[k] = a[i]
        i += 1
        k += 1
    while j <= hi:
        yrd[k] = a[j]
        j += 1
        k += 1
    for k in range(lo, hi + 1):
        a[k] = yrd[k]
    return sayi


# a[lo..hi] içindeki ters çevrim sayısı; a sıralanmış olarak kalır
def ters_cevrim_bs(a, yrd, lo, hi):
    if lo >= hi:
        return 0
    mid = lo + (hi - lo) // 2
    sol = ters_cevrim_bs(a, yrd, lo, mid)
    sag = ters_cevrim_bs(a, yrd, mid + 1, hi)
    return sol + sag + birlestir_say(a, yrd, lo, mid, hi)


# Girdiyi bozmamak için kopya üzerinde sayar
def ters_cevrim_say(a):
    b = a[:]
    yrd = [0] * len(a)
    return ters_cevrim_bs(b, yrd, 0, len(a) - 1)


# Kâhin (H5): tüm i < j çiftleri, n(n-1)/2 karşılaştırma
def ters_cevrim_kaba(a):
    global karsilastirma_kaba
    sayi = 0
    n = len(a)
    for i in range(n):
        for j in range(i + 1, n):
            karsilastirma_kaba += 1
            if a[i] > a[j]:
                sayi += 1
    return sayi


def ciftleri_yaz(a):
    sayi, n = 0, len(a)
    print("çiftler:", end="")
    for i in range(n):
        for j in range(i + 1, n):
            if a[i] > a[j]:
                if sayi > 0 and sayi % 8 == 0:
                    print("\n        ", end="")
                print(f" ({a[i]},{a[j]})", end="")
                sayi += 1
    print()


def main():
    global karsilastirma, karsilastirma_kaba
    k1 = [2, 4, 1, 3, 5]
    k2 = [6, 3, 8, 1, 7, 2, 5, 4]
    print("Ters çevrim: i < j ve a[i] > a[j]")
    print(f"[2, 4, 1, 3, 5]: birleştirmeli = {ters_cevrim_say(k1)} · "
          f"kaba = {ters_cevrim_kaba(k1)}")
    ciftleri_yaz(k1)
    karsilastirma = karsilastirma_kaba = 0
    t2 = ters_cevrim_say(k2)
    t2_kaba = ters_cevrim_kaba(k2)
    print(f"[6, 3, 8, 1, 7, 2, 5, 4]: birleştirmeli = {t2} ({karsilastirma} "
          f"karşılaştırma) · kaba = {t2_kaba} ({karsilastirma_kaba})")
    ciftleri_yaz(k2)

    boyutlar = [10, 100, 1000, 3000]
    print("\nRastgele girdi (tohum 42, 0..999): birleştirmeli ↔ kâhin")
    print("     n  ters çevrim  karş. (bs)  karş. (kaba)  kâhin")
    for n in boyutlar:
        rastgele_tohum(42)
        x = rastgele_dizi(n, 0, 999)
        karsilastirma = karsilastirma_kaba = 0
        bs = ters_cevrim_say(x)
        kaba = ters_cevrim_kaba(x)
        print(f"{n:6d} {bs:12d} {karsilastirma:11d} {karsilastirma_kaba:13d}"
              "  " + ("aynı" if bs == kaba else "FARKLI"))

    n = 100000
    print(f"\nn = {n} (kaba yöntem {n * (n - 1) // 2} karşılaştırma isterdi)")
    for tur in range(3):
        adlar = ["rastgele", "sıralı  ", "ters    "]
        rastgele_tohum(42)
        x = rastgele_dizi(n, 0, 999999)
        for k in range(n):
            if tur == 1:
                x[k] = k
            elif tur == 2:
                x[k] = n - k
        karsilastirma = 0
        bs = ters_cevrim_say(x)
        print(f"{adlar[tur]} ters çevrim = {bs:11d} · karşılaştırma = "
              f"{karsilastirma}")
    print(f"Ters sıralıda n(n-1)/2 = {n * (n - 1) // 2}; araya ekleme "
          "sıralaması tam olarak\nters çevrim sayısı kadar kaydırma yapar "
          "(H5).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Ters çevrim sayısı iki
# sıralama arasındaki Kendall tau uzaklığıdır.

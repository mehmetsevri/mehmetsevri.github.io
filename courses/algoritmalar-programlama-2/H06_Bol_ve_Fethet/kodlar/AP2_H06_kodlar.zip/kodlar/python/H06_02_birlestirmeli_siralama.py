"""H06_02_birlestirmeli_siralama.py — AP-2 Hafta 6 · Örnek 2 (★★)
Amaç    : Birleştirmeli sıralama (yukarıdan aşağıya): böl, fethet,
          birleştir. Yardımcı tampon BİR KEZ ayrılır ve tüm çağrılarca
          paylaşılır. Sayaçlar: karşılaştırma, kopya, çağrı, derinlik.
Çalıştır: python3 H06_02_birlestirmeli_siralama.py
Eşleri  : c/H06_02_birlestirmeli_siralama.c ·
          cpp/H06_02_birlestirmeli_siralama.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_dizi, rastgele_tohum

karsilastirma = kopya = cagri = 0
en_derin = tampon_ayirma = 0


# a[lo..mid] ve a[mid+1..hi] sıralı; yrd üzerinden a[lo..hi]'yi birleştirir
def birlestir(a, yrd, lo, mid, hi):
    global karsilastirma, kopya
    i, j, k = lo, mid + 1, lo
    while i <= mid and j <= hi:
        karsilastirma += 1
        if a[i] <= a[j]:  # eşitse soldan
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    while i <= mid:
        yrd[k] = a[i]
        i += 1
        k += 1
    while j <= hi:
        yrd[k] = a[j]
        j += 1
        k += 1
    for k in range(lo, hi + 1):  # geri kopyala
        a[k] = yrd[k]
    kopya += 2 * (hi - lo + 1)


# a[lo..hi]'yi sıralar; d: özyineleme derinliği (kök = 1)
def bs_ozyineli(a, yrd, lo, hi, d):
    global cagri, en_derin
    cagri += 1
    if d > en_derin:
        en_derin = d
    if lo >= hi:  # 0 ya da 1 eleman: sıralı
        return
    mid = lo + (hi - lo) // 2
    # böl ve fethet: iki yarıyı ayrı ayrı sırala
    bs_ozyineli(a, yrd, lo, mid, d + 1)
    bs_ozyineli(a, yrd, mid + 1, hi, d + 1)
    birlestir(a, yrd, lo, mid, hi)  # birleştir


# Tek tampon: n elemanlık yrd bir kez ayrılır (çöp toplayıcı bırakır)
def birlestirmeli_sirala(a):
    global tampon_ayirma
    if not a:
        return
    yrd = [0] * len(a)
    tampon_ayirma += 1
    bs_ozyineli(a, yrd, 0, len(a) - 1, 1)


def dizi_yaz(ad, a):
    print(f"{ad}: [" + ", ".join(str(x) for x in a) + "]")


# ⌈lg n⌉ (n >= 1): 2^k >= n olan en küçük k
def tavan_log2(n):
    k = 0
    while (1 << k) < n:
        k += 1
    return k


def sayaclari_sifirla():
    global karsilastirma, kopya, cagri, en_derin, tampon_ayirma
    karsilastirma = kopya = cagri = 0
    en_derin = tampon_ayirma = 0


# a'yı sıralar; kâhinle (sorted) karşılaştırıp True/False döndürür
def sinama(a):
    kahin = sorted(a)                                   # yalnızca kâhin
    sayaclari_sifirla()
    birlestirmeli_sirala(a)
    return a == kahin


def main():
    a = [6, 3, 8, 1, 7, 2, 5, 4]
    print("Birleştirmeli sıralama (yukarıdan aşağıya, tek tampon)")
    dizi_yaz("önce ", a)
    sayaclari_sifirla()
    birlestirmeli_sirala(a)
    dizi_yaz("sonra", a)
    print(f"karşılaştırma = {karsilastirma} · kopya = {kopya} · "
          f"çağrı = {cagri} · derinlik = {en_derin}\n"
          f"tampon ayırma = {tampon_ayirma} (her çağrıda değil, bir kez)\n")

    boyutlar = [1, 2, 3, 7, 8, 100, 1000, 1024, 10000, 100000]
    print("Rastgele girdi (tohum 42, 0..999999) · W(n) = n⌈lg n⌉ - "
          "2^⌈lg n⌉ + 1")
    print("     n  karşılaştırma        W(n)  çağrı  derinlik  kâhin")
    for n in boyutlar:
        rastgele_tohum(42)
        x = rastgele_dizi(n, 0, 999999)
        ayni = sinama(x)
        k = tavan_log2(n)
        w = n * k - (1 << k) + 1
        print(f"{n:6d} {karsilastirma:14d} {w:11d} {cagri:6d} "
              f"{en_derin:9d}  " + ("aynı" if ayni else "FARKLI"))
    print("çağrı = 2n - 1 · derinlik = ⌈lg n⌉ + 1 · karşılaştırma "
          "<= W(n)\n")

    print("Girdi türünün etkisi (n = 1024, lg n = 10)")
    print("girdi      karşılaştırma   kopya  kâhin")
    for tur in range(3):
        adlar = ["rastgele", "sıralı  ", "ters    "]
        rastgele_tohum(42)
        x = rastgele_dizi(1024, 0, 999999)
        for i in range(1024):
            if tur == 1:
                x[i] = i
            elif tur == 2:
                x[i] = 1024 - i
        ayni = sinama(x)
        print(f"{adlar[tur]} {karsilastirma:15d} {kopya:7d}  "
              + ("aynı" if ayni else "FARKLI"))
    print(f"Sıralı girdide bile (n/2)·lg n = {1024 // 2 * 10} "
          f"karşılaştırma ve 2n·lg n = {2 * 1024 * 10} kopya:")
    print("birleştirmeli sıralama uyarlanabilir değildir; "
          "Θ(n log n) her durumda.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (qsort algoritma belirtmez); C++ —
# std::stable_sort (kararlı; genellikle birleştirmeli); Python — sorted /
# list.sort (Timsort: birleştirmeli + araya ekleme melezi, kararlı)

"""H10_deney_saldiri.py — AP-2 Hafta 10 · Haftanın Deneyi (b)
Amaç    : C/C++ ile aynı anahtarlar ve aynı karşılaştırma sayıları; süre
          bütçesi: bir ölçümün (1 ısınma + TEKRAR) kestirilen süresi
          BUTCE_S'yi aşacaksa o seri için daha büyük k ölçülmez (çözümleme
          betiği bunları c·n² ya da c·n modeliyle İŞARETLİ kestirir).
Çalıştır: python3 H10_deney_saldiri.py KMIN KMAX TEKRAR CSV_DOSYASI
          [BUTCE_S]
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

SALDIRI, RASTGELE, FNV_TOHUM, TABAN_UST = 0, 1, 2, 3
SERI = ["saldiri", "rastgele", "savunma_fnv", "savunma_taban_ust"]
MASKE32 = 0xFFFFFFFF


class Dugum:
    __slots__ = ("karma", "sonraki", "anahtar")

    def __init__(self, karma, sonraki, anahtar):
        self.karma = karma
        self.sonraki = sonraki
        self.anahtar = anahtar


karsilastirma_sayisi = 0
gizli_taban = 0
gizli_tohum = 0


def karma(seri, s):
    if seri in (SALDIRI, RASTGELE):
        h = 0
        for b in s:
            h = (31 * h + b) & MASKE32
    elif seri == TABAN_UST:
        h = 0
        for b in s:
            h = (gizli_taban * h + b) & MASKE32
    else:
        h = 2166136261 ^ gizli_tohum
        for b in s:
            h ^= b
            h = (h * 16777619) & MASKE32
    return h


def indis(seri, h, p):
    if seri == TABAN_UST:
        return ((h * 2654435769) & MASKE32) >> (32 - p)
    return h & ((1 << p) - 1)


def deneme(seri, anahtarlar):
    """Boş tabloya anahtarları ekle (m = 16'dan, α > 1 olunca × 2)"""
    global karsilastirma_sayisi
    kova = [None] * 16
    p = 4
    n = 0
    for a in anahtarlar:
        h = karma(seri, a)
        j = indis(seri, h, p)
        d = kova[j]
        var = False
        while d is not None:
            karsilastirma_sayisi += 1
            if d.anahtar == a:
                var = True
                break
            d = d.sonraki
        if var:
            continue
        kova[j] = Dugum(h, kova[j], a)
        n += 1
        if n > len(kova):
            yeni = [None] * (2 * len(kova))
            for bas in kova:
                d = bas
                while d is not None:
                    sonraki = d.sonraki
                    k = indis(seri, d.karma, p + 1)
                    d.sonraki = yeni[k]
                    yeni[k] = d
                    d = sonraki
            kova = yeni
            p += 1


def main():
    global karsilastirma_sayisi, gizli_taban, gizli_tohum
    a = sys.argv[1:]
    if len(a) not in (4, 5):
        print("kullanım: KMIN KMAX TEKRAR CSV [BUTCE_S]", file=sys.stderr)
        sys.exit(2)
    kmin, kmax, tekrar = int(a[0]), int(a[1]), int(a[2])
    butce = float(a[4]) if len(a) == 5 else 20.0
    rastgele_tohum(2026)
    gizli_taban = (2 * rastgele_sayi() + 1) & MASKE32
    gizli_tohum = rastgele_sayi()
    son_sure = [0.0] * 4                     # seri başına son tek çalıştırma
    print("seri;k;n;karsilastirma")
    with open(a[3], "a", encoding="utf-8") as csv:
        for k in range(kmin, kmax + 1):
            n = 1 << k
            rastgele_tohum(42)
            carpisan = []
            rastgele = []
            for i in range(n):
                carpisan.append(b"".join(
                    b"BB" if (i >> (k - 1 - b)) & 1 else b"Aa"
                    for b in range(k)))
                s = bytearray(2 * k)
                for b in range(2 * k):
                    x = rastgele_aralik(0, 51)
                    s[b] = 65 + x if x < 26 else 97 + x - 26
                rastgele.append(bytes(s))
            for seri in range(4):
                buyume = 4.0 if seri == SALDIRI else 2.2
                if son_sure[seri] * buyume * (tekrar + 1) > butce:
                    son_sure[seri] = float("inf")
                    continue                 # bütçe aşılacak: ölçülmez
                anahtar = rastgele if seri == RASTGELE else carpisan
                karsilastirma_sayisi = 0
                c0 = islemci_sn()
                deneme(seri, anahtar)        # ısınma + sayaç
                son_sure[seri] = islemci_sn() - c0
                kar = karsilastirma_sayisi
                duvar = []
                cpu = []
                for _ in range(tekrar):
                    t0 = zaman_sn()
                    c0 = islemci_sn()
                    deneme(seri, anahtar)
                    cpu.append((islemci_sn() - c0) * 1e3)
                    duvar.append((zaman_sn() - t0) * 1e3)
                print(f"{SERI[seri]};{k};{n};{kar}", flush=True)
                csv.write(f"py;-;{SERI[seri]};{k};{n};{tekrar};"
                          f"{ortanca(duvar):.4f};{ortanca(cpu):.4f};{kar}\n")
                csv.flush()


if __name__ == "__main__":
    main()

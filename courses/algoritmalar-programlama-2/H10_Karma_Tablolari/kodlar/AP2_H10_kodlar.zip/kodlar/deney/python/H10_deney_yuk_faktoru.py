"""H10_deney_yuk_faktoru.py — AP-2 Hafta 10 · Haftanın Deneyi (a)
Amaç    : yoklama kipi C/C++ ile birebir aynı CSV'yi üretir (deterministik
          sayaçlar; küçük m ile sınanır). sure kipi: etiketli kütüphane
          serisi dict (aynı anahtar kümeleri; dict kendi yük faktörüyle
          çalışır) — başarılı/başarısız arama süresi.
Çalıştır: python3 H10_deney_yuk_faktoru.py yoklama P TOHUM...
          python3 H10_deney_yuk_faktoru.py sure P TOHUM TEKRAR CSV_DOSYASI
          [ALFA_LISTESI]   (ör. 25,55,75,90,95: süre bütçesi için alt küme)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

SORGU_YOKLAMA = 4096
ALFA = [25, 35, 45, 55, 65, 75, 85, 90, 95]


class Dugum:
    __slots__ = ("anahtar", "sonraki")

    def __init__(self, anahtar, sonraki):
        self.anahtar = anahtar
        self.sonraki = sonraki


yoklama_sayisi = 0


def karma_carpma(k, p):
    return ((k * 2654435769) & 0xFFFFFFFF) >> (32 - p)


def dy_ekle(anahtar, dolu, p, k):
    maske = (1 << p) - 1
    i = karma_carpma(k, p)
    while dolu[i]:
        if anahtar[i] == k:
            return False
        i = (i + 1) & maske
    dolu[i] = 1
    anahtar[i] = k
    return True


def dy_ara(anahtar, dolu, p, k):
    global yoklama_sayisi
    maske = (1 << p) - 1
    i = karma_carpma(k, p)
    while True:
        yoklama_sayisi += 1
        if not dolu[i]:
            return False
        if anahtar[i] == k:
            return True
        i = (i + 1) & maske


def zc_ara(kova, p, k):
    global yoklama_sayisi
    d = kova[karma_carpma(k, p)]
    while d is not None:
        yoklama_sayisi += 1
        if d.anahtar == k:
            return True
        d = d.sonraki
    return False


def kur(p, n, tohum):
    m = 1 << p
    anahtar = [0] * m
    dolu = [0] * m
    kova = [None] * m
    eklenen = []
    rastgele_tohum(tohum)
    while len(eklenen) < n:
        k = rastgele_sayi()
        if dy_ekle(anahtar, dolu, p, k):
            j = karma_carpma(k, p)
            kova[j] = Dugum(k, kova[j])
            eklenen.append(k)
    return anahtar, dolu, kova, eklenen


def yoklama_kipi(p, tohumlar):
    global yoklama_sayisi
    m = 1 << p
    print("yapi;alfa_yuzde;n;m;tohum;basarili_ort;basarisiz_ort")
    for yuzde in ALFA:
        n = yuzde * m // 100
        for tohum in tohumlar:
            anahtar, dolu, kova, eklenen = kur(p, n, tohum * 1000 + yuzde)
            yoklama_sayisi = 0
            for k in eklenen:
                zc_ara(kova, p, k)
            zs = yoklama_sayisi / n
            yoklama_sayisi = 0
            for k in eklenen:
                dy_ara(anahtar, dolu, p, k)
            ds = yoklama_sayisi / n
            zb = db = 0
            for _ in range(SORGU_YOKLAMA):
                k = rastgele_sayi() | 0x80000000
                yoklama_sayisi = 0
                zc_ara(kova, p, k)
                zb += yoklama_sayisi
                yoklama_sayisi = 0
                dy_ara(anahtar, dolu, p, k)
                db += yoklama_sayisi
            print(f"zincirleme;{yuzde};{n};{m};{tohum};{zs:.6f};"
                  f"{zb / SORGU_YOKLAMA:.6f}")
            print(f"dogrusal;{yuzde};{n};{m};{tohum};{ds:.6f};"
                  f"{db / SORGU_YOKLAMA:.6f}")


def sure_kipi(p, tohum, tekrar, csv_yolu, alfalar):
    """dict serisi: C/C++ ile aynı anahtar kümeleri ve sorgu sırası"""
    m = 1 << p
    with open(csv_yolu, "a", encoding="utf-8") as csv:
        for yuzde in alfalar:
            n = yuzde * m // 100
            # Aynı anahtar listesi: LCG dizisi, yinelenenler atlanarak (C'de
            # dy_ekle'nin elediği gibi); burada yalnız üretim için set
            rastgele_tohum(tohum * 1000 + yuzde)
            gorulen = set()
            eklenen = []
            while len(eklenen) < n:
                k = rastgele_sayi()
                if k not in gorulen:
                    gorulen.add(k)
                    eklenen.append(k)
            for i in range(n - 1, 0, -1):    # C ile aynı karıştırma
                j = rastgele_aralik(0, i)
                eklenen[i], eklenen[j] = eklenen[j], eklenen[i]
            yok = [rastgele_sayi() | 0x80000000 for _ in range(n)]
            d = {k: k for k in eklenen}
            for tur, sorgu in (("basarili", eklenen), ("basarisiz", yok)):
                def gorev():
                    return sum(1 for k in sorgu if k in d)
                gorev()                      # ısınma
                duvar = []
                cpu = []
                for _ in range(tekrar):
                    t0 = zaman_sn()
                    c0 = islemci_sn()
                    bulunan = gorev()
                    cpu.append((islemci_sn() - c0) * 1e3)
                    duvar.append((zaman_sn() - t0) * 1e3)
                cms = ortanca(cpu)
                csv.write(f"py;-;dict;{yuzde};{n};-;{tur};{tekrar};"
                          f"{ortanca(duvar):.4f};{cms:.4f};"
                          f"{cms * 1e6 / n:.3f};{bulunan}\n")
                print(f"dict {yuzde} {tur} bulunan={bulunan}")


def main():
    a = sys.argv[1:]
    if len(a) >= 3 and a[0] == "yoklama":
        yoklama_kipi(int(a[1]), [int(x) for x in a[2:]])
    elif len(a) in (5, 6) and a[0] == "sure":
        alfalar = ALFA if len(a) == 5 else [int(x) for x in a[5].split(",")]
        sure_kipi(int(a[1]), int(a[2]), int(a[3]), a[4], alfalar)
    else:
        print("kullanım: yoklama P TOHUM... | sure P TOHUM TEKRAR CSV "
              "[ALFA_LISTESI]", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()

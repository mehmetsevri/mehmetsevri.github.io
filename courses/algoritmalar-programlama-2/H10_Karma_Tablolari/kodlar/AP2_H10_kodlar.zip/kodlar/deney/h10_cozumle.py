#!/usr/bin/env python3
"""h10_cozumle.py — AP-2 Hafta 10 · Haftanın Deneyi çözümlemesi

Ham CSV'lerden (sonuclar/h10_deney_*.csv) özet tabloları üretir; bütün
oranlar, katlar, sapmalar ve kestirimler burada hesaplanır (elle sayı yok):
  h10_ozet_yoklama.csv   α ve yapı başına tohumlar üzerinden ortalama,
                         standart sapma, en az/en çok; kuramsal değer
                         (Knuth, 1998) ve yüzde sapma
  h10_ozet_sure.csv      sorgu başına işlemci süresi (ns); zincirleme /
                         doğrusal ve kütüphane / doğrusal katları
  h10_ozet_saldiri.csv   seri başına karşılaştırma ve süre; n × 2 katları;
                         log–log eğimi; Python'da ölçülmeyenler için
                         İŞARETLİ kestirim (saldırı c·n², diğerleri c·n)
  h10_ozet.json          belge/kart/DEVIR için anahtar sayılar
Kullanım: python3 h10_cozumle.py
"""
import csv
import json
import math
import os
import statistics

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def kuram(yapi, tur, a):
    if yapi == "zincirleme":
        return 1 + a / 2 if tur == "basarili" else a
    if tur == "basarili":
        return 0.5 * (1 + 1 / (1 - a))
    return 0.5 * (1 + 1 / (1 - a) ** 2)


def egim(xs, ys):
    """log2–log2 en küçük kareler eğimi"""
    lx = [math.log2(x) for x in xs]
    ly = [math.log2(y) for y in ys]
    mx, my = statistics.fmean(lx), statistics.fmean(ly)
    pay = sum((a - mx) * (b - my) for a, b in zip(lx, ly))
    payda = sum((a - mx) ** 2 for a in lx)
    return pay / payda


def yoklama_ozet(ozet):
    satir = oku("h10_deney_yoklama.csv")
    gruplar = {}
    for s in satir:
        gruplar.setdefault((s["yapi"], int(s["alfa_yuzde"])), []).append(s)
    cikti = []
    for (yapi, yuzde), g in sorted(gruplar.items()):
        n, m = int(g[0]["n"]), int(g[0]["m"])
        a = n / m
        kayit = {"yapi": yapi, "alfa_yuzde": yuzde, "alfa": f"{a:.4f}",
                 "n": n, "m": m, "tohum_sayisi": len(g)}
        for tur in ("basarili", "basarisiz"):
            v = [float(x[tur + "_ort"]) for x in g]
            ort = statistics.fmean(v)
            k = kuram(yapi, tur, a)
            kayit.update({
                f"{tur}_ort": f"{ort:.4f}",
                f"{tur}_std": f"{statistics.stdev(v):.4f}",
                f"{tur}_en_az": f"{min(v):.4f}",
                f"{tur}_en_cok": f"{max(v):.4f}",
                f"{tur}_kuram": f"{k:.4f}",
                f"{tur}_sapma_yuzde": f"{100 * (ort - k) / k:+.2f}"})
        cikti.append(kayit)
    yaz("h10_ozet_yoklama.csv", cikti)
    ozet["yoklama"] = cikti


def sure_ozet(ozet):
    satir = oku("h10_deney_arama_suresi.csv")
    d = {}
    for s in satir:
        anahtar = (s["dil"], s["yapi"], int(s["alfa_yuzde"]), s["tur"])
        assert anahtar not in d, f"yinelenen satır: {anahtar}"
        d[anahtar] = float(s["ns_sorgu_islemci"])
    cikti = []
    for (dil, yapi, yuzde, tur), ns in sorted(d.items()):
        kayit = {"dil": dil, "yapi": yapi, "alfa_yuzde": yuzde, "tur": tur,
                 "ns_sorgu": f"{ns:.2f}"}
        ref = d.get((dil if dil != "py" else "c", "dogrusal", yuzde, tur))
        kayit["dogrusal_kati"] = f"{ns / ref:.3f}" if ref else ""
        cikti.append(kayit)
    yaz("h10_ozet_sure.csv", cikti)
    # anahtar katlar: zincirleme / doğrusal (başarılı ve başarısız)
    katlar = {}
    for dil in ("c", "cpp"):
        for tur in ("basarili", "basarisiz"):
            katlar[f"{dil}_{tur}"] = {
                y: round(d[(dil, "zincirleme", y, tur)] /
                         d[(dil, "dogrusal", y, tur)], 3)
                for y in sorted({k[2] for k in d if k[0] == dil})}
    for tur in ("basarili", "basarisiz"):
        katlar[f"unordered_map_{tur}"] = {
            y: round(d[("cpp", "unordered_map", y, tur)] /
                     d[("cpp", "dogrusal", y, tur)], 3)
            for y in sorted({k[2] for k in d if k[1] == "unordered_map"})}
        katlar[f"dict_c_dogrusal_{tur}"] = {
            y: round(d[("py", "dict", y, tur)] / d[("c", "dogrusal", y, tur)],
                     3)
            for y in sorted({k[2] for k in d if k[1] == "dict"})}
    ozet["sure"] = {f"{k[0]}|{k[1]}|{k[2]}|{k[3]}": v for k, v in d.items()}
    ozet["sure_katlar"] = katlar


def saldiri_ozet(ozet):
    satir = oku("h10_deney_saldiri.csv")
    d = {}
    for s in satir:
        anahtar = (s["dil"] + s["derleme"].replace("-", ""), s["seri"],
                   int(s["k"]))
        assert anahtar not in d, f"yinelenen satır: {anahtar}"
        d[anahtar] = (int(s["n"]), int(s["karsilastirma"]),
                      float(s["ortanca_islemci_ms"]),
                      float(s["ortanca_duvar_ms"]))
    cikti = []
    egimler = {}
    kestirim = {}
    for dil in sorted({k[0] for k in d}):
        for seri in ("saldiri", "rastgele", "savunma_fnv",
                     "savunma_taban_ust"):
            ks = sorted(k[2] for k in d if k[0] == dil and k[1] == seri)
            if not ks:
                continue
            for i, k in enumerate(ks):
                n, kar, ms, dms = d[(dil, seri, k)]
                kayit = {"dil": dil, "seri": seri, "k": k, "n": n,
                         "karsilastirma": kar, "islemci_ms": f"{ms:.4f}",
                         "duvar_ms": f"{dms:.4f}", "olcum": "ölçüldü"}
                if i > 0:
                    n0, kar0, ms0, _ = d[(dil, seri, ks[i - 1])]
                    kayit["kar_kati"] = f"{kar / kar0:.3f}"
                    kayit["sure_kati"] = f"{ms / ms0:.3f}" if ms0 > 0 else ""
                cikti.append(kayit)
            # eğim: süresi ≥ 1 ms olan noktalar
            xs = [d[(dil, seri, k)][0] for k in ks if d[(dil, seri, k)][2] >= 1]
            ys = [d[(dil, seri, k)][2] for k in ks if d[(dil, seri, k)][2] >= 1]
            if len(xs) >= 3:
                egimler[f"{dil}|{seri}"] = round(egim(xs, ys), 3)
            xk = [d[(dil, seri, k)][0] for k in ks]
            yk = [d[(dil, seri, k)][1] for k in ks]
            egimler[f"{dil}|{seri}|karsilastirma"] = round(
                egim(xk, [max(y, 1) for y in yk]), 3)
            # Python: ölçülmeyen k için kestirim (en büyük ölçülen noktadan)
            if dil == "py" and ks[-1] < 16:
                n_son, _, ms_son, _ = d[(dil, seri, ks[-1])]
                us = 2 if seri == "saldiri" else 1
                for k in range(ks[-1] + 1, 17):
                    n = 1 << k
                    tahmin = ms_son * (n / n_son) ** us
                    karc = d[("cO2", seri, k)][1]
                    cikti.append({"dil": dil, "seri": seri, "k": k, "n": n,
                                  "karsilastirma": karc,
                                  "islemci_ms": f"{tahmin:.1f}",
                                  "duvar_ms": "",
                                  "olcum": f"KESTİRİM (c·n^{us}, k = "
                                           f"{ks[-1]}'den)"})
                    kestirim[f"{seri}|{k}"] = round(tahmin, 1)
    yaz("h10_ozet_saldiri.csv", cikti)
    ozet["saldiri"] = {f"{k[0]}|{k[1]}|{k[2]}": list(v) for k, v in
                       d.items()}
    ozet["saldiri_egim"] = egimler
    ozet["saldiri_py_kestirim_ms"] = kestirim
    # C'de saldırı / rastgele süre katı (her k) ve C -O0 / -O2
    ozet["saldiri_kat_c"] = {
        k: round(d[("cO2", "saldiri", k)][2] / d[("cO2", "rastgele", k)][2],
                 1) for k in range(8, 17) if ("cO2", "saldiri", k) in d}
    ozet["saldiri_O0_O2"] = {
        k: round(d[("cO0", "saldiri", k)][2] / d[("cO2", "saldiri", k)][2],
                 3) for k in range(8, 17) if ("cO0", "saldiri", k) in d}
    ozet["saldiri_cpp_c"] = {
        k: round(d[("cppO2", "saldiri", k)][2] / d[("cO2", "saldiri", k)][2],
                 3) for k in range(8, 17) if ("cppO2", "saldiri", k) in d}
    ozet["saldiri_py_c"] = {
        k: round(d[("py", "saldiri", k)][2] / d[("cO2", "saldiri", k)][2], 1)
        for k in range(8, 17) if ("py", "saldiri", k) in d}


def kelime_ozet(ozet):
    satir = oku("h10_deney_kelime_sayaci.csv")
    ozet["kelime_sayaci"] = [
        {"dil": s["dil"], "yontem": s["yontem"],
         "ortanca_ms": float(s["ortanca_ms"]), "en_az_ms": float(s["en_az_ms"]),
         "en_cok_ms": float(s["en_cok_ms"])} for s in satir]


def yaz(ad, satirlar):
    alanlar = []
    for s in satirlar:
        for k in s:
            if k not in alanlar:
                alanlar.append(k)
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8",
              newline="") as f:
        w = csv.DictWriter(f, alanlar, delimiter=";")
        w.writeheader()
        w.writerows(satirlar)


def main():
    ozet = {}
    yoklama_ozet(ozet)
    sure_ozet(ozet)
    saldiri_ozet(ozet)
    kelime_ozet(ozet)
    ozet["denetim"] = json.load(open(os.path.join(SONUC, "h10_denetim.json"),
                                     encoding="utf-8"))
    with open(os.path.join(SONUC, "h10_ozet.json"), "w",
              encoding="utf-8") as f:
        json.dump(ozet, f, ensure_ascii=False, indent=1)
    print("özetler yazıldı:", ", ".join(sorted(
        x for x in os.listdir(SONUC) if x.startswith("h10_ozet"))))
    print("eğimler:", ozet["saldiri_egim"])
    print("C zincirleme/doğrusal katı:", ozet["sure_katlar"]["c_basarili"])


if __name__ == "__main__":
    main()

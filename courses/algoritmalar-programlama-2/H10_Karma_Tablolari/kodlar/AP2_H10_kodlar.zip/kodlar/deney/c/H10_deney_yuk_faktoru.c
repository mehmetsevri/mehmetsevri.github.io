/* H10_deney_yuk_faktoru.c — AP-2 Hafta 10 · Haftanın Deneyi (a)
 * Amaç    : Yük faktörü α = 0,25 … 0,95: ayrı zincirleme ve doğrusal
 *           yoklamada (1) ortalama yoklama sayısı (deterministik; birden
 *           çok tohum) ve (2) arama süresi (bitişik hücreler / dağınık
 *           düğümler). Karma: çarpma yöntemi (Örnek 5 ile aynı).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_deney_yuk_faktoru.c ortak_rastgele.c zamanlayici.c \
 *           -o H10_deney_yuk_faktoru
 * Çalıştır: ./H10_deney_yuk_faktoru yoklama P TOHUM...   (CSV: stdout)
 *           ./H10_deney_yuk_faktoru sure P TOHUM TEKRAR CSV_DOSYASI
 *           (süreler CSV dosyasına; stdout'a yalnız doğrulama sayıları)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

/* CSV'deki derleme etiketi: sürücü -DDERLEME='"-O0"' biçiminde verir;
 * verilmezse __OPTIMIZE__ (GCC/Clang, -O1 ve üstü) makrosundan çıkarılır */
#ifndef DERLEME
#ifdef __OPTIMIZE__
#define DERLEME "-O2"
#else
#define DERLEME "-O0"
#endif
#endif

#define SORGU_YOKLAMA 4096       /* başarısız arama (yoklama kipi) */

static const int ALFA[] = {25, 35, 45, 55, 65, 75, 85, 90, 95};
#define ALFA_N 9

typedef struct {
    uint32_t anahtar;
    uint32_t dolu;               /* hücre 8 bayt: bitişik dizi */
} Hucre;

typedef struct Dugum {
    uint32_t anahtar;
    struct Dugum *sonraki;
} Dugum;

static long long yoklama_sayisi = 0;

static uint32_t karma_carpma(uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

static int dy_ekle(Hucre *t, int p, uint32_t k)
{
    uint32_t maske = (1u << p) - 1u;
    uint32_t i = karma_carpma(k, p);
    while (t[i].dolu) {
        if (t[i].anahtar == k) {
            return 0;
        }
        i = (i + 1u) & maske;
    }
    t[i].dolu = 1;
    t[i].anahtar = k;
    return 1;
}

static int dy_ara(const Hucre *t, int p, uint32_t k)
{
    uint32_t maske = (1u << p) - 1u;
    uint32_t i = karma_carpma(k, p);
    for (;;) {
        yoklama_sayisi++;
        if (!t[i].dolu) {
            return 0;
        }
        if (t[i].anahtar == k) {
            return 1;
        }
        i = (i + 1u) & maske;
    }
}

static int zc_ekle(Dugum **kova, int p, uint32_t k)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return -1;
    }
    uint32_t j = karma_carpma(k, p);
    d->anahtar = k;
    d->sonraki = kova[j];
    kova[j] = d;
    return 1;
}

static int zc_ara(Dugum *const *kova, int p, uint32_t k)
{
    for (const Dugum *d = kova[karma_carpma(k, p)]; d != NULL;
         d = d->sonraki) {
        yoklama_sayisi++;
        if (d->anahtar == k) {
            return 1;
        }
    }
    return 0;
}

static void zc_yok_et(Dugum **kova, size_t m)
{
    for (size_t j = 0; j < m; j++) {
        Dugum *d = kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            free(d);
            d = sonraki;
        }
        kova[j] = NULL;
    }
}

/* n farklı anahtar: önce doğrusal tabloya (yinelenen elenir), sonra aynı
 * sırayla zincirleme tabloya. Örnek 5 ile aynı üretim. */
static int kur(Hucre *dy, Dugum **kova, uint32_t *eklenen, int p, size_t n,
               uint64_t tohum)
{
    size_t m = (size_t)1 << p;
    memset(dy, 0, m * sizeof *dy);
    rastgele_tohum(tohum);
    size_t e = 0;
    while (e < n) {
        uint32_t k = rastgele_sayi();
        if (dy_ekle(dy, p, k)) {
            if (zc_ekle(kova, p, k) < 0) {
                return -1;
            }
            eklenen[e++] = k;
        }
    }
    return 0;
}

static int yoklama_kipi(int p, int tohum_n, char **tohum_s)
{
    size_t m = (size_t)1 << p;
    Hucre *dy = malloc(m * sizeof *dy);
    Dugum **kova = calloc(m, sizeof *kova);
    uint32_t *eklenen = malloc(m * sizeof *eklenen);
    if (dy == NULL || kova == NULL || eklenen == NULL) {
        return 1;
    }
    printf("yapi;alfa_yuzde;n;m;tohum;basarili_ort;basarisiz_ort\n");
    for (int a = 0; a < ALFA_N; a++) {
        size_t n = (size_t)ALFA[a] * m / 100;
        for (int s = 0; s < tohum_n; s++) {
            long tohum = strtol(tohum_s[s], NULL, 10);
            if (kur(dy, kova, eklenen, p, n,
                    (uint64_t)tohum * 1000u + (uint64_t)ALFA[a]) != 0) {
                return 1;
            }
            yoklama_sayisi = 0;
            for (size_t i = 0; i < n; i++) {
                zc_ara(kova, p, eklenen[i]);
            }
            double zs = (double)yoklama_sayisi / n;
            yoklama_sayisi = 0;
            for (size_t i = 0; i < n; i++) {
                dy_ara(dy, p, eklenen[i]);
            }
            double ds = (double)yoklama_sayisi / n;
            long long zb = 0;
            long long db = 0;
            for (int q = 0; q < SORGU_YOKLAMA; q++) {
                uint32_t k = rastgele_sayi() | 0x80000000u;
                yoklama_sayisi = 0;
                zc_ara(kova, p, k);
                zb += yoklama_sayisi;
                yoklama_sayisi = 0;
                dy_ara(dy, p, k);
                db += yoklama_sayisi;
            }
            printf("zincirleme;%d;%zu;%zu;%ld;%.6f;%.6f\n", ALFA[a], n, m,
                   tohum, zs, (double)zb / SORGU_YOKLAMA);
            printf("dogrusal;%d;%zu;%zu;%ld;%.6f;%.6f\n", ALFA[a], n, m,
                   tohum, ds, (double)db / SORGU_YOKLAMA);
            zc_yok_et(kova, m);
        }
    }
    free(dy);
    free(kova);
    free(eklenen);
    return 0;
}

/* --- süre ölçümü: 1 ısınma + tekrar; duvar ve işlemci süresi ortancası */
typedef struct {
    const Hucre *dy;
    Dugum *const *kova;
    int p;
    const uint32_t *sorgu;
    size_t n;
    int yapi;                    /* 0 doğrusal, 1 zincirleme */
    long long bulunan;
} Is;

static void calistir(Is *is)
{
    long long b = 0;
    if (is->yapi == 0) {
        for (size_t i = 0; i < is->n; i++) {
            b += dy_ara(is->dy, is->p, is->sorgu[i]);
        }
    } else {
        for (size_t i = 0; i < is->n; i++) {
            b += zc_ara(is->kova, is->p, is->sorgu[i]);
        }
    }
    is->bulunan = b;
}

static void olc(Is *is, int tekrar, double *duvar_ms, double *islemci_ms)
{
    double d[101];
    double c[101];
    calistir(is);                            /* ısınma */
    for (int r = 0; r < tekrar; r++) {
        double t0 = zaman_sn();
        double c0 = islemci_sn();
        calistir(is);
        c[r] = (islemci_sn() - c0) * 1e3;
        d[r] = (zaman_sn() - t0) * 1e3;
    }
    *duvar_ms = ortanca(d, tekrar);
    *islemci_ms = ortanca(c, tekrar);
}

/* Fisher–Yates (ortak LCG) — uint32_t dizisi için */
static void karistir(uint32_t *a, size_t n)
{
    for (size_t i = n - 1; i > 0; i--) {
        size_t j = (size_t)rastgele_aralik(0, (int)i);
        uint32_t g = a[i];
        a[i] = a[j];
        a[j] = g;
    }
}

static int sure_kipi(int p, long tohum, int tekrar, const char *csv_yolu)
{
    size_t m = (size_t)1 << p;
    Hucre *dy = malloc(m * sizeof *dy);
    Dugum **kova = calloc(m, sizeof *kova);
    uint32_t *eklenen = malloc(m * sizeof *eklenen);
    uint32_t *yok = malloc(m * sizeof *yok);
    FILE *csv = fopen(csv_yolu, "a");
    if (dy == NULL || kova == NULL || eklenen == NULL || yok == NULL ||
        csv == NULL) {
        return 1;
    }
    for (int a = 0; a < ALFA_N; a++) {
        size_t n = (size_t)ALFA[a] * m / 100;
        if (kur(dy, kova, eklenen, p, n,
                (uint64_t)tohum * 1000u + (uint64_t)ALFA[a]) != 0) {
            return 1;
        }
        karistir(eklenen, n);                /* sorgu sırası rastgele */
        for (size_t i = 0; i < n; i++) {
            yok[i] = rastgele_sayi() | 0x80000000u;
        }
        for (int yapi = 0; yapi < 2; yapi++) {
            for (int tur = 0; tur < 2; tur++) {
                Is is = {dy, kova, p, tur == 0 ? eklenen : yok, n, yapi, 0};
                double dms, cms;
                olc(&is, tekrar, &dms, &cms);
                fprintf(csv, "c;" DERLEME
                        ";%s;%d;%zu;%zu;%s;%d;%.4f;%.4f;%.3f;%lld\n",
                        yapi == 0 ? "dogrusal" : "zincirleme", ALFA[a], n, m,
                        tur == 0 ? "basarili" : "basarisiz", tekrar, dms, cms,
                        cms * 1e6 / (double)n, is.bulunan);
                printf("%s %d %s bulunan=%lld\n",
                       yapi == 0 ? "dogrusal" : "zincirleme", ALFA[a],
                       tur == 0 ? "basarili" : "basarisiz", is.bulunan);
            }
        }
        zc_yok_et(kova, m);
    }
    fclose(csv);
    free(dy);
    free(kova);
    free(eklenen);
    free(yok);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc >= 4 && strcmp(argv[1], "yoklama") == 0) {
        int p = (int)strtol(argv[2], NULL, 10);
        if (p < 4 || p > 22) {
            return 2;
        }
        return yoklama_kipi(p, argc - 3, argv + 3);
    }
    if (argc == 6 && strcmp(argv[1], "sure") == 0) {
        int p = (int)strtol(argv[2], NULL, 10);
        int tekrar = (int)strtol(argv[4], NULL, 10);
        if (p < 4 || p > 22 || tekrar < 1 || tekrar > 101) {
            return 2;
        }
        return sure_kipi(p, strtol(argv[3], NULL, 10), tekrar, argv[5]);
    }
    fprintf(stderr, "kullanım: %s yoklama P TOHUM... | sure P TOHUM TEKRAR "
            "CSV\n", argv[0]);
    return 2;
}

/* Kütüphane karşılığı: C — yok; C++ — std::unordered_map (deneyin
 * etiketli kütüphane serisi, C++ sürümünde); Python — dict. */

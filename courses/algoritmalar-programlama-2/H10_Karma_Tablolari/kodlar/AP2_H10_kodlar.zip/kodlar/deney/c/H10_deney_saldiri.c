/* H10_deney_saldiri.c — AP-2 Hafta 10 · Haftanın Deneyi (b)
 * Amaç    : Saldırı altında ekleme: n = 2^k çakışan anahtar ("Aa"/"BB"
 *           blokları, polinom 31) zincirleme tabloya eklenirken toplam
 *           anahtar karşılaştırması ve süre (karesel büyüme); aynı
 *           uzunlukta rastgele anahtarlar (doğrusal) ve savunmalar: tohumlu
 *           FNV-1a, rastgele taban + üst bit indisi (Örnek 13). Düğüm
 *           anahtarı düğümün içinde tutulur (karşılaştırma sayısı Örnek 13
 *           ile aynıdır; yalnız bellek düzeni farklı).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_deney_saldiri.c ortak_rastgele.c zamanlayici.c \
 *           -o H10_deney_saldiri
 * Çalıştır: ./H10_deney_saldiri KMIN KMAX TEKRAR CSV_DOSYASI
 *           (stdout: deterministik karşılaştırma sayıları; süreler CSV'ye)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

/* CSV'deki derleme etiketi: sürücü -DDERLEME='"-O0"' biçiminde verir;
 * verilmezse __OPTIMIZE__ (GCC/Clang, -O1 ve üstü) makrosundan çıkarılır */
#ifndef DERLEME
#ifdef __OPTIMIZE__
#define DERLEME "-O2"
#else
#define DERLEME "-O0"
#endif
#endif

#define UZ 33

enum { SALDIRI = 0, RASTGELE = 1, FNV_TOHUM = 2, TABAN_UST = 3 };
static const char *SERI[4] = {"saldiri", "rastgele", "savunma_fnv",
                              "savunma_taban_ust"};

typedef struct Dugum {
    uint32_t karma;
    struct Dugum *sonraki;
    char anahtar[UZ];            /* düğüm içinde (tek ayırma) */
} Dugum;

typedef struct {
    Dugum **kova;
    int p;
    size_t n;
    int seri;
} Tablo;

static long long karsilastirma_sayisi = 0;
static uint32_t gizli_taban = 0;
static uint32_t gizli_tohum = 0;

static uint32_t karma(int seri, const char *s)
{
    uint32_t h;
    if (seri == SALDIRI || seri == RASTGELE) {
        h = 0;
        for (; *s != '\0'; s++) {
            h = 31u * h + (unsigned char)*s;
        }
    } else if (seri == TABAN_UST) {
        h = 0;
        for (; *s != '\0'; s++) {
            h = gizli_taban * h + (unsigned char)*s;
        }
    } else {
        h = 2166136261u ^ gizli_tohum;
        for (; *s != '\0'; s++) {
            h ^= (unsigned char)*s;
            h *= 16777619u;
        }
    }
    return h;
}

static size_t indis(int seri, uint32_t h, int p)
{
    if (seri == TABAN_UST) {
        return (size_t)((h * 2654435769u) >> (32 - p));
    }
    return (size_t)(h & (((uint32_t)1 << p) - 1u));
}

static void yok_et(Tablo *t)
{
    for (size_t j = 0; j < ((size_t)1 << t->p); j++) {
        Dugum *d = t->kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            free(d);
            d = sonraki;
        }
    }
    free(t->kova);
}

static int buyut(Tablo *t)
{
    size_t m = (size_t)1 << t->p;
    Dugum **yeni = calloc(2 * m, sizeof *yeni);
    if (yeni == NULL) {
        return -1;
    }
    for (size_t j = 0; j < m; j++) {
        Dugum *d = t->kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            size_t k = indis(t->seri, d->karma, t->p + 1);
            d->sonraki = yeni[k];
            yeni[k] = d;
            d = sonraki;
        }
    }
    free(t->kova);
    t->kova = yeni;
    t->p++;
    return 0;
}

static int ekle(Tablo *t, const char *anahtar)
{
    uint32_t h = karma(t->seri, anahtar);
    size_t j = indis(t->seri, h, t->p);
    for (Dugum *d = t->kova[j]; d != NULL; d = d->sonraki) {
        karsilastirma_sayisi++;
        if (strcmp(d->anahtar, anahtar) == 0) {
            return 0;
        }
    }
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return -1;
    }
    d->karma = h;
    memcpy(d->anahtar, anahtar, strlen(anahtar) + 1);
    d->sonraki = t->kova[j];
    t->kova[j] = d;
    t->n++;
    return t->n > ((size_t)1 << t->p) ? buyut(t) : 1;
}

/* Bir deneme: boş tabloya n anahtar ekle, sonra yok et */
static void deneme(int seri, char (*anahtar)[UZ], size_t n)
{
    Tablo t;
    t.p = 4;
    t.n = 0;
    t.seri = seri;
    t.kova = calloc(16, sizeof *t.kova);
    if (t.kova == NULL) {
        exit(1);
    }
    for (size_t i = 0; i < n; i++) {
        if (ekle(&t, anahtar[i]) < 0) {
            exit(1);
        }
    }
    yok_et(&t);
}

int main(int argc, char *argv[])
{
    if (argc != 5) {
        fprintf(stderr, "kullanım: %s KMIN KMAX TEKRAR CSV\n", argv[0]);
        return 2;
    }
    int kmin = (int)strtol(argv[1], NULL, 10);
    int kmax = (int)strtol(argv[2], NULL, 10);
    int tekrar = (int)strtol(argv[3], NULL, 10);
    if (kmin < 4 || kmax > 16 || kmin > kmax || tekrar < 1 || tekrar > 101) {
        return 2;
    }
    FILE *csv = fopen(argv[4], "a");
    char (*carpisan)[UZ] = malloc(((size_t)1 << kmax) * sizeof *carpisan);
    char (*rastgele)[UZ] = malloc(((size_t)1 << kmax) * sizeof *rastgele);
    if (csv == NULL || carpisan == NULL || rastgele == NULL) {
        return 1;
    }
    rastgele_tohum(2026);                    /* Örnek 13 ile aynı gizliler */
    gizli_taban = 2u * rastgele_sayi() + 1u;
    gizli_tohum = rastgele_sayi();
    printf("seri;k;n;karsilastirma\n");
    for (int k = kmin; k <= kmax; k++) {
        size_t n = (size_t)1 << k;
        rastgele_tohum(42);
        for (size_t i = 0; i < n; i++) {
            for (int b = 0; b < k; b++) {
                const char *blok = (i >> (k - 1 - b)) & 1u ? "BB" : "Aa";
                carpisan[i][2 * b] = blok[0];
                carpisan[i][2 * b + 1] = blok[1];
            }
            carpisan[i][2 * k] = '\0';
            for (int b = 0; b < 2 * k; b++) {
                int x = rastgele_aralik(0, 51);
                rastgele[i][b] = (char)(x < 26 ? 'A' + x : 'a' + x - 26);
            }
            rastgele[i][2 * k] = '\0';
        }
        for (int seri = 0; seri < 4; seri++) {
            char (*a)[UZ] = seri == RASTGELE ? rastgele : carpisan;
            karsilastirma_sayisi = 0;
            deneme(seri, a, n);              /* ısınma + sayaç */
            long long kar = karsilastirma_sayisi;
            double d[101];
            double c[101];
            for (int r = 0; r < tekrar; r++) {
                double t0 = zaman_sn();
                double c0 = islemci_sn();
                deneme(seri, a, n);
                c[r] = (islemci_sn() - c0) * 1e3;
                d[r] = (zaman_sn() - t0) * 1e3;
            }
            printf("%s;%d;%zu;%lld\n", SERI[seri], k, n, kar);
            fflush(stdout);
            fprintf(csv, "c;" DERLEME ";%s;%d;%zu;%d;%.4f;%.4f;%lld\n",
                    SERI[seri], k, n, tekrar, ortanca(d, tekrar),
                    ortanca(c, tekrar), kar);
            fflush(csv);
        }
    }
    fclose(csv);
    free(carpisan);
    free(rastgele);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::unordered_map<std::string, …>
 * (std::hash gerçekleştirime bağlı); Python — dict (tohumlu SipHash). */

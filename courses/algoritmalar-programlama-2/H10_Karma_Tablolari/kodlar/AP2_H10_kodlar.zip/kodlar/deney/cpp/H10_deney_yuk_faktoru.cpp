/* H10_deney_yuk_faktoru.cpp — AP-2 Hafta 10 · Haftanın Deneyi (a)
 * Amaç    : C sürümüyle aynı ölçüm; ek olarak etiketli kütüphane serisi:
 *           std::unordered_map<std::uint32_t, std::uint32_t> (kova sayısı
 *           ≈ m ile kurulur, max_load_factor 1,0: aynı n'de yeniden karma
 *           olmaz). Yoklama kipinin çıktısı C ile birebir aynıdır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_deney_yuk_faktoru.cpp -o H10_deney_yuk_faktoru
 * Çalıştır: ./H10_deney_yuk_faktoru yoklama P TOHUM...   (CSV: stdout)
 *           ./H10_deney_yuk_faktoru sure P TOHUM TEKRAR CSV_DOSYASI
 */
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

/* CSV'deki derleme etiketi: sürücü -DDERLEME='"-O0"' biçiminde verir;
 * verilmezse __OPTIMIZE__ (GCC/Clang, -O1 ve üstü) makrosundan çıkarılır */
#ifndef DERLEME
#ifdef __OPTIMIZE__
#define DERLEME "-O2"
#else
#define DERLEME "-O0"
#endif
#endif

const int SORGU_YOKLAMA = 4096;
const int ALFA[] = {25, 35, 45, 55, 65, 75, 85, 90, 95};

struct Hucre {
    std::uint32_t anahtar;
    std::uint32_t dolu;          // hücre 8 bayt: bitişik dizi
};

struct Dugum {
    std::uint32_t anahtar;
    Dugum *sonraki;
};

static long long yoklama_sayisi = 0;

static std::uint32_t karma_carpma(std::uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

static bool dy_ekle(std::vector<Hucre>& t, int p, std::uint32_t k)
{
    std::uint32_t maske = (1u << p) - 1u;
    std::uint32_t i = karma_carpma(k, p);
    while (t[i].dolu) {
        if (t[i].anahtar == k) {
            return false;
        }
        i = (i + 1u) & maske;
    }
    t[i].dolu = 1;
    t[i].anahtar = k;
    return true;
}

static bool dy_ara(const std::vector<Hucre>& t, int p, std::uint32_t k)
{
    std::uint32_t maske = (1u << p) - 1u;
    std::uint32_t i = karma_carpma(k, p);
    for (;;) {
        yoklama_sayisi++;
        if (!t[i].dolu) {
            return false;
        }
        if (t[i].anahtar == k) {
            return true;
        }
        i = (i + 1u) & maske;
    }
}

// Zincirleme kovaları: RAII sarmalayıcı, yıkıcıda döngüyle silme
struct Kovalar {
    std::vector<Dugum *> bas;
    explicit Kovalar(std::size_t m) : bas(m, nullptr) {}
    Kovalar(const Kovalar&) = delete;
    Kovalar& operator=(const Kovalar&) = delete;
    ~Kovalar() { yok_et(); }
    void yok_et()
    {
        for (Dugum *&b : bas) {
            while (b != nullptr) {
                Dugum *sonraki = b->sonraki;
                delete b;
                b = sonraki;
            }
        }
    }
};

static void zc_ekle(Kovalar& kova, int p, std::uint32_t k)
{
    std::uint32_t j = karma_carpma(k, p);
    kova.bas[j] = new Dugum{k, kova.bas[j]};
}

static bool zc_ara(const Kovalar& kova, int p, std::uint32_t k)
{
    for (const Dugum *d = kova.bas[karma_carpma(k, p)]; d != nullptr;
         d = d->sonraki) {
        yoklama_sayisi++;
        if (d->anahtar == k) {
            return true;
        }
    }
    return false;
}

static void kur(std::vector<Hucre>& dy, Kovalar& kova,
                std::vector<std::uint32_t>& eklenen, int p, std::size_t n,
                std::uint64_t tohum)
{
    std::fill(dy.begin(), dy.end(), Hucre{0, 0});
    rastgele_tohum(tohum);
    eklenen.clear();
    while (eklenen.size() < n) {
        std::uint32_t k = rastgele_sayi();
        if (dy_ekle(dy, p, k)) {
            zc_ekle(kova, p, k);
            eklenen.push_back(k);
        }
    }
}

static int yoklama_kipi(int p, int tohum_n, char **tohum_s)
{
    std::size_t m = std::size_t{1} << p;
    std::vector<Hucre> dy(m);
    Kovalar kova(m);
    std::vector<std::uint32_t> eklenen;
    std::cout << "yapi;alfa_yuzde;n;m;tohum;basarili_ort;basarisiz_ort\n"
              << std::fixed << std::setprecision(6);
    for (int yuzde : ALFA) {
        std::size_t n = static_cast<std::size_t>(yuzde) * m / 100;
        for (int s = 0; s < tohum_n; s++) {
            long tohum = std::strtol(tohum_s[s], nullptr, 10);
            kur(dy, kova, eklenen, p, n,
                static_cast<std::uint64_t>(tohum) * 1000u +
                    static_cast<std::uint64_t>(yuzde));
            yoklama_sayisi = 0;
            for (std::uint32_t k : eklenen) {
                zc_ara(kova, p, k);
            }
            double zs = static_cast<double>(yoklama_sayisi) / n;
            yoklama_sayisi = 0;
            for (std::uint32_t k : eklenen) {
                dy_ara(dy, p, k);
            }
            double ds = static_cast<double>(yoklama_sayisi) / n;
            long long zb = 0;
            long long db = 0;
            for (int q = 0; q < SORGU_YOKLAMA; q++) {
                std::uint32_t k = rastgele_sayi() | 0x80000000u;
                yoklama_sayisi = 0;
                zc_ara(kova, p, k);
                zb += yoklama_sayisi;
                yoklama_sayisi = 0;
                dy_ara(dy, p, k);
                db += yoklama_sayisi;
            }
            std::cout << "zincirleme;" << yuzde << ';' << n << ';' << m << ';'
                      << tohum << ';' << zs << ';'
                      << static_cast<double>(zb) / SORGU_YOKLAMA << '\n'
                      << "dogrusal;" << yuzde << ';' << n << ';' << m << ';'
                      << tohum << ';' << ds << ';'
                      << static_cast<double>(db) / SORGU_YOKLAMA << '\n';
            kova.yok_et();
        }
    }
    return 0;
}

// 1 ısınma + tekrar; duvar ve işlemci süresi ortancası (ms)
template <class Gorev>
static void olc(Gorev gorev, int tekrar, double& duvar_ms, double& cpu_ms)
{
    std::vector<double> d;
    std::vector<double> c;
    gorev();
    for (int r = 0; r < tekrar; r++) {
        double t0 = zaman_sn();
        double c0 = islemci_sn();
        gorev();
        c.push_back((islemci_sn() - c0) * 1e3);
        d.push_back((zaman_sn() - t0) * 1e3);
    }
    duvar_ms = ortanca(d);
    cpu_ms = ortanca(c);
}

static void karistir(std::vector<std::uint32_t>& a)
{
    for (std::size_t i = a.size() - 1; i > 0; i--) {
        std::size_t j =
            static_cast<std::size_t>(rastgele_aralik(0, static_cast<int>(i)));
        std::uint32_t g = a[i];
        a[i] = a[j];
        a[j] = g;
    }
}

static int sure_kipi(int p, long tohum, int tekrar, const char *csv_yolu)
{
    std::size_t m = std::size_t{1} << p;
    std::vector<Hucre> dy(m);
    Kovalar kova(m);
    std::vector<std::uint32_t> eklenen;
    std::vector<std::uint32_t> yok;
    std::ofstream csv(csv_yolu, std::ios::app);
    if (!csv) {
        return 1;
    }
    csv << std::fixed;
    for (int yuzde : ALFA) {
        std::size_t n = static_cast<std::size_t>(yuzde) * m / 100;
        kur(dy, kova, eklenen, p, n,
            static_cast<std::uint64_t>(tohum) * 1000u +
                static_cast<std::uint64_t>(yuzde));
        karistir(eklenen);
        yok.assign(n, 0);
        for (std::size_t i = 0; i < n; i++) {
            yok[i] = rastgele_sayi() | 0x80000000u;
        }
        std::unordered_map<std::uint32_t, std::uint32_t> um(m);
        um.max_load_factor(1.0f);
        for (std::uint32_t k : eklenen) {
            um.emplace(k, k);
        }
        for (int yapi = 0; yapi < 3; yapi++) {
            const char *ad = yapi == 0 ? "dogrusal"
                             : yapi == 1 ? "zincirleme" : "unordered_map";
            for (int tur = 0; tur < 2; tur++) {
                const std::vector<std::uint32_t>& sorgu =
                    tur == 0 ? eklenen : yok;
                long long bulunan = 0;
                auto gorev = [&]() {
                    long long b = 0;
                    for (std::uint32_t k : sorgu) {
                        if (yapi == 0) {
                            b += dy_ara(dy, p, k);
                        } else if (yapi == 1) {
                            b += zc_ara(kova, p, k);
                        } else {
                            b += um.find(k) != um.end();
                        }
                    }
                    bulunan = b;
                };
                double dms, cms;
                olc(gorev, tekrar, dms, cms);
                csv << "cpp;" DERLEME ";" << ad << ';' << yuzde << ';' << n
                    << ';' << (yapi == 2 ? um.bucket_count() : m) << ';'
                    << (tur == 0 ? "basarili" : "basarisiz") << ';' << tekrar
                    << ';' << std::setprecision(4) << dms << ';' << cms << ';'
                    << std::setprecision(3) << cms * 1e6 / n << ';' << bulunan
                    << '\n';
                std::cout << ad << ' ' << yuzde << ' '
                          << (tur == 0 ? "basarili" : "basarisiz")
                          << " bulunan=" << bulunan << '\n';
            }
        }
        kova.yok_et();
    }
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc >= 4 && std::strcmp(argv[1], "yoklama") == 0) {
        int p = static_cast<int>(std::strtol(argv[2], nullptr, 10));
        if (p < 4 || p > 22) {
            return 2;
        }
        return yoklama_kipi(p, argc - 3, argv + 3);
    }
    if (argc == 6 && std::strcmp(argv[1], "sure") == 0) {
        int p = static_cast<int>(std::strtol(argv[2], nullptr, 10));
        int tekrar = static_cast<int>(std::strtol(argv[4], nullptr, 10));
        if (p < 4 || p > 22 || tekrar < 1 || tekrar > 101) {
            return 2;
        }
        return sure_kipi(p, std::strtol(argv[3], nullptr, 10), tekrar,
                         argv[5]);
    }
    std::cerr << "kullanım: " << argv[0]
              << " yoklama P TOHUM... | sure P TOHUM TEKRAR CSV\n";
    return 2;
}

/* Kütüphane karşılığı: C — yok; C++ — std::unordered_map (bu dosyadaki
 * etiketli seri); Python — dict. */

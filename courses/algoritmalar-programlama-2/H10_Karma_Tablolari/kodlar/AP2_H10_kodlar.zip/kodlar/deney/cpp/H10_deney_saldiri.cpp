/* H10_deney_saldiri.cpp — AP-2 Hafta 10 · Haftanın Deneyi (b)
 * Amaç    : C sürümüyle aynı ölçüm (aynı anahtarlar, aynı karşılaştırma
 *           sayıları). Düğüm anahtarı C'deki gibi düğüm içinde sabit
 *           boyutlu dizi (std::array): iki dilin bellek düzeni aynı kalsın
 *           diye std::string (ayrı yığın ayırması) kullanılmadı.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_deney_saldiri.cpp -o H10_deney_saldiri
 * Çalıştır: ./H10_deney_saldiri KMIN KMAX TEKRAR CSV_DOSYASI
 */
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

/* CSV'deki derleme etiketi: sürücü -DDERLEME='"-O0"' biçiminde verir;
 * verilmezse __OPTIMIZE__ (GCC/Clang, -O1 ve üstü) makrosundan çıkarılır */
#ifndef DERLEME
#ifdef __OPTIMIZE__
#define DERLEME "-O2"
#else
#define DERLEME "-O0"
#endif
#endif

const std::size_t UZ = 33;
using Anahtar = std::array<char, UZ>;

enum { SALDIRI = 0, RASTGELE = 1, FNV_TOHUM = 2, TABAN_UST = 3 };
const char *SERI[4] = {"saldiri", "rastgele", "savunma_fnv",
                       "savunma_taban_ust"};

struct Dugum {
    std::uint32_t karma;
    Dugum *sonraki;
    Anahtar anahtar;             // düğüm içinde (tek ayırma)
};

static long long karsilastirma_sayisi = 0;
static std::uint32_t gizli_taban = 0;
static std::uint32_t gizli_tohum = 0;

static std::uint32_t karma(int seri, const char *s)
{
    std::uint32_t h;
    if (seri == SALDIRI || seri == RASTGELE) {
        h = 0;
        for (; *s != '\0'; s++) {
            h = 31u * h + static_cast<unsigned char>(*s);
        }
    } else if (seri == TABAN_UST) {
        h = 0;
        for (; *s != '\0'; s++) {
            h = gizli_taban * h + static_cast<unsigned char>(*s);
        }
    } else {
        h = 2166136261u ^ gizli_tohum;
        for (; *s != '\0'; s++) {
            h ^= static_cast<unsigned char>(*s);
            h *= 16777619u;
        }
    }
    return h;
}

static std::size_t indis(int seri, std::uint32_t h, int p)
{
    if (seri == TABAN_UST) {
        return (h * 2654435769u) >> (32 - p);
    }
    return h & ((std::uint32_t{1} << p) - 1u);
}

// Sahiplik: düğümler tablonundur; yıkıcı döngüyle siler (RAII)
struct Tablo {
    std::vector<Dugum *> kova = std::vector<Dugum *>(16, nullptr);
    int p = 4;
    std::size_t n = 0;
    int seri;
    explicit Tablo(int seri_) : seri(seri_) {}
    Tablo(const Tablo&) = delete;
    Tablo& operator=(const Tablo&) = delete;
    ~Tablo()
    {
        for (Dugum *d : kova) {
            while (d != nullptr) {
                Dugum *sonraki = d->sonraki;
                delete d;
                d = sonraki;
            }
        }
    }
};

static void buyut(Tablo& t)
{
    std::vector<Dugum *> yeni(2 * t.kova.size(), nullptr);
    for (Dugum *d : t.kova) {
        while (d != nullptr) {
            Dugum *sonraki = d->sonraki;
            std::size_t k = indis(t.seri, d->karma, t.p + 1);
            d->sonraki = yeni[k];
            yeni[k] = d;
            d = sonraki;
        }
    }
    t.kova.swap(yeni);
    t.p++;
}

static void ekle(Tablo& t, const Anahtar& a)
{
    std::uint32_t h = karma(t.seri, a.data());
    std::size_t j = indis(t.seri, h, t.p);
    for (Dugum *d = t.kova[j]; d != nullptr; d = d->sonraki) {
        karsilastirma_sayisi++;
        if (std::strcmp(d->anahtar.data(), a.data()) == 0) {
            return;
        }
    }
    t.kova[j] = new Dugum{h, t.kova[j], a};
    t.n++;
    if (t.n > t.kova.size()) {
        buyut(t);
    }
}

static void deneme(int seri, const std::vector<Anahtar>& anahtar)
{
    Tablo t(seri);
    for (const Anahtar& a : anahtar) {
        ekle(t, a);
    }
}

int main(int argc, char *argv[])
{
    if (argc != 5) {
        std::cerr << "kullanım: " << argv[0] << " KMIN KMAX TEKRAR CSV\n";
        return 2;
    }
    int kmin = static_cast<int>(std::strtol(argv[1], nullptr, 10));
    int kmax = static_cast<int>(std::strtol(argv[2], nullptr, 10));
    int tekrar = static_cast<int>(std::strtol(argv[3], nullptr, 10));
    if (kmin < 4 || kmax > 16 || kmin > kmax || tekrar < 1) {
        return 2;
    }
    std::ofstream csv(argv[4], std::ios::app);
    if (!csv) {
        return 1;
    }
    csv << std::fixed << std::setprecision(4);
    rastgele_tohum(2026);                    // Örnek 13 ile aynı gizliler
    gizli_taban = 2u * rastgele_sayi() + 1u;
    gizli_tohum = rastgele_sayi();
    std::cout << "seri;k;n;karsilastirma\n";
    for (int k = kmin; k <= kmax; k++) {
        std::size_t n = std::size_t{1} << k;
        std::vector<Anahtar> carpisan(n);
        std::vector<Anahtar> rastgele(n);
        rastgele_tohum(42);
        for (std::size_t i = 0; i < n; i++) {
            for (int b = 0; b < k; b++) {
                const char *blok = (i >> (k - 1 - b)) & 1u ? "BB" : "Aa";
                carpisan[i][2 * b] = blok[0];
                carpisan[i][2 * b + 1] = blok[1];
            }
            carpisan[i][2 * k] = '\0';
            for (int b = 0; b < 2 * k; b++) {
                int x = rastgele_aralik(0, 51);
                rastgele[i][b] = static_cast<char>(x < 26 ? 'A' + x
                                                          : 'a' + x - 26);
            }
            rastgele[i][2 * k] = '\0';
        }
        for (int seri = 0; seri < 4; seri++) {
            const std::vector<Anahtar>& a =
                seri == RASTGELE ? rastgele : carpisan;
            karsilastirma_sayisi = 0;
            deneme(seri, a);                 // ısınma + sayaç
            long long kar = karsilastirma_sayisi;
            std::vector<double> d;
            std::vector<double> c;
            for (int r = 0; r < tekrar; r++) {
                double t0 = zaman_sn();
                double c0 = islemci_sn();
                deneme(seri, a);
                c.push_back((islemci_sn() - c0) * 1e3);
                d.push_back((zaman_sn() - t0) * 1e3);
            }
            std::cout << SERI[seri] << ';' << k << ';' << n << ';' << kar
                      << std::endl;
            csv << "cpp;" DERLEME ";" << SERI[seri] << ';' << k << ';' << n
                << ';' << tekrar << ';' << ortanca(d) << ';' << ortanca(c) << ';'
                << kar << std::endl;
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::unordered_map<std::string, …>
 * (std::hash gerçekleştirime bağlı); Python — dict (tohumlu SipHash). */

#!/usr/bin/env python3
"""h10_olcum_calistir.py — AP-2 Hafta 10 · Haftanın Deneyi sürücüsü

Derler, çalıştırır ve ham sonuçları sonuclar/*.csv dosyalarına yazar:
  (a) h10_deney_yoklama.csv       α = 0,25…0,95; 7 tohum; m = 2^16 (C);
                                   C++ ve Python aynı sayıları üretmeli
      h10_deney_arama_suresi.csv  m = 2^20: doğrusal / zincirleme (C, C++),
                                   std::unordered_map (C++), dict (Python)
  (b) h10_deney_saldiri.csv       n = 2^8 … 2^16: saldırı, rastgele,
                                   savunmalar (C -O2 2^16'ya dek; C++ -O2
                                   2^15'e, C -O0 2^13'e dek; Python süre
                                   bütçeli)
  (c) h10_deney_kelime_sayaci.csv Örnek 7 ve kütüphane karşılıkları (atölye)
Ölçüm: 1 ısınma + 5 tekrar, ortanca; duvar saati ve işlemci zamanı.
Ortam bilgisi: OLCUM_ORTAMI.txt; denetimler: sonuclar/h10_denetim.json.
Kullanım: python3 h10_olcum_calistir.py      (≈ 4 dk)
Sonra   : python3 h10_cozumle.py ; python3 ../../gorseller/kaynak/
          h10_deney_grafik.py
"""
import datetime
import json
import os
import platform
import re
import resource
import shutil
import statistics
import subprocess
import sys
import tempfile
import time

KOK = os.path.dirname(os.path.abspath(__file__))
KODLAR = os.path.dirname(KOK)
SONUC = os.path.join(KOK, "sonuclar")
C = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]
TEKRAR = 5
TOHUMLAR = [str(t) for t in range(1, 8)]


def kabuk(komut, **kw):
    return subprocess.run(komut, capture_output=True, text=True, check=True,
                          **kw)


def derle(gecici):
    ikili = {}
    for ad in ("H10_deney_yuk_faktoru", "H10_deney_saldiri"):
        for bayrak in ("-O2", "-O0"):
            hedef = os.path.join(gecici, f"{ad}_c{bayrak}")
            p = kabuk(C + [bayrak, f'-DDERLEME="{bayrak}"',
                           os.path.join(KOK, "c", ad + ".c"),
                           os.path.join(KOK, "c", "ortak_rastgele.c"),
                           os.path.join(KOK, "c", "zamanlayici.c"),
                           "-o", hedef])
            assert not p.stderr.strip(), p.stderr
            ikili[(ad, "c", bayrak)] = hedef
        hedef = os.path.join(gecici, f"{ad}_cpp")
        p = kabuk(CPP + ["-O2", '-DDERLEME="-O2"',
                         "-I" + os.path.join(KOK, "cpp"),
                         os.path.join(KOK, "cpp", ad + ".cpp"), "-o", hedef])
        assert not p.stderr.strip(), p.stderr
        ikili[(ad, "cpp", "-O2")] = hedef
    for dil, klasor, uz, derleyici in (("c", "c", ".c", C),
                                      ("cpp", "cpp", ".cpp", CPP)):
        hedef = os.path.join(gecici, f"H10_07_{dil}")
        kaynak = [os.path.join(KODLAR, klasor, "H10_07_kelime_frekansi" + uz)]
        if dil == "c":
            kaynak.append(os.path.join(KODLAR, "c", "zamanlayici.c"))
        kabuk(derleyici + ["-O2"] + kaynak + ["-o", hedef])
        ikili[("H10_07", dil, "-O2")] = hedef
    hedef = os.path.join(gecici, "H10_K07_cpp")
    kabuk(CPP + ["-O2", "-I" + os.path.join(KODLAR, "cpp"),
                 os.path.join(KODLAR, "kavram",
                              "H10_K07_kutuphane_frekans.cpp"), "-o", hedef])
    ikili[("H10_K07", "cpp", "-O2")] = hedef
    return ikili


def py(ad):
    return [sys.executable, os.path.join(KOK, "python", ad + ".py")]


def ortam_metni(bas, son, yuk_once, yuk_sonra, sure, evreler):
    lscpu = kabuk(["lscpu"]).stdout
    model = re.search(r"Model name:\s*(.+)", lscpu)
    return "\n".join([
        "AP-2 Hafta 10 · Haftanın Deneyi — ölçüm ortamı",
        f"Tarih          : {bas:%Y-%m-%d %H:%M} – {son:%H:%M}",
        f"İşlemci        : {model.group(1).strip() if model else '?'}",
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine)",
        f"Yük ortalaması : önce {yuk_once} · sonra {yuk_sonra} "
        "(/proc/loadavg: 1, 5, 15 dk)",
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})",
        f"C derleyicisi  : {kabuk(['gcc', '--version']).stdout.splitlines()[0]}",
        f"C++ derleyicisi: {kabuk(['g++', '--version']).stdout.splitlines()[0]}",
        f"Python         : Python {platform.python_version()}",
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra -pedantic "
        "-O2 (saldırı deneyinde C ayrıca -O0)",
        f"Yöntem         : 1 ısınma + {TEKRAR} tekrar, ortanca; duvar saati "
        "ve işlemci zamanı birlikte kaydedildi",
        "Saat           : duvar C timespec_get, C++ steady_clock, Python "
        "time.perf_counter; işlemci C/C++ clock(), Python time.process_time",
        "Bellek         : en büyük alt sürecin tepe yerleşik belleği "
        f"{resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024:.0f}"
        " MB (getrusage RUSAGE_CHILDREN, ru_maxrss)",
        f"Toplam süre    : {sure:.1f} s (sürücünün duvar saati)",
        "Evre süreleri  : " + " · ".join(f"{a} {b:.1f} s" for a, b in evreler),
        "Not            : ölçüm sırasında makinede başka işler de çalışıyordu "
        "(yük ortalamasına bakınız);",
        "                 bu yüzden duvar saati ile işlemci zamanı arasında "
        "fark olabilir; çözümlemede işlemci zamanı kullanılır.",
        ""])


def main():
    os.makedirs(SONUC, exist_ok=True)
    bas = datetime.datetime.now()
    t0 = time.time()
    yuk_once = open("/proc/loadavg").read().split()[:3]
    gecici = tempfile.mkdtemp(prefix="h10_deney_")
    denetim = {}
    evreler = []
    t_evre = time.time()

    def evre(ad):
        nonlocal t_evre
        evreler.append((ad, time.time() - t_evre))
        t_evre = time.time()
    try:
        ikili = derle(gecici)
        evre("derleme")
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", LC_ALL="C.UTF-8")
        # (a1) yoklama sayıları
        yol = os.path.join(SONUC, "h10_deney_yoklama.csv")
        c16 = kabuk([ikili[("H10_deney_yuk_faktoru", "c", "-O2")], "yoklama",
                     "16"] + TOHUMLAR).stdout
        open(yol, "w", encoding="utf-8").write(c16)
        p16 = kabuk([ikili[("H10_deney_yuk_faktoru", "cpp", "-O2")],
                     "yoklama", "16"] + TOHUMLAR).stdout
        c13 = kabuk([ikili[("H10_deney_yuk_faktoru", "c", "-O2")], "yoklama",
                     "13", "1", "2"]).stdout
        y13 = kabuk(py("H10_deney_yuk_faktoru") + ["yoklama", "13", "1", "2"],
                    cwd=os.path.join(KOK, "python"), env=env).stdout
        denetim["yoklama_c_cpp_m2^16_ayni"] = c16 == p16
        denetim["yoklama_c_py_m2^13_ayni"] = c13 == y13
        print("(a1) yoklama: C = C++ (m = 2^16):", c16 == p16,
              "· C = Python (m = 2^13):", c13 == y13, flush=True)
        evre("(a1) yoklama")
        # (a2) arama süresi
        yol = os.path.join(SONUC, "h10_deney_arama_suresi.csv")
        open(yol, "w", encoding="utf-8").write(
            "dil;derleme;yapi;alfa_yuzde;n;m;tur;tekrar;ortanca_duvar_ms;"
            "ortanca_islemci_ms;ns_sorgu_islemci;bulunan\n")
        kabuk([ikili[("H10_deney_yuk_faktoru", "c", "-O2")], "sure", "20",
               "42", str(TEKRAR), yol])
        print("(a2) C bitti", flush=True)
        kabuk([ikili[("H10_deney_yuk_faktoru", "cpp", "-O2")], "sure", "20",
               "42", str(TEKRAR), yol])
        print("(a2) C++ bitti", flush=True)
        kabuk(py("H10_deney_yuk_faktoru") + ["sure", "20", "42", str(TEKRAR),
                                             yol, "25,55,75,90,95"],
              cwd=os.path.join(KOK, "python"), env=env)
        print("(a2) Python dict bitti", flush=True)
        evre("(a2) arama süresi")
        # (b) saldırı
        yol = os.path.join(SONUC, "h10_deney_saldiri.csv")
        open(yol, "w", encoding="utf-8").write(
            "dil;derleme;seri;k;n;tekrar;ortanca_duvar_ms;ortanca_islemci_ms;"
            "karsilastirma\n")
        sayac = {}
        for anahtar, kmax in ((("H10_deney_saldiri", "c", "-O2"), 16),
                              (("H10_deney_saldiri", "cpp", "-O2"), 15),
                              (("H10_deney_saldiri", "c", "-O0"), 13)):
            out = kabuk([ikili[anahtar], "8", str(kmax), str(TEKRAR),
                         yol]).stdout
            sayac[anahtar[1] + anahtar[2]] = out
            print("(b)", anahtar[1], anahtar[2], "bitti", flush=True)
        out = kabuk(py("H10_deney_saldiri") + ["8", "16", str(TEKRAR), yol,
                                               "12"],
                    cwd=os.path.join(KOK, "python"), env=env).stdout
        sayac["py"] = out
        print("(b) Python bitti", flush=True)
        evre("(b) saldırı")
        satir_c = set(sayac["c-O2"].splitlines())
        denetim["saldiri_c_cpp_alt_kume"] = set(
            sayac["cpp-O2"].splitlines()) <= satir_c
        denetim["saldiri_c_O0_alt_kume"] = set(
            sayac["c-O0"].splitlines()) <= satir_c
        denetim["saldiri_py_alt_kume"] = set(sayac["py"].splitlines()) <= \
            satir_c
        anahtarlar = [tuple(x.split(";")[:5]) for x in
                      open(yol, encoding="utf-8").read().splitlines()[1:]]
        denetim["saldiri_csv_tekil"] = len(anahtarlar) == len(set(anahtarlar))
        denetim["saldiri_csv_O0_var"] = any(a[1] == "-O0" for a in anahtarlar)
        # (c) kelime sayacı (atölye): programların kendi stderr süresi
        yol = os.path.join(SONUC, "h10_deney_kelime_sayaci.csv")
        girdi = open(os.path.join(KODLAR, "girdiler",
                                  "H10_07_kelime_frekansi.txt"), "rb").read()
        isler = [("c", "elle (Örnek 7)", [ikili[("H10_07", "c", "-O2")]]),
                 ("cpp", "elle (Örnek 7)", [ikili[("H10_07", "cpp", "-O2")]]),
                 ("cpp", "std::unordered_map (K07)",
                  [ikili[("H10_K07", "cpp", "-O2")]]),
                 ("py", "elle (Örnek 7)",
                  [sys.executable, os.path.join(KODLAR, "python",
                                                "H10_07_kelime_frekansi.py")]),
                 ("py", "dict (K07)",
                  [sys.executable, os.path.join(KODLAR, "kavram",
                                                "H10_K07_kutuphane_frekans.py")])]
        with open(yol, "w", encoding="utf-8") as f:
            f.write("dil;yontem;tekrar;ortanca_ms;en_az_ms;en_cok_ms\n")
            for dil, yontem, komut in isler:
                sureler = []
                for r in range(TEKRAR + 1):
                    p = subprocess.run(komut, input=girdi, capture_output=True,
                                       env=env, cwd=os.path.dirname(komut[-1]))
                    m = re.search(rb": ([0-9.]+) ms", p.stderr)
                    if r > 0:                # ilk çalıştırma ısınma
                        sureler.append(float(m.group(1)))
                f.write(f"{dil};{yontem};{TEKRAR};"
                        f"{statistics.median(sureler):.3f};"
                        f"{min(sureler):.3f};{max(sureler):.3f}\n")
        print("(c) kelime sayacı bitti", flush=True)
        evre("(c) kelime sayacı")
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    yuk_sonra = open("/proc/loadavg").read().split()[:3]
    sure = time.time() - t0
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(ortam_metni(bas, datetime.datetime.now(), " ".join(yuk_once),
                            " ".join(yuk_sonra), sure, evreler))
    with open(os.path.join(SONUC, "h10_denetim.json"), "w",
              encoding="utf-8") as f:
        json.dump(denetim, f, ensure_ascii=False, indent=1)
    print(json.dumps(denetim, ensure_ascii=False), f"süre {sure:.1f} s")
    return 0 if all(denetim.values()) else 1


if __name__ == "__main__":
    sys.exit(main())

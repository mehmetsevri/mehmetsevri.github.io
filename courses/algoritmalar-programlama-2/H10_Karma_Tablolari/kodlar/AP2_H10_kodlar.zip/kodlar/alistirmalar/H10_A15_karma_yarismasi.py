"""H10_A15_karma_yarismasi.py — AP-2 Hafta 10 · Atölye 1 (★★)
Amaç    : Karma fonksiyonu yarışması: ogrenci_karma'yı kendi
          fonksiyonunuzla değiştirin; 10^5 adın kova dağılımını ölçün
Çalıştır: python3 ../girdiler/ad_listesi_uret.py 100000 |
          python3 H10_A15_karma_yarismasi.py [m]   (varsayılan 100003)
Eşleri  : alistirmalar/H10_A15_karma_yarismasi.c
"""
import sys

MASKE32 = 0xFFFFFFFF


def ogrenci_karma(s):
    """YARIŞMA: bu fonksiyonu kendi fonksiyonunuzla değiştirin. Şimdilik
    baytların toplamı (kötü bir başlangıç: sıra bilgisi yok)."""
    h = 0
    for b in s:
        h = (h + b) & MASKE32
    return h


def karma_polinom(s):
    h = 0
    for b in s:
        h = (31 * h + b) & MASKE32
    return h


def karma_fnv1a(s):
    h = 2166136261
    for b in s:
        h ^= b
        h = (h * 16777619) & MASKE32
    return h


F = (("polinom", karma_polinom), ("FNV-1a", karma_fnv1a),
     ("kendi", ogrenci_karma))


def main():
    m = 100003
    if len(sys.argv) > 1:
        try:
            m = int(sys.argv[1])
        except ValueError:
            m = 0
        if not 2 <= m <= 1 << 24:
            print("kullanım: H10_A15_karma_yarismasi.py [m] (2 ≤ m ≤ 2^24)",
                  file=sys.stderr)
            sys.exit(2)
    adlar = sys.stdin.buffer.read().split(b"\n")
    if adlar and adlar[-1] == b"":
        adlar.pop()
    n = len(adlar)
    not_ = "  (m = 2^p: indis yalnız düşük bitler)" if m & (m - 1) == 0 \
        else ""
    print(f"n = {n} ad, m = {m} kova, α = {n / m:.3f}{not_}")
    print("  işlev     boş kova  en uzun  başarılı   χ²/(m−1)")
    for ad, f in F:
        k = [0] * m
        for s in adlar:
            k[f(s) % m] += 1
        bek = n / m
        ki = sum((c - bek) * (c - bek) / bek for c in k)
        bas = sum(c * (c + 1) / 2.0 for c in k)
        print(f"  {ad:<8} {k.count(0):9d} {max(k):8d} {bas / n:9.3f} "
              f"{ki / (m - 1):10.3f}")


if __name__ == "__main__":
    main()

/* H10_A07_hata_bul_buyutme.c — AP-2 Hafta 10 · Alıştırma 10.7 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: tablo büyüdükten sonra bazı anahtarlar
 * bulunamıyor. Hatalı satırı bulun, nedenini açıklayın ve düzeltin
 * (Örnek 6'nın buyut fonksiyonuyla karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_A07_hata_bul_buyutme.c -o H10_A07_hata_bul_buyutme
 * Çalıştır: ./H10_A07_hata_bul_buyutme
 */
#include <stdio.h>

#define EN_BUYUK 64

static int anahtar[EN_BUYUK];
static int dolu[EN_BUYUK];
static int m = 4;                        /* kapasite (2'nin kuvveti) */
static int n = 0;

static int yer(int k)                    /* k'nin hücresi ya da ilk BOŞ */
{
    int i = k & (m - 1);
    while (dolu[i] && anahtar[i] != k) {
        i = (i + 1) & (m - 1);
    }
    return i;
}

static void buyut(void)
{
    int eski_m = m;
    m = 2 * m;
    for (int i = eski_m; i < m; i++) {   /* yeni yarı boş başlar */
        dolu[i] = 0;
    }
    printf("büyütme: m %d -> %d\n", eski_m, m);
}

static void ekle(int k)
{
    if (4 * (n + 1) > 3 * m) {
        buyut();
    }
    int i = yer(k);
    if (!dolu[i]) {
        dolu[i] = 1;
        anahtar[i] = k;
        n++;
    }
    printf("ekle %2d -> hücre %d\n", k, i);
}

int main(void)
{
    const int k[] = {6, 10, 14, 7};
    for (int j = 0; j < 4; j++) {
        ekle(k[j]);
    }
    for (int j = 0; j < 4; j++) {
        int i = yer(k[j]);
        printf("ara %2d: %s\n", k[j], dolu[i] ? "bulundu" : "YOK");
    }
    return 0;
}

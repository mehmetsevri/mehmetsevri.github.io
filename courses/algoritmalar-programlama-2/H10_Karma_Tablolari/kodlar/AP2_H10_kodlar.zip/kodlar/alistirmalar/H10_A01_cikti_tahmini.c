/* H10_A01_cikti_tahmini.c — AP-2 Hafta 10 · Alıştırma 10.1 (★)
 * Amaç    : Doğrusal yoklama ve mezar taşı: çıktıyı çalıştırmadan tahmin
 *           edin, sonra derleyip karşılaştırın (m = 7, h(k) = k mod 7)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_A01_cikti_tahmini.c -o H10_A01_cikti_tahmini
 * Çalıştır: ./H10_A01_cikti_tahmini
 */
#include <stdio.h>

#define M 7
enum { BOS, DOLU, MEZAR };

static int durum[M];
static int anahtar[M];

/* k varsa hücresi (*var = 1), yoksa eklenecek yer: ilk mezar ya da BOŞ */
static int yer_bul(int k, int *yoklama, int *var)
{
    int i = k % M;
    int ilk_mezar = -1;
    *yoklama = 0;
    *var = 0;
    for (int adim = 0; adim < M; adim++) {
        (*yoklama)++;
        if (durum[i] == BOS) {
            return ilk_mezar >= 0 ? ilk_mezar : i;
        }
        if (durum[i] == MEZAR) {
            if (ilk_mezar < 0) {
                ilk_mezar = i;
            }
        } else if (anahtar[i] == k) {
            *var = 1;
            return i;
        }
        i = (i + 1) % M;
    }
    return ilk_mezar;
}

static void ekle(int k)
{
    int y, var;
    int i = yer_bul(k, &y, &var);
    if (!var && i >= 0) {
        durum[i] = DOLU;
        anahtar[i] = k;
    }
    printf("ekle %2d -> hücre %d (%d yoklama)\n", k, i, y);
}

int main(void)
{
    const int k[] = {10, 17, 3, 24, 31};
    for (int j = 0; j < 5; j++) {
        ekle(k[j]);
    }
    int y, var;
    int i = yer_bul(17, &y, &var);
    durum[i] = MEZAR;                    /* sil 17 */
    printf("sil 17 -> hücre %d MEZAR\n", i);
    i = yer_bul(24, &y, &var);
    printf("ara 24 -> %s, %d yoklama\n", var ? "var" : "yok", y);
    ekle(38);
    for (int j = 0; j < M; j++) {
        const char *ara = j + 1 < M ? " " : "\n";
        if (durum[j] == DOLU) {
            printf("[%d %d]%s", j, anahtar[j], ara);
        } else {
            printf("[%d %s]%s", j, durum[j] == MEZAR ? "M" : "-", ara);
        }
    }
    return 0;
}

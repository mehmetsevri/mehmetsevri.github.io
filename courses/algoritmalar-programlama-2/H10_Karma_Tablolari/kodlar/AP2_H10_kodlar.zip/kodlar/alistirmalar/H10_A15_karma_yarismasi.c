/* H10_A15_karma_yarismasi.c — AP-2 Hafta 10 · Atölye 1 (★★)
 * Amaç    : Karma fonksiyonu yarışması: ogrenci_karma'yı kendi
 *           fonksiyonunuzla değiştirin; 10^5 adın kova dağılımını ölçün
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_A15_karma_yarismasi.c -o H10_A15_karma_yarismasi
 * Çalıştır: python3 ../girdiler/ad_listesi_uret.py 100000 |
 *           ./H10_A15_karma_yarismasi [m]       (varsayılan m = 100003)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define F_SAYISI 4

/* YARIŞMA: bu fonksiyonu kendi fonksiyonunuzla değiştirin. Şimdilik
 * baytların toplamı (kötü bir başlangıç: sıra bilgisi yok). */
static uint32_t ogrenci_karma(const char *s)
{
    uint32_t h = 0;
    for (; *s != '\0'; s++) {
        h += (unsigned char)*s;
    }
    return h;
}

static uint32_t karma_polinom(const char *s)
{
    uint32_t h = 0;
    for (; *s != '\0'; s++) {
        h = 31u * h + (unsigned char)*s;
    }
    return h;
}

static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

static uint32_t karma(int f, const char *s)
{
    if (f == 0) {
        return karma_polinom(s);
    }
    return f == 1 ? karma_fnv1a(s) : ogrenci_karma(s);
}

static const char *F_AD[F_SAYISI] = {"polinom", "FNV-1a", "kendi", ""};

int main(int argc, char **argv)
{
    long m = 100003;
    if (argc > 1) {
        char *son;
        m = strtol(argv[1], &son, 10);
        if (*son != '\0' || m < 2 || m > (1L << 24)) {
            fprintf(stderr, "kullanım: %s [m] (2 ≤ m ≤ 2^24)\n", argv[0]);
            return 2;
        }
    }
    int *c = calloc((size_t)m * (F_SAYISI - 1), sizeof *c);
    if (c == NULL) {
        return 1;
    }
    char satir[256];
    long n = 0;
    while (fgets(satir, sizeof satir, stdin) != NULL) {
        satir[strcspn(satir, "\n")] = '\0';
        for (int f = 0; f < F_SAYISI - 1; f++) {
            c[(size_t)f * m + karma(f, satir) % (uint32_t)m]++;
        }
        n++;
    }
    printf("n = %ld ad, m = %ld kova, α = %.3f%s\n", n, m, (double)n / m,
           (m & (m - 1)) == 0 ? "  (m = 2^p: indis yalnız düşük bitler)"
                              : "");
    printf("  işlev     boş kova  en uzun  başarılı   χ²/(m−1)\n");
    for (int f = 0; f < F_SAYISI - 1; f++) {
        const int *k = c + (size_t)f * m;
        double bek = (double)n / m, ki = 0.0, bas = 0.0;
        long bos = 0;
        int uzun = 0;
        for (long j = 0; j < m; j++) {
            bos += k[j] == 0;
            uzun = k[j] > uzun ? k[j] : uzun;
            ki += (k[j] - bek) * (k[j] - bek) / bek;
            bas += k[j] * (k[j] + 1) / 2.0;
        }
        printf("  %-8s %9ld %8d %9.3f %10.3f\n", F_AD[f], bos, uzun,
               bas / n, ki / (m - 1));
    }
    free(c);
    return 0;
}

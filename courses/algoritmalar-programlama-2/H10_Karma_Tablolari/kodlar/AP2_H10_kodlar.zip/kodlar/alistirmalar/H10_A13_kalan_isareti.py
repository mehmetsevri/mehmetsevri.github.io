"""H10_A13_kalan_isareti.py — AP-2 Hafta 10 · Alıştırma 10.13 (★★)
Amaç    : Diller arası okuma: C eşiyle aynı kayan karma satırı
          (+ q YOK). Hangi dil kaç karma eşitliği bulur, neden?
Çalıştır: python3 H10_A13_kalan_isareti.py
Eşleri  : alistirmalar/H10_A13_kalan_isareti.c
"""


def main():
    t = "2359023141526739921"
    p = "31415"
    d, q, h, hp, ht = 10, 13, 1, 0, 0
    n, m = len(t), len(p)
    for _ in range(1, m):
        h = h * d % q
    for i in range(m):
        hp = (d * hp + int(p[i])) % q
        ht = (d * ht + int(t[i])) % q
    esit = 0
    for s in range(n - m + 1):
        if ht == hp:
            esit += 1
        if s + m < n:
            ht = (d * (ht - int(t[s]) * h) + int(t[s + m])) % q
    print("karma eşitliği:", esit)


if __name__ == "__main__":
    main()

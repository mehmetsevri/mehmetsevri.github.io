/* H10_A09_parsons_zincir_sil.c — AP-2 Hafta 10 · Alıştırma 10.9 (★★)
 * Parsons: tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar ayrı
 * zincirlemede Dugum ** ile silme fonksiyonunun KARIŞTIRILMIŞ satırlarıdır
 * (iki satır fazladır: kullanılmayacak). Doğru sıraya dizin, girintiyi
 * düzeltin; Örnek 3'ün baştaki, ortadaki ve sondaki silmeleri çalışmalı.
 */
        bag = &(*bag)->sonraki;
    return 0;
            free(silinen);
static int tablo_sil(Tablo *t, const char *anahtar)
            *bag = silinen->sonraki;
        bag = (*bag)->sonraki;
    while (*bag != NULL) {
            Dugum *silinen = *bag;
            return 1;
        if (strcmp((*bag)->anahtar, anahtar) == 0) {
    Dugum **bag = &t->kova[kova_no(t, anahtar)];
            free(silinen->anahtar);
        }
            free(*bag);
    }
{
}

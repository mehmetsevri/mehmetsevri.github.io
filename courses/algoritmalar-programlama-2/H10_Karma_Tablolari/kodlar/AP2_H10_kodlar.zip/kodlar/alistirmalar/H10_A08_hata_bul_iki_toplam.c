/* H10_A08_hata_bul_iki_toplam.c — AP-2 Hafta 10 · Alıştırma 10.8 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: iki toplamın karma çözümü, a[i] + a[j] = T
 * için i ≠ j olan bir çift aramalı; bu program bazı girdilerde yanlış çift
 * bildiriyor. Hatayı bulun ve iki satırın yerini değiştirerek düzeltin
 * (Örnek 8'in iki_toplam_karma fonksiyonu).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_A08_hata_bul_iki_toplam.c -o H10_A08_hata_bul_iki_toplam
 */
#include <stdio.h>

#define EVREN 100                        /* değerler 0..99 */

/* konum[v] = v'nin ilk görüldüğü indis + 1 (0: görülmedi) */
static int iki_toplam(const int *a, int n, int T, int *bi, int *bj)
{
    int konum[EVREN] = {0};
    for (int j = 0; j < n; j++) {
        if (konum[a[j]] == 0) {
            konum[a[j]] = j + 1;
        }
        int tumleyen = T - a[j];
        if (tumleyen >= 0 && tumleyen < EVREN && konum[tumleyen] != 0) {
            *bi = konum[tumleyen] - 1;
            *bj = j;
            return 1;
        }
    }
    return 0;
}

static void dene(const int *a, int n, int T)
{
    int i, j;
    if (iki_toplam(a, n, T, &i, &j)) {
        printf("T = %2d: (%d, %d) -> %d + %d\n", T, i, j, a[i], a[j]);
    } else {
        printf("T = %2d: çift yok\n", T);
    }
}

int main(void)
{
    const int a[] = {3, 8, 5, 1, 9};
    dene(a, 5, 9);
    dene(a, 5, 6);
    dene(a, 5, 16);
    return 0;
}

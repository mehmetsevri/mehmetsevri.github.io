/* H10_A13_kalan_isareti.c — AP-2 Hafta 10 · Alıştırma 10.13 (★★)
 * Amaç    : Diller arası okuma: Python eşiyle aynı kayan karma satırı
 *           (+ q YOK). Hangi dil kaç karma eşitliği bulur, neden?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_A13_kalan_isareti.c -o H10_A13_kalan_isareti
 * Eşleri  : alistirmalar/H10_A13_kalan_isareti.py
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    const char *t = "2359023141526739921";
    const char *p = "31415";
    long long d = 10, q = 13, h = 1, hp = 0, ht = 0;
    size_t n = strlen(t), m = strlen(p);
    for (size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    for (size_t i = 0; i < m; i++) {
        hp = (d * hp + (p[i] - '0')) % q;
        ht = (d * ht + (t[i] - '0')) % q;
    }
    int esit = 0;
    for (size_t s = 0; s + m <= n; s++) {
        if (ht == hp) {
            esit++;
        }
        if (s + m < n) {
            ht = (d * (ht - (t[s] - '0') * h) + (t[s + m] - '0')) % q;
        }
    }
    printf("karma eşitliği: %d\n", esit);
    return 0;
}

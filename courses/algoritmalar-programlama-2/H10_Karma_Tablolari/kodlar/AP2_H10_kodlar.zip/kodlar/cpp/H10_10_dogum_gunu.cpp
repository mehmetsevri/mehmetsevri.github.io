/* H10_10_dogum_gunu.cpp — AP-2 Hafta 10 · Örnek 10 (★★)
 * Amaç    : Doğum günü paradoksu: n kişide en az bir ortak doğum günü
 *           olasılığı (kesin formül, n = 1..60; 23 kişide ≈ 0,507), ortak
 *           LCG ile Monte Carlo karşılaştırması; karma bağlantısı: m kovaya
 *           ilk çakışmaya kadar beklenen anahtar sayısı, %50 eşiği
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_10_dogum_gunu.cpp -o H10_10_dogum_gunu
 * Çalıştır: ./H10_10_dogum_gunu
 * Eşleri  : c/H10_10_dogum_gunu.c · python/H10_10_dogum_gunu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const int GUN = 365;
const int DENEME = 5000;

// P(n) = 1 − Π_{k=0}^{n-1} (m − k)/m ; çarpım soldan sağa, üç dilde aynı
static std::vector<double> kesin_tablo(int n_ust, long long m)
{
    std::vector<double> p(n_ust + 1, 0.0);
    double q = 1.0;                          // çakışma yok olasılığı
    for (int n = 1; n <= n_ust; n++) {
        q = q * (static_cast<double>(m - (n - 1)) / static_cast<double>(m));
        p[n] = 1.0 - q;
    }
    return p;
}

// Bir deneme: n doğum günü çek; ilk tekrar görülürse true. gorulen =
// doğrudan adresleme; damga = deneme numarası (diziyi sıfırlamadan)
static bool deneme_yap(int n, std::vector<int>& gorulen, int damga)
{
    for (int k = 0; k < n; k++) {
        int g = rastgele_aralik(0, GUN - 1);
        if (gorulen[g] == damga) {
            return true;
        }
        gorulen[g] = damga;
    }
    return false;
}

// m kova: %50 eşiğini geçen en küçük n ve ilk çakışmanın beklenen sırası
// E = Σ_{k≥0} P(ilk k anahtarda çakışma yok)
static void esik_satiri(const std::string& ad, long long m)
{
    double q = 1.0;
    double beklenen = 1.0;                   // k = 0 terimi
    long long esik = 0;
    for (long long k = 1; k <= m && q > 1e-18; k++) {
        beklenen += q;                       // q = P(ilk k'da yok)
        q = q * (static_cast<double>(m - k) / static_cast<double>(m));
        if (esik == 0 && 1.0 - q >= 0.5) {
            esik = k + 1;
        }
    }
    std::cout << "  " << std::setw(14) << m << ' ' << std::setw(10) << esik
              << ' ' << std::fixed << std::setprecision(3) << std::setw(12)
              << beklenen << ' ' << std::setw(12)
              << std::sqrt(3.14159265358979323846 *
                           static_cast<double>(m) / 2.0)
              << "   " << ad << '\n';
}

int main()
{
    std::vector<double> p = kesin_tablo(60, GUN);

    std::cout << "1) Kesin olasılık: P(n) = 1 − (365/365)(364/365)…"
                 "((365−n+1)/365)\n"
              << std::fixed << std::setprecision(6);
    for (int r = 1; r <= 20; r++) {
        std::cout << "  n = " << std::setw(2) << r << ": " << p[r]
                  << "   n = " << std::setw(2) << r + 20 << ": " << p[r + 20]
                  << "   n = " << std::setw(2) << r + 40 << ": " << p[r + 40]
                  << '\n';
    }
    int esik = 1;
    while (p[esik] < 0.5) {
        esik++;
    }
    std::cout << std::setprecision(4) << "  P ≥ 0,5 olan en küçük n = "
              << esik << " (P = " << p[esik] << "); n = 57'de " << p[57]
              << '\n';

    std::cout << "\n2) Monte Carlo (ortak LCG, tohum 42, " << DENEME
              << " deneme / satır)\n"
              << "     n   kesin   tahmin    fark\n";
    std::vector<int> gorulen(GUN, 0);
    rastgele_tohum(42);
    int damga = 0;
    for (int n : {10, 20, 23, 30, 40, 50, 60}) {
        int cakisan = 0;
        for (int d = 0; d < DENEME; d++) {
            cakisan += deneme_yap(n, gorulen, ++damga);
        }
        double tahmin = static_cast<double>(cakisan) / DENEME;
        std::cout << "  " << std::setw(4) << n << ' ' << std::setw(7) << p[n]
                  << ' ' << std::setw(8) << tahmin << ' ' << std::showpos
                  << std::setw(7) << tahmin - p[n] << std::noshowpos << '\n';
    }

    std::cout << "\n3) Karma bağlantısı: m kova, düzgün karma — ilk çakışma "
                 "ne zaman?\n"
              << "               m   %50 eşiği  E[ilk çakışma]  √(πm/2)   "
                 "yorum\n";
    esik_satiri("yılın günleri", 365);
    esik_satiri("bin kovalı tablo", 1000);
    esik_satiri("milyon kovalı tablo", 1000000);
    esik_satiri("32 bit karma değerleri", 4294967296LL);
    long long toplam = 0;
    for (int d = 0; d < DENEME; d++) {
        ++damga;
        int k = 0;
        for (;;) {
            int g = rastgele_aralik(0, GUN - 1);
            k++;
            if (gorulen[g] == damga) {
                break;
            }
            gorulen[g] = damga;
        }
        toplam += k;
    }
    std::cout << "  m = 365, Monte Carlo: ilk çakışmanın ortalama sırası = "
              << std::setprecision(3)
              << static_cast<double>(toplam) / DENEME << " (" << DENEME
              << " deneme)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::unordered_set
 * ile görülen günler tutulabilir); Python — set (ya da
 * math.prod / math.perm ile kesin formül). */

/* H10_11_naif_eslesme.cpp — AP-2 Hafta 10 · Örnek 11 (★)
 * Amaç    : Naif (kaba kuvvet) desen eşleme: her kayma s için deseni
 *           soldan sağa karşılaştır; karşılaştırma sayacı; rastgele metinde
 *           ≈ n, en kötü durumda (aaaa…a / aa…ab) (n − m + 1)·m;
 *           kâhin: std::string::find döngüsü
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_11_naif_eslesme.cpp -o H10_11_naif_eslesme
 * Çalıştır: ./H10_11_naif_eslesme
 * Eşleri  : c/H10_11_naif_eslesme.c · python/H10_11_naif_eslesme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const std::size_t EN_COK = 10;           // yazdırılacak en çok konum

static long long karsilastirma_sayisi = 0;

// t içinde p'nin tüm konumları (eşleşme sırasıyla)
static std::vector<std::size_t> naif_ara(const std::string& t,
                                         const std::string& p)
{
    std::vector<std::size_t> konum;
    std::size_t n = t.size();
    std::size_t m = p.size();
    if (m == 0 || m > n) {
        return konum;
    }
    for (std::size_t s = 0; s + m <= n; s++) {   // s: kayma (shift)
        std::size_t j = 0;
        while (j < m) {
            karsilastirma_sayisi++;
            if (t[s + j] != p[j]) {
                break;                       // ilk uyuşmazlıkta bırak
            }
            j++;
        }
        if (j == m) {
            konum.push_back(s);
        }
    }
    return konum;
}

// Kâhin: std::string::find ile aynı konumlar (çakışan eşleşmeler dahil)
static std::vector<std::size_t> kahin_ara(const std::string& t,
                                          const std::string& p)
{
    std::vector<std::size_t> konum;
    for (std::size_t q = t.find(p); q != std::string::npos;
         q = t.find(p, q + 1)) {
        konum.push_back(q);
    }
    return konum;
}

// UTF-8: devam baytları 10xxxxxx'tir; karakter = devam olmayan bayt
static std::size_t karakter_konumu(const std::string& t, std::size_t bayt)
{
    std::size_t c = 0;
    for (std::size_t i = 0; i < bayt; i++) {
        c += (static_cast<unsigned char>(t[i]) & 0xC0) != 0x80;
    }
    return c;
}

static void sinama(const std::string& ad, const std::string& t,
                   const std::string& p)
{
    karsilastirma_sayisi = 0;
    std::vector<std::size_t> k1 = naif_ara(t, p);
    std::vector<std::size_t> k2 = kahin_ara(t, p);
    long long kayma = static_cast<long long>(t.size() - p.size() + 1);
    std::cout << "  " << ad << ": n = " << t.size() << ", m = " << p.size()
              << ", eşleşme = " << k1.size() << ", karşılaştırma = "
              << karsilastirma_sayisi << " (kayma başına " << std::fixed
              << std::setprecision(3)
              << static_cast<double>(karsilastirma_sayisi) / kayma
              << "), kâhinle aynı mı? " << (k1 == k2 ? "evet" : "HAYIR")
              << "\n    konumlar:";
    for (std::size_t i = 0; i < k1.size() && i < EN_COK; i++) {
        std::cout << ' ' << k1[i];
    }
    std::cout << (k1.size() > EN_COK ? " …\n" : "\n");
}

int main()
{
    std::cout << "1) Küçük örnek: t = \"abracadabra\", p = \"abra\"\n";
    const std::string t = "abracadabra";
    const std::string p = "abra";
    std::size_t m = p.size();
    for (std::size_t s = 0; s + m <= t.size(); s++) {
        std::size_t j = 0;
        while (j < m && t[s + j] == p[j]) {
            j++;
        }
        std::cout << "  s = " << s << ": " << t.substr(s, m) << "  ";
        if (j == m) {
            std::cout << "EŞLEŞME (" << m << " karşılaştırma)\n";
        } else {
            std::cout << "uyuşmazlık (j = " << j << "; " << j + 1
                      << " karşılaştırma)\n";
        }
    }
    sinama("abracadabra", t, p);

    std::cout << "\n2) Bayt düzeyinde: konum karakter değil BAYT "
                 "sayısıdır\n";
    const std::string tr = "Koca Ali, kılıç ustası Ali'ydi.";
    sinama("Türkçe tümce", tr, "Ali");
    for (std::size_t b : naif_ara(tr, "Ali")) {
        std::cout << "    bayt " << std::setw(2) << b << " = karakter "
                  << std::setw(2) << karakter_konumu(tr, b) << '\n';
    }
    std::cout << "    (\"kılıç\" 5 harf ama " << std::string("kılıç").size()
              << " bayt: ı ve ç UTF-8'de ikişer bayt)\n";

    std::cout << "\n3) Rastgele metin (abece {a, b, c, d}, tohum 42) ve en "
                 "kötü durum\n";
    const std::size_t N = 100000;
    std::string metin(N, ' ');
    rastgele_tohum(42);
    for (std::size_t i = 0; i < N; i++) {
        metin[i] = static_cast<char>('a' + rastgele_aralik(0, 3));
    }
    sinama("rastgele, m = 8", metin, metin.substr(50000, 8));
    sinama("rastgele, m = 3", metin, metin.substr(70000, 3));

    const std::size_t N2 = 10000;
    const std::string a_n(N2, 'a');
    sinama("en kötü: a^n, a^99 b", a_n, std::string(99, 'a') + "b");
    sinama("en kötü: a^n, a^100", a_n, std::string(100, 'a'));
    std::cout << "  (en kötü durumda karşılaştırma = (n − m + 1)·m = "
              << (N2 - 100 + 1) * 100
              << "; rastgele metinde ≈ 4/3 · kayma)\n";
    return 0;
}

/* Kütüphane karşılığı: C — strstr (<string.h>; algoritması
 * gerçekleştirime bağlı); C++ — std::string::find, std::search
 * (C++17: std::boyer_moore_searcher); Python — str.find / bytes.find,
 * in işleci. */

/* H10_02_karma_fonksiyonlari.cpp — AP-2 Hafta 10 · Örnek 2 (★★)
 * Amaç    : Dizgi karma fonksiyonları: toplam (kötü), polinom (Horner,
 *           taban 31) ve FNV-1a (32 bit); 10 000 adın m kovaya dağılımı:
 *           boş kova, en uzun kova, ortalama zincir, χ² ölçütü, histogram
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_02_karma_fonksiyonlari.cpp -o H10_02_karma_fonksiyonlari
 * Çalıştır: ./H10_02_karma_fonksiyonlari \
 *           < ../girdiler/H10_02_karma_fonksiyonlari.txt
 * Eşleri  : c/H10_02_karma_fonksiyonlari.c ·
 *           python/H10_02_karma_fonksiyonlari.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

const int F_SAYISI = 3;

static const char *F_AD[F_SAYISI] = {"toplam", "polinom", "FNV-1a"};

// Toplam: baytların toplamı — harflerin SIRASINI hiç görmez (kötü)
static std::uint32_t karma_toplam(const std::string& s)
{
    std::uint32_t h = 0;
    for (unsigned char b : s) {
        h += b;
    }
    return h;
}

// Polinom (Horner, taban 31): h = 31·h + bayt; uint32_t mod 2^32 sarar
static std::uint32_t karma_polinom(const std::string& s)
{
    std::uint32_t h = 0;
    for (unsigned char b : s) {
        h = 31u * h + b;
    }
    return h;
}

// FNV-1a 32 bit (Fowler, Noll, Vo): önce XOR, sonra FNV asalıyla çarp
static std::uint32_t karma_fnv1a(const std::string& s)
{
    std::uint32_t h = 2166136261u;      // FNV başlangıç değeri
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;                 // FNV asalı (2^24 + 2^8 + 0x93)
    }
    return h;
}

static std::uint32_t karma(int f, const std::string& s)
{
    if (f == 0) {
        return karma_toplam(s);
    }
    return f == 1 ? karma_polinom(s) : karma_fnv1a(s);
}

// Dağılım ölçütleri: c[0..m-1] kova doluluğu, n anahtar
static void olcut_satiri(int f, const std::vector<int>& c, int n)
{
    int m = static_cast<int>(c.size());
    double beklenen = static_cast<double>(n) / m;   // α = n / m
    int bos = 0;
    int en_uzun = 0;
    double ki_kare = 0.0;
    double basarili = 0.0;              // Σ c(c + 1) / 2
    for (int j = 0; j < m; j++) {
        bos += c[j] == 0;
        if (c[j] > en_uzun) {
            en_uzun = c[j];
        }
        double fark = c[j] - beklenen;
        ki_kare += fark * fark / beklenen;
        basarili += c[j] * (c[j] + 1) / 2.0;
    }
    std::cout << "  " << std::left << std::setw(8) << F_AD[f] << std::right
              << ' ' << std::setw(8) << bos << ' ' << std::setw(8)
              << en_uzun << std::fixed << std::setprecision(3) << ' '
              << std::setw(10) << static_cast<double>(n) / (m - bos) << ' '
              << std::setw(10) << basarili / n << ' ' << std::setprecision(1)
              << std::setw(12) << ki_kare << ' ' << std::setprecision(3)
              << std::setw(8) << ki_kare / (m - 1) << '\n';
}

static void kuram_satiri(int m, int n)
{
    double alfa = static_cast<double>(n) / m;
    double bos = m * std::exp(-alfa);
    std::cout << "  düzgün   " << std::fixed << std::setprecision(1)
              << std::setw(8) << bos << ' ' << std::setw(8) << "-" << ' '
              << std::setprecision(3) << std::setw(10) << n / (m - bos)
              << ' ' << std::setw(10) << 1.0 + alfa / 2.0 << ' '
              << std::setprecision(1) << std::setw(12)
              << static_cast<double>(m - 1) << ' ' << std::setprecision(3)
              << std::setw(8) << 1.0 << '\n';
}

// Histogram verisi: kaç kovada tam k anahtar var? + Poisson beklentisi
static void histogram(const std::vector<std::vector<int>>& c, int n)
{
    int m = static_cast<int>(c[0].size());
    int en_uzun = 0;
    for (int f = 0; f < F_SAYISI; f++) {
        for (int j = 0; j < m; j++) {
            if (c[f][j] > en_uzun) {
                en_uzun = c[f][j];
            }
        }
    }
    std::vector<std::vector<int>> sayi(en_uzun + 1,
                                       std::vector<int>(F_SAYISI, 0));
    for (int f = 0; f < F_SAYISI; f++) {
        for (int j = 0; j < m; j++) {
            sayi[c[f][j]][f]++;
        }
    }
    double alfa = static_cast<double>(n) / m;
    double p = std::exp(-alfa);         // P(k) = e^-α α^k / k!
    std::cout << "     k   toplam  polinom   FNV-1a  Poisson(m·P(k))\n";
    for (int k = 0; k <= en_uzun; k++) {
        if (k > 0) {
            p = p * alfa / k;
        }
        std::cout << "  " << std::setw(4) << k << ' ' << std::setw(8)
                  << sayi[k][0] << ' ' << std::setw(8) << sayi[k][1] << ' '
                  << std::setw(8) << sayi[k][2] << ' ' << std::fixed
                  << std::setprecision(1) << std::setw(16) << m * p << '\n';
    }
}

int main()
{
    const int m_deger[2] = {1009, 10007};       // iki asal kova sayısı
    std::vector<std::vector<std::vector<int>>> c(2);
    for (int t = 0; t < 2; t++) {
        c[t].assign(F_SAYISI, std::vector<int>(m_deger[t], 0));
    }
    std::cout << "1) Üç karma fonksiyonu (UTF-8 baytları, 32 bit işaretsiz)\n"
              << "  toplam : h = h + b                         (mod 2^32)\n"
              << "  polinom: h = 31·h + b (Horner)             (mod 2^32)\n"
              << "  FNV-1a : h = (h XOR b)·16777619, h0 = 2166136261 "
                 "(mod 2^32)\n"
              << "      toplam     polinom      FNV-1a bayt  ad\n";

    std::string satir;
    int n = 0;
    std::uint32_t en_az = UINT32_MAX;
    std::uint32_t en_cok = 0;
    while (std::getline(std::cin, satir)) {
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (satir.empty()) {
            continue;
        }
        std::uint32_t h[F_SAYISI];
        for (int f = 0; f < F_SAYISI; f++) {
            h[f] = karma(f, satir);
            for (int t = 0; t < 2; t++) {
                c[t][f][h[f] % static_cast<std::uint32_t>(m_deger[t])]++;
            }
        }
        if (h[0] < en_az) {
            en_az = h[0];
        }
        if (h[0] > en_cok) {
            en_cok = h[0];
        }
        if (n < 5) {
            std::cout << "  " << std::setw(10) << h[0] << "  "
                      << std::setw(10) << h[1] << "  " << std::setw(10)
                      << h[2] << ' ' << std::setw(4) << satir.size() << "  "
                      << satir << '\n';
        }
        n++;
    }
    std::cout << "  ... toplam " << n << " ad; toplam karmanın aralığı "
              << "yalnızca [" << en_az << ", " << en_cok << "]\n";

    std::cout << "\n2) Toplam karmanın zayıflığı: baytların sırası önemsiz\n";
    const std::vector<std::string> ornek = {"Ali Can", "Can Ali", "Nil Aca",
                                            "ali can"};
    for (const std::string& s : ornek) {
        std::cout << "  toplam = " << std::setw(5) << karma_toplam(s)
                  << "  polinom = " << std::setw(10) << karma_polinom(s)
                  << "  FNV-1a = " << std::setw(10) << karma_fnv1a(s)
                  << "  \"" << s << "\"\n";
    }

    std::cout << "\n3) Kovalara dağılım: indis = h mod m\n"
              << "  χ² = Σ (c_j − n/m)² / (n/m)   (j = 0..m−1; düzgün "
                 "dağılımda ≈ m − 1)\n"
              << "  başarılı arama ort. = Σ c_j (c_j + 1) / 2 / n   "
                 "(düzgünde ≈ 1 + α/2)\n";
    for (int t = 0; t < 2; t++) {
        std::cout << "\n  n = " << n << ", m = " << m_deger[t] << ", α = "
                  << std::fixed << std::setprecision(3)
                  << static_cast<double>(n) / m_deger[t] << '\n'
                  << "  işlev    boş kova  en uzun  dolu/kova  başarılı "
                     "          χ²  χ²/(m−1)\n";
        for (int f = 0; f < F_SAYISI; f++) {
            olcut_satiri(f, c[t][f], n);
        }
        kuram_satiri(m_deger[t], n);
    }

    std::cout << "\n4) Histogram verisi (m = " << m_deger[1]
              << "): k anahtarlı kova sayısı\n";
    histogram(c[1], n);
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX hsearch kendi karma fonksiyonunu
 * kullanır); C++ — std::hash<std::string> (değeri gerçekleştirime
 * bağlı); Python — hash(s) (SipHash ailesi, tohumlu; PEP 456,
 * PYTHONHASHSEED — bkz. Dil Penceresi kavram programı). */

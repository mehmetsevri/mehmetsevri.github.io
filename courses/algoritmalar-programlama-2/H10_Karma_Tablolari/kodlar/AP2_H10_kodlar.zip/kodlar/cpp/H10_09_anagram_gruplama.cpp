/* H10_09_anagram_gruplama.cpp — AP-2 Hafta 10 · Örnek 9 (★★)
 * Amaç    : Anagram gruplama: anahtar tasarımı — sözcüğün baytları sayma
 *           sıralamasıyla (H7) sıralanır; aynı anahtar = aynı harfler.
 *           Zincirleme karma tablosu: anahtar → grup (üye listesi)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_09_anagram_gruplama.cpp -o H10_09_anagram_gruplama
 * Çalıştır: ./H10_09_anagram_gruplama \
 *           < ../girdiler/H10_09_anagram_gruplama.txt
 * Eşleri  : c/H10_09_anagram_gruplama.c ·
 *           python/H10_09_anagram_gruplama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

const std::size_t M = 31;        // kova sayısı (asal)

struct Grup {
    std::string anahtar;         // sıralanmış baytlar
    std::vector<std::string> uyeler;
    Grup *sonraki;               // aynı kovadaki sonraki grup
};

static long long karsilastirma_sayisi = 0;

// Sahiplik: gruplar tablonundur; yıkıcı zincirleri döngüyle siler (RAII)
struct Tablo {
    std::vector<Grup *> kova = std::vector<Grup *>(M, nullptr);
    Tablo() = default;
    Tablo(const Tablo&) = delete;
    Tablo& operator=(const Tablo&) = delete;
    ~Tablo()
    {
        for (Grup *g : kova) {
            while (g != nullptr) {
                Grup *sonraki = g->sonraki;
                delete g;
                g = sonraki;
            }
        }
    }
};

static std::uint32_t karma_fnv1a(const std::string& s)
{
    std::uint32_t h = 2166136261u;
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

// Anahtar: baytların sayma sıralaması (256 sayaç; Θ(L + 256))
static std::string anahtar_yap(const std::string& sozcuk)
{
    int sayac[256] = {0};
    for (unsigned char b : sozcuk) {
        sayac[b]++;
    }
    std::string anahtar;
    for (int b = 1; b < 256; b++) {
        anahtar.append(static_cast<std::size_t>(sayac[b]),
                       static_cast<char>(b));
    }
    return anahtar;
}

static void baytlari_yaz(const std::string& s)
{
    const char *rakam = "0123456789abcdef";
    for (unsigned char b : s) {
        std::cout << ' ' << rakam[b >> 4] << rakam[b & 0xF];
    }
}

// Sözcüğü grubuna ekler (grup yoksa oluşturur)
static void grupla(Tablo& t, const std::string& sozcuk)
{
    std::string anahtar = anahtar_yap(sozcuk);
    std::size_t j = karma_fnv1a(anahtar) % M;
    Grup *g = t.kova[j];
    while (g != nullptr) {
        karsilastirma_sayisi++;
        if (g->anahtar == anahtar) {
            break;
        }
        g = g->sonraki;
    }
    if (g == nullptr) {
        g = new Grup{anahtar, {}, t.kova[j]};
        t.kova[j] = g;
    }
    g->uyeler.push_back(sozcuk);
}

int main()
{
    Tablo t;
    std::string satir;
    int sozcuk_sayisi = 0;

    std::cout << "1) Anahtar tasarımı: baytlar sayma sıralamasıyla "
                 "sıralanır\n";
    for (const std::string& s : {std::string("kitap"), std::string("takip"),
                                 std::string("kış")}) {
        std::cout << "  " << s << ": bayt";
        baytlari_yaz(s);
        std::cout << " -> anahtar";
        baytlari_yaz(anahtar_yap(s));
        std::cout << '\n';
    }
    std::cout << "  (kitap ve takip aynı anahtar: \"aikpt\"; \"kış\" "
                 "anahtarında UTF-8 baytları ayrıştı:\n   anahtar yalnız "
                 "eşitlik içindir, metin olarak yazdırılmaz)\n";

    while (std::getline(std::cin, satir)) {
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (satir.empty()) {
            continue;
        }
        grupla(t, satir);
        sozcuk_sayisi++;
    }

    // Çıktı biçimi için sıralama (kâhin değil): üyeler ve gruplar
    std::vector<std::vector<std::string>> gruplar;
    std::vector<std::string> tekiller;
    for (const Grup *bas : t.kova) {
        for (const Grup *g = bas; g != nullptr; g = g->sonraki) {
            std::vector<std::string> u = g->uyeler;
            std::sort(u.begin(), u.end());
            if (u.size() >= 2) {
                gruplar.push_back(u);
            } else {
                tekiller.push_back(u[0]);
            }
        }
    }
    std::sort(gruplar.begin(), gruplar.end(),
              [](const std::vector<std::string>& a,
                 const std::vector<std::string>& b) { return a[0] < b[0]; });
    std::sort(tekiller.begin(), tekiller.end());

    std::cout << "\n2) " << sozcuk_sayisi << " sözcük -> anagram grupları "
              << "(≥ 2 üye; gruplar ilk üyeye, üyeler bayt sırasına göre)\n";
    for (std::size_t r = 0; r < gruplar.size(); r++) {
        std::cout << "  " << std::setw(2) << r + 1 << ". ("
                  << gruplar[r].size() << ')';
        for (const std::string& s : gruplar[r]) {
            std::cout << ' ' << s;
        }
        std::cout << '\n';
    }
    std::cout << "  tek üyeli: " << tekiller.size() << " sözcük:";
    for (const std::string& s : tekiller) {
        std::cout << ' ' << s;
    }
    std::cout << '\n'
              << "  anahtar karşılaştırması = " << karsilastirma_sayisi
              << " (m = " << M << " kova)\n"
              << "  (bayt sırası: \"maç\" < \"çam\", çünkü 'm' = 0x6d < "
                 "0xc3 = 'ç'nin ilk baytı)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; çıktı biçimi için qsort); C++ —
 * std::unordered_map<std::string, std::vector<std::string>> + std::sort;
 * Python — dict + sorted(w) (anahtar: bytes(sorted(w)) ya da tuple). */

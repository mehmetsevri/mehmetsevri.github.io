/* H10_14_kmp.cpp — AP-2 Hafta 10 · Örnek 14 (★★★, merak)
 * Amaç    : Knuth–Morris–Pratt: önek fonksiyonu π (desenin her önekinin
 *           hem öneki hem soneki olan en uzun özdeş parçası); metinde geri
 *           gitmeden eşleme, Θ(n + m) karşılaştırma; naif ve Rabin–Karp ile
 *           aynı konumlar; kâhin: std::string::find döngüsü
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_14_kmp.cpp -o H10_14_kmp
 * Çalıştır: ./H10_14_kmp
 * Eşleri  : c/H10_14_kmp.c · python/H10_14_kmp.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : karşılaştırma sayısı ≤ 2n: her metin karakteri için bir başarılı
 *           ya da q = 0'daki karşılaştırma + q'yu azaltan (toplamda en çok
 *           n kez artmış olan) düşüşler
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

const std::size_t EN_COK = 10;

static long long karsilastirma_sayisi = 0;
static bool iz_ac = false;       // bölüm 2: her metin karakterini yaz

static bool esit_mi(char a, char b)
{
    karsilastirma_sayisi++;
    return a == b;
}

// pi[q] = p[0..q]'nun hem öneki hem soneki olan en uzun (kendisinden
// kısa) parçanın uzunluğu. Θ(m) karşılaştırma (en çok 2m)
static std::vector<std::size_t> onek_fonksiyonu(const std::string& p)
{
    std::vector<std::size_t> pi(p.size(), 0);
    std::size_t k = 0;
    for (std::size_t q = 1; q < p.size(); q++) {
        for (;;) {
            if (esit_mi(p[k], p[q])) {
                k++;
                break;
            }
            if (k == 0) {
                break;
            }
            k = pi[k - 1];               // daha kısa sınıra düş
        }
        pi[q] = k;
    }
    return pi;
}

// t'de p'nin tüm konumları; i hiç geri gitmez
static std::vector<std::size_t> kmp_ara(const std::string& t,
                                        const std::string& p,
                                        const std::vector<std::size_t>& pi)
{
    std::vector<std::size_t> konum;
    std::size_t m = p.size();
    std::size_t q = 0;                   // eşleşmiş önek uzunluğu
    for (std::size_t i = 0; i < t.size(); i++) {
        std::size_t q_once = q;
        std::string dusus;
        for (;;) {                       // her adımda 1 karşılaştırma
            if (esit_mi(p[q], t[i])) {
                q++;
                break;
            }
            if (q == 0) {
                break;
            }
            q = pi[q - 1];               // metinde geri gitmeden kay
            if (iz_ac) {
                dusus += " -> " + std::to_string(q);
            }
        }
        if (iz_ac) {
            std::cout << "  " << std::setw(2) << i << "    " << t[i] << "  "
                      << std::setw(5) << q_once << std::left << std::setw(16)
                      << dusus << std::right << ' ' << std::setw(5) << q;
        }
        if (q == m) {
            konum.push_back(i + 1 - m);
            if (iz_ac) {
                std::cout << "   EŞLEŞME: kayma s = " << i + 1 - m;
            }
            q = pi[q - 1];               // çakışan eşleşmeler için
        }
        if (iz_ac) {
            std::cout << '\n';
        }
    }
    return konum;
}

static std::vector<std::size_t> naif_ara(const std::string& t,
                                         const std::string& p)
{
    std::vector<std::size_t> konum;
    for (std::size_t s = 0; s + p.size() <= t.size(); s++) {
        std::size_t j = 0;
        while (j < p.size() && esit_mi(t[s + j], p[j])) {
            j++;
        }
        if (j == p.size()) {
            konum.push_back(s);
        }
    }
    return konum;
}

// Rabin–Karp (Örnek 12; d = 256, q = 1000003): yalnız konumlar için
static std::vector<std::size_t> rk_ara(const std::string& t,
                                       const std::string& p)
{
    const long long d = 256;
    const long long q = 1000003;
    std::size_t n = t.size();
    std::size_t m = p.size();
    long long h = 1;
    long long hp = 0;
    long long ht = 0;
    std::vector<std::size_t> konum;
    for (std::size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    for (std::size_t i = 0; i < m; i++) {
        hp = (d * hp + static_cast<unsigned char>(p[i])) % q;
        ht = (d * ht + static_cast<unsigned char>(t[i])) % q;
    }
    for (std::size_t s = 0;; s++) {
        if (hp == ht && t.compare(s, m, p) == 0) {
            konum.push_back(s);
        }
        if (s + m >= n) {
            break;
        }
        ht = (d * (ht + q - static_cast<unsigned char>(t[s]) * h % q) +
              static_cast<unsigned char>(t[s + m])) % q;
    }
    return konum;
}

// Kâhin: std::string::find döngüsü (çakışan eşleşmeler dahil)
static std::vector<std::size_t> kahin_ara(const std::string& t,
                                          const std::string& p)
{
    std::vector<std::size_t> konum;
    for (std::size_t q = t.find(p); q != std::string::npos;
         q = t.find(p, q + 1)) {
        konum.push_back(q);
    }
    return konum;
}

static void karsilastir(const std::string& ad, const std::string& t,
                        const std::string& p)
{
    karsilastirma_sayisi = 0;
    std::vector<std::size_t> pi = onek_fonksiyonu(p);
    long long k_pi = karsilastirma_sayisi;
    karsilastirma_sayisi = 0;
    std::vector<std::size_t> k1 = kmp_ara(t, p, pi);
    long long k_kmp = karsilastirma_sayisi;
    karsilastirma_sayisi = 0;
    std::vector<std::size_t> k2 = naif_ara(t, p);
    long long k_naif = karsilastirma_sayisi;
    std::vector<std::size_t> k3 = kahin_ara(t, p);
    std::vector<std::size_t> k4 = rk_ara(t, p);
    std::cout << "  " << ad << ": n = " << t.size() << ", m = " << p.size()
              << ", eşleşme = " << k1.size() << '\n'
              << "    karşılaştırma: π = " << k_pi << " (≤ 2m = "
              << 2 * p.size() << "), KMP = " << k_kmp << " (≤ 2n = "
              << 2 * t.size() << "), naif = " << k_naif << '\n'
              << "    konumlar:";
    for (std::size_t i = 0; i < k1.size() && i < EN_COK; i++) {
        std::cout << ' ' << k1[i];
    }
    std::cout << (k1.size() > EN_COK ? " …" : "")
              << "\n    naif ile aynı mı? " << (k1 == k2 ? "evet" : "HAYIR")
              << "; Rabin–Karp ile? " << (k1 == k4 ? "evet" : "HAYIR")
              << "; kâhin (strstr) ile? " << (k1 == k3 ? "evet" : "HAYIR")
              << '\n';
}

int main()
{
    const std::string P = "ababaca";
    std::vector<std::size_t> pi = onek_fonksiyonu(P);
    std::cout << "1) Önek fonksiyonu: P = " << P << "\n     q:";
    for (std::size_t q = 0; q < P.size(); q++) {
        std::cout << ' ' << q + 1;
    }
    std::cout << "\n  P[q]:";
    for (char c : P) {
        std::cout << ' ' << c;
    }
    std::cout << "\n  π[q]:";
    for (std::size_t v : pi) {
        std::cout << ' ' << v;
    }
    std::cout << "\n  (ör. π[5] = 3: \"ababa\"nın hem öneki hem soneki olan "
                 "en uzun parça \"aba\")\n";

    std::cout << "\n2) Eşleme izi: T = bacbabababacaab (q: eşleşmiş önek; "
                 "->: uyuşmazlıkta q = π[q])\n"
              << "   i  T[i]  q önce  düşüşler        q sonra\n";
    const std::string T = "bacbabababacaab";
    iz_ac = true;
    kmp_ara(T, P, pi);
    iz_ac = false;

    std::cout << "\n3) Karşılaştırma sayıları: KMP, naif; kâhinle "
                 "konumlar\n";
    karsilastir("T = bacbabababacaab", T, P);
    const std::size_t N = 100000;
    std::string metin(N, ' ');
    rastgele_tohum(42);
    for (std::size_t i = 0; i < N; i++) {
        metin[i] = static_cast<char>('a' + rastgele_aralik(0, 3));
    }
    karsilastir("rastgele {a,b,c,d}, desen = metin[50000..50007]", metin,
                metin.substr(50000, 8));
    const std::string a_n(10000, 'a');
    karsilastir("en kötü (naif için): a^10000, a^99 b", a_n,
                std::string(99, 'a') + "b");
    karsilastir("her kayma eşleşir: a^10000, a^100", a_n,
                std::string(100, 'a'));
    return 0;
}

/* Kütüphane karşılığı: C — strstr; C++ — std::string::find, std::search
 * (C++17: std::boyer_moore_searcher); Python — bytes.find / str.find
 * (KMP standart kütüphanelerde ayrıca sunulmaz). */

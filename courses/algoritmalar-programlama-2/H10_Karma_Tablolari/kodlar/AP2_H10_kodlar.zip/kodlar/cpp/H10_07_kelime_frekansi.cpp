/* H10_07_kelime_frekansi.cpp — AP-2 Hafta 10 · Örnek 7 (★★)
 * Amaç    : Metindeki sözcüklerin sıklığı: bayt düzeyinde sözcük ayırma,
 *           ASCII küçük harf dönüşümü elle (A–Z → +32), UTF-8 Türkçe harfler
 *           (bayt ≥ 0x80) olduğu gibi ve harf sayılır; zincirleme karma
 *           tablosu (α > 1 olunca × 2); en sık 20 sözcük (sıralı çıktı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_07_kelime_frekansi.cpp -o H10_07_kelime_frekansi
 * Çalıştır: ./H10_07_kelime_frekansi \
 *           < ../girdiler/H10_07_kelime_frekansi.txt
 * Eşleri  : c/H10_07_kelime_frekansi.c ·
 *           python/H10_07_kelime_frekansi.py
 * Çıktı   : üç dilde aynı (=); süre stderr'e
 */
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

#include "zamanlayici.hpp"

struct Dugum {
    std::string anahtar;
    int deger;                   // sıklık
    Dugum *sonraki;
};

static long long tasinan_dugum = 0;

// Sahiplik: düğümler tablonundur; yıkıcı zincirleri döngüyle siler (RAII)
struct Tablo {
    std::vector<Dugum *> kova;   // m: 2'nin kuvveti, indis = h & (m - 1)
    std::size_t n = 0;
    explicit Tablo(std::size_t m) : kova(m, nullptr) {}
    Tablo(const Tablo&) = delete;
    Tablo& operator=(const Tablo&) = delete;
    ~Tablo()
    {
        for (Dugum *d : kova) {
            while (d != nullptr) {
                Dugum *sonraki = d->sonraki;
                delete d;
                d = sonraki;
            }
        }
    }
};

static std::uint32_t karma_fnv1a(const std::string& s)
{
    std::uint32_t h = 2166136261u;
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

// α > 1: kova dizisi × 2; düğümler yeni kovalarına bağlanır (ayırma yok)
static void buyut(Tablo& t)
{
    std::size_t yeni_m = 2 * t.kova.size();
    std::vector<Dugum *> yeni(yeni_m, nullptr);
    for (Dugum *d : t.kova) {
        while (d != nullptr) {
            Dugum *sonraki = d->sonraki;
            std::size_t k = karma_fnv1a(d->anahtar) & (yeni_m - 1);
            d->sonraki = yeni[k];
            yeni[k] = d;
            tasinan_dugum++;
            d = sonraki;
        }
    }
    t.kova.swap(yeni);
}

// Sözcüğün sıklığını 1 artırır (yoksa 1 ile ekler)
static void say(Tablo& t, const std::string& sozcuk)
{
    std::size_t j = karma_fnv1a(sozcuk) & (t.kova.size() - 1);
    for (Dugum *d = t.kova[j]; d != nullptr; d = d->sonraki) {
        if (d->anahtar == sozcuk) {
            d->deger++;
            return;
        }
    }
    t.kova[j] = new Dugum{sozcuk, 1, t.kova[j]};
    t.n++;
    if (t.n > t.kova.size()) {
        buyut(t);
    }
}

// Harf: ASCII A–Z, a–z ya da UTF-8 çok baytlı karakterin baytı (≥ 0x80)
static bool harf_mi(unsigned char b)
{
    return (b >= 'A' && b <= 'Z') || (b >= 'a' && b <= 'z') || b >= 0x80;
}

// Çıktı biçimi için sıralama (kâhin değil): sıklık azalan, bayt artan
static bool siklik_sirasi(const Dugum *x, const Dugum *y)
{
    if (x->deger != y->deger) {
        return x->deger > y->deger;
    }
    return x->anahtar < y->anahtar;          // unsigned char sırası
}

int main()
{
    double t0 = zaman_sn();
    std::string metin(std::istreambuf_iterator<char>(std::cin), {});
    Tablo t(16);
    std::string sozcuk;
    long long toplam = 0;
    for (std::size_t i = 0; i <= metin.size(); i++) {
        unsigned char b = i < metin.size()
                              ? static_cast<unsigned char>(metin[i])
                              : ' ';
        if (harf_mi(b)) {
            if (sozcuk.size() < 255) {
                sozcuk += static_cast<char>(b >= 'A' && b <= 'Z' ? b + 32
                                                                 : b);
            }
        } else if (!sozcuk.empty()) {
            say(t, sozcuk);
            toplam++;
            sozcuk.clear();
        }
    }

    std::vector<const Dugum *> liste;
    std::size_t en_uzun = 0;
    for (const Dugum *bas : t.kova) {
        std::size_t u = 0;
        for (const Dugum *d = bas; d != nullptr; d = d->sonraki) {
            liste.push_back(d);
            u++;
        }
        en_uzun = std::max(en_uzun, u);
    }
    std::sort(liste.begin(), liste.end(), siklik_sirasi);

    std::cout << "Girdi: " << metin.size()
              << " bayt; sözcük = harf baytlarının en uzun dizisi\n"
              << "toplam sözcük = " << toplam << ", farklı sözcük = " << t.n
              << '\n'
              << "karma tablosu: m = " << t.kova.size() << " kova, α = "
              << std::fixed << std::setprecision(3)
              << static_cast<double>(t.n) / t.kova.size()
              << ", en uzun zincir = " << en_uzun
              << ", büyütmede taşınan düğüm = " << tasinan_dugum << '\n'
              << "\nEn sık 20 sözcük (sıklık azalan; eşitlikte bayt sırası "
                 "artan)\n";
    for (std::size_t r = 0; r < 20 && r < liste.size(); r++) {
        std::cout << "  " << std::setw(2) << r + 1 << ". " << std::setw(5)
                  << liste[r]->deger << "  " << liste[r]->anahtar << '\n';
    }
    int tr_buyuk = 0;
    for (const Dugum *d : liste) {
        const std::string& s = d->anahtar;
        unsigned char b0 = static_cast<unsigned char>(s[0]);
        unsigned char b1 = s.size() > 1 ? static_cast<unsigned char>(s[1])
                                        : 0;
        bool c3 = b0 == 0xC3 && (b1 == 0x87 || b1 == 0x96 ||
                                 b1 == 0x9C);             // Ç Ö Ü
        bool c4 = b0 == 0xC4 && (b1 == 0x9E || b1 == 0xB0); // Ğ İ
        bool c5 = b0 == 0xC5 && b1 == 0x9E;                 // Ş
        tr_buyuk += c3 || c4 || c5;
    }
    std::cout << "\nTürkçe büyük harfle (Ç Ğ İ Ö Ş Ü) başlayan farklı "
                 "sözcük: " << tr_buyuk
              << " (ASCII dışı harfler küçültülmedi)\n";
    std::cerr << "süre (okuma + sayma + sıralama): " << std::fixed
              << std::setprecision(3) << (zaman_sn() - t0) * 1e3 << " ms\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; sıralama için qsort çıktı
 * biçimidir); C++ — std::unordered_map<std::string, int> + std::sort;
 * Python — collections.Counter(...).most_common(20) ya da dict. */

/* H10_01_dogrudan_adresleme.cpp — AP-2 Hafta 10 · Örnek 1 (★)
 * Amaç    : Doğrudan adresleme: anahtar = indis (0–99 numaralı öğrenci
 *           tablosu); ekle/ara/sil tek erişimde; anahtar evreni büyüyünce
 *           bellek hesabı ve karma fonksiyonuna köprü (k mod 101)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_01_dogrudan_adresleme.cpp -o H10_01_dogrudan_adresleme
 * Çalıştır: ./H10_01_dogrudan_adresleme
 * Eşleri  : c/H10_01_dogrudan_adresleme.c ·
 *           python/H10_01_dogrudan_adresleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

const int EVREN = 100;       // anahtar evreni: 0 .. 99
const int HUCRE_BAYT = 8;    // bir hücre = bir işaretçi (x86-64 LP64)

static long long erisim_sayisi = 0;

// Hücre boş dizgiyse boştur; dolu hücre adın kopyasını tutar
static std::vector<std::string> tablo(EVREN);

static bool gecerli_mi(int no) { return no >= 0 && no < EVREN; }

static void ekle(int no, const std::string& ad)
{
    erisim_sayisi++;
    tablo[no] = ad;              // anahtar = indis: arama yok
}

static const std::string& ara(int no)
{
    erisim_sayisi++;
    return tablo[no];
}

static void sil(int no)
{
    erisim_sayisi++;
    tablo[no].clear();
}

static void tablo_ciz()
{
    std::cout << "     ";
    for (int s = 0; s < 10; s++) {
        std::cout << ' ' << std::setw(2) << s;
    }
    std::cout << '\n';
    for (int r = 0; r < 10; r++) {
        std::cout << "  " << r << "0 ";
        for (int s = 0; s < 10; s++) {
            int no = 10 * r + s;
            if (tablo[no].empty()) {
                std::cout << " --";
            } else {
                std::cout << ' ' << std::setw(2) << std::setfill('0') << no
                          << std::setfill(' ');
            }
        }
        std::cout << '\n';
    }
}

static void sorgula(int no)
{
    if (!gecerli_mi(no)) {
        std::cout << "  ara(" << no << "): geçersiz anahtar (evren 0.."
                  << EVREN - 1 << ")\n";
        return;
    }
    long long once = erisim_sayisi;
    const std::string& ad = ara(no);
    std::cout << "  ara(" << no << "): " << (ad.empty() ? "boş" : ad)
              << "  [erişim = " << erisim_sayisi - once << "]\n";
}

static void bellek_satiri(const std::string& aciklama,
                          unsigned long long evren, unsigned long long kayit)
{
    unsigned long long bayt = evren * HUCRE_BAYT;
    double doluluk = 100.0 * static_cast<double>(kayit) /
                     static_cast<double>(evren);
    std::cout << "  " << std::setw(14) << evren << ' ' << std::setw(6)
              << kayit << ' ' << std::setw(16) << bayt << ' ' << std::fixed
              << std::setprecision(3) << std::setw(12)
              << static_cast<double>(bayt) / 1e9 << ' '
              << std::setprecision(6) << std::setw(12) << doluluk << "  "
              << aciklama << '\n';
}

int main()
{
    const std::vector<int> numara = {7, 23, 42, 64, 99, 0};
    const std::vector<std::string> ad = {"Ayşe Yılmaz", "Mehmet Kaya",
                                         "Zeynep Demir", "Ali Çelik",
                                         "Elif Şahin", "Can Öztürk"};
    const int k = 6;

    std::cout << "1) Doğrudan adresleme: 0..99 numaralı öğrenciler, "
                 "anahtar = indis\n";
    for (int i = 0; i < k; i++) {
        ekle(numara[i], ad[i]);
        std::cout << "  ekle(" << numara[i] << ", \"" << ad[i]
                  << "\") -> tablo[" << numara[i] << "]\n";
    }
    std::cout << "\n  Tablo (100 hücre; \"--\" boş, sayı = dolu hücrenin "
                 "numarası)\n";
    tablo_ciz();

    std::cout << "\n2) Arama ve silme: her işlem tek erişim, Θ(1)\n";
    sorgula(42);
    sorgula(50);
    sil(42);
    std::cout << "  sil(42)\n";
    sorgula(42);
    sorgula(150);
    std::cout << "  toplam erişim: " << erisim_sayisi << " (" << k
              << " ekleme + 3 arama + 1 silme; ara(150) tabloya "
                 "erişmez)\n";
    int dolu = 0;
    for (int no = 0; no < EVREN; no++) {
        dolu += !tablo[no].empty();
    }
    std::cout << "  dolu hücre: " << dolu << " / " << EVREN << '\n';

    std::cout << "\n3) Anahtar evreni büyüyünce bellek (hücre = "
              << HUCRE_BAYT << " bayt)\n";
    std::cout << "         evren U  kayıt    bellek (bayt)  bellek (GB)  "
                 "doluluk (%)  anahtar\n";
    bellek_satiri("sınıf sıra no (0..99)", 100ull,
                  static_cast<unsigned long long>(dolu));
    bellek_satiri("4 haneli no (0..9999)", 10000ull, 5000ull);
    bellek_satiri("9 haneli öğrenci no", 1000000000ull, 5000ull);
    bellek_satiri("32 bit tamsayı (2^32)", 4294967296ull, 5000ull);

    std::cout << "\n4) Köprü: 9 haneli numara -> h(k) = k mod 101 "
                 "(101 hücre)\n";
    const std::vector<unsigned long long> uzun_no = {
        240101007ull, 240101023ull, 240101042ull,
        240101064ull, 240101099ull, 240101108ull};
    for (int i = 0; i < k; i++) {
        std::cout << "  " << uzun_no[i] << " mod 101 = " << std::setw(3)
                  << uzun_no[i] % 101ull << '\n';
    }
    std::cout << "  (çakışma: farklı anahtarlar aynı hücreye düşebilir -> "
                 "Örnek 3, 4)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (dizi; tamsayı anahtarlı küçük evrende
 * doğrudan adresleme); C++ — std::array/std::vector (anahtar = indis);
 * Python — liste [None] * 100 (anahtar = indis). */

/* H10_06_yeniden_boyutlandirma.cpp — AP-2 Hafta 10 · Örnek 6 (★★)
 * Amaç    : Yeniden boyutlandırma (rehash): α = n/m > 3/4 olacaksa kapasite
 *           × 2 ve tüm anahtarlar yeni tabloya yeniden yerleştirilir;
 *           taşınan öğe sayısının toplamı ve öğe başına amortize maliyet
 *           (tek ekleme Θ(n) olabilir, n eklemenin toplamı O(n))
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_06_yeniden_boyutlandirma.cpp -o H10_06_yeniden_boyutlandirma
 * Çalıştır: ./H10_06_yeniden_boyutlandirma [N_ust]   (varsayılan 100000)
 * Eşleri  : c/H10_06_yeniden_boyutlandirma.c ·
 *           python/H10_06_yeniden_boyutlandirma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

struct Tablo {
    std::vector<std::uint32_t> anahtar;
    std::vector<unsigned char> dolu;
    int p;                       // m = 2^p
    std::size_t n = 0;
    explicit Tablo(int p_) : anahtar(std::size_t{1} << p_),
                             dolu(std::size_t{1} << p_, 0), p(p_) {}
};

static long long yoklama_sayisi = 0;
static long long yazma_sayisi = 0;           // hücreye yazılan anahtar
static long long tasinan_sayisi = 0;         // yeniden yerleştirilen
static bool iz_ac = false;                   // bölüm 1: olayları yaz

static std::uint32_t karma_carpma(std::uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

// Yer bulup yazar (yük denetimi yok); true: yeni, false: zaten var
static bool yerlestir(Tablo& t, std::uint32_t k)
{
    std::uint32_t maske = (std::uint32_t{1} << t.p) - 1u;
    std::uint32_t i = karma_carpma(k, t.p);
    for (;;) {
        yoklama_sayisi++;
        if (!t.dolu[i]) {
            break;
        }
        if (t.anahtar[i] == k) {
            return false;
        }
        i = (i + 1u) & maske;
    }
    t.dolu[i] = 1;
    t.anahtar[i] = k;
    t.n++;
    yazma_sayisi++;
    return true;
}

// Kapasite × 2: eski dizideki her anahtar yeni diziye yeniden karma ile
// yerleşir (indis m'ye bağlı olduğundan kopyalamak yetmez)
static void buyut(Tablo& t)
{
    Tablo yeni(t.p + 1);
    std::size_t m = t.anahtar.size();
    for (std::size_t i = 0; i < m; i++) {
        if (t.dolu[i]) {
            yerlestir(yeni, t.anahtar[i]);
            tasinan_sayisi++;
        }
    }
    if (iz_ac) {
        std::cout << "  ekleme #" << t.n + 1 << " öncesi: α = " << t.n + 1
                  << '/' << m << " > 3/4 olacaktı -> m " << m << " -> "
                  << 2 * m << ", taşınan " << t.n << '\n';
    }
    t = std::move(yeni);                     // eski vektörler serbest kalır
}

// Yük denetimli ekleme: (n + 1) / m > 3/4 olacaksa önce büyüt
static bool tablo_ekle(Tablo& t, std::uint32_t k)
{
    if (4 * (t.n + 1) > 3 * t.anahtar.size()) {
        buyut(t);
    }
    return yerlestir(t, k);
}

static void deney_satiri(std::size_t N)
{
    Tablo t(3);                              // m = 8 ile başla
    yoklama_sayisi = yazma_sayisi = tasinan_sayisi = 0;
    long long en_pahali = 0;
    std::size_t en_pahali_no = 0;
    int buyutme = 0;
    rastgele_tohum(42);
    while (t.n < N) {
        long long once = yazma_sayisi;
        int p_once = t.p;
        tablo_ekle(t, rastgele_sayi());
        buyutme += t.p != p_once;
        if (yazma_sayisi - once > en_pahali) {
            en_pahali = yazma_sayisi - once;
            en_pahali_no = t.n;
        }
    }
    std::cout << "  " << std::setw(8) << N << ' ' << std::setw(4) << buyutme
              << ' ' << std::setw(9) << t.anahtar.size() << ' '
              << std::setw(10) << tasinan_sayisi << ' ' << std::fixed
              << std::setprecision(3) << std::setw(8)
              << static_cast<double>(tasinan_sayisi) / N << ' '
              << std::setw(11) << en_pahali << ' ' << std::setw(9)
              << en_pahali_no << ' ' << std::setw(8)
              << static_cast<double>(yazma_sayisi) / N << ' '
              << std::setw(8) << static_cast<double>(yoklama_sayisi) / N
              << '\n';
}

int main(int argc, char *argv[])
{
    long N_ust = 100000;
    if (argc > 2) {
        std::cerr << "kullanım: " << argv[0] << " [N_ust (100..10000000)]\n";
        return 2;
    }
    if (argc == 2) {
        try {
            std::size_t son;
            N_ust = std::stol(argv[1], &son);
            if (argv[1][son] != '\0' || N_ust < 100 || N_ust > 10000000) {
                throw 0;
            }
        } catch (...) {
            std::cerr << "kullanım: " << argv[0]
                      << " [N_ust (100..10000000)]\n";
            return 2;
        }
    }

    std::cout << "1) İlk 100 ekleme: m = 8'den başla, (n + 1)/m > 3/4 "
                 "olacaksa m × 2\n";
    {
        Tablo t(3);
        iz_ac = true;
        rastgele_tohum(42);
        while (t.n < 100) {
            tablo_ekle(t, rastgele_sayi());
        }
        iz_ac = false;
        std::cout << "  100 eklemeden sonra: m = " << t.anahtar.size()
                  << ", α = " << std::fixed << std::setprecision(3)
                  << static_cast<double>(t.n) / t.anahtar.size()
                  << ", toplam taşınan = " << tasinan_sayisi << '\n';
    }

    std::cout << "\n2) N ekleme: büyütme sayısı, taşınan toplamı, en pahalı "
                 "tek ekleme\n"
              << "  (yazma = hücreye anahtar yazımı: ekleme 1 + büyütmede "
                 "taşınanlar; yoklama = bakılan hücre)\n"
              << "         N  büy.    son m    taşınan  taş./N  en pahalı "
                 "  (#ekl.)  yazma/N  yokl./N\n";
    for (long N = 1000; N <= N_ust; N *= 10) {
        deney_satiri(static_cast<std::size_t>(N));
    }
    std::cout << "  (taşınanlar geometrik dizi: 6 + 12 + … + L < 2L ≤ 2N; "
                 "en pahalı tek ekleme L + 1 yazma = Θ(n))\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
 * otomatik rehash (max_load_factor, rehash(), reserve()); Python — dict
 * (otomatik büyür; kullanıcıya açık eşik yok). */

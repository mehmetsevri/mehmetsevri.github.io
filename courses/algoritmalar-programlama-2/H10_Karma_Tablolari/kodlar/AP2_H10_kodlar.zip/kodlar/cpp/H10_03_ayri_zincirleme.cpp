/* H10_03_ayri_zincirleme.cpp — AP-2 Hafta 10 · Örnek 3 (★★)
 * Amaç    : Ayrı zincirleme karma tablosu: m kova + bağlı düğüm listeleri
 *           (H8); ekle (güncelleme semantiği) / ara / sil; anahtar dizgisi
 *           KOPYALANIR; anahtar → karma → kova akışı, sayaçlar
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_03_ayri_zincirleme.cpp -o H10_03_ayri_zincirleme
 * Çalıştır: ./H10_03_ayri_zincirleme
 * Eşleri  : c/H10_03_ayri_zincirleme.c ·
 *           python/H10_03_ayri_zincirleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

struct Dugum {
    std::string anahtar;         // std::string kendi kopyasını tutar
    int deger;
    Dugum *sonraki;
};

static long long karsilastirma_sayisi = 0;   // anahtar karşılaştırması
static long long ayrilan_dugum = 0;
static long long birakilan_dugum = 0;

struct Tablo;
static void tablo_yok_et(Tablo& t);

// Sahiplik: düğümler tablonundur; yıkıcı zincirleri döngüyle siler (RAII)
struct Tablo {
    std::vector<Dugum *> kova;   // m kova başı; boş kova nullptr
    std::size_t n = 0;           // anahtar sayısı
    explicit Tablo(std::size_t m) : kova(m, nullptr) {}
    Tablo(const Tablo&) = delete;
    Tablo& operator=(const Tablo&) = delete;
    ~Tablo() { tablo_yok_et(*this); }
};

// FNV-1a 32 bit; baytlar unsigned char olarak okunur (Hata Avcısı 1)
static std::uint32_t karma_fnv1a(const std::string& s)
{
    std::uint32_t h = 2166136261u;
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

static std::size_t kova_no(const Tablo& t, const std::string& anahtar)
{
    return karma_fnv1a(anahtar) % t.kova.size();
}

// Kovanın zincirinde anahtarı arar; bulunamazsa nullptr
static Dugum *zincirde_bul(Dugum *d, const std::string& anahtar)
{
    for (; d != nullptr; d = d->sonraki) {
        karsilastirma_sayisi++;
        if (d->anahtar == anahtar) {
            return d;
        }
    }
    return nullptr;
}

// 1: yeni anahtar, 0: değer güncellendi
static int tablo_ekle(Tablo& t, const std::string& anahtar, int deger)
{
    std::size_t j = kova_no(t, anahtar);
    Dugum *d = zincirde_bul(t.kova[j], anahtar);
    if (d != nullptr) {
        d->deger = deger;                // güncelleme semantiği
        return 0;
    }
    d = new Dugum{anahtar, deger, t.kova[j]};   // anahtar kopyalanır
    t.kova[j] = d;                       // zincirin başına: O(1)
    t.n++;
    ayrilan_dugum++;
    return 1;
}

// Bulursa deger'e yazar ve true döndürür
static bool tablo_ara(const Tablo& t, const std::string& anahtar,
                      int& deger)
{
    Dugum *d = zincirde_bul(t.kova[kova_no(t, anahtar)], anahtar);
    if (d == nullptr) {
        return false;
    }
    deger = d->deger;
    return true;
}

// Dugum ** ile silme (H8): bağlantıyı tutan işaretçinin adresi gezer
static bool tablo_sil(Tablo& t, const std::string& anahtar)
{
    Dugum **bag = &t.kova[kova_no(t, anahtar)];
    while (*bag != nullptr) {
        karsilastirma_sayisi++;
        if ((*bag)->anahtar == anahtar) {
            Dugum *silinen = *bag;
            *bag = silinen->sonraki;
            delete silinen;
            birakilan_dugum++;
            t.n--;
            return true;
        }
        bag = &(*bag)->sonraki;
    }
    return false;
}

static void tablo_yaz(const Tablo& t)
{
    for (std::size_t j = 0; j < t.kova.size(); j++) {
        std::cout << "  kova " << j << ':';
        for (const Dugum *d = t.kova[j]; d != nullptr; d = d->sonraki) {
            std::cout << ' ' << d->anahtar << '=' << d->deger << " ->";
        }
        std::cout << " NULL\n";
    }
}

// Bütün zincirleri yinelemeli serbest bırakır (yıkıcı da bunu çağırır)
static void tablo_yok_et(Tablo& t)
{
    for (Dugum *&bas : t.kova) {
        Dugum *d = bas;
        while (d != nullptr) {
            Dugum *sonraki = d->sonraki;
            delete d;
            birakilan_dugum++;
            d = sonraki;
        }
        bas = nullptr;
    }
    t.n = 0;
}

static void ara_yaz(const Tablo& t, const std::string& anahtar)
{
    long long once = karsilastirma_sayisi;
    int deger;
    if (tablo_ara(t, anahtar, deger)) {
        std::cout << "  ara " << anahtar << ": " << deger << " (kova "
                  << kova_no(t, anahtar) << ", karşılaştırma = "
                  << karsilastirma_sayisi - once << ")\n";
    } else {
        std::cout << "  ara " << anahtar << ": YOK (kova "
                  << kova_no(t, anahtar) << ", karşılaştırma = "
                  << karsilastirma_sayisi - once << ")\n";
    }
}

static std::string onaltilik(std::uint32_t h)
{
    const char *rakam = "0123456789abcdef";
    std::string s = "0x00000000";
    for (int i = 9; i >= 2; i--) {
        s[i] = rakam[h & 0xFu];
        h >>= 4;
    }
    return s;
}

int main()
{
    const std::vector<std::string> ad = {"ali", "ayşe", "can", "elif",
                                         "deniz", "zeynep", "mert", "ece",
                                         "kerem", "selin", "ömer", "ılgın"};
    const std::vector<int> not_ = {70, 85, 60, 90, 75, 95,
                                   55, 80, 65, 88, 72, 91};
    const int k = 12;
    {
        Tablo t(11);
        std::string tampon;          // girdi okuma tamponunun benzetimi

        std::cout << "1) Anahtar -> FNV-1a karma -> kova (m = "
                  << t.kova.size() << ")\n";
        for (int i = 0; i < k; i++) {
            tampon = ad[i];
            tablo_ekle(t, tampon, not_[i]);
            std::cout << "  ekle " << tampon << '=' << not_[i]
                      << ": karma = " << onaltilik(karma_fnv1a(tampon))
                      << " = " << std::setw(10) << karma_fnv1a(tampon)
                      << " -> kova " << kova_no(t, tampon) << '\n';
        }
        tampon = "XXXXXXXX";
        std::cout << "  (tampon artık \"" << tampon
                  << "\"; tablo kendi kopyalarını tutar)\n"
                  << "  n = " << t.n << ", m = " << t.kova.size()
                  << ", α = n/m = " << std::fixed << std::setprecision(3)
                  << static_cast<double>(t.n) / t.kova.size()
                  << " (zincirlemede α > 1 olabilir)\n";
        tablo_yaz(t);

        std::cout << "\n2) Arama (karşılaştırma = zincirde bakılan düğüm "
                     "sayısı)\n";
        ara_yaz(t, "ayşe");
        ara_yaz(t, "ali");
        ara_yaz(t, "ılgın");
        ara_yaz(t, "berk");

        std::cout << "\n3) Güncelleme semantiği: var olan anahtar yeni "
                     "düğüm oluşturmaz\n";
        int sonuc = tablo_ekle(t, "ayşe", 100);
        std::cout << "  ekle ayşe=100 -> "
                  << (sonuc == 1 ? "yeni" : "güncellendi") << ", n = "
                  << t.n << '\n';
        ara_yaz(t, "ayşe");

        std::cout << "\n4) Silme (Dugum ** ile; ortadaki, baştaki, "
                     "sondaki, olmayan)\n";
        const std::vector<std::string> silinecek = {"elif", "ılgın", "can",
                                                    "berk"};
        for (const std::string& s : silinecek) {
            long long once = karsilastirma_sayisi;
            bool var = tablo_sil(t, s);
            std::cout << "  sil " << s << ": " << (var ? "silindi" : "YOK")
                      << " (kova " << kova_no(t, s) << ", karşılaştırma = "
                      << karsilastirma_sayisi - once << ")\n";
        }
        tablo_yaz(t);

        std::cout << "\n5) Ölçüler\n";
        std::size_t en_uzun = 0;
        std::size_t bos = 0;
        for (const Dugum *bas : t.kova) {
            std::size_t u = 0;
            for (const Dugum *d = bas; d != nullptr; d = d->sonraki) {
                u++;
            }
            bos += u == 0;
            if (u > en_uzun) {
                en_uzun = u;
            }
        }
        karsilastirma_sayisi = 0;
        int bulunan = 0;
        for (int i = 0; i < k; i++) {
            int deger;
            bulunan += tablo_ara(t, ad[i], deger);
        }
        std::cout << "  n = " << t.n << ", boş kova = " << bos
                  << ", en uzun zincir = " << en_uzun << '\n'
                  << "  " << k << " adın " << bulunan
                  << " tanesi bulundu; toplam karşılaştırma = "
                  << karsilastirma_sayisi << '\n';
    }                                // t burada yok edilir (yıkıcı)
    std::cout << "  düğüm: ayrılan = " << ayrilan_dugum
              << ", serbest bırakılan = " << birakilan_dugum << '\n';
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX hcreate/hsearch: silme yok,
 * süreçte tek tablo); C++ — std::unordered_map<std::string, int>
 * (libstdc++: kovalar + düğüm zincirleri); Python — dict (CPython: açık
 * adresleme). */

/* H10_05_yuk_faktoru.cpp — AP-2 Hafta 10 · Örnek 5 (★★)
 * Amaç    : Yük faktörü deneyi: α = 0,25 … 0,95 için ayrı zincirleme ve
 *           doğrusal yoklamada başarılı/başarısız aramanın ortalama
 *           yoklama sayısı; kuramsal değerlerle (Knuth, 1998) karşılaştırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_05_yuk_faktoru.cpp -o H10_05_yuk_faktoru
 * Çalıştır: ./H10_05_yuk_faktoru [p] [tohum]     (m = 2^p, varsayılan
 *           p = 13, tohum = 42)
 * Eşleri  : c/H10_05_yuk_faktoru.c · python/H10_05_yuk_faktoru.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Dugum {
    std::uint32_t anahtar;
    Dugum *sonraki;
};

static long long yoklama_sayisi = 0;

// Çarpma yöntemi (Knuth): A = ⌊2^32 / φ⌋; indis = (k·A mod 2^32) >> (32-p).
// Üst bitler alınır: düşük bitleri kötü anahtarlarda da dağıtır.
static std::uint32_t karma_carpma(std::uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

// --- doğrusal yoklama: anahtar dizisi + dolu bayrağı (bitişik bellek)
static bool dy_ekle(std::vector<std::uint32_t>& anahtar,
                    std::vector<unsigned char>& dolu, int p, std::uint32_t k)
{
    std::uint32_t maske = (1u << p) - 1u;
    std::uint32_t i = karma_carpma(k, p);
    while (dolu[i]) {
        if (anahtar[i] == k) {
            return false;                    // zaten var
        }
        i = (i + 1u) & maske;                // m = 2^p: mod yerine maske
    }
    dolu[i] = 1;
    anahtar[i] = k;
    return true;
}

static bool dy_ara(const std::vector<std::uint32_t>& anahtar,
                   const std::vector<unsigned char>& dolu, int p,
                   std::uint32_t k)
{
    std::uint32_t maske = (1u << p) - 1u;
    std::uint32_t i = karma_carpma(k, p);
    for (;;) {
        yoklama_sayisi++;                    // bakılan her hücre
        if (!dolu[i]) {
            return false;
        }
        if (anahtar[i] == k) {
            return true;
        }
        i = (i + 1u) & maske;
    }
}

// --- ayrı zincirleme: kova başları + dağınık düğümler (RAII sarmalayıcı)
struct Kovalar {
    std::vector<Dugum *> bas;
    explicit Kovalar(std::size_t m) : bas(m, nullptr) {}
    Kovalar(const Kovalar&) = delete;
    Kovalar& operator=(const Kovalar&) = delete;
    ~Kovalar() { yok_et(); }
    void yok_et()                            // yinelemeli: yığın taşmaz
    {
        for (Dugum *&b : bas) {
            Dugum *d = b;
            while (d != nullptr) {
                Dugum *sonraki = d->sonraki;
                delete d;
                d = sonraki;
            }
            b = nullptr;
        }
    }
};

static void zc_ekle(Kovalar& kova, int p, std::uint32_t k)
{
    std::uint32_t j = karma_carpma(k, p);
    kova.bas[j] = new Dugum{k, kova.bas[j]};    // başa ekle
}

static bool zc_ara(const Kovalar& kova, int p, std::uint32_t k)
{
    for (const Dugum *d = kova.bas[karma_carpma(k, p)]; d != nullptr;
         d = d->sonraki) {
        yoklama_sayisi++;                    // bakılan her düğüm
        if (d->anahtar == k) {
            return true;
        }
    }
    return false;
}

static bool sayi_oku(const char *s, long alt, long ust, long& x)
{
    try {
        std::size_t son;
        long v = std::stol(s, &son);
        if (s[son] != '\0' || v < alt || v > ust) {
            return false;
        }
        x = v;
        return true;
    } catch (...) {
        return false;
    }
}

int main(int argc, char *argv[])
{
    long p = 13;
    long tohum = 42;
    if (argc > 3 || (argc > 1 && !sayi_oku(argv[1], 4, 22, p)) ||
        (argc > 2 && !sayi_oku(argv[2], 0, 1000000, tohum))) {
        std::cerr << "kullanım: " << argv[0] << " [p (4..22)] [tohum]\n";
        return 2;
    }
    const std::size_t m = std::size_t{1} << p;
    const std::vector<int> alfa_yuzde = {25, 35, 45, 55, 65, 75, 85, 90, 95};
    const int sorgu = 4096;                  // başarısız arama sayısı
    std::vector<std::uint32_t> anahtar(m);
    std::vector<unsigned char> dolu(m);
    std::vector<std::uint32_t> eklenen(m);
    Kovalar kova(m);

    std::cout << "Yük faktörü deneyi: m = 2^" << p << " = " << m
              << ", tohum = " << tohum
              << ", karma = çarpma yöntemi (A = 2654435769)\n"
              << "ZS/ZB: zincirleme başarılı/başarısız; DS/DB: doğrusal "
                 "yoklama\n"
              << "kuram: ZS = 1 + α/2, ZB = α; DS = ½(1 + 1/(1−α)), "
                 "DB = ½(1 + 1/(1−α)²)\n"
              << "başarısız arama: " << sorgu
              << " anahtar (üst biti 1: tabloda olamaz)\n\n"
              << "     α      n  ZS ölç  ZS kur  ZB ölç  ZB kur   DS ölç   "
                 "DS kur    DB ölç    DB kur\n";
    for (int yuzde : alfa_yuzde) {
        std::size_t n = static_cast<std::size_t>(yuzde) * m / 100;
        double alfa = static_cast<double>(n) / m;
        dolu.assign(m, 0);
        rastgele_tohum(static_cast<std::uint64_t>(tohum) +
                       static_cast<std::uint64_t>(yuzde));
        std::size_t e = 0;
        while (e < n) {
            std::uint32_t k = rastgele_sayi();   // 0 .. 2^31 - 1
            if (dy_ekle(anahtar, dolu, static_cast<int>(p), k)) {
                zc_ekle(kova, static_cast<int>(p), k);
                eklenen[e++] = k;
            }
        }
        double olcum[4];
        yoklama_sayisi = 0;
        for (std::size_t i = 0; i < n; i++) {
            zc_ara(kova, static_cast<int>(p), eklenen[i]);
        }
        olcum[0] = static_cast<double>(yoklama_sayisi) / n;
        yoklama_sayisi = 0;
        for (std::size_t i = 0; i < n; i++) {
            dy_ara(anahtar, dolu, static_cast<int>(p), eklenen[i]);
        }
        olcum[2] = static_cast<double>(yoklama_sayisi) / n;
        long long zb = 0;
        long long db = 0;
        for (int q = 0; q < sorgu; q++) {
            std::uint32_t k = rastgele_sayi() | 0x80000000u;
            yoklama_sayisi = 0;
            zc_ara(kova, static_cast<int>(p), k);
            zb += yoklama_sayisi;
            yoklama_sayisi = 0;
            dy_ara(anahtar, dolu, static_cast<int>(p), k);
            db += yoklama_sayisi;
        }
        olcum[1] = static_cast<double>(zb) / sorgu;
        olcum[3] = static_cast<double>(db) / sorgu;
        double bir_eksi = 1.0 - alfa;
        std::cout << std::fixed << std::setprecision(2) << "  " << alfa
                  << ' ' << std::setw(6) << n << std::setprecision(3) << ' '
                  << std::setw(7) << olcum[0] << ' ' << std::setw(7)
                  << 1.0 + alfa / 2.0 << ' ' << std::setw(7) << olcum[1]
                  << ' ' << std::setw(7) << alfa << ' ' << std::setw(8)
                  << olcum[2] << ' ' << std::setw(8)
                  << 0.5 * (1.0 + 1.0 / bir_eksi) << ' ' << std::setw(9)
                  << olcum[3] << ' ' << std::setw(9)
                  << 0.5 * (1.0 + 1.0 / (bir_eksi * bir_eksi)) << '\n';
        kova.yok_et();
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
 * (load_factor(), max_load_factor(): varsayılan 1,0); Python — dict
 * (CPython: doluluk 2/3'ü geçince büyütür). */

/* H10_13_karma_saldirisi.cpp — AP-2 Hafta 10 · Örnek 13 (★★★)
 * Amaç    : Kötü karma fonksiyonuna saldırı (karma taşkını): polinom 31
 *           karmasında h("Aa") = h("BB"); k bloktan 2^k çakışan anahtar;
 *           zincirleme tabloya eklemede karşılaştırma sayısı karesel büyür
 *           (rastgele anahtarda doğrusal). Savunma denemeleri: ortak
 *           LCG'den tohumlu karma (tohumlu h0, rastgele taban — alt/üst
 *           bit indisi, tohumlu FNV-1a); süreler stderr'e
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_13_karma_saldirisi.cpp -o H10_13_karma_saldirisi
 * Çalıştır: ./H10_13_karma_saldirisi [k_ust]   (n = 2^8 .. 2^k_ust,
 *           varsayılan 10, en çok 16)
 * Eşleri  : c/H10_13_karma_saldirisi.c ·
 *           python/H10_13_karma_saldirisi.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

enum { POLINOM = 0, POLINOM_TOHUM = 1, RASTGELE_TABAN = 2, FNV_TOHUM = 3 };

const std::uint32_t A_FIB = 2654435769u;     // ⌊2^32/φ⌋: üst bit indisi

struct Dugum {
    std::string anahtar;
    std::uint32_t karma;         // büyütmede yeniden hesaplanmaz
    Dugum *sonraki;
};

static long long karsilastirma_sayisi = 0;

// Sahiplik: düğümler tablonundur; yıkıcı zincirleri döngüyle siler (RAII)
struct Tablo {
    std::vector<Dugum *> kova;
    int p = 4;                   // m = 2^p
    std::size_t n = 0;
    int tur;                     // karma fonksiyonu
    std::uint32_t tohum;         // gizli anahtar (saldırgan bilmez)
    bool ust_bit;                // true: indis = (h·A) >> (32 − p)
    Tablo(int tur_, std::uint32_t tohum_, bool ust_bit_)
        : kova(16, nullptr), tur(tur_), tohum(tohum_), ust_bit(ust_bit_) {}
    Tablo(const Tablo&) = delete;
    Tablo& operator=(const Tablo&) = delete;
    ~Tablo()
    {
        for (Dugum *d : kova) {
            while (d != nullptr) {
                Dugum *sonraki = d->sonraki;
                delete d;
                d = sonraki;
            }
        }
    }
};

// Polinom 31 (Java String.hashCode'un formülü; burada UTF-8 baytlarıyla)
static std::uint32_t karma_polinom(const std::string& s, std::uint32_t h,
                                   std::uint32_t taban)
{
    for (unsigned char b : s) {
        h = taban * h + b;
    }
    return h;
}

static std::uint32_t karma_fnv1a(const std::string& s, std::uint32_t h)
{
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

static std::uint32_t karma(const Tablo& t, const std::string& s)
{
    switch (t.tur) {
    case POLINOM:
        return karma_polinom(s, 0u, 31u);
    case POLINOM_TOHUM:                      // tohum = başlangıç değeri
        return karma_polinom(s, t.tohum, 31u);
    case RASTGELE_TABAN:                     // tohum = tek sayı taban
        return karma_polinom(s, 0u, t.tohum);
    default:                                 // FNV-1a, h0 XOR tohum
        return karma_fnv1a(s, 2166136261u ^ t.tohum);
    }
}

// Kova indisi: alt bitler (h & (m − 1)) ya da üst bitler (çarpma)
static std::size_t indis(const Tablo& t, std::uint32_t h, int p)
{
    if (t.ust_bit) {
        return (h * A_FIB) >> (32 - p);
    }
    return h & ((std::uint32_t{1} << p) - 1u);
}

static void buyut(Tablo& t)
{
    std::vector<Dugum *> yeni(2 * t.kova.size(), nullptr);
    for (Dugum *d : t.kova) {
        while (d != nullptr) {
            Dugum *sonraki = d->sonraki;
            std::size_t k = indis(t, d->karma, t.p + 1);
            d->sonraki = yeni[k];
            yeni[k] = d;
            d = sonraki;
        }
    }
    t.kova.swap(yeni);
    t.p++;
}

// Güncelleme semantiği: önce zincirin tamamı aranır (saldırının hedefi)
static void tablo_ekle(Tablo& t, const std::string& anahtar)
{
    std::uint32_t h = karma(t, anahtar);
    std::size_t j = indis(t, h, t.p);
    for (Dugum *d = t.kova[j]; d != nullptr; d = d->sonraki) {
        karsilastirma_sayisi++;
        if (d->anahtar == anahtar) {
            return;
        }
    }
    t.kova[j] = new Dugum{anahtar, h, t.kova[j]};
    t.n++;
    if (t.n > t.kova.size()) {
        buyut(t);
    }
}

// x'i bölen en büyük 2 kuvvetinin üssü (x = 0 için 32)
static int iki_kuvveti(std::uint32_t x)
{
    int e = 0;
    while (e < 32 && (x & 1u) == 0u) {
        x >>= 1;
        e++;
    }
    return e;
}

// i'nin k bitinden anahtar: bit 0 → "Aa", 1 → "BB" (en anlamlı bit önce)
static std::string carpisan_anahtar(std::size_t i, int k)
{
    std::string s;
    for (int b = 0; b < k; b++) {
        s += (i >> (k - 1 - b)) & 1u ? "BB" : "Aa";
    }
    return s;
}

static std::string rastgele_anahtar(int k)
{
    std::string s(2 * k, ' ');
    for (int b = 0; b < 2 * k; b++) {
        int x = rastgele_aralik(0, 51);
        s[b] = static_cast<char>(x < 26 ? 'A' + x : 'a' + x - 26);
    }
    return s;
}

struct Olcum {
    long long karsilastirma;
    std::size_t en_uzun;
    std::size_t dolu;            // boş olmayan kova
    std::size_t m;
};

// Anahtarları tabloya ekler; sayaçları döndürür, süreyi stderr'e yazar
static Olcum dene(const std::vector<std::string>& anahtar, int tur,
                  std::uint32_t tohum, bool ust_bit, const std::string& etiket)
{
    Olcum o{0, 0, 0, 0};
    Tablo t(tur, tohum, ust_bit);
    karsilastirma_sayisi = 0;
    double t0 = zaman_sn();
    for (const std::string& a : anahtar) {
        tablo_ekle(t, a);
    }
    double sure = zaman_sn() - t0;
    o.karsilastirma = karsilastirma_sayisi;
    for (const Dugum *bas : t.kova) {
        std::size_t u = 0;
        for (const Dugum *d = bas; d != nullptr; d = d->sonraki) {
            u++;
        }
        o.dolu += u > 0;
        if (u > o.en_uzun) {
            o.en_uzun = u;
        }
    }
    o.m = t.kova.size();
    std::cerr << "  [süre] n = " << std::setw(6) << anahtar.size() << ' '
              << etiket << ": " << std::fixed << std::setprecision(3)
              << sure * 1e3 << " ms\n";
    return o;
}

int main(int argc, char *argv[])
{
    long k_ust = 10;
    if (argc == 2) {
        try {
            std::size_t son;
            k_ust = std::stol(argv[1], &son);
            if (argv[1][son] != '\0') {
                k_ust = 0;
            }
        } catch (...) {
            k_ust = 0;
        }
    }
    if (argc > 2 || k_ust < 8 || k_ust > 16) {
        std::cerr << "kullanım: " << argv[0] << " [k_ust (8..16)]\n";
        return 2;
    }
    rastgele_tohum(2026);
    std::uint32_t taban = 2u * rastgele_sayi() + 1u;  // tek sayı: tersinir
    std::uint32_t tohum = rastgele_sayi();
    std::cout << "1) Çakışan bloklar: polinom 31, h = 31·h + b (mod 2^32)\n"
              << "  h(\"Aa\") = 65·31 + 97 = " << karma_polinom("Aa", 0u, 31u)
              << ", h(\"BB\") = 66·31 + 66 = " << karma_polinom("BB", 0u, 31u)
              << '\n'
              << "  eşit uzunluklu bloklar: h(xy) = h(x)·31^|y| + h(y) -> "
                 "2^k anahtarın karması aynı\n";
    for (std::size_t i = 0; i < 4; i++) {
        std::string s = carpisan_anahtar(i, 4);
        std::cout << "  " << s << " -> " << std::setw(10)
                  << karma_polinom(s, 0u, 31u) << "   (rastgele taban "
                  << taban << " ile: " << std::setw(10)
                  << karma_polinom(s, 0u, taban) << ")\n";
    }

    std::cout << "\n2) Zincirlemeli tabloya n ekleme (m = 16'dan başlar, "
                 "α > 1 olunca × 2);\n   sayı = anahtar karşılaştırması "
                 "(güncelleme için zincir aranır)\n"
              << "  gizli tohumlar (ortak LCG, tohum 2026): taban = " << taban
              << ", tohum = " << tohum << '\n'
              << "  a) anahtar karşılaştırması\n"
              << "        n     saldırı    n(n−1)/2   rastgele    tohum h0   "
                 "taban/alt  taban/üst  FNV tohum\n";
    std::vector<std::vector<Olcum>> sonuc(17);
    for (int k = 8; k <= static_cast<int>(k_ust); k++) {
        std::size_t n = std::size_t{1} << k;
        std::vector<std::string> anahtar(n);
        std::vector<std::string> rastgele(n);
        rastgele_tohum(42);
        for (std::size_t i = 0; i < n; i++) {
            anahtar[i] = carpisan_anahtar(i, k);
            rastgele[i] = rastgele_anahtar(k);
        }
        std::vector<Olcum>& o = sonuc[k];
        o.push_back(dene(anahtar, POLINOM, 0, false, "saldırı (polinom 31)"));
        o.push_back(dene(rastgele, POLINOM, 0, false,
                         "rastgele (polinom 31)"));
        o.push_back(dene(anahtar, POLINOM_TOHUM, tohum, false,
                         "saldırı, tohumlu h0"));
        o.push_back(dene(anahtar, RASTGELE_TABAN, taban, false,
                         "saldırı, rastgele taban/alt"));
        o.push_back(dene(anahtar, RASTGELE_TABAN, taban, true,
                         "saldırı, rastgele taban/üst"));
        o.push_back(dene(anahtar, FNV_TOHUM, tohum, false,
                         "saldırı, tohumlu FNV-1a"));
        std::cout << "  " << std::setw(7) << n << ' ' << std::setw(11)
                  << o[0].karsilastirma << ' ' << std::setw(11)
                  << static_cast<long long>(n * (n - 1) / 2) << ' '
                  << std::setw(10) << o[1].karsilastirma << ' '
                  << std::setw(11) << o[2].karsilastirma << ' '
                  << std::setw(11) << o[3].karsilastirma << ' '
                  << std::setw(10) << o[4].karsilastirma << ' '
                  << std::setw(10) << o[5].karsilastirma << '\n';
    }
    std::cout << "  b) n × 2 olunca karşılaştırma kaç katına çıktı?\n"
              << "        n  saldırı  rastgele  tohum h0  taban/alt  "
                 "taban/üst  FNV tohum\n";
    const int genislik[6] = {8, 9, 9, 10, 10, 10};
    for (int k = 9; k <= static_cast<int>(k_ust); k++) {
        std::cout << "  " << std::setw(7) << (std::size_t{1} << k);
        for (int i = 0; i < 6; i++) {
            std::cout << ' ' << std::fixed << std::setprecision(2)
                      << std::setw(genislik[i])
                      << static_cast<double>(sonuc[k][i].karsilastirma) /
                             static_cast<double>(
                                 sonuc[k - 1][i].karsilastirma);
        }
        std::cout << '\n';
    }
    std::cout << "  c) dolu kova sayısı / m (en uzun zincir)\n"
              << "        n        m    saldırı      rastgele     taban/alt   "
                 "  taban/üst     FNV tohum\n";
    for (int k = 8; k <= static_cast<int>(k_ust); k++) {
        const std::vector<Olcum>& o = sonuc[k];
        std::cout << "  " << std::setw(7) << (std::size_t{1} << k) << ' '
                  << std::setw(8) << o[0].m;
        for (int i : {0, 1, 3, 4, 5}) {
            std::cout << ' ' << std::setw(6) << o[i].dolu << " ("
                      << std::setw(5) << o[i].en_uzun << ')';
        }
        std::cout << '\n';
    }
    std::cout << "  tohum h0 SAVUNMAZ: h0·31^L eşit uzunluklu her anahtara "
                 "aynı eklenir (çakışma yapıdadır).\n"
              << "  taban/alt: h = h(Aa…Aa) + (taban − 31)·X, X = Σ "
                 "taban^(2i) (BB bloklarının i konumlarında);\n   taban − 31 "
                 "= 2^" << iki_kuvveti(taban - 31u) << " · tek ve taban² − 1 "
                 "= 2^" << iki_kuvveti(taban * taban - 1u)
              << " · tek olduğundan X ≡ BB sayısı (mod 2^"
              << iki_kuvveti(taban * taban - 1u) << "):\n   indisin alt "
                 "bitleri yalnız BB sayısını taşır, birkaç kova dolar (tablo "
                 "c) -> karesel büyüme sürer.\n"
              << "  taban/üst ve FNV tohum: doğrusal büyüme. Gerçek savunma: "
                 "anahtarlı karma (Python: SipHash).\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
 * (std::hash<std::string> gerçekleştirime bağlı; libstdc++'ta
 * çalıştırmalar arasında aynı: rastgele tohum yok); Python — dict/set
 * (str ve bytes karması tohumlu SipHash ailesi; PEP 456, Python 3.4+). */

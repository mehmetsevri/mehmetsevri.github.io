/* H10_04_dogrusal_yoklama.cpp — AP-2 Hafta 10 · Örnek 4 (★★★)
 * Amaç    : Doğrusal yoklamalı açık adresleme (m = 11): yoklama dizisi,
 *           birincil kümelenme; mezar taşıyla silme (arama kopmaz),
 *           mezar taşının yeniden kullanımı; mezar taşlarının etkisi ve
 *           temizleyerek yeniden kurma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_04_dogrusal_yoklama.cpp -o H10_04_dogrusal_yoklama
 * Çalıştır: ./H10_04_dogrusal_yoklama
 * Eşleri  : c/H10_04_dogrusal_yoklama.c ·
 *           python/H10_04_dogrusal_yoklama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

enum { BOS = 0, DOLU = 1, MEZAR = 2 };

struct Hucre {
    int durum = BOS;
    std::string anahtar;         // yalnız DOLU iken anlamlı
    int deger = 0;
};

struct Tablo {
    std::vector<Hucre> hucre;    // vektör kendi belleğini yönetir (RAII)
    std::size_t dolu = 0;
    std::size_t mezar = 0;
    explicit Tablo(std::size_t m) : hucre(m) {}
};

static long long yoklama_sayisi = 0;         // bakılan hücre sayısı
static std::vector<std::size_t> yol;         // son işlemin yoklama yolu

static std::uint32_t karma_fnv1a(const std::string& s)
{
    std::uint32_t h = 2166136261u;
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

static std::size_t ev(const Tablo& t, const std::string& anahtar)
{
    return karma_fnv1a(anahtar) % t.hucre.size();
}

// Anahtarı arar: bulursa hücre indisi, yoksa -1. yer: eklenecek hücre —
// yoldaki İLK mezar taşı, yoksa durulan BOŞ hücre; tablo doluysa -1.
// Mezar taşı aramayı DURDURMAZ; yalnız BOŞ hücre durdurur.
static long bul(const Tablo& t, const std::string& anahtar, long& yer)
{
    std::size_t m = t.hucre.size();
    std::size_t i = ev(t, anahtar);
    long ilk_mezar = -1;
    yol.clear();
    for (std::size_t adim = 0; adim < m; adim++) {
        yoklama_sayisi++;
        if (yol.size() < 64) {
            yol.push_back(i);
        }
        const Hucre& h = t.hucre[i];
        if (h.durum == BOS) {
            yer = ilk_mezar >= 0 ? ilk_mezar : static_cast<long>(i);
            return -1;
        }
        if (h.durum == MEZAR) {
            if (ilk_mezar < 0) {
                ilk_mezar = static_cast<long>(i);
            }
        } else if (h.anahtar == anahtar) {
            return static_cast<long>(i);
        }
        i = (i + 1) % m;                     // doğrusal yoklama
    }
    yer = ilk_mezar;                         // BOŞ hücre hiç yok
    return -1;
}

// 1: yeni, 0: güncellendi, -1: yer yok
static int tablo_ekle(Tablo& t, const std::string& anahtar, int deger)
{
    long yer;
    long i = bul(t, anahtar, yer);
    if (i >= 0) {
        t.hucre[i].deger = deger;
        return 0;
    }
    if (yer < 0) {
        return -1;
    }
    Hucre& h = t.hucre[yer];
    if (h.durum == MEZAR) {
        t.mezar--;                           // mezar taşı yeniden kullanıldı
    }
    h.durum = DOLU;
    h.anahtar = anahtar;                     // kopya
    h.deger = deger;
    t.dolu++;
    return 1;
}

static bool tablo_ara(const Tablo& t, const std::string& anahtar,
                      int& deger)
{
    long yer;
    long i = bul(t, anahtar, yer);
    if (i < 0) {
        return false;
    }
    deger = t.hucre[i].deger;
    return true;
}

// Silinen hücre BOŞ yapılmaz: MEZAR (Hata Avcısı 3)
static bool tablo_sil(Tablo& t, const std::string& anahtar)
{
    long yer;
    long i = bul(t, anahtar, yer);
    if (i < 0) {
        return false;
    }
    t.hucre[i].anahtar.clear();
    t.hucre[i].durum = MEZAR;
    t.dolu--;
    t.mezar++;
    return true;
}

// Mezar taşlarını temizler: DOLU hücreler aynı m ile yeni diziye yeniden
// yerleştirilir (anahtar dizgileri std::move ile taşınır, kopyalanmaz)
static void yeniden_kur(Tablo& t)
{
    std::vector<Hucre> eski(t.hucre.size());
    std::swap(eski, t.hucre);                // t.hucre artık tümü BOŞ
    t.dolu = 0;
    t.mezar = 0;
    for (Hucre& h : eski) {
        if (h.durum == DOLU) {
            long yer;
            bul(t, h.anahtar, yer);
            t.hucre[yer] = std::move(h);
            t.dolu++;
        }
    }
}

static void tablo_yaz(const Tablo& t)
{
    std::cout << ' ';
    for (std::size_t i = 0; i < t.hucre.size(); i++) {
        const Hucre& h = t.hucre[i];
        if (h.durum == BOS) {
            std::cout << " [" << i << " -]";
        } else if (h.durum == MEZAR) {
            std::cout << " [" << i << " MEZAR]";
        } else {
            std::cout << " [" << i << ' ' << h.anahtar << ']';
        }
    }
    std::cout << '\n';
}

static void yol_yaz()
{
    std::cout << "yoklama";
    for (std::size_t k : yol) {
        std::cout << ' ' << k;
    }
    std::cout << " (" << yol.size() << ')';
}

// BOŞ olmayan ardışık hücre öbekleri (dairesel): birincil kümelenme
static void kumeleri_yaz(const Tablo& t)
{
    std::size_t m = t.hucre.size();
    std::size_t bas = 0;
    while (bas < m && t.hucre[bas].durum != BOS) {
        bas++;                               // ilk BOŞ hücre
    }
    if (bas == m) {
        std::cout << "  küme: tablonun tamamı (BOŞ hücre yok)\n";
        return;
    }
    std::cout << "  kümeler:";
    std::size_t i = (bas + 1) % m;
    for (std::size_t adim = 0; adim < m; adim++) {
        if (t.hucre[i].durum != BOS) {
            std::size_t ilk = i;
            std::size_t uzunluk = 0;
            while (t.hucre[i].durum != BOS) {
                uzunluk++;
                i = (i + 1) % m;
                adim++;
            }
            std::cout << " [" << ilk << ".." << (i + m - 1) % m << "] "
                      << uzunluk << " hücre;";
        }
        i = (i + 1) % m;
    }
    std::cout << '\n';
}

// Bölüm 4: rastgele anahtarlarla başarısız/başarılı ortalama yoklama
static void olc_satiri(const Tablo& t, const std::string& tur,
                       const std::vector<std::string>& anahtar)
{
    int deger;
    yoklama_sayisi = 0;
    for (int q = 0; q < 1000; q++) {
        tablo_ara(t, "y" + std::to_string(rastgele_sayi()), deger);
    }
    double basarisiz = yoklama_sayisi / 1000.0;
    yoklama_sayisi = 0;
    for (const std::string& a : anahtar) {
        tablo_ara(t, a, deger);
    }
    double basarili = static_cast<double>(yoklama_sayisi) / anahtar.size();
    std::cout << "  " << std::setw(5) << tur << ' ' << std::setw(6)
              << t.dolu << ' ' << std::setw(6) << t.mezar << std::fixed
              << std::setprecision(3) << ' ' << std::setw(10)
              << static_cast<double>(t.dolu + t.mezar) / t.hucre.size()
              << ' ' << std::setw(10) << basarili << ' ' << std::setw(10)
              << basarisiz << '\n';
}

int main()
{
    const std::vector<std::string> ad = {"ali", "ayşe", "can", "elif",
                                         "deniz", "zeynep", "mert", "ece"};
    const std::vector<int> not_ = {70, 85, 60, 90, 75, 95, 55, 80};
    Tablo t(11);

    std::cout << "1) Ekleme: ev = FNV-1a mod 11, dolu hücrede bir sağa "
                 "(i + 1) mod m\n";
    for (int k = 0; k < 8; k++) {
        tablo_ekle(t, ad[k], not_[k]);
        std::cout << "  ekle " << ad[k] << ": ev " << ev(t, ad[k]) << ", ";
        yol_yaz();
        std::cout << " -> hücre " << yol.back() << '\n';
    }
    tablo_yaz(t);
    std::cout << "  dolu = " << t.dolu << ", α = " << std::fixed
              << std::setprecision(3)
              << static_cast<double>(t.dolu) / t.hucre.size() << '\n';
    kumeleri_yaz(t);

    std::cout << "\n2) Mezar taşıyla silme: sil can (hücre 8 -> MEZAR)\n";
    tablo_sil(t, "can");
    tablo_yaz(t);
    const std::vector<std::string> aranan = {"ece", "mert", "umut", "can"};
    for (const std::string& a : aranan) {
        int deger;
        bool var = tablo_ara(t, a, deger);
        std::cout << "  ara " << a << ": ev " << ev(t, a) << ", ";
        yol_yaz();
        if (var) {
            std::cout << " -> " << deger << '\n';
        } else {
            std::cout << " -> YOK (BOŞ hücrede durdu)\n";
        }
    }
    std::cout << "  (MEZAR aramayı durdurmaz: ece, 8'deki mezar taşını "
                 "geçerek bulundu)\n";

    std::cout << "\n3) Mezar taşının yeniden kullanımı: ekle kerem\n";
    tablo_ekle(t, "kerem", 65);
    std::cout << "  ekle kerem: ev " << ev(t, "kerem") << ", ";
    yol_yaz();
    std::cout << " -> hücre 8 (ilk mezar taşı; yinelenen olmasın diye BOŞ "
                 "hücreye kadar arandı)\n";
    tablo_yaz(t);
    std::cout << "  dolu = " << t.dolu << ", mezar = " << t.mezar << '\n';

    std::cout << "\n4) Mezar taşı birikimi: m = 1024, 512 anahtar; her "
                 "turda 512 sil + 512 ekle\n"
              << "  (doluluk = (dolu + mezar) / m; ortalama yoklama: "
                 "başarılı = tablodaki 512 anahtar,\n   başarısız = 1000 "
                 "olmayan anahtar)\n"
              << "    tur   dolu  mezar   doluluk   başarılı  başarısız\n";
    rastgele_tohum(42);
    Tablo b(1024);
    std::vector<std::string> anahtar(512);
    for (int i = 0; i < 512; i++) {
        do {
            anahtar[i] = "a" + std::to_string(rastgele_sayi());
        } while (tablo_ekle(b, anahtar[i], i) != 1);
    }
    olc_satiri(b, "0", anahtar);
    for (int tur = 1; tur <= 6; tur++) {
        for (int k = 0; k < 512; k++) {
            int s = rastgele_aralik(0, 511);
            tablo_sil(b, anahtar[s]);
            do {
                anahtar[s] = "a" + std::to_string(rastgele_sayi());
            } while (tablo_ekle(b, anahtar[s], k) != 1);
        }
        olc_satiri(b, std::to_string(tur), anahtar);
    }
    yeniden_kur(b);
    olc_satiri(b, "kurma", anahtar);
    std::cout << "  (kurma: 6. turdan sonra yeniden kurma — mezar taşları "
                 "temizlendi, aynı m)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — standart kütüphanede açık
 * adresleme yok (std::unordered_map libstdc++'ta zincirlemedir);
 * Python — dict (CPython: açık adresleme; silinen yuva "dummy" olarak
 * işaretlenir = mezar taşı). */

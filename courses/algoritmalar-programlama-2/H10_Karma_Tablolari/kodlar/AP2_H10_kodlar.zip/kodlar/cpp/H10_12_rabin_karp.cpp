/* H10_12_rabin_karp.cpp — AP-2 Hafta 10 · Örnek 12 (★★★)
 * Amaç    : Rabin–Karp: kayan karma t_{s+1} = (d·(t_s − T[s]·h) + T[s+m])
 *           mod q, h = d^(m−1) mod q; her karma eşitliği karakter karakter
 *           doğrulanır; küçük asal modülle SAHTE eşleşme sayısı, büyük
 *           modülle; mod 2^32 işaretsiz sürüm; negatif ara değerin kalanı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_12_rabin_karp.cpp -o H10_12_rabin_karp
 * Çalıştır: ./H10_12_rabin_karp
 * Eşleri  : c/H10_12_rabin_karp.c · python/H10_12_rabin_karp.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Sonuc {
    long long esitlik = 0;       // karma eşitliği (aday) sayısı
    long long gercek = 0;        // doğrulanan eşleşme
    long long sahte = 0;         // karma eşit, metin farklı
    long long karsilastirma = 0; // doğrulamadaki karakter karşılaştırması
    std::vector<std::size_t> konum;
};

// Aday kaymayı doğrula: karakter karakter (karşılaştırma sayılır)
static void dogrula(const std::string& t, std::size_t s,
                    const std::string& p, Sonuc& r)
{
    std::size_t j = 0;
    r.esitlik++;
    while (j < p.size()) {
        r.karsilastirma++;
        if (t[s + j] != p[j]) {
            break;
        }
        j++;
    }
    if (j == p.size()) {
        r.konum.push_back(s);
        r.gercek++;
    } else {
        r.sahte++;                           // karma eşitliği ≠ eşleşme
    }
}

static long long bayt(const std::string& s, std::size_t i)
{
    return static_cast<unsigned char>(s[i]);
}

// Asal modüllü Rabin–Karp (q < 2^31: ara değerler long long'a sığar)
static Sonuc rk_ara(const std::string& t, const std::string& p, long long d,
                    long long q)
{
    Sonuc r;
    std::size_t n = t.size();
    std::size_t m = p.size();
    if (m == 0 || m > n) {
        return r;
    }
    long long h = 1;                         // d^(m-1) mod q
    for (std::size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    long long hp = 0;
    long long ht = 0;
    for (std::size_t i = 0; i < m; i++) {    // Horner
        hp = (d * hp + bayt(p, i)) % q;
        ht = (d * ht + bayt(t, i)) % q;
    }
    for (std::size_t s = 0;; s++) {
        if (hp == ht) {
            dogrula(t, s, p, r);
        }
        if (s + m >= n) {
            break;
        }
        // + q: C++'ta % bölünenin işaretini alır; ara değer negatif olmasın
        ht = (d * (ht + q - bayt(t, s) * h % q) + bayt(t, s + m)) % q;
    }
    return r;
}

// mod 2^32 sürümü: std::uint32_t aritmetiği kendiliğinden sarar (tanımlı)
static Sonuc rk_ara32(const std::string& t, const std::string& p,
                      std::uint32_t d)
{
    Sonuc r;
    std::size_t n = t.size();
    std::size_t m = p.size();
    if (m == 0 || m > n) {
        return r;
    }
    std::uint32_t h = 1;
    for (std::size_t i = 1; i < m; i++) {
        h *= d;
    }
    std::uint32_t hp = 0;
    std::uint32_t ht = 0;
    for (std::size_t i = 0; i < m; i++) {
        hp = d * hp + static_cast<unsigned char>(p[i]);
        ht = d * ht + static_cast<unsigned char>(t[i]);
    }
    for (std::size_t s = 0;; s++) {
        if (hp == ht) {
            dogrula(t, s, p, r);
        }
        if (s + m >= n) {
            break;
        }
        std::uint32_t cikan = static_cast<unsigned char>(t[s]);
        ht = d * (ht - cikan * h) + static_cast<unsigned char>(t[s + m]);
    }
    return r;
}

static void sonuc_satiri(const std::string& ad, const Sonuc& r)
{
    std::cout << "  " << std::setw(10) << r.esitlik << ' ' << std::setw(8)
              << r.gercek << ' ' << std::setw(8) << r.sahte << ' '
              << std::setw(12) << r.karsilastirma << "  " << ad << '\n';
}

// Tek pencerenin karması (Horner, mod q)
static long long karma_mod(const std::string& s, long long d, long long q)
{
    long long h = 0;
    for (std::size_t i = 0; i < s.size(); i++) {
        h = (d * h + bayt(s, i)) % q;
    }
    return h;
}

// Kâhin: naif arama (Örnek 11) ile eşleşme sayısı
static long long naif_say(const std::string& t, const std::string& p)
{
    long long say = 0;
    for (std::size_t s = 0; s + p.size() <= t.size(); s++) {
        std::size_t j = 0;
        while (j < p.size() && t[s + j] == p[j]) {
            j++;
        }
        say += j == p.size();
    }
    return say;
}

int main()
{
    // 1) Ondalık rakamlar, d = 10, q = 13 (Cormen vd., 2022, § 32.2'deki
    // örnekle aynı veri)
    const std::string T = "2359023141526739921";
    const std::string P = "31415";
    std::size_t n = T.size();
    std::size_t m = P.size();
    std::vector<long long> t(n);
    std::vector<long long> p(m);
    for (std::size_t i = 0; i < n; i++) {
        t[i] = T[i] - '0';
    }
    for (std::size_t i = 0; i < m; i++) {
        p[i] = P[i] - '0';
    }
    const long long d = 10;
    const long long q = 13;
    long long h = 1;
    for (std::size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    long long hp = 0;
    long long ht = 0;
    for (std::size_t i = 0; i < m; i++) {
        hp = (d * hp + p[i]) % q;
        ht = (d * ht + t[i]) % q;
    }
    std::cout << "1) T = " << T << ", P = " << P << ", d = " << d
              << ", q = " << q << '\n'
              << "  h = d^(m−1) mod q = " << h << ", p = P mod q = " << hp
              << '\n'
              << "   s  pencere  t_s  sonuç\n";
    std::vector<long long> ts(n);            // bölüm 2 için t_s
    for (std::size_t s = 0; s + m <= n; s++) {
        std::cout << "  " << std::setw(2) << s << "  " << T.substr(s, m)
                  << "  " << std::setw(3) << ht << "  ";
        if (ht == hp) {
            bool esit = T.compare(s, m, P) == 0;
            std::cout << (esit ? "karma eşit -> doğrulandı: EŞLEŞME"
                               : "karma eşit -> doğrulama: SAHTE eşleşme")
                      << '\n';
        } else {
            std::cout << "-\n";
        }
        ts[s] = ht;
        if (s + m < n) {
            ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q;
        }
    }

    std::cout << "\n2) Negatif ara değerin kalanı (H1 Dil Penceresi): x = "
                 "t_s − T[s]·h\n"
              << "   s  t_s  T[s]·h     x  C/C++: x % q  Python: x % q  "
                 "(t_s + q − T[s]·h % q) % q\n";
    for (std::size_t s = 0; s < 6; s++) {
        long long x = ts[s] - t[s] * h;      // negatif olabilir
        long long c_kalan = x % q;           // C++: sıfıra doğru kesme
        long long taban_kalan = (x % q + q) % q;   // Python'un % kuralı
        long long arti_q = (ts[s] + q - t[s] * h % q) % q;
        std::cout << "  " << std::setw(2) << s << ' ' << std::setw(4)
                  << ts[s] << ' ' << std::setw(7) << t[s] * h << ' '
                  << std::setw(5) << x << ' ' << std::setw(13) << c_kalan
                  << ' ' << std::setw(14) << taban_kalan << ' '
                  << std::setw(28) << arti_q << '\n';
    }
    std::cout << "  (kodda negatif ara değer oluşmaz: T[s]·h % q "
                 "çıkarılmadan önce + q eklenir)\n";

    // 3) Bayt metni, d = 256
    const std::size_t N = 100000;
    std::string metin(N, ' ');
    rastgele_tohum(42);
    for (std::size_t i = 0; i < N; i++) {
        metin[i] = static_cast<char>('a' + rastgele_aralik(0, 3));
    }
    const std::string desen = metin.substr(50000, 8);
    std::cout << "\n3) Rastgele metin n = " << N << " ({a, b, c, d}), desen "
              << "m = 8 (metin[50000..50007] = " << desen << ")\n"
              << "  naif kâhin: " << naif_say(metin, desen)
              << " eşleşme; kayma sayısı = " << N - 8 + 1 << '\n'
              << "    eşitlik   gerçek    sahte  karşılaştır.  karma\n";
    sonuc_satiri("d = 256, q = 13 (küçük asal)", rk_ara(metin, desen, 256,
                                                         13));
    sonuc_satiri("d = 256, q = 1009", rk_ara(metin, desen, 256, 1009));
    sonuc_satiri("d = 256, q = 1000003", rk_ara(metin, desen, 256, 1000003));
    sonuc_satiri("d = 256, q = 2^31 − 1",
                 rk_ara(metin, desen, 256, 2147483647));
    sonuc_satiri("d = 31, mod 2^32 (uint32_t sarması)",
                 rk_ara32(metin, desen, 31u));
    Sonuc r = rk_ara32(metin, desen, 256u);
    sonuc_satiri("d = 256, mod 2^32 (kötü: 256^4 ≡ 0)", r);
    std::cout << "  gerçek eşleşme konumları:";
    for (std::size_t i = 0; i < r.konum.size() && i < 8; i++) {
        std::cout << ' ' << r.konum[i];
    }
    std::cout << "\n  (d = 256 ve mod 2^32'de pencerenin yalnız son 4 baytı "
                 "karmayı belirler)\n"
              << "  yapısal çakışma, d = 256 = 2^8, q = 2^31 − 1: "
                 "h(bbdcbbbb) = " << karma_mod("bbdcbbbb", 256, 2147483647)
              << ", h(aacbdddd) = " << karma_mod("aacbdddd", 256, 2147483647)
              << '\n'
              << "  (2^31 ≡ 1 olduğundan 256^k ≡ 2^(8k mod 31): baytlar bit "
                 "konumlarında üst üste biner)\n";

    std::cout << "\n4) En kötü durum: T = a^10000\n"
              << "    eşitlik   gerçek    sahte  karşılaştır.  desen, karma\n";
    const std::string a_n(10000, 'a');
    std::string a100(100, 'a');
    sonuc_satiri("a^100, q = 1000003 (her kayma gerçek)",
                 rk_ara(a_n, a100, 256, 1000003));
    a100[99] = 'n';                          // 'n' − 'a' = 13
    sonuc_satiri("a^99 n, q = 1000003", rk_ara(a_n, a100, 256, 1000003));
    sonuc_satiri("a^99 n, q = 13 ('n' − 'a' = 13 ≡ 0)",
                 rk_ara(a_n, a100, 256, 13));
    std::cout << "  (her pencerede karma eşitse doğrulama Θ(n·m): "
                 "Rabin–Karp'ın en kötü durumu)\n";
    return 0;
}

/* Kütüphane karşılığı: C — strstr; C++ — std::string::find,
 * std::search; Python — bytes.find / str.find (kullandıkları arama
 * algoritması gerçekleştirime bağlıdır). */

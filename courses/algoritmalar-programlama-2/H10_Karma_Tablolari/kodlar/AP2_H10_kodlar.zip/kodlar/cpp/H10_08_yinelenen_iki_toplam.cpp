/* H10_08_yinelenen_iki_toplam.cpp — AP-2 Hafta 10 · Örnek 8 (★★)
 * Amaç    : Karma tablosuyla O(n²) → O(n): (1) yinelenen numara tespiti
 *           (sayaçlı karma kümesi; H2'nin kaba kuvvetiyle aynı sonuç),
 *           (2) iki toplam (two-sum): a[i] + a[j] = T; kâhin O(n²) kaba
 *           kuvvet; karşılaştırma ve yoklama sayıları
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_08_yinelenen_iki_toplam.cpp -o H10_08_yinelenen_iki_toplam
 * Çalıştır: ./H10_08_yinelenen_iki_toplam
 * Eşleri  : c/H10_08_yinelenen_iki_toplam.c ·
 *           python/H10_08_yinelenen_iki_toplam.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

// Açık adresleme (doğrusal yoklama), uint32_t anahtar → int değer
struct Harita {
    std::vector<std::uint32_t> anahtar;
    std::vector<int> deger;
    std::vector<unsigned char> dolu;
    int p = 4;                   // m = 2^p ≥ 2n: α ≤ 1/2
    explicit Harita(std::size_t n)
    {
        while ((std::size_t{1} << p) < 2 * n) {
            p++;
        }
        std::size_t m = std::size_t{1} << p;
        anahtar.resize(m);
        deger.resize(m);
        dolu.assign(m, 0);
    }
};

static long long yoklama_sayisi = 0;
static long long karsilastirma_sayisi = 0;

static std::uint32_t karma_carpma(std::uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

// Anahtarın hücresini döndürür: bulunduysa var = true, yoksa ilk BOŞ hücre
static std::size_t harita_yer(const Harita& h, std::uint32_t k, bool& var)
{
    std::uint32_t maske = (std::uint32_t{1} << h.p) - 1u;
    std::uint32_t i = karma_carpma(k, h.p);
    for (;;) {
        yoklama_sayisi++;
        if (!h.dolu[i]) {
            var = false;
            return i;
        }
        if (h.anahtar[i] == k) {
            var = true;
            return i;
        }
        i = (i + 1u) & maske;
    }
}

// --- 1) Yinelenen tespiti ----------------------------------------------

// Kâhin (H2): tüm çiftler, eşit çift sayısı; n(n-1)/2 karşılaştırma
static long long cift_kaba(const std::vector<std::uint32_t>& a)
{
    long long cift = 0;
    for (std::size_t i = 0; i + 1 < a.size(); i++) {
        for (std::size_t j = i + 1; j < a.size(); j++) {
            karsilastirma_sayisi++;
            cift += a[i] == a[j];
        }
    }
    return cift;
}

// Karma ile: her değerin kaç kez geçtiği; eşit çift = Σ c(c-1)/2.
// Yinelenen değerler (c ≥ 2) (değer, sayı) çiftleri olarak yin'e yazılır.
static long long cift_karma(const std::vector<std::uint32_t>& a,
                            std::vector<std::pair<std::uint32_t, int>>& yin)
{
    Harita h(a.size());
    for (std::uint32_t x : a) {
        bool var;
        std::size_t yer = harita_yer(h, x, var);
        if (var) {
            h.deger[yer]++;
        } else {
            h.dolu[yer] = 1;
            h.anahtar[yer] = x;
            h.deger[yer] = 1;
        }
    }
    long long cift = 0;
    yin.clear();
    for (std::size_t i = 0; i < h.dolu.size(); i++) {
        if (h.dolu[i] && h.deger[i] >= 2) {
            long long c = h.deger[i];
            cift += c * (c - 1) / 2;
            yin.emplace_back(h.anahtar[i], h.deger[i]);
        }
    }
    return cift;
}

static void senaryo(const std::string& ad,
                    const std::vector<std::uint32_t>& a)
{
    std::vector<std::pair<std::uint32_t, int>> yin;
    karsilastirma_sayisi = 0;
    long long c1 = cift_kaba(a);
    yoklama_sayisi = 0;
    long long c2 = cift_karma(a, yin);
    // çıktı biçimi: yinelenenleri değere göre sırala (karma sırası
    // tanımsız) — küçük dizi, araya ekleme
    for (std::size_t i = 1; i < yin.size(); i++) {
        std::pair<std::uint32_t, int> x = yin[i];
        std::size_t j = i;
        while (j > 0 && yin[j - 1].first > x.first) {
            yin[j] = yin[j - 1];
            j--;
        }
        yin[j] = x;
    }
    std::cout << "  " << ad << " n=" << a.size() << ": kaba " << c1
              << " çift (kar=" << karsilastirma_sayisi << ") | karma " << c2
              << " çift (yokl=" << yoklama_sayisi << ") | yinelenen:";
    if (yin.empty()) {
        std::cout << " yok";
    }
    for (const auto& [deger, sayi] : yin) {
        std::cout << ' ' << deger << "×" << sayi;
    }
    std::cout << '\n';
}

// --- 2) İki toplam -------------------------------------------------------

// Kâhin: en küçük j, sonra en küçük i ile a[i] + a[j] = T
static bool iki_toplam_kaba(const std::vector<std::uint32_t>& a,
                            std::uint32_t T, std::size_t& bi,
                            std::size_t& bj)
{
    for (std::size_t j = 1; j < a.size(); j++) {
        for (std::size_t i = 0; i < j; i++) {
            karsilastirma_sayisi++;
            if (std::uint64_t{a[i]} + a[j] == T) {
                bi = i;
                bj = j;
                return true;
            }
        }
    }
    return false;
}

// Karma: soldan sağa; T - a[j] daha önce görüldüyse ilk görüldüğü i
static bool iki_toplam_karma(const std::vector<std::uint32_t>& a,
                             std::uint32_t T, std::size_t& bi,
                             std::size_t& bj)
{
    Harita h(a.size());
    for (std::size_t j = 0; j < a.size(); j++) {
        bool var;
        if (a[j] <= T) {
            std::size_t yer = harita_yer(h, T - a[j], var);
            if (var) {
                bi = static_cast<std::size_t>(h.deger[yer]);
                bj = j;
                return true;
            }
        }
        std::size_t yer = harita_yer(h, a[j], var);
        if (!var) {                          // yalnız ilk konum tutulur
            h.dolu[yer] = 1;
            h.anahtar[yer] = a[j];
            h.deger[yer] = static_cast<int>(j);
        }
    }
    return false;
}

static void iki_toplam_satiri(const std::string& ad,
                              const std::vector<std::uint32_t>& a,
                              std::uint32_t T, bool kaba_da)
{
    std::size_t i2 = 0, j2 = 0;
    yoklama_sayisi = 0;
    bool b2 = iki_toplam_karma(a, T, i2, j2);
    std::cout << "  " << ad << ", n = " << a.size() << ", T = " << T << ": ";
    if (b2) {
        std::cout << '(' << i2 << ", " << j2 << ") " << a[i2] << " + "
                  << a[j2];
    } else {
        std::cout << "çift yok";
    }
    std::cout << " | karma yokl=" << yoklama_sayisi;
    if (kaba_da) {
        std::size_t i1 = 0, j1 = 0;
        karsilastirma_sayisi = 0;
        bool b1 = iki_toplam_kaba(a, T, i1, j1);
        bool ayni = b1 == b2 && (!b1 || (i1 == i2 && j1 == j2));
        std::cout << " | kaba kar=" << karsilastirma_sayisi << ", aynı mı? "
                  << (ayni ? "evet" : "HAYIR");
    }
    std::cout << '\n';
}

int main()
{
    std::cout << "1) Yinelenen tespiti: eşit çift sayısı = Σ c(c-1)/2 (c: "
                 "bir değerin kaç kez geçtiği)\n";
    senaryo("S1", {11, 22, 33, 44, 55});
    senaryo("S2", {7, 3, 7, 5, 3, 7});
    senaryo("S3", {9, 9, 1, 2, 3, 4});
    senaryo("S4", {1, 2, 3, 4, 8, 8});

    std::cout << "\n  Öğrenci numaraları 2400000000 + karıştırılmış 0..n-1, "
                 "a[n/2] = a[0] kopyası (tohum 42)\n"
              << "         n   çift  karma yokl.  yokl./n   kaba kar.  "
                 "(kaba = n(n-1)/2)\n";
    for (std::size_t n : {1000, 2000, 10000, 100000}) {
        std::vector<int> sira(n);
        for (std::size_t i = 0; i < n; i++) {
            sira[i] = static_cast<int>(i);
        }
        rastgele_tohum(42);
        rastgele_karistir(sira);
        std::vector<std::uint32_t> no(n);
        for (std::size_t i = 0; i < n; i++) {
            no[i] = 2400000000u + static_cast<std::uint32_t>(sira[i]);
        }
        no[n / 2] = no[0];
        std::vector<std::pair<std::uint32_t, int>> yin;
        yoklama_sayisi = 0;
        long long cift = cift_karma(no, yin);
        std::cout << "  " << std::setw(8) << n << ' ' << std::setw(6) << cift
                  << ' ' << std::setw(12) << yoklama_sayisi << ' '
                  << std::fixed << std::setprecision(3) << std::setw(8)
                  << static_cast<double>(yoklama_sayisi) / n;
        if (n <= 2000) {
            karsilastirma_sayisi = 0;
            long long c1 = cift_kaba(no);
            std::cout << ' ' << std::setw(11) << karsilastirma_sayisi << "  "
                      << (c1 == cift ? "(aynı sonuç)" : "(FARKLI!)") << '\n';
        } else {
            std::cout << ' ' << std::setw(11) << "-" << '\n';
        }
    }

    std::cout << "\n2) İki toplam: a[i] + a[j] = T olan ilk çift (en küçük "
                 "j, sonra en küçük i)\n";
    const std::vector<std::uint32_t> k = {8, 3, 11, 7, 2, 15, 5};
    iki_toplam_satiri("küçük", k, 9, true);
    iki_toplam_satiri("küçük", k, 100, true);
    for (std::size_t n : {1000, 2000, 100000}) {
        std::vector<std::uint32_t> a(n);
        rastgele_tohum(7);
        for (std::size_t i = 0; i < n; i++) {
            a[i] = 2u * static_cast<std::uint32_t>(
                            rastgele_aralik(0, 499999));     // çift
        }
        iki_toplam_satiri("tek T", a, 999999, n <= 2000);   // çözüm yok
        iki_toplam_satiri("son ikili", a, a[n - 2] + a[n - 1], n <= 2000);
    }
    std::cout << "  (tek T: tüm sayılar çift olduğundan çözüm yok — en kötü "
                 "durum: kaba n(n-1)/2 karşılaştırma,\n   karma öğe başına "
                 "iki arama: toplam Θ(n) yoklama)\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_set /
 * std::unordered_map (find, count); Python — set / dict
 * (x in gorulen, gorulen[x] = j). */

"""H10_Q04_kalan.py — AP-2 Hafta 10 · Quiz 4
Amaç    : Negatif ara değerin kalanı (Rabin–Karp güncellemesi)
Çalıştır: python3 H10_Q04_kalan.py
Eşleri  : quiz/H10_Q04_kalan.c
"""


def main():
    x = 3 - 15                          # t_s − T[s]·h
    q = 13
    print(x % q, (x % q + q) % q)


if __name__ == "__main__":
    main()

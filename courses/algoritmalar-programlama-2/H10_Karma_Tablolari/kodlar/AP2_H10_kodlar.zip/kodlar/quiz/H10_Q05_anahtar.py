"""H10_Q05_anahtar.py — AP-2 Hafta 10 · Quiz 5
Amaç    : Sözlük anahtarı: değiştirilemez (karma edilebilir) türler
Çalıştır: python3 H10_Q05_anahtar.py
"""


def main():
    gruplar = {}
    for s in ("kitap", "takip"):
        anahtar = tuple(sorted(s))
        gruplar.setdefault(anahtar, []).append(s)
    print(len(gruplar))
    try:
        gruplar[sorted("elma")] = ["elma"]
        print("eklendi")
    except TypeError as e:
        print(type(e).__name__)


if __name__ == "__main__":
    main()

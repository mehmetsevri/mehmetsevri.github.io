/* H10_Q07_sarma.c — AP-2 Hafta 10 · Quiz 7
 * Amaç    : İşaretsiz taşma: polinom karmanın bir adımı (uint32_t)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H10_Q07_sarma.c \
 *           -o H10_Q07_sarma
 */
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    uint32_t h = 4294967295u;           /* 2^32 − 1 */
    h = 31u * h + 2u;
    printf("%lu\n", (unsigned long)h);
    return 0;
}

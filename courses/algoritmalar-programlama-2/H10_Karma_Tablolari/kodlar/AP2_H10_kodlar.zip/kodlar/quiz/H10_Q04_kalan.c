/* H10_Q04_kalan.c — AP-2 Hafta 10 · Quiz 4
 * Amaç    : Negatif ara değerin kalanı (Rabin–Karp güncellemesi)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H10_Q04_kalan.c \
 *           -o H10_Q04_kalan
 * Eşleri  : quiz/H10_Q04_kalan.py
 */
#include <stdio.h>

int main(void)
{
    long long x = 3 - 15;               /* t_s − T[s]·h */
    long long q = 13;
    printf("%lld %lld\n", x % q, (x % q + q) % q);
    return 0;
}

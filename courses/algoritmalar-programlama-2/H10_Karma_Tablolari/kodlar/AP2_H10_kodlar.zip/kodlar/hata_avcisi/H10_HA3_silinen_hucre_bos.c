/* H10_HA3_silinen_hucre_bos.c — AP-2 Hafta 10 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR
 * Hata    : doğrusal yoklamada silinen hücre BOŞ yapılıyor (mezar taşı
 *           yok). Arama BOŞ hücrede durduğu için silinen hücrenin ötesine
 *           yoklamayla yerleşmiş anahtarlar "kaybolur"; yeniden eklenince
 *           tabloda İKİ kopya oluşur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA3_silinen_hucre_bos.c -o H10_HA3_silinen_hucre_bos
 * Düzeltme: H10_HA3_silinen_hucre_bos_duzeltilmis.c (Örnek 4 ile aynı)
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define M 11

static const char *hucre[M];     /* NULL = BOŞ; dizgi değişmezlerine başvuru */

static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

/* Bulursa indis, yoksa -1; *yoklama: bakılan hücre sayısı */
static int ara(const char *anahtar, int *yoklama)
{
    int i = (int)(karma_fnv1a(anahtar) % M);
    *yoklama = 0;
    for (int adim = 0; adim < M; adim++) {
        (*yoklama)++;
        if (hucre[i] == NULL) {
            return -1;                       /* BOŞ: arama durur */
        }
        if (strcmp(hucre[i], anahtar) == 0) {
            return i;
        }
        i = (i + 1) % M;
    }
    return -1;
}

static void ekle(const char *anahtar)
{
    int y;
    if (ara(anahtar, &y) >= 0) {
        return;                              /* zaten var */
    }
    int i = (int)(karma_fnv1a(anahtar) % M);
    while (hucre[i] != NULL) {
        i = (i + 1) % M;
    }
    hucre[i] = anahtar;
}

static void sil(const char *anahtar)
{
    int y;
    int i = ara(anahtar, &y);
    if (i >= 0) {
        hucre[i] = NULL;                     /* HATA: mezar taşı olmalıydı */
    }
}

static void yaz(void)
{
    printf(" ");
    for (int i = 0; i < M; i++) {
        printf(" [%d %s]", i, hucre[i] ? hucre[i] : "-");
    }
    printf("\n");
}

int main(void)
{
    const char *ad[] = {"ali", "ayşe", "can", "elif", "deniz", "zeynep",
                        "mert", "ece"};
    for (int k = 0; k < 8; k++) {
        ekle(ad[k]);
    }
    printf("8 ekleme (Örnek 4 ile aynı):\n");
    yaz();
    sil("can");
    printf("sil can (hücre 8 BOŞ yapıldı):\n");
    yaz();
    const char *aranan[] = {"ece", "mert", "zeynep"};
    for (int k = 0; k < 3; k++) {
        int y;
        int i = ara(aranan[k], &y);
        printf("  ara %s: %s (%d yoklama)\n", aranan[k],
               i >= 0 ? "bulundu" : "YOK — tabloda olduğu hâlde!", y);
    }
    ekle("ece");
    printf("yeniden ekle ece:\n");
    yaz();
    int kopya = 0;
    for (int i = 0; i < M; i++) {
        kopya += hucre[i] != NULL && strcmp(hucre[i], "ece") == 0;
    }
    printf("  tablodaki \"ece\" sayısı: %d (1 olmalı)\n", kopya);
    return 0;
}

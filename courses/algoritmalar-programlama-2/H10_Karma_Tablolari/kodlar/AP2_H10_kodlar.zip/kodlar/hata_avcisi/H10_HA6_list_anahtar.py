"""H10_HA6_list_anahtar.py — AP-2 Hafta 10 · Hata Avcısı 6
BU DOSYA KASITLI HATA İÇERİR
Hata    : anagram gruplamada anahtar olarak sorted(sozcuk) — yani bir LIST —
          kullanılıyor. list değiştirilebilir (mutable) olduğu için karma
          edilemez: dict ve set anahtarı olamaz.
          Belirti: TypeError: unhashable type: 'list'
Çalıştır: python3 H10_HA6_list_anahtar.py
Düzeltme: H10_HA6_list_anahtar_duzeltilmis.py
"""


def main():
    sozcukler = ["kitap", "takip", "elma", "kalp", "plak"]
    gruplar = {}
    for s in sozcukler:
        anahtar = sorted(s)                  # HATA: list (değiştirilebilir)
        print(f"{s}: anahtar = {anahtar}")
        if anahtar not in gruplar:           # burada TypeError
            gruplar[anahtar] = []
        gruplar[anahtar].append(s)
    print(gruplar)


if __name__ == "__main__":
    main()

/* H10_HA5_dogrulamasiz_rabin_karp.c — AP-2 Hafta 10 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR
 * Hata    : Rabin–Karp'ta karma eşitliği doğrudan eşleşme sayılıyor;
 *           pencere karakter karakter DOĞRULANMIYOR. Farklı metinler aynı
 *           karmayı verebildiği için (sahte eşleşme) yanlış konumlar
 *           raporlanır; küçük modülde (q = 13) neredeyse her 13 pencereden
 *           biri.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA5_dogrulamasiz_rabin_karp.c ../c/ortak_rastgele.c \
 *           -I../c -o H10_HA5_dogrulamasiz_rabin_karp
 * Düzeltme: H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

/* Eşleşme sayısını döndürür; ilk 5 konumu yazdırır */
static long rk_ara(const unsigned char *t, size_t n, const unsigned char *p,
                   size_t m, long long d, long long q)
{
    long long h = 1;
    long long hp = 0;
    long long ht = 0;
    long say = 0;
    for (size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    for (size_t i = 0; i < m; i++) {
        hp = (d * hp + p[i]) % q;
        ht = (d * ht + t[i]) % q;
    }
    printf("  konumlar:");
    for (size_t s = 0;; s++) {
        if (hp == ht) {                      /* HATA: doğrulama yok */
            if (say < 5) {
                printf(" %zu", s);
            }
            say++;
        }
        if (s + m >= n) {
            break;
        }
        ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q;
    }
    printf("%s\n", say > 5 ? " …" : "");
    return say;
}

int main(void)
{
    const char *T = "2359023141526739921";
    const char *P = "31415";
    unsigned char t[32];
    unsigned char p[8];
    for (size_t i = 0; i < strlen(T); i++) {
        t[i] = (unsigned char)(T[i] - '0');
    }
    for (size_t i = 0; i < strlen(P); i++) {
        p[i] = (unsigned char)(P[i] - '0');
    }
    printf("T = %s, P = %s, d = 10, q = 13\n", T, P);
    long say = rk_ara(t, strlen(T), p, strlen(P), 10, 13);
    printf("  bildirilen eşleşme: %ld (doğrusu 1: yalnız kayma 6; 12'deki "
           "67399 sahte)\n", say);

    size_t N = 100000;
    unsigned char *metin = malloc(N);
    if (metin == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    for (size_t i = 0; i < N; i++) {
        metin[i] = (unsigned char)('a' + rastgele_aralik(0, 3));
    }
    printf("rastgele metin (Örnek 12), desen = metin[50000..50007], "
           "d = 256, q = 13\n");
    say = rk_ara(metin, N, metin + 50000, 8, 256, 13);
    printf("  bildirilen eşleşme: %ld (doğrusu 1)\n", say);
    free(metin);
    return 0;
}

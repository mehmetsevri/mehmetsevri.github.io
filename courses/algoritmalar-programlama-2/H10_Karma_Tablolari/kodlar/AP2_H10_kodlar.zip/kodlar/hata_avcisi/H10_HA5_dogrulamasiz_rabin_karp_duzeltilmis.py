"""H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis.py — AP-2 Hafta 10 · HA 5
Düzeltme: karma eşitliği yalnız ADAY'dır; pencere desenle karşılaştırılır
          (dilim eşitliği), eşitse eşleşme sayılır, değilse sahte eşleşme
          sayacı artar.
Çalıştır: python3 H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis.py
Hatalı  : H10_HA5_dogrulamasiz_rabin_karp.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402


def rk_ara(t, p, d, q):
    """Gerçek eşleşme sayısını döndürür; ilk 5 konumu yazdırır"""
    n, m = len(t), len(p)
    h = 1
    for _ in range(1, m):
        h = h * d % q
    hp = ht = 0
    for i in range(m):
        hp = (d * hp + p[i]) % q
        ht = (d * ht + t[i]) % q
    konum = []
    say = 0
    sahte = 0
    s = 0
    while True:
        if hp == ht:
            if t[s:s + m] == p:              # DÜZELTME: doğrula
                if say < 5:
                    konum.append(s)
                say += 1
            else:
                sahte += 1
        if s + m >= n:
            break
        ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q
        s += 1
    print("  konumlar:" + "".join(f" {k}" for k in konum)
          + (" …" if say > 5 else "") + f"; sahte eşleşme (elenen) = {sahte}")
    return say


def main():
    T, P = "2359023141526739921", "31415"
    t = [ord(c) - 48 for c in T]
    p = [ord(c) - 48 for c in P]
    print(f"T = {T}, P = {P}, d = 10, q = 13")
    print(f"  eşleşme: {rk_ara(t, p, 10, 13)}")
    rastgele_tohum(42)
    metin = bytes(97 + rastgele_aralik(0, 3) for _ in range(100000))
    print("rastgele metin (Örnek 12), desen = metin[50000..50007], "
          "d = 256, q = 13")
    print(f"  eşleşme: {rk_ara(metin, metin[50000:50008], 256, 13)}")


if __name__ == "__main__":
    main()

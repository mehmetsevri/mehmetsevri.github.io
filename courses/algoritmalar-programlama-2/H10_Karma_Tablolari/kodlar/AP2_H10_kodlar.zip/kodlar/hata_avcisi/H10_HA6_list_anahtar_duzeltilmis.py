"""H10_HA6_list_anahtar_duzeltilmis.py — AP-2 Hafta 10 · Hata Avcısı 6
Düzeltme: anahtar değiştirilemez (immutable) bir türe çevrilir:
          tuple(sorted(s)) ya da "".join(sorted(s)). Değiştirilemez nesnenin
          karması yaşamı boyunca sabittir; bu yüzden sözlük anahtarı olabilir.
          (Örnek 9'da anahtar bytes'tır.)
Çalıştır: python3 H10_HA6_list_anahtar_duzeltilmis.py
Hatalı  : H10_HA6_list_anahtar.py
"""


def main():
    sozcukler = ["kitap", "takip", "elma", "kalp", "plak"]
    gruplar = {}
    for s in sozcukler:
        anahtar = tuple(sorted(s))           # DÜZELTME: değiştirilemez
        print(f"{s}: anahtar = {anahtar}")
        if anahtar not in gruplar:
            gruplar[anahtar] = []
        gruplar[anahtar].append(s)
    # dict ekleme sırasını korur (Python 3.7+ dil güvencesi)
    for anahtar, uyeler in gruplar.items():
        print(f"  {''.join(anahtar)}: {' '.join(uyeler)}")


if __name__ == "__main__":
    main()

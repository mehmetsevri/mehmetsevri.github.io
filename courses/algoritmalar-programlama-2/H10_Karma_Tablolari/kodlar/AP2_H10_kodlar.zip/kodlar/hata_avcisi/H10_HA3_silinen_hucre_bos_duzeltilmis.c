/* H10_HA3_silinen_hucre_bos_duzeltilmis.c — AP-2 Hafta 10 · Hata Avcısı 3
 * Düzeltme: silinen hücre MEZAR (tombstone) olarak işaretlenir. Arama
 *           mezar taşında DURMAZ (yalnız BOŞ hücre durdurur); ekleme ilk
 *           mezar taşını yeniden kullanır ama önce BOŞ hücreye kadar arar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA3_silinen_hucre_bos_duzeltilmis.c \
 *           -o H10_HA3_silinen_hucre_bos_duzeltilmis
 * Hatalı  : H10_HA3_silinen_hucre_bos.c
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define M 11

enum { BOS = 0, DOLU = 1, MEZAR = 2 };

static int durum[M];
static const char *hucre[M];

static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

/* Bulursa indis, yoksa -1; *yer: ilk mezar taşı ya da durulan BOŞ hücre */
static int ara(const char *anahtar, int *yoklama, int *yer)
{
    int i = (int)(karma_fnv1a(anahtar) % M);
    int ilk_mezar = -1;
    *yoklama = 0;
    *yer = -1;
    for (int adim = 0; adim < M; adim++) {
        (*yoklama)++;
        if (durum[i] == BOS) {
            *yer = ilk_mezar >= 0 ? ilk_mezar : i;
            return -1;
        }
        if (durum[i] == MEZAR) {
            if (ilk_mezar < 0) {
                ilk_mezar = i;               /* DÜZELTME: durma, ilerle */
            }
        } else if (strcmp(hucre[i], anahtar) == 0) {
            return i;
        }
        i = (i + 1) % M;
    }
    *yer = ilk_mezar;
    return -1;
}

static void ekle(const char *anahtar)
{
    int y;
    int yer;
    if (ara(anahtar, &y, &yer) >= 0 || yer < 0) {
        return;                              /* zaten var ya da tablo dolu */
    }
    durum[yer] = DOLU;
    hucre[yer] = anahtar;
}

static void sil(const char *anahtar)
{
    int y;
    int yer;
    int i = ara(anahtar, &y, &yer);
    if (i >= 0) {
        durum[i] = MEZAR;                    /* DÜZELTME */
        hucre[i] = NULL;
    }
}

static void yaz(void)
{
    printf(" ");
    for (int i = 0; i < M; i++) {
        printf(" [%d %s]", i, durum[i] == DOLU ? hucre[i]
                              : durum[i] == MEZAR ? "MEZAR" : "-");
    }
    printf("\n");
}

int main(void)
{
    const char *ad[] = {"ali", "ayşe", "can", "elif", "deniz", "zeynep",
                        "mert", "ece"};
    for (int k = 0; k < 8; k++) {
        ekle(ad[k]);
    }
    printf("8 ekleme (Örnek 4 ile aynı):\n");
    yaz();
    sil("can");
    printf("sil can (hücre 8 MEZAR yapıldı):\n");
    yaz();
    const char *aranan[] = {"ece", "mert", "zeynep"};
    for (int k = 0; k < 3; k++) {
        int y;
        int yer;
        int i = ara(aranan[k], &y, &yer);
        printf("  ara %s: %s (%d yoklama)\n", aranan[k],
               i >= 0 ? "bulundu" : "YOK", y);
    }
    ekle("ece");
    printf("yeniden ekle ece (zaten var: değişiklik yok):\n");
    yaz();
    int kopya = 0;
    for (int i = 0; i < M; i++) {
        kopya += durum[i] == DOLU && strcmp(hucre[i], "ece") == 0;
    }
    printf("  tablodaki \"ece\" sayısı: %d (1 olmalı)\n", kopya);
    return 0;
}

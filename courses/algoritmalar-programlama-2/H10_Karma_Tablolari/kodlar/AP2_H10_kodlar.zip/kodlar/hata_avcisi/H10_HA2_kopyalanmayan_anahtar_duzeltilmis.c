/* H10_HA2_kopyalanmayan_anahtar_duzeltilmis.c — AP-2 Hafta 10 · HA 2
 * Düzeltme: düğüm anahtarın KENDİ kopyasını tutar (dizgi_kopyala: malloc +
 *           memcpy; strdup C17'de yok); kopya düğümle birlikte serbest
 *           bırakılır. Sahiplik: anahtar dizgisi düğümündür.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA2_kopyalanmayan_anahtar_duzeltilmis.c \
 *           -o H10_HA2_kopyalanmayan_anahtar_duzeltilmis
 * Hatalı  : H10_HA2_kopyalanmayan_anahtar.c
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define M 7

typedef struct Dugum {
    char *anahtar;               /* sahiplik: düğümündür (kopya) */
    int deger;
    struct Dugum *sonraki;
} Dugum;

static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

static char *dizgi_kopyala(const char *s)
{
    size_t uzunluk = strlen(s) + 1;
    char *kopya = malloc(uzunluk);
    if (kopya != NULL) {
        memcpy(kopya, s, uzunluk);
    }
    return kopya;
}

static int ekle(Dugum **kova, const char *anahtar, int deger)
{
    size_t j = karma_fnv1a(anahtar) % M;
    for (Dugum *d = kova[j]; d != NULL; d = d->sonraki) {
        if (strcmp(d->anahtar, anahtar) == 0) {
            d->deger = deger;
            return 0;
        }
    }
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return -1;
    }
    d->anahtar = dizgi_kopyala(anahtar);     /* DÜZELTME: kendi kopyası */
    if (d->anahtar == NULL) {
        free(d);
        return -1;
    }
    d->deger = deger;
    d->sonraki = kova[j];
    kova[j] = d;
    return 1;
}

static int ara(Dugum *const *kova, const char *anahtar, int *deger)
{
    for (const Dugum *d = kova[karma_fnv1a(anahtar) % M]; d != NULL;
         d = d->sonraki) {
        if (strcmp(d->anahtar, anahtar) == 0) {
            *deger = d->deger;
            return 1;
        }
    }
    return 0;
}

static void yaz(Dugum *const *kova)
{
    for (int j = 0; j < M; j++) {
        printf("  kova %d:", j);
        for (const Dugum *d = kova[j]; d != NULL; d = d->sonraki) {
            printf(" %s=%d ->", d->anahtar, d->deger);
        }
        printf(" NULL\n");
    }
}

int main(void)
{
    const char *girdi[] = {"ali", "ayşe", "can", "elif", "deniz"};
    Dugum *kova[M] = {NULL};
    char tampon[32];             /* fgets ile okunan satırın benzetimi */
    for (int i = 0; i < 5; i++) {
        snprintf(tampon, sizeof tampon, "%s", girdi[i]);
        if (ekle(kova, tampon, 10 * (i + 1)) < 0) {
            return 1;
        }
    }
    printf("5 ekleme sonrası tablo:\n");
    yaz(kova);
    for (int i = 0; i < 5; i++) {
        int deger;
        int var = ara(kova, girdi[i], &deger);
        printf("  ara %s: %s\n", girdi[i], var ? "bulundu" : "YOK");
    }
    snprintf(tampon, sizeof tampon, "%s", "XXXX");
    printf("tampon \"XXXX\" yapıldıktan sonra:\n");
    yaz(kova);
    for (int j = 0; j < M; j++) {
        Dugum *d = kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            free(d->anahtar);
            free(d);
            d = sonraki;
        }
    }
    return 0;
}

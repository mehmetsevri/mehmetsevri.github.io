/* H10_HA1_negatif_indis_duzeltilmis.c — AP-2 Hafta 10 · Hata Avcısı 1
 * Düzeltme: karma uint32_t (işaretsiz taşma mod 2^32 sarar, tanımlıdır),
 *           baytlar unsigned char olarak okunur; h % M her zaman 0..M-1.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA1_negatif_indis_duzeltilmis.c \
 *           -o H10_HA1_negatif_indis_duzeltilmis
 * Hatalı  : H10_HA1_negatif_indis.c
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define M 11

static uint32_t karma_polinom(const char *s)
{
    uint32_t h = 0;
    for (; *s != '\0'; s++) {
        h = 31u * h + (unsigned char)*s;     /* 0..255; mod 2^32 sarma */
    }
    return h;
}

int main(void)
{
    const char *anahtar[] = {"ali", "veli", "şule", "çağrı",
                             "karma_tablosu_cakismasi"};
    int *sayac = calloc(M, sizeof *sayac);
    if (sayac == NULL) {
        return 1;
    }
    for (int i = 0; i < 5; i++) {
        uint32_t h = karma_polinom(anahtar[i]);
        uint32_t j = h % M;                  /* işaretsiz: 0..M-1 */
        printf("karma = %11u, indis = h %% %d = %3u  %s\n", h, M, j,
               anahtar[i]);
        sayac[j]++;
    }
    int toplam = 0;
    for (int j = 0; j < M; j++) {
        toplam += sayac[j];
    }
    printf("tablodaki anahtar sayısı: %d (5 olmalı)\n", toplam);
    free(sayac);
    return 0;
}

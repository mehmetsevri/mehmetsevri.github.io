"""H10_HA3_silinen_hucre_bos.py — AP-2 Hafta 10 · Hata Avcısı 3
BU DOSYA KASITLI HATA İÇERİR
Hata    : doğrusal yoklamada silinen hücre BOŞ (None) yapılıyor (mezar taşı
          yok). Arama BOŞ hücrede durduğu için silinen hücrenin ötesine
          yoklamayla yerleşmiş anahtarlar "kaybolur"; yeniden eklenince
          tabloda İKİ kopya oluşur. Hata dile bağlı değildir.
Çalıştır: python3 H10_HA3_silinen_hucre_bos.py
Düzeltme: H10_HA3_silinen_hucre_bos_duzeltilmis.py
"""
M = 11
hucre = [None] * M               # None = BOŞ


def karma_fnv1a(s):
    h = 2166136261
    for b in s.encode("utf-8"):
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def ara(anahtar):
    """(indis ya da -1, yoklama sayısı)"""
    i = karma_fnv1a(anahtar) % M
    yoklama = 0
    for _ in range(M):
        yoklama += 1
        if hucre[i] is None:
            return -1, yoklama               # BOŞ: arama durur
        if hucre[i] == anahtar:
            return i, yoklama
        i = (i + 1) % M
    return -1, yoklama


def ekle(anahtar):
    if ara(anahtar)[0] >= 0:
        return                               # zaten var
    i = karma_fnv1a(anahtar) % M
    while hucre[i] is not None:
        i = (i + 1) % M
    hucre[i] = anahtar


def sil(anahtar):
    i, _ = ara(anahtar)
    if i >= 0:
        hucre[i] = None                      # HATA: mezar taşı olmalıydı


def yaz():
    print(" " + "".join(f" [{i} {hucre[i] if hucre[i] else '-'}]"
                        for i in range(M)))


def main():
    for a in ["ali", "ayşe", "can", "elif", "deniz", "zeynep", "mert",
              "ece"]:
        ekle(a)
    print("8 ekleme (Örnek 4 ile aynı):")
    yaz()
    sil("can")
    print("sil can (hücre 8 BOŞ yapıldı):")
    yaz()
    for a in ["ece", "mert", "zeynep"]:
        i, y = ara(a)
        print(f"  ara {a}: "
              f"{'bulundu' if i >= 0 else 'YOK — tabloda olduğu hâlde!'} "
              f"({y} yoklama)")
    ekle("ece")
    print("yeniden ekle ece:")
    yaz()
    print(f"  tablodaki \"ece\" sayısı: {hucre.count('ece')} (1 olmalı)")


if __name__ == "__main__":
    main()

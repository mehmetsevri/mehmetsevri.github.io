/* H10_HA4_yuk_denetimi_yok.cpp — AP-2 Hafta 10 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR
 * Hata    : açık adreslemede yük faktörü denetlenmiyor ve yoklama döngüsü
 *           yalnız "BOŞ hücre bulunca" bitiyor. Tablo dolunca (α = 1)
 *           ekleme ve olmayan anahtarı arama SONSUZ DÖNGÜYE girer.
 *           Gösterim güvenli olsun diye döngüye bir ADIM SINIRI eklendi
 *           (gerçek hatalı kodda bu sınır yoktur: program donar).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA4_yuk_denetimi_yok.cpp -o H10_HA4_yuk_denetimi_yok
 * Düzeltme: H10_HA4_yuk_denetimi_yok_duzeltilmis.cpp
 */
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

const std::size_t M = 11;
const long ADIM_SINIRI = 1000000;    // yalnız gösterim güvenliği için

static std::uint32_t karma_fnv1a(const std::string& s)
{
    std::uint32_t h = 2166136261u;
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

// Boş dizgi = BOŞ hücre. true: eklendi/var; false: adım sınırı aşıldı
static bool ekle(std::vector<std::string>& hucre, const std::string& a)
{
    std::size_t i = karma_fnv1a(a) % M;
    long adim = 0;
    while (!hucre[i].empty()) {      // HATA: tablo doluysa hiç bitmez
        if (hucre[i] == a) {
            return true;
        }
        i = (i + 1) % M;
        if (++adim > ADIM_SINIRI) {
            return false;            // gösterim: sonsuz döngüyü kes
        }
    }
    hucre[i] = a;                    // HATA: önce α denetlenmeliydi
    return true;
}

static long ara(const std::vector<std::string>& hucre, const std::string& a)
{
    std::size_t i = karma_fnv1a(a) % M;
    long adim = 0;
    while (!hucre[i].empty()) {      // HATA: en çok M yoklama sınırı yok
        if (hucre[i] == a) {
            return adim + 1;
        }
        i = (i + 1) % M;
        if (++adim > ADIM_SINIRI) {
            return -1;               // gösterim: sonsuz döngüyü kes
        }
    }
    return adim + 1;
}

int main()
{
    std::vector<std::string> hucre(M);
    const std::vector<std::string> ad = {"ali", "ayşe", "can", "elif",
                                         "deniz", "zeynep", "mert", "ece",
                                         "kerem", "selin", "ömer", "ılgın"};
    std::size_t n = 0;
    for (const std::string& a : ad) {
        bool tamam = ekle(hucre, a);
        if (!tamam) {
            std::cout << "ekle " << a << ": " << ADIM_SINIRI
                      << " yoklamadan sonra DURDURULDU — BOŞ hücre yok "
                         "(sınır olmasaydı sonsuz döngü)\n";
            break;
        }
        n++;
        std::cout << "ekle " << a << ": n = " << n << ", α = " << n << "/"
                  << M << '\n';
    }
    long y = ara(hucre, "berk");
    std::cout << "ara berk (tabloda yok): ";
    if (y < 0) {
        std::cout << ADIM_SINIRI
                  << " yoklamadan sonra DURDURULDU — sonsuz döngü\n";
    } else {
        std::cout << y << " yoklama\n";
    }
    return 0;
}

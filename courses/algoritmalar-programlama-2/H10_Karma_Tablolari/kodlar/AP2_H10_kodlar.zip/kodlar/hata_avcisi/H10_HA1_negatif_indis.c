/* H10_HA1_negatif_indis.c — AP-2 Hafta 10 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ (yalnız gösterim için)
 * Hata    : karma işaretli int ile hesaplanıyor ve baytlar işaretli char
 *           olarak okunuyor: Türkçe harfin baytı (ör. 0xC5) negatif sayılır,
 *           uzun anahtarda int taşar; negatif karma % M ile NEGATİF indis
 *           verir (C'de kalan bölünenin işaretini alır — H1 Dil Penceresi)
 *           ve tablo dışına yazılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA1_negatif_indis.c -o H10_HA1_negatif_indis
 *           (ASan + UBSan: -O1 -g -fsanitize=address,undefined)
 * Düzeltme: H10_HA1_negatif_indis_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

#define M 11

static int karma_kotu(const char *s)
{
    int h = 0;
    for (; *s != '\0'; s++) {
        h = 31 * h + *s;         /* HATA: *s işaretli char; int taşabilir */
    }
    return h;
}

int main(void)
{
    const char *anahtar[] = {"ali", "veli", "şule", "çağrı",
                             "karma_tablosu_cakismasi"};
    int *sayac = calloc(M, sizeof *sayac);   /* kova başına anahtar sayısı */
    if (sayac == NULL) {
        return 1;
    }
    for (int i = 0; i < 5; i++) {
        int h = karma_kotu(anahtar[i]);
        int j = h % M;                       /* HATA: h < 0 ise j < 0 */
        printf("karma = %11d, indis = h %% %d = %3d  %s\n", h, M, j,
               anahtar[i]);
        fflush(stdout);
        sayac[j]++;                          /* j < 0: tablo DIŞINA yazma */
    }
    int toplam = 0;
    for (int j = 0; j < M; j++) {
        toplam += sayac[j];
    }
    printf("tablodaki anahtar sayısı: %d (5 olmalı)\n", toplam);
    free(sayac);
    return 0;
}

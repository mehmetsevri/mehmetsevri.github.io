"""H10_HA5_dogrulamasiz_rabin_karp.py — AP-2 Hafta 10 · Hata Avcısı 5
BU DOSYA KASITLI HATA İÇERİR
Hata    : Rabin–Karp'ta karma eşitliği doğrudan eşleşme sayılıyor; pencere
          karakter karakter DOĞRULANMIYOR. Farklı metinler aynı karmayı
          verebildiği için (sahte eşleşme) yanlış konumlar raporlanır.
Çalıştır: python3 H10_HA5_dogrulamasiz_rabin_karp.py
Düzeltme: H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402


def rk_ara(t, p, d, q):
    """Eşleşme sayısını döndürür; ilk 5 konumu yazdırır"""
    n, m = len(t), len(p)
    h = 1
    for _ in range(1, m):
        h = h * d % q
    hp = ht = 0
    for i in range(m):
        hp = (d * hp + p[i]) % q
        ht = (d * ht + t[i]) % q
    konum = []
    say = 0
    s = 0
    while True:
        if hp == ht:                         # HATA: doğrulama yok
            if say < 5:
                konum.append(s)
            say += 1
        if s + m >= n:
            break
        ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q
        s += 1
    print("  konumlar:" + "".join(f" {k}" for k in konum)
          + (" …" if say > 5 else ""))
    return say


def main():
    T, P = "2359023141526739921", "31415"
    t = [ord(c) - 48 for c in T]
    p = [ord(c) - 48 for c in P]
    print(f"T = {T}, P = {P}, d = 10, q = 13")
    say = rk_ara(t, p, 10, 13)
    print(f"  bildirilen eşleşme: {say} (doğrusu 1: yalnız kayma 6; 12'deki "
          "67399 sahte)")
    rastgele_tohum(42)
    metin = bytes(97 + rastgele_aralik(0, 3) for _ in range(100000))
    print("rastgele metin (Örnek 12), desen = metin[50000..50007], "
          "d = 256, q = 13")
    say = rk_ara(metin, metin[50000:50008], 256, 13)
    print(f"  bildirilen eşleşme: {say} (doğrusu 1)")


if __name__ == "__main__":
    main()

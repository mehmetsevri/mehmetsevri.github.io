"""H10_HA3_silinen_hucre_bos_duzeltilmis.py — AP-2 Hafta 10 · HA 3
Düzeltme: silinen hücre MEZAR (tombstone) olarak işaretlenir. Arama mezar
          taşında DURMAZ (yalnız BOŞ hücre durdurur); ekleme ilk mezar
          taşını yeniden kullanır ama önce BOŞ hücreye kadar arar.
Çalıştır: python3 H10_HA3_silinen_hucre_bos_duzeltilmis.py
Hatalı  : H10_HA3_silinen_hucre_bos.py
"""
M = 11
BOS, DOLU, MEZAR = 0, 1, 2
durum = [BOS] * M
hucre = [None] * M


def karma_fnv1a(s):
    h = 2166136261
    for b in s.encode("utf-8"):
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def ara(anahtar):
    """(indis ya da -1, yoklama, yer): yer = ilk mezar taşı ya da BOŞ"""
    i = karma_fnv1a(anahtar) % M
    ilk_mezar = -1
    yoklama = 0
    for _ in range(M):
        yoklama += 1
        if durum[i] == BOS:
            return -1, yoklama, (ilk_mezar if ilk_mezar >= 0 else i)
        if durum[i] == MEZAR:
            if ilk_mezar < 0:
                ilk_mezar = i                # DÜZELTME: durma, ilerle
        elif hucre[i] == anahtar:
            return i, yoklama, -1
        i = (i + 1) % M
    return -1, yoklama, ilk_mezar


def ekle(anahtar):
    i, _, yer = ara(anahtar)
    if i >= 0 or yer < 0:
        return                               # zaten var ya da tablo dolu
    durum[yer] = DOLU
    hucre[yer] = anahtar


def sil(anahtar):
    i, _, _ = ara(anahtar)
    if i >= 0:
        durum[i] = MEZAR                     # DÜZELTME
        hucre[i] = None


def yaz():
    parca = []
    for i in range(M):
        g = (hucre[i] if durum[i] == DOLU else
             "MEZAR" if durum[i] == MEZAR else "-")
        parca.append(f" [{i} {g}]")
    print(" " + "".join(parca))


def main():
    for a in ["ali", "ayşe", "can", "elif", "deniz", "zeynep", "mert",
              "ece"]:
        ekle(a)
    print("8 ekleme (Örnek 4 ile aynı):")
    yaz()
    sil("can")
    print("sil can (hücre 8 MEZAR yapıldı):")
    yaz()
    for a in ["ece", "mert", "zeynep"]:
        i, y, _ = ara(a)
        print(f"  ara {a}: {'bulundu' if i >= 0 else 'YOK'} ({y} yoklama)")
    ekle("ece")
    print("yeniden ekle ece (zaten var: değişiklik yok):")
    yaz()
    sayi = sum(1 for i in range(M) if durum[i] == DOLU and hucre[i] == "ece")
    print(f"  tablodaki \"ece\" sayısı: {sayi} (1 olmalı)")


if __name__ == "__main__":
    main()

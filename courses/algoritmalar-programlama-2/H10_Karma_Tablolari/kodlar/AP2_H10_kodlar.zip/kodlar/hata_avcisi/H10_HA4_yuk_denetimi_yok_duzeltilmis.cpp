/* H10_HA4_yuk_denetimi_yok_duzeltilmis.cpp — AP-2 Hafta 10 · HA 4
 * Düzeltme: (1) her eklemeden önce yük faktörü denetlenir: (n + 1)/m > 3/4
 *           olacaksa kapasite × 2 ve yeniden yerleştirme (Örnek 6);
 *           (2) yoklama döngüsü en çok m hücreye bakar (dolu tabloda bile
 *           sonlanır).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_HA4_yuk_denetimi_yok_duzeltilmis.cpp \
 *           -o H10_HA4_yuk_denetimi_yok_duzeltilmis
 * Hatalı  : H10_HA4_yuk_denetimi_yok.cpp
 */
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

static std::uint32_t karma_fnv1a(const std::string& s)
{
    std::uint32_t h = 2166136261u;
    for (unsigned char b : s) {
        h ^= b;
        h *= 16777619u;
    }
    return h;
}

struct Tablo {
    std::vector<std::string> hucre = std::vector<std::string>(11);
    std::size_t n = 0;
};

// En çok m yoklama: bulunan ya da ilk BOŞ hücre; ikisi de yoksa m
static std::size_t yer_bul(const Tablo& t, const std::string& a,
                           std::size_t& yoklama)
{
    std::size_t m = t.hucre.size();
    std::size_t i = karma_fnv1a(a) % m;
    for (yoklama = 1; yoklama <= m; yoklama++) {    // DÜZELTME (2)
        if (t.hucre[i].empty() || t.hucre[i] == a) {
            return i;
        }
        i = (i + 1) % m;
    }
    return m;
}

static void ekle(Tablo& t, const std::string& a)
{
    if (4 * (t.n + 1) > 3 * t.hucre.size()) {       // DÜZELTME (1)
        Tablo yeni;
        yeni.hucre.assign(2 * t.hucre.size(), "");
        for (const std::string& x : t.hucre) {
            if (!x.empty()) {
                std::size_t y;
                yeni.hucre[yer_bul(yeni, x, y)] = x;
                yeni.n++;
            }
        }
        std::cout << "  (büyütme: m " << t.hucre.size() << " -> "
                  << yeni.hucre.size() << ")\n";
        t = yeni;
    }
    std::size_t y;
    std::size_t i = yer_bul(t, a, y);
    if (t.hucre[i].empty()) {
        t.hucre[i] = a;
        t.n++;
    }
}

int main()
{
    Tablo t;
    const std::vector<std::string> ad = {"ali", "ayşe", "can", "elif",
                                         "deniz", "zeynep", "mert", "ece",
                                         "kerem", "selin", "ömer", "ılgın"};
    for (const std::string& a : ad) {
        ekle(t, a);
        std::cout << "ekle " << a << ": n = " << t.n << ", α = " << t.n
                  << "/" << t.hucre.size() << '\n';
    }
    std::size_t y;
    std::size_t i = yer_bul(t, "berk", y);
    std::cout << "ara berk (tabloda yok): " << y << " yoklama, "
              << (i < t.hucre.size() && t.hucre[i] == "berk" ? "bulundu"
                                                            : "YOK")
              << '\n';
    return 0;
}

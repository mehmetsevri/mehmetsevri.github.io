"""H10_K08_kucuk_harf.py — AP-2 Hafta 10 · Kavram 8 (Dil Penceresi)
Amaç    : str.lower Unicode kurallarıyla çalışır, yerel ayara bakmaz: Ş → ş,
          Ç → ç doğru; ama I → i (Türkçede ı olmalıydı) ve İ → i + U+0307
          (BİRLEŞEN ÜST NOKTA): "İSTANBUL".lower() 9 karakterdir. Örnek 7'nin
          bayt düzeyindeki elle dönüşümü (A–Z → +32) C'deki tolower ile aynı
          sonucu verir: üç dilde aynı çıktı için kullanılan yol budur.
Çalıştır: python3 H10_K08_kucuk_harf.py
"""


def elle(s):
    b = s.encode("utf-8")
    return bytes(x + 32 if 65 <= x <= 90 else x for x in b).decode("utf-8")


def main():
    for s in ["KARMA", "IŞIK", "İSTANBUL", "ÇAĞRI"]:
        k = s.lower()
        print(f"{s}: lower -> {k}, elle -> {elle(s)}, aynı mı? "
              f"{'evet' if k == elle(s) else 'hayır'}")
        print(f"   {len(s)} → {len(k)} karakter:",
              " ".join(f"U+{ord(c):04X}" for c in k))
    print('"ı".upper() =', "ı".upper(), '·', '"i".upper() =', "i".upper(),
          "(iki farklı harf aynı büyük harfe gider)")


if __name__ == "__main__":
    main()

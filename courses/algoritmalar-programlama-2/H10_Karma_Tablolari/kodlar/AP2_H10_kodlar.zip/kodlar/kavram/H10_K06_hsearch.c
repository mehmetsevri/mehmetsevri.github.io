/* H10_K06_hsearch.c — AP-2 Hafta 10 · Kavram 6 (Dil Penceresi)
 * Amaç    : C standart kütüphanesinde genel amaçlı karma tablosu YOKTUR;
 *           POSIX (XSI) <search.h> hcreate/hsearch/hdestroy sunar: süreçte
 *           tek bir tablo, silme işlemi yok, kapasite baştan verilir,
 *           anahtar dizgisinin ömrünü çağıran yönetir. Örnek 7'nin küçük
 *           bir kelime sayacı hsearch ile.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_K06_hsearch.c -o H10_K06_hsearch
 *           (_XOPEN_SOURCE 700: POSIX işlevlerini -std=c17 ile açar)
 * Çalıştır: ./H10_K06_hsearch
 */
#define _XOPEN_SOURCE 700
#include <search.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    const char *metin[] = {"bir", "koca", "ali", "bir", "usta", "ali",
                           "bir", "dedi"};
    const int n = 8;
    int sayac[8] = {0};          /* değerler: anahtarla aynı ömürde */
    int farkli = 0;
    if (hcreate(16) == 0) {      /* kapasite baştan: büyümez */
        return 1;
    }
    for (int i = 0; i < n; i++) {
        ENTRY e;
        e.key = (char *)metin[i];            /* kopyalanmaz: ömür bizde */
        ENTRY *bulunan = hsearch(e, FIND);
        if (bulunan == NULL) {
            e.data = &sayac[farkli++];
            bulunan = hsearch(e, ENTER);
            if (bulunan == NULL) {
                hdestroy();
                return 1;                    /* tablo doldu */
            }
        }
        (*(int *)bulunan->data)++;
    }
    const char *sorgu[] = {"bir", "ali", "koca", "usta", "dedi", "yok"};
    for (int i = 0; i < 6; i++) {
        ENTRY e;
        e.key = (char *)sorgu[i];
        ENTRY *b = hsearch(e, FIND);
        printf("  %s: %d\n", sorgu[i], b ? *(int *)b->data : 0);
    }
    printf("  farklı sözcük: %d (dolaşma işlemi yok: anahtarları biz "
           "tutmalıyız)\n", farkli);
    hdestroy();                  /* anahtar dizgilerini serbest BIRAKMAZ */
    return 0;
}

"""H10_K03_python_hash.py — AP-2 Hafta 10 · Kavram 3 (Dil Penceresi)
Amaç    : Python'un yerleşik hash()'i str ve bytes için her süreçte rastgele
          seçilen gizli bir anahtarla (tohum) hesaplanır (Python 3.3'ten beri
          varsayılan; 3.4'ten beri SipHash ailesi — PEP 456): değer
          çalıştırmadan çalıştırmaya DEĞİŞİR. PYTHONHASHSEED=0 rastgeleliği
          kapatır (yalnız hata ayıklama/tekrarlanabilirlik için). Küçük
          tamsayıların karması kendisidir. Bu yüzden ders örneklerinin
          çıktısında hash() kullanılmaz (ders notu Bölüm 8).
Çalıştır: python3 H10_K03_python_hash.py
          PYTHONHASHSEED=0 python3 H10_K03_python_hash.py
Çıktı   : "bu çalıştırmada" — her çalıştırmada farklı olabilir
"""
import os
import sys


def main():
    tohum = os.environ.get("PYTHONHASHSEED", "(ayarlı değil: rastgele)")
    print(f"PYTHONHASHSEED = {tohum}; sys.flags.hash_randomization = "
          f"{sys.flags.hash_randomization}")
    print(f"  hash('ali')  = {hash('ali')}")
    print(f"  hash(b'ali') = {hash(b'ali')}")
    print(f"  hash(42)     = {hash(42)}   (küçük tamsayı: kendisi)")
    print(f"  hash((1, 2)) = {hash((1, 2))}   (demet: öğelerin karmasından)")
    kume = {"ali", "veli", "can", "elif", "deniz"}
    print(f"  set dolaşma sırası: {' '.join(kume)}")
    print(f"  karma algoritması: {sys.hash_info.algorithm} "
          f"({sys.hash_info.hash_bits} bit)")


if __name__ == "__main__":
    main()

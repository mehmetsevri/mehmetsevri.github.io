"""H10_K07_kutuphane_frekans.py — AP-2 Hafta 10 · Kavram 7
Amaç    : Örnek 7'nin kütüphane karşılığı: dict ile kelime sayımı; sözcük
          ayırma ve ASCII küçültme aynı (bayt düzeyinde, elle). En sık 20
          sözcük Örnek 7 ile birebir aynı çıkmalıdır (kâhin); süre stderr'e
          (atölye karşılaştırması). collections.Counter da aynı işi yapar.
Çalıştır: python3 H10_K07_kutuphane_frekans.py \\
          < ../girdiler/H10_07_kelime_frekansi.txt
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from zamanlayici import zaman_sn  # noqa: E402


def main():
    t0 = zaman_sn()
    metin = sys.stdin.buffer.read()
    sayac = {}                               # kütüphane karma tablosu
    sozcuk = bytearray()
    toplam = 0
    for i in range(len(metin) + 1):
        b = metin[i] if i < len(metin) else 32
        if 65 <= b <= 90 or 97 <= b <= 122 or b >= 0x80:
            if len(sozcuk) < 255:
                sozcuk.append(b + 32 if 65 <= b <= 90 else b)
        elif sozcuk:
            anahtar = bytes(sozcuk)          # bytearray anahtar olamaz
            sayac[anahtar] = sayac.get(anahtar, 0) + 1
            toplam += 1
            sozcuk.clear()
    liste = sorted(sayac.items(), key=lambda kv: (-kv[1], kv[0]))
    print(f"Girdi: {len(metin)} bayt; sözcük = harf baytlarının en uzun "
          "dizisi")
    print(f"toplam sözcük = {toplam}, farklı sözcük = {len(sayac)}")
    print("\nEn sık 20 sözcük (sıklık azalan; eşitlikte bayt sırası artan)")
    for r, (s, c) in enumerate(liste[:20]):
        print(f"  {r + 1:2d}. {c:5d}  " + s.decode("utf-8"))
    print(f"süre (dict): {(zaman_sn() - t0) * 1e3:.3f} ms", file=sys.stderr)


if __name__ == "__main__":
    main()

"""H10_K05_hash_eq_sozlesmesi.py — AP-2 Hafta 10 · Kavram 5 (Dil Penceresi)
Amaç    : Karma edilebilirlik sözleşmesi: a == b ise hash(a) == hash(b)
          olmalı ve nesne tablodayken karması DEĞİŞMEMELİ. (1) Yalnız __eq__
          tanımlayan sınıfın __hash__'i None olur: dict/set anahtarı olamaz.
          (2) __eq__ ve __hash__ aynı alan(lar)dan tanımlanır. (3) Anahtar
          tablodayken alanı değiştirilirse kayıt "kaybolur": anahtarlar
          değişmez olmalıdır (str, bytes, int, tuple, frozenset).
Çalıştır: python3 H10_K05_hash_eq_sozlesmesi.py
"""


class OgrenciEq:
    """Yalnız __eq__: Python __hash__'i None yapar"""

    def __init__(self, numara, ad):
        self.numara = numara
        self.ad = ad

    def __eq__(self, diger):
        return isinstance(diger, OgrenciEq) and self.numara == diger.numara


class Ogrenci:
    """__eq__ ve __hash__ aynı alandan: numara"""

    def __init__(self, numara, ad):
        self.numara = numara
        self.ad = ad

    def __eq__(self, diger):
        return isinstance(diger, Ogrenci) and self.numara == diger.numara

    def __hash__(self):
        return hash(self.numara)


def main():
    print("1) Yalnız __eq__:", "__hash__ =", OgrenciEq.__hash__)
    try:
        {OgrenciEq(2400001, "Ayşe"): "kayıt"}
    except TypeError as e:
        print(f"   dict anahtarı yapılamadı: TypeError: {e}")

    print("2) __eq__ + __hash__ (numara):")
    a = Ogrenci(2400001, "Ayşe")
    b = Ogrenci(2400001, "Ayşe Yılmaz")      # aynı numara, farklı ad
    notlar = {a: 85}
    print(f"   a == b: {a == b}, hash(a) == hash(b): {hash(a) == hash(b)}, "
          f"notlar[b] = {notlar[b]}")

    print("3) Anahtar tablodayken değiştirilirse:")
    a.numara = 2400999                       # HATA ÖRNEĞİ: anahtar değişti
    print(f"   a in notlar: {a in notlar} (kayıt tabloda ama eski "
          "karmanın kovasında)")
    print(f"   Ogrenci(2400001, '') in notlar: "
          f"{Ogrenci(2400001, '') in notlar} (karma eşleşir, == tutmaz)")
    print(f"   len(notlar) = {len(notlar)}")
    print("   Çözüm: anahtar olarak değişmez numara (int) ya da "
          "tuple kullanın.")


if __name__ == "__main__":
    main()

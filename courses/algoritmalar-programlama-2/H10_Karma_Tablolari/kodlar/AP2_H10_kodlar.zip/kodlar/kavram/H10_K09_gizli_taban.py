"""H10_K09_gizli_taban.py — AP-2 Hafta 10 · Kavram 9
Amaç    : Örnek 13'ün "rastgele taban + alt bit" savunması gizli tabanın
          şansına mı bağlı? 20 rastgele tek taban (ortak LCG, tohum 2026;
          ilki Örnek 13'ün tabanı) için Aa/BB saldırı anahtarlarında
          (n = 512 ve 1024) anahtar karşılaştırması; t = v2(taban − 31),
          s = v2(taban² − 1): indisin en az alt t + s biti yalnız BB
          bloklarının sayısını taşır (her tek tabanda t ≥ 1, s ≥ 3)
Çalıştır: python3 H10_K09_gizli_taban.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_sayi, rastgele_tohum  # noqa: E402

MASKE32 = 0xFFFFFFFF
A_FIB = 2654435769               # üst bit indisi (Örnek 5, Örnek 13)


def karma(s, taban):
    """polinom karma, gizli taban, h0 = 0 (Örnek 13'ün taban savunması)"""
    h = 0
    for b in s:
        h = (taban * h + b) & MASKE32
    return h


def indis(h, p, ust_bit):
    if ust_bit:
        return ((h * A_FIB) & MASKE32) >> (32 - p)
    return h & ((1 << p) - 1)


def ekle_hepsi(anahtarlar, taban, ust_bit):
    """Örnek 13'ün tablosu: m = 16'dan başlar, n > m olunca m × 2; her
    ekleme zinciri baştan sona tarar. Döner: anahtar karşılaştırması."""
    p = 4
    kova = [[] for _ in range(1 << p)]
    karsilastirma = 0
    n = 0
    for a in anahtarlar:
        h = karma(a, taban)
        zincir = kova[indis(h, p, ust_bit)]
        var = False
        for anahtar, _ in zincir:
            karsilastirma += 1
            if anahtar == a:
                var = True
                break
        if var:
            continue
        zincir.insert(0, (a, h))         # başa ekleme
        n += 1
        if n > len(kova):                # α > 1: × 2, yeniden yerleştir
            p += 1
            yeni = [[] for _ in range(1 << p)]
            for z in kova:                 # Örnek 13'ün buyut'u gibi:
                for anahtar, hh in z:      # zincir sırasıyla başa ekle
                    yeni[indis(hh, p, ust_bit)].insert(0, (anahtar, hh))
            kova = yeni
    return karsilastirma


def carpisan_anahtar(i, k):
    """i'nin k bitinden anahtar: bit 0 → "Aa", 1 → "BB" (Örnek 13)"""
    return b"".join(b"BB" if (i >> (k - 1 - b)) & 1 else b"Aa"
                    for b in range(k))


def iki_ussu(x):
    """x'i bölen en büyük 2 kuvvetinin üssü (x = 0 için 32)"""
    e = 0
    while e < 32 and x & 1 == 0:
        x >>= 1
        e += 1
    return e


def main():
    rastgele_tohum(2026)
    tabanlar = [(2 * rastgele_sayi() + 1) & MASKE32 for _ in range(20)]
    a9 = [carpisan_anahtar(i, 9) for i in range(1 << 9)]
    a10 = [carpisan_anahtar(i, 10) for i in range(1 << 10)]
    print("Gizli taban ve alt bit indisi: 20 tek taban (ortak LCG, tohum "
          "2026; 1. satır Örnek 13'ün tabanı)")
    print("saldırı: tek kova, n(n−1)/2 = 130816 (n = 512) ve 523776 "
          "(n = 1024)")
    print("        taban   t   s  t+s   alt n=512  alt n=1024    kat"
          "  üst n=1024")
    alt, kat, ust = [], [], []
    for taban in tabanlar:
        t = iki_ussu((taban - 31) & MASKE32)
        s = iki_ussu((taban * taban - 1) & MASKE32)
        k9 = ekle_hepsi(a9, taban, False)
        k10 = ekle_hepsi(a10, taban, False)
        u10 = ekle_hepsi(a10, taban, True)
        alt.append(k10)
        kat.append(k10 / k9)
        ust.append(u10)
        print(f"  {taban:11d}  {t:2d}  {s:2d}  {t + s:3d}  {k9:10d}"
              f"  {k10:10d}  {k10 / k9:5.2f}  {u10:10d}")
    sirali = sorted(alt)
    ortanca = (sirali[9] + sirali[10]) / 2
    print(f"alt bit, n = 1024: en az {sirali[0]}, ortanca {ortanca:.1f}, "
          f"en çok {sirali[-1]} karşılaştırma")
    print(f"  n × 2'de kat > 3 (karesele yakın): "
          f"{sum(1 for x in kat if x > 3)} / {len(kat)} taban")
    print(f"üst bit, n = 1024: en az {min(ust)}, en çok {max(ust)} "
          f"karşılaştırma")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok — Python'un str/bytes karması anahtarlı SipHash
# ailesidir (PEP 456); burada savunmanın neden yetmediği ölçülür.

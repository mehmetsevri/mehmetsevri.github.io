/* H10_K02_isaretsiz_sarma.c — AP-2 Hafta 10 · Kavram 2 (Kaputun Altında)
 * Amaç    : İşaretsiz taşma TANIMLIDIR: uint32_t aritmetiği mod 2^32 sarar;
 *           polinom karma bunu bilinçli kullanır. Her adımda sarmanın
 *           gerçekleşip gerçekleşmediği 64 bitlik "gerçek" değerle
 *           karşılaştırılarak gösterilir. (İşaretli int taşması ise
 *           TANIMSIZ davranıştır: Hata Avcısı 1.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_K02_isaretsiz_sarma.c -o H10_K02_isaretsiz_sarma
 * Çalıştır: ./H10_K02_isaretsiz_sarma
 * Eşleri  : H10_K02_isaretsiz_sarma.cpp · H10_K02_isaretsiz_sarma.py
 *           (üçünde de aynı karma değerleri)
 */
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    const char *s = "karma_tablosu";
    uint32_t h = 0;                  /* mod 2^32 */
    uint64_t gercek = 0;             /* sarmadan önceki değer (mod 2^64) */
    printf("polinom karma, taban 31: \"%s\"\n", s);
    printf("   i  bayt  31·h + b (mod 2^64)        h (uint32_t)  sardı mı?\n");
    for (int i = 0; s[i] != '\0'; i++) {
        unsigned char b = (unsigned char)s[i];
        gercek = 31u * (uint64_t)h + b;      /* önceki h üzerinden */
        h = 31u * h + b;                     /* 32 bit: kendiliğinden sarar */
        printf("  %2d  %4u  %20llu  %14u  %s\n", i, b,
               (unsigned long long)gercek, h,
               gercek != h ? "evet (2^32'nin katı atıldı)" : "hayır");
    }
    printf("sonuç: h = %u = 0x%08x\n", h, h);
    printf("UINT32_MAX + 1 = %u (tanımlı: mod 2^32)\n",
           (uint32_t)(UINT32_MAX + 1u));
    return 0;
}

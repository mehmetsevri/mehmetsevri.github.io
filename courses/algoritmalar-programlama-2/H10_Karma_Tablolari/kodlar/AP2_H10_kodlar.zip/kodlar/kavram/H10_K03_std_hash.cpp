/* H10_K03_std_hash.cpp — AP-2 Hafta 10 · Kavram 3 (Dil Penceresi)
 * Amaç    : std::hash<std::string>'in değeri gerçekleştirime bağlıdır
 *           (standart algoritmayı belirtmez); libstdc++'ta çalıştırmalar
 *           arasında AYNIDIR (Python'daki gibi süreç başına rastgele tohum
 *           yoktur). std::hash<int> libstdc++'ta sayının kendisidir. Bu
 *           yüzden ders örneklerinin çıktısında std::hash kullanılmaz.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_K03_std_hash.cpp -o H10_K03_std_hash
 * Çalıştır: ./H10_K03_std_hash   (iki kez çalıştırıp karşılaştırın)
 * Çıktı   : "bu derleyicide" (64 bit size_t, libstdc++)
 */
#include <functional>
#include <iostream>
#include <string>

int main()
{
    std::hash<std::string> h_dizgi;
    std::hash<int> h_int;
    std::cout << "sizeof(std::size_t) = " << sizeof(std::size_t) << " bayt\n"
              << "  std::hash<std::string>{}(\"ali\")  = " << h_dizgi("ali")
              << '\n'
              << "  std::hash<std::string>{}(\"veli\") = " << h_dizgi("veli")
              << '\n'
              << "  std::hash<int>{}(42)            = " << h_int(42) << '\n';
    return 0;
}

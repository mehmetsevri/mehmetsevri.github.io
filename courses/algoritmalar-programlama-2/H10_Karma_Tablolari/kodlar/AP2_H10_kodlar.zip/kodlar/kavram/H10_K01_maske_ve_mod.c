/* H10_K01_maske_ve_mod.c — AP-2 Hafta 10 · Kavram 1 (Kaputun Altında)
 * Amaç    : m = 2^p iken h % m == h & (m − 1) (işaretsiz h için); maskenin
 *           yalnız DÜŞÜK p biti kullandığı, düzenli anahtarlarda (çift
 *           sayılar, 16'nın katları) kimlik karmasıyla kovaların boş
 *           kaldığı; asal m ve çarpma yönteminin (üst bitler) bunu
 *           düzelttiği. % ve & süreleri stderr'e (bu çalıştırmada).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_K01_maske_ve_mod.c ../c/zamanlayici.c -I../c \
 *           -o H10_K01_maske_ve_mod
 * Çalıştır: ./H10_K01_maske_ve_mod
 */
#include <stdint.h>
#include <stdio.h>

#include "zamanlayici.h"

#define N 1024                   /* anahtar sayısı */

/* Dolu kova sayısı ve en uzun kova: dagit(anahtar, yöntem) */
static void dagilim(const uint32_t *k, int yontem, int *dolu, int *en_uzun)
{
    int sayac[64] = {0};
    for (int i = 0; i < N; i++) {
        uint32_t j;
        if (yontem == 0) {
            j = k[i] & 15u;                  /* m = 16, maske: alt 4 bit */
        } else if (yontem == 1) {
            j = k[i] % 17u;                  /* m = 17 (asal), bölme */
        } else {
            j = (k[i] * 2654435769u) >> 28;  /* m = 16, üst 4 bit */
        }
        sayac[j]++;
    }
    *dolu = 0;
    *en_uzun = 0;
    for (int j = 0; j < 17; j++) {
        *dolu += sayac[j] > 0;
        if (sayac[j] > *en_uzun) {
            *en_uzun = sayac[j];
        }
    }
}

int main(void)
{
    printf("1) m = 2^p iken h %% m = h & (m − 1): ");
    int esit = 1;
    for (uint32_t h = 0; h < 1000000u; h++) {
        uint32_t g = h * 2654435769u;        /* farklı bit desenleri */
        esit = esit && (g % 16u) == (g & 15u) && (g % 1024u) == (g & 1023u);
    }
    printf("%s (10^6 değer, m = 16 ve 1024)\n", esit ? "evet" : "HAYIR");

    printf("\n2) Kimlik karması h(k) = k ile %d düzenli anahtar\n", N);
    printf("  m=16 maske    m=17 asal     m=16 çarpma   anahtarlar\n");
    printf("  (alt 4 bit)   (h %% 17)      (üst 4 bit)\n");
    printf("  dolu en uzun  dolu en uzun  dolu en uzun\n");
    const char *ad[3] = {"0, 1, 2, ... (ardışık)", "0, 2, 4, ... (çift)",
                         "0, 16, 32, ... (16k)"};
    const uint32_t adim[3] = {1u, 2u, 16u};
    uint32_t k[N];
    for (int a = 0; a < 3; a++) {
        for (int i = 0; i < N; i++) {
            k[i] = adim[a] * (uint32_t)i;
        }
        printf(" ");
        for (int y = 0; y < 3; y++) {
            int dolu, en_uzun;
            dagilim(k, y, &dolu, &en_uzun);
            printf(" %4d %8d", dolu, en_uzun);
        }
        printf("  %s\n", ad[a]);
    }
    printf("  (maske yalnız alt bitleri görür: 16'nın katlarında alt 4 bit "
           "hep 0 -> tek kova)\n");

    /* % ile & maliyeti: m çalışma anında bilinsin diye volatile */
    volatile uint32_t m_v = 1024u;
    uint32_t m = m_v;
    uint32_t maske = m - 1u;
    uint64_t t1 = 0;
    uint64_t t2 = 0;
    double a0 = zaman_sn();
    for (uint32_t h = 0; h < 200000000u; h++) {
        t1 += (h * 2654435769u) % m;
    }
    double a1 = zaman_sn();
    for (uint32_t h = 0; h < 200000000u; h++) {
        t2 += (h * 2654435769u) & maske;
    }
    double a2 = zaman_sn();
    printf("\n3) 2·10^8 indis hesabı: toplamlar eşit mi? %s\n",
           t1 == t2 ? "evet" : "HAYIR");
    fprintf(stderr, "  [bu çalıştırmada] %% : %.1f ms, & : %.1f ms\n",
            (a1 - a0) * 1e3, (a2 - a1) * 1e3);
    return 0;
}

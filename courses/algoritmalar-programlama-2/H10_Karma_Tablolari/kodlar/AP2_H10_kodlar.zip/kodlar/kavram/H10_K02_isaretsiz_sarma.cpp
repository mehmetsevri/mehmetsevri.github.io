/* H10_K02_isaretsiz_sarma.cpp — AP-2 Hafta 10 · Kavram 2 (Kaputun Altında)
 * Amaç    : İşaretsiz taşma TANIMLIDIR: std::uint32_t aritmetiği mod 2^32
 *           sarar; polinom karma bunu bilinçli kullanır. Her adımda
 *           sarmanın gerçekleşip gerçekleşmediği 64 bitlik "gerçek" değerle
 *           karşılaştırılarak gösterilir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_K02_isaretsiz_sarma.cpp -o H10_K02_isaretsiz_sarma
 * Çalıştır: ./H10_K02_isaretsiz_sarma
 * Eşleri  : H10_K02_isaretsiz_sarma.c · H10_K02_isaretsiz_sarma.py
 */
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>

int main()
{
    const std::string s = "karma_tablosu";
    std::uint32_t h = 0;             // mod 2^32
    std::uint64_t gercek = 0;        // sarmadan önceki değer (mod 2^64)
    std::cout << "polinom karma, taban 31: \"" << s << "\"\n"
              << "   i  bayt  31·h + b (mod 2^64)        h (uint32_t)  sardı "
                 "mı?\n";
    for (std::size_t i = 0; i < s.size(); i++) {
        unsigned char b = static_cast<unsigned char>(s[i]);
        gercek = 31u * static_cast<std::uint64_t>(h) + b;
        h = 31u * h + b;             // 32 bit: kendiliğinden sarar
        std::cout << "  " << std::setw(2) << i << "  " << std::setw(4)
                  << static_cast<unsigned>(b) << "  " << std::setw(20)
                  << gercek << "  " << std::setw(14) << h << "  "
                  << (gercek != h ? "evet (2^32'nin katı atıldı)" : "hayır")
                  << '\n';
    }
    std::cout << "sonuç: h = " << h << " = 0x" << std::hex << std::setw(8)
              << std::setfill('0') << h << std::dec << std::setfill(' ')
              << '\n'
              << "UINT32_MAX + 1 = "
              << static_cast<std::uint32_t>(
                     std::numeric_limits<std::uint32_t>::max() + 1u)
              << " (tanımlı: mod 2^32)\n";
    return 0;
}

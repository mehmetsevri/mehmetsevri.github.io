"""H10_K04_dict_sirasi.py — AP-2 Hafta 10 · Kavram 4 (Dil Penceresi)
Amaç    : dict, anahtarları EKLEME SIRASIYLA dolaşır — Python 3.7'den beri
          dil güvencesidir (CPython 3.6'da gerçekleştirim ayrıntısıydı). Bir
          anahtarı silip yeniden eklemek onu sona taşır; değeri güncellemek
          sırayı değiştirmez. set için böyle bir güvence YOKTUR. Çıktıyı
          dillerden bağımsız kılmak için anahtarlar yine sıralanarak
          yazdırılır (sorted).
Çalıştır: python3 H10_K04_dict_sirasi.py
Çıktı   : bölüm 1–3 her çalıştırmada aynı; bölüm 4 (set) "bu çalıştırmada"
"""


def main():
    plaka = {}
    for ad, no in [("rize", 53), ("artvin", 8), ("trabzon", 61),
                   ("giresun", 28), ("ordu", 52)]:
        plaka[ad] = no
    print("1) ekleme sırası:", " ".join(plaka))
    plaka["artvin"] = 8                      # güncelleme: sıra aynı
    print("2) artvin güncellendi:", " ".join(plaka))
    del plaka["rize"]
    plaka["rize"] = 53                       # sil + ekle: sona gider
    print("3) rize silinip eklendi:", " ".join(plaka))
    print("   sıralı (çıktı eşdeğerliği için):", " ".join(sorted(plaka)))
    kume = set(plaka)
    print("4) set dolaşma sırası (güvence yok; bu çalıştırmada):",
          " ".join(kume))


if __name__ == "__main__":
    main()

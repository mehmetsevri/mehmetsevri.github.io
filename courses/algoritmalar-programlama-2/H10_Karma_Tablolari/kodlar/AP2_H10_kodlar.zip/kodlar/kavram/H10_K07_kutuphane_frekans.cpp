/* H10_K07_kutuphane_frekans.cpp — AP-2 Hafta 10 · Kavram 7
 * Amaç    : Örnek 7'nin kütüphane karşılığı: std::unordered_map<std::string,
 *           int> ile kelime sayımı; sözcük ayırma ve ASCII küçültme aynı
 *           (bayt düzeyinde, elle). En sık 20 sözcük Örnek 7 ile birebir
 *           aynı çıkmalıdır (kâhin); süre stderr'e (atölye karşılaştırması).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 -I../cpp \
 *           H10_K07_kutuphane_frekans.cpp -o H10_K07_kutuphane_frekans
 * Çalıştır: ./H10_K07_kutuphane_frekans \
 *           < ../girdiler/H10_07_kelime_frekansi.txt
 */
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "zamanlayici.hpp"

int main()
{
    double t0 = zaman_sn();
    std::string metin(std::istreambuf_iterator<char>(std::cin), {});
    std::unordered_map<std::string, int> sayac;
    std::string sozcuk;
    long long toplam = 0;
    for (std::size_t i = 0; i <= metin.size(); i++) {
        unsigned char b = i < metin.size()
                              ? static_cast<unsigned char>(metin[i])
                              : ' ';
        bool harf = (b >= 'A' && b <= 'Z') || (b >= 'a' && b <= 'z') ||
                    b >= 0x80;
        if (harf) {
            if (sozcuk.size() < 255) {
                sozcuk += static_cast<char>(b >= 'A' && b <= 'Z' ? b + 32
                                                                 : b);
            }
        } else if (!sozcuk.empty()) {
            sayac[sozcuk]++;                 // kütüphane karma tablosu
            toplam++;
            sozcuk.clear();
        }
    }
    std::vector<std::pair<std::string, int>> liste(sayac.begin(),
                                                   sayac.end());
    std::sort(liste.begin(), liste.end(),
              [](const auto& x, const auto& y) {
                  return x.second != y.second ? x.second > y.second
                                              : x.first < y.first;
              });
    std::cout << "Girdi: " << metin.size()
              << " bayt; sözcük = harf baytlarının en uzun dizisi\n"
              << "toplam sözcük = " << toplam << ", farklı sözcük = "
              << sayac.size() << '\n'
              << "\nEn sık 20 sözcük (sıklık azalan; eşitlikte bayt sırası "
                 "artan)\n";
    for (std::size_t r = 0; r < 20 && r < liste.size(); r++) {
        std::cout << "  " << std::setw(2) << r + 1 << ". " << std::setw(5)
                  << liste[r].second << "  " << liste[r].first << '\n';
    }
    std::cerr << "süre (std::unordered_map): " << std::fixed
              << std::setprecision(3) << (zaman_sn() - t0) * 1e3 << " ms\n";
    return 0;
}

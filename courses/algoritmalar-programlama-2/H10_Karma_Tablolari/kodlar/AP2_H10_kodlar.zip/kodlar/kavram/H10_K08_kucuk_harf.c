/* H10_K08_kucuk_harf.c — AP-2 Hafta 10 · Kavram 8 (Dil Penceresi)
 * Amaç    : tolower BAYT BAYT çalışır ve yerel ayara bağlıdır; "C" yerel
 *           ayarında yalnız ASCII A–Z dönüşür. UTF-8'de iki bayt olan
 *           Türkçe büyük harfler (İ = c4 b0, Ş = c5 9e, Ç = c3 87) bayt
 *           düzeyinde DEĞİŞMEZ; 'I' ise 'i' olur (Türkçede 'ı' olmalıydı).
 *           Örnek 7'nin elle dönüşümü (A–Z → +32) aynı sonucu verir ve
 *           yerel ayara bağlı değildir: üç dilde aynı çıktının yolu budur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_K08_kucuk_harf.c -o H10_K08_kucuk_harf
 * Çalıştır: ./H10_K08_kucuk_harf
 */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

static void baytlari_yaz(const char *s)
{
    for (; *s != '\0'; s++) {
        printf(" %02x", (unsigned char)*s);
    }
}

int main(void)
{
    const char *sozcukler[] = {"KARMA", "IŞIK", "İSTANBUL", "ÇAĞRI"};
    for (int i = 0; i < 4; i++) {
        const char *s = sozcukler[i];
        char kutuphane[32], elle[32];
        size_t n = strlen(s);
        for (size_t j = 0; j <= n; j++) {
            unsigned char b = (unsigned char)s[j];
            kutuphane[j] = (char)tolower(b);             /* "C" yerel ayarı */
            elle[j] = (char)(b >= 'A' && b <= 'Z' ? b + 32 : b);
        }
        printf("%s: tolower -> %s, elle -> %s, aynı mı? %s\n", s, kutuphane,
               elle, strcmp(kutuphane, elle) == 0 ? "evet" : "hayır");
        printf("   %zu bayt:", n);
        baytlari_yaz(kutuphane);
        printf("\n");
    }
    return 0;
}

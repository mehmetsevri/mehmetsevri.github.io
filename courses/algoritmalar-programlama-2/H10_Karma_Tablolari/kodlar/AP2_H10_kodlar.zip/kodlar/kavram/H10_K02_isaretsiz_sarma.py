"""H10_K02_isaretsiz_sarma.py — AP-2 Hafta 10 · Kavram 2 (Dil Penceresi)
Amaç    : Python tamsayısı taşmaz, sınırsız büyür; C'deki uint32_t sarmasını
          elde etmek için her adımda & 0xFFFFFFFF uygulanır — sonuç C/C++ ile
          birebir aynıdır. Son bölüm (yalnız Python): maskesiz değer büyür.
Çalıştır: python3 H10_K02_isaretsiz_sarma.py
Eşleri  : H10_K02_isaretsiz_sarma.c · H10_K02_isaretsiz_sarma.cpp
"""


def main():
    s = b"karma_tablosu"
    h = 0                            # mod 2^32 (maskeyle)
    print(f"polinom karma, taban 31: \"{s.decode()}\"")
    print("   i  bayt  31·h + b (mod 2^64)        h (uint32_t)  sardı mı?")
    for i, b in enumerate(s):
        gercek = 31 * h + b          # Python: taşma yok
        h = gercek & 0xFFFFFFFF      # C'deki uint32_t sarması
        print(f"  {i:2d}  {b:4d}  {gercek:20d}  {h:14d}  "
              + ("evet (2^32'nin katı atıldı)" if gercek != h else "hayır"))
    print(f"sonuç: h = {h} = 0x{h:08x}")
    print(f"UINT32_MAX + 1 = {(0xFFFFFFFF + 1) & 0xFFFFFFFF} (tanımlı: "
          "mod 2^32)")
    # Yalnız Python: maske olmadan değer büyür (C'de karşılığı yok)
    buyuk = 0
    for b in s:
        buyuk = 31 * buyuk + b
    print(f"[yalnız Python] maskesiz: {buyuk.bit_length()} bit; "
          f"maskesiz & 0xFFFFFFFF = {buyuk & 0xFFFFFFFF} (aynı sonuç)")


if __name__ == "__main__":
    main()

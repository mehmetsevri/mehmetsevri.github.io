/* H10_K05_std_hash_ozel.cpp — AP-2 Hafta 10 · Kavram 5 (Dil Penceresi)
 * Amaç    : Kullanıcı tanımlı türü std::unordered_set / unordered_map
 *           anahtarı yapmak için iki şey gerekir: operator== ve
 *           std::hash<T> özelleştirmesi (ya da şablon argümanı olarak bir
 *           karma nesnesi). Sözleşme Python'dakiyle aynı: a == b ise
 *           karmalar eşit olmalı; karma yalnız == 'nin kullandığı
 *           alan(lar)dan hesaplanmalı.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_K05_std_hash_ozel.cpp -o H10_K05_std_hash_ozel
 * Çalıştır: ./H10_K05_std_hash_ozel
 */
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <string>
#include <unordered_map>

struct Ogrenci {
    std::uint32_t numara;
    std::string ad;
};

// Eşitlik yalnız numaraya bakar ...
static bool operator==(const Ogrenci& a, const Ogrenci& b)
{
    return a.numara == b.numara;
}

// ... o hâlde karma da yalnız numaradan hesaplanmalı
namespace std {
template <>
struct hash<Ogrenci> {
    std::size_t operator()(const Ogrenci& o) const noexcept
    {
        return std::hash<std::uint32_t>{}(o.numara);
    }
};
}  // namespace std

int main()
{
    std::unordered_map<Ogrenci, int> notlar;
    Ogrenci a{2400001, "Ayşe"};
    Ogrenci b{2400001, "Ayşe Yılmaz"};       // aynı numara, farklı ad
    notlar[a] = 85;
    std::cout << "a == b: " << (a == b ? "true" : "false")
              << ", karmalar eşit: "
              << (std::hash<Ogrenci>{}(a) == std::hash<Ogrenci>{}(b)
                      ? "true"
                      : "false")
              << ", notlar[b] = " << notlar.at(b) << '\n';
    notlar[b] = 90;                          // aynı anahtar: güncelleme
    std::cout << "notlar[b] = 90 sonrası: boyut = " << notlar.size()
              << ", notlar[a] = " << notlar.at(a) << '\n';
    std::cout << "anahtar const'tur: unordered_map düğümündeki Ogrenci "
                 "değiştirilemez (derleme hatası olur)\n";
    return 0;
}

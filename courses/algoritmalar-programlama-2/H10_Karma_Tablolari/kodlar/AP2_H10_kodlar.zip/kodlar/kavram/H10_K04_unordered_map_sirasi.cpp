/* H10_K04_unordered_map_sirasi.cpp — AP-2 Hafta 10 · Kavram 4
 * Amaç    : std::unordered_map'in dolaşma sırası BELİRTİLMEMİŞTİR: ekleme
 *           sırası korunmaz ve yeniden karma (rehash) sırayı değiştirebilir.
 *           Aynı anahtarlar std::map'te (sıralı ağaç) ve sıralanmış
 *           vektörde her zaman aynı sırada çıkar — üç dilde aynı çıktı için
 *           anahtarlar yazdırılmadan önce sıralanır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H10_K04_unordered_map_sirasi.cpp -o H10_K04_unordered_map_sirasi
 * Çalıştır: ./H10_K04_unordered_map_sirasi
 * Çıktı   : "bu derleyicide" (libstdc++); başka kütüphanede sıra farklı
 *           olabilir
 */
#include <algorithm>
#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

static void yaz(const char *baslik,
                const std::unordered_map<std::string, int>& m)
{
    std::cout << baslik << " (kova sayısı " << m.bucket_count() << "):";
    for (const auto& [ad, no] : m) {
        std::cout << ' ' << ad;
    }
    std::cout << '\n';
}

int main()
{
    std::unordered_map<std::string, int> plaka;
    const std::vector<std::pair<std::string, int>> veri = {
        {"rize", 53}, {"artvin", 8}, {"trabzon", 61}, {"giresun", 28},
        {"ordu", 52}};
    std::cout << "ekleme sırası: rize artvin trabzon giresun ordu\n";
    for (const auto& [ad, no] : veri) {
        plaka[ad] = no;
    }
    yaz("1) unordered_map dolaşma", plaka);
    plaka.rehash(64);                        // kova sayısını büyüt
    yaz("2) rehash(64) sonrası", plaka);
    std::map<std::string, int> sirali(plaka.begin(), plaka.end());
    std::cout << "3) std::map (sıralı):";
    for (const auto& [ad, no] : sirali) {
        std::cout << ' ' << ad;
    }
    std::vector<std::string> anahtar;
    for (const auto& [ad, no] : plaka) {
        anahtar.push_back(ad);
    }
    std::sort(anahtar.begin(), anahtar.end());
    std::cout << "\n4) anahtarlar sıralanarak (çıktı eşdeğerliği):";
    for (const std::string& a : anahtar) {
        std::cout << ' ' << a;
    }
    std::cout << '\n';
    return 0;
}

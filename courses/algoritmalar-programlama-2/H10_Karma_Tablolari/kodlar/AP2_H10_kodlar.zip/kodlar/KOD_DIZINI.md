# Hafta 10 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı ve beklenen çıktısıyla aşağıdadır. **Ders notu**, **Sunum** ve **Web** sütunları kodun gösterildiği yeri (bölüm, slayt, web kutusu) ve görünür metindeki anışları (PDF sayfası, slayt) verir. Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11.15 (örnekler 3.10 uyumludur).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. Standart girdiden okuyan örnekler (2, 7, 9) `girdiler/KÖK.txt` dosyasını bekler: `./program < girdiler/KÖK.txt`.

Eşdeğerlik: `python3 esdeger_test.py .` → **14/14 GEÇTİ** (14 “=”: üç dilde bayt bayt aynı stdout), uyarı 0; `--asan` (AddressSanitizer + UBSan + LeakSanitizer) ile **14/14 GEÇTİ** (hatalı 0). Valgrind: 55/55 program temiz (0 hata, 0 bayt kayıp) (`BELLEK_DENETIMI.txt`).


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H10_01_dogrudan_adresleme` | ★ | = | — | Doğrudan adresleme: 0–99 numaralı öğrenci tablosu (anahtar = indis); boş hücre, Θ(1) işlemler, anahtar evreni büyüyünce bellek | — | Bölüm 3.2; Ek A.1; metin s. 3, 4, 6, 7, 49 | slayt metin: 9 | örnek kutusu (üç dil), metin |
| `H10_02_karma_fonksiyonlari` | ★★ | = | — | Dizgi karma fonksiyonları: toplam (kötü), polinom (Horner, taban 31), FNV-1a; 10 000 adın kovalara dağılımı, χ² ölçütü ve histogram | < girdiler/H10_02_karma_fonksiyonlari.txt | Bölüm 3.3; Ek A.2; metin s. 3, 5, 7, 8, 45, 49 … | slayt kod: 13; metin: 12 | örnek kutusu (üç dil), metin |
| `H10_03_ayri_zincirleme` | ★★ | = | evet | Ayrı zincirleme karma tablosu: kova + düğüm listesi; ekle (güncelleme semantiği) / ara / sil; anahtar dizgisinin kopyalanması | — | Bölüm 4.1; Ek A.3; metin s. 3, 4, 5, 7, 9, 11 … | slayt kod: 20, 21; metin: 10, 18 | örnek kutusu (üç dil), metin |
| `H10_04_dogrusal_yoklama` | ★★★ | = | evet | Doğrusal yoklamalı açık adresleme: kümelenme, mezar taşıyla silme, mezar taşı birikimi ve temizleyerek yeniden kurma | — | Bölüm 4.2; Ek A.4; metin s. 3, 11, 15, 16, 52 | slayt kod: 28, 29; metin: 18 | örnek kutusu (üç dil), metin |
| `H10_05_yuk_faktoru` | ★★ | = | — | Yük faktörü deneyi: α = 0,25 … 0,95 için zincirleme ve doğrusal yoklamada ortalama yoklama; Knuth'un kuramsal değerleri | [p] [tohum] (m = 2^p, varsayılan p = 13, tohum = 42) | Ek A.5; metin s. 3, 4, 5, 12, 18, 32 … | slayt metin: 31 | örnek kutusu (üç dil), metin |
| `H10_06_yeniden_boyutlandirma` | ★★ | = | evet | Yeniden boyutlandırma: α > 3/4 olacaksa m × 2; taşınan öğe toplamı, öğe başına amortize maliyet, en pahalı tek ekleme | [N_ust] (varsayılan 100000) | Bölüm 4.3; Ek A.6; metin s. 3, 5, 18, 19, 36, 42 … | slayt kod: 34; metin: 32, 51 | örnek kutusu (üç dil), metin |
| `H10_07_kelime_frekansi` | ★★ | = | — | Kelime frekansı: bayt düzeyinde sözcük ayırma, elle ASCII küçük harf, zincirleme karma tablosu; en sık 20 sözcük (Ömer Seyfettin) | < girdiler/H10_07_kelime_frekansi.txt | Bölüm 5.1; Ek A.7; metin s. 2, 3, 4, 12, 26, 30 … | slayt metin: 37 | örnek kutusu (üç dil), metin |
| `H10_08_yinelenen_iki_toplam` | ★★ | = | — | Yinelenen tespiti ve iki toplam: karma kümesiyle O(n²) → O(n); kâhin kaba kuvvet ve karşılaştırma/yoklama sayıları | — | Bölüm 5.2; Ek A.8; metin s. 2, 3, 4, 27, 28, 30 … | slayt metin: 37 | örnek kutusu (üç dil), metin |
| `H10_09_anagram_gruplama` | ★★ | = | — | Anagram gruplama: anahtar = baytları sayma sıralamasıyla sıralanmış sözcük; zincirleme tabloda gruplar | < girdiler/H10_09_anagram_gruplama.txt | Bölüm 5.3; Ek A.9; metin s. 2, 3, 29, 30, 57 | slayt metin: 37 | örnek kutusu (üç dil), metin |
| `H10_10_dogum_gunu` | ★★ | = | — | Doğum günü paradoksu: kesin olasılık (n = 1..60, 23 kişide ≈ 0,507), Monte Carlo ve karma bağlantısı (ilk çakışma, %50 eşiği) | — | Bölüm 5.4; Ek A.10; metin s. 2, 3, 9, 29, 57 | slayt metin: 17 | örnek kutusu (üç dil), metin |
| `H10_11_naif_eslesme` | ★ | = | evet | Naif desen eşleme: kayma kayma karşılaştırma; rastgele metinde ≈ n, en kötü durumda (n − m + 1)·m; bayt ve karakter konumu | — | Bölüm 4.4; Ek A.11; metin s. 3, 4, 5, 21, 58 | slayt metin: 42 | örnek kutusu (üç dil), metin |
| `H10_12_rabin_karp` | ★★★ | = | evet | Rabin–Karp: kayan karma, karma eşitliğinin doğrulanması; küçük ve büyük modülle sahte eşleşme, mod 2^32 sürümü, negatif kalan | — | Bölüm 4.5; Ek A.12; metin s. 3, 23, 24, 44, 59 | slayt kod: 46; metin: 45, 47 | örnek kutusu (üç dil), metin |
| `H10_13_karma_saldirisi` | ★★★ | = | — | Kötü karma fonksiyonuna saldırı: "Aa"/"BB" bloklarıyla 2^k çakışan anahtar; karesel büyüme ve tohumlu karma savunmaları | [k_ust] (n = 2^8 .. 2^k_ust, varsayılan 10, en çok 16) | Bölüm 5.6; Ek A.13; metin s. 2, 3, 4, 30, 31, 34 … | slayt kod: 40; metin: 38 | örnek kutusu (üç dil), metin |
| `H10_14_kmp` | ★★★ | = | evet | KMP (merak): önek fonksiyonu π, metinde geri gitmeden eşleme, Θ(n + m) karşılaştırma; naif, Rabin–Karp ve kâhinle aynı konumlar | — | Ek A.14; metin s. 3, 25, 26, 61 | slayt metin: 48 | örnek kutusu (üç dil), metin |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt`. C++/Python'da C'den anlam olarak farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`.

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py` (13 Ekim 2026 sürümü). Kullananlar: ortak_rastgele — Örnek 4, 5, 6, 8, 10, 11, 12, 13, 14; zamanlayici — Örnek 7, 13 (süreler yalnızca stderr'e).


## 2. Kavram programları (kavram/)

Merdiven dışı küçük programlar (Kaputun Altında, Dil Penceresi). Çıktılar `kavram/ciktilar/`; “bu çalıştırmada” etiketli değerler (süre, `hash()`, `unordered_map` sırası) eşdeğerlik kapsamı dışındadır.

| Dosya | Dil | Amaç | Çıktı | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H10_K01_maske_ve_mod.c` | C | m = 2^p iken h % m == h & (m − 1) (işaretsiz h için); maskenin yalnız DÜŞÜK p biti kullandığı, düzenli anahtarlarda (çift sayılar, 16'nın katları) kimlik karmasıyla kovaların boş kaldığı; asal m ve çarpma yönteminin (üst bitler) bunu düzelttiği. % ve & süreleri stderr'e (bu çalıştırmada). | `ciktilar/H10_K01_maske_ve_mod.txt` | metin s. 10 | — | metin |
| `kavram/H10_K02_isaretsiz_sarma.c` | C | İşaretsiz taşma TANIMLIDIR: uint32_t aritmetiği mod 2^32 sarar; polinom karma bunu bilinçli kullanır. Her adımda sarmanın gerçekleşip gerçekleşmediği 64 bitlik "gerçek" değerle karşılaştırılarak gösterilir. (İşaretli int taşması ise TANIMSIZ davranıştır: Hata Avcısı 1.) | `ciktilar/H10_K02_isaretsiz_sarma_c.txt` | metin s. 10 | — | — |
| `kavram/H10_K02_isaretsiz_sarma.cpp` | C++ | İşaretsiz taşma TANIMLIDIR: std::uint32_t aritmetiği mod 2^32 sarar; polinom karma bunu bilinçli kullanır. Her adımda sarmanın gerçekleşip gerçekleşmediği 64 bitlik "gerçek" değerle karşılaştırılarak gösterilir. | `ciktilar/H10_K02_isaretsiz_sarma_cpp.txt` | metin s. 10 | — | — |
| `kavram/H10_K02_isaretsiz_sarma.py` | Python | Python tamsayısı taşmaz, sınırsız büyür; C'deki uint32_t sarmasını elde etmek için her adımda & 0xFFFFFFFF uygulanır — sonuç C/C++ ile birebir aynıdır. Son bölüm (yalnız Python): maskesiz değer büyür. | `ciktilar/H10_K02_isaretsiz_sarma_py.txt` | metin s. 10 | — | — |
| `kavram/H10_K03_python_hash.py` | Python | Python'un yerleşik hash()'i str ve bytes için her süreçte rastgele seçilen gizli bir anahtarla (tohum) hesaplanır (Python 3.3'ten beri varsayılan; 3.4'ten beri SipHash ailesi — PEP 456): değer çalıştırmadan çalıştırmaya DEĞİŞİR. PYTHONHASHSEED=0 rastgeleliği kapatır (yalnız hata ayıklama/tekrarlanabilirlik için). Küçük tamsayıların karması kendisidir. Bu yüzden ders örneklerinin çıktısında hash() kullanılmaz (ders notu Bölüm 8). | `ciktilar/H10_K03_python_hash.txt` | metin s. 4, 37 | — | metin |
| `kavram/H10_K03_std_hash.cpp` | C++ | std::hash<std::string>'in değeri gerçekleştirime bağlıdır (standart algoritmayı belirtmez); libstdc++'ta çalıştırmalar arasında AYNIDIR (Python'daki gibi süreç başına rastgele tohum yoktur). std::hash<int> libstdc++'ta sayının kendisidir. Bu yüzden ders örneklerinin çıktısında std::hash kullanılmaz. | `ciktilar/H10_K03_std_hash.txt` | metin s. 4, 37 | — | metin |
| `kavram/H10_K04_dict_sirasi.py` | Python | dict, anahtarları EKLEME SIRASIYLA dolaşır — Python 3.7'den beri dil güvencesidir (CPython 3.6'da gerçekleştirim ayrıntısıydı). Bir anahtarı silip yeniden eklemek onu sona taşır; değeri güncellemek sırayı değiştirmez. set için böyle bir güvence YOKTUR. Çıktıyı dillerden bağımsız kılmak için anahtarlar yine sıralanarak yazdırılır (sorted). | `ciktilar/H10_K04_dict_sirasi.txt` | metin s. 37 | — | metin |
| `kavram/H10_K04_unordered_map_sirasi.cpp` | C++ | std::unordered_map'in dolaşma sırası BELİRTİLMEMİŞTİR: ekleme sırası korunmaz ve yeniden karma (rehash) sırayı değiştirebilir. Aynı anahtarlar std::map'te (sıralı ağaç) ve sıralanmış vektörde her zaman aynı sırada çıkar — üç dilde aynı çıktı için anahtarlar yazdırılmadan önce sıralanır. | `ciktilar/H10_K04_unordered_map_sirasi.txt` | metin s. 37 | — | metin |
| `kavram/H10_K05_hash_eq_sozlesmesi.py` | Python | Karma edilebilirlik sözleşmesi: a == b ise hash(a) == hash(b) olmalı ve nesne tablodayken karması DEĞİŞMEMELİ. (1) Yalnız __eq__ tanımlayan sınıfın __hash__'i None olur: dict/set anahtarı olamaz. (2) __eq__ ve __hash__ aynı alan(lar)dan tanımlanır. (3) Anahtar tablodayken alanı değiştirilirse kayıt "kaybolur": anahtarlar değişmez olmalıdır (str, bytes, int, tuple, frozenset). | `ciktilar/H10_K05_hash_eq_sozlesmesi.txt` | metin s. 5, 37, 44 | — | metin |
| `kavram/H10_K05_std_hash_ozel.cpp` | C++ | Kullanıcı tanımlı türü std::unordered_set / unordered_map anahtarı yapmak için iki şey gerekir: operator== ve std::hash<T> özelleştirmesi (ya da şablon argümanı olarak bir karma nesnesi). Sözleşme Python'dakiyle aynı: a == b ise karmalar eşit olmalı; karma yalnız == 'nin kullandığı alan(lar)dan hesaplanmalı. | `ciktilar/H10_K05_std_hash_ozel.txt` | metin s. 5, 37, 44 | — | metin |
| `kavram/H10_K06_hsearch.c` | C | C standart kütüphanesinde genel amaçlı karma tablosu YOKTUR; POSIX (XSI) <search.h> hcreate/hsearch/hdestroy sunar: süreçte tek bir tablo, silme işlemi yok, kapasite baştan verilir, anahtar dizgisinin ömrünü çağıran yönetir. Örnek 7'nin küçük bir kelime sayacı hsearch ile. | `ciktilar/H10_K06_hsearch.txt` | metin s. 37 | — | metin |
| `kavram/H10_K07_kutuphane_frekans.cpp` | C++ | Örnek 7'nin kütüphane karşılığı: std::unordered_map<std::string, int> ile kelime sayımı; sözcük ayırma ve ASCII küçültme aynı (bayt düzeyinde, elle). En sık 20 sözcük Örnek 7 ile birebir aynı çıkmalıdır (kâhin); süre stderr'e (atölye karşılaştırması). | `ciktilar/H10_K07_kutuphane_frekans_cpp.txt` | metin s. 27, 32, 34, 45 | — | metin |
| `kavram/H10_K07_kutuphane_frekans.py` | Python | Örnek 7'nin kütüphane karşılığı: dict ile kelime sayımı; sözcük ayırma ve ASCII küçültme aynı (bayt düzeyinde, elle). En sık 20 sözcük Örnek 7 ile birebir aynı çıkmalıdır (kâhin); süre stderr'e (atölye karşılaştırması). collections.Counter da aynı işi yapar. | `ciktilar/H10_K07_kutuphane_frekans_py.txt` | metin s. 27, 32, 34, 45 | — | metin |
| `kavram/H10_K08_kucuk_harf.c` | C | tolower BAYT BAYT çalışır ve yerel ayara bağlıdır; "C" yerel ayarında yalnız ASCII A–Z dönüşür. UTF-8'de iki bayt olan Türkçe büyük harfler (İ = c4 b0, Ş = c5 9e, Ç = c3 87) bayt düzeyinde DEĞİŞMEZ; 'I' ise 'i' olur (Türkçede 'ı' olmalıydı). Örnek 7'nin elle dönüşümü (A–Z → +32) aynı sonucu verir ve yerel ayara bağlı değildir: üç dilde aynı çıktının yolu budur. | `ciktilar/H10_K08_kucuk_harf_c.txt` | metin s. 38, 45 | — | metin |
| `kavram/H10_K08_kucuk_harf.py` | Python | str.lower Unicode kurallarıyla çalışır, yerel ayara bakmaz: Ş → ş, Ç → ç doğru; ama I → i (Türkçede ı olmalıydı) ve İ → i + U+0307 (BİRLEŞEN ÜST NOKTA): "İSTANBUL".lower() 9 karakterdir. Örnek 7'nin bayt düzeyindeki elle dönüşümü (A–Z → +32) C'deki tolower ile aynı sonucu verir: üç dilde aynı çıktı için kullanılan yol budur. | `ciktilar/H10_K08_kucuk_harf_py.txt` | metin s. 38, 45 | — | metin |
| `kavram/H10_K09_gizli_taban.py` | Python | Örnek 13'ün "rastgele taban + alt bit" savunması gizli tabanın şansına mı bağlı? 20 rastgele tek taban (ortak LCG, tohum 2026; ilki Örnek 13'ün tabanı) için Aa/BB saldırı anahtarlarında (n = 512 ve 1024) anahtar karşılaştırması; t = v2(taban − 31), s = v2(taban² − 1): indisin en az alt t + s biti yalnız BB bloklarının sayısını taşır (her tek tabanda t ≥ 1, s ≥ 3) | `ciktilar/H10_K09_gizli_taban.txt` | metin s. 31, 34, 38 | slayt metin: 40 | metin |


## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir. Belirtiler bu makinede, bu çalıştırmada gözlenmiştir (`hata_avcisi/ciktilar/`; HA1'de ASan ve UBSan raporları adres/PID/yol sadeleştirilmiş olarak). C/C++ dosyaları `hata_avcisi/` içinde `-I../c` ile derlenir (HA5: `../c/ortak_rastgele.c`).

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H10_HA1_negatif_indis.c` | C | kasıtlı hata | karma işaretli int ile hesaplanıyor ve baytlar işaretli char olarak okunuyor: Türkçe harfin baytı (ör. 0xC5) negatif sayılır, uzun anahtarda int taşar; negatif karma % M ile NEGATİF indis verir (C'de kalan bölünenin işaretini alır — H1 Dil Penceresi) ve tablo dışına yazılır. | `ciktilar/H10_HA1_negatif_indis.txt` `ciktilar/H10_HA1_negatif_indis_asan.txt` `ciktilar/H10_HA1_negatif_indis_ubsan.txt` | metin s. 5, 10, 35, 38 | slayt metin: 28 | metin |
| `hata_avcisi/H10_HA1_negatif_indis_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H10_HA1_negatif_indis_duzeltilmis.txt` | metin s. 5, 10, 35, 38 | slayt metin: 28 | metin |
| `hata_avcisi/H10_HA2_kopyalanmayan_anahtar.c` | C | kasıtlı hata | zincirleme tabloya eklerken anahtar dizgisi KOPYALANMIYOR; düğüm, girdi okuma tamponunun adresini saklıyor. Tampon her yeni sözcükte değiştiği için tablodaki bütün anahtarlar son okunan sözcüğe "dönüşür"; tampon değişince tablo bozulur. | `ciktilar/H10_HA2_kopyalanmayan_anahtar.txt` | metin s. 13, 36 | slayt metin: 28, 49, 50 | metin |
| `hata_avcisi/H10_HA2_kopyalanmayan_anahtar_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H10_HA2_kopyalanmayan_anahtar_duzeltilmis.txt` | metin s. 13, 36 | slayt metin: 28, 49, 50 | metin |
| `hata_avcisi/H10_HA3_silinen_hucre_bos.c` | C | kasıtlı hata | doğrusal yoklamada silinen hücre BOŞ yapılıyor (mezar taşı yok). Arama BOŞ hücrede durduğu için silinen hücrenin ötesine yoklamayla yerleşmiş anahtarlar "kaybolur"; yeniden eklenince tabloda İKİ kopya oluşur. | `ciktilar/H10_HA3_silinen_hucre_bos_c.txt` | metin s. 15, 17 | — | metin |
| `hata_avcisi/H10_HA3_silinen_hucre_bos.py` | Python | kasıtlı hata | doğrusal yoklamada silinen hücre BOŞ (None) yapılıyor (mezar taşı yok). Arama BOŞ hücrede durduğu için silinen hücrenin ötesine yoklamayla yerleşmiş anahtarlar "kaybolur"; yeniden eklenince tabloda İKİ kopya oluşur. Hata dile bağlı değildir. | `ciktilar/H10_HA3_silinen_hucre_bos_py.txt` | metin s. 15, 17 | — | metin |
| `hata_avcisi/H10_HA3_silinen_hucre_bos_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H10_HA3_silinen_hucre_bos_duzeltilmis_c.txt` | metin s. 15, 17 | — | metin |
| `hata_avcisi/H10_HA3_silinen_hucre_bos_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H10_HA3_silinen_hucre_bos_duzeltilmis_py.txt` | metin s. 15, 17 | — | metin |
| `hata_avcisi/H10_HA4_yuk_denetimi_yok.cpp` | C++ | kasıtlı hata | açık adreslemede yük faktörü denetlenmiyor ve yoklama döngüsü yalnız "BOŞ hücre bulunca" bitiyor. Tablo dolunca (α = 1) ekleme ve olmayan anahtarı arama SONSUZ DÖNGÜYE girer. Gösterim güvenli olsun diye döngüye bir ADIM SINIRI eklendi (gerçek hatalı kodda bu sınır yoktur: program donar). | `ciktilar/H10_HA4_yuk_denetimi_yok.txt` | metin s. 16, 36 | slayt metin: 28 | — |
| `hata_avcisi/H10_HA4_yuk_denetimi_yok_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H10_HA4_yuk_denetimi_yok_duzeltilmis.txt` | metin s. 16, 36 | slayt metin: 28 | — |
| `hata_avcisi/H10_HA5_dogrulamasiz_rabin_karp.c` | C | kasıtlı hata | Rabin–Karp'ta karma eşitliği doğrudan eşleşme sayılıyor; pencere karakter karakter DOĞRULANMIYOR. Farklı metinler aynı karmayı verebildiği için (sahte eşleşme) yanlış konumlar raporlanır; küçük modülde (q = 13) neredeyse her 13 pencereden biri. | `ciktilar/H10_HA5_dogrulamasiz_rabin_karp_c.txt` | Bölüm 7; metin s. 23 | slayt metin: 50 | metin |
| `hata_avcisi/H10_HA5_dogrulamasiz_rabin_karp.py` | Python | kasıtlı hata | Rabin–Karp'ta karma eşitliği doğrudan eşleşme sayılıyor; pencere karakter karakter DOĞRULANMIYOR. Farklı metinler aynı karmayı verebildiği için (sahte eşleşme) yanlış konumlar raporlanır. | `ciktilar/H10_HA5_dogrulamasiz_rabin_karp_py.txt` | metin s. 23 | slayt kod: 50 | satır içi kod, metin |
| `hata_avcisi/H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis_c.txt` | metin s. 23 | slayt metin: 50 | metin |
| `hata_avcisi/H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H10_HA5_dogrulamasiz_rabin_karp_duzeltilmis_py.txt` | metin s. 23 | slayt kod: 50 | satır içi kod, metin |
| `hata_avcisi/H10_HA6_list_anahtar.py` | Python | kasıtlı hata | anagram gruplamada anahtar olarak sorted(sozcuk) — yani bir LIST — kullanılıyor. list değiştirilebilir (mutable) olduğu için karma edilemez: dict ve set anahtarı olamaz. Belirti: TypeError: unhashable type: 'list' | `ciktilar/H10_HA6_list_anahtar.txt` | metin s. 29, 36, 57 | — | metin |
| `hata_avcisi/H10_HA6_list_anahtar_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H10_HA6_list_anahtar_duzeltilmis.txt` | metin s. 29, 36, 57 | — | metin |


## 4. Haftanın Deneyi (deney/)

Sürücü `python3 deney/h10_olcum_calistir.py` (derler, çalıştırır, ham CSV'leri ve `OLCUM_ORTAMI.txt`'yi yazar), çözümleme `python3 deney/h10_cozumle.py` (özet CSV/JSON: oranlar, katlar, eğimler, işaretli kestirimler), grafikler `python3 ../gorseller/kaynak/h10_deney_grafik.py`. Ortak modüllerin kopyaları `deney/{c,cpp,python}/` içindedir.

| Dosya | Dil | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `deney/c/H10_deney_saldiri.c` | C | Saldırı altında ekleme: n = 2^k çakışan anahtar ("Aa"/"BB" blokları, polinom 31) zincirleme tabloya eklenirken toplam anahtar karşılaştırması ve süre (karesel büyüme); aynı uzunlukta rastgele anahtarlar (doğrusal) ve savunmalar: tohumlu FNV-1a, rastgele taban + üst bit indisi (Örnek 13). Düğüm anahtarı düğümün içinde tutulur (karşılaştırma sayısı Örnek 13 ile aynıdır; yalnız bellek düzeni farklı). | metin s. 35 | slayt metin: 31, 36, 41 | metin |
| `deney/c/H10_deney_yuk_faktoru.c` | C | Yük faktörü α = 0,25 … 0,95: ayrı zincirleme ve doğrusal yoklamada (1) ortalama yoklama sayısı (deterministik; birden çok tohum) ve (2) arama süresi (bitişik hücreler / dağınık düğümler). Karma: çarpma yöntemi (Örnek 5 ile aynı). | metin s. 35 | slayt metin: 31, 36, 41 | metin |
| `deney/cpp/H10_deney_saldiri.cpp` | C++ | C sürümüyle aynı ölçüm (aynı anahtarlar, aynı karşılaştırma sayıları). Düğüm anahtarı C'deki gibi düğüm içinde sabit boyutlu dizi (std::array): iki dilin bellek düzeni aynı kalsın diye std::string (ayrı yığın ayırması) kullanılmadı. | metin s. 35 | slayt metin: 31, 36, 41 | metin |
| `deney/cpp/H10_deney_yuk_faktoru.cpp` | C++ | C sürümüyle aynı ölçüm; ek olarak etiketli kütüphane serisi: std::unordered_map<std::uint32_t, std::uint32_t> (kova sayısı ≈ m ile kurulur, max_load_factor 1,0: aynı n'de yeniden karma olmaz). Yoklama kipinin çıktısı C ile birebir aynıdır. | metin s. 35 | slayt metin: 31, 36, 41 | metin |
| `deney/python/H10_deney_saldiri.py` | Python | C/C++ ile aynı anahtarlar ve aynı karşılaştırma sayıları; süre bütçesi: bir ölçümün (1 ısınma + TEKRAR) kestirilen süresi BUTCE_S'yi aşacaksa o seri için daha büyük k ölçülmez (çözümleme betiği bunları c·n² ya da c·n modeliyle İŞARETLİ kestirir). | metin s. 35 | slayt metin: 31, 36, 41 | metin |
| `deney/python/H10_deney_yuk_faktoru.py` | Python | yoklama kipi C/C++ ile birebir aynı CSV'yi üretir (deterministik sayaçlar; küçük m ile sınanır). sure kipi: etiketli kütüphane serisi dict (aynı anahtar kümeleri; dict kendi yük faktörüyle çalışır) — başarılı/başarısız arama süresi. | metin s. 35 | slayt metin: 31, 36, 41 | metin |
| `deney/h10_olcum_calistir.py` | Python | AP-2 Hafta 10 · Haftanın Deneyi sürücüsü | metin s. 35 | slayt metin: 31, 36, 41 | metin |
| `deney/h10_cozumle.py` | Python | AP-2 Hafta 10 · Haftanın Deneyi çözümlemesi | metin s. 35 | slayt metin: 31, 36, 41 | metin |

Ham ve özet veriler (`deney/sonuclar/`): `h10_denetim.json`, `h10_deney_arama_suresi.csv`, `h10_deney_kelime_sayaci.csv`, `h10_deney_saldiri.csv`, `h10_deney_yoklama.csv`, `h10_ozet.json`, `h10_ozet_saldiri.csv`, `h10_ozet_sure.csv`, `h10_ozet_yoklama.csv`; ölçüm ortamı `deney/OLCUM_ORTAMI.txt`.


## 5. Girdiler (girdiler/)

Kaynak ve telif bilgisi: `girdiler/KAYNAK_NOTU.txt`.

| Dosya | Açıklama |
|---|---|
| `girdiler/H10_02_karma_fonksiyonlari.txt` | Örnek 2 standart girdisi (156282 bayt) |
| `girdiler/H10_07_kelime_frekansi.txt` | Örnek 7 standart girdisi (52424 bayt) |
| `girdiler/H10_09_anagram_gruplama.txt` | Örnek 9 standart girdisi (194 bayt) |
| `girdiler/KAYNAK_NOTU.txt` | Girdilerin kaynağı, telif durumu ve yapılan dönüşümler |
| `girdiler/ad_listesi_uret.py` | Ortak LCG (tohum 42) ile Türkçe ad ve soyad parçalarından birbirinden farklı n tam ad üretir (UTF-8, satır başına bir ad). Varsayılan n = 10000: H10_02_karma_fonksiyonlari.txt bu komutla üretildi. Atölye (karma fonksiyonu yarışması) için n = 100000. |


## 6. Alıştırma ve quiz programları (alistirmalar/, quiz/)

Alıştırmaların ve quiz sorularının kodlu dosyaları. Çıktıları (`alistirmalar/ciktilar/`, `quiz/ciktilar/`) yanıt olduğu için öğrenci ZIP'inde yoktur. Parsons bulmacası (A09) bilerek derlenmez; “hata bul” dosyaları (A07, A08) kasıtlı mantık hatası içerir ama bellek açısından temizdir (ASan + Valgrind, `BELLEK_DENETIMI.txt`).

| Dosya | Dil | Kullanım | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `alistirmalar/H10_A01_cikti_tahmini.c` | C | Alıştırma 10.1 | Doğrusal yoklama ve mezar taşı: çıktıyı çalıştırmadan tahmin edin, sonra derleyip karşılaştırın (m = 7, h(k) = k mod 7) | metin s. 41 | — | satır içi kod, metin |
| `alistirmalar/H10_A07_hata_bul_buyutme.c` | C | Alıştırma 10.7 | — | Alıştırma 10.7; metin s. 42 | — | satır içi kod, metin |
| `alistirmalar/H10_A08_hata_bul_iki_toplam.c` | C | Alıştırma 10.8 | — | Alıştırma 10.8; metin s. 28, 43 | — | satır içi kod, metin |
| `alistirmalar/H10_A09_parsons_zincir_sil.c` | C | Alıştırma 10.9 | — | Alıştırma 10.9; metin s. 43 | — | satır içi kod, metin |
| `alistirmalar/H10_A13_kalan_isareti.c` | C | Alıştırma 10.13 | Diller arası okuma: Python eşiyle aynı kayan karma satırı (+ q YOK). Hangi dil kaç karma eşitliği bulur, neden? | Alıştırma 10.13; metin s. 24, 44 | — | satır içi kod, metin |
| `alistirmalar/H10_A13_kalan_isareti.py` | Python | Alıştırma 10.13 | Diller arası okuma: C eşiyle aynı kayan karma satırı (+ q YOK). Hangi dil kaç karma eşitliği bulur, neden? | metin s. 24, 44 | — | metin |
| `alistirmalar/H10_A15_karma_yarismasi.c` | C | Atölye 1 | Karma fonksiyonu yarışması: ogrenci_karma'yı kendi fonksiyonunuzla değiştirin; 10^5 adın kova dağılımını ölçün | metin s. 3, 45 | — | metin |
| `alistirmalar/H10_A15_karma_yarismasi.py` | Python | Atölye 1 | Karma fonksiyonu yarışması: ogrenci_karma'yı kendi fonksiyonunuzla değiştirin; 10^5 adın kova dağılımını ölçün | metin s. 3, 45 | — | metin |
| `quiz/H10_Q04_kalan.c` | C | web quiz sorusu 4 | Negatif ara değerin kalanı (Rabin–Karp güncellemesi) | — | — | satır içi kod |
| `quiz/H10_Q04_kalan.py` | Python | web quiz sorusu 4 | Negatif ara değerin kalanı (Rabin–Karp güncellemesi) | — | — | — |
| `quiz/H10_Q05_anahtar.py` | Python | web quiz sorusu 5 | Sözlük anahtarı: değiştirilemez (karma edilebilir) türler | — | — | satır içi kod |
| `quiz/H10_Q07_sarma.c` | C | web quiz sorusu 7 | İşaretsiz taşma: polinom karmanın bir adımı (uint32_t) | — | — | satır içi kod |


## 7. Diğer

- `BELLEK_DENETIMI.txt` — Valgrind (ve ASan) bellek denetimi sonuçları (betikle üretildi; doğrulama kanıtıdır).
- `ornekler.json` — örnek üst verisi (başlık, düzey, çıktı türü, fark satırları, Dil Penceresi notu).
- `esdeger_test.py` — eşdeğerlik testi (ortak; değiştirilmedi).

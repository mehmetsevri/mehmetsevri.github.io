"""ad_listesi_uret.py — AP-2 Hafta 10 · Örnek 2 girdisinin üreteci
Amaç    : Ortak LCG (tohum 42) ile Türkçe ad ve soyad parçalarından
          birbirinden farklı n tam ad üretir (UTF-8, satır başına bir ad).
          Varsayılan n = 10000: H10_02_karma_fonksiyonlari.txt bu komutla
          üretildi. Atölye (karma fonksiyonu yarışması) için n = 100000.
Çalıştır: python3 ad_listesi_uret.py [n] > adlar.txt
Kural   : her ad için ad (100 seçenek), olasılık 1/4 ile ikinci ad ve
          soyad (100 seçenek) LCG ile seçilir (ikinci ad ilkiyle aynıysa
          eklenmez); daha önce üretilmiş ad atlanır (yinelenen yok).
          Aynı n ile her zaman aynı liste çıkar; n en çok 200000.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402

ADLAR = (
    "Ahmet Mehmet Mustafa Ali Hüseyin Hasan İbrahim İsmail Osman Yusuf "
    "Murat Ömer Ramazan Halil Süleyman Abdullah Mahmut Recep Salih Fatih "
    "Kadir Emre Hakan Adem Kemal Yaşar Burak Serkan Uğur Gökhan Volkan Cem "
    "Can Efe Kerem Arda Mert Deniz Barış Tolga Onur Oğuz Çağrı Doğan Erkan "
    "Furkan Görkem Ilgaz Kaan Levent Fatma Ayşe Emine Hatice Zeynep Elif "
    "Meryem Şerife Zehra Sultan Hanife Merve Özlem Yasemin Hülya Esra "
    "Büşra Gül Dilek Ebru Sevgi Songül Gülsüm Kübra İrem Ece Defne Ela "
    "Nehir Asya Duru Öykü Şeyma Tuğba Çiğdem Gizem Aslı Derya Nazlı Pınar "
    "Sibel Şule Ümran Yağmur Zerrin Nur Selin Melike Rabia Beyza").split()
SOYADLAR = (
    "Yılmaz Kaya Demir Şahin Çelik Yıldız Yıldırım Öztürk Aydın Özdemir "
    "Arslan Doğan Kılıç Aslan Çetin Kara Koç Kurt Özkan Şimşek Polat Özcan "
    "Korkmaz Çakır Erdoğan Yavuz Can Acar Şen Aktaş Güler Yalçın Güneş "
    "Bozkurt Bulut Keskin Ünal Turan Gül Özer Işık Kaplan Avcı Sarı Tekin "
    "Taş Köse Yüksel Ateş Aksoy Ekinci Akın Karataş Uçar Tunç Sevim Erdem "
    "Coşkun Akbulut Güven Altun Uysal Kocabaş Bayram Bilgin Duman Gündüz "
    "Kalkan Karakaya Kartal Tosun Ural Uzun Yazıcı Yiğit Zengin Başaran "
    "Bektaş Cengiz Çiftçi Dağlı Eren Ergün Gökçe Gürbüz Kahraman Karaca "
    "Kılınç Metin Oral Özgür Savaş Sönmez Soylu Şeker Tan Toprak Türkmen "
    "Ülker Yücel").split()


def ad_uret(n):
    rastgele_tohum(42)
    goruldu = set()        # yalnızca yinelenen denetimi (üreteç aracı)
    sonuc = []
    while len(sonuc) < n:
        ad = ADLAR[rastgele_aralik(0, len(ADLAR) - 1)]
        if rastgele_aralik(0, 3) == 0:
            ikinci = ADLAR[rastgele_aralik(0, len(ADLAR) - 1)]
            if ikinci != ad:
                ad += " " + ikinci
        ad += " " + SOYADLAR[rastgele_aralik(0, len(SOYADLAR) - 1)]
        if ad not in goruldu:
            goruldu.add(ad)
            sonuc.append(ad)
    return sonuc


def main():
    n = 10000
    if len(sys.argv) > 1:
        try:
            n = int(sys.argv[1])
        except ValueError:
            print("kullanım: python3 ad_listesi_uret.py [n]", file=sys.stderr)
            sys.exit(2)
    if not 1 <= n <= 200000:
        print("n 1 ile 200000 arasında olmalı", file=sys.stderr)
        sys.exit(2)
    cikti = sys.stdout.buffer
    for ad in ad_uret(n):
        cikti.write(ad.encode("utf-8") + b"\n")


if __name__ == "__main__":
    main()

"""H10_08_yinelenen_iki_toplam.py — AP-2 Hafta 10 · Örnek 8 (★★)
Amaç    : Karma tablosuyla O(n²) → O(n): (1) yinelenen numara tespiti
          (sayaçlı karma kümesi; H2'nin kaba kuvvetiyle aynı sonuç),
          (2) iki toplam (two-sum): a[i] + a[j] = T; kâhin O(n²) kaba
          kuvvet; karşılaştırma ve yoklama sayıları
Çalıştır: python3 H10_08_yinelenen_iki_toplam.py
Eşleri  : c/H10_08_yinelenen_iki_toplam.c ·
          cpp/H10_08_yinelenen_iki_toplam.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_karistir, rastgele_tohum


class Harita:
    """Açık adresleme (doğrusal yoklama), tamsayı anahtar → int değer"""
    __slots__ = ("anahtar", "deger", "dolu", "p")

    def __init__(self, n):
        p = 4
        while (1 << p) < 2 * n:              # m = 2^p ≥ 2n: α ≤ 1/2
            p += 1
        m = 1 << p
        self.anahtar = [0] * m
        self.deger = [0] * m
        self.dolu = [0] * m
        self.p = p


yoklama_sayisi = 0
karsilastirma_sayisi = 0


def karma_carpma(k, p):
    return ((k * 2654435769) & 0xFFFFFFFF) >> (32 - p)


def harita_yer(h, k):
    """(hücre, var): bulunduysa var = True, yoksa ilk BOŞ hücre"""
    global yoklama_sayisi
    maske = (1 << h.p) - 1
    i = karma_carpma(k, h.p)
    while True:
        yoklama_sayisi += 1
        if not h.dolu[i]:
            return i, False
        if h.anahtar[i] == k:
            return i, True
        i = (i + 1) & maske


# --- 1) Yinelenen tespiti -----------------------------------------------

def cift_kaba(a):
    """Kâhin (H2): tüm çiftler, eşit çift sayısı; n(n-1)/2 karşılaştırma"""
    global karsilastirma_sayisi
    cift = 0
    n = len(a)
    for i in range(n - 1):
        for j in range(i + 1, n):
            karsilastirma_sayisi += 1
            cift += a[i] == a[j]
    return cift


def cift_karma(a, yin):
    """Karma ile: her değerin kaç kez geçtiği; eşit çift = Σ c(c-1)/2.
    Yinelenen değerler (c ≥ 2) (değer, sayı) olarak yin'e eklenir."""
    h = Harita(len(a))
    for x in a:
        yer, var = harita_yer(h, x)
        if var:
            h.deger[yer] += 1
        else:
            h.dolu[yer] = 1
            h.anahtar[yer] = x
            h.deger[yer] = 1
    cift = 0
    yin.clear()
    for i in range(len(h.dolu)):
        if h.dolu[i] and h.deger[i] >= 2:
            c = h.deger[i]
            cift += c * (c - 1) // 2
            yin.append((h.anahtar[i], h.deger[i]))
    return cift


def senaryo(ad, a):
    global karsilastirma_sayisi, yoklama_sayisi
    yin = []
    karsilastirma_sayisi = 0
    c1 = cift_kaba(a)
    yoklama_sayisi = 0
    c2 = cift_karma(a, yin)
    # çıktı biçimi: yinelenenleri değere göre sırala (karma sırası
    # tanımsız) — küçük liste, araya ekleme
    for i in range(1, len(yin)):
        x = yin[i]
        j = i
        while j > 0 and yin[j - 1][0] > x[0]:
            yin[j] = yin[j - 1]
            j -= 1
        yin[j] = x
    satir = (f"  {ad} n={len(a)}: kaba {c1} çift "
             f"(kar={karsilastirma_sayisi}) | karma {c2} çift "
             f"(yokl={yoklama_sayisi}) | yinelenen:")
    if not yin:
        satir += " yok"
    for deger, sayi in yin:
        satir += f" {deger}×{sayi}"
    print(satir)


# --- 2) İki toplam --------------------------------------------------------

def iki_toplam_kaba(a, T):
    """Kâhin: en küçük j, sonra en küçük i ile a[i] + a[j] = T; yoksa None"""
    global karsilastirma_sayisi
    for j in range(1, len(a)):
        for i in range(j):
            karsilastirma_sayisi += 1
            if a[i] + a[j] == T:
                return i, j
    return None


def iki_toplam_karma(a, T):
    """Karma: soldan sağa; T - a[j] daha önce görüldüyse ilk görüldüğü i"""
    h = Harita(len(a))
    for j in range(len(a)):
        if a[j] <= T:
            yer, var = harita_yer(h, T - a[j])
            if var:
                return h.deger[yer], j
        yer, var = harita_yer(h, a[j])
        if not var:                          # yalnız ilk konum tutulur
            h.dolu[yer] = 1
            h.anahtar[yer] = a[j]
            h.deger[yer] = j
    return None


def iki_toplam_satiri(ad, a, T, kaba_da):
    global karsilastirma_sayisi, yoklama_sayisi
    yoklama_sayisi = 0
    b2 = iki_toplam_karma(a, T)
    satir = f"  {ad}, n = {len(a)}, T = {T}: "
    if b2 is not None:
        i2, j2 = b2
        satir += f"({i2}, {j2}) {a[i2]} + {a[j2]}"
    else:
        satir += "çift yok"
    satir += f" | karma yokl={yoklama_sayisi}"
    if kaba_da:
        karsilastirma_sayisi = 0
        b1 = iki_toplam_kaba(a, T)
        ayni = b1 == b2
        satir += (f" | kaba kar={karsilastirma_sayisi}, aynı mı? "
                  f"{'evet' if ayni else 'HAYIR'}")
    print(satir)


def main():
    global karsilastirma_sayisi, yoklama_sayisi
    print("1) Yinelenen tespiti: eşit çift sayısı = Σ c(c-1)/2 (c: bir "
          "değerin kaç kez geçtiği)")
    senaryo("S1", [11, 22, 33, 44, 55])
    senaryo("S2", [7, 3, 7, 5, 3, 7])
    senaryo("S3", [9, 9, 1, 2, 3, 4])
    senaryo("S4", [1, 2, 3, 4, 8, 8])

    print("\n  Öğrenci numaraları 2400000000 + karıştırılmış 0..n-1, "
          "a[n/2] = a[0] kopyası (tohum 42)")
    print("         n   çift  karma yokl.  yokl./n   kaba kar.  "
          "(kaba = n(n-1)/2)")
    for n in [1000, 2000, 10000, 100000]:
        sira = list(range(n))
        rastgele_tohum(42)
        rastgele_karistir(sira)
        no = [2400000000 + s for s in sira]
        no[n // 2] = no[0]
        yoklama_sayisi = 0
        cift = cift_karma(no, [])
        satir = (f"  {n:8d} {cift:6d} {yoklama_sayisi:12d} "
                 f"{yoklama_sayisi / n:8.3f}")
        if n <= 2000:
            karsilastirma_sayisi = 0
            c1 = cift_kaba(no)
            satir += (f" {karsilastirma_sayisi:11d}  "
                      + ("(aynı sonuç)" if c1 == cift else "(FARKLI!)"))
        else:
            satir += f" {'-':>11}"
        print(satir)

    print("\n2) İki toplam: a[i] + a[j] = T olan ilk çift (en küçük j, "
          "sonra en küçük i)")
    k = [8, 3, 11, 7, 2, 15, 5]
    iki_toplam_satiri("küçük", k, 9, True)
    iki_toplam_satiri("küçük", k, 100, True)
    for n in [1000, 2000, 100000]:
        rastgele_tohum(7)
        a = [2 * rastgele_aralik(0, 499999) for _ in range(n)]   # çift
        iki_toplam_satiri("tek T", a, 999999, n <= 2000)        # yok
        iki_toplam_satiri("son ikili", a, a[n - 2] + a[n - 1], n <= 2000)
    print("  (tek T: tüm sayılar çift olduğundan çözüm yok — en kötü "
          "durum: kaba n(n-1)/2 karşılaştırma,\n   karma öğe başına iki "
          "arama: toplam Θ(n) yoklama)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_set /
# std::unordered_map (find, count); Python — set / dict
# (x in gorulen, gorulen[x] = j).

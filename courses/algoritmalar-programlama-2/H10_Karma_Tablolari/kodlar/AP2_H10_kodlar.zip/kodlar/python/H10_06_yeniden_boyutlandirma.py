"""H10_06_yeniden_boyutlandirma.py — AP-2 Hafta 10 · Örnek 6 (★★)
Amaç    : Yeniden boyutlandırma (rehash): α = n/m > 3/4 olacaksa kapasite
          × 2 ve tüm anahtarlar yeni tabloya yeniden yerleştirilir;
          taşınan öğe sayısının toplamı ve öğe başına amortize maliyet
          (tek ekleme Θ(n) olabilir, n eklemenin toplamı O(n))
Çalıştır: python3 H10_06_yeniden_boyutlandirma.py [N_ust]
          (varsayılan 100000)
Eşleri  : c/H10_06_yeniden_boyutlandirma.c ·
          cpp/H10_06_yeniden_boyutlandirma.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

from ortak_rastgele import rastgele_sayi, rastgele_tohum


class Tablo:
    __slots__ = ("anahtar", "dolu", "p", "n")

    def __init__(self, p):
        self.anahtar = [0] * (1 << p)
        self.dolu = [0] * (1 << p)
        self.p = p                           # m = 2^p
        self.n = 0


yoklama_sayisi = 0
yazma_sayisi = 0                             # hücreye yazılan anahtar
tasinan_sayisi = 0                           # yeniden yerleştirilen
iz_ac = False                                # bölüm 1: olayları yaz


def karma_carpma(k, p):
    return ((k * 2654435769) & 0xFFFFFFFF) >> (32 - p)


def yerlestir(t, k):
    """Yer bulup yazar (yük denetimi yok); True: yeni, False: zaten var"""
    global yoklama_sayisi, yazma_sayisi
    maske = (1 << t.p) - 1
    i = karma_carpma(k, t.p)
    while True:
        yoklama_sayisi += 1
        if not t.dolu[i]:
            break
        if t.anahtar[i] == k:
            return False
        i = (i + 1) & maske
    t.dolu[i] = 1
    t.anahtar[i] = k
    t.n += 1
    yazma_sayisi += 1
    return True


def buyut(t):
    """Kapasite × 2: eski listedeki her anahtar yeni listeye yeniden karma
    ile yerleşir (indis m'ye bağlı olduğundan kopyalamak yetmez)"""
    global tasinan_sayisi
    yeni = Tablo(t.p + 1)
    m = len(t.anahtar)
    for i in range(m):
        if t.dolu[i]:
            yerlestir(yeni, t.anahtar[i])
            tasinan_sayisi += 1
    if iz_ac:
        print(f"  ekleme #{t.n + 1} öncesi: α = {t.n + 1}/{m} > 3/4 "
              f"olacaktı -> m {m} -> {2 * m}, taşınan {t.n}")
    t.anahtar, t.dolu, t.p = yeni.anahtar, yeni.dolu, yeni.p


def tablo_ekle(t, k):
    """Yük denetimli ekleme: (n + 1) / m > 3/4 olacaksa önce büyüt"""
    if 4 * (t.n + 1) > 3 * len(t.anahtar):
        buyut(t)
    return yerlestir(t, k)


def deney_satiri(N):
    global yoklama_sayisi, yazma_sayisi, tasinan_sayisi
    t = Tablo(3)                             # m = 8 ile başla
    yoklama_sayisi = yazma_sayisi = tasinan_sayisi = 0
    en_pahali = 0
    en_pahali_no = 0
    buyutme = 0
    rastgele_tohum(42)
    while t.n < N:
        once = yazma_sayisi
        p_once = t.p
        tablo_ekle(t, rastgele_sayi())
        buyutme += t.p != p_once
        if yazma_sayisi - once > en_pahali:
            en_pahali = yazma_sayisi - once
            en_pahali_no = t.n
    print(f"  {N:8d} {buyutme:4d} {len(t.anahtar):9d} {tasinan_sayisi:10d} "
          f"{tasinan_sayisi / N:8.3f} {en_pahali:11d} {en_pahali_no:9d} "
          f"{yazma_sayisi / N:8.3f} {yoklama_sayisi / N:8.3f}")


def main():
    global iz_ac
    N_ust = 100000
    if len(sys.argv) > 2:
        print(f"kullanım: {sys.argv[0]} [N_ust (100..10000000)]",
              file=sys.stderr)
        sys.exit(2)
    if len(sys.argv) == 2:
        try:
            N_ust = int(sys.argv[1])
            if not 100 <= N_ust <= 10000000:
                raise ValueError
        except ValueError:
            print(f"kullanım: {sys.argv[0]} [N_ust (100..10000000)]",
                  file=sys.stderr)
            sys.exit(2)

    print("1) İlk 100 ekleme: m = 8'den başla, (n + 1)/m > 3/4 olacaksa "
          "m × 2")
    t = Tablo(3)
    iz_ac = True
    rastgele_tohum(42)
    while t.n < 100:
        tablo_ekle(t, rastgele_sayi())
    iz_ac = False
    print(f"  100 eklemeden sonra: m = {len(t.anahtar)}, "
          f"α = {t.n / len(t.anahtar):.3f}, toplam taşınan = "
          f"{tasinan_sayisi}")

    print("\n2) N ekleme: büyütme sayısı, taşınan toplamı, en pahalı "
          "tek ekleme")
    print("  (yazma = hücreye anahtar yazımı: ekleme 1 + büyütmede "
          "taşınanlar; yoklama = bakılan hücre)")
    print("         N  büy.    son m    taşınan  taş./N  en pahalı "
          "  (#ekl.)  yazma/N  yokl./N")
    N = 1000
    while N <= N_ust:
        deney_satiri(N)
        N *= 10
    print("  (taşınanlar geometrik dizi: 6 + 12 + … + L < 2L ≤ 2N; "
          "en pahalı tek ekleme L + 1 yazma = Θ(n))")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
# otomatik rehash (max_load_factor, rehash(), reserve()); Python — dict
# (otomatik büyür; kullanıcıya açık eşik yok).

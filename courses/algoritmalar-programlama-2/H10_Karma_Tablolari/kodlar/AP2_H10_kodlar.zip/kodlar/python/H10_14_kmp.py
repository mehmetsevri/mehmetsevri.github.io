"""H10_14_kmp.py — AP-2 Hafta 10 · Örnek 14 (★★★, merak)
Amaç    : Knuth–Morris–Pratt: önek fonksiyonu π (desenin her önekinin
          hem öneki hem soneki olan en uzun özdeş parçası); metinde geri
          gitmeden eşleme, Θ(n + m) karşılaştırma; naif ve Rabin–Karp ile
          aynı konumlar; kâhin: bytes.find döngüsü
Çalıştır: python3 H10_14_kmp.py
Eşleri  : c/H10_14_kmp.c · cpp/H10_14_kmp.cpp
Çıktı   : üç dilde aynı (=)
Not     : karşılaştırma sayısı ≤ 2n: her metin karakteri için bir başarılı
          ya da q = 0'daki karşılaştırma + q'yu azaltan (toplamda en çok
          n kez artmış olan) düşüşler
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

EN_COK = 10

karsilastirma_sayisi = 0
iz_ac = False                    # bölüm 2: her metin karakterini yaz


def esit_mi(a, b):
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return a == b


def onek_fonksiyonu(p):
    """pi[q] = p[0..q]'nun hem öneki hem soneki olan en uzun (kendisinden
    kısa) parçanın uzunluğu. Θ(m) karşılaştırma (en çok 2m)"""
    pi = [0] * len(p)
    k = 0
    for q in range(1, len(p)):
        while True:
            if esit_mi(p[k], p[q]):
                k += 1
                break
            if k == 0:
                break
            k = pi[k - 1]                # daha kısa sınıra düş
        pi[q] = k
    return pi


def kmp_ara(t, p, pi):
    """t'de p'nin tüm konumları; i hiç geri gitmez (t, p: bytes)"""
    konum = []
    m = len(p)
    q = 0                                # eşleşmiş önek uzunluğu
    for i in range(len(t)):
        q_once = q
        dusus = ""
        while True:                      # her adımda 1 karşılaştırma
            if esit_mi(p[q], t[i]):
                q += 1
                break
            if q == 0:
                break
            q = pi[q - 1]                # metinde geri gitmeden kay
            if iz_ac:
                dusus += f" -> {q}"
        if iz_ac:
            satir = f"  {i:2d}    {chr(t[i])}  {q_once:5d}{dusus:<16} {q:5d}"
        if q == m:
            konum.append(i + 1 - m)
            if iz_ac:
                satir += f"   EŞLEŞME: kayma s = {i + 1 - m}"
            q = pi[q - 1]                # çakışan eşleşmeler için
        if iz_ac:
            print(satir)
    return konum


def naif_ara(t, p):
    konum = []
    m = len(p)
    for s in range(len(t) - m + 1):
        j = 0
        while j < m and esit_mi(t[s + j], p[j]):
            j += 1
        if j == m:
            konum.append(s)
    return konum


def rk_ara(t, p):
    """Rabin–Karp (Örnek 12; d = 256, q = 1000003): yalnız konumlar için"""
    d = 256
    q = 1000003
    n = len(t)
    m = len(p)
    h = 1
    hp = 0
    ht = 0
    konum = []
    for _ in range(1, m):
        h = h * d % q
    for i in range(m):
        hp = (d * hp + p[i]) % q
        ht = (d * ht + t[i]) % q
    s = 0
    while True:
        if hp == ht and t[s:s + m] == p:
            konum.append(s)
        if s + m >= n:
            break
        ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q
        s += 1
    return konum


def kahin_ara(t, p):
    """Kâhin: bytes.find döngüsü (çakışan eşleşmeler dahil)"""
    konum = []
    q = t.find(p)
    while q != -1:
        konum.append(q)
        q = t.find(p, q + 1)
    return konum


def karsilastir(ad, t, p):
    global karsilastirma_sayisi
    karsilastirma_sayisi = 0
    pi = onek_fonksiyonu(p)
    k_pi = karsilastirma_sayisi
    karsilastirma_sayisi = 0
    k1 = kmp_ara(t, p, pi)
    k_kmp = karsilastirma_sayisi
    karsilastirma_sayisi = 0
    k2 = naif_ara(t, p)
    k_naif = karsilastirma_sayisi
    k3 = kahin_ara(t, p)
    k4 = rk_ara(t, p)
    print(f"  {ad}: n = {len(t)}, m = {len(p)}, eşleşme = {len(k1)}")
    print(f"    karşılaştırma: π = {k_pi} (≤ 2m = {2 * len(p)}), KMP = "
          f"{k_kmp} (≤ 2n = {2 * len(t)}), naif = {k_naif}")
    print("    konumlar:" + "".join(f" {x}" for x in k1[:EN_COK])
          + (" …" if len(k1) > EN_COK else ""))
    print(f"    naif ile aynı mı? {'evet' if k1 == k2 else 'HAYIR'}; "
          f"Rabin–Karp ile? {'evet' if k1 == k4 else 'HAYIR'}; kâhin "
          f"(strstr) ile? {'evet' if k1 == k3 else 'HAYIR'}")


def main():
    global iz_ac
    P = b"ababaca"
    pi = onek_fonksiyonu(P)
    print(f"1) Önek fonksiyonu: P = {P.decode()}")
    print("     q:" + "".join(f" {q + 1}" for q in range(len(P))))
    print("  P[q]:" + "".join(f" {chr(c)}" for c in P))
    print("  π[q]:" + "".join(f" {v}" for v in pi))
    print("  (ör. π[5] = 3: \"ababa\"nın hem öneki hem soneki olan en uzun "
          "parça \"aba\")")

    print("\n2) Eşleme izi: T = bacbabababacaab (q: eşleşmiş önek; ->: "
          "uyuşmazlıkta q = π[q])")
    print("   i  T[i]  q önce  düşüşler        q sonra")
    T = b"bacbabababacaab"
    iz_ac = True
    kmp_ara(T, P, pi)
    iz_ac = False

    print("\n3) Karşılaştırma sayıları: KMP, naif; kâhinle konumlar")
    karsilastir("T = bacbabababacaab", T, P)
    N = 100000
    rastgele_tohum(42)
    metin = bytes(97 + rastgele_aralik(0, 3) for _ in range(N))
    karsilastir("rastgele {a,b,c,d}, desen = metin[50000..50007]", metin,
                metin[50000:50008])
    a_n = b"a" * 10000
    karsilastir("en kötü (naif için): a^10000, a^99 b", a_n,
                b"a" * 99 + b"b")
    karsilastir("her kayma eşleşir: a^10000, a^100", a_n, b"a" * 100)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — strstr; C++ — std::string::find, std::search
# (C++17: std::boyer_moore_searcher); Python — bytes.find / str.find
# (KMP standart kütüphanelerde ayrıca sunulmaz).

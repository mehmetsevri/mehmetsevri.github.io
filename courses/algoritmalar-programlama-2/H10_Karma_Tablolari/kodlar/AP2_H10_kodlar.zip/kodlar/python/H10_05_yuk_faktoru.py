"""H10_05_yuk_faktoru.py — AP-2 Hafta 10 · Örnek 5 (★★)
Amaç    : Yük faktörü deneyi: α = 0,25 … 0,95 için ayrı zincirleme ve
          doğrusal yoklamada başarılı/başarısız aramanın ortalama
          yoklama sayısı; kuramsal değerlerle (Knuth, 1998) karşılaştırma
Çalıştır: python3 H10_05_yuk_faktoru.py [p] [tohum]     (m = 2^p,
          varsayılan p = 13, tohum = 42)
Eşleri  : c/H10_05_yuk_faktoru.c · cpp/H10_05_yuk_faktoru.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

from ortak_rastgele import rastgele_sayi, rastgele_tohum


class Dugum:
    __slots__ = ("anahtar", "sonraki")

    def __init__(self, anahtar, sonraki):
        self.anahtar = anahtar
        self.sonraki = sonraki


yoklama_sayisi = 0


def karma_carpma(k, p):
    """Çarpma yöntemi (Knuth): A = ⌊2^32 / φ⌋; indis = (k·A mod 2^32)
    >> (32 - p). Üst bitler alınır: düşük bitleri kötü anahtarlarda da
    dağıtır."""
    return ((k * 2654435769) & 0xFFFFFFFF) >> (32 - p)


# --- doğrusal yoklama: anahtar listesi + dolu bayrağı
def dy_ekle(anahtar, dolu, p, k):
    maske = (1 << p) - 1
    i = karma_carpma(k, p)
    while dolu[i]:
        if anahtar[i] == k:
            return False                     # zaten var
        i = (i + 1) & maske                  # m = 2^p: mod yerine maske
    dolu[i] = 1
    anahtar[i] = k
    return True


def dy_ara(anahtar, dolu, p, k):
    global yoklama_sayisi
    maske = (1 << p) - 1
    i = karma_carpma(k, p)
    while True:
        yoklama_sayisi += 1                  # bakılan her hücre
        if not dolu[i]:
            return False
        if anahtar[i] == k:
            return True
        i = (i + 1) & maske


# --- ayrı zincirleme: kova başları + düğümler
def zc_ekle(kova, p, k):
    j = karma_carpma(k, p)
    kova[j] = Dugum(k, kova[j])              # başa ekle


def zc_ara(kova, p, k):
    global yoklama_sayisi
    d = kova[karma_carpma(k, p)]
    while d is not None:
        yoklama_sayisi += 1                  # bakılan her düğüm
        if d.anahtar == k:
            return True
        d = d.sonraki
    return False


def sayi_oku(s, alt, ust):
    try:
        v = int(s)
    except ValueError:
        return None
    return v if alt <= v <= ust else None


def main():
    global yoklama_sayisi
    p, tohum = 13, 42
    arg = sys.argv[1:]
    if len(arg) > 0:
        p = sayi_oku(arg[0], 4, 22)
    if len(arg) > 1:
        tohum = sayi_oku(arg[1], 0, 1000000)
    if len(arg) > 2 or p is None or tohum is None:
        print(f"kullanım: {sys.argv[0]} [p (4..22)] [tohum]",
              file=sys.stderr)
        sys.exit(2)
    m = 1 << p
    alfa_yuzde = [25, 35, 45, 55, 65, 75, 85, 90, 95]
    sorgu = 4096                             # başarısız arama sayısı
    anahtar = [0] * m
    eklenen = [0] * m

    print(f"Yük faktörü deneyi: m = 2^{p} = {m}, tohum = {tohum}, "
          "karma = çarpma yöntemi (A = 2654435769)")
    print("ZS/ZB: zincirleme başarılı/başarısız; DS/DB: doğrusal yoklama")
    print("kuram: ZS = 1 + α/2, ZB = α; DS = ½(1 + 1/(1−α)), "
          "DB = ½(1 + 1/(1−α)²)")
    print(f"başarısız arama: {sorgu} anahtar (üst biti 1: tabloda "
          "olamaz)\n")
    print("     α      n  ZS ölç  ZS kur  ZB ölç  ZB kur   DS ölç   DS kur"
          "    DB ölç    DB kur")
    for yuzde in alfa_yuzde:
        n = yuzde * m // 100
        alfa = n / m
        dolu = [0] * m
        kova = [None] * m
        rastgele_tohum(tohum + yuzde)
        e = 0
        while e < n:
            k = rastgele_sayi()              # 0 .. 2^31 - 1
            if dy_ekle(anahtar, dolu, p, k):
                zc_ekle(kova, p, k)
                eklenen[e] = k
                e += 1
        olcum = [0.0] * 4
        yoklama_sayisi = 0
        for i in range(n):
            zc_ara(kova, p, eklenen[i])
        olcum[0] = yoklama_sayisi / n
        yoklama_sayisi = 0
        for i in range(n):
            dy_ara(anahtar, dolu, p, eklenen[i])
        olcum[2] = yoklama_sayisi / n
        zb = 0
        db = 0
        for _ in range(sorgu):
            k = rastgele_sayi() | 0x80000000
            yoklama_sayisi = 0
            zc_ara(kova, p, k)
            zb += yoklama_sayisi
            yoklama_sayisi = 0
            dy_ara(anahtar, dolu, p, k)
            db += yoklama_sayisi
        olcum[1] = zb / sorgu
        olcum[3] = db / sorgu
        bir_eksi = 1.0 - alfa
        print(f"  {alfa:.2f} {n:6d} {olcum[0]:7.3f} {1.0 + alfa / 2.0:7.3f} "
              f"{olcum[1]:7.3f} {alfa:7.3f} {olcum[2]:8.3f} "
              f"{0.5 * (1.0 + 1.0 / bir_eksi):8.3f} {olcum[3]:9.3f} "
              f"{0.5 * (1.0 + 1.0 / (bir_eksi * bir_eksi)):9.3f}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
# (load_factor(), max_load_factor(): varsayılan 1,0); Python — dict
# (CPython: doluluk 2/3'ü geçince büyütür).

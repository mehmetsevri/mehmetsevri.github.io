"""H10_03_ayri_zincirleme.py — AP-2 Hafta 10 · Örnek 3 (★★)
Amaç    : Ayrı zincirleme karma tablosu: m kova + bağlı düğüm listeleri
          (H8); ekle (güncelleme semantiği) / ara / sil; anahtar dizgisi
          KOPYALANIR; anahtar → karma → kova akışı, sayaçlar
Çalıştır: python3 H10_03_ayri_zincirleme.py
Eşleri  : c/H10_03_ayri_zincirleme.c ·
          cpp/H10_03_ayri_zincirleme.cpp
Çıktı   : üç dilde aynı (=)
"""


class Dugum:
    __slots__ = ("anahtar", "deger", "sonraki")

    def __init__(self, anahtar, deger, sonraki):
        self.anahtar = anahtar   # bytes: değişmez, paylaşılabilir
        self.deger = deger
        self.sonraki = sonraki


class Tablo:
    __slots__ = ("kova", "m", "n")

    def __init__(self, m):
        self.kova = [None] * m   # m kova başı; boş kova None
        self.m = m
        self.n = 0               # anahtar sayısı


karsilastirma_sayisi = 0         # anahtar karşılaştırması
ayrilan_dugum = 0
birakilan_dugum = 0


def karma_fnv1a(s):
    """FNV-1a 32 bit; s bytes (her öğe 0..255 arası tamsayı)"""
    h = 2166136261
    for b in s:
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def kova_no(t, anahtar):
    return karma_fnv1a(anahtar) % t.m


def zincirde_bul(d, anahtar):
    """Kovanın zincirinde anahtarı arar; bulunamazsa None"""
    global karsilastirma_sayisi
    while d is not None:
        karsilastirma_sayisi += 1
        if d.anahtar == anahtar:
            return d
        d = d.sonraki
    return None


def tablo_ekle(t, anahtar, deger):
    """1: yeni anahtar, 0: değer güncellendi"""
    global ayrilan_dugum
    j = kova_no(t, anahtar)
    d = zincirde_bul(t.kova[j], anahtar)
    if d is not None:
        d.deger = deger                  # güncelleme semantiği
        return 0
    t.kova[j] = Dugum(bytes(anahtar), deger, t.kova[j])  # başa: O(1)
    t.n += 1
    ayrilan_dugum += 1
    return 1


def tablo_ara(t, anahtar):
    """Bulursa değeri, yoksa None döndürür"""
    d = zincirde_bul(t.kova[kova_no(t, anahtar)], anahtar)
    return None if d is None else d.deger


def tablo_sil(t, anahtar):
    """Python'da Dugum ** yok: önceki düğümü izleyerek bağlantıyı atla"""
    global karsilastirma_sayisi, birakilan_dugum
    j = kova_no(t, anahtar)
    onceki = None
    d = t.kova[j]
    while d is not None:
        karsilastirma_sayisi += 1
        if d.anahtar == anahtar:
            if onceki is None:
                t.kova[j] = d.sonraki
            else:
                onceki.sonraki = d.sonraki
            birakilan_dugum += 1         # son başvuru gidince toplanır
            t.n -= 1
            return True
        onceki = d
        d = d.sonraki
    return False


def tablo_yaz(t):
    for j in range(t.m):
        satir = f"  kova {j}:"
        d = t.kova[j]
        while d is not None:
            satir += f" {d.anahtar.decode('utf-8')}={d.deger} ->"
            d = d.sonraki
        print(satir + " NULL")


def tablo_yok_et(t):
    """C'deki free'lerin karşılığı: başvuruları bırak (sayaçla)"""
    global birakilan_dugum
    for j in range(t.m):
        d = t.kova[j]
        while d is not None:
            birakilan_dugum += 1
            d = d.sonraki
        t.kova[j] = None
    t.n = 0


def ara_yaz(t, anahtar):
    once = karsilastirma_sayisi
    deger = tablo_ara(t, anahtar)
    a = anahtar.decode("utf-8")
    if deger is not None:
        print(f"  ara {a}: {deger} (kova {kova_no(t, anahtar)}, "
              f"karşılaştırma = {karsilastirma_sayisi - once})")
    else:
        print(f"  ara {a}: YOK (kova {kova_no(t, anahtar)}, "
              f"karşılaştırma = {karsilastirma_sayisi - once})")


def main():
    global karsilastirma_sayisi
    ad = ["ali", "ayşe", "can", "elif", "deniz", "zeynep", "mert", "ece",
          "kerem", "selin", "ömer", "ılgın"]
    not_ = [70, 85, 60, 90, 75, 95, 55, 80, 65, 88, 72, 91]
    k = 12
    t = Tablo(11)
    tampon = bytearray()         # girdi okuma tamponunun benzetimi

    print(f"1) Anahtar -> FNV-1a karma -> kova (m = {t.m})")
    for i in range(k):
        tampon[:] = ad[i].encode("utf-8")
        tablo_ekle(t, tampon, not_[i])
        h = karma_fnv1a(tampon)
        print(f"  ekle {tampon.decode('utf-8')}={not_[i]}: karma = "
              f"0x{h:08x} = {h:10d} -> kova {kova_no(t, tampon)}")
    tampon[:] = b"XXXXXXXX"
    print(f"  (tampon artık \"{tampon.decode('utf-8')}\"; tablo kendi "
          "kopyalarını tutar)")
    print(f"  n = {t.n}, m = {t.m}, α = n/m = {t.n / t.m:.3f} "
          "(zincirlemede α > 1 olabilir)")
    tablo_yaz(t)

    print("\n2) Arama (karşılaştırma = zincirde bakılan düğüm sayısı)")
    for s in ["ayşe", "ali", "ılgın", "berk"]:
        ara_yaz(t, s.encode("utf-8"))

    print("\n3) Güncelleme semantiği: var olan anahtar yeni düğüm "
          "oluşturmaz")
    sonuc = tablo_ekle(t, "ayşe".encode("utf-8"), 100)
    print(f"  ekle ayşe=100 -> {'yeni' if sonuc == 1 else 'güncellendi'}, "
          f"n = {t.n}")
    ara_yaz(t, "ayşe".encode("utf-8"))

    print("\n4) Silme (Dugum ** ile; ortadaki, baştaki, sondaki, olmayan)")
    for s in ["elif", "ılgın", "can", "berk"]:
        b = s.encode("utf-8")
        once = karsilastirma_sayisi
        var = tablo_sil(t, b)
        print(f"  sil {s}: {'silindi' if var else 'YOK'} "
              f"(kova {kova_no(t, b)}, karşılaştırma = "
              f"{karsilastirma_sayisi - once})")
    tablo_yaz(t)

    print("\n5) Ölçüler")
    en_uzun = 0
    bos = 0
    for j in range(t.m):
        u = 0
        d = t.kova[j]
        while d is not None:
            u += 1
            d = d.sonraki
        bos += u == 0
        if u > en_uzun:
            en_uzun = u
    karsilastirma_sayisi = 0
    bulunan = 0
    for i in range(k):
        bulunan += tablo_ara(t, ad[i].encode("utf-8")) is not None
    print(f"  n = {t.n}, boş kova = {bos}, en uzun zincir = {en_uzun}")
    print(f"  {k} adın {bulunan} tanesi bulundu; toplam karşılaştırma = "
          f"{karsilastirma_sayisi}")
    tablo_yok_et(t)
    print(f"  düğüm: ayrılan = {ayrilan_dugum}, serbest bırakılan = "
          f"{birakilan_dugum}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (POSIX hcreate/hsearch: silme yok,
# süreçte tek tablo); C++ — std::unordered_map<std::string, int>
# (libstdc++: kovalar + düğüm zincirleri); Python — dict (CPython: açık
# adresleme).

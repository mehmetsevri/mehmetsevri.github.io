"""H10_09_anagram_gruplama.py — AP-2 Hafta 10 · Örnek 9 (★★)
Amaç    : Anagram gruplama: anahtar tasarımı — sözcüğün baytları sayma
          sıralamasıyla (H7) sıralanır; aynı anahtar = aynı harfler.
          Zincirleme karma tablosu: anahtar → grup (üye listesi)
Çalıştır: python3 H10_09_anagram_gruplama.py \\
          < ../girdiler/H10_09_anagram_gruplama.txt
Eşleri  : c/H10_09_anagram_gruplama.c ·
          cpp/H10_09_anagram_gruplama.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

M = 31                           # kova sayısı (asal)


class Grup:
    __slots__ = ("anahtar", "uyeler", "sonraki")

    def __init__(self, anahtar, sonraki):
        self.anahtar = anahtar   # bytes (değişmez: list olamaz, HA 6)
        self.uyeler = []
        self.sonraki = sonraki   # aynı kovadaki sonraki grup


karsilastirma_sayisi = 0


def karma_fnv1a(s):
    h = 2166136261
    for b in s:
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def anahtar_yap(sozcuk):
    """Anahtar: baytların sayma sıralaması (256 sayaç; Θ(L + 256))"""
    sayac = [0] * 256
    for b in sozcuk:
        sayac[b] += 1
    anahtar = bytearray()
    for b in range(1, 256):
        anahtar += bytes([b]) * sayac[b]
    return bytes(anahtar)


def baytlar(s):
    return "".join(f" {b:02x}" for b in s)


def grupla(kova, sozcuk):
    """Sözcüğü grubuna ekler (grup yoksa oluşturur)"""
    global karsilastirma_sayisi
    anahtar = anahtar_yap(sozcuk)
    j = karma_fnv1a(anahtar) % M
    g = kova[j]
    while g is not None:
        karsilastirma_sayisi += 1
        if g.anahtar == anahtar:
            break
        g = g.sonraki
    if g is None:
        g = Grup(anahtar, kova[j])
        kova[j] = g
    g.uyeler.append(sozcuk)


def main():
    kova = [None] * M
    sozcuk_sayisi = 0

    print("1) Anahtar tasarımı: baytlar sayma sıralamasıyla sıralanır")
    for s in ["kitap", "takip", "kış"]:
        b = s.encode("utf-8")
        print(f"  {s}: bayt{baytlar(b)} -> anahtar{baytlar(anahtar_yap(b))}")
    print("  (kitap ve takip aynı anahtar: \"aikpt\"; \"kış\" anahtarında "
          "UTF-8 baytları ayrıştı:\n   anahtar yalnız eşitlik içindir, "
          "metin olarak yazdırılmaz)")

    for satir in sys.stdin.buffer.read().split(b"\n"):
        satir = satir.rstrip(b"\r")
        if not satir:
            continue
        grupla(kova, satir)
        sozcuk_sayisi += 1

    # Çıktı biçimi için sıralama (kâhin değil): üyeler ve gruplar
    gruplar = []
    tekiller = []
    for j in range(M):
        g = kova[j]
        while g is not None:
            u = sorted(g.uyeler)
            if len(u) >= 2:
                gruplar.append(u)
            else:
                tekiller.append(u[0])
            g = g.sonraki
    gruplar.sort(key=lambda u: u[0])
    tekiller.sort()

    print(f"\n2) {sozcuk_sayisi} sözcük -> anagram grupları (≥ 2 üye; "
          "gruplar ilk üyeye, üyeler bayt sırasına göre)")
    for r, u in enumerate(gruplar):
        print(f"  {r + 1:2d}. ({len(u)}) "
              + " ".join(s.decode("utf-8") for s in u))
    print(f"  tek üyeli: {len(tekiller)} sözcük: "
          + " ".join(s.decode("utf-8") for s in tekiller))
    print(f"  anahtar karşılaştırması = {karsilastirma_sayisi} (m = {M} "
          "kova)")
    print("  (bayt sırası: \"maç\" < \"çam\", çünkü 'm' = 0x6d < 0xc3 = "
          "'ç'nin ilk baytı)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle; çıktı biçimi için qsort); C++ —
# std::unordered_map<std::string, std::vector<std::string>> + std::sort;
# Python — dict + sorted(w) (anahtar: bytes(sorted(w)) ya da tuple).

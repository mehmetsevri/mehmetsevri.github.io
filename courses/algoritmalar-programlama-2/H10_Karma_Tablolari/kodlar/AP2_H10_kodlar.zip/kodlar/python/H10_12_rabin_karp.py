"""H10_12_rabin_karp.py — AP-2 Hafta 10 · Örnek 12 (★★★)
Amaç    : Rabin–Karp: kayan karma t_{s+1} = (d·(t_s − T[s]·h) + T[s+m])
          mod q, h = d^(m−1) mod q; her karma eşitliği karakter karakter
          doğrulanır; küçük asal modülle SAHTE eşleşme sayısı, büyük
          modülle; mod 2^32 işaretsiz sürüm; negatif ara değerin kalanı
Çalıştır: python3 H10_12_rabin_karp.py
Eşleri  : c/H10_12_rabin_karp.c · cpp/H10_12_rabin_karp.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

EN_COK = 8
MASKE32 = 0xFFFFFFFF


class Sonuc:
    __slots__ = ("esitlik", "gercek", "sahte", "karsilastirma", "konum")

    def __init__(self):
        self.esitlik = 0         # karma eşitliği (aday) sayısı
        self.gercek = 0          # doğrulanan eşleşme
        self.sahte = 0           # karma eşit, metin farklı
        self.karsilastirma = 0   # doğrulamadaki karakter karşılaştırması
        self.konum = []


def dogrula(t, s, p, r):
    """Aday kaymayı doğrula: karakter karakter (karşılaştırma sayılır)"""
    j = 0
    m = len(p)
    r.esitlik += 1
    while j < m:
        r.karsilastirma += 1
        if t[s + j] != p[j]:
            break
        j += 1
    if j == m:
        r.konum.append(s)
        r.gercek += 1
    else:
        r.sahte += 1                         # karma eşitliği ≠ eşleşme


def rk_ara(t, p, d, q):
    """Asal modüllü Rabin–Karp (t, p: bytes; Python tamsayısı taşmaz)"""
    r = Sonuc()
    n = len(t)
    m = len(p)
    if m == 0 or m > n:
        return r
    h = 1                                    # d^(m-1) mod q
    for _ in range(1, m):
        h = h * d % q
    hp = 0
    ht = 0
    for i in range(m):                       # Horner
        hp = (d * hp + p[i]) % q
        ht = (d * ht + t[i]) % q
    s = 0
    while True:
        if hp == ht:
            dogrula(t, s, p, r)
        if s + m >= n:
            break
        # + q gerekmez (Python'da % bölenin işaretini alır) ama C ile aynı
        # adımlar için korunur
        ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q
        s += 1
    return r


def rk_ara32(t, p, d):
    """mod 2^32 sürümü: her adımda & MASKE32 (C'deki uint32_t sarması)"""
    r = Sonuc()
    n = len(t)
    m = len(p)
    if m == 0 or m > n:
        return r
    h = 1
    for _ in range(1, m):
        h = (h * d) & MASKE32
    hp = 0
    ht = 0
    for i in range(m):
        hp = (d * hp + p[i]) & MASKE32
        ht = (d * ht + t[i]) & MASKE32
    s = 0
    while True:
        if hp == ht:
            dogrula(t, s, p, r)
        if s + m >= n:
            break
        ht = (d * (ht - t[s] * h) + t[s + m]) & MASKE32  # negatif & → mod
        s += 1
    return r


def sonuc_satiri(ad, r):
    print(f"  {r.esitlik:10d} {r.gercek:8d} {r.sahte:8d} "
          f"{r.karsilastirma:12d}  {ad}")


def karma_mod(s, d, q):
    """Tek pencerenin karması (Horner, mod q)"""
    h = 0
    for b in s:
        h = (d * h + b) % q
    return h


def naif_say(t, p):
    """Kâhin: naif arama (Örnek 11) ile eşleşme sayısı"""
    say = 0
    m = len(p)
    for s in range(len(t) - m + 1):
        j = 0
        while j < m and t[s + j] == p[j]:
            j += 1
        say += j == m
    return say


def c_kalan(x, q):
    """C/C++'taki % (sıfıra doğru kesmeli bölümün kalanı), q > 0 için"""
    r = abs(x) % q
    return -r if x < 0 else r


def main():
    # 1) Ondalık rakamlar, d = 10, q = 13 (Cormen vd., 2022, § 32.2'deki
    # örnekle aynı veri)
    T = "2359023141526739921"
    P = "31415"
    n = len(T)
    m = len(P)
    t = [ord(c) - ord("0") for c in T]
    p = [ord(c) - ord("0") for c in P]
    d = 10
    q = 13
    h = 1
    for _ in range(1, m):
        h = h * d % q
    hp = 0
    ht = 0
    for i in range(m):
        hp = (d * hp + p[i]) % q
        ht = (d * ht + t[i]) % q
    print(f"1) T = {T}, P = {P}, d = {d}, q = {q}")
    print(f"  h = d^(m−1) mod q = {h}, p = P mod q = {hp}")
    print("   s  pencere  t_s  sonuç")
    ts = [0] * n                             # bölüm 2 için t_s
    for s in range(n - m + 1):
        satir = f"  {s:2d}  {T[s:s + m]}  {ht:3d}  "
        if ht == hp:
            esit = T[s:s + m] == P
            print(satir + ("karma eşit -> doğrulandı: EŞLEŞME" if esit
                           else "karma eşit -> doğrulama: SAHTE eşleşme"))
        else:
            print(satir + "-")
        ts[s] = ht
        if s + m < n:
            ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q

    print("\n2) Negatif ara değerin kalanı (H1 Dil Penceresi): x = t_s − "
          "T[s]·h")
    print("   s  t_s  T[s]·h     x  C/C++: x % q  Python: x % q  "
          "(t_s + q − T[s]·h % q) % q")
    for s in range(6):
        x = ts[s] - t[s] * h                 # negatif olabilir
        arti_q = (ts[s] + q - t[s] * h % q) % q
        print(f"  {s:2d} {ts[s]:4d} {t[s] * h:7d} {x:5d} {c_kalan(x, q):13d} "
              f"{x % q:14d} {arti_q:28d}")
    print("  (kodda negatif ara değer oluşmaz: T[s]·h % q çıkarılmadan önce "
          "+ q eklenir)")

    # 3) Bayt metni, d = 256
    N = 100000
    rastgele_tohum(42)
    metin = bytes(97 + rastgele_aralik(0, 3) for _ in range(N))
    desen = metin[50000:50008]
    print(f"\n3) Rastgele metin n = {N} ({{a, b, c, d}}), desen m = 8 "
          f"(metin[50000..50007] = {desen.decode()})")
    print(f"  naif kâhin: {naif_say(metin, desen)} eşleşme; kayma sayısı = "
          f"{N - 8 + 1}")
    print("    eşitlik   gerçek    sahte  karşılaştır.  karma")
    sonuc_satiri("d = 256, q = 13 (küçük asal)", rk_ara(metin, desen, 256, 13))
    sonuc_satiri("d = 256, q = 1009", rk_ara(metin, desen, 256, 1009))
    sonuc_satiri("d = 256, q = 1000003", rk_ara(metin, desen, 256, 1000003))
    sonuc_satiri("d = 256, q = 2^31 − 1",
                 rk_ara(metin, desen, 256, 2147483647))
    sonuc_satiri("d = 31, mod 2^32 (uint32_t sarması)",
                 rk_ara32(metin, desen, 31))
    r = rk_ara32(metin, desen, 256)
    sonuc_satiri("d = 256, mod 2^32 (kötü: 256^4 ≡ 0)", r)
    print("  gerçek eşleşme konumları:"
          + "".join(f" {k}" for k in r.konum[:EN_COK]))
    print("  (d = 256 ve mod 2^32'de pencerenin yalnız son 4 baytı karmayı "
          "belirler)")
    print(f"  yapısal çakışma, d = 256 = 2^8, q = 2^31 − 1: h(bbdcbbbb) = "
          f"{karma_mod(b'bbdcbbbb', 256, 2147483647)}, h(aacbdddd) = "
          f"{karma_mod(b'aacbdddd', 256, 2147483647)}")
    print("  (2^31 ≡ 1 olduğundan 256^k ≡ 2^(8k mod 31): baytlar bit "
          "konumlarında üst üste biner)")

    print("\n4) En kötü durum: T = a^10000")
    print("    eşitlik   gerçek    sahte  karşılaştır.  desen, karma")
    a_n = b"a" * 10000
    sonuc_satiri("a^100, q = 1000003 (her kayma gerçek)",
                 rk_ara(a_n, b"a" * 100, 256, 1000003))
    a99n = b"a" * 99 + b"n"                  # 'n' − 'a' = 13
    sonuc_satiri("a^99 n, q = 1000003", rk_ara(a_n, a99n, 256, 1000003))
    sonuc_satiri("a^99 n, q = 13 ('n' − 'a' = 13 ≡ 0)",
                 rk_ara(a_n, a99n, 256, 13))
    print("  (her pencerede karma eşitse doğrulama Θ(n·m): Rabin–Karp'ın en "
          "kötü durumu)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — strstr; C++ — std::string::find,
# std::search; Python — bytes.find / str.find (kullandıkları arama
# algoritması gerçekleştirime bağlıdır).

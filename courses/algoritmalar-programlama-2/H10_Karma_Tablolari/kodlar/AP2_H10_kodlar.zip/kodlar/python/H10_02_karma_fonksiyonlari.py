"""H10_02_karma_fonksiyonlari.py — AP-2 Hafta 10 · Örnek 2 (★★)
Amaç    : Dizgi karma fonksiyonları: toplam (kötü), polinom (Horner,
          taban 31) ve FNV-1a (32 bit); 10 000 adın m kovaya dağılımı:
          boş kova, en uzun kova, ortalama zincir, χ² ölçütü, histogram
Çalıştır: python3 H10_02_karma_fonksiyonlari.py \\
          < ../girdiler/H10_02_karma_fonksiyonlari.txt
Eşleri  : c/H10_02_karma_fonksiyonlari.c ·
          cpp/H10_02_karma_fonksiyonlari.cpp
Çıktı   : üç dilde aynı (=)
"""
import math
import sys

F_SAYISI = 3
F_AD = ["toplam", "polinom", "FNV-1a"]
MASKE32 = 0xFFFFFFFF            # mod 2^32: C'deki uint32_t sarmasının eşi


def karma_toplam(s):
    """Toplam: baytların toplamı — harflerin SIRASINI hiç görmez (kötü)"""
    h = 0
    for b in s:
        h = (h + b) & MASKE32
    return h


def karma_polinom(s):
    """Polinom (Horner, taban 31): h = 31·h + bayt; & MASKE32 ile sarar"""
    h = 0
    for b in s:
        h = (31 * h + b) & MASKE32
    return h


def karma_fnv1a(s):
    """FNV-1a 32 bit (Fowler, Noll, Vo): önce XOR, sonra FNV asalıyla"""
    h = 2166136261                      # FNV başlangıç değeri
    for b in s:
        h ^= b
        h = (h * 16777619) & MASKE32    # FNV asalı (2^24 + 2^8 + 0x93)
    return h


def karma(f, s):
    if f == 0:
        return karma_toplam(s)
    return karma_polinom(s) if f == 1 else karma_fnv1a(s)


def olcut_satiri(f, c, n):
    """Dağılım ölçütleri: c[0..m-1] kova doluluğu, n anahtar"""
    m = len(c)
    beklenen = n / m                    # α = n / m
    bos = 0
    en_uzun = 0
    ki_kare = 0.0
    basarili = 0.0                      # Σ c(c + 1) / 2
    for j in range(m):
        bos += c[j] == 0
        if c[j] > en_uzun:
            en_uzun = c[j]
        fark = c[j] - beklenen
        ki_kare += fark * fark / beklenen
        basarili += c[j] * (c[j] + 1) / 2.0
    print(f"  {F_AD[f]:<8} {bos:8d} {en_uzun:8d} {n / (m - bos):10.3f} "
          f"{basarili / n:10.3f} {ki_kare:12.1f} {ki_kare / (m - 1):8.3f}")


def kuram_satiri(m, n):
    alfa = n / m
    bos = m * math.exp(-alfa)
    print(f"  düzgün   {bos:8.1f} {'-':>8} {n / (m - bos):10.3f} "
          f"{1.0 + alfa / 2.0:10.3f} {float(m - 1):12.1f} {1.0:8.3f}")


def histogram(c, n):
    """Histogram verisi: kaç kovada tam k anahtar var? + Poisson"""
    m = len(c[0])
    en_uzun = 0
    for f in range(F_SAYISI):
        for j in range(m):
            if c[f][j] > en_uzun:
                en_uzun = c[f][j]
    sayi = [[0] * F_SAYISI for _ in range(en_uzun + 1)]
    for f in range(F_SAYISI):
        for j in range(m):
            sayi[c[f][j]][f] += 1
    alfa = n / m
    p = math.exp(-alfa)                 # P(k) = e^-α α^k / k!
    print("     k   toplam  polinom   FNV-1a  Poisson(m·P(k))")
    for k in range(en_uzun + 1):
        if k > 0:
            p = p * alfa / k
        print(f"  {k:4d} {sayi[k][0]:8d} {sayi[k][1]:8d} {sayi[k][2]:8d} "
              f"{m * p:16.1f}")


def main():
    m_deger = [1009, 10007]             # iki asal kova sayısı
    c = [[[0] * m_deger[t] for _ in range(F_SAYISI)] for t in range(2)]
    print("1) Üç karma fonksiyonu (UTF-8 baytları, 32 bit işaretsiz)")
    print("  toplam : h = h + b                         (mod 2^32)")
    print("  polinom: h = 31·h + b (Horner)             (mod 2^32)")
    print("  FNV-1a : h = (h XOR b)·16777619, h0 = 2166136261 (mod 2^32)")
    print("      toplam     polinom      FNV-1a bayt  ad")

    n = 0
    en_az = MASKE32
    en_cok = 0
    for satir in sys.stdin.buffer.read().split(b"\n"):
        satir = satir.rstrip(b"\r")     # bytes: UTF-8 baytları
        if not satir:
            continue
        h = [karma(f, satir) for f in range(F_SAYISI)]
        for f in range(F_SAYISI):
            for t in range(2):
                c[t][f][h[f] % m_deger[t]] += 1
        if h[0] < en_az:
            en_az = h[0]
        if h[0] > en_cok:
            en_cok = h[0]
        if n < 5:
            print(f"  {h[0]:10d}  {h[1]:10d}  {h[2]:10d} {len(satir):4d}  "
                  + satir.decode("utf-8"))
        n += 1
    print(f"  ... toplam {n} ad; toplam karmanın aralığı yalnızca "
          f"[{en_az}, {en_cok}]")

    print("\n2) Toplam karmanın zayıflığı: baytların sırası önemsiz")
    for s in [b"Ali Can", b"Can Ali", b"Nil Aca", b"ali can"]:
        print(f"  toplam = {karma_toplam(s):5d}  polinom = "
              f"{karma_polinom(s):10d}  FNV-1a = {karma_fnv1a(s):10d}  "
              f"\"{s.decode('utf-8')}\"")

    print("\n3) Kovalara dağılım: indis = h mod m")
    print("  χ² = Σ (c_j − n/m)² / (n/m)   (j = 0..m−1; düzgün dağılımda "
          "≈ m − 1)")
    print("  başarılı arama ort. = Σ c_j (c_j + 1) / 2 / n   "
          "(düzgünde ≈ 1 + α/2)")
    for t in range(2):
        print(f"\n  n = {n}, m = {m_deger[t]}, α = {n / m_deger[t]:.3f}")
        print("  işlev    boş kova  en uzun  dolu/kova  başarılı "
              "          χ²  χ²/(m−1)")
        for f in range(F_SAYISI):
            olcut_satiri(f, c[t][f], n)
        kuram_satiri(m_deger[t], n)

    print(f"\n4) Histogram verisi (m = {m_deger[1]}): k anahtarlı kova "
          "sayısı")
    histogram(c[1], n)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (POSIX hsearch kendi karma fonksiyonunu
# kullanır); C++ — std::hash<std::string> (değeri gerçekleştirime
# bağlı); Python — hash(s) (SipHash ailesi, tohumlu; PEP 456,
# PYTHONHASHSEED — bkz. Dil Penceresi kavram programı).

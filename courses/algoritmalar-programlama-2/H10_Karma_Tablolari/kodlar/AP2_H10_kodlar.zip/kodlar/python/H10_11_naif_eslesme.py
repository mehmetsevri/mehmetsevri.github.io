"""H10_11_naif_eslesme.py — AP-2 Hafta 10 · Örnek 11 (★)
Amaç    : Naif (kaba kuvvet) desen eşleme: her kayma s için deseni
          soldan sağa karşılaştır; karşılaştırma sayacı; rastgele metinde
          ≈ n, en kötü durumda (aaaa…a / aa…ab) (n − m + 1)·m;
          kâhin: bytes.find döngüsü
Çalıştır: python3 H10_11_naif_eslesme.py
Eşleri  : c/H10_11_naif_eslesme.c · cpp/H10_11_naif_eslesme.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

EN_COK = 10                      # yazdırılacak en çok konum

karsilastirma_sayisi = 0


def naif_ara(t, p):
    """t içinde p'nin tüm konumları (t, p: bytes)"""
    global karsilastirma_sayisi
    konum = []
    n = len(t)
    m = len(p)
    if m == 0 or m > n:
        return konum
    for s in range(n - m + 1):               # s: kayma (shift)
        j = 0
        while j < m:
            karsilastirma_sayisi += 1
            if t[s + j] != p[j]:
                break                        # ilk uyuşmazlıkta bırak
            j += 1
        if j == m:
            konum.append(s)
    return konum


def kahin_ara(t, p):
    """Kâhin: bytes.find ile aynı konumlar (çakışan eşleşmeler dahil)"""
    konum = []
    q = t.find(p)
    while q != -1:
        konum.append(q)
        q = t.find(p, q + 1)
    return konum


def karakter_konumu(t, bayt):
    """UTF-8: devam baytları 10xxxxxx'tir; karakter = devam olmayan bayt"""
    c = 0
    for i in range(bayt):
        c += (t[i] & 0xC0) != 0x80
    return c


def sinama(ad, t, p):
    global karsilastirma_sayisi
    karsilastirma_sayisi = 0
    k1 = naif_ara(t, p)
    k2 = kahin_ara(t, p)
    kayma = len(t) - len(p) + 1
    print(f"  {ad}: n = {len(t)}, m = {len(p)}, eşleşme = {len(k1)}, "
          f"karşılaştırma = {karsilastirma_sayisi} (kayma başına "
          f"{karsilastirma_sayisi / kayma:.3f}), kâhinle aynı mı? "
          f"{'evet' if k1 == k2 else 'HAYIR'}")
    print("    konumlar:" + "".join(f" {x}" for x in k1[:EN_COK])
          + (" …" if len(k1) > EN_COK else ""))


def main():
    print("1) Küçük örnek: t = \"abracadabra\", p = \"abra\"")
    t = b"abracadabra"
    p = b"abra"
    m = len(p)
    for s in range(len(t) - m + 1):
        j = 0
        while j < m and t[s + j] == p[j]:
            j += 1
        satir = f"  s = {s}: {t[s:s + m].decode()}  "
        if j == m:
            print(satir + f"EŞLEŞME ({m} karşılaştırma)")
        else:
            print(satir + f"uyuşmazlık (j = {j}; {j + 1} karşılaştırma)")
    sinama("abracadabra", t, p)

    print("\n2) Bayt düzeyinde: konum karakter değil BAYT sayısıdır")
    tr = "Koca Ali, kılıç ustası Ali'ydi.".encode("utf-8")
    sinama("Türkçe tümce", tr, b"Ali")
    for b in naif_ara(tr, b"Ali"):
        print(f"    bayt {b:2d} = karakter {karakter_konumu(tr, b):2d}")
    print(f"    (\"kılıç\" 5 harf ama {len('kılıç'.encode('utf-8'))} bayt: "
          "ı ve ç UTF-8'de ikişer bayt)")

    print("\n3) Rastgele metin (abece {a, b, c, d}, tohum 42) ve en kötü "
          "durum")
    N = 100000
    rastgele_tohum(42)
    metin = bytes(97 + rastgele_aralik(0, 3) for _ in range(N))
    sinama("rastgele, m = 8", metin, metin[50000:50008])
    sinama("rastgele, m = 3", metin, metin[70000:70003])

    N2 = 10000
    a_n = b"a" * N2
    sinama("en kötü: a^n, a^99 b", a_n, b"a" * 99 + b"b")
    sinama("en kötü: a^n, a^100", a_n, b"a" * 100)
    print(f"  (en kötü durumda karşılaştırma = (n − m + 1)·m = "
          f"{(N2 - 100 + 1) * 100}; rastgele metinde ≈ 4/3 · kayma)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — strstr (<string.h>; algoritması
# gerçekleştirime bağlı); C++ — std::string::find, std::search
# (C++17: std::boyer_moore_searcher); Python — str.find / bytes.find,
# in işleci.

"""H10_04_dogrusal_yoklama.py — AP-2 Hafta 10 · Örnek 4 (★★★)
Amaç    : Doğrusal yoklamalı açık adresleme (m = 11): yoklama dizisi,
          birincil kümelenme; mezar taşıyla silme (arama kopmaz),
          mezar taşının yeniden kullanımı; mezar taşlarının etkisi ve
          temizleyerek yeniden kurma
Çalıştır: python3 H10_04_dogrusal_yoklama.py
Eşleri  : c/H10_04_dogrusal_yoklama.c ·
          cpp/H10_04_dogrusal_yoklama.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum

BOS, DOLU, MEZAR = 0, 1, 2


class Hucre:
    __slots__ = ("durum", "anahtar", "deger")

    def __init__(self):
        self.durum = BOS
        self.anahtar = None      # yalnız DOLU iken: bytes
        self.deger = 0


class Tablo:
    __slots__ = ("hucre", "m", "dolu", "mezar")

    def __init__(self, m):
        self.hucre = [Hucre() for _ in range(m)]
        self.m = m
        self.dolu = 0
        self.mezar = 0


yoklama_sayisi = 0               # bakılan hücre sayısı
yol = []                         # son işlemin yoklama yolu


def karma_fnv1a(s):
    h = 2166136261
    for b in s:
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def ev(t, anahtar):
    return karma_fnv1a(anahtar) % t.m


def bul(t, anahtar):
    """(indis ya da -1, yer): yer = yoldaki İLK mezar taşı, yoksa durulan
    BOŞ hücre; tablo doluysa -1. Mezar taşı aramayı DURDURMAZ."""
    global yoklama_sayisi
    i = ev(t, anahtar)
    ilk_mezar = -1
    yol.clear()
    for _ in range(t.m):
        yoklama_sayisi += 1
        if len(yol) < 64:
            yol.append(i)
        h = t.hucre[i]
        if h.durum == BOS:
            return -1, (ilk_mezar if ilk_mezar >= 0 else i)
        if h.durum == MEZAR:
            if ilk_mezar < 0:
                ilk_mezar = i
        elif h.anahtar == anahtar:
            return i, -1
        i = (i + 1) % t.m                    # doğrusal yoklama
    return -1, ilk_mezar                     # BOŞ hücre hiç yok


def tablo_ekle(t, anahtar, deger):
    """1: yeni, 0: güncellendi, -1: yer yok"""
    i, yer = bul(t, anahtar)
    if i >= 0:
        t.hucre[i].deger = deger
        return 0
    if yer < 0:
        return -1
    h = t.hucre[yer]
    if h.durum == MEZAR:
        t.mezar -= 1                         # mezar taşı yeniden kullanıldı
    h.durum = DOLU
    h.anahtar = bytes(anahtar)               # değişmez kopya
    h.deger = deger
    t.dolu += 1
    return 1


def tablo_ara(t, anahtar):
    i, _ = bul(t, anahtar)
    return None if i < 0 else t.hucre[i].deger


def tablo_sil(t, anahtar):
    """Silinen hücre BOŞ yapılmaz: MEZAR (Hata Avcısı 3)"""
    i, _ = bul(t, anahtar)
    if i < 0:
        return False
    t.hucre[i].anahtar = None
    t.hucre[i].durum = MEZAR
    t.dolu -= 1
    t.mezar += 1
    return True


def yeniden_kur(t):
    """Mezar taşlarını temizler: DOLU hücreler aynı m ile yeni listeye
    yeniden yerleştirilir (Hucre nesneleri taşınır, kopyalanmaz)"""
    eski = t.hucre
    t.hucre = [Hucre() for _ in range(t.m)]
    t.dolu = 0
    t.mezar = 0
    for h in eski:
        if h.durum == DOLU:
            _, yer = bul(t, h.anahtar)
            t.hucre[yer] = h
            t.dolu += 1


def tablo_yaz(t):
    satir = " "
    for i in range(t.m):
        h = t.hucre[i]
        if h.durum == BOS:
            satir += f" [{i} -]"
        elif h.durum == MEZAR:
            satir += f" [{i} MEZAR]"
        else:
            satir += f" [{i} {h.anahtar.decode('utf-8')}]"
    print(satir)


def yol_metni():
    return "yoklama " + " ".join(str(k) for k in yol) + f" ({len(yol)})"


def kumeleri_yaz(t):
    """BOŞ olmayan ardışık hücre öbekleri (dairesel): birincil kümelenme"""
    m = t.m
    bas = 0
    while bas < m and t.hucre[bas].durum != BOS:
        bas += 1                             # ilk BOŞ hücre
    if bas == m:
        print("  küme: tablonun tamamı (BOŞ hücre yok)")
        return
    satir = "  kümeler:"
    i = (bas + 1) % m
    adim = 0
    while adim < m:
        if t.hucre[i].durum != BOS:
            ilk = i
            uzunluk = 0
            while t.hucre[i].durum != BOS:
                uzunluk += 1
                i = (i + 1) % m
                adim += 1
            satir += f" [{ilk}..{(i + m - 1) % m}] {uzunluk} hücre;"
        i = (i + 1) % m
        adim += 1
    print(satir)


def olc_satiri(t, tur, anahtar):
    """Bölüm 4: rastgele anahtarlarla başarısız/başarılı ortalama yoklama"""
    global yoklama_sayisi
    yoklama_sayisi = 0
    for _ in range(1000):
        tablo_ara(t, f"y{rastgele_sayi()}".encode())
    basarisiz = yoklama_sayisi / 1000.0
    yoklama_sayisi = 0
    for a in anahtar:
        tablo_ara(t, a)
    basarili = yoklama_sayisi / len(anahtar)
    print(f"  {tur:>5} {t.dolu:6d} {t.mezar:6d} "
          f"{(t.dolu + t.mezar) / t.m:10.3f} {basarili:10.3f} "
          f"{basarisiz:10.3f}")


def main():
    ad = [s.encode("utf-8") for s in
          ["ali", "ayşe", "can", "elif", "deniz", "zeynep", "mert", "ece"]]
    not_ = [70, 85, 60, 90, 75, 95, 55, 80]
    t = Tablo(11)

    print("1) Ekleme: ev = FNV-1a mod 11, dolu hücrede bir sağa "
          "(i + 1) mod m")
    for k in range(8):
        tablo_ekle(t, ad[k], not_[k])
        print(f"  ekle {ad[k].decode('utf-8')}: ev {ev(t, ad[k])}, "
              f"{yol_metni()} -> hücre {yol[-1]}")
    tablo_yaz(t)
    print(f"  dolu = {t.dolu}, α = {t.dolu / t.m:.3f}")
    kumeleri_yaz(t)

    print("\n2) Mezar taşıyla silme: sil can (hücre 8 -> MEZAR)")
    tablo_sil(t, b"can")
    tablo_yaz(t)
    for s in ["ece", "mert", "umut", "can"]:
        a = s.encode("utf-8")
        deger = tablo_ara(t, a)
        satir = f"  ara {s}: ev {ev(t, a)}, {yol_metni()}"
        if deger is not None:
            print(f"{satir} -> {deger}")
        else:
            print(f"{satir} -> YOK (BOŞ hücrede durdu)")
    print("  (MEZAR aramayı durdurmaz: ece, 8'deki mezar taşını geçerek "
          "bulundu)")

    print("\n3) Mezar taşının yeniden kullanımı: ekle kerem")
    tablo_ekle(t, b"kerem", 65)
    print(f"  ekle kerem: ev {ev(t, b'kerem')}, {yol_metni()} -> hücre 8 "
          "(ilk mezar taşı; yinelenen olmasın diye BOŞ hücreye kadar "
          "arandı)")
    tablo_yaz(t)
    print(f"  dolu = {t.dolu}, mezar = {t.mezar}")

    print("\n4) Mezar taşı birikimi: m = 1024, 512 anahtar; her turda "
          "512 sil + 512 ekle")
    print("  (doluluk = (dolu + mezar) / m; ortalama yoklama: başarılı = "
          "tablodaki 512 anahtar,\n   başarısız = 1000 olmayan anahtar)")
    print("    tur   dolu  mezar   doluluk   başarılı  başarısız")
    rastgele_tohum(42)
    b = Tablo(1024)
    anahtar = [b""] * 512
    for i in range(512):
        while True:
            anahtar[i] = f"a{rastgele_sayi()}".encode()
            if tablo_ekle(b, anahtar[i], i) == 1:
                break
    olc_satiri(b, "0", anahtar)
    for tur in range(1, 7):
        for k in range(512):
            s = rastgele_aralik(0, 511)
            tablo_sil(b, anahtar[s])
            while True:
                anahtar[s] = f"a{rastgele_sayi()}".encode()
                if tablo_ekle(b, anahtar[s], k) == 1:
                    break
        olc_satiri(b, str(tur), anahtar)
    yeniden_kur(b)
    olc_satiri(b, "kurma", anahtar)
    print("  (kurma: 6. turdan sonra yeniden kurma — mezar taşları "
          "temizlendi, aynı m)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — standart kütüphanede açık
# adresleme yok (std::unordered_map libstdc++'ta zincirlemedir);
# Python — dict (CPython: açık adresleme; silinen yuva "dummy" olarak
# işaretlenir = mezar taşı).

"""H10_13_karma_saldirisi.py — AP-2 Hafta 10 · Örnek 13 (★★★)
Amaç    : Kötü karma fonksiyonuna saldırı (karma taşkını): polinom 31
          karmasında h("Aa") = h("BB"); k bloktan 2^k çakışan anahtar;
          zincirleme tabloya eklemede karşılaştırma sayısı karesel büyür
          (rastgele anahtarda doğrusal). Savunma denemeleri: ortak
          LCG'den tohumlu karma (tohumlu h0, rastgele taban — alt/üst
          bit indisi, tohumlu FNV-1a); süreler stderr'e
Çalıştır: python3 H10_13_karma_saldirisi.py [k_ust]   (n = 2^8 ..
          2^k_ust, varsayılan 10, en çok 16)
Eşleri  : c/H10_13_karma_saldirisi.c · cpp/H10_13_karma_saldirisi.cpp
Çıktı   : üç dilde aynı (=); süreler stderr'e
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum
from zamanlayici import zaman_sn

POLINOM, POLINOM_TOHUM, RASTGELE_TABAN, FNV_TOHUM = 0, 1, 2, 3
A_FIB = 2654435769               # ⌊2^32/φ⌋: üst bit indisi (Örnek 5)
MASKE32 = 0xFFFFFFFF


class Dugum:
    __slots__ = ("anahtar", "karma", "sonraki")

    def __init__(self, anahtar, karma, sonraki):
        self.anahtar = anahtar
        self.karma = karma       # büyütmede yeniden hesaplanmaz
        self.sonraki = sonraki


class Tablo:
    __slots__ = ("kova", "p", "n", "tur", "tohum", "ust_bit")

    def __init__(self, tur, tohum, ust_bit):
        self.kova = [None] * 16
        self.p = 4               # m = 2^p
        self.n = 0
        self.tur = tur           # karma fonksiyonu
        self.tohum = tohum       # gizli anahtar (saldırgan bilmez)
        self.ust_bit = ust_bit   # True: indis = (h·A) >> (32 − p)


karsilastirma_sayisi = 0


def karma_polinom(s, h, taban):
    """Polinom 31 (Java String.hashCode'un formülü; UTF-8 baytlarıyla)"""
    for b in s:
        h = (taban * h + b) & MASKE32
    return h


def karma_fnv1a(s, h):
    for b in s:
        h ^= b
        h = (h * 16777619) & MASKE32
    return h


def karma(t, s):
    if t.tur == POLINOM:
        return karma_polinom(s, 0, 31)
    if t.tur == POLINOM_TOHUM:               # tohum = başlangıç değeri
        return karma_polinom(s, t.tohum, 31)
    if t.tur == RASTGELE_TABAN:              # tohum = tek sayı taban
        return karma_polinom(s, 0, t.tohum)
    return karma_fnv1a(s, 2166136261 ^ t.tohum)   # FNV-1a, h0 XOR tohum


def indis(t, h, p):
    """Kova indisi: alt bitler (h & (m − 1)) ya da üst bitler (çarpma)"""
    if t.ust_bit:
        return ((h * A_FIB) & MASKE32) >> (32 - p)
    return h & ((1 << p) - 1)


def buyut(t):
    yeni = [None] * (2 * len(t.kova))
    for j in range(len(t.kova)):
        d = t.kova[j]
        while d is not None:
            sonraki = d.sonraki
            k = indis(t, d.karma, t.p + 1)
            d.sonraki = yeni[k]
            yeni[k] = d
            d = sonraki
    t.kova = yeni
    t.p += 1


def tablo_ekle(t, anahtar):
    """Güncelleme semantiği: önce zincirin tamamı aranır (saldırının
    hedefi)"""
    global karsilastirma_sayisi
    h = karma(t, anahtar)
    j = indis(t, h, t.p)
    d = t.kova[j]
    while d is not None:
        karsilastirma_sayisi += 1
        if d.anahtar == anahtar:
            return
        d = d.sonraki
    t.kova[j] = Dugum(anahtar, h, t.kova[j])
    t.n += 1
    if t.n > len(t.kova):
        buyut(t)


def iki_kuvveti(x):
    """x'i bölen en büyük 2 kuvvetinin üssü (x = 0 için 32)"""
    e = 0
    while e < 32 and x & 1 == 0:
        x >>= 1
        e += 1
    return e


def carpisan_anahtar(i, k):
    """i'nin k bitinden anahtar: bit 0 → "Aa", 1 → "BB" (anlamlı bit önce)"""
    return b"".join(b"BB" if (i >> (k - 1 - b)) & 1 else b"Aa"
                    for b in range(k))


def rastgele_anahtar(k):
    s = bytearray(2 * k)
    for b in range(2 * k):
        x = rastgele_aralik(0, 51)
        s[b] = 65 + x if x < 26 else 97 + x - 26
    return bytes(s)


def dene(anahtar, tur, tohum, ust_bit, etiket):
    """Anahtarları tabloya ekler; (karşılaştırma, en uzun, dolu kova, m)
    döndürür, süreyi stderr'e yazar"""
    global karsilastirma_sayisi
    t = Tablo(tur, tohum, ust_bit)
    karsilastirma_sayisi = 0
    t0 = zaman_sn()
    for a in anahtar:
        tablo_ekle(t, a)
    sure = zaman_sn() - t0
    en_uzun = 0
    dolu = 0
    for bas in t.kova:
        u = 0
        d = bas
        while d is not None:
            u += 1
            d = d.sonraki
        dolu += u > 0
        en_uzun = max(en_uzun, u)
    print(f"  [süre] n = {len(anahtar):6d} {etiket}: {sure * 1e3:.3f} ms",
          file=sys.stderr)
    return karsilastirma_sayisi, en_uzun, dolu, len(t.kova)


def main():
    k_ust = 10
    if len(sys.argv) == 2:
        try:
            k_ust = int(sys.argv[1])
        except ValueError:
            k_ust = 0
    if len(sys.argv) > 2 or not 8 <= k_ust <= 16:
        print(f"kullanım: {sys.argv[0]} [k_ust (8..16)]", file=sys.stderr)
        sys.exit(2)
    rastgele_tohum(2026)
    taban = (2 * rastgele_sayi() + 1) & MASKE32     # tek sayı: tersinir
    tohum = rastgele_sayi()
    print("1) Çakışan bloklar: polinom 31, h = 31·h + b (mod 2^32)")
    print(f"  h(\"Aa\") = 65·31 + 97 = {karma_polinom(b'Aa', 0, 31)}, "
          f"h(\"BB\") = 66·31 + 66 = {karma_polinom(b'BB', 0, 31)}")
    print("  eşit uzunluklu bloklar: h(xy) = h(x)·31^|y| + h(y) -> 2^k "
          "anahtarın karması aynı")
    for i in range(4):
        s = carpisan_anahtar(i, 4)
        print(f"  {s.decode()} -> {karma_polinom(s, 0, 31):10d}   (rastgele "
              f"taban {taban} ile: {karma_polinom(s, 0, taban):10d})")

    print("\n2) Zincirlemeli tabloya n ekleme (m = 16'dan başlar, α > 1 "
          "olunca × 2);\n   sayı = anahtar karşılaştırması (güncelleme "
          "için zincir aranır)")
    print(f"  gizli tohumlar (ortak LCG, tohum 2026): taban = {taban}, "
          f"tohum = {tohum}")
    print("  a) anahtar karşılaştırması")
    print("        n     saldırı    n(n−1)/2   rastgele    tohum h0   "
          "taban/alt  taban/üst  FNV tohum")
    sonuc = {}
    for k in range(8, k_ust + 1):
        n = 1 << k
        rastgele_tohum(42)
        anahtar = []
        rastgele = []
        for i in range(n):
            anahtar.append(carpisan_anahtar(i, k))
            rastgele.append(rastgele_anahtar(k))
        o = [dene(anahtar, POLINOM, 0, False, "saldırı (polinom 31)"),
             dene(rastgele, POLINOM, 0, False, "rastgele (polinom 31)"),
             dene(anahtar, POLINOM_TOHUM, tohum, False,
                  "saldırı, tohumlu h0"),
             dene(anahtar, RASTGELE_TABAN, taban, False,
                  "saldırı, rastgele taban/alt"),
             dene(anahtar, RASTGELE_TABAN, taban, True,
                  "saldırı, rastgele taban/üst"),
             dene(anahtar, FNV_TOHUM, tohum, False,
                  "saldırı, tohumlu FNV-1a")]
        sonuc[k] = o
        print(f"  {n:7d} {o[0][0]:11d} {n * (n - 1) // 2:11d} {o[1][0]:10d} "
              f"{o[2][0]:11d} {o[3][0]:11d} {o[4][0]:10d} {o[5][0]:10d}")
    print("  b) n × 2 olunca karşılaştırma kaç katına çıktı?")
    print("        n  saldırı  rastgele  tohum h0  taban/alt  taban/üst  "
          "FNV tohum")
    genislik = [8, 9, 9, 10, 10, 10]
    for k in range(9, k_ust + 1):
        satir = f"  {1 << k:7d}"
        for i in range(6):
            oran = sonuc[k][i][0] / sonuc[k - 1][i][0]
            satir += f" {oran:{genislik[i]}.2f}"
        print(satir)
    print("  c) dolu kova sayısı / m (en uzun zincir)")
    print("        n        m    saldırı      rastgele     taban/alt     "
          "taban/üst     FNV tohum")
    for k in range(8, k_ust + 1):
        o = sonuc[k]
        satir = f"  {1 << k:7d} {o[0][3]:8d}"
        for i in [0, 1, 3, 4, 5]:
            satir += f" {o[i][2]:6d} ({o[i][1]:5d})"
        print(satir)
    e1 = iki_kuvveti((taban - 31) & MASKE32)
    e2 = iki_kuvveti((taban * taban - 1) & MASKE32)
    print("  tohum h0 SAVUNMAZ: h0·31^L eşit uzunluklu her anahtara aynı "
          "eklenir (çakışma yapıdadır).")
    print("  taban/alt: h = h(Aa…Aa) + (taban − 31)·X, X = Σ taban^(2i) "
          "(BB bloklarının i konumlarında);")
    print(f"   taban − 31 = 2^{e1} · tek ve taban² − 1 = 2^{e2} · tek "
          f"olduğundan X ≡ BB sayısı (mod 2^{e2}):")
    print("   indisin alt bitleri yalnız BB sayısını taşır, birkaç kova "
          "dolar (tablo c) -> karesel büyüme sürer.")
    print("  taban/üst ve FNV tohum: doğrusal büyüme. Gerçek savunma: "
          "anahtarlı karma (Python: SipHash).")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
# (std::hash<std::string> gerçekleştirime bağlı; libstdc++'ta
# çalıştırmalar arasında aynı: rastgele tohum yok); Python — dict/set
# (str ve bytes karması tohumlu SipHash ailesi; PEP 456, Python 3.4+).

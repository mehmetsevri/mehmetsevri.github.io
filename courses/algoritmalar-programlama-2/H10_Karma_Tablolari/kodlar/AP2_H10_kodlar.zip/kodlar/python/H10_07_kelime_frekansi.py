"""H10_07_kelime_frekansi.py — AP-2 Hafta 10 · Örnek 7 (★★)
Amaç    : Metindeki sözcüklerin sıklığı: bayt düzeyinde sözcük ayırma,
          ASCII küçük harf dönüşümü elle (A–Z → +32), UTF-8 Türkçe harfler
          (bayt ≥ 0x80) olduğu gibi ve harf sayılır; zincirleme karma
          tablosu (α > 1 olunca × 2); en sık 20 sözcük (sıralı çıktı)
Çalıştır: python3 H10_07_kelime_frekansi.py \\
          < ../girdiler/H10_07_kelime_frekansi.txt
Eşleri  : c/H10_07_kelime_frekansi.c ·
          cpp/H10_07_kelime_frekansi.cpp
Çıktı   : üç dilde aynı (=); süre stderr'e
"""
import sys

from zamanlayici import zaman_sn


class Dugum:
    __slots__ = ("anahtar", "deger", "sonraki")

    def __init__(self, anahtar, deger, sonraki):
        self.anahtar = anahtar   # bytes
        self.deger = deger       # sıklık
        self.sonraki = sonraki


class Tablo:
    __slots__ = ("kova", "m", "n")

    def __init__(self, m):
        self.kova = [None] * m   # m: 2'nin kuvveti, indis = h & (m - 1)
        self.m = m
        self.n = 0


tasinan_dugum = 0


def karma_fnv1a(s):
    h = 2166136261
    for b in s:
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def buyut(t):
    """α > 1: kova listesi × 2; düğümler yeni kovalarına bağlanır"""
    global tasinan_dugum
    yeni_m = 2 * t.m
    yeni = [None] * yeni_m
    for j in range(t.m):
        d = t.kova[j]
        while d is not None:
            sonraki = d.sonraki
            k = karma_fnv1a(d.anahtar) & (yeni_m - 1)
            d.sonraki = yeni[k]
            yeni[k] = d
            tasinan_dugum += 1
            d = sonraki
    t.kova = yeni
    t.m = yeni_m


def say(t, sozcuk):
    """Sözcüğün sıklığını 1 artırır (yoksa 1 ile ekler)"""
    j = karma_fnv1a(sozcuk) & (t.m - 1)
    d = t.kova[j]
    while d is not None:
        if d.anahtar == sozcuk:
            d.deger += 1
            return
        d = d.sonraki
    t.kova[j] = Dugum(bytes(sozcuk), 1, t.kova[j])
    t.n += 1
    if t.n > t.m:
        buyut(t)


def harf_mi(b):
    """Harf: ASCII A–Z, a–z ya da UTF-8 çok baytlı karakterin baytı"""
    return 65 <= b <= 90 or 97 <= b <= 122 or b >= 0x80


def main():
    t0 = zaman_sn()
    metin = sys.stdin.buffer.read()          # bytes: str'ye çevrilmez
    t = Tablo(16)
    sozcuk = bytearray()
    toplam = 0
    for i in range(len(metin) + 1):
        b = metin[i] if i < len(metin) else 32
        if harf_mi(b):
            if len(sozcuk) < 255:
                sozcuk.append(b + 32 if 65 <= b <= 90 else b)
        elif sozcuk:
            say(t, sozcuk)
            toplam += 1
            sozcuk.clear()

    liste = []
    en_uzun = 0
    for j in range(t.m):
        u = 0
        d = t.kova[j]
        while d is not None:
            liste.append(d)
            u += 1
            d = d.sonraki
        en_uzun = max(en_uzun, u)
    # Çıktı biçimi için sıralama (kâhin değil): sıklık azalan, bayt artan
    liste.sort(key=lambda d: (-d.deger, d.anahtar))

    print(f"Girdi: {len(metin)} bayt; sözcük = harf baytlarının en uzun "
          "dizisi")
    print(f"toplam sözcük = {toplam}, farklı sözcük = {t.n}")
    print(f"karma tablosu: m = {t.m} kova, α = {t.n / t.m:.3f}, en uzun "
          f"zincir = {en_uzun}, büyütmede taşınan düğüm = {tasinan_dugum}")
    print("\nEn sık 20 sözcük (sıklık azalan; eşitlikte bayt sırası artan)")
    for r in range(min(20, len(liste))):
        print(f"  {r + 1:2d}. {liste[r].deger:5d}  "
              + liste[r].anahtar.decode("utf-8"))
    tr_buyuk = 0
    for d in liste:
        s = d.anahtar + b"\0"
        c3 = s[0] == 0xC3 and s[1] in (0x87, 0x96, 0x9C)    # Ç Ö Ü
        c4 = s[0] == 0xC4 and s[1] in (0x9E, 0xB0)          # Ğ İ
        c5 = s[0] == 0xC5 and s[1] == 0x9E                  # Ş
        tr_buyuk += c3 or c4 or c5
    print(f"\nTürkçe büyük harfle (Ç Ğ İ Ö Ş Ü) başlayan farklı sözcük: "
          f"{tr_buyuk} (ASCII dışı harfler küçültülmedi)")
    print(f"süre (okuma + sayma + sıralama): {(zaman_sn() - t0) * 1e3:.3f} "
          "ms", file=sys.stderr)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle; sıralama için qsort çıktı
# biçimidir); C++ — std::unordered_map<std::string, int> + std::sort;
# Python — collections.Counter(...).most_common(20) ya da dict.

"""H10_10_dogum_gunu.py — AP-2 Hafta 10 · Örnek 10 (★★)
Amaç    : Doğum günü paradoksu: n kişide en az bir ortak doğum günü
          olasılığı (kesin formül, n = 1..60; 23 kişide ≈ 0,507), ortak
          LCG ile Monte Carlo karşılaştırması; karma bağlantısı: m kovaya
          ilk çakışmaya kadar beklenen anahtar sayısı, %50 eşiği
Çalıştır: python3 H10_10_dogum_gunu.py
Eşleri  : c/H10_10_dogum_gunu.c · cpp/H10_10_dogum_gunu.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_aralik, rastgele_tohum

GUN = 365
DENEME = 5000


def kesin_tablo(n_ust, m):
    """P(n) = 1 − Π_{k=0}^{n-1} (m − k)/m ; çarpım soldan sağa"""
    p = [0.0] * (n_ust + 1)
    q = 1.0                                  # çakışma yok olasılığı
    for n in range(1, n_ust + 1):
        q = q * ((m - (n - 1)) / m)          # int / int: double bölme
        p[n] = 1.0 - q
    return p


def deneme_yap(n, gorulen, damga):
    """Bir deneme: n doğum günü çek; ilk tekrar görülürse True. gorulen =
    doğrudan adresleme; damga = deneme numarası (listeyi sıfırlamadan)"""
    for _ in range(n):
        g = rastgele_aralik(0, GUN - 1)
        if gorulen[g] == damga:
            return True
        gorulen[g] = damga
    return False


def esik_satiri(ad, m):
    """m kova: %50 eşiğini geçen en küçük n ve ilk çakışmanın beklenen
    sırası E = Σ_{k≥0} P(ilk k anahtarda çakışma yok)"""
    q = 1.0
    beklenen = 1.0                           # k = 0 terimi
    esik = 0
    k = 1
    while k <= m and q > 1e-18:
        beklenen += q                        # q = P(ilk k'da yok)
        q = q * ((m - k) / m)
        if esik == 0 and 1.0 - q >= 0.5:
            esik = k + 1
        k += 1
    print(f"  {m:14d} {esik:10d} {beklenen:12.3f} "
          f"{math.sqrt(3.14159265358979323846 * m / 2.0):12.3f}   {ad}")


def main():
    p = kesin_tablo(60, GUN)

    print("1) Kesin olasılık: P(n) = 1 − (365/365)(364/365)…((365−n+1)/365)")
    for r in range(1, 21):
        print(f"  n = {r:2d}: {p[r]:.6f}   n = {r + 20:2d}: {p[r + 20]:.6f}"
              f"   n = {r + 40:2d}: {p[r + 40]:.6f}")
    esik = 1
    while p[esik] < 0.5:
        esik += 1
    print(f"  P ≥ 0,5 olan en küçük n = {esik} (P = {p[esik]:.4f}); "
          f"n = 57'de {p[57]:.4f}")

    print(f"\n2) Monte Carlo (ortak LCG, tohum 42, {DENEME} deneme / satır)")
    print("     n   kesin   tahmin    fark")
    gorulen = [0] * GUN
    rastgele_tohum(42)
    damga = 0
    for n in [10, 20, 23, 30, 40, 50, 60]:
        cakisan = 0
        for _ in range(DENEME):
            damga += 1
            cakisan += deneme_yap(n, gorulen, damga)
        tahmin = cakisan / DENEME
        print(f"  {n:4d} {p[n]:7.4f} {tahmin:8.4f} {tahmin - p[n]:+7.4f}")

    print("\n3) Karma bağlantısı: m kova, düzgün karma — ilk çakışma ne "
          "zaman?")
    print("               m   %50 eşiği  E[ilk çakışma]  √(πm/2)   yorum")
    esik_satiri("yılın günleri", 365)
    esik_satiri("bin kovalı tablo", 1000)
    esik_satiri("milyon kovalı tablo", 1000000)
    esik_satiri("32 bit karma değerleri", 4294967296)
    toplam = 0
    for _ in range(DENEME):
        damga += 1
        k = 0
        while True:
            g = rastgele_aralik(0, GUN - 1)
            k += 1
            if gorulen[g] == damga:
                break
            gorulen[g] = damga
        toplam += k
    print(f"  m = 365, Monte Carlo: ilk çakışmanın ortalama sırası = "
          f"{toplam / DENEME:.3f} ({DENEME} deneme)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — yok (std::unordered_set
# ile görülen günler tutulabilir); Python — set (ya da
# math.prod / math.perm ile kesin formül).

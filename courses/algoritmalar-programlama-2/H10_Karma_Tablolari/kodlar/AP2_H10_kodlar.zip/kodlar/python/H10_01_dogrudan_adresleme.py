"""H10_01_dogrudan_adresleme.py — AP-2 Hafta 10 · Örnek 1 (★)
Amaç    : Doğrudan adresleme: anahtar = indis (0–99 numaralı öğrenci
          tablosu); ekle/ara/sil tek erişimde; anahtar evreni büyüyünce
          bellek hesabı ve karma fonksiyonuna köprü (k mod 101)
Çalıştır: python3 H10_01_dogrudan_adresleme.py
Eşleri  : c/H10_01_dogrudan_adresleme.c ·
          cpp/H10_01_dogrudan_adresleme.cpp
Çıktı   : üç dilde aynı (=)
"""

EVREN = 100          # anahtar evreni: 0 .. 99
HUCRE_BAYT = 8       # bir hücre = bir işaretçi (x86-64 LP64)

erisim_sayisi = 0

# Hücre None ise boştur; dolu hücre adı (str nesnesine başvuru) tutar
tablo = [None] * EVREN


def gecerli_mi(no):
    return 0 <= no < EVREN


def ekle(no, ad):
    global erisim_sayisi
    erisim_sayisi += 1
    tablo[no] = ad               # anahtar = indis: arama yok


def ara(no):
    global erisim_sayisi
    erisim_sayisi += 1
    return tablo[no]


def sil(no):
    global erisim_sayisi
    erisim_sayisi += 1
    tablo[no] = None


def tablo_ciz():
    print("     " + "".join(f" {s:2d}" for s in range(10)))
    for r in range(10):
        satir = f"  {r}0 "
        for s in range(10):
            no = 10 * r + s
            if tablo[no] is None:
                satir += " --"
            else:
                satir += f" {no:02d}"
        print(satir)


def sorgula(no):
    if not gecerli_mi(no):
        print(f"  ara({no}): geçersiz anahtar (evren 0..{EVREN - 1})")
        return
    once = erisim_sayisi
    ad = ara(no)
    print(f"  ara({no}): {ad if ad is not None else 'boş'}  "
          f"[erişim = {erisim_sayisi - once}]")


def bellek_satiri(aciklama, evren, kayit):
    bayt = evren * HUCRE_BAYT
    doluluk = 100.0 * kayit / evren
    print(f"  {evren:14d} {kayit:6d} {bayt:16d} {bayt / 1e9:12.3f} "
          f"{doluluk:12.6f}  {aciklama}")


def main():
    numara = [7, 23, 42, 64, 99, 0]
    ad = ["Ayşe Yılmaz", "Mehmet Kaya", "Zeynep Demir", "Ali Çelik",
          "Elif Şahin", "Can Öztürk"]
    k = 6

    print("1) Doğrudan adresleme: 0..99 numaralı öğrenciler, "
          "anahtar = indis")
    for i in range(k):
        ekle(numara[i], ad[i])
        print(f"  ekle({numara[i]}, \"{ad[i]}\") -> tablo[{numara[i]}]")
    print("\n  Tablo (100 hücre; \"--\" boş, sayı = dolu hücrenin "
          "numarası)")
    tablo_ciz()

    print("\n2) Arama ve silme: her işlem tek erişim, Θ(1)")
    sorgula(42)
    sorgula(50)
    sil(42)
    print("  sil(42)")
    sorgula(42)
    sorgula(150)
    print(f"  toplam erişim: {erisim_sayisi} ({k} ekleme + 3 arama + "
          "1 silme; ara(150) tabloya erişmez)")
    dolu = 0
    for no in range(EVREN):
        dolu += tablo[no] is not None
    print(f"  dolu hücre: {dolu} / {EVREN}")

    print(f"\n3) Anahtar evreni büyüyünce bellek (hücre = {HUCRE_BAYT} "
          "bayt)")
    print("         evren U  kayıt    bellek (bayt)  bellek (GB)  "
          "doluluk (%)  anahtar")
    bellek_satiri("sınıf sıra no (0..99)", 100, dolu)
    bellek_satiri("4 haneli no (0..9999)", 10000, 5000)
    bellek_satiri("9 haneli öğrenci no", 1000000000, 5000)
    bellek_satiri("32 bit tamsayı (2^32)", 4294967296, 5000)

    print("\n4) Köprü: 9 haneli numara -> h(k) = k mod 101 (101 hücre)")
    uzun_no = [240101007, 240101023, 240101042, 240101064, 240101099,
               240101108]
    for i in range(k):
        print(f"  {uzun_no[i]} mod 101 = {uzun_no[i] % 101:3d}")
    print("  (çakışma: farklı anahtarlar aynı hücreye düşebilir -> "
          "Örnek 3, 4)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (dizi; tamsayı anahtarlı küçük evrende
# doğrudan adresleme); C++ — std::array/std::vector (anahtar = indis);
# Python — liste [None] * 100 (anahtar = indis).

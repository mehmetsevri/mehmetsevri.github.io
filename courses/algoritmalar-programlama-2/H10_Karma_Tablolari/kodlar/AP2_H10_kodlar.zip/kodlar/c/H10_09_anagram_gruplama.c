/* H10_09_anagram_gruplama.c — AP-2 Hafta 10 · Örnek 9 (★★)
 * Amaç    : Anagram gruplama: anahtar tasarımı — sözcüğün baytları sayma
 *           sıralamasıyla (H7) sıralanır; aynı anahtar = aynı harfler.
 *           Zincirleme karma tablosu: anahtar → grup (üye listesi)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_09_anagram_gruplama.c -o H10_09_anagram_gruplama
 * Çalıştır: ./H10_09_anagram_gruplama \
 *           < ../girdiler/H10_09_anagram_gruplama.txt
 * Eşleri  : cpp/H10_09_anagram_gruplama.cpp ·
 *           python/H10_09_anagram_gruplama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define M 31                     /* kova sayısı (asal) */
#define EN_COK 64                /* sözcük başına en çok bayt */

typedef struct Uye {
    char *metin;                 /* sahiplik: düğümündür */
    struct Uye *sonraki;
} Uye;

typedef struct Grup {
    char *anahtar;               /* sıralanmış baytlar (kopya) */
    Uye *uyeler;
    int boyut;
    struct Grup *sonraki;        /* aynı kovadaki sonraki grup */
} Grup;

static long long karsilastirma_sayisi = 0;

static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

static char *dizgi_kopyala(const char *s)
{
    size_t uzunluk = strlen(s) + 1;
    char *kopya = malloc(uzunluk);
    if (kopya != NULL) {
        memcpy(kopya, s, uzunluk);
    }
    return kopya;
}

/* Anahtar: baytların sayma sıralaması (256 sayaç; Θ(L + 256)) */
static void anahtar_yap(const char *sozcuk, char *anahtar)
{
    int sayac[256] = {0};
    for (const char *s = sozcuk; *s != '\0'; s++) {
        sayac[(unsigned char)*s]++;
    }
    size_t k = 0;
    for (int b = 1; b < 256; b++) {
        for (int c = 0; c < sayac[b]; c++) {
            anahtar[k++] = (char)b;
        }
    }
    anahtar[k] = '\0';
}

static void baytlari_yaz(const char *s)
{
    for (; *s != '\0'; s++) {
        printf(" %02x", (unsigned char)*s);
    }
}

/* Sözcüğü grubuna ekler (grup yoksa oluşturur). -1: bellek */
static int grupla(Grup **kova, const char *sozcuk)
{
    char anahtar[EN_COK + 1];
    anahtar_yap(sozcuk, anahtar);
    size_t j = karma_fnv1a(anahtar) % M;
    Grup *g = kova[j];
    while (g != NULL) {
        karsilastirma_sayisi++;
        if (strcmp(g->anahtar, anahtar) == 0) {
            break;
        }
        g = g->sonraki;
    }
    if (g == NULL) {
        g = malloc(sizeof *g);
        if (g == NULL) {
            return -1;
        }
        g->anahtar = dizgi_kopyala(anahtar);
        g->uyeler = NULL;
        g->boyut = 0;
        g->sonraki = kova[j];
        kova[j] = g;
        if (g->anahtar == NULL) {
            return -1;
        }
    }
    Uye *u = malloc(sizeof *u);
    if (u == NULL) {
        return -1;
    }
    u->metin = dizgi_kopyala(sozcuk);
    u->sonraki = g->uyeler;
    g->uyeler = u;
    g->boyut++;
    return u->metin == NULL ? -1 : 0;
}

static int dizgi_sirasi(const void *a, const void *b)
{
    return strcmp(*(const char *const *)a, *(const char *const *)b);
}

/* Çıktı biçimi için: grup üyelerini bayt sırasıyla diziye alır */
static void uyeleri_sirala(const Grup *g, const char **dizi)
{
    int k = 0;
    for (const Uye *u = g->uyeler; u != NULL; u = u->sonraki) {
        dizi[k++] = u->metin;
    }
    qsort(dizi, (size_t)g->boyut, sizeof *dizi, dizgi_sirasi);
}

typedef struct {
    const Grup *g;
    const char *ilk;             /* sıralı üyelerin ilki */
} Satir;

static int satir_sirasi(const void *a, const void *b)
{
    return strcmp(((const Satir *)a)->ilk, ((const Satir *)b)->ilk);
}

static void kova_yok_et(Grup **kova)
{
    for (int j = 0; j < M; j++) {
        Grup *g = kova[j];
        while (g != NULL) {
            Grup *gs = g->sonraki;
            Uye *u = g->uyeler;
            while (u != NULL) {
                Uye *us = u->sonraki;
                free(u->metin);
                free(u);
                u = us;
            }
            free(g->anahtar);
            free(g);
            g = gs;
        }
        kova[j] = NULL;
    }
}

int main(void)
{
    Grup *kova[M] = {NULL};
    char satir[EN_COK + 2];
    int sozcuk_sayisi = 0;

    printf("1) Anahtar tasarımı: baytlar sayma sıralamasıyla sıralanır\n");
    const char *ornek[3] = {"kitap", "takip", "kış"};
    for (int i = 0; i < 3; i++) {
        char a[EN_COK + 1];
        anahtar_yap(ornek[i], a);
        printf("  %s: bayt", ornek[i]);
        baytlari_yaz(ornek[i]);
        printf(" -> anahtar");
        baytlari_yaz(a);
        printf("\n");
    }
    printf("  (kitap ve takip aynı anahtar: \"aikpt\"; \"kış\" anahtarında "
           "UTF-8 baytları ayrıştı:\n   anahtar yalnız eşitlik içindir, "
           "metin olarak yazdırılmaz)\n");

    while (fgets(satir, sizeof satir, stdin) != NULL) {
        satir[strcspn(satir, "\r\n")] = '\0';
        if (satir[0] == '\0') {
            continue;
        }
        if (grupla(kova, satir) != 0) {
            kova_yok_et(kova);
            return 1;
        }
        sozcuk_sayisi++;
    }

    int grup_sayisi = 0;
    int tekil = 0;
    for (int j = 0; j < M; j++) {
        for (const Grup *g = kova[j]; g != NULL; g = g->sonraki) {
            grup_sayisi += g->boyut >= 2;
            tekil += g->boyut == 1;
        }
    }
    Satir *liste = malloc((size_t)(grup_sayisi + 1) * sizeof *liste);
    const char **dizi = malloc((size_t)(sozcuk_sayisi + 1) * sizeof *dizi);
    if (liste == NULL || dizi == NULL) {
        return 1;
    }
    int r = 0;
    for (int j = 0; j < M; j++) {
        for (const Grup *g = kova[j]; g != NULL; g = g->sonraki) {
            if (g->boyut >= 2) {
                uyeleri_sirala(g, dizi);
                liste[r].g = g;
                liste[r].ilk = dizi[0];
                r++;
            }
        }
    }
    qsort(liste, (size_t)grup_sayisi, sizeof *liste, satir_sirasi);

    printf("\n2) %d sözcük -> anagram grupları (≥ 2 üye; gruplar ilk üyeye, "
           "üyeler bayt sırasına göre)\n", sozcuk_sayisi);
    for (r = 0; r < grup_sayisi; r++) {
        uyeleri_sirala(liste[r].g, dizi);
        printf("  %2d. (%d)", r + 1, liste[r].g->boyut);
        for (int k = 0; k < liste[r].g->boyut; k++) {
            printf(" %s", dizi[k]);
        }
        printf("\n");
    }
    int k = 0;
    for (int j = 0; j < M; j++) {
        for (const Grup *g = kova[j]; g != NULL; g = g->sonraki) {
            if (g->boyut == 1) {
                dizi[k++] = g->uyeler->metin;
            }
        }
    }
    qsort(dizi, (size_t)k, sizeof *dizi, dizgi_sirasi);
    printf("  tek üyeli: %d sözcük:", tekil);
    for (int i = 0; i < k; i++) {
        printf(" %s", dizi[i]);
    }
    printf("\n");
    free(liste);
    free(dizi);
    printf("  anahtar karşılaştırması = %lld (m = %d kova)\n",
           karsilastirma_sayisi, M);
    printf("  (bayt sırası: \"maç\" < \"çam\", çünkü 'm' = 0x6d < 0xc3 = "
           "'ç'nin ilk baytı)\n");
    kova_yok_et(kova);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; çıktı biçimi için qsort); C++ —
 * std::unordered_map<std::string, std::vector<std::string>> + std::sort;
 * Python — dict + sorted(w) (anahtar: bytes(sorted(w)) ya da tuple). */

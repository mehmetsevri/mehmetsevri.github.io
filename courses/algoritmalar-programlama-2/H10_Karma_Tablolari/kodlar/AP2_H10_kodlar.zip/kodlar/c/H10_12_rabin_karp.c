/* H10_12_rabin_karp.c — AP-2 Hafta 10 · Örnek 12 (★★★)
 * Amaç    : Rabin–Karp: kayan karma t_{s+1} = (d·(t_s − T[s]·h) + T[s+m])
 *           mod q, h = d^(m−1) mod q; her karma eşitliği karakter karakter
 *           doğrulanır; küçük asal modülle SAHTE eşleşme sayısı, büyük
 *           modülle; mod 2^32 işaretsiz sürüm; negatif ara değerin kalanı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_12_rabin_karp.c ortak_rastgele.c -o H10_12_rabin_karp
 * Çalıştır: ./H10_12_rabin_karp
 * Eşleri  : cpp/H10_12_rabin_karp.cpp · python/H10_12_rabin_karp.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define EN_COK 8

typedef struct {
    long long esitlik;           /* karma eşitliği (aday) sayısı */
    long long gercek;            /* doğrulanan eşleşme */
    long long sahte;             /* karma eşit, metin farklı */
    long long karsilastirma;     /* doğrulamadaki karakter karşılaştırması */
    size_t konum[EN_COK];
} Sonuc;

/* Aday kaymayı doğrula: karakter karakter (karşılaştırma sayılır) */
static void dogrula(const unsigned char *t, size_t s, const unsigned char *p,
                    size_t m, Sonuc *r)
{
    size_t j = 0;
    r->esitlik++;
    while (j < m) {
        r->karsilastirma++;
        if (t[s + j] != p[j]) {
            break;
        }
        j++;
    }
    if (j == m) {
        if (r->gercek < EN_COK) {
            r->konum[r->gercek] = s;
        }
        r->gercek++;
    } else {
        r->sahte++;                          /* karma eşitliği ≠ eşleşme */
    }
}

/* Asal modüllü Rabin–Karp (q < 2^31: ara değerler long long'a sığar) */
static void rk_ara(const unsigned char *t, size_t n, const unsigned char *p,
                   size_t m, long long d, long long q, Sonuc *r)
{
    memset(r, 0, sizeof *r);
    if (m == 0 || m > n) {
        return;
    }
    long long h = 1;                         /* d^(m-1) mod q */
    for (size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    long long hp = 0;
    long long ht = 0;
    for (size_t i = 0; i < m; i++) {         /* Horner */
        hp = (d * hp + p[i]) % q;
        ht = (d * ht + t[i]) % q;
    }
    for (size_t s = 0;; s++) {
        if (hp == ht) {
            dogrula(t, s, p, m, r);
        }
        if (s + m >= n) {
            break;
        }
        /* + q: C'de % bölünenin işaretini alır; ara değer negatif olmasın */
        ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q;
    }
}

/* mod 2^32 sürümü: uint32_t aritmetiği kendiliğinden sarar (tanımlı) */
static void rk_ara32(const unsigned char *t, size_t n,
                     const unsigned char *p, size_t m, uint32_t d,
                     Sonuc *r)
{
    memset(r, 0, sizeof *r);
    if (m == 0 || m > n) {
        return;
    }
    uint32_t h = 1;
    for (size_t i = 1; i < m; i++) {
        h *= d;
    }
    uint32_t hp = 0;
    uint32_t ht = 0;
    for (size_t i = 0; i < m; i++) {
        hp = d * hp + p[i];
        ht = d * ht + t[i];
    }
    for (size_t s = 0;; s++) {
        if (hp == ht) {
            dogrula(t, s, p, m, r);
        }
        if (s + m >= n) {
            break;
        }
        ht = d * (ht - t[s] * h) + t[s + m];   /* negatif yok: mod 2^32 */
    }
}

static void sonuc_satiri(const char *ad, const Sonuc *r)
{
    printf("  %10lld %8lld %8lld %12lld  %s\n", r->esitlik, r->gercek,
           r->sahte, r->karsilastirma, ad);
}

/* Tek pencerenin karması (Horner, mod q) */
static long long karma_mod(const char *s, size_t m, long long d, long long q)
{
    long long h = 0;
    for (size_t i = 0; i < m; i++) {
        h = (d * h + (unsigned char)s[i]) % q;
    }
    return h;
}

/* Kâhin: naif arama (Örnek 11) ile konumlar */
static long long naif_say(const unsigned char *t, size_t n,
                          const unsigned char *p, size_t m)
{
    long long say = 0;
    for (size_t s = 0; s + m <= n; s++) {
        size_t j = 0;
        while (j < m && t[s + j] == p[j]) {
            j++;
        }
        say += j == m;
    }
    return say;
}

int main(void)
{
    /* 1) Ondalık rakamlar, d = 10, q = 13 (Cormen vd., 2022, § 32.2'deki
     * örnekle aynı veri) */
    const char *T = "2359023141526739921";
    const char *P = "31415";
    size_t n = strlen(T);
    size_t m = strlen(P);
    unsigned char t[32];
    unsigned char p[8];
    for (size_t i = 0; i < n; i++) {
        t[i] = (unsigned char)(T[i] - '0');
    }
    for (size_t i = 0; i < m; i++) {
        p[i] = (unsigned char)(P[i] - '0');
    }
    const long long d = 10;
    const long long q = 13;
    long long h = 1;
    for (size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    long long hp = 0;
    long long ht = 0;
    for (size_t i = 0; i < m; i++) {
        hp = (d * hp + p[i]) % q;
        ht = (d * ht + t[i]) % q;
    }
    printf("1) T = %s, P = %s, d = %lld, q = %lld\n", T, P, d, q);
    printf("  h = d^(m−1) mod q = %lld, p = P mod q = %lld\n", h, hp);
    printf("   s  pencere  t_s  sonuç\n");
    long long ts[16];                        /* bölüm 2 için t_s */
    for (size_t s = 0; s + m <= n; s++) {
        printf("  %2zu  %.*s  %3lld  ", s, (int)m, T + s, ht);
        if (ht == hp) {
            int esit = memcmp(T + s, P, m) == 0;
            printf("%s\n", esit ? "karma eşit -> doğrulandı: EŞLEŞME"
                                : "karma eşit -> doğrulama: SAHTE eşleşme");
        } else {
            printf("-\n");
        }
        ts[s] = ht;
        if (s + m < n) {
            ht = (d * (ht + q - t[s] * h % q) + t[s + m]) % q;
        }
    }

    printf("\n2) Negatif ara değerin kalanı (H1 Dil Penceresi): x = t_s − "
           "T[s]·h\n");
    printf("   s  t_s  T[s]·h     x  C/C++: x %% q  Python: x %% q  "
           "(t_s + q − T[s]·h %% q) %% q\n");
    for (size_t s = 0; s < 6; s++) {
        long long x = ts[s] - t[s] * h;      /* negatif olabilir */
        long long c_kalan = x % q;           /* C: sıfıra doğru kesme */
        long long taban_kalan = (x % q + q) % q;   /* Python'un % kuralı */
        long long arti_q = (ts[s] + q - t[s] * h % q) % q;
        printf("  %2zu %4lld %7lld %5lld %13lld %14lld %28lld\n", s, ts[s],
               t[s] * h, x, c_kalan, taban_kalan, arti_q);
    }
    printf("  (kodda negatif ara değer oluşmaz: T[s]·h %% q çıkarılmadan "
           "önce + q eklenir)\n");

    /* 3) Bayt metni, d = 256 */
    size_t N = 100000;
    unsigned char *metin = malloc(N);
    if (metin == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    for (size_t i = 0; i < N; i++) {
        metin[i] = (unsigned char)('a' + rastgele_aralik(0, 3));
    }
    unsigned char desen[8];
    memcpy(desen, metin + 50000, 8);
    printf("\n3) Rastgele metin n = %zu ({a, b, c, d}), desen m = 8 "
           "(metin[50000..50007] = %.8s)\n", N, (const char *)desen);
    printf("  naif kâhin: %lld eşleşme; kayma sayısı = %zu\n",
           naif_say(metin, N, desen, 8), N - 8 + 1);
    printf("    eşitlik   gerçek    sahte  karşılaştır.  karma\n");
    Sonuc r;
    rk_ara(metin, N, desen, 8, 256, 13, &r);
    sonuc_satiri("d = 256, q = 13 (küçük asal)", &r);
    rk_ara(metin, N, desen, 8, 256, 1009, &r);
    sonuc_satiri("d = 256, q = 1009", &r);
    rk_ara(metin, N, desen, 8, 256, 1000003, &r);
    sonuc_satiri("d = 256, q = 1000003", &r);
    rk_ara(metin, N, desen, 8, 256, 2147483647, &r);
    sonuc_satiri("d = 256, q = 2^31 − 1", &r);
    rk_ara32(metin, N, desen, 8, 31u, &r);
    sonuc_satiri("d = 31, mod 2^32 (uint32_t sarması)", &r);
    rk_ara32(metin, N, desen, 8, 256u, &r);
    sonuc_satiri("d = 256, mod 2^32 (kötü: 256^4 ≡ 0)", &r);
    printf("  gerçek eşleşme konumları:");
    for (long long i = 0; i < r.gercek && i < EN_COK; i++) {
        printf(" %zu", r.konum[i]);
    }
    printf("\n  (d = 256 ve mod 2^32'de pencerenin yalnız son 4 baytı karmayı "
           "belirler)\n");
    printf("  yapısal çakışma, d = 256 = 2^8, q = 2^31 − 1: h(bbdcbbbb) = "
           "%lld, h(aacbdddd) = %lld\n", karma_mod("bbdcbbbb", 8, 256,
           2147483647), karma_mod("aacbdddd", 8, 256, 2147483647));
    printf("  (2^31 ≡ 1 olduğundan 256^k ≡ 2^(8k mod 31): baytlar bit "
           "konumlarında üst üste biner)\n");

    printf("\n4) En kötü durum: T = a^10000\n");
    printf("    eşitlik   gerçek    sahte  karşılaştır.  desen, karma\n");
    memset(metin, 'a', 10000);
    unsigned char a100[100];
    memset(a100, 'a', 100);
    rk_ara(metin, 10000, a100, 100, 256, 1000003, &r);
    sonuc_satiri("a^100, q = 1000003 (her kayma gerçek)", &r);
    a100[99] = 'n';                          /* 'n' − 'a' = 13 */
    rk_ara(metin, 10000, a100, 100, 256, 1000003, &r);
    sonuc_satiri("a^99 n, q = 1000003", &r);
    rk_ara(metin, 10000, a100, 100, 256, 13, &r);
    sonuc_satiri("a^99 n, q = 13 ('n' − 'a' = 13 ≡ 0)", &r);
    printf("  (her pencerede karma eşitse doğrulama Θ(n·m): Rabin–Karp'ın "
           "en kötü durumu)\n");
    free(metin);
    return 0;
}

/* Kütüphane karşılığı: C — strstr; C++ — std::string::find,
 * std::search; Python — bytes.find / str.find (kullandıkları arama
 * algoritması gerçekleştirime bağlıdır). */

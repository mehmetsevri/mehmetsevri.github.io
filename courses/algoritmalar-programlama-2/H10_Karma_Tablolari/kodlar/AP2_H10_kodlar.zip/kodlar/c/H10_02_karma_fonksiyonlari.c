/* H10_02_karma_fonksiyonlari.c — AP-2 Hafta 10 · Örnek 2 (★★)
 * Amaç    : Dizgi karma fonksiyonları: toplam (kötü), polinom (Horner,
 *           taban 31) ve FNV-1a (32 bit); 10 000 adın m kovaya dağılımı:
 *           boş kova, en uzun kova, ortalama zincir, χ² ölçütü, histogram
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_02_karma_fonksiyonlari.c -o H10_02_karma_fonksiyonlari -lm
 * Çalıştır: ./H10_02_karma_fonksiyonlari \
 *           < ../girdiler/H10_02_karma_fonksiyonlari.txt
 * Eşleri  : cpp/H10_02_karma_fonksiyonlari.cpp ·
 *           python/H10_02_karma_fonksiyonlari.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define F_SAYISI 3

static const char *F_AD[F_SAYISI] = {"toplam", "polinom", "FNV-1a"};

/* Toplam: baytların toplamı — harflerin SIRASINI hiç görmez (kötü) */
static uint32_t karma_toplam(const char *s)
{
    uint32_t h = 0;
    for (; *s != '\0'; s++) {
        h += (unsigned char)*s;
    }
    return h;
}

/* Polinom (Horner, taban 31): h = 31·h + bayt; uint32_t mod 2^32 sarar */
static uint32_t karma_polinom(const char *s)
{
    uint32_t h = 0;
    for (; *s != '\0'; s++) {
        h = 31u * h + (unsigned char)*s;
    }
    return h;
}

/* FNV-1a 32 bit (Fowler, Noll, Vo): önce XOR, sonra FNV asalıyla çarp */
static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;           /* FNV başlangıç değeri */
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;                 /* FNV asalı (2^24 + 2^8 + 0x93) */
    }
    return h;
}

static uint32_t karma(int f, const char *s)
{
    if (f == 0) {
        return karma_toplam(s);
    }
    return f == 1 ? karma_polinom(s) : karma_fnv1a(s);
}

/* Dağılım ölçütleri: c[0..m-1] kova doluluğu, n anahtar */
static void olcut_satiri(int f, const int *c, int m, int n)
{
    double beklenen = (double)n / m;    /* α = n / m */
    int bos = 0;
    int en_uzun = 0;
    double ki_kare = 0.0;
    double basarili = 0.0;              /* Σ c(c + 1) / 2 */
    for (int j = 0; j < m; j++) {
        bos += c[j] == 0;
        if (c[j] > en_uzun) {
            en_uzun = c[j];
        }
        double fark = c[j] - beklenen;
        ki_kare += fark * fark / beklenen;
        basarili += c[j] * (c[j] + 1) / 2.0;
    }
    printf("  %-8s %8d %8d %10.3f %10.3f %12.1f %8.3f\n", F_AD[f], bos,
           en_uzun, (double)n / (m - bos), basarili / n, ki_kare,
           ki_kare / (m - 1));
}

static void kuram_satiri(int m, int n)
{
    double alfa = (double)n / m;
    double bos = m * exp(-alfa);
    printf("  düzgün   %8.1f %8s %10.3f %10.3f %12.1f %8.3f\n", bos, "-",
           n / (m - bos), 1.0 + alfa / 2.0, (double)(m - 1), 1.0);
}

/* Histogram verisi: kaç kovada tam k anahtar var? + Poisson beklentisi */
static void histogram(int *const c[F_SAYISI], int m, int n)
{
    int en_uzun = 0;
    for (int f = 0; f < F_SAYISI; f++) {
        for (int j = 0; j < m; j++) {
            if (c[f][j] > en_uzun) {
                en_uzun = c[f][j];
            }
        }
    }
    int *sayi = calloc((size_t)(en_uzun + 1) * F_SAYISI, sizeof *sayi);
    if (sayi == NULL) {
        exit(1);
    }
    for (int f = 0; f < F_SAYISI; f++) {
        for (int j = 0; j < m; j++) {
            sayi[c[f][j] * F_SAYISI + f]++;
        }
    }
    double alfa = (double)n / m;
    double p = exp(-alfa);              /* P(k) = e^-α α^k / k! */
    printf("     k   toplam  polinom   FNV-1a  Poisson(m·P(k))\n");
    for (int k = 0; k <= en_uzun; k++) {
        if (k > 0) {
            p = p * alfa / k;
        }
        printf("  %4d %8d %8d %8d %16.1f\n", k, sayi[k * F_SAYISI],
               sayi[k * F_SAYISI + 1], sayi[k * F_SAYISI + 2], m * p);
    }
    free(sayi);
}

int main(void)
{
    const int m_deger[2] = {1009, 10007};       /* iki asal kova sayısı */
    int *c[2][F_SAYISI];
    for (int t = 0; t < 2; t++) {
        for (int f = 0; f < F_SAYISI; f++) {
            c[t][f] = calloc((size_t)m_deger[t], sizeof *c[t][f]);
            if (c[t][f] == NULL) {
                return 1;
            }
        }
    }
    printf("1) Üç karma fonksiyonu (UTF-8 baytları, 32 bit işaretsiz)\n");
    printf("  toplam : h = h + b                         (mod 2^32)\n");
    printf("  polinom: h = 31·h + b (Horner)             (mod 2^32)\n");
    printf("  FNV-1a : h = (h XOR b)·16777619, h0 = 2166136261 "
           "(mod 2^32)\n");
    printf("      toplam     polinom      FNV-1a bayt  ad\n");

    char satir[256];
    int n = 0;
    uint32_t en_az = UINT32_MAX;
    uint32_t en_cok = 0;
    while (fgets(satir, sizeof satir, stdin) != NULL) {
        satir[strcspn(satir, "\r\n")] = '\0';
        if (satir[0] == '\0') {
            continue;
        }
        uint32_t h[F_SAYISI];
        for (int f = 0; f < F_SAYISI; f++) {
            h[f] = karma(f, satir);
            for (int t = 0; t < 2; t++) {
                c[t][f][h[f] % (uint32_t)m_deger[t]]++;
            }
        }
        if (h[0] < en_az) {
            en_az = h[0];
        }
        if (h[0] > en_cok) {
            en_cok = h[0];
        }
        if (n < 5) {
            printf("  %10u  %10u  %10u %4zu  %s\n", h[0], h[1], h[2],
                   strlen(satir), satir);
        }
        n++;
    }
    printf("  ... toplam %d ad; toplam karmanın aralığı yalnızca "
           "[%u, %u]\n", n, en_az, en_cok);

    printf("\n2) Toplam karmanın zayıflığı: baytların sırası önemsiz\n");
    const char *ornek[4] = {"Ali Can", "Can Ali", "Nil Aca", "ali can"};
    for (int i = 0; i < 4; i++) {
        printf("  toplam = %5u  polinom = %10u  FNV-1a = %10u  \"%s\"\n",
               karma_toplam(ornek[i]), karma_polinom(ornek[i]),
               karma_fnv1a(ornek[i]), ornek[i]);
    }

    printf("\n3) Kovalara dağılım: indis = h mod m\n");
    printf("  χ² = Σ (c_j − n/m)² / (n/m)   (j = 0..m−1; düzgün "
           "dağılımda ≈ m − 1)\n");
    printf("  başarılı arama ort. = Σ c_j (c_j + 1) / 2 / n   "
           "(düzgünde ≈ 1 + α/2)\n");
    for (int t = 0; t < 2; t++) {
        printf("\n  n = %d, m = %d, α = %.3f\n", n, m_deger[t],
               (double)n / m_deger[t]);
        printf("  işlev    boş kova  en uzun  dolu/kova  başarılı "
               "          χ²  χ²/(m−1)\n");
        for (int f = 0; f < F_SAYISI; f++) {
            olcut_satiri(f, c[t][f], m_deger[t], n);
        }
        kuram_satiri(m_deger[t], n);
    }

    printf("\n4) Histogram verisi (m = %d): k anahtarlı kova sayısı\n",
           m_deger[1]);
    histogram(c[1], m_deger[1], n);

    for (int t = 0; t < 2; t++) {
        for (int f = 0; f < F_SAYISI; f++) {
            free(c[t][f]);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX hsearch kendi karma fonksiyonunu
 * kullanır); C++ — std::hash<std::string> (değeri gerçekleştirime
 * bağlı); Python — hash(s) (SipHash ailesi, tohumlu; PEP 456,
 * PYTHONHASHSEED — bkz. Dil Penceresi kavram programı). */

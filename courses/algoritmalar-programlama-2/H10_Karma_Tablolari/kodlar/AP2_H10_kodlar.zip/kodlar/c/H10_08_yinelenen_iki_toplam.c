/* H10_08_yinelenen_iki_toplam.c — AP-2 Hafta 10 · Örnek 8 (★★)
 * Amaç    : Karma tablosuyla O(n²) → O(n): (1) yinelenen numara tespiti
 *           (sayaçlı karma kümesi; H2'nin kaba kuvvetiyle aynı sonuç),
 *           (2) iki toplam (two-sum): a[i] + a[j] = T; kâhin O(n²) kaba
 *           kuvvet; karşılaştırma ve yoklama sayıları
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_08_yinelenen_iki_toplam.c ortak_rastgele.c \
 *           -o H10_08_yinelenen_iki_toplam
 * Çalıştır: ./H10_08_yinelenen_iki_toplam
 * Eşleri  : cpp/H10_08_yinelenen_iki_toplam.cpp ·
 *           python/H10_08_yinelenen_iki_toplam.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

/* Açık adresleme (doğrusal yoklama), uint32_t anahtar → int değer */
typedef struct {
    uint32_t *anahtar;
    int *deger;
    unsigned char *dolu;
    int p;                       /* m = 2^p ≥ 2n: α ≤ 1/2 */
} Harita;

static long long yoklama_sayisi = 0;
static long long karsilastirma_sayisi = 0;

static uint32_t karma_carpma(uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

/* Sahiplik: diziler çağıranındır; harita_yok_et ile serbest bırakılır */
static int harita_kur(Harita *h, size_t n)
{
    int p = 4;
    while (((size_t)1 << p) < 2 * n) {
        p++;
    }
    size_t m = (size_t)1 << p;
    h->anahtar = malloc(m * sizeof *h->anahtar);
    h->deger = malloc(m * sizeof *h->deger);
    h->dolu = calloc(m, 1);
    h->p = p;
    return h->anahtar && h->deger && h->dolu ? 0 : -1;
}

static void harita_yok_et(Harita *h)
{
    free(h->anahtar);
    free(h->deger);
    free(h->dolu);
}

/* Anahtarın hücresini döndürür: bulunduysa *var = 1, yoksa ilk BOŞ hücre */
static size_t harita_yer(const Harita *h, uint32_t k, int *var)
{
    uint32_t maske = ((uint32_t)1 << h->p) - 1u;
    uint32_t i = karma_carpma(k, h->p);
    for (;;) {
        yoklama_sayisi++;
        if (!h->dolu[i]) {
            *var = 0;
            return i;
        }
        if (h->anahtar[i] == k) {
            *var = 1;
            return i;
        }
        i = (i + 1u) & maske;
    }
}

/* --- 1) Yinelenen tespiti --------------------------------------------- */

/* Kâhin (H2): tüm çiftler, eşit çift sayısı; n(n-1)/2 karşılaştırma */
static long long cift_kaba(const uint32_t *a, size_t n)
{
    long long cift = 0;
    for (size_t i = 0; i + 1 < n; i++) {
        for (size_t j = i + 1; j < n; j++) {
            karsilastirma_sayisi++;
            cift += a[i] == a[j];
        }
    }
    return cift;
}

/* Karma ile: her değerin kaç kez geçtiği; eşit çift = Σ c(c-1)/2.
 * Yinelenen değerler (c ≥ 2) yin[]'e, sayıları yin_c[]'ye yazılır. */
static long long cift_karma(const uint32_t *a, size_t n, uint32_t *yin,
                            int *yin_c, size_t *yin_n)
{
    Harita h;
    if (harita_kur(&h, n) != 0) {
        harita_yok_et(&h);
        exit(1);
    }
    for (size_t i = 0; i < n; i++) {
        int var;
        size_t yer = harita_yer(&h, a[i], &var);
        if (var) {
            h.deger[yer]++;
        } else {
            h.dolu[yer] = 1;
            h.anahtar[yer] = a[i];
            h.deger[yer] = 1;
        }
    }
    long long cift = 0;
    *yin_n = 0;
    size_t m = (size_t)1 << h.p;
    for (size_t i = 0; i < m; i++) {
        if (h.dolu[i] && h.deger[i] >= 2) {
            long long c = h.deger[i];
            cift += c * (c - 1) / 2;
            if (yin != NULL) {
                yin[*yin_n] = h.anahtar[i];
                yin_c[*yin_n] = h.deger[i];
            }
            (*yin_n)++;
        }
    }
    harita_yok_et(&h);
    return cift;
}

static void senaryo(const char *ad, const uint32_t *a, size_t n)
{
    uint32_t yin[8];
    int yin_c[8];
    size_t yin_n;
    karsilastirma_sayisi = 0;
    long long c1 = cift_kaba(a, n);
    yoklama_sayisi = 0;
    long long c2 = cift_karma(a, n, yin, yin_c, &yin_n);
    /* çıktı biçimi: yinelenenleri değere göre sırala (karma sırası
     * tanımsız) — küçük dizi, araya ekleme */
    for (size_t i = 1; i < yin_n; i++) {
        uint32_t x = yin[i];
        int c = yin_c[i];
        size_t j = i;
        while (j > 0 && yin[j - 1] > x) {
            yin[j] = yin[j - 1];
            yin_c[j] = yin_c[j - 1];
            j--;
        }
        yin[j] = x;
        yin_c[j] = c;
    }
    printf("  %s n=%zu: kaba %lld çift (kar=%lld) | karma %lld çift "
           "(yokl=%lld) | yinelenen:", ad, n, c1, karsilastirma_sayisi, c2,
           yoklama_sayisi);
    if (yin_n == 0) {
        printf(" yok");
    }
    for (size_t i = 0; i < yin_n; i++) {
        printf(" %u×%d", yin[i], yin_c[i]);
    }
    printf("\n");
}

/* --- 2) İki toplam ----------------------------------------------------- */

/* Kâhin: en küçük j, sonra en küçük i ile a[i] + a[j] = T; yoksa 0 */
static int iki_toplam_kaba(const uint32_t *a, size_t n, uint32_t T,
                           size_t *bi, size_t *bj)
{
    for (size_t j = 1; j < n; j++) {
        for (size_t i = 0; i < j; i++) {
            karsilastirma_sayisi++;
            if ((uint64_t)a[i] + a[j] == T) {
                *bi = i;
                *bj = j;
                return 1;
            }
        }
    }
    return 0;
}

/* Karma: soldan sağa; T - a[j] daha önce görüldüyse ilk görüldüğü i */
static int iki_toplam_karma(const uint32_t *a, size_t n, uint32_t T,
                            size_t *bi, size_t *bj)
{
    Harita h;
    if (harita_kur(&h, n) != 0) {
        harita_yok_et(&h);
        exit(1);
    }
    int bulundu = 0;
    for (size_t j = 0; j < n; j++) {
        int var;
        if (a[j] <= T) {
            size_t yer = harita_yer(&h, T - a[j], &var);
            if (var) {
                *bi = (size_t)h.deger[yer];
                *bj = j;
                bulundu = 1;
                break;
            }
        }
        size_t yer = harita_yer(&h, a[j], &var);
        if (!var) {                          /* yalnız ilk konum tutulur */
            h.dolu[yer] = 1;
            h.anahtar[yer] = a[j];
            h.deger[yer] = (int)j;
        }
    }
    harita_yok_et(&h);
    return bulundu;
}

static void iki_toplam_satiri(const char *ad, const uint32_t *a, size_t n,
                              uint32_t T, int kaba_da)
{
    size_t i2 = 0, j2 = 0;
    yoklama_sayisi = 0;
    int b2 = iki_toplam_karma(a, n, T, &i2, &j2);
    printf("  %s, n = %zu, T = %u: ", ad, n, T);
    if (b2) {
        printf("(%zu, %zu) %u + %u", i2, j2, a[i2], a[j2]);
    } else {
        printf("çift yok");
    }
    printf(" | karma yokl=%lld", yoklama_sayisi);
    if (kaba_da) {
        size_t i1 = 0, j1 = 0;
        karsilastirma_sayisi = 0;
        int b1 = iki_toplam_kaba(a, n, T, &i1, &j1);
        int ayni = b1 == b2 && (!b1 || (i1 == i2 && j1 == j2));
        printf(" | kaba kar=%lld, aynı mı? %s", karsilastirma_sayisi,
               ayni ? "evet" : "HAYIR");
    }
    printf("\n");
}

int main(void)
{
    const uint32_t s1[] = {11, 22, 33, 44, 55};
    const uint32_t s2[] = {7, 3, 7, 5, 3, 7};
    const uint32_t s3[] = {9, 9, 1, 2, 3, 4};
    const uint32_t s4[] = {1, 2, 3, 4, 8, 8};

    printf("1) Yinelenen tespiti: eşit çift sayısı = Σ c(c-1)/2 (c: bir "
           "değerin kaç kez geçtiği)\n");
    senaryo("S1", s1, 5);
    senaryo("S2", s2, 6);
    senaryo("S3", s3, 6);
    senaryo("S4", s4, 6);

    printf("\n  Öğrenci numaraları 2400000000 + karıştırılmış 0..n-1, "
           "a[n/2] = a[0] kopyası (tohum 42)\n");
    printf("         n   çift  karma yokl.  yokl./n   kaba kar.  "
           "(kaba = n(n-1)/2)\n");
    const size_t boyut[] = {1000, 2000, 10000, 100000};
    for (int t = 0; t < 4; t++) {
        size_t n = boyut[t];
        int *sira = malloc(n * sizeof *sira);
        uint32_t *no = malloc(n * sizeof *no);
        if (sira == NULL || no == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            sira[i] = (int)i;
        }
        rastgele_tohum(42);
        rastgele_karistir(sira, n);
        for (size_t i = 0; i < n; i++) {
            no[i] = 2400000000u + (uint32_t)sira[i];
        }
        no[n / 2] = no[0];
        size_t yin_n;
        yoklama_sayisi = 0;
        long long cift = cift_karma(no, n, NULL, NULL, &yin_n);
        printf("  %8zu %6lld %12lld %8.3f", n, cift, yoklama_sayisi,
               (double)yoklama_sayisi / n);
        if (n <= 2000) {
            karsilastirma_sayisi = 0;
            long long c1 = cift_kaba(no, n);
            printf(" %11lld  %s\n", karsilastirma_sayisi,
                   c1 == cift ? "(aynı sonuç)" : "(FARKLI!)");
        } else {
            printf(" %11s\n", "-");
        }
        free(sira);
        free(no);
    }

    printf("\n2) İki toplam: a[i] + a[j] = T olan ilk çift (en küçük j, "
           "sonra en küçük i)\n");
    const uint32_t k[] = {8, 3, 11, 7, 2, 15, 5};
    iki_toplam_satiri("küçük", k, 7, 9, 1);
    iki_toplam_satiri("küçük", k, 7, 100, 1);
    const size_t boyut2[] = {1000, 2000, 100000};
    for (int t = 0; t < 3; t++) {
        size_t n = boyut2[t];
        uint32_t *a = malloc(n * sizeof *a);
        if (a == NULL) {
            return 1;
        }
        rastgele_tohum(7);
        for (size_t i = 0; i < n; i++) {
            a[i] = 2u * (uint32_t)rastgele_aralik(0, 499999);   /* çift */
        }
        iki_toplam_satiri("tek T", a, n, 999999, n <= 2000);   /* yok */
        iki_toplam_satiri("son ikili", a, n, a[n - 2] + a[n - 1],
                          n <= 2000);
        free(a);
    }
    printf("  (tek T: tüm sayılar çift olduğundan çözüm yok — en kötü "
           "durum: kaba n(n-1)/2 karşılaştırma,\n   karma öğe başına iki "
           "arama: toplam Θ(n) yoklama)\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_set /
 * std::unordered_map (find, count); Python — set / dict
 * (x in gorulen, gorulen[x] = j). */

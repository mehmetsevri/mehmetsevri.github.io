/* H10_10_dogum_gunu.c — AP-2 Hafta 10 · Örnek 10 (★★)
 * Amaç    : Doğum günü paradoksu: n kişide en az bir ortak doğum günü
 *           olasılığı (kesin formül, n = 1..60; 23 kişide ≈ 0,507), ortak
 *           LCG ile Monte Carlo karşılaştırması; karma bağlantısı: m kovaya
 *           ilk çakışmaya kadar beklenen anahtar sayısı, %50 eşiği
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_10_dogum_gunu.c ortak_rastgele.c -o H10_10_dogum_gunu -lm
 * Çalıştır: ./H10_10_dogum_gunu
 * Eşleri  : cpp/H10_10_dogum_gunu.cpp · python/H10_10_dogum_gunu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define GUN 365
#define DENEME 5000

/* P(n) = 1 − Π_{k=0}^{n-1} (m − k)/m ; çarpım soldan sağa, üç dilde aynı */
static void kesin_tablo(double *p, int n_ust, long long m)
{
    double q = 1.0;                          /* çakışma yok olasılığı */
    for (int n = 1; n <= n_ust; n++) {
        q = q * ((double)(m - (n - 1)) / (double)m);
        p[n] = 1.0 - q;
    }
}

/* Bir deneme: n doğum günü çek; ilk tekrar görülürse 1. gorulen[] =
 * doğrudan adresleme; damga = deneme numarası (diziyi sıfırlamadan) */
static int deneme_yap(int n, int *gorulen, int damga)
{
    for (int k = 0; k < n; k++) {
        int g = rastgele_aralik(0, GUN - 1);
        if (gorulen[g] == damga) {
            return 1;
        }
        gorulen[g] = damga;
    }
    return 0;
}

/* m kova: %50 eşiğini geçen en küçük n ve ilk çakışmanın beklenen sırası
 * E = Σ_{k≥0} P(ilk k anahtarda çakışma yok) */
static void esik_satiri(const char *ad, long long m)
{
    double q = 1.0;
    double beklenen = 1.0;                   /* k = 0 terimi */
    long long esik = 0;
    for (long long k = 1; k <= m && q > 1e-18; k++) {
        beklenen += q;                       /* q = P(ilk k'da yok) */
        q = q * ((double)(m - k) / (double)m);
        if (esik == 0 && 1.0 - q >= 0.5) {
            esik = k + 1;
        }
    }
    printf("  %14lld %10lld %12.3f %12.3f   %s\n", m, esik, beklenen,
           sqrt(3.14159265358979323846 * (double)m / 2.0), ad);
}

int main(void)
{
    double p[61];
    kesin_tablo(p, 60, GUN);

    printf("1) Kesin olasılık: P(n) = 1 − (365/365)(364/365)…((365−n+1)/365)"
           "\n");
    for (int r = 1; r <= 20; r++) {
        printf("  n = %2d: %.6f   n = %2d: %.6f   n = %2d: %.6f\n", r, p[r],
               r + 20, p[r + 20], r + 40, p[r + 40]);
    }
    int esik = 1;
    while (p[esik] < 0.5) {
        esik++;
    }
    printf("  P ≥ 0,5 olan en küçük n = %d (P = %.4f); n = 57'de %.4f\n",
           esik, p[esik], p[57]);

    printf("\n2) Monte Carlo (ortak LCG, tohum 42, %d deneme / satır)\n",
           DENEME);
    printf("     n   kesin   tahmin    fark\n");
    int *gorulen = calloc(GUN, sizeof *gorulen);
    if (gorulen == NULL) {
        return 1;
    }
    const int n_deger[] = {10, 20, 23, 30, 40, 50, 60};
    rastgele_tohum(42);
    int damga = 0;
    for (int i = 0; i < 7; i++) {
        int n = n_deger[i];
        int cakisan = 0;
        for (int d = 0; d < DENEME; d++) {
            cakisan += deneme_yap(n, gorulen, ++damga);
        }
        double tahmin = (double)cakisan / DENEME;
        printf("  %4d %7.4f %8.4f %+7.4f\n", n, p[n], tahmin, tahmin - p[n]);
    }

    printf("\n3) Karma bağlantısı: m kova, düzgün karma — ilk çakışma ne "
           "zaman?\n");
    printf("               m   %%50 eşiği  E[ilk çakışma]  √(πm/2)   "
           "yorum\n");
    esik_satiri("yılın günleri", 365);
    esik_satiri("bin kovalı tablo", 1000);
    esik_satiri("milyon kovalı tablo", 1000000);
    esik_satiri("32 bit karma değerleri", 4294967296LL);
    long long toplam = 0;
    for (int d = 0; d < DENEME; d++) {
        ++damga;
        int k = 0;
        for (;;) {
            int g = rastgele_aralik(0, GUN - 1);
            k++;
            if (gorulen[g] == damga) {
                break;
            }
            gorulen[g] = damga;
        }
        toplam += k;
    }
    printf("  m = 365, Monte Carlo: ilk çakışmanın ortalama sırası = %.3f "
           "(%d deneme)\n", (double)toplam / DENEME, DENEME);
    free(gorulen);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — yok (std::unordered_set
 * ile görülen günler tutulabilir); Python — set (ya da
 * math.prod / math.perm ile kesin formül). */

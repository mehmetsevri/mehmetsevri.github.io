/* H10_06_yeniden_boyutlandirma.c — AP-2 Hafta 10 · Örnek 6 (★★)
 * Amaç    : Yeniden boyutlandırma (rehash): α = n/m > 3/4 olacaksa kapasite
 *           × 2 ve tüm anahtarlar yeni tabloya yeniden yerleştirilir;
 *           taşınan öğe sayısının toplamı ve öğe başına amortize maliyet
 *           (tek ekleme Θ(n) olabilir, n eklemenin toplamı O(n))
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_06_yeniden_boyutlandirma.c ortak_rastgele.c \
 *           -o H10_06_yeniden_boyutlandirma
 * Çalıştır: ./H10_06_yeniden_boyutlandirma [N_ust]   (varsayılan 100000)
 * Eşleri  : cpp/H10_06_yeniden_boyutlandirma.cpp ·
 *           python/H10_06_yeniden_boyutlandirma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    uint32_t *anahtar;
    unsigned char *dolu;
    int p;                       /* m = 2^p */
    size_t n;
} Tablo;

static long long yoklama_sayisi = 0;
static long long yazma_sayisi = 0;           /* hücreye yazılan anahtar */
static long long tasinan_sayisi = 0;         /* yeniden yerleştirilen */
static int iz_ac = 0;                        /* bölüm 1: olayları yaz */

static uint32_t karma_carpma(uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

/* Sahiplik: dizileri çağıran tablo_yok_et ile serbest bırakır */
static int tablo_kur(Tablo *t, int p)
{
    size_t m = (size_t)1 << p;
    t->anahtar = malloc(m * sizeof *t->anahtar);
    t->dolu = calloc(m, 1);
    if (t->anahtar == NULL || t->dolu == NULL) {
        free(t->anahtar);
        free(t->dolu);
        return -1;
    }
    t->p = p;
    t->n = 0;
    return 0;
}

static void tablo_yok_et(Tablo *t)
{
    free(t->anahtar);
    free(t->dolu);
}

/* Yer bulup yazar (yük denetimi yok); 1: yeni, 0: zaten var */
static int yerlestir(Tablo *t, uint32_t k)
{
    uint32_t maske = ((uint32_t)1 << t->p) - 1u;
    uint32_t i = karma_carpma(k, t->p);
    for (;;) {
        yoklama_sayisi++;
        if (!t->dolu[i]) {
            break;
        }
        if (t->anahtar[i] == k) {
            return 0;
        }
        i = (i + 1u) & maske;
    }
    t->dolu[i] = 1;
    t->anahtar[i] = k;
    t->n++;
    yazma_sayisi++;
    return 1;
}

/* Kapasite × 2: eski dizideki her anahtar yeni diziye yeniden karma ile
 * yerleşir (indis m'ye bağlı olduğundan kopyalamak yetmez). -1: bellek */
static int buyut(Tablo *t)
{
    Tablo yeni;
    if (tablo_kur(&yeni, t->p + 1) != 0) {
        return -1;
    }
    size_t m = (size_t)1 << t->p;
    for (size_t i = 0; i < m; i++) {
        if (t->dolu[i]) {
            yerlestir(&yeni, t->anahtar[i]);
            tasinan_sayisi++;
        }
    }
    if (iz_ac) {
        printf("  ekleme #%zu öncesi: α = %zu/%zu > 3/4 olacaktı -> m %zu -> "
               "%zu, taşınan %zu\n", t->n + 1, t->n + 1, m, m, 2 * m, t->n);
    }
    tablo_yok_et(t);
    *t = yeni;
    return 0;
}

/* Yük denetimli ekleme: (n + 1) / m > 3/4 olacaksa önce büyüt */
static int tablo_ekle(Tablo *t, uint32_t k)
{
    size_t m = (size_t)1 << t->p;
    if (4 * (t->n + 1) > 3 * m) {
        if (buyut(t) != 0) {
            return -1;
        }
    }
    return yerlestir(t, k);
}

static int deney_satiri(size_t N)
{
    Tablo t;
    if (tablo_kur(&t, 3) != 0) {             /* m = 8 ile başla */
        return -1;
    }
    yoklama_sayisi = yazma_sayisi = tasinan_sayisi = 0;
    long long en_pahali = 0;
    size_t en_pahali_no = 0;
    int buyutme = 0;
    rastgele_tohum(42);
    while (t.n < N) {
        long long once = yazma_sayisi;
        int p_once = t.p;
        if (tablo_ekle(&t, rastgele_sayi()) < 0) {
            tablo_yok_et(&t);
            return -1;
        }
        buyutme += t.p != p_once;
        if (yazma_sayisi - once > en_pahali) {
            en_pahali = yazma_sayisi - once;
            en_pahali_no = t.n;
        }
    }
    printf("  %8zu %4d %9zu %10lld %8.3f %11lld %9zu %8.3f %8.3f\n", N,
           buyutme, (size_t)1 << t.p, tasinan_sayisi,
           (double)tasinan_sayisi / N, en_pahali, en_pahali_no,
           (double)yazma_sayisi / N, (double)yoklama_sayisi / N);
    tablo_yok_et(&t);
    return 0;
}

int main(int argc, char *argv[])
{
    long N_ust = 100000;
    if (argc > 2) {
        fprintf(stderr, "kullanım: %s [N_ust (100..10000000)]\n", argv[0]);
        return 2;
    }
    if (argc == 2) {
        char *son;
        N_ust = strtol(argv[1], &son, 10);
        if (*argv[1] == '\0' || *son != '\0' || N_ust < 100 ||
            N_ust > 10000000) {
            fprintf(stderr, "kullanım: %s [N_ust (100..10000000)]\n",
                    argv[0]);
            return 2;
        }
    }

    printf("1) İlk 100 ekleme: m = 8'den başla, (n + 1)/m > 3/4 olacaksa "
           "m × 2\n");
    Tablo t;
    if (tablo_kur(&t, 3) != 0) {
        return 1;
    }
    iz_ac = 1;
    rastgele_tohum(42);
    while (t.n < 100) {
        if (tablo_ekle(&t, rastgele_sayi()) < 0) {
            tablo_yok_et(&t);
            return 1;
        }
    }
    iz_ac = 0;
    printf("  100 eklemeden sonra: m = %zu, α = %.3f, toplam taşınan = "
           "%lld\n", (size_t)1 << t.p, (double)t.n / ((size_t)1 << t.p),
           tasinan_sayisi);
    tablo_yok_et(&t);

    printf("\n2) N ekleme: büyütme sayısı, taşınan toplamı, en pahalı "
           "tek ekleme\n");
    printf("  (yazma = hücreye anahtar yazımı: ekleme 1 + büyütmede "
           "taşınanlar; yoklama = bakılan hücre)\n");
    printf("         N  büy.    son m    taşınan  taş./N  en pahalı "
           "  (#ekl.)  yazma/N  yokl./N\n");
    for (long N = 1000; N <= N_ust; N *= 10) {
        if (deney_satiri((size_t)N) != 0) {
            return 1;
        }
    }
    printf("  (taşınanlar geometrik dizi: 6 + 12 + … + L < 2L ≤ 2N; "
           "en pahalı tek ekleme L + 1 yazma = Θ(n))\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
 * otomatik rehash (max_load_factor, rehash(), reserve()); Python — dict
 * (otomatik büyür; kullanıcıya açık eşik yok). */

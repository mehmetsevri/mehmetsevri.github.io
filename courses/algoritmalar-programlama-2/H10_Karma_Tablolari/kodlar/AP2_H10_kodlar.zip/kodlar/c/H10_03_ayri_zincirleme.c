/* H10_03_ayri_zincirleme.c — AP-2 Hafta 10 · Örnek 3 (★★)
 * Amaç    : Ayrı zincirleme karma tablosu: m kova + bağlı düğüm listeleri
 *           (H8); ekle (güncelleme semantiği) / ara / sil; anahtar dizgisi
 *           KOPYALANIR; anahtar → karma → kova akışı, sayaçlar
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_03_ayri_zincirleme.c -o H10_03_ayri_zincirleme
 * Çalıştır: ./H10_03_ayri_zincirleme
 * Eşleri  : cpp/H10_03_ayri_zincirleme.cpp ·
 *           python/H10_03_ayri_zincirleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Dugum {
    char *anahtar;               /* sahiplik: düğümündür (kopya) */
    int deger;
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    Dugum **kova;                /* m kova başı; boş kova NULL */
    size_t m;
    size_t n;                    /* anahtar sayısı */
} Tablo;

static long long karsilastirma_sayisi = 0;   /* anahtar karşılaştırması */
static long long ayrilan_dugum = 0;
static long long birakilan_dugum = 0;

/* FNV-1a 32 bit; baytlar unsigned char olarak okunur (Hata Avcısı 1) */
static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

/* strdup C17'de yok: malloc + memcpy. Sahiplik: dönen dizgi çağıranındır;
 * free ile serbest bırakılır. Bellek yetmezse NULL. */
static char *dizgi_kopyala(const char *s)
{
    size_t uzunluk = strlen(s) + 1;
    char *kopya = malloc(uzunluk);
    if (kopya != NULL) {
        memcpy(kopya, s, uzunluk);
    }
    return kopya;
}

/* Sahiplik: dönen tablo çağıranındır; tablo_yok_et ile serbest bırakılır */
static Tablo *tablo_olustur(size_t m)
{
    Tablo *t = malloc(sizeof *t);
    if (t == NULL) {
        return NULL;
    }
    t->kova = calloc(m, sizeof *t->kova);
    if (t->kova == NULL) {
        free(t);
        return NULL;
    }
    t->m = m;
    t->n = 0;
    return t;
}

static size_t kova_no(const Tablo *t, const char *anahtar)
{
    return karma_fnv1a(anahtar) % t->m;
}

/* Kovanın zincirinde anahtarı arar; bulunamazsa NULL */
static Dugum *zincirde_bul(Dugum *d, const char *anahtar)
{
    for (; d != NULL; d = d->sonraki) {
        karsilastirma_sayisi++;
        if (strcmp(d->anahtar, anahtar) == 0) {
            return d;
        }
    }
    return NULL;
}

/* 1: yeni anahtar, 0: değer güncellendi, -1: bellek yetmedi */
static int tablo_ekle(Tablo *t, const char *anahtar, int deger)
{
    size_t j = kova_no(t, anahtar);
    Dugum *d = zincirde_bul(t->kova[j], anahtar);
    if (d != NULL) {
        d->deger = deger;                /* güncelleme semantiği */
        return 0;
    }
    d = malloc(sizeof *d);
    if (d == NULL) {
        return -1;
    }
    d->anahtar = dizgi_kopyala(anahtar); /* dış tampona bağlanma! */
    if (d->anahtar == NULL) {
        free(d);
        return -1;
    }
    d->deger = deger;
    d->sonraki = t->kova[j];             /* zincirin başına: O(1) */
    t->kova[j] = d;
    t->n++;
    ayrilan_dugum++;
    return 1;
}

/* Bulursa *deger'e yazar ve 1 döndürür; yoksa 0 */
static int tablo_ara(const Tablo *t, const char *anahtar, int *deger)
{
    Dugum *d = zincirde_bul(t->kova[kova_no(t, anahtar)], anahtar);
    if (d == NULL) {
        return 0;
    }
    *deger = d->deger;
    return 1;
}

/* Dugum ** ile silme (H8): bağlantıyı tutan işaretçinin adresi gezer */
static int tablo_sil(Tablo *t, const char *anahtar)
{
    Dugum **bag = &t->kova[kova_no(t, anahtar)];
    while (*bag != NULL) {
        karsilastirma_sayisi++;
        if (strcmp((*bag)->anahtar, anahtar) == 0) {
            Dugum *silinen = *bag;
            *bag = silinen->sonraki;
            free(silinen->anahtar);
            free(silinen);
            birakilan_dugum++;
            t->n--;
            return 1;
        }
        bag = &(*bag)->sonraki;
    }
    return 0;
}

static void tablo_yaz(const Tablo *t)
{
    for (size_t j = 0; j < t->m; j++) {
        printf("  kova %zu:", j);
        for (const Dugum *d = t->kova[j]; d != NULL; d = d->sonraki) {
            printf(" %s=%d ->", d->anahtar, d->deger);
        }
        printf(" NULL\n");
    }
}

/* Bütün zincirleri yinelemeli serbest bırakır; tablo da serbest kalır */
static void tablo_yok_et(Tablo *t)
{
    for (size_t j = 0; j < t->m; j++) {
        Dugum *d = t->kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            free(d->anahtar);
            free(d);
            birakilan_dugum++;
            d = sonraki;
        }
    }
    free(t->kova);
    free(t);
}

static void ara_yaz(const Tablo *t, const char *anahtar)
{
    long long once = karsilastirma_sayisi;
    int deger;
    if (tablo_ara(t, anahtar, &deger)) {
        printf("  ara %s: %d (kova %zu, karşılaştırma = %lld)\n", anahtar,
               deger, kova_no(t, anahtar), karsilastirma_sayisi - once);
    } else {
        printf("  ara %s: YOK (kova %zu, karşılaştırma = %lld)\n", anahtar,
               kova_no(t, anahtar), karsilastirma_sayisi - once);
    }
}

int main(void)
{
    const char *ad[] = {"ali", "ayşe", "can", "elif", "deniz", "zeynep",
                        "mert", "ece", "kerem", "selin", "ömer", "ılgın"};
    const int not_[] = {70, 85, 60, 90, 75, 95, 55, 80, 65, 88, 72, 91};
    const int k = 12;
    Tablo *t = tablo_olustur(11);
    if (t == NULL) {
        return 1;
    }
    char tampon[32];             /* girdi okuma tamponunun benzetimi */

    printf("1) Anahtar -> FNV-1a karma -> kova (m = %zu)\n", t->m);
    for (int i = 0; i < k; i++) {
        snprintf(tampon, sizeof tampon, "%s", ad[i]);
        int sonuc = tablo_ekle(t, tampon, not_[i]);
        if (sonuc < 0) {
            tablo_yok_et(t);
            return 1;
        }
        printf("  ekle %s=%d: karma = 0x%08x = %10u -> kova %zu\n", tampon,
               not_[i], karma_fnv1a(tampon), karma_fnv1a(tampon),
               kova_no(t, tampon));
    }
    snprintf(tampon, sizeof tampon, "%s", "XXXXXXXX");
    printf("  (tampon artık \"%s\"; tablo kendi kopyalarını tutar)\n",
           tampon);
    printf("  n = %zu, m = %zu, α = n/m = %.3f (zincirlemede α > 1 "
           "olabilir)\n", t->n, t->m, (double)t->n / t->m);
    tablo_yaz(t);

    printf("\n2) Arama (karşılaştırma = zincirde bakılan düğüm sayısı)\n");
    ara_yaz(t, "ayşe");
    ara_yaz(t, "ali");
    ara_yaz(t, "ılgın");
    ara_yaz(t, "berk");

    printf("\n3) Güncelleme semantiği: var olan anahtar yeni düğüm "
           "oluşturmaz\n");
    int sonuc = tablo_ekle(t, "ayşe", 100);
    printf("  ekle ayşe=100 -> %s, n = %zu\n",
           sonuc == 1 ? "yeni" : "güncellendi", t->n);
    ara_yaz(t, "ayşe");

    printf("\n4) Silme (Dugum ** ile; ortadaki, baştaki, sondaki, "
           "olmayan)\n");
    const char *silinecek[] = {"elif", "ılgın", "can", "berk"};
    for (int i = 0; i < 4; i++) {
        long long once = karsilastirma_sayisi;
        int var = tablo_sil(t, silinecek[i]);
        printf("  sil %s: %s (kova %zu, karşılaştırma = %lld)\n",
               silinecek[i], var ? "silindi" : "YOK",
               kova_no(t, silinecek[i]), karsilastirma_sayisi - once);
    }
    tablo_yaz(t);

    printf("\n5) Ölçüler\n");
    size_t en_uzun = 0;
    size_t bos = 0;
    for (size_t j = 0; j < t->m; j++) {
        size_t u = 0;
        for (const Dugum *d = t->kova[j]; d != NULL; d = d->sonraki) {
            u++;
        }
        bos += u == 0;
        if (u > en_uzun) {
            en_uzun = u;
        }
    }
    karsilastirma_sayisi = 0;
    int bulunan = 0;
    for (int i = 0; i < k; i++) {
        int deger;
        bulunan += tablo_ara(t, ad[i], &deger);
    }
    printf("  n = %zu, boş kova = %zu, en uzun zincir = %zu\n", t->n, bos,
           en_uzun);
    printf("  %d adın %d tanesi bulundu; toplam karşılaştırma = %lld\n", k,
           bulunan, karsilastirma_sayisi);
    tablo_yok_et(t);
    printf("  düğüm: ayrılan = %lld, serbest bırakılan = %lld\n",
           ayrilan_dugum, birakilan_dugum);
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX hcreate/hsearch: silme yok,
 * süreçte tek tablo); C++ — std::unordered_map<std::string, int>
 * (libstdc++: kovalar + düğüm zincirleri); Python — dict (CPython: açık
 * adresleme). */

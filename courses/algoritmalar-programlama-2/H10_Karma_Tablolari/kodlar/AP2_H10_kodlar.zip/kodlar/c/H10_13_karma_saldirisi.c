/* H10_13_karma_saldirisi.c — AP-2 Hafta 10 · Örnek 13 (★★★)
 * Amaç    : Kötü karma fonksiyonuna saldırı (karma taşkını): polinom 31
 *           karmasında h("Aa") = h("BB"); k bloktan 2^k çakışan anahtar;
 *           zincirleme tabloya eklemede karşılaştırma sayısı karesel büyür
 *           (rastgele anahtarda doğrusal). Savunma denemeleri: ortak
 *           LCG'den tohumlu karma (tohumlu h0, rastgele taban — alt/üst
 *           bit indisi, tohumlu FNV-1a); süreler stderr'e
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_13_karma_saldirisi.c ortak_rastgele.c zamanlayici.c \
 *           -o H10_13_karma_saldirisi
 * Çalıştır: ./H10_13_karma_saldirisi [k_ust]   (n = 2^8 .. 2^k_ust,
 *           varsayılan 10, en çok 16)
 * Eşleri  : cpp/H10_13_karma_saldirisi.cpp ·
 *           python/H10_13_karma_saldirisi.py
 * Çıktı   : üç dilde aynı (=); süreler stderr'e
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define UZ 33                    /* en çok 16 blok × 2 bayt + NUL */

enum { POLINOM = 0, POLINOM_TOHUM = 1, RASTGELE_TABAN = 2, FNV_TOHUM = 3 };

#define A_FIB 2654435769u        /* ⌊2^32/φ⌋: üst bit indisi (Örnek 5) */

typedef struct Dugum {
    char *anahtar;
    uint32_t karma;              /* büyütmede yeniden hesaplanmaz */
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    Dugum **kova;
    int p;                       /* m = 2^p */
    size_t n;
    int tur;                     /* karma fonksiyonu */
    uint32_t tohum;              /* gizli anahtar (saldırgan bilmez) */
    int ust_bit;                 /* 1: indis = (h·A) >> (32 − p) */
} Tablo;

static long long karsilastirma_sayisi = 0;

/* Polinom 31 (Java String.hashCode'un formülü; burada UTF-8 baytlarıyla) */
static uint32_t karma_polinom(const char *s, uint32_t h, uint32_t taban)
{
    for (; *s != '\0'; s++) {
        h = taban * h + (unsigned char)*s;
    }
    return h;
}

static uint32_t karma_fnv1a(const char *s, uint32_t h)
{
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

static uint32_t karma(const Tablo *t, const char *s)
{
    switch (t->tur) {
    case POLINOM:
        return karma_polinom(s, 0u, 31u);
    case POLINOM_TOHUM:                      /* tohum = başlangıç değeri */
        return karma_polinom(s, t->tohum, 31u);
    case RASTGELE_TABAN:                     /* tohum = tek sayı taban */
        return karma_polinom(s, 0u, t->tohum);
    default:                                 /* FNV-1a, h0 XOR tohum */
        return karma_fnv1a(s, 2166136261u ^ t->tohum);
    }
}

static char *dizgi_kopyala(const char *s)
{
    size_t uzunluk = strlen(s) + 1;
    char *kopya = malloc(uzunluk);
    if (kopya != NULL) {
        memcpy(kopya, s, uzunluk);
    }
    return kopya;
}

/* Kova indisi: alt bitler (h & (m − 1)) ya da üst bitler (çarpma) */
static size_t indis(const Tablo *t, uint32_t h, int p)
{
    if (t->ust_bit) {
        return (size_t)((h * A_FIB) >> (32 - p));
    }
    return (size_t)(h & (((uint32_t)1 << p) - 1u));
}

/* Sahiplik: dönen tablo çağıranındır; tablo_yok_et ile serbest bırakılır */
static Tablo *tablo_olustur(int tur, uint32_t tohum, int ust_bit)
{
    Tablo *t = malloc(sizeof *t);
    if (t == NULL) {
        return NULL;
    }
    t->p = 4;                                /* m = 16 */
    t->kova = calloc((size_t)1 << t->p, sizeof *t->kova);
    if (t->kova == NULL) {
        free(t);
        return NULL;
    }
    t->n = 0;
    t->tur = tur;
    t->tohum = tohum;
    t->ust_bit = ust_bit;
    return t;
}

static void tablo_yok_et(Tablo *t)
{
    for (size_t j = 0; j < ((size_t)1 << t->p); j++) {
        Dugum *d = t->kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            free(d->anahtar);
            free(d);
            d = sonraki;
        }
    }
    free(t->kova);
    free(t);
}

static int buyut(Tablo *t)
{
    size_t m = (size_t)1 << t->p;
    Dugum **yeni = calloc(2 * m, sizeof *yeni);
    if (yeni == NULL) {
        return -1;
    }
    for (size_t j = 0; j < m; j++) {
        Dugum *d = t->kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            size_t k = indis(t, d->karma, t->p + 1);
            d->sonraki = yeni[k];
            yeni[k] = d;
            d = sonraki;
        }
    }
    free(t->kova);
    t->kova = yeni;
    t->p++;
    return 0;
}

/* Güncelleme semantiği: önce zincirin tamamı aranır (saldırının hedefi) */
static int tablo_ekle(Tablo *t, const char *anahtar)
{
    uint32_t h = karma(t, anahtar);
    size_t j = indis(t, h, t->p);
    for (Dugum *d = t->kova[j]; d != NULL; d = d->sonraki) {
        karsilastirma_sayisi++;
        if (strcmp(d->anahtar, anahtar) == 0) {
            return 0;
        }
    }
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return -1;
    }
    d->anahtar = dizgi_kopyala(anahtar);
    if (d->anahtar == NULL) {
        free(d);
        return -1;
    }
    d->karma = h;
    d->sonraki = t->kova[j];
    t->kova[j] = d;
    t->n++;
    return t->n > ((size_t)1 << t->p) ? buyut(t) : 1;
}

/* Bitişte: en uzun zincir ve dolu (boş olmayan) kova sayısı */
static void zincir_olcusu(const Tablo *t, size_t *en_uzun, size_t *dolu)
{
    *en_uzun = 0;
    *dolu = 0;
    for (size_t j = 0; j < ((size_t)1 << t->p); j++) {
        size_t u = 0;
        for (const Dugum *d = t->kova[j]; d != NULL; d = d->sonraki) {
            u++;
        }
        *dolu += u > 0;
        if (u > *en_uzun) {
            *en_uzun = u;
        }
    }
}

/* x'i bölen en büyük 2 kuvvetinin üssü (x = 0 için 32) */
static int iki_kuvveti(uint32_t x)
{
    int e = 0;
    while (e < 32 && (x & 1u) == 0u) {
        x >>= 1;
        e++;
    }
    return e;
}

/* i'nin k bitinden anahtar: bit 0 → "Aa", 1 → "BB" (en anlamlı bit önce) */
static void carpisan_anahtar(size_t i, int k, char *s)
{
    for (int b = 0; b < k; b++) {
        const char *blok = (i >> (k - 1 - b)) & 1u ? "BB" : "Aa";
        s[2 * b] = blok[0];
        s[2 * b + 1] = blok[1];
    }
    s[2 * k] = '\0';
}

static void rastgele_anahtar(int k, char *s)
{
    for (int b = 0; b < 2 * k; b++) {
        int x = rastgele_aralik(0, 51);
        s[b] = (char)(x < 26 ? 'A' + x : 'a' + x - 26);
    }
    s[2 * k] = '\0';
}

typedef struct {
    long long karsilastirma;
    size_t en_uzun;
    size_t dolu;                 /* boş olmayan kova */
    size_t m;
} Olcum;

/* n anahtarı tabloya ekler; sayaçları döndürür, süreyi stderr'e yazar */
static Olcum dene(char (*anahtar)[UZ], size_t n, int tur, uint32_t tohum,
                  int ust_bit, const char *etiket)
{
    Olcum o;
    Tablo *t = tablo_olustur(tur, tohum, ust_bit);
    if (t == NULL) {
        exit(1);
    }
    karsilastirma_sayisi = 0;
    double t0 = zaman_sn();
    for (size_t i = 0; i < n; i++) {
        if (tablo_ekle(t, anahtar[i]) < 0) {
            exit(1);
        }
    }
    double sure = zaman_sn() - t0;
    o.karsilastirma = karsilastirma_sayisi;
    zincir_olcusu(t, &o.en_uzun, &o.dolu);
    o.m = (size_t)1 << t->p;
    tablo_yok_et(t);
    fprintf(stderr, "  [süre] n = %6zu %-30s %10.3f ms\n", n, etiket,
            sure * 1e3);
    return o;
}

int main(int argc, char *argv[])
{
    long k_ust = 10;
    if (argc == 2) {
        char *son;
        k_ust = strtol(argv[1], &son, 10);
        if (*argv[1] == '\0' || *son != '\0') {
            k_ust = 0;
        }
    }
    if (argc > 2 || k_ust < 8 || k_ust > 16) {
        fprintf(stderr, "kullanım: %s [k_ust (8..16)]\n", argv[0]);
        return 2;
    }
    char (*anahtar)[UZ] = malloc(((size_t)1 << k_ust) * sizeof *anahtar);
    char (*rastgele)[UZ] = malloc(((size_t)1 << k_ust) * sizeof *rastgele);
    if (anahtar == NULL || rastgele == NULL) {
        return 1;
    }
    rastgele_tohum(2026);
    uint32_t taban = 2u * rastgele_sayi() + 1u;  /* tek sayı: tersinir */
    uint32_t tohum = rastgele_sayi();
    printf("1) Çakışan bloklar: polinom 31, h = 31·h + b (mod 2^32)\n");
    printf("  h(\"Aa\") = 65·31 + 97 = %u, h(\"BB\") = 66·31 + 66 = %u\n",
           karma_polinom("Aa", 0u, 31u), karma_polinom("BB", 0u, 31u));
    printf("  eşit uzunluklu bloklar: h(xy) = h(x)·31^|y| + h(y) -> 2^k "
           "anahtarın karması aynı\n");
    for (size_t i = 0; i < 4; i++) {
        char s[UZ];
        carpisan_anahtar(i, 4, s);
        printf("  %s -> %10u   (rastgele taban %u ile: %10u)\n", s,
               karma_polinom(s, 0u, 31u), taban, karma_polinom(s, 0u, taban));
    }
    printf("\n2) Zincirlemeli tabloya n ekleme (m = 16'dan başlar, α > 1 "
           "olunca × 2);\n   sayı = anahtar karşılaştırması (güncelleme "
           "için zincir aranır)\n");
    printf("  gizli tohumlar (ortak LCG, tohum 2026): taban = %u, "
           "tohum = %u\n", taban, tohum);
    printf("  a) anahtar karşılaştırması\n");
    printf("        n     saldırı    n(n−1)/2   rastgele    tohum h0   "
           "taban/alt  taban/üst  FNV tohum\n");
    Olcum sonuc[17][6];
    for (int k = 8; k <= (int)k_ust; k++) {
        size_t n = (size_t)1 << k;
        rastgele_tohum(42);
        for (size_t i = 0; i < n; i++) {
            carpisan_anahtar(i, k, anahtar[i]);
            rastgele_anahtar(k, rastgele[i]);
        }
        Olcum *o = sonuc[k];
        o[0] = dene(anahtar, n, POLINOM, 0, 0, "saldırı (polinom 31)");
        o[1] = dene(rastgele, n, POLINOM, 0, 0, "rastgele (polinom 31)");
        o[2] = dene(anahtar, n, POLINOM_TOHUM, tohum, 0,
                    "saldırı, tohumlu h0");
        o[3] = dene(anahtar, n, RASTGELE_TABAN, taban, 0,
                    "saldırı, rastgele taban/alt");
        o[4] = dene(anahtar, n, RASTGELE_TABAN, taban, 1,
                    "saldırı, rastgele taban/üst");
        o[5] = dene(anahtar, n, FNV_TOHUM, tohum, 0,
                    "saldırı, tohumlu FNV-1a");
        printf("  %7zu %11lld %11lld %10lld %11lld %11lld %10lld %10lld\n",
               n, o[0].karsilastirma, (long long)(n * (n - 1) / 2),
               o[1].karsilastirma, o[2].karsilastirma, o[3].karsilastirma,
               o[4].karsilastirma, o[5].karsilastirma);
    }
    printf("  b) n × 2 olunca karşılaştırma kaç katına çıktı?\n");
    printf("        n  saldırı  rastgele  tohum h0  taban/alt  taban/üst  "
           "FNV tohum\n");
    const int genislik[6] = {8, 9, 9, 10, 10, 10};
    for (int k = 9; k <= (int)k_ust; k++) {
        printf("  %7zu", (size_t)1 << k);
        for (int i = 0; i < 6; i++) {
            printf(" %*.2f", genislik[i],
                   (double)sonuc[k][i].karsilastirma /
                       (double)sonuc[k - 1][i].karsilastirma);
        }
        printf("\n");
    }
    printf("  c) dolu kova sayısı / m (en uzun zincir)\n");
    printf("        n        m    saldırı      rastgele     taban/alt     "
           "taban/üst     FNV tohum\n");
    for (int k = 8; k <= (int)k_ust; k++) {
        const Olcum *o = sonuc[k];
        printf("  %7zu %8zu", (size_t)1 << k, o[0].m);
        const int sira[5] = {0, 1, 3, 4, 5};
        for (int i = 0; i < 5; i++) {
            printf(" %6zu (%5zu)", o[sira[i]].dolu, o[sira[i]].en_uzun);
        }
        printf("\n");
    }
    printf("  tohum h0 SAVUNMAZ: h0·31^L eşit uzunluklu her anahtara aynı "
           "eklenir (çakışma yapıdadır).\n");
    printf("  taban/alt: h = h(Aa…Aa) + (taban − 31)·X, X = Σ taban^(2i) "
           "(BB bloklarının i konumlarında);\n   taban − 31 = 2^%d · tek "
           "ve taban² − 1 = 2^%d · tek olduğundan X ≡ BB sayısı (mod 2^%d):"
           "\n   indisin alt bitleri yalnız BB sayısını taşır, birkaç kova "
           "dolar (tablo c) -> karesel büyüme sürer.\n",
           iki_kuvveti(taban - 31u), iki_kuvveti(taban * taban - 1u),
           iki_kuvveti(taban * taban - 1u));
    printf("  taban/üst ve FNV tohum: doğrusal büyüme. Gerçek savunma: "
           "anahtarlı karma (Python: SipHash).\n");
    free(anahtar);
    free(rastgele);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
 * (std::hash<std::string> gerçekleştirime bağlı; libstdc++'ta
 * çalıştırmalar arasında aynı: rastgele tohum yok); Python — dict/set
 * (str ve bytes karması tohumlu SipHash ailesi; PEP 456, Python 3.4+). */

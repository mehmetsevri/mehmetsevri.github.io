/* H10_04_dogrusal_yoklama.c — AP-2 Hafta 10 · Örnek 4 (★★★)
 * Amaç    : Doğrusal yoklamalı açık adresleme (m = 11): yoklama dizisi,
 *           birincil kümelenme; mezar taşıyla silme (arama kopmaz),
 *           mezar taşının yeniden kullanımı; mezar taşlarının etkisi ve
 *           temizleyerek yeniden kurma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_04_dogrusal_yoklama.c ortak_rastgele.c \
 *           -o H10_04_dogrusal_yoklama
 * Çalıştır: ./H10_04_dogrusal_yoklama
 * Eşleri  : cpp/H10_04_dogrusal_yoklama.cpp ·
 *           python/H10_04_dogrusal_yoklama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

enum { BOS = 0, DOLU = 1, MEZAR = 2 };

typedef struct {
    int durum;
    char *anahtar;               /* yalnız DOLU iken: hücrenin kopyası */
    int deger;
} Hucre;

typedef struct {
    Hucre *hucre;
    size_t m;
    size_t dolu;
    size_t mezar;
} Tablo;

static long long yoklama_sayisi = 0;         /* bakılan hücre sayısı */
static size_t yol[64];                       /* son işlemin yoklama yolu */
static int yol_n = 0;

static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

static char *dizgi_kopyala(const char *s)
{
    size_t uzunluk = strlen(s) + 1;
    char *kopya = malloc(uzunluk);
    if (kopya != NULL) {
        memcpy(kopya, s, uzunluk);
    }
    return kopya;
}

/* Sahiplik: dönen tablo çağıranındır; tablo_yok_et ile serbest bırakılır */
static Tablo *tablo_olustur(size_t m)
{
    Tablo *t = malloc(sizeof *t);
    if (t == NULL) {
        return NULL;
    }
    t->hucre = calloc(m, sizeof *t->hucre);   /* hepsi BOS, NULL */
    if (t->hucre == NULL) {
        free(t);
        return NULL;
    }
    t->m = m;
    t->dolu = 0;
    t->mezar = 0;
    return t;
}

static void tablo_yok_et(Tablo *t)
{
    for (size_t i = 0; i < t->m; i++) {
        free(t->hucre[i].anahtar);           /* BOS/MEZAR: NULL */
    }
    free(t->hucre);
    free(t);
}

static size_t ev(const Tablo *t, const char *anahtar)
{
    return karma_fnv1a(anahtar) % t->m;
}

/* Anahtarı arar: bulursa hücre indisi, yoksa -1. *yer: eklenecek hücre —
 * yoldaki İLK mezar taşı, yoksa durulan BOŞ hücre; tablo doluysa -1.
 * Mezar taşı aramayı DURDURMAZ; yalnız BOŞ hücre durdurur. */
static long bul(const Tablo *t, const char *anahtar, long *yer)
{
    size_t i = ev(t, anahtar);
    long ilk_mezar = -1;
    yol_n = 0;
    for (size_t adim = 0; adim < t->m; adim++) {
        yoklama_sayisi++;
        if (yol_n < 64) {
            yol[yol_n++] = i;
        }
        const Hucre *h = &t->hucre[i];
        if (h->durum == BOS) {
            *yer = ilk_mezar >= 0 ? ilk_mezar : (long)i;
            return -1;
        }
        if (h->durum == MEZAR) {
            if (ilk_mezar < 0) {
                ilk_mezar = (long)i;
            }
        } else if (strcmp(h->anahtar, anahtar) == 0) {
            return (long)i;
        }
        i = (i + 1) % t->m;                  /* doğrusal yoklama */
    }
    *yer = ilk_mezar;                        /* BOŞ hücre hiç yok */
    return -1;
}

/* 1: yeni, 0: güncellendi, -1: yer yok ya da bellek yetmedi */
static int tablo_ekle(Tablo *t, const char *anahtar, int deger)
{
    long yer;
    long i = bul(t, anahtar, &yer);
    if (i >= 0) {
        t->hucre[i].deger = deger;
        return 0;
    }
    if (yer < 0) {
        return -1;
    }
    char *kopya = dizgi_kopyala(anahtar);
    if (kopya == NULL) {
        return -1;
    }
    Hucre *h = &t->hucre[yer];
    if (h->durum == MEZAR) {
        t->mezar--;                          /* mezar taşı yeniden kullanıldı */
    }
    h->durum = DOLU;
    h->anahtar = kopya;
    h->deger = deger;
    t->dolu++;
    return 1;
}

static int tablo_ara(const Tablo *t, const char *anahtar, int *deger)
{
    long yer;
    long i = bul(t, anahtar, &yer);
    if (i < 0) {
        return 0;
    }
    *deger = t->hucre[i].deger;
    return 1;
}

/* Silinen hücre BOŞ yapılmaz: MEZAR (Hata Avcısı 3) */
static int tablo_sil(Tablo *t, const char *anahtar)
{
    long yer;
    long i = bul(t, anahtar, &yer);
    if (i < 0) {
        return 0;
    }
    free(t->hucre[i].anahtar);
    t->hucre[i].anahtar = NULL;
    t->hucre[i].durum = MEZAR;
    t->dolu--;
    t->mezar++;
    return 1;
}

/* Mezar taşlarını temizler: DOLU hücreler aynı m ile yeni diziye yeniden
 * yerleştirilir (anahtar dizgileri taşınır, kopyalanmaz). -1: bellek. */
static int yeniden_kur(Tablo *t)
{
    Hucre *eski = t->hucre;
    t->hucre = calloc(t->m, sizeof *t->hucre);
    if (t->hucre == NULL) {
        t->hucre = eski;
        return -1;
    }
    t->dolu = 0;
    t->mezar = 0;
    for (size_t k = 0; k < t->m; k++) {
        if (eski[k].durum == DOLU) {
            long yer;
            bul(t, eski[k].anahtar, &yer);
            t->hucre[yer] = eski[k];
            t->dolu++;
        }
    }
    free(eski);
    return 0;
}

static void tablo_yaz(const Tablo *t)
{
    printf(" ");
    for (size_t i = 0; i < t->m; i++) {
        const Hucre *h = &t->hucre[i];
        if (h->durum == BOS) {
            printf(" [%zu -]", i);
        } else if (h->durum == MEZAR) {
            printf(" [%zu MEZAR]", i);
        } else {
            printf(" [%zu %s]", i, h->anahtar);
        }
    }
    printf("\n");
}

static void yol_yaz(void)
{
    printf("yoklama");
    for (int k = 0; k < yol_n; k++) {
        printf(" %zu", yol[k]);
    }
    printf(" (%d)", yol_n);
}

/* BOŞ olmayan ardışık hücre öbekleri (dairesel): birincil kümelenme */
static void kumeleri_yaz(const Tablo *t)
{
    size_t bas = 0;
    while (bas < t->m && t->hucre[bas].durum != BOS) {
        bas++;                               /* ilk BOŞ hücre */
    }
    if (bas == t->m) {
        printf("  küme: tablonun tamamı (BOŞ hücre yok)\n");
        return;
    }
    printf("  kümeler:");
    size_t i = (bas + 1) % t->m;
    for (size_t adim = 0; adim < t->m; adim++) {
        if (t->hucre[i].durum != BOS) {
            size_t ilk = i;
            size_t uzunluk = 0;
            while (t->hucre[i].durum != BOS) {
                uzunluk++;
                i = (i + 1) % t->m;
                adim++;
            }
            printf(" [%zu..%zu] %zu hücre;", ilk, (i + t->m - 1) % t->m,
                   uzunluk);
        }
        i = (i + 1) % t->m;
    }
    printf("\n");
}

/* Bölüm 5: rastgele anahtarlarla başarısız/başarılı ortalama yoklama */
static void olc_satiri(const Tablo *t, const char *tur,
                       char (*anahtar)[16], int n)
{
    char tampon[16];
    int deger;
    yoklama_sayisi = 0;
    for (int q = 0; q < 1000; q++) {
        snprintf(tampon, sizeof tampon, "y%u", (unsigned)rastgele_sayi());
        tablo_ara(t, tampon, &deger);
    }
    double basarisiz = yoklama_sayisi / 1000.0;
    yoklama_sayisi = 0;
    for (int i = 0; i < n; i++) {
        tablo_ara(t, anahtar[i], &deger);
    }
    double basarili = (double)yoklama_sayisi / n;
    printf("  %5s %6zu %6zu %10.3f %10.3f %10.3f\n", tur, t->dolu, t->mezar,
           (double)(t->dolu + t->mezar) / t->m, basarili, basarisiz);
}

int main(void)
{
    const char *ad[] = {"ali", "ayşe", "can", "elif", "deniz", "zeynep",
                        "mert", "ece"};
    const int not_[] = {70, 85, 60, 90, 75, 95, 55, 80};
    Tablo *t = tablo_olustur(11);
    if (t == NULL) {
        return 1;
    }

    printf("1) Ekleme: ev = FNV-1a mod 11, dolu hücrede bir sağa "
           "(i + 1) mod m\n");
    for (int k = 0; k < 8; k++) {
        tablo_ekle(t, ad[k], not_[k]);
        printf("  ekle %s: ev %zu, ", ad[k], ev(t, ad[k]));
        yol_yaz();
        printf(" -> hücre %zu\n", yol[yol_n - 1]);
    }
    tablo_yaz(t);
    printf("  dolu = %zu, α = %.3f\n", t->dolu, (double)t->dolu / t->m);
    kumeleri_yaz(t);

    printf("\n2) Mezar taşıyla silme: sil can (hücre 8 -> MEZAR)\n");
    tablo_sil(t, "can");
    tablo_yaz(t);
    const char *aranan[] = {"ece", "mert", "umut", "can"};
    for (int k = 0; k < 4; k++) {
        int deger;
        int var = tablo_ara(t, aranan[k], &deger);
        printf("  ara %s: ev %zu, ", aranan[k], ev(t, aranan[k]));
        yol_yaz();
        if (var) {
            printf(" -> %d\n", deger);
        } else {
            printf(" -> YOK (BOŞ hücrede durdu)\n");
        }
    }
    printf("  (MEZAR aramayı durdurmaz: ece, 8'deki mezar taşını geçerek "
           "bulundu)\n");

    printf("\n3) Mezar taşının yeniden kullanımı: ekle kerem\n");
    tablo_ekle(t, "kerem", 65);
    printf("  ekle kerem: ev %zu, ", ev(t, "kerem"));
    yol_yaz();
    printf(" -> hücre 8 (ilk mezar taşı; yinelenen olmasın diye BOŞ "
           "hücreye kadar arandı)\n");
    tablo_yaz(t);
    printf("  dolu = %zu, mezar = %zu\n", t->dolu, t->mezar);
    tablo_yok_et(t);

    printf("\n4) Mezar taşı birikimi: m = 1024, 512 anahtar; her turda "
           "512 sil + 512 ekle\n");
    printf("  (doluluk = (dolu + mezar) / m; ortalama yoklama: başarılı = "
           "tablodaki 512 anahtar,\n   başarısız = 1000 olmayan anahtar)\n");
    printf("    tur   dolu  mezar   doluluk   başarılı  başarısız\n");
    rastgele_tohum(42);
    Tablo *b = tablo_olustur(1024);
    char (*anahtar)[16] = malloc(512 * sizeof *anahtar);
    if (b == NULL || anahtar == NULL) {
        return 1;
    }
    for (int i = 0; i < 512; i++) {
        do {
            snprintf(anahtar[i], 16, "a%u", (unsigned)rastgele_sayi());
        } while (tablo_ekle(b, anahtar[i], i) != 1);
    }
    olc_satiri(b, "0", anahtar, 512);
    for (int tur = 1; tur <= 6; tur++) {
        for (int k = 0; k < 512; k++) {
            int s = rastgele_aralik(0, 511);
            tablo_sil(b, anahtar[s]);
            do {
                snprintf(anahtar[s], 16, "a%u", (unsigned)rastgele_sayi());
            } while (tablo_ekle(b, anahtar[s], k) != 1);
        }
        char etiket[8];
        snprintf(etiket, sizeof etiket, "%d", tur);
        olc_satiri(b, etiket, anahtar, 512);
    }
    if (yeniden_kur(b) != 0) {
        return 1;
    }
    olc_satiri(b, "kurma", anahtar, 512);
    printf("  (kurma: 6. turdan sonra yeniden kurma — mezar taşları "
           "temizlendi, aynı m)\n");
    tablo_yok_et(b);
    free(anahtar);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — standart kütüphanede açık
 * adresleme yok (std::unordered_map libstdc++'ta zincirlemedir);
 * Python — dict (CPython: açık adresleme; silinen yuva "dummy" olarak
 * işaretlenir = mezar taşı). */

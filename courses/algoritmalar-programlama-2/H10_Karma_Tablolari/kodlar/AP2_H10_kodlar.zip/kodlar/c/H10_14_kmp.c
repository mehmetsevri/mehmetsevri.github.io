/* H10_14_kmp.c — AP-2 Hafta 10 · Örnek 14 (★★★, merak)
 * Amaç    : Knuth–Morris–Pratt: önek fonksiyonu π (desenin her önekinin
 *           hem öneki hem soneki olan en uzun özdeş parçası); metinde geri
 *           gitmeden eşleme, Θ(n + m) karşılaştırma; naif ve Rabin–Karp ile
 *           aynı konumlar; kâhin: strstr döngüsü
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_14_kmp.c ortak_rastgele.c -o H10_14_kmp
 * Çalıştır: ./H10_14_kmp
 * Eşleri  : cpp/H10_14_kmp.cpp · python/H10_14_kmp.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : karşılaştırma sayısı ≤ 2n: her metin karakteri için bir başarılı
 *           ya da q = 0'daki karşılaştırma + q'yu azaltan (toplamda en çok
 *           n kez artmış olan) düşüşler
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define EN_COK 10

static long long karsilastirma_sayisi = 0;
static int iz_ac = 0;            /* bölüm 2: her metin karakterini yaz */

static int esit_mi(char a, char b)
{
    karsilastirma_sayisi++;
    return a == b;
}

/* pi[q] = p[0..q]'nun hem öneki hem soneki olan en uzun (kendisinden
 * kısa) parçanın uzunluğu. Θ(m) karşılaştırma (en çok 2m) */
static void onek_fonksiyonu(const char *p, size_t m, size_t *pi)
{
    size_t k = 0;
    pi[0] = 0;
    for (size_t q = 1; q < m; q++) {
        for (;;) {
            if (esit_mi(p[k], p[q])) {
                k++;
                break;
            }
            if (k == 0) {
                break;
            }
            k = pi[k - 1];               /* daha kısa sınıra düş */
        }
        pi[q] = k;
    }
}

/* t'de p'nin tüm konumları; i hiç geri gitmez. Eşleşme sayısını döndürür */
static size_t kmp_ara(const char *t, size_t n, const char *p, size_t m,
                      const size_t *pi, size_t *konum)
{
    size_t q = 0;                        /* eşleşmiş önek uzunluğu */
    size_t say = 0;
    for (size_t i = 0; i < n; i++) {
        size_t q_once = q;
        char dusus[64] = "";
        size_t u = 0;
        for (;;) {                       /* her adımda 1 karşılaştırma */
            if (esit_mi(p[q], t[i])) {
                q++;
                break;
            }
            if (q == 0) {
                break;
            }
            q = pi[q - 1];               /* metinde geri gitmeden kay */
            if (iz_ac && u + 8 < sizeof dusus) {
                u += (size_t)snprintf(dusus + u, sizeof dusus - u, " -> %zu",
                                      q);
            }
        }
        if (iz_ac) {
            printf("  %2zu    %c  %5zu%-16s %5zu", i, t[i], q_once, dusus, q);
        }
        if (q == m) {
            if (say < EN_COK) {
                konum[say] = i + 1 - m;
            }
            say++;
            if (iz_ac) {
                printf("   EŞLEŞME: kayma s = %zu", i + 1 - m);
            }
            q = pi[q - 1];               /* çakışan eşleşmeler için */
        }
        if (iz_ac) {
            printf("\n");
        }
    }
    return say;
}

static size_t naif_ara(const char *t, size_t n, const char *p, size_t m,
                       size_t *konum)
{
    size_t say = 0;
    for (size_t s = 0; s + m <= n; s++) {
        size_t j = 0;
        while (j < m && esit_mi(t[s + j], p[j])) {
            j++;
        }
        if (j == m) {
            if (say < EN_COK) {
                konum[say] = s;
            }
            say++;
        }
    }
    return say;
}

/* Rabin–Karp (Örnek 12; d = 256, q = 1000003): yalnız konumlar için */
static size_t rk_ara(const char *t, size_t n, const char *p, size_t m,
                     size_t *konum)
{
    const long long d = 256;
    const long long q = 1000003;
    long long h = 1;
    long long hp = 0;
    long long ht = 0;
    size_t say = 0;
    for (size_t i = 1; i < m; i++) {
        h = h * d % q;
    }
    for (size_t i = 0; i < m; i++) {
        hp = (d * hp + (unsigned char)p[i]) % q;
        ht = (d * ht + (unsigned char)t[i]) % q;
    }
    for (size_t s = 0;; s++) {
        if (hp == ht && memcmp(t + s, p, m) == 0) {
            if (say < EN_COK) {
                konum[say] = s;
            }
            say++;
        }
        if (s + m >= n) {
            break;
        }
        ht = (d * (ht + q - (unsigned char)t[s] * h % q) +
              (unsigned char)t[s + m]) % q;
    }
    return say;
}

/* Kâhin: strstr döngüsü (çakışan eşleşmeler dahil) */
static size_t kahin_ara(const char *t, const char *p, size_t *konum)
{
    size_t say = 0;
    for (const char *q = strstr(t, p); q != NULL; q = strstr(q + 1, p)) {
        if (say < EN_COK) {
            konum[say] = (size_t)(q - t);
        }
        say++;
    }
    return say;
}

static int ayni_mi(const size_t *a, size_t na, const size_t *b, size_t nb)
{
    if (na != nb) {
        return 0;
    }
    for (size_t i = 0; i < na && i < EN_COK; i++) {
        if (a[i] != b[i]) {
            return 0;
        }
    }
    return 1;
}

static void karsilastir(const char *ad, const char *t, size_t n,
                        const char *p, size_t m)
{
    size_t *pi = malloc(m * sizeof *pi);
    size_t k1[EN_COK], k2[EN_COK], k3[EN_COK], k4[EN_COK];
    if (pi == NULL) {
        exit(1);
    }
    karsilastirma_sayisi = 0;
    onek_fonksiyonu(p, m, pi);
    long long k_pi = karsilastirma_sayisi;
    karsilastirma_sayisi = 0;
    size_t s1 = kmp_ara(t, n, p, m, pi, k1);
    long long k_kmp = karsilastirma_sayisi;
    karsilastirma_sayisi = 0;
    size_t s2 = naif_ara(t, n, p, m, k2);
    long long k_naif = karsilastirma_sayisi;
    size_t s3 = kahin_ara(t, p, k3);
    size_t s4 = rk_ara(t, n, p, m, k4);
    printf("  %s: n = %zu, m = %zu, eşleşme = %zu\n", ad, n, m, s1);
    printf("    karşılaştırma: π = %lld (≤ 2m = %zu), KMP = %lld (≤ 2n = %zu)"
           ", naif = %lld\n", k_pi, 2 * m, k_kmp, 2 * n, k_naif);
    printf("    konumlar:");
    for (size_t i = 0; i < s1 && i < EN_COK; i++) {
        printf(" %zu", k1[i]);
    }
    printf("%s\n    naif ile aynı mı? %s; Rabin–Karp ile? %s; kâhin (strstr) "
           "ile? %s\n", s1 > EN_COK ? " …" : "",
           ayni_mi(k1, s1, k2, s2) ? "evet" : "HAYIR",
           ayni_mi(k1, s1, k4, s4) ? "evet" : "HAYIR",
           ayni_mi(k1, s1, k3, s3) ? "evet" : "HAYIR");
    free(pi);
}

int main(void)
{
    const char *P = "ababaca";
    size_t m = strlen(P);
    size_t pi[16];
    onek_fonksiyonu(P, m, pi);
    printf("1) Önek fonksiyonu: P = %s\n", P);
    printf("     q:");
    for (size_t q = 0; q < m; q++) {
        printf(" %zu", q + 1);
    }
    printf("\n  P[q]:");
    for (size_t q = 0; q < m; q++) {
        printf(" %c", P[q]);
    }
    printf("\n  π[q]:");
    for (size_t q = 0; q < m; q++) {
        printf(" %zu", pi[q]);
    }
    printf("\n  (ör. π[5] = 3: \"ababa\"nın hem öneki hem soneki olan en uzun "
           "parça \"aba\")\n");

    printf("\n2) Eşleme izi: T = bacbabababacaab (q: eşleşmiş önek; ->: "
           "uyuşmazlıkta q = π[q])\n");
    printf("   i  T[i]  q önce  düşüşler        q sonra\n");
    const char *T = "bacbabababacaab";
    size_t konum[EN_COK];
    iz_ac = 1;
    kmp_ara(T, strlen(T), P, m, pi, konum);
    iz_ac = 0;

    printf("\n3) Karşılaştırma sayıları: KMP, naif; kâhinle konumlar\n");
    karsilastir("T = bacbabababacaab", T, strlen(T), P, m);
    size_t N = 100000;
    char *metin = malloc(N + 1);
    if (metin == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    for (size_t i = 0; i < N; i++) {
        metin[i] = (char)('a' + rastgele_aralik(0, 3));
    }
    metin[N] = '\0';
    char desen[101];
    memcpy(desen, metin + 50000, 8);
    desen[8] = '\0';
    karsilastir("rastgele {a,b,c,d}, desen = metin[50000..50007]", metin, N,
                desen, 8);
    memset(metin, 'a', 10000);
    metin[10000] = '\0';
    memset(desen, 'a', 99);
    desen[99] = 'b';
    desen[100] = '\0';
    karsilastir("en kötü (naif için): a^10000, a^99 b", metin, 10000, desen,
                100);
    desen[99] = 'a';
    karsilastir("her kayma eşleşir: a^10000, a^100", metin, 10000, desen,
                100);
    free(metin);
    return 0;
}

/* Kütüphane karşılığı: C — strstr; C++ — std::string::find, std::search
 * (C++17: std::boyer_moore_searcher); Python — bytes.find / str.find
 * (KMP standart kütüphanelerde ayrıca sunulmaz). */

/* H10_01_dogrudan_adresleme.c — AP-2 Hafta 10 · Örnek 1 (★)
 * Amaç    : Doğrudan adresleme: anahtar = indis (0–99 numaralı öğrenci
 *           tablosu); ekle/ara/sil tek erişimde; anahtar evreni büyüyünce
 *           bellek hesabı ve karma fonksiyonuna köprü (k mod 101)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_01_dogrudan_adresleme.c -o H10_01_dogrudan_adresleme
 * Çalıştır: ./H10_01_dogrudan_adresleme
 * Eşleri  : cpp/H10_01_dogrudan_adresleme.cpp ·
 *           python/H10_01_dogrudan_adresleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>

#define EVREN 100            /* anahtar evreni: 0 .. 99 */
#define HUCRE_BAYT 8         /* bir hücre = bir işaretçi (x86-64 LP64) */

static long long erisim_sayisi = 0;

/* Hücre NULL ise boştur; dolu hücre adın (dizgi değişmezi) adresini tutar */
static const char *tablo[EVREN];

static int gecerli_mi(int no) { return no >= 0 && no < EVREN; }

static void ekle(int no, const char *ad)
{
    erisim_sayisi++;
    tablo[no] = ad;              /* anahtar = indis: arama yok */
}

static const char *ara(int no)
{
    erisim_sayisi++;
    return tablo[no];
}

static void sil(int no)
{
    erisim_sayisi++;
    tablo[no] = NULL;
}

static void tablo_ciz(void)
{
    printf("     ");
    for (int s = 0; s < 10; s++) {
        printf(" %2d", s);
    }
    printf("\n");
    for (int r = 0; r < 10; r++) {
        printf("  %d0 ", r);
        for (int s = 0; s < 10; s++) {
            int no = 10 * r + s;
            if (tablo[no] == NULL) {
                printf(" --");
            } else {
                printf(" %02d", no);
            }
        }
        printf("\n");
    }
}

static void sorgula(int no)
{
    if (!gecerli_mi(no)) {
        printf("  ara(%d): geçersiz anahtar (evren 0..%d)\n", no, EVREN - 1);
        return;
    }
    long long once = erisim_sayisi;
    const char *ad = ara(no);
    printf("  ara(%d): %s  [erişim = %lld]\n", no, ad ? ad : "boş",
           erisim_sayisi - once);
}

static void bellek_satiri(const char *aciklama, unsigned long long evren,
                          unsigned long long kayit)
{
    unsigned long long bayt = evren * HUCRE_BAYT;
    double doluluk = 100.0 * (double)kayit / (double)evren;
    printf("  %14llu %6llu %16llu %12.3f %12.6f  %s\n", evren, kayit, bayt,
           (double)bayt / 1e9, doluluk, aciklama);
}

int main(void)
{
    const int numara[] = {7, 23, 42, 64, 99, 0};
    const char *ad[] = {"Ayşe Yılmaz", "Mehmet Kaya", "Zeynep Demir",
                        "Ali Çelik", "Elif Şahin", "Can Öztürk"};
    const int k = 6;

    printf("1) Doğrudan adresleme: 0..99 numaralı öğrenciler, "
           "anahtar = indis\n");
    for (int i = 0; i < k; i++) {
        ekle(numara[i], ad[i]);
        printf("  ekle(%d, \"%s\") -> tablo[%d]\n", numara[i], ad[i],
               numara[i]);
    }
    printf("\n  Tablo (100 hücre; \"--\" boş, sayı = dolu hücrenin "
           "numarası)\n");
    tablo_ciz();

    printf("\n2) Arama ve silme: her işlem tek erişim, Θ(1)\n");
    sorgula(42);
    sorgula(50);
    sil(42);
    printf("  sil(42)\n");
    sorgula(42);
    sorgula(150);
    printf("  toplam erişim: %lld (%d ekleme + 3 arama + 1 silme; "
           "ara(150) tabloya erişmez)\n", erisim_sayisi, k);
    int dolu = 0;
    for (int no = 0; no < EVREN; no++) {
        dolu += tablo[no] != NULL;
    }
    printf("  dolu hücre: %d / %d\n", dolu, EVREN);

    printf("\n3) Anahtar evreni büyüyünce bellek (hücre = %d bayt)\n",
           HUCRE_BAYT);
    printf("         evren U  kayıt    bellek (bayt)  bellek (GB)  "
           "doluluk (%%)  anahtar\n");
    bellek_satiri("sınıf sıra no (0..99)", 100ull, (unsigned long long)dolu);
    bellek_satiri("4 haneli no (0..9999)", 10000ull, 5000ull);
    bellek_satiri("9 haneli öğrenci no", 1000000000ull, 5000ull);
    bellek_satiri("32 bit tamsayı (2^32)", 4294967296ull, 5000ull);

    printf("\n4) Köprü: 9 haneli numara -> h(k) = k mod 101 (101 hücre)\n");
    const unsigned long long uzun_no[] = {240101007ull, 240101023ull,
                                          240101042ull, 240101064ull,
                                          240101099ull, 240101108ull};
    for (int i = 0; i < k; i++) {
        printf("  %llu mod 101 = %3llu\n", uzun_no[i], uzun_no[i] % 101ull);
    }
    printf("  (çakışma: farklı anahtarlar aynı hücreye düşebilir -> "
           "Örnek 3, 4)\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (dizi; tamsayı anahtarlı küçük evrende
 * doğrudan adresleme); C++ — std::array/std::vector (anahtar = indis);
 * Python — liste [None] * 100 (anahtar = indis). */

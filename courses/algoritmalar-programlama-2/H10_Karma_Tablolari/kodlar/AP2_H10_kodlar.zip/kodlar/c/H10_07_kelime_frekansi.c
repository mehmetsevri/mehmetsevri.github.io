/* H10_07_kelime_frekansi.c — AP-2 Hafta 10 · Örnek 7 (★★)
 * Amaç    : Metindeki sözcüklerin sıklığı: bayt düzeyinde sözcük ayırma,
 *           ASCII küçük harf dönüşümü elle (A–Z → +32), UTF-8 Türkçe harfler
 *           (bayt ≥ 0x80) olduğu gibi ve harf sayılır; zincirleme karma
 *           tablosu (α > 1 olunca × 2); en sık 20 sözcük (sıralı çıktı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_07_kelime_frekansi.c zamanlayici.c -o H10_07_kelime_frekansi
 * Çalıştır: ./H10_07_kelime_frekansi \
 *           < ../girdiler/H10_07_kelime_frekansi.txt
 * Eşleri  : cpp/H10_07_kelime_frekansi.cpp ·
 *           python/H10_07_kelime_frekansi.py
 * Çıktı   : üç dilde aynı (=); süre stderr'e
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "zamanlayici.h"

typedef struct Dugum {
    char *anahtar;               /* sahiplik: düğümündür (kopya) */
    int deger;                   /* sıklık */
    struct Dugum *sonraki;
} Dugum;

typedef struct {
    Dugum **kova;
    size_t m;                    /* 2'nin kuvveti: indis = h & (m - 1) */
    size_t n;
} Tablo;

static long long tasinan_dugum = 0;

static uint32_t karma_fnv1a(const char *s)
{
    uint32_t h = 2166136261u;
    for (; *s != '\0'; s++) {
        h ^= (unsigned char)*s;
        h *= 16777619u;
    }
    return h;
}

static char *dizgi_kopyala(const char *s)
{
    size_t uzunluk = strlen(s) + 1;
    char *kopya = malloc(uzunluk);
    if (kopya != NULL) {
        memcpy(kopya, s, uzunluk);
    }
    return kopya;
}

/* Sahiplik: dönen tablo çağıranındır; tablo_yok_et ile serbest bırakılır */
static Tablo *tablo_olustur(size_t m)
{
    Tablo *t = malloc(sizeof *t);
    if (t == NULL) {
        return NULL;
    }
    t->kova = calloc(m, sizeof *t->kova);
    if (t->kova == NULL) {
        free(t);
        return NULL;
    }
    t->m = m;
    t->n = 0;
    return t;
}

static void tablo_yok_et(Tablo *t)
{
    for (size_t j = 0; j < t->m; j++) {
        Dugum *d = t->kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            free(d->anahtar);
            free(d);
            d = sonraki;
        }
    }
    free(t->kova);
    free(t);
}

/* α > 1: kova dizisi × 2; düğümler yeni kovalarına bağlanır (ayırma yok) */
static int buyut(Tablo *t)
{
    size_t yeni_m = 2 * t->m;
    Dugum **yeni = calloc(yeni_m, sizeof *yeni);
    if (yeni == NULL) {
        return -1;
    }
    for (size_t j = 0; j < t->m; j++) {
        Dugum *d = t->kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            size_t k = karma_fnv1a(d->anahtar) & (yeni_m - 1);
            d->sonraki = yeni[k];
            yeni[k] = d;
            tasinan_dugum++;
            d = sonraki;
        }
    }
    free(t->kova);
    t->kova = yeni;
    t->m = yeni_m;
    return 0;
}

/* Sözcüğün sıklığını 1 artırır (yoksa 1 ile ekler). -1: bellek */
static int say(Tablo *t, const char *sozcuk)
{
    size_t j = karma_fnv1a(sozcuk) & (t->m - 1);
    for (Dugum *d = t->kova[j]; d != NULL; d = d->sonraki) {
        if (strcmp(d->anahtar, sozcuk) == 0) {
            d->deger++;
            return 0;
        }
    }
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return -1;
    }
    d->anahtar = dizgi_kopyala(sozcuk);
    if (d->anahtar == NULL) {
        free(d);
        return -1;
    }
    d->deger = 1;
    d->sonraki = t->kova[j];
    t->kova[j] = d;
    t->n++;
    if (t->n > t->m) {
        return buyut(t);
    }
    return 0;
}

/* Harf: ASCII A–Z, a–z ya da UTF-8 çok baytlı karakterin baytı (≥ 0x80) */
static int harf_mi(unsigned char b)
{
    return (b >= 'A' && b <= 'Z') || (b >= 'a' && b <= 'z') || b >= 0x80;
}

/* Çıktı biçimi için sıralama (kâhin değil): sıklık azalan, bayt artan */
static int siklik_sirasi(const void *a, const void *b)
{
    const Dugum *x = *(const Dugum *const *)a;
    const Dugum *y = *(const Dugum *const *)b;
    if (x->deger != y->deger) {
        return x->deger < y->deger ? 1 : -1;
    }
    return strcmp(x->anahtar, y->anahtar);   /* unsigned char sırası */
}

/* Tüm stdin'i dinamik tampona okur (kapasite × 2). Sahiplik: çağıranın */
static unsigned char *hepsini_oku(size_t *boyut)
{
    size_t kapasite = 4096;
    size_t n = 0;
    unsigned char *tampon = malloc(kapasite);
    if (tampon == NULL) {
        return NULL;
    }
    size_t okunan;
    while ((okunan = fread(tampon + n, 1, kapasite - n, stdin)) > 0) {
        n += okunan;
        if (n == kapasite) {
            unsigned char *yeni = realloc(tampon, 2 * kapasite);
            if (yeni == NULL) {
                free(tampon);
                return NULL;
            }
            tampon = yeni;
            kapasite *= 2;
        }
    }
    *boyut = n;
    return tampon;
}

int main(void)
{
    double t0 = zaman_sn();
    size_t boyut;
    unsigned char *metin = hepsini_oku(&boyut);
    Tablo *t = tablo_olustur(16);
    if (metin == NULL || t == NULL) {
        return 1;
    }
    char sozcuk[256];
    size_t uzunluk = 0;
    long long toplam = 0;
    for (size_t i = 0; i <= boyut; i++) {
        unsigned char b = i < boyut ? metin[i] : ' ';
        if (harf_mi(b)) {
            if (uzunluk < sizeof sozcuk - 1) {
                sozcuk[uzunluk++] =
                    (char)(b >= 'A' && b <= 'Z' ? b + 32 : b);
            }
        } else if (uzunluk > 0) {
            sozcuk[uzunluk] = '\0';
            if (say(t, sozcuk) != 0) {
                return 1;
            }
            toplam++;
            uzunluk = 0;
        }
    }
    free(metin);

    Dugum **liste = malloc(t->n * sizeof *liste);
    if (liste == NULL) {
        return 1;
    }
    size_t k = 0;
    size_t en_uzun = 0;
    for (size_t j = 0; j < t->m; j++) {
        size_t u = 0;
        for (Dugum *d = t->kova[j]; d != NULL; d = d->sonraki) {
            liste[k++] = d;
            u++;
        }
        if (u > en_uzun) {
            en_uzun = u;
        }
    }
    qsort(liste, t->n, sizeof *liste, siklik_sirasi);

    printf("Girdi: %zu bayt; sözcük = harf baytlarının en uzun dizisi\n",
           boyut);
    printf("toplam sözcük = %lld, farklı sözcük = %zu\n", toplam, t->n);
    printf("karma tablosu: m = %zu kova, α = %.3f, en uzun zincir = %zu, "
           "büyütmede taşınan düğüm = %lld\n", t->m, (double)t->n / t->m,
           en_uzun, tasinan_dugum);
    printf("\nEn sık 20 sözcük (sıklık azalan; eşitlikte bayt sırası "
           "artan)\n");
    for (size_t r = 0; r < 20 && r < t->n; r++) {
        printf("  %2zu. %5d  %s\n", r + 1, liste[r]->deger,
               liste[r]->anahtar);
    }
    int tr_buyuk = 0;
    for (size_t r = 0; r < t->n; r++) {
        const unsigned char *s = (const unsigned char *)liste[r]->anahtar;
        int c3 = s[0] == 0xC3 && (s[1] == 0x87 || s[1] == 0x96 ||
                                  s[1] == 0x9C);          /* Ç Ö Ü */
        int c4 = s[0] == 0xC4 && (s[1] == 0x9E || s[1] == 0xB0); /* Ğ İ */
        int c5 = s[0] == 0xC5 && s[1] == 0x9E;               /* Ş */
        tr_buyuk += c3 || c4 || c5;
    }
    printf("\nTürkçe büyük harfle (Ç Ğ İ Ö Ş Ü) başlayan farklı sözcük: %d "
           "(ASCII dışı harfler küçültülmedi)\n", tr_buyuk);
    free(liste);
    tablo_yok_et(t);
    fprintf(stderr, "süre (okuma + sayma + sıralama): %.3f ms\n",
            (zaman_sn() - t0) * 1e3);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle; sıralama için qsort çıktı
 * biçimidir); C++ — std::unordered_map<std::string, int> + std::sort;
 * Python — collections.Counter(...).most_common(20) ya da dict. */

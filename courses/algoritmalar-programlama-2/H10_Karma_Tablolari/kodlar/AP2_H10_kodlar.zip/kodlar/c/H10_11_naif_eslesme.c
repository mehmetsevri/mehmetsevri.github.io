/* H10_11_naif_eslesme.c — AP-2 Hafta 10 · Örnek 11 (★)
 * Amaç    : Naif (kaba kuvvet) desen eşleme: her kayma s için deseni
 *           soldan sağa karşılaştır; karşılaştırma sayacı; rastgele metinde
 *           ≈ n, en kötü durumda (aaaa…a / aa…ab) (n − m + 1)·m;
 *           kâhin: strstr döngüsü
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_11_naif_eslesme.c ortak_rastgele.c -o H10_11_naif_eslesme
 * Çalıştır: ./H10_11_naif_eslesme
 * Eşleri  : cpp/H10_11_naif_eslesme.cpp · python/H10_11_naif_eslesme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define EN_COK 10                /* yazdırılacak en çok konum */

static long long karsilastirma_sayisi = 0;

/* t[0..n-1] içinde p[0..m-1]'in tüm konumları; eşleşme sayısını döndürür,
 * ilk EN_COK konumu konum[]'a yazar */
static size_t naif_ara(const char *t, size_t n, const char *p, size_t m,
                       size_t *konum)
{
    size_t say = 0;
    if (m == 0 || m > n) {
        return 0;
    }
    for (size_t s = 0; s + m <= n; s++) {    /* s: kayma (shift) */
        size_t j = 0;
        while (j < m) {
            karsilastirma_sayisi++;
            if (t[s + j] != p[j]) {
                break;                       /* ilk uyuşmazlıkta bırak */
            }
            j++;
        }
        if (j == m) {
            if (say < EN_COK) {
                konum[say] = s;
            }
            say++;
        }
    }
    return say;
}

/* Kâhin: strstr ile aynı konumlar (çakışan eşleşmeler dahil) */
static size_t kahin_ara(const char *t, const char *p, size_t *konum)
{
    size_t say = 0;
    const char *bas = t;
    const char *q;
    while ((q = strstr(bas, p)) != NULL) {
        if (say < EN_COK) {
            konum[say] = (size_t)(q - t);
        }
        say++;
        bas = q + 1;
    }
    return say;
}

/* UTF-8: devam baytları 10xxxxxx'tir; karakter = devam olmayan bayt */
static size_t karakter_konumu(const char *t, size_t bayt)
{
    size_t c = 0;
    for (size_t i = 0; i < bayt; i++) {
        c += ((unsigned char)t[i] & 0xC0) != 0x80;
    }
    return c;
}

static void sinama(const char *ad, const char *t, size_t n, const char *p,
                   size_t m)
{
    size_t k1[EN_COK];
    size_t k2[EN_COK];
    karsilastirma_sayisi = 0;
    size_t s1 = naif_ara(t, n, p, m, k1);
    size_t s2 = kahin_ara(t, p, k2);
    int ayni = s1 == s2;
    for (size_t i = 0; i < s1 && i < EN_COK && ayni; i++) {
        ayni = k1[i] == k2[i];
    }
    long long kayma = (long long)(n - m + 1);
    printf("  %s: n = %zu, m = %zu, eşleşme = %zu, karşılaştırma = %lld "
           "(kayma başına %.3f), kâhinle aynı mı? %s\n", ad, n, m, s1,
           karsilastirma_sayisi, (double)karsilastirma_sayisi / kayma,
           ayni ? "evet" : "HAYIR");
    printf("    konumlar:");
    for (size_t i = 0; i < s1 && i < EN_COK; i++) {
        printf(" %zu", k1[i]);
    }
    printf(s1 > EN_COK ? " …\n" : "\n");
}

int main(void)
{
    printf("1) Küçük örnek: t = \"abracadabra\", p = \"abra\"\n");
    const char *t = "abracadabra";
    const char *p = "abra";
    size_t n = strlen(t);
    size_t m = strlen(p);
    for (size_t s = 0; s + m <= n; s++) {
        size_t j = 0;
        while (j < m && t[s + j] == p[j]) {
            j++;
        }
        printf("  s = %zu: %.*s  ", s, (int)m, t + s);
        if (j == m) {
            printf("EŞLEŞME (%zu karşılaştırma)\n", m);
        } else {
            printf("uyuşmazlık (j = %zu; %zu karşılaştırma)\n", j, j + 1);
        }
    }
    sinama("abracadabra", t, n, p, m);

    printf("\n2) Bayt düzeyinde: konum karakter değil BAYT sayısıdır\n");
    const char *tr = "Koca Ali, kılıç ustası Ali'ydi.";
    sinama("Türkçe tümce", tr, strlen(tr), "Ali", 3);
    size_t k[EN_COK];
    size_t say = naif_ara(tr, strlen(tr), "Ali", 3, k);
    for (size_t i = 0; i < say && i < EN_COK; i++) {
        printf("    bayt %2zu = karakter %2zu\n", k[i], karakter_konumu(tr,
               k[i]));
    }
    printf("    (\"kılıç\" 5 harf ama %zu bayt: ı ve ç UTF-8'de ikişer "
           "bayt)\n", strlen("kılıç"));

    printf("\n3) Rastgele metin (abece {a, b, c, d}, tohum 42) ve en kötü "
           "durum\n");
    size_t N = 100000;
    char *metin = malloc(N + 1);
    if (metin == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    for (size_t i = 0; i < N; i++) {
        metin[i] = (char)('a' + rastgele_aralik(0, 3));
    }
    metin[N] = '\0';
    char desen[101];
    memcpy(desen, metin + 50000, 8);         /* metinden alınmış desen */
    desen[8] = '\0';
    sinama("rastgele, m = 8", metin, N, desen, 8);
    memcpy(desen, metin + 70000, 3);
    desen[3] = '\0';
    sinama("rastgele, m = 3", metin, N, desen, 3);

    size_t N2 = 10000;
    memset(metin, 'a', N2);
    metin[N2] = '\0';
    memset(desen, 'a', 99);
    desen[99] = 'b';
    desen[100] = '\0';
    sinama("en kötü: a^n, a^99 b", metin, N2, desen, 100);
    desen[99] = 'a';
    sinama("en kötü: a^n, a^100", metin, N2, desen, 100);
    printf("  (en kötü durumda karşılaştırma = (n − m + 1)·m = %zu; "
           "rastgele metinde ≈ 4/3 · kayma)\n", (N2 - 100 + 1) * 100);
    free(metin);
    return 0;
}

/* Kütüphane karşılığı: C — strstr (<string.h>; algoritması
 * gerçekleştirime bağlı); C++ — std::string::find, std::search
 * (C++17: std::boyer_moore_searcher); Python — str.find / bytes.find,
 * in işleci. */

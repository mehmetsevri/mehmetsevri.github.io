/* H10_05_yuk_faktoru.c — AP-2 Hafta 10 · Örnek 5 (★★)
 * Amaç    : Yük faktörü deneyi: α = 0,25 … 0,95 için ayrı zincirleme ve
 *           doğrusal yoklamada başarılı/başarısız aramanın ortalama
 *           yoklama sayısı; kuramsal değerlerle (Knuth, 1998) karşılaştırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H10_05_yuk_faktoru.c ortak_rastgele.c -o H10_05_yuk_faktoru
 * Çalıştır: ./H10_05_yuk_faktoru [p] [tohum]     (m = 2^p, varsayılan
 *           p = 13, tohum = 42)
 * Eşleri  : cpp/H10_05_yuk_faktoru.cpp · python/H10_05_yuk_faktoru.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct Dugum {
    uint32_t anahtar;
    struct Dugum *sonraki;
} Dugum;

static long long yoklama_sayisi = 0;

/* Çarpma yöntemi (Knuth): A = ⌊2^32 / φ⌋; indis = (k·A mod 2^32) >> (32-p).
 * Üst bitler alınır: düşük bitleri kötü anahtarlarda da dağıtır. */
static uint32_t karma_carpma(uint32_t k, int p)
{
    return (k * 2654435769u) >> (32 - p);
}

/* --- doğrusal yoklama: anahtar dizisi + dolu bayrağı (bitişik bellek) */
static int dy_ekle(uint32_t *anahtar, unsigned char *dolu, int p,
                   uint32_t k)
{
    uint32_t maske = (1u << p) - 1u;
    uint32_t i = karma_carpma(k, p);
    while (dolu[i]) {
        if (anahtar[i] == k) {
            return 0;                        /* zaten var */
        }
        i = (i + 1u) & maske;                /* m = 2^p: mod yerine maske */
    }
    dolu[i] = 1;
    anahtar[i] = k;
    return 1;
}

static int dy_ara(const uint32_t *anahtar, const unsigned char *dolu, int p,
                  uint32_t k)
{
    uint32_t maske = (1u << p) - 1u;
    uint32_t i = karma_carpma(k, p);
    for (;;) {
        yoklama_sayisi++;                    /* bakılan her hücre */
        if (!dolu[i]) {
            return 0;
        }
        if (anahtar[i] == k) {
            return 1;
        }
        i = (i + 1u) & maske;
    }
}

/* --- ayrı zincirleme: kova başları + dağınık düğümler */
static int zc_ekle(Dugum **kova, int p, uint32_t k)
{
    Dugum *d = malloc(sizeof *d);
    if (d == NULL) {
        return -1;
    }
    uint32_t j = karma_carpma(k, p);
    d->anahtar = k;
    d->sonraki = kova[j];                    /* başa ekle */
    kova[j] = d;
    return 1;
}

static int zc_ara(Dugum *const *kova, int p, uint32_t k)
{
    for (const Dugum *d = kova[karma_carpma(k, p)]; d != NULL;
         d = d->sonraki) {
        yoklama_sayisi++;                    /* bakılan her düğüm */
        if (d->anahtar == k) {
            return 1;
        }
    }
    return 0;
}

static void zc_yok_et(Dugum **kova, size_t m)
{
    for (size_t j = 0; j < m; j++) {
        Dugum *d = kova[j];
        while (d != NULL) {
            Dugum *sonraki = d->sonraki;
            free(d);
            d = sonraki;
        }
        kova[j] = NULL;
    }
}

static int sayi_oku(const char *s, long alt, long ust, long *x)
{
    char *son;
    long v = strtol(s, &son, 10);
    if (*s == '\0' || *son != '\0' || v < alt || v > ust) {
        return 0;
    }
    *x = v;
    return 1;
}

int main(int argc, char *argv[])
{
    long p = 13;
    long tohum = 42;
    if (argc > 3 || (argc > 1 && !sayi_oku(argv[1], 4, 22, &p)) ||
        (argc > 2 && !sayi_oku(argv[2], 0, 1000000, &tohum))) {
        fprintf(stderr, "kullanım: %s [p (4..22)] [tohum]\n", argv[0]);
        return 2;
    }
    const size_t m = (size_t)1 << p;
    const int alfa_yuzde[] = {25, 35, 45, 55, 65, 75, 85, 90, 95};
    const int sorgu = 4096;                  /* başarısız arama sayısı */
    uint32_t *anahtar = malloc(m * sizeof *anahtar);
    unsigned char *dolu = malloc(m);
    uint32_t *eklenen = malloc(m * sizeof *eklenen);
    Dugum **kova = calloc(m, sizeof *kova);
    if (anahtar == NULL || dolu == NULL || eklenen == NULL || kova == NULL) {
        return 1;
    }

    printf("Yük faktörü deneyi: m = 2^%ld = %zu, tohum = %ld, "
           "karma = çarpma yöntemi (A = 2654435769)\n", p, m, tohum);
    printf("ZS/ZB: zincirleme başarılı/başarısız; DS/DB: doğrusal yoklama\n");
    printf("kuram: ZS = 1 + α/2, ZB = α; DS = ½(1 + 1/(1−α)), "
           "DB = ½(1 + 1/(1−α)²)\n");
    printf("başarısız arama: %d anahtar (üst biti 1: tabloda olamaz)\n\n",
           sorgu);
    printf("     α      n  ZS ölç  ZS kur  ZB ölç  ZB kur   DS ölç   DS kur"
           "    DB ölç    DB kur\n");
    for (size_t a = 0; a < sizeof alfa_yuzde / sizeof alfa_yuzde[0]; a++) {
        size_t n = (size_t)alfa_yuzde[a] * m / 100;
        double alfa = (double)n / m;
        for (size_t i = 0; i < m; i++) {
            dolu[i] = 0;
        }
        rastgele_tohum((uint64_t)tohum + (uint64_t)alfa_yuzde[a]);
        size_t e = 0;
        while (e < n) {
            uint32_t k = rastgele_sayi();    /* 0 .. 2^31 - 1 */
            if (dy_ekle(anahtar, dolu, (int)p, k)) {
                if (zc_ekle(kova, (int)p, k) < 0) {
                    return 1;
                }
                eklenen[e++] = k;
            }
        }
        double olcum[4];
        yoklama_sayisi = 0;
        for (size_t i = 0; i < n; i++) {
            zc_ara(kova, (int)p, eklenen[i]);
        }
        olcum[0] = (double)yoklama_sayisi / n;
        yoklama_sayisi = 0;
        for (size_t i = 0; i < n; i++) {
            dy_ara(anahtar, dolu, (int)p, eklenen[i]);
        }
        olcum[2] = (double)yoklama_sayisi / n;
        long long zb = 0;
        long long db = 0;
        for (int q = 0; q < sorgu; q++) {
            uint32_t k = rastgele_sayi() | 0x80000000u;
            yoklama_sayisi = 0;
            zc_ara(kova, (int)p, k);
            zb += yoklama_sayisi;
            yoklama_sayisi = 0;
            dy_ara(anahtar, dolu, (int)p, k);
            db += yoklama_sayisi;
        }
        olcum[1] = (double)zb / sorgu;
        olcum[3] = (double)db / sorgu;
        double bir_eksi = 1.0 - alfa;
        printf("  %.2f %6zu %7.3f %7.3f %7.3f %7.3f %8.3f %8.3f %9.3f "
               "%9.3f\n", alfa, n, olcum[0], 1.0 + alfa / 2.0, olcum[1],
               alfa, olcum[2], 0.5 * (1.0 + 1.0 / bir_eksi), olcum[3],
               0.5 * (1.0 + 1.0 / (bir_eksi * bir_eksi)));
        zc_yok_et(kova, m);
    }
    free(anahtar);
    free(dolu);
    free(eklenen);
    free(kova);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::unordered_map
 * (load_factor(), max_load_factor(): varsayılan 1,0); Python — dict
 * (CPython: doluluk 2/3'ü geçince büyütür). */

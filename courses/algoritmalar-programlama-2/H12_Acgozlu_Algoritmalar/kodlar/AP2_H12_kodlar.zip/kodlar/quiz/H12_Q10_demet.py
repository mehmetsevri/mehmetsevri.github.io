"""H12_Q10_demet.py — AP-2 Hafta 12 · Quiz sorusu 10
Amaç    : heapq'da (sıklık, Dugum) demetleri: eşit sıklıkta ne olur?
Çalıştır: python3 H12_Q10_demet.py
"""
import heapq


class Dugum:
    def __init__(self, ad):
        self.ad = ad


def dene():
    obek = []
    heapq.heappush(obek, (5, Dugum("a")))
    heapq.heappush(obek, (5, Dugum("b")))
    s, d = heapq.heappop(obek)
    print(s, d.ad)


def main():
    try:
        dene()
    except TypeError as e:
        print("TypeError:", e)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: heapq (sorunun konusu)

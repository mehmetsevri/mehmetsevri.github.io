/* H12_Q05_oncelik_kuyrugu.cpp — AP-2 Hafta 12 · Quiz sorusu 5
 * Amaç    : std::priority_queue + std::greater ile çıkarma sırası
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_Q05_oncelik_kuyrugu.cpp -o H12_Q05_oncelik_kuyrugu
 * Çalıştır: ./H12_Q05_oncelik_kuyrugu
 */
#include <functional>
#include <iostream>
#include <queue>
#include <utility>
#include <vector>

using Cift = std::pair<int, int>;

int main()
{
    std::priority_queue<Cift, std::vector<Cift>, std::greater<Cift>> pq;
    pq.push({3, 1});
    pq.push({1, 5});
    pq.push({3, 0});
    pq.push({2, 2});
    for (int i = 0; i < 2; i++) {
        std::cout << '(' << pq.top().first << ',' << pq.top().second
                  << ") ";
        pq.pop();
    }
    std::cout << '\n';
    return 0;
}

/* Kütüphane karşılığı: std::priority_queue (sorunun konusu) */

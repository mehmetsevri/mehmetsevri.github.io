/* H12_Q08_birlesim_bul.c — AP-2 Hafta 12 · Quiz sorusu 8
 * Amaç    : Saf birleştirme ve yol sıkıştırma: bul(0)'dan sonra ebeveyn
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_Q08_birlesim_bul.c -o H12_Q08_birlesim_bul
 * Çalıştır: ./H12_Q08_birlesim_bul
 */
#include <stdio.h>

#define N 5

static int ebeveyn[N] = {0, 1, 2, 3, 4};

static int bul(int x)
{
    int kok = x;
    while (ebeveyn[kok] != kok) {
        kok = ebeveyn[kok];
    }
    while (ebeveyn[x] != kok) {          /* yol sıkıştırma */
        int sonraki = ebeveyn[x];
        ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

static void birlestir(int x, int y)      /* saf: rütbe yok */
{
    int kx = bul(x), ky = bul(y);
    if (kx != ky) {
        ebeveyn[kx] = ky;
    }
}

int main(void)
{
    birlestir(0, 1);
    birlestir(1, 2);
    birlestir(2, 3);
    bul(0);
    for (int i = 0; i < N; i++) {
        printf("%d ", ebeveyn[i]);
    }
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: yok (elle) */

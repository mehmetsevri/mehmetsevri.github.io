"""H12_08_dijkstra_obek.py — AP-2 Hafta 12 · Örnek 8 (★★★)
Amaç    : Öbekli Dijkstra: (uzaklık, köşe) demetleri, tembel silme
          (köşe yeni uzaklıkla yeniden itilir; eskimiş kayıt çıkınca
          atlanır ve sayılır), en kısa yolun ebeveyn dizisinden yazdırılması;
          kâhin: Örnek 7'nin dizi tabanlı Dijkstra'sı
Çalıştır: python3 H12_08_dijkstra_obek.py ../girdiler/h12_kampus.txt 0
Eşleri  : c/H12_08_dijkstra_obek.c · cpp/H12_08_dijkstra_obek.cpp
Çıktı   : üç dilde aynı (=)
Not     : öbek: Python heapq (C'de elle öbek, C++'ta std::priority_queue);
          demetler (uzaklık, köşe) sözlük sırasıyla karşılaştırılır, eşit
          uzaklıkta küçük köşe önce çıkar.
"""
import heapq
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum

SONSUZ = 2147483647                  # C INT_MAX ile aynı sabit
SATIR_UZUNLUGU = 512                 # C'deki fgets tamponu (510 + '\n' + 0)

itme_sayisi = 0        # öbeğe itilen (uzaklık, köşe) demeti
cikarma_sayisi = 0     # öbekten çıkarılan demet
atlanan_sayisi = 0     # tembel silme: eskimiş olduğu için atlanan demet
kenar_inceleme = 0     # incelenen kenar (u, v)
gevsetme_sayisi = 0    # d[v]'yi küçülten başarılı gevşetme
en_buyuk_obek = 0      # öbeğin ulaştığı en büyük boy
taranan_hucre = 0      # (dizi tabanlı kâhin için)


class Graf:
    __slots__ = ("v_sayisi", "e_sayisi", "yonlu", "komsu", "kenar")

    def __init__(self, v_sayisi, e_sayisi, yonlu):
        self.v_sayisi = v_sayisi
        self.e_sayisi = e_sayisi
        self.yonlu = yonlu
        self.komsu = [[] for _ in range(v_sayisi)]  # (hedef, agirlik)
        self.kenar = []                              # (u, v, w)


def hata(ileti):
    print(f"Hata: {ileti}", file=sys.stderr)


def tamsayi_coz(s):
    """'-'? rakam+ (en çok 9 rakam); değilse None (üç dilde aynı kural)"""
    rakam = s[1:] if s[:1] == b"-" else s
    if len(rakam) == 0 or len(rakam) > 9:
        return None
    for c in rakam:
        if c < 48 or c > 57:             # '0'..'9'
            return None
    return int(s)


def graf_oku(yol):
    """Ortak graf dosyası (rehber 14.3): '#' yorum; 'V E [yonlu|yonsuz]';
    E satır 'u v [w]' (w yoksa 1). Hatada ileti + None (çıkış kodu 1)."""
    try:
        with open(yol, "rb") as f:
            satirlar = f.read().split(b"\n")
    except OSError:
        hata(f"dosya açılamadı: {yol}")
        return None
    g = None
    no = 0
    for satir in satirlar:
        no += 1
        if len(satir) > SATIR_UZUNLUGU - 2:
            hata(f"satır {no}: satır çok uzun")
            return None
        s = satir.strip()
        if len(s) == 0 or s[:1] == b"#":
            continue
        t = s.split()
        if g is None:
            v = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
            e = tamsayi_coz(t[1]) if v is not None else None
            tur = t[2] if len(t) == 3 else b"yonsuz"
            if (e is None or v < 1 or v > 1000000 or e < 0 or
                    e > 10000000 or tur not in (b"yonlu", b"yonsuz")):
                hata(f"satır {no}: başlık 'V E [yonlu|yonsuz]' "
                     "bekleniyordu")
                return None
            g = Graf(v, e, tur == b"yonlu")
            continue
        u = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
        v = tamsayi_coz(t[1]) if u is not None else None
        w = tamsayi_coz(t[2]) if len(t) == 3 else 1
        if v is None or w is None:
            hata(f"satır {no}: kenar 'u v [w]' bekleniyordu")
            return None
        if u < 0 or u >= g.v_sayisi or v < 0 or v >= g.v_sayisi:
            hata(f"satır {no}: köşe numarası 0..{g.v_sayisi - 1} "
                 "aralığında olmalı")
            return None
        if len(g.kenar) == g.e_sayisi:
            hata(f"satır {no}: fazla kenar (E = {g.e_sayisi})")
            return None
        g.kenar.append((u, v, w))
        g.komsu[u].append((v, w))
        if not g.yonlu:
            g.komsu[v].append((u, w))
    if g is None:
        hata("başlık satırı yok")
        return None
    if len(g.kenar) < g.e_sayisi:
        hata(f"kenar sayısı eksik: {g.e_sayisi} bekleniyordu, "
             f"{len(g.kenar)} okundu")
        return None
    for liste in g.komsu:
        liste.sort()                     # (hedef, agirlik) artan
    return g


def uzaklik_yaz(d, genislik):
    s = "∞" if d == SONSUZ else str(d)
    return " " * (genislik - len(s)) + s


def obek_yaz(obek):
    """Öbek içeriği sıralı (iç dizi düzeni kütüphaneye bağlıdır)"""
    return "[" + " ".join(f"({d},{v})" for d, v in sorted(obek)) + "]"


def dijkstra_obek(g, kaynak, d, ebeveyn, yaz):
    """O((V + E) log V): öbekte (uzaklık, köşe); anahtar azaltma yerine
    yeniden itme + tembel silme"""
    global itme_sayisi, cikarma_sayisi, atlanan_sayisi
    global kenar_inceleme, gevsetme_sayisi, en_buyuk_obek
    n = g.v_sayisi
    kesin = [False] * n
    for v in range(n):
        d[v] = SONSUZ
        ebeveyn[v] = -1
    d[kaynak] = 0
    obek = [(0, kaynak)]
    itme_sayisi += 1
    if len(obek) > en_buyuk_obek:
        en_buyuk_obek = len(obek)
    while obek:
        du, u = heapq.heappop(obek)
        cikarma_sayisi += 1
        if kesin[u]:                     # eskimiş kayıt: atla
            atlanan_sayisi += 1
            if yaz:
                print(f"  çıkar ({du},{u}): ESKİMİŞ ({u} kesin, d[{u}] = "
                      f"{d[u]}) -> atla")
            continue
        kesin[u] = True                  # öbekten çıkınca kesinleşir
        if yaz:
            print(f"  çıkar ({du},{u}): {u} kesinleşti; kesinleşen {{" +
                  ", ".join(str(x) for x in range(n) if kesin[x]) + "}")
        for v, w in g.komsu[u]:
            kenar_inceleme += 1
            if not kesin[v] and d[u] != SONSUZ and d[u] + w < d[v]:
                if yaz:
                    print(f"     gevşet {u}->{v} (w = {w}): d[{v}] = "
                          f"{uzaklik_yaz(d[v], 1)} -> {d[u] + w}, it "
                          f"({d[u] + w},{v})")
                d[v] = d[u] + w
                ebeveyn[v] = u
                gevsetme_sayisi += 1
                heapq.heappush(obek, (d[v], v))
                itme_sayisi += 1
                if len(obek) > en_buyuk_obek:
                    en_buyuk_obek = len(obek)
        if yaz:
            print(f"     öbek: {obek_yaz(obek)}")


def dijkstra_dizi(g, kaynak, d, ebeveyn, yaz):
    """O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama"""
    global taranan_hucre, kenar_inceleme, gevsetme_sayisi
    n = g.v_sayisi
    kesin = [False] * n
    for v in range(n):
        d[v] = SONSUZ
        ebeveyn[v] = -1
    d[kaynak] = 0
    for adim in range(1, n + 1):
        u = -1
        for v in range(n):               # en küçük d: doğrusal tarama
            taranan_hucre += 1
            if (not kesin[v] and d[v] != SONSUZ and
                    (u < 0 or d[v] < d[u])):
                u = v
        if u < 0:
            break                        # kalanlar ulaşılamaz
        kesin[u] = True                  # d[u] artık kesin
        if yaz:
            print(f"  adım {adim}: seç {u} (d = {d[u]}); kesinleşen "
                  "{" + ", ".join(str(x) for x in range(n) if kesin[x])
                  + "}")
        for v, w in g.komsu[u]:
            kenar_inceleme += 1
            if kesin[v]:
                continue
            if d[u] != SONSUZ and d[u] + w < d[v]:   # taşma korumalı
                if yaz:
                    print(f"     gevşet {u}->{v} (w = {w}): d[{v}] = "
                          f"{uzaklik_yaz(d[v], 1)} -> {d[u] + w}")
                d[v] = d[u] + w
                ebeveyn[v] = u
                gevsetme_sayisi += 1
            elif yaz:
                print(f"     {u}->{v} (w = {w}): {d[u]} + {w} >= {d[v]}, "
                      "değişmez")
        if yaz:
            print("     d: " + " ".join(uzaklik_yaz(x, 1) for x in d))


def rastgele_graf(v_sayisi, derece, w_ust, tohum):
    """Yönlü: her u için u -> u+1 (halka, ulaşılabilirlik için) ve derece-1
    rastgele kenar; ağırlıklar 1..w_ust (ortak LCG)"""
    rastgele_tohum(tohum)
    g = Graf(v_sayisi, v_sayisi * derece, True)
    for u in range(v_sayisi):
        g.komsu[u].append(((u + 1) % v_sayisi, rastgele_aralik(1, w_ust)))
        for _ in range(derece - 1):
            v = rastgele_aralik(0, v_sayisi - 1)
            g.komsu[u].append((v, rastgele_aralik(1, w_ust)))
    for liste in g.komsu:
        liste.sort()
    return g


def yol_yaz(ebeveyn, kaynak, hedef):
    """Ebeveyn dizisini hedeften kaynağa izle, ters sırada yaz"""
    yol = []
    v = hedef
    while v != -1:
        yol.append(v)
        v = ebeveyn[v]
    if yol[-1] != kaynak:
        return "ulaşılamaz"
    return " -> ".join(str(yol[i]) for i in range(len(yol) - 1, -1, -1))


def sayaclari_sifirla():
    global itme_sayisi, cikarma_sayisi, atlanan_sayisi, kenar_inceleme
    global gevsetme_sayisi, en_buyuk_obek, taranan_hucre
    itme_sayisi = cikarma_sayisi = atlanan_sayisi = kenar_inceleme = 0
    gevsetme_sayisi = en_buyuk_obek = taranan_hucre = 0


def main():
    if len(sys.argv) not in (2, 3):
        print("Kullanım: H12_08_dijkstra_obek GRAF_DOSYASI [KAYNAK]",
              file=sys.stderr)
        sys.exit(2)
    g = graf_oku(sys.argv[1])
    if g is None:
        sys.exit(1)
    kaynak = 0
    if len(sys.argv) == 3:
        kaynak = tamsayi_coz(sys.argv[2].encode())
        if kaynak is None or kaynak < 0 or kaynak >= g.v_sayisi:
            hata(f"kaynak köşe 0..{g.v_sayisi - 1} aralığında olmalı")
            sys.exit(2)
    for u, v, w in g.kenar:
        if w < 0:
            hata(f"negatif ağırlık {u}->{v} ({w}): Dijkstra'nın önkoşulu "
                 "sağlanmıyor (Örnek 9)")
            sys.exit(1)
    print(f"1) Graf: {g.v_sayisi} köşe, {g.e_sayisi} kenar, "
          f"{'yönlü' if g.yonlu else 'yönsüz'}; kaynak {kaynak}")
    print("  öbek öğesi (uzaklık, köşe); başlangıç: öbek [(0,"
          f"{kaynak})]")
    n = g.v_sayisi
    d = [0] * n
    ebeveyn = [0] * n
    dijkstra_obek(g, kaynak, d, ebeveyn, True)
    print(f"  sayaçlar: itme = {itme_sayisi}, çıkarma = {cikarma_sayisi}, "
          f"atlanan (eskimiş) = {atlanan_sayisi}, kenar inceleme = "
          f"{kenar_inceleme}, başarılı gevşetme = {gevsetme_sayisi}, en "
          f"büyük öbek = {en_buyuk_obek}")
    print(f"  itme = 1 + başarılı gevşetme: {itme_sayisi} = 1 + "
          f"{gevsetme_sayisi}; atlanan = itme - kesinleşen: "
          f"{atlanan_sayisi} = {itme_sayisi} - "
          f"{itme_sayisi - atlanan_sayisi}")

    print(f"\n2) En kısa yollar (ebeveyn dizisi geriye izlenir), kaynak "
          f"{kaynak}")
    for v in range(n):
        print(f"  {v}: uzaklık {uzaklik_yaz(d[v], 4)}  yol "
              f"{yol_yaz(ebeveyn, kaynak, v)}")

    print("\n3) Kâhin: dizi tabanlı Dijkstra (Örnek 7) ile karşılaştırma; "
          "rastgele yönlü\n   graflar (derece 4, ağırlık 1..100, tohum 42)")
    print("      V      E   itme  çıkarma  atlanan  en büyük öbek  "
          "(V+E)·⌈log2 V⌉  aynı mı")
    for n in (100, 500, 2000):
        r = rastgele_graf(n, 4, 100, 42)
        d1 = [0] * n
        e1 = [0] * n
        d2 = [0] * n
        e2 = [0] * n
        sayaclari_sifirla()
        dijkstra_dizi(r, 0, d2, e2, False)
        sayaclari_sifirla()
        dijkstra_obek(r, 0, d1, e1, False)
        log = 0
        while (1 << log) < n:
            log += 1
        print(f"  {n:5d}  {r.e_sayisi:5d}  {itme_sayisi:5d}  "
              f"{cikarma_sayisi:7d}  {atlanan_sayisi:7d}  "
              f"{en_buyuk_obek:13d}  {(n + r.e_sayisi) * log:14d}  "
              f"{'evet' if d1 == d2 else 'HAYIR'}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (öbek elle, H7); C++ — öbek
# std::priority_queue<std::pair<int, int>, std::vector<…>,
# std::greater<…>>; Python — heapq. Dijkstra'nın kendisi elle yazılır.

"""H12_11_kruskal.py — AP-2 Hafta 12 · Örnek 11 (★★★)
Amaç    : Kruskal ile en küçük kapsayan ağaç: kenarlar (w, u, v) sırasıyla;
          birleşim–bul (rütbe + yol sıkıştırma) ile döngü denetimi; kabul
          ve reddedilen kenarlar, her adımda birleşim–bul ormanı; kabul
          edilen her kenar için kesim özelliğinin denetimi; kâhin: kaba
          kuvvet (bütün V - 1 kenarlı alt kümeler)
Çalıştır: python3 H12_11_kruskal.py ../girdiler/h12_kampus.txt
Eşleri  : c/H12_11_kruskal.c · cpp/H12_11_kruskal.cpp
Çıktı   : üç dilde aynı (=)
Not     : yönsüz kenar (min(u, v), max(u, v)) olarak tutulur; sıralama
          aracı sorted, demet (w, u, v) tam sıralamadır.
"""
import sys

SATIR_UZUNLUGU = 512                 # C'deki fgets tamponu (510 + '\n' + 0)

izleme_sayisi = 0      # birleşim–bul: işaretçi izleme
bul_sayisi = 0
birlestir_sayisi = 0


class Graf:
    __slots__ = ("v_sayisi", "e_sayisi", "yonlu", "komsu", "kenar")

    def __init__(self, v_sayisi, e_sayisi, yonlu):
        self.v_sayisi = v_sayisi
        self.e_sayisi = e_sayisi
        self.yonlu = yonlu
        self.komsu = [[] for _ in range(v_sayisi)]  # (hedef, agirlik)
        self.kenar = []                              # (u, v, w)


def hata(ileti):
    print(f"Hata: {ileti}", file=sys.stderr)


def tamsayi_coz(s):
    """'-'? rakam+ (en çok 9 rakam); değilse None (üç dilde aynı kural)"""
    rakam = s[1:] if s[:1] == b"-" else s
    if len(rakam) == 0 or len(rakam) > 9:
        return None
    for c in rakam:
        if c < 48 or c > 57:             # '0'..'9'
            return None
    return int(s)


def graf_oku(yol):
    """Ortak graf dosyası (rehber 14.3): '#' yorum; 'V E [yonlu|yonsuz]';
    E satır 'u v [w]' (w yoksa 1). Hatada ileti + None (çıkış kodu 1)."""
    try:
        with open(yol, "rb") as f:
            satirlar = f.read().split(b"\n")
    except OSError:
        hata(f"dosya açılamadı: {yol}")
        return None
    g = None
    no = 0
    for satir in satirlar:
        no += 1
        if len(satir) > SATIR_UZUNLUGU - 2:
            hata(f"satır {no}: satır çok uzun")
            return None
        s = satir.strip()
        if len(s) == 0 or s[:1] == b"#":
            continue
        t = s.split()
        if g is None:
            v = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
            e = tamsayi_coz(t[1]) if v is not None else None
            tur = t[2] if len(t) == 3 else b"yonsuz"
            if (e is None or v < 1 or v > 1000000 or e < 0 or
                    e > 10000000 or tur not in (b"yonlu", b"yonsuz")):
                hata(f"satır {no}: başlık 'V E [yonlu|yonsuz]' "
                     "bekleniyordu")
                return None
            g = Graf(v, e, tur == b"yonlu")
            continue
        u = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
        v = tamsayi_coz(t[1]) if u is not None else None
        w = tamsayi_coz(t[2]) if len(t) == 3 else 1
        if v is None or w is None:
            hata(f"satır {no}: kenar 'u v [w]' bekleniyordu")
            return None
        if u < 0 or u >= g.v_sayisi or v < 0 or v >= g.v_sayisi:
            hata(f"satır {no}: köşe numarası 0..{g.v_sayisi - 1} "
                 "aralığında olmalı")
            return None
        if len(g.kenar) == g.e_sayisi:
            hata(f"satır {no}: fazla kenar (E = {g.e_sayisi})")
            return None
        g.kenar.append((u, v, w))
        g.komsu[u].append((v, w))
        if not g.yonlu:
            g.komsu[v].append((u, w))
    if g is None:
        hata("başlık satırı yok")
        return None
    if len(g.kenar) < g.e_sayisi:
        hata(f"kenar sayısı eksik: {g.e_sayisi} bekleniyordu, "
             f"{len(g.kenar)} okundu")
        return None
    for liste in g.komsu:
        liste.sort()                     # (hedef, agirlik) artan
    return g


class BirlesimBul:
    """Örnek 10'un 'rütbe + sıkıştırma' sürümü"""
    __slots__ = ("ebeveyn", "rutbe")

    def __init__(self, n):
        self.ebeveyn = list(range(n))
        self.rutbe = [0] * n


def bul(b, x):
    global izleme_sayisi, bul_sayisi
    bul_sayisi += 1
    kok = x
    while b.ebeveyn[kok] != kok:
        kok = b.ebeveyn[kok]
        izleme_sayisi += 1
    while b.ebeveyn[x] != kok:           # yol sıkıştırma
        sonraki = b.ebeveyn[x]
        b.ebeveyn[x] = kok
        x = sonraki
    return kok


def birlestir_kok(b, kx, ky):
    """İki farklı kökü rütbeye göre bağlar"""
    global birlestir_sayisi
    birlestir_sayisi += 1
    if b.rutbe[kx] < b.rutbe[ky]:
        kx, ky = ky, kx
    b.ebeveyn[ky] = kx
    if b.rutbe[kx] == b.rutbe[ky]:
        b.rutbe[kx] += 1


def kok_sayacsiz(b, x):
    """Kesim denetimi için: sayaçsız, sıkıştırmasız kök"""
    while b.ebeveyn[x] != x:
        x = b.ebeveyn[x]
    return x


def kesim(g, b, ku):
    """Birleştirmeden ÖNCE: S = ku kökünün kümesi; S ile V - S arasındaki
    en hafif kenarın ağırlığı. (S üyelik listesi, en hafif) döndürür."""
    n = g.v_sayisi
    s = [kok_sayacsiz(b, x) == ku for x in range(n)]
    en_hafif = -1
    for u, v, wk in g.kenar:
        if s[u] != s[v] and (en_hafif < 0 or wk < en_hafif):
            en_hafif = wk
    return s, en_hafif


def kruskal(g, agac, yaz):
    """Kenarları (w, u, v) sırasıyla dolaş; uçlar farklı ağaçtaysa al.
    Ağaç kenarlarını agac'a ekler, toplam ağırlığı döndürür."""
    sira = sorted((w, u if u < v else v, v if u < v else u)
                  for u, v, w in g.kenar)
    b = BirlesimBul(g.v_sayisi)
    toplam = 0
    adim = 0
    for w, u, v in sira:
        adim += 1
        ku, kv = bul(b, u), bul(b, v)
        if ku == kv:
            if yaz:
                print(f"  {adim:2d}  ({w:3d}, {u}, {v})  {ku} {kv}     RET    "
                      f"döngü: {u} ile {v} zaten aynı ağaçta")
            continue
        if yaz:
            s, en_hafif = kesim(g, b, ku)
        birlestir_kok(b, ku, kv)         # iki ağaç birleşir
        agac.append((u, v, w))
        toplam += w
        if yaz:
            print(f"  {adim:2d}  ({w:3d}, {u}, {v})  {ku} {kv}     KABUL  "
                  "ebeveyn: " + " ".join(str(x) for x in b.ebeveyn))
            print("      kesim S = {" + ", ".join(
                str(x) for x in range(g.v_sayisi) if s[x]) +
                f"}}: S'den çıkan en hafif kenar {en_hafif} " +
                ("= w (kesim özelliği)" if en_hafif == w else "!= w (HATA)"))
            if len(agac) == g.v_sayisi - 1:
                print(f"      (ağaç tamam: V - 1 = {g.v_sayisi - 1} kenar; "
                      "erken durdurma kalanları incelemezdi)")
    return toplam


def kaba_kuvvet(g):
    """Bütün V - 1 kenarlı alt kümeler (maske); kapsayan ağaç olanların
    sayısı ve en küçük toplamı"""
    n, m = g.v_sayisi, len(g.kenar)
    sayi, en_kucuk, incelenen = 0, -1, 0
    for maske in range(1 << m):
        k = 0
        x = maske
        while x:
            k += x & 1
            x >>= 1
        if k != n - 1:
            continue
        incelenen += 1
        ebeveyn = list(range(n))
        dongu = False
        toplam = 0
        for i in range(m):
            if maske >> i & 1:
                u, v, w = g.kenar[i]
                while ebeveyn[u] != u:
                    u = ebeveyn[u]
                while ebeveyn[v] != v:
                    v = ebeveyn[v]
                if u == v:
                    dongu = True
                    break
                ebeveyn[u] = v
                toplam += w
        if not dongu:
            sayi += 1
            if en_kucuk < 0 or toplam < en_kucuk:
                en_kucuk = toplam
    return incelenen, sayi, en_kucuk


def main():
    if len(sys.argv) != 2:
        print("Kullanım: H12_11_kruskal GRAF_DOSYASI", file=sys.stderr)
        sys.exit(2)
    g = graf_oku(sys.argv[1])
    if g is None:
        sys.exit(1)
    if g.yonlu:
        hata("en küçük kapsayan ağaç yönsüz graf ister")
        sys.exit(1)
    print(f"1) Graf: {g.v_sayisi} köşe, {g.e_sayisi} kenar, yönsüz")
    print("\n2) Kruskal: kenarlar (w, u, v) sırasıyla; birleşim–bul: rütbe + "
          "yol sıkıştırma")
    print("  adım (w, u, v)     kökler  karar  birleşim–bul ormanı")
    agac = []
    toplam = kruskal(g, agac, True)
    print("  ağaç kenarları: " + ", ".join(f"{u}-{v} ({w})"
                                          for u, v, w in agac))
    print(f"  toplam ağırlık = {toplam}; kabul {len(agac)}, ret "
          f"{len(g.kenar) - len(agac)}; bul = {bul_sayisi}, birleştir = "
          f"{birlestir_sayisi}, işaretçi izleme = {izleme_sayisi}")
    if len(agac) < g.v_sayisi - 1:
        print(f"  graf bağlı değil: {g.v_sayisi - len(agac)} ağaçlı orman")

    if len(g.kenar) <= 20:
        print("\n3) Kâhin: kaba kuvvet (bütün V - 1 kenarlı alt kümeler)")
        incelenen, sayi, en_kucuk = kaba_kuvvet(g)
        print(f"  {incelenen} alt küme, {sayi} tanesi kapsayan ağaç; en "
              f"küçük toplam {en_kucuk} -> Kruskal "
              f"{'en iyi' if en_kucuk == toplam else 'FARKLI'}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — yok (Boost Graph Library
# kruskal_minimum_spanning_tree, networkx minimum_spanning_tree —
# standart dışı; yalnız kâhin).

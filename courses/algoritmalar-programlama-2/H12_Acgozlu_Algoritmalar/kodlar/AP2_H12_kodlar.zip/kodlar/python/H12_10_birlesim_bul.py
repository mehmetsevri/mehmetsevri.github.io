"""H12_10_birlesim_bul.py — AP-2 Hafta 12 · Örnek 10 (★★)
Amaç    : Birleşim–bul (ayrık kümeler): saf, yalnız rütbe, yalnız yol
          sıkıştırma ve ikisi birden; işaretçi izleme sayısı, ağaç
          yüksekliği; küçük örnekte orman, zincirde en kötü durum,
          rastgele işlemlerde işlem başına izleme
Çalıştır: python3 H12_10_birlesim_bul.py
Eşleri  : c/H12_10_birlesim_bul.c · cpp/H12_10_birlesim_bul.cpp
Çıktı   : üç dilde aynı (=)
Not     : saf birleştirmede birincinin kökü ikincinin köküne bağlanır;
          rütbede küçük rütbeli kök büyüğün altına girer (eşitse ikinci
          birinciye, birincinin rütbesi artar). Yol sıkıştırma iki geçişli
          ve yinelemelidir (özyineleme yok).
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

SURUM_ADI = ["saf", "yalnız rütbe", "yalnız sıkıştırma", "rütbe + sıkıştırma"]

izleme_sayisi = 0      # ebeveyn[] üzerinden yapılan işaretçi izleme
baglama_sayisi = 0     # yol sıkıştırmada yeniden bağlanan düğüm


class BirlesimBul:
    __slots__ = ("ebeveyn", "rutbe", "rutbeli", "sikistir")

    def __init__(self, n, surum):
        self.ebeveyn = list(range(n))    # her eleman kendi kümesinin kökü
        self.rutbe = [0] * n
        self.rutbeli = surum in (1, 3)
        self.sikistir = surum in (2, 3)


def bul(b, x):
    """x'in kökü; sıkıştırmada yol üzerindeki düğümler köke bağlanır"""
    global izleme_sayisi, baglama_sayisi
    kok = x
    while b.ebeveyn[kok] != kok:         # 1. geçiş: kökü bul
        kok = b.ebeveyn[kok]
        izleme_sayisi += 1
    if b.sikistir:
        while b.ebeveyn[x] != kok:       # 2. geçiş: yolu köke bağla
            sonraki = b.ebeveyn[x]
            b.ebeveyn[x] = kok
            baglama_sayisi += 1
            x = sonraki
    return kok


def birlestir(b, x, y):
    """İki kümeyi birleştirir; zaten aynıysa False"""
    kx, ky = bul(b, x), bul(b, y)
    if kx == ky:
        return False
    if not b.rutbeli:
        b.ebeveyn[kx] = ky               # saf: birincinin kökü ikinciye
        return True
    if b.rutbe[kx] < b.rutbe[ky]:
        kx, ky = ky, kx                  # kx: rütbesi büyük olan
    b.ebeveyn[ky] = kx
    if b.rutbe[kx] == b.rutbe[ky]:
        b.rutbe[kx] += 1
    return True


def yukseklik(b):
    """Ormanın yüksekliği (en derin düğümün köke uzaklığı); sayaçlara
    girmez. Derinlikler yolun yukarısından aşağı doğru doldurulur: Θ(n)."""
    n = len(b.ebeveyn)
    derinlik = [-1] * n
    en_cok = 0
    yigin = []
    for x in range(n):
        v = x
        while derinlik[v] < 0 and b.ebeveyn[v] != v:
            yigin.append(v)
            v = b.ebeveyn[v]
        if derinlik[v] < 0:
            derinlik[v] = 0              # kök
        while yigin:
            u = yigin.pop()
            derinlik[u] = derinlik[b.ebeveyn[u]] + 1
        if derinlik[x] > en_cok:
            en_cok = derinlik[x]
    return en_cok


def kume_sayisi(b):
    k = 0
    for x in range(len(b.ebeveyn)):
        k += b.ebeveyn[x] == x
    return k


def sola_yasla(s, genislik):
    """Görünür karakter sayısına göre doldurur (ı, ü tek karakterdir)"""
    return s + " " * (genislik - len(s))


def dizi_yaz(a):
    return " ".join(f"{x:2d}" for x in a)


def kucuk_ornek():
    global izleme_sayisi, baglama_sayisi
    islemler = [(0, 1), (2, 3), (0, 2), (4, 5), (6, 7), (4, 6), (1, 5),
                (3, 7)]
    print("1) Küçük örnek: n = 8; birleştir " +
          " ".join(f"({x},{y})" for x, y in islemler) + "; sonra bul(0)")
    print(f"  indis     : {dizi_yaz(range(8))}")
    for surum in range(4):
        b = BirlesimBul(8, surum)
        izleme_sayisi = baglama_sayisi = 0
        sonuc = ""
        for x, y in islemler:
            sonuc += "+" if birlestir(b, x, y) else "="
        once = list(b.ebeveyn)
        h_once = yukseklik(b)
        k = bul(b, 0)
        print(f"  {SURUM_ADI[surum]} ({sonuc}; = : zaten aynı küme)")
        print(f"    ebeveyn : {dizi_yaz(once)}   yükseklik {h_once}")
        print(f"    bul(0) = {k}; sonra ebeveyn: {dizi_yaz(b.ebeveyn)}   "
              f"yükseklik {yukseklik(b)}")
        print(f"    işaretçi izleme = {izleme_sayisi}, yeniden bağlama = "
              f"{baglama_sayisi}")
        if b.rutbeli:
            print(f"    rütbe   : {dizi_yaz(b.rutbe)}")


def zincir(n):
    """En kötü durum: birleştir(i, i+1) sırası saf sürümde zincir kurar;
    ardından her elemanda bul"""
    global izleme_sayisi, baglama_sayisi
    print(f"\n2) Zincir: n = {n}; birleştir(i, i + 1), i = 0..n-2; sonra "
          "bul(0), bul(1), …, bul(n-1)")
    print("  sürüm                yükseklik  birleştirme izl.  bul izl.  "
          "bul başına")
    for surum in range(4):
        b = BirlesimBul(n, surum)
        izleme_sayisi = baglama_sayisi = 0
        for i in range(n - 1):
            birlestir(b, i, i + 1)
        h = yukseklik(b)
        birlestirme = izleme_sayisi
        izleme_sayisi = 0
        for i in range(n):
            bul(b, i)
        bas = izleme_sayisi * 1000 // n
        print(f"  {sola_yasla(SURUM_ADI[surum], 19)}  {h:9d}  "
              f"{birlestirme:16d}  {izleme_sayisi:8d}  "
              f"{bas // 1000:6d}.{bas % 1000:03d}")
    print(f"  saf: bul izleme toplamı = n(n-1)/2 = {n * (n - 1) // 2}")


def rastgele(n):
    """n rastgele birleştirme + n rastgele bul (tohum 42, her sürüme aynı
    işlem dizisi)"""
    global izleme_sayisi, baglama_sayisi
    print(f"  n = {n:6d}:")
    for surum in range(4):
        b = BirlesimBul(n, surum)
        izleme_sayisi = baglama_sayisi = 0
        rastgele_tohum(42)
        for _ in range(n):
            x = rastgele_aralik(0, n - 1)
            y = rastgele_aralik(0, n - 1)
            birlestir(b, x, y)
        for _ in range(n):
            bul(b, rastgele_aralik(0, n - 1))
        islem = 3 * n                    # birleştirmede 2 bul + n bul
        bas = izleme_sayisi * 1000 // islem
        print(f"    {sola_yasla(SURUM_ADI[surum], 19)}  küme "
              f"{kume_sayisi(b):6d}  yükseklik {yukseklik(b):4d}  izleme "
              f"{izleme_sayisi:9d}  bul başına {bas // 1000}.{bas % 1000:03d}")


def main():
    kucuk_ornek()
    zincir(1000)
    print("\n3) Rastgele işlemler: n birleştirme + n bul (3n bul çağrısı)")
    for n in (1000, 2000, 4000, 8000):
        rastgele(n)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — yok (standart kütüphanelerde
# ayrık küme yapısı yok; Boost disjoint_sets ve networkx.utils.UnionFind
# standart dışıdır).

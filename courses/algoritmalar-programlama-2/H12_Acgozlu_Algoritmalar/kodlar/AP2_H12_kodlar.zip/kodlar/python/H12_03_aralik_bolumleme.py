"""H12_03_aralik_bolumleme.py — AP-2 Hafta 12 · Örnek 3 (★★)
Amaç    : Aralık bölümleme: bütün dersleri en az salonla yerleştirmek;
          başlangıca göre sırala, salonların bitiş zamanlarını en küçük
          öbekte tut; salon ataması ve alt sınır (aynı anda en çok ders)
Çalıştır: python3 H12_03_aralik_bolumleme.py
Eşleri  : c/H12_03_aralik_bolumleme.c ·
          cpp/H12_03_aralik_bolumleme.cpp
Çıktı   : üç dilde aynı (=)
Not     : öbek öğesi (bitiş, salon) demeti; eşitlikte küçük salon.
          Aralıklar yarı açık: bir ders 10:30'da biterse salon 10:30'da
          başlayan derse verilebilir.
"""
import heapq

from ortak_rastgele import rastgele_aralik, rastgele_tohum

itme_sayisi = 0
cikarma_sayisi = 0


def saat(dk):
    return f"{dk // 60:02d}:{dk % 60:02d}"


def obek_yaz(obek):
    """Öbek içeriği (bitiş, salon) sıralı yazılır: iç dizi düzeni
    kütüphaneye göre değişir, çıktı buna bağlı olmasın"""
    return "[" + " ".join(f"({saat(b)},{s + 1})"
                          for b, s in sorted(obek)) + "]"


def bolumle(ders, salon, yaz):
    """ders: (bas, bit, kimlik) listesi. salon[kimlik] = atanan salon.
    Salon sayısını döndürür."""
    global itme_sayisi, cikarma_sayisi
    sira = sorted(ders)                  # (bas, bit, kimlik) sırası
    obek = []                            # (bitiş, salon) demetleri
    salon_sayisi = 0
    for bas, bit, kimlik in sira:
        if obek and obek[0][0] <= bas:   # en erken boşalan salon uygun
            _, s = heapq.heappop(obek)
            cikarma_sayisi += 1
            not_ = "boşalan salon"
        else:
            s = salon_sayisi             # yeni salon aç
            salon_sayisi += 1
            not_ = "YENİ salon"
        salon[kimlik] = s
        heapq.heappush(obek, (bit, s))
        itme_sayisi += 1
        if yaz:
            print(f"  {chr(65 + kimlik)} {saat(bas)}-{saat(bit)} -> salon "
                  f"{s + 1} ({not_})  öbek: {obek_yaz(obek)}")
    return salon_sayisi


def derinlik(ders):
    """Alt sınır: aynı anda süren en çok ders sayısı. Olaylar (zaman, tür):
    tür 0 = bitiş, 1 = başlangıç; aynı anda önce bitişler (yarı açık).
    (derinlik, ilk ulaşıldığı zaman) döndürür."""
    olay = []
    for bas, bit, _ in ders:
        olay.append((bas, 1))
        olay.append((bit, 0))
    olay.sort()
    etkin = 0
    en_cok, zaman = 0, 0
    for t, tur in olay:
        etkin += 1 if tur == 1 else -1
        if etkin > en_cok:
            en_cok, zaman = etkin, t
    return en_cok, zaman


def main():
    global itme_sayisi, cikarma_sayisi
    veri = [(540, 630), (540, 750), (600, 690), (630, 720), (660, 840),
            (720, 810), (780, 870), (810, 960), (870, 960), (900, 990)]
    ders = [(veri[i][0], veri[i][1], i) for i in range(len(veri))]
    salon = [0] * len(ders)
    print(f"1) {len(ders)} ders, başlangıca göre sıra; öbekte (bitiş, "
          "salon)")
    k = bolumle(ders, salon, True)
    print(f"  gereken salon = {k}; öbeğe itme = {itme_sayisi}, çıkarma = "
          f"{cikarma_sayisi}")
    d, t = derinlik(ders)
    print(f"  alt sınır: {saat(t)}'da aynı anda {d} ders sürüyor -> en az "
          f"{d} salon gerekir")
    print(f"  açgözlü {k} salon = alt sınır {d}: "
          f"{'en iyi' if k == d else 'FARKLI'}")

    print("\n2) Salon ataması (zaman çizgisi)")
    for s in range(k):
        satir = [f"{chr(65 + i)} {saat(ders[i][0])}-{saat(ders[i][1])}"
                 for i in range(len(ders)) if salon[i] == s]
        print(f"  salon {s + 1}: " + ", ".join(satir))

    print("\n3) Rastgele denetim: salon sayısı = derinlik mi?")
    rastgele_tohum(42)
    esit = 0
    for _ in range(1000):
        n = rastgele_aralik(5, 30)
        r = []
        for i in range(n):
            bas = rastgele_aralik(0, 100)
            r.append((bas, bas + rastgele_aralik(1, 30), i))
        rs = [0] * n
        itme_sayisi = cikarma_sayisi = 0
        esit += bolumle(r, rs, False) == derinlik(r)[0]
    print(f"  1000 rastgele örnek (n = 5..30, tohum 42): eşit = {esit}/1000")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (öbek elle, H7); C++ — öbek
# std::priority_queue<std::pair<int, int>, …, std::greater<…>>; Python —
# heapq (en küçük öbek). Bölümleme algoritmasının kendisi elle yazılır.

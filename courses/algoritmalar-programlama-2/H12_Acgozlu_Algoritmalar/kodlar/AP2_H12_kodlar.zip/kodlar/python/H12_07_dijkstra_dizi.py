"""H12_07_dijkstra_dizi.py — AP-2 Hafta 12 · Örnek 7 (★★)
Amaç    : Ağırlıklı graf okuma (ortak biçim) ve dizi tabanlı O(V²)
          Dijkstra: her adımda kesinleşmemiş en küçük uzaklıklı köşeyi
          doğrusal taramayla seç, komşularını gevşet; kesinleşen küme ve
          uzaklık tablosu adım adım
Çalıştır: python3 H12_07_dijkstra_dizi.py ../girdiler/h12_kampus.txt 0
Eşleri  : c/H12_07_dijkstra_dizi.c · cpp/H12_07_dijkstra_dizi.cpp
Çıktı   : üç dilde aynı (=)
Not     : komşular artan köşe numarasıyla (okuyucu sıralar); eşit
          uzaklıkta küçük numaralı köşe seçilir. SONSUZ = 2^31 - 1 (C'deki
          INT_MAX), yazdırılırken ∞.
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum

SONSUZ = 2147483647                  # C INT_MAX ile aynı sabit
SATIR_UZUNLUGU = 512                 # C'deki fgets tamponu (510 + '\n' + 0)

taranan_hucre = 0      # en küçüğü seçerken bakılan d[] hücresi
kenar_inceleme = 0     # incelenen kenar (u, v)
gevsetme_sayisi = 0    # d[v]'yi küçülten başarılı gevşetme


class Graf:
    __slots__ = ("v_sayisi", "e_sayisi", "yonlu", "komsu", "kenar")

    def __init__(self, v_sayisi, e_sayisi, yonlu):
        self.v_sayisi = v_sayisi
        self.e_sayisi = e_sayisi
        self.yonlu = yonlu
        self.komsu = [[] for _ in range(v_sayisi)]  # (hedef, agirlik)
        self.kenar = []                              # (u, v, w)


def hata(ileti):
    print(f"Hata: {ileti}", file=sys.stderr)


def tamsayi_coz(s):
    """'-'? rakam+ (en çok 9 rakam); değilse None (üç dilde aynı kural)"""
    rakam = s[1:] if s[:1] == b"-" else s
    if len(rakam) == 0 or len(rakam) > 9:
        return None
    for c in rakam:
        if c < 48 or c > 57:             # '0'..'9'
            return None
    return int(s)


def graf_oku(yol):
    """Ortak graf dosyası (rehber 14.3): '#' yorum; 'V E [yonlu|yonsuz]';
    E satır 'u v [w]' (w yoksa 1). Hatada ileti + None (çıkış kodu 1)."""
    try:
        with open(yol, "rb") as f:
            satirlar = f.read().split(b"\n")
    except OSError:
        hata(f"dosya açılamadı: {yol}")
        return None
    g = None
    no = 0
    for satir in satirlar:
        no += 1
        if len(satir) > SATIR_UZUNLUGU - 2:
            hata(f"satır {no}: satır çok uzun")
            return None
        s = satir.strip()
        if len(s) == 0 or s[:1] == b"#":
            continue
        t = s.split()
        if g is None:
            v = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
            e = tamsayi_coz(t[1]) if v is not None else None
            tur = t[2] if len(t) == 3 else b"yonsuz"
            if (e is None or v < 1 or v > 1000000 or e < 0 or
                    e > 10000000 or tur not in (b"yonlu", b"yonsuz")):
                hata(f"satır {no}: başlık 'V E [yonlu|yonsuz]' "
                     "bekleniyordu")
                return None
            g = Graf(v, e, tur == b"yonlu")
            continue
        u = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
        v = tamsayi_coz(t[1]) if u is not None else None
        w = tamsayi_coz(t[2]) if len(t) == 3 else 1
        if v is None or w is None:
            hata(f"satır {no}: kenar 'u v [w]' bekleniyordu")
            return None
        if u < 0 or u >= g.v_sayisi or v < 0 or v >= g.v_sayisi:
            hata(f"satır {no}: köşe numarası 0..{g.v_sayisi - 1} "
                 "aralığında olmalı")
            return None
        if len(g.kenar) == g.e_sayisi:
            hata(f"satır {no}: fazla kenar (E = {g.e_sayisi})")
            return None
        g.kenar.append((u, v, w))
        g.komsu[u].append((v, w))
        if not g.yonlu:
            g.komsu[v].append((u, w))
    if g is None:
        hata("başlık satırı yok")
        return None
    if len(g.kenar) < g.e_sayisi:
        hata(f"kenar sayısı eksik: {g.e_sayisi} bekleniyordu, "
             f"{len(g.kenar)} okundu")
        return None
    for liste in g.komsu:
        liste.sort()                     # (hedef, agirlik) artan
    return g


def uzaklik_yaz(d, genislik):
    s = "∞" if d == SONSUZ else str(d)
    return " " * (genislik - len(s)) + s


def dijkstra_dizi(g, kaynak, d, ebeveyn, yaz):
    """O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama"""
    global taranan_hucre, kenar_inceleme, gevsetme_sayisi
    n = g.v_sayisi
    kesin = [False] * n
    for v in range(n):
        d[v] = SONSUZ
        ebeveyn[v] = -1
    d[kaynak] = 0
    for adim in range(1, n + 1):
        u = -1
        for v in range(n):               # en küçük d: doğrusal tarama
            taranan_hucre += 1
            if (not kesin[v] and d[v] != SONSUZ and
                    (u < 0 or d[v] < d[u])):
                u = v
        if u < 0:
            break                        # kalanlar ulaşılamaz
        kesin[u] = True                  # d[u] artık kesin
        if yaz:
            print(f"  adım {adim}: seç {u} (d = {d[u]}); kesinleşen "
                  "{" + ", ".join(str(x) for x in range(n) if kesin[x])
                  + "}")
        for v, w in g.komsu[u]:
            kenar_inceleme += 1
            if kesin[v]:
                continue
            if d[u] != SONSUZ and d[u] + w < d[v]:   # taşma korumalı
                if yaz:
                    print(f"     gevşet {u}->{v} (w = {w}): d[{v}] = "
                          f"{uzaklik_yaz(d[v], 1)} -> {d[u] + w}")
                d[v] = d[u] + w
                ebeveyn[v] = u
                gevsetme_sayisi += 1
            elif yaz:
                print(f"     {u}->{v} (w = {w}): {d[u]} + {w} >= {d[v]}, "
                      "değişmez")
        if yaz:
            print("     d: " + " ".join(uzaklik_yaz(x, 1) for x in d))


def rastgele_graf(v_sayisi, derece, w_ust, tohum):
    """Yönlü: her u için u -> u+1 (halka, ulaşılabilirlik için) ve derece-1
    rastgele kenar; ağırlıklar 1..w_ust (ortak LCG)"""
    rastgele_tohum(tohum)
    g = Graf(v_sayisi, v_sayisi * derece, True)
    for u in range(v_sayisi):
        g.komsu[u].append(((u + 1) % v_sayisi, rastgele_aralik(1, w_ust)))
        for _ in range(derece - 1):
            v = rastgele_aralik(0, v_sayisi - 1)
            g.komsu[u].append((v, rastgele_aralik(1, w_ust)))
    for liste in g.komsu:
        liste.sort()
    return g


def main():
    global taranan_hucre, kenar_inceleme, gevsetme_sayisi
    if len(sys.argv) not in (2, 3):
        print("Kullanım: H12_07_dijkstra_dizi GRAF_DOSYASI [KAYNAK]",
              file=sys.stderr)
        sys.exit(2)
    g = graf_oku(sys.argv[1])
    if g is None:
        sys.exit(1)
    kaynak = 0
    if len(sys.argv) == 3:
        kaynak = tamsayi_coz(sys.argv[2].encode())
        if kaynak is None or kaynak < 0 or kaynak >= g.v_sayisi:
            hata(f"kaynak köşe 0..{g.v_sayisi - 1} aralığında olmalı")
            sys.exit(2)
    for u, v, w in g.kenar:
        if w < 0:
            hata(f"negatif ağırlık {u}->{v} ({w}): Dijkstra'nın önkoşulu "
                 "sağlanmıyor (Örnek 9)")
            sys.exit(1)
    print(f"1) Graf: {g.v_sayisi} köşe, {g.e_sayisi} kenar, "
          f"{'yönlü' if g.yonlu else 'yönsüz (her kenar iki yönde)'}")
    print("  komşuluk listesi, hedef(ağırlık):")
    for u in range(g.v_sayisi):
        print(f"    {u}: " + " ".join(f"{v}({w})" for v, w in g.komsu[u]))

    print(f"\n2) Dizi tabanlı Dijkstra, kaynak {kaynak}")
    d = [0] * g.v_sayisi
    ebeveyn = [0] * g.v_sayisi
    dijkstra_dizi(g, kaynak, d, ebeveyn, True)
    print("  köşe  uzaklık  ebeveyn")
    for v in range(g.v_sayisi):
        print(f"  {v:4d}  {uzaklik_yaz(d[v], 7)}  {ebeveyn[v]:7d}")
    print(f"  sayaçlar: taranan hücre = {taranan_hucre} (V² = "
          f"{g.v_sayisi * g.v_sayisi}), kenar inceleme = {kenar_inceleme}, "
          f"başarılı gevşetme = {gevsetme_sayisi}")

    print("\n3) Rastgele yönlü graflarda sayaçlar (derece 4, ağırlık 1..100)")
    print("      V       E   taranan hücre          V²  kenar inc.  "
          "gevşetme")
    for n in (100, 200, 400, 800):
        r = rastgele_graf(n, 4, 100, 42)
        rd = [0] * n
        re = [0] * n
        taranan_hucre = kenar_inceleme = gevsetme_sayisi = 0
        dijkstra_dizi(r, 0, rd, re, False)
        print(f"  {n:5d}  {r.e_sayisi:6d}  {taranan_hucre:14d}  "
              f"{n * n:10d}  {kenar_inceleme:10d}  {gevsetme_sayisi:8d}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (Boost Graph Library
# dijkstra_shortest_paths, standart dışı); Python — yok (networkx
# dijkstra_path, standart dışı; yalnız kâhin olarak kullanılabilir).

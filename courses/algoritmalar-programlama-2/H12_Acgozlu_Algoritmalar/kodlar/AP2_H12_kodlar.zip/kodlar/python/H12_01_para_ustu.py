"""H12_01_para_ustu.py — AP-2 Hafta 12 · Örnek 1 (★)
Amaç    : Açgözlü para üstü (AP-1 H4'e dönüş): her adımda en büyük madeni
          parayı al; kanonik sistemlerde en iyi, {1, 3, 4} sisteminde 6
          için yanlış — kaba kuvvetle (tüm kombinasyonlar) gösterilir
Çalıştır: python3 H12_01_para_ustu.py
Eşleri  : c/H12_01_para_ustu.c · cpp/H12_01_para_ustu.cpp
Çıktı   : üç dilde aynı (=)
"""
UST_TUTAR = 100            # kaba kuvvet denetiminin üst sınırı

kombinasyon_sayisi = 0     # kaba kuvvette incelenen geçerli kombinasyon


def sistem_yaz(para):
    """Sistemi artan sırayla yazar: {1, 3, 4}"""
    return "{" + ", ".join(str(para[i])
                           for i in range(len(para) - 1, -1, -1)) + "}"


def acgozlu(para, tutar, adet):
    """para[] azalan sıralı; her adımda sığan en büyük parayı alır.
    Parça sayısını döndürür; ödenemezse -1."""
    parca = 0
    for i in range(len(para)):
        adet[i] = tutar // para[i]       # yerel en iyi seçim
        tutar -= adet[i] * para[i]
        parca += adet[i]
    return parca if tutar == 0 else -1


def kaba_kuvvet(para, i, kalan, adet, en_iyi, en_iyi_adet, liste):
    """Bütün kombinasyonlar: i. paradan 0..kalan/para[i] adet. En az
    parçalı kombinasyon en_iyi[0] ve en_iyi_adet'e yazılır."""
    global kombinasyon_sayisi
    k = len(para)
    if i == k - 1:                       # son para kalanı tam bölmeli
        if kalan % para[i] != 0:
            return
        adet[i] = kalan // para[i]
        kombinasyon_sayisi += 1
        parca = 0
        for j in range(k):
            parca += adet[j]
        if liste:
            print("    " + " + ".join(f"{para[j]}x{adet[j]}"
                                      for j in range(k)) + f" -> {parca}")
        if en_iyi[0] < 0 or parca < en_iyi[0]:
            en_iyi[0] = parca
            en_iyi_adet[:] = adet
        return
    for a in range(kalan // para[i], -1, -1):
        adet[i] = a
        kaba_kuvvet(para, i + 1, kalan - a * para[i], adet, en_iyi,
                    en_iyi_adet, liste)


def en_az_parca(para, tutar, en_iyi_adet, liste):
    adet = [0] * len(para)
    en_iyi = [-1]
    kaba_kuvvet(para, 0, tutar, adet, en_iyi, en_iyi_adet, liste)
    return en_iyi[0]


def cozum_yaz(para, tutar, adet, parca):
    terimler = [f"{para[i]}x{adet[i]}" for i in range(len(para))
                if adet[i] > 0]
    print(f"{tutar} = " + " + ".join(terimler) + f" -> {parca} parça")


def sistemi_dene(para):
    """1..UST_TUTAR için açgözlü ile kaba kuvveti karşılaştırır"""
    global kombinasyon_sayisi
    adet = [0] * len(para)
    en_iyi_adet = [0] * len(para)
    kombinasyon_sayisi = 0
    hatali = []
    for t in range(1, UST_TUTAR + 1):
        if acgozlu(para, t, adet) != en_az_parca(para, t, en_iyi_adet,
                                                 False):
            hatali.append(t)
    print(f"  {sistem_yaz(para)}: açgözlü {UST_TUTAR - len(hatali)}"
          f"/{UST_TUTAR} tutarda en iyi; incelenen kombinasyon = "
          f"{kombinasyon_sayisi}")
    if hatali:
        print(f"    en iyi olmadığı tutar sayısı = {len(hatali)}; ilk 8:"
              + "".join(f" {t}" for t in hatali[:8]))


def main():
    ap1 = [200, 100, 50, 20, 10, 5, 1]   # AP-1 H4'teki TL sistemi
    abd = [25, 10, 5, 1]
    bozuk = [4, 3, 1]
    yedi = [10, 7, 1]
    adet = [0] * 7
    en_iyi_adet = [0] * 7

    print(f"1) AP-1 H4 sistemi {sistem_yaz(ap1)}: açgözlü para üstü")
    print("  ", end="")
    cozum_yaz(ap1, 387, adet, acgozlu(ap1, 387, adet))

    print(f"\n2) Kaba kuvvetle doğrulama (tüm kombinasyonlar), tutar "
          f"1..{UST_TUTAR}")
    for para in (ap1, abd, bozuk, yedi):
        sistemi_dene(para)

    print(f"\n3) Karşı örnek: {sistem_yaz(bozuk)} sisteminde 6")
    print("  açgözlü : ", end="")
    cozum_yaz(bozuk, 6, adet, acgozlu(bozuk, 6, adet))
    global kombinasyon_sayisi
    kombinasyon_sayisi = 0
    print("  bütün kombinasyonlar (büyük paradan küçüğe):")
    en_iyi = en_az_parca(bozuk, 6, en_iyi_adet, True)
    print("  en iyi  : ", end="")
    cozum_yaz(bozuk, 6, en_iyi_adet, en_iyi)
    print(f"  ({kombinasyon_sayisi} kombinasyon incelendi)")
    print("  Açgözlü ilk adımda 4'ü seçer; kalan 2 yalnız 1 + 1 ile "
          "ödenir.\n  En iyi çözüm 4'ü hiç kullanmaz: açgözlü seçim "
          "özelliği bu sistemde yok.")

    print(f"\n4) Bir karşı örnek daha: {sistem_yaz(yedi)} sisteminde 14")
    print("  açgözlü : ", end="")
    cozum_yaz(yedi, 14, adet, acgozlu(yedi, 14, adet))
    print("  en iyi  : ", end="")
    cozum_yaz(yedi, 14, en_iyi_adet,
              en_az_parca(yedi, 14, en_iyi_adet, False))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — yok (açgözlü para üstü bir
# kütüphane işlevi değildir); en iyi çözüm için genel yöntem dinamik
# programlamadır (H13).

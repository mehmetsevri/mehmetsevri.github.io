"""H12_02_aralik_cizelgeleme.py — AP-2 Hafta 12 · Örnek 2 (★★)
Amaç    : Aralık çizelgeleme: en erken biten ilk; üç yanlış ölçütün (en
          kısa, en erken başlayan, en az çakışan) kaba kuvvetle doğrulanmış
          karşı örnekleri; değiş tokuş argümanının rastgele örneklerde
          kâhinle (kaba kuvvet) denetimi
Çalıştır: python3 H12_02_aralik_cizelgeleme.py
Eşleri  : c/H12_02_aralik_cizelgeleme.c ·
          cpp/H12_02_aralik_cizelgeleme.cpp
Çıktı   : üç dilde aynı (=)
Not     : aralıklar yarı açık [bas, bit): bit = sonraki bas ise
          çakışmaz; eşitlikte (bit, bas, kimlik) sırası
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum

DENEME = 1000              # rastgele örnek sayısı
DENEME_N = 8               # rastgele örnekte aralık sayısı


class Aralik:
    __slots__ = ("bas", "bit", "kimlik")

    def __init__(self, bas, bit, kimlik):
        self.bas = bas
        self.bit = bit
        self.kimlik = kimlik


def cakisir(a, b):
    return a.bas < b.bit and b.bas < a.bit


def ad(a):
    return chr(ord("A") + a.kimlik)


def en_erken_biten(a, secilen, yaz):
    """Bitişe göre sırala, tek geçiş: başlangıcı son bitişten küçük
    olmayanı al. Seçilen sayısını döndürür."""
    sira = sorted(a, key=lambda x: (x.bit, x.bas, x.kimlik))
    k = 0
    son_bitis = -1
    for x in sira:
        if x.bas >= son_bitis:           # açgözlü seçim
            secilen[k] = x
            k += 1
            if yaz and son_bitis < 0:
                serit_yaz(x)
                print("seçildi (ilk aralık)")
            elif yaz:
                serit_yaz(x)
                print(f"seçildi (bas {x.bas} >= son bitiş {son_bitis})")
            son_bitis = x.bit
        elif yaz:
            serit_yaz(x)
            print(f"elendi  (bas {x.bas} < son bitiş {son_bitis})")
    return k


def sirayla_sec(sira, secilen):
    """Verilen sırada dolaş; seçilenlerin hepsiyle uyumluysa al"""
    k = 0
    for x in sira:
        uyumlu = True
        for j in range(k):
            if cakisir(x, secilen[j]):
                uyumlu = False
        if uyumlu:
            secilen[k] = x
            k += 1
    return k


def en_kisa_ilk(a, secilen):
    sira = sorted(a, key=lambda x: (x.bit - x.bas, x.bas, x.kimlik))
    return sirayla_sec(sira, secilen)


def en_erken_baslayan(a, secilen):
    sira = sorted(a, key=lambda x: (x.bas, x.bit, x.kimlik))
    return sirayla_sec(sira, secilen)


def en_az_cakisan(a, secilen, yaz):
    """Kalanlar içinde en az çakışanı al, onunla çakışanları at; eşitlikte
    (çakışma, bas, kimlik)"""
    n = len(a)
    kalan = [True] * n
    k = 0
    while True:
        en_iyi, en_iyi_c = -1, 0
        for i in range(n):
            if not kalan[i]:
                continue
            c = 0
            for j in range(n):
                if j != i and kalan[j] and cakisir(a[i], a[j]):
                    c += 1
            if (en_iyi < 0 or c < en_iyi_c or
                    (c == en_iyi_c and a[i].bas < a[en_iyi].bas)):
                en_iyi, en_iyi_c = i, c
        if en_iyi < 0:
            return k
        if yaz:
            print(f"     seç {ad(a[en_iyi])} [{a[en_iyi].bas},"
                  f"{a[en_iyi].bit}) (kalanlarla çakışma = {en_iyi_c})")
        secilen[k] = a[en_iyi]
        k += 1
        for j in range(n):
            if kalan[j] and cakisir(a[en_iyi], a[j]):
                kalan[j] = False
        kalan[en_iyi] = False


def kaba_kuvvet(a):
    """Bütün alt kümeler (2^n); en çok aralıklı uyumlu alt kümenin
    maskesini döndürür (eşitlikte küçük maske)"""
    n = len(a)
    sira = sorted(a, key=lambda x: (x.bas, x.bit, x.kimlik))
    en_iyi_maske, en_iyi_k = 0, 0
    for maske in range(1 << n):
        k = 0
        son = -1
        gecerli = True
        for x in sira:                   # kimlik = dizideki konum
            if maske >> x.kimlik & 1:
                if x.bas < son:
                    gecerli = False
                    break
                son = x.bit
                k += 1
        if gecerli and k > en_iyi_k:
            en_iyi_maske, en_iyi_k = maske, k
    return en_iyi_maske


def maske_say(maske):
    k = 0
    while maske:
        k += maske & 1
        maske >>= 1
    return k


def serit_yaz(x):
    """Zaman şeridi: 0..15, aralık içi '#' (satır sonu çağırana kalır)"""
    serit = "".join("#" if x.bas <= t < x.bit else "."
                    for t in range(16))
    print(f"  {ad(x)} [{x.bas:2d}, {x.bit:2d})  {serit}  ", end="")


def liste_yaz(a):
    return " ".join(f"{ad(x)}[{x.bas},{x.bit})" for x in a)


def secim_yaz(secilen, k):
    return " ".join(ad(secilen[j]) for j in range(k))


def maske_yaz(a, maske):
    return " ".join(ad(a[i]) for i in range(len(a)) if maske >> i & 1)


def karsi_ornek(baslik, a, strateji):
    secilen = [None] * len(a)
    print(f"  {baslik}: {liste_yaz(a)}")
    if strateji == 2:
        k = en_az_cakisan(a, secilen, True)
    elif strateji == 0:
        k = en_kisa_ilk(a, secilen)
    else:
        k = en_erken_baslayan(a, secilen)
    maske = kaba_kuvvet(a)
    print(f"     strateji: {secim_yaz(secilen, k)} -> {k} aralık; en iyi "
          f"(kaba kuvvet, {1 << len(a)} alt küme): {maske_yaz(a, maske)} "
          f"-> {maske_say(maske)}")
    k2 = en_erken_biten(a, secilen, False)
    print(f"     en erken biten: {secim_yaz(secilen, k2)} -> {k2}")


def rastgele_denetim():
    """Kâhin: kaba kuvvet. Değiş tokuş: en iyi çözümün (bitişe göre) ilk
    aralığı açgözlünün ilkiyle değiştirilince çözüm geçerli kalır; önde
    kalma: r. açgözlü aralık en geç r. en iyi aralıkla biter."""
    rastgele_tohum(42)
    tamam = [0, 0, 0, 0]
    takas_gecerli = 0
    onde = 0
    secilen = [None] * DENEME_N
    for _ in range(DENEME):
        a = [None] * DENEME_N
        for i in range(DENEME_N):
            bas = rastgele_aralik(0, 20)
            a[i] = Aralik(bas, bas + rastgele_aralik(1, 8), i)
        maske = kaba_kuvvet(a)
        en_iyi = maske_say(maske)
        k0 = en_erken_biten(a, secilen, False)
        tamam[0] += k0 == en_iyi
        g = secilen[:k0]                 # açgözlünün seçtikleri
        tamam[1] += en_kisa_ilk(a, secilen) == en_iyi
        tamam[2] += en_erken_baslayan(a, secilen) == en_iyi
        tamam[3] += en_az_cakisan(a, secilen, False) == en_iyi
        o = sorted((a[i] for i in range(DENEME_N) if maske >> i & 1),
                   key=lambda x: (x.bit, x.bas, x.kimlik))
        ok = True
        for r in range(en_iyi):
            if g[r].bit > o[r].bit:
                ok = False
        onde += ok
        o[0] = g[0]                      # değiş tokuş adımı
        gecerli = True
        for i in range(en_iyi):
            for j in range(i + 1, en_iyi):
                if cakisir(o[i], o[j]):
                    gecerli = False
        takas_gecerli += gecerli
    print(f"  {DENEME} rastgele örnek (n = {DENEME_N}, bas 0..20, uzunluk "
          f"1..8, tohum 42); en iyiyi bulduğu örnek sayısı:")
    adlar = ["en erken biten   ", "en kısa ilk      ",
             "en erken başlayan", "en az çakışan    "]
    for s in range(4):
        print(f"    {adlar[s]}: {tamam[s]:4d}/{DENEME}")
    print(f"  değiş tokuş: en iyinin ilk aralığı açgözlünün ilkiyle "
          f"değiştirilince geçerli: {takas_gecerli}/{DENEME}")
    print(f"  açgözlü önde kalır (her r için g_r.bit <= o_r.bit): "
          f"{onde}/{DENEME}")


def main():
    veri = [(4, 7), (0, 3), (3, 8), (1, 4), (7, 10), (9, 12), (6, 9),
            (11, 14), (2, 6), (8, 13)]
    a = [Aralik(veri[i][0], veri[i][1], i) for i in range(len(veri))]
    secilen = [None] * len(a)
    print(f"1) En erken biten ilk: {len(a)} istek, yarı açık [bas, bit)")
    print(f"  girdi: {liste_yaz(a)}")
    print("  sıra (bit, bas, kimlik); zaman 0..15 her sütun 1 birim:")
    k = en_erken_biten(a, secilen, True)
    maske = kaba_kuvvet(a)
    print(f"  seçilen {k} aralık: {secim_yaz(secilen, k)}; kaba kuvvet "
          f"({1 << len(a)} alt küme) en çok {maske_say(maske)}")

    print("\n2) Yanlış ölçütler ve karşı örnekleri (kaba kuvvetle "
          "doğrulandı)")
    kisa = [Aralik(0, 5, 0), Aralik(4, 7, 1), Aralik(6, 11, 2)]
    karsi_ornek("a) en kısa ilk", kisa, 0)
    erken = [Aralik(0, 10, 0), Aralik(1, 3, 1), Aralik(4, 6, 2)]
    karsi_ornek("b) en erken başlayan", erken, 1)
    v = [(0, 3), (4, 7), (8, 11), (12, 15), (2, 5), (2, 5), (2, 5),
         (6, 9), (10, 13), (10, 13), (10, 13)]
    az = [Aralik(v[i][0], v[i][1], i) for i in range(len(v))]
    karsi_ornek("c) en az çakışan", az, 2)

    print("\n3) Kâhinle rastgele denetim ve değiş tokuş argümanı")
    rastgele_denetim()


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (qsort yalnız sıralama aracı); C++ — yok
# (std::sort aracı); Python — yok (sorted aracı). Aralık çizelgeleme bir
# kütüphane işlevi değildir.

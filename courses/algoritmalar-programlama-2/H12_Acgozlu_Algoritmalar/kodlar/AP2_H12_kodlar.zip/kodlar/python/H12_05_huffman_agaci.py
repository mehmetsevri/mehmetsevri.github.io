"""H12_05_huffman_agaci.py — AP-2 Hafta 12 · Örnek 5 (★★★)
Amaç    : Huffman ağacı: sıklık tablosu, en küçük öbekle iki en küçüğü
          birleştirme (her adımda öbek içeriği), kod tablosu (simge
          sırasıyla), ağırlıklı yol uzunluğu; tek simgeli metin sınırı
Çalıştır: python3 H12_05_huffman_agaci.py
Eşleri  : c/H12_05_huffman_agaci.c · cpp/H12_05_huffman_agaci.cpp
Çıktı   : üç dilde aynı (=)
Not     : öbek öğesi (sıklık, düğüm no) demeti. Düğüm no oluşturulma
          sırasıdır (yapraklar bayt değeri sırasıyla, sonra iç düğümler):
          eşit sıklıkta önce oluşturulan çıkar. İlk çıkan sol (0), ikinci
          sağ (1) çocuk olur. Tek düğümlü ağaçta kod "0" verilir.
"""
import heapq

itme_sayisi = 0
cikarma_sayisi = 0


class Agac:
    """Düğümler dizilerde: sembol (-1: iç düğüm), siklik, sol, sag"""
    __slots__ = ("sembol", "siklik", "sol", "sag", "kok")

    def __init__(self):
        self.sembol = []
        self.siklik = []
        self.sol = []
        self.sag = []
        self.kok = -1


def dugum_ekle(t, sembol, siklik, sol, sag):
    t.sembol.append(sembol)
    t.siklik.append(siklik)
    t.sol.append(sol)
    t.sag.append(sag)
    return len(t.sembol) - 1


def sembol_yaz(b):
    if b == 32:
        return "␣"
    if 33 <= b <= 126:
        return chr(b)
    return f"\\x{b:02X}"


def sola_yasla(s, genislik):
    """Görünür karakter sayısına göre doldurur (␣ tek karakterdir)"""
    return s + " " * (genislik - len(s))


def dugum_ad(t, i):
    return sembol_yaz(t.sembol[i]) if t.sembol[i] >= 0 else f"#{i}"


def obek_yaz(t, obek):
    return " ".join(f"{s}:{dugum_ad(t, d)}" for s, d in sorted(obek))


def agac_kur(siklik, yaz):
    """siklik[0..255] → Huffman ağacı (kök t.kok; boş metinde -1)"""
    global itme_sayisi, cikarma_sayisi
    t = Agac()
    obek = []
    for b in range(256):
        if siklik[b] > 0:                # yapraklar bayt sırasıyla
            d = dugum_ekle(t, b, siklik[b], -1, -1)
            heapq.heappush(obek, (siklik[b], d))
            itme_sayisi += 1
    if yaz:
        print(f"  başlangıç öbeği: {obek_yaz(t, obek)}")
    adim = 0
    while len(obek) > 1:
        fx, x = heapq.heappop(obek)      # en küçük iki ağaç
        fy, y = heapq.heappop(obek)
        cikarma_sayisi += 2
        z = dugum_ekle(t, -1, fx + fy, x, y)
        heapq.heappush(obek, (fx + fy, z))
        itme_sayisi += 1
        adim += 1
        if yaz:
            print(f"  adım {adim}: {fx}:{dugum_ad(t, x)} + {fy}:"
                  f"{dugum_ad(t, y)} -> #{z} ({fx + fy})   öbek: "
                  f"{obek_yaz(t, obek)}")
    if obek:
        t.kok = heapq.heappop(obek)[1]
        cikarma_sayisi += 1
    return t


def kod_ata(t, d, kod, kodlar):
    """Kökten yaprağa: sola 0, sağa 1"""
    if t.sembol[d] >= 0:
        kodlar[t.sembol[d]] = kod if kod else "0"   # tek düğüm: "0"
        return
    kod_ata(t, t.sol[d], kod + "0", kodlar)
    kod_ata(t, t.sag[d], kod + "1", kodlar)


def agac_ciz(t, d, girinti):
    """Yan yatırılmış ağaç: sağ (1) üstte, sol (0) altta"""
    if t.sembol[d] < 0:
        agac_ciz(t, t.sag[d], girinti + "      ")
    print(f"  {girinti}{t.siklik[d]}:{dugum_ad(t, d)}")
    if t.sembol[d] < 0:
        agac_ciz(t, t.sol[d], girinti + "      ")


def tablo_yaz(t, siklik, kodlar):
    """Kod tablosu simge sırasıyla; ağırlıklı yol uzunluğu"""
    print("  simge  sıklık  kod          uzunluk  sıklık×uzunluk")
    toplam = 0
    farkli = 0
    for b in range(256):
        if siklik[b] > 0:
            u = len(kodlar[b])
            toplam += siklik[b] * u
            farkli += 1
            print(f"  {sola_yasla(sembol_yaz(b), 5)}  {siklik[b]:6d}  "
                  f"{kodlar[b]:<12} "
                  f"{u:7d}  {siklik[b] * u:14d}")
    ic = 0
    for d in range(len(t.sembol)):
        if t.sembol[d] < 0:
            ic += t.siklik[d]
    sabit = 1
    while (1 << sabit) < farkli:
        sabit += 1
    n = 0
    for b in range(256):
        n += siklik[b]
    print(f"  ağırlıklı yol uzunluğu B(T) = Σ sıklık × uzunluk = {toplam} "
          f"bit")
    if t.sembol[t.kok] >= 0:
        print("  tek düğüm: kök yapraktır, kod uzunluğu 0 olurdu; kod \"0\" "
              "(1 bit/simge) verildi")
    else:
        print(f"  iç düğüm sıklıkları toplamı = {ic} (B(T) ile aynı "
              "olmalı)")
    print(f"  sabit uzunluklu kod: {farkli} simge -> {sabit} bit/simge, "
          f"{n} × {sabit} = {n * sabit} bit")


def onek_denetimi(siklik, kodlar):
    """Hiçbir kod başka bir kodun öneki değil mi? (O(k²) kaba denetim)"""
    for a in range(256):
        for b in range(256):
            if (a != b and siklik[a] > 0 and siklik[b] > 0 and
                    kodlar[b].startswith(kodlar[a])):
                return False
    return True


def calistir(baslik, siklik):
    global itme_sayisi, cikarma_sayisi
    itme_sayisi = cikarma_sayisi = 0
    print(baslik)
    t = agac_kur(siklik, True)
    kodlar = [""] * 256
    kod_ata(t, t.kok, "", kodlar)
    print("  ağaç (sağ çocuk = 1 üstte, sol çocuk = 0 altta):")
    agac_ciz(t, t.kok, "")
    tablo_yaz(t, siklik, kodlar)
    print(f"  önek özelliği: "
          f"{'sağlanıyor' if onek_denetimi(siklik, kodlar) else 'YOK'}; "
          f"öbeğe itme = {itme_sayisi}, çıkarma = {cikarma_sayisi}")


def metin_sikligi(metin):
    siklik = [0] * 256
    for b in metin:
        siklik[b] += 1
    return siklik


def main():
    siklik = [0] * 256
    for b, f in zip(b"abcdef", (45, 13, 12, 16, 9, 5)):
        siklik[b] = f
    calistir("1) Sıklık tablosu a:45 b:13 c:12 d:16 e:9 f:5 (Cormen vd.)",
             siklik)
    metin = b"ey edip adanada pide ye"
    calistir(f"\n2) Metin \"{metin.decode()}\" ({len(metin)} bayt; ␣ = "
             "boşluk)", metin_sikligi(metin))
    metin = b"aaaaaaa"
    calistir(f"\n3) Sınır durumu: tek simgeli metin \"{metin.decode()}\"",
             metin_sikligi(metin))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — Huffman ağacı kurucu yok (zlib
# içinde DEFLATE'in kendi Huffman kodlayıcısı vardır ama ağaç arayüzü
# sunmaz); öbek: C elle, C++ std::priority_queue, Python heapq.

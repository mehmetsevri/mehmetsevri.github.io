"""H12_13_graf_boyama.py — AP-2 Hafta 12 · Örnek 13 (★★★)
Amaç    : Açgözlü graf boyama (Welsh–Powell): köşeleri derece azalan
          (eşitlikte küçük numara) sırala; her renk için listeyi dolaş,
          o renkte komşusu olmayanı boya. Renk sayısı; kaba kuvvetle
          kromatik sayı; açgözlünün en iyi olmadığı karşı örnekler
Çalıştır: python3 H12_13_graf_boyama.py ../girdiler/h12_cakisma.txt \
          ../girdiler/h12_yol6.txt ../girdiler/h12_tac8.txt
Eşleri  : c/H12_13_graf_boyama.c · cpp/H12_13_graf_boyama.cpp
Çıktı   : üç dilde aynı (=)
Not     : sezgiseldir: sonucu "en iyi" diye raporlanmaz; kaba kuvvet
          (k^(V-1) boyama, köşe 0'ın rengi 0 sabit) yalnız küçük graflarda.
"""
import sys

SATIR_UZUNLUGU = 512                 # C'deki fgets tamponu (510 + '\n' + 0)
KABA_SINIR = 10                      # kaba kuvvet en çok bu kadar köşede

boyama_sayisi = 0      # kaba kuvvette incelenen boyama


class Graf:
    __slots__ = ("v_sayisi", "e_sayisi", "yonlu", "komsu", "kenar")

    def __init__(self, v_sayisi, e_sayisi, yonlu):
        self.v_sayisi = v_sayisi
        self.e_sayisi = e_sayisi
        self.yonlu = yonlu
        self.komsu = [[] for _ in range(v_sayisi)]  # (hedef, agirlik)
        self.kenar = []                              # (u, v, w)


def hata(ileti):
    print(f"Hata: {ileti}", file=sys.stderr)


def tamsayi_coz(s):
    """'-'? rakam+ (en çok 9 rakam); değilse None (üç dilde aynı kural)"""
    rakam = s[1:] if s[:1] == b"-" else s
    if len(rakam) == 0 or len(rakam) > 9:
        return None
    for c in rakam:
        if c < 48 or c > 57:             # '0'..'9'
            return None
    return int(s)


def graf_oku(yol):
    """Ortak graf dosyası (rehber 14.3): '#' yorum; 'V E [yonlu|yonsuz]';
    E satır 'u v [w]' (w yoksa 1). Hatada ileti + None (çıkış kodu 1)."""
    try:
        with open(yol, "rb") as f:
            satirlar = f.read().split(b"\n")
    except OSError:
        hata(f"dosya açılamadı: {yol}")
        return None
    g = None
    no = 0
    for satir in satirlar:
        no += 1
        if len(satir) > SATIR_UZUNLUGU - 2:
            hata(f"satır {no}: satır çok uzun")
            return None
        s = satir.strip()
        if len(s) == 0 or s[:1] == b"#":
            continue
        t = s.split()
        if g is None:
            v = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
            e = tamsayi_coz(t[1]) if v is not None else None
            tur = t[2] if len(t) == 3 else b"yonsuz"
            if (e is None or v < 1 or v > 1000000 or e < 0 or
                    e > 10000000 or tur not in (b"yonlu", b"yonsuz")):
                hata(f"satır {no}: başlık 'V E [yonlu|yonsuz]' "
                     "bekleniyordu")
                return None
            g = Graf(v, e, tur == b"yonlu")
            continue
        u = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
        v = tamsayi_coz(t[1]) if u is not None else None
        w = tamsayi_coz(t[2]) if len(t) == 3 else 1
        if v is None or w is None:
            hata(f"satır {no}: kenar 'u v [w]' bekleniyordu")
            return None
        if u < 0 or u >= g.v_sayisi or v < 0 or v >= g.v_sayisi:
            hata(f"satır {no}: köşe numarası 0..{g.v_sayisi - 1} "
                 "aralığında olmalı")
            return None
        if len(g.kenar) == g.e_sayisi:
            hata(f"satır {no}: fazla kenar (E = {g.e_sayisi})")
            return None
        g.kenar.append((u, v, w))
        g.komsu[u].append((v, w))
        if not g.yonlu:
            g.komsu[v].append((u, w))
    if g is None:
        hata("başlık satırı yok")
        return None
    if len(g.kenar) < g.e_sayisi:
        hata(f"kenar sayısı eksik: {g.e_sayisi} bekleniyordu, "
             f"{len(g.kenar)} okundu")
        return None
    for liste in g.komsu:
        liste.sort()                     # (hedef, agirlik) artan
    return g


def welsh_powell(g, renk, yaz):
    """Derece azalan sıra; renk c için sırayı dolaş, c renginde komşusu
    olmayan boyanmamış köşeyi c ile boya. Renk sayısını döndürür."""
    n = g.v_sayisi
    sira = sorted(range(n), key=lambda v: (-len(g.komsu[v]), v))
    if yaz:
        print("  sıra (derece azalan, eşitlikte küçük numara): " +
              " ".join(f"{v}(d={len(g.komsu[v])})" for v in sira))
    for v in range(n):
        renk[v] = -1
    boyanan = 0
    c = 0
    while boyanan < n:
        sinif = []
        for x in sira:
            if renk[x] != -1:
                continue
            uygun = True
            for y, _ in g.komsu[x]:
                if renk[y] == c:         # x'in c renkli komşusu var
                    uygun = False
                    break
            if uygun:
                renk[x] = c
                sinif.append(x)
                boyanan += 1
        if yaz:
            print(f"  renk {c}: " + " ".join(str(x) for x in sinif))
        c += 1
    return c


def sirali_boya(g, sira, renk):
    """Verilen sırada her köşeye komşularında kullanılmayan en küçük renk
    (first-fit). Renk sayısını döndürür."""
    n = g.v_sayisi
    for v in range(n):
        renk[v] = -1
    en_cok = 0
    for x in sira:
        kullanilan = [False] * (n + 1)
        for y, _ in g.komsu[x]:
            if renk[y] >= 0:
                kullanilan[renk[y]] = True
        c = 0
        while kullanilan[c]:
            c += 1
        renk[x] = c
        if c + 1 > en_cok:
            en_cok = c + 1
    return en_cok


def gecerli_mi(g, renk):
    for u, v, _ in g.kenar:
        if renk[u] == renk[v]:
            return False
    return True


def kromatik_sayi(g, renk):
    """Kaba kuvvet: k = 1, 2, … için bütün k^(V-1) boyamalar (köşe 0'ın
    rengi 0); ilk geçerli boyamanın k'si"""
    global boyama_sayisi
    n = g.v_sayisi
    for k in range(1, n + 1):
        for v in range(n):
            renk[v] = 0
        while True:
            boyama_sayisi += 1
            if gecerli_mi(g, renk):
                return k
            i = n - 1                    # sayaç gibi bir sonraki boyama
            while i >= 1 and renk[i] == k - 1:
                renk[i] = 0
                i -= 1
            if i < 1:
                break
            renk[i] += 1
    return n


def boya_ve_karsilastir(dosya, baslik):
    global boyama_sayisi
    g = graf_oku(dosya)
    if g is None:
        return None
    n = g.v_sayisi
    print(f"{baslik} — {dosya.split('/')[-1]}: {n} köşe, {g.e_sayisi} kenar")
    renk = [0] * n
    k = welsh_powell(g, renk, True)
    print(f"  Welsh–Powell renk sayısı = {k}; renkler: " +
          " ".join(f"{v}:{renk[v]}" for v in range(n)) +
          f"; geçerli mi? {'evet' if gecerli_mi(g, renk) else 'HAYIR'}")
    sira = sorted(range(n), key=lambda v: (-len(g.komsu[v]), v))
    ff = [0] * n
    sirali_boya(g, sira, ff)
    print(f"  aynı sırayla ilk uygun renk (first-fit) aynı boyamayı veriyor "
          f"mu? {'evet' if ff == renk else 'HAYIR'}")
    if n <= KABA_SINIR:
        boyama_sayisi = 0
        br = [0] * n
        chi = kromatik_sayi(g, br)
        print(f"  kaba kuvvet: kromatik sayı = {chi} ({boyama_sayisi} "
              "boyama incelendi); örnek: " +
              " ".join(f"{v}:{br[v]}" for v in range(n)))
        print(f"  Welsh–Powell {k} renk, en iyi {chi}: " +
              ("en iyi" if k == chi else f"{k - chi} renk FAZLA"))
    return g, renk, k


def main():
    if len(sys.argv) < 2:
        print("Kullanım: H12_13_graf_boyama GRAF_DOSYASI [GRAF_DOSYASI ...]",
              file=sys.stderr)
        sys.exit(2)
    sonuc = boya_ve_karsilastir(sys.argv[1], "1) Sınav çakışma grafı")
    if sonuc is None:
        sys.exit(1)
    g, renk, k = sonuc
    print("  oturum ataması (aynı oturumdaki dersler ortak öğrencisiz):")
    for c in range(k):
        print(f"    oturum {c + 1}: ders " +
              " ".join(str(v) for v in range(g.v_sayisi) if renk[v] == c))
    for i in range(2, len(sys.argv)):
        print()
        sonuc = boya_ve_karsilastir(sys.argv[i], f"{i}) Karşı örnek "
                                    f"{i - 1}")
        if sonuc is None:
            sys.exit(1)
        g, renk, k = sonuc
        sira = ([v for v in range(0, g.v_sayisi, 2)] +
                [v for v in range(1, g.v_sayisi, 2)])
        k2 = sirali_boya(g, sira, renk)
        print("  başka sıra (önce çift, sonra tek numaralılar: " +
              " ".join(str(v) for v in sira) + f") ile first-fit: {k2} "
              "renk — sonuç sıraya bağlı")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — yok (networkx
# greedy_color(strategy='largest_first'), standart dışı; yalnız kâhin).

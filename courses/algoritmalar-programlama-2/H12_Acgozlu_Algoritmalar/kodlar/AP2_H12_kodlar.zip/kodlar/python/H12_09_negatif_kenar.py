"""H12_09_negatif_kenar.py — AP-2 Hafta 12 · Örnek 9 (★★)
Amaç    : Negatif ağırlıklı kenarda Dijkstra'nın yanlış sonucu (karşı
          örnek): kesinleşen köşe sonradan bulunan kısa yolla
          güncellenemez. Kâhin: Bellman–Ford (yalnız doğrulama için).
          Ağırlıklara sabit eklemenin neden çözüm olmadığı
Çalıştır: python3 H12_09_negatif_kenar.py ../girdiler/h12_negatif.txt
Eşleri  : c/H12_09_negatif_kenar.c · cpp/H12_09_negatif_kenar.cpp
Çıktı   : üç dilde aynı (=)
Not     : Dijkstra Örnek 7'nin dizi tabanlı sürümüdür (önkoşul denetimi
          bu örnekte bilerek yapılmaz).
"""
import sys

SONSUZ = 2147483647                  # C INT_MAX ile aynı sabit
SATIR_UZUNLUGU = 512                 # C'deki fgets tamponu (510 + '\n' + 0)

taranan_hucre = 0
kenar_inceleme = 0
gevsetme_sayisi = 0


class Graf:
    __slots__ = ("v_sayisi", "e_sayisi", "yonlu", "komsu", "kenar")

    def __init__(self, v_sayisi, e_sayisi, yonlu):
        self.v_sayisi = v_sayisi
        self.e_sayisi = e_sayisi
        self.yonlu = yonlu
        self.komsu = [[] for _ in range(v_sayisi)]  # (hedef, agirlik)
        self.kenar = []                              # (u, v, w)


def hata(ileti):
    print(f"Hata: {ileti}", file=sys.stderr)


def tamsayi_coz(s):
    """'-'? rakam+ (en çok 9 rakam); değilse None (üç dilde aynı kural)"""
    rakam = s[1:] if s[:1] == b"-" else s
    if len(rakam) == 0 or len(rakam) > 9:
        return None
    for c in rakam:
        if c < 48 or c > 57:             # '0'..'9'
            return None
    return int(s)


def graf_oku(yol):
    """Ortak graf dosyası (rehber 14.3): '#' yorum; 'V E [yonlu|yonsuz]';
    E satır 'u v [w]' (w yoksa 1). Hatada ileti + None (çıkış kodu 1)."""
    try:
        with open(yol, "rb") as f:
            satirlar = f.read().split(b"\n")
    except OSError:
        hata(f"dosya açılamadı: {yol}")
        return None
    g = None
    no = 0
    for satir in satirlar:
        no += 1
        if len(satir) > SATIR_UZUNLUGU - 2:
            hata(f"satır {no}: satır çok uzun")
            return None
        s = satir.strip()
        if len(s) == 0 or s[:1] == b"#":
            continue
        t = s.split()
        if g is None:
            v = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
            e = tamsayi_coz(t[1]) if v is not None else None
            tur = t[2] if len(t) == 3 else b"yonsuz"
            if (e is None or v < 1 or v > 1000000 or e < 0 or
                    e > 10000000 or tur not in (b"yonlu", b"yonsuz")):
                hata(f"satır {no}: başlık 'V E [yonlu|yonsuz]' "
                     "bekleniyordu")
                return None
            g = Graf(v, e, tur == b"yonlu")
            continue
        u = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
        v = tamsayi_coz(t[1]) if u is not None else None
        w = tamsayi_coz(t[2]) if len(t) == 3 else 1
        if v is None or w is None:
            hata(f"satır {no}: kenar 'u v [w]' bekleniyordu")
            return None
        if u < 0 or u >= g.v_sayisi or v < 0 or v >= g.v_sayisi:
            hata(f"satır {no}: köşe numarası 0..{g.v_sayisi - 1} "
                 "aralığında olmalı")
            return None
        if len(g.kenar) == g.e_sayisi:
            hata(f"satır {no}: fazla kenar (E = {g.e_sayisi})")
            return None
        g.kenar.append((u, v, w))
        g.komsu[u].append((v, w))
        if not g.yonlu:
            g.komsu[v].append((u, w))
    if g is None:
        hata("başlık satırı yok")
        return None
    if len(g.kenar) < g.e_sayisi:
        hata(f"kenar sayısı eksik: {g.e_sayisi} bekleniyordu, "
             f"{len(g.kenar)} okundu")
        return None
    for liste in g.komsu:
        liste.sort()                     # (hedef, agirlik) artan
    return g


def uzaklik_yaz(d, genislik):
    s = "∞" if d == SONSUZ else str(d)
    return " " * (genislik - len(s)) + s


def dijkstra_dizi(g, kaynak, d, ebeveyn, yaz):
    """O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama"""
    global taranan_hucre, kenar_inceleme, gevsetme_sayisi
    n = g.v_sayisi
    kesin = [False] * n
    for v in range(n):
        d[v] = SONSUZ
        ebeveyn[v] = -1
    d[kaynak] = 0
    for adim in range(1, n + 1):
        u = -1
        for v in range(n):               # en küçük d: doğrusal tarama
            taranan_hucre += 1
            if (not kesin[v] and d[v] != SONSUZ and
                    (u < 0 or d[v] < d[u])):
                u = v
        if u < 0:
            break                        # kalanlar ulaşılamaz
        kesin[u] = True                  # d[u] artık kesin
        if yaz:
            print(f"  adım {adim}: seç {u} (d = {d[u]}); kesinleşen "
                  "{" + ", ".join(str(x) for x in range(n) if kesin[x])
                  + "}")
        for v, w in g.komsu[u]:
            kenar_inceleme += 1
            if kesin[v]:
                continue
            if d[u] != SONSUZ and d[u] + w < d[v]:   # taşma korumalı
                if yaz:
                    print(f"     gevşet {u}->{v} (w = {w}): d[{v}] = "
                          f"{uzaklik_yaz(d[v], 1)} -> {d[u] + w}")
                d[v] = d[u] + w
                ebeveyn[v] = u
                gevsetme_sayisi += 1
            elif yaz:
                print(f"     {u}->{v} (w = {w}): {d[u]} + {w} >= {d[v]}, "
                      "değişmez")
        if yaz:
            print("     d: " + " ".join(uzaklik_yaz(x, 1) for x in d))


def bellman_ford(g, kaynak, d, yaz):
    """Kâhin: V - 1 tur, her turda bütün kenarlar (dosya sırasıyla)
    gevşetilir; bir tur daha iyileşme varsa negatif döngü vardır.
    Negatif döngü varsa True döndürür."""
    for v in range(g.v_sayisi):
        d[v] = SONSUZ
    d[kaynak] = 0
    for tur in range(1, g.v_sayisi):
        degisti = False
        for u, v, w in g.kenar:
            if d[u] != SONSUZ and d[u] + w < d[v]:
                d[v] = d[u] + w
                degisti = True
            if not g.yonlu and d[v] != SONSUZ and d[v] + w < d[u]:
                d[u] = d[v] + w
                degisti = True
        if yaz:
            print(f"  tur {tur}: d = " +
                  " ".join(uzaklik_yaz(x, 1) for x in d))
        if not degisti:
            break
    for u, v, w in g.kenar:
        if d[u] != SONSUZ and d[u] + w < d[v]:
            return True
    return False


def gevsetilebilir(g, d):
    """En iyilik koşulu: hiçbir kenar d[u] + w < d[v] olmamalı. İhlal
    eden kenarları yazar, sayısını döndürür."""
    k = 0
    for u, v, w in g.kenar:
        if d[u] != SONSUZ and d[u] + w < d[v]:
            print(f"  {u}->{v} (w = {w}): d[{u}] + w = {d[u] + w} < d[{v}] "
                  f"= {d[v]}")
            k += 1
    return k


def yol_yaz(ebeveyn, hedef):
    s = []
    v = hedef
    while v != -1:
        s.append(v)
        v = ebeveyn[v]
    return " -> ".join(str(s[i]) for i in range(len(s) - 1, -1, -1))


def main():
    if len(sys.argv) != 2:
        print("Kullanım: H12_09_negatif_kenar GRAF_DOSYASI", file=sys.stderr)
        sys.exit(2)
    g = graf_oku(sys.argv[1])
    if g is None:
        sys.exit(1)
    n = g.v_sayisi
    print(f"1) Graf: {n} köşe, {g.e_sayisi} kenar, "
          f"{'yönlü' if g.yonlu else 'yönsüz'}; kenarlar: " +
          ", ".join(f"{u}->{v} ({w})" for u, v, w in g.kenar))
    en_kucuk = 0
    for _, _, w in g.kenar:
        if w < en_kucuk:
            en_kucuk = w
    print(f"  en küçük ağırlık = {en_kucuk}: Dijkstra'nın önkoşulu "
          f"(w >= 0) {'sağlanıyor' if en_kucuk >= 0 else 'SAĞLANMIYOR'}")

    print("\n2) Dizi tabanlı Dijkstra (Örnek 7), kaynak 0")
    d = [0] * n
    ebeveyn = [0] * n
    dijkstra_dizi(g, 0, d, ebeveyn, True)

    print("\n3) Kâhin: Bellman–Ford (yalnız doğrulama), kaynak 0")
    bf = [0] * n
    dongu = bellman_ford(g, 0, bf, True)
    print(f"  negatif döngü: {'VAR' if dongu else 'yok'}")

    print("\n4) Karşılaştırma")
    print("  köşe  Dijkstra  Bellman–Ford  doğru mu")
    yanlis = 0
    for v in range(n):
        dogru = d[v] == bf[v]
        yanlis += not dogru
        print(f"  {v:4d}  {uzaklik_yaz(d[v], 8)}  {uzaklik_yaz(bf[v], 12)}  "
              f"{'evet' if dogru else 'HAYIR'}")
    print(f"  {yanlis} köşede yanlış. Dijkstra'nın sonucunda hâlâ "
          "gevşetilebilen kenarlar\n  (en iyilik koşulu ihlali):")
    k = gevsetilebilir(g, d)
    print(f"  {k} kenar. Bu girdide 1 kesinleştikten sonra 2 -> 1 kenarı "
          "daha kısa yol verdi;\n  kesinleşen köşe yeniden işlenmediği için "
          "1 ve onun üzerinden 3 eski değerde kaldı.")

    print(f"\n5) Yaygın yanlış çözüm: bütün ağırlıklara {-en_kucuk} eklemek")
    kaydirilmis = Graf(n, g.e_sayisi, g.yonlu)
    for u, v, w in g.kenar:
        kaydirilmis.kenar.append((u, v, w - en_kucuk))
        kaydirilmis.komsu[u].append((v, w - en_kucuk))
        if not g.yonlu:
            kaydirilmis.komsu[v].append((u, w - en_kucuk))
    for liste in kaydirilmis.komsu:
        liste.sort()
    d2 = [0] * n
    e2 = [0] * n
    dijkstra_dizi(kaydirilmis, 0, d2, e2, False)
    hedef = n - 1
    ozgun = 0
    v = hedef
    while e2[v] != -1:
        for a, b, w in g.kenar:
            if a == e2[v] and b == v:
                ozgun += w
                break
        v = e2[v]
    print(f"  kaydırılmış grafta Dijkstra'nın 0 -> {hedef} yolu: "
          f"{yol_yaz(e2, hedef)} (kaydırılmış uzunluk {d2[hedef]}, özgün "
          f"uzunluk {ozgun})")
    print(f"  gerçek en kısa uzaklık (Bellman–Ford) = {bf[hedef]}: çok kenarlı"
          " yol kenar başına\n  ceza alır; sabit eklemek yolların sırasını "
          "değiştirir.")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — yok (Bellman–Ford: Boost Graph
# Library bellman_ford_shortest_paths, networkx bellman_ford_path —
# standart dışı; yalnız kâhin).

"""H12_04_kesirli_sirt_cantasi.py — AP-2 Hafta 12 · Örnek 4 (★★)
Amaç    : Kesirli sırt çantası: birim değere (değer/ağırlık) göre sırala,
          sığanı tam al, sonuncusunun kesrini al; değer tamsayı kesir
          olarak tutulur. Kâhin: bütün sıralamalar (n!). 0/1 sırt
          çantasında aynı ölçütün başarısızlığı (H13'e köprü)
Çalıştır: python3 H12_04_kesirli_sirt_cantasi.py
Eşleri  : c/H12_04_kesirli_sirt_cantasi.c ·
          cpp/H12_04_kesirli_sirt_cantasi.cpp
Çıktı   : üç dilde aynı (=)
Not     : oranlar çapraz çarpımla karşılaştırılır (v1·w2 ile v2·w1):
          kayan nokta yok; eşitlikte küçük kimlik önce
"""
import functools


class Yuk:
    __slots__ = ("agirlik", "deger", "kimlik")

    def __init__(self, agirlik, deger, kimlik):
        self.agirlik = agirlik
        self.deger = deger
        self.kimlik = kimlik


def ebob(a, b):
    while b != 0:
        a, b = b, a % b
    return a


def ondalik(pay, payda):
    """pay/payda'yı iki basamakla yuvarlar (tamsayı aritmetiği)"""
    yuz = (pay * 200 + payda) // (2 * payda)
    return f"{yuz // 100}.{yuz % 100:02d}"


def kesir_yaz(pay, payda):
    if payda == 1:
        return f"{pay}"
    return f"{pay}/{payda} = {ondalik(pay, payda)}"


def birim_degere_gore(x, y):
    """x önce gelmeli mi? x.deger/x.agirlik > y.deger/y.agirlik"""
    sol, sag = x.deger * y.agirlik, y.deger * x.agirlik
    if sol != sag:
        return -1 if sol > sag else 1
    return -1 if x.kimlik < y.kimlik else (1 if x.kimlik > y.kimlik else 0)


def doldur(sira, kapasite, yaz):
    """Sırayla doldurur; değeri indirgenmiş (pay, payda) olarak döndürür"""
    tam = 0
    kalan = kapasite
    for x in sira:
        if kalan == 0:
            break
        if x.agirlik <= kalan:           # tamamı sığar
            kalan -= x.agirlik
            tam += x.deger
            if yaz:
                print(f"  {chr(65 + x.kimlik)}: {x.agirlik:2d}/"
                      f"{x.agirlik:2d} kg alındı (+{x.deger}), kalan "
                      f"kapasite {kalan}")
        else:                            # kesri alınır, çanta dolar
            pay = tam * x.agirlik + x.deger * kalan
            payda = x.agirlik
            g = ebob(pay, payda)
            if yaz:
                print(f"  {chr(65 + x.kimlik)}: {kalan:2d}/{x.agirlik:2d} "
                      f"kg alındı (+{x.deger}·{kalan}/{x.agirlik}), kalan "
                      "kapasite 0")
                print(f"  toplam değer = {tam} + {x.deger * kalan}/"
                      f"{x.agirlik} = {kesir_yaz(pay // g, payda // g)}")
            return pay // g, payda // g
    if yaz:
        print(f"  toplam değer = {tam}")
    return tam, 1


def sonraki_permutasyon(p):
    """Sözlük sırasında sonraki permütasyon; son permütasyondaysa False"""
    i = len(p) - 2
    while i >= 0 and p[i] >= p[i + 1]:
        i -= 1
    if i < 0:
        return False
    j = len(p) - 1
    while p[j] <= p[i]:
        j -= 1
    p[i], p[j] = p[j], p[i]
    p[i + 1:] = p[i + 1:][::-1]
    return True


def kahin(yuk, kapasite):
    """Bütün n! sırayla doldurma; en büyük değeri ve sıra sayısını verir"""
    p = list(range(len(yuk)))
    en_pay, en_payda = -1, 1
    sayi = 0
    while True:
        sayi += 1
        pay, payda = doldur([yuk[i] for i in p], kapasite, False)
        if pay * en_payda > en_pay * payda:
            en_pay, en_payda = pay, payda
        if not sonraki_permutasyon(p):
            return en_pay, en_payda, sayi


def sifir_bir_kaba(yuk, kapasite):
    """0/1: bütün alt kümeler; (en iyi değer, maske)"""
    n = len(yuk)
    en_iyi, en_maske = -1, 0
    for maske in range(1 << n):
        w = v = 0
        for i in range(n):
            if maske >> i & 1:
                w += yuk[i].agirlik
                v += yuk[i].deger
        if w <= kapasite and v > en_iyi:
            en_iyi, en_maske = v, maske
    return en_iyi, en_maske


def main():
    veri = [(12, 84), (8, 40), (20, 100), (15, 90), (25, 80), (9, 30)]
    yuk = [Yuk(veri[i][0], veri[i][1], i) for i in range(len(veri))]
    kapasite = 60
    print(f"1) Kesirli sırt çantası: kapasite {kapasite} kg, {len(yuk)} "
          "yük")
    print("  yük  ağırlık  değer  birim değer")
    for x in yuk:
        print(f"  {chr(65 + x.kimlik)}   {x.agirlik:5d}  {x.deger:5d}  "
              f"{ondalik(x.deger, x.agirlik):>11}")
    sira = sorted(yuk, key=functools.cmp_to_key(birim_degere_gore))
    print("  birim değere göre sıra (azalan; eşitlikte kimlik): " +
          " ".join(chr(65 + x.kimlik) for x in sira))
    pay, payda = doldur(sira, kapasite, True)

    print(f"\n2) Kâhin: {len(yuk)} yükün bütün sıralamalarıyla doldurma")
    en_pay, en_payda, sayi = kahin(yuk, kapasite)
    print(f"  {sayi} sıralama; en büyük değer {kesir_yaz(en_pay, en_payda)}"
          f"; birim değer sırası bunu veriyor mu? "
          f"{'evet' if (pay, payda) == (en_pay, en_payda) else 'HAYIR'}")
    sira = sorted(yuk, key=lambda x: (-x.deger, x.kimlik))
    p, q = doldur(sira, kapasite, False)
    print(f"  'en değerli ilk' sırası : {kesir_yaz(p, q)}")
    sira = sorted(yuk, key=lambda x: (x.agirlik, x.kimlik))
    p, q = doldur(sira, kapasite, False)
    print(f"  'en hafif ilk' sırası   : {kesir_yaz(p, q)}")

    print("\n3) 0/1 sırt çantasında birim değer ölçütü yetmez (H13'e köprü)")
    kucuk = [Yuk(10, 60, 0), Yuk(20, 100, 1), Yuk(30, 120, 2)]
    print("  kapasite 50: A(10 kg, 60) B(20 kg, 100) C(30 kg, 120)")
    sira = sorted(kucuk, key=functools.cmp_to_key(birim_degere_gore))
    p, q = doldur(sira, 50, False)
    print(f"  kesirli açgözlü          : {kesir_yaz(p, q)}")
    w = v = 0
    alinan = ""
    for x in sira:                       # 0/1: ya tamamı ya hiç
        if w + x.agirlik <= 50:
            w += x.agirlik
            v += x.deger
            alinan += chr(65 + x.kimlik)
    print(f"  0/1 açgözlü (birim değer): {alinan} -> {v}")
    en_iyi, maske = sifir_bir_kaba(kucuk, 50)
    print(f"  0/1 en iyi (kaba kuvvet, {1 << len(kucuk)} alt küme): " +
          "".join(chr(65 + i) for i in range(len(kucuk)) if maske >> i & 1)
          + f" -> {en_iyi}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — yok; sıralama aracı qsort /
# std::sort / sorted (karşılaştırıcı tam sıralama tanımlar).

"""H12_12_prim.py — AP-2 Hafta 12 · Örnek 12 (★★★)
Amaç    : Prim (öbekle, tembel silme) ile en küçük kapsayan ağaç ve
          Kruskal (Örnek 11) ile karşılaştırma: aynı toplam ağırlık;
          ağırlıklar farklıyken aynı ağaç, eşit ağırlıklarda farklı ağaç
          olabilir; rastgele graflarda denetim
Çalıştır: python3 H12_12_prim.py ../girdiler/h12_kampus.txt \
          ../girdiler/h12_esit_agirlik.txt
Eşleri  : c/H12_12_prim.c · cpp/H12_12_prim.cpp
Çıktı   : üç dilde aynı (=)
Not     : öbek öğesi (anahtar, köşe); anahtar[v] = v'yi ağaca bağlayan en
          hafif kenarın ağırlığı. Dijkstra'yla aynı iskelet: yalnız
          gevşetme koşulu d[u] + w < d[v] yerine w < anahtar[v].
"""
import heapq
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum

SONSUZ = 2147483647                  # C INT_MAX ile aynı sabit
SATIR_UZUNLUGU = 512                 # C'deki fgets tamponu (510 + '\n' + 0)

itme_sayisi = 0
cikarma_sayisi = 0
atlanan_sayisi = 0
izleme_sayisi = 0      # Kruskal'ın birleşim–bul sayaçları
bul_sayisi = 0
birlestir_sayisi = 0


class Graf:
    __slots__ = ("v_sayisi", "e_sayisi", "yonlu", "komsu", "kenar")

    def __init__(self, v_sayisi, e_sayisi, yonlu):
        self.v_sayisi = v_sayisi
        self.e_sayisi = e_sayisi
        self.yonlu = yonlu
        self.komsu = [[] for _ in range(v_sayisi)]  # (hedef, agirlik)
        self.kenar = []                              # (u, v, w)


def hata(ileti):
    print(f"Hata: {ileti}", file=sys.stderr)


def tamsayi_coz(s):
    """'-'? rakam+ (en çok 9 rakam); değilse None (üç dilde aynı kural)"""
    rakam = s[1:] if s[:1] == b"-" else s
    if len(rakam) == 0 or len(rakam) > 9:
        return None
    for c in rakam:
        if c < 48 or c > 57:             # '0'..'9'
            return None
    return int(s)


def graf_oku(yol):
    """Ortak graf dosyası (rehber 14.3): '#' yorum; 'V E [yonlu|yonsuz]';
    E satır 'u v [w]' (w yoksa 1). Hatada ileti + None (çıkış kodu 1)."""
    try:
        with open(yol, "rb") as f:
            satirlar = f.read().split(b"\n")
    except OSError:
        hata(f"dosya açılamadı: {yol}")
        return None
    g = None
    no = 0
    for satir in satirlar:
        no += 1
        if len(satir) > SATIR_UZUNLUGU - 2:
            hata(f"satır {no}: satır çok uzun")
            return None
        s = satir.strip()
        if len(s) == 0 or s[:1] == b"#":
            continue
        t = s.split()
        if g is None:
            v = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
            e = tamsayi_coz(t[1]) if v is not None else None
            tur = t[2] if len(t) == 3 else b"yonsuz"
            if (e is None or v < 1 or v > 1000000 or e < 0 or
                    e > 10000000 or tur not in (b"yonlu", b"yonsuz")):
                hata(f"satır {no}: başlık 'V E [yonlu|yonsuz]' "
                     "bekleniyordu")
                return None
            g = Graf(v, e, tur == b"yonlu")
            continue
        u = tamsayi_coz(t[0]) if len(t) in (2, 3) else None
        v = tamsayi_coz(t[1]) if u is not None else None
        w = tamsayi_coz(t[2]) if len(t) == 3 else 1
        if v is None or w is None:
            hata(f"satır {no}: kenar 'u v [w]' bekleniyordu")
            return None
        if u < 0 or u >= g.v_sayisi or v < 0 or v >= g.v_sayisi:
            hata(f"satır {no}: köşe numarası 0..{g.v_sayisi - 1} "
                 "aralığında olmalı")
            return None
        if len(g.kenar) == g.e_sayisi:
            hata(f"satır {no}: fazla kenar (E = {g.e_sayisi})")
            return None
        g.kenar.append((u, v, w))
        g.komsu[u].append((v, w))
        if not g.yonlu:
            g.komsu[v].append((u, w))
    if g is None:
        hata("başlık satırı yok")
        return None
    if len(g.kenar) < g.e_sayisi:
        hata(f"kenar sayısı eksik: {g.e_sayisi} bekleniyordu, "
             f"{len(g.kenar)} okundu")
        return None
    for liste in g.komsu:
        liste.sort()                     # (hedef, agirlik) artan
    return g


def uzaklik_yaz(d, genislik):
    s = "∞" if d == SONSUZ else str(d)
    return " " * (genislik - len(s)) + s


def obek_yaz(obek):
    return "[" + " ".join(f"({k},{v})" for k, v in sorted(obek)) + "]"


def prim(g, bas, agac, yaz):
    """Öbekli Prim; ağaç kenarlarını (min, max, w) olarak agac'a ekler,
    toplam ağırlığı döndürür (yalnız bas'ın bileşeni)"""
    global itme_sayisi, cikarma_sayisi, atlanan_sayisi
    n = g.v_sayisi
    anahtar = [SONSUZ] * n
    ebeveyn = [-1] * n
    agacta = [False] * n
    anahtar[bas] = 0
    obek = [(0, bas)]
    itme_sayisi += 1
    toplam = 0
    while obek:
        k, u = heapq.heappop(obek)
        cikarma_sayisi += 1
        if agacta[u]:                    # eskimiş kayıt
            atlanan_sayisi += 1
            if yaz:
                print(f"  çıkar ({k},{u}): ESKİMİŞ ({u} ağaçta) -> atla")
            continue
        agacta[u] = True
        toplam += k
        if ebeveyn[u] >= 0:
            p = ebeveyn[u]
            agac.append((p if p < u else u, u if p < u else p, k))
        if yaz:
            print(f"  çıkar ({k},{u}): {u} ağaca girdi" +
                  (f" (kenar {ebeveyn[u]}-{u}, {k})" if ebeveyn[u] >= 0
                   else " (başlangıç)"))
        for v, w in g.komsu[u]:
            if not agacta[v] and w < anahtar[v]:
                if yaz:
                    print(f"     anahtar[{v}] = "
                          f"{uzaklik_yaz(anahtar[v], 1)} -> {w} ({u}-{v}),"
                          f" it ({w},{v})")
                anahtar[v] = w
                ebeveyn[v] = u
                heapq.heappush(obek, (w, v))
                itme_sayisi += 1
        if yaz:
            print(f"     öbek: {obek_yaz(obek)}")
    return toplam


class BirlesimBul:
    """Örnek 10'un 'rütbe + sıkıştırma' sürümü"""
    __slots__ = ("ebeveyn", "rutbe")

    def __init__(self, n):
        self.ebeveyn = list(range(n))
        self.rutbe = [0] * n


def bul(b, x):
    global izleme_sayisi, bul_sayisi
    bul_sayisi += 1
    kok = x
    while b.ebeveyn[kok] != kok:
        kok = b.ebeveyn[kok]
        izleme_sayisi += 1
    while b.ebeveyn[x] != kok:           # yol sıkıştırma
        sonraki = b.ebeveyn[x]
        b.ebeveyn[x] = kok
        x = sonraki
    return kok


def birlestir_kok(b, kx, ky):
    """İki farklı kökü rütbeye göre bağlar"""
    global birlestir_sayisi
    birlestir_sayisi += 1
    if b.rutbe[kx] < b.rutbe[ky]:
        kx, ky = ky, kx
    b.ebeveyn[ky] = kx
    if b.rutbe[kx] == b.rutbe[ky]:
        b.rutbe[kx] += 1


def kok_sayacsiz(b, x):
    """Kesim denetimi için: sayaçsız, sıkıştırmasız kök"""
    while b.ebeveyn[x] != x:
        x = b.ebeveyn[x]
    return x


def kesim(g, b, ku):
    """Birleştirmeden ÖNCE: S = ku kökünün kümesi; S ile V - S arasındaki
    en hafif kenarın ağırlığı. (S üyelik listesi, en hafif) döndürür."""
    n = g.v_sayisi
    s = [kok_sayacsiz(b, x) == ku for x in range(n)]
    en_hafif = -1
    for u, v, wk in g.kenar:
        if s[u] != s[v] and (en_hafif < 0 or wk < en_hafif):
            en_hafif = wk
    return s, en_hafif


def kruskal(g, agac, yaz):
    """Kenarları (w, u, v) sırasıyla dolaş; uçlar farklı ağaçtaysa al.
    Ağaç kenarlarını agac'a ekler, toplam ağırlığı döndürür."""
    sira = sorted((w, u if u < v else v, v if u < v else u)
                  for u, v, w in g.kenar)
    b = BirlesimBul(g.v_sayisi)
    toplam = 0
    adim = 0
    for w, u, v in sira:
        adim += 1
        ku, kv = bul(b, u), bul(b, v)
        if ku == kv:
            if yaz:
                print(f"  {adim:2d}  ({w:3d}, {u}, {v})  {ku} {kv}     RET    "
                      f"döngü: {u} ile {v} zaten aynı ağaçta")
            continue
        if yaz:
            s, en_hafif = kesim(g, b, ku)
        birlestir_kok(b, ku, kv)         # iki ağaç birleşir
        agac.append((u, v, w))
        toplam += w
        if yaz:
            print(f"  {adim:2d}  ({w:3d}, {u}, {v})  {ku} {kv}     KABUL  "
                  "ebeveyn: " + " ".join(str(x) for x in b.ebeveyn))
            print("      kesim S = {" + ", ".join(
                str(x) for x in range(g.v_sayisi) if s[x]) +
                f"}}: S'den çıkan en hafif kenar {en_hafif} " +
                ("= w (kesim özelliği)" if en_hafif == w else "!= w (HATA)"))
            if len(agac) == g.v_sayisi - 1:
                print(f"      (ağaç tamam: V - 1 = {g.v_sayisi - 1} kenar; "
                      "erken durdurma kalanları incelemezdi)")
    return toplam


def agac_yaz(agac):
    return ", ".join(f"{u}-{v} ({w})" for u, v, w in agac)


def rastgele_yonsuz(n, m, w_ust, tohum):
    """Bağlı yönsüz graf: yol 0-1-…-(n-1) + rastgele kenarlar (u != v);
    çoklu kenar olabilir. Ağırlıklar 1..w_ust: çok sayıda eşitlik."""
    rastgele_tohum(tohum)
    g = Graf(n, m, False)
    for u in range(n - 1):
        g.kenar.append((u, u + 1, rastgele_aralik(1, w_ust)))
    while len(g.kenar) < m:
        u = rastgele_aralik(0, n - 1)
        v = rastgele_aralik(0, n - 1)
        w = rastgele_aralik(1, w_ust)
        if u != v:
            g.kenar.append((u, v, w))
    for u, v, w in g.kenar:
        g.komsu[u].append((v, w))
        g.komsu[v].append((u, w))
    for liste in g.komsu:
        liste.sort()
    return g


def karsilastir(dosya):
    global itme_sayisi, cikarma_sayisi, atlanan_sayisi
    g = graf_oku(dosya)
    if g is None:
        return 1
    if g.yonlu:
        hata("en küçük kapsayan ağaç yönsüz graf ister")
        return 1
    print(f"  graf: {g.v_sayisi} köşe, {g.e_sayisi} kenar")
    itme_sayisi = cikarma_sayisi = atlanan_sayisi = 0
    ap = []
    tp = prim(g, 0, ap, True)
    ak = []
    tk = kruskal(g, ak, False)
    print(f"  Prim    : {agac_yaz(sorted(ap))}; toplam {tp}")
    print(f"  Kruskal : {agac_yaz(sorted(ak))}; toplam {tk}")
    print(f"  sayaçlar (Prim): itme = {itme_sayisi}, çıkarma = "
          f"{cikarma_sayisi}, atlanan = {atlanan_sayisi}")
    ayni = sorted(ap) == sorted(ak)
    print(f"  toplamlar eşit mi? {'evet' if tp == tk else 'HAYIR'}; kenar "
          f"kümeleri aynı mı? {'evet' if ayni else 'HAYIR'}")
    return 0


def main():
    global itme_sayisi, cikarma_sayisi, atlanan_sayisi
    if len(sys.argv) not in (2, 3):
        print("Kullanım: H12_12_prim GRAF_DOSYASI [GRAF_DOSYASI2]",
              file=sys.stderr)
        sys.exit(2)
    print("1) Prim (öbekle) 0'dan; Kruskal ile karşılaştırma — "
          f"{sys.argv[1].split('/')[-1]}")
    if karsilastir(sys.argv[1]) != 0:
        sys.exit(1)
    print("  Ağırlıklar birbirinden farklıysa en küçük kapsayan ağaç "
          "tektir: iki algoritma\n  aynı kenarları bulur.")
    if len(sys.argv) == 3:
        print("\n2) Eşit ağırlıklı kenarlar — "
              f"{sys.argv[2].split('/')[-1]}")
        if karsilastir(sys.argv[2]) != 0:
            sys.exit(1)
        print("  Toplam aynı, ağaç farklı olabilir: eşit ağırlıklı "
              "kenarlardan hangisinin\n  seçileceğini eşitlik kırma kuralı "
              "belirler (Kruskal: (w, u, v) sırası;\n  Prim: başlangıç "
              "köşesi ve (anahtar, köşe) sırası).")
    print("\n3) Rastgele bağlı yönsüz graflar: V = 50, E = 200, ağırlık "
          "1..10 (tohum 1..20)")
    esit_toplam = farkli_agac = 0
    for tohum in range(1, 21):
        r = rastgele_yonsuz(50, 200, 10, tohum)
        ap = []
        ak = []
        tp = prim(r, 0, ap, False)
        tk = kruskal(r, ak, False)
        esit_toplam += tp == tk
        farkli_agac += sorted(ap) != sorted(ak)
    print(f"  toplamlar eşit: {esit_toplam}/20; ağaç kenar kümesi farklı: "
          f"{farkli_agac}/20")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C, C++, Python — yok (Boost Graph Library
# prim_minimum_spanning_tree, networkx minimum_spanning_tree
# (algorithm='prim') — standart dışı; yalnız kâhin).

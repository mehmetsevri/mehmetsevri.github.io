"""H12_06_huffman_kodlama.py — AP-2 Hafta 12 · Örnek 6 (★★★)
Amaç    : Huffman ile metin kodlama/çözme: bit tamponu (bytearray), bayt
          hizalama ve dolgu bitleri, kodlanmış bayt sayısı, sıkıştırma
          oranı, entropiyle karşılaştırma; çözülen metin = özgün metin
Çalıştır: python3 H12_06_huffman_kodlama.py \
          < ../girdiler/H12_06_huffman_kodlama.txt
Eşleri  : c/H12_06_huffman_kodlama.c · cpp/H12_06_huffman_kodlama.cpp
Çıktı   : üç dilde aynı (=)
Not     : ağaç Örnek 5'teki gibi kurulur. Kodlanmış bayt sayısına ağaç
          (ya da kod uzunlukları tablosu) DAHİL DEĞİLDİR; bir dosya biçimi
          onu da saklamalıdır (2. bölümün son satırı).
"""
import heapq
import math
import sys


class Agac:
    """Düğümler dizilerde: sembol (-1: iç düğüm), siklik, sol, sag"""
    __slots__ = ("sembol", "siklik", "sol", "sag", "kok")

    def __init__(self):
        self.sembol = []
        self.siklik = []
        self.sol = []
        self.sag = []
        self.kok = -1


def dugum_ekle(t, sembol, siklik, sol, sag):
    t.sembol.append(sembol)
    t.siklik.append(siklik)
    t.sol.append(sol)
    t.sag.append(sag)
    return len(t.sembol) - 1


def agac_kur(siklik):
    """siklik[0..255] → Huffman ağacı; öbek öğesi (sıklık, düğüm no)"""
    t = Agac()
    obek = []
    for b in range(256):
        if siklik[b] > 0:
            d = dugum_ekle(t, b, siklik[b], -1, -1)
            heapq.heappush(obek, (siklik[b], d))
    while len(obek) > 1:
        fx, x = heapq.heappop(obek)
        fy, y = heapq.heappop(obek)
        z = dugum_ekle(t, -1, fx + fy, x, y)
        heapq.heappush(obek, (fx + fy, z))
    if obek:
        t.kok = heapq.heappop(obek)[1]
    return t


def kod_ata(t, d, kod, kodlar):
    if t.sembol[d] >= 0:
        kodlar[t.sembol[d]] = kod if kod else "0"   # tek düğüm: "0"
        return
    kod_ata(t, t.sol[d], kod + "0", kodlar)
    kod_ata(t, t.sag[d], kod + "1", kodlar)


def kodla(metin, kodlar):
    """Bit tamponu: bit i, bayt i >> 3'ün (7 - i & 7). bitine (önce en
    anlamlı bit) yazılır. (tampon, toplam bit) döndürür."""
    toplam = 0
    for b in metin:
        toplam += len(kodlar[b])
    tampon = bytearray((toplam + 7) // 8)          # sıfırlarla dolu
    i = 0
    for b in metin:
        for c in kodlar[b]:
            if c == "1":
                tampon[i >> 3] |= 0x80 >> (i & 7)
            i += 1
    return tampon, toplam


def coz(t, tampon, toplam_bit):
    """Kökten başla; 0 sola, 1 sağa; yaprakta simgeyi yaz, köke dön"""
    cikti = bytearray()
    d = t.kok
    for i in range(toplam_bit):
        if t.sembol[t.kok] >= 0:         # tek düğüm: her bit bir simge
            cikti.append(t.sembol[t.kok])
            continue
        bit = tampon[i >> 3] >> (7 - (i & 7)) & 1
        d = t.sag[d] if bit else t.sol[d]
        if t.sembol[d] >= 0:
            cikti.append(t.sembol[d])
            d = t.kok
    return cikti


def fnv1a(veri):
    h = 2166136261
    for b in veri:
        h = ((h ^ b) * 16777619) & 0xFFFFFFFF
    return h


def sembol_yaz(b):
    if b == 32:
        return "␣"
    if 33 <= b <= 126:
        return chr(b)
    return f"\\x{b:02X}"


def ondalik(pay, payda, basamak):
    """pay/payda'yı 'basamak' ondalıkla yuvarlar (tamsayı aritmetiği)"""
    olcek = 10 ** basamak
    x = (pay * olcek * 2 + payda) // (2 * payda)
    return f"{x // olcek}.{x % olcek:0{basamak}d}"


def siklik_say(metin):
    siklik = [0] * 256
    for b in metin:
        siklik[b] += 1
    return siklik


def kucuk_ornek(metin):
    print(f"1) Küçük örnek: \"{metin.decode()}\" ({len(metin)} bayt)")
    t = agac_kur(siklik_say(metin))
    kodlar = [""] * 256
    kod_ata(t, t.kok, "", kodlar)
    tampon, toplam = kodla(metin, kodlar)
    print("  simge kodları (Örnek 5):", " ".join(
        f"{sembol_yaz(b)}={kodlar[b]}" for b in range(256) if kodlar[b]))
    satir = ""
    for i in range(len(tampon) * 8):
        if i > 0 and i % 8 == 0:
            satir += " "
        if i < toplam:
            satir += str(tampon[i >> 3] >> (7 - (i & 7)) & 1)
        else:
            satir += "x"
    print(f"  bitler (bayt bayt; x = dolgu): {satir}")
    print(f"  {toplam} bit -> {len(tampon)} bayt (dolgu "
          f"{len(tampon) * 8 - toplam} bit):",
          " ".join(f"{b:02X}" for b in tampon))
    cozulen = coz(t, tampon, toplam)
    print(f"  çözülen: \"{cozulen.decode()}\" (aynı mı? "
          f"{'evet' if cozulen == metin else 'HAYIR'})")


def buyuk_ornek(metin):
    n = len(metin)
    siklik = siklik_say(metin)
    t = agac_kur(siklik)
    kodlar = [""] * 256
    kod_ata(t, t.kok, "", kodlar)
    farkli = 0
    en_uzun = 0
    for b in range(256):
        if siklik[b] > 0:
            farkli += 1
            if len(kodlar[b]) > en_uzun:
                en_uzun = len(kodlar[b])
    print(f"\n2) Ömer Seyfettin metni (standart girdi): {n} bayt, {farkli} "
          "farklı bayt değeri")
    dagilim = [0] * (en_uzun + 1)
    for b in range(256):
        if siklik[b] > 0:
            dagilim[len(kodlar[b])] += 1
    print("  kod uzunluğu -> simge sayısı:", ", ".join(
        f"{u}:{dagilim[u]}" for u in range(1, en_uzun + 1) if dagilim[u]))
    sira = sorted((b for b in range(256) if siklik[b] > 0),
                  key=lambda b: (-siklik[b], b))
    print("  en sık 6 simge:", ", ".join(
        f"{sembol_yaz(b)} {siklik[b]} ({kodlar[b]})" for b in sira[:6]))
    tampon, toplam = kodla(metin, kodlar)
    print(f"  toplam {toplam} bit -> {len(tampon)} bayt (dolgu "
          f"{len(tampon) * 8 - toplam} bit)")
    print(f"  ortalama kod uzunluğu = {ondalik(toplam, n, 4)} bit/simge "
          f"(sabit 8 bit yerine)")
    entropi = 0.0
    for b in range(256):
        if siklik[b] > 0:
            entropi += siklik[b] / n * math.log2(n / siklik[b])
    print(f"  entropi (bayt düzeyi, sıfırıncı derece) = {entropi:.4f} "
          "bit/simge: alt sınır")
    print(f"  sıkıştırma oranı = {len(tampon)} / {n} = "
          f"%{ondalik(len(tampon) * 100, n, 2)}")
    print(f"  kodlanmış akışın FNV-1a özeti = 0x{fnv1a(tampon):08x}; ilk 8 "
          "bayt:", " ".join(f"{b:02X}" for b in tampon[:8]))
    cozulen = coz(t, tampon, toplam)
    print(f"  çözülen metin özgün metinle aynı mı? "
          f"{'evet' if cozulen == metin else 'HAYIR'} ({len(cozulen)} bayt)")
    dosya = len(tampon) + 256 + 4
    print(f"  ağaç bu sayıya dahil değil: 256 baytlık kod uzunluğu tablosu "
          f"+ 4 bayt simge sayısıyla {dosya} bayt (%"
          f"{ondalik(dosya * 100, n, 2)})")


def tek_simge(metin):
    t = agac_kur(siklik_say(metin))
    kodlar = [""] * 256
    kod_ata(t, t.kok, "", kodlar)
    tampon, toplam = kodla(metin, kodlar)
    cozulen = coz(t, tampon, toplam)
    print(f"\n3) Tek simgeli metin \"{metin.decode()}\": kod \""
          f"{kodlar[metin[0]]}\" -> {toplam} bit, {len(tampon)} bayt; "
          f"çözülen aynı mı? {'evet' if cozulen == metin else 'HAYIR'}")


def main():
    metin = sys.stdin.buffer.read()
    kucuk_ornek(b"ey edip adanada pide ye")
    if len(metin) == 0:
        print("\n2) Standart girdi boş: büyük örnek atlandı")
    else:
        buyuk_ornek(metin)
    tek_simge(b"aaaaaaa")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (zlib/DEFLATE, standart dışı); C++ — yok;
# Python — zlib.compress (DEFLATE = LZ77 + Huffman), bit düzeyinde
# int.to_bytes / int.from_bytes. Ağaç ve kodlama elle yazılır.

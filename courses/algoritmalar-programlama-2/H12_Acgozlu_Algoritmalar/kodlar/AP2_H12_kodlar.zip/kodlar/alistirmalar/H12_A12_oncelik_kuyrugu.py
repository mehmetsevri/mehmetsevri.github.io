"""H12_A12_oncelik_kuyrugu.py — AP-2 Hafta 12 · Alıştırma 12.13 (★★)
Amaç    : Diller arası okuma — aynı dört (uzaklık, köşe) kaydı C++'ta
          std::priority_queue'ya, Python'da heapq'ya itilip çıkarılıyor.
          İki programın çıktısını çalıştırmadan tahmin edin.
Çalıştır: python3 H12_A12_oncelik_kuyrugu.py
Eşi     : alistirmalar/H12_A12_oncelik_kuyrugu.cpp
"""
import heapq


def main():
    pq = []
    heapq.heappush(pq, (45, 2))
    heapq.heappush(pq, (40, 1))
    heapq.heappush(pq, (60, 7))
    heapq.heappush(pq, (40, 3))
    cikti = []
    while pq:
        d, v = heapq.heappop(pq)
        cikti.append(f"({d},{v})")
    print(" ".join(cikti) + " ")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: heapq (bu alıştırmanın konusu)

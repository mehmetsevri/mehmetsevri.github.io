"""H12_A14_huffman_metin.py — AP-2 Hafta 12 · Atölye 2 aracı (★★)
Amaç    : Kendi metniniz için Huffman ağacı: bayt sıklıkları, birleştirme
          adımları, kod tablosu ve toplam bit. Eşitlik kuralı Örnek 5 ile
          aynıdır: öbekte (sıklık, düğüm no); yapraklar bayt değeri
          sırasıyla numaralanır; ilk çıkan sol (0), ikinci sağ (1) çocuk.
          Elle kurduğunuz ağacı bu çıktıyla doğrulayın.
Çalıştır: python3 H12_A14_huffman_metin.py "metin"   (ya da: < dosya.txt)
Eşi     : alistirmalar/H12_A14_huffman_metin.c
"""
import heapq
import sys


def simge(b):
    """Yazdırılabilir ASCII baytı kendisi; boşluk ␣; öbürleri onaltılık"""
    if b == 32:
        return "␣"
    if 33 <= b <= 126:
        return chr(b)
    return f"{b:02X}"


def ad(t, d):
    return simge(t[d][0]) if t[d][0] >= 0 else f"#{d}"


def huffman(metin):
    siklik = [0] * 256
    for b in metin:
        siklik[b] += 1
    t = []                               # düğüm: [simge, sıklık, sol, sağ]
    obek = []
    for b in range(256):
        if siklik[b] > 0:
            t.append([b, siklik[b], -1, -1])
            heapq.heappush(obek, (siklik[b], len(t) - 1))
    print("sıklık: " + " ".join(f"{simge(x[0])}:{x[1]}" for x in t))
    adim = 0
    while len(obek) > 1:
        fx, x = heapq.heappop(obek)
        fy, y = heapq.heappop(obek)
        t.append([-1, fx + fy, x, y])
        heapq.heappush(obek, (fx + fy, len(t) - 1))
        adim += 1
        icerik = " ".join(f"{f}:{ad(t, d)}" for f, d in sorted(obek))
        print(f"adım {adim}: {fx}:{ad(t, x)} + {fy}:{ad(t, y)} -> "
              f"#{len(t) - 1} ({fx + fy})   öbek: {icerik}")
    kodlar = {}

    def kod_ata(d, kod):
        if t[d][0] >= 0:
            kodlar[t[d][0]] = kod if kod else "0"
            return
        kod_ata(t[d][2], kod + "0")
        kod_ata(t[d][3], kod + "1")

    kod_ata(obek[0][1], "")
    print("kod tablosu (bayt sırasıyla):")
    toplam = 0
    for b in sorted(kodlar):
        print(f"  {simge(b)}: sıklık {siklik[b]}, kod {kodlar[b]}")
        toplam += siklik[b] * len(kodlar[b])
    n = len(metin)
    print(f"toplam = {toplam} bit -> {(toplam + 7) // 8} bayt "
          f"(sabit 8 bit/simge: {8 * n} bit); oran = %"
          f"{100 * toplam / (8 * n):.2f} (ağaç hariç)")


def main():
    if len(sys.argv) > 1:
        metin = sys.argv[1].encode("utf-8")
    else:
        metin = sys.stdin.buffer.read()
    if not metin:
        print("Kullanım: python3 H12_A14_huffman_metin.py \"metin\"",
              file=sys.stderr)
        sys.exit(2)
    print(f"Metin: {len(metin)} bayt")
    huffman(metin)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: heapq (öbek); ağaç kurma elle

/* H12_A06_hata_bul_prim.c — AP-2 Hafta 12 · Alıştırma 12.7 (★★)
 * Amaç    : Hata bulma — bu "Prim" gerçekleştirimi kampüs grafında bir
 *           kapsayan ağaç buluyor ama toplamı Kruskal'ınkiyle (Örnek 11)
 *           uyuşmuyor. Hatalı satırı bulun, nedenini açıklayın, düzeltin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_A06_hata_bul_prim.c -o H12_A06_hata_bul_prim
 * Çalıştır: ./H12_A06_hata_bul_prim
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>

#define V 8
#define SONSUZ INT_MAX

/* Kampüs grafı (girdiler/h12_kampus.txt) komşuluk matrisiyle; 0: kenar yok */
static const int W[V][V] = {
    {0, 40, 45, 0, 0, 0, 0, 60},     {40, 0, 30, 120, 0, 0, 0, 140},
    {45, 30, 0, 20, 110, 0, 0, 0},   {0, 120, 20, 0, 50, 55, 0, 0},
    {0, 0, 110, 50, 0, 10, 70, 0},   {0, 0, 0, 55, 10, 0, 80, 0},
    {0, 0, 0, 0, 70, 80, 0, 130},    {60, 140, 0, 0, 0, 0, 130, 0},
};

int main(void)
{
    int anahtar[V], ebeveyn[V];
    bool agacta[V] = {false};
    for (int v = 0; v < V; v++) {
        anahtar[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    anahtar[0] = 0;
    int toplam = 0;
    for (int adim = 0; adim < V; adim++) {
        int u = -1;                       /* ağaçta olmayan en küçük anahtar */
        for (int v = 0; v < V; v++) {
            if (!agacta[v] && anahtar[v] != SONSUZ &&
                (u < 0 || anahtar[v] < anahtar[u])) {
                u = v;
            }
        }
        agacta[u] = true;
        if (ebeveyn[u] >= 0) {
            int w = W[ebeveyn[u]][u];
            printf("kenar %d-%d (%d)\n", ebeveyn[u], u, w);
            toplam += w;
        }
        for (int v = 0; v < V; v++) {
            int w = W[u][v];
            if (w > 0 && !agacta[v] && anahtar[u] + w < anahtar[v]) {
                anahtar[v] = anahtar[u] + w;
                ebeveyn[v] = u;
            }
        }
    }
    printf("toplam ağırlık = %d\n", toplam);
    return 0;
}

/* Kütüphane karşılığı: yok (elle) */

/* H12_A12_oncelik_kuyrugu.cpp — AP-2 Hafta 12 · Alıştırma 12.13 (★★)
 * Amaç    : Diller arası okuma — aynı dört (uzaklık, köşe) kaydı C++'ta
 *           std::priority_queue'ya, Python'da heapq'ya itilip çıkarılıyor.
 *           İki programın çıktısını çalıştırmadan tahmin edin.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_A12_oncelik_kuyrugu.cpp -o H12_A12_oncelik_kuyrugu
 * Çalıştır: ./H12_A12_oncelik_kuyrugu
 * Eşi     : alistirmalar/H12_A12_oncelik_kuyrugu.py
 */
#include <iostream>
#include <queue>
#include <utility>

int main()
{
    std::priority_queue<std::pair<int, int>> pq;
    pq.push({45, 2});
    pq.push({40, 1});
    pq.push({60, 7});
    pq.push({40, 3});
    while (!pq.empty()) {
        auto [d, v] = pq.top();
        pq.pop();
        std::cout << '(' << d << ',' << v << ") ";
    }
    std::cout << '\n';
    return 0;
}

/* Kütüphane karşılığı: std::priority_queue (bu alıştırmanın konusu) */

"""H12_A07_hata_bul_kesirli.py — AP-2 Hafta 12 · Alıştırma 12.8 (★★)
Amaç    : Hata bulma — kesirli sırt çantası Örnek 4'ün yükleriyle bir değer
          buluyor ama kâhinin (Örnek 4: 992/3) altında kalıyor. Hatalı
          satırı bulun; neden yalnız bazı girdilerde ortaya çıktığını
          açıklayın ve düzeltin.
Çalıştır: python3 H12_A07_hata_bul_kesirli.py
"""
from fractions import Fraction

# (ad, ağırlık kg, değer)
YUKLER = [("A", 12, 84), ("B", 8, 40), ("C", 20, 100), ("D", 15, 90),
          ("E", 25, 80), ("F", 9, 30)]


def doldur(yukler, kapasite):
    sira = sorted(yukler, key=lambda y: y[2] // y[1], reverse=True)
    toplam = Fraction(0)
    kalan = kapasite
    for ad, agirlik, deger in sira:
        if kalan == 0:
            break
        alinan = min(agirlik, kalan)
        toplam += Fraction(deger * alinan, agirlik)
        kalan -= alinan
        print(f"  {ad}: {alinan}/{agirlik} kg")
    return toplam


def main():
    t = doldur(YUKLER, 60)
    print(f"toplam değer = {t} = {float(t):.2f}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (elle)

/* H12_A01_cikti_tahmini.c — AP-2 Hafta 12 · Alıştırma 12.1 (★)
 * Amaç    : Çıktı tahmini — açgözlü para üstü dört tutarda; programı
 *           çalıştırmadan önce her satırın çıktısını kâğıda yazın
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_A01_cikti_tahmini.c -o H12_A01_cikti_tahmini
 * Çalıştır: ./H12_A01_cikti_tahmini
 */
#include <stdio.h>

/* para[] azalan sıralı; her adımda sığan en büyük parayı alır.
 * Parça sayısını döndürür; parçaları ekrana yazar. */
static int acgozlu(const int *para, int k, int tutar)
{
    int parca = 0;
    for (int i = 0; i < k; i++) {
        int adet = tutar / para[i];
        if (adet > 0) {
            printf(" %dx%d", para[i], adet);
        }
        tutar -= adet * para[i];
        parca += adet;
    }
    return parca;
}

int main(void)
{
    const int kanonik[4] = {25, 10, 5, 1};
    const int tuhaf[3] = {4, 3, 1};
    const int tutar[4] = {30, 63, 6, 10};
    for (int i = 0; i < 4; i++) {
        const int *para = i < 2 ? kanonik : tuhaf;
        int k = i < 2 ? 4 : 3;
        printf("%2d:", tutar[i]);
        int p = acgozlu(para, k, tutar[i]);
        printf(" -> %d parça\n", p);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (elle) */

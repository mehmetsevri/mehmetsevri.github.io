"""H12_A15_karsi_ornek_ara.py — AP-2 Hafta 12 · Atölye 1 aracı (★★)
Amaç    : "Açgözlü mü, değil mi?" kartları için karşı örnek arayıcı.
          Bir açgözlü stratejiyi küçük rastgele örneklerde kaba kuvvetle
          karşılaştırır; uyuşmazlık bulursa EN KÜÇÜK karşı örneği yazar.
          Kendi stratejinizi STRATEJILER sözlüğüne bir fonksiyon olarak
          ekleyin. Karşı örnek bulunamaması kanıt DEĞİLDİR.
Çalıştır: python3 H12_A15_karsi_ornek_ara.py
Not     : rastgelelik ortak LCG ile (python/ortak_rastgele.py, tohum 42)
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402


# ---- Problem 1: aralık çizelgeleme (yarı açık [bas, bit))
def uyumlu_sec(sira):
    """Verilen sırada dolaş; seçilenlerin hepsiyle uyumluysa al"""
    secilen = []
    for b, e in sira:
        if all(e <= b2 or e2 <= b for b2, e2 in secilen):
            secilen.append((b, e))
    return len(secilen)


def en_erken_biten(a):
    return uyumlu_sec(sorted(a, key=lambda x: (x[1], x[0])))


def en_kisa_ilk(a):
    return uyumlu_sec(sorted(a, key=lambda x: (x[1] - x[0], x[0])))


def kaba_kuvvet(a):
    """2^n alt kümenin en büyük çakışmasız olanı"""
    en_iyi = 0
    for maske in range(1 << len(a)):
        k = [a[i] for i in range(len(a)) if maske >> i & 1]
        if all(k[i][1] <= k[j][0] or k[j][1] <= k[i][0]
               for i in range(len(k)) for j in range(i + 1, len(k))):
            en_iyi = max(en_iyi, len(k))
    return en_iyi


STRATEJILER = {
    "en erken biten": en_erken_biten,
    "en kısa ilk": en_kisa_ilk,
    # "en erken başlayan": ...   (kendi stratejinizi buraya ekleyin)
}


def ara(ad, strateji, deneme=2000, n_ust=7):
    """Rastgele örneklerde dener; en az aralıklı karşı örneği döndürür"""
    rastgele_tohum(42)
    en_kucuk = None
    for _ in range(deneme):
        n = rastgele_aralik(2, n_ust)
        a = []
        for _ in range(n):
            b = rastgele_aralik(0, 12)
            a.append((b, b + rastgele_aralik(1, 6)))
        s, k = strateji(a), kaba_kuvvet(a)
        if s != k and (en_kucuk is None or n < len(en_kucuk[0])):
            en_kucuk = (a, s, k)
    if en_kucuk is None:
        print(f"{ad}: {deneme} örnekte karşı örnek bulunamadı "
              "(bu bir kanıt değildir)")
    else:
        a, s, k = en_kucuk
        print(f"{ad}: karşı örnek ({len(a)} aralık) {a}: strateji {s}, "
              f"en iyi {k}")


def main():
    for ad, strateji in STRATEJILER.items():
        ara(ad, strateji)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (kaba kuvvet elle)

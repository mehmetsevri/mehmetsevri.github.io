/* H12_A14_huffman_metin.c — AP-2 Hafta 12 · Atölye 2 aracı (★★)
 * Amaç    : Kendi metniniz için Huffman ağacı: bayt sıklıkları, birleştirme
 *           adımları, kod tablosu ve toplam bit. Eşitlik kuralı Örnek 5 ile
 *           aynıdır: öbekte (sıklık, düğüm no); yapraklar bayt değeri
 *           sırasıyla numaralanır; ilk çıkan sol (0), ikinci sağ (1) çocuk.
 *           Elle kurduğunuz ağacı bu çıktıyla doğrulayın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_A14_huffman_metin.c -o H12_A14_huffman_metin
 * Çalıştır: ./H12_A14_huffman_metin "metin"   (ya da: < dosya.txt)
 * Eşi     : alistirmalar/H12_A14_huffman_metin.py
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_DUGUM 511
#define MAKS_METIN 65536

typedef struct {
    int sembol;                  /* -1: iç düğüm */
    long long siklik;
    int sol, sag;
} Dugum;

typedef struct {                 /* (sıklık, düğüm no) */
    long long siklik;
    int dugum;
} Oge;

static Dugum t[MAKS_DUGUM];
static int dugum_sayisi = 0;
static Oge obek[MAKS_DUGUM];
static int obek_n = 0;
static char kodlar[256][MAKS_DUGUM];

static int kucuk_mu(Oge x, Oge y)
{
    return x.siklik < y.siklik ||
           (x.siklik == y.siklik && x.dugum < y.dugum);
}

static void obege_ekle(Oge x)
{
    int i = obek_n++;
    obek[i] = x;
    while (i > 0 && kucuk_mu(obek[i], obek[(i - 1) / 2])) {
        Oge g = obek[i];
        obek[i] = obek[(i - 1) / 2];
        obek[(i - 1) / 2] = g;
        i = (i - 1) / 2;
    }
}

static Oge en_kucugu_cikar(void)
{
    Oge kok = obek[0];
    obek[0] = obek[--obek_n];
    int i = 0;
    for (;;) {
        int k = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < obek_n && kucuk_mu(obek[s], obek[k])) {
            k = s;
        }
        if (r < obek_n && kucuk_mu(obek[r], obek[k])) {
            k = r;
        }
        if (k == i) {
            break;
        }
        Oge g = obek[i];
        obek[i] = obek[k];
        obek[k] = g;
        i = k;
    }
    return kok;
}

/* Yazdırılabilir ASCII baytı kendisi; boşluk ␣; öbürleri onaltılık */
static void simge_yaz(int b)
{
    if (b == 32) {
        printf("␣");
    } else if (b >= 33 && b <= 126) {
        printf("%c", b);
    } else {
        printf("%02X", b);
    }
}

static void ad_yaz(int d)
{
    if (t[d].sembol >= 0) {
        simge_yaz(t[d].sembol);
    } else {
        printf("#%d", d);
    }
}

static int oge_karsilastir(const void *p, const void *q)
{
    const Oge *x = p, *y = q;
    return kucuk_mu(*x, *y) ? -1 : (kucuk_mu(*y, *x) ? 1 : 0);
}

static void obek_yaz(void)
{
    Oge kopya[MAKS_DUGUM];
    memcpy(kopya, obek, (size_t)obek_n * sizeof obek[0]);
    qsort(kopya, (size_t)obek_n, sizeof kopya[0], oge_karsilastir);
    for (int i = 0; i < obek_n; i++) {
        printf(i ? " %lld:" : "%lld:", kopya[i].siklik);
        ad_yaz(kopya[i].dugum);
    }
}

static void kod_ata(int d, char *kod, int derinlik)
{
    if (t[d].sembol >= 0) {
        if (derinlik == 0) {
            strcpy(kodlar[t[d].sembol], "0");
        } else {
            memcpy(kodlar[t[d].sembol], kod, (size_t)derinlik);
            kodlar[t[d].sembol][derinlik] = '\0';
        }
        return;
    }
    kod[derinlik] = '0';
    kod_ata(t[d].sol, kod, derinlik + 1);
    kod[derinlik] = '1';
    kod_ata(t[d].sag, kod, derinlik + 1);
}

static void huffman(const unsigned char *metin, size_t n)
{
    long long siklik[256] = {0};
    for (size_t i = 0; i < n; i++) {
        siklik[metin[i]]++;
    }
    printf("sıklık:");
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            t[dugum_sayisi] = (Dugum){b, siklik[b], -1, -1};
            obege_ekle((Oge){siklik[b], dugum_sayisi});
            dugum_sayisi++;
            printf(" ");
            simge_yaz(b);
            printf(":%lld", siklik[b]);
        }
    }
    printf("\n");
    int adim = 0;
    while (obek_n > 1) {
        Oge x = en_kucugu_cikar();
        Oge y = en_kucugu_cikar();
        int z = dugum_sayisi++;
        t[z] = (Dugum){-1, x.siklik + y.siklik, x.dugum, y.dugum};
        obege_ekle((Oge){x.siklik + y.siklik, z});
        adim++;
        printf("adım %d: %lld:", adim, x.siklik);
        ad_yaz(x.dugum);
        printf(" + %lld:", y.siklik);
        ad_yaz(y.dugum);
        printf(" -> #%d (%lld)   öbek: ", z, x.siklik + y.siklik);
        obek_yaz();
        printf("\n");
    }
    char kod[MAKS_DUGUM];
    kod_ata(obek[0].dugum, kod, 0);
    printf("kod tablosu (bayt sırasıyla):\n");
    long long toplam = 0;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            printf("  ");
            simge_yaz(b);
            printf(": sıklık %lld, kod %s\n", siklik[b], kodlar[b]);
            toplam += siklik[b] * (long long)strlen(kodlar[b]);
        }
    }
    printf("toplam = %lld bit -> %lld bayt (sabit 8 bit/simge: %zu bit); "
           "oran = %%%.2f (ağaç hariç)\n", toplam, (toplam + 7) / 8, 8 * n,
           100.0 * (double)toplam / (double)(8 * n));
}

int main(int argc, char *argv[])
{
    static unsigned char metin[MAKS_METIN];
    size_t n = 0;
    if (argc > 1) {
        n = strlen(argv[1]);
        if (n > MAKS_METIN) {
            n = MAKS_METIN;
        }
        memcpy(metin, argv[1], n);
    } else {
        n = fread(metin, 1, MAKS_METIN, stdin);
    }
    if (n == 0) {
        fprintf(stderr, "Kullanım: ./H12_A14_huffman_metin \"metin\"\n");
        return 2;
    }
    printf("Metin: %zu bayt\n", n);
    huffman(metin, n);
    return 0;
}

/* Kütüphane karşılığı: yok (elle öbek ve ağaç) */

/* H12_A08_parsons_kruskal.c — AP-2 Hafta 12 · Alıştırma 12.9 (★)
 * Amaç    : Parsons — Kruskal fonksiyonunun gövde satırları karıştırıldı
 *           ve girintileri silindi; doğru sıraya dizin, girintiyi verin.
 *           İki satır çeldiricidir (kullanılmaz).
 *           Tamamlanacak; bu hâliyle derlenmez.
 * İmza    : static int kruskal(Kenar *e, int m, int n, Kenar *agac, int *k)
 * Denetim : sıraladığınız gövdeyi kavram/H12_K05_cekirdek.c'deki kruskal
 *           fonksiyonuna yapıştırıp programı çalıştırın (toplam aynı mı?)
 */
toplam += e[i].w;
for (int i = 0; i < m; i++) {
}
qsort(e, (size_t)m, sizeof e[0], kenar_karsilastir);
agac[(*k)++] = e[i];
b.ebeveyn[e[i].u] = e[i].v;
if (birlestir(&b, e[i].u, e[i].v)) {
*k = 0;
}
return toplam;
BirlesimBul b;
if (e[i].w < toplam) {
int toplam = 0;
bb_kur(&b, n);

/* H12_12_prim.c — AP-2 Hafta 12 · Örnek 12 (★★★)
 * Amaç    : Prim (öbekle, tembel silme) ile en küçük kapsayan ağaç ve
 *           Kruskal (Örnek 11) ile karşılaştırma: aynı toplam ağırlık;
 *           ağırlıklar farklıyken aynı ağaç, eşit ağırlıklarda farklı ağaç
 *           olabilir; rastgele graflarda denetim
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_12_prim.c \
 *           ortak_rastgele.c -o H12_12_prim
 * Çalıştır: ./H12_12_prim ../girdiler/h12_kampus.txt \
 *           ../girdiler/h12_esit_agirlik.txt
 * Eşleri  : cpp/H12_12_prim.cpp · python/H12_12_prim.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek öğesi (anahtar, köşe); anahtar[v] = v'yi ağaca bağlayan en
 *           hafif kenarın ağırlığı. Dijkstra'yla aynı iskelet: yalnız
 *           gevşetme koşulu d[u] + w < d[v] yerine w < anahtar[v].
 */
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define SONSUZ INT_MAX
#define SATIR_UZUNLUGU 512

static long long itme_sayisi = 0, cikarma_sayisi = 0, atlanan_sayisi = 0;
static long long izleme_sayisi = 0;   /* Kruskal'ın birleşim–bul sayaçları */
static long long bul_sayisi = 0;
static long long birlestir_sayisi = 0;

/* ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ---------------- */
typedef struct {
    int hedef, agirlik;
} Komsu;

typedef struct {                /* H8 dinamik dizisi: komşu listesi */
    Komsu *veri;
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int u, v, w;
} Kenar;

typedef struct {
    int v_sayisi, e_sayisi;
    bool yonlu;
    KomsuDizisi *komsu;         /* komsu[u]: u'dan çıkan kenarlar */
    Kenar *kenar;               /* dosyadaki sırayla kenar listesi */
    int kenar_sayisi;
} Graf;

static void hata(const char *bicim, ...)
{
    va_list ap;
    va_start(ap, bicim);
    fprintf(stderr, "Hata: ");
    vfprintf(stderr, bicim, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

/* x'i sona ekler; doluysa kapasiteyi ikiye katlar. 0: başarı, -1: bellek */
static int kd_ekle(KomsuDizisi *d, Komsu x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite == 0 ? 4 : 2 * d->kapasite;
        Komsu *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

/* Sahiplik: g'nin dizileri graf_yok_et ile serbest bırakılır */
static bool graf_kur(Graf *g, int v_sayisi, int e_sayisi, bool yonlu)
{
    g->v_sayisi = v_sayisi;
    g->e_sayisi = e_sayisi;
    g->yonlu = yonlu;
    g->kenar_sayisi = 0;
    g->komsu = calloc((size_t)v_sayisi, sizeof *g->komsu);
    g->kenar = malloc((size_t)(e_sayisi > 0 ? e_sayisi : 1) * sizeof *g->kenar);
    return g->komsu != NULL && g->kenar != NULL;
}

static void graf_yok_et(Graf *g)
{
    if (g->komsu != NULL) {
        for (int v = 0; v < g->v_sayisi; v++) {
            free(g->komsu[v].veri);
        }
    }
    free(g->komsu);
    free(g->kenar);
    g->komsu = NULL;
    g->kenar = NULL;
}

static int komsu_karsilastir(const void *p, const void *q)
{
    const Komsu *x = p, *y = q;
    if (x->hedef != y->hedef) {
        return x->hedef < y->hedef ? -1 : 1;
    }
    return (x->agirlik > y->agirlik) - (x->agirlik < y->agirlik);
}

static void komsulari_sirala(Graf *g)     /* (hedef, agirlik) artan */
{
    for (int v = 0; v < g->v_sayisi; v++) {
        if (g->komsu[v].boyut > 1) {   /* boş listede veri NULL olabilir */
            qsort(g->komsu[v].veri, g->komsu[v].boyut, sizeof(Komsu),
                  komsu_karsilastir);
        }
    }
}

/* '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural) */
static bool tamsayi_coz(const char *s, int *x)
{
    const char *p = (*s == '-') ? s + 1 : s;
    size_t n = strlen(p);
    if (n == 0 || n > 9) {
        return false;
    }
    for (size_t i = 0; i < n; i++) {
        if (p[i] < '0' || p[i] > '9') {
            return false;
        }
    }
    *x = (int)strtol(s, NULL, 10);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

/* s'yi boşluklarda böler; parça sayısını döndürür (ilk 4'ü t[]'ye) */
static int parcala(char *s, char **t)
{
    int k = 0;
    while (*s != '\0') {
        while (bosluk_mu(*s)) {
            *s++ = '\0';
        }
        if (*s == '\0') {
            break;
        }
        if (k < 4) {
            t[k] = s;
        }
        k++;
        while (*s != '\0' && !bosluk_mu(*s)) {
            s++;
        }
    }
    return k;
}

/* Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
 * (w yoksa 1). 0: başarı; 1: hata (ileti stderr'de, g boş). */
static int graf_oku(const char *yol, Graf *g)
{
    g->komsu = NULL;
    g->kenar = NULL;
    g->v_sayisi = 0;
    FILE *f = fopen(yol, "rb");
    if (f == NULL) {
        hata("dosya açılamadı: %s", yol);
        return 1;
    }
    char satir[SATIR_UZUNLUGU];
    char *t[4];
    int no = 0, sonuc = 0;
    bool baslik = false;
    while (sonuc == 0 && fgets(satir, sizeof satir, f) != NULL) {
        no++;
        size_t uz = strlen(satir);
        if (uz == sizeof satir - 1 && satir[uz - 1] != '\n') {
            hata("satır %d: satır çok uzun", no);
            sonuc = 1;
            break;
        }
        int k = parcala(satir, t);
        if (k == 0 || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            const char *tur = k == 3 ? t[2] : "yonsuz";
            if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &v) ||
                !tamsayi_coz(t[1], &e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 ||
                (strcmp(tur, "yonlu") != 0 && strcmp(tur, "yonsuz") != 0)) {
                hata("satır %d: başlık 'V E [yonlu|yonsuz]' bekleniyordu",
                     no);
                sonuc = 1;
            } else if (!graf_kur(g, v, e, strcmp(tur, "yonlu") == 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &u) ||
            !tamsayi_coz(t[1], &v) || (k == 3 && !tamsayi_coz(t[2], &w))) {
            hata("satır %d: kenar 'u v [w]' bekleniyordu", no);
            sonuc = 1;
        } else if (u < 0 || u >= g->v_sayisi || v < 0 || v >= g->v_sayisi) {
            hata("satır %d: köşe numarası 0..%d aralığında olmalı", no,
                 g->v_sayisi - 1);
            sonuc = 1;
        } else if (g->kenar_sayisi == g->e_sayisi) {
            hata("satır %d: fazla kenar (E = %d)", no, g->e_sayisi);
            sonuc = 1;
        } else {
            g->kenar[g->kenar_sayisi++] = (Kenar){u, v, w};
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0 ||
                (!g->yonlu && kd_ekle(&g->komsu[v], (Komsu){u, w}) != 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
        }
    }
    fclose(f);
    if (sonuc == 0 && !baslik) {
        hata("başlık satırı yok");
        sonuc = 1;
    } else if (sonuc == 0 && g->kenar_sayisi < g->e_sayisi) {
        hata("kenar sayısı eksik: %d bekleniyordu, %d okundu", g->e_sayisi,
             g->kenar_sayisi);
        sonuc = 1;
    }
    if (sonuc != 0) {
        graf_yok_et(g);
        return 1;
    }
    komsulari_sirala(g);
    return 0;
}
/* -------------------------------------------------------------------------- */

/* --- H7 öbeğinin genelleştirilmesi: (anahtar, köşe) en küçük öbeği --- */
typedef struct {
    int anahtar, kose;
} Oge;

typedef struct {
    Oge *a;
    size_t n, kapasite;
} Obek;

static size_t ebeveyn_i(size_t i) { return (i - 1) / 2; }

static bool kucuk_mu(Oge x, Oge y)   /* (anahtar, köşe) sözlük sırası */
{
    return x.anahtar < y.anahtar || (x.anahtar == y.anahtar && x.kose < y.kose);
}

static void takas(Oge *x, Oge *y)
{
    Oge g = *x;
    *x = *y;
    *y = g;
}

static int obege_ekle(Obek *o, Oge x)   /* 0: başarı, -1: bellek */
{
    if (o->n == o->kapasite) {
        size_t yeni = o->kapasite == 0 ? 16 : 2 * o->kapasite;
        Oge *gecici = realloc(o->a, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;
        }
        o->a = gecici;
        o->kapasite = yeni;
    }
    size_t i = o->n++;
    o->a[i] = x;
    while (i > 0 && kucuk_mu(o->a[i], o->a[ebeveyn_i(i)])) {
        takas(&o->a[i], &o->a[ebeveyn_i(i)]);
        i = ebeveyn_i(i);
    }
    itme_sayisi++;
    return 0;
}

static Oge en_kucugu_cikar(Obek *o)     /* o->n > 0 olmalı */
{
    Oge en_kucuk = o->a[0];
    o->a[0] = o->a[--o->n];
    size_t i = 0;
    while (2 * i + 1 < o->n) {
        size_t c = 2 * i + 1;
        if (c + 1 < o->n && kucuk_mu(o->a[c + 1], o->a[c])) {
            c++;
        }
        if (!kucuk_mu(o->a[c], o->a[i])) {
            break;
        }
        takas(&o->a[i], &o->a[c]);
        i = c;
    }
    cikarma_sayisi++;
    return en_kucuk;
}

static int oge_karsilastir(const void *p, const void *q)
{
    Oge x = *(const Oge *)p, y = *(const Oge *)q;
    return kucuk_mu(x, y) ? -1 : (kucuk_mu(y, x) ? 1 : 0);
}

static void obek_yaz(const Obek *o)    /* sıralı (iç düzen önemsiz) */
{
    Oge *kopya = malloc((o->n > 0 ? o->n : 1) * sizeof *kopya);
    if (kopya == NULL) {
        return;
    }
    memcpy(kopya, o->a, o->n * sizeof *kopya);
    qsort(kopya, o->n, sizeof *kopya, oge_karsilastir);
    printf("[");
    for (size_t i = 0; i < o->n; i++) {
        printf(i > 0 ? " (%d,%d)" : "(%d,%d)", kopya[i].anahtar,
               kopya[i].kose);
    }
    printf("]");
    free(kopya);
}
/* ------------------------------------------------------------------- */

static void uzaklik_yaz(int d, int genislik)
{
    if (d == SONSUZ) {
        printf("%*s∞", genislik - 1, "");
    } else {
        printf("%*d", genislik, d);
    }
}

/* Öbekli Prim; ağaç kenarlarını (min, max, w) olarak agac[]'a, sayısını
 * *k'ya yazar; toplam ağırlığı döndürür (yalnız bas'ın bileşeni; bellek
 * hatasında -1) */
static long long prim(const Graf *g, int bas, Kenar *agac, int *k, bool yaz)
{
    int n = g->v_sayisi;
    int *anahtar = malloc((size_t)n * sizeof *anahtar);
    int *ebeveyn = malloc((size_t)n * sizeof *ebeveyn);
    bool *agacta = calloc((size_t)n, sizeof *agacta);
    Obek obek = {NULL, 0, 0};
    long long toplam = 0;
    *k = 0;
    if (anahtar == NULL || ebeveyn == NULL || agacta == NULL) {
        toplam = -1;
    } else {
        for (int v = 0; v < n; v++) {
            anahtar[v] = SONSUZ;
            ebeveyn[v] = -1;
        }
        anahtar[bas] = 0;
        if (obege_ekle(&obek, (Oge){0, bas}) != 0) {
            toplam = -1;
        }
    }
    while (toplam >= 0 && obek.n > 0) {
        Oge x = en_kucugu_cikar(&obek);
        int u = x.kose;
        if (agacta[u]) {                 /* eskimiş kayıt */
            atlanan_sayisi++;
            if (yaz) {
                printf("  çıkar (%d,%d): ESKİMİŞ (%d ağaçta) -> atla\n",
                       x.anahtar, u, u);
            }
            continue;
        }
        agacta[u] = true;
        toplam += x.anahtar;
        if (ebeveyn[u] >= 0) {
            int p = ebeveyn[u];
            agac[(*k)++] = (Kenar){p < u ? p : u, p < u ? u : p, x.anahtar};
        }
        if (yaz) {
            printf("  çıkar (%d,%d): %d ağaca girdi", x.anahtar, u, u);
            if (ebeveyn[u] >= 0) {
                printf(" (kenar %d-%d, %d)\n", ebeveyn[u], u, x.anahtar);
            } else {
                printf(" (başlangıç)\n");
            }
        }
        const KomsuDizisi *kd = &g->komsu[u];
        for (size_t i = 0; i < kd->boyut; i++) {
            int v = kd->veri[i].hedef, w = kd->veri[i].agirlik;
            if (!agacta[v] && w < anahtar[v]) {
                if (yaz) {
                    printf("     anahtar[%d] = ", v);
                    uzaklik_yaz(anahtar[v], 1);
                    printf(" -> %d (%d-%d), it (%d,%d)\n", w, u, v, w, v);
                }
                anahtar[v] = w;
                ebeveyn[v] = u;
                if (obege_ekle(&obek, (Oge){w, v}) != 0) {
                    toplam = -1;
                    break;
                }
            }
        }
        if (yaz && toplam >= 0) {
            printf("     öbek: ");
            obek_yaz(&obek);
            printf("\n");
        }
    }
    free(obek.a);
    free(anahtar);
    free(ebeveyn);
    free(agacta);
    return toplam;
}

typedef struct {                /* Örnek 10'un "rütbe + sıkıştırma" sürümü */
    int *ebeveyn, *rutbe;
    int n;
} BirlesimBul;

/* Sahiplik: diziler bb_yok_et ile serbest bırakılır. false: bellek */
static bool bb_kur(BirlesimBul *b, int n)
{
    b->ebeveyn = malloc((size_t)n * sizeof *b->ebeveyn);
    b->rutbe = calloc((size_t)n, sizeof *b->rutbe);
    if (b->ebeveyn == NULL || b->rutbe == NULL) {
        free(b->ebeveyn);
        free(b->rutbe);
        return false;
    }
    for (int x = 0; x < n; x++) {
        b->ebeveyn[x] = x;
    }
    b->n = n;
    return true;
}

static void bb_yok_et(BirlesimBul *b)
{
    free(b->ebeveyn);
    free(b->rutbe);
}

static int bul(BirlesimBul *b, int x)
{
    bul_sayisi++;
    int kok = x;
    while (b->ebeveyn[kok] != kok) {
        kok = b->ebeveyn[kok];
        izleme_sayisi++;
    }
    while (b->ebeveyn[x] != kok) {       /* yol sıkıştırma */
        int sonraki = b->ebeveyn[x];
        b->ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

/* İki farklı kökü rütbeye göre bağlar */
static void birlestir_kok(BirlesimBul *b, int kx, int ky)
{
    birlestir_sayisi++;
    if (b->rutbe[kx] < b->rutbe[ky]) {
        int g = kx;
        kx = ky;
        ky = g;
    }
    b->ebeveyn[ky] = kx;
    if (b->rutbe[kx] == b->rutbe[ky]) {
        b->rutbe[kx]++;
    }
}

/* Kesim denetimi için: sayaçsız, sıkıştırmasız kök */
static int kok_sayacsiz(const BirlesimBul *b, int x)
{
    while (b->ebeveyn[x] != x) {
        x = b->ebeveyn[x];
    }
    return x;
}

/* Birleştirmeden ÖNCE: S = ku kökünün kümesi (s[] üyelik); S ile V - S
 * arasındaki en hafif kenarın ağırlığını döndürür. */
static int kesim(const Graf *g, const BirlesimBul *b, int ku, bool *s)
{
    for (int x = 0; x < g->v_sayisi; x++) {
        s[x] = kok_sayacsiz(b, x) == ku;
    }
    int en_hafif = -1;
    for (int i = 0; i < g->kenar_sayisi; i++) {
        const Kenar *k = &g->kenar[i];
        if (s[k->u] != s[k->v] && (en_hafif < 0 || k->w < en_hafif)) {
            en_hafif = k->w;
        }
    }
    return en_hafif;
}

static int kenar_karsilastir(const void *p, const void *q)  /* (w, u, v) */
{
    const Kenar *x = p, *y = q;
    if (x->w != y->w) {
        return x->w < y->w ? -1 : 1;
    }
    if (x->u != y->u) {
        return x->u < y->u ? -1 : 1;
    }
    return (x->v > y->v) - (x->v < y->v);
}

/* Kenarları (w, u, v) sırasıyla dolaş; uçlar farklı ağaçtaysa al. Ağaç
 * kenarları agac[]'a, sayısı *k'ya; toplam ağırlık (bellek hatasında -1). */
static long long kruskal(const Graf *g, Kenar *agac, int *k, bool yaz)
{
    int m = g->kenar_sayisi, n = g->v_sayisi;
    Kenar *sira = malloc((size_t)(m > 0 ? m : 1) * sizeof *sira);
    bool *s = malloc((size_t)n * sizeof *s);
    BirlesimBul b;
    if (sira == NULL || s == NULL || !bb_kur(&b, n)) {
        free(sira);
        free(s);
        return -1;
    }
    for (int i = 0; i < m; i++) {
        int u = g->kenar[i].u, v = g->kenar[i].v;
        sira[i] = (Kenar){u < v ? u : v, u < v ? v : u, g->kenar[i].w};
    }
    qsort(sira, (size_t)m, sizeof *sira, kenar_karsilastir);
    long long toplam = 0;
    *k = 0;
    for (int i = 0; i < m; i++) {
        int u = sira[i].u, v = sira[i].v, w = sira[i].w;
        int ku = bul(&b, u), kv = bul(&b, v);
        if (ku == kv) {
            if (yaz) {
                printf("  %2d  (%3d, %d, %d)  %d %d     RET    döngü: %d ile "
                       "%d zaten aynı ağaçta\n", i + 1, w, u, v, ku, kv, u, v);
            }
            continue;
        }
        int en_hafif = 0;
        if (yaz) {
            en_hafif = kesim(g, &b, ku, s);
        }
        birlestir_kok(&b, ku, kv);       /* iki ağaç birleşir */
        agac[(*k)++] = sira[i];
        toplam += w;
        if (yaz) {
            printf("  %2d  (%3d, %d, %d)  %d %d     KABUL  ebeveyn:", i + 1, w,
                   u, v, ku, kv);
            for (int x = 0; x < n; x++) {
                printf(" %d", b.ebeveyn[x]);
            }
            printf("\n      kesim S = {");
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (s[x]) {
                    printf(ilk ? "%d" : ", %d", x);
                    ilk = false;
                }
            }
            printf("}: S'den çıkan en hafif kenar %d %s\n", en_hafif,
                   en_hafif == w ? "= w (kesim özelliği)" : "!= w (HATA)");
            if (*k == n - 1) {
                printf("      (ağaç tamam: V - 1 = %d kenar; erken durdurma "
                       "kalanları incelemezdi)\n", n - 1);
            }
        }
    }
    bb_yok_et(&b);
    free(sira);
    free(s);
    return toplam;
}

static int uvw_karsilastir(const void *p, const void *q)  /* (u, v, w) */
{
    const Kenar *x = p, *y = q;
    if (x->u != y->u) {
        return x->u < y->u ? -1 : 1;
    }
    if (x->v != y->v) {
        return x->v < y->v ? -1 : 1;
    }
    return (x->w > y->w) - (x->w < y->w);
}

static void agac_yaz(const Kenar *agac, int k)
{
    for (int i = 0; i < k; i++) {
        printf(i > 0 ? ", %d-%d (%d)" : "%d-%d (%d)", agac[i].u, agac[i].v,
               agac[i].w);
    }
}

static bool ayni_agac(Kenar *a, int ka, Kenar *b, int kb)
{
    qsort(a, (size_t)ka, sizeof *a, uvw_karsilastir);
    qsort(b, (size_t)kb, sizeof *b, uvw_karsilastir);
    if (ka != kb) {
        return false;
    }
    for (int i = 0; i < ka; i++) {
        if (uvw_karsilastir(&a[i], &b[i]) != 0) {
            return false;
        }
    }
    return true;
}

/* Bağlı yönsüz graf: yol 0-1-…-(n-1) + rastgele kenarlar (u != v); çoklu
 * kenar olabilir. Ağırlıklar 1..w_ust: çok sayıda eşitlik. */
static bool rastgele_yonsuz(Graf *g, int n, int m, int w_ust, uint64_t tohum)
{
    rastgele_tohum(tohum);
    if (!graf_kur(g, n, m, false)) {
        return false;
    }
    for (int u = 0; u < n - 1; u++) {
        g->kenar[g->kenar_sayisi++] = (Kenar){u, u + 1,
                                              rastgele_aralik(1, w_ust)};
    }
    while (g->kenar_sayisi < m) {
        int u = rastgele_aralik(0, n - 1);
        int v = rastgele_aralik(0, n - 1);
        int w = rastgele_aralik(1, w_ust);
        if (u != v) {
            g->kenar[g->kenar_sayisi++] = (Kenar){u, v, w};
        }
    }
    for (int i = 0; i < m; i++) {
        const Kenar *e = &g->kenar[i];
        if (kd_ekle(&g->komsu[e->u], (Komsu){e->v, e->w}) != 0 ||
            kd_ekle(&g->komsu[e->v], (Komsu){e->u, e->w}) != 0) {
            return false;
        }
    }
    komsulari_sirala(g);
    return true;
}

static int karsilastir(const char *dosya)
{
    Graf g;
    if (graf_oku(dosya, &g) != 0) {
        return 1;
    }
    if (g.yonlu) {
        hata("en küçük kapsayan ağaç yönsüz graf ister");
        graf_yok_et(&g);
        return 1;
    }
    printf("  graf: %d köşe, %d kenar\n", g.v_sayisi, g.e_sayisi);
    itme_sayisi = cikarma_sayisi = atlanan_sayisi = 0;
    Kenar *ap = malloc((size_t)g.v_sayisi * sizeof *ap);
    Kenar *ak = malloc((size_t)g.v_sayisi * sizeof *ak);
    int kp = 0, kk = 0;
    long long tp = -1, tk = -1;
    if (ap != NULL && ak != NULL) {
        tp = prim(&g, 0, ap, &kp, true);
        tk = kruskal(&g, ak, &kk, false);
    }
    if (tp < 0 || tk < 0) {
        free(ap);
        free(ak);
        graf_yok_et(&g);
        fprintf(stderr, "Hata: bellek yetersiz\n");
        return 1;
    }
    bool ayni = ayni_agac(ap, kp, ak, kk);
    printf("  Prim    : ");
    agac_yaz(ap, kp);
    printf("; toplam %lld\n  Kruskal : ", tp);
    agac_yaz(ak, kk);
    printf("; toplam %lld\n", tk);
    printf("  sayaçlar (Prim): itme = %lld, çıkarma = %lld, atlanan = %lld\n",
           itme_sayisi, cikarma_sayisi, atlanan_sayisi);
    printf("  toplamlar eşit mi? %s; kenar kümeleri aynı mı? %s\n",
           tp == tk ? "evet" : "HAYIR", ayni ? "evet" : "HAYIR");
    free(ap);
    free(ak);
    graf_yok_et(&g);
    return 0;
}

static const char *taban_ad(const char *yol)
{
    const char *s = strrchr(yol, '/');
    return s == NULL ? yol : s + 1;
}

int main(int argc, char **argv)
{
    if (argc != 2 && argc != 3) {
        fprintf(stderr, "Kullanım: H12_12_prim GRAF_DOSYASI "
                        "[GRAF_DOSYASI2]\n");
        return 2;
    }
    printf("1) Prim (öbekle) 0'dan; Kruskal ile karşılaştırma — %s\n",
           taban_ad(argv[1]));
    if (karsilastir(argv[1]) != 0) {
        return 1;
    }
    printf("  Ağırlıklar birbirinden farklıysa en küçük kapsayan ağaç tektir: "
           "iki algoritma\n  aynı kenarları bulur.\n");
    if (argc == 3) {
        printf("\n2) Eşit ağırlıklı kenarlar — %s\n", taban_ad(argv[2]));
        if (karsilastir(argv[2]) != 0) {
            return 1;
        }
        printf("  Toplam aynı, ağaç farklı olabilir: eşit ağırlıklı "
               "kenarlardan hangisinin\n  seçileceğini eşitlik kırma kuralı "
               "belirler (Kruskal: (w, u, v) sırası;\n  Prim: başlangıç "
               "köşesi ve (anahtar, köşe) sırası).\n");
    }
    printf("\n3) Rastgele bağlı yönsüz graflar: V = 50, E = 200, ağırlık "
           "1..10 (tohum 1..20)\n");
    int esit_toplam = 0, farkli_agac = 0;
    for (int tohum = 1; tohum <= 20; tohum++) {
        Graf r;
        Kenar ap[50], ak[50];
        int kp, kk;
        if (!rastgele_yonsuz(&r, 50, 200, 10, (uint64_t)tohum)) {
            graf_yok_et(&r);
            return 1;
        }
        long long tp = prim(&r, 0, ap, &kp, false);
        long long tk = kruskal(&r, ak, &kk, false);
        esit_toplam += tp == tk;
        farkli_agac += !ayni_agac(ap, kp, ak, kk);
        graf_yok_et(&r);
    }
    printf("  toplamlar eşit: %d/20; ağaç kenar kümesi farklı: %d/20\n",
           esit_toplam, farkli_agac);
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (Boost Graph Library
 * prim_minimum_spanning_tree, networkx minimum_spanning_tree
 * (algorithm='prim') — standart dışı; yalnız kâhin). */

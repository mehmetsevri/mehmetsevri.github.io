/* H12_07_dijkstra_dizi.c — AP-2 Hafta 12 · Örnek 7 (★★)
 * Amaç    : Ağırlıklı graf okuma (ortak biçim) ve dizi tabanlı O(V²)
 *           Dijkstra: her adımda kesinleşmemiş en küçük uzaklıklı köşeyi
 *           doğrusal taramayla seç, komşularını gevşet; kesinleşen küme ve
 *           uzaklık tablosu adım adım
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_07_dijkstra_dizi.c \
 *           ortak_rastgele.c -o H12_07_dijkstra_dizi
 * Çalıştır: ./H12_07_dijkstra_dizi ../girdiler/h12_kampus.txt 0
 * Eşleri  : cpp/H12_07_dijkstra_dizi.cpp · python/H12_07_dijkstra_dizi.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : komşular artan köşe numarasıyla (okuyucu sıralar); eşit
 *           uzaklıkta küçük numaralı köşe seçilir. SONSUZ = INT_MAX,
 *           yazdırılırken ∞.
 */
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define SONSUZ INT_MAX
#define SATIR_UZUNLUGU 512

static long long taranan_hucre = 0;   /* en küçüğü seçerken bakılan d[] */
static long long kenar_inceleme = 0;  /* incelenen kenar (u, v) */
static long long gevsetme_sayisi = 0; /* d[v]'yi küçülten gevşetme */

/* ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ---------------- */
typedef struct {
    int hedef, agirlik;
} Komsu;

typedef struct {                /* H8 dinamik dizisi: komşu listesi */
    Komsu *veri;
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int u, v, w;
} Kenar;

typedef struct {
    int v_sayisi, e_sayisi;
    bool yonlu;
    KomsuDizisi *komsu;         /* komsu[u]: u'dan çıkan kenarlar */
    Kenar *kenar;               /* dosyadaki sırayla kenar listesi */
    int kenar_sayisi;
} Graf;

static void hata(const char *bicim, ...)
{
    va_list ap;
    va_start(ap, bicim);
    fprintf(stderr, "Hata: ");
    vfprintf(stderr, bicim, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

/* x'i sona ekler; doluysa kapasiteyi ikiye katlar. 0: başarı, -1: bellek */
static int kd_ekle(KomsuDizisi *d, Komsu x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite == 0 ? 4 : 2 * d->kapasite;
        Komsu *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

/* Sahiplik: g'nin dizileri graf_yok_et ile serbest bırakılır */
static bool graf_kur(Graf *g, int v_sayisi, int e_sayisi, bool yonlu)
{
    g->v_sayisi = v_sayisi;
    g->e_sayisi = e_sayisi;
    g->yonlu = yonlu;
    g->kenar_sayisi = 0;
    g->komsu = calloc((size_t)v_sayisi, sizeof *g->komsu);
    g->kenar = malloc((size_t)(e_sayisi > 0 ? e_sayisi : 1) * sizeof *g->kenar);
    return g->komsu != NULL && g->kenar != NULL;
}

static void graf_yok_et(Graf *g)
{
    if (g->komsu != NULL) {
        for (int v = 0; v < g->v_sayisi; v++) {
            free(g->komsu[v].veri);
        }
    }
    free(g->komsu);
    free(g->kenar);
    g->komsu = NULL;
    g->kenar = NULL;
}

static int komsu_karsilastir(const void *p, const void *q)
{
    const Komsu *x = p, *y = q;
    if (x->hedef != y->hedef) {
        return x->hedef < y->hedef ? -1 : 1;
    }
    return (x->agirlik > y->agirlik) - (x->agirlik < y->agirlik);
}

static void komsulari_sirala(Graf *g)     /* (hedef, agirlik) artan */
{
    for (int v = 0; v < g->v_sayisi; v++) {
        if (g->komsu[v].boyut > 1) {   /* boş listede veri NULL olabilir */
            qsort(g->komsu[v].veri, g->komsu[v].boyut, sizeof(Komsu),
                  komsu_karsilastir);
        }
    }
}

/* '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural) */
static bool tamsayi_coz(const char *s, int *x)
{
    const char *p = (*s == '-') ? s + 1 : s;
    size_t n = strlen(p);
    if (n == 0 || n > 9) {
        return false;
    }
    for (size_t i = 0; i < n; i++) {
        if (p[i] < '0' || p[i] > '9') {
            return false;
        }
    }
    *x = (int)strtol(s, NULL, 10);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

/* s'yi boşluklarda böler; parça sayısını döndürür (ilk 4'ü t[]'ye) */
static int parcala(char *s, char **t)
{
    int k = 0;
    while (*s != '\0') {
        while (bosluk_mu(*s)) {
            *s++ = '\0';
        }
        if (*s == '\0') {
            break;
        }
        if (k < 4) {
            t[k] = s;
        }
        k++;
        while (*s != '\0' && !bosluk_mu(*s)) {
            s++;
        }
    }
    return k;
}

/* Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
 * (w yoksa 1). 0: başarı; 1: hata (ileti stderr'de, g boş). */
static int graf_oku(const char *yol, Graf *g)
{
    g->komsu = NULL;
    g->kenar = NULL;
    g->v_sayisi = 0;
    FILE *f = fopen(yol, "rb");
    if (f == NULL) {
        hata("dosya açılamadı: %s", yol);
        return 1;
    }
    char satir[SATIR_UZUNLUGU];
    char *t[4];
    int no = 0, sonuc = 0;
    bool baslik = false;
    while (sonuc == 0 && fgets(satir, sizeof satir, f) != NULL) {
        no++;
        size_t uz = strlen(satir);
        if (uz == sizeof satir - 1 && satir[uz - 1] != '\n') {
            hata("satır %d: satır çok uzun", no);
            sonuc = 1;
            break;
        }
        int k = parcala(satir, t);
        if (k == 0 || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            const char *tur = k == 3 ? t[2] : "yonsuz";
            if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &v) ||
                !tamsayi_coz(t[1], &e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 ||
                (strcmp(tur, "yonlu") != 0 && strcmp(tur, "yonsuz") != 0)) {
                hata("satır %d: başlık 'V E [yonlu|yonsuz]' bekleniyordu",
                     no);
                sonuc = 1;
            } else if (!graf_kur(g, v, e, strcmp(tur, "yonlu") == 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &u) ||
            !tamsayi_coz(t[1], &v) || (k == 3 && !tamsayi_coz(t[2], &w))) {
            hata("satır %d: kenar 'u v [w]' bekleniyordu", no);
            sonuc = 1;
        } else if (u < 0 || u >= g->v_sayisi || v < 0 || v >= g->v_sayisi) {
            hata("satır %d: köşe numarası 0..%d aralığında olmalı", no,
                 g->v_sayisi - 1);
            sonuc = 1;
        } else if (g->kenar_sayisi == g->e_sayisi) {
            hata("satır %d: fazla kenar (E = %d)", no, g->e_sayisi);
            sonuc = 1;
        } else {
            g->kenar[g->kenar_sayisi++] = (Kenar){u, v, w};
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0 ||
                (!g->yonlu && kd_ekle(&g->komsu[v], (Komsu){u, w}) != 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
        }
    }
    fclose(f);
    if (sonuc == 0 && !baslik) {
        hata("başlık satırı yok");
        sonuc = 1;
    } else if (sonuc == 0 && g->kenar_sayisi < g->e_sayisi) {
        hata("kenar sayısı eksik: %d bekleniyordu, %d okundu", g->e_sayisi,
             g->kenar_sayisi);
        sonuc = 1;
    }
    if (sonuc != 0) {
        graf_yok_et(g);
        return 1;
    }
    komsulari_sirala(g);
    return 0;
}
/* -------------------------------------------------------------------------- */

static void uzaklik_yaz(int d, int genislik)
{
    if (d == SONSUZ) {
        printf("%*s∞", genislik - 1, "");
    } else {
        printf("%*d", genislik, d);
    }
}

/* O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama */
static void dijkstra_dizi(const Graf *g, int kaynak, int *d, int *ebeveyn,
                          bool yaz)
{
    int n = g->v_sayisi;
    bool *kesin = calloc((size_t)n, sizeof *kesin);
    if (kesin == NULL) {
        return;
    }
    for (int v = 0; v < n; v++) {
        d[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    d[kaynak] = 0;
    for (int adim = 1; adim <= n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {    /* en küçük d: doğrusal tarama */
            taranan_hucre++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;                       /* kalanlar ulaşılamaz */
        }
        kesin[u] = true;                 /* d[u] artık kesin */
        if (yaz) {
            printf("  adım %d: seç %d (d = %d); kesinleşen {", adim, u, d[u]);
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (kesin[x]) {
                    printf(ilk ? "%d" : ", %d", x);
                    ilk = false;
                }
            }
            printf("}\n");
        }
        const KomsuDizisi *k = &g->komsu[u];
        for (size_t i = 0; i < k->boyut; i++) {
            int v = k->veri[i].hedef, w = k->veri[i].agirlik;
            kenar_inceleme++;
            if (kesin[v]) {
                continue;
            }
            if (d[u] != SONSUZ && d[u] + w < d[v]) {   /* taşma korumalı */
                if (yaz) {
                    printf("     gevşet %d->%d (w = %d): d[%d] = ", u, v, w,
                           v);
                    uzaklik_yaz(d[v], 1);
                    printf(" -> %d\n", d[u] + w);
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
            } else if (yaz) {
                printf("     %d->%d (w = %d): %d + %d >= %d, değişmez\n", u,
                       v, w, d[u], w, d[v]);
            }
        }
        if (yaz) {
            printf("     d:");
            for (int x = 0; x < n; x++) {
                printf(" ");
                uzaklik_yaz(d[x], 1);
            }
            printf("\n");
        }
    }
    free(kesin);
}

/* Yönlü: her u için u -> u+1 (halka, ulaşılabilirlik için) ve derece-1
 * rastgele kenar; ağırlıklar 1..w_ust (ortak LCG) */
static bool rastgele_graf(Graf *g, int v_sayisi, int derece, int w_ust,
                          uint64_t tohum)
{
    rastgele_tohum(tohum);
    if (!graf_kur(g, v_sayisi, v_sayisi * derece, true)) {
        return false;
    }
    for (int u = 0; u < v_sayisi; u++) {
        int w = rastgele_aralik(1, w_ust);
        if (kd_ekle(&g->komsu[u], (Komsu){(u + 1) % v_sayisi, w}) != 0) {
            return false;
        }
        for (int j = 0; j < derece - 1; j++) {
            int v = rastgele_aralik(0, v_sayisi - 1);
            w = rastgele_aralik(1, w_ust);
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0) {
                return false;
            }
        }
    }
    komsulari_sirala(g);
    return true;
}

int main(int argc, char **argv)
{
    if (argc != 2 && argc != 3) {
        fprintf(stderr, "Kullanım: H12_07_dijkstra_dizi GRAF_DOSYASI "
                        "[KAYNAK]\n");
        return 2;
    }
    Graf g;
    if (graf_oku(argv[1], &g) != 0) {
        return 1;
    }
    int kaynak = 0;
    if (argc == 3 && (!tamsayi_coz(argv[2], &kaynak) || kaynak < 0 ||
                      kaynak >= g.v_sayisi)) {
        hata("kaynak köşe 0..%d aralığında olmalı", g.v_sayisi - 1);
        graf_yok_et(&g);
        return 2;
    }
    for (int i = 0; i < g.kenar_sayisi; i++) {
        if (g.kenar[i].w < 0) {
            hata("negatif ağırlık %d->%d (%d): Dijkstra'nın önkoşulu "
                 "sağlanmıyor (Örnek 9)", g.kenar[i].u, g.kenar[i].v,
                 g.kenar[i].w);
            graf_yok_et(&g);
            return 1;
        }
    }
    printf("1) Graf: %d köşe, %d kenar, %s\n", g.v_sayisi, g.e_sayisi,
           g.yonlu ? "yönlü" : "yönsüz (her kenar iki yönde)");
    printf("  komşuluk listesi, hedef(ağırlık):\n");
    for (int u = 0; u < g.v_sayisi; u++) {
        printf("    %d:", u);
        for (size_t i = 0; i < g.komsu[u].boyut; i++) {
            printf(" %d(%d)", g.komsu[u].veri[i].hedef,
                   g.komsu[u].veri[i].agirlik);
        }
        printf("\n");
    }

    printf("\n2) Dizi tabanlı Dijkstra, kaynak %d\n", kaynak);
    int *d = malloc((size_t)g.v_sayisi * sizeof *d);
    int *ebeveyn = malloc((size_t)g.v_sayisi * sizeof *ebeveyn);
    if (d == NULL || ebeveyn == NULL) {
        free(d);
        free(ebeveyn);
        graf_yok_et(&g);
        return 1;
    }
    dijkstra_dizi(&g, kaynak, d, ebeveyn, true);
    printf("  köşe  uzaklık  ebeveyn\n");
    for (int v = 0; v < g.v_sayisi; v++) {
        printf("  %4d  ", v);
        uzaklik_yaz(d[v], 7);
        printf("  %7d\n", ebeveyn[v]);
    }
    printf("  sayaçlar: taranan hücre = %lld (V² = %lld), kenar inceleme = "
           "%lld, başarılı gevşetme = %lld\n", taranan_hucre,
           (long long)g.v_sayisi * g.v_sayisi, kenar_inceleme,
           gevsetme_sayisi);
    free(d);
    free(ebeveyn);
    graf_yok_et(&g);

    printf("\n3) Rastgele yönlü graflarda sayaçlar (derece 4, ağırlık "
           "1..100)\n");
    printf("      V       E   taranan hücre          V²  kenar inc.  "
           "gevşetme\n");
    const int boyutlar[4] = {100, 200, 400, 800};
    for (int i = 0; i < 4; i++) {
        int n = boyutlar[i];
        Graf r;
        int *rd = malloc((size_t)n * sizeof *rd);
        int *re = malloc((size_t)n * sizeof *re);
        if (rd == NULL || re == NULL || !rastgele_graf(&r, n, 4, 100, 42)) {
            free(rd);
            free(re);
            return 1;
        }
        taranan_hucre = kenar_inceleme = gevsetme_sayisi = 0;
        dijkstra_dizi(&r, 0, rd, re, false);
        printf("  %5d  %6d  %14lld  %10lld  %10lld  %8lld\n", n, r.e_sayisi,
               taranan_hucre, (long long)n * n, kenar_inceleme,
               gevsetme_sayisi);
        graf_yok_et(&r);
        free(rd);
        free(re);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (Boost Graph Library
 * dijkstra_shortest_paths, standart dışı); Python — yok (networkx
 * dijkstra_path, standart dışı; yalnız kâhin olarak kullanılabilir). */

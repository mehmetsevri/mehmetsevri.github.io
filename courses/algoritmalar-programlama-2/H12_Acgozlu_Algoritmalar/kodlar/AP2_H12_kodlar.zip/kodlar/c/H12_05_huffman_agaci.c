/* H12_05_huffman_agaci.c — AP-2 Hafta 12 · Örnek 5 (★★★)
 * Amaç    : Huffman ağacı: sıklık tablosu, en küçük öbekle iki en küçüğü
 *           birleştirme (her adımda öbek içeriği), kod tablosu (simge
 *           sırasıyla), ağırlıklı yol uzunluğu; tek simgeli metin sınırı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_05_huffman_agaci.c \
 *           -o H12_05_huffman_agaci
 * Çalıştır: ./H12_05_huffman_agaci
 * Eşleri  : cpp/H12_05_huffman_agaci.cpp · python/H12_05_huffman_agaci.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek öğesi (sıklık, düğüm no). Düğüm no oluşturulma sırasıdır
 *           (yapraklar bayt değeri sırasıyla, sonra iç düğümler): eşit
 *           sıklıkta önce oluşturulan çıkar. İlk çıkan sol (0), ikinci sağ
 *           (1) çocuk olur. Tek düğümlü ağaçta kod "0" verilir.
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_DUGUM 511             /* 256 yaprak + 255 iç düğüm */

typedef struct {                   /* düğümler dizilerde */
    int sembol[MAKS_DUGUM];        /* -1: iç düğüm */
    long long siklik[MAKS_DUGUM];
    int sol[MAKS_DUGUM], sag[MAKS_DUGUM];
    int n;                         /* düğüm sayısı */
    int kok;                       /* boş metinde -1 */
} Agac;

/* --- H7 öbeğinin genelleştirilmesi: (sıklık, düğüm) en küçük öbeği --- */
typedef struct {
    long long siklik;
    int dugum;
} Oge;

typedef struct {
    Oge a[MAKS_DUGUM];
    int n;
} Obek;

static long long itme_sayisi = 0, cikarma_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

static bool kucuk_mu(Oge x, Oge y)   /* demet sırası: (sıklık, düğüm) */
{
    return x.siklik < y.siklik || (x.siklik == y.siklik && x.dugum < y.dugum);
}

static void takas(Oge *x, Oge *y)
{
    Oge g = *x;
    *x = *y;
    *y = g;
}

static void yukari_suz(Obek *o, int i)
{
    while (i > 0 && kucuk_mu(o->a[i], o->a[ebeveyn(i)])) {
        takas(&o->a[i], &o->a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
}

static void asagi_suz(Obek *o, int i)
{
    while (2 * i + 1 < o->n) {
        int c = 2 * i + 1;
        if (c + 1 < o->n && kucuk_mu(o->a[c + 1], o->a[c])) {
            c++;
        }
        if (!kucuk_mu(o->a[c], o->a[i])) {
            break;
        }
        takas(&o->a[i], &o->a[c]);
        i = c;
    }
}

static void obege_ekle(Obek *o, Oge x)
{
    o->a[o->n++] = x;
    yukari_suz(o, o->n - 1);
    itme_sayisi++;
}

static Oge en_kucugu_cikar(Obek *o)
{
    Oge en_kucuk = o->a[0];
    o->a[0] = o->a[--o->n];
    asagi_suz(o, 0);
    cikarma_sayisi++;
    return en_kucuk;
}
/* ------------------------------------------------------------------- */

static int dugum_ekle(Agac *t, int sembol, long long siklik, int sol, int sag)
{
    t->sembol[t->n] = sembol;
    t->siklik[t->n] = siklik;
    t->sol[t->n] = sol;
    t->sag[t->n] = sag;
    return t->n++;
}

/* Simgenin görünür biçimi: ␣ boşluk, yazdırılabilir ASCII, yoksa \xHH
 * (tampon en az 16 bayt) */
static const char *sembol_yaz(int b, char *tampon)
{
    if (b == 32) {
        return "␣";
    }
    if (b >= 33 && b <= 126) {
        tampon[0] = (char)b;
        tampon[1] = '\0';
    } else {
        snprintf(tampon, 16, "\\x%02X", (unsigned)b & 0xFFu);
    }
    return tampon;
}

/* Görünür karakter sayısına göre doldurur (UTF-8 devam baytları sayılmaz) */
static void sola_yasla(const char *s, int genislik)
{
    int g = 0;
    for (const char *p = s; *p != '\0'; p++) {
        g += ((unsigned char)*p & 0xC0) != 0x80;
    }
    printf("%s%*s", s, genislik - g, "");
}

static void dugum_ad_yaz(const Agac *t, int i)
{
    char tampon[16];
    if (t->sembol[i] >= 0) {
        printf("%s", sembol_yaz(t->sembol[i], tampon));
    } else {
        printf("#%d", i);
    }
}

static int oge_karsilastir(const void *p, const void *q)
{
    Oge x = *(const Oge *)p, y = *(const Oge *)q;
    return kucuk_mu(x, y) ? -1 : (kucuk_mu(y, x) ? 1 : 0);
}

static void obek_yaz(const Agac *t, const Obek *o)
{
    Oge kopya[MAKS_DUGUM];
    memcpy(kopya, o->a, (size_t)o->n * sizeof kopya[0]);
    qsort(kopya, (size_t)o->n, sizeof kopya[0], oge_karsilastir);
    for (int i = 0; i < o->n; i++) {
        printf(i > 0 ? " %lld:" : "%lld:", kopya[i].siklik);
        dugum_ad_yaz(t, kopya[i].dugum);
    }
}

/* siklik[0..255] → Huffman ağacı (kök t->kok; boş metinde -1) */
static void agac_kur(const long long *siklik, Agac *t, bool yaz)
{
    static Obek obek;
    obek.n = 0;
    t->n = 0;
    t->kok = -1;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {             /* yapraklar bayt sırasıyla */
            int d = dugum_ekle(t, b, siklik[b], -1, -1);
            obege_ekle(&obek, (Oge){siklik[b], d});
        }
    }
    if (yaz) {
        printf("  başlangıç öbeği: ");
        obek_yaz(t, &obek);
        printf("\n");
    }
    int adim = 0;
    while (obek.n > 1) {
        Oge x = en_kucugu_cikar(&obek);  /* en küçük iki ağaç */
        Oge y = en_kucugu_cikar(&obek);
        int z = dugum_ekle(t, -1, x.siklik + y.siklik, x.dugum, y.dugum);
        obege_ekle(&obek, (Oge){x.siklik + y.siklik, z});
        adim++;
        if (yaz) {
            printf("  adım %d: %lld:", adim, x.siklik);
            dugum_ad_yaz(t, x.dugum);
            printf(" + %lld:", y.siklik);
            dugum_ad_yaz(t, y.dugum);
            printf(" -> #%d (%lld)   öbek: ", z, x.siklik + y.siklik);
            obek_yaz(t, &obek);
            printf("\n");
        }
    }
    if (obek.n > 0) {
        t->kok = en_kucugu_cikar(&obek).dugum;
    }
}

/* Kökten yaprağa: sola 0, sağa 1. kod[0..derinlik-1] yoldaki bitler. */
static void kod_ata(const Agac *t, int d, char *kod, int derinlik,
                    char kodlar[256][MAKS_DUGUM])
{
    if (t->sembol[d] >= 0) {
        if (derinlik == 0) {
            strcpy(kodlar[t->sembol[d]], "0");    /* tek düğüm: "0" */
        } else {
            memcpy(kodlar[t->sembol[d]], kod, (size_t)derinlik);
            kodlar[t->sembol[d]][derinlik] = '\0';
        }
        return;
    }
    kod[derinlik] = '0';
    kod_ata(t, t->sol[d], kod, derinlik + 1, kodlar);
    kod[derinlik] = '1';
    kod_ata(t, t->sag[d], kod, derinlik + 1, kodlar);
}

/* Yan yatırılmış ağaç: sağ (1) üstte, sol (0) altta */
static void agac_ciz(const Agac *t, int d, int girinti)
{
    if (t->sembol[d] < 0) {
        agac_ciz(t, t->sag[d], girinti + 6);
    }
    printf("  %*s%lld:", girinti, "", t->siklik[d]);
    dugum_ad_yaz(t, d);
    printf("\n");
    if (t->sembol[d] < 0) {
        agac_ciz(t, t->sol[d], girinti + 6);
    }
}

/* Kod tablosu simge sırasıyla; ağırlıklı yol uzunluğu */
static void tablo_yaz(const Agac *t, const long long *siklik,
                      char kodlar[256][MAKS_DUGUM])
{
    printf("  simge  sıklık  kod          uzunluk  sıklık×uzunluk\n");
    long long toplam = 0;
    int farkli = 0;
    char tampon[16];
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            long long u = (long long)strlen(kodlar[b]);
            toplam += siklik[b] * u;
            farkli++;
            printf("  ");
            sola_yasla(sembol_yaz(b, tampon), 5);
            printf("  %6lld  %-12s %7lld  %14lld\n", siklik[b], kodlar[b], u,
                   siklik[b] * u);
        }
    }
    long long ic = 0;
    for (int d = 0; d < t->n; d++) {
        if (t->sembol[d] < 0) {
            ic += t->siklik[d];
        }
    }
    int sabit = 1;
    while ((1 << sabit) < farkli) {
        sabit++;
    }
    long long n = 0;
    for (int b = 0; b < 256; b++) {
        n += siklik[b];
    }
    printf("  ağırlıklı yol uzunluğu B(T) = Σ sıklık × uzunluk = %lld bit\n",
           toplam);
    if (t->sembol[t->kok] >= 0) {
        printf("  tek düğüm: kök yapraktır, kod uzunluğu 0 olurdu; kod \"0\" "
               "(1 bit/simge) verildi\n");
    } else {
        printf("  iç düğüm sıklıkları toplamı = %lld (B(T) ile aynı "
               "olmalı)\n", ic);
    }
    printf("  sabit uzunluklu kod: %d simge -> %d bit/simge, %lld × %d = "
           "%lld bit\n", farkli, sabit, n, sabit, n * sabit);
}

/* Hiçbir kod başka bir kodun öneki değil mi? (O(k²) kaba denetim) */
static bool onek_denetimi(const long long *siklik,
                          char kodlar[256][MAKS_DUGUM])
{
    for (int a = 0; a < 256; a++) {
        for (int b = 0; b < 256; b++) {
            if (a != b && siklik[a] > 0 && siklik[b] > 0 &&
                strncmp(kodlar[b], kodlar[a], strlen(kodlar[a])) == 0) {
                return false;
            }
        }
    }
    return true;
}

static void calistir(const char *baslik, const long long *siklik)
{
    static Agac t;
    static char kodlar[256][MAKS_DUGUM];
    char kod[MAKS_DUGUM];
    itme_sayisi = cikarma_sayisi = 0;
    printf("%s\n", baslik);
    agac_kur(siklik, &t, true);
    kod_ata(&t, t.kok, kod, 0, kodlar);
    printf("  ağaç (sağ çocuk = 1 üstte, sol çocuk = 0 altta):\n");
    agac_ciz(&t, t.kok, 0);
    tablo_yaz(&t, siklik, kodlar);
    printf("  önek özelliği: %s; öbeğe itme = %lld, çıkarma = %lld\n",
           onek_denetimi(siklik, kodlar) ? "sağlanıyor" : "YOK",
           itme_sayisi, cikarma_sayisi);
}

static void metin_sikligi(const char *metin, long long *siklik)
{
    for (int b = 0; b < 256; b++) {
        siklik[b] = 0;
    }
    for (const char *p = metin; *p != '\0'; p++) {
        siklik[(unsigned char)*p]++;
    }
}

int main(void)
{
    long long siklik[256] = {0};
    const long long f[6] = {45, 13, 12, 16, 9, 5};
    for (int i = 0; i < 6; i++) {
        siklik['a' + i] = f[i];
    }
    calistir("1) Sıklık tablosu a:45 b:13 c:12 d:16 e:9 f:5 (Cormen vd.)",
             siklik);
    const char *metin = "ey edip adanada pide ye";
    printf("\n");
    char baslik[128];
    snprintf(baslik, sizeof baslik, "2) Metin \"%s\" (%zu bayt; ␣ = boşluk)",
             metin, strlen(metin));
    metin_sikligi(metin, siklik);
    calistir(baslik, siklik);
    metin = "aaaaaaa";
    printf("\n");
    snprintf(baslik, sizeof baslik, "3) Sınır durumu: tek simgeli metin "
             "\"%s\"", metin);
    metin_sikligi(metin, siklik);
    calistir(baslik, siklik);
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — Huffman ağacı kurucu yok (zlib
 * içinde DEFLATE'in kendi Huffman kodlayıcısı vardır ama ağaç arayüzü
 * sunmaz); öbek: C elle, C++ std::priority_queue, Python heapq. */

/* H12_13_graf_boyama.c — AP-2 Hafta 12 · Örnek 13 (★★★)
 * Amaç    : Açgözlü graf boyama (Welsh–Powell): köşeleri derece azalan
 *           (eşitlikte küçük numara) sırala; her renk için listeyi dolaş,
 *           o renkte komşusu olmayanı boya. Renk sayısı; kaba kuvvetle
 *           kromatik sayı; açgözlünün en iyi olmadığı karşı örnekler
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_13_graf_boyama.c \
 *           -o H12_13_graf_boyama
 * Çalıştır: ./H12_13_graf_boyama ../girdiler/h12_cakisma.txt \
 *           ../girdiler/h12_yol6.txt ../girdiler/h12_tac8.txt
 * Eşleri  : cpp/H12_13_graf_boyama.cpp · python/H12_13_graf_boyama.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : sezgiseldir: sonucu "en iyi" diye raporlanmaz; kaba kuvvet
 *           (k^(V-1) boyama, köşe 0'ın rengi 0 sabit) yalnız küçük graflarda.
 */
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SATIR_UZUNLUGU 512
#define KABA_SINIR 10           /* kaba kuvvet en çok bu kadar köşede */

static long long boyama_sayisi = 0;   /* kaba kuvvette incelenen boyama */

/* ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ---------------- */
typedef struct {
    int hedef, agirlik;
} Komsu;

typedef struct {                /* H8 dinamik dizisi: komşu listesi */
    Komsu *veri;
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int u, v, w;
} Kenar;

typedef struct {
    int v_sayisi, e_sayisi;
    bool yonlu;
    KomsuDizisi *komsu;         /* komsu[u]: u'dan çıkan kenarlar */
    Kenar *kenar;               /* dosyadaki sırayla kenar listesi */
    int kenar_sayisi;
} Graf;

static void hata(const char *bicim, ...)
{
    va_list ap;
    va_start(ap, bicim);
    fprintf(stderr, "Hata: ");
    vfprintf(stderr, bicim, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

/* x'i sona ekler; doluysa kapasiteyi ikiye katlar. 0: başarı, -1: bellek */
static int kd_ekle(KomsuDizisi *d, Komsu x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite == 0 ? 4 : 2 * d->kapasite;
        Komsu *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

/* Sahiplik: g'nin dizileri graf_yok_et ile serbest bırakılır */
static bool graf_kur(Graf *g, int v_sayisi, int e_sayisi, bool yonlu)
{
    g->v_sayisi = v_sayisi;
    g->e_sayisi = e_sayisi;
    g->yonlu = yonlu;
    g->kenar_sayisi = 0;
    g->komsu = calloc((size_t)v_sayisi, sizeof *g->komsu);
    g->kenar = malloc((size_t)(e_sayisi > 0 ? e_sayisi : 1) * sizeof *g->kenar);
    return g->komsu != NULL && g->kenar != NULL;
}

static void graf_yok_et(Graf *g)
{
    if (g->komsu != NULL) {
        for (int v = 0; v < g->v_sayisi; v++) {
            free(g->komsu[v].veri);
        }
    }
    free(g->komsu);
    free(g->kenar);
    g->komsu = NULL;
    g->kenar = NULL;
}

static int komsu_karsilastir(const void *p, const void *q)
{
    const Komsu *x = p, *y = q;
    if (x->hedef != y->hedef) {
        return x->hedef < y->hedef ? -1 : 1;
    }
    return (x->agirlik > y->agirlik) - (x->agirlik < y->agirlik);
}

static void komsulari_sirala(Graf *g)     /* (hedef, agirlik) artan */
{
    for (int v = 0; v < g->v_sayisi; v++) {
        if (g->komsu[v].boyut > 1) {   /* boş listede veri NULL olabilir */
            qsort(g->komsu[v].veri, g->komsu[v].boyut, sizeof(Komsu),
                  komsu_karsilastir);
        }
    }
}

/* '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural) */
static bool tamsayi_coz(const char *s, int *x)
{
    const char *p = (*s == '-') ? s + 1 : s;
    size_t n = strlen(p);
    if (n == 0 || n > 9) {
        return false;
    }
    for (size_t i = 0; i < n; i++) {
        if (p[i] < '0' || p[i] > '9') {
            return false;
        }
    }
    *x = (int)strtol(s, NULL, 10);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

/* s'yi boşluklarda böler; parça sayısını döndürür (ilk 4'ü t[]'ye) */
static int parcala(char *s, char **t)
{
    int k = 0;
    while (*s != '\0') {
        while (bosluk_mu(*s)) {
            *s++ = '\0';
        }
        if (*s == '\0') {
            break;
        }
        if (k < 4) {
            t[k] = s;
        }
        k++;
        while (*s != '\0' && !bosluk_mu(*s)) {
            s++;
        }
    }
    return k;
}

/* Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
 * (w yoksa 1). 0: başarı; 1: hata (ileti stderr'de, g boş). */
static int graf_oku(const char *yol, Graf *g)
{
    g->komsu = NULL;
    g->kenar = NULL;
    g->v_sayisi = 0;
    FILE *f = fopen(yol, "rb");
    if (f == NULL) {
        hata("dosya açılamadı: %s", yol);
        return 1;
    }
    char satir[SATIR_UZUNLUGU];
    char *t[4];
    int no = 0, sonuc = 0;
    bool baslik = false;
    while (sonuc == 0 && fgets(satir, sizeof satir, f) != NULL) {
        no++;
        size_t uz = strlen(satir);
        if (uz == sizeof satir - 1 && satir[uz - 1] != '\n') {
            hata("satır %d: satır çok uzun", no);
            sonuc = 1;
            break;
        }
        int k = parcala(satir, t);
        if (k == 0 || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            const char *tur = k == 3 ? t[2] : "yonsuz";
            if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &v) ||
                !tamsayi_coz(t[1], &e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 ||
                (strcmp(tur, "yonlu") != 0 && strcmp(tur, "yonsuz") != 0)) {
                hata("satır %d: başlık 'V E [yonlu|yonsuz]' bekleniyordu",
                     no);
                sonuc = 1;
            } else if (!graf_kur(g, v, e, strcmp(tur, "yonlu") == 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &u) ||
            !tamsayi_coz(t[1], &v) || (k == 3 && !tamsayi_coz(t[2], &w))) {
            hata("satır %d: kenar 'u v [w]' bekleniyordu", no);
            sonuc = 1;
        } else if (u < 0 || u >= g->v_sayisi || v < 0 || v >= g->v_sayisi) {
            hata("satır %d: köşe numarası 0..%d aralığında olmalı", no,
                 g->v_sayisi - 1);
            sonuc = 1;
        } else if (g->kenar_sayisi == g->e_sayisi) {
            hata("satır %d: fazla kenar (E = %d)", no, g->e_sayisi);
            sonuc = 1;
        } else {
            g->kenar[g->kenar_sayisi++] = (Kenar){u, v, w};
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0 ||
                (!g->yonlu && kd_ekle(&g->komsu[v], (Komsu){u, w}) != 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
        }
    }
    fclose(f);
    if (sonuc == 0 && !baslik) {
        hata("başlık satırı yok");
        sonuc = 1;
    } else if (sonuc == 0 && g->kenar_sayisi < g->e_sayisi) {
        hata("kenar sayısı eksik: %d bekleniyordu, %d okundu", g->e_sayisi,
             g->kenar_sayisi);
        sonuc = 1;
    }
    if (sonuc != 0) {
        graf_yok_et(g);
        return 1;
    }
    komsulari_sirala(g);
    return 0;
}
/* -------------------------------------------------------------------------- */

typedef struct {
    int derece, kose;
} Sira;

static int siraya_gore(const void *p, const void *q)
{
    const Sira *x = p, *y = q;
    if (x->derece != y->derece) {
        return x->derece > y->derece ? -1 : 1;    /* derece azalan */
    }
    return (x->kose > y->kose) - (x->kose < y->kose);
}

/* sira[0..n-1]: derece azalan, eşitlikte küçük numara */
static void wp_sirasi(const Graf *g, int *sira)
{
    int n = g->v_sayisi;
    Sira *s = malloc((size_t)n * sizeof *s);
    if (s == NULL) {
        for (int v = 0; v < n; v++) {
            sira[v] = v;
        }
        return;
    }
    for (int v = 0; v < n; v++) {
        s[v] = (Sira){(int)g->komsu[v].boyut, v};
    }
    qsort(s, (size_t)n, sizeof *s, siraya_gore);
    for (int i = 0; i < n; i++) {
        sira[i] = s[i].kose;
    }
    free(s);
}

/* Derece azalan sıra; renk c için sırayı dolaş, c renginde komşusu
 * olmayan boyanmamış köşeyi c ile boya. Renk sayısını döndürür. */
static int welsh_powell(const Graf *g, int *renk, int *sira, bool yaz)
{
    int n = g->v_sayisi;
    wp_sirasi(g, sira);
    if (yaz) {
        printf("  sıra (derece azalan, eşitlikte küçük numara):");
        for (int i = 0; i < n; i++) {
            printf(" %d(d=%zu)", sira[i], g->komsu[sira[i]].boyut);
        }
        printf("\n");
    }
    for (int v = 0; v < n; v++) {
        renk[v] = -1;
    }
    int boyanan = 0, c = 0;
    while (boyanan < n) {
        if (yaz) {
            printf("  renk %d:", c);
        }
        for (int i = 0; i < n; i++) {
            int x = sira[i];
            if (renk[x] != -1) {
                continue;
            }
            bool uygun = true;
            for (size_t j = 0; j < g->komsu[x].boyut; j++) {
                if (renk[g->komsu[x].veri[j].hedef] == c) {  /* c renkli */
                    uygun = false;
                    break;
                }
            }
            if (uygun) {
                renk[x] = c;
                boyanan++;
                if (yaz) {
                    printf(" %d", x);
                }
            }
        }
        if (yaz) {
            printf("\n");
        }
        c++;
    }
    return c;
}

/* Verilen sırada her köşeye komşularında kullanılmayan en küçük renk
 * (first-fit). Renk sayısını döndürür. */
static int sirali_boya(const Graf *g, const int *sira, int *renk)
{
    int n = g->v_sayisi;
    bool *kullanilan = malloc((size_t)(n + 1) * sizeof *kullanilan);
    if (kullanilan == NULL) {
        return -1;
    }
    for (int v = 0; v < n; v++) {
        renk[v] = -1;
    }
    int en_cok = 0;
    for (int i = 0; i < n; i++) {
        int x = sira[i];
        memset(kullanilan, 0, (size_t)(n + 1) * sizeof *kullanilan);
        for (size_t j = 0; j < g->komsu[x].boyut; j++) {
            int y = g->komsu[x].veri[j].hedef;
            if (renk[y] >= 0) {
                kullanilan[renk[y]] = true;
            }
        }
        int c = 0;
        while (kullanilan[c]) {
            c++;
        }
        renk[x] = c;
        if (c + 1 > en_cok) {
            en_cok = c + 1;
        }
    }
    free(kullanilan);
    return en_cok;
}

static bool gecerli_mi(const Graf *g, const int *renk)
{
    for (int i = 0; i < g->kenar_sayisi; i++) {
        if (renk[g->kenar[i].u] == renk[g->kenar[i].v]) {
            return false;
        }
    }
    return true;
}

/* Kaba kuvvet: k = 1, 2, … için bütün k^(V-1) boyamalar (köşe 0'ın rengi
 * 0); ilk geçerli boyamanın k'si */
static int kromatik_sayi(const Graf *g, int *renk)
{
    int n = g->v_sayisi;
    for (int k = 1; k <= n; k++) {
        for (int v = 0; v < n; v++) {
            renk[v] = 0;
        }
        for (;;) {
            boyama_sayisi++;
            if (gecerli_mi(g, renk)) {
                return k;
            }
            int i = n - 1;               /* sayaç gibi bir sonraki boyama */
            while (i >= 1 && renk[i] == k - 1) {
                renk[i] = 0;
                i--;
            }
            if (i < 1) {
                break;
            }
            renk[i]++;
        }
    }
    return n;
}

static const char *taban_ad(const char *yol)
{
    const char *s = strrchr(yol, '/');
    return s == NULL ? yol : s + 1;
}

static void renk_yaz(const int *renk, int n)
{
    for (int v = 0; v < n; v++) {
        printf(v > 0 ? " %d:%d" : "%d:%d", v, renk[v]);
    }
}

/* Grafı okur, boyar, kaba kuvvetle karşılaştırır. Başarıda 0; g, renk
 * (çağıran serbest bırakır) ve *k doldurulur. */
static int boya_ve_karsilastir(const char *dosya, const char *baslik,
                               Graf *g, int **renk, int *k)
{
    if (graf_oku(dosya, g) != 0) {
        return 1;
    }
    int n = g->v_sayisi;
    printf("%s — %s: %d köşe, %d kenar\n", baslik, taban_ad(dosya), n,
           g->e_sayisi);
    *renk = malloc((size_t)n * sizeof **renk);
    int *sira = malloc((size_t)n * sizeof *sira);
    int *ff = malloc((size_t)n * sizeof *ff);
    if (*renk == NULL || sira == NULL || ff == NULL) {
        free(sira);
        free(ff);
        return 1;
    }
    *k = welsh_powell(g, *renk, sira, true);
    printf("  Welsh–Powell renk sayısı = %d; renkler: ", *k);
    renk_yaz(*renk, n);
    printf("; geçerli mi? %s\n", gecerli_mi(g, *renk) ? "evet" : "HAYIR");
    sirali_boya(g, sira, ff);
    printf("  aynı sırayla ilk uygun renk (first-fit) aynı boyamayı veriyor "
           "mu? %s\n",
           memcmp(ff, *renk, (size_t)n * sizeof *ff) == 0 ? "evet" : "HAYIR");
    if (n <= KABA_SINIR) {
        boyama_sayisi = 0;
        int chi = kromatik_sayi(g, ff);
        printf("  kaba kuvvet: kromatik sayı = %d (%lld boyama incelendi); "
               "örnek: ", chi, boyama_sayisi);
        renk_yaz(ff, n);
        printf("\n  Welsh–Powell %d renk, en iyi %d: ", *k, chi);
        if (*k == chi) {
            printf("en iyi\n");
        } else {
            printf("%d renk FAZLA\n", *k - chi);
        }
    }
    free(sira);
    free(ff);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "Kullanım: H12_13_graf_boyama GRAF_DOSYASI "
                        "[GRAF_DOSYASI ...]\n");
        return 2;
    }
    Graf g;
    int *renk = NULL, k;
    if (boya_ve_karsilastir(argv[1], "1) Sınav çakışma grafı", &g, &renk,
                            &k) != 0) {
        free(renk);
        return 1;
    }
    printf("  oturum ataması (aynı oturumdaki dersler ortak öğrencisiz):\n");
    for (int c = 0; c < k; c++) {
        printf("    oturum %d: ders", c + 1);
        for (int v = 0; v < g.v_sayisi; v++) {
            if (renk[v] == c) {
                printf(" %d", v);
            }
        }
        printf("\n");
    }
    free(renk);
    graf_yok_et(&g);
    for (int i = 2; i < argc; i++) {
        char baslik[64];
        snprintf(baslik, sizeof baslik, "%d) Karşı örnek %d", i, i - 1);
        printf("\n");
        renk = NULL;
        if (boya_ve_karsilastir(argv[i], baslik, &g, &renk, &k) != 0) {
            free(renk);
            return 1;
        }
        int n = g.v_sayisi;
        int *sira = malloc((size_t)n * sizeof *sira);
        if (sira == NULL) {
            free(renk);
            graf_yok_et(&g);
            return 1;
        }
        int m = 0;
        for (int v = 0; v < n; v += 2) {
            sira[m++] = v;
        }
        for (int v = 1; v < n; v += 2) {
            sira[m++] = v;
        }
        int k2 = sirali_boya(&g, sira, renk);
        printf("  başka sıra (önce çift, sonra tek numaralılar:");
        for (int j = 0; j < n; j++) {
            printf(" %d", sira[j]);
        }
        printf(") ile first-fit: %d renk — sonuç sıraya bağlı\n", k2);
        free(sira);
        free(renk);
        graf_yok_et(&g);
    }
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (networkx
 * greedy_color(strategy='largest_first'), standart dışı; yalnız kâhin). */

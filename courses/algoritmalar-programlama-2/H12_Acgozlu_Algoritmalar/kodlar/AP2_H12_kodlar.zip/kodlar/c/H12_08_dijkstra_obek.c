/* H12_08_dijkstra_obek.c — AP-2 Hafta 12 · Örnek 8 (★★★)
 * Amaç    : Öbekli Dijkstra: (uzaklık, köşe) öğeleri, tembel silme
 *           (köşe yeni uzaklıkla yeniden itilir; eskimiş kayıt çıkınca
 *           atlanır ve sayılır), en kısa yolun ebeveyn dizisinden
 *           yazdırılması; kâhin: Örnek 7'nin dizi tabanlı Dijkstra'sı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_08_dijkstra_obek.c \
 *           ortak_rastgele.c -o H12_08_dijkstra_obek
 * Çalıştır: ./H12_08_dijkstra_obek ../girdiler/h12_kampus.txt 0
 * Eşleri  : cpp/H12_08_dijkstra_obek.cpp · python/H12_08_dijkstra_obek.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek H7 öbeğinin genelleştirilmesidir (en küçük öbek, struct +
 *           karşılaştırıcı); (uzaklık, köşe) sözlük sırası, eşit uzaklıkta
 *           küçük köşe önce çıkar.
 */
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define SONSUZ INT_MAX
#define SATIR_UZUNLUGU 512

static long long itme_sayisi = 0;     /* öbeğe itilen (uzaklık, köşe) */
static long long cikarma_sayisi = 0;  /* öbekten çıkarılan öğe */
static long long atlanan_sayisi = 0;  /* tembel silme: eskimiş, atlanan */
static long long kenar_inceleme = 0;  /* incelenen kenar (u, v) */
static long long gevsetme_sayisi = 0; /* d[v]'yi küçülten gevşetme */
static long long en_buyuk_obek = 0;   /* öbeğin ulaştığı en büyük boy */
static long long taranan_hucre = 0;   /* (dizi tabanlı kâhin için) */

/* ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ---------------- */
typedef struct {
    int hedef, agirlik;
} Komsu;

typedef struct {                /* H8 dinamik dizisi: komşu listesi */
    Komsu *veri;
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int u, v, w;
} Kenar;

typedef struct {
    int v_sayisi, e_sayisi;
    bool yonlu;
    KomsuDizisi *komsu;         /* komsu[u]: u'dan çıkan kenarlar */
    Kenar *kenar;               /* dosyadaki sırayla kenar listesi */
    int kenar_sayisi;
} Graf;

static void hata(const char *bicim, ...)
{
    va_list ap;
    va_start(ap, bicim);
    fprintf(stderr, "Hata: ");
    vfprintf(stderr, bicim, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

/* x'i sona ekler; doluysa kapasiteyi ikiye katlar. 0: başarı, -1: bellek */
static int kd_ekle(KomsuDizisi *d, Komsu x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite == 0 ? 4 : 2 * d->kapasite;
        Komsu *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

/* Sahiplik: g'nin dizileri graf_yok_et ile serbest bırakılır */
static bool graf_kur(Graf *g, int v_sayisi, int e_sayisi, bool yonlu)
{
    g->v_sayisi = v_sayisi;
    g->e_sayisi = e_sayisi;
    g->yonlu = yonlu;
    g->kenar_sayisi = 0;
    g->komsu = calloc((size_t)v_sayisi, sizeof *g->komsu);
    g->kenar = malloc((size_t)(e_sayisi > 0 ? e_sayisi : 1) * sizeof *g->kenar);
    return g->komsu != NULL && g->kenar != NULL;
}

static void graf_yok_et(Graf *g)
{
    if (g->komsu != NULL) {
        for (int v = 0; v < g->v_sayisi; v++) {
            free(g->komsu[v].veri);
        }
    }
    free(g->komsu);
    free(g->kenar);
    g->komsu = NULL;
    g->kenar = NULL;
}

static int komsu_karsilastir(const void *p, const void *q)
{
    const Komsu *x = p, *y = q;
    if (x->hedef != y->hedef) {
        return x->hedef < y->hedef ? -1 : 1;
    }
    return (x->agirlik > y->agirlik) - (x->agirlik < y->agirlik);
}

static void komsulari_sirala(Graf *g)     /* (hedef, agirlik) artan */
{
    for (int v = 0; v < g->v_sayisi; v++) {
        if (g->komsu[v].boyut > 1) {   /* boş listede veri NULL olabilir */
            qsort(g->komsu[v].veri, g->komsu[v].boyut, sizeof(Komsu),
                  komsu_karsilastir);
        }
    }
}

/* '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural) */
static bool tamsayi_coz(const char *s, int *x)
{
    const char *p = (*s == '-') ? s + 1 : s;
    size_t n = strlen(p);
    if (n == 0 || n > 9) {
        return false;
    }
    for (size_t i = 0; i < n; i++) {
        if (p[i] < '0' || p[i] > '9') {
            return false;
        }
    }
    *x = (int)strtol(s, NULL, 10);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

/* s'yi boşluklarda böler; parça sayısını döndürür (ilk 4'ü t[]'ye) */
static int parcala(char *s, char **t)
{
    int k = 0;
    while (*s != '\0') {
        while (bosluk_mu(*s)) {
            *s++ = '\0';
        }
        if (*s == '\0') {
            break;
        }
        if (k < 4) {
            t[k] = s;
        }
        k++;
        while (*s != '\0' && !bosluk_mu(*s)) {
            s++;
        }
    }
    return k;
}

/* Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
 * (w yoksa 1). 0: başarı; 1: hata (ileti stderr'de, g boş). */
static int graf_oku(const char *yol, Graf *g)
{
    g->komsu = NULL;
    g->kenar = NULL;
    g->v_sayisi = 0;
    FILE *f = fopen(yol, "rb");
    if (f == NULL) {
        hata("dosya açılamadı: %s", yol);
        return 1;
    }
    char satir[SATIR_UZUNLUGU];
    char *t[4];
    int no = 0, sonuc = 0;
    bool baslik = false;
    while (sonuc == 0 && fgets(satir, sizeof satir, f) != NULL) {
        no++;
        size_t uz = strlen(satir);
        if (uz == sizeof satir - 1 && satir[uz - 1] != '\n') {
            hata("satır %d: satır çok uzun", no);
            sonuc = 1;
            break;
        }
        int k = parcala(satir, t);
        if (k == 0 || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            const char *tur = k == 3 ? t[2] : "yonsuz";
            if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &v) ||
                !tamsayi_coz(t[1], &e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 ||
                (strcmp(tur, "yonlu") != 0 && strcmp(tur, "yonsuz") != 0)) {
                hata("satır %d: başlık 'V E [yonlu|yonsuz]' bekleniyordu",
                     no);
                sonuc = 1;
            } else if (!graf_kur(g, v, e, strcmp(tur, "yonlu") == 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &u) ||
            !tamsayi_coz(t[1], &v) || (k == 3 && !tamsayi_coz(t[2], &w))) {
            hata("satır %d: kenar 'u v [w]' bekleniyordu", no);
            sonuc = 1;
        } else if (u < 0 || u >= g->v_sayisi || v < 0 || v >= g->v_sayisi) {
            hata("satır %d: köşe numarası 0..%d aralığında olmalı", no,
                 g->v_sayisi - 1);
            sonuc = 1;
        } else if (g->kenar_sayisi == g->e_sayisi) {
            hata("satır %d: fazla kenar (E = %d)", no, g->e_sayisi);
            sonuc = 1;
        } else {
            g->kenar[g->kenar_sayisi++] = (Kenar){u, v, w};
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0 ||
                (!g->yonlu && kd_ekle(&g->komsu[v], (Komsu){u, w}) != 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
        }
    }
    fclose(f);
    if (sonuc == 0 && !baslik) {
        hata("başlık satırı yok");
        sonuc = 1;
    } else if (sonuc == 0 && g->kenar_sayisi < g->e_sayisi) {
        hata("kenar sayısı eksik: %d bekleniyordu, %d okundu", g->e_sayisi,
             g->kenar_sayisi);
        sonuc = 1;
    }
    if (sonuc != 0) {
        graf_yok_et(g);
        return 1;
    }
    komsulari_sirala(g);
    return 0;
}
/* -------------------------------------------------------------------------- */

/* --- H7 öbeğinin genelleştirilmesi: (uzaklık, köşe) en küçük öbeği --- */
typedef struct {
    int uzaklik, kose;
} Oge;

typedef struct {
    Oge *a;
    size_t n, kapasite;
} Obek;

static size_t ebeveyn_i(size_t i) { return (i - 1) / 2; }

/* Demet sırası: önce uzaklık, eşitse köşe (Python demeti / std::pair) */
static bool kucuk_mu(Oge x, Oge y)
{
    return x.uzaklik < y.uzaklik || (x.uzaklik == y.uzaklik && x.kose < y.kose);
}

static void takas(Oge *x, Oge *y)
{
    Oge g = *x;
    *x = *y;
    *y = g;
}

/* 0: başarı, -1: bellek yetersiz (öbek değişmeden geçerli kalır) */
static int obege_ekle(Obek *o, Oge x)
{
    if (o->n == o->kapasite) {
        size_t yeni = o->kapasite == 0 ? 16 : 2 * o->kapasite;
        Oge *gecici = realloc(o->a, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;
        }
        o->a = gecici;
        o->kapasite = yeni;
    }
    size_t i = o->n++;
    o->a[i] = x;
    while (i > 0 && kucuk_mu(o->a[i], o->a[ebeveyn_i(i)])) {   /* yukarı */
        takas(&o->a[i], &o->a[ebeveyn_i(i)]);
        i = ebeveyn_i(i);
    }
    itme_sayisi++;
    if ((long long)o->n > en_buyuk_obek) {
        en_buyuk_obek = (long long)o->n;
    }
    return 0;
}

static Oge en_kucugu_cikar(Obek *o)     /* o->n > 0 olmalı */
{
    Oge en_kucuk = o->a[0];
    o->a[0] = o->a[--o->n];
    size_t i = 0;
    while (2 * i + 1 < o->n) {                                 /* aşağı */
        size_t c = 2 * i + 1;
        if (c + 1 < o->n && kucuk_mu(o->a[c + 1], o->a[c])) {
            c++;
        }
        if (!kucuk_mu(o->a[c], o->a[i])) {
            break;
        }
        takas(&o->a[i], &o->a[c]);
        i = c;
    }
    cikarma_sayisi++;
    return en_kucuk;
}
/* ------------------------------------------------------------------- */

static void uzaklik_yaz(int d, int genislik)
{
    if (d == SONSUZ) {
        printf("%*s∞", genislik - 1, "");
    } else {
        printf("%*d", genislik, d);
    }
}

static int oge_karsilastir(const void *p, const void *q)
{
    Oge x = *(const Oge *)p, y = *(const Oge *)q;
    return kucuk_mu(x, y) ? -1 : (kucuk_mu(y, x) ? 1 : 0);
}

/* Öbek içeriği sıralı (iç dizi düzeni gerçekleştirime bağlıdır) */
static void obek_yaz(const Obek *o)
{
    Oge *kopya = malloc((o->n > 0 ? o->n : 1) * sizeof *kopya);
    if (kopya == NULL) {
        return;
    }
    memcpy(kopya, o->a, o->n * sizeof *kopya);
    qsort(kopya, o->n, sizeof *kopya, oge_karsilastir);
    printf("[");
    for (size_t i = 0; i < o->n; i++) {
        printf(i > 0 ? " (%d,%d)" : "(%d,%d)", kopya[i].uzaklik,
               kopya[i].kose);
    }
    printf("]");
    free(kopya);
}

/* O((V + E) log V): öbekte (uzaklık, köşe); anahtar azaltma yerine
 * yeniden itme + tembel silme. 0: başarı, -1: bellek yetersiz. */
static int dijkstra_obek(const Graf *g, int kaynak, int *d, int *ebeveyn,
                         bool yaz)
{
    int n = g->v_sayisi;
    bool *kesin = calloc((size_t)n, sizeof *kesin);
    Obek obek = {NULL, 0, 0};
    if (kesin == NULL) {
        return -1;
    }
    for (int v = 0; v < n; v++) {
        d[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    d[kaynak] = 0;
    int sonuc = obege_ekle(&obek, (Oge){0, kaynak});
    while (sonuc == 0 && obek.n > 0) {
        Oge x = en_kucugu_cikar(&obek);
        int u = x.kose;
        if (kesin[u]) {                  /* eskimiş kayıt: atla */
            atlanan_sayisi++;
            if (yaz) {
                printf("  çıkar (%d,%d): ESKİMİŞ (%d kesin, d[%d] = %d) -> "
                       "atla\n", x.uzaklik, u, u, u, d[u]);
            }
            continue;
        }
        kesin[u] = true;                 /* öbekten çıkınca kesinleşir */
        if (yaz) {
            printf("  çıkar (%d,%d): %d kesinleşti; kesinleşen {", x.uzaklik,
                   u, u);
            bool ilk = true;
            for (int k = 0; k < n; k++) {
                if (kesin[k]) {
                    printf(ilk ? "%d" : ", %d", k);
                    ilk = false;
                }
            }
            printf("}\n");
        }
        const KomsuDizisi *k = &g->komsu[u];
        for (size_t i = 0; i < k->boyut && sonuc == 0; i++) {
            int v = k->veri[i].hedef, w = k->veri[i].agirlik;
            kenar_inceleme++;
            if (!kesin[v] && d[u] != SONSUZ && d[u] + w < d[v]) {
                if (yaz) {
                    printf("     gevşet %d->%d (w = %d): d[%d] = ", u, v, w,
                           v);
                    uzaklik_yaz(d[v], 1);
                    printf(" -> %d, it (%d,%d)\n", d[u] + w, d[u] + w, v);
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
                sonuc = obege_ekle(&obek, (Oge){d[v], v});
            }
        }
        if (yaz) {
            printf("     öbek: ");
            obek_yaz(&obek);
            printf("\n");
        }
    }
    free(obek.a);
    free(kesin);
    return sonuc;
}

/* O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama */
static void dijkstra_dizi(const Graf *g, int kaynak, int *d, int *ebeveyn,
                          bool yaz)
{
    int n = g->v_sayisi;
    bool *kesin = calloc((size_t)n, sizeof *kesin);
    if (kesin == NULL) {
        return;
    }
    for (int v = 0; v < n; v++) {
        d[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    d[kaynak] = 0;
    for (int adim = 1; adim <= n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {    /* en küçük d: doğrusal tarama */
            taranan_hucre++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;                       /* kalanlar ulaşılamaz */
        }
        kesin[u] = true;                 /* d[u] artık kesin */
        if (yaz) {
            printf("  adım %d: seç %d (d = %d); kesinleşen {", adim, u, d[u]);
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (kesin[x]) {
                    printf(ilk ? "%d" : ", %d", x);
                    ilk = false;
                }
            }
            printf("}\n");
        }
        const KomsuDizisi *k = &g->komsu[u];
        for (size_t i = 0; i < k->boyut; i++) {
            int v = k->veri[i].hedef, w = k->veri[i].agirlik;
            kenar_inceleme++;
            if (kesin[v]) {
                continue;
            }
            if (d[u] != SONSUZ && d[u] + w < d[v]) {   /* taşma korumalı */
                if (yaz) {
                    printf("     gevşet %d->%d (w = %d): d[%d] = ", u, v, w,
                           v);
                    uzaklik_yaz(d[v], 1);
                    printf(" -> %d\n", d[u] + w);
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
            } else if (yaz) {
                printf("     %d->%d (w = %d): %d + %d >= %d, değişmez\n", u,
                       v, w, d[u], w, d[v]);
            }
        }
        if (yaz) {
            printf("     d:");
            for (int x = 0; x < n; x++) {
                printf(" ");
                uzaklik_yaz(d[x], 1);
            }
            printf("\n");
        }
    }
    free(kesin);
}

/* Yönlü: her u için u -> u+1 (halka, ulaşılabilirlik için) ve derece-1
 * rastgele kenar; ağırlıklar 1..w_ust (ortak LCG) */
static bool rastgele_graf(Graf *g, int v_sayisi, int derece, int w_ust,
                          uint64_t tohum)
{
    rastgele_tohum(tohum);
    if (!graf_kur(g, v_sayisi, v_sayisi * derece, true)) {
        return false;
    }
    for (int u = 0; u < v_sayisi; u++) {
        int w = rastgele_aralik(1, w_ust);
        if (kd_ekle(&g->komsu[u], (Komsu){(u + 1) % v_sayisi, w}) != 0) {
            return false;
        }
        for (int j = 0; j < derece - 1; j++) {
            int v = rastgele_aralik(0, v_sayisi - 1);
            w = rastgele_aralik(1, w_ust);
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0) {
                return false;
            }
        }
    }
    komsulari_sirala(g);
    return true;
}

/* Ebeveyn dizisini hedeften kaynağa izle, ters sırada yaz */
static void yol_yaz(const int *ebeveyn, int n, int kaynak, int hedef)
{
    int *yol = malloc((size_t)n * sizeof *yol);
    if (yol == NULL) {
        return;
    }
    int k = 0;
    for (int v = hedef; v != -1; v = ebeveyn[v]) {
        yol[k++] = v;
    }
    if (yol[k - 1] != kaynak) {
        printf("ulaşılamaz");
    } else {
        for (int i = k - 1; i >= 0; i--) {
            printf(i < k - 1 ? " -> %d" : "%d", yol[i]);
        }
    }
    free(yol);
}

static void sayaclari_sifirla(void)
{
    itme_sayisi = cikarma_sayisi = atlanan_sayisi = kenar_inceleme = 0;
    gevsetme_sayisi = en_buyuk_obek = taranan_hucre = 0;
}

int main(int argc, char **argv)
{
    if (argc != 2 && argc != 3) {
        fprintf(stderr, "Kullanım: H12_08_dijkstra_obek GRAF_DOSYASI "
                        "[KAYNAK]\n");
        return 2;
    }
    Graf g;
    if (graf_oku(argv[1], &g) != 0) {
        return 1;
    }
    int kaynak = 0;
    if (argc == 3 && (!tamsayi_coz(argv[2], &kaynak) || kaynak < 0 ||
                      kaynak >= g.v_sayisi)) {
        hata("kaynak köşe 0..%d aralığında olmalı", g.v_sayisi - 1);
        graf_yok_et(&g);
        return 2;
    }
    for (int i = 0; i < g.kenar_sayisi; i++) {
        if (g.kenar[i].w < 0) {
            hata("negatif ağırlık %d->%d (%d): Dijkstra'nın önkoşulu "
                 "sağlanmıyor (Örnek 9)", g.kenar[i].u, g.kenar[i].v,
                 g.kenar[i].w);
            graf_yok_et(&g);
            return 1;
        }
    }
    printf("1) Graf: %d köşe, %d kenar, %s; kaynak %d\n", g.v_sayisi,
           g.e_sayisi, g.yonlu ? "yönlü" : "yönsüz", kaynak);
    printf("  öbek öğesi (uzaklık, köşe); başlangıç: öbek [(0,%d)]\n",
           kaynak);
    int n = g.v_sayisi;
    int *d = malloc((size_t)n * sizeof *d);
    int *ebeveyn = malloc((size_t)n * sizeof *ebeveyn);
    if (d == NULL || ebeveyn == NULL ||
        dijkstra_obek(&g, kaynak, d, ebeveyn, true) != 0) {
        free(d);
        free(ebeveyn);
        graf_yok_et(&g);
        return 1;
    }
    printf("  sayaçlar: itme = %lld, çıkarma = %lld, atlanan (eskimiş) = "
           "%lld, kenar inceleme = %lld, başarılı gevşetme = %lld, en büyük "
           "öbek = %lld\n", itme_sayisi, cikarma_sayisi, atlanan_sayisi,
           kenar_inceleme, gevsetme_sayisi, en_buyuk_obek);
    printf("  itme = 1 + başarılı gevşetme: %lld = 1 + %lld; atlanan = itme "
           "- kesinleşen: %lld = %lld - %lld\n", itme_sayisi,
           gevsetme_sayisi, atlanan_sayisi, itme_sayisi,
           itme_sayisi - atlanan_sayisi);

    printf("\n2) En kısa yollar (ebeveyn dizisi geriye izlenir), kaynak "
           "%d\n", kaynak);
    for (int v = 0; v < n; v++) {
        printf("  %d: uzaklık ", v);
        uzaklik_yaz(d[v], 4);
        printf("  yol ");
        yol_yaz(ebeveyn, n, kaynak, v);
        printf("\n");
    }
    free(d);
    free(ebeveyn);
    graf_yok_et(&g);

    printf("\n3) Kâhin: dizi tabanlı Dijkstra (Örnek 7) ile karşılaştırma; "
           "rastgele yönlü\n   graflar (derece 4, ağırlık 1..100, tohum "
           "42)\n");
    printf("      V      E   itme  çıkarma  atlanan  en büyük öbek  "
           "(V+E)·⌈log2 V⌉  aynı mı\n");
    const int boyutlar[3] = {100, 500, 2000};
    for (int i = 0; i < 3; i++) {
        n = boyutlar[i];
        Graf r;
        int *d1 = malloc((size_t)n * sizeof *d1);
        int *e1 = malloc((size_t)n * sizeof *e1);
        int *d2 = malloc((size_t)n * sizeof *d2);
        int *e2 = malloc((size_t)n * sizeof *e2);
        if (d1 == NULL || e1 == NULL || d2 == NULL || e2 == NULL ||
            !rastgele_graf(&r, n, 4, 100, 42)) {
            free(d1);
            free(e1);
            free(d2);
            free(e2);
            return 1;
        }
        sayaclari_sifirla();
        dijkstra_dizi(&r, 0, d2, e2, false);
        sayaclari_sifirla();
        int hata_kodu = dijkstra_obek(&r, 0, d1, e1, false);
        int log = 0;
        while ((1 << log) < n) {
            log++;
        }
        bool ayni = hata_kodu == 0 &&
                    memcmp(d1, d2, (size_t)n * sizeof *d1) == 0;
        printf("  %5d  %5d  %5lld  %7lld  %7lld  %13lld  %14lld  %s\n", n,
               r.e_sayisi, itme_sayisi, cikarma_sayisi, atlanan_sayisi,
               en_buyuk_obek, (long long)(n + r.e_sayisi) * log,
               ayni ? "evet" : "HAYIR");
        graf_yok_et(&r);
        free(d1);
        free(e1);
        free(d2);
        free(e2);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (öbek elle, H7); C++ — öbek
 * std::priority_queue<std::pair<int, int>, std::vector<…>,
 * std::greater<…>>; Python — heapq. Dijkstra'nın kendisi elle yazılır. */

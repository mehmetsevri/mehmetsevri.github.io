/* H12_03_aralik_bolumleme.c — AP-2 Hafta 12 · Örnek 3 (★★)
 * Amaç    : Aralık bölümleme: bütün dersleri en az salonla yerleştirmek;
 *           başlangıca göre sırala, salonların bitiş zamanlarını en küçük
 *           öbekte tut; salon ataması ve alt sınır (aynı anda en çok ders)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_03_aralik_bolumleme.c ortak_rastgele.c \
 *           -o H12_03_aralik_bolumleme
 * Çalıştır: ./H12_03_aralik_bolumleme
 * Eşleri  : cpp/H12_03_aralik_bolumleme.cpp ·
 *           python/H12_03_aralik_bolumleme.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek öğesi (bitiş, salon); eşitlikte küçük salon. Aralıklar
 *           yarı açık: 10:30'da biten salon 10:30'da başlayana verilebilir.
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define MAKS_N 32

typedef struct {
    int bas, bit, kimlik;
} Ders;

/* --- H7 öbeğinin genelleştirilmesi: (bitiş, salon) en küçük öbeği --- */
typedef struct {
    int bitis, salon;
} Oge;

typedef struct {
    Oge a[MAKS_N];
    int n;
} Obek;

static long long itme_sayisi = 0, cikarma_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

/* Demet sırası: önce bitiş, eşitse salon (tam sıralama) */
static bool kucuk_mu(Oge x, Oge y)
{
    return x.bitis < y.bitis || (x.bitis == y.bitis && x.salon < y.salon);
}

static void takas(Oge *x, Oge *y)
{
    Oge g = *x;
    *x = *y;
    *y = g;
}

static void yukari_suz(Obek *o, int i)
{
    while (i > 0 && kucuk_mu(o->a[i], o->a[ebeveyn(i)])) {
        takas(&o->a[i], &o->a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
}

static void asagi_suz(Obek *o, int i)
{
    while (2 * i + 1 < o->n) {
        int c = 2 * i + 1;
        if (c + 1 < o->n && kucuk_mu(o->a[c + 1], o->a[c])) {
            c++;
        }
        if (!kucuk_mu(o->a[c], o->a[i])) {
            break;
        }
        takas(&o->a[i], &o->a[c]);
        i = c;
    }
}

static void obege_ekle(Obek *o, Oge x)  /* kapasite MAKS_N yeter: n <= 30 */
{
    o->a[o->n++] = x;
    yukari_suz(o, o->n - 1);
    itme_sayisi++;
}

static Oge en_kucugu_cikar(Obek *o)     /* o->n > 0 olmalı */
{
    Oge en_kucuk = o->a[0];
    o->a[0] = o->a[--o->n];
    asagi_suz(o, 0);
    cikarma_sayisi++;
    return en_kucuk;
}
/* ------------------------------------------------------------------- */

static void saat_yaz(int dk)
{
    printf("%02d:%02d", dk / 60, dk % 60);
}

static int oge_karsilastir(const void *p, const void *q)
{
    Oge x = *(const Oge *)p, y = *(const Oge *)q;
    return kucuk_mu(x, y) ? -1 : (kucuk_mu(y, x) ? 1 : 0);
}

/* Öbek içeriği (bitiş, salon) sıralı yazılır: iç dizi düzeni
 * kütüphaneye göre değişir, çıktı buna bağlı olmasın */
static void obek_yaz(const Obek *o)
{
    Oge kopya[MAKS_N];
    for (int i = 0; i < o->n; i++) {
        kopya[i] = o->a[i];
    }
    qsort(kopya, (size_t)o->n, sizeof kopya[0], oge_karsilastir);
    printf("[");
    for (int i = 0; i < o->n; i++) {
        printf(i > 0 ? " (" : "(");
        saat_yaz(kopya[i].bitis);
        printf(",%d)", kopya[i].salon + 1);
    }
    printf("]");
}

static int derse_gore(const void *p, const void *q)
{
    const Ders *x = p, *y = q;
    if (x->bas != y->bas) {
        return x->bas < y->bas ? -1 : 1;
    }
    if (x->bit != y->bit) {
        return x->bit < y->bit ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

/* ders[0..n-1]; salon[kimlik] = atanan salon. Salon sayısını döndürür. */
static int bolumle(const Ders *ders, int n, int *salon, bool yaz)
{
    Ders sira[MAKS_N];
    for (int i = 0; i < n; i++) {
        sira[i] = ders[i];
    }
    qsort(sira, (size_t)n, sizeof sira[0], derse_gore);
    Obek obek = {.n = 0};               /* (bitiş, salon) öğeleri */
    int salon_sayisi = 0;
    for (int i = 0; i < n; i++) {
        const Ders *x = &sira[i];
        int s;
        const char *not_;
        if (obek.n > 0 && obek.a[0].bitis <= x->bas) {  /* en erken boşalan */
            s = en_kucugu_cikar(&obek).salon;
            not_ = "boşalan salon";
        } else {
            s = salon_sayisi++;          /* yeni salon aç */
            not_ = "YENİ salon";
        }
        salon[x->kimlik] = s;
        obege_ekle(&obek, (Oge){x->bit, s});
        if (yaz) {
            printf("  %c ", 'A' + x->kimlik);
            saat_yaz(x->bas);
            printf("-");
            saat_yaz(x->bit);
            printf(" -> salon %d (%s)  öbek: ", s + 1, not_);
            obek_yaz(&obek);
            printf("\n");
        }
    }
    return salon_sayisi;
}

typedef struct {
    int zaman, tur;             /* tür 0 = bitiş, 1 = başlangıç */
} Olay;

static int olaya_gore(const void *p, const void *q)
{
    const Olay *x = p, *y = q;
    if (x->zaman != y->zaman) {
        return x->zaman < y->zaman ? -1 : 1;
    }
    return (x->tur > y->tur) - (x->tur < y->tur);
}

/* Alt sınır: aynı anda süren en çok ders sayısı. Olaylar (zaman, tür):
 * aynı anda önce bitişler (yarı açık). *zaman = ilk ulaşıldığı an. */
static int derinlik(const Ders *ders, int n, int *zaman)
{
    Olay olay[2 * MAKS_N];
    for (int i = 0; i < n; i++) {
        olay[2 * i] = (Olay){ders[i].bas, 1};
        olay[2 * i + 1] = (Olay){ders[i].bit, 0};
    }
    qsort(olay, (size_t)(2 * n), sizeof olay[0], olaya_gore);
    int etkin = 0, en_cok = 0;
    *zaman = 0;
    for (int i = 0; i < 2 * n; i++) {
        etkin += olay[i].tur == 1 ? 1 : -1;
        if (etkin > en_cok) {
            en_cok = etkin;
            *zaman = olay[i].zaman;
        }
    }
    return en_cok;
}

int main(void)
{
    const int veri[10][2] = {{540, 630}, {540, 750}, {600, 690}, {630, 720},
                             {660, 840}, {720, 810}, {780, 870}, {810, 960},
                             {870, 960}, {900, 990}};
    Ders ders[10];
    int salon[MAKS_N];
    for (int i = 0; i < 10; i++) {
        ders[i] = (Ders){veri[i][0], veri[i][1], i};
    }
    printf("1) %d ders, başlangıca göre sıra; öbekte (bitiş, salon)\n", 10);
    int k = bolumle(ders, 10, salon, true);
    printf("  gereken salon = %d; öbeğe itme = %lld, çıkarma = %lld\n", k,
           itme_sayisi, cikarma_sayisi);
    int t;
    int d = derinlik(ders, 10, &t);
    printf("  alt sınır: ");
    saat_yaz(t);
    printf("'da aynı anda %d ders sürüyor -> en az %d salon gerekir\n", d,
           d);
    printf("  açgözlü %d salon = alt sınır %d: %s\n", k, d,
           k == d ? "en iyi" : "FARKLI");

    printf("\n2) Salon ataması (zaman çizgisi)\n");
    for (int s = 0; s < k; s++) {
        printf("  salon %d: ", s + 1);
        bool ilk = true;
        for (int i = 0; i < 10; i++) {
            if (salon[i] == s) {
                printf(ilk ? "%c " : ", %c ", 'A' + i);
                saat_yaz(ders[i].bas);
                printf("-");
                saat_yaz(ders[i].bit);
                ilk = false;
            }
        }
        printf("\n");
    }

    printf("\n3) Rastgele denetim: salon sayısı = derinlik mi?\n");
    rastgele_tohum(42);
    int esit = 0;
    for (int deneme = 0; deneme < 1000; deneme++) {
        int n = rastgele_aralik(5, 30);
        Ders r[MAKS_N];
        int rs[MAKS_N];
        for (int i = 0; i < n; i++) {
            int bas = rastgele_aralik(0, 100);
            r[i] = (Ders){bas, bas + rastgele_aralik(1, 30), i};
        }
        itme_sayisi = cikarma_sayisi = 0;
        esit += bolumle(r, n, rs, false) == derinlik(r, n, &t);
    }
    printf("  1000 rastgele örnek (n = 5..30, tohum 42): eşit = %d/1000\n",
           esit);
    return 0;
}

/* Kütüphane karşılığı: C — yok (öbek elle, H7); C++ — öbek
 * std::priority_queue<std::pair<int, int>, …, std::greater<…>>; Python —
 * heapq (en küçük öbek). Bölümleme algoritmasının kendisi elle yazılır. */

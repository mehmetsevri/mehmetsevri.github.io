/* H12_04_kesirli_sirt_cantasi.c — AP-2 Hafta 12 · Örnek 4 (★★)
 * Amaç    : Kesirli sırt çantası: birim değere (değer/ağırlık) göre sırala,
 *           sığanı tam al, sonuncusunun kesrini al; değer tamsayı kesir
 *           olarak tutulur. Kâhin: bütün sıralamalar (n!). 0/1 sırt
 *           çantasında aynı ölçütün başarısızlığı (H13'e köprü)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_04_kesirli_sirt_cantasi.c -o H12_04_kesirli_sirt_cantasi
 * Çalıştır: ./H12_04_kesirli_sirt_cantasi
 * Eşleri  : cpp/H12_04_kesirli_sirt_cantasi.cpp ·
 *           python/H12_04_kesirli_sirt_cantasi.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : oranlar çapraz çarpımla karşılaştırılır (v1·w2 ile v2·w1):
 *           kayan nokta yok; eşitlikte küçük kimlik önce
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_N 8

typedef struct {
    int agirlik, deger, kimlik;
} Yuk;

typedef struct {
    long long pay, payda;       /* indirgenmiş kesir, payda > 0 */
} Kesir;

static long long ebob(long long a, long long b)
{
    while (b != 0) {
        long long g = a % b;
        a = b;
        b = g;
    }
    return a;
}

/* pay/payda'yı iki basamakla yuvarlayıp yazar (tamsayı aritmetiği) */
static void ondalik_yaz(long long pay, long long payda, int genislik)
{
    long long yuz = (pay * 200 + payda) / (2 * payda);
    char s[32];
    snprintf(s, sizeof s, "%lld.%02lld", yuz / 100, yuz % 100);
    printf("%*s", genislik, s);
}

static void kesir_yaz(Kesir k)
{
    if (k.payda == 1) {
        printf("%lld", k.pay);
        return;
    }
    printf("%lld/%lld = ", k.pay, k.payda);
    ondalik_yaz(k.pay, k.payda, 0);
}

/* x önce gelmeli mi? x.deger/x.agirlik > y.deger/y.agirlik */
static int birim_degere_gore(const void *p, const void *q)
{
    const Yuk *x = p, *y = q;
    long long sol = (long long)x->deger * y->agirlik;
    long long sag = (long long)y->deger * x->agirlik;
    if (sol != sag) {
        return sol > sag ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

static int degere_gore(const void *p, const void *q)    /* değer azalan */
{
    const Yuk *x = p, *y = q;
    if (x->deger != y->deger) {
        return x->deger > y->deger ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

static int agirliga_gore(const void *p, const void *q)  /* ağırlık artan */
{
    const Yuk *x = p, *y = q;
    if (x->agirlik != y->agirlik) {
        return x->agirlik < y->agirlik ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

/* Sırayla doldurur; değeri indirgenmiş kesir olarak döndürür */
static Kesir doldur(const Yuk *sira, int n, int kapasite, bool yaz)
{
    long long tam = 0;
    int kalan = kapasite;
    for (int i = 0; i < n; i++) {
        const Yuk *x = &sira[i];
        if (kalan == 0) {
            break;
        }
        if (x->agirlik <= kalan) {       /* tamamı sığar */
            kalan -= x->agirlik;
            tam += x->deger;
            if (yaz) {
                printf("  %c: %2d/%2d kg alındı (+%d), kalan kapasite %d\n",
                       'A' + x->kimlik, x->agirlik, x->agirlik, x->deger,
                       kalan);
            }
        } else {                         /* kesri alınır, çanta dolar */
            long long pay = tam * x->agirlik + (long long)x->deger * kalan;
            long long payda = x->agirlik;
            long long g = ebob(pay, payda);
            Kesir k = {pay / g, payda / g};
            if (yaz) {
                printf("  %c: %2d/%2d kg alındı (+%d·%d/%d), kalan "
                       "kapasite 0\n", 'A' + x->kimlik, kalan, x->agirlik,
                       x->deger, kalan, x->agirlik);
                printf("  toplam değer = %lld + %d/%d = ", tam,
                       x->deger * kalan, x->agirlik);
                kesir_yaz(k);
                printf("\n");
            }
            return k;
        }
    }
    if (yaz) {
        printf("  toplam değer = %lld\n", tam);
    }
    return (Kesir){tam, 1};
}

/* Sözlük sırasında sonraki permütasyon; son permütasyondaysa false */
static bool sonraki_permutasyon(int *p, int n)
{
    int i = n - 2;
    while (i >= 0 && p[i] >= p[i + 1]) {
        i--;
    }
    if (i < 0) {
        return false;
    }
    int j = n - 1;
    while (p[j] <= p[i]) {
        j--;
    }
    int g = p[i];
    p[i] = p[j];
    p[j] = g;
    for (int a = i + 1, b = n - 1; a < b; a++, b--) {
        g = p[a];
        p[a] = p[b];
        p[b] = g;
    }
    return true;
}

/* Bütün n! sırayla doldurma; en büyük değeri ve sıra sayısını verir */
static Kesir kahin(const Yuk *yuk, int n, int kapasite, int *sayi)
{
    int p[MAKS_N];
    Yuk sira[MAKS_N];
    for (int i = 0; i < n; i++) {
        p[i] = i;
    }
    Kesir en = {-1, 1};
    *sayi = 0;
    do {
        (*sayi)++;
        for (int i = 0; i < n; i++) {
            sira[i] = yuk[p[i]];
        }
        Kesir k = doldur(sira, n, kapasite, false);
        if (k.pay * en.payda > en.pay * k.payda) {
            en = k;
        }
    } while (sonraki_permutasyon(p, n));
    return en;
}

/* 0/1: bütün alt kümeler; en iyi değer ve maskesi */
static int sifir_bir_kaba(const Yuk *yuk, int n, int kapasite,
                          unsigned *en_maske)
{
    int en_iyi = -1;
    *en_maske = 0;
    for (unsigned maske = 0; maske < (1u << n); maske++) {
        int w = 0, v = 0;
        for (int i = 0; i < n; i++) {
            if (maske >> i & 1u) {
                w += yuk[i].agirlik;
                v += yuk[i].deger;
            }
        }
        if (w <= kapasite && v > en_iyi) {
            en_iyi = v;
            *en_maske = maske;
        }
    }
    return en_iyi;
}

static void sirala_kopyala(const Yuk *yuk, int n, Yuk *sira,
                           int (*kars)(const void *, const void *))
{
    memcpy(sira, yuk, (size_t)n * sizeof *yuk);
    qsort(sira, (size_t)n, sizeof *sira, kars);
}

int main(void)
{
    const int veri[6][2] = {{12, 84}, {8, 40}, {20, 100}, {15, 90},
                            {25, 80}, {9, 30}};
    Yuk yuk[6], sira[MAKS_N];
    for (int i = 0; i < 6; i++) {
        yuk[i] = (Yuk){veri[i][0], veri[i][1], i};
    }
    int kapasite = 60;
    printf("1) Kesirli sırt çantası: kapasite %d kg, %d yük\n", kapasite, 6);
    printf("  yük  ağırlık  değer  birim değer\n");
    for (int i = 0; i < 6; i++) {
        printf("  %c   %5d  %5d  ", 'A' + yuk[i].kimlik, yuk[i].agirlik,
               yuk[i].deger);
        ondalik_yaz(yuk[i].deger, yuk[i].agirlik, 11);
        printf("\n");
    }
    sirala_kopyala(yuk, 6, sira, birim_degere_gore);
    printf("  birim değere göre sıra (azalan; eşitlikte kimlik):");
    for (int i = 0; i < 6; i++) {
        printf(" %c", 'A' + sira[i].kimlik);
    }
    printf("\n");
    Kesir k = doldur(sira, 6, kapasite, true);

    printf("\n2) Kâhin: %d yükün bütün sıralamalarıyla doldurma\n", 6);
    int sayi;
    Kesir en = kahin(yuk, 6, kapasite, &sayi);
    printf("  %d sıralama; en büyük değer ", sayi);
    kesir_yaz(en);
    printf("; birim değer sırası bunu veriyor mu? %s\n",
           (k.pay == en.pay && k.payda == en.payda) ? "evet" : "HAYIR");
    sirala_kopyala(yuk, 6, sira, degere_gore);
    printf("  'en değerli ilk' sırası : ");
    kesir_yaz(doldur(sira, 6, kapasite, false));
    printf("\n");
    sirala_kopyala(yuk, 6, sira, agirliga_gore);
    printf("  'en hafif ilk' sırası   : ");
    kesir_yaz(doldur(sira, 6, kapasite, false));
    printf("\n");

    printf("\n3) 0/1 sırt çantasında birim değer ölçütü yetmez (H13'e "
           "köprü)\n");
    const Yuk kucuk[3] = {{10, 60, 0}, {20, 100, 1}, {30, 120, 2}};
    printf("  kapasite 50: A(10 kg, 60) B(20 kg, 100) C(30 kg, 120)\n");
    sirala_kopyala(kucuk, 3, sira, birim_degere_gore);
    printf("  kesirli açgözlü          : ");
    kesir_yaz(doldur(sira, 3, 50, false));
    printf("\n");
    int w = 0, v = 0;
    printf("  0/1 açgözlü (birim değer): ");
    for (int i = 0; i < 3; i++) {        /* 0/1: ya tamamı ya hiç */
        if (w + sira[i].agirlik <= 50) {
            w += sira[i].agirlik;
            v += sira[i].deger;
            printf("%c", 'A' + sira[i].kimlik);
        }
    }
    printf(" -> %d\n", v);
    unsigned maske;
    int en_iyi = sifir_bir_kaba(kucuk, 3, 50, &maske);
    printf("  0/1 en iyi (kaba kuvvet, %u alt küme): ", 1u << 3);
    for (int i = 0; i < 3; i++) {
        if (maske >> i & 1u) {
            printf("%c", 'A' + i);
        }
    }
    printf(" -> %d\n", en_iyi);
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok; sıralama aracı qsort /
 * std::sort / sorted (karşılaştırıcı tam sıralama tanımlar). */

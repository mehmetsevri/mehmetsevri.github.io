/* H12_11_kruskal.c — AP-2 Hafta 12 · Örnek 11 (★★★)
 * Amaç    : Kruskal ile en küçük kapsayan ağaç: kenarlar (w, u, v) sırasıyla;
 *           birleşim–bul (rütbe + yol sıkıştırma) ile döngü denetimi; kabul
 *           ve reddedilen kenarlar, her adımda birleşim–bul ormanı; kabul
 *           edilen her kenar için kesim özelliğinin denetimi; kâhin: kaba
 *           kuvvet (bütün V - 1 kenarlı alt kümeler)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_11_kruskal.c \
 *           -o H12_11_kruskal
 * Çalıştır: ./H12_11_kruskal ../girdiler/h12_kampus.txt
 * Eşleri  : cpp/H12_11_kruskal.cpp · python/H12_11_kruskal.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : yönsüz kenar (min(u, v), max(u, v)) olarak tutulur; sıralama
 *           aracı qsort, karşılaştırıcı (w, u, v) tam sıralamasıdır.
 */
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SATIR_UZUNLUGU 512

static long long izleme_sayisi = 0;   /* birleşim–bul: işaretçi izleme */
static long long bul_sayisi = 0;
static long long birlestir_sayisi = 0;

/* ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ---------------- */
typedef struct {
    int hedef, agirlik;
} Komsu;

typedef struct {                /* H8 dinamik dizisi: komşu listesi */
    Komsu *veri;
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int u, v, w;
} Kenar;

typedef struct {
    int v_sayisi, e_sayisi;
    bool yonlu;
    KomsuDizisi *komsu;         /* komsu[u]: u'dan çıkan kenarlar */
    Kenar *kenar;               /* dosyadaki sırayla kenar listesi */
    int kenar_sayisi;
} Graf;

static void hata(const char *bicim, ...)
{
    va_list ap;
    va_start(ap, bicim);
    fprintf(stderr, "Hata: ");
    vfprintf(stderr, bicim, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

/* x'i sona ekler; doluysa kapasiteyi ikiye katlar. 0: başarı, -1: bellek */
static int kd_ekle(KomsuDizisi *d, Komsu x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite == 0 ? 4 : 2 * d->kapasite;
        Komsu *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

/* Sahiplik: g'nin dizileri graf_yok_et ile serbest bırakılır */
static bool graf_kur(Graf *g, int v_sayisi, int e_sayisi, bool yonlu)
{
    g->v_sayisi = v_sayisi;
    g->e_sayisi = e_sayisi;
    g->yonlu = yonlu;
    g->kenar_sayisi = 0;
    g->komsu = calloc((size_t)v_sayisi, sizeof *g->komsu);
    g->kenar = malloc((size_t)(e_sayisi > 0 ? e_sayisi : 1) * sizeof *g->kenar);
    return g->komsu != NULL && g->kenar != NULL;
}

static void graf_yok_et(Graf *g)
{
    if (g->komsu != NULL) {
        for (int v = 0; v < g->v_sayisi; v++) {
            free(g->komsu[v].veri);
        }
    }
    free(g->komsu);
    free(g->kenar);
    g->komsu = NULL;
    g->kenar = NULL;
}

static int komsu_karsilastir(const void *p, const void *q)
{
    const Komsu *x = p, *y = q;
    if (x->hedef != y->hedef) {
        return x->hedef < y->hedef ? -1 : 1;
    }
    return (x->agirlik > y->agirlik) - (x->agirlik < y->agirlik);
}

static void komsulari_sirala(Graf *g)     /* (hedef, agirlik) artan */
{
    for (int v = 0; v < g->v_sayisi; v++) {
        if (g->komsu[v].boyut > 1) {   /* boş listede veri NULL olabilir */
            qsort(g->komsu[v].veri, g->komsu[v].boyut, sizeof(Komsu),
                  komsu_karsilastir);
        }
    }
}

/* '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural) */
static bool tamsayi_coz(const char *s, int *x)
{
    const char *p = (*s == '-') ? s + 1 : s;
    size_t n = strlen(p);
    if (n == 0 || n > 9) {
        return false;
    }
    for (size_t i = 0; i < n; i++) {
        if (p[i] < '0' || p[i] > '9') {
            return false;
        }
    }
    *x = (int)strtol(s, NULL, 10);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

/* s'yi boşluklarda böler; parça sayısını döndürür (ilk 4'ü t[]'ye) */
static int parcala(char *s, char **t)
{
    int k = 0;
    while (*s != '\0') {
        while (bosluk_mu(*s)) {
            *s++ = '\0';
        }
        if (*s == '\0') {
            break;
        }
        if (k < 4) {
            t[k] = s;
        }
        k++;
        while (*s != '\0' && !bosluk_mu(*s)) {
            s++;
        }
    }
    return k;
}

/* Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
 * (w yoksa 1). 0: başarı; 1: hata (ileti stderr'de, g boş). */
static int graf_oku(const char *yol, Graf *g)
{
    g->komsu = NULL;
    g->kenar = NULL;
    g->v_sayisi = 0;
    FILE *f = fopen(yol, "rb");
    if (f == NULL) {
        hata("dosya açılamadı: %s", yol);
        return 1;
    }
    char satir[SATIR_UZUNLUGU];
    char *t[4];
    int no = 0, sonuc = 0;
    bool baslik = false;
    while (sonuc == 0 && fgets(satir, sizeof satir, f) != NULL) {
        no++;
        size_t uz = strlen(satir);
        if (uz == sizeof satir - 1 && satir[uz - 1] != '\n') {
            hata("satır %d: satır çok uzun", no);
            sonuc = 1;
            break;
        }
        int k = parcala(satir, t);
        if (k == 0 || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            const char *tur = k == 3 ? t[2] : "yonsuz";
            if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &v) ||
                !tamsayi_coz(t[1], &e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 ||
                (strcmp(tur, "yonlu") != 0 && strcmp(tur, "yonsuz") != 0)) {
                hata("satır %d: başlık 'V E [yonlu|yonsuz]' bekleniyordu",
                     no);
                sonuc = 1;
            } else if (!graf_kur(g, v, e, strcmp(tur, "yonlu") == 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &u) ||
            !tamsayi_coz(t[1], &v) || (k == 3 && !tamsayi_coz(t[2], &w))) {
            hata("satır %d: kenar 'u v [w]' bekleniyordu", no);
            sonuc = 1;
        } else if (u < 0 || u >= g->v_sayisi || v < 0 || v >= g->v_sayisi) {
            hata("satır %d: köşe numarası 0..%d aralığında olmalı", no,
                 g->v_sayisi - 1);
            sonuc = 1;
        } else if (g->kenar_sayisi == g->e_sayisi) {
            hata("satır %d: fazla kenar (E = %d)", no, g->e_sayisi);
            sonuc = 1;
        } else {
            g->kenar[g->kenar_sayisi++] = (Kenar){u, v, w};
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0 ||
                (!g->yonlu && kd_ekle(&g->komsu[v], (Komsu){u, w}) != 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
        }
    }
    fclose(f);
    if (sonuc == 0 && !baslik) {
        hata("başlık satırı yok");
        sonuc = 1;
    } else if (sonuc == 0 && g->kenar_sayisi < g->e_sayisi) {
        hata("kenar sayısı eksik: %d bekleniyordu, %d okundu", g->e_sayisi,
             g->kenar_sayisi);
        sonuc = 1;
    }
    if (sonuc != 0) {
        graf_yok_et(g);
        return 1;
    }
    komsulari_sirala(g);
    return 0;
}
/* -------------------------------------------------------------------------- */

typedef struct {                /* Örnek 10'un "rütbe + sıkıştırma" sürümü */
    int *ebeveyn, *rutbe;
    int n;
} BirlesimBul;

/* Sahiplik: diziler bb_yok_et ile serbest bırakılır. false: bellek */
static bool bb_kur(BirlesimBul *b, int n)
{
    b->ebeveyn = malloc((size_t)n * sizeof *b->ebeveyn);
    b->rutbe = calloc((size_t)n, sizeof *b->rutbe);
    if (b->ebeveyn == NULL || b->rutbe == NULL) {
        free(b->ebeveyn);
        free(b->rutbe);
        return false;
    }
    for (int x = 0; x < n; x++) {
        b->ebeveyn[x] = x;
    }
    b->n = n;
    return true;
}

static void bb_yok_et(BirlesimBul *b)
{
    free(b->ebeveyn);
    free(b->rutbe);
}

static int bul(BirlesimBul *b, int x)
{
    bul_sayisi++;
    int kok = x;
    while (b->ebeveyn[kok] != kok) {
        kok = b->ebeveyn[kok];
        izleme_sayisi++;
    }
    while (b->ebeveyn[x] != kok) {       /* yol sıkıştırma */
        int sonraki = b->ebeveyn[x];
        b->ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

/* İki farklı kökü rütbeye göre bağlar */
static void birlestir_kok(BirlesimBul *b, int kx, int ky)
{
    birlestir_sayisi++;
    if (b->rutbe[kx] < b->rutbe[ky]) {
        int g = kx;
        kx = ky;
        ky = g;
    }
    b->ebeveyn[ky] = kx;
    if (b->rutbe[kx] == b->rutbe[ky]) {
        b->rutbe[kx]++;
    }
}

/* Kesim denetimi için: sayaçsız, sıkıştırmasız kök */
static int kok_sayacsiz(const BirlesimBul *b, int x)
{
    while (b->ebeveyn[x] != x) {
        x = b->ebeveyn[x];
    }
    return x;
}

/* Birleştirmeden ÖNCE: S = ku kökünün kümesi (s[] üyelik); S ile V - S
 * arasındaki en hafif kenarın ağırlığını döndürür. */
static int kesim(const Graf *g, const BirlesimBul *b, int ku, bool *s)
{
    for (int x = 0; x < g->v_sayisi; x++) {
        s[x] = kok_sayacsiz(b, x) == ku;
    }
    int en_hafif = -1;
    for (int i = 0; i < g->kenar_sayisi; i++) {
        const Kenar *k = &g->kenar[i];
        if (s[k->u] != s[k->v] && (en_hafif < 0 || k->w < en_hafif)) {
            en_hafif = k->w;
        }
    }
    return en_hafif;
}

static int kenar_karsilastir(const void *p, const void *q)  /* (w, u, v) */
{
    const Kenar *x = p, *y = q;
    if (x->w != y->w) {
        return x->w < y->w ? -1 : 1;
    }
    if (x->u != y->u) {
        return x->u < y->u ? -1 : 1;
    }
    return (x->v > y->v) - (x->v < y->v);
}

/* Kenarları (w, u, v) sırasıyla dolaş; uçlar farklı ağaçtaysa al. Ağaç
 * kenarları agac[]'a, sayısı *k'ya; toplam ağırlık (bellek hatasında -1). */
static long long kruskal(const Graf *g, Kenar *agac, int *k, bool yaz)
{
    int m = g->kenar_sayisi, n = g->v_sayisi;
    Kenar *sira = malloc((size_t)(m > 0 ? m : 1) * sizeof *sira);
    bool *s = malloc((size_t)n * sizeof *s);
    BirlesimBul b;
    if (sira == NULL || s == NULL || !bb_kur(&b, n)) {
        free(sira);
        free(s);
        return -1;
    }
    for (int i = 0; i < m; i++) {
        int u = g->kenar[i].u, v = g->kenar[i].v;
        sira[i] = (Kenar){u < v ? u : v, u < v ? v : u, g->kenar[i].w};
    }
    qsort(sira, (size_t)m, sizeof *sira, kenar_karsilastir);
    long long toplam = 0;
    *k = 0;
    for (int i = 0; i < m; i++) {
        int u = sira[i].u, v = sira[i].v, w = sira[i].w;
        int ku = bul(&b, u), kv = bul(&b, v);
        if (ku == kv) {
            if (yaz) {
                printf("  %2d  (%3d, %d, %d)  %d %d     RET    döngü: %d ile "
                       "%d zaten aynı ağaçta\n", i + 1, w, u, v, ku, kv, u, v);
            }
            continue;
        }
        int en_hafif = 0;
        if (yaz) {
            en_hafif = kesim(g, &b, ku, s);
        }
        birlestir_kok(&b, ku, kv);       /* iki ağaç birleşir */
        agac[(*k)++] = sira[i];
        toplam += w;
        if (yaz) {
            printf("  %2d  (%3d, %d, %d)  %d %d     KABUL  ebeveyn:", i + 1, w,
                   u, v, ku, kv);
            for (int x = 0; x < n; x++) {
                printf(" %d", b.ebeveyn[x]);
            }
            printf("\n      kesim S = {");
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (s[x]) {
                    printf(ilk ? "%d" : ", %d", x);
                    ilk = false;
                }
            }
            printf("}: S'den çıkan en hafif kenar %d %s\n", en_hafif,
                   en_hafif == w ? "= w (kesim özelliği)" : "!= w (HATA)");
            if (*k == n - 1) {
                printf("      (ağaç tamam: V - 1 = %d kenar; erken durdurma "
                       "kalanları incelemezdi)\n", n - 1);
            }
        }
    }
    bb_yok_et(&b);
    free(sira);
    free(s);
    return toplam;
}

/* Bütün V - 1 kenarlı alt kümeler (maske); kapsayan ağaç olanların
 * sayısı ve en küçük toplamı */
static void kaba_kuvvet(const Graf *g, long long *incelenen, long long *sayi,
                        long long *en_kucuk)
{
    int n = g->v_sayisi, m = g->kenar_sayisi;
    int *ebeveyn = malloc((size_t)n * sizeof *ebeveyn);
    *incelenen = *sayi = 0;
    *en_kucuk = -1;
    if (ebeveyn == NULL) {
        return;
    }
    for (unsigned long maske = 0; maske < (1ul << m); maske++) {
        int k = 0;
        for (unsigned long x = maske; x != 0; x >>= 1) {
            k += (int)(x & 1ul);
        }
        if (k != n - 1) {
            continue;
        }
        (*incelenen)++;
        for (int x = 0; x < n; x++) {
            ebeveyn[x] = x;
        }
        bool dongu = false;
        long long toplam = 0;
        for (int i = 0; i < m && !dongu; i++) {
            if (maske >> i & 1ul) {
                int u = g->kenar[i].u, v = g->kenar[i].v;
                while (ebeveyn[u] != u) {
                    u = ebeveyn[u];
                }
                while (ebeveyn[v] != v) {
                    v = ebeveyn[v];
                }
                if (u == v) {
                    dongu = true;
                } else {
                    ebeveyn[u] = v;
                    toplam += g->kenar[i].w;
                }
            }
        }
        if (!dongu) {
            (*sayi)++;
            if (*en_kucuk < 0 || toplam < *en_kucuk) {
                *en_kucuk = toplam;
            }
        }
    }
    free(ebeveyn);
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Kullanım: H12_11_kruskal GRAF_DOSYASI\n");
        return 2;
    }
    Graf g;
    if (graf_oku(argv[1], &g) != 0) {
        return 1;
    }
    if (g.yonlu) {
        hata("en küçük kapsayan ağaç yönsüz graf ister");
        graf_yok_et(&g);
        return 1;
    }
    printf("1) Graf: %d köşe, %d kenar, yönsüz\n", g.v_sayisi, g.e_sayisi);
    printf("\n2) Kruskal: kenarlar (w, u, v) sırasıyla; birleşim–bul: rütbe + "
           "yol sıkıştırma\n");
    printf("  adım (w, u, v)     kökler  karar  birleşim–bul ormanı\n");
    Kenar *agac = malloc((size_t)g.v_sayisi * sizeof *agac);
    int k = 0;
    long long toplam = agac == NULL ? -1 : kruskal(&g, agac, &k, true);
    if (toplam < 0) {
        free(agac);
        graf_yok_et(&g);
        fprintf(stderr, "Hata: bellek yetersiz\n");
        return 1;
    }
    printf("  ağaç kenarları: ");
    for (int i = 0; i < k; i++) {
        printf(i > 0 ? ", %d-%d (%d)" : "%d-%d (%d)", agac[i].u, agac[i].v,
               agac[i].w);
    }
    printf("\n  toplam ağırlık = %lld; kabul %d, ret %d; bul = %lld, "
           "birleştir = %lld, işaretçi izleme = %lld\n", toplam, k,
           g.kenar_sayisi - k, bul_sayisi, birlestir_sayisi, izleme_sayisi);
    if (k < g.v_sayisi - 1) {
        printf("  graf bağlı değil: %d ağaçlı orman\n", g.v_sayisi - k);
    }
    if (g.kenar_sayisi <= 20) {
        long long incelenen, sayi, en_kucuk;
        printf("\n3) Kâhin: kaba kuvvet (bütün V - 1 kenarlı alt kümeler)\n");
        kaba_kuvvet(&g, &incelenen, &sayi, &en_kucuk);
        printf("  %lld alt küme, %lld tanesi kapsayan ağaç; en küçük toplam "
               "%lld -> Kruskal %s\n", incelenen, sayi, en_kucuk,
               en_kucuk == toplam ? "en iyi" : "FARKLI");
    }
    free(agac);
    graf_yok_et(&g);
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (Boost Graph Library
 * kruskal_minimum_spanning_tree, networkx minimum_spanning_tree —
 * standart dışı; yalnız kâhin). */

/* H12_06_huffman_kodlama.c — AP-2 Hafta 12 · Örnek 6 (★★★)
 * Amaç    : Huffman ile metin kodlama/çözme: bit tamponu (uint8_t), bayt
 *           hizalama ve dolgu bitleri, kodlanmış bayt sayısı, sıkıştırma
 *           oranı, entropiyle karşılaştırma; çözülen metin = özgün metin
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_06_huffman_kodlama.c -o H12_06_huffman_kodlama -lm
 * Çalıştır: ./H12_06_huffman_kodlama < ../girdiler/H12_06_huffman_kodlama.txt
 * Eşleri  : cpp/H12_06_huffman_kodlama.cpp · python/H12_06_huffman_kodlama.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : ağaç Örnek 5'teki gibi kurulur. Kodlanmış bayt sayısına ağaç
 *           (ya da kod uzunlukları tablosu) DAHİL DEĞİLDİR; bir dosya
 *           biçimi onu da saklamalıdır (2. bölümün son satırı).
 */
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAKS_DUGUM 511

typedef struct {
    int sembol[MAKS_DUGUM];        /* -1: iç düğüm */
    long long siklik[MAKS_DUGUM];
    int sol[MAKS_DUGUM], sag[MAKS_DUGUM];
    int n, kok;
} Agac;

/* --- (sıklık, düğüm) en küçük öbeği: H7 öbeğinin genelleştirilmesi --- */
typedef struct {
    long long siklik;
    int dugum;
} Oge;

typedef struct {
    Oge a[MAKS_DUGUM];
    int n;
} Obek;

static int ebeveyn(int i) { return (i - 1) / 2; }

static bool kucuk_mu(Oge x, Oge y)
{
    return x.siklik < y.siklik || (x.siklik == y.siklik && x.dugum < y.dugum);
}

static void takas(Oge *x, Oge *y)
{
    Oge g = *x;
    *x = *y;
    *y = g;
}

static void obege_ekle(Obek *o, Oge x)
{
    int i = o->n++;
    o->a[i] = x;
    while (i > 0 && kucuk_mu(o->a[i], o->a[ebeveyn(i)])) {
        takas(&o->a[i], &o->a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
}

static Oge en_kucugu_cikar(Obek *o)
{
    Oge en_kucuk = o->a[0];
    o->a[0] = o->a[--o->n];
    int i = 0;
    while (2 * i + 1 < o->n) {
        int c = 2 * i + 1;
        if (c + 1 < o->n && kucuk_mu(o->a[c + 1], o->a[c])) {
            c++;
        }
        if (!kucuk_mu(o->a[c], o->a[i])) {
            break;
        }
        takas(&o->a[i], &o->a[c]);
        i = c;
    }
    return en_kucuk;
}
/* ------------------------------------------------------------------- */

static int dugum_ekle(Agac *t, int sembol, long long siklik, int sol, int sag)
{
    t->sembol[t->n] = sembol;
    t->siklik[t->n] = siklik;
    t->sol[t->n] = sol;
    t->sag[t->n] = sag;
    return t->n++;
}

/* siklik[0..255] → Huffman ağacı; öbek öğesi (sıklık, düğüm no) */
static void agac_kur(const long long *siklik, Agac *t)
{
    static Obek obek;
    obek.n = 0;
    t->n = 0;
    t->kok = -1;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            int d = dugum_ekle(t, b, siklik[b], -1, -1);
            obege_ekle(&obek, (Oge){siklik[b], d});
        }
    }
    while (obek.n > 1) {
        Oge x = en_kucugu_cikar(&obek);
        Oge y = en_kucugu_cikar(&obek);
        int z = dugum_ekle(t, -1, x.siklik + y.siklik, x.dugum, y.dugum);
        obege_ekle(&obek, (Oge){x.siklik + y.siklik, z});
    }
    if (obek.n > 0) {
        t->kok = en_kucugu_cikar(&obek).dugum;
    }
}

static void kod_ata(const Agac *t, int d, char *kod, int derinlik,
                    char kodlar[256][MAKS_DUGUM])
{
    if (t->sembol[d] >= 0) {
        if (derinlik == 0) {
            strcpy(kodlar[t->sembol[d]], "0");    /* tek düğüm: "0" */
        } else {
            memcpy(kodlar[t->sembol[d]], kod, (size_t)derinlik);
            kodlar[t->sembol[d]][derinlik] = '\0';
        }
        return;
    }
    kod[derinlik] = '0';
    kod_ata(t, t->sol[d], kod, derinlik + 1, kodlar);
    kod[derinlik] = '1';
    kod_ata(t, t->sag[d], kod, derinlik + 1, kodlar);
}

/* Bit tamponu: bit i, bayt i >> 3'ün (7 - i & 7). bitine (önce en anlamlı
 * bit) yazılır. Sahiplik: dönen tampon çağıranındır (free). */
static uint8_t *kodla(const uint8_t *metin, size_t n,
                      char kodlar[256][MAKS_DUGUM], size_t *toplam_bit,
                      size_t *bayt)
{
    size_t toplam = 0;
    for (size_t k = 0; k < n; k++) {
        toplam += strlen(kodlar[metin[k]]);
    }
    *toplam_bit = toplam;
    *bayt = (toplam + 7) / 8;
    uint8_t *tampon = calloc(*bayt > 0 ? *bayt : 1, 1);  /* sıfırlarla dolu */
    if (tampon == NULL) {
        return NULL;
    }
    size_t i = 0;
    for (size_t k = 0; k < n; k++) {
        for (const char *c = kodlar[metin[k]]; *c != '\0'; c++) {
            if (*c == '1') {
                tampon[i >> 3] |= (uint8_t)(0x80u >> (i & 7));
            }
            i++;
        }
    }
    return tampon;
}

/* Kökten başla; 0 sola, 1 sağa; yaprakta simgeyi yaz, köke dön.
 * cikti en az toplam_bit bayt olmalı; çözülen bayt sayısını döndürür. */
static size_t coz(const Agac *t, const uint8_t *tampon, size_t toplam_bit,
                  uint8_t *cikti)
{
    size_t cozulen = 0;
    int d = t->kok;
    for (size_t i = 0; i < toplam_bit; i++) {
        if (t->sembol[t->kok] >= 0) {    /* tek düğüm: her bit bir simge */
            cikti[cozulen++] = (uint8_t)t->sembol[t->kok];
            continue;
        }
        int bit = tampon[i >> 3] >> (7 - (i & 7)) & 1;
        d = bit ? t->sag[d] : t->sol[d];
        if (t->sembol[d] >= 0) {
            cikti[cozulen++] = (uint8_t)t->sembol[d];
            d = t->kok;
        }
    }
    return cozulen;
}

static uint32_t fnv1a(const uint8_t *veri, size_t n)
{
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < n; i++) {
        h = (h ^ veri[i]) * 16777619u;
    }
    return h;
}

static const char *sembol_yaz(int b, char *tampon)   /* tampon >= 16 bayt */
{
    if (b == 32) {
        return "␣";
    }
    if (b >= 33 && b <= 126) {
        tampon[0] = (char)b;
        tampon[1] = '\0';
    } else {
        snprintf(tampon, 16, "\\x%02X", (unsigned)b & 0xFFu);
    }
    return tampon;
}

/* pay/payda'yı 'basamak' ondalıkla yuvarlayıp yazar (tamsayı aritmetiği) */
static void ondalik_yaz(long long pay, long long payda, int basamak)
{
    long long olcek = 1;
    for (int i = 0; i < basamak; i++) {
        olcek *= 10;
    }
    long long x = (pay * olcek * 2 + payda) / (2 * payda);
    printf("%lld.%0*lld", x / olcek, basamak, x % olcek);
}

static void siklik_say(const uint8_t *metin, size_t n, long long *siklik)
{
    for (int b = 0; b < 256; b++) {
        siklik[b] = 0;
    }
    for (size_t i = 0; i < n; i++) {
        siklik[metin[i]]++;
    }
}

static Agac agac;                       /* büyük diziler: statik bellek */
static char kodlar[256][MAKS_DUGUM];

static void kodlari_hazirla(const uint8_t *metin, size_t n, long long *siklik)
{
    char kod[MAKS_DUGUM];
    siklik_say(metin, n, siklik);
    agac_kur(siklik, &agac);
    for (int b = 0; b < 256; b++) {
        kodlar[b][0] = '\0';
    }
    kod_ata(&agac, agac.kok, kod, 0, kodlar);
}

static int kucuk_ornek(const char *metin_s)
{
    const uint8_t *metin = (const uint8_t *)metin_s;
    size_t n = strlen(metin_s), toplam, bayt;
    long long siklik[256];
    char tm[16];
    printf("1) Küçük örnek: \"%s\" (%zu bayt)\n", metin_s, n);
    kodlari_hazirla(metin, n, siklik);
    uint8_t *tampon = kodla(metin, n, kodlar, &toplam, &bayt);
    uint8_t *cozulen = malloc(toplam + 1);
    if (tampon == NULL || cozulen == NULL) {
        free(tampon);
        free(cozulen);
        return 1;
    }
    printf("  simge kodları (Örnek 5):");
    for (int b = 0; b < 256; b++) {
        if (kodlar[b][0] != '\0') {
            printf(" %s=%s", sembol_yaz(b, tm), kodlar[b]);
        }
    }
    printf("\n  bitler (bayt bayt; x = dolgu): ");
    for (size_t i = 0; i < bayt * 8; i++) {
        if (i > 0 && i % 8 == 0) {
            printf(" ");
        }
        if (i < toplam) {
            printf("%d", tampon[i >> 3] >> (7 - (i & 7)) & 1);
        } else {
            printf("x");
        }
    }
    printf("\n  %zu bit -> %zu bayt (dolgu %zu bit):", toplam, bayt,
           bayt * 8 - toplam);
    for (size_t i = 0; i < bayt; i++) {
        printf(" %02X", tampon[i]);
    }
    size_t c = coz(&agac, tampon, toplam, cozulen);
    bool ayni = c == n && memcmp(cozulen, metin, n) == 0;
    printf("\n  çözülen: \"%.*s\" (aynı mı? %s)\n", (int)c,
           (const char *)cozulen, ayni ? "evet" : "HAYIR");
    free(tampon);
    free(cozulen);
    return 0;
}

typedef struct {
    long long siklik;
    int sembol;
} Sayim;

static int sayima_gore(const void *p, const void *q)  /* sıklık azalan */
{
    const Sayim *x = p, *y = q;
    if (x->siklik != y->siklik) {
        return x->siklik > y->siklik ? -1 : 1;
    }
    return (x->sembol > y->sembol) - (x->sembol < y->sembol);
}

static int buyuk_ornek(const uint8_t *metin, size_t n)
{
    long long siklik[256];
    char tm[16];
    kodlari_hazirla(metin, n, siklik);
    int farkli = 0;
    size_t en_uzun = 0;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            farkli++;
            if (strlen(kodlar[b]) > en_uzun) {
                en_uzun = strlen(kodlar[b]);
            }
        }
    }
    printf("\n2) Ömer Seyfettin metni (standart girdi): %zu bayt, %d farklı "
           "bayt değeri\n", n, farkli);
    int dagilim[MAKS_DUGUM] = {0};
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            dagilim[strlen(kodlar[b])]++;
        }
    }
    printf("  kod uzunluğu -> simge sayısı:");
    bool ilk = true;
    for (size_t u = 1; u <= en_uzun; u++) {
        if (dagilim[u] > 0) {
            printf(ilk ? " %zu:%d" : ", %zu:%d", u, dagilim[u]);
            ilk = false;
        }
    }
    Sayim sira[256];
    int k = 0;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            sira[k++] = (Sayim){siklik[b], b};
        }
    }
    qsort(sira, (size_t)k, sizeof sira[0], sayima_gore);
    printf("\n  en sık 6 simge:");
    for (int i = 0; i < k && i < 6; i++) {
        printf(i > 0 ? ", %s %lld (%s)" : " %s %lld (%s)",
               sembol_yaz(sira[i].sembol, tm), sira[i].siklik,
               kodlar[sira[i].sembol]);
    }
    size_t toplam, bayt;
    uint8_t *tampon = kodla(metin, n, kodlar, &toplam, &bayt);
    uint8_t *cozulen = malloc(toplam + 1);
    if (tampon == NULL || cozulen == NULL) {
        free(tampon);
        free(cozulen);
        return 1;
    }
    printf("\n  toplam %zu bit -> %zu bayt (dolgu %zu bit)\n", toplam, bayt,
           bayt * 8 - toplam);
    printf("  ortalama kod uzunluğu = ");
    ondalik_yaz((long long)toplam, (long long)n, 4);
    printf(" bit/simge (sabit 8 bit yerine)\n");
    double entropi = 0.0;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            entropi += (double)siklik[b] / (double)n *
                       log2((double)n / (double)siklik[b]);
        }
    }
    printf("  entropi (bayt düzeyi, sıfırıncı derece) = %.4f bit/simge: alt "
           "sınır\n", entropi);
    printf("  sıkıştırma oranı = %zu / %zu = %%", bayt, n);
    ondalik_yaz((long long)bayt * 100, (long long)n, 2);
    printf("\n  kodlanmış akışın FNV-1a özeti = 0x%08x; ilk 8 bayt:",
           (unsigned)fnv1a(tampon, bayt));
    for (size_t i = 0; i < bayt && i < 8; i++) {
        printf(" %02X", tampon[i]);
    }
    size_t c = coz(&agac, tampon, toplam, cozulen);
    bool ayni = c == n && memcmp(cozulen, metin, n) == 0;
    printf("\n  çözülen metin özgün metinle aynı mı? %s (%zu bayt)\n",
           ayni ? "evet" : "HAYIR", c);
    size_t dosya = bayt + 256 + 4;
    printf("  ağaç bu sayıya dahil değil: 256 baytlık kod uzunluğu tablosu "
           "+ 4 bayt simge sayısıyla %zu bayt (%%", dosya);
    ondalik_yaz((long long)dosya * 100, (long long)n, 2);
    printf(")\n");
    free(tampon);
    free(cozulen);
    return 0;
}

static int tek_simge(const char *metin_s)
{
    const uint8_t *metin = (const uint8_t *)metin_s;
    size_t n = strlen(metin_s), toplam, bayt;
    long long siklik[256];
    kodlari_hazirla(metin, n, siklik);
    uint8_t *tampon = kodla(metin, n, kodlar, &toplam, &bayt);
    uint8_t *cozulen = malloc(toplam + 1);
    if (tampon == NULL || cozulen == NULL) {
        free(tampon);
        free(cozulen);
        return 1;
    }
    size_t c = coz(&agac, tampon, toplam, cozulen);
    bool ayni = c == n && memcmp(cozulen, metin, n) == 0;
    printf("\n3) Tek simgeli metin \"%s\": kod \"%s\" -> %zu bit, %zu bayt; "
           "çözülen aynı mı? %s\n", metin_s, kodlar[metin[0]], toplam, bayt,
           ayni ? "evet" : "HAYIR");
    free(tampon);
    free(cozulen);
    return 0;
}

/* Standart girdinin tamamı. Sahiplik: dönen blok çağıranındır (free). */
static uint8_t *hepsini_oku(FILE *f, size_t *n)
{
    size_t kapasite = 4096;
    *n = 0;
    uint8_t *veri = malloc(kapasite);
    if (veri == NULL) {
        return NULL;
    }
    size_t okunan;
    while ((okunan = fread(veri + *n, 1, kapasite - *n, f)) > 0) {
        *n += okunan;
        if (*n == kapasite) {
            uint8_t *gecici = realloc(veri, 2 * kapasite);
            if (gecici == NULL) {
                free(veri);
                return NULL;
            }
            veri = gecici;
            kapasite *= 2;
        }
    }
    return veri;
}

int main(void)
{
    size_t n;
    uint8_t *metin = hepsini_oku(stdin, &n);
    if (metin == NULL) {
        fprintf(stderr, "Hata: bellek yetersiz\n");
        return 1;
    }
    int hata = kucuk_ornek("ey edip adanada pide ye");
    if (n == 0) {
        printf("\n2) Standart girdi boş: büyük örnek atlandı\n");
    } else {
        hata |= buyuk_ornek(metin, n);
    }
    hata |= tek_simge("aaaaaaa");
    free(metin);
    return hata;
}

/* Kütüphane karşılığı: C — yok (zlib/DEFLATE, standart dışı); C++ — yok;
 * Python — zlib.compress (DEFLATE = LZ77 + Huffman), bit düzeyinde
 * int.to_bytes / int.from_bytes. Ağaç ve kodlama elle yazılır. */

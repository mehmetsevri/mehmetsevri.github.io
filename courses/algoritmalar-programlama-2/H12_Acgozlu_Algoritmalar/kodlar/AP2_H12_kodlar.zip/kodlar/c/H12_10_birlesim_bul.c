/* H12_10_birlesim_bul.c — AP-2 Hafta 12 · Örnek 10 (★★)
 * Amaç    : Birleşim–bul (ayrık kümeler): saf, yalnız rütbe, yalnız yol
 *           sıkıştırma ve ikisi birden; işaretçi izleme sayısı, ağaç
 *           yüksekliği; küçük örnekte orman, zincirde en kötü durum,
 *           rastgele işlemlerde işlem başına izleme
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_10_birlesim_bul.c \
 *           ortak_rastgele.c -o H12_10_birlesim_bul
 * Çalıştır: ./H12_10_birlesim_bul
 * Eşleri  : cpp/H12_10_birlesim_bul.cpp · python/H12_10_birlesim_bul.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : saf birleştirmede birincinin kökü ikincinin köküne bağlanır;
 *           rütbede küçük rütbeli kök büyüğün altına girer (eşitse ikinci
 *           birinciye, birincinin rütbesi artar). Yol sıkıştırma iki
 *           geçişli ve yinelemelidir (özyineleme yok).
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static const char *const SURUM_ADI[4] = {"saf", "yalnız rütbe",
                                         "yalnız sıkıştırma",
                                         "rütbe + sıkıştırma"};

static long long izleme_sayisi = 0;   /* ebeveyn[] üzerinden işaretçi izleme */
static long long baglama_sayisi = 0;  /* sıkıştırmada yeniden bağlanan */

typedef struct {
    int *ebeveyn;
    int *rutbe;
    int n;
    bool rutbeli, sikistir;
} BirlesimBul;

/* Sahiplik: diziler bb_yok_et ile serbest bırakılır. false: bellek */
static bool bb_kur(BirlesimBul *b, int n, int surum)
{
    b->ebeveyn = malloc((size_t)n * sizeof *b->ebeveyn);
    b->rutbe = calloc((size_t)n, sizeof *b->rutbe);
    if (b->ebeveyn == NULL || b->rutbe == NULL) {
        free(b->ebeveyn);
        free(b->rutbe);
        return false;
    }
    for (int x = 0; x < n; x++) {
        b->ebeveyn[x] = x;               /* her eleman kendi kümesinin kökü */
    }
    b->n = n;
    b->rutbeli = surum == 1 || surum == 3;
    b->sikistir = surum == 2 || surum == 3;
    return true;
}

static void bb_yok_et(BirlesimBul *b)
{
    free(b->ebeveyn);
    free(b->rutbe);
}

/* x'in kökü; sıkıştırmada yol üzerindeki düğümler köke bağlanır */
static int bul(BirlesimBul *b, int x)
{
    int kok = x;
    while (b->ebeveyn[kok] != kok) {     /* 1. geçiş: kökü bul */
        kok = b->ebeveyn[kok];
        izleme_sayisi++;
    }
    if (b->sikistir) {
        while (b->ebeveyn[x] != kok) {   /* 2. geçiş: yolu köke bağla */
            int sonraki = b->ebeveyn[x];
            b->ebeveyn[x] = kok;
            baglama_sayisi++;
            x = sonraki;
        }
    }
    return kok;
}

/* İki kümeyi birleştirir; zaten aynıysa false */
static bool birlestir(BirlesimBul *b, int x, int y)
{
    int kx = bul(b, x), ky = bul(b, y);
    if (kx == ky) {
        return false;
    }
    if (!b->rutbeli) {
        b->ebeveyn[kx] = ky;             /* saf: birincinin kökü ikinciye */
        return true;
    }
    if (b->rutbe[kx] < b->rutbe[ky]) {
        int g = kx;                      /* kx: rütbesi büyük olan */
        kx = ky;
        ky = g;
    }
    b->ebeveyn[ky] = kx;
    if (b->rutbe[kx] == b->rutbe[ky]) {
        b->rutbe[kx]++;
    }
    return true;
}

/* Ormanın yüksekliği (en derin düğümün köke uzaklığı); sayaçlara girmez.
 * Derinlikler yolun yukarısından aşağı doğru doldurulur: Θ(n). */
static int yukseklik(const BirlesimBul *b)
{
    int n = b->n;
    int *derinlik = malloc((size_t)n * sizeof *derinlik);
    int *yigin = malloc((size_t)n * sizeof *yigin);
    if (derinlik == NULL || yigin == NULL) {
        free(derinlik);
        free(yigin);
        return -1;
    }
    for (int x = 0; x < n; x++) {
        derinlik[x] = -1;
    }
    int en_cok = 0;
    for (int x = 0; x < n; x++) {
        int v = x, tepe = 0;
        while (derinlik[v] < 0 && b->ebeveyn[v] != v) {
            yigin[tepe++] = v;
            v = b->ebeveyn[v];
        }
        if (derinlik[v] < 0) {
            derinlik[v] = 0;             /* kök */
        }
        while (tepe > 0) {
            int u = yigin[--tepe];
            derinlik[u] = derinlik[b->ebeveyn[u]] + 1;
        }
        if (derinlik[x] > en_cok) {
            en_cok = derinlik[x];
        }
    }
    free(derinlik);
    free(yigin);
    return en_cok;
}

static int kume_sayisi(const BirlesimBul *b)
{
    int k = 0;
    for (int x = 0; x < b->n; x++) {
        k += b->ebeveyn[x] == x;
    }
    return k;
}

/* Görünür karakter sayısına göre doldurur (UTF-8 devam baytları sayılmaz) */
static void sola_yasla(const char *s, int genislik)
{
    int g = 0;
    for (const char *p = s; *p != '\0'; p++) {
        g += ((unsigned char)*p & 0xC0) != 0x80;
    }
    printf("%s%*s", s, genislik - g, "");
}

static void dizi_yaz(const int *a, int n)
{
    for (int i = 0; i < n; i++) {
        printf(i > 0 ? " %2d" : "%2d", a[i]);
    }
}

static int kucuk_ornek(void)
{
    const int islemler[8][2] = {{0, 1}, {2, 3}, {0, 2}, {4, 5}, {6, 7},
                                {4, 6}, {1, 5}, {3, 7}};
    const int indis[8] = {0, 1, 2, 3, 4, 5, 6, 7};
    printf("1) Küçük örnek: n = 8; birleştir");
    for (int i = 0; i < 8; i++) {
        printf(" (%d,%d)", islemler[i][0], islemler[i][1]);
    }
    printf("; sonra bul(0)\n  indis     : ");
    dizi_yaz(indis, 8);
    printf("\n");
    for (int surum = 0; surum < 4; surum++) {
        BirlesimBul b;
        int once[8];
        char sonuc[9];
        if (!bb_kur(&b, 8, surum)) {
            return 1;
        }
        izleme_sayisi = baglama_sayisi = 0;
        for (int i = 0; i < 8; i++) {
            sonuc[i] = birlestir(&b, islemler[i][0], islemler[i][1]) ? '+'
                                                                    : '=';
        }
        sonuc[8] = '\0';
        for (int x = 0; x < 8; x++) {
            once[x] = b.ebeveyn[x];
        }
        int h_once = yukseklik(&b);
        int k = bul(&b, 0);
        printf("  %s (%s; = : zaten aynı küme)\n", SURUM_ADI[surum], sonuc);
        printf("    ebeveyn : ");
        dizi_yaz(once, 8);
        printf("   yükseklik %d\n", h_once);
        printf("    bul(0) = %d; sonra ebeveyn: ", k);
        dizi_yaz(b.ebeveyn, 8);
        printf("   yükseklik %d\n", yukseklik(&b));
        printf("    işaretçi izleme = %lld, yeniden bağlama = %lld\n",
               izleme_sayisi, baglama_sayisi);
        if (b.rutbeli) {
            printf("    rütbe   : ");
            dizi_yaz(b.rutbe, 8);
            printf("\n");
        }
        bb_yok_et(&b);
    }
    return 0;
}

/* En kötü durum: birleştir(i, i+1) sırası saf sürümde zincir kurar;
 * ardından her elemanda bul */
static int zincir(int n)
{
    printf("\n2) Zincir: n = %d; birleştir(i, i + 1), i = 0..n-2; sonra "
           "bul(0), bul(1), …, bul(n-1)\n", n);
    printf("  sürüm                yükseklik  birleştirme izl.  bul izl.  "
           "bul başına\n");
    for (int surum = 0; surum < 4; surum++) {
        BirlesimBul b;
        if (!bb_kur(&b, n, surum)) {
            return 1;
        }
        izleme_sayisi = baglama_sayisi = 0;
        for (int i = 0; i < n - 1; i++) {
            birlestir(&b, i, i + 1);
        }
        int h = yukseklik(&b);
        long long birlestirme = izleme_sayisi;
        izleme_sayisi = 0;
        for (int i = 0; i < n; i++) {
            bul(&b, i);
        }
        long long bas = izleme_sayisi * 1000 / n;
        printf("  ");
        sola_yasla(SURUM_ADI[surum], 19);
        printf("  %9d  %16lld  %8lld  %6lld.%03lld\n", h, birlestirme,
               izleme_sayisi, bas / 1000, bas % 1000);
        bb_yok_et(&b);
    }
    printf("  saf: bul izleme toplamı = n(n-1)/2 = %lld\n",
           (long long)n * (n - 1) / 2);
    return 0;
}

/* n rastgele birleştirme + n rastgele bul (tohum 42, her sürüme aynı
 * işlem dizisi) */
static int rastgele(int n)
{
    printf("  n = %6d:\n", n);
    for (int surum = 0; surum < 4; surum++) {
        BirlesimBul b;
        if (!bb_kur(&b, n, surum)) {
            return 1;
        }
        izleme_sayisi = baglama_sayisi = 0;
        rastgele_tohum(42);
        for (int i = 0; i < n; i++) {
            int x = rastgele_aralik(0, n - 1);
            int y = rastgele_aralik(0, n - 1);
            birlestir(&b, x, y);
        }
        for (int i = 0; i < n; i++) {
            bul(&b, rastgele_aralik(0, n - 1));
        }
        long long islem = 3LL * n;       /* birleştirmede 2 bul + n bul */
        long long bas = izleme_sayisi * 1000 / islem;
        printf("    ");
        sola_yasla(SURUM_ADI[surum], 19);
        printf("  küme %6d  yükseklik %4d  izleme %9lld  bul başına "
               "%lld.%03lld\n", kume_sayisi(&b), yukseklik(&b), izleme_sayisi,
               bas / 1000, bas % 1000);
        bb_yok_et(&b);
    }
    return 0;
}

int main(void)
{
    int hata = kucuk_ornek();
    hata |= zincir(1000);
    printf("\n3) Rastgele işlemler: n birleştirme + n bul (3n bul "
           "çağrısı)\n");
    const int boyutlar[4] = {1000, 2000, 4000, 8000};
    for (int i = 0; i < 4; i++) {
        hata |= rastgele(boyutlar[i]);
    }
    return hata;
}

/* Kütüphane karşılığı: C, C++, Python — yok (standart kütüphanelerde
 * ayrık küme yapısı yok; Boost disjoint_sets ve networkx.utils.UnionFind
 * standart dışıdır). */

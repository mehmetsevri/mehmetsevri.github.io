/* H12_01_para_ustu.c — AP-2 Hafta 12 · Örnek 1 (★)
 * Amaç    : Açgözlü para üstü (AP-1 H4'e dönüş): her adımda en büyük madeni
 *           parayı al; kanonik sistemlerde en iyi, {1, 3, 4} sisteminde 6
 *           için yanlış — kaba kuvvetle (tüm kombinasyonlar) gösterilir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_01_para_ustu.c \
 *           -o H12_01_para_ustu
 * Çalıştır: ./H12_01_para_ustu
 * Eşleri  : cpp/H12_01_para_ustu.cpp · python/H12_01_para_ustu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>

#define UST_TUTAR 100      /* kaba kuvvet denetiminin üst sınırı */
#define MAKS_PARA 8

static long long kombinasyon_sayisi = 0;  /* incelenen geçerli kombinasyon */

/* Sistemi artan sırayla yazar: {1, 3, 4} */
static void sistem_yaz(const int *para, int k)
{
    printf("{");
    for (int i = k - 1; i >= 0; i--) {
        printf(i < k - 1 ? ", %d" : "%d", para[i]);
    }
    printf("}");
}

/* para[] azalan sıralı; her adımda sığan en büyük parayı alır.
 * Parça sayısını döndürür; ödenemezse -1. */
static int acgozlu(const int *para, int k, int tutar, int *adet)
{
    int parca = 0;
    for (int i = 0; i < k; i++) {
        adet[i] = tutar / para[i];       /* yerel en iyi seçim */
        tutar -= adet[i] * para[i];
        parca += adet[i];
    }
    return tutar == 0 ? parca : -1;
}

/* Bütün kombinasyonlar: i. paradan 0..kalan/para[i] adet. En az
 * parçalı kombinasyon *en_iyi ve en_iyi_adet'e yazılır. */
static void kaba_kuvvet(const int *para, int k, int i, int kalan, int *adet,
                        int *en_iyi, int *en_iyi_adet, bool liste)
{
    if (i == k - 1) {                    /* son para kalanı tam bölmeli */
        if (kalan % para[i] != 0) {
            return;
        }
        adet[i] = kalan / para[i];
        kombinasyon_sayisi++;
        int parca = 0;
        for (int j = 0; j < k; j++) {
            parca += adet[j];
        }
        if (liste) {
            printf("    ");
            for (int j = 0; j < k; j++) {
                printf(j > 0 ? " + %dx%d" : "%dx%d", para[j], adet[j]);
            }
            printf(" -> %d\n", parca);
        }
        if (*en_iyi < 0 || parca < *en_iyi) {
            *en_iyi = parca;
            for (int j = 0; j < k; j++) {
                en_iyi_adet[j] = adet[j];
            }
        }
        return;
    }
    for (int a = kalan / para[i]; a >= 0; a--) {
        adet[i] = a;
        kaba_kuvvet(para, k, i + 1, kalan - a * para[i], adet, en_iyi,
                    en_iyi_adet, liste);
    }
}

static int en_az_parca(const int *para, int k, int tutar, int *en_iyi_adet,
                       bool liste)
{
    int adet[MAKS_PARA];
    int en_iyi = -1;
    kaba_kuvvet(para, k, 0, tutar, adet, &en_iyi, en_iyi_adet, liste);
    return en_iyi;
}

static void cozum_yaz(const int *para, int k, int tutar, const int *adet,
                      int parca)
{
    printf("%d = ", tutar);
    bool ilk = true;
    for (int i = 0; i < k; i++) {
        if (adet[i] > 0) {
            printf(ilk ? "%dx%d" : " + %dx%d", para[i], adet[i]);
            ilk = false;
        }
    }
    printf(" -> %d parça\n", parca);
}

/* 1..UST_TUTAR için açgözlü ile kaba kuvveti karşılaştırır */
static void sistemi_dene(const int *para, int k)
{
    int adet[MAKS_PARA], en_iyi_adet[MAKS_PARA];
    int hatali[UST_TUTAR];
    int h = 0;
    kombinasyon_sayisi = 0;
    for (int t = 1; t <= UST_TUTAR; t++) {
        if (acgozlu(para, k, t, adet) !=
            en_az_parca(para, k, t, en_iyi_adet, false)) {
            hatali[h++] = t;
        }
    }
    printf("  ");
    sistem_yaz(para, k);
    printf(": açgözlü %d/%d tutarda en iyi; incelenen kombinasyon = %lld\n",
           UST_TUTAR - h, UST_TUTAR, kombinasyon_sayisi);
    if (h > 0) {
        printf("    en iyi olmadığı tutar sayısı = %d; ilk 8:", h);
        for (int i = 0; i < h && i < 8; i++) {
            printf(" %d", hatali[i]);
        }
        printf("\n");
    }
}

int main(void)
{
    const int ap1[] = {200, 100, 50, 20, 10, 5, 1};  /* AP-1 H4 TL sistemi */
    const int abd[] = {25, 10, 5, 1};
    const int bozuk[] = {4, 3, 1};
    const int yedi[] = {10, 7, 1};
    int adet[MAKS_PARA], en_iyi_adet[MAKS_PARA];

    printf("1) AP-1 H4 sistemi ");
    sistem_yaz(ap1, 7);
    printf(": açgözlü para üstü\n");
    printf("  ");
    cozum_yaz(ap1, 7, 387, adet, acgozlu(ap1, 7, 387, adet));

    printf("\n2) Kaba kuvvetle doğrulama (tüm kombinasyonlar), tutar "
           "1..%d\n", UST_TUTAR);
    sistemi_dene(ap1, 7);
    sistemi_dene(abd, 4);
    sistemi_dene(bozuk, 3);
    sistemi_dene(yedi, 3);

    printf("\n3) Karşı örnek: ");
    sistem_yaz(bozuk, 3);
    printf(" sisteminde 6\n");
    printf("  açgözlü : ");
    cozum_yaz(bozuk, 3, 6, adet, acgozlu(bozuk, 3, 6, adet));
    kombinasyon_sayisi = 0;
    printf("  bütün kombinasyonlar (büyük paradan küçüğe):\n");
    int en_iyi = en_az_parca(bozuk, 3, 6, en_iyi_adet, true);
    printf("  en iyi  : ");
    cozum_yaz(bozuk, 3, 6, en_iyi_adet, en_iyi);
    printf("  (%lld kombinasyon incelendi)\n", kombinasyon_sayisi);
    printf("  Açgözlü ilk adımda 4'ü seçer; kalan 2 yalnız 1 + 1 ile "
           "ödenir.\n  En iyi çözüm 4'ü hiç kullanmaz: açgözlü seçim "
           "özelliği bu sistemde yok.\n");

    printf("\n4) Bir karşı örnek daha: ");
    sistem_yaz(yedi, 3);
    printf(" sisteminde 14\n");
    printf("  açgözlü : ");
    cozum_yaz(yedi, 3, 14, adet, acgozlu(yedi, 3, 14, adet));
    printf("  en iyi  : ");
    cozum_yaz(yedi, 3, 14, en_iyi_adet,
              en_az_parca(yedi, 3, 14, en_iyi_adet, false));
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (açgözlü para üstü bir
 * kütüphane işlevi değildir); en iyi çözüm için genel yöntem dinamik
 * programlamadır (H13). */

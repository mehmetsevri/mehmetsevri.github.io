/* H12_02_aralik_cizelgeleme.c — AP-2 Hafta 12 · Örnek 2 (★★)
 * Amaç    : Aralık çizelgeleme: en erken biten ilk; üç yanlış ölçütün (en
 *           kısa, en erken başlayan, en az çakışan) kaba kuvvetle doğrulanmış
 *           karşı örnekleri; değiş tokuş argümanının rastgele örneklerde
 *           kâhinle (kaba kuvvet) denetimi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_02_aralik_cizelgeleme.c ortak_rastgele.c \
 *           -o H12_02_aralik_cizelgeleme
 * Çalıştır: ./H12_02_aralik_cizelgeleme
 * Eşleri  : cpp/H12_02_aralik_cizelgeleme.cpp ·
 *           python/H12_02_aralik_cizelgeleme.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : aralıklar yarı açık [bas, bit): bit = sonraki bas ise
 *           çakışmaz; eşitlikte (bit, bas, kimlik) sırası
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define DENEME 1000        /* rastgele örnek sayısı */
#define DENEME_N 8         /* rastgele örnekte aralık sayısı */
#define MAKS_N 16

typedef struct {
    int bas, bit, kimlik;
} Aralik;

static bool cakisir(const Aralik *a, const Aralik *b)
{
    return a->bas < b->bit && b->bas < a->bit;
}

static char ad(const Aralik *a)
{
    return (char)('A' + a->kimlik);
}

/* Tam sıralama karşılaştırıcıları (qsort kararsızdır; kimlik son anahtar) */
static int bitise_gore(const void *p, const void *q)
{
    const Aralik *x = p, *y = q;
    if (x->bit != y->bit) {
        return x->bit < y->bit ? -1 : 1;
    }
    if (x->bas != y->bas) {
        return x->bas < y->bas ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

static int uzunluga_gore(const void *p, const void *q)
{
    const Aralik *x = p, *y = q;
    int ux = x->bit - x->bas, uy = y->bit - y->bas;
    if (ux != uy) {
        return ux < uy ? -1 : 1;
    }
    if (x->bas != y->bas) {
        return x->bas < y->bas ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

static int basa_gore(const void *p, const void *q)
{
    const Aralik *x = p, *y = q;
    if (x->bas != y->bas) {
        return x->bas < y->bas ? -1 : 1;
    }
    if (x->bit != y->bit) {
        return x->bit < y->bit ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

/* Zaman şeridi: 0..15, aralık içi '#' (satır sonu çağırana kalır) */
static void serit_yaz(const Aralik *x)
{
    char serit[17];
    for (int t = 0; t < 16; t++) {
        serit[t] = (x->bas <= t && t < x->bit) ? '#' : '.';
    }
    serit[16] = '\0';
    printf("  %c [%2d, %2d)  %s  ", ad(x), x->bas, x->bit, serit);
}

/* Bitişe göre sırala, tek geçiş: başlangıcı son bitişten küçük
 * olmayanı al. Seçilen sayısını döndürür. */
static int en_erken_biten(const Aralik *a, int n, Aralik *secilen, bool yaz)
{
    Aralik sira[MAKS_N];
    for (int i = 0; i < n; i++) {
        sira[i] = a[i];
    }
    qsort(sira, (size_t)n, sizeof sira[0], bitise_gore);
    int k = 0;
    int son_bitis = -1;
    for (int i = 0; i < n; i++) {
        const Aralik *x = &sira[i];
        if (x->bas >= son_bitis) {       /* açgözlü seçim */
            secilen[k++] = *x;
            if (yaz && son_bitis < 0) {
                serit_yaz(x);
                printf("seçildi (ilk aralık)\n");
            } else if (yaz) {
                serit_yaz(x);
                printf("seçildi (bas %d >= son bitiş %d)\n", x->bas,
                       son_bitis);
            }
            son_bitis = x->bit;
        } else if (yaz) {
            serit_yaz(x);
            printf("elendi  (bas %d < son bitiş %d)\n", x->bas, son_bitis);
        }
    }
    return k;
}

/* Verilen sırada dolaş; seçilenlerin hepsiyle uyumluysa al */
static int sirayla_sec(const Aralik *sira, int n, Aralik *secilen)
{
    int k = 0;
    for (int i = 0; i < n; i++) {
        bool uyumlu = true;
        for (int j = 0; j < k; j++) {
            if (cakisir(&sira[i], &secilen[j])) {
                uyumlu = false;
            }
        }
        if (uyumlu) {
            secilen[k++] = sira[i];
        }
    }
    return k;
}

static int en_kisa_ilk(const Aralik *a, int n, Aralik *secilen)
{
    Aralik sira[MAKS_N];
    for (int i = 0; i < n; i++) {
        sira[i] = a[i];
    }
    qsort(sira, (size_t)n, sizeof sira[0], uzunluga_gore);
    return sirayla_sec(sira, n, secilen);
}

static int en_erken_baslayan(const Aralik *a, int n, Aralik *secilen)
{
    Aralik sira[MAKS_N];
    for (int i = 0; i < n; i++) {
        sira[i] = a[i];
    }
    qsort(sira, (size_t)n, sizeof sira[0], basa_gore);
    return sirayla_sec(sira, n, secilen);
}

/* Kalanlar içinde en az çakışanı al, onunla çakışanları at; eşitlikte
 * (çakışma, bas, kimlik) */
static int en_az_cakisan(const Aralik *a, int n, Aralik *secilen, bool yaz)
{
    bool kalan[MAKS_N];
    for (int i = 0; i < n; i++) {
        kalan[i] = true;
    }
    int k = 0;
    for (;;) {
        int en_iyi = -1, en_iyi_c = 0;
        for (int i = 0; i < n; i++) {
            if (!kalan[i]) {
                continue;
            }
            int c = 0;
            for (int j = 0; j < n; j++) {
                if (j != i && kalan[j] && cakisir(&a[i], &a[j])) {
                    c++;
                }
            }
            if (en_iyi < 0 || c < en_iyi_c ||
                (c == en_iyi_c && a[i].bas < a[en_iyi].bas)) {
                en_iyi = i;
                en_iyi_c = c;
            }
        }
        if (en_iyi < 0) {
            return k;
        }
        if (yaz) {
            printf("     seç %c [%d,%d) (kalanlarla çakışma = %d)\n",
                   ad(&a[en_iyi]), a[en_iyi].bas, a[en_iyi].bit, en_iyi_c);
        }
        secilen[k++] = a[en_iyi];
        for (int j = 0; j < n; j++) {
            if (kalan[j] && cakisir(&a[en_iyi], &a[j])) {
                kalan[j] = false;
            }
        }
        kalan[en_iyi] = false;
    }
}

/* Bütün alt kümeler (2^n); en çok aralıklı uyumlu alt kümenin
 * maskesini döndürür (eşitlikte küçük maske) */
static unsigned kaba_kuvvet(const Aralik *a, int n)
{
    Aralik sira[MAKS_N];
    for (int i = 0; i < n; i++) {
        sira[i] = a[i];
    }
    qsort(sira, (size_t)n, sizeof sira[0], basa_gore);
    unsigned en_iyi_maske = 0;
    int en_iyi_k = 0;
    for (unsigned maske = 0; maske < (1u << n); maske++) {
        int k = 0;
        int son = -1;
        bool gecerli = true;
        for (int i = 0; i < n; i++) {    /* kimlik = dizideki konum */
            const Aralik *x = &sira[i];
            if (maske >> x->kimlik & 1u) {
                if (x->bas < son) {
                    gecerli = false;
                    break;
                }
                son = x->bit;
                k++;
            }
        }
        if (gecerli && k > en_iyi_k) {
            en_iyi_maske = maske;
            en_iyi_k = k;
        }
    }
    return en_iyi_maske;
}

static int maske_say(unsigned maske)
{
    int k = 0;
    while (maske) {
        k += maske & 1u;
        maske >>= 1;
    }
    return k;
}

static void liste_yaz(const Aralik *a, int n)
{
    for (int i = 0; i < n; i++) {
        printf(i > 0 ? " %c[%d,%d)" : "%c[%d,%d)", ad(&a[i]), a[i].bas,
               a[i].bit);
    }
}

static void secim_yaz(const Aralik *secilen, int k)
{
    for (int j = 0; j < k; j++) {
        printf(j > 0 ? " %c" : "%c", ad(&secilen[j]));
    }
}

static void maske_yaz(const Aralik *a, int n, unsigned maske)
{
    bool ilk = true;
    for (int i = 0; i < n; i++) {
        if (maske >> i & 1u) {
            printf(ilk ? "%c" : " %c", ad(&a[i]));
            ilk = false;
        }
    }
}

static void karsi_ornek(const char *baslik, const Aralik *a, int n,
                        int strateji)
{
    Aralik secilen[MAKS_N];
    int k;
    printf("  %s: ", baslik);
    liste_yaz(a, n);
    printf("\n");
    if (strateji == 2) {
        k = en_az_cakisan(a, n, secilen, true);
    } else if (strateji == 0) {
        k = en_kisa_ilk(a, n, secilen);
    } else {
        k = en_erken_baslayan(a, n, secilen);
    }
    unsigned maske = kaba_kuvvet(a, n);
    printf("     strateji: ");
    secim_yaz(secilen, k);
    printf(" -> %d aralık; en iyi (kaba kuvvet, %u alt küme): ", k, 1u << n);
    maske_yaz(a, n, maske);
    printf(" -> %d\n", maske_say(maske));
    int k2 = en_erken_biten(a, n, secilen, false);
    printf("     en erken biten: ");
    secim_yaz(secilen, k2);
    printf(" -> %d\n", k2);
}

/* Kâhin: kaba kuvvet. Değiş tokuş: en iyi çözümün (bitişe göre) ilk
 * aralığı açgözlünün ilkiyle değiştirilince çözüm geçerli kalır; önde
 * kalma: r. açgözlü aralık en geç r. en iyi aralıkla biter. */
static void rastgele_denetim(void)
{
    int tamam[4] = {0, 0, 0, 0};
    int takas_gecerli = 0, onde = 0;
    Aralik a[DENEME_N], secilen[DENEME_N], g[DENEME_N], o[DENEME_N];
    rastgele_tohum(42);
    for (int d = 0; d < DENEME; d++) {
        for (int i = 0; i < DENEME_N; i++) {
            int bas = rastgele_aralik(0, 20);
            a[i].bas = bas;
            a[i].bit = bas + rastgele_aralik(1, 8);
            a[i].kimlik = i;
        }
        unsigned maske = kaba_kuvvet(a, DENEME_N);
        int en_iyi = maske_say(maske);
        int k0 = en_erken_biten(a, DENEME_N, secilen, false);
        tamam[0] += k0 == en_iyi;
        for (int j = 0; j < k0; j++) {
            g[j] = secilen[j];           /* açgözlünün seçtikleri */
        }
        tamam[1] += en_kisa_ilk(a, DENEME_N, secilen) == en_iyi;
        tamam[2] += en_erken_baslayan(a, DENEME_N, secilen) == en_iyi;
        tamam[3] += en_az_cakisan(a, DENEME_N, secilen, false) == en_iyi;
        int m = 0;
        for (int i = 0; i < DENEME_N; i++) {
            if (maske >> i & 1u) {
                o[m++] = a[i];
            }
        }
        qsort(o, (size_t)m, sizeof o[0], bitise_gore);
        bool ok = true;
        for (int r = 0; r < en_iyi; r++) {
            if (g[r].bit > o[r].bit) {
                ok = false;
            }
        }
        onde += ok;
        o[0] = g[0];                     /* değiş tokuş adımı */
        bool gecerli = true;
        for (int i = 0; i < en_iyi; i++) {
            for (int j = i + 1; j < en_iyi; j++) {
                if (cakisir(&o[i], &o[j])) {
                    gecerli = false;
                }
            }
        }
        takas_gecerli += gecerli;
    }
    printf("  %d rastgele örnek (n = %d, bas 0..20, uzunluk 1..8, tohum 42); "
           "en iyiyi bulduğu örnek sayısı:\n", DENEME, DENEME_N);
    const char *adlar[4] = {"en erken biten   ", "en kısa ilk      ",
                            "en erken başlayan", "en az çakışan    "};
    for (int s = 0; s < 4; s++) {
        printf("    %s: %4d/%d\n", adlar[s], tamam[s], DENEME);
    }
    printf("  değiş tokuş: en iyinin ilk aralığı açgözlünün ilkiyle "
           "değiştirilince geçerli: %d/%d\n", takas_gecerli, DENEME);
    printf("  açgözlü önde kalır (her r için g_r.bit <= o_r.bit): %d/%d\n",
           onde, DENEME);
}

int main(void)
{
    const int veri[10][2] = {{4, 7}, {0, 3}, {3, 8}, {1, 4}, {7, 10},
                             {9, 12}, {6, 9}, {11, 14}, {2, 6}, {8, 13}};
    Aralik a[10], secilen[MAKS_N];
    for (int i = 0; i < 10; i++) {
        a[i].bas = veri[i][0];
        a[i].bit = veri[i][1];
        a[i].kimlik = i;
    }
    printf("1) En erken biten ilk: %d istek, yarı açık [bas, bit)\n", 10);
    printf("  girdi: ");
    liste_yaz(a, 10);
    printf("\n  sıra (bit, bas, kimlik); zaman 0..15 her sütun 1 birim:\n");
    int k = en_erken_biten(a, 10, secilen, true);
    unsigned maske = kaba_kuvvet(a, 10);
    printf("  seçilen %d aralık: ", k);
    secim_yaz(secilen, k);
    printf("; kaba kuvvet (%u alt küme) en çok %d\n", 1u << 10,
           maske_say(maske));

    printf("\n2) Yanlış ölçütler ve karşı örnekleri (kaba kuvvetle "
           "doğrulandı)\n");
    const Aralik kisa[3] = {{0, 5, 0}, {4, 7, 1}, {6, 11, 2}};
    karsi_ornek("a) en kısa ilk", kisa, 3, 0);
    const Aralik erken[3] = {{0, 10, 0}, {1, 3, 1}, {4, 6, 2}};
    karsi_ornek("b) en erken başlayan", erken, 3, 1);
    const int v[11][2] = {{0, 3}, {4, 7}, {8, 11}, {12, 15}, {2, 5}, {2, 5},
                          {2, 5}, {6, 9}, {10, 13}, {10, 13}, {10, 13}};
    Aralik az[11];
    for (int i = 0; i < 11; i++) {
        az[i].bas = v[i][0];
        az[i].bit = v[i][1];
        az[i].kimlik = i;
    }
    karsi_ornek("c) en az çakışan", az, 11, 2);

    printf("\n3) Kâhinle rastgele denetim ve değiş tokuş argümanı\n");
    rastgele_denetim();
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort yalnız sıralama aracı); C++ — yok
 * (std::sort aracı); Python — yok (sorted aracı). Aralık çizelgeleme bir
 * kütüphane işlevi değildir. */

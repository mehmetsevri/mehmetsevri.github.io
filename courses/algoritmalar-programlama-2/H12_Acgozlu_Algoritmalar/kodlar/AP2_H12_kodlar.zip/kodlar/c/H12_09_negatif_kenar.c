/* H12_09_negatif_kenar.c — AP-2 Hafta 12 · Örnek 9 (★★)
 * Amaç    : Negatif ağırlıklı kenarda Dijkstra'nın yanlış sonucu (karşı
 *           örnek): kesinleşen köşe sonradan bulunan kısa yolla
 *           güncellenemez. Kâhin: Bellman–Ford (yalnız doğrulama için).
 *           Ağırlıklara sabit eklemenin neden çözüm olmadığı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_09_negatif_kenar.c \
 *           -o H12_09_negatif_kenar
 * Çalıştır: ./H12_09_negatif_kenar ../girdiler/h12_negatif.txt
 * Eşleri  : cpp/H12_09_negatif_kenar.cpp · python/H12_09_negatif_kenar.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : Dijkstra Örnek 7'nin dizi tabanlı sürümüdür (önkoşul denetimi
 *           bu örnekte bilerek yapılmaz).
 */
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SONSUZ INT_MAX
#define SATIR_UZUNLUGU 512

static long long taranan_hucre = 0;
static long long kenar_inceleme = 0;
static long long gevsetme_sayisi = 0;

/* ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ---------------- */
typedef struct {
    int hedef, agirlik;
} Komsu;

typedef struct {                /* H8 dinamik dizisi: komşu listesi */
    Komsu *veri;
    size_t boyut, kapasite;
} KomsuDizisi;

typedef struct {
    int u, v, w;
} Kenar;

typedef struct {
    int v_sayisi, e_sayisi;
    bool yonlu;
    KomsuDizisi *komsu;         /* komsu[u]: u'dan çıkan kenarlar */
    Kenar *kenar;               /* dosyadaki sırayla kenar listesi */
    int kenar_sayisi;
} Graf;

static void hata(const char *bicim, ...)
{
    va_list ap;
    va_start(ap, bicim);
    fprintf(stderr, "Hata: ");
    vfprintf(stderr, bicim, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

/* x'i sona ekler; doluysa kapasiteyi ikiye katlar. 0: başarı, -1: bellek */
static int kd_ekle(KomsuDizisi *d, Komsu x)
{
    if (d->boyut == d->kapasite) {
        size_t yeni = d->kapasite == 0 ? 4 : 2 * d->kapasite;
        Komsu *gecici = realloc(d->veri, yeni * sizeof *gecici);
        if (gecici == NULL) {
            return -1;               /* d->veri hâlâ geçerli */
        }
        d->veri = gecici;
        d->kapasite = yeni;
    }
    d->veri[d->boyut++] = x;
    return 0;
}

/* Sahiplik: g'nin dizileri graf_yok_et ile serbest bırakılır */
static bool graf_kur(Graf *g, int v_sayisi, int e_sayisi, bool yonlu)
{
    g->v_sayisi = v_sayisi;
    g->e_sayisi = e_sayisi;
    g->yonlu = yonlu;
    g->kenar_sayisi = 0;
    g->komsu = calloc((size_t)v_sayisi, sizeof *g->komsu);
    g->kenar = malloc((size_t)(e_sayisi > 0 ? e_sayisi : 1) * sizeof *g->kenar);
    return g->komsu != NULL && g->kenar != NULL;
}

static void graf_yok_et(Graf *g)
{
    if (g->komsu != NULL) {
        for (int v = 0; v < g->v_sayisi; v++) {
            free(g->komsu[v].veri);
        }
    }
    free(g->komsu);
    free(g->kenar);
    g->komsu = NULL;
    g->kenar = NULL;
}

static int komsu_karsilastir(const void *p, const void *q)
{
    const Komsu *x = p, *y = q;
    if (x->hedef != y->hedef) {
        return x->hedef < y->hedef ? -1 : 1;
    }
    return (x->agirlik > y->agirlik) - (x->agirlik < y->agirlik);
}

static void komsulari_sirala(Graf *g)     /* (hedef, agirlik) artan */
{
    for (int v = 0; v < g->v_sayisi; v++) {
        if (g->komsu[v].boyut > 1) {   /* boş listede veri NULL olabilir */
            qsort(g->komsu[v].veri, g->komsu[v].boyut, sizeof(Komsu),
                  komsu_karsilastir);
        }
    }
}

/* '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural) */
static bool tamsayi_coz(const char *s, int *x)
{
    const char *p = (*s == '-') ? s + 1 : s;
    size_t n = strlen(p);
    if (n == 0 || n > 9) {
        return false;
    }
    for (size_t i = 0; i < n; i++) {
        if (p[i] < '0' || p[i] > '9') {
            return false;
        }
    }
    *x = (int)strtol(s, NULL, 10);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

/* s'yi boşluklarda böler; parça sayısını döndürür (ilk 4'ü t[]'ye) */
static int parcala(char *s, char **t)
{
    int k = 0;
    while (*s != '\0') {
        while (bosluk_mu(*s)) {
            *s++ = '\0';
        }
        if (*s == '\0') {
            break;
        }
        if (k < 4) {
            t[k] = s;
        }
        k++;
        while (*s != '\0' && !bosluk_mu(*s)) {
            s++;
        }
    }
    return k;
}

/* Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
 * (w yoksa 1). 0: başarı; 1: hata (ileti stderr'de, g boş). */
static int graf_oku(const char *yol, Graf *g)
{
    g->komsu = NULL;
    g->kenar = NULL;
    g->v_sayisi = 0;
    FILE *f = fopen(yol, "rb");
    if (f == NULL) {
        hata("dosya açılamadı: %s", yol);
        return 1;
    }
    char satir[SATIR_UZUNLUGU];
    char *t[4];
    int no = 0, sonuc = 0;
    bool baslik = false;
    while (sonuc == 0 && fgets(satir, sizeof satir, f) != NULL) {
        no++;
        size_t uz = strlen(satir);
        if (uz == sizeof satir - 1 && satir[uz - 1] != '\n') {
            hata("satır %d: satır çok uzun", no);
            sonuc = 1;
            break;
        }
        int k = parcala(satir, t);
        if (k == 0 || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            const char *tur = k == 3 ? t[2] : "yonsuz";
            if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &v) ||
                !tamsayi_coz(t[1], &e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 ||
                (strcmp(tur, "yonlu") != 0 && strcmp(tur, "yonsuz") != 0)) {
                hata("satır %d: başlık 'V E [yonlu|yonsuz]' bekleniyordu",
                     no);
                sonuc = 1;
            } else if (!graf_kur(g, v, e, strcmp(tur, "yonlu") == 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((k != 2 && k != 3) || !tamsayi_coz(t[0], &u) ||
            !tamsayi_coz(t[1], &v) || (k == 3 && !tamsayi_coz(t[2], &w))) {
            hata("satır %d: kenar 'u v [w]' bekleniyordu", no);
            sonuc = 1;
        } else if (u < 0 || u >= g->v_sayisi || v < 0 || v >= g->v_sayisi) {
            hata("satır %d: köşe numarası 0..%d aralığında olmalı", no,
                 g->v_sayisi - 1);
            sonuc = 1;
        } else if (g->kenar_sayisi == g->e_sayisi) {
            hata("satır %d: fazla kenar (E = %d)", no, g->e_sayisi);
            sonuc = 1;
        } else {
            g->kenar[g->kenar_sayisi++] = (Kenar){u, v, w};
            if (kd_ekle(&g->komsu[u], (Komsu){v, w}) != 0 ||
                (!g->yonlu && kd_ekle(&g->komsu[v], (Komsu){u, w}) != 0)) {
                hata("bellek yetersiz");
                sonuc = 1;
            }
        }
    }
    fclose(f);
    if (sonuc == 0 && !baslik) {
        hata("başlık satırı yok");
        sonuc = 1;
    } else if (sonuc == 0 && g->kenar_sayisi < g->e_sayisi) {
        hata("kenar sayısı eksik: %d bekleniyordu, %d okundu", g->e_sayisi,
             g->kenar_sayisi);
        sonuc = 1;
    }
    if (sonuc != 0) {
        graf_yok_et(g);
        return 1;
    }
    komsulari_sirala(g);
    return 0;
}
/* -------------------------------------------------------------------------- */

static void uzaklik_yaz(int d, int genislik)
{
    if (d == SONSUZ) {
        printf("%*s∞", genislik - 1, "");
    } else {
        printf("%*d", genislik, d);
    }
}

/* O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama */
static void dijkstra_dizi(const Graf *g, int kaynak, int *d, int *ebeveyn,
                          bool yaz)
{
    int n = g->v_sayisi;
    bool *kesin = calloc((size_t)n, sizeof *kesin);
    if (kesin == NULL) {
        return;
    }
    for (int v = 0; v < n; v++) {
        d[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    d[kaynak] = 0;
    for (int adim = 1; adim <= n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {    /* en küçük d: doğrusal tarama */
            taranan_hucre++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;                       /* kalanlar ulaşılamaz */
        }
        kesin[u] = true;                 /* d[u] artık kesin */
        if (yaz) {
            printf("  adım %d: seç %d (d = %d); kesinleşen {", adim, u, d[u]);
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (kesin[x]) {
                    printf(ilk ? "%d" : ", %d", x);
                    ilk = false;
                }
            }
            printf("}\n");
        }
        const KomsuDizisi *k = &g->komsu[u];
        for (size_t i = 0; i < k->boyut; i++) {
            int v = k->veri[i].hedef, w = k->veri[i].agirlik;
            kenar_inceleme++;
            if (kesin[v]) {
                continue;
            }
            if (d[u] != SONSUZ && d[u] + w < d[v]) {   /* taşma korumalı */
                if (yaz) {
                    printf("     gevşet %d->%d (w = %d): d[%d] = ", u, v, w,
                           v);
                    uzaklik_yaz(d[v], 1);
                    printf(" -> %d\n", d[u] + w);
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
            } else if (yaz) {
                printf("     %d->%d (w = %d): %d + %d >= %d, değişmez\n", u,
                       v, w, d[u], w, d[v]);
            }
        }
        if (yaz) {
            printf("     d:");
            for (int x = 0; x < n; x++) {
                printf(" ");
                uzaklik_yaz(d[x], 1);
            }
            printf("\n");
        }
    }
    free(kesin);
}

/* Kâhin: V - 1 tur, her turda bütün kenarlar (dosya sırasıyla)
 * gevşetilir; bir tur daha iyileşme varsa negatif döngü vardır.
 * Negatif döngü varsa true döndürür. */
static bool bellman_ford(const Graf *g, int kaynak, int *d, bool yaz)
{
    for (int v = 0; v < g->v_sayisi; v++) {
        d[v] = SONSUZ;
    }
    d[kaynak] = 0;
    for (int tur = 1; tur < g->v_sayisi; tur++) {
        bool degisti = false;
        for (int i = 0; i < g->kenar_sayisi; i++) {
            int u = g->kenar[i].u, v = g->kenar[i].v, w = g->kenar[i].w;
            if (d[u] != SONSUZ && d[u] + w < d[v]) {
                d[v] = d[u] + w;
                degisti = true;
            }
            if (!g->yonlu && d[v] != SONSUZ && d[v] + w < d[u]) {
                d[u] = d[v] + w;
                degisti = true;
            }
        }
        if (yaz) {
            printf("  tur %d: d =", tur);
            for (int v = 0; v < g->v_sayisi; v++) {
                printf(" ");
                uzaklik_yaz(d[v], 1);
            }
            printf("\n");
        }
        if (!degisti) {
            break;
        }
    }
    for (int i = 0; i < g->kenar_sayisi; i++) {
        int u = g->kenar[i].u, v = g->kenar[i].v, w = g->kenar[i].w;
        if (d[u] != SONSUZ && d[u] + w < d[v]) {
            return true;
        }
    }
    return false;
}

/* En iyilik koşulu: hiçbir kenar d[u] + w < d[v] olmamalı. İhlal eden
 * kenarları yazar, sayısını döndürür. */
static int gevsetilebilir(const Graf *g, const int *d)
{
    int k = 0;
    for (int i = 0; i < g->kenar_sayisi; i++) {
        int u = g->kenar[i].u, v = g->kenar[i].v, w = g->kenar[i].w;
        if (d[u] != SONSUZ && d[u] + w < d[v]) {
            printf("  %d->%d (w = %d): d[%d] + w = %d < d[%d] = %d\n", u, v,
                   w, u, d[u] + w, v, d[v]);
            k++;
        }
    }
    return k;
}

static void yol_yaz(const int *ebeveyn, int n, int hedef)
{
    int *s = malloc((size_t)n * sizeof *s);
    if (s == NULL) {
        return;
    }
    int k = 0;
    for (int v = hedef; v != -1; v = ebeveyn[v]) {
        s[k++] = v;
    }
    for (int i = k - 1; i >= 0; i--) {
        printf(i < k - 1 ? " -> %d" : "%d", s[i]);
    }
    free(s);
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Kullanım: H12_09_negatif_kenar GRAF_DOSYASI\n");
        return 2;
    }
    Graf g, kaydirilmis;
    if (graf_oku(argv[1], &g) != 0) {
        return 1;
    }
    int n = g.v_sayisi;
    printf("1) Graf: %d köşe, %d kenar, %s; kenarlar: ", n, g.e_sayisi,
           g.yonlu ? "yönlü" : "yönsüz");
    for (int i = 0; i < g.kenar_sayisi; i++) {
        printf(i > 0 ? ", %d->%d (%d)" : "%d->%d (%d)", g.kenar[i].u,
               g.kenar[i].v, g.kenar[i].w);
    }
    printf("\n");
    int en_kucuk = 0;
    for (int i = 0; i < g.kenar_sayisi; i++) {
        if (g.kenar[i].w < en_kucuk) {
            en_kucuk = g.kenar[i].w;
        }
    }
    printf("  en küçük ağırlık = %d: Dijkstra'nın önkoşulu (w >= 0) %s\n",
           en_kucuk, en_kucuk >= 0 ? "sağlanıyor" : "SAĞLANMIYOR");

    printf("\n2) Dizi tabanlı Dijkstra (Örnek 7), kaynak 0\n");
    int *d = malloc((size_t)n * sizeof *d);
    int *ebeveyn = malloc((size_t)n * sizeof *ebeveyn);
    int *bf = malloc((size_t)n * sizeof *bf);
    int *d2 = malloc((size_t)n * sizeof *d2);
    int *e2 = malloc((size_t)n * sizeof *e2);
    if (d == NULL || ebeveyn == NULL || bf == NULL || d2 == NULL ||
        e2 == NULL || !graf_kur(&kaydirilmis, n, g.e_sayisi, g.yonlu)) {
        fprintf(stderr, "Hata: bellek yetersiz\n");
        return 1;
    }
    dijkstra_dizi(&g, 0, d, ebeveyn, true);

    printf("\n3) Kâhin: Bellman–Ford (yalnız doğrulama), kaynak 0\n");
    bool dongu = bellman_ford(&g, 0, bf, true);
    printf("  negatif döngü: %s\n", dongu ? "VAR" : "yok");

    printf("\n4) Karşılaştırma\n");
    printf("  köşe  Dijkstra  Bellman–Ford  doğru mu\n");
    int yanlis = 0;
    for (int v = 0; v < n; v++) {
        bool dogru = d[v] == bf[v];
        yanlis += !dogru;
        printf("  %4d  ", v);
        uzaklik_yaz(d[v], 8);
        printf("  ");
        uzaklik_yaz(bf[v], 12);
        printf("  %s\n", dogru ? "evet" : "HAYIR");
    }
    printf("  %d köşede yanlış. Dijkstra'nın sonucunda hâlâ gevşetilebilen "
           "kenarlar\n  (en iyilik koşulu ihlali):\n", yanlis);
    int k = gevsetilebilir(&g, d);
    printf("  %d kenar. Bu girdide 1 kesinleştikten sonra 2 -> 1 kenarı "
           "daha kısa yol verdi;\n  kesinleşen köşe yeniden işlenmediği için "
           "1 ve onun üzerinden 3 eski değerde kaldı.\n", k);

    printf("\n5) Yaygın yanlış çözüm: bütün ağırlıklara %d eklemek\n",
           -en_kucuk);
    for (int i = 0; i < g.kenar_sayisi; i++) {
        int u = g.kenar[i].u, v = g.kenar[i].v, w = g.kenar[i].w - en_kucuk;
        kaydirilmis.kenar[kaydirilmis.kenar_sayisi++] = (Kenar){u, v, w};
        if (kd_ekle(&kaydirilmis.komsu[u], (Komsu){v, w}) != 0 ||
            (!g.yonlu && kd_ekle(&kaydirilmis.komsu[v], (Komsu){u, w}) != 0)) {
            fprintf(stderr, "Hata: bellek yetersiz\n");
            return 1;
        }
    }
    komsulari_sirala(&kaydirilmis);
    dijkstra_dizi(&kaydirilmis, 0, d2, e2, false);
    int hedef = n - 1, ozgun = 0;
    for (int v = hedef; e2[v] != -1; v = e2[v]) {
        for (int i = 0; i < g.kenar_sayisi; i++) {
            if (g.kenar[i].u == e2[v] && g.kenar[i].v == v) {
                ozgun += g.kenar[i].w;
                break;
            }
        }
    }
    printf("  kaydırılmış grafta Dijkstra'nın 0 -> %d yolu: ", hedef);
    yol_yaz(e2, n, hedef);
    printf(" (kaydırılmış uzunluk %d, özgün uzunluk %d)\n", d2[hedef], ozgun);
    printf("  gerçek en kısa uzaklık (Bellman–Ford) = %d: çok kenarlı yol "
           "kenar başına\n  ceza alır; sabit eklemek yolların sırasını "
           "değiştirir.\n", bf[hedef]);
    free(d);
    free(ebeveyn);
    free(bf);
    free(d2);
    free(e2);
    graf_yok_et(&kaydirilmis);
    graf_yok_et(&g);
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (Bellman–Ford: Boost Graph
 * Library bellman_ford_shortest_paths, networkx bellman_ford_path —
 * standart dışı; yalnız kâhin). */

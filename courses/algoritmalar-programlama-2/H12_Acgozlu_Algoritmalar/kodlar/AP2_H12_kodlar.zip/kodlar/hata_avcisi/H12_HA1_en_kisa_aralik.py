"""H12_HA1_en_kisa_aralik.py — AP-2 Hafta 12 · Hata Avcısı 1
BU DOSYA KASITLI HATA İÇERİR
Hata    : aralık çizelgelemede açgözlü ölçüt yanlış seçilmiş: "en kısa
          aralık ilk". Elle denenen iki kolay örnekte doğru sonuç verdiği
          için kod "doğru" sanılır; karşı örnekle ya da kâhinle (kaba
          kuvvet) sınanmamıştır.
Çalıştır: python3 H12_HA1_en_kisa_aralik.py
Düzeltme: H12_HA1_en_kisa_aralik_duzeltilmis.py
"""


def cakisir(a, b):
    """Yarı açık [bas, bit) aralıklar"""
    return a[0] < b[1] and b[0] < a[1]


def cizelgele(istek):
    """HATALI ölçüt: kısa olan önce (eşitlikte başlangıç)"""
    sira = sorted(istek, key=lambda x: (x[1] - x[0], x[0]))
    secilen = []
    for x in sira:
        if all(not cakisir(x, y) for y in secilen):
            secilen.append(x)
    return secilen


def main():
    ornekler = [
        ("kolay 1", [(0, 2), (2, 4), (1, 3)]),
        ("kolay 2", [(0, 1), (1, 5), (5, 6), (2, 3)]),
        ("toplantı odası", [(0, 5), (4, 7), (6, 11)]),
    ]
    for ad, istek in ornekler:
        secilen = cizelgele(istek)
        print(f"{ad}: istek {istek}")
        print(f"  seçilen {len(secilen)}: {sorted(secilen)}")


if __name__ == "__main__":
    main()

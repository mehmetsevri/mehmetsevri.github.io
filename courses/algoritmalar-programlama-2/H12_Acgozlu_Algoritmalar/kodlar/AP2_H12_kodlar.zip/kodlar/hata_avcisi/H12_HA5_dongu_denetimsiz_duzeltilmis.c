/* H12_HA5_dongu_denetimsiz_duzeltilmis.c — AP-2 Hafta 12 · HA 5
 * Düzeltme: her kenar için birleşim–bul ile uçların kökleri karşılaştırılır;
 *           kökler aynıysa kenar döngü kurar ve REDDEDİLİR, farklıysa ağaçlar
 *           birleştirilir. V - 1 kenar KABUL edilince durulur (Örnek 11).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_HA5_dongu_denetimsiz_duzeltilmis.c \
 *           -o H12_HA5_dongu_denetimsiz_duzeltilmis
 * Hatalı  : H12_HA5_dongu_denetimsiz.c
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#define V 8
#define E 14

typedef struct {
    int u, v, w;
} Kenar;

/* Örnek 11'in kampüs grafı (girdiler/h12_kampus.txt) */
static Kenar kenar[E] = {{0, 1, 40}, {0, 2, 45}, {0, 7, 60}, {1, 2, 30},
                         {1, 3, 120}, {1, 7, 140}, {2, 3, 20}, {2, 4, 110},
                         {3, 4, 50}, {3, 5, 55}, {4, 5, 10}, {4, 6, 70},
                         {5, 6, 80}, {6, 7, 130}};

static int ebeveyn[V];

static int bul(int x)                    /* yol sıkıştırmalı */
{
    int kok = x;
    while (ebeveyn[kok] != kok) {
        kok = ebeveyn[kok];
    }
    while (ebeveyn[x] != kok) {
        int sonraki = ebeveyn[x];
        ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

static int kenar_karsilastir(const void *p, const void *q)  /* (w, u, v) */
{
    const Kenar *x = p, *y = q;
    if (x->w != y->w) {
        return x->w < y->w ? -1 : 1;
    }
    if (x->u != y->u) {
        return x->u < y->u ? -1 : 1;
    }
    return (x->v > y->v) - (x->v < y->v);
}

int main(void)
{
    qsort(kenar, E, sizeof kenar[0], kenar_karsilastir);
    for (int v = 0; v < V; v++) {
        ebeveyn[v] = v;
    }
    int toplam = 0, kabul = 0;
    printf("seçilen kenarlar:");
    for (int i = 0; i < E && kabul < V - 1; i++) {
        int ku = bul(kenar[i].u), kv = bul(kenar[i].v);
        if (ku == kv) {                  /* DÜZELTME: döngü denetimi */
            printf(" [ret %d-%d (%d)]", kenar[i].u, kenar[i].v, kenar[i].w);
            continue;
        }
        ebeveyn[ku] = kv;
        printf(" %d-%d (%d)", kenar[i].u, kenar[i].v, kenar[i].w);
        toplam += kenar[i].w;
        kabul++;
    }
    int bilesen = 0;
    for (int v = 0; v < V; v++) {
        bilesen += bul(v) == v;
    }
    printf("\nkenar sayısı = %d, toplam ağırlık = %d, bileşen sayısı = %d\n",
           kabul, toplam, bilesen);
    return 0;
}

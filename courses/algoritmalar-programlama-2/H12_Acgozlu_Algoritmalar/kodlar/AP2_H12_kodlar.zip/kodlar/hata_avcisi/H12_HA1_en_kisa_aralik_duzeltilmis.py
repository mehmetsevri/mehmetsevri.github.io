"""H12_HA1_en_kisa_aralik_duzeltilmis.py — AP-2 Hafta 12 · HA 1
Düzeltme: ölçüt "en erken biten ilk" (değiş tokuş argümanıyla kanıtlı;
          Örnek 2). Ayrıca kod kâhinle sınanır: rastgele örneklerde kaba
          kuvvetin (bütün alt kümeler) bulduğu en çok aralık sayısıyla
          karşılaştırılır; eski ölçüt de aynı sınamaya sokulur.
Çalıştır: python3 H12_HA1_en_kisa_aralik_duzeltilmis.py
Hatalı  : H12_HA1_en_kisa_aralik.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))   # ortak_rastgele.py
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402


def cakisir(a, b):
    """Yarı açık [bas, bit) aralıklar"""
    return a[0] < b[1] and b[0] < a[1]


def sec(istek, anahtar):
    sira = sorted(istek, key=anahtar)
    secilen = []
    for x in sira:
        if all(not cakisir(x, y) for y in secilen):
            secilen.append(x)
    return secilen


def cizelgele(istek):
    """DOĞRU ölçüt: erken biten önce (eşitlikte başlangıç)"""
    return sec(istek, lambda x: (x[1], x[0]))


def en_kisa_ilk(istek):
    return sec(istek, lambda x: (x[1] - x[0], x[0]))


def kaba_kuvvet(istek):
    """Kâhin: bütün alt kümeler içinde uyumlu olanların en büyüğü"""
    n = len(istek)
    en_iyi = 0
    for maske in range(1 << n):
        alt = [istek[i] for i in range(n) if maske >> i & 1]
        if all(not cakisir(alt[i], alt[j]) for i in range(len(alt))
               for j in range(i + 1, len(alt))):
            en_iyi = max(en_iyi, len(alt))
    return en_iyi


def main():
    ornekler = [
        ("kolay 1", [(0, 2), (2, 4), (1, 3)]),
        ("kolay 2", [(0, 1), (1, 5), (5, 6), (2, 3)]),
        ("toplantı odası", [(0, 5), (4, 7), (6, 11)]),
    ]
    for ad, istek in ornekler:
        secilen = cizelgele(istek)
        print(f"{ad}: istek {istek}")
        print(f"  seçilen {len(secilen)}: {sorted(secilen)}; kâhin "
              f"{kaba_kuvvet(istek)}")
    rastgele_tohum(7)
    dogru = [0, 0]
    for _ in range(500):
        istek = []
        for _ in range(8):
            bas = rastgele_aralik(0, 20)
            istek.append((bas, bas + rastgele_aralik(1, 8)))
        k = kaba_kuvvet(istek)
        dogru[0] += len(cizelgele(istek)) == k
        dogru[1] += len(en_kisa_ilk(istek)) == k
    print(f"kâhinle 500 rastgele örnek (8 aralık, tohum 7): en erken biten "
          f"{dogru[0]}/500, en kısa ilk {dogru[1]}/500")


if __name__ == "__main__":
    main()

/* H12_HA4_sonsuz_tasmasi_duzeltilmis.c — AP-2 Hafta 12 · HA 4
 * Düzeltme: (1) en küçük seçimi yalnız ulaşılmış köşeler arasında yapılır,
 *           hiçbiri kalmadıysa döngü biter; (2) gevşetme taşma korumalıdır:
 *           d[u] != SONSUZ && d[u] + w < d[v] (rehber 14.2). Ulaşılamayan
 *           köşe "∞" yazdırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_HA4_sonsuz_tasmasi_duzeltilmis.c \
 *           -o H12_HA4_sonsuz_tasmasi_duzeltilmis
 * Hatalı  : H12_HA4_sonsuz_tasmasi.c
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>

#define V 5
#define E 3
#define SONSUZ INT_MAX

/* İki bileşenli yönsüz graf: {0, 1, 2} ve {3, 4}; kaynak 0 */
static const int KENAR[E][3] = {{0, 1, 4}, {1, 2, 3}, {3, 4, 2}};

int main(void)
{
    int d[V];
    bool kesin[V];
    for (int v = 0; v < V; v++) {
        d[v] = SONSUZ;
        kesin[v] = false;
    }
    d[0] = 0;
    for (int adim = 0; adim < V; adim++) {
        int u = -1;
        for (int v = 0; v < V; v++) {    /* DÜZELTME 1: yalnız ulaşılmış */
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            printf("kalan köşeler ulaşılamaz: döngü biter\n");
            break;
        }
        kesin[u] = true;
        printf("seç %d (d = %d)\n", u, d[u]);
        for (int i = 0; i < E; i++) {
            for (int yon = 0; yon < 2; yon++) {
                if (KENAR[i][yon] != u) {
                    continue;
                }
                int v = KENAR[i][1 - yon], w = KENAR[i][2];
                if (!kesin[v] && d[u] != SONSUZ && d[u] + w < d[v]) {
                    d[v] = d[u] + w;     /* DÜZELTME 2: taşma korumalı */
                    printf("  gevşet %d -> %d: d[%d] = %d\n", u, v, v, d[v]);
                }
            }
        }
    }
    for (int v = 0; v < V; v++) {
        if (d[v] == SONSUZ) {
            printf("köşe %d: uzaklık ∞ (ulaşılamaz)\n", v);
        } else {
            printf("köşe %d: uzaklık %d\n", v, d[v]);
        }
    }
    return 0;
}

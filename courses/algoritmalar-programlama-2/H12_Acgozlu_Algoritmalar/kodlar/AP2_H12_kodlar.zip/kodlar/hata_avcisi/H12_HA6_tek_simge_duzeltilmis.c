/* H12_HA6_tek_simge_duzeltilmis.c — AP-2 Hafta 12 · HA 6
 * Düzeltme: tek düğümlü ağaçta (kök yaprak) simgeye 1 bitlik kod "0"
 *           verilir; çözücü de bu durumda her biti bir simge sayar
 *           (Örnek 5–6'daki kural).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_HA6_tek_simge_duzeltilmis.c -o H12_HA6_tek_simge_duzeltilmis
 * Hatalı  : H12_HA6_tek_simge.c
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define MAKS 511

static int sembol[MAKS], sol[MAKS], sag[MAKS], dugum_n;
static long long siklik[MAKS];
static char kodlar[256][MAKS];

/* Ağaç (Örnek 5'teki kural; öbek yerine kısalık için doğrusal arama):
 * her adımda (sıklık, düğüm no) sırasına göre en küçük iki kök birleşir */
static int agac_kur(const char *metin)
{
    long long f[256] = {0};
    int kok_mu[MAKS] = {0};
    dugum_n = 0;
    for (const char *p = metin; *p != '\0'; p++) {
        f[(unsigned char)*p]++;
    }
    for (int b = 0; b < 256; b++) {
        if (f[b] > 0) {
            sembol[dugum_n] = b;
            siklik[dugum_n] = f[b];
            sol[dugum_n] = sag[dugum_n] = -1;
            kok_mu[dugum_n++] = 1;
        }
    }
    for (;;) {
        int x = -1, y = -1;
        for (int i = 0; i < dugum_n; i++) {
            if (!kok_mu[i]) {
                continue;
            }
            if (x < 0 || siklik[i] < siklik[x]) {
                y = x;
                x = i;
            } else if (y < 0 || siklik[i] < siklik[y]) {
                y = i;
            }
        }
        if (y < 0) {
            return x;                    /* tek kök kaldı */
        }
        kok_mu[x] = kok_mu[y] = 0;
        sembol[dugum_n] = -1;
        siklik[dugum_n] = siklik[x] + siklik[y];
        sol[dugum_n] = x;
        sag[dugum_n] = y;
        kok_mu[dugum_n++] = 1;
    }
}

static void kod_ata(int d, char *kod, int derinlik)
{
    if (sembol[d] >= 0) {
        if (derinlik == 0) {
            strcpy(kodlar[sembol[d]], "0");   /* DÜZELTME: tek düğüm */
            return;
        }
        memcpy(kodlar[sembol[d]], kod, (size_t)derinlik);
        kodlar[sembol[d]][derinlik] = '\0';
        return;
    }
    kod[derinlik] = '0';
    kod_ata(sol[d], kod, derinlik + 1);
    kod[derinlik] = '1';
    kod_ata(sag[d], kod, derinlik + 1);
}

static void dene(const char *metin)
{
    uint8_t tampon[64] = {0};
    char kod[MAKS], cozulen[64];
    int kok = agac_kur(metin);
    kod_ata(kok, kod, 0);
    size_t bit = 0;
    for (const char *p = metin; *p != '\0'; p++) {
        for (const char *c = kodlar[(unsigned char)*p]; *c != '\0'; c++) {
            if (*c == '1') {
                tampon[bit >> 3] |= (uint8_t)(0x80u >> (bit & 7));
            }
            bit++;
        }
    }
    size_t k = 0;
    int d = kok;
    for (size_t i = 0; i < bit; i++) {   /* bitlerle sürülen çözücü */
        if (sembol[kok] >= 0) {          /* DÜZELTME: her bit bir simge */
            cozulen[k++] = (char)sembol[kok];
            continue;
        }
        d = (tampon[i >> 3] >> (7 - (i & 7)) & 1) ? sag[d] : sol[d];
        if (sembol[d] >= 0) {
            cozulen[k++] = (char)sembol[d];
            d = kok;
        }
    }
    cozulen[k] = '\0';
    printf("metin \"%s\" (%zu bayt): kodlar", metin, strlen(metin));
    for (int b = 0; b < 256; b++) {
        for (int i = 0; i < dugum_n; i++) {
            if (sembol[i] == b) {
                printf(" %c=\"%s\"", b, kodlar[b]);
            }
        }
    }
    printf("\n  %zu bit -> %zu bayt; çözülen \"%s\" (aynı mı? %s)\n", bit,
           (bit + 7) / 8, cozulen, strcmp(cozulen, metin) == 0 ? "evet"
                                                               : "HAYIR");
}

int main(void)
{
    dene("abracadabra");
    dene("aaaaaaa");
    return 0;
}

/* H12_HA2_erken_kesinlestirme_duzeltilmis.c — AP-2 Hafta 12 · HA 2
 * Düzeltme: köşe yalnız öbekten ÇIKARILINCA kesinleşir; o anda d[u] en
 *           küçük kesinleşmemiş uzaklıktır ve negatif kenar yoksa daha
 *           kısa yol bulunamaz. Kesinleşmiş köşenin eskimiş kaydı atlanır
 *           (tembel silme, Örnek 8).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_HA2_erken_kesinlestirme_duzeltilmis.c \
 *           -o H12_HA2_erken_kesinlestirme_duzeltilmis
 * Hatalı  : H12_HA2_erken_kesinlestirme.c
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>

#define V 8
#define E 14
#define SONSUZ INT_MAX

/* Örnek 7–8'in kampüs grafı (girdiler/h12_kampus.txt), yönsüz */
static const int KENAR[E][3] = {{0, 1, 40}, {0, 2, 45}, {0, 7, 60},
    {1, 2, 30}, {1, 3, 120}, {1, 7, 140}, {2, 3, 20}, {2, 4, 110},
    {3, 4, 50}, {3, 5, 55}, {4, 5, 10}, {4, 6, 70}, {5, 6, 80},
    {6, 7, 130}};

typedef struct {
    int uzaklik, kose;
} Oge;

static Oge obek[2 * E + 1];
static int obek_n = 0;

static bool kucuk_mu(Oge x, Oge y)
{
    return x.uzaklik < y.uzaklik || (x.uzaklik == y.uzaklik && x.kose < y.kose);
}

static void obege_ekle(Oge x)
{
    int i = obek_n++;
    obek[i] = x;
    while (i > 0 && kucuk_mu(obek[i], obek[(i - 1) / 2])) {
        Oge g = obek[i];
        obek[i] = obek[(i - 1) / 2];
        obek[(i - 1) / 2] = g;
        i = (i - 1) / 2;
    }
}

static Oge en_kucugu_cikar(void)
{
    Oge en_kucuk = obek[0];
    obek[0] = obek[--obek_n];
    int i = 0;
    while (2 * i + 1 < obek_n) {
        int c = 2 * i + 1;
        if (c + 1 < obek_n && kucuk_mu(obek[c + 1], obek[c])) {
            c++;
        }
        if (!kucuk_mu(obek[c], obek[i])) {
            break;
        }
        Oge g = obek[i];
        obek[i] = obek[c];
        obek[c] = g;
        i = c;
    }
    return en_kucuk;
}

int main(void)
{
    int d[V], ebeveyn[V];
    bool kesin[V];
    for (int v = 0; v < V; v++) {
        d[v] = SONSUZ;
        ebeveyn[v] = -1;
        kesin[v] = false;
    }
    d[0] = 0;
    obege_ekle((Oge){0, 0});
    while (obek_n > 0) {
        int u = en_kucugu_cikar().kose;
        if (kesin[u]) {
            continue;                    /* eskimiş kayıt */
        }
        kesin[u] = true;                 /* DÜZELTME: çıkarılınca kesin */
        for (int i = 0; i < E; i++) {
            for (int yon = 0; yon < 2; yon++) {     /* yönsüz: iki yön */
                if (KENAR[i][yon] != u) {
                    continue;
                }
                int v = KENAR[i][1 - yon], w = KENAR[i][2];
                if (!kesin[v] && d[u] + w < d[v]) {
                    d[v] = d[u] + w;
                    ebeveyn[v] = u;
                    obege_ekle((Oge){d[v], v});
                    printf("%d -> %d: d[%d] = %d\n", u, v, v, d[v]);
                }
            }
        }
    }
    printf("köşe  uzaklık  ebeveyn\n");
    for (int v = 0; v < V; v++) {
        printf("%4d  %7d  %7d\n", v, d[v], ebeveyn[v]);
    }
    return 0;
}

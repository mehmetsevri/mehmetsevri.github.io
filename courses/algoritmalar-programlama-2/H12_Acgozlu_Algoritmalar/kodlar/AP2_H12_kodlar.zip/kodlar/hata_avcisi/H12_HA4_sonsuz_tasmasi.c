/* H12_HA4_sonsuz_tasmasi.c — AP-2 Hafta 12 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR — TANIMSIZ DAVRANIŞ (yalnız gösterim için)
 * Hata    : sonsuz uzaklık INT_MAX ile gösteriliyor ama (1) en küçük seçimi
 *           ulaşılamayan (d = INT_MAX) köşeyi de seçiyor, (2) gevşetmede
 *           d[u] + w toplanmadan önce d[u] != SONSUZ denetlenmiyor.
 *           INT_MAX + w işaretli taşmadır: C'de TANIMSIZ DAVRANIŞ.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_HA4_sonsuz_tasmasi.c -o H12_HA4_sonsuz_tasmasi
 *           (UBSan: -O1 -g -fsanitize=undefined)
 * Düzeltme: H12_HA4_sonsuz_tasmasi_duzeltilmis.c
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>

#define V 5
#define E 3
#define SONSUZ INT_MAX

/* İki bileşenli yönsüz graf: {0, 1, 2} ve {3, 4}; kaynak 0 */
static const int KENAR[E][3] = {{0, 1, 4}, {1, 2, 3}, {3, 4, 2}};

int main(void)
{
    int d[V];
    bool kesin[V];
    for (int v = 0; v < V; v++) {
        d[v] = SONSUZ;
        kesin[v] = false;
    }
    d[0] = 0;
    for (int adim = 0; adim < V; adim++) {
        int u = -1;
        for (int v = 0; v < V; v++) {    /* HATA 1: SONSUZ köşe de seçilir */
            if (!kesin[v] && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        kesin[u] = true;
        printf("seç %d (d = %d)\n", u, d[u]);
        for (int i = 0; i < E; i++) {
            for (int yon = 0; yon < 2; yon++) {
                if (KENAR[i][yon] != u) {
                    continue;
                }
                int v = KENAR[i][1 - yon], w = KENAR[i][2];
                if (!kesin[v] && d[u] + w < d[v]) {   /* HATA 2: taşma */
                    d[v] = d[u] + w;
                    printf("  gevşet %d -> %d: d[%d] = %d\n", u, v, v, d[v]);
                }
            }
        }
    }
    for (int v = 0; v < V; v++) {
        printf("köşe %d: uzaklık %d\n", v, d[v]);
    }
    return 0;
}

/* H12_HA5_dongu_denetimsiz.c — AP-2 Hafta 12 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR
 * Hata    : Kruskal'da döngü denetimi yok: kenarlar (w, u, v) sırasıyla
 *           alınıyor ve V - 1 kenar olunca duruluyor. Seçilen kenarlar döngü
 *           kurabilir ve bazı köşeler hiç bağlanmaz; toplam ağırlık en küçük
 *           kapsayan ağaçtan bile KÜÇÜK çıkar (çünkü ağaç değildir).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_HA5_dongu_denetimsiz.c -o H12_HA5_dongu_denetimsiz
 * Düzeltme: H12_HA5_dongu_denetimsiz_duzeltilmis.c
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#define V 8
#define E 14

typedef struct {
    int u, v, w;
} Kenar;

/* Örnek 11'in kampüs grafı (girdiler/h12_kampus.txt) */
static Kenar kenar[E] = {{0, 1, 40}, {0, 2, 45}, {0, 7, 60}, {1, 2, 30},
                         {1, 3, 120}, {1, 7, 140}, {2, 3, 20}, {2, 4, 110},
                         {3, 4, 50}, {3, 5, 55}, {4, 5, 10}, {4, 6, 70},
                         {5, 6, 80}, {6, 7, 130}};

static int kenar_karsilastir(const void *p, const void *q)  /* (w, u, v) */
{
    const Kenar *x = p, *y = q;
    if (x->w != y->w) {
        return x->w < y->w ? -1 : 1;
    }
    if (x->u != y->u) {
        return x->u < y->u ? -1 : 1;
    }
    return (x->v > y->v) - (x->v < y->v);
}

int main(void)
{
    qsort(kenar, E, sizeof kenar[0], kenar_karsilastir);
    int toplam = 0;
    bool degdi[V] = {false};
    printf("seçilen kenarlar:");
    for (int i = 0; i < V - 1; i++) {    /* HATA: döngü denetimi yok */
        printf(" %d-%d (%d)", kenar[i].u, kenar[i].v, kenar[i].w);
        toplam += kenar[i].w;
        degdi[kenar[i].u] = degdi[kenar[i].v] = true;
    }
    printf("\nkenar sayısı = %d, toplam ağırlık = %d\n", V - 1, toplam);
    printf("hiçbir seçilen kenara değmeyen köşeler:");
    for (int v = 0; v < V; v++) {
        if (!degdi[v]) {
            printf(" %d", v);
        }
    }
    printf("\n");
    return 0;
}

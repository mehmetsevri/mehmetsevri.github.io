/* H12_HA3_eskimis_kayit.cpp — AP-2 Hafta 12 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR
 * Hata    : tembel silmeli Dijkstra'da öbekten çıkan ESKİMİŞ kayıt
 *           (du > d[u]) atlanmıyor: köşe yeniden "işlenir", bütün kenarları
 *           yeniden incelenir. Negatif kenar yokken uzaklıklar yine doğru
 *           çıkar (gevşetme başarısız olur) ama iş artar; kesinleşme sırası
 *           aynı köşeyi birkaç kez içerir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 -I../cpp \
 *           H12_HA3_eskimis_kayit.cpp -o H12_HA3_eskimis_kayit
 * Düzeltme: H12_HA3_eskimis_kayit_duzeltilmis.cpp
 */
#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

using Komsu = std::pair<int, int>;               // (hedef, ağırlık)
using Graf = std::vector<std::vector<Komsu>>;
using Oge = std::pair<long long, int>;           // (uzaklık, köşe)

static const long long SONSUZ = std::numeric_limits<long long>::max();

struct Sayac {
    long long itme = 0, cikarma = 0, inceleme = 0, gevsetme = 0;
};

static std::vector<long long> dijkstra(const Graf& g, int s, Sayac& c,
                                       std::vector<int>& sira)
{
    std::vector<long long> d(g.size(), SONSUZ);
    std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>> obek;
    d[s] = 0;
    obek.push({0, s});
    c.itme++;
    while (!obek.empty()) {
        auto [du, u] = obek.top();
        obek.pop();
        c.cikarma++;
        (void)du;                        // HATA: du > d[u] denetimi yok
        sira.push_back(u);               // "kesinleşen" köşe
        for (auto [v, w] : g[u]) {
            c.inceleme++;
            if (d[u] + w < d[v]) {
                d[v] = d[u] + w;
                c.gevsetme++;
                obek.push({d[v], v});
                c.itme++;
            }
        }
    }
    return d;
}

static Graf kampus()
{
    const int k[14][3] = {{0, 1, 40}, {0, 2, 45}, {0, 7, 60}, {1, 2, 30},
                          {1, 3, 120}, {1, 7, 140}, {2, 3, 20}, {2, 4, 110},
                          {3, 4, 50}, {3, 5, 55}, {4, 5, 10}, {4, 6, 70},
                          {5, 6, 80}, {6, 7, 130}};
    Graf g(8);
    for (const auto& e : k) {
        g[e[0]].push_back({e[1], e[2]});
        g[e[1]].push_back({e[0], e[2]});
    }
    return g;
}

// Yönlü rastgele graf: her (u, v) çifti olasılık p_pay/1024 ile kenar
static Graf rastgele(int n, int p_pay)
{
    rastgele_tohum(42);
    Graf g(n);
    for (int u = 0; u < n; u++) {
        for (int v = 0; v < n; v++) {
            int r = rastgele_aralik(0, 1023);
            int w = rastgele_aralik(1, 100);
            if (u != v && r < p_pay) {
                g[u].push_back({v, w});
            }
        }
    }
    return g;
}

static void rapor(const char* ad, const Graf& g)
{
    Sayac c;
    std::vector<int> sira;
    std::vector<long long> d = dijkstra(g, 0, c, sira);
    long long toplam = 0, e = 0;
    for (std::size_t v = 0; v < g.size(); v++) {
        toplam += d[v] == SONSUZ ? 0 : d[v];
        e += static_cast<long long>(g[v].size());
    }
    std::cout << ad << ": V = " << g.size() << ", kenar listesi öğesi = " << e
              << "\n  uzaklık toplamı = " << toplam << "; itme = " << c.itme
              << ", çıkarma = " << c.cikarma << ", kenar inceleme = "
              << c.inceleme << ", başarılı gevşetme = " << c.gevsetme
              << "\n  'kesinleşen' köşe sayısı = " << sira.size() << "\n";
}

int main()
{
    Graf g = kampus();
    Sayac c;
    std::vector<int> sira;
    std::vector<long long> d = dijkstra(g, 0, c, sira);
    std::cout << "kampüs grafı, kaynak 0: d =";
    for (long long x : d) {
        std::cout << " " << x;
    }
    std::cout << "\n  kesinleşme sırası:";
    for (int u : sira) {
        std::cout << " " << u;
    }
    std::cout << "\n";
    rapor("kampüs", g);
    rapor("rastgele seyrek (p = 4/1024)", rastgele(1000, 4));
    rapor("rastgele yoğun (p = 512/1024)", rastgele(1000, 512));
    return 0;
}

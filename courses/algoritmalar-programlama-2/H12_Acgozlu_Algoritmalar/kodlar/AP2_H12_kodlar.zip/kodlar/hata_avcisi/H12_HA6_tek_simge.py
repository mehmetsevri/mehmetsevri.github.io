"""H12_HA6_tek_simge.py — AP-2 Hafta 12 · Hata Avcısı 6 (Python)
BU DOSYA KASITLI HATA İÇERİR
Hata    : Huffman'da tek simgeli metin: ağaç tek düğümdür (kök yapraktır)
          ve simgenin kodu BOŞ dizgi olur; kodlanmış metin 0 bayttır. Bu
          çözücü simge sayısıyla sürülür ve her simge için en az bir bit
          okur: boş tamponu okumaya çalışır (C'deki sürümde bitlerle
          sürülen çözücü ise hiç simge üretmiyordu).
Çalıştır: python3 H12_HA6_tek_simge.py
Düzeltme: H12_HA6_tek_simge_duzeltilmis.py
"""
import heapq


def agac_kur(metin):
    """Örnek 5'teki kural: öbekte (sıklık, düğüm no)"""
    sembol, sol, sag = [], [], []
    obek = []
    for b in range(256):
        f = metin.count(bytes([b]))
        if f > 0:
            sembol.append(b)
            sol.append(-1)
            sag.append(-1)
            heapq.heappush(obek, (f, len(sembol) - 1))
    while len(obek) > 1:
        fx, x = heapq.heappop(obek)
        fy, y = heapq.heappop(obek)
        sembol.append(-1)
        sol.append(x)
        sag.append(y)
        heapq.heappush(obek, (fx + fy, len(sembol) - 1))
    return sembol, sol, sag, obek[0][1]


def kod_ata(agac, d, kod, kodlar):
    sembol, sol, sag, _ = agac
    if sembol[d] >= 0:
        kodlar[sembol[d]] = kod          # HATA: kök yapraksa kod ""
        return
    kod_ata(agac, sol[d], kod + "0", kodlar)
    kod_ata(agac, sag[d], kod + "1", kodlar)


def coz(agac, tampon, n):
    """Simge sayısıyla sürülen çözücü: her simge en az bir bit okur"""
    sembol, sol, sag, kok = agac
    cikti = bytearray()
    i = 0
    while len(cikti) < n:
        d = kok
        while True:
            bit = tampon[i >> 3] >> (7 - (i & 7)) & 1
            i += 1
            d = sag[d] if bit else sol[d]
            if sembol[d] >= 0:
                break
        cikti.append(sembol[d])
    return bytes(cikti)


def dene(metin):
    agac = agac_kur(metin)
    kodlar = {}
    kod_ata(agac, agac[3], "", kodlar)
    bitler = "".join(kodlar[b] for b in metin)
    tampon = bytearray((len(bitler) + 7) // 8)
    for i, c in enumerate(bitler):
        if c == "1":
            tampon[i >> 3] |= 0x80 >> (i & 7)
    print(f"metin {metin.decode()!r}: kodlar " +
          " ".join(f"{chr(b)}={kodlar[b]!r}" for b in sorted(kodlar)) +
          f"; {len(bitler)} bit -> {len(tampon)} bayt")
    cozulen = coz(agac, tampon, len(metin))
    print(f"  çözülen {cozulen.decode()!r} (aynı mı? "
          f"{'evet' if cozulen == metin else 'HAYIR'})")


def main():
    dene(b"abracadabra")
    dene(b"aaaaaaa")


if __name__ == "__main__":
    main()

"""H12_deney_birlesim_bul.py — AP-2 Hafta 12 · Haftanın Deneyi, ek (Python)
Amaç    : Birleşim–bul sürümlerinin (saf, yalnız rütbe, yalnız yol
          sıkıştırma, ikisi birden) işlem başına işaretçi izleme sayısı ve
          süresi; n rastgele birleştirme + n rastgele bul (3n bul çağrısı)
Çalıştır: python3 H12_deney_birlesim_bul.py N
          saf|rutbe|sikistirma|ikisi|hepsi TEKRAR [CSV]
Çıktı   : stdout'a deterministik sayaçlar, CSV'ye süreler (ms)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

SURUM = ["saf", "rutbe", "sikistirma", "ikisi"]


def calistir(n, rutbeli, sikistir, x, y, q):
    """n birleştirme + n bul; (ebeveyn, izleme, bağlama) döndürür"""
    ebeveyn = list(range(n))
    rutbe = [0] * n
    izleme = baglama = 0

    def bul(a):
        nonlocal izleme, baglama
        kok = a
        while ebeveyn[kok] != kok:
            kok = ebeveyn[kok]
            izleme += 1
        if sikistir:
            while ebeveyn[a] != kok:
                sonraki = ebeveyn[a]
                ebeveyn[a] = kok
                baglama += 1
                a = sonraki
        return kok

    for i in range(n):
        kx, ky = bul(x[i]), bul(y[i])
        if kx == ky:
            continue
        if not rutbeli:
            ebeveyn[kx] = ky
            continue
        if rutbe[kx] < rutbe[ky]:
            kx, ky = ky, kx
        ebeveyn[ky] = kx
        if rutbe[kx] == rutbe[ky]:
            rutbe[kx] += 1
    for i in range(n):
        bul(q[i])
    return ebeveyn, izleme, baglama


def yukseklik(ebeveyn):
    n = len(ebeveyn)
    derinlik = [-1] * n
    en_cok = 0
    yigin = []
    for x in range(n):
        v = x
        while derinlik[v] < 0 and ebeveyn[v] != v:
            yigin.append(v)
            v = ebeveyn[v]
        if derinlik[v] < 0:
            derinlik[v] = 0
        while yigin:
            u = yigin.pop()
            derinlik[u] = derinlik[ebeveyn[u]] + 1
        if derinlik[x] > en_cok:
            en_cok = derinlik[x]
    return en_cok


def olc(s, n, x, y, q, tekrar, csv):
    duvar, islemci = [], []
    for k in range(tekrar + 1):          # k = 0: ısınma
        t0, c0 = zaman_sn(), islemci_sn()
        ebeveyn, izleme, baglama = calistir(n, s in (1, 3), s in (2, 3), x,
                                            y, q)
        if k > 0:
            duvar.append((zaman_sn() - t0) * 1000.0)
            islemci.append((islemci_sn() - c0) * 1000.0)
    kume = 0
    for i in range(n):
        kume += ebeveyn[i] == i
    h = yukseklik(ebeveyn)
    print(f"{SURUM[s]} n={n} izleme={izleme} baglama={baglama} kume={kume} "
          f"yukseklik={h}")
    o_duvar, o_islemci = ortanca(duvar), ortanca(islemci)
    print(f"  Python {SURUM[s]} n={n}: {o_duvar:.3f} ms", file=sys.stderr)
    if csv:
        with open(csv, "a", encoding="utf-8") as f:
            f.write(f"py;{SURUM[s]};{n};{3 * n};{tekrar};{o_duvar:.4f};"
                    f"{min(duvar):.4f};{max(duvar):.4f};{o_islemci:.4f};"
                    f"{izleme};{baglama};{kume};{h};olcum\n")


def main():
    a = sys.argv
    try:
        n, tekrar = int(a[1]), int(a[3])
        secim = -1 if a[2] == "hepsi" else SURUM.index(a[2])
        if len(a) not in (4, 5) or not 2 <= n <= 10000000 or \
                not 1 <= tekrar <= 51:
            raise ValueError
    except (IndexError, ValueError):
        print("Kullanım: H12_deney_birlesim_bul N "
              "saf|rutbe|sikistirma|ikisi|hepsi TEKRAR [CSV]",
              file=sys.stderr)
        sys.exit(2)
    rastgele_tohum(42)                   # işlem dizisi (ölçüm dışı)
    x = [0] * n
    y = [0] * n
    for i in range(n):
        x[i] = rastgele_aralik(0, n - 1)
        y[i] = rastgele_aralik(0, n - 1)
    q = [rastgele_aralik(0, n - 1) for _ in range(n)]
    csv = a[4] if len(a) == 5 else None
    for s in range(4):
        if secim in (-1, s):
            olc(s, n, x, y, q, tekrar, csv)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: Python — yok (networkx.utils.UnionFind standart
# dışı).

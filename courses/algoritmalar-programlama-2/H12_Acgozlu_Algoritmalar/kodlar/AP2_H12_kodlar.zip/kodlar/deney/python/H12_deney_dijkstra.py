"""H12_deney_dijkstra.py — AP-2 Hafta 12 · Haftanın Deneyi (Python)
Amaç    : Dizi tabanlı O(V²) Dijkstra, elle yazılmış öbekli Dijkstra ve
          heapq'lu Dijkstra (etiketli kütüphane serisi); süre ve sayaçlar.
          Graf üretimi C sürümüyle birebir aynıdır (ortak LCG).
Çalıştır: python3 H12_deney_dijkstra.py V D lcg|kotu
          dizi|elle|kutuphane|hepsi TEKRAR [CSV]
Çıktı   : stdout'a deterministik sayaçlar, CSV'ye süreler (ms)
"""
import heapq
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

SONSUZ = 2147483647

sayac = {}


def sayac_sifirla():
    for k in ("itme", "cikarma", "atlanan", "gevsetme", "inceleme",
              "taranan"):
        sayac[k] = 0


def graf_uret(v_sayisi, d, kotu):
    """CSR: u'nun kenarları bas[u]..bas[u+1]-1"""
    bas = [0] * (v_sayisi + 1)
    for u in range(v_sayisi):
        k = min(v_sayisi - 1 - u, d) if kotu else d
        bas[u + 1] = bas[u] + k
    e = bas[v_sayisi]
    hedef = [0] * e
    agirlik = [0] * e
    rastgele_tohum(42)
    for u in range(v_sayisi):
        k = bas[u]
        if kotu:
            v = u + 1
            while k < bas[u + 1]:
                hedef[k] = v
                agirlik[k] = 2 * (v - u) - 1
                v += 1
                k += 1
            continue
        hedef[k] = (u + 1) % v_sayisi
        agirlik[k] = rastgele_aralik(1, 1000)
        k += 1
        while k < bas[u + 1]:
            hedef[k] = rastgele_aralik(0, v_sayisi - 1)
            agirlik[k] = rastgele_aralik(1, 1000)
            k += 1
    return bas, hedef, agirlik


def dijkstra_dizi(n, bas, hedef, agirlik):
    d = [SONSUZ] * n
    kesin = [False] * n
    d[0] = 0
    taranan = inceleme = gevsetme = 0
    for _ in range(n):
        u = -1
        en = SONSUZ
        for v in range(n):               # en küçük d: doğrusal tarama
            if not kesin[v] and d[v] < en:
                u, en = v, d[v]
        taranan += n
        if u < 0:
            break
        kesin[u] = True
        du = d[u]
        for k in range(bas[u], bas[u + 1]):
            v = hedef[k]
            inceleme += 1
            if not kesin[v] and du + agirlik[k] < d[v]:
                d[v] = du + agirlik[k]
                gevsetme += 1
    sayac["taranan"] += taranan
    sayac["inceleme"] += inceleme
    sayac["gevsetme"] += gevsetme
    return d


def elle_ekle(a, x):
    """Elle yazılmış en küçük öbek: yukarı süz (demetler karşılaştırılır)"""
    a.append(x)
    i = len(a) - 1
    while i > 0:
        e = (i - 1) // 2
        if not x < a[e]:
            break
        a[i] = a[e]
        i = e
    a[i] = x


def elle_cikar(a):
    en_kucuk = a[0]
    son = a.pop()
    n = len(a)
    if n == 0:
        return en_kucuk
    i = 0
    while 2 * i + 1 < n:                 # aşağı süz
        c = 2 * i + 1
        if c + 1 < n and a[c + 1] < a[c]:
            c += 1
        if not a[c] < son:
            break
        a[i] = a[c]
        i = c
    a[i] = son
    return en_kucuk


def dijkstra_obek(n, bas, hedef, agirlik, ekle, cikar):
    d = [SONSUZ] * n
    kesin = [False] * n
    d[0] = 0
    obek = []
    ekle(obek, (0, 0))
    itme, cikarma, atlanan, inceleme, gevsetme = 1, 0, 0, 0, 0
    while obek:
        u = cikar(obek)[1]
        cikarma += 1
        if kesin[u]:
            atlanan += 1
            continue
        kesin[u] = True
        du = d[u]
        for k in range(bas[u], bas[u + 1]):
            v = hedef[k]
            inceleme += 1
            if not kesin[v] and du + agirlik[k] < d[v]:
                d[v] = du + agirlik[k]
                gevsetme += 1
                ekle(obek, (d[v], v))
                itme += 1
    sayac["itme"] += itme
    sayac["cikarma"] += cikarma
    sayac["atlanan"] += atlanan
    sayac["inceleme"] += inceleme
    sayac["gevsetme"] += gevsetme
    return d


def olc(surum, agirlik_tur, n, d_p, graf, tekrar, csv):
    bas, hedef, agirlik = graf
    duvar, islemci = [], []
    for k in range(tekrar + 1):          # k = 0: ısınma
        sayac_sifirla()
        t0, c0 = zaman_sn(), islemci_sn()
        if surum == "dizi":
            d = dijkstra_dizi(n, bas, hedef, agirlik)
        elif surum == "elle":
            d = dijkstra_obek(n, bas, hedef, agirlik, elle_ekle, elle_cikar)
        else:
            d = dijkstra_obek(n, bas, hedef, agirlik, heapq.heappush,
                              heapq.heappop)
        if k > 0:
            duvar.append((zaman_sn() - t0) * 1000.0)
            islemci.append((islemci_sn() - c0) * 1000.0)
    toplam = ulasilan = 0
    for x in d:
        if x != SONSUZ:
            toplam += x
            ulasilan += 1
    e = bas[n]
    print(f"{surum} {agirlik_tur} V={n} D={d_p} E={e} itme={sayac['itme']} "
          f"cikarma={sayac['cikarma']} atlanan={sayac['atlanan']} "
          f"gevsetme={sayac['gevsetme']} inceleme={sayac['inceleme']} "
          f"taranan={sayac['taranan']} ulasilan={ulasilan} toplam={toplam}")
    o_duvar, o_islemci = ortanca(duvar), ortanca(islemci)
    print(f"  Python {surum} {agirlik_tur} V={n} D={d_p}: {o_duvar:.3f} ms",
          file=sys.stderr)
    if csv:
        with open(csv, "a", encoding="utf-8") as f:
            f.write(f"py;{surum};{agirlik_tur};{n};{d_p};{e};{tekrar};"
                    f"{o_duvar:.4f};{min(duvar):.4f};{max(duvar):.4f};"
                    f"{o_islemci:.4f};{sayac['itme']};{sayac['cikarma']};"
                    f"{sayac['atlanan']};{sayac['gevsetme']};"
                    f"{sayac['inceleme']};{sayac['taranan']};{ulasilan};"
                    f"{toplam};olcum\n")


def main():
    a = sys.argv
    try:
        n, d_p, tekrar = int(a[1]), int(a[2]), int(a[5])
        if (len(a) not in (6, 7) or not 2 <= n <= 100000 or
                not 1 <= d_p <= 100000 or not 1 <= tekrar <= 51 or
                a[3] not in ("lcg", "kotu") or
                a[4] not in ("dizi", "elle", "kutuphane", "hepsi")):
            raise ValueError
    except (IndexError, ValueError):
        print("Kullanım: H12_deney_dijkstra V D lcg|kotu "
              "dizi|elle|kutuphane|hepsi TEKRAR [CSV]", file=sys.stderr)
        sys.exit(2)
    graf = graf_uret(n, d_p, a[3] == "kotu")
    csv = a[6] if len(a) == 7 else None
    for s in ("dizi", "elle", "kutuphane"):
        if a[4] in ("hepsi", s):
            olc(s, a[3], n, d_p, graf, tekrar, csv)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: Python — heapq (bu deneyde etiketli "kutuphane"
# serisi olarak ölçülür).

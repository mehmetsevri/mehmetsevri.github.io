/* H12_deney_dijkstra.c — AP-2 Hafta 12 · Haftanın Deneyi (C)
 * Amaç    : Dizi tabanlı O(V²) Dijkstra ile öbek tabanlı (tembel silmeli)
 *           O((V + E) log V) Dijkstra'nın süresi ve sayaçları; seyrek ve
 *           yoğun graflar, rastgele (LCG) ve kötü durum ağırlıkları
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_deney_dijkstra.c \
 *           ortak_rastgele.c zamanlayici.c -o H12_deney_dijkstra
 * Çalıştır: ./H12_deney_dijkstra V D AGIRLIK SURUM TEKRAR [CSV]
 *           AGIRLIK: lcg  — her u için u -> u+1 (halka) + D-1 rastgele hedef,
 *                           ağırlık 1..1000 (tohum 42); E = V·D
 *                    kotu — bant DAG: u -> v (u < v <= u + D), ağırlık
 *                           2(v - u) - 1: her gevşetme başarılı, itme = E + 1
 *           SURUM  : dizi | elle (öbek) | hepsi;  TEKRAR: ısınma sonrası
 * Çıktı   : stdout'a deterministik sayaçlar (dillerin karşılaştırması için),
 *           CSV'ye süreler (ms; duvar saati ve işlemci zamanı ortancası)
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define SONSUZ INT_MAX
#define EN_COK_TEKRAR 51

typedef struct {               /* CSR: u'nun kenarları bas[u]..bas[u+1]-1 */
    int v_sayisi;
    long long e_sayisi;
    long long *bas;
    int *hedef, *agirlik;
} Graf;

typedef struct {
    long long itme, cikarma, atlanan, gevsetme, inceleme, taranan;
} Sayac;

typedef struct {
    int uzaklik, kose;
} Oge;

typedef struct {
    Oge *a;
    long long n, kapasite;
} Obek;

static Sayac sayac;

/* Sahiplik: dönen grafın dizileri graf_yok_et ile serbest bırakılır */
static bool graf_uret(Graf *g, int v_sayisi, int d, bool kotu)
{
    g->v_sayisi = v_sayisi;
    g->hedef = NULL;
    g->agirlik = NULL;
    g->bas = malloc(((size_t)v_sayisi + 1) * sizeof *g->bas);
    if (g->bas == NULL) {
        return false;
    }
    g->bas[0] = 0;
    for (int u = 0; u < v_sayisi; u++) {
        long long k = d;
        if (kotu) {
            k = (long long)v_sayisi - 1 - u < d ? v_sayisi - 1 - u : d;
        }
        g->bas[u + 1] = g->bas[u] + k;
    }
    g->e_sayisi = g->bas[v_sayisi];
    size_t m = (size_t)(g->e_sayisi > 0 ? g->e_sayisi : 1);
    g->hedef = malloc(m * sizeof *g->hedef);
    g->agirlik = malloc(m * sizeof *g->agirlik);
    if (g->hedef == NULL || g->agirlik == NULL) {
        return false;
    }
    rastgele_tohum(42);
    for (int u = 0; u < v_sayisi; u++) {
        long long k = g->bas[u];
        if (kotu) {
            for (int v = u + 1; k < g->bas[u + 1]; v++, k++) {
                g->hedef[k] = v;
                g->agirlik[k] = 2 * (v - u) - 1;
            }
            continue;
        }
        g->hedef[k] = (u + 1) % v_sayisi;
        g->agirlik[k] = rastgele_aralik(1, 1000);
        for (k++; k < g->bas[u + 1]; k++) {
            g->hedef[k] = rastgele_aralik(0, v_sayisi - 1);
            g->agirlik[k] = rastgele_aralik(1, 1000);
        }
    }
    return true;
}

static void graf_yok_et(Graf *g)
{
    free(g->bas);
    free(g->hedef);
    free(g->agirlik);
}

/* O(V²): d[] dizisinde doğrusal en küçük arama */
static void dijkstra_dizi(const Graf *g, int *d, bool *kesin)
{
    int n = g->v_sayisi;
    for (int v = 0; v < n; v++) {
        d[v] = SONSUZ;
        kesin[v] = false;
    }
    d[0] = 0;
    for (int adim = 0; adim < n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {
            sayac.taranan++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;
        }
        kesin[u] = true;
        for (long long k = g->bas[u]; k < g->bas[u + 1]; k++) {
            int v = g->hedef[k];
            sayac.inceleme++;
            if (!kesin[v] && d[u] + g->agirlik[k] < d[v]) {
                d[v] = d[u] + g->agirlik[k];
                sayac.gevsetme++;
            }
        }
    }
}

static bool kucuk_mu(Oge x, Oge y)
{
    return x.uzaklik < y.uzaklik || (x.uzaklik == y.uzaklik && x.kose < y.kose);
}

static bool obege_ekle(Obek *o, Oge x)
{
    if (o->n == o->kapasite) {
        long long yeni = o->kapasite == 0 ? 1024 : 2 * o->kapasite;
        Oge *gecici = realloc(o->a, (size_t)yeni * sizeof *gecici);
        if (gecici == NULL) {
            return false;
        }
        o->a = gecici;
        o->kapasite = yeni;
    }
    long long i = o->n++;
    while (i > 0 && kucuk_mu(x, o->a[(i - 1) / 2])) {     /* yukarı süz */
        o->a[i] = o->a[(i - 1) / 2];
        i = (i - 1) / 2;
    }
    o->a[i] = x;
    sayac.itme++;
    return true;
}

static Oge en_kucugu_cikar(Obek *o)
{
    Oge en_kucuk = o->a[0], son = o->a[--o->n];
    long long i = 0;
    while (2 * i + 1 < o->n) {                             /* aşağı süz */
        long long c = 2 * i + 1;
        if (c + 1 < o->n && kucuk_mu(o->a[c + 1], o->a[c])) {
            c++;
        }
        if (!kucuk_mu(o->a[c], son)) {
            break;
        }
        o->a[i] = o->a[c];
        i = c;
    }
    o->a[i] = son;
    sayac.cikarma++;
    return en_kucuk;
}

/* O((V + E) log V): (uzaklık, köşe) öbeği, tembel silme */
static bool dijkstra_obek(const Graf *g, int *d, bool *kesin, Obek *obek)
{
    int n = g->v_sayisi;
    for (int v = 0; v < n; v++) {
        d[v] = SONSUZ;
        kesin[v] = false;
    }
    d[0] = 0;
    obek->n = 0;
    if (!obege_ekle(obek, (Oge){0, 0})) {
        return false;
    }
    while (obek->n > 0) {
        int u = en_kucugu_cikar(obek).kose;
        if (kesin[u]) {
            sayac.atlanan++;
            continue;
        }
        kesin[u] = true;
        for (long long k = g->bas[u]; k < g->bas[u + 1]; k++) {
            int v = g->hedef[k];
            sayac.inceleme++;
            if (!kesin[v] && d[u] + g->agirlik[k] < d[v]) {
                d[v] = d[u] + g->agirlik[k];
                sayac.gevsetme++;
                if (!obege_ekle(obek, (Oge){d[v], v})) {
                    return false;
                }
            }
        }
    }
    return true;
}

static int olc(const char *surum, const char *agirlik, const Graf *g, int d_p,
               int tekrar, FILE *csv)
{
    int n = g->v_sayisi;
    int *d = malloc((size_t)n * sizeof *d);
    bool *kesin = malloc((size_t)n * sizeof *kesin);
    Obek obek = {NULL, 0, 0};
    double duvar[EN_COK_TEKRAR], islemci[EN_COK_TEKRAR];
    bool dizi = strcmp(surum, "dizi") == 0;
    if (d == NULL || kesin == NULL) {
        free(d);
        free(kesin);
        return 1;
    }
    for (int k = 0; k <= tekrar; k++) {  /* k = 0: ısınma */
        memset(&sayac, 0, sizeof sayac);
        double t0 = zaman_sn(), c0 = islemci_sn();
        if (dizi) {
            dijkstra_dizi(g, d, kesin);
        } else if (!dijkstra_obek(g, d, kesin, &obek)) {
            fprintf(stderr, "bellek yetersiz\n");
            free(d);
            free(kesin);
            free(obek.a);
            return 1;
        }
        if (k > 0) {
            duvar[k - 1] = (zaman_sn() - t0) * 1000.0;
            islemci[k - 1] = (islemci_sn() - c0) * 1000.0;
        }
    }
    long long toplam = 0, ulasilan = 0;
    for (int v = 0; v < n; v++) {
        if (d[v] != SONSUZ) {
            toplam += d[v];
            ulasilan++;
        }
    }
    printf("%s %s V=%d D=%d E=%lld itme=%lld cikarma=%lld atlanan=%lld "
           "gevsetme=%lld inceleme=%lld taranan=%lld ulasilan=%lld "
           "toplam=%lld\n", surum, agirlik, n, d_p, g->e_sayisi, sayac.itme,
           sayac.cikarma, sayac.atlanan, sayac.gevsetme, sayac.inceleme,
           sayac.taranan, ulasilan, toplam);
    double en_az = duvar[0], en_cok = duvar[0];
    for (int k = 1; k < tekrar; k++) {
        en_az = duvar[k] < en_az ? duvar[k] : en_az;
        en_cok = duvar[k] > en_cok ? duvar[k] : en_cok;
    }
    double o_duvar = ortanca(duvar, tekrar);
    double o_islemci = ortanca(islemci, tekrar);
    fprintf(stderr, "  C %s %s V=%d D=%d: %.3f ms\n", surum, agirlik, n, d_p,
            o_duvar);
    if (csv != NULL) {
        fprintf(csv, "c;%s;%s;%d;%d;%lld;%d;%.4f;%.4f;%.4f;%.4f;%lld;%lld;"
                     "%lld;%lld;%lld;%lld;%lld;%lld;olcum\n", surum, agirlik,
                n, d_p, g->e_sayisi, tekrar, o_duvar, en_az, en_cok,
                o_islemci, sayac.itme, sayac.cikarma, sayac.atlanan,
                sayac.gevsetme, sayac.inceleme, sayac.taranan, ulasilan,
                toplam);
    }
    free(d);
    free(kesin);
    free(obek.a);
    return 0;
}

static bool sayi_al(const char *s, long long alt, long long ust, int *x)
{
    char *son;
    long long v = strtoll(s, &son, 10);
    if (*s == '\0' || *son != '\0' || v < alt || v > ust) {
        return false;
    }
    *x = (int)v;
    return true;
}

int main(int argc, char **argv)
{
    int v_sayisi, d, tekrar;
    if ((argc != 6 && argc != 7) || !sayi_al(argv[1], 2, 100000, &v_sayisi) ||
        !sayi_al(argv[2], 1, 100000, &d) ||
        !sayi_al(argv[5], 1, EN_COK_TEKRAR, &tekrar) ||
        (strcmp(argv[3], "lcg") != 0 && strcmp(argv[3], "kotu") != 0) ||
        (strcmp(argv[4], "dizi") != 0 && strcmp(argv[4], "elle") != 0 &&
         strcmp(argv[4], "hepsi") != 0)) {
        fprintf(stderr, "Kullanım: H12_deney_dijkstra V D lcg|kotu "
                        "dizi|elle|hepsi TEKRAR [CSV]\n");
        return 2;
    }
    Graf g;
    if (!graf_uret(&g, v_sayisi, d, strcmp(argv[3], "kotu") == 0)) {
        fprintf(stderr, "bellek yetersiz\n");
        graf_yok_et(&g);
        return 1;
    }
    FILE *csv = NULL;
    if (argc == 7 && (csv = fopen(argv[6], "a")) == NULL) {
        fprintf(stderr, "CSV açılamadı: %s\n", argv[6]);
        graf_yok_et(&g);
        return 1;
    }
    int hata = 0;
    if (strcmp(argv[4], "elle") != 0) {
        hata |= olc("dizi", argv[3], &g, d, tekrar, csv);
    }
    if (strcmp(argv[4], "dizi") != 0) {
        hata |= olc("elle", argv[3], &g, d, tekrar, csv);
    }
    if (csv != NULL) {
        fclose(csv);
    }
    graf_yok_et(&g);
    return hata;
}

/* Kütüphane karşılığı: C — öncelik kuyruğu yok (öbek elle, H7). */

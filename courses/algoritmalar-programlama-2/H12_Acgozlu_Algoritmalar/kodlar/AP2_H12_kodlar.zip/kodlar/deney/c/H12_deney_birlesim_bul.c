/* H12_deney_birlesim_bul.c — AP-2 Hafta 12 · Haftanın Deneyi, ek (C)
 * Amaç    : Birleşim–bul sürümlerinin (saf, yalnız rütbe, yalnız yol
 *           sıkıştırma, ikisi birden) işlem başına işaretçi izleme sayısı ve
 *           süresi; n rastgele birleştirme + n rastgele bul (3n bul çağrısı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_deney_birlesim_bul.c \
 *           ortak_rastgele.c zamanlayici.c -o H12_deney_birlesim_bul
 * Çalıştır: ./H12_deney_birlesim_bul N saf|rutbe|sikistirma|ikisi|hepsi
 *           TEKRAR [CSV]
 * Çıktı   : stdout'a deterministik sayaçlar, CSV'ye süreler (ms). İşlem
 *           dizisi ölçümden önce üretilir (LCG ölçüme girmez).
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

static const char *const SURUM[4] = {"saf", "rutbe", "sikistirma", "ikisi"};
static long long izleme = 0, baglama = 0;

typedef struct {
    int *ebeveyn, *rutbe;
    int n;
    bool rutbeli, sikistir;
} BirlesimBul;

static int bul(BirlesimBul *b, int x)
{
    int kok = x;
    while (b->ebeveyn[kok] != kok) {
        kok = b->ebeveyn[kok];
        izleme++;
    }
    if (b->sikistir) {
        while (b->ebeveyn[x] != kok) {
            int sonraki = b->ebeveyn[x];
            b->ebeveyn[x] = kok;
            baglama++;
            x = sonraki;
        }
    }
    return kok;
}

static void birlestir(BirlesimBul *b, int x, int y)
{
    int kx = bul(b, x), ky = bul(b, y);
    if (kx == ky) {
        return;
    }
    if (!b->rutbeli) {
        b->ebeveyn[kx] = ky;
        return;
    }
    if (b->rutbe[kx] < b->rutbe[ky]) {
        int g = kx;
        kx = ky;
        ky = g;
    }
    b->ebeveyn[ky] = kx;
    if (b->rutbe[kx] == b->rutbe[ky]) {
        b->rutbe[kx]++;
    }
}

static int yukseklik(const BirlesimBul *b, int *derinlik, int *yigin)
{
    int en_cok = 0;
    for (int x = 0; x < b->n; x++) {
        derinlik[x] = -1;
    }
    for (int x = 0; x < b->n; x++) {
        int v = x, tepe = 0;
        while (derinlik[v] < 0 && b->ebeveyn[v] != v) {
            yigin[tepe++] = v;
            v = b->ebeveyn[v];
        }
        if (derinlik[v] < 0) {
            derinlik[v] = 0;
        }
        while (tepe > 0) {
            int u = yigin[--tepe];
            derinlik[u] = derinlik[b->ebeveyn[u]] + 1;
        }
        en_cok = derinlik[x] > en_cok ? derinlik[x] : en_cok;
    }
    return en_cok;
}

static int olc(int s, int n, const int *x, const int *y, const int *q,
               int tekrar, FILE *csv)
{
    BirlesimBul b = {malloc((size_t)n * sizeof(int)),
                     malloc((size_t)n * sizeof(int)), n, s == 1 || s == 3,
                     s == 2 || s == 3};
    int *derinlik = malloc((size_t)n * sizeof *derinlik);
    int *yigin = malloc((size_t)n * sizeof *yigin);
    double duvar[51], islemci[51];
    if (b.ebeveyn == NULL || b.rutbe == NULL || derinlik == NULL ||
        yigin == NULL) {
        free(b.ebeveyn);
        free(b.rutbe);
        free(derinlik);
        free(yigin);
        return 1;
    }
    for (int k = 0; k <= tekrar; k++) {  /* k = 0: ısınma */
        izleme = baglama = 0;
        double t0 = zaman_sn(), c0 = islemci_sn();
        for (int i = 0; i < n; i++) {
            b.ebeveyn[i] = i;
            b.rutbe[i] = 0;
        }
        for (int i = 0; i < n; i++) {
            birlestir(&b, x[i], y[i]);
        }
        for (int i = 0; i < n; i++) {
            bul(&b, q[i]);
        }
        if (k > 0) {
            duvar[k - 1] = (zaman_sn() - t0) * 1000.0;
            islemci[k - 1] = (islemci_sn() - c0) * 1000.0;
        }
    }
    int kume = 0;
    for (int i = 0; i < n; i++) {
        kume += b.ebeveyn[i] == i;
    }
    int h = yukseklik(&b, derinlik, yigin);
    printf("%s n=%d izleme=%lld baglama=%lld kume=%d yukseklik=%d\n",
           SURUM[s], n, izleme, baglama, kume, h);
    double en_az = duvar[0], en_cok = duvar[0];
    for (int k = 1; k < tekrar; k++) {
        en_az = duvar[k] < en_az ? duvar[k] : en_az;
        en_cok = duvar[k] > en_cok ? duvar[k] : en_cok;
    }
    double o_duvar = ortanca(duvar, tekrar);
    double o_islemci = ortanca(islemci, tekrar);
    fprintf(stderr, "  C %s n=%d: %.3f ms\n", SURUM[s], n, o_duvar);
    if (csv != NULL) {
        fprintf(csv, "c;%s;%d;%lld;%d;%.4f;%.4f;%.4f;%.4f;%lld;%lld;%d;%d;"
                     "olcum\n", SURUM[s], n, 3LL * n, tekrar, o_duvar, en_az,
                en_cok, o_islemci, izleme, baglama, kume, h);
    }
    free(b.ebeveyn);
    free(b.rutbe);
    free(derinlik);
    free(yigin);
    return 0;
}

int main(int argc, char **argv)
{
    char *son;
    long n = argc > 1 ? strtol(argv[1], &son, 10) : 0;
    long tekrar = argc > 3 ? strtol(argv[3], &son, 10) : 0;
    int secim = -2;
    if (argc > 2) {
        for (int s = 0; s < 4; s++) {
            if (strcmp(argv[2], SURUM[s]) == 0) {
                secim = s;
            }
        }
        if (strcmp(argv[2], "hepsi") == 0) {
            secim = -1;
        }
    }
    if ((argc != 4 && argc != 5) || n < 2 || n > 10000000 || tekrar < 1 ||
        tekrar > 51 || secim == -2) {
        fprintf(stderr, "Kullanım: H12_deney_birlesim_bul N "
                        "saf|rutbe|sikistirma|ikisi|hepsi TEKRAR [CSV]\n");
        return 2;
    }
    int *x = malloc((size_t)n * sizeof *x);
    int *y = malloc((size_t)n * sizeof *y);
    int *q = malloc((size_t)n * sizeof *q);
    FILE *csv = argc == 5 ? fopen(argv[4], "a") : NULL;
    if (x == NULL || y == NULL || q == NULL || (argc == 5 && csv == NULL)) {
        fprintf(stderr, "bellek ya da CSV hatası\n");
        free(x);
        free(y);
        free(q);
        return 1;
    }
    rastgele_tohum(42);                  /* işlem dizisi (ölçüm dışı) */
    for (long i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, (int)n - 1);
        y[i] = rastgele_aralik(0, (int)n - 1);
    }
    for (long i = 0; i < n; i++) {
        q[i] = rastgele_aralik(0, (int)n - 1);
    }
    int hata = 0;
    for (int s = 0; s < 4; s++) {
        if (secim == -1 || secim == s) {
            hata |= olc(s, (int)n, x, y, q, (int)tekrar, csv);
        }
    }
    if (csv != NULL) {
        fclose(csv);
    }
    free(x);
    free(y);
    free(q);
    return hata;
}

/* Kütüphane karşılığı: C — yok (ayrık küme yapısı standart kütüphanede
 * yok). */

#!/usr/bin/env python3
"""h12_olcum_calistir.py — AP-2 Hafta 12 · Haftanın Deneyi sürücüsü

Derler, çalıştırır ve ham sonuçları sonuclar/*.csv dosyalarına yazar:
  (a) h12_deney_dijkstra_olcek.csv     V = 10³…10⁴ (öbek: 2·10⁴'e dek);
      seyrek (D = 4: E = 4V) ve yoğun (D = V/2: E = V²/2) rastgele graflar
  (b) h12_deney_dijkstra_yogunluk.csv  V sabit (C/C++ 2000, Python 500),
      D = 2 … V−1: rastgele (lcg) ve kötü durum (kotu: bant DAG, her
      gevşetme başarılı) ağırlıklarla kesişim noktası
  (c) h12_deney_birlesim_bul.csv       n = 10⁴…10⁶: dört sürüm
Ölçüm: 1 ısınma + 5 tekrar, ortanca; duvar saati ve işlemci zamanı. Yayılımı
büyük (en çok / en az > 2) ya da duvar saati işlemci zamanından belirgin
uzun (duvar / işlemci > 1,3: süreç başka işler yüzünden bekletilmiş) olan
ölçüm (ortanca > 2 ms) bir kez yinelenir.
Ortam: OLCUM_ORTAMI.txt; dillerin sayaç denetimi: sonuclar/h12_denetim.json.
Kullanım: python3 h12_olcum_calistir.py      (≈ 3–4 dk)
Sonra   : python3 h12_cozumle.py ; python3 ../../gorseller/kaynak/
          h12_deney_grafik.py
"""
import datetime
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import tempfile
import time

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic", "-O2"]
CPP = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic", "-O2"]
TEKRAR = "5"
BASLIK_D = ("dil;surum;agirlik;V;D;E;tekrar;ortanca_ms;en_az_ms;en_cok_ms;"
            "islemci_ortanca_ms;itme;cikarma;atlanan;gevsetme;inceleme;"
            "taranan;ulasilan;uzaklik_toplami;olcum\n")
BASLIK_B = ("dil;surum;n;islem;tekrar;ortanca_ms;en_az_ms;en_cok_ms;"
            "islemci_ortanca_ms;izleme;baglama;kume;yukseklik;olcum\n")
LOG = []
YINELENEN = []


def derle(gecici):
    ikili = {}
    for ad in ("H12_deney_dijkstra", "H12_deney_birlesim_bul"):
        hedef = os.path.join(gecici, ad + "_c")
        p = subprocess.run(C + [os.path.join(KOK, "c", ad + ".c"),
                                os.path.join(KOK, "c", "ortak_rastgele.c"),
                                os.path.join(KOK, "c", "zamanlayici.c"),
                                "-o", hedef], capture_output=True, text=True)
        assert p.returncode == 0 and not p.stderr.strip(), p.stderr
        ikili[(ad, "c")] = [hedef]
        hedef = os.path.join(gecici, ad + "_cpp")
        p = subprocess.run(CPP + [os.path.join(KOK, "cpp", ad + ".cpp"),
                                  "-I" + os.path.join(KOK, "cpp"),
                                  "-o", hedef], capture_output=True, text=True)
        assert p.returncode == 0 and not p.stderr.strip(), p.stderr
        ikili[(ad, "cpp")] = [hedef]
        ikili[(ad, "py")] = [sys.executable,
                             os.path.join(KOK, "python", ad + ".py")]
    return ikili


def son_satir(csv):
    with open(csv, encoding="utf-8") as f:
        return f.read().rstrip("\n").split("\n")


def kos(komut, csv):
    """Programı çalıştırır; yayılımı büyük satırları bir kez yineler.
    Deterministik stdout satırlarını döndürür."""
    once = len(son_satir(csv))
    p = subprocess.run(komut + [csv], capture_output=True, text=True,
                       env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    if p.returncode != 0:
        sys.exit(f"HATA: {' '.join(komut)}\n{p.stderr}")
    LOG.append(p.stderr.rstrip())
    satirlar = son_satir(csv)
    yeni = satirlar[once:]
    sorunlu = False
    for s in yeni:
        a = s.split(";")
        if len(a) > 14:                  # Dijkstra CSV: ortanca 7. sütun
            o, en_az, en_cok, isl = (float(a[7]), float(a[8]), float(a[9]),
                                     float(a[10]))
        else:                            # birleşim–bul CSV: 5. sütun
            o, en_az, en_cok, isl = (float(a[5]), float(a[6]), float(a[7]),
                                     float(a[8]))
        if o > 2.0 and (en_cok > 2.0 * en_az or o > 1.3 * isl):
            sorunlu = True
    if sorunlu:                          # bir kez yinele, eskisini at
        with open(csv, "w", encoding="utf-8") as f:
            f.write("\n".join(satirlar[:once]) + "\n")
        p = subprocess.run(komut + [csv], capture_output=True, text=True,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        YINELENEN.append(" ".join(os.path.basename(x) for x in komut[-6:]))
        LOG.append("(yinelendi) " + p.stderr.rstrip())
    return p.stdout.strip().split("\n")


def main():
    os.makedirs(SONUC, exist_ok=True)
    bas = time.time()
    yuk_once = open("/proc/loadavg").read().split()[:3]
    tarih_bas = datetime.datetime.now()
    gecici = tempfile.mkdtemp(prefix="h12_deney_")
    evre = {}
    sayaclar = {}                        # (dil, yapılandırma) -> satırlar
    try:
        t = time.time()
        ikili = derle(gecici)
        evre["derleme"] = time.time() - t
        olcek = os.path.join(SONUC, "h12_deney_dijkstra_olcek.csv")
        yogun = os.path.join(SONUC, "h12_deney_dijkstra_yogunluk.csv")
        bb = os.path.join(SONUC, "h12_deney_birlesim_bul.csv")
        for yol, baslik in ((olcek, BASLIK_D), (yogun, BASLIK_D),
                            (bb, BASLIK_B)):
            with open(yol, "w", encoding="utf-8") as f:
                f.write(baslik)
        dj = "H12_deney_dijkstra"
        # (a) V ölçeklemesi
        t = time.time()
        for dil in ("c", "cpp", "py"):
            seyrek = [1000, 2000, 5000, 10000] if dil != "py" else \
                [1000, 2000, 5000]
            for v in seyrek:
                sayaclar[(dil, f"seyrek V={v}")] = kos(
                    ikili[(dj, dil)] + [str(v), "4", "lcg", "hepsi", TEKRAR],
                    olcek)
            yalniz_obek = [20000] if dil != "py" else [10000, 20000]
            for v in yalniz_obek:
                for s in ("elle", "kutuphane") if dil != "c" else ("elle",):
                    sayaclar[(dil, f"seyrek V={v} {s}")] = kos(
                        ikili[(dj, dil)] + [str(v), "4", "lcg", s, TEKRAR],
                        olcek)
            yogunlar = [1000, 2000, 5000, 10000] if dil != "py" else \
                [500, 1000, 2000]
            for v in yogunlar:
                sayaclar[(dil, f"yogun V={v}")] = kos(
                    ikili[(dj, dil)] + [str(v), str(v // 2), "lcg", "hepsi",
                                        TEKRAR], olcek)
        evre["(a) ölçekleme"] = time.time() - t
        # (b) yoğunluk taraması
        t = time.time()
        for dil in ("c", "cpp", "py"):
            v = 2000 if dil != "py" else 500
            dler = [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 1999] \
                if dil != "py" else [2, 4, 8, 16, 32, 64, 128, 256, 499]
            for agirlik in ("lcg", "kotu"):
                for d in dler:
                    sayaclar[(dil, f"tarama V={v} D={d} {agirlik}")] = kos(
                        ikili[(dj, dil)] + [str(v), str(d), agirlik, "hepsi",
                                            TEKRAR], yogun)
        # dillerarası sayaç denetimi için Python'un V = 500 taraması C'de de
        for d in (4, 64, 499):
            for agirlik in ("lcg", "kotu"):
                for dil in ("c", "cpp"):
                    p = subprocess.run(ikili[(dj, dil)] + [
                        "500", str(d), agirlik, "hepsi", "1"],
                        capture_output=True, text=True)
                    sayaclar[(dil, f"tarama V=500 D={d} {agirlik}")] = \
                        p.stdout.strip().split("\n")
        evre["(b) yoğunluk taraması"] = time.time() - t
        # (c) birleşim–bul
        t = time.time()
        bul = "H12_deney_birlesim_bul"
        for dil in ("c", "cpp", "py"):
            nler = [10000, 30000, 100000, 300000, 1000000] if dil != "py" \
                else [10000, 30000, 100000, 300000]
            for n in nler:
                surumler = ["rutbe", "sikistirma", "ikisi"]
                if n <= (30000 if dil != "py" else 10000):
                    surumler = ["saf"] + surumler
                for s in surumler:
                    sayaclar.setdefault((dil, f"bb n={n}"), []).extend(kos(
                        ikili[(bul, dil)] + [str(n), s, TEKRAR], bb))
        evre["(c) birleşim–bul"] = time.time() - t
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    toplam = time.time() - bas
    rss = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss // 1024
    yuk_sonra = open("/proc/loadavg").read().split()[:3]
    # dillerarası denetim: aynı yapılandırmanın sayaç satırları
    denetim = {}
    anahtarlar = sorted({k for _, k in sayaclar})
    for k in anahtarlar:
        diller = {d: sayaclar[(d, k)] for d in ("c", "cpp", "py")
                  if (d, k) in sayaclar}
        if len(diller) < 2:
            continue
        ortak = None
        tamam = True
        for d, satirlar in diller.items():
            s = {x.replace("kutuphane", "elle") for x in satirlar}
            if ortak is None:
                ortak = s
            elif not (s <= ortak or ortak <= s):
                tamam = False
        denetim[k] = {"diller": sorted(diller), "ayni": tamam}
    with open(os.path.join(SONUC, "h12_denetim.json"), "w",
              encoding="utf-8") as f:
        json.dump({"sayac_denetimi": denetim,
                   "yinelenen_olcumler": YINELENEN,
                   "evre_sn": {k: round(v, 1) for k, v in evre.items()},
                   "toplam_sn": round(toplam, 1),
                   "en_buyuk_alt_surec_MB": rss}, f, ensure_ascii=False,
                  indent=1)
    lscpu = subprocess.run(["lscpu"], capture_output=True, text=True).stdout
    model = next((x.split(":", 1)[1].strip() for x in lscpu.splitlines()
                  if x.startswith("Model name")), platform.processor())
    gcc = subprocess.run(["gcc", "--version"], capture_output=True,
                         text=True).stdout.splitlines()[0]
    gpp = subprocess.run(["g++", "--version"], capture_output=True,
                         text=True).stdout.splitlines()[0]
    tarih_son = datetime.datetime.now()
    satirlar = [
        "AP-2 Hafta 12 · Haftanın Deneyi — ölçüm ortamı",
        f"Tarih          : {tarih_bas:%Y-%m-%d %H:%M} – {tarih_son:%H:%M}",
        f"İşlemci        : {model}",
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine)",
        f"Yük ortalaması : önce {' '.join(yuk_once)} · sonra "
        f"{' '.join(yuk_sonra)} (/proc/loadavg: 1, 5, 15 dk)",
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})",
        f"C derleyicisi  : {gcc}",
        f"C++ derleyicisi: {gpp}",
        f"Python         : Python {platform.python_version()}",
        "Bayraklar      : -std=c17 / -std=c++17 -Wall -Wextra -pedantic -O2",
        "Yöntem         : 1 ısınma + 5 tekrar, ortanca; duvar saati ve "
        "işlemci zamanı birlikte kaydedildi",
        "Saat           : duvar C timespec_get, C++ steady_clock, Python "
        "time.perf_counter; işlemci C/C++ clock(), Python "
        "time.process_time",
        f"Bellek         : en büyük alt sürecin tepe yerleşik belleği {rss} "
        "MB (getrusage RUSAGE_CHILDREN, ru_maxrss)",
        f"Toplam süre    : {toplam:.1f} s (sürücünün duvar saati)",
        "Evre süreleri  : " + " · ".join(f"{k} {v:.1f} s"
                                         for k, v in evre.items()),
        f"Yinelenen      : {len(YINELENEN)} ölçüm (yayılım > 2 kat ya da "
        "duvar/işlemci > 1,3)",
        "Not            : makinede başka ajanlar da çalışıyordu (yük "
        "ortalamasına bakınız); süreler \"bu makinede ölçülen\" "
        "değerlerdir.",
    ]
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(satirlar) + "\n")
    with open(os.path.join(SONUC, "h12_olcum_gunlugu.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(LOG) + "\n")
    print("\n".join(satirlar))
    print("sayaç denetimi:", sum(v["ayni"] for v in denetim.values()), "/",
          len(denetim))


if __name__ == "__main__":
    main()

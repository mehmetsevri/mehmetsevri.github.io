#!/usr/bin/env python3
"""h12_cozumle.py — AP-2 Hafta 12 · Haftanın Deneyi çözümlemesi

Ham CSV'lerden (h12_olcum_calistir.py) oranları, log–log eğimleri,
kesişim noktalarını ve kestirimleri HESAPLAR; hiçbir sayı elle yazılmaz.
Çıktı: sonuclar/h12_ozet.json, sonuclar/h12_ozet_olcek.csv,
       sonuclar/h12_ozet_kesisim.csv, sonuclar/h12_ozet_birlesim_bul.csv
Kullanım: python3 h12_cozumle.py
"""
import csv
import json
import math
import os

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
DIL_AD = {"c": "C", "cpp": "C++", "py": "Python"}


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def egim(x, y):
    """En küçük kareler: log y = a + b log x; b döndürülür"""
    lx = [math.log(v) for v in x]
    ly = [math.log(v) for v in y]
    mx, my = sum(lx) / len(lx), sum(ly) / len(ly)
    pay = sum((a - mx) * (b - my) for a, b in zip(lx, ly))
    payda = sum((a - mx) ** 2 for a in lx)
    return pay / payda


KARARLILIK = 0.10   # kesişimden sonra oran 1'den en az %10 uzaklaşmalı


def kesisim(noktalar):
    """noktalar: (E, t_dizi, t_obek) artan E. t_obek/t_dizi oranının 1'i
    geçtiği iki komşu nokta arasında log E – log oran doğrusal
    aradeğerlemesiyle E*. Kesişim yoksa (None, None).
    İkinci değer kararlılıktır: kesişimden sonra en az iki nokta var, BÜTÜN
    bu noktalar 1'in öbür yanında kalıyor ve son nokta 1'den en az %10
    uzaklaşıyorsa True; değilse (oran 1 çevresinde gidip geliyor ya da
    kesişim yalnız son noktaya dayanıyorsa) False — belirsiz kesişim."""
    for i, ((e1, d1, o1), (e2, d2, o2)) in enumerate(zip(noktalar,
                                                         noktalar[1:])):
        r1, r2 = math.log(o1 / d1), math.log(o2 / d2)
        if r1 < 0 <= r2 or r1 > 0 >= r2:
            t = r1 / (r1 - r2)
            e_star = math.exp(math.log(e1) + t * (math.log(e2) -
                                                  math.log(e1)))
            sonra = [math.log(o / d) for _, d, o in noktalar[i + 1:]]
            isaret = 1 if r2 >= 0 else -1
            kararli = (len(sonra) >= 2 and
                       all(x * isaret >= 0 for x in sonra) and
                       abs(sonra[-1]) >= math.log(1 + KARARLILIK))
            return e_star, kararli
    return None, None


def main():
    ozet = {}
    # ---------------- (a) ölçekleme ----------------
    olcek = oku("h12_deney_dijkstra_olcek.csv")
    seri = {}
    for r in olcek:
        tur = "seyrek" if r["D"] == "4" else "yogun"
        seri.setdefault((r["dil"], r["surum"], tur), []).append(
            (int(r["V"]), int(r["E"]), float(r["ortanca_ms"]),
             float(r["en_az_ms"]), float(r["en_cok_ms"]),
             float(r["islemci_ortanca_ms"])))
    egimler = {}
    satirlar = []
    for (dil, surum, tur), s in sorted(seri.items()):
        s.sort()
        v = [x[0] for x in s]
        t = [x[2] for x in s]
        b = egim(v, t) if len(s) >= 2 else None
        egimler[f"{dil}/{surum}/{tur}"] = round(b, 3) if b else None
        for x in s:
            satirlar.append([dil, surum, tur, x[0], x[1], f"{x[2]:.4f}",
                             f"{x[4] / x[3]:.3f}", "olcum"])
    # Python dizi V = 10⁴ (seyrek) ölçülmedi: c·V² kestirimi (V = 5000'den)
    kestirim = {}
    py = {x[0]: x[2] for x in seri.get(("py", "dizi", "seyrek"), [])}
    if 5000 in py:
        k = py[5000] * (10000 / 5000) ** 2
        kestirim["py/dizi/seyrek/V=10000"] = round(k, 1)
        satirlar.append(["py", "dizi", "seyrek", 10000, 40000, f"{k:.4f}",
                         "", "kestirim (c·V², V = 5000'den)"])
    with open(os.path.join(SONUC, "h12_ozet_olcek.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;surum;tur;V;E;ortanca_ms;en_cok_bolu_en_az;olcum\n")
        for s in satirlar:
            f.write(";".join(str(x) for x in s) + "\n")
    # dizi / öbek katları (aynı dil, aynı V)
    katlar = {}
    for (dil, surum, tur), s in seri.items():
        if surum != "dizi":
            continue
        for obek in ("elle", "kutuphane"):
            o = {x[0]: x[2] for x in seri.get((dil, obek, tur), [])}
            for x in s:
                if x[0] in o:
                    katlar[f"{dil}/{tur}/V={x[0]}/dizi÷{obek}"] = round(
                        x[2] / o[x[0]], 2)
    # kütüphane ÷ elle (C++, Python)
    kutup = {}
    for dil in ("cpp", "py"):
        oranlar = []
        for tur in ("seyrek", "yogun"):
            e = {x[0]: x[2] for x in seri.get((dil, "elle", tur), [])}
            for x in seri.get((dil, "kutuphane", tur), []):
                if x[0] in e:
                    oranlar.append(round(x[2] / e[x[0]], 3))
        oranlar.sort()
        kutup[dil] = {"oranlar": oranlar,
                      "ortanca": oranlar[len(oranlar) // 2] if oranlar
                      else None}
    # ardışık nokta katları (V × 2 ya da × 2,5)
    ardisik = {}
    for (dil, surum, tur), s in seri.items():
        s = sorted(s)
        ardisik[f"{dil}/{surum}/{tur}"] = [
            [a[0], b[0], round(b[2] / a[2], 2)] for a, b in zip(s, s[1:])]
    ozet["olcek"] = {"loglog_egim_V": egimler, "dizi_bolu_obek": katlar,
                     "kutuphane_bolu_elle": kutup,
                     "ardisik_katlar": ardisik, "kestirim": kestirim}
    # ---------------- (b) yoğunluk taraması ve kesişim ----------------
    tarama = oku("h12_deney_dijkstra_yogunluk.csv")
    tablo = {}
    for r in tarama:
        tablo.setdefault((r["dil"], r["agirlik"], int(r["V"])), {})[
            (int(r["D"]), r["surum"])] = r
    kes = {}
    kes_satir = []
    for (dil, agirlik, v), t in sorted(tablo.items()):
        dler = sorted({d for d, _ in t})
        log2v = math.log2(v)
        kuram = v * v / log2v
        for obek in ("elle", "kutuphane"):
            if (dler[0], obek) not in t:
                continue
            nok = [(int(t[(d, "dizi")]["E"]),
                    float(t[(d, "dizi")]["ortanca_ms"]),
                    float(t[(d, obek)]["ortanca_ms"])) for d in dler]
            e_star, kararli = kesisim(nok)
            # sabitlerle düzeltilmiş kestirim: dizi ≈ a·V² + b·E,
            # öbek ≈ c·itme·log2(itme) (+ kenar taraması b·E)
            en_kucuk = t[(dler[0], "dizi")]
            a_hucre = float(en_kucuk["ortanca_ms"]) / (v * v)
            buyuk = t[(dler[-1], obek)]
            itme = int(buyuk["itme"])
            c_islem = float(buyuk["ortanca_ms"]) / (itme * math.log2(itme))
            kayit = {
                "V": v, "kuramsal_E": round(kuram),
                "olculen_E": round(e_star) if e_star else None,
                "olculen_E_bolu_V": round(e_star / v, 1) if e_star else None,
                "olculen_bolu_kuramsal": round(e_star / kuram, 3)
                if e_star else None,
                "dizi_hucre_ns": round(a_hucre * 1e6, 3),
                "obek_itme_log_ns": round(c_islem * 1e6, 3),
                "itme_bolu_E_en_buyuk_D": round(itme / int(buyuk["E"]), 4),
                "son_oran_obek_bolu_dizi": round(nok[-1][2] / nok[-1][1], 3),
                "kararli": kararli,
            }
            if e_star is not None and not kararli:
                kayit["not"] = ("belirsiz kesişim: oran 1 çevresinde "
                                "gidip geliyor, son noktada 1'den "
                                f"%{KARARLILIK * 100:.0f}'dan az uzaklaşıyor "
                                "ya da yalnız son noktaya dayanıyor (son "
                                f"oran {nok[-1][2] / nok[-1][1]:.3f})")
            if agirlik == "kotu" and c_islem > 0:
                # c·E·log2(E) = a·V² → E'yi ikiye bölmeyle çöz
                alt, ust = 1.0, float(v * v)
                for _ in range(200):
                    orta = (alt + ust) / 2
                    if c_islem * orta * math.log2(orta) < a_hucre * v * v:
                        alt = orta
                    else:
                        ust = orta
                kayit["sabitli_kestirim_E"] = round(alt)
            if e_star is None:
                ilk = nok[0][2] / nok[0][1]
                son = nok[-1][2] / nok[-1][1]
                kayit["not"] = ("kesişim yok: öbek/dizi oranı "
                                f"{ilk:.3f} → {son:.3f} (bütün aralıkta "
                                + ("öbek hızlı" if son < 1 else "dizi hızlı")
                                + ")")
            kes[f"{dil}/{agirlik}/{obek}"] = kayit
            for d in dler:
                kes_satir.append([dil, agirlik, obek, v, d,
                                  t[(d, "dizi")]["E"],
                                  t[(d, "dizi")]["ortanca_ms"],
                                  t[(d, obek)]["ortanca_ms"],
                                  f"{float(t[(d, obek)]['ortanca_ms']) / float(t[(d, 'dizi')]['ortanca_ms']):.3f}",
                                  t[(d, obek)]["itme"],
                                  f"{int(t[(d, obek)]['itme']) / int(t[(d, 'dizi')]['E']):.4f}"])
    with open(os.path.join(SONUC, "h12_ozet_kesisim.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;agirlik;obek;V;D;E;dizi_ms;obek_ms;obek_bolu_dizi;"
                "itme;itme_bolu_E\n")
        for s in kes_satir:
            f.write(";".join(str(x) for x in s) + "\n")
    ozet["kesisim"] = kes
    # ---------------- (c) birleşim–bul ----------------
    bb = oku("h12_deney_birlesim_bul.csv")
    bb_satir = []
    bbo = {}
    for r in bb:
        n, islem = int(r["n"]), int(r["islem"])
        izl = int(r["izleme"]) / islem
        ns = float(r["ortanca_ms"]) * 1e6 / islem
        bb_satir.append([r["dil"], r["surum"], n, islem, r["izleme"],
                         f"{izl:.4f}", f"{ns:.2f}", r["yukseklik"],
                         r["kume"]])
        bbo.setdefault(f"{r['dil']}/{r['surum']}", []).append(
            [n, round(izl, 4), round(ns, 2), int(r["yukseklik"])])
    with open(os.path.join(SONUC, "h12_ozet_birlesim_bul.csv"), "w",
              encoding="utf-8") as f:
        f.write("dil;surum;n;islem;izleme;izleme_bolu_islem;ns_bolu_islem;"
                "yukseklik;kume\n")
        for s in bb_satir:
            f.write(";".join(str(x) for x in s) + "\n")
    # log2 n ve log* n karşılaştırması (yalnız bilgi)
    def log_yildiz(n):
        k = 0
        x = float(n)
        while x > 1:
            x = math.log2(x)
            k += 1
        return k
    ozet["birlesim_bul"] = {
        "seriler": bbo,
        "log2_n": {str(n): round(math.log2(n), 2)
                   for n in (10000, 30000, 100000, 300000, 1000000)},
        "log_yildiz_n": {str(n): log_yildiz(n)
                         for n in (10000, 30000, 100000, 300000, 1000000)},
    }
    # gürültü: yayılımı büyük satırlar
    gurultu = []
    for ad in ("h12_deney_dijkstra_olcek.csv",
               "h12_deney_dijkstra_yogunluk.csv"):
        for r in oku(ad):
            oran = float(r["en_cok_ms"]) / float(r["en_az_ms"])
            if oran > 1.5 and float(r["ortanca_ms"]) > 1:
                gurultu.append(f"{ad.split('_')[-1][:-4]}: {r['dil']} "
                               f"{r['surum']} {r['agirlik']} V={r['V']} "
                               f"D={r['D']}: en çok/en az = {oran:.2f}")
    for r in bb:
        oran = float(r["en_cok_ms"]) / float(r["en_az_ms"])
        if oran > 1.5 and float(r["ortanca_ms"]) > 1:
            gurultu.append(f"birlesim_bul: {r['dil']} {r['surum']} "
                           f"n={r['n']}: en çok/en az = {oran:.2f}")
    ozet["gurultu_yayilim_1_5_ustu"] = gurultu
    denetim = json.load(open(os.path.join(SONUC, "h12_denetim.json"),
                             encoding="utf-8"))
    ozet["sayac_denetimi"] = {
        "toplam": len(denetim["sayac_denetimi"]),
        "ayni": sum(v["ayni"] for v in denetim["sayac_denetimi"].values())}
    with open(os.path.join(SONUC, "h12_ozet.json"), "w",
              encoding="utf-8") as f:
        json.dump(ozet, f, ensure_ascii=False, indent=1)
    print(json.dumps({k: ozet[k] for k in ("kesisim",)}, ensure_ascii=False,
                     indent=1))
    print(json.dumps(ozet["olcek"]["loglog_egim_V"], ensure_ascii=False,
                     indent=1))
    print(json.dumps(ozet["olcek"]["kutuphane_bolu_elle"],
                     ensure_ascii=False))
    print("gürültü:", len(gurultu))


if __name__ == "__main__":
    main()

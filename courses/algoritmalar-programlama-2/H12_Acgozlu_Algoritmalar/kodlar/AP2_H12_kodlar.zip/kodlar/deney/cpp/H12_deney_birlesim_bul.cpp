/* H12_deney_birlesim_bul.cpp — AP-2 Hafta 12 · Haftanın Deneyi, ek (C++)
 * Amaç    : Birleşim–bul sürümlerinin (saf, yalnız rütbe, yalnız yol
 *           sıkıştırma, ikisi birden) işlem başına işaretçi izleme sayısı ve
 *           süresi; n rastgele birleştirme + n rastgele bul (3n bul çağrısı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_deney_birlesim_bul.cpp -o H12_deney_birlesim_bul
 * Çalıştır: ./H12_deney_birlesim_bul N saf|rutbe|sikistirma|ikisi|hepsi
 *           TEKRAR [CSV]
 * Çıktı   : stdout'a deterministik sayaçlar, CSV'ye süreler (ms)
 */
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static const char* const SURUM[4] = {"saf", "rutbe", "sikistirma", "ikisi"};
static long long izleme = 0, baglama = 0;

struct BirlesimBul {
    std::vector<int> ebeveyn, rutbe;
    bool rutbeli, sikistir;
};

static int bul(BirlesimBul& b, int x)
{
    int kok = x;
    while (b.ebeveyn[kok] != kok) {
        kok = b.ebeveyn[kok];
        izleme++;
    }
    if (b.sikistir) {
        while (b.ebeveyn[x] != kok) {
            int sonraki = b.ebeveyn[x];
            b.ebeveyn[x] = kok;
            baglama++;
            x = sonraki;
        }
    }
    return kok;
}

static void birlestir(BirlesimBul& b, int x, int y)
{
    int kx = bul(b, x), ky = bul(b, y);
    if (kx == ky) {
        return;
    }
    if (!b.rutbeli) {
        b.ebeveyn[kx] = ky;
        return;
    }
    if (b.rutbe[kx] < b.rutbe[ky]) {
        std::swap(kx, ky);
    }
    b.ebeveyn[ky] = kx;
    if (b.rutbe[kx] == b.rutbe[ky]) {
        b.rutbe[kx]++;
    }
}

static int yukseklik(const BirlesimBul& b)
{
    int n = static_cast<int>(b.ebeveyn.size()), en_cok = 0;
    std::vector<int> derinlik(n, -1), yigin;
    for (int x = 0; x < n; x++) {
        int v = x;
        while (derinlik[v] < 0 && b.ebeveyn[v] != v) {
            yigin.push_back(v);
            v = b.ebeveyn[v];
        }
        if (derinlik[v] < 0) {
            derinlik[v] = 0;
        }
        while (!yigin.empty()) {
            int u = yigin.back();
            yigin.pop_back();
            derinlik[u] = derinlik[b.ebeveyn[u]] + 1;
        }
        en_cok = std::max(en_cok, derinlik[x]);
    }
    return en_cok;
}

static void olc(int s, int n, const std::vector<int>& x,
                const std::vector<int>& y, const std::vector<int>& q,
                int tekrar, std::FILE* csv)
{
    BirlesimBul b{std::vector<int>(n), std::vector<int>(n), s == 1 || s == 3,
                  s == 2 || s == 3};
    std::vector<double> duvar, islemci;
    for (int k = 0; k <= tekrar; k++) {  // k = 0: ısınma
        izleme = baglama = 0;
        double t0 = zaman_sn(), c0 = islemci_sn();
        for (int i = 0; i < n; i++) {
            b.ebeveyn[i] = i;
            b.rutbe[i] = 0;
        }
        for (int i = 0; i < n; i++) {
            birlestir(b, x[i], y[i]);
        }
        for (int i = 0; i < n; i++) {
            bul(b, q[i]);
        }
        if (k > 0) {
            duvar.push_back((zaman_sn() - t0) * 1000.0);
            islemci.push_back((islemci_sn() - c0) * 1000.0);
        }
    }
    int kume = 0;
    for (int i = 0; i < n; i++) {
        kume += b.ebeveyn[i] == i;
    }
    int h = yukseklik(b);
    std::cout << SURUM[s] << " n=" << n << " izleme=" << izleme
              << " baglama=" << baglama << " kume=" << kume
              << " yukseklik=" << h << "\n";
    double en_az = duvar[0], en_cok = duvar[0];
    for (double t : duvar) {
        en_az = std::min(en_az, t);
        en_cok = std::max(en_cok, t);
    }
    double o_duvar = ortanca(duvar), o_islemci = ortanca(islemci);
    std::fprintf(stderr, "  C++ %s n=%d: %.3f ms\n", SURUM[s], n, o_duvar);
    if (csv != nullptr) {
        std::fprintf(csv, "cpp;%s;%d;%lld;%d;%.4f;%.4f;%.4f;%.4f;%lld;%lld;"
                          "%d;%d;olcum\n", SURUM[s], n, 3LL * n, tekrar,
                     o_duvar, en_az, en_cok, o_islemci, izleme, baglama,
                     kume, h);
    }
}

int main(int argc, char** argv)
{
    char* son;
    long n = argc > 1 ? std::strtol(argv[1], &son, 10) : 0;
    long tekrar = argc > 3 ? std::strtol(argv[3], &son, 10) : 0;
    int secim = -2;
    if (argc > 2) {
        for (int s = 0; s < 4; s++) {
            if (std::string(argv[2]) == SURUM[s]) {
                secim = s;
            }
        }
        if (std::string(argv[2]) == "hepsi") {
            secim = -1;
        }
    }
    if ((argc != 4 && argc != 5) || n < 2 || n > 10000000 || tekrar < 1 ||
        tekrar > 51 || secim == -2) {
        std::cerr << "Kullanım: H12_deney_birlesim_bul N "
                     "saf|rutbe|sikistirma|ikisi|hepsi TEKRAR [CSV]\n";
        return 2;
    }
    std::FILE* csv = argc == 5 ? std::fopen(argv[4], "a") : nullptr;
    if (argc == 5 && csv == nullptr) {
        std::cerr << "CSV açılamadı\n";
        return 1;
    }
    std::vector<int> x(n), y(n), q(n);
    rastgele_tohum(42);                  // işlem dizisi (ölçüm dışı)
    for (long i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, static_cast<int>(n) - 1);
        y[i] = rastgele_aralik(0, static_cast<int>(n) - 1);
    }
    for (long i = 0; i < n; i++) {
        q[i] = rastgele_aralik(0, static_cast<int>(n) - 1);
    }
    for (int s = 0; s < 4; s++) {
        if (secim == -1 || secim == s) {
            olc(s, static_cast<int>(n), x, y, q, static_cast<int>(tekrar),
                csv);
        }
    }
    if (csv != nullptr) {
        std::fclose(csv);
    }
    return 0;
}

/* Kütüphane karşılığı: C++ — yok (Boost disjoint_sets standart dışı). */

/* H12_deney_dijkstra.cpp — AP-2 Hafta 12 · Haftanın Deneyi (C++)
 * Amaç    : Dizi tabanlı O(V²) Dijkstra, elle yazılmış öbekli Dijkstra ve
 *           std::priority_queue'lu Dijkstra (etiketli kütüphane serisi);
 *           süre ve sayaçlar. Graf üretimi C sürümüyle birebir aynıdır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_deney_dijkstra.cpp -o H12_deney_dijkstra
 * Çalıştır: ./H12_deney_dijkstra V D lcg|kotu dizi|elle|kutuphane|hepsi
 *           TEKRAR [CSV]   (anlamlar C sürümünün başlığında)
 * Çıktı   : stdout'a deterministik sayaçlar, CSV'ye süreler (ms)
 */
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static const int SONSUZ = std::numeric_limits<int>::max();

struct Graf {                  // CSR: u'nun kenarları bas[u]..bas[u+1]-1
    int v_sayisi = 0;
    std::vector<long long> bas;
    std::vector<int> hedef, agirlik;
};

struct Sayac {
    long long itme = 0, cikarma = 0, atlanan = 0, gevsetme = 0, inceleme = 0,
              taranan = 0;
};

static Sayac sayac;

static Graf graf_uret(int v_sayisi, int d, bool kotu)
{
    Graf g;
    g.v_sayisi = v_sayisi;
    g.bas.assign(v_sayisi + 1, 0);
    for (int u = 0; u < v_sayisi; u++) {
        long long k = d;
        if (kotu) {
            k = std::min<long long>(v_sayisi - 1 - u, d);
        }
        g.bas[u + 1] = g.bas[u] + k;
    }
    g.hedef.resize(g.bas[v_sayisi]);
    g.agirlik.resize(g.bas[v_sayisi]);
    rastgele_tohum(42);
    for (int u = 0; u < v_sayisi; u++) {
        long long k = g.bas[u];
        if (kotu) {
            for (int v = u + 1; k < g.bas[u + 1]; v++, k++) {
                g.hedef[k] = v;
                g.agirlik[k] = 2 * (v - u) - 1;
            }
            continue;
        }
        g.hedef[k] = (u + 1) % v_sayisi;
        g.agirlik[k] = rastgele_aralik(1, 1000);
        for (k++; k < g.bas[u + 1]; k++) {
            g.hedef[k] = rastgele_aralik(0, v_sayisi - 1);
            g.agirlik[k] = rastgele_aralik(1, 1000);
        }
    }
    return g;
}

static void dijkstra_dizi(const Graf& g, std::vector<int>& d)
{
    int n = g.v_sayisi;
    std::vector<char> kesin(n, 0);
    d.assign(n, SONSUZ);
    d[0] = 0;
    for (int adim = 0; adim < n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {
            sayac.taranan++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;
        }
        kesin[u] = 1;
        for (long long k = g.bas[u]; k < g.bas[u + 1]; k++) {
            int v = g.hedef[k];
            sayac.inceleme++;
            if (!kesin[v] && d[u] + g.agirlik[k] < d[v]) {
                d[v] = d[u] + g.agirlik[k];
                sayac.gevsetme++;
            }
        }
    }
}

// Elle yazılmış en küçük öbek (C sürümündeki ile aynı adımlar)
struct ElleObek {
    std::vector<std::pair<int, int>> a;   // (uzaklık, köşe)

    void ekle(std::pair<int, int> x)
    {
        a.push_back(x);
        std::size_t i = a.size() - 1;
        while (i > 0 && x < a[(i - 1) / 2]) {           // yukarı süz
            a[i] = a[(i - 1) / 2];
            i = (i - 1) / 2;
        }
        a[i] = x;
        sayac.itme++;
    }

    std::pair<int, int> cikar()
    {
        std::pair<int, int> en_kucuk = a[0], son = a.back();
        a.pop_back();
        std::size_t i = 0, n = a.size();
        while (n > 0 && 2 * i + 1 < n) {                // aşağı süz
            std::size_t c = 2 * i + 1;
            if (c + 1 < n && a[c + 1] < a[c]) {
                c++;
            }
            if (!(a[c] < son)) {
                break;
            }
            a[i] = a[c];
            i = c;
        }
        if (n > 0) {
            a[i] = son;
        }
        sayac.cikarma++;
        return en_kucuk;
    }

    bool bos() const { return a.empty(); }
};

// Kütüphane öbeği: std::priority_queue + std::greater (en küçük öbek)
struct KutuphaneObek {
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>,
                        std::greater<std::pair<int, int>>> q;

    void ekle(std::pair<int, int> x)
    {
        q.push(x);
        sayac.itme++;
    }

    std::pair<int, int> cikar()
    {
        std::pair<int, int> x = q.top();
        q.pop();
        sayac.cikarma++;
        return x;
    }

    bool bos() const { return q.empty(); }
};

template <class Obek>
static void dijkstra_obek(const Graf& g, std::vector<int>& d)
{
    int n = g.v_sayisi;
    std::vector<char> kesin(n, 0);
    d.assign(n, SONSUZ);
    d[0] = 0;
    Obek obek;
    obek.ekle({0, 0});
    while (!obek.bos()) {
        int u = obek.cikar().second;
        if (kesin[u]) {
            sayac.atlanan++;
            continue;
        }
        kesin[u] = 1;
        for (long long k = g.bas[u]; k < g.bas[u + 1]; k++) {
            int v = g.hedef[k];
            sayac.inceleme++;
            if (!kesin[v] && d[u] + g.agirlik[k] < d[v]) {
                d[v] = d[u] + g.agirlik[k];
                sayac.gevsetme++;
                obek.ekle({d[v], v});
            }
        }
    }
}

static void olc(const std::string& surum, const std::string& agirlik,
                const Graf& g, int d_p, int tekrar, std::FILE* csv)
{
    std::vector<int> d;
    std::vector<double> duvar, islemci;
    for (int k = 0; k <= tekrar; k++) {  // k = 0: ısınma
        sayac = Sayac();
        double t0 = zaman_sn(), c0 = islemci_sn();
        if (surum == "dizi") {
            dijkstra_dizi(g, d);
        } else if (surum == "elle") {
            dijkstra_obek<ElleObek>(g, d);
        } else {
            dijkstra_obek<KutuphaneObek>(g, d);
        }
        if (k > 0) {
            duvar.push_back((zaman_sn() - t0) * 1000.0);
            islemci.push_back((islemci_sn() - c0) * 1000.0);
        }
    }
    long long toplam = 0, ulasilan = 0;
    for (int x : d) {
        if (x != SONSUZ) {
            toplam += x;
            ulasilan++;
        }
    }
    long long e = g.bas[g.v_sayisi];
    std::cout << surum << " " << agirlik << " V=" << g.v_sayisi << " D=" << d_p
              << " E=" << e << " itme=" << sayac.itme << " cikarma="
              << sayac.cikarma << " atlanan=" << sayac.atlanan << " gevsetme="
              << sayac.gevsetme << " inceleme=" << sayac.inceleme
              << " taranan=" << sayac.taranan << " ulasilan=" << ulasilan
              << " toplam=" << toplam << "\n";
    double en_az = duvar[0], en_cok = duvar[0];
    for (double x : duvar) {
        en_az = std::min(en_az, x);
        en_cok = std::max(en_cok, x);
    }
    double o_duvar = ortanca(duvar), o_islemci = ortanca(islemci);
    std::fprintf(stderr, "  C++ %s %s V=%d D=%d: %.3f ms\n", surum.c_str(),
                 agirlik.c_str(), g.v_sayisi, d_p, o_duvar);
    if (csv != nullptr) {
        std::fprintf(csv, "cpp;%s;%s;%d;%d;%lld;%d;%.4f;%.4f;%.4f;%.4f;%lld;"
                          "%lld;%lld;%lld;%lld;%lld;%lld;%lld;olcum\n",
                     surum.c_str(), agirlik.c_str(), g.v_sayisi, d_p, e,
                     tekrar, o_duvar, en_az, en_cok, o_islemci, sayac.itme,
                     sayac.cikarma, sayac.atlanan, sayac.gevsetme,
                     sayac.inceleme, sayac.taranan, ulasilan, toplam);
    }
}

static bool sayi_al(const char* s, long long alt, long long ust, int& x)
{
    char* son;
    long long v = std::strtoll(s, &son, 10);
    if (*s == '\0' || *son != '\0' || v < alt || v > ust) {
        return false;
    }
    x = static_cast<int>(v);
    return true;
}

int main(int argc, char** argv)
{
    int v_sayisi, d, tekrar;
    std::string agirlik = argc > 3 ? argv[3] : "", surum = argc > 4 ? argv[4]
                                                                    : "";
    if ((argc != 6 && argc != 7) || !sayi_al(argv[1], 2, 100000, v_sayisi) ||
        !sayi_al(argv[2], 1, 100000, d) || !sayi_al(argv[5], 1, 51, tekrar) ||
        (agirlik != "lcg" && agirlik != "kotu") ||
        (surum != "dizi" && surum != "elle" && surum != "kutuphane" &&
         surum != "hepsi")) {
        std::cerr << "Kullanım: H12_deney_dijkstra V D lcg|kotu "
                     "dizi|elle|kutuphane|hepsi TEKRAR [CSV]\n";
        return 2;
    }
    Graf g = graf_uret(v_sayisi, d, agirlik == "kotu");
    std::FILE* csv = nullptr;
    if (argc == 7 && (csv = std::fopen(argv[6], "a")) == nullptr) {
        std::cerr << "CSV açılamadı: " << argv[6] << "\n";
        return 1;
    }
    for (const char* s : {"dizi", "elle", "kutuphane"}) {
        if (surum == "hepsi" || surum == s) {
            olc(s, agirlik, g, d, tekrar, csv);
        }
    }
    if (csv != nullptr) {
        std::fclose(csv);
    }
    return 0;
}

/* Kütüphane karşılığı: C++ — std::priority_queue (bu deneyde etiketli
 * "kutuphane" serisi olarak ölçülür). */

/* H12_K05_cekirdek.c — AP-2 Hafta 12 · Kavram 5
 * Amaç    : Haftanın açgözlü algoritmalarının yazdırmasız çekirdekleri
 *           (slaytlar ve "Üç Dilde" için kısa sürümler). Örneklerdeki
 *           fonksiyonların izleme ve sayaç satırları atılmıştır; adlar,
 *           eşitlik kırma kuralları ve sonuçlar örneklerle aynıdır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_K05_cekirdek.c \
 *           -o H12_K05_cekirdek
 * Çalıştır: ./H12_K05_cekirdek
 * Eşleri  : kavram/H12_K05_cekirdek.cpp · kavram/H12_K05_cekirdek.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SONSUZ INT_MAX
#define MAKS_V 16
#define MAKS_OBEK 64             /* bu programın girdileri için yeterli */
#define MAKS_DUGUM 32

/* ---- (anahtar, no) en küçük öbeği: H7 öbeğinin genelleştirilmesi ---- */
typedef struct {
    int anahtar, no;
} Oge;

typedef struct {
    Oge a[MAKS_OBEK];
    int n;
} Obek;

/* Demet sırası: önce anahtar, eşitse no (tam sıralama) */
static bool kucuk_mu(Oge x, Oge y)
{
    return x.anahtar < y.anahtar ||
           (x.anahtar == y.anahtar && x.no < y.no);
}

static void obege_ekle(Obek *h, Oge x)
{
    int i = h->n++;
    h->a[i] = x;
    while (i > 0 && kucuk_mu(h->a[i], h->a[(i - 1) / 2])) {
        Oge t = h->a[i];
        h->a[i] = h->a[(i - 1) / 2];
        h->a[(i - 1) / 2] = t;
        i = (i - 1) / 2;
    }
}

static Oge en_kucugu_cikar(Obek *h)
{
    Oge kok = h->a[0];
    h->a[0] = h->a[--h->n];
    int i = 0;
    for (;;) {
        int k = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < h->n && kucuk_mu(h->a[s], h->a[k])) {
            k = s;
        }
        if (r < h->n && kucuk_mu(h->a[r], h->a[k])) {
            k = r;
        }
        if (k == i) {
            break;
        }
        Oge t = h->a[i];
        h->a[i] = h->a[k];
        h->a[k] = t;
        i = k;
    }
    return kok;
}

/* ---- Örnek 2 ve 3: yarı açık aralıklar [bas, bit) ---- */
typedef struct {
    int bas, bit, kimlik;
} Aralik;

/* Tam sıralama (bit, bas, kimlik): qsort kararsızdır */
static int bitise_gore(const void *p, const void *q)
{
    const Aralik *x = p, *y = q;
    if (x->bit != y->bit) {
        return x->bit < y->bit ? -1 : 1;
    }
    if (x->bas != y->bas) {
        return x->bas < y->bas ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

/* Tam sıralama (bas, bit, kimlik) */
static int basa_gore(const void *p, const void *q)
{
    const Aralik *x = p, *y = q;
    if (x->bas != y->bas) {
        return x->bas < y->bas ? -1 : 1;
    }
    if (x->bit != y->bit) {
        return x->bit < y->bit ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

/* Örnek 2: en erken biten ilk; seçilen sayısını döndürür */
static int en_erken_biten(Aralik *a, int n, Aralik *secilen)
{
    qsort(a, (size_t)n, sizeof a[0], bitise_gore);
    int k = 0, son_bitis = -1;
    for (int i = 0; i < n; i++) {
        if (a[i].bas >= son_bitis) {     /* açgözlü seçim */
            secilen[k++] = a[i];
            son_bitis = a[i].bit;
        }
    }
    return k;
}

/* Örnek 3: aralık bölümleme; salon sayısını döndürür */
static int bolumle(Aralik *a, int n, int *salon)
{
    qsort(a, (size_t)n, sizeof a[0], basa_gore);
    Obek obek = {.n = 0};                /* (bitiş, salon) */
    int salon_sayisi = 0;
    for (int i = 0; i < n; i++) {
        int s;
        if (obek.n > 0 && obek.a[0].anahtar <= a[i].bas) {
            s = en_kucugu_cikar(&obek).no;     /* boşalan salon */
        } else {
            s = salon_sayisi++;                /* yeni salon */
        }
        salon[a[i].kimlik] = s;
        obege_ekle(&obek, (Oge){a[i].bit, s});
    }
    return salon_sayisi;
}

/* ---- Örnek 4: kesirli sırt çantası ---- */
typedef struct {
    int agirlik, deger, kimlik;
} Yuk;

/* Birim değere göre azalan: v1/w1 > v2/w2  <=>  v1·w2 > v2·w1 */
static int birim_degere_gore(const void *p, const void *q)
{
    const Yuk *x = p, *y = q;
    long long sol = (long long)x->deger * y->agirlik;
    long long sag = (long long)y->deger * x->agirlik;
    if (sol != sag) {
        return sol > sag ? -1 : 1;
    }
    return (x->kimlik > y->kimlik) - (x->kimlik < y->kimlik);
}

/* Toplam değer *pay / *payda (kayan nokta yok) */
static void doldur(Yuk *y, int n, int kapasite, long long *pay,
                   long long *payda)
{
    qsort(y, (size_t)n, sizeof y[0], birim_degere_gore);
    long long tam = 0;
    int kalan = kapasite;
    *pay = 0;
    *payda = 1;
    for (int i = 0; i < n && kalan > 0; i++) {
        if (y[i].agirlik <= kalan) {     /* tamamı sığar */
            kalan -= y[i].agirlik;
            tam += y[i].deger;
        } else {                         /* kesri alınır, çanta dolar */
            *pay = tam * y[i].agirlik + (long long)y[i].deger * kalan;
            *payda = y[i].agirlik;
            return;
        }
    }
    *pay = tam;
}

static long long ebob(long long a, long long b)
{
    while (b != 0) {
        long long r = a % b;
        a = b;
        b = r;
    }
    return a;
}

/* ---- Örnek 5: Huffman ağacı (düğümler dizilerde) ---- */
typedef struct {
    int sembol[MAKS_DUGUM];      /* -1: iç düğüm */
    int siklik[MAKS_DUGUM];
    int sol[MAKS_DUGUM], sag[MAKS_DUGUM];
    int n, kok;
} Agac;

static int dugum_ekle(Agac *t, int sembol, int siklik, int sol, int sag)
{
    t->sembol[t->n] = sembol;
    t->siklik[t->n] = siklik;
    t->sol[t->n] = sol;
    t->sag[t->n] = sag;
    return t->n++;
}

/* Öbekte (sıklık, düğüm no): eşitlikte önce oluşturulan çıkar */
static void agac_kur(const int *siklik, int k, Agac *t)
{
    Obek obek = {.n = 0};
    t->n = 0;
    for (int b = 0; b < k; b++) {        /* yapraklar simge sırasıyla */
        int d = dugum_ekle(t, b, siklik[b], -1, -1);
        obege_ekle(&obek, (Oge){siklik[b], d});
    }
    while (obek.n > 1) {
        Oge x = en_kucugu_cikar(&obek);  /* en küçük iki ağaç */
        Oge y = en_kucugu_cikar(&obek);
        int f = x.anahtar + y.anahtar;
        int z = dugum_ekle(t, -1, f, x.no, y.no);
        obege_ekle(&obek, (Oge){f, z});
    }
    t->kok = en_kucugu_cikar(&obek).no;
}

/* Kökten yaprağa: sol 0, sağ 1; tek düğümlü ağaçta kod "0" */
static void kod_ata(const Agac *t, int d, char *kod, int derinlik,
                    char kodlar[][MAKS_DUGUM])
{
    if (t->sembol[d] >= 0) {
        if (derinlik == 0) {
            strcpy(kodlar[t->sembol[d]], "0");
        } else {
            memcpy(kodlar[t->sembol[d]], kod, (size_t)derinlik);
            kodlar[t->sembol[d]][derinlik] = '\0';
        }
        return;
    }
    kod[derinlik] = '0';
    kod_ata(t, t->sol[d], kod, derinlik + 1, kodlar);
    kod[derinlik] = '1';
    kod_ata(t, t->sag[d], kod, derinlik + 1, kodlar);
}

/* ---- Örnek 7–13: graf (komşular artan hedef sırasıyla) ---- */
typedef struct {
    int hedef, agirlik;
} Komsu;

typedef struct {
    int n;
    int derece[MAKS_V];
    Komsu komsu[MAKS_V][MAKS_V];
} Graf;

typedef struct {
    int u, v, w;
} Kenar;

/* Yönsüz graf: kenarlar (u, v) sırasıyla verilirse komşular sıralı olur */
static void graf_kur(Graf *g, int n, const Kenar *e, int m)
{
    g->n = n;
    for (int v = 0; v < n; v++) {
        g->derece[v] = 0;
    }
    for (int i = 0; i < m; i++) {
        int u = e[i].u, v = e[i].v;
        g->komsu[u][g->derece[u]++] = (Komsu){v, e[i].w};
        g->komsu[v][g->derece[v]++] = (Komsu){u, e[i].w};
    }
}

/* Kesinleşmemiş, d'si en küçük köşe; yoksa -1 (eşitlikte küçük no) */
static int en_yakin(int n, const int *d, const bool *kesin)
{
    int u = -1;
    for (int v = 0; v < n; v++) {
        if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
            u = v;
        }
    }
    return u;
}

/* Örnek 7: dizi tabanlı Dijkstra, Θ(V²) */
static void dijkstra_dizi(const Graf *g, int s, int *d, int *ebeveyn)
{
    bool kesin[MAKS_V] = {false};
    for (int v = 0; v < g->n; v++) {
        d[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    d[s] = 0;
    int u;
    while ((u = en_yakin(g->n, d, kesin)) >= 0) {
        kesin[u] = true;                 /* d[u] artık kesin */
        for (int i = 0; i < g->derece[u]; i++) {
            int v = g->komsu[u][i].hedef;
            int w = g->komsu[u][i].agirlik;
            if (!kesin[v] && d[u] != SONSUZ && d[u] + w < d[v]) {
                d[v] = d[u] + w;         /* gevşetme */
                ebeveyn[v] = u;
            }
        }
    }
}

/* Örnek 8: öbekli Dijkstra, tembel silme. Öbekten çıkan u'nun d[u]'su
 * sonludur: d[u] + w taşmaz. */
static void dijkstra_obek(const Graf *g, int s, int *d, int *ebeveyn)
{
    bool kesin[MAKS_V] = {false};
    Obek obek = {.n = 0};                /* (uzaklık, köşe) */
    for (int v = 0; v < g->n; v++) {
        d[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    d[s] = 0;
    obege_ekle(&obek, (Oge){0, s});
    while (obek.n > 0) {
        int u = en_kucugu_cikar(&obek).no;
        if (kesin[u]) {
            continue;                    /* eskimiş kayıt */
        }
        kesin[u] = true;
        for (int i = 0; i < g->derece[u]; i++) {
            int v = g->komsu[u][i].hedef;
            int w = g->komsu[u][i].agirlik;
            if (!kesin[v] && d[u] + w < d[v]) {
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                obege_ekle(&obek, (Oge){d[v], v});
            }
        }
    }
}

/* ---- Örnek 10: birleşim–bul (rütbe + yol sıkıştırma) ---- */
typedef struct {
    int ebeveyn[MAKS_V], rutbe[MAKS_V];
} BirlesimBul;

static void bb_kur(BirlesimBul *b, int n)
{
    for (int i = 0; i < n; i++) {
        b->ebeveyn[i] = i;
        b->rutbe[i] = 0;
    }
}

/* Kökü bul, sonra yoldaki her düğümü köke bağla (iki geçiş) */
static int bul(BirlesimBul *b, int x)
{
    int kok = x;
    while (b->ebeveyn[kok] != kok) {
        kok = b->ebeveyn[kok];
    }
    while (b->ebeveyn[x] != kok) {
        int sonraki = b->ebeveyn[x];
        b->ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

/* Rütbeye göre birleştir; zaten aynı kümedeyse false */
static bool birlestir(BirlesimBul *b, int x, int y)
{
    int kx = bul(b, x), ky = bul(b, y);
    if (kx == ky) {
        return false;
    }
    if (b->rutbe[kx] < b->rutbe[ky]) {
        int g = kx;
        kx = ky;
        ky = g;
    }
    b->ebeveyn[ky] = kx;
    if (b->rutbe[kx] == b->rutbe[ky]) {
        b->rutbe[kx]++;
    }
    return true;
}

/* ---- Örnek 11: Kruskal ---- */
/* Tam sıralama (w, u, v) */
static int kenar_karsilastir(const void *p, const void *q)
{
    const Kenar *x = p, *y = q;
    if (x->w != y->w) {
        return x->w < y->w ? -1 : 1;
    }
    if (x->u != y->u) {
        return x->u < y->u ? -1 : 1;
    }
    return (x->v > y->v) - (x->v < y->v);
}

/* Toplam ağırlığı döndürür; ağaç kenarları agac[0..*k-1] */
static int kruskal(Kenar *e, int m, int n, Kenar *agac, int *k)
{
    BirlesimBul b;
    bb_kur(&b, n);
    qsort(e, (size_t)m, sizeof e[0], kenar_karsilastir);
    int toplam = 0;
    *k = 0;
    for (int i = 0; i < m; i++) {
        if (birlestir(&b, e[i].u, e[i].v)) {   /* döngü yoksa kabul */
            agac[(*k)++] = e[i];
            toplam += e[i].w;
        }
    }
    return toplam;
}

/* ---- Örnek 12: Prim (öbekle, tembel silme) ---- */
static int prim(const Graf *g, int s, int *ebeveyn)
{
    bool agacta[MAKS_V] = {false};
    int anahtar[MAKS_V];
    Obek obek = {.n = 0};                /* (anahtar, köşe) */
    for (int v = 0; v < g->n; v++) {
        anahtar[v] = SONSUZ;
        ebeveyn[v] = -1;
    }
    anahtar[s] = 0;
    obege_ekle(&obek, (Oge){0, s});
    int toplam = 0;
    while (obek.n > 0) {
        Oge x = en_kucugu_cikar(&obek);
        int u = x.no;
        if (agacta[u]) {
            continue;                    /* eskimiş kayıt */
        }
        agacta[u] = true;
        toplam += x.anahtar;
        for (int i = 0; i < g->derece[u]; i++) {
            int v = g->komsu[u][i].hedef;
            int w = g->komsu[u][i].agirlik;
            if (!agacta[v] && w < anahtar[v]) {  /* Dijkstra: d[u] + w */
                anahtar[v] = w;
                ebeveyn[v] = u;
                obege_ekle(&obek, (Oge){w, v});
            }
        }
    }
    return toplam;
}

/* ---- Örnek 13: Welsh–Powell ---- */
typedef struct {
    int derece, no;
} Kose;

/* Derece azalan, eşitlikte küçük numara */
static int dereceye_gore(const void *p, const void *q)
{
    const Kose *x = p, *y = q;
    if (x->derece != y->derece) {
        return x->derece > y->derece ? -1 : 1;
    }
    return (x->no > y->no) - (x->no < y->no);
}

/* Renk sayısını döndürür; renk[v] = v'nin rengi (0'dan) */
static int welsh_powell(const Graf *g, int *renk)
{
    Kose sira[MAKS_V];
    for (int v = 0; v < g->n; v++) {
        sira[v] = (Kose){g->derece[v], v};
        renk[v] = -1;
    }
    qsort(sira, (size_t)g->n, sizeof sira[0], dereceye_gore);
    int boyanan = 0, c = 0;
    while (boyanan < g->n) {             /* c rengi için bir tur */
        for (int i = 0; i < g->n; i++) {
            int x = sira[i].no;
            bool uygun = renk[x] == -1;
            for (int j = 0; uygun && j < g->derece[x]; j++) {
                if (renk[g->komsu[x][j].hedef] == c) {
                    uygun = false;       /* c renkli komşu var */
                }
            }
            if (uygun) {
                renk[x] = c;
                boyanan++;
            }
        }
        c++;
    }
    return c;
}

static void dizi_yaz(const int *a, int n)
{
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
}

int main(void)
{
    /* Örnek 2'nin 10 isteği (A..J) */
    Aralik istek[10] = {{4, 7, 0}, {0, 3, 1}, {3, 8, 2}, {1, 4, 3},
                        {7, 10, 4}, {9, 12, 5}, {6, 9, 6}, {11, 14, 7},
                        {2, 6, 8}, {8, 13, 9}};
    Aralik secilen[10];
    int k = en_erken_biten(istek, 10, secilen);
    printf("1) en erken biten ilk:");
    for (int i = 0; i < k; i++) {
        printf(" %c", 'A' + secilen[i].kimlik);
    }
    printf(" (%d aralık)\n", k);

    /* Örnek 3'ün 10 dersi (dakika: 540 = 09:00) */
    Aralik ders[10] = {{540, 630, 0}, {540, 750, 1}, {600, 690, 2},
                       {630, 720, 3}, {660, 840, 4}, {720, 810, 5},
                       {780, 870, 6}, {810, 960, 7}, {870, 960, 8},
                       {900, 990, 9}};
    int salon[10];
    int s = bolumle(ders, 10, salon);
    printf("2) aralık bölümleme: %d salon;", s);
    for (int i = 0; i < 10; i++) {
        printf(" %c:%d", 'A' + i, salon[i] + 1);
    }
    printf("\n");

    /* Örnek 4'ün 6 yükü, kapasite 60 kg */
    Yuk yuk[6] = {{12, 84, 0}, {8, 40, 1}, {20, 100, 2},
                  {15, 90, 3}, {25, 80, 4}, {9, 30, 5}};
    long long pay, payda;
    doldur(yuk, 6, 60, &pay, &payda);
    long long g = ebob(pay, payda);
    printf("3) kesirli sırt çantası (60 kg): %lld/%lld\n", pay / g,
           payda / g);

    /* Örnek 5: Cormen vd. sıklık tablosu a..f */
    const int siklik[6] = {45, 13, 12, 16, 9, 5};
    static Agac t;
    static char kodlar[6][MAKS_DUGUM];
    char kod[MAKS_DUGUM];
    agac_kur(siklik, 6, &t);
    kod_ata(&t, t.kok, kod, 0, kodlar);
    printf("4) Huffman (Cormen vd.):");
    for (int i = 0; i < 6; i++) {
        printf(" %c=%s", 'a' + i, kodlar[i]);
    }
    printf("\n");

    /* Kampüs grafı (girdiler/h12_kampus.txt) */
    Kenar kampus[14] = {{0, 1, 40}, {0, 2, 45}, {0, 7, 60}, {1, 2, 30},
                        {1, 3, 120}, {1, 7, 140}, {2, 3, 20},
                        {2, 4, 110}, {3, 4, 50}, {3, 5, 55}, {4, 5, 10},
                        {4, 6, 70}, {5, 6, 80}, {6, 7, 130}};
    static Graf gk;
    graf_kur(&gk, 8, kampus, 14);
    int d[MAKS_V], ebeveyn[MAKS_V];
    dijkstra_dizi(&gk, 0, d, ebeveyn);
    printf("5) Dijkstra (dizi), kaynak 0: d =");
    dizi_yaz(d, 8);
    printf("\n");
    dijkstra_obek(&gk, 0, d, ebeveyn);
    printf("6) Dijkstra (öbek), kaynak 0: d =");
    dizi_yaz(d, 8);
    printf("; ebeveyn =");
    dizi_yaz(ebeveyn, 8);
    printf("\n");

    /* Örnek 10'un küçük örneği */
    BirlesimBul b;
    bb_kur(&b, 8);
    const int cift[8][2] = {{0, 1}, {2, 3}, {0, 2}, {4, 5},
                            {6, 7}, {4, 6}, {1, 5}, {3, 7}};
    for (int i = 0; i < 8; i++) {
        birlestir(&b, cift[i][0], cift[i][1]);
    }
    int kok = bul(&b, 0);
    printf("7) birleşim–bul (rütbe + sıkıştırma): bul(0) = %d; ebeveyn =",
           kok);
    dizi_yaz(b.ebeveyn, 8);
    printf("\n");

    Kenar agac[MAKS_V];
    int ak;
    int toplam = kruskal(kampus, 14, 8, agac, &ak);
    printf("8) Kruskal:");
    for (int i = 0; i < ak; i++) {
        printf(" %d-%d (%d)", agac[i].u, agac[i].v, agac[i].w);
    }
    printf("; toplam %d\n", toplam);

    toplam = prim(&gk, 0, ebeveyn);
    printf("9) Prim (0'dan): ebeveyn =");
    dizi_yaz(ebeveyn, 8);
    printf("; toplam %d\n", toplam);

    /* Sınav çakışma grafı (girdiler/h12_cakisma.txt), ağırlıksız */
    Kenar cakisma[13] = {{0, 1, 1}, {0, 2, 1}, {0, 4, 1}, {1, 2, 1},
                         {1, 3, 1}, {2, 3, 1}, {2, 5, 1}, {3, 6, 1},
                         {4, 5, 1}, {4, 7, 1}, {5, 6, 1}, {5, 7, 1},
                         {6, 7, 1}};
    static Graf gc;
    graf_kur(&gc, 8, cakisma, 13);
    int renk[MAKS_V];
    int c = welsh_powell(&gc, renk);
    printf("10) Welsh–Powell: %d renk;", c);
    for (int v = 0; v < 8; v++) {
        printf(" %d:%d", v, renk[v]);
    }
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort yalnız sıralama için);
 * C++ — std::priority_queue, std::sort; Python — heapq, sorted */

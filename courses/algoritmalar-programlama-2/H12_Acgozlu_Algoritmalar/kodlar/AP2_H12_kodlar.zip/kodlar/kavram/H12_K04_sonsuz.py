"""H12_K04_sonsuz.py — AP-2 Hafta 12 · Kavram 4 (Python)
Amaç    : Dil Penceresi — Python tamsayısı taşmaz; math.inf (float) her
          tamsayıdan büyüktür ve toplamada değişmez. Ama yazdırılınca
          "inf" çıkar ve float'tır: ders örnekleri üç dilde aynı çıktı için
          C'deki INT_MAX ile aynı tamsayı sabitini kullanır (rehber 14.2).
Çalıştır: python3 H12_K04_sonsuz.py
Eşleri  : H12_K04_sonsuz.c · H12_K04_sonsuz.cpp
"""
import math
import sys

SONSUZ = 2147483647                  # C'deki INT_MAX ile aynı sabit


def main():
    print(f"SONSUZ + 5 = {SONSUZ + 5} (taşma yok; C'de tanımsız davranış)")
    print(f"math.inf = {math.inf}, tür: {type(math.inf).__name__}, "
          f"math.inf + 5 == math.inf: {math.inf + 5 == math.inf}")
    print(f"10**100 < math.inf: {10 ** 100 < math.inf}; "
          f"f'{{math.inf:.2f}}' -> {math.inf:.2f}")
    print(f"sys.maxsize = {sys.maxsize} (en büyük int DEĞİL: Py_ssize_t'nin, "
          "yani liste boyutunun üst sınırı)")
    try:
        int(math.inf)
    except OverflowError as e:
        print(f"int(math.inf): OverflowError: {e}")
    d = [0, 7, math.inf]
    print(f"uzaklık listesi math.inf ile: {d} -> çıktı C'den farklı olurdu")


if __name__ == "__main__":
    main()

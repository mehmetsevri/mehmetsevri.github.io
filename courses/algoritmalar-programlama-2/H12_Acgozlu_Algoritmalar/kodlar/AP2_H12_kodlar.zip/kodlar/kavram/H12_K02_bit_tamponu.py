"""H12_K02_bit_tamponu.py — AP-2 Hafta 12 · Kavram 2 (Python)
Amaç    : Kaputun Altında / Dil Penceresi — Huffman kodlarının bit
          tamponuna yazılması: bytearray ile MSB önce ve LSB önce düzen,
          dolgu bitleri; aynı sonucun int ile kurulup int.to_bytes ile
          baytlara çevrilmesi ve int.from_bytes ile geri okunması.
Çalıştır: python3 H12_K02_bit_tamponu.py
Eşleri  : H12_K02_bit_tamponu.c (aynı tampon; to_bytes bölümü yalnız
          Python'da)
"""


def yaz(kodlar, boyut, msb_once):
    tampon = bytearray(boyut)
    i = 0
    for kod in kodlar:
        for c in kod:
            if c == "1":
                konum = 7 - (i & 7) if msb_once else i & 7
                tampon[i >> 3] |= 1 << konum
            i += 1
    return tampon, i


def oku(tampon, i, msb_once):
    konum = 7 - (i & 7) if msb_once else i & 7
    return tampon[i >> 3] >> konum & 1


def main():
    kodlar = ["110", "0", "1011", "0", "111"]
    bit = sum(len(k) for k in kodlar)
    bayt = (bit + 7) // 8
    print(f"Kodlar sırayla: 110 0 1011 0 111 (toplam {bit} bit -> {bayt} "
          f"bayt, dolgu {bayt * 8 - bit} bit)")
    for msb in (True, False):
        tampon, _ = yaz(kodlar, 4, msb)
        print(("MSB önce (Örnek 6):" if msb else "LSB önce          :") +
              "".join(f" {b:08b} = 0x{b:02X}" for b in tampon[:bayt]))
        print("  geri okunan bitler: " +
              "".join(str(oku(tampon, i, msb)) for i in range(bit)))
    print("Not: dolgu bitleri 0'dır; çözücü kaç bit (ya da kaç simge) "
          "okuyacağını\nbilmezse dolguyu veri sanabilir.")
    # Yalnız Python: bitleri tek bir tamsayıda topla, baytlara çevir
    dizgi = "".join(kodlar)
    x = int(dizgi, 2) << (bayt * 8 - bit)        # dolgu: sağa sıfırlar
    b = x.to_bytes(bayt, "big")
    print(f"int.to_bytes({bayt}, 'big'): " +
          " ".join(f"0x{v:02X}" for v in b) +
          f"  (MSB önce düzenle aynı mı? "
          f"{'evet' if b == bytes(yaz(kodlar, bayt, True)[0]) else 'HAYIR'})")
    geri = int.from_bytes(b, "big") >> (bayt * 8 - bit)
    print(f"int.from_bytes -> {geri:0{bit}b} (özgün {dizgi})")


if __name__ == "__main__":
    main()

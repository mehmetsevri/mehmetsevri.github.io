/* H12_K04_sonsuz.c — AP-2 Hafta 12 · Kavram 4 (C)
 * Amaç    : Dil Penceresi — "sonsuz uzaklık": int'te sonsuz yoktur, en büyük
 *           değer (INT_MAX) gözcü olarak kullanılır ve toplama taşma
 *           korumalı yapılır (INT_MAX + w işaretli taşma: tanımsız
 *           davranış, Hata Avcısı 4). double'da INFINITY vardır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_K04_sonsuz.c \
 *           -o H12_K04_sonsuz -lm
 * Eşleri  : H12_K04_sonsuz.cpp · H12_K04_sonsuz.py
 */
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>

#define SONSUZ INT_MAX

/* Taşma korumalı gevşetme: d[u] + w < d[v] mi? */
static bool kisalir_mi(int du, int w, int dv)
{
    return du != SONSUZ && du + w < dv;
}

/* Alternatif: toplamı daha geniş türde yapmak */
static bool kisalir_mi_genis(int du, int w, int dv)
{
    return (long long)du + w < dv;
}

int main(void)
{
    printf("INT_MAX = %d, LLONG_MAX = %lld (bu makinede, LP64)\n", INT_MAX,
           LLONG_MAX);
    printf("koruma ile: kisalir_mi(SONSUZ, 5, SONSUZ) = %d\n",
           kisalir_mi(SONSUZ, 5, SONSUZ));
    printf("long long ile: (long long)INT_MAX + 5 = %lld; "
           "kisalir_mi_genis(SONSUZ, 5, SONSUZ) = %d\n",
           (long long)INT_MAX + 5, kisalir_mi_genis(SONSUZ, 5, SONSUZ));
    double inf = INFINITY;
    printf("double: INFINITY = %f, INFINITY + 5 == INFINITY: %d, "
           "isinf: %d, 1e308 < INFINITY: %d\n", inf, inf + 5 == inf,
           isinf(inf) != 0, 1e308 < inf);
    printf("Not: INT_MAX + 5 burada çalıştırılmaz (tanımsız davranış); "
           "(int)INFINITY de\ntanımsızdır. Gözcü değer yazdırılırken "
           "ayrıca ele alınır (Örnek 7: ∞).\n");
    return 0;
}

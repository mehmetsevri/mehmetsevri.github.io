/* H12_K03_demet_karsilastirma.cpp — AP-2 Hafta 12 · Kavram 3 (C++)
 * Amaç    : Dil Penceresi — std::pair ve std::tuple (std::tie) sözlük
 *           sırasıyla karşılaştırılır; std::priority_queue<std::pair<…>,
 *           std::vector<…>, std::greater<…>> en küçük öbek olur. Kendi
 *           struct'ımız için ya operator< ya da karşılaştırıcı gerekir
 *           (tanımlanmazsa priority_queue derlenmez).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_K03_demet_karsilastirma.cpp -o H12_K03_demet_karsilastirma
 * Eşleri  : H12_K03_demet_karsilastirma.py · H12_K03_demet_karsilastirma.c
 */
#include <functional>
#include <iostream>
#include <queue>
#include <tuple>
#include <utility>
#include <vector>

struct Oge {
    int uzaklik, kose;
    bool operator<(const Oge& y) const      // std::tie ile sözlük sırası
    {
        return std::tie(uzaklik, kose) < std::tie(y.uzaklik, y.kose);
    }
};

int main()
{
    using Cift = std::pair<int, int>;
    const Cift ciftler[3][2] = {{{2, 5}, {2, 7}}, {{2, 7}, {3, 0}},
                                {{3, 0}, {2, 9}}};
    std::cout << "1) Sözlük sırası (std::pair::operator<):\n";
    for (const auto& c : ciftler) {
        std::cout << "  (" << c[0].first << ", " << c[0].second << ") < ("
                  << c[1].first << ", " << c[1].second << "): "
                  << (c[0] < c[1] ? "True" : "False") << "\n";
    }
    std::priority_queue<Cift, std::vector<Cift>, std::greater<Cift>> obek;
    for (Cift x : {Cift{4, 2}, Cift{1, 5}, Cift{4, 1}, Cift{1, 3}}) {
        obek.push(x);
    }
    std::cout << "2) priority_queue + std::greater ile çıkarma sırası:";
    while (!obek.empty()) {
        std::cout << " (" << obek.top().first << ", " << obek.top().second
                  << ")";
        obek.pop();
    }
    std::priority_queue<Oge> en_buyuk;      // operator< tanımlı: en büyük öbek
    for (Oge x : {Oge{4, 2}, Oge{1, 5}, Oge{4, 1}, Oge{1, 3}}) {
        en_buyuk.push(x);
    }
    std::cout << "\n3) struct Oge (operator< std::tie ile), varsayılan en "
                 "büyük öbek:";
    while (!en_buyuk.empty()) {
        std::cout << " (" << en_buyuk.top().uzaklik << ", "
                  << en_buyuk.top().kose << ")";
        en_buyuk.pop();
    }
    std::cout << "\n";
    return 0;
}

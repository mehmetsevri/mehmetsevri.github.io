/* H12_K02_bit_tamponu.c — AP-2 Hafta 12 · Kavram 2
 * Amaç    : Kaputun Altında — Huffman kodlarının bit tamponuna yazılması:
 *           bit i, bayt i / 8'e; bayt içinde önce en anlamlı bit (MSB önce,
 *           Örnek 6'daki düzen) ya da önce en az anlamlı bit (LSB önce).
 *           Son bayttaki dolgu bitleri (bayt hizalama) ve geri okuma.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H12_K02_bit_tamponu.c \
 *           -o H12_K02_bit_tamponu
 * Eşleri  : H12_K02_bit_tamponu.py (aynı tampon + int.to_bytes)
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static void ikilik_yaz(uint8_t b)
{
    for (int k = 7; k >= 0; k--) {
        putchar('0' + (b >> k & 1));
    }
}

/* kodlar[] ardışık yazılır; msb_once: bayt içi bit sırası */
static size_t yaz(const char *const *kodlar, int k, uint8_t *tampon,
                  size_t boyut, bool msb_once)
{
    size_t i = 0;
    memset(tampon, 0, boyut);
    for (int j = 0; j < k; j++) {
        for (const char *c = kodlar[j]; *c != '\0'; c++, i++) {
            if (*c == '1') {
                int konum = msb_once ? 7 - (int)(i & 7) : (int)(i & 7);
                tampon[i >> 3] |= (uint8_t)(1u << konum);
            }
        }
    }
    return i;                            /* yazılan bit sayısı */
}

static int oku(const uint8_t *tampon, size_t i, bool msb_once)
{
    int konum = msb_once ? 7 - (int)(i & 7) : (int)(i & 7);
    return tampon[i >> 3] >> konum & 1;
}

int main(void)
{
    const char *const kodlar[5] = {"110", "0", "1011", "0", "111"};
    uint8_t tampon[4];
    printf("Kodlar sırayla: 110 0 1011 0 111 (toplam ");
    size_t bit = 0;
    for (int j = 0; j < 5; j++) {
        bit += strlen(kodlar[j]);
    }
    size_t bayt = (bit + 7) / 8;
    printf("%zu bit -> %zu bayt, dolgu %zu bit)\n", bit, bayt,
           bayt * 8 - bit);
    for (int m = 1; m >= 0; m--) {
        yaz(kodlar, 5, tampon, sizeof tampon, m == 1);
        printf("%s:", m ? "MSB önce (Örnek 6)" : "LSB önce          ");
        for (size_t b = 0; b < bayt; b++) {
            printf(" ");
            ikilik_yaz(tampon[b]);
            printf(" = 0x%02X", tampon[b]);
        }
        printf("\n  geri okunan bitler: ");
        for (size_t i = 0; i < bit; i++) {
            printf("%d", oku(tampon, i, m == 1));
        }
        printf("\n");
    }
    printf("Not: dolgu bitleri 0'dır; çözücü kaç bit (ya da kaç simge) "
           "okuyacağını\nbilmezse dolguyu veri sanabilir.\n");
    return 0;
}

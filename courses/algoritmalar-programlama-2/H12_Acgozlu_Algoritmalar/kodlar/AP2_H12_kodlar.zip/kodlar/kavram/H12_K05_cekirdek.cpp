/* H12_K05_cekirdek.cpp — AP-2 Hafta 12 · Kavram 5
 * Amaç    : Haftanın açgözlü algoritmalarının yazdırmasız çekirdekleri
 *           (slaytlar ve "Üç Dilde" için kısa sürümler). Örneklerdeki
 *           fonksiyonların izleme ve sayaç satırları atılmıştır; adlar,
 *           eşitlik kırma kuralları ve sonuçlar örneklerle aynıdır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H12_K05_cekirdek.cpp \
 *           -o H12_K05_cekirdek
 * Çalıştır: ./H12_K05_cekirdek
 * Eşleri  : kavram/H12_K05_cekirdek.c · kavram/H12_K05_cekirdek.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <functional>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

static const int SONSUZ = std::numeric_limits<int>::max();

// (anahtar, no) çiftleri; std::greater ile en küçük öbek (H7'nin karşılığı)
using Oge = std::pair<int, int>;
using Obek = std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>>;

// ---- Örnek 2 ve 3: yarı açık aralıklar [bas, bit)
struct Aralik {
    int bas, bit, kimlik;
};

// Tam sıralama (bit, bas, kimlik): std::sort kararsızdır
static bool bitise_gore(const Aralik& x, const Aralik& y)
{
    return std::tie(x.bit, x.bas, x.kimlik) <
           std::tie(y.bit, y.bas, y.kimlik);
}

// Tam sıralama (bas, bit, kimlik)
static bool basa_gore(const Aralik& x, const Aralik& y)
{
    return std::tie(x.bas, x.bit, x.kimlik) <
           std::tie(y.bas, y.bit, y.kimlik);
}

// Örnek 2: en erken biten ilk; seçilen sayısını döndürür
static int en_erken_biten(std::vector<Aralik> a,
                          std::vector<Aralik>& secilen)
{
    std::sort(a.begin(), a.end(), bitise_gore);
    int son_bitis = -1;
    for (const Aralik& x : a) {
        if (x.bas >= son_bitis) {        // açgözlü seçim
            secilen.push_back(x);
            son_bitis = x.bit;
        }
    }
    return static_cast<int>(secilen.size());
}

// Örnek 3: aralık bölümleme; salon sayısını döndürür
static int bolumle(std::vector<Aralik> a, std::vector<int>& salon)
{
    std::sort(a.begin(), a.end(), basa_gore);
    Obek obek;                           // (bitiş, salon)
    int salon_sayisi = 0;
    for (const Aralik& x : a) {
        int s;
        if (!obek.empty() && obek.top().first <= x.bas) {
            s = obek.top().second;             // boşalan salon
            obek.pop();
        } else {
            s = salon_sayisi++;                // yeni salon
        }
        salon[x.kimlik] = s;
        obek.push({x.bit, s});
    }
    return salon_sayisi;
}

// ---- Örnek 4: kesirli sırt çantası
struct Yuk {
    int agirlik, deger, kimlik;
};

// Birim değere göre azalan: v1/w1 > v2/w2  <=>  v1·w2 > v2·w1
static bool birim_degere_gore(const Yuk& x, const Yuk& y)
{
    long long sol = static_cast<long long>(x.deger) * y.agirlik;
    long long sag = static_cast<long long>(y.deger) * x.agirlik;
    if (sol != sag) {
        return sol > sag;
    }
    return x.kimlik < y.kimlik;
}

// Toplam değer (pay, payda) (kayan nokta yok)
static std::pair<long long, long long> doldur(std::vector<Yuk> y,
                                              int kapasite)
{
    std::sort(y.begin(), y.end(), birim_degere_gore);
    long long tam = 0;
    int kalan = kapasite;
    for (const Yuk& x : y) {
        if (kalan == 0) {
            break;
        }
        if (x.agirlik <= kalan) {        // tamamı sığar
            kalan -= x.agirlik;
            tam += x.deger;
        } else {                         // kesri alınır, çanta dolar
            long long pay = tam * x.agirlik +
                            static_cast<long long>(x.deger) * kalan;
            return {pay, x.agirlik};
        }
    }
    return {tam, 1};
}

// ---- Örnek 5: Huffman ağacı (düğümler vektörlerde)
struct Agac {
    std::vector<int> sembol, siklik, sol, sag;   // sembol -1: iç düğüm
    int kok = -1;
};

static int dugum_ekle(Agac& t, int sembol, int siklik, int sol, int sag)
{
    t.sembol.push_back(sembol);
    t.siklik.push_back(siklik);
    t.sol.push_back(sol);
    t.sag.push_back(sag);
    return static_cast<int>(t.sembol.size()) - 1;
}

// Öbekte (sıklık, düğüm no): eşitlikte önce oluşturulan çıkar
static void agac_kur(const std::vector<int>& siklik, Agac& t)
{
    Obek obek;
    for (int b = 0; b < static_cast<int>(siklik.size()); b++) {
        int d = dugum_ekle(t, b, siklik[b], -1, -1);
        obek.push({siklik[b], d});
    }
    while (obek.size() > 1) {
        auto [fx, x] = obek.top();       // en küçük iki ağaç
        obek.pop();
        auto [fy, y] = obek.top();
        obek.pop();
        int f = fx + fy;
        int z = dugum_ekle(t, -1, f, x, y);
        obek.push({f, z});
    }
    t.kok = obek.top().second;
}

// Kökten yaprağa: sol 0, sağ 1; tek düğümlü ağaçta kod "0"
static void kod_ata(const Agac& t, int d, const std::string& kod,
                    std::vector<std::string>& kodlar)
{
    if (t.sembol[d] >= 0) {
        kodlar[t.sembol[d]] = kod.empty() ? "0" : kod;
        return;
    }
    kod_ata(t, t.sol[d], kod + "0", kodlar);
    kod_ata(t, t.sag[d], kod + "1", kodlar);
}

// ---- Örnek 7–13: graf (komşular artan hedef sırasıyla)
struct Komsu {
    int hedef, agirlik;
};

struct Graf {
    std::vector<std::vector<Komsu>> komsu;
};

struct Kenar {
    int u, v, w;
};

// Yönsüz graf: kenarlar (u, v) sırasıyla verilirse komşular sıralı olur
static Graf graf_kur(int n, const std::vector<Kenar>& e)
{
    Graf g;
    g.komsu.resize(n);
    for (const Kenar& k : e) {
        g.komsu[k.u].push_back({k.v, k.w});
        g.komsu[k.v].push_back({k.u, k.w});
    }
    return g;
}

// Kesinleşmemiş, d'si en küçük köşe; yoksa -1 (eşitlikte küçük no)
static int en_yakin(const std::vector<int>& d,
                    const std::vector<bool>& kesin)
{
    int u = -1;
    for (int v = 0; v < static_cast<int>(d.size()); v++) {
        if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
            u = v;
        }
    }
    return u;
}

// Örnek 7: dizi tabanlı Dijkstra, Θ(V²)
static void dijkstra_dizi(const Graf& g, int s, std::vector<int>& d,
                          std::vector<int>& ebeveyn)
{
    int n = static_cast<int>(g.komsu.size());
    std::vector<bool> kesin(n, false);
    d.assign(n, SONSUZ);
    ebeveyn.assign(n, -1);
    d[s] = 0;
    int u;
    while ((u = en_yakin(d, kesin)) >= 0) {
        kesin[u] = true;                 // d[u] artık kesin
        for (const Komsu& k : g.komsu[u]) {
            int v = k.hedef, w = k.agirlik;
            if (!kesin[v] && d[u] != SONSUZ && d[u] + w < d[v]) {
                d[v] = d[u] + w;         // gevşetme
                ebeveyn[v] = u;
            }
        }
    }
}

// Örnek 8: öbekli Dijkstra, tembel silme. Öbekten çıkan u'nun d[u]'su
// sonludur: d[u] + w taşmaz.
static void dijkstra_obek(const Graf& g, int s, std::vector<int>& d,
                          std::vector<int>& ebeveyn)
{
    int n = static_cast<int>(g.komsu.size());
    std::vector<bool> kesin(n, false);
    Obek obek;                           // (uzaklık, köşe)
    d.assign(n, SONSUZ);
    ebeveyn.assign(n, -1);
    d[s] = 0;
    obek.push({0, s});
    while (!obek.empty()) {
        auto [du, u] = obek.top();
        obek.pop();
        if (kesin[u]) {
            continue;                    // eskimiş kayıt
        }
        kesin[u] = true;
        for (const Komsu& k : g.komsu[u]) {
            int v = k.hedef, w = k.agirlik;
            if (!kesin[v] && d[u] + w < d[v]) {
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                obek.push({d[v], v});
            }
        }
    }
}

// ---- Örnek 10: birleşim–bul (rütbe + yol sıkıştırma)
struct BirlesimBul {
    std::vector<int> ebeveyn, rutbe;
    explicit BirlesimBul(int n) : ebeveyn(n), rutbe(n, 0)
    {
        std::iota(ebeveyn.begin(), ebeveyn.end(), 0);
    }
};

// Kökü bul, sonra yoldaki her düğümü köke bağla (iki geçiş)
static int bul(BirlesimBul& b, int x)
{
    int kok = x;
    while (b.ebeveyn[kok] != kok) {
        kok = b.ebeveyn[kok];
    }
    while (b.ebeveyn[x] != kok) {
        int sonraki = b.ebeveyn[x];
        b.ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

// Rütbeye göre birleştir; zaten aynı kümedeyse false
static bool birlestir(BirlesimBul& b, int x, int y)
{
    int kx = bul(b, x), ky = bul(b, y);
    if (kx == ky) {
        return false;
    }
    if (b.rutbe[kx] < b.rutbe[ky]) {
        std::swap(kx, ky);
    }
    b.ebeveyn[ky] = kx;
    if (b.rutbe[kx] == b.rutbe[ky]) {
        b.rutbe[kx]++;
    }
    return true;
}

// ---- Örnek 11: Kruskal; toplam ağırlığı döndürür
static int kruskal(std::vector<Kenar> e, int n, std::vector<Kenar>& agac)
{
    BirlesimBul b(n);
    std::sort(e.begin(), e.end(), [](const Kenar& x, const Kenar& y) {
        return std::tie(x.w, x.u, x.v) < std::tie(y.w, y.u, y.v);
    });
    int toplam = 0;
    for (const Kenar& k : e) {
        if (birlestir(b, k.u, k.v)) {    // döngü yoksa kabul
            agac.push_back(k);
            toplam += k.w;
        }
    }
    return toplam;
}

// ---- Örnek 12: Prim (öbekle, tembel silme)
static int prim(const Graf& g, int s, std::vector<int>& ebeveyn)
{
    int n = static_cast<int>(g.komsu.size());
    std::vector<bool> agacta(n, false);
    std::vector<int> anahtar(n, SONSUZ);
    Obek obek;                           // (anahtar, köşe)
    ebeveyn.assign(n, -1);
    anahtar[s] = 0;
    obek.push({0, s});
    int toplam = 0;
    while (!obek.empty()) {
        auto [a, u] = obek.top();
        obek.pop();
        if (agacta[u]) {
            continue;                    // eskimiş kayıt
        }
        agacta[u] = true;
        toplam += a;
        for (const Komsu& k : g.komsu[u]) {
            int v = k.hedef, w = k.agirlik;
            if (!agacta[v] && w < anahtar[v]) {  // Dijkstra: d[u] + w
                anahtar[v] = w;
                ebeveyn[v] = u;
                obek.push({w, v});
            }
        }
    }
    return toplam;
}

// ---- Örnek 13: Welsh–Powell; renk sayısını döndürür
static int welsh_powell(const Graf& g, std::vector<int>& renk)
{
    int n = static_cast<int>(g.komsu.size());
    std::vector<int> sira(n);
    std::iota(sira.begin(), sira.end(), 0);
    std::sort(sira.begin(), sira.end(), [&g](int x, int y) {
        std::size_t dx = g.komsu[x].size(), dy = g.komsu[y].size();
        return dx != dy ? dx > dy : x < y;   // derece azalan
    });
    renk.assign(n, -1);
    int boyanan = 0, c = 0;
    while (boyanan < n) {                // c rengi için bir tur
        for (int x : sira) {
            bool uygun = renk[x] == -1;
            for (const Komsu& k : g.komsu[x]) {
                if (uygun && renk[k.hedef] == c) {
                    uygun = false;       // c renkli komşu var
                }
            }
            if (uygun) {
                renk[x] = c;
                boyanan++;
            }
        }
        c++;
    }
    return c;
}

static void dizi_yaz(const std::vector<int>& a)
{
    for (int x : a) {
        std::cout << ' ' << x;
    }
}

int main()
{
    // Örnek 2'nin 10 isteği (A..J)
    std::vector<Aralik> istek = {{4, 7, 0}, {0, 3, 1}, {3, 8, 2},
                                 {1, 4, 3}, {7, 10, 4}, {9, 12, 5},
                                 {6, 9, 6}, {11, 14, 7}, {2, 6, 8},
                                 {8, 13, 9}};
    std::vector<Aralik> secilen;
    int k = en_erken_biten(istek, secilen);
    std::cout << "1) en erken biten ilk:";
    for (const Aralik& x : secilen) {
        std::cout << ' ' << static_cast<char>('A' + x.kimlik);
    }
    std::cout << " (" << k << " aralık)\n";

    // Örnek 3'ün 10 dersi (dakika: 540 = 09:00)
    std::vector<Aralik> ders = {{540, 630, 0}, {540, 750, 1},
                                {600, 690, 2}, {630, 720, 3},
                                {660, 840, 4}, {720, 810, 5},
                                {780, 870, 6}, {810, 960, 7},
                                {870, 960, 8}, {900, 990, 9}};
    std::vector<int> salon(10);
    int s = bolumle(ders, salon);
    std::cout << "2) aralık bölümleme: " << s << " salon;";
    for (int i = 0; i < 10; i++) {
        std::cout << ' ' << static_cast<char>('A' + i) << ':'
                  << salon[i] + 1;
    }
    std::cout << '\n';

    // Örnek 4'ün 6 yükü, kapasite 60 kg
    std::vector<Yuk> yuk = {{12, 84, 0}, {8, 40, 1}, {20, 100, 2},
                            {15, 90, 3}, {25, 80, 4}, {9, 30, 5}};
    auto [pay, payda] = doldur(yuk, 60);
    long long g = std::gcd(pay, payda);
    std::cout << "3) kesirli sırt çantası (60 kg): " << pay / g << '/'
              << payda / g << '\n';

    // Örnek 5: Cormen vd. sıklık tablosu a..f
    Agac t;
    agac_kur({45, 13, 12, 16, 9, 5}, t);
    std::vector<std::string> kodlar(6);
    kod_ata(t, t.kok, "", kodlar);
    std::cout << "4) Huffman (Cormen vd.):";
    for (int i = 0; i < 6; i++) {
        std::cout << ' ' << static_cast<char>('a' + i) << '=' << kodlar[i];
    }
    std::cout << '\n';

    // Kampüs grafı (girdiler/h12_kampus.txt)
    std::vector<Kenar> kampus = {{0, 1, 40}, {0, 2, 45}, {0, 7, 60},
                                 {1, 2, 30}, {1, 3, 120}, {1, 7, 140},
                                 {2, 3, 20}, {2, 4, 110}, {3, 4, 50},
                                 {3, 5, 55}, {4, 5, 10}, {4, 6, 70},
                                 {5, 6, 80}, {6, 7, 130}};
    Graf gk = graf_kur(8, kampus);
    std::vector<int> d, ebeveyn;
    dijkstra_dizi(gk, 0, d, ebeveyn);
    std::cout << "5) Dijkstra (dizi), kaynak 0: d =";
    dizi_yaz(d);
    std::cout << '\n';
    dijkstra_obek(gk, 0, d, ebeveyn);
    std::cout << "6) Dijkstra (öbek), kaynak 0: d =";
    dizi_yaz(d);
    std::cout << "; ebeveyn =";
    dizi_yaz(ebeveyn);
    std::cout << '\n';

    // Örnek 10'un küçük örneği
    BirlesimBul b(8);
    const int cift[8][2] = {{0, 1}, {2, 3}, {0, 2}, {4, 5},
                            {6, 7}, {4, 6}, {1, 5}, {3, 7}};
    for (const auto& c : cift) {
        birlestir(b, c[0], c[1]);
    }
    int kok = bul(b, 0);
    std::cout << "7) birleşim–bul (rütbe + sıkıştırma): bul(0) = " << kok
              << "; ebeveyn =";
    dizi_yaz(b.ebeveyn);
    std::cout << '\n';

    std::vector<Kenar> agac;
    int toplam = kruskal(kampus, 8, agac);
    std::cout << "8) Kruskal:";
    for (const Kenar& e : agac) {
        std::cout << ' ' << e.u << '-' << e.v << " (" << e.w << ')';
    }
    std::cout << "; toplam " << toplam << '\n';

    toplam = prim(gk, 0, ebeveyn);
    std::cout << "9) Prim (0'dan): ebeveyn =";
    dizi_yaz(ebeveyn);
    std::cout << "; toplam " << toplam << '\n';

    // Sınav çakışma grafı (girdiler/h12_cakisma.txt), ağırlıksız
    std::vector<Kenar> cakisma = {{0, 1, 1}, {0, 2, 1}, {0, 4, 1},
                                  {1, 2, 1}, {1, 3, 1}, {2, 3, 1},
                                  {2, 5, 1}, {3, 6, 1}, {4, 5, 1},
                                  {4, 7, 1}, {5, 6, 1}, {5, 7, 1},
                                  {6, 7, 1}};
    Graf gc = graf_kur(8, cakisma);
    std::vector<int> renk;
    int c = welsh_powell(gc, renk);
    std::cout << "10) Welsh–Powell: " << c << " renk;";
    for (int v = 0; v < 8; v++) {
        std::cout << ' ' << v << ':' << renk[v];
    }
    std::cout << '\n';
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort yalnız sıralama için);
 * C++ — std::priority_queue, std::sort; Python — heapq, sorted */

/* H12_K03_demet_karsilastirma.c — AP-2 Hafta 12 · Kavram 3 (C)
 * Amaç    : Dil Penceresi — C'de demet yok: (uzaklık, köşe) bir struct'tır ve
 *           sözlük sırası karşılaştırıcıyla elle yazılır. qsort için
 *           -1/0/1 döndüren karşılaştırıcı, öbek için "küçük mü?" yüklemi.
 *           qsort kararsızdır: karşılaştırıcı tam sıralama tanımlamalıdır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_K03_demet_karsilastirma.c -o H12_K03_demet_karsilastirma
 * Eşleri  : H12_K03_demet_karsilastirma.py · H12_K03_demet_karsilastirma.cpp
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int uzaklik, kose;
} Oge;

/* Öbek için yüklem: (uzaklık, köşe) sözlük sırası */
static bool kucuk_mu(Oge x, Oge y)
{
    return x.uzaklik < y.uzaklik || (x.uzaklik == y.uzaklik && x.kose < y.kose);
}

/* qsort için karşılaştırıcı: -1, 0, 1 (tam sıralama) */
static int karsilastir(const void *p, const void *q)
{
    Oge x = *(const Oge *)p, y = *(const Oge *)q;
    return kucuk_mu(x, y) ? -1 : (kucuk_mu(y, x) ? 1 : 0);
}

int main(void)
{
    const Oge ciftler[3][2] = {{{2, 5}, {2, 7}}, {{2, 7}, {3, 0}},
                               {{3, 0}, {2, 9}}};
    printf("1) Sözlük sırası (elle yazılmış kucuk_mu):\n");
    for (int i = 0; i < 3; i++) {
        Oge a = ciftler[i][0], b = ciftler[i][1];
        printf("  (%d, %d) < (%d, %d): %s\n", a.uzaklik, a.kose, b.uzaklik,
               b.kose, kucuk_mu(a, b) ? "True" : "False");
    }
    Oge dizi[4] = {{4, 2}, {1, 5}, {4, 1}, {1, 3}};
    qsort(dizi, 4, sizeof dizi[0], karsilastir);
    printf("2) qsort + karşılaştırıcı ile sıralı:");
    for (int i = 0; i < 4; i++) {
        printf(" (%d, %d)", dizi[i].uzaklik, dizi[i].kose);
    }
    printf("\n3) Yalnız uzaklığa bakan karşılaştırıcı tam sıralama değildir: "
           "(1, 5) ile (1, 3)\n   eşit sayılır ve qsort'un hangisini önce "
           "koyacağı belirtilmemiştir.\n");
    return 0;
}

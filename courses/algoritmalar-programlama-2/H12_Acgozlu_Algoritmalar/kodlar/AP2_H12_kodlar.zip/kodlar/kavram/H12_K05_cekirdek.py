"""H12_K05_cekirdek.py — AP-2 Hafta 12 · Kavram 5
Amaç    : Haftanın açgözlü algoritmalarının yazdırmasız çekirdekleri
          (slaytlar ve "Üç Dilde" için kısa sürümler). Örneklerdeki
          fonksiyonların izleme ve sayaç satırları atılmıştır; adlar,
          eşitlik kırma kuralları ve sonuçlar örneklerle aynıdır.
Çalıştır: python3 H12_K05_cekirdek.py
Eşleri  : kavram/H12_K05_cekirdek.c · kavram/H12_K05_cekirdek.cpp
Çıktı   : üç dilde aynı (=)
"""
import heapq
from collections import namedtuple
from functools import cmp_to_key
from math import gcd

SONSUZ = 2147483647              # C'deki INT_MAX ile aynı (math.inf değil)

Aralik = namedtuple("Aralik", "bas bit kimlik")   # yarı açık [bas, bit)
Yuk = namedtuple("Yuk", "agirlik deger kimlik")


# ---- Örnek 2 ve 3
def en_erken_biten(a, secilen):
    """Örnek 2: en erken biten ilk; seçilen sayısını döndürür"""
    a = sorted(a, key=lambda x: (x.bit, x.bas, x.kimlik))
    son_bitis = -1
    for x in a:
        if x.bas >= son_bitis:           # açgözlü seçim
            secilen.append(x)
            son_bitis = x.bit
    return len(secilen)


def bolumle(a, salon):
    """Örnek 3: aralık bölümleme; salon sayısını döndürür"""
    a = sorted(a)                        # (bas, bit, kimlik) sırası
    obek = []                            # (bitiş, salon) demetleri
    salon_sayisi = 0
    for x in a:
        if obek and obek[0][0] <= x.bas:
            _, s = heapq.heappop(obek)         # boşalan salon
        else:
            s = salon_sayisi                   # yeni salon
            salon_sayisi += 1
        salon[x.kimlik] = s
        heapq.heappush(obek, (x.bit, s))
    return salon_sayisi


# ---- Örnek 4: kesirli sırt çantası
def birim_degere_gore(p, q):
    """Birim değere göre azalan: v1/w1 > v2/w2  <=>  v1·w2 > v2·w1"""
    sol, sag = p.deger * q.agirlik, q.deger * p.agirlik
    if sol != sag:
        return -1 if sol > sag else 1
    return (p.kimlik > q.kimlik) - (p.kimlik < q.kimlik)


def doldur(y, kapasite):
    """Toplam değer (pay, payda) (kayan nokta yok)"""
    y = sorted(y, key=cmp_to_key(birim_degere_gore))
    tam = 0
    kalan = kapasite
    for x in y:
        if kalan == 0:
            break
        if x.agirlik <= kalan:           # tamamı sığar
            kalan -= x.agirlik
            tam += x.deger
        else:                            # kesri alınır, çanta dolar
            return tam * x.agirlik + x.deger * kalan, x.agirlik
    return tam, 1


# ---- Örnek 5: Huffman ağacı (düğümler listelerde)
class Agac:
    __slots__ = ("sembol", "siklik", "sol", "sag", "kok")

    def __init__(self):
        self.sembol, self.siklik, self.sol, self.sag = [], [], [], []
        self.kok = -1


def dugum_ekle(t, sembol, siklik, sol, sag):
    t.sembol.append(sembol)
    t.siklik.append(siklik)
    t.sol.append(sol)
    t.sag.append(sag)
    return len(t.sembol) - 1


def agac_kur(siklik, t):
    """Öbekte (sıklık, düğüm no): eşitlikte önce oluşturulan çıkar"""
    obek = []
    for b, f in enumerate(siklik):       # yapraklar simge sırasıyla
        d = dugum_ekle(t, b, f, -1, -1)
        heapq.heappush(obek, (f, d))
    while len(obek) > 1:
        fx, x = heapq.heappop(obek)      # en küçük iki ağaç
        fy, y = heapq.heappop(obek)
        f = fx + fy
        z = dugum_ekle(t, -1, f, x, y)
        heapq.heappush(obek, (f, z))
    t.kok = obek[0][1]


def kod_ata(t, d, kod, kodlar):
    """Kökten yaprağa: sol 0, sağ 1; tek düğümlü ağaçta kod "0" """
    if t.sembol[d] >= 0:
        kodlar[t.sembol[d]] = kod if kod else "0"
        return
    kod_ata(t, t.sol[d], kod + "0", kodlar)
    kod_ata(t, t.sag[d], kod + "1", kodlar)


# ---- Örnek 7–13: graf (komşular artan hedef sırasıyla)
def graf_kur(n, kenarlar):
    """Yönsüz graf; komşu listesi (hedef, ağırlık) demetleri.
    Kenarlar (u, v) sırasıyla verilirse komşular sıralı olur."""
    komsu = [[] for _ in range(n)]
    for u, v, w in kenarlar:
        komsu[u].append((v, w))
        komsu[v].append((u, w))
    return komsu


def en_yakin(d, kesin):
    """Kesinleşmemiş, d'si en küçük köşe; yoksa -1"""
    u = -1
    for v in range(len(d)):
        if not kesin[v] and d[v] != SONSUZ and (u < 0 or d[v] < d[u]):
            u = v
    return u


def dijkstra_dizi(g, s):
    """Örnek 7: dizi tabanlı Dijkstra, Θ(V²); (d, ebeveyn)"""
    n = len(g)
    kesin = [False] * n
    d = [SONSUZ] * n
    ebeveyn = [-1] * n
    d[s] = 0
    u = en_yakin(d, kesin)
    while u >= 0:
        kesin[u] = True                  # d[u] artık kesin
        for v, w in g[u]:
            if not kesin[v] and d[u] != SONSUZ and d[u] + w < d[v]:
                d[v] = d[u] + w          # gevşetme
                ebeveyn[v] = u
        u = en_yakin(d, kesin)
    return d, ebeveyn


def dijkstra_obek(g, s):
    """Örnek 8: öbekli Dijkstra, tembel silme; (d, ebeveyn).
    Öbekten çıkan u'nun d[u]'su sonludur."""
    n = len(g)
    kesin = [False] * n
    d = [SONSUZ] * n
    ebeveyn = [-1] * n
    obek = [(0, s)]                      # (uzaklık, köşe) demetleri
    d[s] = 0
    while obek:
        _, u = heapq.heappop(obek)
        if kesin[u]:
            continue                     # eskimiş kayıt
        kesin[u] = True
        for v, w in g[u]:
            if not kesin[v] and d[u] + w < d[v]:
                d[v] = d[u] + w
                ebeveyn[v] = u
                heapq.heappush(obek, (d[v], v))
    return d, ebeveyn


# ---- Örnek 10: birleşim–bul (rütbe + yol sıkıştırma)
class BirlesimBul:
    __slots__ = ("ebeveyn", "rutbe")

    def __init__(self, n):
        self.ebeveyn = list(range(n))
        self.rutbe = [0] * n


def bul(b, x):
    """Kökü bul, sonra yoldaki her düğümü köke bağla (iki geçiş)"""
    kok = x
    while b.ebeveyn[kok] != kok:
        kok = b.ebeveyn[kok]
    while b.ebeveyn[x] != kok:
        sonraki = b.ebeveyn[x]
        b.ebeveyn[x] = kok
        x = sonraki
    return kok


def birlestir(b, x, y):
    """Rütbeye göre birleştir; zaten aynı kümedeyse False"""
    kx, ky = bul(b, x), bul(b, y)
    if kx == ky:
        return False
    if b.rutbe[kx] < b.rutbe[ky]:
        kx, ky = ky, kx
    b.ebeveyn[ky] = kx
    if b.rutbe[kx] == b.rutbe[ky]:
        b.rutbe[kx] += 1
    return True


# ---- Örnek 11: Kruskal
def kruskal(kenarlar, n, agac):
    """Toplam ağırlığı döndürür; kenarlar (w, u, v) sırasıyla"""
    b = BirlesimBul(n)
    toplam = 0
    for w, u, v in sorted((w, u, v) for u, v, w in kenarlar):
        if birlestir(b, u, v):           # döngü yoksa kabul
            agac.append((u, v, w))
            toplam += w
    return toplam


# ---- Örnek 12: Prim (öbekle, tembel silme)
def prim(g, s, ebeveyn):
    n = len(g)
    agacta = [False] * n
    anahtar = [SONSUZ] * n
    obek = [(0, s)]                      # (anahtar, köşe) demetleri
    anahtar[s] = 0
    toplam = 0
    while obek:
        a, u = heapq.heappop(obek)
        if agacta[u]:
            continue                     # eskimiş kayıt
        agacta[u] = True
        toplam += a
        for v, w in g[u]:
            if not agacta[v] and w < anahtar[v]:  # Dijkstra: d[u] + w
                anahtar[v] = w
                ebeveyn[v] = u
                heapq.heappush(obek, (w, v))
    return toplam


# ---- Örnek 13: Welsh–Powell
def welsh_powell(g, renk):
    """Renk sayısını döndürür; derece azalan, eşitlikte küçük numara"""
    n = len(g)
    sira = sorted(range(n), key=lambda v: (-len(g[v]), v))
    for v in range(n):
        renk[v] = -1
    boyanan = 0
    c = 0
    while boyanan < n:                   # c rengi için bir tur
        for x in sira:
            uygun = renk[x] == -1
            for y, _ in g[x]:
                if uygun and renk[y] == c:
                    uygun = False        # c renkli komşu var
            if uygun:
                renk[x] = c
                boyanan += 1
        c += 1
    return c


def main():
    istek = [Aralik(4, 7, 0), Aralik(0, 3, 1), Aralik(3, 8, 2),
             Aralik(1, 4, 3), Aralik(7, 10, 4), Aralik(9, 12, 5),
             Aralik(6, 9, 6), Aralik(11, 14, 7), Aralik(2, 6, 8),
             Aralik(8, 13, 9)]
    secilen = []
    k = en_erken_biten(istek, secilen)
    print("1) en erken biten ilk: " +
          " ".join(chr(65 + x.kimlik) for x in secilen) + f" ({k} aralık)")

    veri = [(540, 630), (540, 750), (600, 690), (630, 720), (660, 840),
            (720, 810), (780, 870), (810, 960), (870, 960), (900, 990)]
    ders = [Aralik(a, b, i) for i, (a, b) in enumerate(veri)]
    salon = [0] * 10
    s = bolumle(ders, salon)
    print(f"2) aralık bölümleme: {s} salon; " +
          " ".join(f"{chr(65 + i)}:{salon[i] + 1}" for i in range(10)))

    yuk = [Yuk(12, 84, 0), Yuk(8, 40, 1), Yuk(20, 100, 2),
           Yuk(15, 90, 3), Yuk(25, 80, 4), Yuk(9, 30, 5)]
    pay, payda = doldur(yuk, 60)
    g = gcd(pay, payda)
    print(f"3) kesirli sırt çantası (60 kg): {pay // g}/{payda // g}")

    t = Agac()
    agac_kur([45, 13, 12, 16, 9, 5], t)
    kodlar = [""] * 6
    kod_ata(t, t.kok, "", kodlar)
    print("4) Huffman (Cormen vd.): " +
          " ".join(f"{chr(97 + i)}={kodlar[i]}" for i in range(6)))

    kampus = [(0, 1, 40), (0, 2, 45), (0, 7, 60), (1, 2, 30), (1, 3, 120),
              (1, 7, 140), (2, 3, 20), (2, 4, 110), (3, 4, 50), (3, 5, 55),
              (4, 5, 10), (4, 6, 70), (5, 6, 80), (6, 7, 130)]
    gk = graf_kur(8, kampus)
    d, ebeveyn = dijkstra_dizi(gk, 0)
    print("5) Dijkstra (dizi), kaynak 0: d = " + " ".join(map(str, d)))
    d, ebeveyn = dijkstra_obek(gk, 0)
    print("6) Dijkstra (öbek), kaynak 0: d = " + " ".join(map(str, d)) +
          "; ebeveyn = " + " ".join(map(str, ebeveyn)))

    b = BirlesimBul(8)
    for x, y in [(0, 1), (2, 3), (0, 2), (4, 5), (6, 7), (4, 6), (1, 5),
                 (3, 7)]:
        birlestir(b, x, y)
    kok = bul(b, 0)
    print(f"7) birleşim–bul (rütbe + sıkıştırma): bul(0) = {kok}; "
          "ebeveyn = " + " ".join(map(str, b.ebeveyn)))

    agac = []
    toplam = kruskal(kampus, 8, agac)
    print("8) Kruskal: " + " ".join(f"{u}-{v} ({w})" for u, v, w in agac) +
          f"; toplam {toplam}")

    ebeveyn = [-1] * 8
    toplam = prim(gk, 0, ebeveyn)
    print("9) Prim (0'dan): ebeveyn = " + " ".join(map(str, ebeveyn)) +
          f"; toplam {toplam}")

    cakisma = [(0, 1, 1), (0, 2, 1), (0, 4, 1), (1, 2, 1), (1, 3, 1),
               (2, 3, 1), (2, 5, 1), (3, 6, 1), (4, 5, 1), (4, 7, 1),
               (5, 6, 1), (5, 7, 1), (6, 7, 1)]
    gc = graf_kur(8, cakisma)
    renk = [0] * 8
    c = welsh_powell(gc, renk)
    print(f"10) Welsh–Powell: {c} renk; " +
          " ".join(f"{v}:{renk[v]}" for v in range(8)))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (qsort yalnız sıralama için);
# C++ — std::priority_queue, std::sort; Python — heapq, sorted

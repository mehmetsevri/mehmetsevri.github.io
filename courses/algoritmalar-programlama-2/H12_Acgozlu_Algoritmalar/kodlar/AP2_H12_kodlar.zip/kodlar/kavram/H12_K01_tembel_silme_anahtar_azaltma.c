/* H12_K01_tembel_silme_anahtar_azaltma.c — AP-2 Hafta 12 · Kavram 1
 * Amaç    : Kaputun Altında — öncelik kuyruğunda "anahtar azaltma"
 *           (decrease-key: konum dizili öbek, her köşe öbekte en çok bir kez)
 *           ile "tembel silme" (köşeyi yeni uzaklıkla yeniden it, eskimiş
 *           kaydı çıkınca atla) arasındaki bellek–zaman ödünleşimi: öbeğin
 *           en büyük boyu, itme/çıkarma sayısı, öbek içi karşılaştırma ve
 *           ek dizi belleği. Süreler stderr'e (bu çalıştırmada).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H12_K01_tembel_silme_anahtar_azaltma.c ../c/ortak_rastgele.c \
 *           ../c/zamanlayici.c -I../c -o H12_K01_tembel_silme_anahtar_azaltma
 * Çalıştır: ./H12_K01_tembel_silme_anahtar_azaltma
 */
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define SONSUZ INT_MAX

typedef struct {                 /* CSR graf (deney programındaki gibi) */
    int n;
    long long *bas;
    int *hedef, *agirlik;
} Graf;

typedef struct {
    long long itme, cikarma, atlanan, azaltma, karsilastirma, en_buyuk;
} Sayac;

static Sayac s;

/* Sahiplik: g'nin dizileri graf_yok_et ile serbest bırakılır */
static bool graf_uret(Graf *g, int n, int d)
{
    g->n = n;
    g->bas = malloc(((size_t)n + 1) * sizeof *g->bas);
    g->hedef = malloc((size_t)n * (size_t)d * sizeof *g->hedef);
    g->agirlik = malloc((size_t)n * (size_t)d * sizeof *g->agirlik);
    if (g->bas == NULL || g->hedef == NULL || g->agirlik == NULL) {
        return false;
    }
    rastgele_tohum(42);
    for (int u = 0; u <= n; u++) {
        g->bas[u] = (long long)u * d;
    }
    for (int u = 0; u < n; u++) {
        long long k = g->bas[u];
        g->hedef[k] = (u + 1) % n;
        g->agirlik[k] = rastgele_aralik(1, 1000);
        for (k++; k < g->bas[u + 1]; k++) {
            g->hedef[k] = rastgele_aralik(0, n - 1);
            g->agirlik[k] = rastgele_aralik(1, 1000);
        }
    }
    return true;
}

static void graf_yok_et(Graf *g)
{
    free(g->bas);
    free(g->hedef);
    free(g->agirlik);
}

/* --- (1) Tembel silme: (uzaklık, köşe) öğeleri, yinelenen kayıtlar --- */
typedef struct {
    int uzaklik, kose;
} Oge;

static bool kucuk(Oge x, Oge y)
{
    s.karsilastirma++;
    return x.uzaklik < y.uzaklik || (x.uzaklik == y.uzaklik && x.kose < y.kose);
}

static void tembel(const Graf *g, int *d, Oge *a)  /* a: E + 1 yuva */
{
    long long n_obek = 0;
    bool *kesin = calloc((size_t)g->n, sizeof *kesin);
    if (kesin == NULL) {
        return;
    }
    for (int v = 0; v < g->n; v++) {
        d[v] = SONSUZ;
    }
    d[0] = 0;
    a[n_obek++] = (Oge){0, 0};
    s.itme++;
    while (n_obek > 0) {
        Oge x = a[0], son = a[--n_obek];
        long long i = 0;
        s.cikarma++;
        while (2 * i + 1 < n_obek) {
            long long c = 2 * i + 1;
            if (c + 1 < n_obek && kucuk(a[c + 1], a[c])) {
                c++;
            }
            if (!kucuk(a[c], son)) {
                break;
            }
            a[i] = a[c];
            i = c;
        }
        a[i] = son;
        int u = x.kose;
        if (kesin[u]) {
            s.atlanan++;
            continue;
        }
        kesin[u] = true;
        for (long long k = g->bas[u]; k < g->bas[u + 1]; k++) {
            int v = g->hedef[k], w = g->agirlik[k];
            if (!kesin[v] && d[u] + w < d[v]) {
                d[v] = d[u] + w;
                Oge y = {d[v], v};       /* yeni kayıt; eskisi öbekte kalır */
                long long j = n_obek++;
                while (j > 0 && kucuk(y, a[(j - 1) / 2])) {
                    a[j] = a[(j - 1) / 2];
                    j = (j - 1) / 2;
                }
                a[j] = y;
                s.itme++;
                if (n_obek > s.en_buyuk) {
                    s.en_buyuk = n_obek;
                }
            }
        }
    }
    free(kesin);
}

/* --- (2) Anahtar azaltma: öbekte köşeler; konum[v] = v'nin yuvası --- */
static bool kucuk_k(const int *d, int x, int y)
{
    s.karsilastirma++;
    return d[x] < d[y] || (d[x] == d[y] && x < y);
}

static void yukari(int *a, int *konum, const int *d, int i)
{
    int x = a[i];
    while (i > 0 && kucuk_k(d, x, a[(i - 1) / 2])) {
        a[i] = a[(i - 1) / 2];
        konum[a[i]] = i;
        i = (i - 1) / 2;
    }
    a[i] = x;
    konum[x] = i;
}

static void anahtar_azaltma(const Graf *g, int *d, int *a, int *konum)
{
    int n_obek = 0;
    for (int v = 0; v < g->n; v++) {
        d[v] = SONSUZ;
        konum[v] = -1;                   /* -1: hiç girmedi, -2: çıktı */
    }
    d[0] = 0;
    a[n_obek++] = 0;
    konum[0] = 0;
    s.itme++;
    s.en_buyuk = 1;
    while (n_obek > 0) {
        int u = a[0], son = a[--n_obek];
        konum[u] = -2;
        s.cikarma++;
        if (n_obek > 0) {                /* son öğeyi kökten aşağı süz */
            int i = 0;
            while (2 * i + 1 < n_obek) {
                int c = 2 * i + 1;
                if (c + 1 < n_obek && kucuk_k(d, a[c + 1], a[c])) {
                    c++;
                }
                if (!kucuk_k(d, a[c], son)) {
                    break;
                }
                a[i] = a[c];
                konum[a[i]] = i;
                i = c;
            }
            a[i] = son;
            konum[son] = i;
        }
        for (long long k = g->bas[u]; k < g->bas[u + 1]; k++) {
            int v = g->hedef[k], w = g->agirlik[k];
            if (konum[v] != -2 && d[u] + w < d[v]) {
                d[v] = d[u] + w;
                if (konum[v] == -1) {    /* ilk kez: ekle */
                    a[n_obek] = v;
                    yukari(a, konum, d, n_obek++);
                    s.itme++;
                    if (n_obek > s.en_buyuk) {
                        s.en_buyuk = n_obek;
                    }
                } else {                 /* öbekte: anahtarı azalt */
                    yukari(a, konum, d, konum[v]);
                    s.azaltma++;
                }
            }
        }
    }
}

static void rapor(int n, int derece)
{
    Graf g;
    if (!graf_uret(&g, n, derece)) {
        graf_yok_et(&g);
        return;
    }
    long long e = (long long)n * derece;
    int *d1 = malloc((size_t)n * sizeof *d1);
    int *d2 = malloc((size_t)n * sizeof *d2);
    Oge *a = malloc(((size_t)e + 1) * sizeof *a);
    int *b = malloc((size_t)n * sizeof *b);
    int *konum = malloc((size_t)n * sizeof *konum);
    if (d1 && d2 && a && b && konum) {
        double t0 = zaman_sn();
        s = (Sayac){0, 0, 0, 0, 0, 1};
        tembel(&g, d1, a);
        Sayac t = s;
        double t1 = zaman_sn();
        s = (Sayac){0, 0, 0, 0, 0, 0};
        anahtar_azaltma(&g, d2, b, konum);
        double t2 = zaman_sn();
        bool ayni = true;
        for (int v = 0; v < n; v++) {
            ayni = ayni && d1[v] == d2[v];
        }
        printf("V = %d, E = %lld (derece %d), uzaklıklar aynı mı? %s\n", n, e,
               derece, ayni ? "evet" : "HAYIR");
        printf("  yöntem                 itme    çıkarma    atlanan    azaltma"
               "  karşılaştırma  en büyük öbek\n");
        printf("  %-16s %10lld %10lld %10lld %10lld %14lld %14lld\n",
               "tembel silme", t.itme, t.cikarma, t.atlanan, t.azaltma,
               t.karsilastirma, t.en_buyuk);
        printf("  %-16s %10lld %10lld %10lld %10lld %14lld %14lld\n",
               "anahtar azaltma", s.itme, s.cikarma, s.atlanan, s.azaltma,
               s.karsilastirma, s.en_buyuk);
        printf("  öbek belleği (en büyük boy × öğe): tembel %lld × 8 bayt = "
               "%lld bayt; azaltma %lld × 4 bayt + konum[] %d × 4 bayt = "
               "%lld bayt\n", t.en_buyuk, t.en_buyuk * 8, s.en_buyuk, n,
               s.en_buyuk * 4 + (long long)n * 4);
        fprintf(stderr, "  (bu çalıştırmada) tembel %.3f ms, azaltma "
                "%.3f ms\n", (t1 - t0) * 1000.0, (t2 - t1) * 1000.0);
    }
    free(d1);
    free(d2);
    free(a);
    free(b);
    free(konum);
    graf_yok_et(&g);
}

int main(void)
{
    printf("Tembel silme ve anahtar azaltma (rastgele yönlü graflar, tohum "
           "42)\n");
    printf("Not: tembel silmede öbek öğesi 8 bayttır (int uzaklık + int köşe;"
           " bu makinede);\nanahtar azaltmada öbek yalnız köşe numarası "
           "tutar, uzaklık d[]'den okunur.\n\n");
    rapor(10000, 4);
    printf("\n");
    rapor(2000, 1000);
    return 0;
}

/* H12_K04_sonsuz.cpp — AP-2 Hafta 12 · Kavram 4 (C++)
 * Amaç    : Dil Penceresi — std::numeric_limits<T>: int için max() gözcü
 *           olarak kullanılır (has_infinity = false); double için
 *           infinity() vardır. Taşma koruması C'dekiyle aynıdır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H12_K04_sonsuz.cpp \
 *           -o H12_K04_sonsuz
 * Eşleri  : H12_K04_sonsuz.c · H12_K04_sonsuz.py
 */
#include <cmath>
#include <iostream>
#include <limits>

static const int SONSUZ = std::numeric_limits<int>::max();

static bool kisalir_mi(int du, int w, int dv)
{
    return du != SONSUZ && du + w < dv;
}

int main()
{
    std::cout << "numeric_limits<int>::max() = " << SONSUZ
              << ", has_infinity = "
              << std::numeric_limits<int>::has_infinity << "\n";
    std::cout << "numeric_limits<long long>::max() = "
              << std::numeric_limits<long long>::max() << "\n";
    std::cout << "koruma ile: kisalir_mi(SONSUZ, 5, SONSUZ) = "
              << kisalir_mi(SONSUZ, 5, SONSUZ) << "\n";
    double inf = std::numeric_limits<double>::infinity();
    std::cout << "double: infinity() = " << inf << ", has_infinity = "
              << std::numeric_limits<double>::has_infinity
              << ", inf + 5 == inf: " << (inf + 5 == inf)
              << ", std::isinf: " << std::isinf(inf) << "\n";
    return 0;
}

"""H12_K03_demet_karsilastirma.py — AP-2 Hafta 12 · Kavram 3 (Python)
Amaç    : Dil Penceresi — Python demetleri sözlük sırasıyla karşılaştırılır:
          önce ilk öğe, eşitse ikinci… heapq bu yüzden (uzaklık, köşe)
          demetlerini ek kod yazmadan doğru sıralar. Eşit sıklıkta
          karşılaştırılamayan bir nesneye gelinirse TypeError; çözüm,
          benzersiz bir ikincil anahtar (düğüm no / oluşturulma sırası).
Çalıştır: python3 H12_K03_demet_karsilastirma.py
Eşleri  : H12_K03_demet_karsilastirma.c · H12_K03_demet_karsilastirma.cpp
"""
import heapq


class Dugum:
    """Karşılaştırma işleçleri (<) tanımlanmamış bir sınıf"""
    __slots__ = ("simge",)

    def __init__(self, simge):
        self.simge = simge


def main():
    print("1) Sözlük sırası:")
    for a, b in (((2, 5), (2, 7)), ((2, 7), (3, 0)), ((3, 0), (2, 9))):
        print(f"  {a} < {b}: {a < b}")
    print("2) heapq ile (uzaklık, köşe) demetleri:")
    obek = []
    for x in ((4, 2), (1, 5), (4, 1), (1, 3)):
        heapq.heappush(obek, x)
    print("  çıkarma sırası:", " ".join(str(heapq.heappop(obek))
                                        for _ in range(4)))
    print("3) (sıklık, Dugum) demeti: eşit sıklıkta ikinci öğe "
          "karşılaştırılır")
    obek = []
    try:
        heapq.heappush(obek, (5, Dugum("a")))
        heapq.heappush(obek, (5, Dugum("b")))
        print("  hata yok")
    except TypeError as e:
        print(f"  TypeError: {e}")
    print("4) (sıklık, düğüm no, Dugum): düğüm no benzersiz, üçüncü öğeye "
          "hiç gelinmez")
    obek = []
    for no, (f, s) in enumerate(((5, "a"), (5, "b"), (2, "c"))):
        heapq.heappush(obek, (f, no, Dugum(s)))
    print("  çıkarma sırası:", " ".join(
        f"({f}, {no}, {d.simge})" for f, no, d in
        (heapq.heappop(obek) for _ in range(3))))


if __name__ == "__main__":
    main()

# Hafta 12 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı ve beklenen çıktısıyla aşağıdadır. **Ders notu** sütunu kodun gösterildiği bölümü (Ek A: C++ ve Python karşılıkları) ve dosyanın anıldığı PDF sayfalarını, **Sunum** kod slaytlarını ve metinde anıldığı slaytları, **Web** örnek kutusunu, satır içi kodu ve metin anılmasını verir (betikle, görünür metinden). Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11.15 (örnekler 3.10 uyumludur).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] -o program [-lm]` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. Graf dosyası alan örnekler (7, 8, 9, 11, 12, 13) `girdiler/` altındaki dosyaları argüman olarak alır (biçim: rehber 14.3, `girdiler/KAYNAK_NOTU.txt`); standart girdiden okuyan örnek (6) `./program < girdiler/KÖK.txt` ile çalışır.

Eşdeğerlik: `python3 esdeger_test.py .` → **13/13 GEÇTİ** (13 “=”: üç dilde bayt bayt aynı stdout), uyarı 0; `--asan` (AddressSanitizer + UBSan + LeakSanitizer) ile **13/13 GEÇTİ** (hatalı 0). Valgrind: 45/45 program temiz (0 hata, 0 bayt kayıp); alıştırma/quiz 6/6 temiz (`BELLEK_DENETIMI.txt`).


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H12_01_para_ustu` | ★ | = | — | Para üstü: açgözlü çözüm (AP-1 H4 sistemi), kanonik {1, 5, 10, 25} ve {1, 3, 4} sisteminde 6 için karşı örnek; kaba kuvvetle (tüm kombinasyonlar) doğrulama | — | Bölüm 3.2; Ek A.1; metin s. 3, 4, 5, 6, 31, 45 … | slayt metin: 5 | örnek kutusu (üç dil), satır içi kod, metin |
| `H12_02_aralik_cizelgeleme` | ★★ | = | evet | Aralık çizelgeleme: en erken biten ilk; üç yanlış ölçütün (en kısa, en erken başlayan, en az çakışan) kaba kuvvetle doğrulanmış karşı örnekleri; değiş tokuş argümanının kâhinle denetimi | — | Ek A.2; metin s. 3, 4, 5, 9, 10, 11 … | slayt metin: 12, 14, 16, 17 | örnek kutusu (üç dil), metin |
| `H12_03_aralik_bolumleme` | ★★ | = | — | Aralık bölümleme: en az salon; başlangıca göre sıra, salon bitişleri en küçük öbekte (bitiş, salon); salon ataması ve alt sınır (aynı anda en çok ders) | — | Ek A.3; metin s. 3, 5, 12, 13, 41, 49 … | slayt metin: 18 | örnek kutusu (üç dil), metin |
| `H12_04_kesirli_sirt_cantasi` | ★★ | = | evet | Kesirli sırt çantası: birim değere göre seçim, tamsayı kesirle değer; kâhin: bütün sıralamalar; 0/1 sırt çantasında aynı ölçütün başarısızlığı | — | Ek A.4; metin s. 3, 5, 14, 15, 42, 44 … | slayt metin: 20 | örnek kutusu (üç dil), metin |
| `H12_05_huffman_agaci` | ★★★ | = | evet | Huffman ağacı: sıklık tablosu, birleştirme adımları ve öbek içeriği, kod tablosu (simge sırasıyla), ağırlıklı yol uzunluğu; tek simgeli metin | — | Ek A.5; metin s. 3, 4, 17, 18, 31, 41 … | slayt metin: 22, 23, 24 | örnek kutusu (üç dil), metin |
| `H12_06_huffman_kodlama` | ★★★ | = | evet | Huffman ile metin kodlama/çözme: bit tamponu, dolgu bitleri, sıkıştırma oranı, entropi; Ömer Seyfettin metninde çözülen = özgün | < girdiler/H12_06_huffman_kodlama.txt | Bölüm 5.1; Ek A.6; metin s. 2, 3, 4, 8, 19, 31 … | slayt metin: 25 | örnek kutusu (üç dil), satır içi kod, metin |
| `H12_07_dijkstra_dizi` | ★★ | = | evet | Ağırlıklı graf okuma (ortak biçim) ve dizi tabanlı O(V²) Dijkstra: kesinleşen küme, gevşetme ve uzaklık tablosu adım adım | girdiler/h12_kampus.txt 0 | Ek A.7; metin s. 3, 4, 19, 20, 21, 49 … | slayt metin: 31 | örnek kutusu (üç dil), metin |
| `H12_08_dijkstra_obek` | ★★★ | = | evet | Öbekli Dijkstra: (uzaklık, köşe) demetleri, tembel silme ve eskimiş kayıt sayacı, en kısa yolların yazdırılması; kâhin: dizi tabanlı Dijkstra | girdiler/h12_kampus.txt 0 | Ek A.8; metin s. 3, 20, 21, 43, 49, 56 | slayt metin: 26, 28, 34 | örnek kutusu (üç dil), metin |
| `H12_09_negatif_kenar` | ★★ | = | — | Negatif kenarda Dijkstra'nın yanlış sonucu (karşı örnek); kâhin Bellman–Ford; ağırlıklara sabit eklemenin neden çözüm olmadığı | girdiler/h12_negatif.txt | Ek A.9; metin s. 2, 3, 21, 31, 32, 38 … | slayt metin: 36 | örnek kutusu (üç dil), metin |
| `H12_10_birlesim_bul` | ★★ | = | evet | Birleşim–bul: saf, yalnız rütbe, yalnız yol sıkıştırma, ikisi birden; işaretçi izleme sayısı ve ağaç yüksekliği (küçük örnek, zincir, rastgele) | — | Ek A.10; metin s. 3, 4, 23, 24, 58 | slayt metin: 37 | örnek kutusu (üç dil), metin |
| `H12_11_kruskal` | ★★★ | = | evet | Kruskal: kenarlar (w, u, v) sırasıyla, birleşim–bul ile döngü denetimi; kabul/ret, birleşim–bul ormanı, kesim özelliği; kâhin: kaba kuvvet | girdiler/h12_kampus.txt | Ek A.11; metin s. 3, 5, 26, 27, 42, 49 … | slayt metin: 40 | örnek kutusu (üç dil), metin |
| `H12_12_prim` | ★★★ | = | evet | Prim (öbekle) ve Kruskal: aynı toplam; farklı ağırlıklarda aynı, eşit ağırlıklarda farklı ağaç; rastgele graflarda denetim | girdiler/h12_kampus.txt girdiler/h12_esit_agirlik.txt | Ek A.12; metin s. 3, 29, 60 | slayt metin: 43 | örnek kutusu (üç dil), metin |
| `H12_13_graf_boyama` | ★★★ | = | — | Açgözlü graf boyama (Welsh–Powell): sınav çakışma grafında oturum ataması; kaba kuvvetle kromatik sayı; en iyi olmayan sonuç örnekleri | girdiler/h12_cakisma.txt girdiler/h12_yol6.txt girdiler/h12_tac8.txt | Ek A.13; metin s. 2, 3, 31, 32, 33, 38 … | slayt metin: 45 | örnek kutusu (üç dil), metin |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt`. C++/Python'da C'den anlam olarak farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`. Graf okuyucu (Örnek 7) Örnek 8, 9, 11, 12 ve 13'te aynen yinelenir (her dosya tek başına derlenir).

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`. Kullananlar: ortak_rastgele — Örnek 2, 3, 7, 8, 10, 12; zamanlayici merdivende kullanılmaz (kavram programı K01 ve deney programları kullanır).


## 2. Kavram programları (kavram/)

Merdiven dışı küçük programlar (Kaputun Altında, Dil Penceresi). Çıktılar `kavram/ciktilar/`; “bu çalıştırmada” etiketli değerler (süreler) eşdeğerlik kapsamı dışındadır.

| Dosya | Dil | Amaç | Çıktı | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H12_K01_tembel_silme_anahtar_azaltma.c` | C | Kaputun Altında — öncelik kuyruğunda "anahtar azaltma" (decrease-key: konum dizili öbek, her köşe öbekte en çok bir kez) ile "tembel silme" (köşeyi yeni uzaklıkla yeniden it, eskimiş kaydı çıkınca atla) arasındaki bellek–zaman ödünleşimi: öbeğin en büyük boyu, itme/çıkarma sayısı, öbek içi karşılaştırma ve ek dizi belleği. Süreler stderr'e (bu çalıştırmada). | `ciktilar/H12_K01_tembel_silme_anahtar_azaltma_c.txt` | metin s. 7, 8 | slayt metin: 33 | metin |
| `kavram/H12_K02_bit_tamponu.c` | C | Kaputun Altında — Huffman kodlarının bit tamponuna yazılması: bit i, bayt i / 8'e; bayt içinde önce en anlamlı bit (MSB önce, Örnek 6'daki düzen) ya da önce en az anlamlı bit (LSB önce). Son bayttaki dolgu bitleri (bayt hizalama) ve geri okuma. | `ciktilar/H12_K02_bit_tamponu_c.txt` | metin s. 8 | — | metin |
| `kavram/H12_K02_bit_tamponu.py` | Python | Kaputun Altında / Dil Penceresi — Huffman kodlarının bit tamponuna yazılması: bytearray ile MSB önce ve LSB önce düzen, dolgu bitleri; aynı sonucun int ile kurulup int.to_bytes ile baytlara çevrilmesi ve int.from_bytes ile geri okunması. | `ciktilar/H12_K02_bit_tamponu_py.txt` | metin s. 8 | — | metin |
| `kavram/H12_K03_demet_karsilastirma.c` | C | Dil Penceresi — C'de demet yok: (uzaklık, köşe) bir struct'tır ve sözlük sırası karşılaştırıcıyla elle yazılır. qsort için -1/0/1 döndüren karşılaştırıcı, öbek için "küçük mü?" yüklemi. qsort kararsızdır: karşılaştırıcı tam sıralama tanımlamalıdır. | `ciktilar/H12_K03_demet_karsilastirma_c.txt` | metin s. 37, 38 | — | metin |
| `kavram/H12_K03_demet_karsilastirma.cpp` | C++ | Dil Penceresi — std::pair ve std::tuple (std::tie) sözlük sırasıyla karşılaştırılır; std::priority_queue<std::pair<…>, std::vector<…>, std::greater<…>> en küçük öbek olur. Kendi struct'ımız için ya operator< ya da karşılaştırıcı gerekir (tanımlanmazsa priority_queue derlenmez). | `ciktilar/H12_K03_demet_karsilastirma_cpp.txt` | metin s. 37, 38 | — | metin |
| `kavram/H12_K03_demet_karsilastirma.py` | Python | Dil Penceresi — Python demetleri sözlük sırasıyla karşılaştırılır: önce ilk öğe, eşitse ikinci… heapq bu yüzden (uzaklık, köşe) demetlerini ek kod yazmadan doğru sıralar. Eşit sıklıkta karşılaştırılamayan bir nesneye gelinirse TypeError; çözüm, benzersiz bir ikincil anahtar (düğüm no / oluşturulma sırası). | `ciktilar/H12_K03_demet_karsilastirma_py.txt` | metin s. 37, 38 | — | metin |
| `kavram/H12_K04_sonsuz.c` | C | Dil Penceresi — "sonsuz uzaklık": int'te sonsuz yoktur, en büyük değer (INT_MAX) gözcü olarak kullanılır ve toplama taşma korumalı yapılır (INT_MAX + w işaretli taşma: tanımsız davranış, Hata Avcısı 4). double'da INFINITY vardır. | `ciktilar/H12_K04_sonsuz_c.txt` | metin s. 38 | — | metin |
| `kavram/H12_K04_sonsuz.cpp` | C++ | Dil Penceresi — std::numeric_limits<T>: int için max() gözcü olarak kullanılır (has_infinity = false); double için infinity() vardır. Taşma koruması C'dekiyle aynıdır. | `ciktilar/H12_K04_sonsuz_cpp.txt` | metin s. 38 | — | metin |
| `kavram/H12_K04_sonsuz.py` | Python | Dil Penceresi — Python tamsayısı taşmaz; math.inf (float) her tamsayıdan büyüktür ve toplamada değişmez. Ama yazdırılınca "inf" çıkar ve float'tır: ders örnekleri üç dilde aynı çıktı için C'deki INT_MAX ile aynı tamsayı sabitini kullanır (rehber 14.2). | `ciktilar/H12_K04_sonsuz_py.txt` | metin s. 38 | — | metin |
| `kavram/H12_K05_cekirdek.c` | C | Haftanın açgözlü algoritmalarının yazdırmasız çekirdekleri (slaytlar ve "Üç Dilde" için kısa sürümler). Örneklerdeki fonksiyonların izleme ve sayaç satırları atılmıştır; adlar, eşitlik kırma kuralları ve sonuçlar örneklerle aynıdır. | `ciktilar/H12_K05_cekirdek_c.txt` | Bölüm 4.1; Bölüm 4.2; Bölüm 4.3; Bölüm 4.4; Bölüm 4.5; Bölüm 4.6; Bölüm 4.7; Bölüm 4.8; Bölüm 5.3; metin s. 9, 49 | slayt kod: 15, 31, 32, 38 | satır içi kod, metin |
| `kavram/H12_K05_cekirdek.cpp` | C++ | Haftanın açgözlü algoritmalarının yazdırmasız çekirdekleri (slaytlar ve "Üç Dilde" için kısa sürümler). Örneklerdeki fonksiyonların izleme ve sayaç satırları atılmıştır; adlar, eşitlik kırma kuralları ve sonuçlar örneklerle aynıdır. | `ciktilar/H12_K05_cekirdek_cpp.txt` | Bölüm 4.1; Bölüm 4.2; Bölüm 4.3; Bölüm 4.4; Bölüm 4.5; Bölüm 4.6; Bölüm 4.7; Bölüm 4.8; metin s. 9, 49 | slayt kod: 32, 38 | satır içi kod, metin |
| `kavram/H12_K05_cekirdek.py` | Python | Haftanın açgözlü algoritmalarının yazdırmasız çekirdekleri (slaytlar ve "Üç Dilde" için kısa sürümler). Örneklerdeki fonksiyonların izleme ve sayaç satırları atılmıştır; adlar, eşitlik kırma kuralları ve sonuçlar örneklerle aynıdır. | `ciktilar/H12_K05_cekirdek_py.txt` | Bölüm 4.1; Bölüm 4.2; Bölüm 4.3; Bölüm 4.4; Bölüm 4.5; Bölüm 4.6; Bölüm 4.7; Bölüm 4.8; metin s. 9, 49 | slayt kod: 32, 38 | satır içi kod, metin |


## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir. Belirtiler bu makinede, bu çalıştırmada gözlenmiştir (`hata_avcisi/ciktilar/`; HA4'te UBSan raporu yol/PID sadeleştirilmiş olarak). HA3 `-I../cpp` ile derlenir (ortak_rastgele.hpp).

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H12_HA1_en_kisa_aralik.py` | Python | kasıtlı hata | aralık çizelgelemede açgözlü ölçüt yanlış seçilmiş: "en kısa aralık ilk". Elle denenen iki kolay örnekte doğru sonuç verdiği için kod "doğru" sanılır; karşı örnekle ya da kâhinle (kaba kuvvet) sınanmamıştır. | `ciktilar/H12_HA1_en_kisa_aralik.txt` | — | — | — |
| `hata_avcisi/H12_HA1_en_kisa_aralik_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H12_HA1_en_kisa_aralik_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H12_HA2_erken_kesinlestirme.c` | C | kasıtlı hata | Dijkstra'da köşe öbeğe İTİLİRKEN kesinleşmiş sayılıyor (kesin[v] = true gevşetmede). Sonradan bulunan daha kısa yol "kesin" köşeye giremez; ilk bulunan uzaklık donar. | `ciktilar/H12_HA2_erken_kesinlestirme.txt` | Bölüm 7; metin s. 36 | slayt kod: 49 | satır içi kod, metin |
| `hata_avcisi/H12_HA2_erken_kesinlestirme_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H12_HA2_erken_kesinlestirme_duzeltilmis.txt` | metin s. 36 | slayt kod: 49 | metin |
| `hata_avcisi/H12_HA3_eskimis_kayit.cpp` | C++ | kasıtlı hata | tembel silmeli Dijkstra'da öbekten çıkan ESKİMİŞ kayıt (du > d[u]) atlanmıyor: köşe yeniden "işlenir", bütün kenarları yeniden incelenir. Negatif kenar yokken uzaklıklar yine doğru çıkar (gevşetme başarısız olur) ama iş artar; kesinleşme sırası aynı köşeyi birkaç kez içerir. | `ciktilar/H12_HA3_eskimis_kayit.txt` | — | — | — |
| `hata_avcisi/H12_HA3_eskimis_kayit_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H12_HA3_eskimis_kayit_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H12_HA4_sonsuz_tasmasi.c` | C | kasıtlı hata | sonsuz uzaklık INT_MAX ile gösteriliyor ama (1) en küçük seçimi ulaşılamayan (d = INT_MAX) köşeyi de seçiyor, (2) gevşetmede d[u] + w toplanmadan önce d[u] != SONSUZ denetlenmiyor. INT_MAX + w işaretli taşmadır: C'de TANIMSIZ DAVRANIŞ. | `ciktilar/H12_HA4_sonsuz_tasmasi.txt` `ciktilar/H12_HA4_sonsuz_tasmasi_ubsan.txt` | metin s. 37 | — | metin |
| `hata_avcisi/H12_HA4_sonsuz_tasmasi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H12_HA4_sonsuz_tasmasi_duzeltilmis.txt` | metin s. 37 | — | metin |
| `hata_avcisi/H12_HA5_dongu_denetimsiz.c` | C | kasıtlı hata | Kruskal'da döngü denetimi yok: kenarlar (w, u, v) sırasıyla alınıyor ve V - 1 kenar olunca duruluyor. Seçilen kenarlar döngü kurabilir ve bazı köşeler hiç bağlanmaz; toplam ağırlık en küçük kapsayan ağaçtan bile KÜÇÜK çıkar (çünkü ağaç değildir). | `ciktilar/H12_HA5_dongu_denetimsiz.txt` | metin s. 37 | — | metin |
| `hata_avcisi/H12_HA5_dongu_denetimsiz_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H12_HA5_dongu_denetimsiz_duzeltilmis.txt` | metin s. 37 | — | metin |
| `hata_avcisi/H12_HA6_tek_simge.c` | C | kasıtlı hata | Huffman'da tek simgeli metin: ağaç tek düğümdür (kök yapraktır), kökten yaprağa yol boştur ve simgenin kodu BOŞ dizgi olur. Kodlanmış metin 0 bittir; bitlerle sürülen çözücü hiçbir simge üretmez: veri kaybolur. | `ciktilar/H12_HA6_tek_simge_c.txt` | — | — | — |
| `hata_avcisi/H12_HA6_tek_simge.py` | Python | kasıtlı hata | Huffman'da tek simgeli metin: ağaç tek düğümdür (kök yapraktır) ve simgenin kodu BOŞ dizgi olur; kodlanmış metin 0 bayttır. Bu çözücü simge sayısıyla sürülür ve her simge için en az bir bit okur: boş tamponu okumaya çalışır (C'deki sürümde bitlerle sürülen çözücü ise hiç simge üretmiyordu). | `ciktilar/H12_HA6_tek_simge_py.txt` | — | — | — |
| `hata_avcisi/H12_HA6_tek_simge_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H12_HA6_tek_simge_duzeltilmis_c.txt` | — | — | — |
| `hata_avcisi/H12_HA6_tek_simge_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H12_HA6_tek_simge_duzeltilmis_py.txt` | — | — | — |


## 4. Haftanın Deneyi (deney/)

Sürücü `python3 deney/h12_olcum_calistir.py` (derler, çalıştırır, ham CSV'leri ve `OLCUM_ORTAMI.txt`'yi yazar; ≈ 2 dk), çözümleme `python3 deney/h12_cozumle.py` (özet CSV/JSON: katlar, eğimler, kesişim noktaları, kestirimler), grafikler `python3 ../gorseller/kaynak/h12_deney_grafik.py`. Ortak modüllerin kopyaları `deney/{c,cpp,python}/` içindedir.

| Dosya | Dil | Amaç | Argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `deney/c/H12_deney_birlesim_bul.c` | C | Birleşim–bul sürümlerinin (saf, yalnız rütbe, yalnız yol sıkıştırma, ikisi birden) işlem başına işaretçi izleme sayısı ve süresi; n rastgele birleştirme + n rastgele bul (3n bul çağrısı) | N saf\|rutbe\|sikistirma\|ikisi\|hepsi TEKRAR [CSV] | — | — | — |
| `deney/c/H12_deney_dijkstra.c` | C | Dizi tabanlı O(V²) Dijkstra ile öbek tabanlı (tembel silmeli) O((V + E) log V) Dijkstra'nın süresi ve sayaçları; seyrek ve yoğun graflar, rastgele (LCG) ve kötü durum ağırlıkları | V D AGIRLIK SURUM TEKRAR [CSV] | — | — | — |
| `deney/cpp/H12_deney_birlesim_bul.cpp` | C++ | Birleşim–bul sürümlerinin (saf, yalnız rütbe, yalnız yol sıkıştırma, ikisi birden) işlem başına işaretçi izleme sayısı ve süresi; n rastgele birleştirme + n rastgele bul (3n bul çağrısı) | N saf\|rutbe\|sikistirma\|ikisi\|hepsi TEKRAR [CSV] | — | — | — |
| `deney/cpp/H12_deney_dijkstra.cpp` | C++ | Dizi tabanlı O(V²) Dijkstra, elle yazılmış öbekli Dijkstra ve std::priority_queue'lu Dijkstra (etiketli kütüphane serisi); süre ve sayaçlar. Graf üretimi C sürümüyle birebir aynıdır. | V D lcg\|kotu dizi\|elle\|kutuphane\|hepsi TEKRAR [CSV] (anlamlar C sürümünün başlığında) | — | — | — |
| `deney/python/H12_deney_birlesim_bul.py` | Python | Birleşim–bul sürümlerinin (saf, yalnız rütbe, yalnız yol sıkıştırma, ikisi birden) işlem başına işaretçi izleme sayısı ve süresi; n rastgele birleştirme + n rastgele bul (3n bul çağrısı) | N saf\|rutbe\|sikistirma\|ikisi\|hepsi TEKRAR [CSV] | — | — | — |
| `deney/python/H12_deney_dijkstra.py` | Python | Dizi tabanlı O(V²) Dijkstra, elle yazılmış öbekli Dijkstra ve heapq'lu Dijkstra (etiketli kütüphane serisi); süre ve sayaçlar. Graf üretimi C sürümüyle birebir aynıdır (ortak LCG). | V D lcg\|kotu dizi\|elle\|kutuphane\|hepsi TEKRAR [CSV] | — | — | — |
| `deney/h12_olcum_calistir.py` | Python | AP-2 Hafta 12 · Haftanın Deneyi sürücüsü | — | metin s. 36 | — | metin |
| `deney/h12_cozumle.py` | Python | AP-2 Hafta 12 · Haftanın Deneyi çözümlemesi | — | — | — | — |

Ham ve özet veriler (`deney/sonuclar/`): `h12_denetim.json`, `h12_deney_birlesim_bul.csv`, `h12_deney_dijkstra_olcek.csv`, `h12_deney_dijkstra_yogunluk.csv`, `h12_olcum_gunlugu.txt`, `h12_ozet.json`, `h12_ozet_birlesim_bul.csv`, `h12_ozet_kesisim.csv`, `h12_ozet_olcek.csv`; ölçüm ortamı `deney/OLCUM_ORTAMI.txt`.


## 5. Girdiler (girdiler/)

Kaynak ve telif bilgisi: `girdiler/KAYNAK_NOTU.txt`.

| Dosya | Açıklama |
|---|---|
| `girdiler/H12_06_huffman_kodlama.txt` | Örnek 6 standart girdisi (52424 bayt; H10 Ömer Seyfettin metninin aynısı) |
| `girdiler/KAYNAK_NOTU.txt` | Girdilerin kaynağı, telif durumu ve kurgusal veriler |
| `girdiler/h12_a02_graf.txt` | Graf dosyası `6 9 yonsuz`: Alıştırma 12.2 (KURGUSAL): 6 köşe, 9 yönsüz kenar; ağırlık = süre (dk). Kullanan: Örnek — |
| `girdiler/h12_cakisma.txt` | Graf dosyası `8 13 yonsuz`: Sınav çakışma grafı (KURGUSAL): köşe = ders, kenar = iki dersin ortak öğrencisi var (aynı oturuma konamaz). Kullanan: Örnek 13 |
| `girdiler/h12_esit_agirlik.txt` | Graf dosyası `4 4 yonsuz`: Eşit ağırlıklı kenarlar: en küçük kapsayan ağaç tek değil (Örnek 12). Kullanan: Örnek 12 |
| `girdiler/h12_kampus.txt` | Graf dosyası `8 14 yonsuz`: H12 kampüs grafı (KURGUSAL): 8 bina, 14 yol; ağırlık = yol uzunluğu (m). Kullanan: Örnek 7, 8, 11, 12 |
| `girdiler/h12_kampus_atolye.txt` | Graf dosyası `10 18 yonsuz`: Atölye 3 kampüs grafı (KURGUSAL): 10 bina, 18 yol; ağırlık = yol uzunluğu (m). Kullanan: Örnek — |
| `girdiler/h12_negatif.txt` | Graf dosyası `4 4 yonlu`: Negatif ağırlıklı kenar içeren yönlü graf: Dijkstra'nın karşı örneği (Örnek 9). Kullanan: Örnek 9 |
| `girdiler/h12_tac8.txt` | Graf dosyası `8 12 yonsuz`: Taç grafı (crown graph): u_i = 2i, v_i = 2i + 1 (i = 0..3); u_i ile v_j i != j iken komşu. Kullanan: Örnek 13 |
| `girdiler/h12_yol6.txt` | Graf dosyası `6 5 yonsuz`: 6 köşeli yol grafı 0-3-4-5-2-1 (iki parçalı: kromatik sayı 2). Kullanan: Örnek 13 |


## 6. Alıştırma ve quiz programları (alistirmalar/, quiz/)

Alıştırmaların ve quiz sorularının kodlu dosyaları. Çıktıları (`alistirmalar/ciktilar/`, `quiz/ciktilar/`) yanıt olduğu için öğrenci ZIP'inde yoktur. Parsons bulmacası (A08) bilerek derlenmez; “hata bul” dosyaları (A06, A07) kasıtlı mantık hatası içerir ama bellek açısından temizdir (ASan + Valgrind, `BELLEK_DENETIMI.txt`).

| Dosya | Dil | Kullanım | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `alistirmalar/H12_A01_cikti_tahmini.c` | C | Alıştırma 12.1 | Çıktı tahmini — açgözlü para üstü dört tutarda; programı çalıştırmadan önce her satırın çıktısını kâğıda yazın | metin s. 41 | slayt metin: 51 | metin |
| `alistirmalar/H12_A06_hata_bul_prim.c` | C | Alıştırma 12.7 | Hata bulma — bu "Prim" gerçekleştirimi kampüs grafında bir kapsayan ağaç buluyor ama toplamı Kruskal'ınkiyle (Örnek 11) uyuşmuyor. Hatalı satırı bulun, nedenini açıklayın, düzeltin. | Alıştırma 12.7; metin s. 42 | — | satır içi kod, metin |
| `alistirmalar/H12_A07_hata_bul_kesirli.py` | Python | Alıştırma 12.8 | Hata bulma — kesirli sırt çantası Örnek 4'ün yükleriyle bir değer buluyor ama kâhinin (Örnek 4: 992/3) altında kalıyor. Hatalı satırı bulun; neden yalnız bazı girdilerde ortaya çıktığını açıklayın ve düzeltin. | Alıştırma 12.8; metin s. 42 | — | satır içi kod, metin |
| `alistirmalar/H12_A08_parsons_kruskal.c` | C | Alıştırma 12.9 | Parsons — Kruskal fonksiyonunun gövde satırları karıştırıldı ve girintileri silindi; doğru sıraya dizin, girintiyi verin. İki satır çeldiricidir (kullanılmaz). Tamamlanacak; bu hâliyle derlenmez. | Alıştırma 12.9; metin s. 42 | — | satır içi kod, metin |
| `alistirmalar/H12_A12_oncelik_kuyrugu.cpp` | C++ | Alıştırma 12.13 | Diller arası okuma — aynı dört (uzaklık, köşe) kaydı C++'ta std::priority_queue'ya, Python'da heapq'ya itilip çıkarılıyor. İki programın çıktısını çalıştırmadan tahmin edin. | Alıştırma 12.13; metin s. 38, 43 | — | satır içi kod, metin |
| `alistirmalar/H12_A12_oncelik_kuyrugu.py` | Python | Alıştırma 12.13 | Diller arası okuma — aynı dört (uzaklık, köşe) kaydı C++'ta std::priority_queue'ya, Python'da heapq'ya itilip çıkarılıyor. İki programın çıktısını çalıştırmadan tahmin edin. | metin s. 38, 43 | — | metin |
| `alistirmalar/H12_A14_huffman_metin.c` | C | Atölye 2 aracı; Alıştırma 12.3 | Kendi metniniz için Huffman ağacı: bayt sıklıkları, birleştirme adımları, kod tablosu ve toplam bit. Eşitlik kuralı Örnek 5 ile aynıdır: öbekte (sıklık, düğüm no); yapraklar bayt değeri sırasıyla numaralanır; ilk çıkan sol (0), ikinci sağ (1) çocuk. Elle kurduğunuz ağacı bu çıktıyla doğrulayın. | metin s. 3, 19, 41, 44 | — | metin |
| `alistirmalar/H12_A14_huffman_metin.py` | Python | Atölye 2 aracı; Alıştırma 12.3 | Kendi metniniz için Huffman ağacı: bayt sıklıkları, birleştirme adımları, kod tablosu ve toplam bit. Eşitlik kuralı Örnek 5 ile aynıdır: öbekte (sıklık, düğüm no); yapraklar bayt değeri sırasıyla numaralanır; ilk çıkan sol (0), ikinci sağ (1) çocuk. Elle kurduğunuz ağacı bu çıktıyla doğrulayın. | metin s. 3, 19, 41, 44 | — | metin |
| `alistirmalar/H12_A15_karsi_ornek_ara.py` | Python | Atölye 1 aracı | "Açgözlü mü, değil mi?" kartları için karşı örnek arayıcı. Bir açgözlü stratejiyi küçük rastgele örneklerde kaba kuvvetle karşılaştırır; uyuşmazlık bulursa EN KÜÇÜK karşı örneği yazar. Kendi stratejinizi STRATEJILER sözlüğüne bir fonksiyon olarak ekleyin. Karşı örnek bulunamaması kanıt DEĞİLDİR. | metin s. 3, 38, 44 | — | metin |
| `quiz/H12_Q05_oncelik_kuyrugu.cpp` | C++ | web quiz sorusu 5 | std::priority_queue + std::greater ile çıkarma sırası | — | — | satır içi kod |
| `quiz/H12_Q08_birlesim_bul.c` | C | web quiz sorusu 8 | Saf birleştirme ve yol sıkıştırma: bul(0)'dan sonra ebeveyn | — | — | satır içi kod |
| `quiz/H12_Q10_demet.py` | Python | web quiz sorusu 10 | heapq'da (sıklık, Dugum) demetleri: eşit sıklıkta ne olur? | — | — | satır içi kod |


## 7. Diğer

- `BELLEK_DENETIMI.txt` — Valgrind (ve ASan) bellek denetimi sonuçları (betikle üretildi; doğrulama kanıtıdır).
- `ornekler.json` — örnek üst verisi (başlık, düzey, çıktı türü, argümanlar, fark satırları, Dil Penceresi notu).
- `esdeger_test.py` — eşdeğerlik testi (ortak; değiştirilmedi).
- `../web/AP2_H12_kartlar.json` — 8 algoritma kimlik kartı (sayılar çıktılardan ve deney özetinden).

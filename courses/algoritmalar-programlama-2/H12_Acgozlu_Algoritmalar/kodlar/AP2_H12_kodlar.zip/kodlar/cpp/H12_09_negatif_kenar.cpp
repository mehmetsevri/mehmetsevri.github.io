/* H12_09_negatif_kenar.cpp — AP-2 Hafta 12 · Örnek 9 (★★)
 * Amaç    : Negatif ağırlıklı kenarda Dijkstra'nın yanlış sonucu (karşı
 *           örnek): kesinleşen köşe sonradan bulunan kısa yolla
 *           güncellenemez. Kâhin: Bellman–Ford (yalnız doğrulama için).
 *           Ağırlıklara sabit eklemenin neden çözüm olmadığı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_09_negatif_kenar.cpp -o H12_09_negatif_kenar
 * Çalıştır: ./H12_09_negatif_kenar ../girdiler/h12_negatif.txt
 * Eşleri  : c/H12_09_negatif_kenar.c · python/H12_09_negatif_kenar.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : Dijkstra Örnek 7'nin dizi tabanlı sürümüdür (önkoşul denetimi
 *           bu örnekte bilerek yapılmaz).
 */
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <tuple>
#include <vector>

static const int SONSUZ = std::numeric_limits<int>::max();
static const std::size_t SATIR_UZUNLUGU = 512;  // C'deki fgets tamponu

static long long taranan_hucre = 0;
static long long kenar_inceleme = 0;
static long long gevsetme_sayisi = 0;

// ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ----------------
struct Komsu {
    int hedef, agirlik;
};

struct Kenar {
    int u, v, w;
};

struct Graf {
    int v_sayisi = 0, e_sayisi = 0;
    bool yonlu = false;
    std::vector<std::vector<Komsu>> komsu;  // komsu[u]: u'dan çıkanlar
    std::vector<Kenar> kenar;               // dosyadaki sırayla
};

static void hata(const std::string& ileti)
{
    std::cerr << "Hata: " << ileti << "\n";
}

static void komsulari_sirala(Graf& g)     // (hedef, agirlik) artan
{
    for (auto& liste : g.komsu) {
        std::sort(liste.begin(), liste.end(),
                  [](const Komsu& x, const Komsu& y) {
                      return std::tie(x.hedef, x.agirlik) <
                             std::tie(y.hedef, y.agirlik);
                  });
    }
}

// '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural)
static bool tamsayi_coz(const std::string& s, int& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9) {
        return false;
    }
    for (std::size_t i = bas; i < s.size(); i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
    }
    x = std::stoi(s);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

static std::vector<std::string> parcala(const std::string& s)
{
    std::vector<std::string> t;
    std::size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && bosluk_mu(s[i])) {
            i++;
        }
        std::size_t j = i;
        while (j < s.size() && !bosluk_mu(s[j])) {
            j++;
        }
        if (j > i) {
            t.push_back(s.substr(i, j - i));
        }
        i = j;
    }
    return t;
}

// Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
// (w yoksa 1). true: başarı; false: hata (ileti stderr'de).
static bool graf_oku(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    if (!f) {
        hata("dosya açılamadı: " + yol);
        return false;
    }
    std::string satir;
    int no = 0;
    bool baslik = false;
    while (std::getline(f, satir)) {
        no++;
        if (satir.size() > SATIR_UZUNLUGU - 2) {
            hata("satır " + std::to_string(no) + ": satır çok uzun");
            return false;
        }
        std::vector<std::string> t = parcala(satir);
        if (t.empty() || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            std::string tur = t.size() == 3 ? t[2] : "yonsuz";
            if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], v) ||
                !tamsayi_coz(t[1], e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 || (tur != "yonlu" && tur != "yonsuz")) {
                hata("satır " + std::to_string(no) +
                     ": başlık 'V E [yonlu|yonsuz]' bekleniyordu");
                return false;
            }
            g.v_sayisi = v;
            g.e_sayisi = e;
            g.yonlu = tur == "yonlu";
            g.komsu.assign(v, {});
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], u) ||
            !tamsayi_coz(t[1], v) || (t.size() == 3 && !tamsayi_coz(t[2], w))) {
            hata("satır " + std::to_string(no) +
                 ": kenar 'u v [w]' bekleniyordu");
            return false;
        }
        if (u < 0 || u >= g.v_sayisi || v < 0 || v >= g.v_sayisi) {
            hata("satır " + std::to_string(no) + ": köşe numarası 0.." +
                 std::to_string(g.v_sayisi - 1) + " aralığında olmalı");
            return false;
        }
        if (static_cast<int>(g.kenar.size()) == g.e_sayisi) {
            hata("satır " + std::to_string(no) + ": fazla kenar (E = " +
                 std::to_string(g.e_sayisi) + ")");
            return false;
        }
        g.kenar.push_back(Kenar{u, v, w});
        g.komsu[u].push_back(Komsu{v, w});
        if (!g.yonlu) {
            g.komsu[v].push_back(Komsu{u, w});
        }
    }
    if (!baslik) {
        hata("başlık satırı yok");
        return false;
    }
    if (static_cast<int>(g.kenar.size()) < g.e_sayisi) {
        hata("kenar sayısı eksik: " + std::to_string(g.e_sayisi) +
             " bekleniyordu, " + std::to_string(g.kenar.size()) + " okundu");
        return false;
    }
    komsulari_sirala(g);
    return true;
}
// --------------------------------------------------------------------------

static std::string uzaklik_yaz(int d, int genislik)
{
    std::string s = d == SONSUZ ? "∞" : std::to_string(d);
    int gorunur = d == SONSUZ ? 1 : static_cast<int>(s.size());
    return std::string(std::max(0, genislik - gorunur), ' ') + s;
}

// O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama
static void dijkstra_dizi(const Graf& g, int kaynak, std::vector<int>& d,
                          std::vector<int>& ebeveyn, bool yaz)
{
    int n = g.v_sayisi;
    std::vector<bool> kesin(n, false);
    d.assign(n, SONSUZ);
    ebeveyn.assign(n, -1);
    d[kaynak] = 0;
    for (int adim = 1; adim <= n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {    // en küçük d: doğrusal tarama
            taranan_hucre++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;                       // kalanlar ulaşılamaz
        }
        kesin[u] = true;                 // d[u] artık kesin
        if (yaz) {
            std::cout << "  adım " << adim << ": seç " << u << " (d = "
                      << d[u] << "); kesinleşen {";
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (kesin[x]) {
                    std::cout << (ilk ? "" : ", ") << x;
                    ilk = false;
                }
            }
            std::cout << "}\n";
        }
        for (const Komsu& k : g.komsu[u]) {
            int v = k.hedef, w = k.agirlik;
            kenar_inceleme++;
            if (kesin[v]) {
                continue;
            }
            if (d[u] != SONSUZ && d[u] + w < d[v]) {   // taşma korumalı
                if (yaz) {
                    std::cout << "     gevşet " << u << "->" << v << " (w = "
                              << w << "): d[" << v << "] = "
                              << uzaklik_yaz(d[v], 1) << " -> " << d[u] + w
                              << "\n";
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
            } else if (yaz) {
                std::cout << "     " << u << "->" << v << " (w = " << w
                          << "): " << d[u] << " + " << w << " >= " << d[v]
                          << ", değişmez\n";
            }
        }
        if (yaz) {
            std::cout << "     d:";
            for (int x : d) {
                std::cout << " " << uzaklik_yaz(x, 1);
            }
            std::cout << "\n";
        }
    }
}

// Kâhin: V - 1 tur, her turda bütün kenarlar (dosya sırasıyla)
// gevşetilir; bir tur daha iyileşme varsa negatif döngü vardır.
// Negatif döngü varsa true döndürür.
static bool bellman_ford(const Graf& g, int kaynak, std::vector<int>& d,
                         bool yaz)
{
    d.assign(g.v_sayisi, SONSUZ);
    d[kaynak] = 0;
    for (int tur = 1; tur < g.v_sayisi; tur++) {
        bool degisti = false;
        for (const Kenar& k : g.kenar) {
            if (d[k.u] != SONSUZ && d[k.u] + k.w < d[k.v]) {
                d[k.v] = d[k.u] + k.w;
                degisti = true;
            }
            if (!g.yonlu && d[k.v] != SONSUZ && d[k.v] + k.w < d[k.u]) {
                d[k.u] = d[k.v] + k.w;
                degisti = true;
            }
        }
        if (yaz) {
            std::cout << "  tur " << tur << ": d =";
            for (int x : d) {
                std::cout << " " << uzaklik_yaz(x, 1);
            }
            std::cout << "\n";
        }
        if (!degisti) {
            break;
        }
    }
    for (const Kenar& k : g.kenar) {
        if (d[k.u] != SONSUZ && d[k.u] + k.w < d[k.v]) {
            return true;
        }
    }
    return false;
}

// En iyilik koşulu: hiçbir kenar d[u] + w < d[v] olmamalı. İhlal eden
// kenarları yazar, sayısını döndürür.
static int gevsetilebilir(const Graf& g, const std::vector<int>& d)
{
    int k = 0;
    for (const Kenar& e : g.kenar) {
        if (d[e.u] != SONSUZ && d[e.u] + e.w < d[e.v]) {
            std::cout << "  " << e.u << "->" << e.v << " (w = " << e.w
                      << "): d[" << e.u << "] + w = " << d[e.u] + e.w
                      << " < d[" << e.v << "] = " << d[e.v] << "\n";
            k++;
        }
    }
    return k;
}

static std::string yol_yaz(const std::vector<int>& ebeveyn, int hedef)
{
    std::vector<int> s;
    for (int v = hedef; v != -1; v = ebeveyn[v]) {
        s.push_back(v);
    }
    std::string t;
    for (auto it = s.rbegin(); it != s.rend(); ++it) {
        t += (t.empty() ? "" : " -> ") + std::to_string(*it);
    }
    return t;
}

int main(int argc, char** argv)
{
    if (argc != 2) {
        std::cerr << "Kullanım: H12_09_negatif_kenar GRAF_DOSYASI\n";
        return 2;
    }
    Graf g;
    if (!graf_oku(argv[1], g)) {
        return 1;
    }
    int n = g.v_sayisi;
    std::cout << "1) Graf: " << n << " köşe, " << g.e_sayisi << " kenar, "
              << (g.yonlu ? "yönlü" : "yönsüz") << "; kenarlar: ";
    for (std::size_t i = 0; i < g.kenar.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << g.kenar[i].u << "->"
                  << g.kenar[i].v << " (" << g.kenar[i].w << ")";
    }
    std::cout << "\n";
    int en_kucuk = 0;
    for (const Kenar& k : g.kenar) {
        if (k.w < en_kucuk) {
            en_kucuk = k.w;
        }
    }
    std::cout << "  en küçük ağırlık = " << en_kucuk
              << ": Dijkstra'nın önkoşulu (w >= 0) "
              << (en_kucuk >= 0 ? "sağlanıyor" : "SAĞLANMIYOR") << "\n";

    std::cout << "\n2) Dizi tabanlı Dijkstra (Örnek 7), kaynak 0\n";
    std::vector<int> d, ebeveyn, bf;
    dijkstra_dizi(g, 0, d, ebeveyn, true);

    std::cout << "\n3) Kâhin: Bellman–Ford (yalnız doğrulama), kaynak 0\n";
    bool dongu = bellman_ford(g, 0, bf, true);
    std::cout << "  negatif döngü: " << (dongu ? "VAR" : "yok") << "\n";

    std::cout << "\n4) Karşılaştırma\n";
    std::cout << "  köşe  Dijkstra  Bellman–Ford  doğru mu\n";
    int yanlis = 0;
    for (int v = 0; v < n; v++) {
        bool dogru = d[v] == bf[v];
        yanlis += !dogru;
        std::cout << "  " << std::setw(4) << v << "  " << uzaklik_yaz(d[v], 8)
                  << "  " << uzaklik_yaz(bf[v], 12) << "  "
                  << (dogru ? "evet" : "HAYIR") << "\n";
    }
    std::cout << "  " << yanlis << " köşede yanlış. Dijkstra'nın sonucunda "
                 "hâlâ gevşetilebilen kenarlar\n  (en iyilik koşulu "
                 "ihlali):\n";
    int k = gevsetilebilir(g, d);
    std::cout << "  " << k << " kenar. Bu girdide 1 kesinleştikten sonra "
                 "2 -> 1 kenarı daha kısa yol verdi;\n  kesinleşen köşe "
                 "yeniden işlenmediği için 1 ve onun üzerinden 3 eski "
                 "değerde kaldı.\n";

    std::cout << "\n5) Yaygın yanlış çözüm: bütün ağırlıklara " << -en_kucuk
              << " eklemek\n";
    Graf kaydirilmis;
    kaydirilmis.v_sayisi = n;
    kaydirilmis.e_sayisi = g.e_sayisi;
    kaydirilmis.yonlu = g.yonlu;
    kaydirilmis.komsu.assign(n, {});
    for (const Kenar& e : g.kenar) {
        int w = e.w - en_kucuk;
        kaydirilmis.kenar.push_back(Kenar{e.u, e.v, w});
        kaydirilmis.komsu[e.u].push_back(Komsu{e.v, w});
        if (!g.yonlu) {
            kaydirilmis.komsu[e.v].push_back(Komsu{e.u, w});
        }
    }
    komsulari_sirala(kaydirilmis);
    std::vector<int> d2, e2;
    dijkstra_dizi(kaydirilmis, 0, d2, e2, false);
    int hedef = n - 1, ozgun = 0;
    for (int v = hedef; e2[v] != -1; v = e2[v]) {
        for (const Kenar& e : g.kenar) {
            if (e.u == e2[v] && e.v == v) {
                ozgun += e.w;
                break;
            }
        }
    }
    std::cout << "  kaydırılmış grafta Dijkstra'nın 0 -> " << hedef
              << " yolu: " << yol_yaz(e2, hedef) << " (kaydırılmış uzunluk "
              << d2[hedef] << ", özgün uzunluk " << ozgun << ")\n";
    std::cout << "  gerçek en kısa uzaklık (Bellman–Ford) = " << bf[hedef]
              << ": çok kenarlı yol kenar başına\n  ceza alır; sabit eklemek "
                 "yolların sırasını değiştirir.\n";
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (Bellman–Ford: Boost Graph
 * Library bellman_ford_shortest_paths, networkx bellman_ford_path —
 * standart dışı; yalnız kâhin). */

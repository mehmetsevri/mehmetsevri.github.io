/* H12_02_aralik_cizelgeleme.cpp — AP-2 Hafta 12 · Örnek 2 (★★)
 * Amaç    : Aralık çizelgeleme: en erken biten ilk; üç yanlış ölçütün (en
 *           kısa, en erken başlayan, en az çakışan) kaba kuvvetle doğrulanmış
 *           karşı örnekleri; değiş tokuş argümanının rastgele örneklerde
 *           kâhinle (kaba kuvvet) denetimi
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_02_aralik_cizelgeleme.cpp -o H12_02_aralik_cizelgeleme
 * Çalıştır: ./H12_02_aralik_cizelgeleme
 * Eşleri  : c/H12_02_aralik_cizelgeleme.c ·
 *           python/H12_02_aralik_cizelgeleme.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : aralıklar yarı açık [bas, bit): bit = sonraki bas ise
 *           çakışmaz; eşitlikte (bit, bas, kimlik) sırası
 */
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <tuple>
#include <vector>

#include "ortak_rastgele.hpp"

static const int DENEME = 1000;    // rastgele örnek sayısı
static const int DENEME_N = 8;     // rastgele örnekte aralık sayısı

struct Aralik {
    int bas, bit, kimlik;
};

static bool cakisir(const Aralik& a, const Aralik& b)
{
    return a.bas < b.bit && b.bas < a.bit;
}

static char ad(const Aralik& a)
{
    return static_cast<char>('A' + a.kimlik);
}

// Tam sıralama: std::tie demetleri sözlük sırasıyla karşılaştırır
static bool bitise_gore(const Aralik& x, const Aralik& y)
{
    return std::tie(x.bit, x.bas, x.kimlik) < std::tie(y.bit, y.bas,
                                                       y.kimlik);
}

static bool uzunluga_gore(const Aralik& x, const Aralik& y)
{
    int ux = x.bit - x.bas, uy = y.bit - y.bas;
    return std::tie(ux, x.bas, x.kimlik) < std::tie(uy, y.bas, y.kimlik);
}

static bool basa_gore(const Aralik& x, const Aralik& y)
{
    return std::tie(x.bas, x.bit, x.kimlik) < std::tie(y.bas, y.bit,
                                                       y.kimlik);
}

// Zaman şeridi: 0..15, aralık içi '#' (satır sonu çağırana kalır)
static void serit_yaz(const Aralik& x)
{
    std::string serit(16, '.');
    for (int t = 0; t < 16; t++) {
        if (x.bas <= t && t < x.bit) {
            serit[t] = '#';
        }
    }
    std::cout << "  " << ad(x) << " [" << std::setw(2) << x.bas << ", "
              << std::setw(2) << x.bit << ")  " << serit << "  ";
}

// Bitişe göre sırala, tek geçiş: başlangıcı son bitişten küçük
// olmayanı al. Seçilen sayısını döndürür.
static int en_erken_biten(const std::vector<Aralik>& a,
                          std::vector<Aralik>& secilen, bool yaz)
{
    std::vector<Aralik> sira = a;
    std::sort(sira.begin(), sira.end(), bitise_gore);
    secilen.clear();
    int son_bitis = -1;
    for (const Aralik& x : sira) {
        if (x.bas >= son_bitis) {        // açgözlü seçim
            secilen.push_back(x);
            if (yaz && son_bitis < 0) {
                serit_yaz(x);
                std::cout << "seçildi (ilk aralık)\n";
            } else if (yaz) {
                serit_yaz(x);
                std::cout << "seçildi (bas " << x.bas << " >= son bitiş "
                          << son_bitis << ")\n";
            }
            son_bitis = x.bit;
        } else if (yaz) {
            serit_yaz(x);
            std::cout << "elendi  (bas " << x.bas << " < son bitiş "
                      << son_bitis << ")\n";
        }
    }
    return static_cast<int>(secilen.size());
}

// Verilen sırada dolaş; seçilenlerin hepsiyle uyumluysa al
static int sirayla_sec(const std::vector<Aralik>& sira,
                       std::vector<Aralik>& secilen)
{
    secilen.clear();
    for (const Aralik& x : sira) {
        bool uyumlu = true;
        for (const Aralik& y : secilen) {
            if (cakisir(x, y)) {
                uyumlu = false;
            }
        }
        if (uyumlu) {
            secilen.push_back(x);
        }
    }
    return static_cast<int>(secilen.size());
}

static int en_kisa_ilk(const std::vector<Aralik>& a,
                       std::vector<Aralik>& secilen)
{
    std::vector<Aralik> sira = a;
    std::sort(sira.begin(), sira.end(), uzunluga_gore);
    return sirayla_sec(sira, secilen);
}

static int en_erken_baslayan(const std::vector<Aralik>& a,
                             std::vector<Aralik>& secilen)
{
    std::vector<Aralik> sira = a;
    std::sort(sira.begin(), sira.end(), basa_gore);
    return sirayla_sec(sira, secilen);
}

// Kalanlar içinde en az çakışanı al, onunla çakışanları at; eşitlikte
// (çakışma, bas, kimlik)
static int en_az_cakisan(const std::vector<Aralik>& a,
                         std::vector<Aralik>& secilen, bool yaz)
{
    int n = static_cast<int>(a.size());
    std::vector<bool> kalan(n, true);
    secilen.clear();
    for (;;) {
        int en_iyi = -1, en_iyi_c = 0;
        for (int i = 0; i < n; i++) {
            if (!kalan[i]) {
                continue;
            }
            int c = 0;
            for (int j = 0; j < n; j++) {
                if (j != i && kalan[j] && cakisir(a[i], a[j])) {
                    c++;
                }
            }
            if (en_iyi < 0 || c < en_iyi_c ||
                (c == en_iyi_c && a[i].bas < a[en_iyi].bas)) {
                en_iyi = i;
                en_iyi_c = c;
            }
        }
        if (en_iyi < 0) {
            return static_cast<int>(secilen.size());
        }
        if (yaz) {
            std::cout << "     seç " << ad(a[en_iyi]) << " ["
                      << a[en_iyi].bas << "," << a[en_iyi].bit
                      << ") (kalanlarla çakışma = " << en_iyi_c << ")\n";
        }
        secilen.push_back(a[en_iyi]);
        for (int j = 0; j < n; j++) {
            if (kalan[j] && cakisir(a[en_iyi], a[j])) {
                kalan[j] = false;
            }
        }
        kalan[en_iyi] = false;
    }
}

// Bütün alt kümeler (2^n); en çok aralıklı uyumlu alt kümenin
// maskesini döndürür (eşitlikte küçük maske)
static unsigned kaba_kuvvet(const std::vector<Aralik>& a)
{
    int n = static_cast<int>(a.size());
    std::vector<Aralik> sira = a;
    std::sort(sira.begin(), sira.end(), basa_gore);
    unsigned en_iyi_maske = 0;
    int en_iyi_k = 0;
    for (unsigned maske = 0; maske < (1u << n); maske++) {
        int k = 0;
        int son = -1;
        bool gecerli = true;
        for (const Aralik& x : sira) {   // kimlik = dizideki konum
            if (maske >> x.kimlik & 1u) {
                if (x.bas < son) {
                    gecerli = false;
                    break;
                }
                son = x.bit;
                k++;
            }
        }
        if (gecerli && k > en_iyi_k) {
            en_iyi_maske = maske;
            en_iyi_k = k;
        }
    }
    return en_iyi_maske;
}

static int maske_say(unsigned maske)
{
    int k = 0;
    while (maske) {
        k += maske & 1u;
        maske >>= 1;
    }
    return k;
}

static std::string liste_yaz(const std::vector<Aralik>& a)
{
    std::string s;
    for (std::size_t i = 0; i < a.size(); i++) {
        s += (i > 0 ? " " : "") + std::string(1, ad(a[i])) + "[" +
             std::to_string(a[i].bas) + "," + std::to_string(a[i].bit) + ")";
    }
    return s;
}

static std::string secim_yaz(const std::vector<Aralik>& secilen)
{
    std::string s;
    for (std::size_t j = 0; j < secilen.size(); j++) {
        s += (j > 0 ? " " : "") + std::string(1, ad(secilen[j]));
    }
    return s;
}

static std::string maske_yaz(const std::vector<Aralik>& a, unsigned maske)
{
    std::string s;
    for (std::size_t i = 0; i < a.size(); i++) {
        if (maske >> i & 1u) {
            s += (s.empty() ? "" : " ") + std::string(1, ad(a[i]));
        }
    }
    return s;
}

static void karsi_ornek(const std::string& baslik,
                        const std::vector<Aralik>& a, int strateji)
{
    std::vector<Aralik> secilen;
    int k;
    std::cout << "  " << baslik << ": " << liste_yaz(a) << "\n";
    if (strateji == 2) {
        k = en_az_cakisan(a, secilen, true);
    } else if (strateji == 0) {
        k = en_kisa_ilk(a, secilen);
    } else {
        k = en_erken_baslayan(a, secilen);
    }
    unsigned maske = kaba_kuvvet(a);
    std::cout << "     strateji: " << secim_yaz(secilen) << " -> " << k
              << " aralık; en iyi (kaba kuvvet, " << (1u << a.size())
              << " alt küme): " << maske_yaz(a, maske) << " -> "
              << maske_say(maske) << "\n";
    int k2 = en_erken_biten(a, secilen, false);
    std::cout << "     en erken biten: " << secim_yaz(secilen) << " -> "
              << k2 << "\n";
}

// Kâhin: kaba kuvvet. Değiş tokuş: en iyi çözümün (bitişe göre) ilk
// aralığı açgözlünün ilkiyle değiştirilince çözüm geçerli kalır; önde
// kalma: r. açgözlü aralık en geç r. en iyi aralıkla biter.
static void rastgele_denetim()
{
    int tamam[4] = {0, 0, 0, 0};
    int takas_gecerli = 0, onde = 0;
    std::vector<Aralik> a(DENEME_N), secilen;
    rastgele_tohum(42);
    for (int d = 0; d < DENEME; d++) {
        for (int i = 0; i < DENEME_N; i++) {
            int bas = rastgele_aralik(0, 20);
            a[i] = Aralik{bas, bas + rastgele_aralik(1, 8), i};
        }
        unsigned maske = kaba_kuvvet(a);
        int en_iyi = maske_say(maske);
        int k0 = en_erken_biten(a, secilen, false);
        tamam[0] += k0 == en_iyi;
        std::vector<Aralik> g = secilen;  // açgözlünün seçtikleri
        tamam[1] += en_kisa_ilk(a, secilen) == en_iyi;
        tamam[2] += en_erken_baslayan(a, secilen) == en_iyi;
        tamam[3] += en_az_cakisan(a, secilen, false) == en_iyi;
        std::vector<Aralik> o;
        for (int i = 0; i < DENEME_N; i++) {
            if (maske >> i & 1u) {
                o.push_back(a[i]);
            }
        }
        std::sort(o.begin(), o.end(), bitise_gore);
        bool ok = true;
        for (int r = 0; r < en_iyi; r++) {
            if (g[r].bit > o[r].bit) {
                ok = false;
            }
        }
        onde += ok;
        o[0] = g[0];                     // değiş tokuş adımı
        bool gecerli = true;
        for (int i = 0; i < en_iyi; i++) {
            for (int j = i + 1; j < en_iyi; j++) {
                if (cakisir(o[i], o[j])) {
                    gecerli = false;
                }
            }
        }
        takas_gecerli += gecerli;
    }
    std::cout << "  " << DENEME << " rastgele örnek (n = " << DENEME_N
              << ", bas 0..20, uzunluk 1..8, tohum 42); en iyiyi bulduğu "
                 "örnek sayısı:\n";
    const char* adlar[4] = {"en erken biten   ", "en kısa ilk      ",
                            "en erken başlayan", "en az çakışan    "};
    for (int s = 0; s < 4; s++) {
        std::cout << "    " << adlar[s] << ": " << std::setw(4) << tamam[s]
                  << "/" << DENEME << "\n";
    }
    std::cout << "  değiş tokuş: en iyinin ilk aralığı açgözlünün ilkiyle "
                 "değiştirilince geçerli: " << takas_gecerli << "/"
              << DENEME << "\n";
    std::cout << "  açgözlü önde kalır (her r için g_r.bit <= o_r.bit): "
              << onde << "/" << DENEME << "\n";
}

int main()
{
    const int veri[10][2] = {{4, 7}, {0, 3}, {3, 8}, {1, 4}, {7, 10},
                             {9, 12}, {6, 9}, {11, 14}, {2, 6}, {8, 13}};
    std::vector<Aralik> a, secilen;
    for (int i = 0; i < 10; i++) {
        a.push_back(Aralik{veri[i][0], veri[i][1], i});
    }
    std::cout << "1) En erken biten ilk: " << a.size()
              << " istek, yarı açık [bas, bit)\n";
    std::cout << "  girdi: " << liste_yaz(a) << "\n";
    std::cout << "  sıra (bit, bas, kimlik); zaman 0..15 her sütun 1 "
                 "birim:\n";
    int k = en_erken_biten(a, secilen, true);
    unsigned maske = kaba_kuvvet(a);
    std::cout << "  seçilen " << k << " aralık: " << secim_yaz(secilen)
              << "; kaba kuvvet (" << (1u << a.size())
              << " alt küme) en çok " << maske_say(maske) << "\n";

    std::cout << "\n2) Yanlış ölçütler ve karşı örnekleri (kaba kuvvetle "
                 "doğrulandı)\n";
    karsi_ornek("a) en kısa ilk", {{0, 5, 0}, {4, 7, 1}, {6, 11, 2}}, 0);
    karsi_ornek("b) en erken başlayan", {{0, 10, 0}, {1, 3, 1}, {4, 6, 2}},
                1);
    const int v[11][2] = {{0, 3}, {4, 7}, {8, 11}, {12, 15}, {2, 5}, {2, 5},
                          {2, 5}, {6, 9}, {10, 13}, {10, 13}, {10, 13}};
    std::vector<Aralik> az;
    for (int i = 0; i < 11; i++) {
        az.push_back(Aralik{v[i][0], v[i][1], i});
    }
    karsi_ornek("c) en az çakışan", az, 2);

    std::cout << "\n3) Kâhinle rastgele denetim ve değiş tokuş argümanı\n";
    rastgele_denetim();
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort yalnız sıralama aracı); C++ — yok
 * (std::sort aracı); Python — yok (sorted aracı). Aralık çizelgeleme bir
 * kütüphane işlevi değildir. */

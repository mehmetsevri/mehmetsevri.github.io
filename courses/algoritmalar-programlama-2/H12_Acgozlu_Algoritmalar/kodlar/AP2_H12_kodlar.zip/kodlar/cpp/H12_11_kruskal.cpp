/* H12_11_kruskal.cpp — AP-2 Hafta 12 · Örnek 11 (★★★)
 * Amaç    : Kruskal ile en küçük kapsayan ağaç: kenarlar (w, u, v) sırasıyla;
 *           birleşim–bul (rütbe + yol sıkıştırma) ile döngü denetimi; kabul
 *           ve reddedilen kenarlar, her adımda birleşim–bul ormanı; kabul
 *           edilen her kenar için kesim özelliğinin denetimi; kâhin: kaba
 *           kuvvet (bütün V - 1 kenarlı alt kümeler)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H12_11_kruskal.cpp \
 *           -o H12_11_kruskal
 * Çalıştır: ./H12_11_kruskal ../girdiler/h12_kampus.txt
 * Eşleri  : c/H12_11_kruskal.c · python/H12_11_kruskal.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : yönsüz kenar (min(u, v), max(u, v)) olarak tutulur; sıralama
 *           aracı std::sort, std::tie ile (w, u, v) tam sıralaması.
 */
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

static const std::size_t SATIR_UZUNLUGU = 512;  // C'deki fgets tamponu

static long long izleme_sayisi = 0;   // birleşim–bul: işaretçi izleme
static long long bul_sayisi = 0;
static long long birlestir_sayisi = 0;

// ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ----------------
struct Komsu {
    int hedef, agirlik;
};

struct Kenar {
    int u, v, w;
};

struct Graf {
    int v_sayisi = 0, e_sayisi = 0;
    bool yonlu = false;
    std::vector<std::vector<Komsu>> komsu;  // komsu[u]: u'dan çıkanlar
    std::vector<Kenar> kenar;               // dosyadaki sırayla
};

static void hata(const std::string& ileti)
{
    std::cerr << "Hata: " << ileti << "\n";
}

static void komsulari_sirala(Graf& g)     // (hedef, agirlik) artan
{
    for (auto& liste : g.komsu) {
        std::sort(liste.begin(), liste.end(),
                  [](const Komsu& x, const Komsu& y) {
                      return std::tie(x.hedef, x.agirlik) <
                             std::tie(y.hedef, y.agirlik);
                  });
    }
}

// '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural)
static bool tamsayi_coz(const std::string& s, int& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9) {
        return false;
    }
    for (std::size_t i = bas; i < s.size(); i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
    }
    x = std::stoi(s);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

static std::vector<std::string> parcala(const std::string& s)
{
    std::vector<std::string> t;
    std::size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && bosluk_mu(s[i])) {
            i++;
        }
        std::size_t j = i;
        while (j < s.size() && !bosluk_mu(s[j])) {
            j++;
        }
        if (j > i) {
            t.push_back(s.substr(i, j - i));
        }
        i = j;
    }
    return t;
}

// Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
// (w yoksa 1). true: başarı; false: hata (ileti stderr'de).
static bool graf_oku(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    if (!f) {
        hata("dosya açılamadı: " + yol);
        return false;
    }
    std::string satir;
    int no = 0;
    bool baslik = false;
    while (std::getline(f, satir)) {
        no++;
        if (satir.size() > SATIR_UZUNLUGU - 2) {
            hata("satır " + std::to_string(no) + ": satır çok uzun");
            return false;
        }
        std::vector<std::string> t = parcala(satir);
        if (t.empty() || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            std::string tur = t.size() == 3 ? t[2] : "yonsuz";
            if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], v) ||
                !tamsayi_coz(t[1], e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 || (tur != "yonlu" && tur != "yonsuz")) {
                hata("satır " + std::to_string(no) +
                     ": başlık 'V E [yonlu|yonsuz]' bekleniyordu");
                return false;
            }
            g.v_sayisi = v;
            g.e_sayisi = e;
            g.yonlu = tur == "yonlu";
            g.komsu.assign(v, {});
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], u) ||
            !tamsayi_coz(t[1], v) || (t.size() == 3 && !tamsayi_coz(t[2], w))) {
            hata("satır " + std::to_string(no) +
                 ": kenar 'u v [w]' bekleniyordu");
            return false;
        }
        if (u < 0 || u >= g.v_sayisi || v < 0 || v >= g.v_sayisi) {
            hata("satır " + std::to_string(no) + ": köşe numarası 0.." +
                 std::to_string(g.v_sayisi - 1) + " aralığında olmalı");
            return false;
        }
        if (static_cast<int>(g.kenar.size()) == g.e_sayisi) {
            hata("satır " + std::to_string(no) + ": fazla kenar (E = " +
                 std::to_string(g.e_sayisi) + ")");
            return false;
        }
        g.kenar.push_back(Kenar{u, v, w});
        g.komsu[u].push_back(Komsu{v, w});
        if (!g.yonlu) {
            g.komsu[v].push_back(Komsu{u, w});
        }
    }
    if (!baslik) {
        hata("başlık satırı yok");
        return false;
    }
    if (static_cast<int>(g.kenar.size()) < g.e_sayisi) {
        hata("kenar sayısı eksik: " + std::to_string(g.e_sayisi) +
             " bekleniyordu, " + std::to_string(g.kenar.size()) + " okundu");
        return false;
    }
    komsulari_sirala(g);
    return true;
}
// --------------------------------------------------------------------------

struct BirlesimBul {             // Örnek 10'un "rütbe + sıkıştırma" sürümü
    std::vector<int> ebeveyn, rutbe;

    explicit BirlesimBul(int n) : ebeveyn(n), rutbe(n, 0)
    {
        std::iota(ebeveyn.begin(), ebeveyn.end(), 0);
    }
};

static int bul(BirlesimBul& b, int x)
{
    bul_sayisi++;
    int kok = x;
    while (b.ebeveyn[kok] != kok) {
        kok = b.ebeveyn[kok];
        izleme_sayisi++;
    }
    while (b.ebeveyn[x] != kok) {        // yol sıkıştırma
        int sonraki = b.ebeveyn[x];
        b.ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

// İki farklı kökü rütbeye göre bağlar
static void birlestir_kok(BirlesimBul& b, int kx, int ky)
{
    birlestir_sayisi++;
    if (b.rutbe[kx] < b.rutbe[ky]) {
        std::swap(kx, ky);
    }
    b.ebeveyn[ky] = kx;
    if (b.rutbe[kx] == b.rutbe[ky]) {
        b.rutbe[kx]++;
    }
}

// Kesim denetimi için: sayaçsız, sıkıştırmasız kök
static int kok_sayacsiz(const BirlesimBul& b, int x)
{
    while (b.ebeveyn[x] != x) {
        x = b.ebeveyn[x];
    }
    return x;
}

// Birleştirmeden ÖNCE: S = ku kökünün kümesi (s üyelik); S ile V - S
// arasındaki en hafif kenarın ağırlığını döndürür.
static int kesim(const Graf& g, const BirlesimBul& b, int ku,
                 std::vector<bool>& s)
{
    s.assign(g.v_sayisi, false);
    for (int x = 0; x < g.v_sayisi; x++) {
        s[x] = kok_sayacsiz(b, x) == ku;
    }
    int en_hafif = -1;
    for (const Kenar& k : g.kenar) {
        if (s[k.u] != s[k.v] && (en_hafif < 0 || k.w < en_hafif)) {
            en_hafif = k.w;
        }
    }
    return en_hafif;
}

// Kenarları (w, u, v) sırasıyla dolaş; uçlar farklı ağaçtaysa al.
// Ağaç kenarlarını agac'a ekler, toplam ağırlığı döndürür.
static long long kruskal(const Graf& g, std::vector<Kenar>& agac, bool yaz)
{
    std::vector<Kenar> sira;
    for (const Kenar& k : g.kenar) {
        sira.push_back(Kenar{std::min(k.u, k.v), std::max(k.u, k.v), k.w});
    }
    std::sort(sira.begin(), sira.end(), [](const Kenar& x, const Kenar& y) {
        return std::tie(x.w, x.u, x.v) < std::tie(y.w, y.u, y.v);
    });
    BirlesimBul b(g.v_sayisi);
    std::vector<bool> s;
    long long toplam = 0;
    int adim = 0;
    for (const Kenar& e : sira) {
        adim++;
        int ku = bul(b, e.u), kv = bul(b, e.v);
        if (ku == kv) {
            if (yaz) {
                std::cout << "  " << std::setw(2) << adim << "  ("
                          << std::setw(3) << e.w << ", " << e.u << ", " << e.v
                          << ")  " << ku << " " << kv << "     RET    döngü: "
                          << e.u << " ile " << e.v << " zaten aynı ağaçta\n";
            }
            continue;
        }
        int en_hafif = 0;
        if (yaz) {
            en_hafif = kesim(g, b, ku, s);
        }
        birlestir_kok(b, ku, kv);        // iki ağaç birleşir
        agac.push_back(e);
        toplam += e.w;
        if (yaz) {
            std::cout << "  " << std::setw(2) << adim << "  (" << std::setw(3)
                      << e.w << ", " << e.u << ", " << e.v << ")  " << ku
                      << " " << kv << "     KABUL  ebeveyn:";
            for (int x : b.ebeveyn) {
                std::cout << " " << x;
            }
            std::cout << "\n      kesim S = {";
            bool ilk = true;
            for (int x = 0; x < g.v_sayisi; x++) {
                if (s[x]) {
                    std::cout << (ilk ? "" : ", ") << x;
                    ilk = false;
                }
            }
            std::cout << "}: S'den çıkan en hafif kenar " << en_hafif << " "
                      << (en_hafif == e.w ? "= w (kesim özelliği)"
                                          : "!= w (HATA)")
                      << "\n";
            if (static_cast<int>(agac.size()) == g.v_sayisi - 1) {
                std::cout << "      (ağaç tamam: V - 1 = " << g.v_sayisi - 1
                          << " kenar; erken durdurma kalanları "
                             "incelemezdi)\n";
            }
        }
    }
    return toplam;
}

// Bütün V - 1 kenarlı alt kümeler (maske); kapsayan ağaç olanların
// sayısı ve en küçük toplamı
static void kaba_kuvvet(const Graf& g, long long& incelenen, long long& sayi,
                        long long& en_kucuk)
{
    int n = g.v_sayisi, m = static_cast<int>(g.kenar.size());
    incelenen = sayi = 0;
    en_kucuk = -1;
    std::vector<int> ebeveyn(n);
    for (unsigned long maske = 0; maske < (1ul << m); maske++) {
        int k = 0;
        for (unsigned long x = maske; x != 0; x >>= 1) {
            k += static_cast<int>(x & 1ul);
        }
        if (k != n - 1) {
            continue;
        }
        incelenen++;
        std::iota(ebeveyn.begin(), ebeveyn.end(), 0);
        bool dongu = false;
        long long toplam = 0;
        for (int i = 0; i < m && !dongu; i++) {
            if (maske >> i & 1ul) {
                int u = g.kenar[i].u, v = g.kenar[i].v;
                while (ebeveyn[u] != u) {
                    u = ebeveyn[u];
                }
                while (ebeveyn[v] != v) {
                    v = ebeveyn[v];
                }
                if (u == v) {
                    dongu = true;
                } else {
                    ebeveyn[u] = v;
                    toplam += g.kenar[i].w;
                }
            }
        }
        if (!dongu) {
            sayi++;
            if (en_kucuk < 0 || toplam < en_kucuk) {
                en_kucuk = toplam;
            }
        }
    }
}

int main(int argc, char** argv)
{
    if (argc != 2) {
        std::cerr << "Kullanım: H12_11_kruskal GRAF_DOSYASI\n";
        return 2;
    }
    Graf g;
    if (!graf_oku(argv[1], g)) {
        return 1;
    }
    if (g.yonlu) {
        hata("en küçük kapsayan ağaç yönsüz graf ister");
        return 1;
    }
    std::cout << "1) Graf: " << g.v_sayisi << " köşe, " << g.e_sayisi
              << " kenar, yönsüz\n";
    std::cout << "\n2) Kruskal: kenarlar (w, u, v) sırasıyla; birleşim–bul: "
                 "rütbe + yol sıkıştırma\n";
    std::cout << "  adım (w, u, v)     kökler  karar  birleşim–bul ormanı\n";
    std::vector<Kenar> agac;
    long long toplam = kruskal(g, agac, true);
    std::cout << "  ağaç kenarları: ";
    for (std::size_t i = 0; i < agac.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << agac[i].u << "-" << agac[i].v
                  << " (" << agac[i].w << ")";
    }
    int k = static_cast<int>(agac.size());
    std::cout << "\n  toplam ağırlık = " << toplam << "; kabul " << k
              << ", ret " << static_cast<int>(g.kenar.size()) - k
              << "; bul = " << bul_sayisi << ", birleştir = "
              << birlestir_sayisi << ", işaretçi izleme = " << izleme_sayisi
              << "\n";
    if (k < g.v_sayisi - 1) {
        std::cout << "  graf bağlı değil: " << g.v_sayisi - k
                  << " ağaçlı orman\n";
    }
    if (g.kenar.size() <= 20) {
        long long incelenen, sayi, en_kucuk;
        std::cout << "\n3) Kâhin: kaba kuvvet (bütün V - 1 kenarlı alt "
                     "kümeler)\n";
        kaba_kuvvet(g, incelenen, sayi, en_kucuk);
        std::cout << "  " << incelenen << " alt küme, " << sayi
                  << " tanesi kapsayan ağaç; en küçük toplam " << en_kucuk
                  << " -> Kruskal "
                  << (en_kucuk == toplam ? "en iyi" : "FARKLI") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (Boost Graph Library
 * kruskal_minimum_spanning_tree, networkx minimum_spanning_tree —
 * standart dışı; yalnız kâhin). */

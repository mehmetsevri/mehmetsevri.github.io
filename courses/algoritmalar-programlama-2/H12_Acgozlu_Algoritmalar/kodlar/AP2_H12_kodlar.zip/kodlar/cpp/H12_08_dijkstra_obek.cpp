/* H12_08_dijkstra_obek.cpp — AP-2 Hafta 12 · Örnek 8 (★★★)
 * Amaç    : Öbekli Dijkstra: (uzaklık, köşe) çiftleri, tembel silme
 *           (köşe yeni uzaklıkla yeniden itilir; eskimiş kayıt çıkınca
 *           atlanır ve sayılır), en kısa yolun ebeveyn dizisinden
 *           yazdırılması; kâhin: Örnek 7'nin dizi tabanlı Dijkstra'sı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_08_dijkstra_obek.cpp -o H12_08_dijkstra_obek
 * Çalıştır: ./H12_08_dijkstra_obek ../girdiler/h12_kampus.txt 0
 * Eşleri  : c/H12_08_dijkstra_obek.c · python/H12_08_dijkstra_obek.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek std::priority_queue<std::pair<int, int>, …,
 *           std::greater<…>> (en küçük öbek); std::pair sözlük sırasıyla
 *           karşılaştırılır, eşit uzaklıkta küçük köşe önce çıkar.
 */
#include <algorithm>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static const int SONSUZ = std::numeric_limits<int>::max();
static const std::size_t SATIR_UZUNLUGU = 512;  // C'deki fgets tamponu

static long long itme_sayisi = 0;     // öbeğe itilen (uzaklık, köşe)
static long long cikarma_sayisi = 0;  // öbekten çıkarılan çift
static long long atlanan_sayisi = 0;  // tembel silme: eskimiş, atlanan
static long long kenar_inceleme = 0;  // incelenen kenar (u, v)
static long long gevsetme_sayisi = 0; // d[v]'yi küçülten gevşetme
static long long en_buyuk_obek = 0;   // öbeğin ulaştığı en büyük boy
static long long taranan_hucre = 0;   // (dizi tabanlı kâhin için)

using Oge = std::pair<int, int>;      // (uzaklık, köşe)
using Obek = std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>>;

// ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ----------------
struct Komsu {
    int hedef, agirlik;
};

struct Kenar {
    int u, v, w;
};

struct Graf {
    int v_sayisi = 0, e_sayisi = 0;
    bool yonlu = false;
    std::vector<std::vector<Komsu>> komsu;  // komsu[u]: u'dan çıkanlar
    std::vector<Kenar> kenar;               // dosyadaki sırayla
};

static void hata(const std::string& ileti)
{
    std::cerr << "Hata: " << ileti << "\n";
}

static void komsulari_sirala(Graf& g)     // (hedef, agirlik) artan
{
    for (auto& liste : g.komsu) {
        std::sort(liste.begin(), liste.end(),
                  [](const Komsu& x, const Komsu& y) {
                      return std::tie(x.hedef, x.agirlik) <
                             std::tie(y.hedef, y.agirlik);
                  });
    }
}

// '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural)
static bool tamsayi_coz(const std::string& s, int& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9) {
        return false;
    }
    for (std::size_t i = bas; i < s.size(); i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
    }
    x = std::stoi(s);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

static std::vector<std::string> parcala(const std::string& s)
{
    std::vector<std::string> t;
    std::size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && bosluk_mu(s[i])) {
            i++;
        }
        std::size_t j = i;
        while (j < s.size() && !bosluk_mu(s[j])) {
            j++;
        }
        if (j > i) {
            t.push_back(s.substr(i, j - i));
        }
        i = j;
    }
    return t;
}

// Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
// (w yoksa 1). true: başarı; false: hata (ileti stderr'de).
static bool graf_oku(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    if (!f) {
        hata("dosya açılamadı: " + yol);
        return false;
    }
    std::string satir;
    int no = 0;
    bool baslik = false;
    while (std::getline(f, satir)) {
        no++;
        if (satir.size() > SATIR_UZUNLUGU - 2) {
            hata("satır " + std::to_string(no) + ": satır çok uzun");
            return false;
        }
        std::vector<std::string> t = parcala(satir);
        if (t.empty() || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            std::string tur = t.size() == 3 ? t[2] : "yonsuz";
            if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], v) ||
                !tamsayi_coz(t[1], e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 || (tur != "yonlu" && tur != "yonsuz")) {
                hata("satır " + std::to_string(no) +
                     ": başlık 'V E [yonlu|yonsuz]' bekleniyordu");
                return false;
            }
            g.v_sayisi = v;
            g.e_sayisi = e;
            g.yonlu = tur == "yonlu";
            g.komsu.assign(v, {});
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], u) ||
            !tamsayi_coz(t[1], v) || (t.size() == 3 && !tamsayi_coz(t[2], w))) {
            hata("satır " + std::to_string(no) +
                 ": kenar 'u v [w]' bekleniyordu");
            return false;
        }
        if (u < 0 || u >= g.v_sayisi || v < 0 || v >= g.v_sayisi) {
            hata("satır " + std::to_string(no) + ": köşe numarası 0.." +
                 std::to_string(g.v_sayisi - 1) + " aralığında olmalı");
            return false;
        }
        if (static_cast<int>(g.kenar.size()) == g.e_sayisi) {
            hata("satır " + std::to_string(no) + ": fazla kenar (E = " +
                 std::to_string(g.e_sayisi) + ")");
            return false;
        }
        g.kenar.push_back(Kenar{u, v, w});
        g.komsu[u].push_back(Komsu{v, w});
        if (!g.yonlu) {
            g.komsu[v].push_back(Komsu{u, w});
        }
    }
    if (!baslik) {
        hata("başlık satırı yok");
        return false;
    }
    if (static_cast<int>(g.kenar.size()) < g.e_sayisi) {
        hata("kenar sayısı eksik: " + std::to_string(g.e_sayisi) +
             " bekleniyordu, " + std::to_string(g.kenar.size()) + " okundu");
        return false;
    }
    komsulari_sirala(g);
    return true;
}
// --------------------------------------------------------------------------

static std::string uzaklik_yaz(int d, int genislik)
{
    std::string s = d == SONSUZ ? "∞" : std::to_string(d);
    int gorunur = d == SONSUZ ? 1 : static_cast<int>(s.size());
    return std::string(std::max(0, genislik - gorunur), ' ') + s;
}

// Öbek içeriği sıralı (iç dizi düzeni gerçekleştirime bağlıdır)
static std::string obek_yaz(Obek kopya)
{
    std::string s = "[";
    bool ilk = true;
    while (!kopya.empty()) {             // kopyadan çıkarmak sıralı verir
        s += (ilk ? "(" : " (") + std::to_string(kopya.top().first) + "," +
             std::to_string(kopya.top().second) + ")";
        kopya.pop();
        ilk = false;
    }
    return s + "]";
}

static void obege_ekle(Obek& obek, Oge x)
{
    obek.push(x);
    itme_sayisi++;
    if (static_cast<long long>(obek.size()) > en_buyuk_obek) {
        en_buyuk_obek = static_cast<long long>(obek.size());
    }
}

// O((V + E) log V): öbekte (uzaklık, köşe); anahtar azaltma yerine
// yeniden itme + tembel silme
static void dijkstra_obek(const Graf& g, int kaynak, std::vector<int>& d,
                          std::vector<int>& ebeveyn, bool yaz)
{
    int n = g.v_sayisi;
    std::vector<bool> kesin(n, false);
    d.assign(n, SONSUZ);
    ebeveyn.assign(n, -1);
    d[kaynak] = 0;
    Obek obek;
    obege_ekle(obek, {0, kaynak});
    while (!obek.empty()) {
        auto [du, u] = obek.top();
        obek.pop();
        cikarma_sayisi++;
        if (kesin[u]) {                  // eskimiş kayıt: atla
            atlanan_sayisi++;
            if (yaz) {
                std::cout << "  çıkar (" << du << "," << u << "): ESKİMİŞ ("
                          << u << " kesin, d[" << u << "] = " << d[u]
                          << ") -> atla\n";
            }
            continue;
        }
        kesin[u] = true;                 // öbekten çıkınca kesinleşir
        if (yaz) {
            std::cout << "  çıkar (" << du << "," << u << "): " << u
                      << " kesinleşti; kesinleşen {";
            bool ilk = true;
            for (int k = 0; k < n; k++) {
                if (kesin[k]) {
                    std::cout << (ilk ? "" : ", ") << k;
                    ilk = false;
                }
            }
            std::cout << "}\n";
        }
        for (const Komsu& k : g.komsu[u]) {
            int v = k.hedef, w = k.agirlik;
            kenar_inceleme++;
            if (!kesin[v] && d[u] != SONSUZ && d[u] + w < d[v]) {
                if (yaz) {
                    std::cout << "     gevşet " << u << "->" << v << " (w = "
                              << w << "): d[" << v << "] = "
                              << uzaklik_yaz(d[v], 1) << " -> " << d[u] + w
                              << ", it (" << d[u] + w << "," << v << ")\n";
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
                obege_ekle(obek, {d[v], v});
            }
        }
        if (yaz) {
            std::cout << "     öbek: " << obek_yaz(obek) << "\n";
        }
    }
}

// O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama
static void dijkstra_dizi(const Graf& g, int kaynak, std::vector<int>& d,
                          std::vector<int>& ebeveyn, bool yaz)
{
    int n = g.v_sayisi;
    std::vector<bool> kesin(n, false);
    d.assign(n, SONSUZ);
    ebeveyn.assign(n, -1);
    d[kaynak] = 0;
    for (int adim = 1; adim <= n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {    // en küçük d: doğrusal tarama
            taranan_hucre++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;                       // kalanlar ulaşılamaz
        }
        kesin[u] = true;                 // d[u] artık kesin
        if (yaz) {
            std::cout << "  adım " << adim << ": seç " << u << " (d = "
                      << d[u] << "); kesinleşen {";
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (kesin[x]) {
                    std::cout << (ilk ? "" : ", ") << x;
                    ilk = false;
                }
            }
            std::cout << "}\n";
        }
        for (const Komsu& k : g.komsu[u]) {
            int v = k.hedef, w = k.agirlik;
            kenar_inceleme++;
            if (kesin[v]) {
                continue;
            }
            if (d[u] != SONSUZ && d[u] + w < d[v]) {   // taşma korumalı
                if (yaz) {
                    std::cout << "     gevşet " << u << "->" << v << " (w = "
                              << w << "): d[" << v << "] = "
                              << uzaklik_yaz(d[v], 1) << " -> " << d[u] + w
                              << "\n";
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
            } else if (yaz) {
                std::cout << "     " << u << "->" << v << " (w = " << w
                          << "): " << d[u] << " + " << w << " >= " << d[v]
                          << ", değişmez\n";
            }
        }
        if (yaz) {
            std::cout << "     d:";
            for (int x : d) {
                std::cout << " " << uzaklik_yaz(x, 1);
            }
            std::cout << "\n";
        }
    }
}

// Yönlü: her u için u -> u+1 (halka, ulaşılabilirlik için) ve derece-1
// rastgele kenar; ağırlıklar 1..w_ust (ortak LCG)
static Graf rastgele_graf(int v_sayisi, int derece, int w_ust,
                          std::uint64_t tohum)
{
    rastgele_tohum(tohum);
    Graf g;
    g.v_sayisi = v_sayisi;
    g.e_sayisi = v_sayisi * derece;
    g.yonlu = true;
    g.komsu.assign(v_sayisi, {});
    for (int u = 0; u < v_sayisi; u++) {
        int w = rastgele_aralik(1, w_ust);
        g.komsu[u].push_back(Komsu{(u + 1) % v_sayisi, w});
        for (int j = 0; j < derece - 1; j++) {
            int v = rastgele_aralik(0, v_sayisi - 1);
            w = rastgele_aralik(1, w_ust);
            g.komsu[u].push_back(Komsu{v, w});
        }
    }
    komsulari_sirala(g);
    return g;
}

// Ebeveyn dizisini hedeften kaynağa izle, ters sırada yaz
static std::string yol_yaz(const std::vector<int>& ebeveyn, int kaynak,
                           int hedef)
{
    std::vector<int> yol;
    for (int v = hedef; v != -1; v = ebeveyn[v]) {
        yol.push_back(v);
    }
    if (yol.back() != kaynak) {
        return "ulaşılamaz";
    }
    std::string s;
    for (auto it = yol.rbegin(); it != yol.rend(); ++it) {
        s += (s.empty() ? "" : " -> ") + std::to_string(*it);
    }
    return s;
}

static void sayaclari_sifirla()
{
    itme_sayisi = cikarma_sayisi = atlanan_sayisi = kenar_inceleme = 0;
    gevsetme_sayisi = en_buyuk_obek = taranan_hucre = 0;
}

int main(int argc, char** argv)
{
    if (argc != 2 && argc != 3) {
        std::cerr << "Kullanım: H12_08_dijkstra_obek GRAF_DOSYASI [KAYNAK]\n";
        return 2;
    }
    Graf g;
    if (!graf_oku(argv[1], g)) {
        return 1;
    }
    int kaynak = 0;
    if (argc == 3 && (!tamsayi_coz(argv[2], kaynak) || kaynak < 0 ||
                      kaynak >= g.v_sayisi)) {
        hata("kaynak köşe 0.." + std::to_string(g.v_sayisi - 1) +
             " aralığında olmalı");
        return 2;
    }
    for (const Kenar& k : g.kenar) {
        if (k.w < 0) {
            hata("negatif ağırlık " + std::to_string(k.u) + "->" +
                 std::to_string(k.v) + " (" + std::to_string(k.w) +
                 "): Dijkstra'nın önkoşulu sağlanmıyor (Örnek 9)");
            return 1;
        }
    }
    std::cout << "1) Graf: " << g.v_sayisi << " köşe, " << g.e_sayisi
              << " kenar, " << (g.yonlu ? "yönlü" : "yönsüz") << "; kaynak "
              << kaynak << "\n";
    std::cout << "  öbek öğesi (uzaklık, köşe); başlangıç: öbek [(0,"
              << kaynak << ")]\n";
    std::vector<int> d, ebeveyn;
    dijkstra_obek(g, kaynak, d, ebeveyn, true);
    std::cout << "  sayaçlar: itme = " << itme_sayisi << ", çıkarma = "
              << cikarma_sayisi << ", atlanan (eskimiş) = " << atlanan_sayisi
              << ", kenar inceleme = " << kenar_inceleme
              << ", başarılı gevşetme = " << gevsetme_sayisi
              << ", en büyük öbek = " << en_buyuk_obek << "\n";
    std::cout << "  itme = 1 + başarılı gevşetme: " << itme_sayisi << " = 1 + "
              << gevsetme_sayisi << "; atlanan = itme - kesinleşen: "
              << atlanan_sayisi << " = " << itme_sayisi << " - "
              << itme_sayisi - atlanan_sayisi << "\n";

    std::cout << "\n2) En kısa yollar (ebeveyn dizisi geriye izlenir), "
                 "kaynak " << kaynak << "\n";
    for (int v = 0; v < g.v_sayisi; v++) {
        std::cout << "  " << v << ": uzaklık " << uzaklik_yaz(d[v], 4)
                  << "  yol " << yol_yaz(ebeveyn, kaynak, v) << "\n";
    }

    std::cout << "\n3) Kâhin: dizi tabanlı Dijkstra (Örnek 7) ile "
                 "karşılaştırma; rastgele yönlü\n   graflar (derece 4, "
                 "ağırlık 1..100, tohum 42)\n";
    std::cout << "      V      E   itme  çıkarma  atlanan  en büyük öbek  "
                 "(V+E)·⌈log2 V⌉  aynı mı\n";
    for (int n : {100, 500, 2000}) {
        Graf r = rastgele_graf(n, 4, 100, 42);
        std::vector<int> d1, e1, d2, e2;
        sayaclari_sifirla();
        dijkstra_dizi(r, 0, d2, e2, false);
        sayaclari_sifirla();
        dijkstra_obek(r, 0, d1, e1, false);
        int log = 0;
        while ((1 << log) < n) {
            log++;
        }
        std::cout << "  " << std::setw(5) << n << "  " << std::setw(5)
                  << r.e_sayisi << "  " << std::setw(5) << itme_sayisi << "  "
                  << std::setw(7) << cikarma_sayisi << "  " << std::setw(7)
                  << atlanan_sayisi << "  " << std::setw(13) << en_buyuk_obek
                  << "  " << std::setw(14)
                  << static_cast<long long>(n + r.e_sayisi) * log << "  "
                  << (d1 == d2 ? "evet" : "HAYIR") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (öbek elle, H7); C++ — öbek
 * std::priority_queue<std::pair<int, int>, std::vector<…>,
 * std::greater<…>>; Python — heapq. Dijkstra'nın kendisi elle yazılır. */

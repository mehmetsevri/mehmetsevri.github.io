/* H12_10_birlesim_bul.cpp — AP-2 Hafta 12 · Örnek 10 (★★)
 * Amaç    : Birleşim–bul (ayrık kümeler): saf, yalnız rütbe, yalnız yol
 *           sıkıştırma ve ikisi birden; işaretçi izleme sayısı, ağaç
 *           yüksekliği; küçük örnekte orman, zincirde en kötü durum,
 *           rastgele işlemlerde işlem başına izleme
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_10_birlesim_bul.cpp -o H12_10_birlesim_bul
 * Çalıştır: ./H12_10_birlesim_bul
 * Eşleri  : c/H12_10_birlesim_bul.c · python/H12_10_birlesim_bul.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : saf birleştirmede birincinin kökü ikincinin köküne bağlanır;
 *           rütbede küçük rütbeli kök büyüğün altına girer (eşitse ikinci
 *           birinciye, birincinin rütbesi artar). Yol sıkıştırma iki
 *           geçişli ve yinelemelidir (özyineleme yok).
 */
#include <iomanip>
#include <iostream>
#include <numeric>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static const char* const SURUM_ADI[4] = {"saf", "yalnız rütbe",
                                         "yalnız sıkıştırma",
                                         "rütbe + sıkıştırma"};

static long long izleme_sayisi = 0;   // ebeveyn[] üzerinden işaretçi izleme
static long long baglama_sayisi = 0;  // sıkıştırmada yeniden bağlanan

struct BirlesimBul {
    std::vector<int> ebeveyn, rutbe;
    bool rutbeli, sikistir;

    BirlesimBul(int n, int surum)
        : ebeveyn(n), rutbe(n, 0), rutbeli(surum == 1 || surum == 3),
          sikistir(surum == 2 || surum == 3)
    {
        std::iota(ebeveyn.begin(), ebeveyn.end(), 0);  // her eleman kök
    }
};

// x'in kökü; sıkıştırmada yol üzerindeki düğümler köke bağlanır
static int bul(BirlesimBul& b, int x)
{
    int kok = x;
    while (b.ebeveyn[kok] != kok) {      // 1. geçiş: kökü bul
        kok = b.ebeveyn[kok];
        izleme_sayisi++;
    }
    if (b.sikistir) {
        while (b.ebeveyn[x] != kok) {    // 2. geçiş: yolu köke bağla
            int sonraki = b.ebeveyn[x];
            b.ebeveyn[x] = kok;
            baglama_sayisi++;
            x = sonraki;
        }
    }
    return kok;
}

// İki kümeyi birleştirir; zaten aynıysa false
static bool birlestir(BirlesimBul& b, int x, int y)
{
    int kx = bul(b, x), ky = bul(b, y);
    if (kx == ky) {
        return false;
    }
    if (!b.rutbeli) {
        b.ebeveyn[kx] = ky;              // saf: birincinin kökü ikinciye
        return true;
    }
    if (b.rutbe[kx] < b.rutbe[ky]) {
        std::swap(kx, ky);               // kx: rütbesi büyük olan
    }
    b.ebeveyn[ky] = kx;
    if (b.rutbe[kx] == b.rutbe[ky]) {
        b.rutbe[kx]++;
    }
    return true;
}

// Ormanın yüksekliği (en derin düğümün köke uzaklığı); sayaçlara girmez.
// Derinlikler yolun yukarısından aşağı doğru doldurulur: Θ(n).
static int yukseklik(const BirlesimBul& b)
{
    int n = static_cast<int>(b.ebeveyn.size());
    std::vector<int> derinlik(n, -1), yigin;
    int en_cok = 0;
    for (int x = 0; x < n; x++) {
        int v = x;
        while (derinlik[v] < 0 && b.ebeveyn[v] != v) {
            yigin.push_back(v);
            v = b.ebeveyn[v];
        }
        if (derinlik[v] < 0) {
            derinlik[v] = 0;             // kök
        }
        while (!yigin.empty()) {
            int u = yigin.back();
            yigin.pop_back();
            derinlik[u] = derinlik[b.ebeveyn[u]] + 1;
        }
        if (derinlik[x] > en_cok) {
            en_cok = derinlik[x];
        }
    }
    return en_cok;
}

static int kume_sayisi(const BirlesimBul& b)
{
    int k = 0;
    for (std::size_t x = 0; x < b.ebeveyn.size(); x++) {
        k += b.ebeveyn[x] == static_cast<int>(x);
    }
    return k;
}

// Görünür karakter sayısına göre doldurur (UTF-8 devam baytları sayılmaz)
static std::string sola_yasla(const std::string& s, int genislik)
{
    int g = 0;
    for (unsigned char c : s) {
        g += (c & 0xC0) != 0x80;
    }
    return s + std::string(genislik - g, ' ');
}

static std::string dizi_yaz(const std::vector<int>& a)
{
    std::string s;
    for (std::size_t i = 0; i < a.size(); i++) {
        std::string x = std::to_string(a[i]);
        s += (i > 0 ? " " : "") + std::string(2 - x.size(), ' ') + x;
    }
    return s;
}

static void kucuk_ornek()
{
    const std::vector<std::pair<int, int>> islemler = {
        {0, 1}, {2, 3}, {0, 2}, {4, 5}, {6, 7}, {4, 6}, {1, 5}, {3, 7}};
    std::cout << "1) Küçük örnek: n = 8; birleştir";
    for (const auto& [x, y] : islemler) {
        std::cout << " (" << x << "," << y << ")";
    }
    std::cout << "; sonra bul(0)\n  indis     : "
              << dizi_yaz({0, 1, 2, 3, 4, 5, 6, 7}) << "\n";
    for (int surum = 0; surum < 4; surum++) {
        BirlesimBul b(8, surum);
        izleme_sayisi = baglama_sayisi = 0;
        std::string sonuc;
        for (const auto& [x, y] : islemler) {
            sonuc += birlestir(b, x, y) ? "+" : "=";
        }
        std::vector<int> once = b.ebeveyn;
        int h_once = yukseklik(b);
        int k = bul(b, 0);
        std::cout << "  " << SURUM_ADI[surum] << " (" << sonuc
                  << "; = : zaten aynı küme)\n";
        std::cout << "    ebeveyn : " << dizi_yaz(once) << "   yükseklik "
                  << h_once << "\n";
        std::cout << "    bul(0) = " << k << "; sonra ebeveyn: "
                  << dizi_yaz(b.ebeveyn) << "   yükseklik " << yukseklik(b)
                  << "\n";
        std::cout << "    işaretçi izleme = " << izleme_sayisi
                  << ", yeniden bağlama = " << baglama_sayisi << "\n";
        if (b.rutbeli) {
            std::cout << "    rütbe   : " << dizi_yaz(b.rutbe) << "\n";
        }
    }
}

// En kötü durum: birleştir(i, i+1) sırası saf sürümde zincir kurar;
// ardından her elemanda bul
static void zincir(int n)
{
    std::cout << "\n2) Zincir: n = " << n << "; birleştir(i, i + 1), "
                 "i = 0..n-2; sonra bul(0), bul(1), …, bul(n-1)\n";
    std::cout << "  sürüm                yükseklik  birleştirme izl.  "
                 "bul izl.  bul başına\n";
    for (int surum = 0; surum < 4; surum++) {
        BirlesimBul b(n, surum);
        izleme_sayisi = baglama_sayisi = 0;
        for (int i = 0; i < n - 1; i++) {
            birlestir(b, i, i + 1);
        }
        int h = yukseklik(b);
        long long birlestirme = izleme_sayisi;
        izleme_sayisi = 0;
        for (int i = 0; i < n; i++) {
            bul(b, i);
        }
        long long bas = izleme_sayisi * 1000 / n;
        std::cout << "  " << sola_yasla(SURUM_ADI[surum], 19) << "  "
                  << std::setw(9) << h << "  " << std::setw(16)
                  << birlestirme << "  " << std::setw(8) << izleme_sayisi
                  << "  " << std::setw(6) << bas / 1000 << "."
                  << std::setfill('0') << std::setw(3) << bas % 1000
                  << std::setfill(' ') << "\n";
    }
    std::cout << "  saf: bul izleme toplamı = n(n-1)/2 = "
              << static_cast<long long>(n) * (n - 1) / 2 << "\n";
}

// n rastgele birleştirme + n rastgele bul (tohum 42, her sürüme aynı
// işlem dizisi)
static void rastgele(int n)
{
    std::cout << "  n = " << std::setw(6) << n << ":\n";
    for (int surum = 0; surum < 4; surum++) {
        BirlesimBul b(n, surum);
        izleme_sayisi = baglama_sayisi = 0;
        rastgele_tohum(42);
        for (int i = 0; i < n; i++) {
            int x = rastgele_aralik(0, n - 1);
            int y = rastgele_aralik(0, n - 1);
            birlestir(b, x, y);
        }
        for (int i = 0; i < n; i++) {
            bul(b, rastgele_aralik(0, n - 1));
        }
        long long islem = 3LL * n;       // birleştirmede 2 bul + n bul
        long long bas = izleme_sayisi * 1000 / islem;
        std::cout << "    " << sola_yasla(SURUM_ADI[surum], 19) << "  küme "
                  << std::setw(6) << kume_sayisi(b) << "  yükseklik "
                  << std::setw(4) << yukseklik(b) << "  izleme "
                  << std::setw(9) << izleme_sayisi << "  bul başına "
                  << bas / 1000 << "." << std::setfill('0') << std::setw(3)
                  << bas % 1000 << std::setfill(' ') << "\n";
    }
}

int main()
{
    kucuk_ornek();
    zincir(1000);
    std::cout << "\n3) Rastgele işlemler: n birleştirme + n bul (3n bul "
                 "çağrısı)\n";
    for (int n : {1000, 2000, 4000, 8000}) {
        rastgele(n);
    }
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (standart kütüphanelerde
 * ayrık küme yapısı yok; Boost disjoint_sets ve networkx.utils.UnionFind
 * standart dışıdır). */

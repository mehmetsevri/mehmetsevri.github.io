/* H12_12_prim.cpp — AP-2 Hafta 12 · Örnek 12 (★★★)
 * Amaç    : Prim (öbekle, tembel silme) ile en küçük kapsayan ağaç ve
 *           Kruskal (Örnek 11) ile karşılaştırma: aynı toplam ağırlık;
 *           ağırlıklar farklıyken aynı ağaç, eşit ağırlıklarda farklı ağaç
 *           olabilir; rastgele graflarda denetim
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H12_12_prim.cpp \
 *           -o H12_12_prim
 * Çalıştır: ./H12_12_prim ../girdiler/h12_kampus.txt \
 *           ../girdiler/h12_esit_agirlik.txt
 * Eşleri  : c/H12_12_prim.c · python/H12_12_prim.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek öğesi (anahtar, köşe); anahtar[v] = v'yi ağaca bağlayan en
 *           hafif kenarın ağırlığı. Dijkstra'yla aynı iskelet: yalnız
 *           gevşetme koşulu d[u] + w < d[v] yerine w < anahtar[v].
 */
#include <algorithm>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static const int SONSUZ = std::numeric_limits<int>::max();
static const std::size_t SATIR_UZUNLUGU = 512;  // C'deki fgets tamponu

static long long itme_sayisi = 0, cikarma_sayisi = 0, atlanan_sayisi = 0;
static long long izleme_sayisi = 0;   // Kruskal'ın birleşim–bul sayaçları
static long long bul_sayisi = 0;
static long long birlestir_sayisi = 0;

using Oge = std::pair<int, int>;      // (anahtar, köşe)
using Obek = std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>>;

// ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ----------------
struct Komsu {
    int hedef, agirlik;
};

struct Kenar {
    int u, v, w;
};

struct Graf {
    int v_sayisi = 0, e_sayisi = 0;
    bool yonlu = false;
    std::vector<std::vector<Komsu>> komsu;  // komsu[u]: u'dan çıkanlar
    std::vector<Kenar> kenar;               // dosyadaki sırayla
};

static void hata(const std::string& ileti)
{
    std::cerr << "Hata: " << ileti << "\n";
}

static void komsulari_sirala(Graf& g)     // (hedef, agirlik) artan
{
    for (auto& liste : g.komsu) {
        std::sort(liste.begin(), liste.end(),
                  [](const Komsu& x, const Komsu& y) {
                      return std::tie(x.hedef, x.agirlik) <
                             std::tie(y.hedef, y.agirlik);
                  });
    }
}

// '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural)
static bool tamsayi_coz(const std::string& s, int& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9) {
        return false;
    }
    for (std::size_t i = bas; i < s.size(); i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
    }
    x = std::stoi(s);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

static std::vector<std::string> parcala(const std::string& s)
{
    std::vector<std::string> t;
    std::size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && bosluk_mu(s[i])) {
            i++;
        }
        std::size_t j = i;
        while (j < s.size() && !bosluk_mu(s[j])) {
            j++;
        }
        if (j > i) {
            t.push_back(s.substr(i, j - i));
        }
        i = j;
    }
    return t;
}

// Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
// (w yoksa 1). true: başarı; false: hata (ileti stderr'de).
static bool graf_oku(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    if (!f) {
        hata("dosya açılamadı: " + yol);
        return false;
    }
    std::string satir;
    int no = 0;
    bool baslik = false;
    while (std::getline(f, satir)) {
        no++;
        if (satir.size() > SATIR_UZUNLUGU - 2) {
            hata("satır " + std::to_string(no) + ": satır çok uzun");
            return false;
        }
        std::vector<std::string> t = parcala(satir);
        if (t.empty() || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            std::string tur = t.size() == 3 ? t[2] : "yonsuz";
            if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], v) ||
                !tamsayi_coz(t[1], e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 || (tur != "yonlu" && tur != "yonsuz")) {
                hata("satır " + std::to_string(no) +
                     ": başlık 'V E [yonlu|yonsuz]' bekleniyordu");
                return false;
            }
            g.v_sayisi = v;
            g.e_sayisi = e;
            g.yonlu = tur == "yonlu";
            g.komsu.assign(v, {});
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], u) ||
            !tamsayi_coz(t[1], v) || (t.size() == 3 && !tamsayi_coz(t[2], w))) {
            hata("satır " + std::to_string(no) +
                 ": kenar 'u v [w]' bekleniyordu");
            return false;
        }
        if (u < 0 || u >= g.v_sayisi || v < 0 || v >= g.v_sayisi) {
            hata("satır " + std::to_string(no) + ": köşe numarası 0.." +
                 std::to_string(g.v_sayisi - 1) + " aralığında olmalı");
            return false;
        }
        if (static_cast<int>(g.kenar.size()) == g.e_sayisi) {
            hata("satır " + std::to_string(no) + ": fazla kenar (E = " +
                 std::to_string(g.e_sayisi) + ")");
            return false;
        }
        g.kenar.push_back(Kenar{u, v, w});
        g.komsu[u].push_back(Komsu{v, w});
        if (!g.yonlu) {
            g.komsu[v].push_back(Komsu{u, w});
        }
    }
    if (!baslik) {
        hata("başlık satırı yok");
        return false;
    }
    if (static_cast<int>(g.kenar.size()) < g.e_sayisi) {
        hata("kenar sayısı eksik: " + std::to_string(g.e_sayisi) +
             " bekleniyordu, " + std::to_string(g.kenar.size()) + " okundu");
        return false;
    }
    komsulari_sirala(g);
    return true;
}
// --------------------------------------------------------------------------

static std::string uzaklik_yaz(int d, int genislik)
{
    std::string s = d == SONSUZ ? "∞" : std::to_string(d);
    int gorunur = d == SONSUZ ? 1 : static_cast<int>(s.size());
    return std::string(std::max(0, genislik - gorunur), ' ') + s;
}

static std::string obek_yaz(Obek kopya)  // sıralı (iç düzen önemsiz)
{
    std::string s = "[";
    bool ilk = true;
    while (!kopya.empty()) {
        s += (ilk ? "(" : " (") + std::to_string(kopya.top().first) + "," +
             std::to_string(kopya.top().second) + ")";
        kopya.pop();
        ilk = false;
    }
    return s + "]";
}

// Öbekli Prim; ağaç kenarlarını (min, max, w) olarak agac'a ekler,
// toplam ağırlığı döndürür (yalnız bas'ın bileşeni)
static long long prim(const Graf& g, int bas, std::vector<Kenar>& agac,
                      bool yaz)
{
    int n = g.v_sayisi;
    std::vector<int> anahtar(n, SONSUZ), ebeveyn(n, -1);
    std::vector<bool> agacta(n, false);
    anahtar[bas] = 0;
    Obek obek;
    obek.push({0, bas});
    itme_sayisi++;
    long long toplam = 0;
    while (!obek.empty()) {
        auto [k, u] = obek.top();
        obek.pop();
        cikarma_sayisi++;
        if (agacta[u]) {                 // eskimiş kayıt
            atlanan_sayisi++;
            if (yaz) {
                std::cout << "  çıkar (" << k << "," << u << "): ESKİMİŞ ("
                          << u << " ağaçta) -> atla\n";
            }
            continue;
        }
        agacta[u] = true;
        toplam += k;
        if (ebeveyn[u] >= 0) {
            int p = ebeveyn[u];
            agac.push_back(Kenar{std::min(p, u), std::max(p, u), k});
        }
        if (yaz) {
            std::cout << "  çıkar (" << k << "," << u << "): " << u
                      << " ağaca girdi";
            if (ebeveyn[u] >= 0) {
                std::cout << " (kenar " << ebeveyn[u] << "-" << u << ", " << k
                          << ")\n";
            } else {
                std::cout << " (başlangıç)\n";
            }
        }
        for (const Komsu& kd : g.komsu[u]) {
            int v = kd.hedef, w = kd.agirlik;
            if (!agacta[v] && w < anahtar[v]) {
                if (yaz) {
                    std::cout << "     anahtar[" << v << "] = "
                              << uzaklik_yaz(anahtar[v], 1) << " -> " << w
                              << " (" << u << "-" << v << "), it (" << w
                              << "," << v << ")\n";
                }
                anahtar[v] = w;
                ebeveyn[v] = u;
                obek.push({w, v});
                itme_sayisi++;
            }
        }
        if (yaz) {
            std::cout << "     öbek: " << obek_yaz(obek) << "\n";
        }
    }
    return toplam;
}

struct BirlesimBul {             // Örnek 10'un "rütbe + sıkıştırma" sürümü
    std::vector<int> ebeveyn, rutbe;

    explicit BirlesimBul(int n) : ebeveyn(n), rutbe(n, 0)
    {
        std::iota(ebeveyn.begin(), ebeveyn.end(), 0);
    }
};

static int bul(BirlesimBul& b, int x)
{
    bul_sayisi++;
    int kok = x;
    while (b.ebeveyn[kok] != kok) {
        kok = b.ebeveyn[kok];
        izleme_sayisi++;
    }
    while (b.ebeveyn[x] != kok) {        // yol sıkıştırma
        int sonraki = b.ebeveyn[x];
        b.ebeveyn[x] = kok;
        x = sonraki;
    }
    return kok;
}

// İki farklı kökü rütbeye göre bağlar
static void birlestir_kok(BirlesimBul& b, int kx, int ky)
{
    birlestir_sayisi++;
    if (b.rutbe[kx] < b.rutbe[ky]) {
        std::swap(kx, ky);
    }
    b.ebeveyn[ky] = kx;
    if (b.rutbe[kx] == b.rutbe[ky]) {
        b.rutbe[kx]++;
    }
}

// Kesim denetimi için: sayaçsız, sıkıştırmasız kök
static int kok_sayacsiz(const BirlesimBul& b, int x)
{
    while (b.ebeveyn[x] != x) {
        x = b.ebeveyn[x];
    }
    return x;
}

// Birleştirmeden ÖNCE: S = ku kökünün kümesi (s üyelik); S ile V - S
// arasındaki en hafif kenarın ağırlığını döndürür.
static int kesim(const Graf& g, const BirlesimBul& b, int ku,
                 std::vector<bool>& s)
{
    s.assign(g.v_sayisi, false);
    for (int x = 0; x < g.v_sayisi; x++) {
        s[x] = kok_sayacsiz(b, x) == ku;
    }
    int en_hafif = -1;
    for (const Kenar& k : g.kenar) {
        if (s[k.u] != s[k.v] && (en_hafif < 0 || k.w < en_hafif)) {
            en_hafif = k.w;
        }
    }
    return en_hafif;
}

// Kenarları (w, u, v) sırasıyla dolaş; uçlar farklı ağaçtaysa al.
// Ağaç kenarlarını agac'a ekler, toplam ağırlığı döndürür.
static long long kruskal(const Graf& g, std::vector<Kenar>& agac, bool yaz)
{
    std::vector<Kenar> sira;
    for (const Kenar& k : g.kenar) {
        sira.push_back(Kenar{std::min(k.u, k.v), std::max(k.u, k.v), k.w});
    }
    std::sort(sira.begin(), sira.end(), [](const Kenar& x, const Kenar& y) {
        return std::tie(x.w, x.u, x.v) < std::tie(y.w, y.u, y.v);
    });
    BirlesimBul b(g.v_sayisi);
    std::vector<bool> s;
    long long toplam = 0;
    int adim = 0;
    for (const Kenar& e : sira) {
        adim++;
        int ku = bul(b, e.u), kv = bul(b, e.v);
        if (ku == kv) {
            if (yaz) {
                std::cout << "  " << std::setw(2) << adim << "  ("
                          << std::setw(3) << e.w << ", " << e.u << ", " << e.v
                          << ")  " << ku << " " << kv << "     RET    döngü: "
                          << e.u << " ile " << e.v << " zaten aynı ağaçta\n";
            }
            continue;
        }
        int en_hafif = 0;
        if (yaz) {
            en_hafif = kesim(g, b, ku, s);
        }
        birlestir_kok(b, ku, kv);        // iki ağaç birleşir
        agac.push_back(e);
        toplam += e.w;
        if (yaz) {
            std::cout << "  " << std::setw(2) << adim << "  (" << std::setw(3)
                      << e.w << ", " << e.u << ", " << e.v << ")  " << ku
                      << " " << kv << "     KABUL  ebeveyn:";
            for (int x : b.ebeveyn) {
                std::cout << " " << x;
            }
            std::cout << "\n      kesim S = {";
            bool ilk = true;
            for (int x = 0; x < g.v_sayisi; x++) {
                if (s[x]) {
                    std::cout << (ilk ? "" : ", ") << x;
                    ilk = false;
                }
            }
            std::cout << "}: S'den çıkan en hafif kenar " << en_hafif << " "
                      << (en_hafif == e.w ? "= w (kesim özelliği)"
                                          : "!= w (HATA)")
                      << "\n";
            if (static_cast<int>(agac.size()) == g.v_sayisi - 1) {
                std::cout << "      (ağaç tamam: V - 1 = " << g.v_sayisi - 1
                          << " kenar; erken durdurma kalanları "
                             "incelemezdi)\n";
            }
        }
    }
    return toplam;
}

static bool uvw_kucuk(const Kenar& x, const Kenar& y)
{
    return std::tie(x.u, x.v, x.w) < std::tie(y.u, y.v, y.w);
}

static std::string agac_yaz(const std::vector<Kenar>& agac)
{
    std::string s;
    for (const Kenar& e : agac) {
        s += (s.empty() ? "" : ", ") + std::to_string(e.u) + "-" +
             std::to_string(e.v) + " (" + std::to_string(e.w) + ")";
    }
    return s;
}

static bool ayni_agac(std::vector<Kenar>& a, std::vector<Kenar>& b)
{
    std::sort(a.begin(), a.end(), uvw_kucuk);
    std::sort(b.begin(), b.end(), uvw_kucuk);
    if (a.size() != b.size()) {
        return false;
    }
    for (std::size_t i = 0; i < a.size(); i++) {
        if (uvw_kucuk(a[i], b[i]) || uvw_kucuk(b[i], a[i])) {
            return false;
        }
    }
    return true;
}

// Bağlı yönsüz graf: yol 0-1-…-(n-1) + rastgele kenarlar (u != v); çoklu
// kenar olabilir. Ağırlıklar 1..w_ust: çok sayıda eşitlik.
static Graf rastgele_yonsuz(int n, int m, int w_ust, std::uint64_t tohum)
{
    rastgele_tohum(tohum);
    Graf g;
    g.v_sayisi = n;
    g.e_sayisi = m;
    g.yonlu = false;
    g.komsu.assign(n, {});
    for (int u = 0; u < n - 1; u++) {
        g.kenar.push_back(Kenar{u, u + 1, rastgele_aralik(1, w_ust)});
    }
    while (static_cast<int>(g.kenar.size()) < m) {
        int u = rastgele_aralik(0, n - 1);
        int v = rastgele_aralik(0, n - 1);
        int w = rastgele_aralik(1, w_ust);
        if (u != v) {
            g.kenar.push_back(Kenar{u, v, w});
        }
    }
    for (const Kenar& e : g.kenar) {
        g.komsu[e.u].push_back(Komsu{e.v, e.w});
        g.komsu[e.v].push_back(Komsu{e.u, e.w});
    }
    komsulari_sirala(g);
    return g;
}

static int karsilastir(const std::string& dosya)
{
    Graf g;
    if (!graf_oku(dosya, g)) {
        return 1;
    }
    if (g.yonlu) {
        hata("en küçük kapsayan ağaç yönsüz graf ister");
        return 1;
    }
    std::cout << "  graf: " << g.v_sayisi << " köşe, " << g.e_sayisi
              << " kenar\n";
    itme_sayisi = cikarma_sayisi = atlanan_sayisi = 0;
    std::vector<Kenar> ap, ak;
    long long tp = prim(g, 0, ap, true);
    long long tk = kruskal(g, ak, false);
    bool ayni = ayni_agac(ap, ak);
    std::cout << "  Prim    : " << agac_yaz(ap) << "; toplam " << tp << "\n";
    std::cout << "  Kruskal : " << agac_yaz(ak) << "; toplam " << tk << "\n";
    std::cout << "  sayaçlar (Prim): itme = " << itme_sayisi << ", çıkarma = "
              << cikarma_sayisi << ", atlanan = " << atlanan_sayisi << "\n";
    std::cout << "  toplamlar eşit mi? " << (tp == tk ? "evet" : "HAYIR")
              << "; kenar kümeleri aynı mı? " << (ayni ? "evet" : "HAYIR")
              << "\n";
    return 0;
}

static std::string taban_ad(const std::string& yol)
{
    std::size_t i = yol.rfind('/');
    return i == std::string::npos ? yol : yol.substr(i + 1);
}

int main(int argc, char** argv)
{
    if (argc != 2 && argc != 3) {
        std::cerr << "Kullanım: H12_12_prim GRAF_DOSYASI [GRAF_DOSYASI2]\n";
        return 2;
    }
    std::cout << "1) Prim (öbekle) 0'dan; Kruskal ile karşılaştırma — "
              << taban_ad(argv[1]) << "\n";
    if (karsilastir(argv[1]) != 0) {
        return 1;
    }
    std::cout << "  Ağırlıklar birbirinden farklıysa en küçük kapsayan ağaç "
                 "tektir: iki algoritma\n  aynı kenarları bulur.\n";
    if (argc == 3) {
        std::cout << "\n2) Eşit ağırlıklı kenarlar — " << taban_ad(argv[2])
                  << "\n";
        if (karsilastir(argv[2]) != 0) {
            return 1;
        }
        std::cout << "  Toplam aynı, ağaç farklı olabilir: eşit ağırlıklı "
                     "kenarlardan hangisinin\n  seçileceğini eşitlik kırma "
                     "kuralı belirler (Kruskal: (w, u, v) sırası;\n  Prim: "
                     "başlangıç köşesi ve (anahtar, köşe) sırası).\n";
    }
    std::cout << "\n3) Rastgele bağlı yönsüz graflar: V = 50, E = 200, "
                 "ağırlık 1..10 (tohum 1..20)\n";
    int esit_toplam = 0, farkli_agac = 0;
    for (int tohum = 1; tohum <= 20; tohum++) {
        Graf r = rastgele_yonsuz(50, 200, 10,
                                 static_cast<std::uint64_t>(tohum));
        std::vector<Kenar> ap, ak;
        long long tp = prim(r, 0, ap, false);
        long long tk = kruskal(r, ak, false);
        esit_toplam += tp == tk;
        farkli_agac += !ayni_agac(ap, ak);
    }
    std::cout << "  toplamlar eşit: " << esit_toplam << "/20; ağaç kenar "
                 "kümesi farklı: " << farkli_agac << "/20\n";
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (Boost Graph Library
 * prim_minimum_spanning_tree, networkx minimum_spanning_tree
 * (algorithm='prim') — standart dışı; yalnız kâhin). */

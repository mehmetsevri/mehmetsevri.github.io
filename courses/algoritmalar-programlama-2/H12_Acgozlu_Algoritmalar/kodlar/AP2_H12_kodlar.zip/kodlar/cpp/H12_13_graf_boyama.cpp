/* H12_13_graf_boyama.cpp — AP-2 Hafta 12 · Örnek 13 (★★★)
 * Amaç    : Açgözlü graf boyama (Welsh–Powell): köşeleri derece azalan
 *           (eşitlikte küçük numara) sırala; her renk için listeyi dolaş,
 *           o renkte komşusu olmayanı boya. Renk sayısı; kaba kuvvetle
 *           kromatik sayı; açgözlünün en iyi olmadığı karşı örnekler
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_13_graf_boyama.cpp -o H12_13_graf_boyama
 * Çalıştır: ./H12_13_graf_boyama ../girdiler/h12_cakisma.txt \
 *           ../girdiler/h12_yol6.txt ../girdiler/h12_tac8.txt
 * Eşleri  : c/H12_13_graf_boyama.c · python/H12_13_graf_boyama.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : sezgiseldir: sonucu "en iyi" diye raporlanmaz; kaba kuvvet
 *           (k^(V-1) boyama, köşe 0'ın rengi 0 sabit) yalnız küçük graflarda.
 */
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <tuple>
#include <vector>

static const std::size_t SATIR_UZUNLUGU = 512;  // C'deki fgets tamponu
static const int KABA_SINIR = 10;     // kaba kuvvet en çok bu kadar köşede

static long long boyama_sayisi = 0;   // kaba kuvvette incelenen boyama

// ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ----------------
struct Komsu {
    int hedef, agirlik;
};

struct Kenar {
    int u, v, w;
};

struct Graf {
    int v_sayisi = 0, e_sayisi = 0;
    bool yonlu = false;
    std::vector<std::vector<Komsu>> komsu;  // komsu[u]: u'dan çıkanlar
    std::vector<Kenar> kenar;               // dosyadaki sırayla
};

static void hata(const std::string& ileti)
{
    std::cerr << "Hata: " << ileti << "\n";
}

static void komsulari_sirala(Graf& g)     // (hedef, agirlik) artan
{
    for (auto& liste : g.komsu) {
        std::sort(liste.begin(), liste.end(),
                  [](const Komsu& x, const Komsu& y) {
                      return std::tie(x.hedef, x.agirlik) <
                             std::tie(y.hedef, y.agirlik);
                  });
    }
}

// '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural)
static bool tamsayi_coz(const std::string& s, int& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9) {
        return false;
    }
    for (std::size_t i = bas; i < s.size(); i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
    }
    x = std::stoi(s);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

static std::vector<std::string> parcala(const std::string& s)
{
    std::vector<std::string> t;
    std::size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && bosluk_mu(s[i])) {
            i++;
        }
        std::size_t j = i;
        while (j < s.size() && !bosluk_mu(s[j])) {
            j++;
        }
        if (j > i) {
            t.push_back(s.substr(i, j - i));
        }
        i = j;
    }
    return t;
}

// Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
// (w yoksa 1). true: başarı; false: hata (ileti stderr'de).
static bool graf_oku(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    if (!f) {
        hata("dosya açılamadı: " + yol);
        return false;
    }
    std::string satir;
    int no = 0;
    bool baslik = false;
    while (std::getline(f, satir)) {
        no++;
        if (satir.size() > SATIR_UZUNLUGU - 2) {
            hata("satır " + std::to_string(no) + ": satır çok uzun");
            return false;
        }
        std::vector<std::string> t = parcala(satir);
        if (t.empty() || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            std::string tur = t.size() == 3 ? t[2] : "yonsuz";
            if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], v) ||
                !tamsayi_coz(t[1], e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 || (tur != "yonlu" && tur != "yonsuz")) {
                hata("satır " + std::to_string(no) +
                     ": başlık 'V E [yonlu|yonsuz]' bekleniyordu");
                return false;
            }
            g.v_sayisi = v;
            g.e_sayisi = e;
            g.yonlu = tur == "yonlu";
            g.komsu.assign(v, {});
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], u) ||
            !tamsayi_coz(t[1], v) || (t.size() == 3 && !tamsayi_coz(t[2], w))) {
            hata("satır " + std::to_string(no) +
                 ": kenar 'u v [w]' bekleniyordu");
            return false;
        }
        if (u < 0 || u >= g.v_sayisi || v < 0 || v >= g.v_sayisi) {
            hata("satır " + std::to_string(no) + ": köşe numarası 0.." +
                 std::to_string(g.v_sayisi - 1) + " aralığında olmalı");
            return false;
        }
        if (static_cast<int>(g.kenar.size()) == g.e_sayisi) {
            hata("satır " + std::to_string(no) + ": fazla kenar (E = " +
                 std::to_string(g.e_sayisi) + ")");
            return false;
        }
        g.kenar.push_back(Kenar{u, v, w});
        g.komsu[u].push_back(Komsu{v, w});
        if (!g.yonlu) {
            g.komsu[v].push_back(Komsu{u, w});
        }
    }
    if (!baslik) {
        hata("başlık satırı yok");
        return false;
    }
    if (static_cast<int>(g.kenar.size()) < g.e_sayisi) {
        hata("kenar sayısı eksik: " + std::to_string(g.e_sayisi) +
             " bekleniyordu, " + std::to_string(g.kenar.size()) + " okundu");
        return false;
    }
    komsulari_sirala(g);
    return true;
}
// --------------------------------------------------------------------------

// Derece azalan, eşitlikte küçük numara
static std::vector<int> wp_sirasi(const Graf& g)
{
    std::vector<int> sira(g.v_sayisi);
    for (int v = 0; v < g.v_sayisi; v++) {
        sira[v] = v;
    }
    std::sort(sira.begin(), sira.end(), [&g](int x, int y) {
        int dx = static_cast<int>(g.komsu[x].size());
        int dy = static_cast<int>(g.komsu[y].size());
        return dx != dy ? dx > dy : x < y;
    });
    return sira;
}

// Derece azalan sıra; renk c için sırayı dolaş, c renginde komşusu
// olmayan boyanmamış köşeyi c ile boya. Renk sayısını döndürür.
static int welsh_powell(const Graf& g, std::vector<int>& renk, bool yaz)
{
    int n = g.v_sayisi;
    std::vector<int> sira = wp_sirasi(g);
    if (yaz) {
        std::cout << "  sıra (derece azalan, eşitlikte küçük numara):";
        for (int v : sira) {
            std::cout << " " << v << "(d=" << g.komsu[v].size() << ")";
        }
        std::cout << "\n";
    }
    renk.assign(n, -1);
    int boyanan = 0, c = 0;
    while (boyanan < n) {
        if (yaz) {
            std::cout << "  renk " << c << ":";
        }
        for (int x : sira) {
            if (renk[x] != -1) {
                continue;
            }
            bool uygun = true;
            for (const Komsu& k : g.komsu[x]) {
                if (renk[k.hedef] == c) {  // x'in c renkli komşusu var
                    uygun = false;
                    break;
                }
            }
            if (uygun) {
                renk[x] = c;
                boyanan++;
                if (yaz) {
                    std::cout << " " << x;
                }
            }
        }
        if (yaz) {
            std::cout << "\n";
        }
        c++;
    }
    return c;
}

// Verilen sırada her köşeye komşularında kullanılmayan en küçük renk
// (first-fit). Renk sayısını döndürür.
static int sirali_boya(const Graf& g, const std::vector<int>& sira,
                       std::vector<int>& renk)
{
    int n = g.v_sayisi;
    renk.assign(n, -1);
    int en_cok = 0;
    for (int x : sira) {
        std::vector<bool> kullanilan(n + 1, false);
        for (const Komsu& k : g.komsu[x]) {
            if (renk[k.hedef] >= 0) {
                kullanilan[renk[k.hedef]] = true;
            }
        }
        int c = 0;
        while (kullanilan[c]) {
            c++;
        }
        renk[x] = c;
        en_cok = std::max(en_cok, c + 1);
    }
    return en_cok;
}

static bool gecerli_mi(const Graf& g, const std::vector<int>& renk)
{
    for (const Kenar& e : g.kenar) {
        if (renk[e.u] == renk[e.v]) {
            return false;
        }
    }
    return true;
}

// Kaba kuvvet: k = 1, 2, … için bütün k^(V-1) boyamalar (köşe 0'ın rengi
// 0); ilk geçerli boyamanın k'si
static int kromatik_sayi(const Graf& g, std::vector<int>& renk)
{
    int n = g.v_sayisi;
    for (int k = 1; k <= n; k++) {
        renk.assign(n, 0);
        for (;;) {
            boyama_sayisi++;
            if (gecerli_mi(g, renk)) {
                return k;
            }
            int i = n - 1;               // sayaç gibi bir sonraki boyama
            while (i >= 1 && renk[i] == k - 1) {
                renk[i] = 0;
                i--;
            }
            if (i < 1) {
                break;
            }
            renk[i]++;
        }
    }
    return n;
}

static std::string taban_ad(const std::string& yol)
{
    std::size_t i = yol.rfind('/');
    return i == std::string::npos ? yol : yol.substr(i + 1);
}

static std::string renk_yaz(const std::vector<int>& renk)
{
    std::string s;
    for (std::size_t v = 0; v < renk.size(); v++) {
        s += (v > 0 ? " " : "") + std::to_string(v) + ":" +
             std::to_string(renk[v]);
    }
    return s;
}

// Grafı okur, boyar, kaba kuvvetle karşılaştırır; başarıda true
static bool boya_ve_karsilastir(const std::string& dosya,
                                const std::string& baslik, Graf& g,
                                std::vector<int>& renk, int& k)
{
    if (!graf_oku(dosya, g)) {
        return false;
    }
    int n = g.v_sayisi;
    std::cout << baslik << " — " << taban_ad(dosya) << ": " << n
              << " köşe, " << g.e_sayisi << " kenar\n";
    k = welsh_powell(g, renk, true);
    std::cout << "  Welsh–Powell renk sayısı = " << k << "; renkler: "
              << renk_yaz(renk) << "; geçerli mi? "
              << (gecerli_mi(g, renk) ? "evet" : "HAYIR") << "\n";
    std::vector<int> ff;
    sirali_boya(g, wp_sirasi(g), ff);
    std::cout << "  aynı sırayla ilk uygun renk (first-fit) aynı boyamayı "
                 "veriyor mu? " << (ff == renk ? "evet" : "HAYIR") << "\n";
    if (n <= KABA_SINIR) {
        boyama_sayisi = 0;
        std::vector<int> br;
        int chi = kromatik_sayi(g, br);
        std::cout << "  kaba kuvvet: kromatik sayı = " << chi << " ("
                  << boyama_sayisi << " boyama incelendi); örnek: "
                  << renk_yaz(br) << "\n";
        std::cout << "  Welsh–Powell " << k << " renk, en iyi " << chi << ": "
                  << (k == chi ? "en iyi"
                               : std::to_string(k - chi) + " renk FAZLA")
                  << "\n";
    }
    return true;
}

int main(int argc, char** argv)
{
    if (argc < 2) {
        std::cerr << "Kullanım: H12_13_graf_boyama GRAF_DOSYASI "
                     "[GRAF_DOSYASI ...]\n";
        return 2;
    }
    Graf g;
    std::vector<int> renk;
    int k;
    if (!boya_ve_karsilastir(argv[1], "1) Sınav çakışma grafı", g, renk, k)) {
        return 1;
    }
    std::cout << "  oturum ataması (aynı oturumdaki dersler ortak "
                 "öğrencisiz):\n";
    for (int c = 0; c < k; c++) {
        std::cout << "    oturum " << c + 1 << ": ders";
        for (int v = 0; v < g.v_sayisi; v++) {
            if (renk[v] == c) {
                std::cout << " " << v;
            }
        }
        std::cout << "\n";
    }
    for (int i = 2; i < argc; i++) {
        std::cout << "\n";
        Graf h;
        if (!boya_ve_karsilastir(argv[i], std::to_string(i) +
                                              ") Karşı örnek " +
                                              std::to_string(i - 1),
                                 h, renk, k)) {
            return 1;
        }
        std::vector<int> sira;
        for (int v = 0; v < h.v_sayisi; v += 2) {
            sira.push_back(v);
        }
        for (int v = 1; v < h.v_sayisi; v += 2) {
            sira.push_back(v);
        }
        int k2 = sirali_boya(h, sira, renk);
        std::cout << "  başka sıra (önce çift, sonra tek numaralılar:";
        for (int v : sira) {
            std::cout << " " << v;
        }
        std::cout << ") ile first-fit: " << k2
                  << " renk — sonuç sıraya bağlı\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (networkx
 * greedy_color(strategy='largest_first'), standart dışı; yalnız kâhin). */

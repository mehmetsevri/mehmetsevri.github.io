/* H12_07_dijkstra_dizi.cpp — AP-2 Hafta 12 · Örnek 7 (★★)
 * Amaç    : Ağırlıklı graf okuma (ortak biçim) ve dizi tabanlı O(V²)
 *           Dijkstra: her adımda kesinleşmemiş en küçük uzaklıklı köşeyi
 *           doğrusal taramayla seç, komşularını gevşet; kesinleşen küme ve
 *           uzaklık tablosu adım adım
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_07_dijkstra_dizi.cpp -o H12_07_dijkstra_dizi
 * Çalıştır: ./H12_07_dijkstra_dizi ../girdiler/h12_kampus.txt 0
 * Eşleri  : c/H12_07_dijkstra_dizi.c · python/H12_07_dijkstra_dizi.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : komşular artan köşe numarasıyla (okuyucu sıralar); eşit
 *           uzaklıkta küçük numaralı köşe seçilir. SONSUZ =
 *           std::numeric_limits<int>::max(), yazdırılırken ∞.
 */
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <tuple>
#include <vector>

#include "ortak_rastgele.hpp"

static const int SONSUZ = std::numeric_limits<int>::max();
static const std::size_t SATIR_UZUNLUGU = 512;  // C'deki fgets tamponu

static long long taranan_hucre = 0;   // en küçüğü seçerken bakılan d[]
static long long kenar_inceleme = 0;  // incelenen kenar (u, v)
static long long gevsetme_sayisi = 0; // d[v]'yi küçülten gevşetme

// ---------------- Ortak graf dosyası okuyucu (rehber 14.3) ----------------
struct Komsu {
    int hedef, agirlik;
};

struct Kenar {
    int u, v, w;
};

struct Graf {
    int v_sayisi = 0, e_sayisi = 0;
    bool yonlu = false;
    std::vector<std::vector<Komsu>> komsu;  // komsu[u]: u'dan çıkanlar
    std::vector<Kenar> kenar;               // dosyadaki sırayla
};

static void hata(const std::string& ileti)
{
    std::cerr << "Hata: " << ileti << "\n";
}

static void komsulari_sirala(Graf& g)     // (hedef, agirlik) artan
{
    for (auto& liste : g.komsu) {
        std::sort(liste.begin(), liste.end(),
                  [](const Komsu& x, const Komsu& y) {
                      return std::tie(x.hedef, x.agirlik) <
                             std::tie(y.hedef, y.agirlik);
                  });
    }
}

// '-'? rakam+ (en çok 9 rakam); değilse false (üç dilde aynı kural)
static bool tamsayi_coz(const std::string& s, int& x)
{
    std::size_t bas = (!s.empty() && s[0] == '-') ? 1 : 0;
    std::size_t n = s.size() - bas;
    if (n == 0 || n > 9) {
        return false;
    }
    for (std::size_t i = bas; i < s.size(); i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
    }
    x = std::stoi(s);
    return true;
}

static bool bosluk_mu(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\v' ||
           c == '\f';
}

static std::vector<std::string> parcala(const std::string& s)
{
    std::vector<std::string> t;
    std::size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && bosluk_mu(s[i])) {
            i++;
        }
        std::size_t j = i;
        while (j < s.size() && !bosluk_mu(s[j])) {
            j++;
        }
        if (j > i) {
            t.push_back(s.substr(i, j - i));
        }
        i = j;
    }
    return t;
}

// Ortak graf dosyası: '#' yorum; 'V E [yonlu|yonsuz]'; E satır 'u v [w]'
// (w yoksa 1). true: başarı; false: hata (ileti stderr'de).
static bool graf_oku(const std::string& yol, Graf& g)
{
    std::ifstream f(yol, std::ios::binary);
    if (!f) {
        hata("dosya açılamadı: " + yol);
        return false;
    }
    std::string satir;
    int no = 0;
    bool baslik = false;
    while (std::getline(f, satir)) {
        no++;
        if (satir.size() > SATIR_UZUNLUGU - 2) {
            hata("satır " + std::to_string(no) + ": satır çok uzun");
            return false;
        }
        std::vector<std::string> t = parcala(satir);
        if (t.empty() || t[0][0] == '#') {
            continue;
        }
        if (!baslik) {
            int v, e;
            std::string tur = t.size() == 3 ? t[2] : "yonsuz";
            if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], v) ||
                !tamsayi_coz(t[1], e) || v < 1 || v > 1000000 || e < 0 ||
                e > 10000000 || (tur != "yonlu" && tur != "yonsuz")) {
                hata("satır " + std::to_string(no) +
                     ": başlık 'V E [yonlu|yonsuz]' bekleniyordu");
                return false;
            }
            g.v_sayisi = v;
            g.e_sayisi = e;
            g.yonlu = tur == "yonlu";
            g.komsu.assign(v, {});
            baslik = true;
            continue;
        }
        int u, v, w = 1;
        if ((t.size() != 2 && t.size() != 3) || !tamsayi_coz(t[0], u) ||
            !tamsayi_coz(t[1], v) || (t.size() == 3 && !tamsayi_coz(t[2], w))) {
            hata("satır " + std::to_string(no) +
                 ": kenar 'u v [w]' bekleniyordu");
            return false;
        }
        if (u < 0 || u >= g.v_sayisi || v < 0 || v >= g.v_sayisi) {
            hata("satır " + std::to_string(no) + ": köşe numarası 0.." +
                 std::to_string(g.v_sayisi - 1) + " aralığında olmalı");
            return false;
        }
        if (static_cast<int>(g.kenar.size()) == g.e_sayisi) {
            hata("satır " + std::to_string(no) + ": fazla kenar (E = " +
                 std::to_string(g.e_sayisi) + ")");
            return false;
        }
        g.kenar.push_back(Kenar{u, v, w});
        g.komsu[u].push_back(Komsu{v, w});
        if (!g.yonlu) {
            g.komsu[v].push_back(Komsu{u, w});
        }
    }
    if (!baslik) {
        hata("başlık satırı yok");
        return false;
    }
    if (static_cast<int>(g.kenar.size()) < g.e_sayisi) {
        hata("kenar sayısı eksik: " + std::to_string(g.e_sayisi) +
             " bekleniyordu, " + std::to_string(g.kenar.size()) + " okundu");
        return false;
    }
    komsulari_sirala(g);
    return true;
}
// --------------------------------------------------------------------------

static std::string uzaklik_yaz(int d, int genislik)
{
    std::string s = d == SONSUZ ? "∞" : std::to_string(d);
    int gorunur = d == SONSUZ ? 1 : static_cast<int>(s.size());
    return std::string(std::max(0, genislik - gorunur), ' ') + s;
}

// O(V²): öncelik kuyruğu yerine d[] dizisinde doğrusal en küçük arama
static void dijkstra_dizi(const Graf& g, int kaynak, std::vector<int>& d,
                          std::vector<int>& ebeveyn, bool yaz)
{
    int n = g.v_sayisi;
    std::vector<bool> kesin(n, false);
    d.assign(n, SONSUZ);
    ebeveyn.assign(n, -1);
    d[kaynak] = 0;
    for (int adim = 1; adim <= n; adim++) {
        int u = -1;
        for (int v = 0; v < n; v++) {    // en küçük d: doğrusal tarama
            taranan_hucre++;
            if (!kesin[v] && d[v] != SONSUZ && (u < 0 || d[v] < d[u])) {
                u = v;
            }
        }
        if (u < 0) {
            break;                       // kalanlar ulaşılamaz
        }
        kesin[u] = true;                 // d[u] artık kesin
        if (yaz) {
            std::cout << "  adım " << adim << ": seç " << u << " (d = "
                      << d[u] << "); kesinleşen {";
            bool ilk = true;
            for (int x = 0; x < n; x++) {
                if (kesin[x]) {
                    std::cout << (ilk ? "" : ", ") << x;
                    ilk = false;
                }
            }
            std::cout << "}\n";
        }
        for (const Komsu& k : g.komsu[u]) {
            int v = k.hedef, w = k.agirlik;
            kenar_inceleme++;
            if (kesin[v]) {
                continue;
            }
            if (d[u] != SONSUZ && d[u] + w < d[v]) {   // taşma korumalı
                if (yaz) {
                    std::cout << "     gevşet " << u << "->" << v << " (w = "
                              << w << "): d[" << v << "] = "
                              << uzaklik_yaz(d[v], 1) << " -> " << d[u] + w
                              << "\n";
                }
                d[v] = d[u] + w;
                ebeveyn[v] = u;
                gevsetme_sayisi++;
            } else if (yaz) {
                std::cout << "     " << u << "->" << v << " (w = " << w
                          << "): " << d[u] << " + " << w << " >= " << d[v]
                          << ", değişmez\n";
            }
        }
        if (yaz) {
            std::cout << "     d:";
            for (int x : d) {
                std::cout << " " << uzaklik_yaz(x, 1);
            }
            std::cout << "\n";
        }
    }
}

// Yönlü: her u için u -> u+1 (halka, ulaşılabilirlik için) ve derece-1
// rastgele kenar; ağırlıklar 1..w_ust (ortak LCG)
static Graf rastgele_graf(int v_sayisi, int derece, int w_ust,
                          std::uint64_t tohum)
{
    rastgele_tohum(tohum);
    Graf g;
    g.v_sayisi = v_sayisi;
    g.e_sayisi = v_sayisi * derece;
    g.yonlu = true;
    g.komsu.assign(v_sayisi, {});
    for (int u = 0; u < v_sayisi; u++) {
        int w = rastgele_aralik(1, w_ust);
        g.komsu[u].push_back(Komsu{(u + 1) % v_sayisi, w});
        for (int j = 0; j < derece - 1; j++) {
            int v = rastgele_aralik(0, v_sayisi - 1);
            w = rastgele_aralik(1, w_ust);
            g.komsu[u].push_back(Komsu{v, w});
        }
    }
    komsulari_sirala(g);
    return g;
}

int main(int argc, char** argv)
{
    if (argc != 2 && argc != 3) {
        std::cerr << "Kullanım: H12_07_dijkstra_dizi GRAF_DOSYASI [KAYNAK]\n";
        return 2;
    }
    Graf g;
    if (!graf_oku(argv[1], g)) {
        return 1;
    }
    int kaynak = 0;
    if (argc == 3 && (!tamsayi_coz(argv[2], kaynak) || kaynak < 0 ||
                      kaynak >= g.v_sayisi)) {
        hata("kaynak köşe 0.." + std::to_string(g.v_sayisi - 1) +
             " aralığında olmalı");
        return 2;
    }
    for (const Kenar& k : g.kenar) {
        if (k.w < 0) {
            hata("negatif ağırlık " + std::to_string(k.u) + "->" +
                 std::to_string(k.v) + " (" + std::to_string(k.w) +
                 "): Dijkstra'nın önkoşulu sağlanmıyor (Örnek 9)");
            return 1;
        }
    }
    std::cout << "1) Graf: " << g.v_sayisi << " köşe, " << g.e_sayisi
              << " kenar, "
              << (g.yonlu ? "yönlü" : "yönsüz (her kenar iki yönde)") << "\n";
    std::cout << "  komşuluk listesi, hedef(ağırlık):\n";
    for (int u = 0; u < g.v_sayisi; u++) {
        std::cout << "    " << u << ":";
        for (const Komsu& k : g.komsu[u]) {
            std::cout << " " << k.hedef << "(" << k.agirlik << ")";
        }
        std::cout << "\n";
    }

    std::cout << "\n2) Dizi tabanlı Dijkstra, kaynak " << kaynak << "\n";
    std::vector<int> d, ebeveyn;
    dijkstra_dizi(g, kaynak, d, ebeveyn, true);
    std::cout << "  köşe  uzaklık  ebeveyn\n";
    for (int v = 0; v < g.v_sayisi; v++) {
        std::cout << "  " << std::setw(4) << v << "  " << uzaklik_yaz(d[v], 7)
                  << "  " << std::setw(7) << ebeveyn[v] << "\n";
    }
    std::cout << "  sayaçlar: taranan hücre = " << taranan_hucre << " (V² = "
              << static_cast<long long>(g.v_sayisi) * g.v_sayisi
              << "), kenar inceleme = " << kenar_inceleme
              << ", başarılı gevşetme = " << gevsetme_sayisi << "\n";

    std::cout << "\n3) Rastgele yönlü graflarda sayaçlar (derece 4, ağırlık "
                 "1..100)\n";
    std::cout << "      V       E   taranan hücre          V²  kenar inc.  "
                 "gevşetme\n";
    for (int n : {100, 200, 400, 800}) {
        Graf r = rastgele_graf(n, 4, 100, 42);
        std::vector<int> rd, re;
        taranan_hucre = kenar_inceleme = gevsetme_sayisi = 0;
        dijkstra_dizi(r, 0, rd, re, false);
        std::cout << "  " << std::setw(5) << n << "  " << std::setw(6)
                  << r.e_sayisi << "  " << std::setw(14) << taranan_hucre
                  << "  " << std::setw(10) << static_cast<long long>(n) * n
                  << "  " << std::setw(10) << kenar_inceleme << "  "
                  << std::setw(8) << gevsetme_sayisi << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (Boost Graph Library
 * dijkstra_shortest_paths, standart dışı); Python — yok (networkx
 * dijkstra_path, standart dışı; yalnız kâhin olarak kullanılabilir). */

/* H12_01_para_ustu.cpp — AP-2 Hafta 12 · Örnek 1 (★)
 * Amaç    : Açgözlü para üstü (AP-1 H4'e dönüş): her adımda en büyük madeni
 *           parayı al; kanonik sistemlerde en iyi, {1, 3, 4} sisteminde 6
 *           için yanlış — kaba kuvvetle (tüm kombinasyonlar) gösterilir
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H12_01_para_ustu.cpp \
 *           -o H12_01_para_ustu
 * Çalıştır: ./H12_01_para_ustu
 * Eşleri  : c/H12_01_para_ustu.c · python/H12_01_para_ustu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <vector>

static const int UST_TUTAR = 100;  // kaba kuvvet denetiminin üst sınırı

static long long kombinasyon_sayisi = 0;  // incelenen geçerli kombinasyon

// Sistemi artan sırayla yazar: {1, 3, 4}
static void sistem_yaz(const std::vector<int>& para)
{
    std::cout << "{";
    for (int i = static_cast<int>(para.size()) - 1; i >= 0; i--) {
        std::cout << (i < static_cast<int>(para.size()) - 1 ? ", " : "")
                  << para[i];
    }
    std::cout << "}";
}

// para[] azalan sıralı; her adımda sığan en büyük parayı alır.
// Parça sayısını döndürür; ödenemezse -1.
static int acgozlu(const std::vector<int>& para, int tutar,
                   std::vector<int>& adet)
{
    int parca = 0;
    for (std::size_t i = 0; i < para.size(); i++) {
        adet[i] = tutar / para[i];       // yerel en iyi seçim
        tutar -= adet[i] * para[i];
        parca += adet[i];
    }
    return tutar == 0 ? parca : -1;
}

// Bütün kombinasyonlar: i. paradan 0..kalan/para[i] adet. En az
// parçalı kombinasyon en_iyi ve en_iyi_adet'e yazılır.
static void kaba_kuvvet(const std::vector<int>& para, std::size_t i,
                        int kalan, std::vector<int>& adet, int& en_iyi,
                        std::vector<int>& en_iyi_adet, bool liste)
{
    std::size_t k = para.size();
    if (i == k - 1) {                    // son para kalanı tam bölmeli
        if (kalan % para[i] != 0) {
            return;
        }
        adet[i] = kalan / para[i];
        kombinasyon_sayisi++;
        int parca = 0;
        for (std::size_t j = 0; j < k; j++) {
            parca += adet[j];
        }
        if (liste) {
            std::cout << "    ";
            for (std::size_t j = 0; j < k; j++) {
                std::cout << (j > 0 ? " + " : "") << para[j] << "x"
                          << adet[j];
            }
            std::cout << " -> " << parca << "\n";
        }
        if (en_iyi < 0 || parca < en_iyi) {
            en_iyi = parca;
            en_iyi_adet = adet;
        }
        return;
    }
    for (int a = kalan / para[i]; a >= 0; a--) {
        adet[i] = a;
        kaba_kuvvet(para, i + 1, kalan - a * para[i], adet, en_iyi,
                    en_iyi_adet, liste);
    }
}

static int en_az_parca(const std::vector<int>& para, int tutar,
                       std::vector<int>& en_iyi_adet, bool liste)
{
    std::vector<int> adet(para.size(), 0);
    int en_iyi = -1;
    kaba_kuvvet(para, 0, tutar, adet, en_iyi, en_iyi_adet, liste);
    return en_iyi;
}

static void cozum_yaz(const std::vector<int>& para, int tutar,
                      const std::vector<int>& adet, int parca)
{
    std::cout << tutar << " = ";
    bool ilk = true;
    for (std::size_t i = 0; i < para.size(); i++) {
        if (adet[i] > 0) {
            std::cout << (ilk ? "" : " + ") << para[i] << "x" << adet[i];
            ilk = false;
        }
    }
    std::cout << " -> " << parca << " parça\n";
}

// 1..UST_TUTAR için açgözlü ile kaba kuvveti karşılaştırır
static void sistemi_dene(const std::vector<int>& para)
{
    std::vector<int> adet(para.size()), en_iyi_adet(para.size());
    std::vector<int> hatali;
    kombinasyon_sayisi = 0;
    for (int t = 1; t <= UST_TUTAR; t++) {
        if (acgozlu(para, t, adet) !=
            en_az_parca(para, t, en_iyi_adet, false)) {
            hatali.push_back(t);
        }
    }
    int h = static_cast<int>(hatali.size());
    std::cout << "  ";
    sistem_yaz(para);
    std::cout << ": açgözlü " << UST_TUTAR - h << "/" << UST_TUTAR
              << " tutarda en iyi; incelenen kombinasyon = "
              << kombinasyon_sayisi << "\n";
    if (h > 0) {
        std::cout << "    en iyi olmadığı tutar sayısı = " << h
                  << "; ilk 8:";
        for (int i = 0; i < h && i < 8; i++) {
            std::cout << " " << hatali[i];
        }
        std::cout << "\n";
    }
}

int main()
{
    const std::vector<int> ap1 = {200, 100, 50, 20, 10, 5, 1};  // AP-1 H4
    const std::vector<int> abd = {25, 10, 5, 1};
    const std::vector<int> bozuk = {4, 3, 1};
    const std::vector<int> yedi = {10, 7, 1};
    std::vector<int> adet(7), en_iyi_adet(7);

    std::cout << "1) AP-1 H4 sistemi ";
    sistem_yaz(ap1);
    std::cout << ": açgözlü para üstü\n";
    std::cout << "  ";
    cozum_yaz(ap1, 387, adet, acgozlu(ap1, 387, adet));

    std::cout << "\n2) Kaba kuvvetle doğrulama (tüm kombinasyonlar), tutar "
                 "1.." << UST_TUTAR << "\n";
    for (const auto& para : {ap1, abd, bozuk, yedi}) {
        sistemi_dene(para);
    }

    std::cout << "\n3) Karşı örnek: ";
    sistem_yaz(bozuk);
    std::cout << " sisteminde 6\n";
    std::cout << "  açgözlü : ";
    cozum_yaz(bozuk, 6, adet, acgozlu(bozuk, 6, adet));
    kombinasyon_sayisi = 0;
    std::cout << "  bütün kombinasyonlar (büyük paradan küçüğe):\n";
    int en_iyi = en_az_parca(bozuk, 6, en_iyi_adet, true);
    std::cout << "  en iyi  : ";
    cozum_yaz(bozuk, 6, en_iyi_adet, en_iyi);
    std::cout << "  (" << kombinasyon_sayisi << " kombinasyon incelendi)\n";
    std::cout << "  Açgözlü ilk adımda 4'ü seçer; kalan 2 yalnız 1 + 1 ile "
                 "ödenir.\n  En iyi çözüm 4'ü hiç kullanmaz: açgözlü seçim "
                 "özelliği bu sistemde yok.\n";

    std::cout << "\n4) Bir karşı örnek daha: ";
    sistem_yaz(yedi);
    std::cout << " sisteminde 14\n";
    std::cout << "  açgözlü : ";
    cozum_yaz(yedi, 14, adet, acgozlu(yedi, 14, adet));
    std::cout << "  en iyi  : ";
    cozum_yaz(yedi, 14, en_iyi_adet, en_az_parca(yedi, 14, en_iyi_adet,
                                                  false));
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (açgözlü para üstü bir
 * kütüphane işlevi değildir); en iyi çözüm için genel yöntem dinamik
 * programlamadır (H13). */

/* H12_03_aralik_bolumleme.cpp — AP-2 Hafta 12 · Örnek 3 (★★)
 * Amaç    : Aralık bölümleme: bütün dersleri en az salonla yerleştirmek;
 *           başlangıca göre sırala, salonların bitiş zamanlarını en küçük
 *           öbekte tut; salon ataması ve alt sınır (aynı anda en çok ders)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_03_aralik_bolumleme.cpp -o H12_03_aralik_bolumleme
 * Çalıştır: ./H12_03_aralik_bolumleme
 * Eşleri  : c/H12_03_aralik_bolumleme.c ·
 *           python/H12_03_aralik_bolumleme.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek öğesi (bitiş, salon) çifti; eşitlikte küçük salon.
 *           Aralıklar yarı açık: 10:30'da biten salon 10:30'da başlayana
 *           verilebilir.
 */
#include <algorithm>
#include <cstdio>
#include <functional>
#include <iostream>
#include <queue>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

struct Ders {
    int bas, bit, kimlik;
};

// (bitiş, salon) çiftleri; std::greater ile en küçük öbek
using Oge = std::pair<int, int>;
using Obek = std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>>;

static long long itme_sayisi = 0, cikarma_sayisi = 0;

static std::string saat(int dk)
{
    char t[16];
    std::snprintf(t, sizeof t, "%02d:%02d", dk / 60, dk % 60);
    return t;
}

// Öbek içeriği (bitiş, salon) sıralı yazılır: iç dizi düzeni
// kütüphaneye göre değişir, çıktı buna bağlı olmasın
static std::string obek_yaz(Obek kopya)
{
    std::string s = "[";
    bool ilk = true;
    while (!kopya.empty()) {             // kopyadan çıkarmak sıralı verir
        s += (ilk ? "(" : " (") + saat(kopya.top().first) + "," +
             std::to_string(kopya.top().second + 1) + ")";
        kopya.pop();
        ilk = false;
    }
    return s + "]";
}

// ders: (bas, bit, kimlik). salon[kimlik] = atanan salon.
// Salon sayısını döndürür.
static int bolumle(const std::vector<Ders>& ders, std::vector<int>& salon,
                   bool yaz)
{
    std::vector<Ders> sira = ders;
    std::sort(sira.begin(), sira.end(), [](const Ders& x, const Ders& y) {
        return std::tie(x.bas, x.bit, x.kimlik) <
               std::tie(y.bas, y.bit, y.kimlik);
    });
    Obek obek;                           // (bitiş, salon) çiftleri
    int salon_sayisi = 0;
    for (const Ders& x : sira) {
        int s;
        std::string not_;
        if (!obek.empty() && obek.top().first <= x.bas) {  // en erken boşalan
            s = obek.top().second;
            obek.pop();
            cikarma_sayisi++;
            not_ = "boşalan salon";
        } else {
            s = salon_sayisi++;          // yeni salon aç
            not_ = "YENİ salon";
        }
        salon[x.kimlik] = s;
        obek.push({x.bit, s});
        itme_sayisi++;
        if (yaz) {
            std::cout << "  " << static_cast<char>('A' + x.kimlik) << " "
                      << saat(x.bas) << "-" << saat(x.bit) << " -> salon "
                      << s + 1 << " (" << not_ << ")  öbek: "
                      << obek_yaz(obek) << "\n";
        }
    }
    return salon_sayisi;
}

// Alt sınır: aynı anda süren en çok ders sayısı. Olaylar (zaman, tür):
// tür 0 = bitiş, 1 = başlangıç; aynı anda önce bitişler (yarı açık).
// (derinlik, ilk ulaşıldığı zaman) döndürür.
static std::pair<int, int> derinlik(const std::vector<Ders>& ders)
{
    std::vector<std::pair<int, int>> olay;
    for (const Ders& x : ders) {
        olay.push_back({x.bas, 1});
        olay.push_back({x.bit, 0});
    }
    std::sort(olay.begin(), olay.end());
    int etkin = 0, en_cok = 0, zaman = 0;
    for (const auto& [t, tur] : olay) {
        etkin += tur == 1 ? 1 : -1;
        if (etkin > en_cok) {
            en_cok = etkin;
            zaman = t;
        }
    }
    return {en_cok, zaman};
}

int main()
{
    const int veri[10][2] = {{540, 630}, {540, 750}, {600, 690}, {630, 720},
                             {660, 840}, {720, 810}, {780, 870}, {810, 960},
                             {870, 960}, {900, 990}};
    std::vector<Ders> ders;
    for (int i = 0; i < 10; i++) {
        ders.push_back(Ders{veri[i][0], veri[i][1], i});
    }
    std::vector<int> salon(ders.size(), 0);
    std::cout << "1) " << ders.size()
              << " ders, başlangıca göre sıra; öbekte (bitiş, salon)\n";
    int k = bolumle(ders, salon, true);
    std::cout << "  gereken salon = " << k << "; öbeğe itme = "
              << itme_sayisi << ", çıkarma = " << cikarma_sayisi << "\n";
    auto [d, t] = derinlik(ders);
    std::cout << "  alt sınır: " << saat(t) << "'da aynı anda " << d
              << " ders sürüyor -> en az " << d << " salon gerekir\n";
    std::cout << "  açgözlü " << k << " salon = alt sınır " << d << ": "
              << (k == d ? "en iyi" : "FARKLI") << "\n";

    std::cout << "\n2) Salon ataması (zaman çizgisi)\n";
    for (int s = 0; s < k; s++) {
        std::cout << "  salon " << s + 1 << ": ";
        bool ilk = true;
        for (std::size_t i = 0; i < ders.size(); i++) {
            if (salon[i] == s) {
                std::cout << (ilk ? "" : ", ")
                          << static_cast<char>('A' + i) << " "
                          << saat(ders[i].bas) << "-" << saat(ders[i].bit);
                ilk = false;
            }
        }
        std::cout << "\n";
    }

    std::cout << "\n3) Rastgele denetim: salon sayısı = derinlik mi?\n";
    rastgele_tohum(42);
    int esit = 0;
    for (int deneme = 0; deneme < 1000; deneme++) {
        int n = rastgele_aralik(5, 30);
        std::vector<Ders> r;
        for (int i = 0; i < n; i++) {
            int bas = rastgele_aralik(0, 100);
            r.push_back(Ders{bas, bas + rastgele_aralik(1, 30), i});
        }
        std::vector<int> rs(n, 0);
        itme_sayisi = cikarma_sayisi = 0;
        esit += bolumle(r, rs, false) == derinlik(r).first;
    }
    std::cout << "  1000 rastgele örnek (n = 5..30, tohum 42): eşit = "
              << esit << "/1000\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (öbek elle, H7); C++ — öbek
 * std::priority_queue<std::pair<int, int>, …, std::greater<…>>; Python —
 * heapq (en küçük öbek). Bölümleme algoritmasının kendisi elle yazılır. */

/* H12_04_kesirli_sirt_cantasi.cpp — AP-2 Hafta 12 · Örnek 4 (★★)
 * Amaç    : Kesirli sırt çantası: birim değere (değer/ağırlık) göre sırala,
 *           sığanı tam al, sonuncusunun kesrini al; değer tamsayı kesir
 *           olarak tutulur. Kâhin: bütün sıralamalar (n!). 0/1 sırt
 *           çantasında aynı ölçütün başarısızlığı (H13'e köprü)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_04_kesirli_sirt_cantasi.cpp -o H12_04_kesirli_sirt_cantasi
 * Çalıştır: ./H12_04_kesirli_sirt_cantasi
 * Eşleri  : c/H12_04_kesirli_sirt_cantasi.c ·
 *           python/H12_04_kesirli_sirt_cantasi.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : oranlar çapraz çarpımla karşılaştırılır (v1·w2 ile v2·w1):
 *           kayan nokta yok; eşitlikte küçük kimlik önce
 */
#include <algorithm>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

struct Yuk {
    int agirlik, deger, kimlik;
};

struct Kesir {
    long long pay, payda;       // indirgenmiş kesir, payda > 0
};

static long long ebob(long long a, long long b)
{
    while (b != 0) {
        long long g = a % b;
        a = b;
        b = g;
    }
    return a;
}

// pay/payda'yı iki basamakla yuvarlar (tamsayı aritmetiği)
static std::string ondalik(long long pay, long long payda)
{
    long long yuz = (pay * 200 + payda) / (2 * payda);
    char s[32];
    std::snprintf(s, sizeof s, "%lld.%02lld", yuz / 100, yuz % 100);
    return s;
}

static std::string kesir_yaz(Kesir k)
{
    if (k.payda == 1) {
        return std::to_string(k.pay);
    }
    return std::to_string(k.pay) + "/" + std::to_string(k.payda) + " = " +
           ondalik(k.pay, k.payda);
}

// x önce gelmeli mi? x.deger/x.agirlik > y.deger/y.agirlik
static bool birim_degere_gore(const Yuk& x, const Yuk& y)
{
    long long sol = static_cast<long long>(x.deger) * y.agirlik;
    long long sag = static_cast<long long>(y.deger) * x.agirlik;
    if (sol != sag) {
        return sol > sag;
    }
    return x.kimlik < y.kimlik;
}

// Sırayla doldurur; değeri indirgenmiş kesir olarak döndürür
static Kesir doldur(const std::vector<Yuk>& sira, int kapasite, bool yaz)
{
    long long tam = 0;
    int kalan = kapasite;
    for (const Yuk& x : sira) {
        if (kalan == 0) {
            break;
        }
        if (x.agirlik <= kalan) {        // tamamı sığar
            kalan -= x.agirlik;
            tam += x.deger;
            if (yaz) {
                std::cout << "  " << static_cast<char>('A' + x.kimlik)
                          << ": " << std::setw(2) << x.agirlik << "/"
                          << std::setw(2) << x.agirlik << " kg alındı (+"
                          << x.deger << "), kalan kapasite " << kalan
                          << "\n";
            }
        } else {                         // kesri alınır, çanta dolar
            long long pay = tam * x.agirlik +
                            static_cast<long long>(x.deger) * kalan;
            long long payda = x.agirlik;
            long long g = ebob(pay, payda);
            Kesir k = {pay / g, payda / g};
            if (yaz) {
                std::cout << "  " << static_cast<char>('A' + x.kimlik)
                          << ": " << std::setw(2) << kalan << "/"
                          << std::setw(2) << x.agirlik << " kg alındı (+"
                          << x.deger << "·" << kalan << "/" << x.agirlik
                          << "), kalan kapasite 0\n";
                std::cout << "  toplam değer = " << tam << " + "
                          << x.deger * kalan << "/" << x.agirlik << " = "
                          << kesir_yaz(k) << "\n";
            }
            return k;
        }
    }
    if (yaz) {
        std::cout << "  toplam değer = " << tam << "\n";
    }
    return Kesir{tam, 1};
}

// Sözlük sırasında sonraki permütasyon; son permütasyondaysa false
static bool sonraki_permutasyon(std::vector<int>& p)
{
    int n = static_cast<int>(p.size());
    int i = n - 2;
    while (i >= 0 && p[i] >= p[i + 1]) {
        i--;
    }
    if (i < 0) {
        return false;
    }
    int j = n - 1;
    while (p[j] <= p[i]) {
        j--;
    }
    std::swap(p[i], p[j]);
    std::reverse(p.begin() + i + 1, p.end());
    return true;
}

// Bütün n! sırayla doldurma; en büyük değeri ve sıra sayısını verir
static Kesir kahin(const std::vector<Yuk>& yuk, int kapasite, int& sayi)
{
    std::vector<int> p(yuk.size());
    for (std::size_t i = 0; i < p.size(); i++) {
        p[i] = static_cast<int>(i);
    }
    Kesir en = {-1, 1};
    sayi = 0;
    do {
        sayi++;
        std::vector<Yuk> sira;
        for (int i : p) {
            sira.push_back(yuk[i]);
        }
        Kesir k = doldur(sira, kapasite, false);
        if (k.pay * en.payda > en.pay * k.payda) {
            en = k;
        }
    } while (sonraki_permutasyon(p));
    return en;
}

// 0/1: bütün alt kümeler; (en iyi değer, maske)
static std::pair<int, unsigned> sifir_bir_kaba(const std::vector<Yuk>& yuk,
                                               int kapasite)
{
    int n = static_cast<int>(yuk.size());
    int en_iyi = -1;
    unsigned en_maske = 0;
    for (unsigned maske = 0; maske < (1u << n); maske++) {
        int w = 0, v = 0;
        for (int i = 0; i < n; i++) {
            if (maske >> i & 1u) {
                w += yuk[i].agirlik;
                v += yuk[i].deger;
            }
        }
        if (w <= kapasite && v > en_iyi) {
            en_iyi = v;
            en_maske = maske;
        }
    }
    return {en_iyi, en_maske};
}

int main()
{
    const int veri[6][2] = {{12, 84}, {8, 40}, {20, 100}, {15, 90},
                            {25, 80}, {9, 30}};
    std::vector<Yuk> yuk;
    for (int i = 0; i < 6; i++) {
        yuk.push_back(Yuk{veri[i][0], veri[i][1], i});
    }
    int kapasite = 60;
    std::cout << "1) Kesirli sırt çantası: kapasite " << kapasite << " kg, "
              << yuk.size() << " yük\n";
    std::cout << "  yük  ağırlık  değer  birim değer\n";
    for (const Yuk& x : yuk) {
        std::cout << "  " << static_cast<char>('A' + x.kimlik) << "   "
                  << std::setw(5) << x.agirlik << "  " << std::setw(5)
                  << x.deger << "  " << std::setw(11)
                  << ondalik(x.deger, x.agirlik) << "\n";
    }
    std::vector<Yuk> sira = yuk;
    std::sort(sira.begin(), sira.end(), birim_degere_gore);
    std::cout << "  birim değere göre sıra (azalan; eşitlikte kimlik):";
    for (const Yuk& x : sira) {
        std::cout << " " << static_cast<char>('A' + x.kimlik);
    }
    std::cout << "\n";
    Kesir k = doldur(sira, kapasite, true);

    std::cout << "\n2) Kâhin: " << yuk.size()
              << " yükün bütün sıralamalarıyla doldurma\n";
    int sayi;
    Kesir en = kahin(yuk, kapasite, sayi);
    std::cout << "  " << sayi << " sıralama; en büyük değer "
              << kesir_yaz(en) << "; birim değer sırası bunu veriyor mu? "
              << ((k.pay == en.pay && k.payda == en.payda) ? "evet"
                                                         : "HAYIR")
              << "\n";
    sira = yuk;
    std::sort(sira.begin(), sira.end(), [](const Yuk& x, const Yuk& y) {
        return x.deger != y.deger ? x.deger > y.deger : x.kimlik < y.kimlik;
    });
    std::cout << "  'en değerli ilk' sırası : "
              << kesir_yaz(doldur(sira, kapasite, false)) << "\n";
    sira = yuk;
    std::sort(sira.begin(), sira.end(), [](const Yuk& x, const Yuk& y) {
        return x.agirlik != y.agirlik ? x.agirlik < y.agirlik
                                      : x.kimlik < y.kimlik;
    });
    std::cout << "  'en hafif ilk' sırası   : "
              << kesir_yaz(doldur(sira, kapasite, false)) << "\n";

    std::cout << "\n3) 0/1 sırt çantasında birim değer ölçütü yetmez (H13'e "
                 "köprü)\n";
    const std::vector<Yuk> kucuk = {{10, 60, 0}, {20, 100, 1}, {30, 120, 2}};
    std::cout << "  kapasite 50: A(10 kg, 60) B(20 kg, 100) C(30 kg, 120)\n";
    sira = kucuk;
    std::sort(sira.begin(), sira.end(), birim_degere_gore);
    std::cout << "  kesirli açgözlü          : "
              << kesir_yaz(doldur(sira, 50, false)) << "\n";
    int w = 0, v = 0;
    std::string alinan;
    for (const Yuk& x : sira) {          // 0/1: ya tamamı ya hiç
        if (w + x.agirlik <= 50) {
            w += x.agirlik;
            v += x.deger;
            alinan += static_cast<char>('A' + x.kimlik);
        }
    }
    std::cout << "  0/1 açgözlü (birim değer): " << alinan << " -> " << v
              << "\n";
    auto [en_iyi, maske] = sifir_bir_kaba(kucuk, 50);
    std::cout << "  0/1 en iyi (kaba kuvvet, " << (1u << kucuk.size())
              << " alt küme): ";
    for (std::size_t i = 0; i < kucuk.size(); i++) {
        if (maske >> i & 1u) {
            std::cout << static_cast<char>('A' + i);
        }
    }
    std::cout << " -> " << en_iyi << "\n";
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok; sıralama aracı qsort /
 * std::sort / sorted (karşılaştırıcı tam sıralama tanımlar). */

/* H12_06_huffman_kodlama.cpp — AP-2 Hafta 12 · Örnek 6 (★★★)
 * Amaç    : Huffman ile metin kodlama/çözme: bit tamponu (std::uint8_t),
 *           bayt hizalama ve dolgu bitleri, kodlanmış bayt sayısı,
 *           sıkıştırma oranı, entropiyle karşılaştırma; çözülen = özgün
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_06_huffman_kodlama.cpp -o H12_06_huffman_kodlama
 * Çalıştır: ./H12_06_huffman_kodlama \
 *           < ../girdiler/H12_06_huffman_kodlama.txt
 * Eşleri  : c/H12_06_huffman_kodlama.c · python/H12_06_huffman_kodlama.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : ağaç Örnek 5'teki gibi kurulur. Kodlanmış bayt sayısına ağaç
 *           (ya da kod uzunlukları tablosu) DAHİL DEĞİLDİR; bir dosya
 *           biçimi onu da saklamalıdır (2. bölümün son satırı).
 */
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <queue>
#include <string>
#include <utility>
#include <vector>

using Oge = std::pair<long long, int>;   // (sıklık, düğüm)
using Obek = std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>>;
using Baytlar = std::vector<std::uint8_t>;

struct Agac {
    std::vector<int> sembol;        // -1: iç düğüm
    std::vector<long long> siklik;
    std::vector<int> sol, sag;
    int kok = -1;
};

static int dugum_ekle(Agac& t, int sembol, long long siklik, int sol, int sag)
{
    t.sembol.push_back(sembol);
    t.siklik.push_back(siklik);
    t.sol.push_back(sol);
    t.sag.push_back(sag);
    return static_cast<int>(t.sembol.size()) - 1;
}

// siklik[0..255] → Huffman ağacı; öbek öğesi (sıklık, düğüm no)
static Agac agac_kur(const std::vector<long long>& siklik)
{
    Agac t;
    Obek obek;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            int d = dugum_ekle(t, b, siklik[b], -1, -1);
            obek.push({siklik[b], d});
        }
    }
    while (obek.size() > 1) {
        auto [fx, x] = obek.top();
        obek.pop();
        auto [fy, y] = obek.top();
        obek.pop();
        int z = dugum_ekle(t, -1, fx + fy, x, y);
        obek.push({fx + fy, z});
    }
    if (!obek.empty()) {
        t.kok = obek.top().second;
    }
    return t;
}

static void kod_ata(const Agac& t, int d, const std::string& kod,
                    std::vector<std::string>& kodlar)
{
    if (t.sembol[d] >= 0) {
        kodlar[t.sembol[d]] = kod.empty() ? "0" : kod;  // tek düğüm: "0"
        return;
    }
    kod_ata(t, t.sol[d], kod + "0", kodlar);
    kod_ata(t, t.sag[d], kod + "1", kodlar);
}

// Bit tamponu: bit i, bayt i >> 3'ün (7 - i & 7). bitine (önce en anlamlı
// bit) yazılır. Toplam bit sayısı toplam_bit'e yazılır.
static Baytlar kodla(const Baytlar& metin,
                     const std::vector<std::string>& kodlar,
                     std::size_t& toplam_bit)
{
    std::size_t toplam = 0;
    for (std::uint8_t b : metin) {
        toplam += kodlar[b].size();
    }
    toplam_bit = toplam;
    Baytlar tampon((toplam + 7) / 8, 0);          // sıfırlarla dolu
    std::size_t i = 0;
    for (std::uint8_t b : metin) {
        for (char c : kodlar[b]) {
            if (c == '1') {
                tampon[i >> 3] |= static_cast<std::uint8_t>(0x80u >> (i & 7));
            }
            i++;
        }
    }
    return tampon;
}

// Kökten başla; 0 sola, 1 sağa; yaprakta simgeyi yaz, köke dön
static Baytlar coz(const Agac& t, const Baytlar& tampon,
                   std::size_t toplam_bit)
{
    Baytlar cikti;
    int d = t.kok;
    for (std::size_t i = 0; i < toplam_bit; i++) {
        if (t.sembol[t.kok] >= 0) {      // tek düğüm: her bit bir simge
            cikti.push_back(static_cast<std::uint8_t>(t.sembol[t.kok]));
            continue;
        }
        int bit = tampon[i >> 3] >> (7 - (i & 7)) & 1;
        d = bit ? t.sag[d] : t.sol[d];
        if (t.sembol[d] >= 0) {
            cikti.push_back(static_cast<std::uint8_t>(t.sembol[d]));
            d = t.kok;
        }
    }
    return cikti;
}

static std::uint32_t fnv1a(const Baytlar& veri)
{
    std::uint32_t h = 2166136261u;
    for (std::uint8_t b : veri) {
        h = (h ^ b) * 16777619u;
    }
    return h;
}

static std::string sembol_yaz(int b)
{
    if (b == 32) {
        return "␣";
    }
    if (b >= 33 && b <= 126) {
        return std::string(1, static_cast<char>(b));
    }
    char t[16];
    std::snprintf(t, sizeof t, "\\x%02X", static_cast<unsigned>(b) & 0xFFu);
    return t;
}

static std::string onaltilik(std::uint8_t b)
{
    char t[8];
    std::snprintf(t, sizeof t, "%02X", static_cast<unsigned>(b));
    return t;
}

// pay/payda'yı 'basamak' ondalıkla yuvarlar (tamsayı aritmetiği)
static std::string ondalik(long long pay, long long payda, int basamak)
{
    long long olcek = 1;
    for (int i = 0; i < basamak; i++) {
        olcek *= 10;
    }
    long long x = (pay * olcek * 2 + payda) / (2 * payda);
    std::string kesir = std::to_string(x % olcek);
    return std::to_string(x / olcek) + "." +
           std::string(basamak - kesir.size(), '0') + kesir;
}

static std::vector<long long> siklik_say(const Baytlar& metin)
{
    std::vector<long long> siklik(256, 0);
    for (std::uint8_t b : metin) {
        siklik[b]++;
    }
    return siklik;
}

static Baytlar baytlar(const std::string& s)
{
    return Baytlar(s.begin(), s.end());
}

static void kucuk_ornek(const std::string& metin_s)
{
    Baytlar metin = baytlar(metin_s);
    std::cout << "1) Küçük örnek: \"" << metin_s << "\" (" << metin.size()
              << " bayt)\n";
    Agac t = agac_kur(siklik_say(metin));
    std::vector<std::string> kodlar(256);
    kod_ata(t, t.kok, "", kodlar);
    std::size_t toplam;
    Baytlar tampon = kodla(metin, kodlar, toplam);
    std::cout << "  simge kodları (Örnek 5):";
    for (int b = 0; b < 256; b++) {
        if (!kodlar[b].empty()) {
            std::cout << " " << sembol_yaz(b) << "=" << kodlar[b];
        }
    }
    std::string satir;
    for (std::size_t i = 0; i < tampon.size() * 8; i++) {
        if (i > 0 && i % 8 == 0) {
            satir += " ";
        }
        if (i < toplam) {
            satir += static_cast<char>('0' + (tampon[i >> 3] >>
                                               (7 - (i & 7)) & 1));
        } else {
            satir += "x";
        }
    }
    std::cout << "\n  bitler (bayt bayt; x = dolgu): " << satir << "\n";
    std::cout << "  " << toplam << " bit -> " << tampon.size()
              << " bayt (dolgu " << tampon.size() * 8 - toplam << " bit):";
    for (std::uint8_t b : tampon) {
        std::cout << " " << onaltilik(b);
    }
    Baytlar cozulen = coz(t, tampon, toplam);
    std::cout << "\n  çözülen: \"" << std::string(cozulen.begin(),
                                                   cozulen.end())
              << "\" (aynı mı? " << (cozulen == metin ? "evet" : "HAYIR")
              << ")\n";
}

static void buyuk_ornek(const Baytlar& metin)
{
    long long n = static_cast<long long>(metin.size());
    std::vector<long long> siklik = siklik_say(metin);
    Agac t = agac_kur(siklik);
    std::vector<std::string> kodlar(256);
    kod_ata(t, t.kok, "", kodlar);
    int farkli = 0;
    std::size_t en_uzun = 0;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            farkli++;
            en_uzun = std::max(en_uzun, kodlar[b].size());
        }
    }
    std::cout << "\n2) Ömer Seyfettin metni (standart girdi): " << n
              << " bayt, " << farkli << " farklı bayt değeri\n";
    std::vector<int> dagilim(en_uzun + 1, 0);
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            dagilim[kodlar[b].size()]++;
        }
    }
    std::cout << "  kod uzunluğu -> simge sayısı:";
    bool ilk = true;
    for (std::size_t u = 1; u <= en_uzun; u++) {
        if (dagilim[u] > 0) {
            std::cout << (ilk ? " " : ", ") << u << ":" << dagilim[u];
            ilk = false;
        }
    }
    std::vector<int> sira;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            sira.push_back(b);
        }
    }
    std::sort(sira.begin(), sira.end(), [&siklik](int x, int y) {
        return siklik[x] != siklik[y] ? siklik[x] > siklik[y] : x < y;
    });
    std::cout << "\n  en sık 6 simge:";
    for (std::size_t i = 0; i < sira.size() && i < 6; i++) {
        std::cout << (i > 0 ? ", " : " ") << sembol_yaz(sira[i]) << " "
                  << siklik[sira[i]] << " (" << kodlar[sira[i]] << ")";
    }
    std::size_t toplam;
    Baytlar tampon = kodla(metin, kodlar, toplam);
    long long bayt = static_cast<long long>(tampon.size());
    std::cout << "\n  toplam " << toplam << " bit -> " << bayt
              << " bayt (dolgu " << bayt * 8 - static_cast<long long>(toplam)
              << " bit)\n";
    std::cout << "  ortalama kod uzunluğu = "
              << ondalik(static_cast<long long>(toplam), n, 4)
              << " bit/simge (sabit 8 bit yerine)\n";
    double entropi = 0.0;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            entropi += static_cast<double>(siklik[b]) / n *
                       std::log2(static_cast<double>(n) / siklik[b]);
        }
    }
    std::cout << "  entropi (bayt düzeyi, sıfırıncı derece) = " << std::fixed
              << std::setprecision(4) << entropi
              << " bit/simge: alt sınır\n";
    std::cout << "  sıkıştırma oranı = " << bayt << " / " << n << " = %"
              << ondalik(bayt * 100, n, 2) << "\n";
    char ozet[16];
    std::snprintf(ozet, sizeof ozet, "%08x",
                  static_cast<unsigned>(fnv1a(tampon)));
    std::cout << "  kodlanmış akışın FNV-1a özeti = 0x" << ozet
              << "; ilk 8 bayt:";
    for (std::size_t i = 0; i < tampon.size() && i < 8; i++) {
        std::cout << " " << onaltilik(tampon[i]);
    }
    Baytlar cozulen = coz(t, tampon, toplam);
    std::cout << "\n  çözülen metin özgün metinle aynı mı? "
              << (cozulen == metin ? "evet" : "HAYIR") << " ("
              << cozulen.size() << " bayt)\n";
    long long dosya = bayt + 256 + 4;
    std::cout << "  ağaç bu sayıya dahil değil: 256 baytlık kod uzunluğu "
                 "tablosu + 4 bayt simge sayısıyla " << dosya << " bayt (%"
              << ondalik(dosya * 100, n, 2) << ")\n";
}

static void tek_simge(const std::string& metin_s)
{
    Baytlar metin = baytlar(metin_s);
    Agac t = agac_kur(siklik_say(metin));
    std::vector<std::string> kodlar(256);
    kod_ata(t, t.kok, "", kodlar);
    std::size_t toplam;
    Baytlar tampon = kodla(metin, kodlar, toplam);
    Baytlar cozulen = coz(t, tampon, toplam);
    std::cout << "\n3) Tek simgeli metin \"" << metin_s << "\": kod \""
              << kodlar[metin[0]] << "\" -> " << toplam << " bit, "
              << tampon.size() << " bayt; çözülen aynı mı? "
              << (cozulen == metin ? "evet" : "HAYIR") << "\n";
}

int main()
{
    std::cin >> std::noskipws;
    Baytlar metin((std::istreambuf_iterator<char>(std::cin)),
                  std::istreambuf_iterator<char>());
    kucuk_ornek("ey edip adanada pide ye");
    if (metin.empty()) {
        std::cout << "\n2) Standart girdi boş: büyük örnek atlandı\n";
    } else {
        buyuk_ornek(metin);
    }
    tek_simge("aaaaaaa");
    return 0;
}

/* Kütüphane karşılığı: C — yok (zlib/DEFLATE, standart dışı); C++ — yok;
 * Python — zlib.compress (DEFLATE = LZ77 + Huffman), bit düzeyinde
 * int.to_bytes / int.from_bytes. Ağaç ve kodlama elle yazılır. */

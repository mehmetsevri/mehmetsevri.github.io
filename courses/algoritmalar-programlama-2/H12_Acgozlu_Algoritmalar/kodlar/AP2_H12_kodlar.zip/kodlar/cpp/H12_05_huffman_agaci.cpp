/* H12_05_huffman_agaci.cpp — AP-2 Hafta 12 · Örnek 5 (★★★)
 * Amaç    : Huffman ağacı: sıklık tablosu, en küçük öbekle iki en küçüğü
 *           birleştirme (her adımda öbek içeriği), kod tablosu (simge
 *           sırasıyla), ağırlıklı yol uzunluğu; tek simgeli metin sınırı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H12_05_huffman_agaci.cpp -o H12_05_huffman_agaci
 * Çalıştır: ./H12_05_huffman_agaci
 * Eşleri  : c/H12_05_huffman_agaci.c · python/H12_05_huffman_agaci.py
 * Çıktı   : üç dilde aynı (=)
 * Not     : öbek öğesi (sıklık, düğüm no) çifti. Düğüm no oluşturulma
 *           sırasıdır (yapraklar bayt değeri sırasıyla, sonra iç düğümler):
 *           eşit sıklıkta önce oluşturulan çıkar. İlk çıkan sol (0), ikinci
 *           sağ (1) çocuk olur. Tek düğümlü ağaçta kod "0" verilir.
 */
#include <cstdio>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <string>
#include <utility>
#include <vector>

// (sıklık, düğüm) çiftleri; std::greater ile en küçük öbek
using Oge = std::pair<long long, int>;
using Obek = std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>>;

static long long itme_sayisi = 0, cikarma_sayisi = 0;

struct Agac {                       // düğümler vektörlerde
    std::vector<int> sembol;        // -1: iç düğüm
    std::vector<long long> siklik;
    std::vector<int> sol, sag;
    int kok = -1;                   // boş metinde -1
};

static int dugum_ekle(Agac& t, int sembol, long long siklik, int sol, int sag)
{
    t.sembol.push_back(sembol);
    t.siklik.push_back(siklik);
    t.sol.push_back(sol);
    t.sag.push_back(sag);
    return static_cast<int>(t.sembol.size()) - 1;
}

// Simgenin görünür biçimi: ␣ boşluk, yazdırılabilir ASCII, yoksa \xHH
static std::string sembol_yaz(int b)
{
    if (b == 32) {
        return "␣";
    }
    if (b >= 33 && b <= 126) {
        return std::string(1, static_cast<char>(b));
    }
    char t[8];
    std::snprintf(t, sizeof t, "\\x%02X", static_cast<unsigned>(b));
    return t;
}

// Görünür karakter sayısına göre doldurur (UTF-8 devam baytları sayılmaz)
static std::string sola_yasla(const std::string& s, int genislik)
{
    int g = 0;
    for (unsigned char c : s) {
        g += (c & 0xC0) != 0x80;
    }
    return s + std::string(genislik - g, ' ');
}

static std::string dugum_ad(const Agac& t, int i)
{
    return t.sembol[i] >= 0 ? sembol_yaz(t.sembol[i])
                            : "#" + std::to_string(i);
}

static std::string obek_yaz(const Agac& t, Obek kopya)
{
    std::string s;
    while (!kopya.empty()) {             // kopyadan çıkarmak sıralı verir
        s += (s.empty() ? "" : " ") + std::to_string(kopya.top().first) +
             ":" + dugum_ad(t, kopya.top().second);
        kopya.pop();
    }
    return s;
}

// siklik[0..255] → Huffman ağacı (kök t.kok; boş metinde -1)
static Agac agac_kur(const std::vector<long long>& siklik, bool yaz)
{
    Agac t;
    Obek obek;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {             // yapraklar bayt sırasıyla
            int d = dugum_ekle(t, b, siklik[b], -1, -1);
            obek.push({siklik[b], d});
            itme_sayisi++;
        }
    }
    if (yaz) {
        std::cout << "  başlangıç öbeği: " << obek_yaz(t, obek) << "\n";
    }
    int adim = 0;
    while (obek.size() > 1) {
        auto [fx, x] = obek.top();       // en küçük iki ağaç
        obek.pop();
        auto [fy, y] = obek.top();
        obek.pop();
        cikarma_sayisi += 2;
        int z = dugum_ekle(t, -1, fx + fy, x, y);
        obek.push({fx + fy, z});
        itme_sayisi++;
        adim++;
        if (yaz) {
            std::cout << "  adım " << adim << ": " << fx << ":"
                      << dugum_ad(t, x) << " + " << fy << ":"
                      << dugum_ad(t, y) << " -> #" << z << " (" << fx + fy
                      << ")   öbek: " << obek_yaz(t, obek) << "\n";
        }
    }
    if (!obek.empty()) {
        t.kok = obek.top().second;
        obek.pop();
        cikarma_sayisi++;
    }
    return t;
}

// Kökten yaprağa: sola 0, sağa 1
static void kod_ata(const Agac& t, int d, const std::string& kod,
                    std::vector<std::string>& kodlar)
{
    if (t.sembol[d] >= 0) {
        kodlar[t.sembol[d]] = kod.empty() ? "0" : kod;  // tek düğüm: "0"
        return;
    }
    kod_ata(t, t.sol[d], kod + "0", kodlar);
    kod_ata(t, t.sag[d], kod + "1", kodlar);
}

// Yan yatırılmış ağaç: sağ (1) üstte, sol (0) altta
static void agac_ciz(const Agac& t, int d, const std::string& girinti)
{
    if (t.sembol[d] < 0) {
        agac_ciz(t, t.sag[d], girinti + "      ");
    }
    std::cout << "  " << girinti << t.siklik[d] << ":" << dugum_ad(t, d)
              << "\n";
    if (t.sembol[d] < 0) {
        agac_ciz(t, t.sol[d], girinti + "      ");
    }
}

// Kod tablosu simge sırasıyla; ağırlıklı yol uzunluğu
static void tablo_yaz(const Agac& t, const std::vector<long long>& siklik,
                      const std::vector<std::string>& kodlar)
{
    std::cout << "  simge  sıklık  kod          uzunluk  sıklık×uzunluk\n";
    long long toplam = 0;
    int farkli = 0;
    for (int b = 0; b < 256; b++) {
        if (siklik[b] > 0) {
            long long u = static_cast<long long>(kodlar[b].size());
            toplam += siklik[b] * u;
            farkli++;
            std::cout << "  " << sola_yasla(sembol_yaz(b), 5) << "  "
                      << std::setw(6) << siklik[b] << "  " << std::left
                      << std::setw(12) << kodlar[b] << std::right << " "
                      << std::setw(7) << u << "  " << std::setw(14)
                      << siklik[b] * u << "\n";
        }
    }
    long long ic = 0;
    for (std::size_t d = 0; d < t.sembol.size(); d++) {
        if (t.sembol[d] < 0) {
            ic += t.siklik[d];
        }
    }
    int sabit = 1;
    while ((1 << sabit) < farkli) {
        sabit++;
    }
    long long n = 0;
    for (int b = 0; b < 256; b++) {
        n += siklik[b];
    }
    std::cout << "  ağırlıklı yol uzunluğu B(T) = Σ sıklık × uzunluk = "
              << toplam << " bit\n";
    if (t.sembol[t.kok] >= 0) {
        std::cout << "  tek düğüm: kök yapraktır, kod uzunluğu 0 olurdu; kod "
                     "\"0\" (1 bit/simge) verildi\n";
    } else {
        std::cout << "  iç düğüm sıklıkları toplamı = " << ic
                  << " (B(T) ile aynı olmalı)\n";
    }
    std::cout << "  sabit uzunluklu kod: " << farkli << " simge -> " << sabit
              << " bit/simge, " << n << " × " << sabit << " = " << n * sabit
              << " bit\n";
}

// Hiçbir kod başka bir kodun öneki değil mi? (O(k²) kaba denetim)
static bool onek_denetimi(const std::vector<long long>& siklik,
                          const std::vector<std::string>& kodlar)
{
    for (int a = 0; a < 256; a++) {
        for (int b = 0; b < 256; b++) {
            if (a != b && siklik[a] > 0 && siklik[b] > 0 &&
                kodlar[b].compare(0, kodlar[a].size(), kodlar[a]) == 0) {
                return false;
            }
        }
    }
    return true;
}

static void calistir(const std::string& baslik,
                     const std::vector<long long>& siklik)
{
    itme_sayisi = cikarma_sayisi = 0;
    std::cout << baslik << "\n";
    Agac t = agac_kur(siklik, true);
    std::vector<std::string> kodlar(256);
    kod_ata(t, t.kok, "", kodlar);
    std::cout << "  ağaç (sağ çocuk = 1 üstte, sol çocuk = 0 altta):\n";
    agac_ciz(t, t.kok, "");
    tablo_yaz(t, siklik, kodlar);
    std::cout << "  önek özelliği: "
              << (onek_denetimi(siklik, kodlar) ? "sağlanıyor" : "YOK")
              << "; öbeğe itme = " << itme_sayisi << ", çıkarma = "
              << cikarma_sayisi << "\n";
}

static std::vector<long long> metin_sikligi(const std::string& metin)
{
    std::vector<long long> siklik(256, 0);
    for (unsigned char b : metin) {
        siklik[b]++;
    }
    return siklik;
}

int main()
{
    std::vector<long long> siklik(256, 0);
    const long long f[6] = {45, 13, 12, 16, 9, 5};
    for (int i = 0; i < 6; i++) {
        siklik['a' + i] = f[i];
    }
    calistir("1) Sıklık tablosu a:45 b:13 c:12 d:16 e:9 f:5 (Cormen vd.)",
             siklik);
    std::string metin = "ey edip adanada pide ye";
    calistir("\n2) Metin \"" + metin + "\" (" + std::to_string(metin.size()) +
             " bayt; ␣ = boşluk)", metin_sikligi(metin));
    metin = "aaaaaaa";
    calistir("\n3) Sınır durumu: tek simgeli metin \"" + metin + "\"",
             metin_sikligi(metin));
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — Huffman ağacı kurucu yok (zlib
 * içinde DEFLATE'in kendi Huffman kodlayıcısı vardır ama ağaç arayüzü
 * sunmaz); öbek: C elle, C++ std::priority_queue, Python heapq. */

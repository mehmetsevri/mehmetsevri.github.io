"""H14_Q60_h12_sonsuz.py — AP-2 Hafta 14 · Final hazırlık (H12) · Diller arası
Amaç    : SONSUZ = 2**31 - 1 (C'deki INT_MAX) iken d[u] + w Python'da
          taşmaz; karşılaştırma doğru biçimde False çıkar.
          C eşi: H14_Q60_h12_sonsuz.c
Çalıştır: python3 H14_Q60_h12_sonsuz.py
"""
SONSUZ = 2**31 - 1


def main():
    du, w, dv = SONSUZ, 5, 100
    print(du + w, du + w < dv)


if __name__ == "__main__":
    main()

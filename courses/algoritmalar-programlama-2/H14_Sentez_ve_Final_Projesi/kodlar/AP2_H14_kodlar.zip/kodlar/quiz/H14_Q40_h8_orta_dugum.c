/* H14_Q40_h8_orta_dugum.c — AP-2 Hafta 14 · Final hazırlık (H8) · Değişmez
 * Amaç    : Yavaş–hızlı işaretçiyle ortadaki düğüm. Döngünün her
 *           yinelemesinin BAŞINDA (ve çıkışta) dört aday ifade; 1..30
 *           düğümlü listelerde ihlaller sayılır. indis(p) = p'nin sırası
 *           (0'dan); hızlı NULL olunca indisi n sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q40_h8_orta_dugum.c
 *           -o H14_Q40_h8_orta_dugum
 * Çalıştır: ./H14_Q40_h8_orta_dugum
 */
#include <stdio.h>

typedef struct Dugum {
    int indis;
    struct Dugum *sonraki;
} Dugum;

int main(void)
{
    Dugum d[30];
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0, dogru = 0;
    for (int n = 1; n <= 30; n++) {
        for (int i = 0; i < n; i++) {
            d[i].indis = i;
            d[i].sonraki = i + 1 < n ? &d[i + 1] : NULL;
        }
        Dugum *yavas = &d[0], *hizli = &d[0];
        for (;;) {
            int h = hizli != NULL ? hizli->indis : n;   /* NULL = n. konum */
            sinama++;
            ihlal[0] += !(h == 2 * yavas->indis);                  /* A */
            ihlal[1] += !(hizli != NULL && hizli->sonraki == NULL); /* B */
            ihlal[2] += !(yavas->indis == n / 2);                  /* C */
            ihlal[3] += !(h - yavas->indis == 1);                  /* D */
            if (!(hizli != NULL && hizli->sonraki != NULL)) {
                break;
            }
            yavas = yavas->sonraki;
            hizli = hizli->sonraki->sonraki;
        }
        dogru += yavas->indis == n / 2;
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    printf("orta = n/2 (çiftte ikinci orta): %lld / 30\n", dogru);
    return 0;
}

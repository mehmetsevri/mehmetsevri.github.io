/* H14_Q11_h3_bit_say.c — AP-2 Hafta 14 · Final hazırlık (H3) · İzleme
 * Amaç    : f(n) = f(n / 2) + n % 2 özyinelemesi: dönüş değeri ve çağrı
 *           sayısı (ilk çağrı dahil).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q11_h3_bit_say.c
 *           -o H14_Q11_h3_bit_say
 * Çalıştır: ./H14_Q11_h3_bit_say
 */
#include <stdio.h>

static int cagri = 0;

static int f(int n)
{
    cagri++;
    if (n <= 1) {
        return n;
    }
    return f(n / 2) + n % 2;
}

int main(void)
{
    int s = f(13);
    printf("f(13) = %d, çağrı = %d\n", s, cagri);
    return 0;
}

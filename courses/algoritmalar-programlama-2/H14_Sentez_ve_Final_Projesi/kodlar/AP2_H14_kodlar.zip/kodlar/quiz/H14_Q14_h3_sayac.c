/* H14_Q14_h3_sayac.c — AP-2 Hafta 14 · Final hazırlık (H3) · Diller arası
 * Amaç    : Global sayaçla özyinelemeli fib(5): değer ve çağrı sayısı.
 *           Python eşi: H14_Q14_h3_sayac.py
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q14_h3_sayac.c
 *           -o H14_Q14_h3_sayac
 * Çalıştır: ./H14_Q14_h3_sayac
 */
#include <stdio.h>

static int sayac = 0;

static int fib(int n)
{
    sayac += 1;
    if (n <= 1) {
        return n;
    }
    return fib(n - 1) + fib(n - 2);
}

int main(void)
{
    int f = fib(5);
    printf("%d %d\n", f, sayac);
    return 0;
}

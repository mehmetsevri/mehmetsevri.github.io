/* H14_Q37_h8_liste_sil.c — AP-2 Hafta 14 · Final hazırlık (H8) · Hata bulma
 * Amaç    : Tek bağlı listede değere göre ilk düğümü silen, BAŞ düğümü özel
 *           ele almayan fonksiyon. [3 -> 1 -> 4] listesinin kopyalarında dört
 *           silme denenir; liste her seferinde yeniden kurulur ve bırakılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q37_h8_liste_sil.c
 *           -o H14_Q37_h8_liste_sil
 * Çalıştır: ./H14_Q37_h8_liste_sil
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int deger;
    struct Dugum *sonraki;
} Dugum;

/* HATALI: yalnız bas->sonraki'den itibaren arar; 1 = silindi */
static int sil(Dugum *bas, int x)
{
    Dugum *p = bas;
    while (p != NULL && p->sonraki != NULL && p->sonraki->deger != x) {
        p = p->sonraki;
    }
    if (p == NULL || p->sonraki == NULL) {
        return 0;
    }
    Dugum *s = p->sonraki;
    p->sonraki = s->sonraki;
    free(s);
    return 1;
}

static Dugum *kur(const int *a, int n)
{
    Dugum *bas = NULL;
    for (int i = n - 1; i >= 0; i--) {
        Dugum *d = malloc(sizeof *d);
        if (d == NULL) {
            exit(1);
        }
        d->deger = a[i];
        d->sonraki = bas;
        bas = d;
    }
    return bas;
}

static void yaz_birak(Dugum *bas)
{
    printf("[");
    while (bas != NULL) {
        Dugum *s = bas->sonraki;
        printf("%d%s", bas->deger, s != NULL ? " -> " : "");
        free(bas);
        bas = s;
    }
    printf("]");
}

int main(void)
{
    const int a[3] = {3, 1, 4}, b[2] = {3, 1};
    struct {
        const int *v;
        int n, x;
    } g[4] = {{a, 3, 3}, {a, 3, 4}, {a, 3, 9}, {b, 2, 1}};
    for (int t = 0; t < 4; t++) {
        Dugum *bas = kur(g[t].v, g[t].n);
        int s = sil(bas, g[t].x);
        printf("x = %d: sil = %d, liste ", g[t].x, s);
        yaz_birak(bas);
        int beklenen = 0;
        for (int i = 0; i < g[t].n; i++) {
            beklenen = beklenen || g[t].v[i] == g[t].x;
        }
        printf(" %s\n", s == beklenen ? "doğru" : "YANLIŞ");
    }
    return 0;
}

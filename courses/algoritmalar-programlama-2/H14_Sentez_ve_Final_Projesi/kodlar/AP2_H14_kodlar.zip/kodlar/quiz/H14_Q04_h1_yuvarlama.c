/* H14_Q04_h1_yuvarlama.c — AP-2 Hafta 14 · Final hazırlık (H1) · Diller arası
 * Amaç    : C'nin round() fonksiyonu yarımları SIFIRDAN UZAĞA yuvarlar.
 *           Python eşi: H14_Q04_h1_yuvarlama.py (round yarımları ÇİFTE).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q04_h1_yuvarlama.c
 *           -o H14_Q04_h1_yuvarlama -lm
 * Çalıştır: ./H14_Q04_h1_yuvarlama
 */
#include <math.h>
#include <stdio.h>

int main(void)
{
    printf("%.0f %.0f %.0f\n", round(2.5), round(3.5), round(-2.5));
    return 0;
}

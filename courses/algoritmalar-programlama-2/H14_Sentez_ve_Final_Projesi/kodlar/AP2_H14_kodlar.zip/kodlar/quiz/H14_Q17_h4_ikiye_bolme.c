/* H14_Q17_h4_ikiye_bolme.c — AP-2 Hafta 14 · Final hazırlık (H4) · Hata bulma
 * Amaç    : x³ − x − 2 = 0'ın [1, 2]'deki kökü ikiye bölmeyle; döngü
 *           `while (hi - lo > eps)`. Dört eps değeri denenir; döngü
 *           güvenlik için 2000 yinelemede kesilir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q17_h4_ikiye_bolme.c
 *           -o H14_Q17_h4_ikiye_bolme
 * Çalıştır: ./H14_Q17_h4_ikiye_bolme
 */
#include <stdio.h>

static double f(double x)
{
    return x * x * x - x - 2.0;
}

int main(void)
{
    const double eps[4] = {1e-6, 1e-12, 1e-15, 1e-20};
    for (int k = 0; k < 4; k++) {
        double lo = 1.0, hi = 2.0;
        int y = 0;
        while (hi - lo > eps[k] && y < 2000) {
            double mid = lo + (hi - lo) / 2.0;
            if (f(mid) > 0.0) {
                hi = mid;
            } else {
                lo = mid;
            }
            y++;
        }
        if (y < 2000) {
            printf("eps = %.0e: %d yinelemede bitti, kök ≈ %.12f\n", eps[k],
                   y, lo);
        } else {
            printf("eps = %.0e: 2000 yinelemede BİTMEDİ (hi - lo = %.3e "
                   "değişmiyor)\n", eps[k], hi - lo);
        }
    }
    return 0;
}

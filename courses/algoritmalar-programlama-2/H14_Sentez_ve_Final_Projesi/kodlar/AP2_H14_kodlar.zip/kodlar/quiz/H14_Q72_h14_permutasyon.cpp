/* H14_Q72_h14_permutasyon.cpp — AP-2 Hafta 14 · Final hazırlık (H14) ·
 *                                Diller arası
 * Amaç    : do { ... } while (std::next_permutation(...)) döngüsü verilen
 *           diziden başlar ve sözlük sırasında SONUNCUYA varınca durur;
 *           sıralı başlamazsa bütün permütasyonları üretmez.
 *           Python eşi: H14_Q72_h14_permutasyon.py
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q72_h14_permutasyon.cpp -o H14_Q72_h14_permutasyon
 * Çalıştır: ./H14_Q72_h14_permutasyon
 */
#include <algorithm>
#include <iostream>
#include <vector>

int main()
{
    std::vector<int> v = {2, 1, 3};
    std::vector<std::vector<int>> p;
    do {
        p.push_back(v);
    } while (std::next_permutation(v.begin(), v.end()));
    std::cout << p.size();
    for (const auto& t : p) {
        std::cout << ' ' << t[0] << t[1] << t[2];
    }
    std::cout << '\n';
    return 0;
}

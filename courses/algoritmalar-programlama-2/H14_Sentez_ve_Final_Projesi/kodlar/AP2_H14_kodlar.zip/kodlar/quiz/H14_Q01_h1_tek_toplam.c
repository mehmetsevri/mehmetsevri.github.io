/* H14_Q01_h1_tek_toplam.c — AP-2 Hafta 14 · Final hazırlık (H1) · İzleme ve
 *                           değişmez
 * Amaç    : Tek sayıların toplamıyla tamsayı karekök: 1 + 3 + 5 + ... = i².
 *           (1) kok(30) izlemesi; (2) dört aday ifade, döngü koşulunun HER
 *           sınanışında (son, yanlış çıkan sınama dahil) denetlenir ve kaç
 *           kez yanlış oldukları sayılır (n = 0..2000).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q01_h1_tek_toplam.c
 *           -o H14_Q01_h1_tek_toplam
 * Çalıştır: ./H14_Q01_h1_tek_toplam
 */
#include <stdio.h>

/* ön koşul: n >= 0; son koşul: dönüş = ⌊√n⌋ */
static int kok(int n, int *s_son, int *yineleme)
{
    int s = 0, i = 0;
    *yineleme = 0;
    while (s + 2 * i + 1 <= n) {
        s += 2 * i + 1;
        i++;
        (*yineleme)++;
    }
    *s_son = s;
    return i;
}

int main(void)
{
    int s, y;
    int k = kok(30, &s, &y);
    printf("kok(30) = %d, s = %d, yineleme = %d\n", k, s, y);
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0, dogru = 0;
    for (int n = 0; n <= 2000; n++) {
        int si = 0, i = 0;
        for (;;) {                       /* her koşul sınanışında */
            sinama++;
            ihlal[0] += !(si == i * i && si <= n);        /* A */
            ihlal[1] += !(si == i * i && si < n);         /* B */
            ihlal[2] += !(si == 2 * i + 1);               /* C */
            ihlal[3] += !((i + 1) * (i + 1) <= n);        /* D */
            if (!(si + 2 * i + 1 <= n)) {
                break;
            }
            si += 2 * i + 1;
            i++;
        }
        dogru += i * i <= n && (i + 1) * (i + 1) > n;
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    printf("kok(n) = ⌊√n⌋ doğru: %lld / 2001\n", dogru);
    return 0;
}

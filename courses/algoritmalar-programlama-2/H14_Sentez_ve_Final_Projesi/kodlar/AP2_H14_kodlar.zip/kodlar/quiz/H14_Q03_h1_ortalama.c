/* H14_Q03_h1_ortalama.c — AP-2 Hafta 14 · Final hazırlık (H1) · Hata bulma
 * Amaç    : int toplamı int n'e bölen "ortalama" fonksiyonu. Dört girdide
 *           sonucu, double ile hesaplanan doğru değerle karşılaştırır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q03_h1_ortalama.c
 *           -o H14_Q03_h1_ortalama
 * Çalıştır: ./H14_Q03_h1_ortalama
 */
#include <stdio.h>

static double ortalama(const int *a, int n)          /* HATALI */
{
    int t = 0;
    for (int i = 0; i < n; i++) {
        t += a[i];
    }
    return t / n;
}

static double dogru_ortalama(const int *a, int n)
{
    int t = 0;
    for (int i = 0; i < n; i++) {
        t += a[i];
    }
    return (double)t / n;
}

int main(void)
{
    const int g1[] = {1, 2}, g2[] = {2, 4}, g3[] = {3, 3, 3}, g4[] = {7};
    const int *g[4] = {g1, g2, g3, g4};
    const int n[4] = {2, 2, 3, 1};
    const char *ad[4] = {"{1, 2}", "{2, 4}", "{3, 3, 3}", "{7}"};
    for (int k = 0; k < 4; k++) {
        double o = ortalama(g[k], n[k]), d = dogru_ortalama(g[k], n[k]);
        printf("%-10s -> %.2f (doğrusu %.2f) %s\n", ad[k], o, d,
               o == d ? "aynı" : "YANLIŞ");
    }
    return 0;
}

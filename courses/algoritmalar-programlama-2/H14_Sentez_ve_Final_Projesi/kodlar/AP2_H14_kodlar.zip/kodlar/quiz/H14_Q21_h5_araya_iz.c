/* H14_Q21_h5_araya_iz.c — AP-2 Hafta 14 · Final hazırlık (H5) · İzleme
 * Amaç    : [5 2 9 1 6 3] dizisinde araya eklemenin her dış yinelemesinden
 *           sonraki durum; karşılaştırma için seçmeli ve kabarcık
 *           sıralamasının ilk üç geçişi.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q21_h5_araya_iz.c
 *           -o H14_Q21_h5_araya_iz
 * Çalıştır: ./H14_Q21_h5_araya_iz
 */
#include <stdio.h>
#include <string.h>

#define N 6

static void yaz(const char *ad, int k, const int *a)
{
    printf("%-8s %d:", ad, k);
    for (int i = 0; i < N; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

int main(void)
{
    const int g[N] = {5, 2, 9, 1, 6, 3};
    int a[N];
    memcpy(a, g, sizeof a);
    for (int i = 1; i < N; i++) {                         /* araya ekleme */
        int x = a[i], j = i - 1;
        while (j >= 0 && a[j] > x) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
        yaz("araya", i, a);
    }
    memcpy(a, g, sizeof a);
    for (int i = 0; i < 3; i++) {                         /* seçmeli */
        int en = i;
        for (int j = i + 1; j < N; j++) {
            en = a[j] < a[en] ? j : en;
        }
        int t = a[i];
        a[i] = a[en];
        a[en] = t;
        yaz("seçmeli", i + 1, a);
    }
    memcpy(a, g, sizeof a);
    for (int g2 = 0; g2 < 3; g2++) {                      /* kabarcık */
        for (int j = 0; j + 1 < N - g2; j++) {
            if (a[j] > a[j + 1]) {
                int t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
        yaz("kabarcık", g2 + 1, a);
    }
    return 0;
}

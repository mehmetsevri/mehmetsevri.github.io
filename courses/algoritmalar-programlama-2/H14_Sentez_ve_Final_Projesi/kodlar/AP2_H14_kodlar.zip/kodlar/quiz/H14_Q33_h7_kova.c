/* H14_Q33_h7_kova.c — AP-2 Hafta 14 · Final hazırlık (H7) · Hata bulma
 * Amaç    : Kova sıralamasında kova indisi k = (int)(x * K), K = 10. Kod
 *           [0, 1) varsayar; program dört girdinin indislerini HESAPLAR ve
 *           K'ye ulaşanı (dizi dışı yazma olurdu) yazmadan bildirir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q33_h7_kova.c
 *           -o H14_Q33_h7_kova
 * Çalıştır: ./H14_Q33_h7_kova
 */
#include <stdio.h>

#define K 10

int main(void)
{
    const double g[4][3] = {{0.25, 1.0, 0.5}, {0.0, 0.5, 0.75},
                            {0.1, 0.1, 0.1}, {0.999, 0.001, 0.5}};
    const char *ad[4] = {"{0.25, 1.0, 0.5}", "{0.0, 0.5, 0.75}",
                         "{0.1, 0.1, 0.1}", "{0.999, 0.001, 0.5}"};
    for (int t = 0; t < 4; t++) {
        printf("%-20s kova:", ad[t]);
        int tasan = 0;
        for (int i = 0; i < 3; i++) {
            int k = (int)(g[t][i] * K);
            printf(" %d", k);
            tasan = tasan || k >= K;
        }
        printf(" %s\n", tasan ? "-> indis K = 10: DİZİ DIŞI" : "-> geçerli");
    }
    return 0;
}

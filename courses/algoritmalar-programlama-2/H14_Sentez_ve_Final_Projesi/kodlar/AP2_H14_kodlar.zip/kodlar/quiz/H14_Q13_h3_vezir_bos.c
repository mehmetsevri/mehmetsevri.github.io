/* H14_Q13_h3_vezir_bos.c — AP-2 Hafta 14 · Final hazırlık (H3) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: N-vezir geri izlemesinde sut[r],
 * r. satırdaki vezirin sütunudur. (satir, c) karesi, önceki satırlardaki
 * bir vezirle aynı sütunda ya da aynı köşegende ise güvenli DEĞİLDİR.
 * Sınama: N = 4..8 için çözüm sayıları (2 10 4 40 92 olmalı).
 */
#include <stdio.h>
#include <stdlib.h>

static int sut[16];

static int guvenli(int satir, int c)
{
    for (int r = 0; r < satir; r++) {
        ________;
    }
    return 1;
}

static long long coz(int satir, int n)
{
    if (satir == n) {
        return 1;
    }
    long long s = 0;
    for (int c = 0; c < n; c++) {
        if (guvenli(satir, c)) {
            sut[satir] = c;
            s += coz(satir + 1, n);
        }
    }
    return s;
}

int main(void)
{
    for (int n = 4; n <= 8; n++) {
        printf("%lld%s", coz(0, n), n < 8 ? " " : "\n");
    }
    return 0;
}

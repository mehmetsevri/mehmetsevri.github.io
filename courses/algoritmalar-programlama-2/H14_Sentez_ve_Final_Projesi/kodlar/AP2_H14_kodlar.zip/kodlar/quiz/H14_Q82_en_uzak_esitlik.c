/* H14_Q82_en_uzak_esitlik.c — AP-2 Hafta 14 · Haftalık quiz (diller arası)
 * Amaç    : Şehir 0'a EN UZAK şehri seçerken eşitlik kuralı. Kare
 *           uzaklıklar d2[] içinde iki şehir aynı en büyük değere sahip;
 *           C döngüsü ">=" ile seçer. Python eşi: H14_Q82_en_uzak_esitlik.py
 *           (max(..., key=...)).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q82_en_uzak_esitlik.c -o H14_Q82_en_uzak_esitlik
 */
#include <stdio.h>

int main(void)
{
    const int d2[5] = {0, 25, 41, 41, 9};
    int sec = 1;
    for (int j = 1; j < 5; j++) {
        if (d2[j] >= d2[sec]) {
            sec = j;
        }
    }
    printf("C: en uzak şehir %d (d² = %d)\n", sec, d2[sec]);
    return 0;
}

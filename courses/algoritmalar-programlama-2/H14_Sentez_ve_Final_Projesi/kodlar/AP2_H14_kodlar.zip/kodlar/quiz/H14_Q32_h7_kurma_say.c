/* H14_Q32_h7_kurma_say.c — AP-2 Hafta 14 · Final hazırlık (H7) · Karmaşıklık
 * Amaç    : Aşağıdan yukarıya öbek kurmada (en büyük öbek) anahtar
 *           karşılaştırması sayısı; artan sıralı girdi (her düğüm en
 *           derine iner: en kötü durum).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q32_h7_kurma_say.c
 *           -o H14_Q32_h7_kurma_say -lm
 * Çalıştır: ./H14_Q32_h7_kurma_say
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static long long kars;

static void asagi_suz(int *a, int n, int i)
{
    for (;;) {
        int b = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < n) {
            kars++;
            b = a[s] > a[b] ? s : b;
        }
        if (r < n) {
            kars++;
            b = a[r] > a[b] ? r : b;
        }
        if (b == i) {
            return;
        }
        int t = a[i];
        a[i] = a[b];
        a[b] = t;
        i = b;
    }
}

int main(void)
{
    const int boy[4] = {1000, 10000, 100000, 1000000};
    int *a = malloc(1000000 * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (int k = 0; k < 4; k++) {
        int n = boy[k];
        for (int i = 0; i < n; i++) {
            a[i] = i;
        }
        kars = 0;
        for (int i = n / 2 - 1; i >= 0; i--) {
            asagi_suz(a, n, i);
        }
        printf("n = %7d: karşılaştırma = %8lld, /n = %.3f, "
               "/(n log2 n) = %.3f\n", n, kars, (double)kars / n,
               (double)kars / (n * log2((double)n)));
    }
    free(a);
    return 0;
}

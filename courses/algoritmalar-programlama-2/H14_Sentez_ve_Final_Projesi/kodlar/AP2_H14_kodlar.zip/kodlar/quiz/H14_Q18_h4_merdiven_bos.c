/* H14_Q18_h4_merdiven_bos.c — AP-2 Hafta 14 · Final hazırlık (H4) · Kod
 *                              tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: satırları ve sütunları artan sıralı
 * R × C matriste merdiven araması sağ üst köşeden başlar. Boş satır,
 * m[i][j] != x iken bir adım atar.
 * Sınama: 100 rastgele matriste bulunan ve bulunmayan değerler.
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define R 5
#define C 6

static int m[R][C];

static int ara(int x)
{
    int i = 0, j = C - 1;
    while (i < R && j >= 0) {
        if (m[i][j] == x) {
            return 1;
        }
        ________;
    }
    return 0;
}

int main(void)
{
    long long dogru = 0, toplam = 0;
    rastgele_tohum(18);
    for (int d = 0; d < 100; d++) {
        for (int i = 0; i < R; i++) {
            for (int j = 0; j < C; j++) {
                int ust = i > 0 ? m[i - 1][j] : 0;
                int sol = j > 0 ? m[i][j - 1] : 0;
                m[i][j] = (ust > sol ? ust : sol) + rastgele_aralik(1, 3);
            }
        }
        for (int x = 0; x <= m[R - 1][C - 1] + 1; x++) {
            int var = 0;
            for (int i = 0; i < R; i++) {
                for (int j = 0; j < C; j++) {
                    var = var || m[i][j] == x;
                }
            }
            toplam++;
            dogru += ara(x) == var;
        }
    }
    printf("doğru %lld / %lld\n", dogru, toplam);
    return 0;
}

/* H14_Q52_h11_bfs_bos.c — AP-2 Hafta 14 · Final hazırlık (H11) · Kod
 *                          tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: BFS'de keşfedilen komşu v için
 * yapılacaklar (ziyaret işareti KUYRUĞA EKLERKEN konur).
 * Sınama: iki grafta ziyaret sırası ve kuyruğa ekleme sayısı.
 */
#include <stdio.h>

#define V 6

static int g[V][V];

static void bfs(int kaynak)
{
    int q[V * V], bas = 0, son = 0, ziyaret[V] = {0};
    ziyaret[kaynak] = 1;
    q[son++] = kaynak;
    printf("sıra:");
    while (bas < son) {
        int u = q[bas++];
        printf(" %d", u);
        for (int v = 0; v < V; v++) {
            if (g[u][v] && !ziyaret[v]) {
                ________;
            }
        }
    }
    printf(" (kuyruğa ekleme = %d)\n", son);
}

int main(void)
{
    const int e1[6][2] = {{0, 1}, {0, 2}, {1, 3}, {2, 3}, {3, 4}, {2, 5}};
    const int e2[7][2] = {{0, 1}, {0, 2}, {0, 3}, {1, 4}, {2, 4}, {3, 4},
                          {4, 5}};
    for (int i = 0; i < 6; i++) {
        g[e1[i][0]][e1[i][1]] = g[e1[i][1]][e1[i][0]] = 1;
    }
    bfs(0);
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            g[i][j] = 0;
        }
    }
    for (int i = 0; i < 7; i++) {
        g[e2[i][0]][e2[i][1]] = g[e2[i][1]][e2[i][0]] = 1;
    }
    bfs(0);
    return 0;
}

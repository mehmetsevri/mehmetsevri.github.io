/* H14_Q70_h14_nn_bos.c — AP-2 Hafta 14 · Final hazırlık (H14) · Kod
 *                         tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: en yakın komşu sezgiselinde son
 * şehirden henüz gidilmemiş EN YAKIN şehir seçilir; eşitlikte küçük
 * indisli şehir (dersin belirleyicilik kuralı). Karşılaştırma tamsayı d².
 * Sınama: Örnek 2'nin 5 şehri ve eşit uzaklıklı bir kare.
 */
#include <stdio.h>

#define MAKS 8

static int n, x[MAKS], y[MAKS];

static long long d2(int i, int j)
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static void nn(void)
{
    int gidildi[MAKS] = {0}, son = 0;
    gidildi[0] = 1;
    printf("0");
    for (int k = 1; k < n; k++) {
        int en = -1;
        for (int j = 0; j < n; j++) {
            ________;
        }
        gidildi[en] = 1;
        son = en;
        printf("-%d", en);
    }
    printf("-0\n");
}

int main(void)
{
    const int ax[5] = {0, 6, 1, 5, 3}, ay[5] = {0, 1, 4, 5, 2};
    const int bx[4] = {0, 2, 0, 2}, by[4] = {0, 0, 2, 2};
    n = 5;
    for (int i = 0; i < n; i++) {
        x[i] = ax[i];
        y[i] = ay[i];
    }
    nn();
    n = 4;
    for (int i = 0; i < n; i++) {
        x[i] = bx[i];
        y[i] = by[i];
    }
    nn();
    return 0;
}

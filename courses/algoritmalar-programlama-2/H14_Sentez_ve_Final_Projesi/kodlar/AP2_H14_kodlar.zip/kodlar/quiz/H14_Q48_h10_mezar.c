/* H14_Q48_h10_mezar.c — AP-2 Hafta 14 · Final hazırlık (H10) · Değişmez
 * Amaç    : Doğrusal yoklamalı tablo (m = 16, mezar taşıyla silme). Her
 *           ekle/sil işleminden SONRA dört aday ifade sınanır; 3000 rastgele
 *           işlemde ihlaller sayılır. Hücre: BOS, MEZAR ya da anahtar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q48_h10_mezar.c
 *           ../c/ortak_rastgele.c -o H14_Q48_h10_mezar
 * Çalıştır: ./H14_Q48_h10_mezar
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define M 16
#define BOS (-1)
#define MEZAR (-2)

static int t[M];

static int h(int k)
{
    return (k * 7) % M;
}

static int bul(int k)
{
    for (int i = 0, p = h(k); i < M && t[p] != BOS; i++, p = (p + 1) % M) {
        if (t[p] == k) {
            return p;
        }
    }
    return -1;
}

int main(void)
{
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0;
    for (int i = 0; i < M; i++) {
        t[i] = BOS;
    }
    rastgele_tohum(48);
    int adet = 0;
    for (int d = 0; d < 3000; d++) {
        int k = rastgele_aralik(0, 40);
        if (rastgele_aralik(0, 2) > 0 && adet < 12 && bul(k) < 0) {
            int p = h(k);
            while (t[p] >= 0) {                 /* boş ya da mezara yaz */
                p = (p + 1) % M;
            }
            t[p] = k;
            adet++;
        } else if (bul(k) >= 0) {
            t[bul(k)] = MEZAR;
            adet--;
        }
        int A = 1, B = 1, C = 1, D = 1, onceki = -1, kume = 0;
        for (int p = 0; p < M; p++) {
            if (t[p] < 0) {
                continue;
            }
            for (int q = h(t[p]); q != p; q = (q + 1) % M) {
                A = A && t[q] != BOS;       /* h(k)..konum: BOŞ yok */
            }
            B = B && h(t[p]) == p;          /* her anahtar kendi evinde */
            D = D && t[p] > onceki;         /* anahtarlar artan */
            onceki = t[p];
        }
        for (int p = 0; p < M; p++) {       /* dolu bölgelerin sayısı */
            kume += t[p] >= 0 && t[(p + M - 1) % M] < 0;
        }
        C = kume <= 1;
        sinama++;
        ihlal[0] += !A;
        ihlal[1] += !B;
        ihlal[2] += !C;
        ihlal[3] += !D;
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

"""H14_Q44_h9_pop.py — AP-2 Hafta 14 · Final hazırlık (H9) · Diller arası
Amaç    : list.pop() tepedeki öğeyi hem çıkarır hem DÖNDÜRÜR. C++ eşi:
          H14_Q44_h9_pop_bos.cpp (std::stack::pop() void döndürür)
Çalıştır: python3 H14_Q44_h9_pop.py
"""


def main():
    yigin = [3, 1, 4]
    x = yigin.pop()
    print(x, yigin)


if __name__ == "__main__":
    main()

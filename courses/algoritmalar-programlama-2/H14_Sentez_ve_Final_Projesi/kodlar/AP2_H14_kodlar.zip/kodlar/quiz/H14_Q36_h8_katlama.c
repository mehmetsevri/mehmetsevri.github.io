/* H14_Q36_h8_katlama.c — AP-2 Hafta 14 · Final hazırlık (H8) · Karmaşıklık
 * Amaç    : Dinamik diziye n = 2^20 ekleme; kapasite 1'den başlar. Dolunca
 *           (a) ikiye katlanır, (b) 10 artırılır. Taşınan (kopyalanan) öğe
 *           sayısı hesaplanır (bellek ayrılmaz; yalnız sayılır).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q36_h8_katlama.c
 *           -o H14_Q36_h8_katlama
 * Çalıştır: ./H14_Q36_h8_katlama
 */
#include <stdio.h>

int main(void)
{
    const long long n = 1048576;
    for (int s = 0; s < 2; s++) {
        long long kap = 1, boy = 0, kopya = 0, buyume = 0;
        for (long long i = 0; i < n; i++) {
            if (boy == kap) {
                kopya += boy;                 /* eski öğeler taşınır */
                kap = s == 0 ? kap * 2 : kap + 10;
                buyume++;
            }
            boy++;
        }
        printf("%s kopya = %12lld, büyütme = %6lld, ekleme başına "
               "%.2f kopya\n", s == 0 ? "× 2 :" : "+ 10:", kopya, buyume,
               (double)kopya / (double)n);
    }
    return 0;
}

/* H14_Q57_h12_dijkstra_iz.c — AP-2 Hafta 14 · Final hazırlık (H12) · İzleme
 * Amaç    : Yönsüz ağırlıklı graf 0-1 (4), 0-2 (1), 2-1 (2), 1-3 (1),
 *           2-3 (5), 3-4 (3); 0'dan dizi tabanlı Dijkstra. Kesinleşme sırası
 *           ve uzaklıklar (eşitlikte küçük numaralı köşe).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q57_h12_dijkstra_iz.c
 *           -o H14_Q57_h12_dijkstra_iz
 * Çalıştır: ./H14_Q57_h12_dijkstra_iz
 */
#include <limits.h>
#include <stdio.h>

#define V 5

int main(void)
{
    int w[V][V] = {{0}};
    const int e[6][3] = {{0, 1, 4}, {0, 2, 1}, {2, 1, 2}, {1, 3, 1},
                         {2, 3, 5}, {3, 4, 3}};
    for (int i = 0; i < 6; i++) {
        w[e[i][0]][e[i][1]] = w[e[i][1]][e[i][0]] = e[i][2];
    }
    int d[V], kesin[V] = {0};
    for (int i = 0; i < V; i++) {
        d[i] = INT_MAX;
    }
    d[0] = 0;
    printf("kesinleşme:");
    for (int k = 0; k < V; k++) {
        int u = -1;
        for (int i = 0; i < V; i++) {
            if (!kesin[i] && d[i] != INT_MAX && (u < 0 || d[i] < d[u])) {
                u = i;
            }
        }
        if (u < 0) {
            break;
        }
        kesin[u] = 1;
        printf(" %d(%d)", u, d[u]);
        for (int v = 0; v < V; v++) {
            if (w[u][v] > 0 && !kesin[v] && d[u] + w[u][v] < d[v]) {
                d[v] = d[u] + w[u][v];
            }
        }
    }
    printf("\nd[4] = %d\n", d[4]);
    return 0;
}

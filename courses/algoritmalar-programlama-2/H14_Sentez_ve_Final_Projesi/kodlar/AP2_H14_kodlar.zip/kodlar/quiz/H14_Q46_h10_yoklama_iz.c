/* H14_Q46_h10_yoklama_iz.c — AP-2 Hafta 14 · Final hazırlık (H10) · İzleme
 * Amaç    : m = 10, h(k) = k mod 10, doğrusal yoklama; 12, 22, 5, 32, 15
 *           sırayla eklenir. Son tablo ve anahtar başına yoklama (dolu ya da
 *           boş, bakılan her hücre bir yoklama).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q46_h10_yoklama_iz.c
 *           -o H14_Q46_h10_yoklama_iz
 * Çalıştır: ./H14_Q46_h10_yoklama_iz
 */
#include <stdio.h>

#define M 10

int main(void)
{
    int t[M], toplam = 0;
    const int k[5] = {12, 22, 5, 32, 15};
    for (int i = 0; i < M; i++) {
        t[i] = -1;
    }
    for (int i = 0; i < 5; i++) {
        int h = k[i] % M, y = 1;
        while (t[h] != -1) {
            h = (h + 1) % M;
            y++;
        }
        t[h] = k[i];
        toplam += y;
        printf("%2d -> hücre %d (%d yoklama)\n", k[i], h, y);
    }
    printf("tablo: [");
    for (int i = 0; i < M; i++) {
        if (t[i] < 0) {
            printf("_%s", i + 1 < M ? " " : "");
        } else {
            printf("%d%s", t[i], i + 1 < M ? " " : "");
        }
    }
    printf("], toplam %d yoklama\n", toplam);
    return 0;
}

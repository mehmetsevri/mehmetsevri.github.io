/* H14_Q44_h9_pop_bos.cpp — AP-2 Hafta 14 · Final hazırlık (H9) · Diller arası
 * Tamamlanacak; bu hâliyle derlenmez: Python'daki `x = yigin.pop()`
 * satırının std::stack karşılığı (tepe değeri x'e alınmalı ve çıkarılmalı).
 * Beklenen çıktı Python eşininkiyle aynı: "4 [3, 1]".
 */
#include <iostream>
#include <stack>

int main()
{
    std::stack<int> y;
    y.push(3);
    y.push(1);
    y.push(4);
    int x = 0;
    ________;
    std::stack<int> ters;
    while (!y.empty()) {
        ters.push(y.top());
        y.pop();
    }
    std::cout << x << " [";
    bool ilk = true;
    while (!ters.empty()) {
        std::cout << (ilk ? "" : ", ") << ters.top();
        ilk = false;
        ters.pop();
    }
    std::cout << "]\n";
    return 0;
}

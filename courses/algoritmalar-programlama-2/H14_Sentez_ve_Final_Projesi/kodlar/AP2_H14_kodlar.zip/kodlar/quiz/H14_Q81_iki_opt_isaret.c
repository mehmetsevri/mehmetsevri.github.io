/* H14_Q81_iki_opt_isaret.c — AP-2 Hafta 14 · Haftalık quiz
 * BU DOSYA KASITLI HATA İÇERİR (koşul ters yazılmıştır).
 * Amaç    : İlk iyileştirmeli 2-opt'un kabul koşulu "kazanc > EPS" olarak
 *           yazılırsa ne olur? Örnek 3'ün en kötü örneği (#24, tohum 2026,
 *           n = 8): en yakın komşu turundan başlanır; hatalı ve doğru
 *           sürümlerin son uzunlukları ve hamle sayıları yazdırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q81_iki_opt_isaret.c -lm -o H14_Q81_iki_opt_isaret
 */
#include <math.h>
#include <stdio.h>

#define N 8
#define EPS 1e-9

static const int x[N] = {50, 79, 33, 10, 11, 42, 71, 7};
static const int y[N] = {6, 21, 11, 28, 94, 76, 55, 37};
static double d[N][N];

static double tur_uzunlugu(const int *tur)
{
    double t = 0.0;
    for (int k = 1; k < N; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t + d[tur[N - 1]][tur[0]];
}

static int iki_opt(int *tur, int hatali)
{
    int hamle = 0, degisti = 1;
    while (degisti) {
        degisti = 0;
        for (int i = 1; i < N - 1 && !degisti; i++) {
            for (int j = i + 1; j < N && !degisti; j++) {
                int a = tur[i - 1], b = tur[i], c = tur[j];
                int e = tur[(j + 1) % N];
                double kazanc = (d[a][c] + d[b][e]) - (d[a][b] + d[c][e]);
                if (hatali ? kazanc > EPS : kazanc < -EPS) {
                    for (int p = i, q = j; p < q; p++, q--) {
                        int g = tur[p];
                        tur[p] = tur[q];
                        tur[q] = g;
                    }
                    hamle++;
                    degisti = 1;
                }
            }
        }
    }
    return hamle;
}

int main(void)
{
    const int nn[N] = {0, 2, 3, 7, 5, 6, 1, 4};   /* Örnek 3'ün NN turu */
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            d[i][j] = sqrt((double)((x[i] - x[j]) * (x[i] - x[j]) +
                                    (y[i] - y[j]) * (y[i] - y[j])));
        }
    }
    for (int hatali = 1; hatali >= 0; hatali--) {
        int tur[N];
        for (int i = 0; i < N; i++) {
            tur[i] = nn[i];
        }
        int h = iki_opt(tur, hatali);
        printf("%s: %.2f -> %.2f (%d hamle)\n",
               hatali ? "kazanc > EPS (hatalı)" : "kazanc < -EPS (doğru) ",
               tur_uzunlugu(nn), tur_uzunlugu(tur), h);
    }
    return 0;
}

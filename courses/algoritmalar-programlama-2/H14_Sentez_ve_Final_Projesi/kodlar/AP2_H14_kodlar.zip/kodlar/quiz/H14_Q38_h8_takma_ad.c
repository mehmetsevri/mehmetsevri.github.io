/* H14_Q38_h8_takma_ad.c — AP-2 Hafta 14 · Final hazırlık (H8) · Diller arası
 * Amaç    : C'de yapı ataması (b = a) bütün alanları, gömülü diziyi de
 *           KOPYALAR; b'deki değişiklik a'yı etkilemez. İşaretçi ataması
 *           (p = &a) ise aynı nesneyi gösterir. Python eşi:
 *           H14_Q38_h8_takma_ad.py
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q38_h8_takma_ad.c
 *           -o H14_Q38_h8_takma_ad
 * Çalıştır: ./H14_Q38_h8_takma_ad
 */
#include <stdio.h>

typedef struct {
    int v[4];
    int n;
} Dizi;

int main(void)
{
    Dizi a = {{1, 2, 3, 0}, 3};
    Dizi b = a;                       /* kopya */
    b.v[b.n++] = 4;
    b.v[0] = 99;
    Dizi *p = &a;                     /* takma ad */
    printf("a: %d %d %d (n = %d); b: %d %d %d %d (n = %d); p == &a: %d\n",
           a.v[0], a.v[1], a.v[2], a.n, b.v[0], b.v[1], b.v[2], b.v[3], b.n,
           p == &a);
    return 0;
}

/* H14_Q08_h2_egim_bos.c — AP-2 Hafta 14 · Final hazırlık (H2) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: iki ölçümden (n1, t1), (n2, t2)
 * log–log eğimini (büyüme üssü kestirimi) döndüren ifadeyi yazın.
 * Sınama: t = n², t = n log n ve t = n³ için n = 1000 → 2000.
 */
#include <math.h>
#include <stdio.h>

static double egim(double n1, double t1, double n2, double t2)
{
    return ________;
}

int main(void)
{
    double n1 = 1000.0, n2 = 2000.0;
    printf("%.2f %.2f %.2f\n", egim(n1, n1 * n1, n2, n2 * n2),
           egim(n1, n1 * log(n1), n2, n2 * log(n2)),
           egim(n1, n1 * n1 * n1, n2, n2 * n2 * n2));
    return 0;
}

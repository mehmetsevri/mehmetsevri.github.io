/* H14_Q51_h11_bfs_iz.c — AP-2 Hafta 14 · Final hazırlık (H11) · İzleme
 * Amaç    : Yönsüz graf 0-1, 0-2, 1-3, 2-3, 3-4, 2-5 (komşular artan
 *           sırayla). 0'dan BFS ziyaret sırası ve uzaklıklar; karşılaştırma
 *           için özyinelemeli DFS ziyaret sırası.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q51_h11_bfs_iz.c
 *           -o H14_Q51_h11_bfs_iz
 * Çalıştır: ./H14_Q51_h11_bfs_iz
 */
#include <stdio.h>

#define V 6

static int g[V][V], ziyaret[V];

static void dfs(int u)
{
    ziyaret[u] = 1;
    printf(" %d", u);
    for (int v = 0; v < V; v++) {
        if (g[u][v] && !ziyaret[v]) {
            dfs(v);
        }
    }
}

int main(void)
{
    const int e[6][2] = {{0, 1}, {0, 2}, {1, 3}, {2, 3}, {3, 4}, {2, 5}};
    for (int i = 0; i < 6; i++) {
        g[e[i][0]][e[i][1]] = g[e[i][1]][e[i][0]] = 1;
    }
    int q[V], bas = 0, son = 0, d[V];
    for (int i = 0; i < V; i++) {
        d[i] = -1;
    }
    d[0] = 0;
    q[son++] = 0;
    printf("BFS:");
    while (bas < son) {
        int u = q[bas++];
        printf(" %d", u);
        for (int v = 0; v < V; v++) {
            if (g[u][v] && d[v] < 0) {
                d[v] = d[u] + 1;
                q[son++] = v;
            }
        }
    }
    printf("\nuzaklık:");
    for (int i = 0; i < V; i++) {
        printf(" %d:%d", i, d[i]);
    }
    printf("\nDFS:");
    dfs(0);
    printf("\n");
    return 0;
}

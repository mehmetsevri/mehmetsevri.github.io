/* H14_Q22_h5_kabarcik_degismez.c — AP-2 Hafta 14 · Final hazırlık (H5) ·
 *                                   Değişmez
 * Amaç    : Kabarcık sıralamasında p. geçişin BAŞINDA (p = 0, 1, ..., n − 1;
 *           p geçiş tamamlanmış) dört aday ifade; 1000 rastgele dizide
 *           ihlaller sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q22_h5_kabarcik_degismez.c ../c/ortak_rastgele.c \
 *           -o H14_Q22_h5_kabarcik_degismez
 * Çalıştır: ./H14_Q22_h5_kabarcik_degismez
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../c/ortak_rastgele.h"

static int artan(const void *x, const void *y)
{
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}

static int sirali(const int *a, int bas, int son)
{
    for (int i = bas + 1; i < son; i++) {
        if (a[i - 1] > a[i]) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int a[12], s[12];
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0;
    rastgele_tohum(22);
    for (int d = 0; d < 1000; d++) {
        int n = rastgele_aralik(1, 12);
        rastgele_dizi(a, (size_t)n, 0, 9);
        memcpy(s, a, sizeof a);
        qsort(s, (size_t)n, sizeof *s, artan);
        for (int p = 0; p < n; p++) {
            int ust = 1, alt = 1;
            long long ters = 0;
            for (int i = n - p; i < n; i++) {
                ust = ust && a[i] == s[i];         /* en büyük p, yerinde */
            }
            for (int i = 0; i < p; i++) {
                alt = alt && a[i] == s[i];         /* en küçük p, yerinde */
            }
            for (int i = 0; i < n; i++) {
                for (int j = i + 1; j < n; j++) {
                    ters += a[i] > a[j];
                }
            }
            sinama++;
            ihlal[0] += !ust;                       /* A */
            ihlal[1] += !sirali(a, 0, p);           /* B */
            ihlal[2] += !alt;                       /* C */
            ihlal[3] += !(ters <= n - p);           /* D */
            for (int j = 0; j + 1 < n - p; j++) {   /* p. geçiş */
                if (a[j] > a[j + 1]) {
                    int t = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = t;
                }
            }
        }
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

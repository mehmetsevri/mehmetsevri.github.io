/* H14_Q30_h6_lomuto_degismez.c — AP-2 Hafta 14 · Final hazırlık (H6) ·
 *                                 Değişmez
 * Amaç    : Lomuto bölümlemesi (pivot = a[hi], `a[j] < pivot` ise i++ ve
 *           takas). j döngüsünün her yinelemesinin BAŞINDA dört aday ifade;
 *           1000 rastgele dizide ihlaller sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q30_h6_lomuto_degismez.c ../c/ortak_rastgele.c \
 *           -o H14_Q30_h6_lomuto_degismez
 * Çalıştır: ./H14_Q30_h6_lomuto_degismez
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

static int bolge(const int *a, int bas, int son, int pivot, int kucuk)
{
    for (int k = bas; k <= son; k++) {
        if (kucuk ? !(a[k] < pivot) : !(a[k] >= pivot)) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int a[15];
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0;
    rastgele_tohum(30);
    for (int d = 0; d < 1000; d++) {
        int n = rastgele_aralik(2, 15), lo = 0, hi = n - 1;
        rastgele_dizi(a, (size_t)n, 0, 9);
        int pivot = a[hi], i = lo - 1;
        for (int j = lo; j < hi; j++) {
            int sirali = 1;
            for (int k = lo + 1; k < j; k++) {
                sirali = sirali && a[k - 1] <= a[k];
            }
            sinama++;
            ihlal[0] += !(bolge(a, lo, i, pivot, 1) &&
                          bolge(a, i + 1, j - 1, pivot, 0));      /* A */
            ihlal[1] += !(bolge(a, lo, i, pivot, 1) &&
                          bolge(a, i + 1, hi - 1, pivot, 0));     /* B */
            ihlal[2] += !sirali;                                  /* C */
            ihlal[3] += !(i == j - 1);                            /* D */
            if (a[j] < pivot) {
                i++;
                int t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
        }
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

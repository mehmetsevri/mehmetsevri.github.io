/* H14_Q69_h14_dogrulayici.c — AP-2 Hafta 14 · Final hazırlık (H14) · Hata
 *                              bulma
 * Amaç    : Alt küme toplamı sertifika doğrulayıcısı (Örnek 6). HATALI sürüm
 *           indislerin aralıkta olduğunu ve toplamı denetler ama AYNI
 *           indisin iki kez kullanılmasını denetlemez. a = {13, 7, 21, 4, 18,
 *           9}, T = 26 için dört sertifika.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q69_h14_dogrulayici.c -o H14_Q69_h14_dogrulayici
 * Çalıştır: ./H14_Q69_h14_dogrulayici
 */
#include <stdio.h>

#define N 6

static const int a[N] = {13, 7, 21, 4, 18, 9};

static int hatali(const int *s, int k, int T)
{
    int toplam = 0;
    for (int i = 0; i < k; i++) {
        if (s[i] < 0 || s[i] >= N) {
            return 0;
        }
        toplam += a[s[i]];
    }
    return toplam == T;
}

static int dogru(const int *s, int k, int T)
{
    int kul[N] = {0}, toplam = 0;
    for (int i = 0; i < k; i++) {
        if (s[i] < 0 || s[i] >= N || kul[s[i]]) {
            return 0;
        }
        kul[s[i]] = 1;
        toplam += a[s[i]];
    }
    return toplam == T;
}

int main(void)
{
    const int s1[2] = {0, 0}, s2[3] = {3, 5, 0}, s3[2] = {1, 4}, s4[1] = {6};
    const int *s[4] = {s1, s2, s3, s4};
    const int k[4] = {2, 3, 2, 1};
    const char *ad[4] = {"{0, 0}", "{3, 5, 0}", "{1, 4}", "{6}"};
    for (int t = 0; t < 4; t++) {
        int h = hatali(s[t], k[t], 26), d = dogru(s[t], k[t], 26);
        printf("%-10s hatalı: %-5s doğru: %-5s %s\n", ad[t],
               h ? "KABUL" : "RED", d ? "KABUL" : "RED",
               h == d ? "aynı" : "FARKLI");
    }
    return 0;
}

/* H14_Q26_h6_ana_teorem.c — AP-2 Hafta 14 · Final hazırlık (H6) · Karmaşıklık
 * Amaç    : T(n) = 3T(n/2) + n, T(1) = 1 bağıntısının iş sayacı: n ikiye
 *           katlanınca T kaç katına çıkar? log₂ 3 ≈ 1,585.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q26_h6_ana_teorem.c
 *           -o H14_Q26_h6_ana_teorem -lm
 * Çalıştır: ./H14_Q26_h6_ana_teorem
 */
#include <math.h>
#include <stdio.h>

static long long T(long long n)
{
    if (n <= 1) {
        return 1;
    }
    return 3 * T(n / 2) + n;
}

int main(void)
{
    long long onceki = T(512);
    for (long long n = 1024; n <= 1048576; n *= 4) {
        long long t = T(n), y = T(n / 2);
        printf("n = %7lld: T(n) = %12lld, T(n)/T(n/2) = %.4f\n", n, t,
               (double)t / (double)y);
        onceki = t;
    }
    printf("log2(3) = %.4f; T(n)/n^log2(3) = %.4f (n = 1048576)\n",
           log2(3.0), (double)onceki / pow(1048576.0, log2(3.0)));
    return 0;
}

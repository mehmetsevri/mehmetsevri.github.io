/* H14_Q24_h5_araya_j0.c — AP-2 Hafta 14 · Final hazırlık (H5) · Hata bulma
 * Amaç    : İç döngü koşulu `j > 0` olan (a[0] ile hiç karşılaştırmayan)
 *           araya ekleme. Dört girdide sonuç ve doğruluk.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q24_h5_araya_j0.c
 *           -o H14_Q24_h5_araya_j0
 * Çalıştır: ./H14_Q24_h5_araya_j0
 */
#include <stdio.h>

static void araya(int *a, int n)                      /* HATALI */
{
    for (int i = 1; i < n; i++) {
        int x = a[i], j = i - 1;
        while (j > 0 && a[j] > x) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}

int main(void)
{
    int g[4][4] = {{2, 3, 1}, {1, 3, 2}, {1, 2, 3}, {1, 4, 2, 3}};
    const int n[4] = {3, 3, 3, 4};
    for (int k = 0; k < 4; k++) {
        printf("[");
        for (int i = 0; i < n[k]; i++) {
            printf("%d%s", g[k][i], i + 1 < n[k] ? " " : "]");
        }
        araya(g[k], n[k]);
        int ok = 1;
        printf(" -> [");
        for (int i = 0; i < n[k]; i++) {
            printf("%d%s", g[k][i], i + 1 < n[k] ? " " : "]");
            ok = ok && (i == 0 || g[k][i - 1] <= g[k][i]);
        }
        printf(" %s\n", ok ? "sıralı" : "YANLIŞ");
    }
    return 0;
}

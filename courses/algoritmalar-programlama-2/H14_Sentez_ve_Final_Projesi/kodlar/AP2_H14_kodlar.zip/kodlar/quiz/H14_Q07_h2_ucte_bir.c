/* H14_Q07_h2_ucte_bir.c — AP-2 Hafta 14 · Final hazırlık (H2) · İzleme
 * Amaç    : i'yi her adımda 3'e bölen (tamsayı bölmesi) döngü kaç kez döner?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q07_h2_ucte_bir.c
 *           -o H14_Q07_h2_ucte_bir
 * Çalıştır: ./H14_Q07_h2_ucte_bir
 */
#include <stdio.h>

int main(void)
{
    int say = 0;
    printf("i:");
    for (int i = 100; i > 0; i /= 3) {
        printf(" %d", i);
        say++;
    }
    printf("\nsay = %d\n", say);
    return 0;
}

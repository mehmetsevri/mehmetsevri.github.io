/* H14_Q63_h13_ters_dongu_bos.c — AP-2 Hafta 14 · Final hazırlık (H13) · Kod
 *                                 tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: tek satırlı 0/1 sırt çantasında
 * (her nesne en çok bir kez) iç döngünün başlığı.
 * Sınama: 300 rastgele örnek, bütün alt kümeleri deneyen kâhine karşı.
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define WMAX 30

static int sirt(const int *ag, const int *de, int n, int W)
{
    int dp[WMAX + 1];
    for (int w = 0; w <= W; w++) {
        dp[w] = 0;
    }
    for (int i = 0; i < n; i++) {
        ________ {
            int aday = dp[w - ag[i]] + de[i];
            dp[w] = aday > dp[w] ? aday : dp[w];
        }
    }
    return dp[W];
}

int main(void)
{
    int ag[10], de[10];
    long long dogru = 0;
    rastgele_tohum(63);
    for (int t = 0; t < 300; t++) {
        int n = rastgele_aralik(1, 10), W = rastgele_aralik(1, WMAX), en = 0;
        for (int i = 0; i < n; i++) {
            ag[i] = rastgele_aralik(1, 10);
            de[i] = rastgele_aralik(1, 30);
        }
        for (int s = 0; s < (1 << n); s++) {
            int ta = 0, td = 0;
            for (int k = 0; k < n; k++) {
                if (s >> k & 1) {
                    ta += ag[k];
                    td += de[k];
                }
            }
            en = ta <= W && td > en ? td : en;
        }
        dogru += sirt(ag, de, n, W) == en;
    }
    printf("doğru %lld / 300\n", dogru);
    return 0;
}

"""H14_Q38_h8_takma_ad.py — AP-2 Hafta 14 · Final hazırlık (H8) · Diller arası
Amaç    : Python'da `b = a` yeni bir liste oluşturmaz: iki ad AYNI listeyi
          gösterir. C eşi: H14_Q38_h8_takma_ad.c (yapı ataması kopyalar)
Çalıştır: python3 H14_Q38_h8_takma_ad.py
"""


def main():
    a = [1, 2, 3]
    b = a
    b.append(4)
    b[0] = 99
    print(a, a is b)


if __name__ == "__main__":
    main()

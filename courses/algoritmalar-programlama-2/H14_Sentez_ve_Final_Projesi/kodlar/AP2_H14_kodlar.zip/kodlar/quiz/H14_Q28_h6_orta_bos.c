/* H14_Q28_h6_orta_bos.c — AP-2 Hafta 14 · Final hazırlık (H6) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: kapalı aralıklı [lo, hi]
 * birleştirmeli sıralamada orta nokta. Sol yarı [lo, mid], sağ yarı
 * [mid + 1, hi]; her iki yarı da boş olmamalı.
 * Sınama: 200 rastgele dizi sıralanmalı.
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

static int tampon[64];

static void birlestirmeli(int *a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = ________;
    birlestirmeli(a, lo, mid);
    birlestirmeli(a, mid + 1, hi);
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        tampon[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i <= mid) {
        tampon[k++] = a[i++];
    }
    while (j <= hi) {
        tampon[k++] = a[j++];
    }
    for (k = lo; k <= hi; k++) {
        a[k] = tampon[k];
    }
}

int main(void)
{
    int a[64];
    long long dogru = 0;
    rastgele_tohum(28);
    for (int d = 0; d < 200; d++) {
        int n = rastgele_aralik(1, 64), ok = 1;
        rastgele_dizi(a, (size_t)n, 0, 99);
        birlestirmeli(a, 0, n - 1);
        for (int i = 1; i < n; i++) {
            ok = ok && a[i - 1] <= a[i];
        }
        dogru += ok;
    }
    printf("doğru %lld / 200\n", dogru);
    return 0;
}

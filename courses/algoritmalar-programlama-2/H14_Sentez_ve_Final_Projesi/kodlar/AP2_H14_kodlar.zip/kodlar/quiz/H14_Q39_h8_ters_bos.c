/* H14_Q39_h8_ters_bos.c — AP-2 Hafta 14 · Final hazırlık (H8) · Parsons
 * Tamamlanacak; bu hâliyle derlenmez: tek bağlı listeyi yinelemeli ters
 * çeviren döngünün gövdesi (dört satır) doğru sırayla yazılmalıdır.
 * Satırlar: sonraki = gecerli->sonraki;  gecerli->sonraki = onceki;
 *           onceki = gecerli;            gecerli = sonraki;
 * Sınama: 0..6 düğümlü listeler.
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Dugum {
    int deger;
    struct Dugum *sonraki;
} Dugum;

static Dugum *ters(Dugum *bas)
{
    Dugum *onceki = NULL, *gecerli = bas, *sonraki = NULL;
    int adim = 0;
    while (gecerli != NULL && adim++ < 100) {
        ________
    }
    (void)sonraki;
    return onceki;
}

int main(void)
{
    Dugum d[6];
    for (int n = 0; n <= 6; n++) {
        for (int i = 0; i < n; i++) {
            d[i].deger = i + 1;
            d[i].sonraki = i + 1 < n ? &d[i + 1] : NULL;
        }
        Dugum *p = ters(n > 0 ? &d[0] : NULL);
        printf("n = %d:", n);
        for (int k = 0; p != NULL && k < 10; k++, p = p->sonraki) {
            printf(" %d", p->deger);
        }
        printf("\n");
    }
    return 0;
}

/* H14_Q55_h11_bfs_kuyruk.c — AP-2 Hafta 14 · Final hazırlık (H11) · Değişmez
 * Amaç    : BFS'de while döngüsünün her yinelemesinin BAŞINDA kuyruk
 *           içeriği hakkında dört aday ifade; 300 rastgele yönsüz grafta
 *           ihlaller sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q55_h11_bfs_kuyruk.c
 *           ../c/ortak_rastgele.c -o H14_Q55_h11_bfs_kuyruk
 * Çalıştır: ./H14_Q55_h11_bfs_kuyruk
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define V 12

int main(void)
{
    int g[V][V], d[V], q[V];
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0;
    rastgele_tohum(55);
    for (int t = 0; t < 300; t++) {
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                g[i][j] = 0;
            }
        }
        for (int k = 0; k < 18; k++) {
            int u = rastgele_aralik(0, V - 1), v = rastgele_aralik(0, V - 1);
            if (u != v) {
                g[u][v] = g[v][u] = 1;
            }
        }
        int bas = 0, son = 0;
        for (int i = 0; i < V; i++) {
            d[i] = -1;
        }
        d[0] = 0;
        q[son++] = 0;
        while (bas < son) {
            int A = 1, B = 1, C = 1, D = 1;
            for (int i = bas; i < son; i++) {
                A = A && d[q[i]] >= d[q[bas]] && d[q[i]] <= d[q[bas]] + 1 &&
                    (i == bas || d[q[i - 1]] <= d[q[i]]);
                B = B && d[q[i]] == d[q[bas]];
                C = C && (i == bas || q[i - 1] < q[i]);
                D = D && d[q[i]] < 0;           /* henüz keşfedilmemiş */
            }
            sinama++;
            ihlal[0] += !A;
            ihlal[1] += !B;
            ihlal[2] += !C;
            ihlal[3] += !D;
            int u = q[bas++];
            for (int v = 0; v < V; v++) {
                if (g[u][v] && d[v] < 0) {
                    d[v] = d[u] + 1;
                    q[son++] = v;
                }
            }
        }
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

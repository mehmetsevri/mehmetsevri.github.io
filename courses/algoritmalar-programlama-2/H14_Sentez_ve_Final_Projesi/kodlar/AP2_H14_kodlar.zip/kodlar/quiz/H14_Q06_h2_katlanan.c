/* H14_Q06_h2_katlanan.c — AP-2 Hafta 14 · Final hazırlık (H2) · Karmaşıklık
 * Amaç    : Dış döngü i = 1, 2, 4, ... (i < n), iç döngü i kez: toplam adım.
 *           n = 2^k için say = 1 + 2 + ... + 2^(k-1) = n - 1.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q06_h2_katlanan.c
 *           -o H14_Q06_h2_katlanan
 * Çalıştır: ./H14_Q06_h2_katlanan
 */
#include <stdio.h>

static long long say(long long n)
{
    long long s = 0;
    for (long long i = 1; i < n; i *= 2) {
        for (long long j = 0; j < i; j++) {
            s++;
        }
    }
    return s;
}

int main(void)
{
    const long long n[4] = {1000, 1024, 32768, 1048576};
    for (int k = 0; k < 4; k++) {
        long long s = say(n[k]);
        printf("n = %7lld: say = %7lld, say/n = %.3f\n", n[k], s,
               (double)s / (double)n[k]);
    }
    return 0;
}

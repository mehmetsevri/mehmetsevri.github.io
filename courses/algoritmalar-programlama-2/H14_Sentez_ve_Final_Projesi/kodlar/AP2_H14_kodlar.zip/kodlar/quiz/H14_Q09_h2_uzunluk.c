/* H14_Q09_h2_uzunluk.c — AP-2 Hafta 14 · Final hazırlık (H2) · Hata bulma
 * Amaç    : Döngü koşulunda dizgi uzunluğunu her yinelemede yeniden
 *           hesaplayan büyük harfe çevirme. uzunluk() strlen gibi çalışır ve
 *           okuduğu karakterleri sayar; düzeltilmiş sürüm uzunluğu bir kez
 *           hesaplar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q09_h2_uzunluk.c
 *           -o H14_Q09_h2_uzunluk
 * Çalıştır: ./H14_Q09_h2_uzunluk
 */
#include <stdio.h>
#include <stdlib.h>

static long long okunan = 0;

static size_t uzunluk(const char *s)              /* strlen + sayaç */
{
    size_t n = 0;
    while (s[n] != '\0') {
        n++;
        okunan++;
    }
    okunan++;                                      /* '\0' */
    return n;
}

static void buyut(char *s)                         /* YAVAŞ */
{
    for (size_t i = 0; i < uzunluk(s); i++) {
        if (s[i] >= 'a' && s[i] <= 'z') {
            s[i] = (char)(s[i] - 'a' + 'A');
        }
    }
}

static void buyut_hizli(char *s)
{
    size_t n = uzunluk(s);
    for (size_t i = 0; i < n; i++) {
        if (s[i] >= 'a' && s[i] <= 'z') {
            s[i] = (char)(s[i] - 'a' + 'A');
        }
    }
}

int main(void)
{
    const size_t boy[3] = {1000, 2000, 4000};
    for (int k = 0; k < 3; k++) {
        size_t n = boy[k];
        char *s = malloc(n + 1);
        if (s == NULL) {
            return 1;
        }
        for (size_t i = 0; i < n; i++) {
            s[i] = (char)('a' + i % 26);
        }
        s[n] = '\0';
        okunan = 0;
        buyut(s);
        long long yavas = okunan;
        okunan = 0;
        buyut_hizli(s);
        printf("n = %4zu: okunan karakter %8lld (yavaş) ↔ %4lld (hızlı)\n",
               n, yavas, okunan);
        free(s);
    }
    return 0;
}

/* H14_Q16_h4_ust_sinir.c — AP-2 Hafta 14 · Final hazırlık (H4) · Değişmez
 * Amaç    : Yarı açık aralıklı üst sınır (upper_bound): ilk a[i] > x konumu.
 *           Dört aday ifade döngü koşulunun HER sınanışında (çıkış dahil)
 *           denetlenir; 3000 rastgele sıralı dizide (tekrarlı) ihlaller
 *           sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q16_h4_ust_sinir.c
 *           ../c/ortak_rastgele.c -o H14_Q16_h4_ust_sinir
 * Çalıştır: ./H14_Q16_h4_ust_sinir
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

static long long ihlal[4], sinama;

static int hepsi(const int *a, int bas, int son, int x, int tur)
{
    for (int i = bas; i < son; i++) {           /* tur 0: <= x, 1: > x,  */
        int ok = tur == 0 ? a[i] <= x : tur == 1 ? a[i] > x  /* 2: < x, */
                 : tur == 2 ? a[i] < x : a[i] >= x;          /* 3: >= x */
        if (!ok) {
            return 0;
        }
    }
    return 1;
}

static int ust_sinir(const int *a, int n, int x)
{
    int lo = 0, hi = n;
    for (;;) {
        int var = 0;
        for (int i = lo; i < hi; i++) {
            var = var || a[i] == x;
        }
        sinama++;
        ihlal[0] += !(hepsi(a, 0, lo, x, 0) && hepsi(a, hi, n, x, 1));
        ihlal[1] += !(hepsi(a, 0, lo, x, 2) && hepsi(a, hi, n, x, 3));
        ihlal[2] += !(lo <= hi - 1);
        ihlal[3] += !var;
        if (!(lo < hi)) {
            break;
        }
        int mid = lo + (hi - lo) / 2;
        if (a[mid] <= x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

int main(void)
{
    int a[20];
    long long dogru = 0;
    rastgele_tohum(16);
    for (int d = 0; d < 3000; d++) {
        int n = rastgele_aralik(0, 20);
        int v = 0;
        for (int i = 0; i < n; i++) {
            v += rastgele_aralik(0, 2);          /* tekrarlı, sıralı */
            a[i] = v;
        }
        int x = rastgele_aralik(-1, v + 1);
        int k = ust_sinir(a, n, x), b = 0;
        while (b < n && a[b] <= x) {
            b++;
        }
        dogru += k == b;
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    printf("ust_sinir doğru: %lld / 3000\n", dogru);
    return 0;
}

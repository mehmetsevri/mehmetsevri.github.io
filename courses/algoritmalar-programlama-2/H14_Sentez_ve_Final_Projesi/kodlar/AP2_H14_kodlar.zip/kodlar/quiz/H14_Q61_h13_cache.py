"""H14_Q61_h13_cache.py — AP-2 Hafta 14 · Final hazırlık (H13) · Diller arası
Amaç    : functools.cache ile özyinelemeli (yukarıdan aşağıya) Fibonacci;
          derinlik n kadar çağrı zinciri ister. Varsayılan özyineleme
          sınırıyla n = 300 ve n = 1500 denenir. C eşi: H14_Q61_h13_cache.c
Çalıştır: python3 H14_Q61_h13_cache.py
"""
import functools
import sys

MOD = 1_000_000_007


@functools.cache
def fib(n):
    if n <= 1:
        return n
    return (fib(n - 1) + fib(n - 2)) % MOD


def main():
    print(f"sınır = {sys.getrecursionlimit()}")
    for n in (300, 1500):
        fib.cache_clear()
        try:
            print(f"fib({n}) mod p = {fib(n)}")
        except RecursionError:
            print(f"fib({n}): RecursionError")


if __name__ == "__main__":
    main()

"""H14_Q34_h7_bayt_sirasi.py — AP-2 Hafta 14 · Final hazırlık (H7) · Diller
          arası
Amaç    : sorted dizgileri kod noktası sırasıyla karşılaştırır (Türk
          alfabesi sırası DEĞİL). C eşi: H14_Q34_h7_bayt_sirasi.c (qsort +
          strcmp, UTF-8 baytları)
Çalıştır: python3 H14_Q34_h7_bayt_sirasi.py
"""


def main():
    print(" ".join(sorted(["Zeynep", "Çağla", "Can", "Ömer"])))


if __name__ == "__main__":
    main()

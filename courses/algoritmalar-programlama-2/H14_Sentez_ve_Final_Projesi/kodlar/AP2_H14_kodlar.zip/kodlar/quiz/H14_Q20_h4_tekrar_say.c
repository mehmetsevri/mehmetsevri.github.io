/* H14_Q20_h4_tekrar_say.c — AP-2 Hafta 14 · Final hazırlık (H4) · Karmaşıklık
 * Amaç    : Sıralı dizide x'in kaç kez geçtiği: alt sınır + üst sınır (iki
 *           ikili arama) ile alt sınırdan sağa doğru doğrusal genişletme
 *           karşılaştırılır (yoklama = dizi elemanı okuma).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q20_h4_tekrar_say.c
 *           -o H14_Q20_h4_tekrar_say
 * Çalıştır: ./H14_Q20_h4_tekrar_say
 */
#include <stdio.h>
#include <stdlib.h>

static long long yoklama;

static int sinir(const int *a, int n, int x, int ust)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        yoklama++;
        if (ust ? a[mid] <= x : a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

int main(void)
{
    const int n = 1000000;
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    const int k[3] = {1, 1000, 500000};
    for (int t = 0; t < 3; t++) {
        int bas = (n - k[t]) / 2;               /* x = 7'nin k kopyası */
        for (int i = 0; i < n; i++) {
            a[i] = i < bas ? 5 : i < bas + k[t] ? 7 : 9;
        }
        yoklama = 0;
        int sayi = sinir(a, n, 7, 1) - sinir(a, n, 7, 0);
        long long iki = yoklama;
        yoklama = 0;
        int p = sinir(a, n, 7, 0), q = p;       /* bir konum, sonra yay */
        while (q < n && (yoklama++, a[q] == 7)) {
            q++;
        }
        printf("k = %6d: sayı %6d; iki ikili arama %2lld yoklama, "
               "alt sınır + genişletme %6lld yoklama\n", k[t], sayi, iki,
               yoklama);
    }
    free(a);
    return 0;
}

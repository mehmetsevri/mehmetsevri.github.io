/* H14_Q59_h12_negatif.c — AP-2 Hafta 14 · Final hazırlık (H12) · Hata bulma
 * Amaç    : Kesinleşen köşeyi bir daha güncellemeyen Dijkstra ile Bellman–Ford
 *           (kâhin) dört küçük yönlü grafta 0'dan uzaklıkları karşılaştırır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q59_h12_negatif.c
 *           -o H14_Q59_h12_negatif
 * Çalıştır: ./H14_Q59_h12_negatif
 */
#include <stdio.h>

#define V 4
#define SONSUZ 1000000

typedef struct {
    int u, v, w;
} Kenar;

static void dijkstra(const Kenar *e, int m, int *d)
{
    int kesin[V] = {0};
    for (int i = 0; i < V; i++) {
        d[i] = SONSUZ;
    }
    d[0] = 0;
    for (int k = 0; k < V; k++) {
        int u = -1;
        for (int i = 0; i < V; i++) {
            if (!kesin[i] && d[i] < SONSUZ && (u < 0 || d[i] < d[u])) {
                u = i;
            }
        }
        if (u < 0) {
            return;
        }
        kesin[u] = 1;
        for (int j = 0; j < m; j++) {
            if (e[j].u == u && !kesin[e[j].v] && d[u] + e[j].w < d[e[j].v]) {
                d[e[j].v] = d[u] + e[j].w;
            }
        }
    }
}

static void bellman_ford(const Kenar *e, int m, int *d)
{
    for (int i = 0; i < V; i++) {
        d[i] = SONSUZ;
    }
    d[0] = 0;
    for (int k = 0; k < V - 1; k++) {
        for (int j = 0; j < m; j++) {
            if (d[e[j].u] < SONSUZ && d[e[j].u] + e[j].w < d[e[j].v]) {
                d[e[j].v] = d[e[j].u] + e[j].w;
            }
        }
    }
}

int main(void)
{
    const Kenar g[4][3] = {{{0, 1, 2}, {0, 2, 5}, {2, 1, -4}},
                           {{0, 1, 2}, {1, 2, 3}, {0, 2, 6}},
                           {{0, 1, 1}, {1, 2, 1}, {2, 3, 1}},
                           {{0, 1, 5}, {0, 2, 1}, {2, 1, 1}}};
    const char *ad[4] = {"0→1 (2), 0→2 (5), 2→1 (−4)",
                         "0→1 (2), 1→2 (3), 0→2 (6)",
                         "0→1 (1), 1→2 (1), 2→3 (1)",
                         "0→1 (5), 0→2 (1), 2→1 (1)"};
    for (int t = 0; t < 4; t++) {
        int a[V], b[V], ayni = 1;
        dijkstra(g[t], 3, a);
        bellman_ford(g[t], 3, b);
        for (int i = 0; i < V; i++) {
            ayni = ayni && a[i] == b[i];
        }
        printf("%s: Dijkstra d[1] = %d, Bellman–Ford d[1] = %d %s\n", ad[t],
               a[1], b[1], ayni ? "aynı" : "FARKLI");
    }
    return 0;
}

"""H14_Q23_h5_ters_kararli.py — AP-2 Hafta 14 · Final hazırlık (H5) · Diller
          arası
Amaç    : sorted(..., reverse=True) kararlıdır: eşit anahtarlılar GİRDİ
          sırasında kalır (ters çevrilmez). C++ eşi:
          H14_Q23_h5_ters_kararli.cpp (std::stable_sort, büyükten küçüğe)
Çalıştır: python3 H14_Q23_h5_ters_kararli.py
"""


def main():
    kayitlar = [("Ada", 70), ("Bora", 85), ("Can", 70), ("Deniz", 85)]
    s = sorted(kayitlar, key=lambda k: k[1], reverse=True)
    print(" ".join(ad for ad, _ in s))


if __name__ == "__main__":
    main()

"""H14_Q72_h14_permutasyon.py — AP-2 Hafta 14 · Final hazırlık (H14) · Diller
          arası
Amaç    : itertools.permutations girdinin KONUM sırasıyla bütün n!
          permütasyonu üretir (değerler sıralı olmasa da).
          C++ eşi: H14_Q72_h14_permutasyon.cpp (std::next_permutation)
Çalıştır: python3 H14_Q72_h14_permutasyon.py
"""
import itertools


def main():
    p = list(itertools.permutations([2, 1, 3]))
    print(len(p), " ".join("".join(map(str, t)) for t in p))


if __name__ == "__main__":
    main()

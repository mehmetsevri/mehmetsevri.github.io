/* H14_Q25_h5_erken_cikis_bos.c — AP-2 Hafta 14 · Final hazırlık (H5) · Kod
 *                                 tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: erken çıkışlı kabarcık sıralaması.
 * Bir geçişte hiç takas yoksa dizi sıralıdır ve sıralama bitmelidir.
 * Sınama: 200 rastgele dizi sıralanmalı; zaten sıralı girdide 1 geçiş.
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

static int gecis;

static void kabarcik(int *a, int n)
{
    gecis = 0;
    for (int i = 0; i < n - 1; i++) {
        int takas = 0;
        gecis++;
        for (int j = 0; j < n - 1 - i; j++) {
            if (a[j] > a[j + 1]) {
                int t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
                takas = 1;
            }
        }
        ________;
    }
}

int main(void)
{
    int a[20];
    long long dogru = 0;
    rastgele_tohum(25);
    for (int d = 0; d < 200; d++) {
        int n = rastgele_aralik(1, 20), ok = 1;
        rastgele_dizi(a, (size_t)n, 0, 50);
        kabarcik(a, n);
        for (int i = 1; i < n; i++) {
            ok = ok && a[i - 1] <= a[i];
        }
        dogru += ok;
    }
    for (int i = 0; i < 20; i++) {
        a[i] = i;
    }
    kabarcik(a, 20);
    printf("doğru %lld / 200; sıralı girdide geçiş = %d\n", dogru, gecis);
    return 0;
}

/* H14_Q34_h7_bayt_sirasi.c — AP-2 Hafta 14 · Final hazırlık (H7) · Diller
 *                             arası
 * Amaç    : strcmp UTF-8 dizgilerini bayt bayt (unsigned char) karşılaştırır;
 *           UTF-8'de bayt sırası kod noktası sırasıyla aynıdır.
 *           Python eşi: H14_Q34_h7_bayt_sirasi.py
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q34_h7_bayt_sirasi.c
 *           -o H14_Q34_h7_bayt_sirasi
 * Çalıştır: ./H14_Q34_h7_bayt_sirasi
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int karsilastir(const void *x, const void *y)
{
    return strcmp(*(const char *const *)x, *(const char *const *)y);
}

int main(void)
{
    const char *ad[4] = {"Zeynep", "Çağla", "Can", "Ömer"};
    qsort(ad, 4, sizeof ad[0], karsilastir);
    for (int i = 0; i < 4; i++) {
        printf("%s%s", ad[i], i < 3 ? " " : "\n");
    }
    return 0;
}

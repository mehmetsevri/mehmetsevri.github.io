"""H14_Q04_h1_yuvarlama.py — AP-2 Hafta 14 · Final hazırlık (H1) · Diller arası
Amaç    : Python'un round() fonksiyonu yarımları en yakın ÇİFT tamsayıya
          yuvarlar ("bankacı yuvarlaması"). C eşi: H14_Q04_h1_yuvarlama.c
Çalıştır: python3 H14_Q04_h1_yuvarlama.py
"""


def main():
    print(round(2.5), round(3.5), round(-2.5))


if __name__ == "__main__":
    main()

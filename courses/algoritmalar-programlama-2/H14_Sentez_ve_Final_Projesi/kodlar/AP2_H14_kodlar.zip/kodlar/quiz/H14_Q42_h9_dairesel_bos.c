/* H14_Q42_h9_dairesel_bos.c — AP-2 Hafta 14 · Final hazırlık (H9) · Kod
 *                              tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: dairesel tampon kuyrukta (kapasite
 * KAP, öğe sayısı adet ile tutulur) cikar() işlemi baş indisini ilerletir.
 * Sınama: 2000 rastgele ekle/çıkar işlemi, kaydırmalı dizi kâhinine karşı.
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define KAP 8

static int t[KAP], bas = 0, son = 0, adet = 0;

static void ekle(int x)
{
    t[son] = x;
    son = (son + 1) % KAP;
    adet++;
}

static int cikar(void)
{
    int x = t[bas];
    ________;
    adet--;
    return x;
}

int main(void)
{
    int kahin[KAP], kn = 0;
    long long dogru = 0, islem = 0;
    rastgele_tohum(42);
    for (int d = 0; d < 2000; d++) {
        if (adet < KAP && (adet == 0 || rastgele_aralik(0, 1) == 0)) {
            int x = rastgele_aralik(0, 99);
            ekle(x);
            kahin[kn++] = x;
        } else {
            int x = cikar(), k = kahin[0];
            for (int i = 1; i < kn; i++) {
                kahin[i - 1] = kahin[i];
            }
            kn--;
            islem++;
            dogru += x == k;
        }
    }
    printf("doğru %lld / %lld çıkarma\n", dogru, islem);
    return 0;
}

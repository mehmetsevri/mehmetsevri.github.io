/* H14_Q68_h14_iki_opt_degismez.c — AP-2 Hafta 14 · Final hazırlık (H14) ·
 *                                   Değişmez
 * Amaç    : Örnek 4'ün ilk iyileştirmeli 2-opt'u (Örnek 3'ün 100 örneği,
 *           tohum 2026, n = 8, NN turundan). UYGULANAN her hamleden SONRA
 *           dört aday ifade sınanır; ihlaller sayılır. Genel en iyi kaba
 *           kuvvetle bulunur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q68_h14_iki_opt_degismez.c ../c/ortak_rastgele.c -lm \
 *           -o H14_Q68_h14_iki_opt_degismez
 * Çalıştır: ./H14_Q68_h14_iki_opt_degismez
 */
#include <math.h>
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define N 8
#define EPS 1e-9

static int x[N], y[N], yol[N], kul[N];
static double d[N][N], en_iyi;

static long long d2(int i, int j)
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static double uzunluk(const int *t)
{
    double s = 0.0;
    for (int k = 1; k < N; k++) {
        s += d[t[k - 1]][t[k]];
    }
    return s + d[t[N - 1]][t[0]];
}

static void dene(int k, double kismi)
{
    if (k == N) {
        double s = kismi + d[yol[N - 1]][0];
        en_iyi = s < en_iyi - EPS ? s : en_iyi;
        return;
    }
    for (int s = 1; s < N; s++) {
        if (!kul[s]) {
            kul[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kul[s] = 0;
        }
    }
}

static int iyilesen_var(const int *t)      /* bir hamle kısaltır mı? */
{
    for (int i = 1; i < N - 1; i++) {
        for (int j = i + 1; j < N; j++) {
            int a = t[i - 1], b = t[i], c = t[j], e = t[(j + 1) % N];
            if ((d[a][c] + d[b][e]) - (d[a][b] + d[c][e]) < -EPS) {
                return 1;
            }
        }
    }
    return 0;
}

int main(void)
{
    long long ihlal[4] = {0, 0, 0, 0}, hamle = 0;
    rastgele_tohum(2026);
    for (int t = 0; t < 100; t++) {
        for (int i = 0; i < N; i++) {
            x[i] = rastgele_aralik(0, 99);
            y[i] = rastgele_aralik(0, 99);
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                d[i][j] = sqrt((double)d2(i, j));
            }
        }
        for (int i = 0; i < N; i++) {
            kul[i] = 0;
        }
        yol[0] = 0;
        kul[0] = 1;
        en_iyi = 1e300;
        dene(1, 0.0);
        int tur[N], ziyaret[N] = {0};               /* en yakın komşu */
        tur[0] = 0;
        ziyaret[0] = 1;
        for (int k = 1; k < N; k++) {
            int sec = -1;
            for (int s = 0; s < N; s++) {
                if (!ziyaret[s] &&
                    (sec == -1 || d2(tur[k - 1], s) < d2(tur[k - 1], sec))) {
                    sec = s;
                }
            }
            tur[k] = sec;
            ziyaret[sec] = 1;
        }
        int degisti = 1;
        while (degisti) {                            /* Örnek 4: iki_opt */
            degisti = 0;
            for (int i = 1; i < N - 1 && !degisti; i++) {
                for (int j = i + 1; j < N && !degisti; j++) {
                    int a = tur[i - 1], b = tur[i], c = tur[j];
                    int e = tur[(j + 1) % N];
                    if ((d[a][c] + d[b][e]) - (d[a][b] + d[c][e]) >= -EPS) {
                        continue;
                    }
                    double once = uzunluk(tur), en_uzun = 0.0;
                    for (int k = 0; k < N; k++) {
                        double kk = d[tur[k]][tur[(k + 1) % N]];
                        en_uzun = kk > en_uzun ? kk : en_uzun;
                    }
                    int cikan_en_uzun = d[a][b] == en_uzun ||
                                        d[c][e] == en_uzun;
                    for (int p = i, q = j; p < q; p++, q--) {
                        int g = tur[p];
                        tur[p] = tur[q];
                        tur[q] = g;
                    }
                    degisti = 1;
                    hamle++;
                    int perm = tur[0] == 0, gor[N] = {0};
                    for (int k = 0; k < N; k++) {
                        perm = perm && !gor[tur[k]];
                        gor[tur[k]] = 1;
                    }
                    double sonra = uzunluk(tur);
                    ihlal[0] += !(perm && sonra < once - EPS);       /* A */
                    ihlal[1] += !(fabs(sonra - en_iyi) < EPS);       /* B */
                    ihlal[2] += !cikan_en_uzun;                      /* C */
                    ihlal[3] += iyilesen_var(tur);                   /* D */
                }
            }
        }
    }
    printf("uygulanan hamle = %lld; ihlal: A = %lld, B = %lld, C = %lld, "
           "D = %lld\n", hamle, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

/* H14_Q45_h9_parantez.c — AP-2 Hafta 14 · Final hazırlık (H9) · Hata bulma
 * Amaç    : Yığın yerine yalnız SAYAÇ kullanan parantez denetimi (açılışta
 *           +1, kapanışta −1; negatif olursa ya da sonda 0 değilse hata).
 *           Dört girdide yığınlı doğru denetimle karşılaştırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q45_h9_parantez.c
 *           -o H14_Q45_h9_parantez
 * Çalıştır: ./H14_Q45_h9_parantez
 */
#include <stdio.h>
#include <string.h>

static int sayacli(const char *s)                      /* HATALI */
{
    int d = 0;
    for (size_t i = 0; s[i] != '\0'; i++) {
        d += strchr("([{", s[i]) != NULL ? 1 : -1;
        if (d < 0) {
            return 0;
        }
    }
    return d == 0;
}

static int yiginli(const char *s)
{
    char y[64];
    int tepe = 0;
    for (size_t i = 0; s[i] != '\0'; i++) {
        if (strchr("([{", s[i]) != NULL) {
            y[tepe++] = s[i];
        } else {
            char ac = s[i] == ')' ? '(' : s[i] == ']' ? '[' : '{';
            if (tepe == 0 || y[tepe - 1] != ac) {
                return 0;
            }
            tepe--;
        }
    }
    return tepe == 0;
}

int main(void)
{
    const char *g[4] = {"([)]", "(()", "())(", "{[()]}"};
    for (int k = 0; k < 4; k++) {
        int a = sayacli(g[k]), b = yiginli(g[k]);
        printf("%-7s sayaçlı: %-6s yığınlı: %-6s %s\n", g[k],
               a ? "geçer" : "hata", b ? "geçer" : "hata",
               a == b ? "aynı" : "FARKLI");
    }
    return 0;
}

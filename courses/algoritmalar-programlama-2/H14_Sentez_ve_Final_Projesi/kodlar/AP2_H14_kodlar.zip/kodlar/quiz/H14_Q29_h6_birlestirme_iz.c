/* H14_Q29_h6_birlestirme_iz.c — AP-2 Hafta 14 · Final hazırlık (H6) · İzleme
 * Amaç    : [1 4 7 8] ile [2 3 5 6] birleştirilirken kaç anahtar
 *           karşılaştırması yapılır? (Bir dizi bitince kalan kopyalanır.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q29_h6_birlestirme_iz.c -o H14_Q29_h6_birlestirme_iz
 * Çalıştır: ./H14_Q29_h6_birlestirme_iz
 */
#include <stdio.h>

int main(void)
{
    const int a[4] = {1, 4, 7, 8}, b[4] = {2, 3, 5, 6};
    int c[8], i = 0, j = 0, k = 0, kars = 0;
    while (i < 4 && j < 4) {
        kars++;
        c[k++] = a[i] <= b[j] ? a[i++] : b[j++];
    }
    while (i < 4) {
        c[k++] = a[i++];
    }
    while (j < 4) {
        c[k++] = b[j++];
    }
    printf("c:");
    for (k = 0; k < 8; k++) {
        printf(" %d", c[k]);
    }
    printf("\nkarşılaştırma = %d\n", kars);
    return 0;
}

/* H14_Q61_h13_cache.c — AP-2 Hafta 14 · Final hazırlık (H13) · Diller arası
 * Amaç    : Memo dizili özyinelemeli Fibonacci (mod 10⁹ + 7); n = 300 ve
 *           n = 1500 (çağrı zinciri derinliği ≈ n; C yığını yeter).
 *           Python eşi: H14_Q61_h13_cache.py
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q61_h13_cache.c
 *           -o H14_Q61_h13_cache
 * Çalıştır: ./H14_Q61_h13_cache
 */
#include <stdio.h>

#define MOD 1000000007LL

static long long memo[1501];

static long long fib(int n)
{
    if (n <= 1) {
        return n;
    }
    if (memo[n] >= 0) {
        return memo[n];
    }
    return memo[n] = (fib(n - 1) + fib(n - 2)) % MOD;
}

int main(void)
{
    const int n[2] = {300, 1500};
    for (int k = 0; k < 2; k++) {
        for (int i = 0; i <= 1500; i++) {
            memo[i] = -1;
        }
        printf("fib(%d) mod p = %lld\n", n[k], fib(n[k]));
    }
    return 0;
}

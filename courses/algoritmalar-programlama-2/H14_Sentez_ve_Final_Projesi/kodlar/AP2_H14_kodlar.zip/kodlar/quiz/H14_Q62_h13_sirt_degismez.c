/* H14_Q62_h13_sirt_degismez.c — AP-2 Hafta 14 · Final hazırlık (H13) ·
 *                                Değişmez
 * Amaç    : Tek satırlı 0/1 sırt çantası (w TERS sırada). i. nesne
 *           işlendikten SONRA dp[] hakkında dört aday ifade; kâhin: ilk i
 *           nesnenin bütün alt kümeleri. 300 rastgele örnekte ihlaller.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q62_h13_sirt_degismez.c ../c/ortak_rastgele.c \
 *           -o H14_Q62_h13_sirt_degismez
 * Çalıştır: ./H14_Q62_h13_sirt_degismez
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define NMAX 8
#define WMAX 20

int main(void)
{
    int ag[NMAX], de[NMAX], dp[WMAX + 1];
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0;
    rastgele_tohum(62);
    for (int t = 0; t < 300; t++) {
        int n = rastgele_aralik(1, NMAX), W = rastgele_aralik(1, WMAX);
        for (int i = 0; i < n; i++) {
            ag[i] = rastgele_aralik(1, 8);
            de[i] = rastgele_aralik(1, 20);
        }
        for (int w = 0; w <= W; w++) {
            dp[w] = 0;
        }
        for (int i = 0; i < n; i++) {
            for (int w = W; w >= ag[i]; w--) {
                int aday = dp[w - ag[i]] + de[i];
                dp[w] = aday > dp[w] ? aday : dp[w];
            }
            int A = 1, B = 1, C = 1, D = 1;       /* ilk i + 1 nesne */
            for (int w = 0; w <= W; w++) {
                int en01 = 0, tam = -1, sinirsiz[WMAX + 1];
                for (int s = 0; s < (1 << (i + 1)); s++) {
                    int ta = 0, td = 0;
                    for (int k = 0; k <= i; k++) {
                        if (s >> k & 1) {
                            ta += ag[k];
                            td += de[k];
                        }
                    }
                    if (ta <= w && td > en01) {
                        en01 = td;
                    }
                    if (ta == w && td > tam) {
                        tam = td;
                    }
                }
                for (int x = 0; x <= w; x++) {    /* sınırsız sayıda */
                    sinirsiz[x] = 0;
                    for (int k = 0; k <= i; k++) {
                        if (ag[k] <= x && sinirsiz[x - ag[k]] + de[k] >
                                              sinirsiz[x]) {
                            sinirsiz[x] = sinirsiz[x - ag[k]] + de[k];
                        }
                    }
                }
                A = A && dp[w] == en01;
                B = B && dp[w] == sinirsiz[w];
                C = C && dp[w] == (tam < 0 ? 0 : tam);
                D = D && (w == 0 || dp[w] <= dp[w - 1]);
            }
            sinama++;
            ihlal[0] += !A;
            ihlal[1] += !B;
            ihlal[2] += !C;
            ihlal[3] += !D;
        }
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

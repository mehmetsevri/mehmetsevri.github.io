"""H14_Q82_en_uzak_esitlik.py — AP-2 Hafta 14 · Haftalık quiz (diller arası)
Amaç    : Şehir 0'a EN UZAK şehri seçerken eşitlik kuralı. Kare uzaklıklar
          d2 içinde iki şehir aynı en büyük değere sahip; max() eşit
          anahtarlardan İLKİNİ döndürür.
          C eşi: H14_Q82_en_uzak_esitlik.c (döngüde ">=")
Çalıştır: python3 H14_Q82_en_uzak_esitlik.py
"""


def main():
    d2 = [0, 25, 41, 41, 9]
    sec = max(range(1, 5), key=lambda j: d2[j])
    print(f"Python: en uzak şehir {sec} (d² = {d2[sec]})")


if __name__ == "__main__":
    main()

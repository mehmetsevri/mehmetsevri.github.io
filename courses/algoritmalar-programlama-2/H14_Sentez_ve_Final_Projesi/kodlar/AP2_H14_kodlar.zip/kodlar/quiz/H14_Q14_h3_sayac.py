"""H14_Q14_h3_sayac.py — AP-2 Hafta 14 · Final hazırlık (H3) · Diller arası
Amaç    : Özyinelemeli fib'de çağrı sayacı. Fonksiyon içinde `sayac += 1`
          ataması sayac'ı YEREL değişken yapar (global bildirimi yok).
          Program oluşan istisnanın türünü yazar. C eşi: H14_Q14_h3_sayac.c
Çalıştır: python3 H14_Q14_h3_sayac.py
"""
sayac = 0


def fib(n):
    sayac += 1          # noqa: F821 (kasıtlı: global bildirimi yok)
    if n <= 1:
        return n
    return fib(n - 1) + fib(n - 2)


def main():
    try:
        print(fib(5), sayac)
    except Exception as e:     # türünü göstermek için
        print(type(e).__name__)


if __name__ == "__main__":
    main()

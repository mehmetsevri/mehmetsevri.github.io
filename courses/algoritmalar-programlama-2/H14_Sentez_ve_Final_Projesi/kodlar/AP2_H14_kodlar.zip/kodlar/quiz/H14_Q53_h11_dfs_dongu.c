/* H14_Q53_h11_dfs_dongu.c — AP-2 Hafta 14 · Final hazırlık (H11) · Hata bulma
 * Amaç    : Yönlü grafta döngü tespiti. HATALI sürüm iki renk kullanır
 *           (ziyaret edilmiş bir köşeye yeniden varmak = döngü); doğru sürüm
 *           üç renklidir (yalnız GRİ, yani yığında olan köşeye kenar döngü).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q53_h11_dfs_dongu.c
 *           -o H14_Q53_h11_dfs_dongu
 * Çalıştır: ./H14_Q53_h11_dfs_dongu
 */
#include <stdio.h>

#define V 4

static int g[V][V], renk[V];

static int iki_renk(int u)                           /* HATALI */
{
    renk[u] = 1;
    for (int v = 0; v < V; v++) {
        if (g[u][v] && (renk[v] != 0 || iki_renk(v))) {
            return 1;
        }
    }
    return 0;
}

static int uc_renk(int u)                     /* 0 beyaz, 1 gri, 2 siyah */
{
    renk[u] = 1;
    for (int v = 0; v < V; v++) {
        if (g[u][v] && (renk[v] == 1 || (renk[v] == 0 && uc_renk(v)))) {
            return 1;
        }
    }
    renk[u] = 2;
    return 0;
}

static int dongu_var(int (*f)(int))
{
    for (int i = 0; i < V; i++) {
        renk[i] = 0;
    }
    for (int s = 0; s < V; s++) {
        if (renk[s] == 0 && f(s)) {
            return 1;
        }
    }
    return 0;
}

int main(void)
{
    const int e[4][4][2] = {{{0, 1}, {0, 2}, {1, 3}, {2, 3}},
                            {{0, 1}, {1, 2}, {2, 0}, {0, 0}},
                            {{0, 1}, {1, 2}, {0, 0}, {0, 0}},
                            {{0, 1}, {2, 3}, {0, 0}, {0, 0}}};
    const int m[4] = {4, 3, 2, 2};
    const char *ad[4] = {"0→1, 0→2, 1→3, 2→3", "0→1, 1→2, 2→0", "0→1, 1→2",
                         "0→1, 2→3"};
    for (int t = 0; t < 4; t++) {
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                g[i][j] = 0;
            }
        }
        for (int i = 0; i < m[t]; i++) {
            g[e[t][i][0]][e[t][i][1]] = 1;
        }
        int a = dongu_var(iki_renk), b = dongu_var(uc_renk);
        printf("%s | iki renk: %-5s üç renk: %-5s %s\n", ad[t],
               a ? "döngü" : "yok", b ? "döngü" : "yok",
               a == b ? "aynı" : "FARKLI");
    }
    return 0;
}

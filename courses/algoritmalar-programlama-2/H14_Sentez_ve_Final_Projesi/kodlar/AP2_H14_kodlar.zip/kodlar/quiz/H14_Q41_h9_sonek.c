/* H14_Q41_h9_sonek.c — AP-2 Hafta 14 · Final hazırlık (H9) · İzleme
 * Amaç    : "5 1 2 + 4 * + 3 -" sonek ifadesinin yığınla değerlendirilmesi:
 *           her simgeden sonra yığın, sonuç ve en büyük yığın derinliği.
 *           İşleç için önce b (tepe), sonra a çıkarılır: a op b.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q41_h9_sonek.c
 *           -o H14_Q41_h9_sonek
 * Çalıştır: ./H14_Q41_h9_sonek
 */
#include <stdio.h>

int main(void)
{
    const char *ifade[9] = {"5", "1", "2", "+", "4", "*", "+", "3", "-"};
    int y[16], tepe = 0, derin = 0;
    for (int k = 0; k < 9; k++) {
        char c = ifade[k][0];
        if (c >= '0' && c <= '9') {
            y[tepe++] = c - '0';
        } else {
            int b = y[--tepe], a = y[--tepe];
            y[tepe++] = c == '+' ? a + b : c == '-' ? a - b : a * b;
        }
        derin = tepe > derin ? tepe : derin;
        printf("%s:", ifade[k]);
        for (int i = 0; i < tepe; i++) {
            printf(" %d", y[i]);
        }
        printf("\n");
    }
    printf("sonuç = %d, en büyük derinlik = %d\n", y[0], derin);
    return 0;
}

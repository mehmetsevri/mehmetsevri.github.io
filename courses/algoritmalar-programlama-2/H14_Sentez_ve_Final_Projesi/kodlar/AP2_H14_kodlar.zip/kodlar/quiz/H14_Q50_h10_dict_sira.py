"""H14_Q50_h10_dict_sira.py — AP-2 Hafta 14 · Final hazırlık (H10) · Diller
          arası
Amaç    : Python dict'i (3.7'den beri dil güvencesi) EKLEME sırasını korur;
          silinip yeniden eklenen anahtar sona geçer. C++'ta
          std::unordered_map'in dolaşma sırası belirtilmemiştir.
Çalıştır: python3 H14_Q50_h10_dict_sira.py
"""


def main():
    d = {"b": 1, "a": 2, "c": 3}
    del d["b"]
    d["b"] = 4
    print(" ".join(d))


if __name__ == "__main__":
    main()

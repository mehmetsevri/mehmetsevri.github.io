/* H14_Q23_h5_ters_kararli.cpp — AP-2 Hafta 14 · Final hazırlık (H5) ·
 *                                Diller arası
 * Amaç    : std::stable_sort ile puana göre büyükten küçüğe; eşitler girdi
 *           sırasında kalır. Python eşi: H14_Q23_h5_ters_kararli.py
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q23_h5_ters_kararli.cpp -o H14_Q23_h5_ters_kararli
 * Çalıştır: ./H14_Q23_h5_ters_kararli
 */
#include <algorithm>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

int main()
{
    std::vector<std::pair<std::string, int>> k = {
        {"Ada", 70}, {"Bora", 85}, {"Can", 70}, {"Deniz", 85}};
    std::stable_sort(k.begin(), k.end(),
                     [](const auto& a, const auto& b) {
                         return a.second > b.second;
                     });
    for (std::size_t i = 0; i < k.size(); i++) {
        std::cout << k[i].first << (i + 1 < k.size() ? " " : "\n");
    }
    return 0;
}

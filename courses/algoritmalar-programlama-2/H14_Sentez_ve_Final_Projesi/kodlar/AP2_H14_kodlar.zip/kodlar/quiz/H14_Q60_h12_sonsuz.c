/* H14_Q60_h12_sonsuz.c — AP-2 Hafta 14 · Final hazırlık (H12) · Diller arası
 * Amaç    : d[u] = INT_MAX iken d[u] + w İŞARETLİ taşmadır (tanımsız
 *           davranış). Program taşmayı YAPMADAN __builtin_add_overflow ile
 *           sınar; gerçek toplamı long long ile ve "sarmış" olsaydı oluşacak
 *           değeri uint32_t ile (tanımlı) gösterir. Python eşi:
 *           H14_Q60_h12_sonsuz.py
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q60_h12_sonsuz.c
 *           -o H14_Q60_h12_sonsuz
 * Çalıştır: ./H14_Q60_h12_sonsuz
 */
#include <limits.h>
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    int du = INT_MAX, w = 5, dv = 100, toplam;
    int tasar = __builtin_add_overflow(du, w, &toplam);
    uint32_t sar = (uint32_t)du + (uint32_t)w;
    printf("taşma: %s; gerçek toplam %lld; 32 bitte sarsaydı %d "
           "(< d[v] = %d: %s)\n", tasar ? "evet" : "hayır",
           (long long)du + w, (int)(sar - 4294967296LL), dv,
           (int)(sar - 4294967296LL) < dv ? "doğru" : "yanlış");
    printf("korumalı: d[u] != INT_MAX && d[u] + w < d[v] -> %s\n",
           du != INT_MAX && du + w < dv ? "gevşet" : "gevşetme");
    return 0;
}

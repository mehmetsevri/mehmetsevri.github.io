/* H14_Q15_h3_alt_kume_degismez.c — AP-2 Hafta 14 · Final hazırlık (H3) ·
 *                                   Değişmez
 * Amaç    : Alt küme toplamı geri izlemesi (budamasız; dahil et / etme).
 *           dene(i, toplam) çağrısının GİRİŞİNDE dört aday ifade sınanır;
 *           500 rastgele girdide kaç kez yanlış oldukları sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_Q15_h3_alt_kume_degismez.c ../c/ortak_rastgele.c \
 *           -o H14_Q15_h3_alt_kume_degismez
 * Çalıştır: ./H14_Q15_h3_alt_kume_degismez
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

static int a[10], secili[10], n, hedef;
static long long cozum, sinama, ihlal[4];

static void dene(int i, int toplam)
{
    int s = 0, hepsi = 1, tum = 0;
    for (int j = 0; j < i; j++) {
        s += secili[j] ? a[j] : 0;
        hepsi = hepsi && secili[j];
        tum += a[j];
    }
    sinama++;
    ihlal[0] += !(toplam == s);          /* A: seçilenlerin toplamı */
    ihlal[1] += !(toplam <= hedef);      /* B */
    ihlal[2] += !hepsi;                  /* C: a[0..i-1] hepsi seçili */
    ihlal[3] += !(toplam < tum);         /* D: toplam < a[0]+...+a[i-1] */
    if (i == n) {
        cozum += toplam == hedef;
        return;
    }
    secili[i] = 1;
    dene(i + 1, toplam + a[i]);
    secili[i] = 0;
    dene(i + 1, toplam);
}

int main(void)
{
    rastgele_tohum(15);
    for (int d = 0; d < 500; d++) {
        n = rastgele_aralik(1, 10);
        int tum = 0;
        for (int i = 0; i < n; i++) {
            a[i] = rastgele_aralik(1, 20);
            secili[i] = 0;
            tum += a[i];
        }
        hedef = rastgele_aralik(0, tum);
        dene(0, 0);
    }
    printf("çağrı = %lld, çözüm = %lld; ihlal: A = %lld, B = %lld, "
           "C = %lld, D = %lld\n", sinama, cozum, ihlal[0], ihlal[1],
           ihlal[2], ihlal[3]);
    return 0;
}

/* H14_Q31_h7_obek_cikar.c — AP-2 Hafta 14 · Final hazırlık (H7) · İzleme
 * Amaç    : En büyük öbek [9 7 8 3 5 6]'dan en büyüğü çıkarma: son eleman
 *           köke taşınır ve aşağı süzülür (büyük çocukla takas).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_Q31_h7_obek_cikar.c
 *           -o H14_Q31_h7_obek_cikar
 * Çalıştır: ./H14_Q31_h7_obek_cikar
 */
#include <stdio.h>

int main(void)
{
    int a[6] = {9, 7, 8, 3, 5, 6}, n = 6, takas = 0;
    int en_buyuk = a[0];
    a[0] = a[--n];
    int i = 0;
    for (;;) {
        int b = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < n && a[s] > a[b]) {
            b = s;
        }
        if (r < n && a[r] > a[b]) {
            b = r;
        }
        if (b == i) {
            break;
        }
        int t = a[i];
        a[i] = a[b];
        a[b] = t;
        takas++;
        i = b;
    }
    printf("çıkan = %d; öbek:", en_buyuk);
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf(" (takas = %d)\n", takas);
    return 0;
}

/* H14_A10_parsons_held_karp.c — AP-2 Hafta 14 · Alıştırma 14.10 (★★)
 * Parsons: tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar
 * Held–Karp'ın GERİ ÇIKARMA fonksiyonunun KARIŞTIRILMIŞ satırlarıdır; iki
 * satır fazladır (kullanılmayacak). ebeveyn[S * n + j], dp[S][j]'yi veren
 * önceki şehirdir (Örnek 5); son, dönüşten önceki son şehirdir. Doğru
 * sıraya dizin, girintiyi düzeltin: Örnek 2'nin beş şehrinde son = 2 ile
 * tur[] = 0 4 1 3 2 olmalı (Örnek 5'in turu 0-4-1-3-2-0).
 */
        S |= 1 << son;
    tur[0] = son;
        tur[k] = son;
{
    for (int k = n - 1; k >= 1; k--) {
        son = i;
static void geri_cikar(int son, int *tur)
        int i = ebeveyn[(S ^ (1 << son)) * n + son];
    }
    int S = (1 << n) - 1;
        S ^= 1 << son;
}
        int i = ebeveyn[S * n + son];

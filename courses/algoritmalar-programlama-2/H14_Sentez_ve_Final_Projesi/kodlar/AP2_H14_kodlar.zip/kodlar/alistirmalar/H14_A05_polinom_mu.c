/* H14_A05_polinom_mu.c — AP-2 Hafta 14 · Alıştırma 14.5 (★★)
 * Amaç    : Dört fonksiyonun iş sayaçları, girdideki SAYININ bit uzunluğu
 *           b büyürken. Hangisi girdi uzunluğunda polinom, hangisi sözde
 *           polinom (sayının DEĞERİNDE polinom, bit uzunluğunda üstel)?
 *           Sayaçları b'ye göre tablolayıp sınıflandırın.
 *   us_al(3, e, m)       : e = 2^b − 1 için hızlı üs alma (kare al, çarp)
 *   basamak_toplami(N)   : N = 2^b − 1'in onluk basamakları toplamı
 *   asal_mi(N)           : 2^b'den küçük en büyük asal, deneme bölmesi
 *   alt_kume_dp(a, T)    : 10 sayı, hedef T = 2^b − 1, tek satırlı DP
 *                          (H13); b > 24 için tablo bütçesi aşılır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A05_polinom_mu.c -o H14_A05_polinom_mu
 * Çalıştır: ./H14_A05_polinom_mu
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

static long long us_al(uint64_t taban, uint64_t us, uint64_t mod,
                       uint64_t *sonuc)
{
    long long adim = 0;
    uint64_t s = 1 % mod;
    taban %= mod;
    while (us > 0) {
        if (us & 1) {
            s = s * taban % mod;
        }
        taban = taban * taban % mod;
        us >>= 1;
        adim++;
    }
    *sonuc = s;
    return adim;
}

static long long basamak_toplami(uint64_t N, int *toplam)
{
    long long adim = 0;
    *toplam = 0;
    while (N > 0) {
        *toplam += (int)(N % 10);
        N /= 10;
        adim++;
    }
    return adim;
}

static long long asal_mi(uint64_t N, int *asal)
{
    long long adim = 0;
    *asal = N >= 2;
    for (uint64_t b = 2; b * b <= N; b++) {
        adim++;
        if (N % b == 0) {
            *asal = 0;
            break;
        }
    }
    return adim;
}

/* tek satırlı alt küme toplamı DP'si (H13); dönen: güncellenen hücre */
static long long alt_kume_dp(const int *a, int n, long long T, int *var)
{
    unsigned char *ul = calloc((size_t)T + 1, 1);
    long long hucre = 0;
    if (ul == NULL) {
        *var = -1;
        return -1;
    }
    ul[0] = 1;
    for (int i = 0; i < n; i++) {
        for (long long w = T; w >= a[i]; w--) {
            ul[w] = ul[w] || ul[w - a[i]];
            hucre++;
        }
    }
    *var = ul[T];
    free(ul);
    return hucre;
}

int main(void)
{
    const uint64_t asallar[6] = {251u, 65521u, 16777213u, 4294967291u,
                                 1099511627689u, 281474976710597u};
    printf("   b   us_al  basamak  asal_mi (bölme)   alt_kume_dp (hücre)\n");
    for (int k = 0; k < 6; k++) {
        int b = 8 * (k + 1), toplam, asal, var;
        uint64_t N = ((uint64_t)1 << b) - 1, sonuc;
        long long a1 = us_al(3, N, 1000000007u, &sonuc);
        long long a2 = basamak_toplami(N, &toplam);
        long long a3 = asal_mi(asallar[k], &asal);
        printf("  %2d  %6lld  %7lld  %15lld   ", b, a1, a2, a3);
        if (b <= 24) {
            int a[10];
            for (int i = 0; i < 10; i++) {
                a[i] = (int)((N / 10) * (unsigned)(i + 1) / 11) + 1;
            }
            printf("%19lld\n", alt_kume_dp(a, 10, (long long)N, &var));
        } else {
            printf("%19s\n", "bütçe aşıldı");
        }
        if (!asal) {
            printf("  (beklenmedik: %llu asal değil)\n",
                   (unsigned long long)asallar[k]);
        }
    }
    return 0;
}

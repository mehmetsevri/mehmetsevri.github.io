"""H14_A18_gs_yarismasi.py — AP-2 Hafta 14 · Atölye 2 (hakem programı)
Amaç    : Gezgin satıcı yarışması. 50 şehir ortak LCG ile üretilir (tohum
          50, koordinatlar 0..999); her takım kendi sezgiselini yazar ve
          turunu bir dosyaya kaydeder. Bu program turu DOĞRULAR (her şehir
          tam bir kez) ve uzunluğunu hesaplar. Argümansız çalıştırılırsa
          şehirleri ve iki taban çizgisini (en yakın komşu; en yakın komşu
          + ilk iyileştirmeli 2-opt) yazar.
Tur dosyası: 50 şehir indisi (0..49), boşluk ya da satır sonuyla
          ayrılmış; '#' ile başlayan satırlar yorumdur.
Çalıştır: python3 H14_A18_gs_yarismasi.py
          python3 H14_A18_gs_yarismasi.py ../girdiler/H14_A18_ornek_tur.txt
Eşi     : H14_A18_gs_yarismasi.c (aynı çıktı, aynı iletiler)
"""
import math
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402

N = 50
EPS = 1e-9


def sehirleri_uret():
    rastgele_tohum(50)
    x, y = [0] * N, [0] * N
    for i in range(N):
        x[i] = rastgele_aralik(0, 999)
        y[i] = rastgele_aralik(0, 999)
    d = [[math.sqrt((x[i] - x[j]) ** 2 + (y[i] - y[j]) ** 2)
          for j in range(N)] for i in range(N)]
    return x, y, d


def tur_uzunlugu(d, tur):
    t = 0.0
    for k in range(1, N):
        t += d[tur[k - 1]][tur[k]]
    return t + d[tur[N - 1]][tur[0]]


def en_yakin_komsu(d):
    ziyaret = [False] * N
    tur = [0]
    ziyaret[0] = True
    for _ in range(1, N):
        son, sec = tur[-1], -1
        for s in range(N):
            if not ziyaret[s] and (sec == -1 or d[son][s] < d[son][sec]):
                sec = s
        tur.append(sec)
        ziyaret[sec] = True
    return tur


def iki_opt(d, tur):
    iyilestirme, degisti = 0, True
    while degisti:
        degisti = False
        i = 1
        while i < N - 1 and not degisti:
            j = i + 1
            while j < N and not degisti:
                a, b, c = tur[i - 1], tur[i], tur[j]
                e = tur[(j + 1) % N]
                if (d[a][c] + d[b][e]) - (d[a][b] + d[c][e]) < -EPS:
                    tur[i:j + 1] = tur[i:j + 1][::-1]
                    iyilestirme += 1
                    degisti = True
                j += 1
            i += 1
    return iyilestirme


def tur_oku(yol):
    """Dönen: (tur, None) geçerli; (None, ileti) hata"""
    try:
        f = open(yol, encoding="utf-8")
    except OSError:
        return None, f"dosya açılamadı: {yol}"
    goruldu, tur = [False] * N, []
    with f:
        for satir in f:
            if satir.lstrip().startswith("#"):
                continue
            for simge in satir.split():
                try:
                    v = int(simge)
                except ValueError:
                    return None, "geçersiz tur: sayı olmayan simge"
                if not 0 <= v < N:
                    return None, (f"geçersiz tur: {v} şehir indisi değil "
                                  f"(0..{N - 1})")
                if goruldu[v]:
                    return None, f"geçersiz tur: şehir {v} iki kez"
                if len(tur) == N:
                    return None, f"geçersiz tur: {N}'den çok şehir"
                goruldu[v] = True
                tur.append(v)
    if len(tur) != N:
        return None, f"geçersiz tur: {len(tur)} şehir ({N} olmalı)"
    return tur, None


def main():
    x, y, d = sehirleri_uret()
    if len(sys.argv) > 2:
        print(f"kullanım: {sys.argv[0]} [tur_dosyası]")
        sys.exit(2)
    if len(sys.argv) == 2:
        tur, ileti = tur_oku(sys.argv[1])
        if ileti is not None:
            print(ileti)
            sys.exit(1)
        print(f"geçerli tur; uzunluk {tur_uzunlugu(d, tur):.2f}")
        return
    print(f"Gezgin satıcı yarışması: {N} şehir (tohum 50, 0..999)")
    for i in range(N):
        print(f"{i:2d}({x[i]:3d}, {y[i]:3d})", end="\n" if i % 5 == 4
              else "  ")
    tur = en_yakin_komsu(d)
    print(f"taban 1, en yakın komşu (şehir 0'dan): {tur_uzunlugu(d, tur):.2f}")
    iy = iki_opt(d, tur)
    print(f"taban 2, + 2-opt (ilk iyileştirme)   : {tur_uzunlugu(d, tur):.2f}"
          f" ({iy} iyileştirme)")


if __name__ == "__main__":
    main()

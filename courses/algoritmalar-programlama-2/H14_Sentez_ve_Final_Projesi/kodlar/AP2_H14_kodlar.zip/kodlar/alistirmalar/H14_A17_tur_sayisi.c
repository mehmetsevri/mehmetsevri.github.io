/* H14_A17_tur_sayisi.c — AP-2 Hafta 14 · Alıştırma 14.17 (★★)
 * Amaç    : Diller arası okuma: gezgin satıcıda farklı tur sayısı
 *           (n − 1)!/2, 32 bitlik İŞARETSİZ tamsayıyla (önce (n − 1)!,
 *           sonra 2'ye bölme). Eş dosya H14_A17_tur_sayisi.py aynı hesabı
 *           Python tamsayısıyla yapar. Çalıştırmadan: C'nin çıktısı hangi
 *           n'de yanlışlaşır, o satırda ne yazar? İşaretsiz taşma C'de
 *           tanımlı mıdır? uint64_t ile sınır nereye kayar (K01)?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A17_tur_sayisi.c -o H14_A17_tur_sayisi
 * Çalıştır: ./H14_A17_tur_sayisi
 */
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    uint32_t f = 1;
    for (int n = 2; n <= 16; n++) {
        f *= (uint32_t)(n - 1);           /* f = (n − 1)! */
        if (n >= 3) {
            printf("n = %2d: (n-1)!/2 = %u\n", n, (unsigned)(f / 2));
        }
    }
    return 0;
}

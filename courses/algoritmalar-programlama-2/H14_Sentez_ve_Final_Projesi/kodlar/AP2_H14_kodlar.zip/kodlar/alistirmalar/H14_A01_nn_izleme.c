/* H14_A01_nn_izleme.c — AP-2 Hafta 14 · Alıştırma 14.1 (★)
 * Amaç    : Altı şehirde en yakın komşu sezgiseli (Örnek 3'ün kuralı:
 *           ziyaret edilmemiş en yakın şehir; karşılaştırma tamsayı kare
 *           uzaklıkla, eşitlikte KÜÇÜK indis). İki başlangıç şehri: 0 ve 3.
 *           Programı çalıştırmadan iki turu ve uzunluklarını tahmin edin.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A01_nn_izleme.c -lm -o H14_A01_nn_izleme
 * Çalıştır: ./H14_A01_nn_izleme
 */
#include <math.h>
#include <stdio.h>

#define N 6

static const int x[N] = {0, 8, 2, 7, 4, 1};
static const int y[N] = {0, 1, 5, 6, 3, 9};

static int d2(int i, int j)
{
    int dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static double en_yakin_komsu(int bas, int *tur)
{
    int ziyaret[N] = {0};
    double uzunluk = 0.0;
    tur[0] = bas;
    ziyaret[bas] = 1;
    for (int k = 1; k < N; k++) {
        int son = tur[k - 1], sec = -1;
        for (int s = 0; s < N; s++) {
            if (!ziyaret[s] && (sec == -1 || d2(son, s) < d2(son, sec))) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
        uzunluk += sqrt((double)d2(son, sec));
    }
    return uzunluk + sqrt((double)d2(tur[N - 1], bas));   /* dönüş */
}

int main(void)
{
    const int baslangic[2] = {0, 3};
    for (int b = 0; b < 2; b++) {
        int tur[N];
        double u = en_yakin_komsu(baslangic[b], tur);
        printf("başlangıç %d: ", baslangic[b]);
        for (int k = 0; k < N; k++) {
            printf("%d-", tur[k]);
        }
        printf("%d  uzunluk %.2f\n", tur[0], u);
    }
    return 0;
}

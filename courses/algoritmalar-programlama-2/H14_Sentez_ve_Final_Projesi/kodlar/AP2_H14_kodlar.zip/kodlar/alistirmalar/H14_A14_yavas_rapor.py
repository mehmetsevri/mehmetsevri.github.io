"""H14_A14_yavas_rapor.py — AP-2 Hafta 14 · Alıştırma 14.14 (★★★)
Amaç    : Profil ödevi. Ders kayıtlarından rapor üreten, DOĞRU ama YAVAŞ
          bir program (m kayıt: öğrenci no, ders, puan; LCG tohum 14).
          Önce ölçün ve profil çıkarın (cProfile), darboğaz(lar)ı bulun,
          ALGORİTMAYI değiştirin; yeni sürümün stdout'u bununla bayt bayt
          aynı olmalıdır. Adım süreleri stderr'e (bu çalıştırmada).
Profil  : python3 -m cProfile -s tottime H14_A14_yavas_rapor.py
Çalıştır: python3 H14_A14_yavas_rapor.py [m]     (varsayılan m = 6000)
Eşi     : H14_A14_yavas_rapor.c (aynı stdout)
"""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402

DERS_SAYISI = 200


def uret(m):
    rastgele_tohum(14)
    kayit = []
    for _ in range(m):
        no = 220000000 + rastgele_aralik(0, m // 3 - 1)
        ders = rastgele_aralik(0, DERS_SAYISI - 1)
        puan = rastgele_aralik(0, 100)
        kayit.append((no, ders, puan))
    return kayit


def ders_istatistigi(kayit):
    """ders başına kayıt ve puan toplamı: ders listesinde doğrusal arama"""
    kod, say, top = [], [], []
    for no, ders, puan in kayit:
        k = 0
        while k < len(kod) and kod[k] != ders:
            k += 1
        if k == len(kod):
            kod.append(ders)
            say.append(0)
            top.append(0)
        say[k] += 1
        top[k] += puan
    return kod, say, top


def ogrenci_sayilari(kayit):
    """öğrenci başına ders sayısı: öğrenci listesinde doğrusal arama"""
    nolar, say = [], []
    for no, ders, puan in kayit:
        k = 0
        while k < len(nolar) and nolar[k] != no:
            k += 1
        if k == len(nolar):
            nolar.append(no)
            say.append(0)
        say[k] += 1
    return nolar, say


def cift_kayit(kayit):
    """aynı öğrencinin aynı derse birden çok kaydı: eşit kayıt çiftleri"""
    cift = 0
    m = len(kayit)
    for i in range(m):
        for j in range(i + 1, m):
            if kayit[i][0] == kayit[j][0] and kayit[i][1] == kayit[j][1]:
                cift += 1
    return cift


def main():
    m = int(sys.argv[1]) if len(sys.argv) > 1 else 6000
    if not 3 <= m <= 1000000:
        print(f"kullanım: {sys.argv[0]} [m], 3 <= m <= 1000000",
              file=sys.stderr)
        sys.exit(2)
    t = time.process_time()
    kayit = uret(m)
    print(f"üretim       {time.process_time() - t:.3f} s", file=sys.stderr)
    print(f"Ders kayıt raporu (m = {m} kayıt, tohum 14)")

    t = time.process_time()
    kod, say, top = ders_istatistigi(kayit)
    kal = 0
    for k in range(1, len(kod)):
        if say[k] > say[kal] or (say[k] == say[kal] and kod[k] < kod[kal]):
            kal = k
    print(f"dersler      {time.process_time() - t:.3f} s", file=sys.stderr)
    print(f"  1) dersler    : {len(kod)} ders; en kalabalık "
          f"DRS{kod[kal]:03d} ({say[kal]} kayıt)")

    t = time.process_time()
    nolar, osay = ogrenci_sayilari(kayit)
    cok = 0
    for k in range(1, len(nolar)):
        if osay[k] > osay[cok] or (osay[k] == osay[cok] and
                                   nolar[k] < nolar[cok]):
            cok = k
    print(f"öğrenciler   {time.process_time() - t:.3f} s", file=sys.stderr)
    print(f"  2) öğrenciler : {len(nolar)} öğrenci; en çok kayıt "
          f"{nolar[cok]} ({osay[cok]} kayıt)")

    t = time.process_time()
    cift = cift_kayit(kayit)
    print(f"çift kayıt   {time.process_time() - t:.3f} s", file=sys.stderr)
    print(f"  3) çift kayıt : {cift} eşit (öğrenci, ders) çifti")

    t = time.process_time()
    secildi = [False] * len(kod)
    parcalar = []
    for _ in range(5):
        en = -1
        for k in range(len(kod)):
            if secildi[k]:
                continue
            if en == -1:
                en = k
                continue
            sol, sag = top[k] * say[en], top[en] * say[k]
            if sol > sag or (sol == sag and kod[k] < kod[en]):
                en = k
        secildi[en] = True
        parcalar.append(f" DRS{kod[en]:03d} {top[en] / say[en]:.2f}")
    print("  4) en yüksek ortalama:" + "".join(parcalar))
    print(f"ilk 5        {time.process_time() - t:.3f} s", file=sys.stderr)


if __name__ == "__main__":
    main()

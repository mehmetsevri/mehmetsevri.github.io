"""H14_A17_tur_sayisi.py — AP-2 Hafta 14 · Alıştırma 14.17 (★★)
Amaç    : Diller arası okuma: gezgin satıcıda farklı tur sayısı (n − 1)!/2,
          Python tamsayısıyla (önce (n − 1)!, sonra 2'ye bölme). Eş dosya
          H14_A17_tur_sayisi.c aynı hesabı 32 bitlik işaretsiz tamsayıyla
          yapar.
Çalıştır: python3 H14_A17_tur_sayisi.py
"""


def main():
    f = 1
    for n in range(2, 17):
        f *= n - 1                        # f = (n − 1)!
        if n >= 3:
            print(f"n = {n:2d}: (n-1)!/2 = {f // 2}")


if __name__ == "__main__":
    main()

"""H14_A16_esitlik_kirma.py — AP-2 Hafta 14 · Alıştırma 14.16 (★★)
Amaç    : Diller arası okuma: Örnek 2'nin beş şehrinde 24 turun en kısası
          ve en uzunu Python'un min/max fonksiyonlarıyla seçiliyor; eş
          dosya H14_A16_esitlik_kirma.c aynı turları aynı sırayla bir
          döngüde karşılaştırıyor. İki programın çıktısını çalıştırmadan
          yazın: hangi satır farklı çıkar, neden? Matematiksel olarak eşit
          uzunluktaki turlar arasında seçimi ne belirler?
Çalıştır: python3 H14_A16_esitlik_kirma.py
"""
import itertools
import math

X = [0, 6, 1, 5, 3]
Y = [0, 1, 4, 5, 2]


def uzaklik(i, j):
    return math.sqrt((X[i] - X[j]) ** 2 + (Y[i] - Y[j]) ** 2)


def uzunluk(tur):
    t = 0.0
    for k in range(1, len(tur)):
        t += uzaklik(tur[k - 1], tur[k])
    return t + uzaklik(tur[-1], tur[0])


def yaz(etiket, tur):
    print(f"{etiket}: {'-'.join(map(str, tur))}-0  {uzunluk(tur):.2f}")


def main():
    turlar = [(0,) + p for p in itertools.permutations(range(1, 5))]
    yaz("en kısa", min(turlar, key=uzunluk))
    yaz("en uzun", max(turlar, key=uzunluk))


if __name__ == "__main__":
    main()

/* H14_A14_yavas_rapor.c — AP-2 Hafta 14 · Alıştırma 14.14 (★★★)
 * Amaç    : Profil ödevi. Ders kayıtlarından rapor üreten, DOĞRU ama YAVAŞ
 *           bir program (m kayıt: öğrenci no, ders, puan; LCG tohum 14).
 *           Önce ölçün ve profil çıkarın (gprof), darboğaz(lar)ı bulun,
 *           ALGORİTMAYI değiştirin; yeni sürümün stdout'u bununla bayt
 *           bayt aynı olmalıdır. Adım süreleri stderr'e (bu çalıştırmada).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A14_yavas_rapor.c ../c/ortak_rastgele.c \
 *           -o H14_A14_yavas_rapor
 * Profil  : gcc -std=c17 -O2 -g -pg -fno-inline H14_A14_yavas_rapor.c \
 *           ../c/ortak_rastgele.c -o yavas_pg && ./yavas_pg 40000 \
 *           && gprof -b -p yavas_pg gmon.out
 * Çalıştır: ./H14_A14_yavas_rapor [m]     (varsayılan m = 6000)
 * Eşi     : H14_A14_yavas_rapor.py (aynı stdout)
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../c/ortak_rastgele.h"

#define DERS_SAYISI 200

typedef struct {
    int no, ders, puan;
} Kayit;

static Kayit *kayit;
static int m;

static int ders_kod[DERS_SAYISI], ders_say[DERS_SAYISI], ders_adet;
static long long ders_top[DERS_SAYISI];
static int *ogr_no, *ogr_say, ogr_adet;

static double sn(clock_t bas)
{
    return (double)(clock() - bas) / CLOCKS_PER_SEC;
}

static void uret(void)
{
    rastgele_tohum(14);
    for (int i = 0; i < m; i++) {
        kayit[i].no = 220000000 + rastgele_aralik(0, m / 3 - 1);
        kayit[i].ders = rastgele_aralik(0, DERS_SAYISI - 1);
        kayit[i].puan = rastgele_aralik(0, 100);
    }
}

/* 1) ders başına kayıt ve puan toplamı: ders listesinde doğrusal arama */
static void ders_istatistigi(void)
{
    ders_adet = 0;
    for (int i = 0; i < m; i++) {
        int k = 0;
        while (k < ders_adet && ders_kod[k] != kayit[i].ders) {
            k++;
        }
        if (k == ders_adet) {
            ders_kod[k] = kayit[i].ders;
            ders_say[k] = 0;
            ders_top[k] = 0;
            ders_adet++;
        }
        ders_say[k]++;
        ders_top[k] += kayit[i].puan;
    }
}

/* 2) öğrenci başına ders sayısı: öğrenci listesinde doğrusal arama */
static void ogrenci_sayilari(void)
{
    ogr_adet = 0;
    for (int i = 0; i < m; i++) {
        int k = 0;
        while (k < ogr_adet && ogr_no[k] != kayit[i].no) {
            k++;
        }
        if (k == ogr_adet) {
            ogr_no[k] = kayit[i].no;
            ogr_say[k] = 0;
            ogr_adet++;
        }
        ogr_say[k]++;
    }
}

/* 3) aynı öğrencinin aynı derse birden çok kaydı: eşit kayıt çiftleri */
static long long cift_kayit(void)
{
    long long cift = 0;
    for (int i = 0; i < m; i++) {
        for (int j = i + 1; j < m; j++) {
            cift += kayit[i].no == kayit[j].no &&
                    kayit[i].ders == kayit[j].ders;
        }
    }
    return cift;
}

/* a'nın ortalaması b'ninkinden büyük mü (eşitlikte küçük ders kodu)? */
static int once_gelir(int a, int b)
{
    long long sol = ders_top[a] * ders_say[b];
    long long sag = ders_top[b] * ders_say[a];
    return sol > sag || (sol == sag && ders_kod[a] < ders_kod[b]);
}

int main(int argc, char **argv)
{
    m = argc > 1 ? atoi(argv[1]) : 6000;
    if (m < 3 || m > 1000000) {
        fprintf(stderr, "kullanım: %s [m], 3 <= m <= 1000000\n", argv[0]);
        return 2;
    }
    kayit = malloc((size_t)m * sizeof *kayit);
    ogr_no = malloc((size_t)m * sizeof *ogr_no);
    ogr_say = malloc((size_t)m * sizeof *ogr_say);
    if (kayit == NULL || ogr_no == NULL || ogr_say == NULL) {
        fprintf(stderr, "bellek yetersiz\n");
        free(kayit);
        free(ogr_no);
        free(ogr_say);
        return 1;
    }
    clock_t t = clock();
    uret();
    fprintf(stderr, "üretim       %.3f s\n", sn(t));
    printf("Ders kayıt raporu (m = %d kayıt, tohum 14)\n", m);

    t = clock();
    ders_istatistigi();
    int kalabalik = 0;
    for (int k = 1; k < ders_adet; k++) {
        if (ders_say[k] > ders_say[kalabalik] ||
            (ders_say[k] == ders_say[kalabalik] &&
             ders_kod[k] < ders_kod[kalabalik])) {
            kalabalik = k;
        }
    }
    fprintf(stderr, "dersler      %.3f s\n", sn(t));
    printf("  1) dersler    : %d ders; en kalabalık DRS%03d (%d kayıt)\n",
           ders_adet, ders_kod[kalabalik], ders_say[kalabalik]);

    t = clock();
    ogrenci_sayilari();
    int cok = 0;
    for (int k = 1; k < ogr_adet; k++) {
        if (ogr_say[k] > ogr_say[cok] ||
            (ogr_say[k] == ogr_say[cok] && ogr_no[k] < ogr_no[cok])) {
            cok = k;
        }
    }
    fprintf(stderr, "öğrenciler   %.3f s\n", sn(t));
    printf("  2) öğrenciler : %d öğrenci; en çok kayıt %d (%d kayıt)\n",
           ogr_adet, ogr_no[cok], ogr_say[cok]);

    t = clock();
    long long cift = cift_kayit();
    fprintf(stderr, "çift kayıt   %.3f s\n", sn(t));
    printf("  3) çift kayıt : %lld eşit (öğrenci, ders) çifti\n", cift);

    t = clock();
    int secildi[DERS_SAYISI] = {0};
    printf("  4) en yüksek ortalama:");
    for (int r = 0; r < 5; r++) {
        int en = -1;
        for (int k = 0; k < ders_adet; k++) {
            if (!secildi[k] && (en == -1 || once_gelir(k, en))) {
                en = k;
            }
        }
        secildi[en] = 1;
        printf(" DRS%03d %.2f", ders_kod[en],
               (double)ders_top[en] / ders_say[en]);
    }
    printf("\n");
    fprintf(stderr, "ilk 5        %.3f s\n", sn(t));
    free(kayit);
    free(ogr_no);
    free(ogr_say);
    return 0;
}

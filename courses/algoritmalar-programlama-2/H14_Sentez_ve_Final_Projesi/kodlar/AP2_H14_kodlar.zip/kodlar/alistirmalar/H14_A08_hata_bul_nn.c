/* H14_A08_hata_bul_nn.c — AP-2 Hafta 14 · Alıştırma 14.8 (★★)
 * BU DOSYA KASITLI HATA İÇERİR (hatayı bulun; bellek hatası değildir).
 * Amaç    : En yakın komşu turunu kaba kuvvetin bulduğu en iyi turla
 *           karşılaştıran küçük bir test (LCG, tohum 2026, n = 8; Örnek 3'ün
 *           ilk beş örneği). Kâhinin raporu bir şeylerin yanlış olduğunu
 *           söylüyor: hangi satır, neden?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A08_hata_bul_nn.c ../c/ortak_rastgele.c -lm \
 *           -o H14_A08_hata_bul_nn
 * Çalıştır: ./H14_A08_hata_bul_nn
 */
#include <math.h>
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define N 8
#define EPS 1e-9

static int x[N], y[N];
static double d[N][N];

static long long d2(int i, int j)
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static double tur_uzunlugu(const int *tur)
{
    double t = 0.0;
    for (int k = 1; k < N; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t;
}

static void en_yakin_komsu(int *tur)
{
    int ziyaret[N] = {0};
    tur[0] = 0;
    ziyaret[0] = 1;
    for (int k = 1; k < N; k++) {
        int son = tur[k - 1], sec = -1;
        for (int s = 0; s < N; s++) {
            if (!ziyaret[s] && (sec == -1 || d2(son, s) < d2(son, sec))) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
}

/* kâhin: kaba kuvvet (Örnek 2), dönüş kenarı dahil */
static int yol[N], kullanildi[N];
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == N) {
        double toplam = kismi + d[yol[N - 1]][0];
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
        }
        return;
    }
    for (int s = 1; s < N; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

int main(void)
{
    rastgele_tohum(2026);
    printf("örnek  NN uzunluğu  en iyi (kaba kuvvet)    oran\n");
    for (int t = 1; t <= 5; t++) {
        int tur[N];
        for (int i = 0; i < N; i++) {
            x[i] = rastgele_aralik(0, 99);
            y[i] = rastgele_aralik(0, 99);
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                d[i][j] = sqrt((double)d2(i, j));
            }
        }
        en_yakin_komsu(tur);
        yol[0] = 0;
        kullanildi[0] = 1;
        en_iyi = 1e300;
        dene(1, 0.0);
        double nn = tur_uzunlugu(tur);
        printf("  %d     %8.2f          %8.2f       %.4f%s\n", t, nn, en_iyi,
               nn / en_iyi, nn < en_iyi - EPS ? "  <- sezgisel en iyiden kısa?"
                                               : "");
    }
    return 0;
}

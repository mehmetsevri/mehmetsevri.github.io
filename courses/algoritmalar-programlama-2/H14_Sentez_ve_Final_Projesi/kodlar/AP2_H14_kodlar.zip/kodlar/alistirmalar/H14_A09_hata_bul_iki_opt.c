/* H14_A09_hata_bul_iki_opt.c — AP-2 Hafta 14 · Alıştırma 14.9 (★★)
 * BU DOSYA KASITLI HATA İÇERİR (hatayı bulun; bellek hatası değildir).
 * Amaç    : İlk iyileştirmeli 2-opt (Örnek 4'ün kuralı) en yakın komşu
 *           turlarına uygulanıyor (LCG, tohum 2026, n = 8; Örnek 3'ün 100
 *           örneği). Sonra bir DENETİM taraması, bitmiş turda kısaltan bir
 *           2-opt hamlesi kalıp kalmadığına bakıyor. Denetim neden hamle
 *           buluyor? Hatalı satırı bulun, düzeltin; düzeltilmiş sürümde
 *           #24'ün sonucu Örnek 4 ile aynı olmalı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A09_hata_bul_iki_opt.c ../c/ortak_rastgele.c -lm \
 *           -o H14_A09_hata_bul_iki_opt
 * Çalıştır: ./H14_A09_hata_bul_iki_opt
 */
#include <math.h>
#include <stdio.h>

#include "../c/ortak_rastgele.h"

#define N 8
#define ORNEK 100
#define EPS 1e-9

static int x[N], y[N];
static double d[N][N];

static long long d2(int i, int j)
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static double tur_uzunlugu(const int *tur)
{
    double t = 0.0;
    for (int k = 1; k < N; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t + d[tur[N - 1]][tur[0]];
}

static void en_yakin_komsu(int *tur)
{
    int ziyaret[N] = {0};
    tur[0] = 0;
    ziyaret[0] = 1;
    for (int k = 1; k < N; k++) {
        int son = tur[k - 1], sec = -1;
        for (int s = 0; s < N; s++) {
            if (!ziyaret[s] && (sec == -1 || d2(son, s) < d2(son, sec))) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
}

static void ters_cevir(int *tur, int i, int j)
{
    while (i < j) {
        int gecici = tur[i];
        tur[i] = tur[j];
        tur[j] = gecici;
        i++;
        j--;
    }
}

static int iki_opt(int *tur)
{
    int iyilestirme = 0, degisti = 1;
    while (degisti) {
        degisti = 0;
        for (int i = 1; i < N - 1 && !degisti; i++) {
            for (int j = i + 1; j < N - 1 && !degisti; j++) {
                int a = tur[i - 1], b = tur[i], c = tur[j];
                int e = tur[(j + 1) % N];
                double kazanc = (d[a][c] + d[b][e])
                                - (d[a][b] + d[c][e]);
                if (kazanc < -EPS) {
                    ters_cevir(tur, i, j);
                    iyilestirme++;
                    degisti = 1;
                }
            }
        }
    }
    return iyilestirme;
}

/* denetim: bütün (i, j) çiftleri, i = 1..N−2, j = i+1..N−1 */
static int kisaltan_hamle(const int *tur, int *bi, int *bj, double *kaz)
{
    int say = 0;
    for (int i = 1; i < N - 1; i++) {
        for (int j = i + 1; j < N; j++) {
            int a = tur[i - 1], b = tur[i], c = tur[j];
            int e = tur[(j + 1) % N];
            double kazanc = (d[a][c] + d[b][e]) - (d[a][b] + d[c][e]);
            if (kazanc < -EPS) {
                if (say == 0) {
                    *bi = i;
                    *bj = j;
                    *kaz = -kazanc;
                }
                say++;
            }
        }
    }
    return say;
}

int main(void)
{
    int yerel_degil = 0, yazilan = 0;
    rastgele_tohum(2026);
    for (int t = 1; t <= ORNEK; t++) {
        int tur[N], bi = 0, bj = 0;
        double kaz = 0.0;
        for (int i = 0; i < N; i++) {
            x[i] = rastgele_aralik(0, 99);
            y[i] = rastgele_aralik(0, 99);
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                d[i][j] = sqrt((double)d2(i, j));
            }
        }
        en_yakin_komsu(tur);
        int iy = iki_opt(tur);
        int kalan = kisaltan_hamle(tur, &bi, &bj, &kaz);
        yerel_degil += kalan > 0;
        if (t == 24 || (kalan > 0 && yazilan < 3)) {
            yazilan += t != 24;
            printf("#%-3d 2-opt sonrası %7.2f (%d iyileştirme); ", t,
                   tur_uzunlugu(tur), iy);
            if (kalan > 0) {
                printf("denetim: %d kısaltan hamle, ilki (%d, %d) %.2f\n",
                       kalan, bi, bj, kaz);
            } else {
                printf("denetim: kısaltan hamle yok\n");
            }
        }
    }
    printf("denetimde kısaltan hamle kalan örnek: %d / %d\n", yerel_degil,
           ORNEK);
    return 0;
}

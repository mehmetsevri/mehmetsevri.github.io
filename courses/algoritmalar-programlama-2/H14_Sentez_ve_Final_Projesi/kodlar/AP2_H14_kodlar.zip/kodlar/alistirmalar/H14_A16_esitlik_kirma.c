/* H14_A16_esitlik_kirma.c — AP-2 Hafta 14 · Alıştırma 14.16 (★★)
 * Amaç    : Diller arası okuma: Örnek 2'nin beş şehrinde 24 tur sözlük
 *           sırasıyla üretilir (şehir 0 sabit) ve en kısası ile en uzunu
 *           döngüde <= ve >= ile seçilir. Eş dosya
 *           H14_A16_esitlik_kirma.py aynı turları min/max ile seçer.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A16_esitlik_kirma.c -lm -o H14_A16_esitlik_kirma
 * Çalıştır: ./H14_A16_esitlik_kirma
 */
#include <math.h>
#include <stdio.h>
#include <string.h>

#define N 5

static const int X[N] = {0, 6, 1, 5, 3};
static const int Y[N] = {0, 1, 4, 5, 2};
static int tur[N], kullanildi[N], kisa[N], uzun[N];
static double en_kisa = 1e300, en_uzun = -1.0;

static double uzaklik(int i, int j)
{
    return sqrt((double)((X[i] - X[j]) * (X[i] - X[j]) +
                         (Y[i] - Y[j]) * (Y[i] - Y[j])));
}

static double uzunluk(const int *t)
{
    double u = 0.0;
    for (int k = 1; k < N; k++) {
        u += uzaklik(t[k - 1], t[k]);
    }
    return u + uzaklik(t[N - 1], t[0]);
}

static void dene(int k)
{
    if (k == N) {
        double u = uzunluk(tur);
        if (u <= en_kisa) {
            en_kisa = u;
            memcpy(kisa, tur, sizeof tur);
        }
        if (u >= en_uzun) {
            en_uzun = u;
            memcpy(uzun, tur, sizeof tur);
        }
        return;
    }
    for (int s = 1; s < N; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            tur[k] = s;
            dene(k + 1);
            kullanildi[s] = 0;
        }
    }
}

static void yaz(const char *etiket, const int *t)
{
    printf("%s: ", etiket);
    for (int k = 0; k < N; k++) {
        printf("%d-", t[k]);
    }
    printf("0  %.2f\n", uzunluk(t));
}

int main(void)
{
    tur[0] = 0;
    kullanildi[0] = 1;
    dene(1);
    yaz("en kısa", kisa);
    yaz("en uzun", uzun);
    return 0;
}

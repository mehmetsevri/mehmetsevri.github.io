/* H14_A18_gs_yarismasi.c — AP-2 Hafta 14 · Atölye 2 (hakem programı)
 * Amaç    : Gezgin satıcı yarışması. 50 şehir ortak LCG ile üretilir
 *           (tohum 50, koordinatlar 0..999); her takım kendi sezgiselini
 *           yazar ve turunu bir dosyaya kaydeder. Bu program turu
 *           DOĞRULAR (her şehir tam bir kez) ve uzunluğunu hesaplar.
 *           Argümansız çalıştırılırsa şehirleri ve iki taban çizgisini
 *           (en yakın komşu; en yakın komşu + ilk iyileştirmeli 2-opt)
 *           yazar.
 * Tur dosyası: 50 şehir indisi (0..49), boşluk ya da satır sonuyla
 *           ayrılmış; '#' ile başlayan satırlar yorumdur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_A18_gs_yarismasi.c ../c/ortak_rastgele.c -lm \
 *           -o H14_A18_gs_yarismasi
 * Çalıştır: ./H14_A18_gs_yarismasi
 *           ./H14_A18_gs_yarismasi ../girdiler/H14_A18_ornek_tur.txt
 * Eşi     : H14_A18_gs_yarismasi.py (aynı çıktı, aynı iletiler)
 */
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "../c/ortak_rastgele.h"

#define N 50
#define EPS 1e-9

static int x[N], y[N];
static double d[N][N];

static void sehirleri_uret(void)
{
    rastgele_tohum(50);
    for (int i = 0; i < N; i++) {
        x[i] = rastgele_aralik(0, 999);
        y[i] = rastgele_aralik(0, 999);
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            double dx = x[i] - x[j], dy = y[i] - y[j];
            d[i][j] = sqrt(dx * dx + dy * dy);
        }
    }
}

static double tur_uzunlugu(const int *tur)
{
    double t = 0.0;
    for (int k = 1; k < N; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t + d[tur[N - 1]][tur[0]];
}

static void en_yakin_komsu(int *tur)
{
    int ziyaret[N] = {0};
    tur[0] = 0;
    ziyaret[0] = 1;
    for (int k = 1; k < N; k++) {
        int son = tur[k - 1], sec = -1;
        for (int s = 0; s < N; s++) {
            if (!ziyaret[s] && (sec == -1 || d[son][s] < d[son][sec])) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
}

static int iki_opt(int *tur)
{
    int iyilestirme = 0, degisti = 1;
    while (degisti) {
        degisti = 0;
        for (int i = 1; i < N - 1 && !degisti; i++) {
            for (int j = i + 1; j < N && !degisti; j++) {
                int a = tur[i - 1], b = tur[i], c = tur[j];
                int e = tur[(j + 1) % N];
                if ((d[a][c] + d[b][e]) - (d[a][b] + d[c][e]) < -EPS) {
                    for (int p = i, q = j; p < q; p++, q--) {
                        int g = tur[p];
                        tur[p] = tur[q];
                        tur[q] = g;
                    }
                    iyilestirme++;
                    degisti = 1;
                }
            }
        }
    }
    return iyilestirme;
}

/* Dönen: 0 geçerli; 1 biçim/geçerlik hatası (ileti stdout'a) */
static int tur_oku(const char *yol, int *tur)
{
    FILE *f = fopen(yol, "r");
    char satir[1024];
    int adet = 0, goruldu[N] = {0};
    if (f == NULL) {
        printf("dosya açılamadı: %s\n", yol);
        return 1;
    }
    while (fgets(satir, sizeof satir, f) != NULL) {
        char *p = satir;
        while (isspace((unsigned char)*p)) {
            p++;
        }
        if (*p == '#') {
            continue;
        }
        while (*p != '\0') {
            char *son;
            long v = strtol(p, &son, 10);
            if (son == p) {
                if (isspace((unsigned char)*p)) {
                    p++;
                    continue;
                }
                printf("geçersiz tur: sayı olmayan simge\n");
                fclose(f);
                return 1;
            }
            p = son;
            if (v < 0 || v >= N) {
                printf("geçersiz tur: %ld şehir indisi değil (0..%d)\n", v,
                       N - 1);
                fclose(f);
                return 1;
            }
            if (goruldu[v]) {
                printf("geçersiz tur: şehir %ld iki kez\n", v);
                fclose(f);
                return 1;
            }
            if (adet == N) {
                printf("geçersiz tur: %d'den çok şehir\n", N);
                fclose(f);
                return 1;
            }
            goruldu[v] = 1;
            tur[adet++] = (int)v;
        }
    }
    fclose(f);
    if (adet != N) {
        printf("geçersiz tur: %d şehir (%d olmalı)\n", adet, N);
        return 1;
    }
    return 0;
}

int main(int argc, char **argv)
{
    int tur[N];
    sehirleri_uret();
    if (argc > 2) {
        printf("kullanım: %s [tur_dosyası]\n", argv[0]);
        return 2;
    }
    if (argc == 2) {
        if (tur_oku(argv[1], tur) != 0) {
            return 1;
        }
        printf("geçerli tur; uzunluk %.2f\n", tur_uzunlugu(tur));
        return 0;
    }
    printf("Gezgin satıcı yarışması: %d şehir (tohum 50, 0..999)\n", N);
    for (int i = 0; i < N; i++) {
        printf("%2d(%3d, %3d)%s", i, x[i], y[i], i % 5 == 4 ? "\n" : "  ");
    }
    en_yakin_komsu(tur);
    printf("taban 1, en yakın komşu (şehir 0'dan): %.2f\n",
           tur_uzunlugu(tur));
    int iy = iki_opt(tur);
    printf("taban 2, + 2-opt (ilk iyileştirme)   : %.2f (%d iyileştirme)\n",
           tur_uzunlugu(tur), iy);
    return 0;
}

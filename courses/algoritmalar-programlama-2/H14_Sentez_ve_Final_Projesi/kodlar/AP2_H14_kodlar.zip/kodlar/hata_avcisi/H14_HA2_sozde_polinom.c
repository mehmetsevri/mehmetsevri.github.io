/* H14_HA2_sozde_polinom.c — AP-2 Hafta 14 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR
 * Amaç    : 0/1 sırt çantası (H13) için "DP O(n·W), yani polinom; her
 *           girdide hızlı" varsayımı. Bütçe kararı girdi UZUNLUĞUYLA
 *           veriliyor: tahmin = n · b (b = W'nin bit sayısı). Oysa tablo
 *           n·(W + 1) hücredir ve W ≈ 2^b: süre b'ye göre ÜSTELDİR (sözde
 *           polinom). Belirti: tahmin hep "küçük" görünür; gerçek hücre
 *           sayacı b = 8'den 24'e 2^16 kat büyür; b = 40'ta tablo ayrılamaz.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_HA2_sozde_polinom.c ../c/ortak_rastgele.c \
 *           ../c/zamanlayici.c -I../c -o H14_HA2_sozde_polinom
 * Düzeltme: H14_HA2_sozde_polinom_duzeltilmis.c
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define N 20
#define BUTCE 1000000LL                  /* "çalıştırılabilir" iş sınırı */

int main(void)
{
    const int bitler[6] = {8, 12, 16, 20, 24, 40};
    printf("0/1 sırt çantası, n = %d nesne; kapasite W = 2^b - 1\n", N);
    printf("   b  tahmin n·b   karar          gerçek hücre       değer\n");
    for (int t = 0; t < 6; t++) {
        int b = bitler[t];
        long long W = (1LL << b) - 1, w[N];
        int v[N];
        rastgele_tohum((uint64_t)b);
        for (int i = 0; i < N; i++) {
            w[i] = 1 + (long long)(rastgele_kesir() * (double)(W / 4));
            v[i] = rastgele_aralik(1, 100);
        }
        long long tahmin = (long long)N * b;     /* HATA: girdi uzunluğu */
        if (tahmin > BUTCE) {
            printf("  %2d  %10lld   bütçe aşıldı\n", b, tahmin);
            continue;
        }
        int *dp = calloc((size_t)W + 1, sizeof *dp);   /* tablo: W + 1 */
        if (dp == NULL) {
            printf("  %2d  %10lld   DP uygun       HATA: %lld hücrelik tablo "
                   "ayrılamadı\n", b, tahmin, W + 1);
            continue;
        }
        long long hucre = 0;
        double t0 = islemci_sn();
        for (int i = 0; i < N; i++) {
            for (long long c = W; c >= w[i]; c--) {
                hucre++;
                if (dp[c - w[i]] + v[i] > dp[c]) {
                    dp[c] = dp[c - w[i]] + v[i];
                }
            }
        }
        printf("  %2d  %10lld   DP uygun   %16lld  %10d\n", b, tahmin, hucre,
               dp[W]);
        fprintf(stderr, "b = %2d: %.1f ms (işlemci, bu çalıştırmada)\n", b,
                (islemci_sn() - t0) * 1e3);
        free(dp);
    }
    return 0;
}

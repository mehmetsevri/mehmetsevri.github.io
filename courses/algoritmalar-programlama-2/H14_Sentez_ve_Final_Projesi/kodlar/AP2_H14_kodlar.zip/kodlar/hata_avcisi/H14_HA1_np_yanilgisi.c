/* H14_HA1_np_yanilgisi.c — AP-2 Hafta 14 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR
 * Amaç    : Problemleri karmaşıklık sınıfına ayıran küçük bir "rapor"
 *           programı. Hata: "NP, polinom OLMAYAN demektir" yanılgısı koda
 *           dökülmüş: np_mi = !polinom_cozum_biliniyor. Belirti: P'deki
 *           problemler "NP'de değil" çıkar (oysa P ⊆ NP) ve karar
 *           verilemeyen durma problemi "NP'de" görünür.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_HA1_np_yanilgisi.c -o H14_HA1_np_yanilgisi
 * Düzeltme: H14_HA1_np_yanilgisi_duzeltilmis.c
 */
#include <stdio.h>

typedef struct {
    const char *ad;
    int polinom_cozum_biliniyor;    /* bilinen polinom zamanlı algoritma */
    int polinom_dogrulayici_var;    /* "evet" sertifikası polinom zamanda
                                     * doğrulanabilir mi */
    int karar_verilebilir;          /* her girdide duran bir algoritma */
} Problem;

static const Problem PROBLEM[6] = {
    {"Dizi sıralı mı?", 1, 1, 1},
    {"s'den t'ye en çok k kenarlı yol var mı? (BFS)", 1, 1, 1},
    {"Toplamı T olan alt küme var mı?", 0, 1, 1},
    {"Uzunluğu en çok L olan tur var mı? (gezgin satıcı)", 0, 1, 1},
    {"Graf 3 renkle boyanabilir mi?", 0, 1, 1},
    {"Program bu girdide durur mu? (durma problemi)", 0, 0, 0},
};

int main(void)
{
    int p_say = 0, np_say = 0, ikisi = 0;
    printf("Karmaşıklık sınıfı raporu\n");
    for (int i = 0; i < 6; i++) {
        const Problem *p = &PROBLEM[i];
        int p_mi = p->polinom_cozum_biliniyor;
        int np_mi = !p->polinom_cozum_biliniyor;     /* HATA: yanılgı */
        printf("  P: %s  NP: %s  %s\n", p_mi ? "evet " : "hayır",
               np_mi ? "evet " : "hayır", p->ad);
        p_say += p_mi;
        np_say += np_mi;
        ikisi += p_mi && np_mi;
    }
    printf("P'de %d, NP'de %d problem; ikisinde birden %d problem\n", p_say,
           np_say, ikisi);
    return 0;
}

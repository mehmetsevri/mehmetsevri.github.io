/* H14_HA1_np_yanilgisi_duzeltilmis.c — AP-2 Hafta 14 · Hata Avcısı 1
 * Amaç    : Düzeltilmiş sınıflandırma. NP, "evet" yanıtının bir sertifikayla
 *           POLİNOM ZAMANDA DOĞRULANABİLDİĞİ karar problemleridir; P'deki
 *           her problem NP'dedir (sertifika gerekmez: çözüp bakarız). NP-tam
 *           problemler için polinom algoritma BİLİNMİYOR (P = NP açık soru);
 *           durma problemi ise karar verilemez, NP'de değildir. Program
 *           üç doğrulayıcıyı (alt küme, tur, 3-renk) adım sayısıyla çalıştırır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_HA1_np_yanilgisi_duzeltilmis.c \
 *           -o H14_HA1_np_yanilgisi_duzeltilmis
 */
#include <stdio.h>

typedef struct {
    const char *ad;
    int polinom_cozum_biliniyor;
    int polinom_dogrulayici_var;
    int karar_verilebilir;
} Problem;

static const Problem PROBLEM[6] = {
    {"Dizi sıralı mı?", 1, 1, 1},
    {"s'den t'ye en çok k kenarlı yol var mı? (BFS)", 1, 1, 1},
    {"Toplamı T olan alt küme var mı?", 0, 1, 1},
    {"Uzunluğu en çok L olan tur var mı? (gezgin satıcı)", 0, 1, 1},
    {"Graf 3 renkle boyanabilir mi?", 0, 1, 1},
    {"Program bu girdide durur mu? (durma problemi)", 0, 0, 0},
};

static long long adim;

/* Alt küme sertifikası: indisler geçerli, tekrarsız, toplam = T — O(n) */
static int altkume_dogrula(const int *a, int n, const int *s, int k, int T)
{
    int gor[16] = {0}, top = 0;
    for (int i = 0; i < k; i++) {
        adim++;
        if (s[i] < 0 || s[i] >= n || gor[s[i]]) {
            return 0;
        }
        gor[s[i]] = 1;
        top += a[s[i]];
    }
    return top == T;
}

/* Tur sertifikası: 0..n-1'in permütasyonu mu, uzunluk <= L mi — O(n) */
static int tur_dogrula(int n, const int w[][5], const int *t, int L)
{
    int gor[5] = {0}, uz = 0;
    for (int i = 0; i < n; i++) {
        adim++;
        if (t[i] < 0 || t[i] >= n || gor[t[i]]) {
            return 0;
        }
        gor[t[i]] = 1;
        uz += w[t[i]][t[(i + 1) % n]];
    }
    return uz <= L;
}

/* 3-renk sertifikası: her kenarın uçları farklı renkte mi — O(V + E) */
static int renk_dogrula(int E, const int k[][2], const int *renk)
{
    for (int e = 0; e < E; e++) {
        adim++;
        if (renk[k[e][0]] == renk[k[e][1]]) {
            return 0;
        }
    }
    return 1;
}

int main(void)
{
    int p_say = 0, np_say = 0, ikisi = 0, p_np_degil = 0;
    printf("Karmaşıklık sınıfı raporu (düzeltilmiş)\n");
    for (int i = 0; i < 6; i++) {
        const Problem *p = &PROBLEM[i];
        int p_mi = p->polinom_cozum_biliniyor;
        int np_mi = p->polinom_dogrulayici_var;      /* tanım: doğrulama */
        printf("  P: %s  NP: %s  %s%s\n", p_mi ? "evet "
               : (p->karar_verilebilir ? "?    " : "hayır"),
               np_mi ? "evet " : "hayır", p->ad,
               !p->karar_verilebilir ? " — karar verilemez (Turing)"
               : (!p_mi ? " — NP-tam; polinom algoritma bilinmiyor" : ""));
        p_say += p_mi;
        np_say += np_mi;
        ikisi += p_mi && np_mi;
        p_np_degil += p_mi && !np_mi;
    }
    printf("P'de %d, NP'de %d problem; ikisinde birden %d; P'de olup NP'de "
           "olmayan %d (P ⊆ NP)\n", p_say, np_say, ikisi, p_np_degil);
    printf("('?' = polinom algoritma bilinmiyor; bu 'yok' demek değildir: "
           "P = NP sorusu açıktır)\n");

    const int a[6] = {13, 7, 21, 4, 18, 9}, s_iyi[3] = {0, 1, 4},
              s_kotu[3] = {0, 1, 3};
    adim = 0;
    int r1 = altkume_dogrula(a, 6, s_iyi, 3, 38);
    long long a1 = adim;
    adim = 0;
    int r2 = altkume_dogrula(a, 6, s_kotu, 3, 38);
    printf("\nDoğrulayıcılar (sertifika verilince):\n");
    printf("  alt küme, T = 38: {0, 1, 4} %s (%lld adım), {0, 1, 3} %s (%lld "
           "adım)\n", r1 ? "KABUL" : "RED", a1, r2 ? "KABUL" : "RED", adim);
    const int w[5][5] = {{0, 3, 4, 2, 7}, {3, 0, 4, 6, 3}, {4, 4, 0, 5, 8},
                         {2, 6, 5, 0, 6}, {7, 3, 8, 6, 0}};
    const int tur[5] = {0, 3, 2, 1, 4};
    adim = 0;
    int r3 = tur_dogrula(5, w, tur, 21);
    printf("  gezgin satıcı, L = 21: tur 0-3-2-1-4-0 %s (%lld adım)\n",
           r3 ? "KABUL" : "RED", adim);
    const int k[7][2] = {{0, 1}, {0, 2}, {1, 2}, {1, 3}, {2, 4}, {3, 4},
                         {0, 4}};
    const int renk[5] = {0, 1, 2, 0, 1};
    adim = 0;
    int r4 = renk_dogrula(7, k, renk);
    printf("  3-renk, 5 köşe 7 kenar: renkler 0 1 2 0 1 %s (%lld adım)\n",
           r4 ? "KABUL" : "RED", adim);
    return 0;
}

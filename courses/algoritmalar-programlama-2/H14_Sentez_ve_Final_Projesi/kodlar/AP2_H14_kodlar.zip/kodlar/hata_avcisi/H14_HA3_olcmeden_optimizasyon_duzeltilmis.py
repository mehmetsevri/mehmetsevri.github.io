"""H14_HA3_olcmeden_optimizasyon_duzeltilmis.py — AP-2 Hafta 14 · HA 3
Amaç    : Düzeltme: önce ÖLÇ. Program kendi profilini cProfile + pstats ile
          çıkarır (stderr), zamanın en çok geçtiği fonksiyonu bulur ve
          algoritmayı orada değiştirir: tüm çiftler O(n²) yerine sırala +
          komşu grupları O(n log n). Sonuçlar (stdout) iki sürümde aynıdır;
          süreler ve profil stderr'e "bu çalıştırmada" yazılır.
Çalıştır: python3 H14_HA3_olcmeden_optimizasyon_duzeltilmis.py
"""
import cProfile
import io
import os
import pstats
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402
from zamanlayici import islemci_sn                          # noqa: E402

N = 3000


def kayitlari_uret():
    rastgele_tohum(3)
    numara = [220000000 + rastgele_aralik(0, 3 * N) for _ in range(N)]
    notlar = [rastgele_aralik(0, 100) for _ in range(N)]
    return numara, notlar


def ortalama(notlar):
    toplam = 0
    for x in notlar:
        toplam += x
    return toplam / len(notlar)


def yinelenen_ciftler(numara):
    cift = 0
    for i in range(len(numara)):
        for j in range(i + 1, len(numara)):
            if numara[i] == numara[j]:
                cift += 1
    return cift


def yinelenen_siralama(numara):
    """Darboğazın yerinde algoritma değişikliği: O(n log n)"""
    a = sorted(numara)                   # H6'nın kütüphane karşılığı
    cift = 0
    i = 0
    while i < len(a):
        j = i + 1
        while j < len(a) and a[j] == a[i]:
            j += 1
        cift += (j - i) * (j - i - 1) // 2      # grup içi çift
        i = j
    return cift


def isle(yin_fonk):
    numara, notlar = kayitlari_uret()
    return ortalama(notlar), yin_fonk(numara)


def main():
    profil = cProfile.Profile()                  # 1) ölç
    t0 = islemci_sn()
    profil.enable()
    ort1, cift1 = isle(yinelenen_ciftler)
    profil.disable()
    t1 = islemci_sn()
    akim = io.StringIO()
    st = pstats.Stats(profil, stream=akim).strip_dirs().sort_stats("tottime")
    st.print_stats(5)
    en_sicak = max(st.stats.items(), key=lambda kv: kv[1][2])[0][2]
    print(akim.getvalue(), file=sys.stderr)
    print(f"en çok zaman (tottime): {en_sicak} (bu çalıştırmada)",
          file=sys.stderr)
    ort2, cift2 = isle(yinelenen_siralama)       # 2) darboğazı değiştir
    t2 = islemci_sn()
    print(f"n = {N}: ortalama {ort1:.2f}, yinelenen çift {cift1}")
    print(f"sıralamalı sürüm: ortalama {ort2:.2f}, yinelenen çift {cift2}; "
          + ("aynı" if (ort1, cift1) == (ort2, cift2) else "FARKLI"))
    print(f"önce {(t1 - t0) * 1e3:.1f} ms (profil açık), sonra "
          f"{(t2 - t1) * 1e3:.1f} ms; hızlanma {(t1 - t0) / (t2 - t1):.1f} "
          "kat (işlemci, bu çalıştırmada)", file=sys.stderr)


if __name__ == "__main__":
    main()

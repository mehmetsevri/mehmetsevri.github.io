/* H14_HA5_kahinsiz_test_duzeltilmis.c — AP-2 Hafta 14 · Hata Avcısı 5
 * Amaç    : Düzeltme: komşu döngüsü i = 1 .. n−1 (son çift dahil) ve test
 *           paketi KÂHİNLİ: elle testlerin yanında tohumlu rastgele test
 *           (tüm çiftler kâhini) ve sınır durumları (n = 0, 1, 2; hepsi eşit;
 *           yinelenen en büyük değerde) her çalıştırmada koşar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_HA5_kahinsiz_test_duzeltilmis.c ../c/ortak_rastgele.c \
 *           -I../c -o H14_HA5_kahinsiz_test_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS 64

static int kucuk_once(const void *p, const void *q)
{
    int a = *(const int *)p, b = *(const int *)q;
    return (a > b) - (a < b);
}

static int yinelenen_var_hizli(const int *a, int n)
{
    int b[MAKS];
    if (n < 2) {
        return 0;
    }
    memcpy(b, a, (size_t)n * sizeof *b);
    qsort(b, (size_t)n, sizeof *b, kucuk_once);
    for (int i = 1; i < n; i++) {                /* son çift dahil */
        if (b[i - 1] == b[i]) {
            return 1;
        }
    }
    return 0;
}

static int yinelenen_var_kahin(const int *a, int n)
{
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] == a[j]) {
                return 1;
            }
        }
    }
    return 0;
}

int main(void)
{
    const int sinir[5][4] = {{0}, {4}, {4, 4}, {2, 9, 9, 9}, {1, 5, 3, 5}};
    const int boy[5] = {0, 1, 2, 4, 4}, beklenen[5] = {0, 0, 1, 1, 1};
    int gecen = 0;
    for (int t = 0; t < 5; t++) {
        gecen += yinelenen_var_hizli(sinir[t], boy[t]) == beklenen[t];
    }
    printf("sınır durumları (n = 0, 1, 2; üçlü; en büyükte yinelenen): "
           "%d/5 geçti\n", gecen);
    int uyusan = 0, var_say = 0;
    for (int tohum = 1; tohum <= 1000; tohum++) {
        int a[MAKS];
        rastgele_tohum((uint64_t)tohum);
        int n = rastgele_aralik(2, 12);
        rastgele_dizi(a, (size_t)n, 0, 20);
        int k = yinelenen_var_kahin(a, n);
        uyusan += yinelenen_var_hizli(a, n) == k;
        var_say += k;
    }
    printf("kâhinli rastgele test: %d/1000 uyuştu (%d denemede yinelenen "
           "vardı)\n", uyusan, var_say);
    return uyusan == 1000 && gecen == 5 ? 0 : 1;
}

/* H14_HA5_kahinsiz_test.c — AP-2 Hafta 14 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR
 * Amaç    : Final projesinde kâhin testi olmadan "çalışıyor" demek. Hızlı
 *           yinelenen numara denetimi (sırala + komşuları karşılaştır, H6)
 *           elle yazılmış üç testi geçiyor; geliştirici "çalışıyor" diyor.
 *           Hata: komşu döngüsü i = 1 .. n−2; SON çift hiç karşılaştırılmaz.
 *           --kahin: tohumlu rastgele test, tüm çiftler kâhinine (v2.1)
 *           karşı; ilk karşı örneği bulur, küçültür ve 1 ile çıkar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_HA5_kahinsiz_test.c ../c/ortak_rastgele.c -I../c \
 *           -o H14_HA5_kahinsiz_test
 * Çalıştır: ./H14_HA5_kahinsiz_test        ./H14_HA5_kahinsiz_test --kahin
 * Düzeltme: H14_HA5_kahinsiz_test_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define MAKS 64

static int kucuk_once(const void *p, const void *q)
{
    int a = *(const int *)p, b = *(const int *)q;
    return (a > b) - (a < b);
}

/* Hızlı sürüm: kopyayı sırala, komşu eşit mi? (1: yinelenen var) */
static int yinelenen_var_hizli(const int *a, int n)
{
    int b[MAKS];
    memcpy(b, a, (size_t)n * sizeof *b);
    qsort(b, (size_t)n, sizeof *b, kucuk_once);
    for (int i = 1; i < n - 1; i++) {            /* HATA: i < n olmalı */
        if (b[i - 1] == b[i]) {
            return 1;
        }
    }
    return 0;
}

/* Kâhin (v2.1): tüm çiftler — yavaş ama doğruluğu apaçık */
static int yinelenen_var_kahin(const int *a, int n)
{
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] == a[j]) {
                return 1;
            }
        }
    }
    return 0;
}

static void dizi_yaz(const int *a, int n)
{
    printf("[");
    for (int i = 0; i < n; i++) {
        printf(i ? " %d" : "%d", a[i]);
    }
    printf("]");
}

int main(int argc, char *argv[])
{
    const int t1[4] = {7, 3, 9, 3}, t2[5] = {5, 1, 4, 2, 8},
              t3[6] = {6, 6, 2, 9, 4, 1};
    const int *testler[3] = {t1, t2, t3};
    const int boy[3] = {4, 5, 6}, beklenen[3] = {1, 0, 1};
    int gecen = 0;
    for (int t = 0; t < 3; t++) {
        int s = yinelenen_var_hizli(testler[t], boy[t]);
        printf("elle test %d: ", t + 1);
        dizi_yaz(testler[t], boy[t]);
        printf(" -> %d (beklenen %d) %s\n", s, beklenen[t],
               s == beklenen[t] ? "GEÇTİ" : "KALDI");
        gecen += s == beklenen[t];
    }
    printf("%d/3 elle test geçti: \"çalışıyor\"\n", gecen);
    if (argc < 2 || strcmp(argv[1], "--kahin") != 0) {
        return 0;
    }
    printf("\nKâhinli rastgele test (tohum 1..1000; n 2..12; değerler "
           "0..20):\n");
    for (int tohum = 1; tohum <= 1000; tohum++) {
        int a[MAKS];
        rastgele_tohum((uint64_t)tohum);
        int n = rastgele_aralik(2, 12);
        rastgele_dizi(a, (size_t)n, 0, 20);
        int s = yinelenen_var_hizli(a, n), k = yinelenen_var_kahin(a, n);
        if (s != k) {
            printf("  deneme %d (tohum %d, n = %d): ", tohum, tohum, n);
            dizi_yaz(a, n);
            printf(" -> hızlı %d, kâhin %d\n", s, k);
            /* küçült: hata sürdükçe bir öğe at */
            for (int i = 0; i < n;) {
                int b[MAKS], m = 0;
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        b[m++] = a[j];
                    }
                }
                if (m >= 2 && yinelenen_var_hizli(b, m) !=
                              yinelenen_var_kahin(b, m)) {
                    memcpy(a, b, (size_t)m * sizeof *a);
                    n = m;
                } else {
                    i++;
                }
            }
            printf("  küçültülmüş karşı örnek: ");
            dizi_yaz(a, n);
            printf(" -> hızlı %d, kâhin %d\n", yinelenen_var_hizli(a, n),
                   yinelenen_var_kahin(a, n));
            return 1;
        }
    }
    printf("  1000 denemede uyuşmazlık yok\n");
    return 0;
}

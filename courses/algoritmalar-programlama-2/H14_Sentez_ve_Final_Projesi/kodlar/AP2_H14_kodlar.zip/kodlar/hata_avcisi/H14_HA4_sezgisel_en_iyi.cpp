/* H14_HA4_sezgisel_en_iyi.cpp — AP-2 Hafta 14 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR
 * Amaç    : Rota raporu: en yakın komşu sezgiselinin turu "EN KISA TUR"
 *           diye raporlanıyor; hiçbir doğrulama ya da sınır yok. Belirti:
 *           Örnek 3'ün 8 şehirlik en kötü örneğinde (tohum 2026, #24)
 *           rapor 374,96 diyor; kaba kuvvet aynı şehirler için 252,18'lik
 *           bir tur bulur (Örnek 3, bölüm 3): rapor %48,7 uzun.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 -I../cpp \
 *           H14_HA4_sezgisel_en_iyi.cpp -o H14_HA4_sezgisel_en_iyi
 * Düzeltme: H14_HA4_sezgisel_en_iyi_duzeltilmis.cpp
 */
#include <cmath>
#include <cstdio>
#include <vector>

#include "ortak_rastgele.hpp"

static int n;
static std::vector<int> x, y;

static double d(int i, int j)
{
    double dx = x[i] - x[j], dy = y[i] - y[j];
    return std::sqrt(dx * dx + dy * dy);
}

static std::vector<int> en_yakin_komsu()
{
    std::vector<int> tur(1, 0), ziyaret(n, 0);
    ziyaret[0] = 1;
    for (int k = 1; k < n; k++) {
        int son = tur.back(), sec = -1;
        for (int s = 0; s < n; s++) {
            if (!ziyaret[s] && (sec == -1 || d(son, s) < d(son, sec))) {
                sec = s;
            }
        }
        tur.push_back(sec);
        ziyaret[sec] = 1;
    }
    return tur;
}

int main()
{
    rastgele_tohum(2026);
    for (int t = 0; t < 24; t++) {                // Örnek 3'ün #24 örneği
        n = 8;
        x.assign(n, 0);
        y.assign(n, 0);
        for (int i = 0; i < n; i++) {
            x[i] = rastgele_aralik(0, 99);
            y[i] = rastgele_aralik(0, 99);
        }
    }
    std::vector<int> tur = en_yakin_komsu();
    double u = 0.0;
    for (int k = 1; k < n; k++) {
        u += d(tur[k - 1], tur[k]);
    }
    u += d(tur[n - 1], tur[0]);
    std::printf("ROTA RAPORU (%d şehir)\nEN KISA TUR:", n);   // HATA
    for (int s : tur) {
        std::printf(" %d", s);
    }
    std::printf(" %d\nUzunluk: %.2f (en iyi çözüm)\n", tur[0], u);
    return 0;
}

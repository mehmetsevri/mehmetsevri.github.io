"""H14_HA3_olcmeden_optimizasyon.py — AP-2 Hafta 14 · Hata Avcısı 3
BU DOSYA KASITLI HATA İÇERİR
Amaç    : Ölçmeden optimizasyon. Kayıt işleme programı yavaş bulununca
          "ortalama hesabı yavaştır" diye TAHMİN ediliyor ve ortalama
          'hızlandırılıyor' (ortalama_hizli: dörder açılmış döngü).
          Ölçülmediği için asıl darboğaz — O(n²) yinelenen tespiti —
          yerinde kalıyor. Belirti: 'optimizasyondan' sonra toplam süre
          hemen hemen aynı (stderr); profil, zamanın neredeyse tamamının
          yinelenen_ciftler'de geçtiğini gösterir.
Çalıştır: python3 H14_HA3_olcmeden_optimizasyon.py
Profil  : python3 -m cProfile -s tottime H14_HA3_olcmeden_optimizasyon.py
Düzeltme: H14_HA3_olcmeden_optimizasyon_duzeltilmis.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402
from zamanlayici import islemci_sn                          # noqa: E402

N = 3000


def kayitlari_uret():
    rastgele_tohum(3)
    numara = [220000000 + rastgele_aralik(0, 3 * N) for _ in range(N)]
    notlar = [rastgele_aralik(0, 100) for _ in range(N)]
    return numara, notlar


def ortalama(notlar):
    toplam = 0
    for x in notlar:
        toplam += x
    return toplam / len(notlar)


def ortalama_hizli(notlar):
    """'Optimizasyon': döngü dörder açıldı (ölçülmeden yapıldı)"""
    toplam = 0
    i = 0
    n = len(notlar)
    while i + 4 <= n:
        toplam += notlar[i] + notlar[i + 1] + notlar[i + 2] + notlar[i + 3]
        i += 4
    while i < n:
        toplam += notlar[i]
        i += 1
    return toplam / n


def yinelenen_ciftler(numara):
    cift = 0
    for i in range(len(numara)):
        for j in range(i + 1, len(numara)):
            if numara[i] == numara[j]:
                cift += 1
    return cift


def isle(ort_fonk):
    numara, notlar = kayitlari_uret()
    return ort_fonk(notlar), yinelenen_ciftler(numara)


def main():
    t0 = islemci_sn()
    ort1, cift1 = isle(ortalama)
    t1 = islemci_sn()
    ort2, cift2 = isle(ortalama_hizli)               # HATA: ölçmeden
    t2 = islemci_sn()
    print(f"n = {N}: ortalama {ort1:.2f}, yinelenen çift {cift1}")
    print(f"'hızlı' sürüm: ortalama {ort2:.2f}, yinelenen çift {cift2}")
    print(f"önce {(t1 - t0) * 1e3:.1f} ms, sonra {(t2 - t1) * 1e3:.1f} ms; "
          f"hızlanma {(t1 - t0) / (t2 - t1):.2f} kat (işlemci, bu "
          "çalıştırmada)", file=sys.stderr)


if __name__ == "__main__":
    main()

/* H14_HA4_sezgisel_en_iyi_duzeltilmis.cpp — AP-2 Hafta 14 · Hata Avcısı 4
 * Amaç    : Düzeltme: sezgiselin sonucu "sezgisel tur" diye raporlanır ve
 *           ne kadar iyi olduğu ÖLÇÜLÜR: n <= 10'da kaba kuvvet (Örnek 2)
 *           kesin en iyiyi verir, rapor oranı yazar; 2-opt (Örnek 4) turu
 *           iyileştirir. Büyük n'de kesin değer bilinmediğinden rapor
 *           "yaklaşık" der ve yöntemini açıklar.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 -I../cpp \
 *           H14_HA4_sezgisel_en_iyi_duzeltilmis.cpp \
 *           -o H14_HA4_sezgisel_en_iyi_duzeltilmis
 */
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static int n;
static std::vector<int> x, y;

static double d(int i, int j)
{
    double dx = x[i] - x[j], dy = y[i] - y[j];
    return std::sqrt(dx * dx + dy * dy);
}

static double uzunluk(const std::vector<int>& t)
{
    double u = 0.0;
    for (int k = 1; k < n; k++) {
        u += d(t[k - 1], t[k]);
    }
    return u + d(t[n - 1], t[0]);
}

static std::vector<int> en_yakin_komsu()
{
    std::vector<int> tur(1, 0), ziyaret(n, 0);
    ziyaret[0] = 1;
    for (int k = 1; k < n; k++) {
        int son = tur.back(), sec = -1;
        for (int s = 0; s < n; s++) {
            if (!ziyaret[s] && (sec == -1 || d(son, s) < d(son, sec))) {
                sec = s;
            }
        }
        tur.push_back(sec);
        ziyaret[sec] = 1;
    }
    return tur;
}

static void iki_opt(std::vector<int>& t)         // Örnek 4, ilk iyileştirme
{
    bool degisti = true;
    while (degisti) {
        degisti = false;
        for (int i = 1; i < n - 1 && !degisti; i++) {
            for (int j = i + 1; j < n && !degisti; j++) {
                int a = t[i - 1], b = t[i], c = t[j], e = t[(j + 1) % n];
                if ((d(a, c) + d(b, e)) - (d(a, b) + d(c, e)) < -1e-9) {
                    for (int p = i, q = j; p < q; p++, q--) {
                        std::swap(t[p], t[q]);
                    }
                    degisti = true;
                }
            }
        }
    }
}

static std::vector<int> yol, kullanildi;
static double en_iyi;

static void dene(int k, double kismi)            // Örnek 2, kaba kuvvet
{
    if (k == n) {
        en_iyi = std::min(en_iyi, kismi + d(yol[n - 1], 0));
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d(yol[k - 1], s));
            kullanildi[s] = 0;
        }
    }
}

int main()
{
    rastgele_tohum(2026);
    for (int t = 0; t < 24; t++) {                // Örnek 3'ün #24 örneği
        n = 8;
        x.assign(n, 0);
        y.assign(n, 0);
        for (int i = 0; i < n; i++) {
            x[i] = rastgele_aralik(0, 99);
            y[i] = rastgele_aralik(0, 99);
        }
    }
    std::vector<int> tur = en_yakin_komsu();
    double u_nn = uzunluk(tur);
    iki_opt(tur);
    double u_2 = uzunluk(tur);
    std::printf("ROTA RAPORU (%d şehir)\n", n);
    std::printf("Sezgisel tur (en yakın komşu): %.2f — en iyi olduğu "
                "garanti EDİLMEZ\n", u_nn);
    std::printf("2-opt ile iyileştirilmiş tur : %.2f — yerel en iyi\n", u_2);
    if (n <= 10) {
        yol.assign(n, 0);
        kullanildi.assign(n, 0);
        kullanildi[0] = 1;
        en_iyi = 1e300;
        dene(1, 0.0);
        std::printf("Kesin en iyi (kaba kuvvet)   : %.2f\n", en_iyi);
        std::printf("Oranlar: sezgisel/en iyi = %.4f, 2-opt/en iyi = %.4f\n",
                    u_nn / en_iyi, u_2 / en_iyi);
    } else {
        std::printf("n > 10: kesin en iyi hesaplanmadı; tur 'yaklaşık' "
                    "diye raporlanmalıdır\n");
    }
    return 0;
}

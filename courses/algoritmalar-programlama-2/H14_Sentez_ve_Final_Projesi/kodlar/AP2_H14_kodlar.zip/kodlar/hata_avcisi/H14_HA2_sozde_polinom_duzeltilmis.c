/* H14_HA2_sozde_polinom_duzeltilmis.c — AP-2 Hafta 14 · Hata Avcısı 2
 * Amaç    : Düzeltme: DP'nin maliyeti GERÇEK tablo boyutuyla, n·(W + 1)
 *           hücreyle tahmin edilir (W'nin DEĞERİ, bit sayısı değil). Tablo
 *           bütçeyi aşarsa ve n küçükse geri izleme (en çok 2^(n+1) − 1
 *           düğüm, H3) seçilir: sözde polinom DP, W küçükken; üstel ama
 *           W'den bağımsız geri izleme, n küçükken. İkisi de çalışabilen
 *           boyutlarda sonuçlar karşılaştırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_HA2_sozde_polinom_duzeltilmis.c ../c/ortak_rastgele.c \
 *           ../c/zamanlayici.c -I../c -o H14_HA2_sozde_polinom_duzeltilmis
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define N 20
#define DP_BUTCE 50000000LL              /* tablo hücresi */

static long long w[N], W, dugum;
static int v[N], en_iyi;

/* Geri izleme (H3): i. nesneyi al / alma; kapasiteyi aşan dal budanır */
static void geri_izle(int i, long long agirlik, int deger)
{
    dugum++;
    if (agirlik > W) {
        return;
    }
    if (deger > en_iyi) {
        en_iyi = deger;
    }
    if (i == N) {
        return;
    }
    geri_izle(i + 1, agirlik + w[i], deger + v[i]);
    geri_izle(i + 1, agirlik, deger);
}

static int dp_coz(long long *hucre)              /* -1: bellek yok */
{
    int *dp = calloc((size_t)W + 1, sizeof *dp);
    if (dp == NULL) {
        return -1;
    }
    *hucre = 0;
    for (int i = 0; i < N; i++) {
        for (long long c = W; c >= w[i]; c--) {
            (*hucre)++;
            if (dp[c - w[i]] + v[i] > dp[c]) {
                dp[c] = dp[c - w[i]] + v[i];
            }
        }
    }
    int sonuc = dp[W];
    free(dp);
    return sonuc;
}

int main(void)
{
    const int bitler[6] = {8, 12, 16, 20, 24, 40};
    printf("0/1 sırt çantası, n = %d nesne; kapasite W = 2^b - 1\n", N);
    printf("   b         n·(W+1)  2^(n+1)-1  seçim         iş (hücre/düğüm)"
           "   değer  denetim\n");
    for (int t = 0; t < 6; t++) {
        int b = bitler[t];
        W = (1LL << b) - 1;
        rastgele_tohum((uint64_t)b);
        for (int i = 0; i < N; i++) {
            w[i] = 1 + (long long)(rastgele_kesir() * (double)(W / 4));
            v[i] = rastgele_aralik(1, 100);
        }
        long long tablo = (long long)N * (W + 1);   /* DOĞRU maliyet */
        long long agac = (1LL << (N + 1)) - 1;
        double t0 = islemci_sn();
        en_iyi = 0;
        dugum = 0;
        geri_izle(0, 0, 0);
        double t1 = islemci_sn();
        if (tablo <= DP_BUTCE) {
            long long hucre = 0;
            int d = dp_coz(&hucre);
            printf("  %2d  %14lld  %9lld  DP           %16lld  %6d  geri "
                   "izleme %s\n", b, tablo, agac, hucre, d,
                   d == en_iyi ? "aynı" : "FARKLI");
            fprintf(stderr, "b = %2d: DP %.1f ms, geri izleme %.1f ms "
                    "(işlemci, bu çalıştırmada)\n", b,
                    (islemci_sn() - t1) * 1e3, (t1 - t0) * 1e3);
        } else {
            printf("  %2d  %14lld  %9lld  geri izleme  %16lld  %6d  tablo "
                   "bütçeyi aşıyor\n", b, tablo, agac, dugum, en_iyi);
            fprintf(stderr, "b = %2d: geri izleme %.1f ms (işlemci, bu "
                    "çalıştırmada)\n", b, (t1 - t0) * 1e3);
        }
    }
    return 0;
}

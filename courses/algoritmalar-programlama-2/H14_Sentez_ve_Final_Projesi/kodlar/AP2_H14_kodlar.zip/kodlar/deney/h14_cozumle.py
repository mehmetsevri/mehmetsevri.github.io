#!/usr/bin/env python3
"""h14_cozumle.py — AP-2 Hafta 14 · Haftanın Deneyi: dönem kıyaslama
raporunun çözümlemesi. Bütün oranlar, katlar ve kestirimler BURADA, ham
CSV'lerden hesaplanır (elle sayı yok).

Girdi : sonuclar/h14_deney_miniobs.csv, sonuclar/h14_deney_kiyas.csv
        (h14_olcum_calistir.py); Mini-OBS 2 proje ölçümleri
        (--miniobs/v2.X/olcum/*.csv; karşılaştırma için, salt okunur);
        dönemin haftalık deney CSV'leri (--hafta-kok/H??_*/kodlar/deney/
        sonuclar; sentez tablosu için, salt okunur)
Çıktı : sonuclar/h14_ozet_surumler.csv   (a) ilk/son sürüm, ölçüm + kestirim
        sonuclar/h14_ozet_katlar.csv     (a) ilk/son sürüm katları
        sonuclar/h14_ozet_proje.csv      (a) bu ölçüm ↔ proje belgeleri
        sonuclar/h14_ozet_kazanc.csv     (b) algoritmik / derleyici / dil
        sonuclar/h14_ozet_sentez.csv     (c) dönemin deneylerinden bulgular
        sonuclar/h14_ozet.json           hepsi (belge ve sunum için)
Süre  : işlemci zamanı; ortancası 1 ms'nin altındaysa duvar saati (clock()
        1 µs adımlıdır).
Kullanım: python3 h14_cozumle.py --miniobs .../91_Proje_MiniOBS2
          --hafta-kok .../out
"""
import argparse
import csv
import glob
import json
import math
import os
import re
import statistics
import subprocess
import sys

BURASI = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(BURASI, "sonuclar")
MILYON = 1000000


def oku(yol, ayrac=";"):
    with open(yol, encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=ayrac))


def yaz(ad, alanlar, satirlar):
    """';' ayraçlı CSV; ';' içeren alanlar tırnaklanır (csv modülü)"""
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8",
              newline="") as f:
        w = csv.writer(f, delimiter=";", lineterminator="\n")
        w.writerow(alanlar)
        for r in satirlar:
            w.writerow([bicim(r[a]) for a in alanlar])


def bicim(x):
    if isinstance(x, float):
        return f"{x:.6g}" if abs(x) < 1e-3 or abs(x) >= 1e6 else f"{x:.4f}"
    return str(x)


def etkin(r):
    """ms: işlemci zamanı; 1 ms'nin altında duvar saati"""
    isl = float(r["islemci_ms"])
    return isl if isl >= 1.0 else float(r["duvar_ms"])


def egim_ekk(noktalar):
    """log T = a + k·log n doğrusuna en küçük kareler eğimi (bütün noktalar;
    tek bir gürültülü ya da önbellek geçişine düşen nokta kestirimi
    sürüklemesin diye)"""
    xs = [math.log(n) for n, _ in noktalar]
    ys = [math.log(t) for _, t in noktalar]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    return (sum((x - mx) * (y - my) for x, y in zip(xs, ys))
            / sum((x - mx) ** 2 for x in xs))


# ===================================================================== (a)
def bolum_a(M):
    """Sürüm serileri, kestirimler ve katlar"""
    seri = {}
    for r in M:
        if r["derleme"] != "-O2":
            continue
        anahtar = (r["grup"], r["yontem"], r["surum"])
        birim = etkin(r) / int(r["isler"])            # ms / işlem
        seri.setdefault(anahtar, []).append((int(r["n"]), birim, r))
    satirlar = []
    for (grup, yontem, surum), noktalar in seri.items():
        noktalar.sort()
        for n, ms, r in noktalar:
            satirlar.append(dict(grup=grup, yontem=yontem, surum=surum, n=n,
                                 ms=ms, tur="ölçüm", yontem_kestirim="",
                                 egim="", kontrol=r["kontrol"],
                                 sayac=r["sayac"] or r["dugum"],
                                 yineleme=r["yineleme"]))
        if grup in ("yinelenen", "yukleme") and noktalar[-1][0] < MILYON:
            n2, t2, _ = noktalar[-1]
            k = egim_ekk([(n, t) for n, t, _ in noktalar])
            kaba = t2 * (MILYON / n2) ** 2
            egimli = t2 * (MILYON / n2) ** k
            satirlar.append(dict(grup=grup, yontem=yontem, surum=surum,
                                 n=MILYON, ms=kaba, tur="kestirim",
                                 yontem_kestirim=f"kaba: T({n2})·(10^6/"
                                 f"{n2})^2", egim=2.0, kontrol="", sayac="",
                                 yineleme=""))
            satirlar.append(dict(grup=grup, yontem=yontem, surum=surum,
                                 n=MILYON, ms=egimli, tur="kestirim",
                                 yontem_kestirim=f"eğimli: T({n2})·(10^6/"
                                 f"{n2})^k, k = ölçülen noktaların log–log "
                                 "en küçük kareler eğimi", egim=k,
                                 kontrol="", sayac="", yineleme=""))
    yaz("h14_ozet_surumler.csv", ["grup", "yontem", "surum", "n", "ms",
                                  "tur", "yontem_kestirim", "egim",
                                  "kontrol", "sayac", "yineleme"], satirlar)

    def deger_y(yontem_ad, n, tur="ölçüm", kes=None):
        for r in satirlar:
            if (r["yontem"] == yontem_ad and r["n"] == n and r["tur"] == tur
                    and (kes is None or r["yontem_kestirim"].startswith(kes))):
                return r["ms"]
        raise KeyError((yontem_ad, n))

    katlar = []

    def kat(grup, pay_ad, pay, payda_ad, payda, n, tur):
        katlar.append(dict(grup=grup, pay=pay_ad, payda=payda_ad, n=n,
                           pay_ms=pay, payda_ms=payda, kat=pay / payda,
                           tur=tur))

    d6 = deger_y("doğrusal (v1.0)", MILYON)
    i6 = deger_y("ikili", MILYON)
    k6 = deger_y("karma", MILYON)
    kat("arama", "v2.0 doğrusal", d6, "v2.3 ikili", i6, MILYON, "ölçüm")
    kat("arama", "v2.0 doğrusal", d6, "v2.9 karma", k6, MILYON, "ölçüm")
    kat("arama", "v2.3 ikili", i6, "v2.9 karma", k6, MILYON, "ölçüm")
    for n in (100000,):
        c = deger_y("tüm çiftler", n)
        s = deger_y("sıralama", n)
        h = deger_y("karma kümesi", n)
        kat("yinelenen", "v2.1 tüm çiftler", c, "v2.5 sıralama", s, n,
            "ölçüm")
        kat("yinelenen", "v2.1 tüm çiftler", c, "v2.9 karma", h, n, "ölçüm")
        kat("yinelenen", "v2.5 sıralama", s, "v2.9 karma", h, n, "ölçüm")
    for kes in ("kaba", "eğimli"):
        c = deger_y("tüm çiftler", MILYON, "kestirim", kes)
        kat("yinelenen", f"v2.1 tüm çiftler ({kes} kestirim)", c,
            "v2.5 sıralama", deger_y("sıralama", MILYON), MILYON,
            "kestirim")
        kat("yinelenen", f"v2.1 tüm çiftler ({kes} kestirim)", c,
            "v2.9 karma", deger_y("karma kümesi", MILYON), MILYON,
            "kestirim")
    kat("yinelenen", "v2.5 sıralama", deger_y("sıralama", MILYON),
        "v2.9 karma", deger_y("karma kümesi", MILYON), MILYON, "ölçüm")
    for n in (16000, 32000):
        kat("yukleme", "v2.0 (v1.0 yükleyicisi)", deger_y("v1.0 yükleyicisi",
                                                           n),
            "v2.5 toplu", deger_y("toplu (sırala + komşu)", n), n, "ölçüm")
    for kes in ("kaba", "eğimli"):
        kat("yukleme", f"v2.0 ({kes} kestirim)",
            deger_y("v1.0 yükleyicisi", MILYON, "kestirim", kes),
            "v2.5 toplu", deger_y("toplu (sırala + komşu)", MILYON), MILYON,
            "kestirim")
    for n in (20, 35):
        kat("ders_secimi", "geri izleme (v2.2 ağacı)",
            deger_y("geri izleme (v2.2 ağacı)", n), "v2.12 DP",
            deger_y("DP (0/1 sırt çantası)", n), n, "ölçüm")
    yaz("h14_ozet_katlar.csv", ["grup", "pay", "payda", "n", "pay_ms",
                                "payda_ms", "kat", "tur"], katlar)
    return satirlar, katlar


# ============================================== (a) proje belgeleriyle
def proje_karsilastir(M, miniobs):
    def proje(surum, dosya, kosul, sutun="ortanca_ms", bolen=None):
        rows = [r for r in oku(os.path.join(miniobs, surum, "olcum", dosya))
                if kosul(r)]
        if not rows:
            return None
        v = statistics.median(float(r[sutun]) for r in rows)
        return v / float(rows[0][bolen]) if bolen else v

    def bu(surum, islem, n):
        for r in M:
            if (r["surum"] == surum and r["islem"] == islem and
                    int(r["n"]) == n and r["derleme"] == "-O2"):
                return etkin(r) / int(r["isler"])
        return None

    plan = [
        ("v2.0 doğrusal arama (ms/arama)", "v2.0", "arama",
         [10000, 100000, MILYON], "arama.csv",
         lambda n: (lambda r: r["islem"] == "arama" and int(r["n"]) == n),
         None),
        ("v2.3 ikili arama (ms/arama)", "v2.3", "ikili",
         [10000, 100000, MILYON], "arama.csv",
         lambda n: (lambda r: r["islem"] == "ikili" and int(r["n"]) == n),
         None),
        ("v2.9 karma arama (ms/sorgu)", "v2.9", "ara_karma",
         [100000, MILYON], "arama.csv",
         lambda n: (lambda r: r["islem"] == "ara_karma"
                    and int(r["n"]) == n), "sorgu"),
        ("v2.1 tüm çiftler (ms)", "v2.1", "yinelenen", [16000, 32000, 64000],
         "yinelenen.csv",
         lambda n: (lambda r: r["islem"] == "yinelenen" and int(r["n"]) == n
                    and r["yinelenen"] == "0"), None),
        ("v2.5 sırala + komşular (ms)", "v2.5", "yinelenen_siralama",
         [16000, 64000, 100000, MILYON], "yinelenen.csv",
         lambda n: (lambda r: r["islem"] == "yinelenen_siralama"
                    and int(r["n"]) == n and r["yinelenen"] == "0"), None),
        ("v2.9 karma kümesi (ms)", "v2.9", "yin_karma", [100000, MILYON],
         "yinelenen.csv",
         lambda n: (lambda r: r["islem"] == "yin_karma"
                    and int(r["n"]) == n), None),
        ("v2.0 yükleme, v1.0 (ms)", "v2.0", "yukleme", [16000, 32000, 64000],
         "yukleme.csv",
         lambda n: (lambda r: r["islem"] == "yukleme" and int(r["n"]) == n),
         None),
        ("v2.5 toplu yükleme (ms)", "v2.5", "yukleme_toplu",
         [16000, 32000, 100000, MILYON], "yukleme.csv",
         lambda n: (lambda r: r["islem"] == "yukleme_toplu"
                    and int(r["n"]) == n and r["sira"] == "karisik"), None),
        ("v2.12 geri izleme, W = 45 (ms)", "v2.12", "geri", [20, 25, 30, 35],
         "sirt.csv",
         lambda n: (lambda r: r["islem"] == "geri" and int(r["n"]) == n
                    and r["W"] == "45"), None),
        ("v2.12 DP, W = 45 (ms)", "v2.12", "dp", [20, 25, 30, 35],
         "sirt.csv",
         lambda n: (lambda r: r["islem"] == "dp" and int(r["n"]) == n
                    and r["W"] == "45"), None),
    ]
    satirlar = []
    for ad, surum, islem, nler, dosya, kosul, bolen in plan:
        for n in nler:
            p = proje(surum, dosya, kosul(n), bolen=bolen)
            b = bu(surum, islem, n)
            if p is None or b is None:
                continue
            satirlar.append(dict(islem=ad, n=n, bu_olcum_ms=b, proje_ms=p,
                                 oran=b / p))
    yaz("h14_ozet_proje.csv", ["islem", "n", "bu_olcum_ms", "proje_ms",
                               "oran"], satirlar)
    # projenin kendi kestirimi (v2.0/olcum/kestirim.py; salt okunur)
    p = subprocess.run([sys.executable, "-I", os.path.join(
        miniobs, "v2.0", "olcum", "kestirim.py")], capture_output=True,
        text=True)
    m = re.search(r"kestirim n = 1000000:\s+(\d+) s", p.stdout)
    proje_kes = {"v2.0_yukleme_1e6_s": int(m.group(1)) if m else None}
    for r in oku(os.path.join(miniobs, "v2.9", "olcum", "yinelenen.csv")):
        if r["islem"] == "yin_ciftler" and int(r["n"]) == MILYON:
            proje_kes["v2.9_yin_ciftler_1e6_ms"] = float(r["ortanca_ms"])
            proje_kes["v2.9_yin_ciftler_1e6_kestirim"] = r["kestirim"]
    return satirlar, proje_kes


# ===================================================================== (b)
def bolum_b(M, K):
    kaz = []

    def ekle(tur, islem, n, pay_ad, pay, payda_ad, payda, kaynak):
        kaz.append(dict(tur=tur, islem=islem, n=n, pay=pay_ad,
                        payda=payda_ad, pay_ms=pay, payda_ms=payda,
                        kat=pay / payda, kaynak=kaynak))

    def k(cekirdek, n, dil, derleme):
        for r in K:
            if (r["cekirdek"] == cekirdek and int(r["n"]) == n and
                    r["dil"] == dil and r["derleme"] == derleme):
                return etkin(r)
        raise KeyError((cekirdek, n, dil, derleme))

    # algoritmik (C -O2, aynı işlem, aynı n)
    for yavas, hizli, n in (("yin_ciftler", "yin_siralama", 4000),
                            ("yin_ciftler", "yin_karma", 4000),
                            ("yin_siralama", "yin_karma", 100000)):
        ekle("algoritmik", "yinelenen (dizi modeli)", n, yavas,
             k(yavas, n, "C", "-O2"), hizli, k(hizli, n, "C", "-O2"),
             "h14_deney_kiyas.csv")
    for yavas, hizli in (("ara_dogrusal", "ara_ikili"),
                         ("ara_dogrusal", "ara_karma"),
                         ("ara_ikili", "ara_karma")):
        sor = {r["cekirdek"]: int(r["sorgu"]) for r in K}
        ekle("algoritmik", "arama (sorgu başına)", 100000, yavas,
             k(yavas, 100000, "C", "-O2") / sor[yavas], hizli,
             k(hizli, 100000, "C", "-O2") / sor[hizli],
             "h14_deney_kiyas.csv")
    # derleyici (-O0 / -O2) ve dil (Python / C, C++ / C)
    for cekirdek, n in sorted({(r["cekirdek"], int(r["n"])) for r in K},
                              key=lambda t: (t[0], t[1])):
        c2 = k(cekirdek, n, "C", "-O2")
        ekle("derleyici", cekirdek, n, "C -O0", k(cekirdek, n, "C", "-O0"),
             "C -O2", c2, "h14_deney_kiyas.csv")
        ekle("dil", cekirdek, n, "Python", k(cekirdek, n, "Python",
                                            "CPython"), "C -O2", c2,
             "h14_deney_kiyas.csv")
        ekle("dil_cpp", cekirdek, n, "C++ -O2", k(cekirdek, n, "C++", "-O2"),
             "C -O2", c2, "h14_deney_kiyas.csv")
    # Mini-OBS olcer'leri: -O0 / -O2
    o2 = {(r["surum"], r["islem"], int(r["n"])): r for r in M
          if r["derleme"] == "-O2"}
    for r in M:
        if r["derleme"] != "-O0":
            continue
        a = o2[(r["surum"], r["islem"], int(r["n"]))]
        ekle("derleyici_miniobs", f"{r['surum']} {r['islem']}",
             int(r["n"]), "-O0", etkin(r) / int(r["isler"]), "-O2",
             etkin(a) / int(a["isler"]), "h14_deney_miniobs.csv")
    yaz("h14_ozet_kazanc.csv", ["tur", "islem", "n", "pay", "payda",
                                "pay_ms", "payda_ms", "kat", "kaynak"], kaz)
    ozet = {}
    for tur in ("derleyici", "dil", "dil_cpp", "derleyici_miniobs"):
        v = sorted(r["kat"] for r in kaz if r["tur"] == tur)
        ozet[tur] = {"adet": len(v), "en_az": v[0], "ortanca":
                     statistics.median(v), "en_cok": v[-1]}
    return kaz, ozet


# ===================================================================== (c)
def sentez(kok):
    """Her hafta 1–2 bulgu; sayılar CSV'lerden"""
    def S(hafta, ad):
        yol = glob.glob(os.path.join(kok, f"H{hafta:02d}_*", "kodlar",
                                     "deney", "sonuclar", ad))
        return oku(yol[0]), os.path.relpath(yol[0], kok)

    sat = []

    def ekle(h, ne, kuram, sonuc, kaynak):
        sat.append(dict(hafta=f"H{h}", ne=ne, kuram=kuram, sonuc=sonuc,
                        kaynak=kaynak))

    t, y = S(1, "h01_deney_tablo.csv")
    v = {(r["dil"], r["derleme"]): float(r["ortanca_ms"]) for r in t
         if r["n"] == "10000000"}
    ekle(1, "doğrusal toplam, n = 10⁷: dil ve derleme", "Θ(n); dil ve "
         "derleme yalnız sabit çarpanı değiştirir",
         f"Python / C -O2 = {v[('Python', 'CPython')] / v[('C', 'O2')]:.1f} "
         f"kat; C -O0 / C -O2 = {v[('C', 'O0')] / v[('C', 'O2')]:.2f} kat",
         y)
    t, y = S(2, "h02_deney_ozet.csv")
    g = [r for r in t if r["konfig"] == "c_O2"]
    ekle(2, "\"gizemli\" fonksiyonların log–log eğimi (C -O2)",
         "eğim = büyüme üssü (oran testi)",
         "; ".join(f"{r['fonksiyon']}: eğim {float(r['egim_ortak']):.2f} → "
                   f"{r['gercek_sinif']}" for r in g), y)
    t, y = S(3, "h03_deney_olcum.csv")
    d = {r["yontem"]: int(r["dugum"]) for r in t
         if r["N"] == "8" and r["dil"] == "C" and r["derleme"] == "-O2"}
    ekle(3, "8-vezir: budamasız ↔ budamalı düğüm", "budama ağacın büyük "
         "bölümünü keser", f"{d['budamasiz']} ↔ {d['budamali']} düğüm "
         f"({d['budamasiz'] / d['budamali']:.0f} kat az)", y)
    t, y = S(4, "h04_deney_kesisim.csv")
    ks = next(r for r in t if r["dil"] == "C" and r["derleme"] == "-O2" and
              r["karsilastirma"] == "dogrusal/ikili")
    t2, y2 = S(4, "h04_deney_oran.csv")
    o = next(r for r in t2 if r["n"] == "100000")
    ekle(4, "doğrusal ↔ ikili arama", "Θ(n) ↔ Θ(log n); küçük n'de sabitler "
         "baskın", f"kesişim n ≈ {ks['kesisim_n']}; n = 10⁵'te doğrusal / "
         f"ikili = {float(o['c_dogrusal_ikili']):.0f} kat", f"{y}; {y2}")
    t, y = S(5, "h05_deney_oran.csv")

    def son(alg, girdi):
        return [r for r in t if r["dil"] == "C" and r["derleme"] == "-O2"
                and r["algoritma"] == alg and r["girdi"] == girdi][-1]
    a1, a2 = son("araya", "rastgele"), son("araya", "neredeyse")
    ekle(5, "araya ekleme: rastgele ↔ neredeyse sıralı girdi",
         "en kötü/ortalama Θ(n²), neredeyse sıralıda Θ(n) (uyarlanabilir)",
         f"n {a1['n']}→{a1['n2']}: süre oranı {float(a1['sure_orani']):.2f} "
         f"(eğim {float(a1['egim_b']):.2f}) ↔ "
         f"{float(a2['sure_orani']):.2f} (eğim {float(a2['egim_b']):.2f})", y)
    t, y = S(6, "h06_deney_oran.csv")
    b = [r for r in t if r["dil"] == "C" and r["derleme"] == "-O2" and
         r["algoritma"] == "birlestirmeli" and r["girdi"] == "rastgele" and
         r["oran"]]
    b = b[-1]
    ekle(6, "birleştirmeli sıralama, oran testi", "Θ(n log n): T(10n)/T(n) ≈ "
         "10·log(10n)/log n", f"n {b['onceki_n']}→{b['n']}: oran "
         f"{float(b['oran']):.2f} (kuram {float(b['kuram_nlogn']):.2f}; "
         f"karesel olsa {float(b['kuram_n2']):.0f})", y)
    t, y = S(7, "h07_ozet_tablo.csv")
    v7 = {(r["algoritma"], r["girdi"]): (float(r["islemci_ms"]), r["tur"])
          for r in t if r["n"] == "1000000"}
    s7, b7 = v7[("secmeli", "rastgele")], v7[("birlestirmeli", "rastgele")]
    t2, y2 = S(7, "h07_ozet_aralik.csv")
    ar = {r["algoritma"]: float(r["islemci_ms"]) for r in t2
          if r["n"] == "1000000" and r["K"] == "100" and r["dil"] == "C"}
    ekle(7, "n = 10⁶: seçmeli ↔ birleştirmeli; sayma (K = 100) ↔ kütüphane",
         "Θ(n²) ↔ Θ(n log n); Θ(n + K) karşılaştırmasız",
         f"seçmeli {s7[0] / 1000:.0f} s ({s7[1]}) ↔ birleştirmeli "
         f"{b7[0]:.1f} ms; sayma {ar['sayma']:.2f} ms ↔ qsort "
         f"{ar['kutuphane']:.1f} ms", f"{y}; {y2}")
    t, y = S(8, "h08_ozet_dolasma.csv")
    r8 = next(r for r in t if r["dil"] == "c" and r["n"] == "1000000")
    ekle(8, "10⁶ düğüm dolaşma: dizi ↔ bitişik liste ↔ dağınık liste",
         "üçü de Θ(n); fark önbellekte", f"{float(r8['dizi_ns']):.2f} ↔ "
         f"{float(r8['bitisik_ns']):.2f} ↔ {float(r8['karisik_ns']):.1f} "
         f"ns/öğe (dağınık / bitişik = "
         f"{float(r8['karisik_bitisik_orani']):.1f} kat)", y)
    t, y = S(9, "h09_ozet_kat.csv")
    r9 = [r for r in t if r["pay"] == "C -O2 kaydirmali" and
          r["payda"] == "C -O2 dairesel"][-1]
    ekle(9, "kuyruk: kaydırmalı dizi ↔ dairesel tampon", "işlem başına "
         "Θ(n) ↔ Θ(1)", f"n = {r9['n']}: {float(r9['kat']):.0f} kat"
         + (" (kestirim)" if r9["kestirim"] == "evet" else ""), y)
    t, y = S(10, "h10_ozet_yoklama.csv")
    r10 = [r for r in t if r["yapi"] == "dogrusal"]
    en = max(r10, key=lambda r: float(r["alfa"]))
    ekle(10, "doğrusal yoklama: ortalama yoklama ↔ Knuth formülü",
         "başarısız ½(1 + 1/(1−α)²)", f"α = {float(en['alfa']):.2f}: ölçülen "
         f"{float(en['basarisiz_ort']):.2f}, kuram "
         f"{float(en['basarisiz_kuram']):.2f} (sapma "
         f"%{en['basarisiz_sapma_yuzde']}); bütün α'larda en büyük |sapma| "
         f"%{max(abs(float(r['basarisiz_sapma_yuzde'])) for r in r10):.2f}",
         y)
    t, y = S(11, "h11_ozet_temsil.csv")
    r11 = [r for r in t if r["dil"] == "c" and r["yogunluk"] == "seyrek" and
           r["matris_ms"]][-1]
    ekle(11, "seyrek grafta BFS: komşuluk matrisi ↔ listesi", "Θ(V²) ↔ "
         "Θ(V + E)", f"V = {r11['V']}: süre "
         f"{float(r11['matris_liste_sure_kati']):.0f} kat, bellek "
         f"{float(r11['matris_liste_bayt_kati']):.0f} kat", y)
    t, y = S(12, "h12_ozet_birlesim_bul.csv")
    # saf sürüm yalnız küçük n'lerde ölçülmüş: ikisinin de olduğu en büyük n
    nmax = max(int(r["n"]) for r in t if r["dil"] == "c" and
               r["surum"] == "saf")
    u = {r["surum"]: r for r in t if r["dil"] == "c" and int(r["n"]) == nmax}
    ekle(12, "birleşim–bul: saf ↔ rütbe + yol sıkıştırma",
         "saf O(n) ağaç yüksekliği ↔ neredeyse sabit", f"n = {nmax}: "
         f"işlem başına izleme {float(u['saf']['izleme_bolu_islem']):.1f} ↔ "
         f"{float(u['ikisi']['izleme_bolu_islem']):.2f}; ağaç yüksekliği "
         f"{u['saf']['yukseklik']} ↔ {u['ikisi']['yukseklik']}", y)
    t, y = S(13, "h13_ozet_fib.csv")
    r13 = next(r for r in t if r["dil"] == "c" and r["n"] == "35")
    ekle(13, "Fibonacci n = 35: saf özyineleme ↔ memo",
         "Θ(φⁿ) çağrı ↔ Θ(n)", f"çağrı {r13['saf_cagri']} ↔ "
         f"{r13['memo_cagri']}; süre katı saf/memo "
         f"{float(r13['kat_saf_memo']):.0f}", y)
    yaz("h14_ozet_sentez.csv", ["hafta", "ne", "kuram", "sonuc", "kaynak"],
        sat)
    return sat


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--miniobs", required=True)
    ap.add_argument("--hafta-kok", required=True)
    a = ap.parse_args()
    M = oku(os.path.join(SONUC, "h14_deney_miniobs.csv"))
    K = oku(os.path.join(SONUC, "h14_deney_kiyas.csv"))
    surumler, katlar = bolum_a(M)
    proje, proje_kes = proje_karsilastir(M, a.miniobs)
    kazanc, kazanc_ozet = bolum_b(M, K)
    sent = sentez(a.hafta_kok)
    json.dump({"surumler": surumler, "katlar": katlar, "proje": proje,
               "proje_kestirim": proje_kes, "kazanc": kazanc,
               "kazanc_ozet": kazanc_ozet, "sentez": sent},
              open(os.path.join(SONUC, "h14_ozet.json"), "w",
                   encoding="utf-8"), ensure_ascii=False, indent=1)
    for r in katlar:
        print(f"{r['grup']:12} {r['pay']:40} / {r['payda']:16} n = "
              f"{r['n']:8}: {r['kat']:12.1f} kat ({r['tur']})")
    print(json.dumps(kazanc_ozet, ensure_ascii=False))
    print(json.dumps(proje_kes, ensure_ascii=False))
    for r in proje:
        print(f"{r['islem']:34} n = {r['n']:8}: bu {r['bu_olcum_ms']:.6g} ms"
              f" ↔ proje {r['proje_ms']:.6g} ms (oran {r['oran']:.2f})")
    for r in sent:
        print(f"{r['hafta']:4} {r['ne']}: {r['sonuc']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

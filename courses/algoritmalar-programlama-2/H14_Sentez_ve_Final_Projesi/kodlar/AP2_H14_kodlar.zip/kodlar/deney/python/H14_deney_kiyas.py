"""H14_deney_kiyas.py — AP-2 Hafta 14 · Haftanın Deneyi (b)
Amaç    : Kazançların ölçeği: aynı çekirdeği farklı dille ölçmek (C
          sürümüyle aynı algoritmalar, aynı tohumlar, aynı denetim
          toplamları). Örnek 9'un sekiz çekirdeği + Mini-OBS işlemlerinin
          dizi modeli (yinelenen ve arama)
Kullanım: python3 H14_deney_kiyas.py CEKIRDEK N [--tekrar T] [--csv dosya]
          [--etiket E]
Çıktı   : stdout: cekirdek;n;sorgu;kontrol · stderr ve --csv: süreler
"""
import heapq
import os
import sys
from collections import deque

from ortak_rastgele import (rastgele_aralik, rastgele_karistir,
                            rastgele_tohum)
from zamanlayici import islemci_sn, ortanca, zaman_sn

DERECE = 5
SIRT_W = 1000
SORGU_DOGRUSAL = 100
SORGU_HIZLI = 100000

n = 0
sorgu = 0
g1 = []
g2 = []
g3 = []
yrd = []
karma_bit = 1


# ===== Örnek 9'un çekirdekleri (aynı kod, aynı tohumlar) ==============
def arama_hazirla():
    global sorgu
    rastgele_tohum(1)
    for i in range(n):
        g1[i] = 3 * i + 1
        g2[i] = rastgele_aralik(0, 3 * n)
    sorgu = n


def ikili_ara(a, boy, x):
    lo, hi = 0, boy - 1
    while lo <= hi:
        orta = lo + (hi - lo) // 2
        if a[orta] == x:
            return orta
        elif a[orta] < x:
            lo = orta + 1
        else:
            hi = orta - 1
    return -1


def arama_calistir():
    kontrol = 0
    for q in range(sorgu):
        kontrol += ikili_ara(g1, n, g2[q]) + 1
    return kontrol


def siralama_hazirla():
    rastgele_tohum(2)
    for i in range(n):
        g1[i] = rastgele_aralik(0, 1000000)


def siralama_kontrol(a):
    k = 0
    for i in range(n):
        if i > 0 and a[i - 1] > a[i]:
            return -1
        k += (i % 1000 + 1) * a[i]
    return k


def birlestirmeli(a, lo, hi):
    if hi - lo < 2:
        return
    orta = lo + (hi - lo) // 2
    birlestirmeli(a, lo, orta)
    birlestirmeli(a, orta, hi)
    i, j, k = lo, orta, lo
    while i < orta and j < hi:
        if a[i] <= a[j]:
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    while i < orta:
        yrd[k] = a[i]
        i += 1
        k += 1
    while j < hi:
        yrd[k] = a[j]
        j += 1
        k += 1
    a[lo:hi] = yrd[lo:hi]


def birlestirmeli_calistir():
    a = g1[:n]
    birlestirmeli(a, 0, n)
    return siralama_kontrol(a)


def asagi_suz(a, i, boy):
    while True:
        b, s, r = i, 2 * i + 1, 2 * i + 2
        if s < boy and a[s] > a[b]:
            b = s
        if r < boy and a[r] > a[b]:
            b = r
        if b == i:
            return
        a[i], a[b] = a[b], a[i]
        i = b


def obek_calistir():
    a = g1[:n]
    for i in range(n // 2 - 1, -1, -1):
        asagi_suz(a, i, n)
    for son in range(n - 1, 0, -1):
        a[0], a[son] = a[son], a[0]
        asagi_suz(a, 0, son)
    return siralama_kontrol(a)


def bit_kur(kac):
    """2^bit >= 2·kac"""
    global karma_bit
    karma_bit = 1
    while (1 << karma_bit) < 2 * kac:
        karma_bit += 1


def karma_hazirla():
    rastgele_tohum(4)
    for i in range(n):
        g1[i] = rastgele_aralik(0, n)
        g2[i] = rastgele_aralik(0, 2 * n)
    bit_kur(n)


def karma(anahtar):
    return ((anahtar * 2654435769) & 0xFFFFFFFF) >> (32 - karma_bit)


def karma_calistir():
    kap = 1 << karma_bit
    maske = kap - 1
    tablo = [-1] * kap
    farkli = bulunan = yoklama = 0
    for i in range(n):
        h = karma(g1[i])
        yoklama += 1
        while tablo[h] != -1 and tablo[h] != g1[i]:
            h = (h + 1) & maske
            yoklama += 1
        if tablo[h] != g1[i]:
            tablo[h] = g1[i]
            farkli += 1
    for q in range(n):
        h = karma(g2[q])
        yoklama += 1
        while tablo[h] != -1 and tablo[h] != g2[q]:
            h = (h + 1) & maske
            yoklama += 1
        bulunan += tablo[h] == g2[q]
    return farkli + bulunan + yoklama


def graf_hazirla():
    rastgele_tohum(5)
    for u in range(n):
        v = [0] * DERECE
        w = [0] * DERECE
        for k in range(DERECE):
            v[k] = (u + 1) % n if k == 0 else rastgele_aralik(0, n - 1)
            w[k] = rastgele_aralik(1, 100)
        for k in range(1, DERECE):
            tv, tw, j = v[k], w[k], k - 1
            while j >= 0 and (v[j] > tv or (v[j] == tv and w[j] > tw)):
                v[j + 1] = v[j]
                w[j + 1] = w[j]
                j -= 1
            v[j + 1] = tv
            w[j + 1] = tw
        g1[DERECE * u:DERECE * u + DERECE] = v
        g2[DERECE * u:DERECE * u + DERECE] = w


def bfs_calistir():
    uz = [-1] * n
    kuyruk = deque([0])
    kontrol = 0
    uz[0] = 0
    while kuyruk:
        u = kuyruk.popleft()
        kontrol += uz[u] + 1
        for k in range(DERECE * u, DERECE * u + DERECE):
            if uz[g1[k]] == -1:
                uz[g1[k]] = uz[u] + 1
                kuyruk.append(g1[k])
    return kontrol


def dijkstra_calistir():
    obek = [(0, 0)]
    uz = [-1] * n
    uz[0] = 0
    kontrol = 0
    while obek:
        d, u = heapq.heappop(obek)
        if d > uz[u]:
            continue
        kontrol += d
        for k in range(DERECE * u, DERECE * u + DERECE):
            v = g1[k]
            yeni = d + g2[k]
            if uz[v] == -1 or yeni < uz[v]:
                uz[v] = yeni
                heapq.heappush(obek, (yeni, v))
    return kontrol


def lcs_hazirla():
    rastgele_tohum(7)
    for i in range(2 * n):
        g1[i] = ord("ACGT"[rastgele_aralik(0, 3)])


def lcs_calistir():
    onceki = [0] * (n + 1)
    simdi = [0] * (n + 1)
    a = g1[:n]
    b = g1[n:2 * n]
    for i in range(1, n + 1):
        simdi[0] = 0
        for j in range(1, n + 1):
            if a[i - 1] == b[j - 1]:
                simdi[j] = onceki[j - 1] + 1
            else:
                simdi[j] = (onceki[j] if onceki[j] >= simdi[j - 1]
                            else simdi[j - 1])
        onceki, simdi = simdi, onceki
    return onceki[n]


def sirt_hazirla():
    rastgele_tohum(8)
    for i in range(n):
        g1[i] = rastgele_aralik(1, 50)
        g2[i] = rastgele_aralik(1, 100)


def sirt_calistir():
    dp = [0] * (SIRT_W + 1)
    for i in range(n):
        w, v = g1[i], g2[i]
        for c in range(SIRT_W, w - 1, -1):
            if dp[c - w] + v > dp[c]:
                dp[c] = dp[c - w] + v
    return dp[SIRT_W]


# ===== Mini-OBS işlemlerinin dizi modeli ==============================
def yin_hazirla():
    rastgele_tohum(8)
    a = [220000000 + i for i in range(n)]
    rastgele_karistir(a)
    for i in range(1, n):
        if rastgele_aralik(0, 99) == 0:
            a[i] = a[rastgele_aralik(0, i - 1)]
    g1[:n] = a
    bit_kur(n)


def yin_ciftler_calistir():
    """v2.1: Θ(n²)"""
    cift = 0
    for i in range(n):
        x = g1[i]
        for j in range(i + 1, n):
            cift += x == g1[j]
    return cift


def yin_siralama_calistir():
    """v2.5: Θ(n log n)"""
    cift = 0
    a = g1[:n]
    birlestirmeli(a, 0, n)
    i = 0
    while i < n:
        j = i + 1
        while j < n and a[j] == a[i]:
            j += 1
        cift += (j - i) * (j - i - 1) // 2
        i = j
    return cift


def yin_karma_calistir():
    """v2.9: ortalama Θ(n)"""
    kap = 1 << karma_bit
    maske = kap - 1
    anahtar = [-1] * kap
    adet = [0] * kap
    cift = 0
    for i in range(n):
        x = g1[i]
        h = karma(x)
        while anahtar[h] != -1 and anahtar[h] != x:
            h = (h + 1) & maske
        anahtar[h] = x
        cift += adet[h]
        adet[h] += 1
    return cift


def ara_hazirla(kac_sorgu):
    global sorgu, yrd
    rastgele_tohum(9)
    a = [0] * n
    for i in range(n):
        a[i] = 220000000 + 2 * i
        g3[i] = a[i]
    rastgele_karistir(a)
    g1[:n] = a
    sorgu = kac_sorgu
    for q in range(sorgu):
        g2[q] = 220000000 + rastgele_aralik(0, 2 * n - 1)
    bit_kur(n)
    kap = 1 << karma_bit
    yrd = [-1] * kap
    for i in range(n):
        h = karma(g1[i])
        while yrd[h] != -1:
            h = (h + 1) & (kap - 1)
        yrd[h] = i


def ara_dogrusal_hazirla():
    ara_hazirla(SORGU_DOGRUSAL)


def ara_hizli_hazirla():
    ara_hazirla(SORGU_HIZLI)


def ara_dogrusal_calistir():
    """v1.0/v2.0: Θ(n)"""
    kontrol = 0
    for q in range(sorgu):
        x = g2[q]
        k = -1
        for i in range(n):
            if g1[i] == x:
                k = i
                break
        kontrol += 0 if k == -1 else (g1[k] - 220000000) // 2 + 1
    return kontrol


def ara_ikili_calistir():
    """v2.3: Θ(log n)"""
    kontrol = 0
    for q in range(sorgu):
        kontrol += ikili_ara(g3, n, g2[q]) + 1
    return kontrol


def ara_karma_calistir():
    """v2.9: ortalama Θ(1)"""
    kontrol = 0
    maske = (1 << karma_bit) - 1
    for q in range(sorgu):
        x = g2[q]
        h = karma(x)
        while yrd[h] != -1 and g1[yrd[h]] != x:
            h = (h + 1) & maske
        kontrol += 0 if yrd[h] == -1 else (x - 220000000) // 2 + 1
    return kontrol


CEKIRDEK = {
    "ikili_arama": (arama_hazirla, arama_calistir),
    "birlestirmeli": (siralama_hazirla, birlestirmeli_calistir),
    "obek_siralama": (siralama_hazirla, obek_calistir),
    "karma_tablosu": (karma_hazirla, karma_calistir),
    "bfs": (graf_hazirla, bfs_calistir),
    "dijkstra": (graf_hazirla, dijkstra_calistir),
    "lcs": (lcs_hazirla, lcs_calistir),
    "sirt_cantasi": (sirt_hazirla, sirt_calistir),
    "yin_ciftler": (yin_hazirla, yin_ciftler_calistir),
    "yin_siralama": (yin_hazirla, yin_siralama_calistir),
    "yin_karma": (yin_hazirla, yin_karma_calistir),
    "ara_dogrusal": (ara_dogrusal_hazirla, ara_dogrusal_calistir),
    "ara_ikili": (ara_hizli_hazirla, ara_ikili_calistir),
    "ara_karma": (ara_hizli_hazirla, ara_karma_calistir),
}


def kullanim():
    print(f"Kullanım: {sys.argv[0]} CEKIRDEK N [--tekrar T] [--csv dosya] "
          "[--etiket E]", file=sys.stderr)
    return 2


def main():
    global n, sorgu, g1, g2, g3, yrd
    a = sys.argv
    if len(a) < 3 or a[1] not in CEKIRDEK or len(a) % 2 == 0:
        return kullanim()
    try:
        v = int(a[2])
    except ValueError:
        return kullanim()
    tekrar, csv, etiket = 5, None, "-"
    for i in range(3, len(a) - 1, 2):
        if a[i] == "--tekrar":
            tekrar = int(a[i + 1])
        elif a[i] == "--csv":
            csv = a[i + 1]
        elif a[i] == "--etiket":
            etiket = a[i + 1]
        else:
            return kullanim()
    if v < 2 or v > 20000000 or tekrar < 1 or tekrar > 101:
        return kullanim()
    n = v
    sorgu = 0
    boyut = DERECE * n + 4 * n + SORGU_HIZLI + SIRT_W + 16
    g1 = [0] * boyut
    g2 = [0] * boyut
    g3 = [0] * boyut
    yrd = [0] * boyut
    hazirla, calistir = CEKIRDEK[a[1]]
    hazirla()
    kontrol = calistir()                         # ısınma + sonuç
    islemci = []
    duvar = []
    for _ in range(tekrar):
        w0 = zaman_sn()
        t0 = islemci_sn()
        k2 = calistir()
        islemci.append(islemci_sn() - t0)
        duvar.append(zaman_sn() - w0)
        if k2 != kontrol:
            kontrol = -2
    i_ms = ortanca(islemci) * 1e3
    d_ms = ortanca(duvar) * 1e3
    print(f"{a[1]};{n};{sorgu};{kontrol}")
    print(f"{a[1]} n = {n}: işlemci {i_ms:.3f} ms, duvar {d_ms:.3f} ms "
          f"(ortanca, {tekrar} tekrar; bu çalıştırmada)", file=sys.stderr)
    if csv is not None:
        bos = not os.path.exists(csv) or os.path.getsize(csv) == 0
        with open(csv, "a", encoding="utf-8") as f:
            if bos:
                f.write("cekirdek;n;sorgu;dil;derleme;tekrar;islemci_ms;"
                        "duvar_ms;kontrol\n")
            f.write(f"{a[1]};{n};{sorgu};Python;{etiket};{tekrar};"
                    f"{i_ms:.6f};{d_ms:.6f};{kontrol}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: Örnek 9'daki gibi (sorted, set/dict, heapq, ...).

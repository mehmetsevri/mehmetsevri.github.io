/* H14_deney_kiyas.cpp — AP-2 Hafta 14 · Haftanın Deneyi (b)
 * Amaç    : Kazançların ölçeği: aynı çekirdeği farklı derlemeyle ve
 *           farklı dille ölçmek (C sürümüyle aynı algoritmalar, aynı
 *           tohumlar, aynı denetim toplamları). Örnek 9'un sekiz çekirdeği
 *           + Mini-OBS işlemlerinin dizi modeli (yinelenen ve arama)
 * Kullanım: ./H14_deney_kiyas CEKIRDEK N [--tekrar T] [--csv dosya]
 *                             [--etiket E]
 * Çıktı   : stdout: cekirdek;n;sorgu;kontrol · stderr ve --csv: süreler
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_deney_kiyas.cpp -o H14_deney_kiyas
 */
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <queue>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

constexpr int DERECE = 5;
constexpr int SIRT_W = 1000;
constexpr int SORGU_DOGRUSAL = 100;
constexpr int SORGU_HIZLI = 100000;

static int n, sorgu;
static std::vector<int> g1, g2, g3, is, yrd;

// ===== Örnek 9'un çekirdekleri (aynı kod, aynı tohumlar) ==============
static void arama_hazirla()
{
    rastgele_tohum(1);
    for (int i = 0; i < n; i++) {
        g1[i] = 3 * i + 1;
        g2[i] = rastgele_aralik(0, 3 * n);
    }
    sorgu = n;
}

static long long ikili_ara(const std::vector<int>& a, int boy, int x)
{
    int lo = 0, hi = boy - 1;
    while (lo <= hi) {
        int orta = lo + (hi - lo) / 2;
        if (a[orta] == x) {
            return orta;
        } else if (a[orta] < x) {
            lo = orta + 1;
        } else {
            hi = orta - 1;
        }
    }
    return -1;
}

static long long arama_calistir()
{
    long long kontrol = 0;
    for (int q = 0; q < sorgu; q++) {
        kontrol += ikili_ara(g1, n, g2[q]) + 1;
    }
    return kontrol;
}

static void siralama_hazirla()
{
    rastgele_tohum(2);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(0, 1000000);
    }
}

static long long siralama_kontrol(const std::vector<int>& a)
{
    long long k = 0;
    for (int i = 0; i < n; i++) {
        if (i > 0 && a[i - 1] > a[i]) {
            return -1;
        }
        k += static_cast<long long>(i % 1000 + 1) * a[i];
    }
    return k;
}

static void birlestirmeli(std::vector<int>& a, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(a, lo, orta);
    birlestirmeli(a, orta, hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        yrd[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i < orta) {
        yrd[k++] = a[i++];
    }
    while (j < hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k < hi; k++) {
        a[k] = yrd[k];
    }
}

static long long birlestirmeli_calistir()
{
    std::copy(g1.begin(), g1.begin() + n, is.begin());
    birlestirmeli(is, 0, n);
    return siralama_kontrol(is);
}

static void asagi_suz(std::vector<int>& a, int i, int boy)
{
    for (;;) {
        int b = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < boy && a[s] > a[b]) {
            b = s;
        }
        if (r < boy && a[r] > a[b]) {
            b = r;
        }
        if (b == i) {
            return;
        }
        std::swap(a[i], a[b]);
        i = b;
    }
}

static long long obek_calistir()
{
    std::copy(g1.begin(), g1.begin() + n, is.begin());
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(is, i, n);
    }
    for (int son = n - 1; son > 0; son--) {
        std::swap(is[0], is[son]);
        asagi_suz(is, 0, son);
    }
    return siralama_kontrol(is);
}

static int karma_bit;

static void bit_kur(int kac)                     // 2^bit >= 2·kac
{
    karma_bit = 1;
    while ((1 << karma_bit) < 2 * kac) {
        karma_bit++;
    }
}

static void karma_hazirla()
{
    rastgele_tohum(4);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(0, n);
        g2[i] = rastgele_aralik(0, 2 * n);
    }
    bit_kur(n);
}

static std::uint32_t karma(int anahtar)
{
    return static_cast<std::uint32_t>(static_cast<std::uint32_t>(anahtar) *
                                      2654435769u) >> (32 - karma_bit);
}

static long long karma_calistir()
{
    const int kap = 1 << karma_bit;
    const std::uint32_t maske = static_cast<std::uint32_t>(kap - 1);
    long long farkli = 0, bulunan = 0, yoklama = 0;
    std::fill(is.begin(), is.begin() + kap, -1);
    for (int i = 0; i < n; i++) {
        std::uint32_t h = karma(g1[i]);
        yoklama++;
        while (is[h] != -1 && is[h] != g1[i]) {
            h = (h + 1) & maske;
            yoklama++;
        }
        if (is[h] != g1[i]) {
            is[h] = g1[i];
            farkli++;
        }
    }
    for (int q = 0; q < n; q++) {
        std::uint32_t h = karma(g2[q]);
        yoklama++;
        while (is[h] != -1 && is[h] != g2[q]) {
            h = (h + 1) & maske;
            yoklama++;
        }
        bulunan += is[h] == g2[q];
    }
    return farkli + bulunan + yoklama;
}

static void graf_hazirla()
{
    rastgele_tohum(5);
    for (int u = 0; u < n; u++) {
        int* v = &g1[DERECE * u];
        int* w = &g2[DERECE * u];
        for (int k = 0; k < DERECE; k++) {
            v[k] = k == 0 ? (u + 1) % n : rastgele_aralik(0, n - 1);
            w[k] = rastgele_aralik(1, 100);
        }
        for (int k = 1; k < DERECE; k++) {
            int tv = v[k], tw = w[k], j = k - 1;
            while (j >= 0 && (v[j] > tv || (v[j] == tv && w[j] > tw))) {
                v[j + 1] = v[j];
                w[j + 1] = w[j];
                j--;
            }
            v[j + 1] = tv;
            w[j + 1] = tw;
        }
    }
}

static long long bfs_calistir()
{
    std::vector<int> uz(n, -1);
    std::queue<int> kuyruk;
    long long kontrol = 0;
    uz[0] = 0;
    kuyruk.push(0);
    while (!kuyruk.empty()) {
        int u = kuyruk.front();
        kuyruk.pop();
        kontrol += uz[u] + 1;
        for (int k = DERECE * u; k < DERECE * u + DERECE; k++) {
            if (uz[g1[k]] == -1) {
                uz[g1[k]] = uz[u] + 1;
                kuyruk.push(g1[k]);
            }
        }
    }
    return kontrol;
}

static long long dijkstra_calistir()
{
    using Oge = std::pair<long long, int>;
    std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>> obek;
    std::vector<long long> uz(n, -1);
    uz[0] = 0;
    obek.push({0, 0});
    long long kontrol = 0;
    while (!obek.empty()) {
        Oge en = obek.top();
        obek.pop();
        if (en.first > uz[en.second]) {
            continue;
        }
        kontrol += en.first;
        for (int k = DERECE * en.second; k < DERECE * en.second + DERECE;
             k++) {
            int v = g1[k];
            long long yeni = en.first + g2[k];
            if (uz[v] == -1 || yeni < uz[v]) {
                uz[v] = yeni;
                obek.push({yeni, v});
            }
        }
    }
    return kontrol;
}

static void lcs_hazirla()
{
    rastgele_tohum(7);
    for (int i = 0; i < 2 * n; i++) {
        g1[i] = "ACGT"[rastgele_aralik(0, 3)];
    }
}

static long long lcs_calistir()
{
    std::vector<int> onceki(n + 1, 0), simdi(n + 1, 0);
    const int* a = &g1[0];
    const int* b = &g1[n];
    for (int i = 1; i <= n; i++) {
        simdi[0] = 0;
        for (int j = 1; j <= n; j++) {
            if (a[i - 1] == b[j - 1]) {
                simdi[j] = onceki[j - 1] + 1;
            } else {
                simdi[j] = onceki[j] >= simdi[j - 1] ? onceki[j]
                                                       : simdi[j - 1];
            }
        }
        std::swap(onceki, simdi);
    }
    return onceki[n];
}

static void sirt_hazirla()
{
    rastgele_tohum(8);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(1, 50);
        g2[i] = rastgele_aralik(1, 100);
    }
}

static long long sirt_calistir()
{
    std::vector<int> dp(SIRT_W + 1, 0);
    for (int i = 0; i < n; i++) {
        for (int c = SIRT_W; c >= g1[i]; c--) {
            if (dp[c - g1[i]] + g2[i] > dp[c]) {
                dp[c] = dp[c - g1[i]] + g2[i];
            }
        }
    }
    return dp[SIRT_W];
}

// ===== Mini-OBS işlemlerinin dizi modeli ==============================
static void yin_hazirla()
{
    rastgele_tohum(8);
    std::vector<int> a(n);
    for (int i = 0; i < n; i++) {
        a[i] = 220000000 + i;
    }
    rastgele_karistir(a);
    for (int i = 1; i < n; i++) {
        if (rastgele_aralik(0, 99) == 0) {
            a[i] = a[rastgele_aralik(0, i - 1)];
        }
    }
    std::copy(a.begin(), a.end(), g1.begin());
    bit_kur(n);
}

static long long yin_ciftler_calistir()           // v2.1: Θ(n²)
{
    long long cift = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            cift += g1[i] == g1[j];
        }
    }
    return cift;
}

static long long yin_siralama_calistir()          // v2.5: Θ(n log n)
{
    long long cift = 0;
    std::copy(g1.begin(), g1.begin() + n, is.begin());
    birlestirmeli(is, 0, n);
    for (int i = 0, j; i < n; i = j) {
        for (j = i + 1; j < n && is[j] == is[i]; j++) {
        }
        cift += static_cast<long long>(j - i) * (j - i - 1) / 2;
    }
    return cift;
}

static long long yin_karma_calistir()             // v2.9: ort. Θ(n)
{
    const int kap = 1 << karma_bit;
    const std::uint32_t maske = static_cast<std::uint32_t>(kap - 1);
    long long cift = 0;
    std::fill(is.begin(), is.begin() + kap, -1);
    std::fill(yrd.begin(), yrd.begin() + kap, 0);
    for (int i = 0; i < n; i++) {
        std::uint32_t h = karma(g1[i]);
        while (is[h] != -1 && is[h] != g1[i]) {
            h = (h + 1) & maske;
        }
        is[h] = g1[i];
        cift += yrd[h]++;
    }
    return cift;
}

static void ara_hazirla(int kac_sorgu)
{
    rastgele_tohum(9);
    std::vector<int> a(n);
    for (int i = 0; i < n; i++) {
        a[i] = 220000000 + 2 * i;
        g3[i] = a[i];
    }
    rastgele_karistir(a);
    std::copy(a.begin(), a.end(), g1.begin());
    sorgu = kac_sorgu;
    for (int q = 0; q < sorgu; q++) {
        g2[q] = 220000000 + rastgele_aralik(0, 2 * n - 1);
    }
    bit_kur(n);
    const int kap = 1 << karma_bit;
    std::fill(yrd.begin(), yrd.begin() + kap, -1);
    for (int i = 0; i < n; i++) {
        std::uint32_t h = karma(g1[i]);
        while (yrd[h] != -1) {
            h = (h + 1) & static_cast<std::uint32_t>(kap - 1);
        }
        yrd[h] = i;
    }
}

static void ara_dogrusal_hazirla()
{
    ara_hazirla(SORGU_DOGRUSAL);
}

static void ara_hizli_hazirla()
{
    ara_hazirla(SORGU_HIZLI);
}

static long long ara_dogrusal_calistir()          // v1.0/v2.0: Θ(n)
{
    long long kontrol = 0;
    for (int q = 0; q < sorgu; q++) {
        int k = -1;
        for (int i = 0; i < n; i++) {
            if (g1[i] == g2[q]) {
                k = i;
                break;
            }
        }
        kontrol += k == -1 ? 0 : (g1[k] - 220000000) / 2 + 1;
    }
    return kontrol;
}

static long long ara_ikili_calistir()             // v2.3: Θ(log n)
{
    long long kontrol = 0;
    for (int q = 0; q < sorgu; q++) {
        kontrol += ikili_ara(g3, n, g2[q]) + 1;
    }
    return kontrol;
}

static long long ara_karma_calistir()             // v2.9: ort. Θ(1)
{
    long long kontrol = 0;
    const std::uint32_t maske = (1u << karma_bit) - 1;
    for (int q = 0; q < sorgu; q++) {
        std::uint32_t h = karma(g2[q]);
        while (yrd[h] != -1 && g1[yrd[h]] != g2[q]) {
            h = (h + 1) & maske;
        }
        kontrol += yrd[h] == -1 ? 0 : (g2[q] - 220000000) / 2 + 1;
    }
    return kontrol;
}

struct Cekirdek {
    const char* ad;
    void (*hazirla)();
    long long (*calistir)();
};

static const Cekirdek CEKIRDEK[] = {
    {"ikili_arama", arama_hazirla, arama_calistir},
    {"birlestirmeli", siralama_hazirla, birlestirmeli_calistir},
    {"obek_siralama", siralama_hazirla, obek_calistir},
    {"karma_tablosu", karma_hazirla, karma_calistir},
    {"bfs", graf_hazirla, bfs_calistir},
    {"dijkstra", graf_hazirla, dijkstra_calistir},
    {"lcs", lcs_hazirla, lcs_calistir},
    {"sirt_cantasi", sirt_hazirla, sirt_calistir},
    {"yin_ciftler", yin_hazirla, yin_ciftler_calistir},
    {"yin_siralama", yin_hazirla, yin_siralama_calistir},
    {"yin_karma", yin_hazirla, yin_karma_calistir},
    {"ara_dogrusal", ara_dogrusal_hazirla, ara_dogrusal_calistir},
    {"ara_ikili", ara_hizli_hazirla, ara_ikili_calistir},
    {"ara_karma", ara_hizli_hazirla, ara_karma_calistir},
};

int main(int argc, char* argv[])
{
    const char* kullanim = "Kullanım: %s CEKIRDEK N [--tekrar T] [--csv "
                           "dosya] [--etiket E]\n";
    if (argc < 3) {
        std::fprintf(stderr, kullanim, argv[0]);
        return 2;
    }
    const Cekirdek* k = nullptr;
    for (const Cekirdek& c : CEKIRDEK) {
        if (std::strcmp(argv[1], c.ad) == 0) {
            k = &c;
        }
    }
    char* son;
    long v = std::strtol(argv[2], &son, 10);
    int tekrar = 5;
    std::string csv, etiket = "-";
    for (int i = 3; k != nullptr && i + 1 < argc; i += 2) {
        if (std::strcmp(argv[i], "--tekrar") == 0) {
            tekrar = static_cast<int>(std::strtol(argv[i + 1], nullptr, 10));
        } else if (std::strcmp(argv[i], "--csv") == 0) {
            csv = argv[i + 1];
        } else if (std::strcmp(argv[i], "--etiket") == 0) {
            etiket = argv[i + 1];
        } else {
            k = nullptr;
        }
    }
    if (k == nullptr || *son != '\0' || v < 2 || v > 20000000 ||
        tekrar < 1 || tekrar > 101 || argc % 2 == 0) {
        std::fprintf(stderr, kullanim, argv[0]);
        return 2;
    }
    n = static_cast<int>(v);
    sorgu = 0;
    const std::size_t boyut = static_cast<std::size_t>(DERECE) * n +
                              4 * static_cast<std::size_t>(n) + SORGU_HIZLI +
                              SIRT_W + 16;
    g1.assign(boyut, 0);
    g2.assign(boyut, 0);
    g3.assign(boyut, 0);
    is.assign(boyut, 0);
    yrd.assign(boyut, 0);
    k->hazirla();
    long long kontrol = k->calistir();           // ısınma + sonuç
    std::vector<double> islemci, duvar;
    for (int t = 0; t < tekrar; t++) {
        double w0 = zaman_sn(), t0 = islemci_sn();
        long long k2 = k->calistir();
        islemci.push_back(islemci_sn() - t0);
        duvar.push_back(zaman_sn() - w0);
        if (k2 != kontrol) {
            kontrol = -2;
        }
    }
    double i_ms = ortanca(islemci) * 1e3, d_ms = ortanca(duvar) * 1e3;
    std::printf("%s;%d;%d;%lld\n", k->ad, n, sorgu, kontrol);
    std::fprintf(stderr, "%s n = %d: işlemci %.3f ms, duvar %.3f ms "
                 "(ortanca, %d tekrar; bu çalıştırmada)\n", k->ad, n, i_ms,
                 d_ms, tekrar);
    if (!csv.empty()) {
        std::FILE* f = std::fopen(csv.c_str(), "a");
        if (f == nullptr) {
            return 1;
        }
        if (std::ftell(f) == 0) {
            std::fprintf(f, "cekirdek;n;sorgu;dil;derleme;tekrar;islemci_ms;"
                         "duvar_ms;kontrol\n");
        }
        std::fprintf(f, "%s;%d;%d;C++;%s;%d;%.6f;%.6f;%lld\n", k->ad, n,
                     sorgu, etiket.c_str(), tekrar, i_ms, d_ms, kontrol);
        std::fclose(f);
    }
    return 0;
}

/* Kütüphane karşılığı: Örnek 9'daki gibi (std::sort, std::unordered_set,
 * std::priority_queue, ...). */

#!/usr/bin/env python3
"""h14_olcum_calistir.py — AP-2 Hafta 14 · Haftanın Deneyi: dönem
kıyaslama raporu için ölçüm sürücüsü.

(a) Mini-OBS 2'nin ilk (kaba kuvvet) ve son (algoritmik) sürümleri:
    numarayla arama v2.0 doğrusal / v2.3 ikili / v2.9 karma; yinelenen
    tespiti v2.1 tüm çiftler / v2.5 sıralama / v2.9 karma; yükleme v2.0
    (v1.0 yükleyicisi) / v2.5 toplu; ders seçimi v2.2 geri izlemesi (v2.12
    olcer_dp "geri") / v2.12 DP. Sürümler proje klasöründen ÇALIŞMA
    klasörüne KOPYALANIR ve orada derlenir (proje klasörüne yazılmaz);
    kopyada deney.c yerine deney_islemci.c (aynı arayüz, işlemci zamanı)
    derlenir. Sürümlerin kendi olcer araçları kullanılır.
(b) Kazançların ölçeği: aynı işlem -O2 / -O0 (Mini-OBS olcer'leri ve
    H14_deney_kiyas.c) ve C / C++ / Python (H14_deney_kiyas.*).
Düzen  : her ölçüm 1 ısınma + 5 tekrar, ORTANCA; işlemci zamanı esas,
    duvar saati ayrıca kaydedilir. Tutarsız noktalar 2 kez daha ölçülür ve
    üç ölçümün ortancası alınır (yineleme sütunu). Tutarsız nokta: (a)'da
    yerel log–log eğimi serinin ortanca eğiminden 0,4'ten çok sapan
    aralığın iki ucu; (b)'de C ve C++ -O2 sürelerinin 1,5 kattan çok
    ayrışması (aynı algoritma, benzer makine kodu). 1 ms'nin altındaki
    süreler için çözümlemede duvar saati kullanılır (clock() 1 µs
    adımlıdır).
Kullanım: python3 h14_olcum_calistir.py --miniobs .../91_Proje_MiniOBS2
          [--calisma KLASÖR] [--sonuclar sonuclar] [--yalniz a|b]
Çıktı  : sonuclar/h14_deney_miniobs.csv, h14_deney_kiyas.csv,
         h14_olcum_gunlugu.txt; ../OLCUM_ORTAMI.txt
"""
import argparse
import datetime
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time

BURASI = os.path.dirname(os.path.abspath(__file__))
SURUMLER = {"v2.0": "olcer", "v2.1": "olcer", "v2.3": "olcer",
            "v2.5": "olcer", "v2.9": "olcer_karma", "v2.12": "olcer_dp"}
BAYRAK = {"-O2": "-std=c17 -Wall -Wextra -pedantic -O2 -g",
          "-O0": "-std=c17 -Wall -Wextra -pedantic -O0 -g"}
GUNLUK = []


def gunluk(metin):
    GUNLUK.append(metin)
    print(metin, file=sys.stderr, flush=True)


def kur(miniobs, calisma):
    """Sürümleri kopyala; deney.c yerine deney_islemci.c; -O2 ve -O0"""
    islemci_c = os.path.join(BURASI, "c", "deney_islemci.c")
    for derleme in ("-O2", "-O0"):
        for surum, hedef in SURUMLER.items():
            kaynak = os.path.join(miniobs, surum)
            kl = os.path.join(calisma, derleme[1:], surum)
            os.makedirs(kl, exist_ok=True)
            for ad in os.listdir(kaynak):
                if ad.endswith((".c", ".h")) or ad == "Makefile":
                    shutil.copy2(os.path.join(kaynak, ad), kl)
            shutil.copy2(islemci_c, os.path.join(kl, "deney.c"))
            p = subprocess.run(["make", "-s", hedef,
                                f"CFLAGS={BAYRAK[derleme]}"], cwd=kl,
                               capture_output=True, text=True)
            if p.returncode != 0 or "warning" in p.stderr:
                sys.exit(f"derleme sorunu {surum} {derleme}:\n{p.stderr}")
            gunluk(f"derlendi: {surum}/{hedef} {derleme}")


def csv_oku(yol):
    satirlar = open(yol, encoding="utf-8").read().strip().split("\n")
    baslik = satirlar[0].split(";")
    return [dict(zip(baslik, s.split(";"))) for s in satirlar[1:]]


def olc_bir(calisma, surum, derleme, islem, n, ek, birim):
    """Bir olcer çağrısı (tek n). Dönen: satır sözlüğü"""
    kl = os.path.join(calisma, derleme[1:], surum)
    csv = os.path.join(kl, "h14_tmp.csv")
    if os.path.exists(csv):
        os.remove(csv)
    komut = ([f"./{SURUMLER[surum]}", islem, "--n", str(n), "--tekrar",
              "5"] + ek + ["--csv", csv])
    t0 = time.time()
    p = subprocess.run(komut, cwd=kl, capture_output=True, text=True,
                       timeout=1800)
    if p.returncode != 0:
        sys.exit(f"çalıştırma hatası: {' '.join(komut)}\n{p.stderr[-800:]}")
    satir = csv_oku(csv)[-1]
    olcum = re.findall(r"\[deney_islemci\] tekrar=(\d+) islemci_ortanca_ms="
                       r"([\d.]+) duvar_ortanca_ms=([\d.]+)", p.stderr)
    tekrar, isl, duv = olcum[-1]
    isl, duv = float(isl), float(duv)
    if birim == "islem":                       # CSV: işlem başına
        isler = int(satir["ic_tekrar"])
    elif birim == "sorgu":                     # CSV: toplu, sorgu sayısı
        isler = int(satir["sorgu"])
    else:
        isler = 1
    csv_ms = float(satir["ortanca_ms"]) * (isler if birim == "islem" else 1)
    if abs(csv_ms - isl) > 1e-3 * max(1.0, isl):
        gunluk(f"UYARI: CSV ({csv_ms}) ile günlük ({isl}) farklı: "
               f"{surum} {islem} {n}")
    kontrol = satir.get("kontrol", satir.get("deger", ""))
    gunluk(f"{surum:5} {derleme} {islem:20} n = {n:8}: işlemci {isl:12.4f} "
           f"ms, duvar {duv:12.4f} ms ({isler} işlem; "
           f"{time.time() - t0:.1f} s)")
    return {"surum": surum, "derleme": derleme, "islem": islem, "n": n,
            "isler": isler, "tekrar": int(tekrar), "islemci_ms": isl,
            "duvar_ms": duv, "kontrol": kontrol,
            "kestirim": satir.get("kestirim", "0"),
            "sayac": satir.get("karsilastirma", satir.get("hucre", "")),
            "dugum": satir.get("dugum", "")}


def yinelenen_ek(n):
    return ["--yinelenen", str(n // 100)]


# (grup, yöntem etiketi, sürüm, olcer işlemi, n listesi, ek argüman, birim)
PLAN_A = [
    ("arama", "doğrusal (v1.0)", "v2.0", "arama",
     [10000, 100000, 1000000], lambda n: [], "islem"),
    ("arama", "ikili", "v2.3", "ikili",
     [10000, 100000, 1000000], lambda n: [], "islem"),
    ("arama", "karma", "v2.9", "ara_karma",
     [10000, 100000, 1000000], lambda n: [], "sorgu"),
    ("yinelenen", "tüm çiftler", "v2.1", "yinelenen",
     [16000, 32000, 64000, 100000], yinelenen_ek, "tek"),
    ("yinelenen", "sıralama", "v2.5", "yinelenen_siralama",
     [16000, 32000, 64000, 100000, 1000000], yinelenen_ek, "tek"),
    ("yinelenen", "karma kümesi", "v2.9", "yin_karma",
     [16000, 32000, 64000, 100000, 1000000], lambda n: [], "tek"),
    ("yukleme", "v1.0 yükleyicisi", "v2.0", "yukleme",
     [16000, 32000, 64000], lambda n: [], "tek"),
    ("yukleme", "toplu (sırala + komşu)", "v2.5", "yukleme_toplu",
     [16000, 32000, 100000, 1000000], lambda n: [], "tek"),
    ("ders_secimi", "geri izleme (v2.2 ağacı)", "v2.12", "geri",
     [20, 25, 30, 35], lambda n: ["--akts", "45", "--butce", "60"], "tek"),
    ("ders_secimi", "DP (0/1 sırt çantası)", "v2.12", "dp",
     [20, 25, 30, 35], lambda n: ["--akts", "45"], "tek"),
]
# -O0 karşılaştırması (derleyici kazancı): (sürüm, işlem, n, ek, birim)
PLAN_O0 = [
    ("v2.0", "arama", 1000000, [], "islem"),
    ("v2.3", "ikili", 1000000, [], "islem"),
    ("v2.9", "ara_karma", 1000000, [], "sorgu"),
    ("v2.1", "yinelenen", 16000, yinelenen_ek(16000), "tek"),
    ("v2.1", "yinelenen", 32000, yinelenen_ek(32000), "tek"),
    ("v2.5", "yinelenen_siralama", 1000000, yinelenen_ek(1000000), "tek"),
    ("v2.9", "yin_karma", 1000000, [], "tek"),
    ("v2.0", "yukleme", 16000, [], "tek"),
    ("v2.5", "yukleme_toplu", 100000, [], "tek"),
    ("v2.12", "geri", 30, ["--akts", "45", "--butce", "60"], "tek"),
    ("v2.12", "dp", 35, ["--akts", "45"], "tek"),
]


def etkin_ms(r):
    """İşlemci zamanı; 1 ms'nin altında duvar saati (clock() 1 µs adımlı)"""
    return r["islemci_ms"] if r["islemci_ms"] >= 1.0 else r["duvar_ms"]


def tutarsiz(seri):
    """Yerel log–log eğimi serinin ortanca eğiminden 0,4'ten çok sapan ya
    da negatif olan aralıkların İKİ ucu (yinelenecek indisler)"""
    egim = []
    for i in range(1, len(seri)):
        t0, t1 = etkin_ms(seri[i - 1]), etkin_ms(seri[i])
        oran = seri[i]["n"] / seri[i - 1]["n"]
        egim.append(math.log(max(t1, 1e-9) / max(t0, 1e-9)) / math.log(oran))
    if not egim:
        return []
    orta = sorted(egim)[len(egim) // 2]
    secilen = set()
    for i, e in enumerate(egim, start=1):
        if e < 0 or (len(egim) >= 2 and abs(e - orta) > 0.4):
            secilen.update((i - 1, i))
    return sorted(secilen)


def bolum_a(calisma, sonuclar):
    satirlar = []
    for grup, yontem, surum, islem, nler, ek, birim in PLAN_A:
        seri = []
        for n in nler:
            r = olc_bir(calisma, surum, "-O2", islem, n, ek(n), birim)
            r.update(grup=grup, yontem=yontem, yineleme=0)
            seri.append(r)
        for i in tutarsiz(seri):               # tutarsız nokta: yinele
            isl, duv = [seri[i]["islemci_ms"]], [seri[i]["duvar_ms"]]
            for _ in range(2):
                r = olc_bir(calisma, surum, "-O2", islem, nler[i],
                            ek(nler[i]), birim)
                isl.append(r["islemci_ms"])
                duv.append(r["duvar_ms"])
            seri[i]["islemci_ms"] = sorted(isl)[1]
            seri[i]["duvar_ms"] = sorted(duv)[1]
            seri[i]["yineleme"] = 2
            gunluk(f"  tutarsız nokta yinelendi: {surum} {islem} {nler[i]}"
                   f" -> ölçümler {isl} ms; ortanca {sorted(isl)[1]:.4f} ms")
        satirlar += seri
    for surum, islem, n, ek, birim in PLAN_O0:
        grup, yontem = next((g, y) for g, y, s, i, _, _, _ in PLAN_A
                            if s == surum and i == islem)
        r = olc_bir(calisma, surum, "-O0", islem, n, ek, birim)
        r.update(grup=grup, yontem=yontem, yineleme=0)
        satirlar.append(r)
    alanlar = ["grup", "yontem", "surum", "islem", "derleme", "n", "isler",
               "tekrar", "islemci_ms", "duvar_ms", "islemci_ms_islem",
               "duvar_ms_islem", "kontrol", "sayac", "dugum", "kestirim",
               "yineleme"]
    with open(os.path.join(sonuclar, "h14_deney_miniobs.csv"), "w",
              encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for r in satirlar:
            r["islemci_ms_islem"] = r["islemci_ms"] / r["isler"]
            r["duvar_ms_islem"] = r["duvar_ms"] / r["isler"]
            f.write(";".join(
                f"{r[a]:.6f}" if isinstance(r[a], float) else str(r[a])
                for a in alanlar) + "\n")


# (b) çekirdekler: (çekirdek, n); her biri C -O2, C -O0, C++ -O2, Python
PLAN_B = [("ikili_arama", 100000), ("birlestirmeli", 100000),
          ("obek_siralama", 100000), ("karma_tablosu", 100000),
          ("bfs", 100000), ("dijkstra", 100000), ("lcs", 1000),
          ("sirt_cantasi", 200), ("yin_ciftler", 4000),
          ("yin_siralama", 4000), ("yin_karma", 4000),
          ("yin_siralama", 100000), ("yin_karma", 100000),
          ("ara_dogrusal", 100000), ("ara_ikili", 100000),
          ("ara_karma", 100000)]


def bolum_b(sonuclar, gecici):
    c = os.path.join(BURASI, "c")
    ikili = {}
    for etiket, bayrak in (("-O2", "-O2"), ("-O0", "-O0")):
        hedef = os.path.join(gecici, f"kiyas_c{bayrak}")
        komut = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic", bayrak,
                 os.path.join(c, "H14_deney_kiyas.c"),
                 os.path.join(c, "ortak_rastgele.c"),
                 os.path.join(c, "zamanlayici.c"), "-I", c, "-o", hedef]
        p = subprocess.run(komut, capture_output=True, text=True)
        if p.returncode != 0 or p.stderr.strip():
            sys.exit(p.stderr)
        ikili[("C", etiket)] = [hedef]
    hedef = os.path.join(gecici, "kiyas_cpp")
    cpp = os.path.join(BURASI, "cpp")
    p = subprocess.run(["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic",
                        "-O2", os.path.join(cpp, "H14_deney_kiyas.cpp"),
                        "-I", cpp, "-o", hedef], capture_output=True,
                       text=True)
    if p.returncode != 0 or p.stderr.strip():
        sys.exit(p.stderr)
    ikili[("C++", "-O2")] = [hedef]
    ikili[("Python", "CPython")] = [sys.executable, os.path.join(
        BURASI, "python", "H14_deney_kiyas.py")]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    tmp = os.path.join(gecici, "kiyas_tmp.csv")

    def bir_olcum(komut, cekirdek, n, etiket):
        if os.path.exists(tmp):
            os.remove(tmp)
        t0 = time.time()
        p = subprocess.run(komut + [cekirdek, str(n), "--tekrar", "5",
                                    "--csv", tmp, "--etiket", etiket],
                           capture_output=True, text=True, env=env,
                           cwd=gecici, timeout=1800)
        if p.returncode != 0:
            sys.exit(f"{komut} {cekirdek}: {p.stderr}")
        satir = csv_oku(tmp)[-1]
        gunluk(f"{satir['dil']:6} {etiket:7} {p.stderr.strip()} "
               f"[{time.time() - t0:.1f} s]")
        return satir, p.stdout.strip()

    sonuc, kontrol = {}, {}
    for cekirdek, n in PLAN_B:
        for anahtar, komut in ikili.items():
            satir, cikti = bir_olcum(komut, cekirdek, n, anahtar[1])
            satir["yineleme"] = 0
            sonuc[(cekirdek, n, anahtar)] = satir
            kontrol.setdefault((cekirdek, n), set()).add(cikti)
    # Tutarsızlık: C ile C++ -O2 aynı makine koduna yakındır; işlemci
    # süreleri 1,5 kattan çok ayrışıyorsa ikisi de 2 kez daha ölçülür.
    for cekirdek, n in PLAN_B:
        c = sonuc[(cekirdek, n, ("C", "-O2"))]
        cpp = sonuc[(cekirdek, n, ("C++", "-O2"))]
        oran = float(cpp["islemci_ms"]) / max(float(c["islemci_ms"]), 1e-9)
        if 1 / 1.5 <= oran <= 1.5 or float(c["islemci_ms"]) < 1.0:
            continue
        for anahtar in (("C", "-O2"), ("C++", "-O2")):
            ilk = sonuc[(cekirdek, n, anahtar)]
            isl, duv = [float(ilk["islemci_ms"])], [float(ilk["duvar_ms"])]
            for _ in range(2):
                satir, _ = bir_olcum(ikili[anahtar], cekirdek, n, anahtar[1])
                isl.append(float(satir["islemci_ms"]))
                duv.append(float(satir["duvar_ms"]))
            ilk["islemci_ms"] = f"{sorted(isl)[1]:.6f}"
            ilk["duvar_ms"] = f"{sorted(duv)[1]:.6f}"
            ilk["yineleme"] = 2
            gunluk(f"  tutarsız nokta yinelendi: {anahtar} {cekirdek} {n} -> "
                   f"{isl} ms; ortanca {sorted(isl)[1]:.4f} ms")
    alanlar = ["cekirdek", "n", "sorgu", "dil", "derleme", "tekrar",
               "islemci_ms", "duvar_ms", "kontrol", "yineleme"]
    with open(os.path.join(sonuclar, "h14_deney_kiyas.csv"), "w",
              encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for cekirdek, n in PLAN_B:
            for anahtar in ikili:
                r = sonuc[(cekirdek, n, anahtar)]
                f.write(";".join(str(r[a]) for a in alanlar) + "\n")
    farkli = [k for k, v in kontrol.items() if len(v) != 1]
    gunluk(f"(b) denetim: {len(kontrol) - len(farkli)}/{len(kontrol)} "
           "çekirdek-boyut için dört yapılandırmanın stdout'u aynı"
           + (f"; FARKLI: {farkli}" if farkli else ""))


def ortam(sonuclar, bas, son, yuk_bas, yuk_son, sure, evre):
    def cmd(k):
        return subprocess.run(k, capture_output=True, text=True).stdout
    lscpu = cmd(["lscpu"])
    model = re.search(r"Model name:\s*(.+)", lscpu)
    onbellek = re.findall(r"(L1d|L2|L3) cache:\s*(.+)", lscpu)
    L = ["AP-2 Hafta 14 · Haftanın Deneyi — ölçüm ortamı",
         f"Tarih          : {bas:%Y-%m-%d %H:%M} – {son:%H:%M}",
         f"İşlemci        : {model.group(1).strip() if model else '?'}",
         f"Çekirdek sayısı: {os.cpu_count()} (sanal makine)",
         "Önbellek       : " + ", ".join(f"{a} {b.strip()}"
                                         for a, b in onbellek),
         f"Yük ortalaması : önce {yuk_bas} · sonra {yuk_son} "
         "(/proc/loadavg: 1, 5, 15 dk)",
         f"İşletim sistemi: {platform.system()} {platform.release()} "
         f"({platform.machine()})",
         f"C derleyicisi  : {cmd(['gcc', '--version']).splitlines()[0]}",
         f"C++ derleyicisi: {cmd(['g++', '--version']).splitlines()[0]}",
         f"Python         : Python {platform.python_version()}",
         "Bayraklar      : C -std=c17 -Wall -Wextra -pedantic -O2 (karşı"
         "laştırma için -O0); C++ -std=c++17 ... -O2;",
         "                 Mini-OBS olcer'leri sürümlerin Makefile'ıyla, "
         "CFLAGS = ... -O2 -g (ya da -O0 -g)",
         "Yöntem         : 1 ısınma + 5 tekrar, ORTANCA; işlemci zamanı "
         "(C clock, C++ islemci_sn, Python time.process_time) esas,",
         "                 duvar saati ayrı sütunda; Mini-OBS'de deney.c "
         "yerine deney_islemci.c (aynı arayüz) derlendi",
         "Tutarsızlık    : yerel log–log eğimi serinin ortanca eğiminden "
         "0,4'ten çok sapan (ya da negatif) aralığın",
         "                 iki ucu 2 kez daha ölçüldü; üç ölçümün ortancası "
         "alındı (yineleme sütunu);",
         "                 (b)'de C ile C++ -O2 süreleri 1,5 kattan çok "
         "ayrışırsa ikisi de 2 kez daha ölçüldü",
         "Çözünürlük     : clock() 1 µs adımlıdır; 1 ms'nin altındaki "
         "ortancalarda çözümlemede duvar saati kullanıldı",
         f"Toplam süre    : {sure:.1f} s (sürücünün duvar saati)",
         "Evre süreleri  : " + " · ".join(f"{a} {b:.1f} s"
                                          for a, b in evre),
         "Not            : ölçüm sırasında makinede başka süreçler (ajanlar) "
         "de çalışıyordu; süreler bu makineye ve bu ana özgüdür,",
         "                 sayaçlar ve denetim toplamları makineden "
         "bağımsızdır."]
    with open(os.path.join(os.path.dirname(sonuclar), "OLCUM_ORTAMI.txt"),
              "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--miniobs", required=True)
    ap.add_argument("--calisma", default=None)
    ap.add_argument("--sonuclar", default=os.path.join(BURASI, "sonuclar"))
    ap.add_argument("--yalniz", choices=["a", "b"], default=None)
    a = ap.parse_args()
    os.makedirs(a.sonuclar, exist_ok=True)
    gecici = tempfile.mkdtemp(prefix="h14_olcum_")
    calisma = a.calisma or os.path.join(gecici, "miniobs")
    bas = datetime.datetime.now()
    yuk_bas = open("/proc/loadavg").read().split()[:3]
    t0 = time.time()
    evre = []
    try:
        if a.yalniz in (None, "a"):
            kur(a.miniobs, calisma)
            evre.append(("derleme", time.time() - t0))
            t1 = time.time()
            bolum_a(calisma, a.sonuclar)
            evre.append(("(a) Mini-OBS", time.time() - t1))
        if a.yalniz in (None, "b"):
            t1 = time.time()
            bolum_b(a.sonuclar, gecici)
            evre.append(("(b) çekirdekler", time.time() - t1))
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    yuk_son = open("/proc/loadavg").read().split()[:3]
    sure = time.time() - t0
    with open(os.path.join(a.sonuclar, "h14_olcum_gunlugu.txt"),
              "a" if a.yalniz == "b" else "w", encoding="utf-8") as f:
        f.write("\n".join(GUNLUK) + "\n")
    if a.yalniz is None:
        ortam(a.sonuclar, bas, datetime.datetime.now(), " ".join(yuk_bas),
              " ".join(yuk_son), sure, evre)
    gunluk(f"toplam {sure:.1f} s")
    return 0


if __name__ == "__main__":
    sys.exit(main())

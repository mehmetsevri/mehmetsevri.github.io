/* H14_deney_kiyas.c — AP-2 Hafta 14 · Haftanın Deneyi (b)
 * Amaç    : Kazançların ölçeği: aynı çekirdeği farklı derlemeyle (-O0 /
 *           -O2) ve farklı dille (C / C++ / Python) ölçmek. Örnek 9'un
 *           sekiz çekirdeği + Mini-OBS işlemlerinin dizi modeli: yinelenen
 *           (tüm çiftler / sırala + komşular / karma kümesi) ve numarayla
 *           arama (doğrusal / ikili / karma). Algoritmalar Örnek 9 ile aynı.
 * Kullanım: ./H14_deney_kiyas CEKIRDEK N [--tekrar T] [--csv dosya]
 *                             [--etiket E]
 *           CEKIRDEK: ikili_arama birlestirmeli obek_siralama karma_tablosu
 *           bfs dijkstra lcs sirt_cantasi yin_ciftler yin_siralama
 *           yin_karma ara_dogrusal ara_ikili ara_karma
 * Çıktı   : stdout: cekirdek;n;sorgu;kontrol (belirleyici)
 *           stderr ve --csv: 1 ısınma + T tekrar (varsayılan 5), ORTANCA;
 *           işlemci zamanı (clock) ve duvar saati ayrı sütunlarda
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H14_deney_kiyas.c \
 *           ortak_rastgele.c zamanlayici.c -o H14_deney_kiyas
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define DERECE 5
#define SIRT_W 1000
#define SORGU_DOGRUSAL 100
#define SORGU_HIZLI 100000

static int n, sorgu;
static int *g1, *g2, *g3, *is, *yrd;     /* sahiplik: bu modül; birak() */

static int ayir(size_t boyut)
{
    g1 = malloc(boyut * sizeof *g1);
    g2 = malloc(boyut * sizeof *g2);
    g3 = malloc(boyut * sizeof *g3);
    is = malloc(boyut * sizeof *is);
    yrd = malloc(boyut * sizeof *yrd);
    return g1 && g2 && g3 && is && yrd ? 0 : -1;
}

static void birak(void)
{
    free(g1);
    free(g2);
    free(g3);
    free(is);
    free(yrd);
}

/* ===== Örnek 9'un çekirdekleri (aynı kod, aynı tohumlar) ============ */
static void arama_hazirla(void)
{
    rastgele_tohum(1);
    for (int i = 0; i < n; i++) {
        g1[i] = 3 * i + 1;
        g2[i] = rastgele_aralik(0, 3 * n);
    }
    sorgu = n;
}

static long long ikili_ara(const int *a, int boy, int x)    /* konum/-1 */
{
    int lo = 0, hi = boy - 1;
    while (lo <= hi) {
        int orta = lo + (hi - lo) / 2;
        if (a[orta] == x) {
            return orta;
        } else if (a[orta] < x) {
            lo = orta + 1;
        } else {
            hi = orta - 1;
        }
    }
    return -1;
}

static long long arama_calistir(void)
{
    long long kontrol = 0;
    for (int q = 0; q < sorgu; q++) {
        kontrol += ikili_ara(g1, n, g2[q]) + 1;
    }
    return kontrol;
}

static void siralama_hazirla(void)
{
    rastgele_tohum(2);
    rastgele_dizi(g1, (size_t)n, 0, 1000000);
}

static long long siralama_kontrol(const int *a)
{
    long long k = 0;
    for (int i = 0; i < n; i++) {
        if (i > 0 && a[i - 1] > a[i]) {
            return -1;
        }
        k += (long long)(i % 1000 + 1) * a[i];
    }
    return k;
}

static void birlestirmeli(int *a, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(a, lo, orta);
    birlestirmeli(a, orta, hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        yrd[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i < orta) {
        yrd[k++] = a[i++];
    }
    while (j < hi) {
        yrd[k++] = a[j++];
    }
    memcpy(a + lo, yrd + lo, (size_t)(hi - lo) * sizeof *a);
}

static long long birlestirmeli_calistir(void)
{
    memcpy(is, g1, (size_t)n * sizeof *is);
    birlestirmeli(is, 0, n);
    return siralama_kontrol(is);
}

static void asagi_suz(int *a, int i, int boy)
{
    for (;;) {
        int b = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < boy && a[s] > a[b]) {
            b = s;
        }
        if (r < boy && a[r] > a[b]) {
            b = r;
        }
        if (b == i) {
            return;
        }
        int t = a[i];
        a[i] = a[b];
        a[b] = t;
        i = b;
    }
}

static long long obek_calistir(void)
{
    memcpy(is, g1, (size_t)n * sizeof *is);
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(is, i, n);
    }
    for (int son = n - 1; son > 0; son--) {
        int t = is[0];
        is[0] = is[son];
        is[son] = t;
        asagi_suz(is, 0, son);
    }
    return siralama_kontrol(is);
}

static int karma_bit;

static void bit_kur(int kac)                     /* 2^bit >= 2·kac */
{
    karma_bit = 1;
    while ((1 << karma_bit) < 2 * kac) {
        karma_bit++;
    }
}

static void karma_hazirla(void)
{
    rastgele_tohum(4);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(0, n);
        g2[i] = rastgele_aralik(0, 2 * n);
    }
    bit_kur(n);
}

static uint32_t karma(int anahtar)
{
    return (uint32_t)((uint32_t)anahtar * 2654435769u) >> (32 - karma_bit);
}

/* Açık adresleme kümesi: ekle (varsa geç); dönen: daha önce var mıydı */
static int kume_ekle(int *tablo, int anahtar, long long *yoklama)
{
    uint32_t h = karma(anahtar), maske = (1u << karma_bit) - 1;
    (*yoklama)++;
    while (tablo[h] != -1 && tablo[h] != anahtar) {
        h = (h + 1) & maske;
        (*yoklama)++;
    }
    if (tablo[h] == anahtar) {
        return 1;
    }
    tablo[h] = anahtar;
    return 0;
}

static int kume_var(const int *tablo, int anahtar, long long *yoklama)
{
    uint32_t h = karma(anahtar), maske = (1u << karma_bit) - 1;
    (*yoklama)++;
    while (tablo[h] != -1 && tablo[h] != anahtar) {
        h = (h + 1) & maske;
        (*yoklama)++;
    }
    return tablo[h] == anahtar;
}

static long long karma_calistir(void)
{
    int kap = 1 << karma_bit;
    long long farkli = 0, bulunan = 0, yoklama = 0;
    for (int i = 0; i < kap; i++) {
        is[i] = -1;
    }
    for (int i = 0; i < n; i++) {
        farkli += !kume_ekle(is, g1[i], &yoklama);
    }
    for (int q = 0; q < n; q++) {
        bulunan += kume_var(is, g2[q], &yoklama);
    }
    return farkli + bulunan + yoklama;
}

static void graf_hazirla(void)
{
    rastgele_tohum(5);
    for (int u = 0; u < n; u++) {
        int *v = g1 + DERECE * u, *w = g2 + DERECE * u;
        for (int k = 0; k < DERECE; k++) {
            v[k] = k == 0 ? (u + 1) % n : rastgele_aralik(0, n - 1);
            w[k] = rastgele_aralik(1, 100);
        }
        for (int k = 1; k < DERECE; k++) {
            int tv = v[k], tw = w[k], j = k - 1;
            while (j >= 0 && (v[j] > tv || (v[j] == tv && w[j] > tw))) {
                v[j + 1] = v[j];
                w[j + 1] = w[j];
                j--;
            }
            v[j + 1] = tv;
            w[j + 1] = tw;
        }
    }
}

static long long bfs_calistir(void)
{
    int *uz = is, *kuyruk = yrd, bas = 0, son = 0;
    long long kontrol = 0;
    for (int v = 0; v < n; v++) {
        uz[v] = -1;
    }
    uz[0] = 0;
    kuyruk[son++] = 0;
    while (bas < son) {
        int u = kuyruk[bas++];
        kontrol += uz[u] + 1;
        for (int k = DERECE * u; k < DERECE * u + DERECE; k++) {
            if (uz[g1[k]] == -1) {
                uz[g1[k]] = uz[u] + 1;
                kuyruk[son++] = g1[k];
            }
        }
    }
    return kontrol;
}

typedef struct {
    long long d;
    int v;
} Oge;

static int oge_kucuk(Oge a, Oge b)
{
    return a.d < b.d || (a.d == b.d && a.v < b.v);
}

static long long dijkstra_calistir(void)
{
    Oge *obek = malloc(((size_t)DERECE * n + 1) * sizeof *obek);
    long long *uz = malloc((size_t)n * sizeof *uz);
    if (obek == NULL || uz == NULL) {
        free(obek);
        free(uz);
        return -1;
    }
    int boy = 0;
    for (int v = 0; v < n; v++) {
        uz[v] = -1;
    }
    uz[0] = 0;
    obek[boy++] = (Oge){0, 0};
    long long kontrol = 0;
    while (boy > 0) {
        Oge en = obek[0];
        obek[0] = obek[--boy];
        for (int i = 0;;) {
            int b = i, s = 2 * i + 1, r = 2 * i + 2;
            if (s < boy && oge_kucuk(obek[s], obek[b])) {
                b = s;
            }
            if (r < boy && oge_kucuk(obek[r], obek[b])) {
                b = r;
            }
            if (b == i) {
                break;
            }
            Oge t = obek[i];
            obek[i] = obek[b];
            obek[b] = t;
            i = b;
        }
        if (en.d > uz[en.v]) {
            continue;
        }
        kontrol += en.d;
        for (int k = DERECE * en.v; k < DERECE * en.v + DERECE; k++) {
            int v = g1[k];
            long long yeni = en.d + g2[k];
            if (uz[v] == -1 || yeni < uz[v]) {
                uz[v] = yeni;
                int i = boy++;
                obek[i] = (Oge){yeni, v};
                while (i > 0 && oge_kucuk(obek[i], obek[(i - 1) / 2])) {
                    Oge t = obek[i];
                    obek[i] = obek[(i - 1) / 2];
                    obek[(i - 1) / 2] = t;
                    i = (i - 1) / 2;
                }
            }
        }
    }
    free(obek);
    free(uz);
    return kontrol;
}

static void lcs_hazirla(void)
{
    rastgele_tohum(7);
    for (int i = 0; i < 2 * n; i++) {
        g1[i] = "ACGT"[rastgele_aralik(0, 3)];
    }
}

static long long lcs_calistir(void)
{
    int *onceki = is, *simdi = yrd;
    const int *a = g1, *b = g1 + n;
    for (int j = 0; j <= n; j++) {
        onceki[j] = 0;
    }
    for (int i = 1; i <= n; i++) {
        simdi[0] = 0;
        for (int j = 1; j <= n; j++) {
            if (a[i - 1] == b[j - 1]) {
                simdi[j] = onceki[j - 1] + 1;
            } else {
                simdi[j] = onceki[j] >= simdi[j - 1] ? onceki[j]
                                                       : simdi[j - 1];
            }
        }
        int *t = onceki;
        onceki = simdi;
        simdi = t;
    }
    return onceki[n];
}

static void sirt_hazirla(void)
{
    rastgele_tohum(8);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(1, 50);
        g2[i] = rastgele_aralik(1, 100);
    }
}

static long long sirt_calistir(void)
{
    int *dp = is;
    for (int c = 0; c <= SIRT_W; c++) {
        dp[c] = 0;
    }
    for (int i = 0; i < n; i++) {
        for (int c = SIRT_W; c >= g1[i]; c--) {
            if (dp[c - g1[i]] + g2[i] > dp[c]) {
                dp[c] = dp[c - g1[i]] + g2[i];
            }
        }
    }
    return dp[SIRT_W];
}

/* ===== Mini-OBS işlemlerinin dizi modeli ============================ */
/* Numaralar: 220000000 + i karışık; %1'i öncekilerden birinin kopyası
 * (Örnek 8 ile aynı üretim); kontrol = eşit çift sayısı */
static void yin_hazirla(void)
{
    rastgele_tohum(8);
    for (int i = 0; i < n; i++) {
        g1[i] = 220000000 + i;
    }
    rastgele_karistir(g1, (size_t)n);
    for (int i = 1; i < n; i++) {
        if (rastgele_aralik(0, 99) == 0) {
            g1[i] = g1[rastgele_aralik(0, i - 1)];
        }
    }
    bit_kur(n);
}

static long long yin_ciftler_calistir(void)       /* v2.1: Θ(n²) */
{
    long long cift = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            cift += g1[i] == g1[j];
        }
    }
    return cift;
}

static long long yin_siralama_calistir(void)      /* v2.5: Θ(n log n) */
{
    long long cift = 0;
    memcpy(is, g1, (size_t)n * sizeof *is);
    birlestirmeli(is, 0, n);
    for (int i = 0, j; i < n; i = j) {
        for (j = i + 1; j < n && is[j] == is[i]; j++) {
        }
        cift += (long long)(j - i) * (j - i - 1) / 2;
    }
    return cift;
}

static long long yin_karma_calistir(void)         /* v2.9: ort. Θ(n) */
{
    int kap = 1 << karma_bit;
    long long cift = 0, yoklama = 0;
    uint32_t maske = (uint32_t)kap - 1;
    for (int i = 0; i < kap; i++) {
        is[i] = -1;                              /* anahtar; -1 = boş */
        yrd[i] = 0;                              /* adet */
    }
    for (int i = 0; i < n; i++) {
        uint32_t h = karma(g1[i]);
        yoklama++;
        while (is[h] != -1 && is[h] != g1[i]) {
            h = (h + 1) & maske;
            yoklama++;
        }
        is[h] = g1[i];
        cift += yrd[h]++;                        /* yeni eş, eskilerle çift */
    }
    return cift;
}

/* Arama: n farklı numara (220000000 + 2i, karışık sırada); sorgular yarı
 * yarıya var/yok; kontrol = Σ (bulunan indis + 1) — üç yöntemde AYNI */
static void ara_hazirla(int kac_sorgu)
{
    rastgele_tohum(9);
    for (int i = 0; i < n; i++) {
        g1[i] = 220000000 + 2 * i;               /* sıralı kopya: g3 */
        g3[i] = g1[i];
    }
    rastgele_karistir(g1, (size_t)n);            /* kayıt sırası karışık */
    sorgu = kac_sorgu;
    for (int q = 0; q < sorgu; q++) {
        g2[q] = 220000000 + rastgele_aralik(0, 2 * n - 1);  /* tek: yok */
    }
    bit_kur(n);
    int kap = 1 << karma_bit;                    /* dizin: numara -> sıra */
    for (int i = 0; i < kap; i++) {
        yrd[i] = -1;
    }
    for (int i = 0; i < n; i++) {
        uint32_t h = karma(g1[i]);
        while (yrd[h] != -1) {
            h = (h + 1) & (uint32_t)(kap - 1);
        }
        yrd[h] = i;
    }
}

static void ara_dogrusal_hazirla(void)
{
    ara_hazirla(SORGU_DOGRUSAL);
}

static void ara_hizli_hazirla(void)
{
    ara_hazirla(SORGU_HIZLI);
}

static long long ara_dogrusal_calistir(void)      /* v1.0/v2.0: Θ(n) */
{
    long long kontrol = 0;
    for (int q = 0; q < sorgu; q++) {
        int k = -1;
        for (int i = 0; i < n; i++) {
            if (g1[i] == g2[q]) {
                k = i;
                break;
            }
        }
        kontrol += k == -1 ? 0 : (g1[k] - 220000000) / 2 + 1;
    }
    return kontrol;
}

static long long ara_ikili_calistir(void)         /* v2.3: Θ(log n) */
{
    long long kontrol = 0;
    for (int q = 0; q < sorgu; q++) {
        kontrol += ikili_ara(g3, n, g2[q]) + 1;
    }
    return kontrol;
}

static long long ara_karma_calistir(void)         /* v2.9: ort. Θ(1) */
{
    long long kontrol = 0;
    uint32_t maske = (1u << karma_bit) - 1;
    for (int q = 0; q < sorgu; q++) {
        uint32_t h = karma(g2[q]);
        while (yrd[h] != -1 && g1[yrd[h]] != g2[q]) {
            h = (h + 1) & maske;
        }
        kontrol += yrd[h] == -1 ? 0 : (g2[q] - 220000000) / 2 + 1;
    }
    return kontrol;
}

typedef struct {
    const char *ad;
    void (*hazirla)(void);
    long long (*calistir)(void);
} Cekirdek;

static const Cekirdek CEKIRDEK[] = {
    {"ikili_arama", arama_hazirla, arama_calistir},
    {"birlestirmeli", siralama_hazirla, birlestirmeli_calistir},
    {"obek_siralama", siralama_hazirla, obek_calistir},
    {"karma_tablosu", karma_hazirla, karma_calistir},
    {"bfs", graf_hazirla, bfs_calistir},
    {"dijkstra", graf_hazirla, dijkstra_calistir},
    {"lcs", lcs_hazirla, lcs_calistir},
    {"sirt_cantasi", sirt_hazirla, sirt_calistir},
    {"yin_ciftler", yin_hazirla, yin_ciftler_calistir},
    {"yin_siralama", yin_hazirla, yin_siralama_calistir},
    {"yin_karma", yin_hazirla, yin_karma_calistir},
    {"ara_dogrusal", ara_dogrusal_hazirla, ara_dogrusal_calistir},
    {"ara_ikili", ara_hizli_hazirla, ara_ikili_calistir},
    {"ara_karma", ara_hizli_hazirla, ara_karma_calistir},
};

static void kullanim(const char *ad)
{
    fprintf(stderr, "Kullanım: %s CEKIRDEK N [--tekrar T] [--csv dosya] "
            "[--etiket E]\n", ad);
}

int main(int argc, char *argv[])
{
    if (argc < 3) {
        kullanim(argv[0]);
        return 2;
    }
    const Cekirdek *k = NULL;
    for (size_t c = 0; c < sizeof CEKIRDEK / sizeof CEKIRDEK[0]; c++) {
        if (strcmp(argv[1], CEKIRDEK[c].ad) == 0) {
            k = &CEKIRDEK[c];
        }
    }
    char *son;
    long v = strtol(argv[2], &son, 10);
    int tekrar = 5;
    const char *csv = NULL, *etiket = "-";
    for (int i = 3; k != NULL && i + 1 < argc; i += 2) {
        if (strcmp(argv[i], "--tekrar") == 0) {
            tekrar = (int)strtol(argv[i + 1], NULL, 10);
        } else if (strcmp(argv[i], "--csv") == 0) {
            csv = argv[i + 1];
        } else if (strcmp(argv[i], "--etiket") == 0) {
            etiket = argv[i + 1];
        } else {
            k = NULL;
        }
    }
    if (k == NULL || *son != '\0' || v < 2 || v > 20000000 || tekrar < 1 ||
        tekrar > 101 || argc % 2 == 0) {
        kullanim(argv[0]);
        return 2;
    }
    n = (int)v;
    sorgu = 0;
    if (ayir((size_t)DERECE * n + 4 * (size_t)n + SORGU_HIZLI + SIRT_W + 16)
        != 0) {
        birak();
        fprintf(stderr, "bellek yetmedi\n");
        return 1;
    }
    k->hazirla();
    long long kontrol = k->calistir();           /* ısınma + sonuç */
    double islemci[101], duvar[101];
    for (int t = 0; t < tekrar; t++) {
        double w0 = zaman_sn(), t0 = islemci_sn();
        long long k2 = k->calistir();
        islemci[t] = islemci_sn() - t0;
        duvar[t] = zaman_sn() - w0;
        if (k2 != kontrol) {
            kontrol = -2;                        /* belirleyici değil */
        }
    }
    double i_ms = ortanca(islemci, tekrar) * 1e3;
    double d_ms = ortanca(duvar, tekrar) * 1e3;
    printf("%s;%d;%d;%lld\n", k->ad, n, sorgu, kontrol);
    fprintf(stderr, "%s n = %d: işlemci %.3f ms, duvar %.3f ms (ortanca, %d "
            "tekrar; bu çalıştırmada)\n", k->ad, n, i_ms, d_ms, tekrar);
    if (csv != NULL) {
        FILE *f = fopen(csv, "a");
        if (f == NULL) {
            birak();
            return 1;
        }
        if (ftell(f) == 0) {
            fprintf(f, "cekirdek;n;sorgu;dil;derleme;tekrar;islemci_ms;"
                    "duvar_ms;kontrol\n");
        }
        fprintf(f, "%s;%d;%d;C;%s;%d;%.6f;%.6f;%lld\n", k->ad, n, sorgu,
                etiket, tekrar, i_ms, d_ms, kontrol);
        fclose(f);
    }
    birak();
    return 0;
}

/* Kütüphane karşılığı: Örnek 9'daki gibi (bsearch, qsort, ...). */

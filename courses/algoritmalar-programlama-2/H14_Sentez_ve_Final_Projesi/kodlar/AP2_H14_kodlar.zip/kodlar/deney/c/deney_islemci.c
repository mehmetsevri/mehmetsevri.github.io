/* deney_islemci.c — AP-2 Hafta 14 · Haftanın Deneyi: Mini-OBS 2 olcer
 *           araçları için İŞLEMCİ ZAMANLI ölçüm düzeni
 * Amaç    : Mini-OBS 2 sürümlerinin (v2.0–v2.12) deney.c modülüyle AYNI
 *           arayüz (deney.h: deney_olc, DeneySonucu) ve aynı düzen (1
 *           ısınma + tekrar ölçüm, ortanca). Tek fark: DeneySonucu'na
 *           duvar saati yerine bu sürecin İŞLEMCİ ZAMANI (clock) yazılır;
 *           makinede başka süreçler çalışırken bekleme süresi ölçüme
 *           girmez. Duvar saati ortancası ayrıca stderr'e yazılır.
 * Kullanım: sürümün kopyasında deney.c yerine bu dosya derlenir
 *           (kodlar/deney/h14_olcum_calistir.py bunu yapar); proje
 *           klasöründeki dosyalar DEĞİŞTİRİLMEZ.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -g -c deney_islemci.c
 */
#include <stdio.h>

#include "deney.h"
#include "zamanlayici.h"   /* islemci_sn, zaman_sn, ortanca */

void deney_olc(void (*gorev)(void *), void *veri, int tekrar, DeneySonucu *ds)
{
    double sureler[DENEY_AZAMI_TEKRAR], duvar[DENEY_AZAMI_TEKRAR];
    if (tekrar < 1) {
        tekrar = 1;
    }
    if (tekrar > DENEY_AZAMI_TEKRAR) {
        tekrar = DENEY_AZAMI_TEKRAR;
    }
    double t0 = islemci_sn();
    gorev(veri);                         /* ısınma: önbellek, sayfa tabloları */
    ds->isinma_sn = islemci_sn() - t0;
    double toplam = 0.0;
    for (int k = 0; k < tekrar; k++) {
        double w0 = zaman_sn();
        t0 = islemci_sn();
        gorev(veri);
        sureler[k] = islemci_sn() - t0;
        duvar[k] = zaman_sn() - w0;
        toplam += sureler[k];
    }
    ds->tekrar = tekrar;
    ds->ilk_sn = sureler[0];
    ds->ortalama_sn = toplam / tekrar;
    ds->ortanca_sn = ortanca(sureler, tekrar);   /* sureler'i sıralar */
    ds->en_az_sn = sureler[0];
    ds->en_cok_sn = sureler[tekrar - 1];
    fprintf(stderr, "[deney_islemci] tekrar=%d islemci_ortanca_ms=%.6f "
            "duvar_ortanca_ms=%.6f\n", tekrar, ds->ortanca_sn * 1e3,
            ortanca(duvar, tekrar) * 1e3);
}

"""H14_04_iki_opt.py — AP-2 Hafta 14 · Örnek 4 (★★★)
Amaç    : 2-opt yerel arama: en yakın komşu turundan başla; iki kenarı
          (a-b, c-e) çıkarıp (a-c, b-e) ekle = tur[i..j]'yi ters çevir.
          İLK İYİLEŞTİRME: sabit sırayla (i = 1..n−2, j = i+1..n−1)
          taranır, kısaltan ilk hamle uygulanır ve tarama baştan başlar;
          hiçbir hamle kısaltmıyorsa tur bir 2-opt YEREL EN İYİSİDİR.
          Yerel en iyinin genel en iyi olmadığı bir örnek (kaba kuvvet)
Kurallar: kazanç = (d(a,c) + d(b,e)) − (d(a,b) + d(c,e)) < −1e-9 ise
          hamle uygulanır; tam tarama (n−1)(n−2)/2 hamle → O(n²)
Çalıştır: python3 H14_04_iki_opt.py
Eşleri  : c/H14_04_iki_opt.c · cpp/H14_04_iki_opt.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_aralik, rastgele_tohum

EPS = 1e-9
ORNEK = 100

n = 0
x = []
y = []
d = []
denenen = 0                         # incelenen 2-opt hamlesi


def d2(i, j):
    dx = x[i] - x[j]
    dy = y[i] - y[j]
    return dx * dx + dy * dy


def uzakliklari_hesapla():
    global d
    d = [[math.sqrt(d2(i, j)) for j in range(n)] for i in range(n)]


def tur_uzunlugu(tur):
    t = 0.0
    for k in range(1, n):
        t += d[tur[k - 1]][tur[k]]
    return t + d[tur[n - 1]][tur[0]]


def tur_metni(tur):
    return "".join(f"{s}-" for s in tur) + str(tur[0])


def en_yakin_komsu():
    """Örnek 3: en yakın komşu, şehir 0'dan, eşitlikte küçük indeks"""
    ziyaret = [0] * n
    tur = [0] * n
    ziyaret[0] = 1
    for k in range(1, n):
        son = tur[k - 1]
        sec = -1
        for s in range(n):
            if not ziyaret[s] and (sec == -1 or d2(son, s) < d2(son, sec)):
                sec = s
        tur[k] = sec
        ziyaret[sec] = 1
    return tur


def ters_cevir(tur, i, j):
    while i < j:
        tur[i], tur[j] = tur[j], tur[i]
        i += 1
        j -= 1


def iki_opt(tur, ayrinti):
    """İlk iyileştirmeli 2-opt; dönen: uygulanan hamle sayısı"""
    global denenen
    iyilestirme = 0
    degisti = True
    while degisti:
        degisti = False
        i = 1
        while i < n - 1 and not degisti:
            j = i + 1
            while j < n and not degisti:
                a, b, c = tur[i - 1], tur[i], tur[j]
                e = tur[(j + 1) % n]
                kazanc = (d[a][c] + d[b][e]) - (d[a][b] + d[c][e])
                denenen += 1
                if kazanc < -EPS:
                    ters_cevir(tur, i, j)
                    iyilestirme += 1
                    degisti = True
                    if ayrinti:
                        print(f"    {iyilestirme:2d}  ({i}, {j})  {a}-{b}, "
                              f"{c}-{e}  {a}-{c}, {b}-{e}  {-kazanc:7.2f}  "
                              f"{tur_uzunlugu(tur):8.2f}   {tur_metni(tur)}")
                j += 1
            i += 1
    return iyilestirme


# --- Kaba kuvvet (Örnek 2) ---------------------------------------------
yol = []
kullanildi = []
en_iyi_tur = []
en_iyi = 0.0


def dene(k, kismi):
    global en_iyi, en_iyi_tur
    if k == n:
        toplam = kismi + d[yol[n - 1]][0]
        if toplam < en_iyi - EPS:
            en_iyi = toplam
            en_iyi_tur = yol[:]
        return
    for s in range(1, n):
        if not kullanildi[s]:
            kullanildi[s] = 1
            yol[k] = s
            dene(k + 1, kismi + d[yol[k - 1]][s])
            kullanildi[s] = 0


def kaba_kuvvet():
    global kullanildi, yol, en_iyi
    kullanildi = [0] * n
    yol = [0] * n
    kullanildi[0] = 1
    en_iyi = 1e300
    dene(1, 0.0)
    return en_iyi


def rastgele_sehirler(adet):
    global n, x, y
    n = adet
    x = [0] * n
    y = [0] * n
    for i in range(n):
        x[i] = rastgele_aralik(0, 99)
        y[i] = rastgele_aralik(0, 99)
    uzakliklari_hesapla()


def main():
    global n, x, y, denenen
    rastgele_tohum(2026)
    for _ in range(24):
        rastgele_sehirler(8)                   # 24. örneğe kadar ilerle
    print("1) Örnek 3'ün en kötü örneği (#24; tohum 2026, n = 8)\n"
          "   şehir:" + "".join(f" {i}({x[i]}, {y[i]})" for i in range(n)))
    tur = en_yakin_komsu()
    print(f"   NN turu: {tur_metni(tur)}  uzunluk {tur_uzunlugu(tur):.2f}")
    print("   2-opt adımları (ilk iyileştirme; i = 1..n-2, j = i+1..n-1)")
    print("   adım  (i, j)  çıkan     giren     kazanç  uzunluk   tur")
    denenen = 0
    adim = iki_opt(tur, True)
    kb = kaba_kuvvet()
    print(f"   iyileştirme = {adim}, denenen hamle = {denenen} (tam tarama "
          f"= (n-1)(n-2)/2 = {(n - 1) * (n - 2) // 2})")
    print(f"   2-opt: {tur_uzunlugu(tur):.2f}; en iyi (kaba kuvvet): "
          f"{kb:.2f}; oran {tur_uzunlugu(tur) / kb:.4f}")

    print("\n2) Örnek 3'ün 100 örneği (tohum 2026, n = 8): NN -> 2-opt")
    top_nn = top_2 = kotu_nn = kotu_2 = 0.0
    esit_nn = esit_2 = 0
    ilk_yerel = -1
    top_adim = 0
    yerel_tur = yerel_x = yerel_y = None
    rastgele_tohum(2026)
    for t in range(ORNEK):
        rastgele_sehirler(8)
        opt = kaba_kuvvet()
        tur = en_yakin_komsu()
        r1 = tur_uzunlugu(tur) / opt
        top_adim += iki_opt(tur, False)
        r2 = tur_uzunlugu(tur) / opt
        top_nn += r1
        top_2 += r2
        kotu_nn = r1 if r1 > kotu_nn else kotu_nn
        kotu_2 = r2 if r2 > kotu_2 else kotu_2
        esit_nn += r1 < 1.0 + 1e-9
        esit_2 += r2 < 1.0 + 1e-9
        if r2 >= 1.0 + 1e-9 and ilk_yerel == -1:
            ilk_yerel = t
            yerel_tur = tur[:]
            yerel_x = x[:]
            yerel_y = y[:]
    print("               en kötü  ortalama  = en iyi")
    print(f"   NN          {kotu_nn:.4f}    {top_nn / ORNEK:.4f}   "
          f"{esit_nn:3d} / {ORNEK}")
    print(f"   NN + 2-opt  {kotu_2:.4f}    {top_2 / ORNEK:.4f}   "
          f"{esit_2:3d} / {ORNEK}   (ortalama {top_adim / ORNEK:.2f} "
          "iyileştirme)")

    if ilk_yerel >= 0:
        n = 8
        x = yerel_x
        y = yerel_y
        uzakliklari_hesapla()
        print(f"\n3) Yerel en iyi != genel en iyi: örnek #{ilk_yerel + 1}\n"
              "   şehir:" + "".join(f" {i}({x[i]}, {y[i]})"
                                    for i in range(n)))
        denenen = 0
        ek = iki_opt(yerel_tur, False)
        print(f"   2-opt turu: {tur_metni(yerel_tur)}  uzunluk "
              f"{tur_uzunlugu(yerel_tur):.2f}")
        print(f"   yeniden tarama: {denenen} hamle, {ek} iyileştirme -> "
              "2-opt yerel en iyisi")
        kb = kaba_kuvvet()
        print(f"   genel en iyi: {tur_metni(en_iyi_tur)}  uzunluk {kb:.2f} "
              f"(oran {tur_uzunlugu(yerel_tur) / kb:.4f})")

    print("\n4) Büyük n (LCG, tohum 7): NN -> 2-opt")
    print("     n   NN uzunluğu  2-opt uzunluğu  iyileştirme   denenen hamle")
    adet = 25
    while adet <= 100:
        rastgele_tohum(7)
        rastgele_sehirler(adet)
        tur = en_yakin_komsu()
        u0 = tur_uzunlugu(tur)
        denenen = 0
        adim = iki_opt(tur, False)
        print(f"  {n:4d}  {u0:11.2f}  {tur_uzunlugu(tur):14.2f}  "
              f"{adim:11d}  {denenen:14d}")
        adet *= 2


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). 2-opt'un ilk iyileştirmeli
# bu sürümü sabit tarama sırası sayesinde belirleyicidir.

"""H14_09_donem_kiyas.py — AP-2 Hafta 14 · Örnek 9 (★★★)
Amaç    : Dönem kıyaslama programı: dönemin sekiz algoritmik çekirdeği
          sabit boyutlarda — ikili arama (H4), birleştirmeli sıralama
          (H6), öbek sıralaması (H7), karma tablosu (H10), BFS (H11),
          Dijkstra (H12), LCS (H13), 0/1 sırt çantası (H13). stdout'a
          YALNIZCA denetim toplamları; işlemci süreleri stderr'e ya da
          --csv ile CSV'ye. Girdiler ortak LCG'den (çekirdek başına tohum)
Kurallar: komşular artan köşe numarasıyla (eşitlikte ağırlık); öbekte
          (uzaklık, köşe) demetleri; karma: 32 bit Fibonacci çarpanı +
          doğrusal yoklama; denetim toplamlarının tanımı her çekirdekte
Çalıştır: python3 H14_09_donem_kiyas.py [--olcek K] [--tekrar T]
          [--csv dosya]
Eşleri  : c/H14_09_donem_kiyas.c · cpp/H14_09_donem_kiyas.cpp
Çıktı   : üç dilde aynı (=)
"""
import heapq
import os
import sys
from collections import deque

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn, ortanca

n = 0                               # çekirdeğin boyutu
g1 = []                             # veriler
g2 = []
yrd = []


# --- 1) İkili arama (H4): a[i] = 3i + 1; kontrol = Σ (konum + 1) -------
def arama_hazirla():
    rastgele_tohum(1)
    for i in range(n):
        g1[i] = 3 * i + 1
        g2[i] = rastgele_aralik(0, 3 * n)        # sorgular: 1/3 bulunur


def arama_calistir():
    kontrol = 0
    for q in range(n):
        lo, hi, x, konum = 0, n - 1, g2[q], -1
        while lo <= hi:
            orta = lo + (hi - lo) // 2
            if g1[orta] == x:
                konum = orta
                break
            elif g1[orta] < x:
                lo = orta + 1
            else:
                hi = orta - 1
        kontrol += konum + 1
    return kontrol


# --- Sıralama girdisi; kontrol = Σ (i mod 1000 + 1)·a[i], sırasızsa -1 -
def siralama_hazirla():
    rastgele_tohum(2)
    for i in range(n):
        g1[i] = rastgele_aralik(0, 1000000)


def siralama_kontrol(a):
    k = 0
    for i in range(n):
        if i > 0 and a[i - 1] > a[i]:
            return -1
        k += (i % 1000 + 1) * a[i]
    return k


# --- 2) Birleştirmeli sıralama (H6), a[lo..hi) -------------------------
def birlestirmeli(a, lo, hi):
    if hi - lo < 2:
        return
    orta = lo + (hi - lo) // 2
    birlestirmeli(a, lo, orta)
    birlestirmeli(a, orta, hi)
    i, j, k = lo, orta, lo
    while i < orta and j < hi:
        if a[i] <= a[j]:
            yrd[k] = a[i]
            i += 1
        else:
            yrd[k] = a[j]
            j += 1
        k += 1
    while i < orta:
        yrd[k] = a[i]
        i += 1
        k += 1
    while j < hi:
        yrd[k] = a[j]
        j += 1
        k += 1
    a[lo:hi] = yrd[lo:hi]


def birlestirmeli_calistir():
    a = g1[:n]
    birlestirmeli(a, 0, n)
    return siralama_kontrol(a)


# --- 3) Öbek sıralaması (H7): en büyük öbek, aşağı süzme ---------------
def asagi_suz(a, i, boy):
    while True:
        b, s, r = i, 2 * i + 1, 2 * i + 2
        if s < boy and a[s] > a[b]:
            b = s
        if r < boy and a[r] > a[b]:
            b = r
        if b == i:
            return
        a[i], a[b] = a[b], a[i]
        i = b


def obek_calistir():
    a = g1[:n]
    for i in range(n // 2 - 1, -1, -1):
        asagi_suz(a, i, n)
    for son in range(n - 1, 0, -1):
        a[0], a[son] = a[son], a[0]
        asagi_suz(a, 0, son)
    return siralama_kontrol(a)


# --- 4) Karma tablosu (H10): doğrusal yoklama, kapasite 2^k >= 2n -------
# kontrol = farklı anahtar + bulunan sorgu + toplam yoklama
karma_bit = 1


def karma_hazirla():
    global karma_bit
    rastgele_tohum(4)
    for i in range(n):
        g1[i] = rastgele_aralik(0, n)            # tekrarlı anahtarlar
        g2[i] = rastgele_aralik(0, 2 * n)        # sorgular
    karma_bit = 1
    while (1 << karma_bit) < 2 * n:
        karma_bit += 1


def karma(anahtar):
    """Fibonacci karması (32 bit işaretsiz aritmetik)"""
    return ((anahtar * 2654435769) & 0xFFFFFFFF) >> (32 - karma_bit)


def karma_calistir():
    kap = 1 << karma_bit
    maske = kap - 1
    tablo = [-1] * kap                           # -1 = boş
    farkli = bulunan = yoklama = 0
    for i in range(n):                           # ekle (varsa geç)
        h = karma(g1[i])
        yoklama += 1
        while tablo[h] != -1 and tablo[h] != g1[i]:
            h = (h + 1) & maske
            yoklama += 1
        if tablo[h] == -1:
            tablo[h] = g1[i]
            farkli += 1
    for q in range(n):                           # ara
        h = karma(g2[q])
        yoklama += 1
        while tablo[h] != -1 and tablo[h] != g2[q]:
            h = (h + 1) & maske
            yoklama += 1
        bulunan += tablo[h] == g2[q]
    return farkli + bulunan + yoklama


# --- Graf: V köşe, her köşeden 4 rastgele + (u+1) mod V kenarı (yönlü);
# komşular (v, w) artan sırada; CSR: köşe u'nun kenarları 5u..5u+4 -----
DERECE = 5


def graf_hazirla():
    rastgele_tohum(5)
    for u in range(n):
        v = [0] * DERECE
        w = [0] * DERECE
        for k in range(DERECE):
            v[k] = (u + 1) % n if k == 0 else rastgele_aralik(0, n - 1)
            w[k] = rastgele_aralik(1, 100)
        for k in range(1, DERECE):               # araya ekleme, (v, w)
            tv, tw, j = v[k], w[k], k - 1
            while j >= 0 and (v[j] > tv or (v[j] == tv and w[j] > tw)):
                v[j + 1] = v[j]
                w[j + 1] = w[j]
                j -= 1
            v[j + 1] = tv
            w[j + 1] = tw
        g1[DERECE * u:DERECE * u + DERECE] = v
        g2[DERECE * u:DERECE * u + DERECE] = w


# --- 5) BFS (H11) 0'dan; kontrol = Σ (uzaklık + 1), ulaşılanlar --------
def bfs_calistir():
    uz = [-1] * n
    kuyruk = deque([0])                          # H9'un kuyruğu
    kontrol = 0
    uz[0] = 0
    while kuyruk:
        u = kuyruk.popleft()
        kontrol += uz[u] + 1
        for k in range(DERECE * u, DERECE * u + DERECE):
            if uz[g1[k]] == -1:
                uz[g1[k]] = uz[u] + 1
                kuyruk.append(g1[k])
    return kontrol


# --- 6) Dijkstra (H12), öncelik kuyruğu, tembel silme; (d, v) demetleri
def dijkstra_calistir():
    obek = [(0, 0)]
    uz = [-1] * n                                # -1 = sonsuz
    uz[0] = 0
    kontrol = 0
    while obek:
        d, u = heapq.heappop(obek)               # en küçüğü çıkar
        if d > uz[u]:
            continue                             # eskimiş öğe
        kontrol += d
        for k in range(DERECE * u, DERECE * u + DERECE):
            v = g1[k]
            yeni = d + g2[k]
            if uz[v] == -1 or yeni < uz[v]:
                uz[v] = yeni
                heapq.heappush(obek, (yeni, v))
    return kontrol


# --- 7) LCS (H13): iki satırlı tablo; kontrol = LCS uzunluğu ----------
def lcs_hazirla():
    rastgele_tohum(7)
    for i in range(2 * n):
        g1[i] = ord("ACGT"[rastgele_aralik(0, 3)])


def lcs_calistir():
    onceki = [0] * (n + 1)
    simdi = [0] * (n + 1)
    a = g1[:n]
    b = g1[n:2 * n]
    for i in range(1, n + 1):
        simdi[0] = 0
        for j in range(1, n + 1):
            if a[i - 1] == b[j - 1]:
                simdi[j] = onceki[j - 1] + 1
            else:
                simdi[j] = (onceki[j] if onceki[j] >= simdi[j - 1]
                            else simdi[j - 1])
        onceki, simdi = simdi, onceki
    return onceki[n]


# --- 8) 0/1 sırt çantası (H13): tek satır, kapasite TERS sırada -------
SIRT_W = 1000


def sirt_hazirla():
    rastgele_tohum(8)
    for i in range(n):
        g1[i] = rastgele_aralik(1, 50)           # ağırlık
        g2[i] = rastgele_aralik(1, 100)          # değer


def sirt_calistir():
    dp = [0] * (SIRT_W + 1)
    for i in range(n):
        w, v = g1[i], g2[i]
        for c in range(SIRT_W, w - 1, -1):
            if dp[c - w] + v > dp[c]:
                dp[c] = dp[c - w] + v
    return dp[SIRT_W]


CEKIRDEK = [
    ("ikili_arama", "H4", "n sorgu, sıralı n dizide", 20000,
     arama_hazirla, arama_calistir),
    ("birlestirmeli", "H6", "n sayı", 20000, siralama_hazirla,
     birlestirmeli_calistir),
    ("obek_siralama", "H7", "n sayı", 20000, siralama_hazirla,
     obek_calistir),
    ("karma_tablosu", "H10", "n ekleme + n arama", 20000, karma_hazirla,
     karma_calistir),
    ("bfs", "H11", "V = n, E = 5n", 20000, graf_hazirla, bfs_calistir),
    ("dijkstra", "H12", "V = n, E = 5n, w 1..100", 20000, graf_hazirla,
     dijkstra_calistir),
    ("lcs", "H13", "n × n tablo", 600, lcs_hazirla, lcs_calistir),
    ("sirt_cantasi", "H13", "n nesne, W = 1000", 100, sirt_hazirla,
     sirt_calistir),
]


def sayi_al(s, alt, ust):
    """geçersizse None"""
    try:
        v = int(s)
    except ValueError:
        return None
    return v if alt <= v <= ust else None


def main():
    global n, g1, g2, yrd
    olcek, tekrar, csv = 1, 1, None
    i = 1
    while i < len(sys.argv):
        tamam = i + 1 < len(sys.argv)
        if tamam and sys.argv[i] == "--olcek":
            i += 1
            olcek = sayi_al(sys.argv[i], 1, 50)
            tamam = olcek is not None
        elif tamam and sys.argv[i] == "--tekrar":
            i += 1
            tekrar = sayi_al(sys.argv[i], 1, 101)
            tamam = tekrar is not None
        elif tamam and sys.argv[i] == "--csv":
            i += 1
            csv = sys.argv[i]
        else:
            tamam = False
        if not tamam:
            print(f"Kullanım: {sys.argv[0]} [--olcek K] [--tekrar T] "
                  "[--csv dosya]", file=sys.stderr)
            return 2
        i += 1
    f = None
    if csv is not None:
        try:
            f = open(csv, "a", encoding="utf-8")
        except OSError:
            print(f"{csv} açılamadı", file=sys.stderr)
            return 1
        if os.path.getsize(csv) == 0:
            f.write("cekirdek;n;dil;tekrar;islemci_ms;kontrol\n")
    print(f"Dönem kıyaslaması (ölçek {olcek}): denetim toplamları")
    print("  çekirdek        hafta         n              kontrol  boyut")
    for ad, hafta, aciklama, boyut, hazirla, calistir in CEKIRDEK:
        n = boyut * olcek
        uzunluk = DERECE * n + SIRT_W + 2
        g1 = [0] * uzunluk
        g2 = [0] * uzunluk
        yrd = [0] * uzunluk
        hazirla()
        kontrol = calistir()                     # ısınma + sonuç
        sure = []
        for _ in range(tekrar):
            t0 = islemci_sn()
            k2 = calistir()
            sure.append(islemci_sn() - t0)
            if k2 != kontrol:
                kontrol = -2                     # belirleyici değil!
        ort = ortanca(sure)
        print(f"  {ad:<14s}  {hafta:<5s}  {n:8d}  {kontrol:19d}  {aciklama}")
        print(f"{ad:<14s} n = {n:8d}: {ort * 1e3:10.3f} ms (işlemci, "
              f"ortanca, {tekrar} tekrar; bu çalıştırmada)", file=sys.stderr)
        if f is not None:
            f.write(f"{ad};{n};Python;{tekrar};{ort * 1e3:.6f};{kontrol}\n")
    if f is not None:
        f.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — bsearch, qsort; C++ — std::binary_search,
# std::stable_sort, std::make_heap/std::sort_heap, std::unordered_set,
# std::priority_queue; Python — bisect, sorted, heapq, set/dict.

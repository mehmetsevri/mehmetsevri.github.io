"""H14_05_held_karp.py — AP-2 Hafta 14 · Örnek 5 (★★★, merak)
Amaç    : Held–Karp: gezgin satıcı için bit maskesi DP'si. Üstel ama
          kaba kuvvetten çok hızlı: Θ(n²·2ⁿ) geçiş, n·2ⁿ tablo.
          n <= 10'da kaba kuvvetle (Örnek 2) aynı sonuç; tablo kesiti;
          bellek hesabı. İsteğe bağlı: --n N (4 <= N <= 16) tek ölçüm
DP      : durum dp[S][j] = 0'dan başlayıp S kümesindeki şehirleri birer
          kez gezerek j'de biten en kısa yol (0, j ∈ S) · geçiş dp[S][j]
          = min_i dp[S − {j}][i] + d(i, j) · temel dp[{0}][0] = 0 ·
          sıra S artan (alt küme her zaman daha küçük sayı) · cevap
          min_j dp[tümü][j] + d(j, 0) · geri çıkarma ebeveyn[S][j]
          (eşitlikte küçük i: katı "<")
Çalıştır: python3 H14_05_held_karp.py     python3 H14_05_held_karp.py --n 14
Eşleri  : c/H14_05_held_karp.c · cpp/H14_05_held_karp.cpp
Çıktı   : üç dilde aynı (=)
"""
import math
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn

MAKS_N = 16
KB_MAKS = 10
EPS = 1e-9
SONSUZ = 1e300

n = 0
x = []
y = []
d = []

dp = []                             # (1 << n) * n, düz liste
ebeveyn = []
durum = 0                           # hesaplanan dp[S][j]
gecis = 0


def uzakliklari_hesapla():
    global d
    d = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            d[i][j] = math.sqrt(dx * dx + dy * dy)


def tur_metni(tur):
    return "".join(f"{s}-" for s in tur) + "0"


def held_karp():
    """Dönen: (uzunluk, tur); tablolar dp, ebeveyn (genel)"""
    global dp, ebeveyn, durum, gecis
    boyut = (1 << n) * n
    dp = [SONSUZ] * boyut
    ebeveyn = [-1] * boyut
    dp[1 * n + 0] = 0.0                          # S = {0}, j = 0
    durum = 0
    gecis = 0
    for S in range(1, 1 << n, 2):                # 0'ı içeren kümeler
        for j in range(1, n):
            if not S & (1 << j):
                continue
            onceki = S ^ (1 << j)
            en = SONSUZ
            arg = -1
            for i in range(n):
                if not onceki & (1 << i) or dp[onceki * n + i] >= SONSUZ:
                    continue
                aday = dp[onceki * n + i] + d[i][j]
                gecis += 1
                if aday < en:
                    en = aday
                    arg = i
            dp[S * n + j] = en
            ebeveyn[S * n + j] = arg
            durum += 1
    tum = (1 << n) - 1
    son = -1
    en = SONSUZ
    for j in range(1, n):
        aday = dp[tum * n + j] + d[j][0]
        if aday < en:
            en = aday
            son = j
    tur = [0] * n
    S = tum
    for k in range(n - 1, 0, -1):                # geri çıkarma
        tur[k] = son
        i = ebeveyn[S * n + son]
        S ^= 1 << son
        son = i
    tur[0] = son                                 # 0 olmalı
    return en, tur


# --- Kaba kuvvet (Örnek 2) ---------------------------------------------
yol = []
kullanildi = []
kb_tur = []
en_iyi = 0.0


def dene(k, kismi):
    global en_iyi, kb_tur
    if k == n:
        toplam = kismi + d[yol[n - 1]][0]
        if toplam < en_iyi - EPS:
            en_iyi = toplam
            kb_tur = yol[:]
        return
    for s in range(1, n):
        if not kullanildi[s]:
            kullanildi[s] = 1
            yol[k] = s
            dene(k + 1, kismi + d[yol[k - 1]][s])
            kullanildi[s] = 0


def kaba_kuvvet():
    global kullanildi, yol, en_iyi
    kullanildi = [0] * n
    yol = [0] * n
    kullanildi[0] = 1
    en_iyi = SONSUZ
    dene(1, 0.0)
    return en_iyi


def sehirleri_kur(adet, tohum):
    global n, x, y
    n = adet
    rastgele_tohum(tohum)
    x = [0] * n
    y = [0] * n
    for i in range(n):
        x[i] = rastgele_aralik(0, 99)
        y[i] = rastgele_aralik(0, 99)
    uzakliklari_hesapla()


def kume_metni(S):
    return "{" + ",".join(str(i) for i in range(n) if S & (1 << i)) + "}"


def tek_olcum(adet):
    sehirleri_kur(adet, 42)
    t0 = islemci_sn()
    u, tur = held_karp()
    sure = islemci_sn() - t0
    print(f"n = {n}: uzunluk {u:.2f}, durum {durum}, geçiş {gecis}; tur "
          f"{tur_metni(tur)}")
    print(f"Held-Karp n = {n}: {sure * 1e3:.3f} ms (işlemci, bu "
          "çalıştırmada)", file=sys.stderr)
    return 0


def kullanim():
    print(f"Kullanım: {sys.argv[0]} [--n N]  (4 <= N <= 16)",
          file=sys.stderr)
    return 2


def main():
    global n, x, y
    if len(sys.argv) == 3 and sys.argv[1] == "--n":
        try:
            v = int(sys.argv[2])
        except ValueError:
            return kullanim()
        if v < 4 or v > MAKS_N:
            return kullanim()
        return tek_olcum(v)
    if len(sys.argv) != 1:
        return kullanim()

    x = [0, 6, 1, 5, 3]
    y = [0, 1, 4, 5, 2]
    n = 5
    uzakliklari_hesapla()
    u, tur = held_karp()
    print("1) Örnek 2'nin küçük örneği (n = 5): dp[S][j] tablosu "
          "(- = tanımsız)")
    print("  S               j=1     j=2     j=3     j=4    ebeveyn (j=1..4)")
    for S in range(1, 1 << n, 2):
        satir = f"  {kume_metni(S):<11s}"
        for j in range(1, n):
            v = dp[S * n + j]
            satir += f"  {'-':>6s}" if v >= SONSUZ else f"  {v:6.2f}"
        satir += "   " + "".join(f" {ebeveyn[S * n + j]:2d}"
                                 for j in range(1, n))
        print(satir)
    print(f"  cevap = min_j dp[{{0..4}}][j] + d(j, 0) = {u:.2f}; tur "
          f"{tur_metni(tur)}")
    print(f"  durum = {durum} = (n-1)·2^(n-2); geçiş = {gecis}")

    print("\n2) LCG şehirleri (tohum 42; Örnek 2 ile aynı örnekler)")
    print("   n   durum    geçiş     n²·2ⁿ  Held-Karp  kaba kuvvet  sonuç")
    for adet in range(4, 17):
        sehirleri_kur(adet, 42)
        t0 = islemci_sn()
        u, tur = held_karp()
        sure = islemci_sn() - t0
        satir = (f"  {n:2d}  {durum:6d}  {gecis:7d}  {n * n * (1 << n):8d}"
                 f"  {u:9.2f}")
        if n <= KB_MAKS:
            kb = kaba_kuvvet()
            satir += f"  {kb:11.2f}  " + ("aynı" if abs(kb - u) < 1e-6
                                          else "FARKLI")
        else:
            satir += f"  {'-':>11s}  -"
        print(satir)
        print(f"n = {adet:2d}: Held-Karp {sure * 1e3:.3f} ms (işlemci, bu "
              "çalıştırmada)", file=sys.stderr)
    sehirleri_kur(16, 42)
    u, tur = held_karp()
    print(f"   n = 16 turu: {tur_metni(tur)}")

    print("\n3) Bellek: n·2ⁿ tablo hücresi × (8 bayt dp + 1 bayt ebeveyn)")
    print("   n  tablo hücresi n·2ⁿ      bellek")
    for k in (10, 12, 14, 16, 18, 20, 25, 30):
        h = float(k) * math.pow(2.0, k)
        mib = h * 9.0 / 1048576.0
        print(f"  {k:2d}  {h:18.0f}  {mib:10.1f} MiB")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: yok (C, C++, Python). Kâhin: Örnek 2'nin kaba
# kuvveti (n <= 10). Uygulamada kesin çözücüler (ör. Concorde) dal-kesme
# yöntemleri kullanır; Held–Karp ders kitabı ölçeğinde bir DP'dir.

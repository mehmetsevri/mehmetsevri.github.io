"""H14_02_gs_kaba_kuvvet.py — AP-2 Hafta 14 · Örnek 2 (★★)
Amaç    : Gezgin satıcı, kaba kuvvet: şehir 0 sabit, 1..n−1'in bütün
          permütasyonları H3'ün üreticisiyle SÖZLÜK SIRASINDA denenir;
          denenen tur = (n − 1)!, ters turlar aynı uzunlukta (simetri)
Kurallar: tamsayı koordinatlar, Öklid uzaklığı sqrt; tur uzunluğu
          şehir 0'dan başlayıp soldan sağa toplanır; eşitlikte (fark
          < 1e-9) sözlük sırasında İLK bulunan tur korunur
Çalıştır: python3 H14_02_gs_kaba_kuvvet.py      (süreler stderr'e)
Eşleri  : c/H14_02_gs_kaba_kuvvet.c · cpp/H14_02_gs_kaba_kuvvet.cpp
Çıktı   : üç dilde aynı (=)
"""
import math
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn

EPS = 1e-9

n = 0
x = []
y = []
d = []                              # Öklid uzaklığı

yol = []                            # kurulmakta olan tur
kullanildi = []
en_iyi_tur = []
en_iyi = 0.0
tur_sayisi = 0
cagri_sayisi = 0
yaz_mi = False
yalniz_yari = False                 # yol[1] < yol[n-1]


def uzakliklari_hesapla():
    global d
    d = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            d[i][j] = math.sqrt(dx * dx + dy * dy)


def tur_metni(tur):
    return "".join(f"{s}-" for s in tur) + "0"


def dene(k, kismi):
    """yol[0..k-1] dolu (yol[0] = 0); kismi = yol boyunca uzunluk"""
    global cagri_sayisi, tur_sayisi, en_iyi, en_iyi_tur
    cagri_sayisi += 1
    if k == n:                                       # yaprak: tam tur
        if yalniz_yari and yol[1] > yol[n - 1]:
            return                                   # tersi zaten sayıldı
        toplam = kismi + d[yol[n - 1]][0]            # dönüş kenarı
        tur_sayisi += 1
        if yaz_mi:
            print(f"    {tur_sayisi:3d}  {tur_metni(yol)}  {toplam:7.2f}")
        if toplam < en_iyi - EPS:
            en_iyi = toplam
            en_iyi_tur = yol[:]
        return
    for s in range(1, n):
        if not kullanildi[s]:
            kullanildi[s] = 1                        # seç
            yol[k] = s
            dene(k + 1, kismi + d[yol[k - 1]][s])    # dene
            kullanildi[s] = 0                        # geri al


def kaba_kuvvet():
    global kullanildi, yol, en_iyi, tur_sayisi, cagri_sayisi
    kullanildi = [0] * n
    yol = [0] * n
    kullanildi[0] = 1
    en_iyi = 1e300
    tur_sayisi = 0
    cagri_sayisi = 0
    dene(1, 0.0)


def sehirleri_kur(adet, tohum):
    global n, x, y
    n = adet
    rastgele_tohum(tohum)
    x = [0] * n
    y = [0] * n
    for i in range(n):
        x[i] = rastgele_aralik(0, 99)
        y[i] = rastgele_aralik(0, 99)
    uzakliklari_hesapla()


def main():
    global n, x, y, yaz_mi, yalniz_yari
    x = [0, 6, 1, 5, 3]
    y = [0, 1, 4, 5, 2]
    n = 5
    uzakliklari_hesapla()
    print("1) Küçük örnek: n = 5 şehir\n   şehir:"
          + "".join(f"  {i}({x[i]}, {y[i]})" for i in range(n)))
    print("   d[i][j]  :" + "".join(f" {j:6d}" for j in range(n)))
    for i in range(n):
        print(f"   {i}        :" + "".join(f" {d[i][j]:6.2f}"
                                           for j in range(n)))
    print("   Turlar (şehir 0 sabit; 1..4 sözlük sırasıyla):")
    print("     no  tur          uzunluk")
    yaz_mi = True
    kaba_kuvvet()
    yaz_mi = False
    print(f"   denenen tur = {tur_sayisi} = 4!; çağrı = {cagri_sayisi}")
    print(f"   en iyi: {tur_metni(en_iyi_tur)}  uzunluk {en_iyi:.2f}")
    yalniz_yari = True
    kaba_kuvvet()
    yalniz_yari = False
    print("   yol[1] < yol[n-1] olanlar (her tur ile tersinden biri): "
          f"{tur_sayisi} = 4!/2")

    print("\n2) LCG şehirleri (tohum 42, koordinat 0..99)")
    print("   n  denenen tur     (n-1)!      çağrı   en iyi   en iyi tur")
    faktoriyel = 2                                   # (3 - 1)!
    for adet in range(4, 11):
        faktoriyel *= adet - 1
        sehirleri_kur(adet, 42)
        t0 = islemci_sn()
        kaba_kuvvet()
        sure = islemci_sn() - t0
        print(f"  {n:2d}  {tur_sayisi:11d}  {faktoriyel:9d}  "
              f"{cagri_sayisi:9d}  {en_iyi:7.2f}   {tur_metni(en_iyi_tur)}"
              + ("" if tur_sayisi == faktoriyel else "  FARKLI"))
        print(f"n = {adet:2d}: {sure * 1e3:.3f} ms (işlemci, bu "
              "çalıştırmada)", file=sys.stderr)

    print("\n3) Simetri: n = 10'da yalnız yol[1] < yol[9] olan turlar")
    tam = en_iyi
    yalniz_yari = True
    kaba_kuvvet()
    print(f"   değerlendirilen tur = {tur_sayisi} = 9!/2; en iyi = "
          f"{en_iyi:.2f} ("
          + ("aynı" if abs(en_iyi - tam) < 1e-6 else "FARKLI") + ")")
    print(f"   (yapraklar yine üretildi: çağrı = {cagri_sayisi}; gerçek "
          "kazanç için dal erken kesilmeli)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — std::next_permutation (sözlük
# sırasında sonraki); Python — itertools.permutations (yalnızca kâhin).

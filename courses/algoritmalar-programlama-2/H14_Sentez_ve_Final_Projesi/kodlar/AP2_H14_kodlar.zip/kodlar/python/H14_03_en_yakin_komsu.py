"""H14_03_en_yakin_komsu.py — AP-2 Hafta 14 · Örnek 3 (★★)
Amaç    : Gezgin satıcı için en yakın komşu sezgiseli: her adımda
          ziyaret edilmemiş en yakın şehre git (eşitlikte KÜÇÜK indeks;
          karşılaştırma tamsayı kare uzaklıkla). Kaba kuvvetle
          karşılaştırma: LCG ile 100 örnekte yaklaşım oranı (en kötü,
          ortalama, ortanca); aday incelemesi n(n−1)/2 → Θ(n²)
Çalıştır: python3 H14_03_en_yakin_komsu.py
Eşleri  : c/H14_03_en_yakin_komsu.c · cpp/H14_03_en_yakin_komsu.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_aralik, rastgele_tohum

EPS = 1e-9
ORNEK = 100

n = 0
x = []
y = []
d = []
aday_sayisi = 0                     # en yakın komşunun incelediği aday


def d2(i, j):
    """kare uzaklık: tam, eşitlik güvenli"""
    dx = x[i] - x[j]
    dy = y[i] - y[j]
    return dx * dx + dy * dy


def uzakliklari_hesapla():
    global d
    d = [[math.sqrt(d2(i, j)) for j in range(n)] for i in range(n)]


def tur_uzunlugu(tur):
    t = 0.0
    for k in range(1, n):
        t += d[tur[k - 1]][tur[k]]
    return t + d[tur[n - 1]][tur[0]]             # dönüş kenarı


def tur_metni(tur):
    return "".join(f"{s}-" for s in tur) + str(tur[0])


def en_yakin_komsu(bas, ayrinti):
    """En yakın komşu: bas'tan başla; ayrinti ise her adımı yaz"""
    global aday_sayisi
    ziyaret = [0] * n
    tur = [bas]
    ziyaret[bas] = 1
    for k in range(1, n):
        son = tur[k - 1]
        sec = -1
        en_az = 0
        satir = f"    {k}     {son}    "
        for s in range(n):
            if not ziyaret[s]:
                dd = d2(son, s)
                aday_sayisi += 1
                satir += f" {s}:{dd}"
                if sec == -1 or dd < en_az:      # eşitlikte ilk (küçük)
                    sec = s
                    en_az = dd
        if ayrinti:
            print(f"{satir}  -> {sec}")
        tur.append(sec)
        ziyaret[sec] = 1
    return tur


# --- Kaba kuvvet (Örnek 2) ---------------------------------------------
yol = []
kullanildi = []
en_iyi_tur = []
en_iyi = 0.0


def dene(k, kismi):
    global en_iyi, en_iyi_tur
    if k == n:
        toplam = kismi + d[yol[n - 1]][0]
        if toplam < en_iyi - EPS:
            en_iyi = toplam
            en_iyi_tur = yol[:]
        return
    for s in range(1, n):
        if not kullanildi[s]:
            kullanildi[s] = 1
            yol[k] = s
            dene(k + 1, kismi + d[yol[k - 1]][s])
            kullanildi[s] = 0


def kaba_kuvvet():
    global kullanildi, yol, en_iyi
    kullanildi = [0] * n
    yol = [0] * n
    kullanildi[0] = 1
    en_iyi = 1e300
    dene(1, 0.0)
    return en_iyi


def rastgele_sehirler(adet):
    global n, x, y
    n = adet
    x = [0] * n
    y = [0] * n
    for i in range(n):
        x[i] = rastgele_aralik(0, 99)
        y[i] = rastgele_aralik(0, 99)
    uzakliklari_hesapla()


def main():
    global n, x, y, aday_sayisi
    x = [0, 6, 1, 5, 3]
    y = [0, 1, 4, 5, 2]
    n = 5
    uzakliklari_hesapla()
    print("1) Örnek 2'nin küçük örneği (n = 5), şehir 0'dan; aday s:d²")
    print("  adım  son   adaylar              seçilen")
    aday_sayisi = 0
    tur = en_yakin_komsu(0, True)
    nn = tur_uzunlugu(tur)
    kb = kaba_kuvvet()
    print(f"   NN turu: {tur_metni(tur)}  uzunluk {nn:.2f}")
    print(f"   en iyi : {tur_metni(en_iyi_tur)}  uzunluk {kb:.2f}")
    print(f"   oran = {nn / kb:.4f}; aday incelemesi = {aday_sayisi} = "
          "n(n-1)/2")

    print(f"\n2) LCG (tohum 2026), n = 8, {ORNEK} örnek; oran = NN / en iyi")
    oran = [[0.0] * ORNEK for _ in range(2)]
    esit = [0, 0]
    en_kotu_no = 0
    toplam = [0.0, 0.0]
    kx8 = []
    ky8 = []
    rastgele_tohum(2026)
    for t in range(ORNEK):
        rastgele_sehirler(8)
        kx8.append(x[:])
        ky8.append(y[:])
        opt = kaba_kuvvet()
        tur = en_yakin_komsu(0, False)
        oran[0][t] = tur_uzunlugu(tur) / opt
        en_iyi_bas = 1e300                       # her başlangıçtan NN
        for b in range(n):
            u = tur_uzunlugu(en_yakin_komsu(b, False))
            if u < en_iyi_bas - EPS:
                en_iyi_bas = u
        oran[1][t] = en_iyi_bas / opt
        for v in range(2):
            toplam[v] += oran[v][t]
            esit[v] += oran[v][t] < 1.0 + 1e-9
        if oran[0][t] > oran[0][en_kotu_no]:
            en_kotu_no = t
    ad = ["NN (şehir 0'dan)     ", "NN (en iyi başlangıç)"]
    sinir = [1.05, 1.10, 1.20, 1.30, 1e300]
    print("                         en kötü  ortalama  ortanca  NN = en iyi")
    for v in range(2):
        s = sorted(oran[v])
        print(f"   {ad[v]}   {s[ORNEK - 1]:.4f}    {toplam[v] / ORNEK:.4f}   "
              f"{(s[ORNEK // 2 - 1] + s[ORNEK // 2]) / 2.0:.4f}   "
              f"{esit[v]:3d} / {ORNEK}")
    satir = f"   dağılım (şehir 0'dan): = 1: {esit[0]}"
    alt = 1.0
    for b in range(5):
        say = 0
        for t in range(ORNEK):
            say += (oran[0][t] >= 1.0 + 1e-9 and oran[0][t] > alt
                    and oran[0][t] <= sinir[b])
        if b < 4:
            satir += f" · ({alt:.2f}, {sinir[b]:.2f}]: {say}"
        else:
            satir += f" · > {alt:.2f}: {say}"
        alt = sinir[b]
    print(satir)

    print(f"\n3) En kötü örnek: #{en_kotu_no + 1} (oran "
          f"{oran[0][en_kotu_no]:.4f})")
    n = 8
    x = kx8[en_kotu_no]
    y = ky8[en_kotu_no]
    print("   şehir:" + "".join(f" {i}({x[i]}, {y[i]})" for i in range(n)))
    uzakliklari_hesapla()
    tur = en_yakin_komsu(0, False)
    kb = kaba_kuvvet()
    print(f"   NN    : {tur_metni(tur)}  uzunluk {tur_uzunlugu(tur):.2f}")
    print(f"   en iyi: {tur_metni(en_iyi_tur)}  uzunluk {kb:.2f}")

    print("\n4) Aday incelemesi n(n-1)/2: Θ(n²) (LCG, tohum 7)")
    print("     n     aday  n(n-1)/2  NN uzunluğu")
    adet = 10
    while adet <= 200:
        rastgele_tohum(7)
        rastgele_sehirler(adet)
        aday_sayisi = 0
        tur = en_yakin_komsu(0, False)
        print(f"  {n:4d}  {aday_sayisi:7d}  {n * (n - 1) // 2:8d}  "
              f"{tur_uzunlugu(tur):11.2f}")
        adet *= 2


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Kâhin: Örnek 2'nin kaba
# kuvveti (n <= 10).

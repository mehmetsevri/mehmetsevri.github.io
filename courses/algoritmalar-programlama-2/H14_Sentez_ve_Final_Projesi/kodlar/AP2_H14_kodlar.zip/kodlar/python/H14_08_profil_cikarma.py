"""H14_08_profil_cikarma.py — AP-2 Hafta 14 · Örnek 8 (★★★)
Amaç    : Profil çıkarma: KASITLI darboğazlı küçük bir kayıt işleme
          programı (üretim, istatistik, O(n²) yinelenen tespiti, harf
          dağılımı, ilk 3). Profil (gprof / cProfile) asıl zamanın tüm
          çiftlerde geçtiğini gösterir; darboğaz "sırala + komşular"
          (H6, O(n log n)) ile giderilir. stdout belirleyicidir; adım
          süreleri (işlemci zamanı) stderr'e "bu çalıştırmada" yazılır
Profil  : python3 -m cProfile -s tottime H14_08_profil_cikarma.py 4000
Çalıştır: python3 H14_08_profil_cikarma.py [n] [--surum yavas|hizli|ikisi]
Eşleri  : c/H14_08_profil_cikarma.c · cpp/H14_08_profil_cikarma.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_karistir, rastgele_tohum
from zamanlayici import islemci_sn

TABAN_NO = 220000000

numara = []
notlar = []
gecici = []
n = 0


def kayitlari_uret():
    """1) Üretim: numaralar ardışık ve karışık; %1'i öncekilerden birinin
    kopyası (kasıtlı yinelenen)"""
    global numara, notlar
    yinelenen = 0
    rastgele_tohum(8)
    numara = [0] * n
    notlar = [0] * n
    for i in range(n):
        numara[i] = TABAN_NO + i
        notlar[i] = rastgele_aralik(0, 100)
    rastgele_karistir(numara)
    for i in range(1, n):
        if rastgele_aralik(0, 99) == 0:
            numara[i] = numara[rastgele_aralik(0, i - 1)]
            yinelenen += 1
    return yinelenen


def istatistik():
    """2) İstatistik: toplam, en düşük, en yüksek — O(n)"""
    toplam = 0
    en_dusuk = 100
    en_yuksek = 0
    for x in notlar:
        toplam += x
        en_dusuk = x if x < en_dusuk else en_dusuk
        en_yuksek = x if x > en_yuksek else en_yuksek
    return toplam, en_dusuk, en_yuksek


def yinelenen_ciftler():
    """3a) Yinelenen, YAVAŞ: tüm çiftler — n(n−1)/2 karşılaştırma
    (darboğaz). Dönen: (çift, karşılaştırma)"""
    cift = 0
    kars = 0
    for i in range(n):
        for j in range(i + 1, n):
            kars += 1
            cift += numara[i] == numara[j]
    return cift, kars


def birlestirmeli(a, lo, hi):
    """Birleştirmeli sıralama (H6), a[lo..hi), artan; dönen: karşılaştırma"""
    if hi - lo < 2:
        return 0
    orta = lo + (hi - lo) // 2
    kars = birlestirmeli(a, lo, orta) + birlestirmeli(a, orta, hi)
    i, j, k = lo, orta, lo
    while i < orta and j < hi:
        kars += 1
        if a[i] <= a[j]:
            gecici[k] = a[i]
            i += 1
        else:
            gecici[k] = a[j]
            j += 1
        k += 1
    while i < orta:
        gecici[k] = a[i]
        i += 1
        k += 1
    while j < hi:
        gecici[k] = a[j]
        j += 1
        k += 1
    a[lo:hi] = gecici[lo:hi]
    return kars


def yinelenen_siralama():
    """3b) Yinelenen, HIZLI: kopyayı sırala, eşit komşu gruplarını say"""
    global gecici
    cift = 0
    kopya = numara[:]
    gecici = [0] * n
    kars = birlestirmeli(kopya, 0, n)
    i = 0
    while i < n:
        j = i + 1
        while j < n and kopya[j] == kopya[i]:
            kars += 1
            j += 1
        cift += (j - i) * (j - i - 1) // 2      # grup içi çift
        i = j
    return cift, kars


HARF = ["AA", "BA", "BB", "CB", "CC", "DC", "DD", "FF"]
ALT = [90, 85, 80, 70, 60, 55, 50, 0]


def harf_dagilimi():
    """4) Harf dağılımı (örnek ölçek) — O(n)"""
    say = [0] * 8
    for x in notlar:
        h = 0
        while x < ALT[h]:
            h += 1
        say[h] += 1
    return say


def ilk_uc():
    """5) İlk 3: en yüksek not, eşitlikte küçük numara — 3 tarama"""
    sec = [-1, -1, -1]
    for k in range(3):
        for i in range(n):
            alindi = False
            for t in range(k):
                alindi = alindi or sec[t] == i
            if not alindi and (sec[k] == -1 or notlar[i] > notlar[sec[k]]
                               or (notlar[i] == notlar[sec[k]]
                                   and numara[i] < numara[sec[k]])):
                sec[k] = i
    return sec


def kullanim():
    print(f"Kullanım: {sys.argv[0]} [n] [--surum yavas|hizli|ikisi] "
          "(10 <= n <= 10^6)", file=sys.stderr)
    return 2


def main():
    global n
    adet = 4000
    yavas = hizli = True
    i = 1
    while i < len(sys.argv):
        if sys.argv[i] == "--surum" and i + 1 < len(sys.argv):
            i += 1
            s = sys.argv[i]
            yavas = s != "hizli"
            hizli = s != "yavas"
            if s not in ("yavas", "hizli", "ikisi"):
                print("--surum yavas|hizli|ikisi", file=sys.stderr)
                return 2
        else:
            try:
                v = int(sys.argv[i])
            except ValueError:
                return kullanim()
            if v < 10 or v > 1000000:
                return kullanim()
            adet = v
        i += 1
    n = adet
    t0 = islemci_sn()
    t = [0.0] * 6
    yin = kayitlari_uret()
    t[0] = islemci_sn()
    toplam, dusuk, yuksek = istatistik()
    t[1] = islemci_sn()
    cift_y = cift_h = -1
    kars_y = kars_h = 0
    if yavas:
        cift_y, kars_y = yinelenen_ciftler()
    t[2] = islemci_sn()
    if hizli:
        cift_h, kars_h = yinelenen_siralama()
    t[3] = islemci_sn()
    say = harf_dagilimi()
    t[4] = islemci_sn()
    sec = ilk_uc()
    t[5] = islemci_sn()

    print(f"Kayıt işleme (n = {n}, tohum 8)")
    print(f"  1) üretim      : {n} kayıt, {yin} kasıtlı yinelenen numara")
    print(f"  2) istatistik  : ortalama {toplam / n:.2f}, en düşük {dusuk}, "
          f"en yüksek {yuksek}")
    if yavas:
        print(f"  3) yinelenen   : {cift_y} eşit çift (tüm çiftler, {kars_y} "
              "karşılaştırma)")
    if hizli:
        print(f"  3) yinelenen   : {cift_h} eşit çift (sırala + komşular, "
              f"{kars_h} karşılaştırma)")
    if yavas and hizli:
        print("     iki sürüm aynı mı: "
              + ("evet" if cift_y == cift_h else "HAYIR"))
    print("  4) harf        :" + "".join(f" {HARF[h]} {say[h]}"
                                         for h in range(8)))
    print("  5) ilk 3       :" + "".join(f" {numara[k]} ({notlar[k]})"
                                         for k in sec))

    ad = ["üretim", "istatistik", "yinelenen (yavaş)", "yinelenen (hızlı)",
          "harf", "ilk 3"]
    onceki = t0
    toplam_sn = t[5] - t0
    print(f"Adım süreleri (işlemci, bu çalıştırmada; n = {n}):",
          file=sys.stderr)
    for k in range(6):
        yuzde = 100.0 * (t[k] - onceki) / toplam_sn if toplam_sn > 0 else 0
        print(f"  {ad[k]:<18s} {(t[k] - onceki) * 1e3:10.3f} ms  "
              f"%{yuzde:5.1f}", file=sys.stderr)
        onceki = t[k]
    if yavas and hizli and t[3] > t[2]:
        print(f"  yinelenen: yavaş / hızlı = "
              f"{(t[2] - t[1]) / (t[3] - t[2]):.1f} kat", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — qsort ile sıralama; C++ — std::sort,
# std::unordered_set (karma, H10); Python — sorted, set/collections.Counter.
# Burada algoritmalar elle yazıldı; profil, darboğazın yerini gösterir.

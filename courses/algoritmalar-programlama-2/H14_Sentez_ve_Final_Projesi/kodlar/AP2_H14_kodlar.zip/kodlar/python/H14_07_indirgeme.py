"""H14_07_indirgeme.py — AP-2 Hafta 14 · Örnek 7 (★★)
Amaç    : İndirgeme (modelleme): yeni bir problemi BİLİNEN bir çözücüye
          çevirmek. (1) Sudoku → geri izleme (H3 Örnek 13); (2) labirent
          → ızgara grafında BFS (H11 Örnek 10); (3) ders planı → yönlü
          grafta topolojik sıralama (H11 Örnek 11, Kahn). Benzeri: sınav
          programı → graf boyama (H12 Örnek 13)
Kurallar: komşular artan köşe numarasıyla (yukarı, sol, sağ, aşağı);
          Kahn'da giriş derecesi 0 olanlardan EN KÜÇÜK numaralı seçilir
          (doğrusal tarama; V küçük); ders kodu → köşe: alfabetik sıra
Çalıştır: python3 H14_07_indirgeme.py ../girdiler/H14_07_sudoku.txt \\
          ../girdiler/H14_07_labirent.txt ../girdiler/H14_07_ders_plani.txt
Eşleri  : c/H14_07_indirgeme.c · cpp/H14_07_indirgeme.cpp
Çıktı   : üç dilde aynı (=); okunamayan/bozuk dosyada çıkış kodu 1
"""
import sys
from collections import deque


class BicimHatasi(Exception):
    pass


def satirlar(yol):
    """Dosyanın satırları (sondaki \\r\\n silinmiş); açılamazsa OSError"""
    with open(yol, encoding="utf-8") as f:
        return [s.rstrip("\r\n") for s in f]


def yorumsuz(satir_listesi, i):
    """i'den başlayarak yorum olmayan, boş olmayan ilk satır: (satır, i)"""
    while i < len(satir_listesi):
        s = satir_listesi[i]
        i += 1
        if s and s[0] != "#":
            return s, i
    return None, i


# === 1) Sudoku -> geri izleme (H3 Örnek 13) ===========================
tablo = [[0] * 9 for _ in range(9)]     # 0 = boş kare
satir_var = [[False] * 10 for _ in range(9)]
sutun_var = [[False] * 10 for _ in range(9)]
kutu_var = [[False] * 10 for _ in range(9)]
sudoku_dugum = 0


def kutu_no(r, c):
    return (r // 3) * 3 + c // 3


def isaretle(r, c, d, deger):
    satir_var[r][d] = deger
    sutun_var[c][d] = deger
    kutu_var[kutu_no(r, c)][d] = deger


def sudoku_oku(yol):
    """Dönen: ipucu sayısı; BicimHatasi / OSError"""
    L = satirlar(yol)
    i = 0
    ipucu = 0
    for r in range(9):
        s, i = yorumsuz(L, i)
        if s is None or len(s) != 9:
            raise BicimHatasi
        for c in range(9):
            if s[c] == ".":
                d = 0
            elif "1" <= s[c] <= "9":
                d = ord(s[c]) - ord("0")
            else:
                raise BicimHatasi
            if d > 0:
                if (satir_var[r][d] or sutun_var[c][d]
                        or kutu_var[kutu_no(r, c)][d]):
                    raise BicimHatasi            # ipuçları çelişiyor
                isaretle(r, c, d, True)
                ipucu += 1
            tablo[r][c] = d
    return ipucu


def sudoku_coz(konum):
    """İlk boş kareyi (satır satır) bul; 1..9'u dene; çıkmazda geri al"""
    global sudoku_dugum
    sudoku_dugum += 1
    while konum < 81 and tablo[konum // 9][konum % 9] != 0:
        konum += 1
    if konum == 81:
        return True                              # bütün kareler dolu
    r, c = konum // 9, konum % 9
    for d in range(1, 10):
        if (not satir_var[r][d] and not sutun_var[c][d]
                and not kutu_var[kutu_no(r, c)][d]):
            tablo[r][c] = d                      # seç
            isaretle(r, c, d, True)
            if sudoku_coz(konum + 1):            # dene
                return True
            isaretle(r, c, d, False)             # geri al
            tablo[r][c] = 0
    return False


def sudoku_say(konum, sinir):
    """Çözüm sayısı (en çok sinir'e kadar): bulmaca iyi tanımlı mı?"""
    while konum < 81 and tablo[konum // 9][konum % 9] != 0:
        konum += 1
    if konum == 81:
        return 1
    r, c = konum // 9, konum % 9
    say = 0
    d = 1
    while d <= 9 and say < sinir:
        if (not satir_var[r][d] and not sutun_var[c][d]
                and not kutu_var[kutu_no(r, c)][d]):
            tablo[r][c] = d
            isaretle(r, c, d, True)
            say += sudoku_say(konum + 1, sinir - say)
            isaretle(r, c, d, False)
            tablo[r][c] = 0
        d += 1
    return say


def sudoku_yaz():
    for r in range(9):
        satir = "   "
        for c in range(9):
            satir += str(tablo[r][c]) if tablo[r][c] else "."
            if c < 8:
                satir += " | " if c % 3 == 2 else " "
        print(satir)
        if r % 3 == 2 and r < 8:
            print("   ------+-------+------")


# === 2) Labirent -> BFS (H11 Örnek 10) ================================
izgara = []
R = C = 0


def labirent_oku(yol):
    """Dönen: (bas, hedef); BicimHatasi / OSError"""
    global R, C, izgara
    L = satirlar(yol)
    s, i = yorumsuz(L, 0)
    try:
        R, C = (int(t) for t in s.split()[:2])
    except (AttributeError, ValueError):
        raise BicimHatasi from None
    if R < 1 or R > 32 or C < 1 or C > 64:
        raise BicimHatasi
    bas = hedef = -1
    izgara = []
    for r in range(R):
        if i >= len(L) or len(L[i]) != C:        # ham satır: '#' olabilir
            raise BicimHatasi
        s = L[i]
        i += 1
        for c in range(C):
            if s[c] == "S":
                bas = r * C + c
            elif s[c] == "E":
                hedef = r * C + c
        izgara.append(list(s))
    if bas < 0 or hedef < 0:
        raise BicimHatasi
    return bas, hedef


def bfs(bas, hedef):
    """Ağırlıksız grafta BFS; köşe = r·C + c.
    Dönen: (uzaklık listesi, ebeveyn listesi, kuyruktan çıkan köşe)"""
    kuyruk = deque()                             # H9'un kuyruğu
    dr = (-1, 0, 0, 1)
    dc = (0, -1, 1, 0)
    uzaklik = [-1] * (R * C)
    ebeveyn = [-1] * (R * C)
    uzaklik[bas] = 0
    kuyruk.append(bas)
    ziyaret_sayisi = 0
    while kuyruk:
        u = kuyruk.popleft()
        ziyaret_sayisi += 1
        if u == hedef:
            break
        for k in range(4):                       # artan köşe numarası
            r, c = u // C + dr[k], u % C + dc[k]
            if r < 0 or r >= R or c < 0 or c >= C or izgara[r][c] == "#":
                continue
            v = r * C + c
            if uzaklik[v] == -1:
                uzaklik[v] = uzaklik[u] + 1
                ebeveyn[v] = u
                kuyruk.append(v)
    return uzaklik, ebeveyn, ziyaret_sayisi


# === 3) Ders planı -> topolojik sıralama (H11 Örnek 11, Kahn) =========
kod = []
V = E = 0
komsu = []                                       # komşuluk matrisi


def kod_bul(k):
    """yoksa -1"""
    for i in range(V):
        if kod[i] == k:
            return i
    return -1


def plan_oku(yol):
    """İki geçiş: kodları topla ve alfabetik sırala (köşe numarası), sonra
    kenarları kur. BicimHatasi / OSError"""
    global kod, V, E, komsu
    L = satirlar(yol)
    ciftler = []
    kod = []
    V = E = 0
    i = 0
    while True:
        s, i = yorumsuz(L, i)
        if s is None:
            break
        t = s.split()
        if E == 128 or len(t) < 2 or len(t[0]) >= 9 or len(t[1]) >= 9:
            raise BicimHatasi
        ciftler.append((t[0], t[1]))
        E += 1
        for k in (t[0], t[1]):
            if kod_bul(k) == -1:
                if V == 32:
                    raise BicimHatasi
                kod.append(k)
                V += 1
    kod = sorted(kod)                            # araç: sıralama
    komsu = [[0] * V for _ in range(V)]
    for a, b in ciftler:
        komsu[kod_bul(a)][kod_bul(b)] = 1


def kahn():
    """Dönen: (sıralanan köşe sayısı, sıra, dönem); sayı < V ise döngü"""
    giris = [0] * V
    alindi = [0] * V
    donem = [1] * V
    sira = []
    for u in range(V):
        for v in range(V):
            giris[v] += komsu[u][v]
    for k in range(V):
        sec = -1
        v = 0
        while v < V and sec == -1:               # en küçük numara
            if not alindi[v] and giris[v] == 0:
                sec = v
            v += 1
        if sec == -1:
            return k, sira, donem                # döngü: kalanlar
        alindi[sec] = 1
        sira.append(sec)
        for v in range(V):
            if komsu[sec][v]:
                giris[v] -= 1
                if donem[sec] + 1 > donem[v]:
                    donem[v] = donem[sec] + 1    # en uzun önkoşul zinciri
    return V, sira, donem


def hata(yol, e):
    ileti = "dosya açılamadı" if isinstance(e, OSError) else "biçim hatası"
    print(f"{yol}: {ileti}", file=sys.stderr)
    return 1


def main():
    global sudoku_dugum
    if len(sys.argv) != 4:
        print(f"Kullanım: {sys.argv[0]} sudoku.txt labirent.txt plan.txt",
              file=sys.stderr)
        return 2
    print("1) Sudoku -> geri izleme (H3 Örnek 13)")
    print("   Modelleme: boş kare = karar; aday = 1..9; kısıt = satır, "
          "sütun, 3x3 kutu")
    try:
        ipucu = sudoku_oku(sys.argv[1])
    except (OSError, BicimHatasi) as e:
        return hata(sys.argv[1], e)
    print(f"   Bulmaca ({ipucu} ipucu, {81 - ipucu} boş kare):")
    sudoku_yaz()
    print(f"   çözüm sayısı (2'de durur): {sudoku_say(0, 2)}")
    sudoku_dugum = 0
    cozuldu = sudoku_coz(0)
    print(f"   {'Çözüm' if cozuldu else 'Çözüm yok'} (ziyaret edilen düğüm "
          f"= {sudoku_dugum}):")
    if cozuldu:
        sudoku_yaz()

    print("\n2) Labirent -> BFS (H11 Örnek 10)")
    print("   Modelleme: boş hücre = köşe (r*C + c); yatay/dikey komşu boş "
          "hücre = kenar;\n   ağırlıksız en kısa yol = BFS")
    try:
        bas, hedef = labirent_oku(sys.argv[2])
    except (OSError, BicimHatasi) as e:
        return hata(sys.argv[2], e)
    kose = kenar = 0
    for r in range(R):
        for c in range(C):
            if izgara[r][c] != "#":
                kose += 1
                kenar += c + 1 < C and izgara[r][c + 1] != "#"
                kenar += r + 1 < R and izgara[r + 1][c] != "#"
    uzaklik, ebeveyn, ziyaret = bfs(bas, hedef)
    u = uzaklik[hedef]
    print(f"   {R} x {C} ızgara: köşe = {kose}, kenar = {kenar}; S = "
          f"({bas // C}, {bas % C}) köşe {bas}, E = ({hedef // C}, "
          f"{hedef % C}) köşe {hedef}")
    if u < 0:
        print(f"   E'ye yol yok (ziyaret edilen köşe = {ziyaret})")
    else:
        print(f"   en kısa yol = {u} adım; kuyruktan çıkan köşe = {ziyaret}")
        v = ebeveyn[hedef]
        while v != bas:
            izgara[v // C][v % C] = "*"
            v = ebeveyn[v]
        for satir in izgara:
            print("   " + "".join(satir))

    print("\n3) Ders planı -> topolojik sıralama (H11 Örnek 11, Kahn)")
    print("   Modelleme: ders kodu = köşe (alfabetik numara); \"A B\" "
          "satırı = A -> B kenarı;\n   geçerli plan = topolojik sıra; "
          "döngü varsa plan yok")
    try:
        plan_oku(sys.argv[3])
    except (OSError, BicimHatasi) as e:
        return hata(sys.argv[3], e)
    print(f"   köşe = {V}, kenar = {E}:"
          + ",".join(f" {v} {kod[v]}" for v in range(V)))
    s, sira, donem = kahn()
    if s < V:
        print(f"   döngü var: yalnız {s} ders sıralanabildi; plan yok")
        return 0
    print("   topolojik sıra: " + " ".join(kod[v] for v in sira))
    print("   dönemler (en erken dönem = en uzun önkoşul zinciri + 1):")
    for d in range(1, V + 1):
        ad = [kod[v] for v in sira if donem[v] == d]
        if ad:
            print(f"     {d}. dönem: " + " ".join(ad))
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — yok; C++ — yok (Boost.Graph:
# topological_sort); Python — graphlib.TopologicalSorter (3.9+; yalnızca
# kâhin). Sıralama (qsort / std::sort / sorted) burada yalnız araçtır.

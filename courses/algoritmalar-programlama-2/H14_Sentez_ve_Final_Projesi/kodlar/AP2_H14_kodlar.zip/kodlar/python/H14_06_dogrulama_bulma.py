"""H14_06_dogrulama_bulma.py — AP-2 Hafta 14 · Örnek 6 (★)
Amaç    : NP sezgisi: alt küme toplamında verilen bir çözümü (sertifika:
          seçilen indisler) DOĞRULAMAK O(n) adımdır; çözümü BULMAK için
          bilinen yollar H3'ün geri izlemesi (en kötü 2^(n+1) − 1 düğüm) ve
          H13'ün sözde polinom DP'sidir ((n+1)·(T+1) hücre). "Evet"
          örneğinde sertifika vardır; "hayır" örneğinde gösterilecek
          sertifika yoktur (doğrulama yalnız "evet" yanıtları içindir)
Çalıştır: python3 H14_06_dogrulama_bulma.py
Eşleri  : c/H14_06_dogrulama_bulma.c · cpp/H14_06_dogrulama_bulma.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum

a = []


def dogrula(hedef, sec):
    """Doğrulayıcı: sertifika sec (indisler) geçerli mi, tekrarsız mı,
    toplamı hedef mi? Her öğe için bir adım + son karşılaştırma: O(n + k).
    Dönen: (sonuç, adım, neden)"""
    n = len(a)
    goruldu = [False] * n
    toplam = 0
    adim = 0
    if len(sec) > n:
        return False, adim, "öğe sayısı n'den fazla"
    for i in sec:
        adim += 1
        if i < 0 or i >= n:
            return False, adim, "indis dizi dışında"
        if goruldu[i]:
            return False, adim, "aynı indis iki kez"
        goruldu[i] = True
        toplam += a[i]
    adim += 1
    if toplam != hedef:
        return False, adim, "toplam hedefe eşit değil"
    return True, adim, "toplam = hedef"


# --- Bulma 1: H3'ün budamalı geri izlemesi, ilk çözümde dur ------------
dugum = 0
yol = []
bulunan = []


def geri_izle(i, toplam, hedef):
    global dugum, bulunan
    dugum += 1
    if toplam > hedef:
        return False                       # a_i > 0: torunlar da aşar
    if i == len(a):
        if toplam == hedef:
            bulunan = yol[:]
            return True
        return False
    if geri_izle(i + 1, toplam, hedef):              # önce almadan
        return True
    yol.append(i)                                    # sonra alarak
    bulundu = geri_izle(i + 1, toplam + a[i], hedef)
    yol.pop()
    return bulundu


# --- Bulma 2: H13'ün DP'si (bool tablo) + geri çıkarma ----------------
hucre = 0


def dp_bul(hedef):
    """Dönen: (var mı, seçilen indisler artan sırada)"""
    global hucre
    n = len(a)
    T = hedef
    v = [[False] * (T + 1) for _ in range(n + 1)]
    v[0][0] = True
    hucre = T + 1
    for i in range(1, n + 1):
        for t in range(T + 1):
            v[i][t] = v[i - 1][t] or (a[i - 1] <= t
                                      and v[i - 1][t - a[i - 1]])
            hucre += 1
    sec = []
    if v[n][T]:
        t = T
        for i in range(n, 0, -1):                    # eşitlikte almadan
            if not v[i - 1][t]:
                sec.append(i - 1)
                t -= a[i - 1]
        sec.reverse()                                # artan sıra
    return v[n][T], sec


def kume_metni(sec):
    return "{" + ", ".join(str(i) for i in sec) + "}"


def main():
    global a, dugum, yol, bulunan
    a = [13, 7, 21, 4, 18, 9]
    hedef = 38
    print("1) a = {13, 7, 21, 4, 18, 9} (indis 0..5), hedef = 38")
    print("   Doğrulama (sertifika = seçilen indisler):")
    for s in ([0, 1, 4], [0, 1, 3], [0, 0, 4], [2, 9]):
        sonuc, adim, neden = dogrula(hedef, s)
        print(f"   {kume_metni(s):<10s} -> "
              f"{'KABUL' if sonuc else 'RED':<5s} ({neden}); adım = {adim}")
    dugum = 0
    yol = []
    bulunan = []
    bulundu = geri_izle(0, 0, hedef)
    print(f"   Bulma, geri izleme (H3; önce almadan): "
          f"{'çözüm' if bulundu else 'yok'} {kume_metni(bulunan)}; düğüm = "
          f"{dugum} (2^(n+1) - 1 = {(1 << (len(a) + 1)) - 1})")
    _, sec = dp_bul(hedef)
    print(f"   Bulma, DP (H13): çözüm {kume_metni(sec)}; hücre = {hucre} = "
          "(n+1)(T+1)")
    print("   DP'nin çözümü doğrulayıcıdan: "
          + ("KABUL" if dogrula(hedef, sec)[0] else "RED"))

    print("\n2) \"Evet\" örnekleri: a = LCG(1..1000), hedef = rastgele bir "
          "alt kümenin toplamı")
    print("   n   hedef  doğrulama  geri izleme düğümü  DP hücresi"
          "    2^(n+1)-1")
    rastgele_tohum(14)
    for n in range(10, 31, 4):
        a = rastgele_dizi(n, 1, 1000)
        hedef = 0
        for i in range(n):
            if rastgele_aralik(0, 1):
                hedef += a[i]
        dugum = 0
        yol = []
        geri_izle(0, 0, hedef)
        _, sec = dp_bul(hedef)
        gecerli, adim, _ = dogrula(hedef, sec)
        print(f"  {n:2d}  {hedef:6d}  {adim:4d} adım  {dugum:18d}  "
              f"{hucre:10d}  {(1 << (n + 1)) - 1:11d}"
              + ("" if gecerli else "  DOĞRULANAMADI"))

    print("\n3) \"Hayır\" örnekleri: bütün sayılar çift, hedef tek "
          "(çözüm yok; sertifika da yok)")
    print("   n   hedef  geri izleme düğümü  DP hücresi    2^(n+1)-1")
    for n in range(10, 19, 4):
        a = [0] * n
        toplam = 0
        for i in range(n):
            a[i] = 2 * rastgele_aralik(1, 500)
            toplam += a[i]
        hedef = toplam // 2 + (toplam // 2 % 2 == 0)   # tek sayı
        dugum = 0
        yol = []
        var = geri_izle(0, 0, hedef)
        dp_var, _ = dp_bul(hedef)
        print(f"  {n:2d}  {hedef:6d}  {dugum:18d}  {hucre:10d}  "
              f"{(1 << (n + 1)) - 1:11d}  "
              + ("ÇÖZÜM VAR?" if var or dp_var else "çözüm yok"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (C, C++, Python). Doğrulayıcı, H3'ün bit
# maskesi kaba kuvvetinin "bu alt küme doğru mu?" adımıdır.

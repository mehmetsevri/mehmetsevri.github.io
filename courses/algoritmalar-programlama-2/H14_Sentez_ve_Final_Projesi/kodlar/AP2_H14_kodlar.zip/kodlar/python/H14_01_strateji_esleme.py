"""H14_01_strateji_esleme.py — AP-2 Hafta 14 · Örnek 1 (★★)
Amaç    : Problem–strateji eşleme: on kısa problem için çözüm
          iskeletleri tek programda. Her problemde seçilen strateji,
          karmaşıklık, gerekçe satırı ve küçük girdide sonuç yazdırılır.
          Yelpaze: kaba kuvvet, geri izleme, ikili arama, böl ve fethet,
          karma, graf dolaşma, açgözlü (iki problem), DP, sezgisel
Kurallar: eşitlikte küçük indeks; komşular artan numarayla; girdiler
          elle ya da ortak LCG'den (tohum yazılı)
Çalıştır: python3 H14_01_strateji_esleme.py
Eşleri  : c/H14_01_strateji_esleme.c · cpp/H14_01_strateji_esleme.cpp
Çıktı   : üç dilde aynı (=)
"""
import math
from collections import deque

from ortak_rastgele import rastgele_aralik, rastgele_tohum

# (problem, strateji, karmaşıklık, hafta, gerekçe)
KART = [
    ("En yakın nokta çifti (8 nokta)", "kaba kuvvet", "O(n²)", "H2",
     "n küçük: 28 çiftin hepsi denenir; daha karmaşık yönteme gerek yok"),
    ("6 x 6 tahtada 6 vezir: kaç çözüm?", "geri izleme", "O(n!) budamalı",
     "H3", "kısıt ihlal eden kısmi yerleşim erken budanır"),
    ("Sıralı 15 notta 70 ve üstü kaç not?", "ikili arama", "O(log n)", "H4",
     "dizi sıralı: ilk >= 70 konumu (lower_bound) yeter"),
    ("Ters çevrim sayısı (8 sayı)", "böl ve fethet", "O(n log n)", "H6",
     "birleştirme adımı, sol yarıdan büyükleri toplu sayar"),
    ("Numaralarda yinelenen var mı?", "karma", "ortalama O(n)", "H10",
     "her numara bir kez eklenir; görülmüş mü sorusu O(1)"),
    ("Ağda 0'dan 6'ya en az aktarma", "graf dolaşma (BFS)", "O(V + E)",
     "H11", "kenarlar ağırlıksız: BFS katmanı = en az kenar"),
    ("En çok çakışmayan sınav (8 aralık)", "açgözlü", "O(n log n)", "H12",
     "en erken biteni seçmek güvenli (değiş tokuş kanıtı)"),
    ("{1, 3, 4} paralarla 6: en az para", "DP", "O(n·T)", "H13",
     "açgözlü 4+1+1 = 3 para verir; DP en iyiyi (3+3) bulur"),
    ("8 şehirde kısa tur (gezgin satıcı)", "sezgisel (en yakın komşu)",
     "O(n²)", "H14", "NP-zor; büyük n'de kesin yöntem yok: hızlı, iyi tur"),
    ("Ağırlıklı ağda 0'dan 5'e en kısa yol", "açgözlü (Dijkstra)", "O(V²)",
     "H12", "ağırlıklar negatif değil: en yakını kesinleştirmek güvenli"),
]


def baslik(p):
    problem, strateji, karmasiklik, hafta, gerekce = KART[p]
    print(f"P{p + 1}  {problem}\n    strateji : {strateji} · {karmasiklik} "
          f"· {hafta}\n    gerekçe  : {gerekce}")


def p1_en_yakin_cift():
    """P1 — kaba kuvvet: tüm çiftler, en küçük kare uzaklık"""
    rastgele_tohum(11)
    x = [0] * 8
    y = [0] * 8
    for i in range(8):
        x[i] = rastgele_aralik(0, 99)
        y[i] = rastgele_aralik(0, 99)
    bi, bj, cift, en = 0, 1, 0, -1
    for i in range(8):
        for j in range(i + 1, 8):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            cift += 1
            if en == -1 or dx * dx + dy * dy < en:
                en = dx * dx + dy * dy
                bi, bj = i, j
    print(f"    sonuç    : {bi} ({x[bi]}, {y[bi]}) ile {bj} ({x[bj]}, "
          f"{y[bj]}); uzaklık {math.sqrt(en):.2f}; {cift} çift")


# P2 — geri izleme: satır satır vezir koy; sütun ve çaprazlar dolu mu?
sutun = [False] * 6
capraz1 = [False] * 11
capraz2 = [False] * 11
dugum = 0


def vezir(r):
    global dugum
    dugum += 1
    if r == 6:
        return 1
    cozum = 0
    for c in range(6):
        if not sutun[c] and not capraz1[r + c] and not capraz2[r - c + 5]:
            sutun[c] = capraz1[r + c] = capraz2[r - c + 5] = True   # seç
            cozum += vezir(r + 1)                                   # dene
            sutun[c] = capraz1[r + c] = capraz2[r - c + 5] = False  # geri
    return cozum


def p2_vezir():
    global dugum
    yaprak = 1
    for _ in range(6):
        yaprak *= 6                              # budamasız: 6^6 yaprak
    dugum = 0
    c = vezir(0)
    print(f"    sonuç    : {c} çözüm; {dugum} düğüm (budamasız ağaç 6^6 = "
          f"{yaprak} yaprak)")


def p3_alt_sinir():
    """P3 — ikili arama: ilk >= x konumu (yarı açık aralık)"""
    a = [35, 41, 48, 52, 55, 60, 63, 67, 70, 70, 74, 81, 88, 90, 97]
    lo, hi, yoklama = 0, 15, 0
    while lo < hi:
        orta = lo + (hi - lo) // 2
        yoklama += 1
        if a[orta] < 70:
            lo = orta + 1
        else:
            hi = orta
    print(f"    sonuç    : ilk >= 70 konumu {lo}; {15 - lo} not; {yoklama} "
          "yoklama")


def birlestir_say(a, g, lo, hi):
    """P4 — böl ve fethet: birleştirirken ters çevrim say"""
    if hi - lo < 2:
        return 0
    orta = lo + (hi - lo) // 2
    t = birlestir_say(a, g, lo, orta) + birlestir_say(a, g, orta, hi)
    i, j, k = lo, orta, lo
    while i < orta and j < hi:
        if a[i] <= a[j]:
            g[k] = a[i]
            i += 1
        else:
            t += orta - i               # a[i..orta-1] hepsi a[j]'den büyük
            g[k] = a[j]
            j += 1
        k += 1
    while i < orta:
        g[k] = a[i]
        i += 1
        k += 1
    while j < hi:
        g[k] = a[j]
        j += 1
        k += 1
    a[lo:hi] = g[lo:hi]
    return t


def p4_ters_cevrim():
    a = [8, 4, 2, 1, 7, 3, 6, 5]
    t = birlestir_say(a, [0] * 8, 0, 8)
    print(f"    sonuç    : [8 4 2 1 7 3 6 5] -> {t} ters çevrim (en çok "
          "8·7/2 = 28)")


def p5_yinelenen():
    """P5 — karma: doğrusal yoklamalı küme; ilk yineleneni bul"""
    no = [2201004, 2201017, 2201002, 2201033, 2201021, 2201008, 2201017,
          2201040, 2201002, 2201011]
    tablo = [-1] * 16
    yoklama = 0
    bulunan = -1
    i = 0
    while i < 10 and bulunan == -1:
        h = no[i] % 16                           # basit bölme karması
        yoklama += 1
        while tablo[h] != -1 and tablo[h] != no[i]:
            h = (h + 1) % 16
            yoklama += 1
        if tablo[h] == no[i]:
            bulunan = i
        else:
            tablo[h] = no[i]
        i += 1
    print(f"    sonuç    : ilk yinelenen {no[bulunan]} (konum {bulunan}); "
          f"{yoklama} yoklama")


def p6_bfs():
    """P6 — BFS: ağırlıksız grafta en az kenar"""
    kenar = [(0, 1), (0, 2), (1, 3), (2, 3), (2, 4), (3, 5), (4, 5), (5, 6),
             (1, 4)]
    kom = [[0] * 7 for _ in range(7)]
    for u, v in kenar:
        kom[u][v] = kom[v][u] = 1
    uz = [-1] * 7
    eb = [-1] * 7
    kuyruk = deque([0])                          # H9'un kuyruğu
    uz[0] = 0
    while kuyruk:
        u = kuyruk.popleft()
        for v in range(7):                       # artan köşe numarası
            if kom[u][v] and uz[v] == -1:
                uz[v] = uz[u] + 1
                eb[v] = u
                kuyruk.append(v)
    yol = []
    v = 6
    while v != -1:
        yol.append(v)
        v = eb[v]
    print(f"    sonuç    : {uz[6]} aktarma; yol "
          + " ".join(str(v) for v in reversed(yol)))


def p7_aralik():
    """P7 — açgözlü: (bitiş, başlangıç, no) sırasında en erken biteni"""
    bas_ = [1, 3, 0, 5, 3, 5, 6, 8]
    bit = [4, 5, 6, 7, 9, 9, 10, 11]
    sira = [0] * 8
    for i in range(8):                           # araya ekleme (araç)
        j = i
        while j > 0 and (bit[sira[j - 1]] > bit[i]
                         or (bit[sira[j - 1]] == bit[i]
                             and bas_[sira[j - 1]] > bas_[i])):
            sira[j] = sira[j - 1]
            j -= 1
        sira[j] = i
    secilen = []
    son_bitis = -1
    for i in sira:
        if bas_[i] >= son_bitis:
            secilen.append(i)
            son_bitis = bit[i]
    print(f"    sonuç    : {len(secilen)} sınav:"
          + "".join(f" s{i}[{bas_[i]}, {bit[i]})" for i in secilen))


def p8_bozuk_para():
    """P8 — DP: en az para; karşılaştırma için açgözlü"""
    para = [1, 3, 4]
    enaz = [1000] * 7
    son = [-1] * 7
    enaz[0] = 0
    for t in range(1, 7):
        for c in para:
            if c <= t and enaz[t - c] + 1 < enaz[t]:
                enaz[t] = enaz[t - c] + 1
                son[t] = c
    acgozlu = 0
    kalan = 6
    for c in range(2, -1, -1):
        while para[c] <= kalan:
            kalan -= para[c]
            acgozlu += 1
    parcalar = []
    t = 6
    while t > 0:
        parcalar.append(str(son[t]))
        t -= son[t]
    print(f"    sonuç    : DP {enaz[6]} para (" + " + ".join(parcalar)
          + f"); açgözlü {acgozlu} para")


# P9 — sezgisel: en yakın komşu; küçük n'de kaba kuvvetle denetim
d = [[0.0] * 8 for _ in range(8)]
kullanildi = [False] * 8
yol = [0] * 8
en_iyi = 0.0


def dene(k, kismi):
    global en_iyi
    if k == 8:
        t = kismi + d[yol[7]][0]
        if t < en_iyi - 1e-9:
            en_iyi = t
        return
    for s in range(1, 8):
        if not kullanildi[s]:
            kullanildi[s] = True
            yol[k] = s
            dene(k + 1, kismi + d[yol[k - 1]][s])
            kullanildi[s] = False


def p9_sezgisel():
    global en_iyi
    rastgele_tohum(42)
    x = [0] * 8
    y = [0] * 8
    for i in range(8):
        x[i] = rastgele_aralik(0, 99)
        y[i] = rastgele_aralik(0, 99)
    for i in range(8):
        for j in range(8):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            d[i][j] = math.sqrt(dx * dx + dy * dy)
    ziyaret = [False] * 8
    tur = [0] * 8
    ziyaret[0] = True
    for k in range(1, 8):
        sec = -1
        for s in range(8):
            if not ziyaret[s] and (sec == -1 or d[tur[k - 1]][s]
                                   < d[tur[k - 1]][sec]):
                sec = s
        tur[k] = sec
        ziyaret[sec] = True
    u = 0.0
    for k in range(1, 8):
        u += d[tur[k - 1]][tur[k]]
    u += d[tur[7]][0]
    yol[0] = 0
    kullanildi[0] = True
    en_iyi = 1e300
    dene(1, 0.0)
    print(f"    sonuç    : NN turu {u:.2f}; en iyi (kaba kuvvet, 5040 tur) "
          f"{en_iyi:.2f}; oran {u / en_iyi:.4f}")


def p10_dijkstra():
    """P10 — Dijkstra, dizi sürümü (H12 Örnek 7), O(V²)"""
    kenar = [(0, 1, 7), (0, 2, 9), (0, 5, 14), (1, 2, 10), (1, 3, 15),
             (2, 3, 11), (2, 5, 2), (3, 4, 6), (4, 5, 9)]
    w = [[-1] * 6 for _ in range(6)]
    for a, b, c in kenar:
        w[a][b] = w[b][a] = c
    uz = [-1] * 6
    eb = [-1] * 6
    bitti = [False] * 6
    uz[0] = 0
    for _ in range(6):
        u = -1
        for v in range(6):                       # eşitlikte küçük köşe
            if not bitti[v] and uz[v] != -1 and (u == -1 or uz[v] < uz[u]):
                u = v
        if u == -1:
            break
        bitti[u] = True
        for v in range(6):
            if w[u][v] != -1 and (uz[v] == -1 or uz[u] + w[u][v] < uz[v]):
                uz[v] = uz[u] + w[u][v]
                eb[v] = u
    yol5 = []
    v = 5
    while v != -1:
        yol5.append(v)
        v = eb[v]
    print(f"    sonuç    : uzaklık {uz[5]}; yol "
          + " ".join(str(v) for v in reversed(yol5))
          + f" (doğrudan 0-5 kenarı {w[0][5]})")


def main():
    cozucu = [p1_en_yakin_cift, p2_vezir, p3_alt_sinir, p4_ters_cevrim,
              p5_yinelenen, p6_bfs, p7_aralik, p8_bozuk_para, p9_sezgisel,
              p10_dijkstra]
    print("Problem–strateji eşleme: on problem, on iskelet\n")
    for p in range(10):
        baslik(p)
        cozucu[p]()
    print("\nÖzet tablo (problem · strateji · karmaşıklık · hafta)")
    for p in range(10):
        problem, strateji, karmasiklik, hafta, _ = KART[p]
        print(f"  P{p + 1:<2d} {problem} · {strateji} · {karmasiklik} · "
              f"{hafta}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: her iskeletin kütüphane karşılığı ilgili haftanın
# örneğinde verildi (ör. bsearch/std::lower_bound/bisect_left, qsort/
# std::sort/sorted, std::unordered_set/set, std::priority_queue/heapq).

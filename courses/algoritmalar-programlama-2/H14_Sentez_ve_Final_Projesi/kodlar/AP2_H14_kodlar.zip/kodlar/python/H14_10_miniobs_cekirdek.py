"""H14_10_miniobs_cekirdek.py — AP-2 Hafta 14 · Örnek 10 (★★★)
Amaç    : Final projesi entegrasyonu: menü güdümlü küçük bir "Mini-OBS
          çekirdeği". stdin'deki komut dosyasını okur ve her komutu
          dönemin bir modülüne yönlendirir: ekle (H8 dinamik dizi + H10
          karma dizini), ara (H10), sirala (H6 birleştirmeli), yinelenen
          (H10 karma kümesi), onkosul/plan (H11 Kahn), oneri (H13
          düzenleme uzaklığı). Modüller tek dosyada bölümlerle ayrılır.
DİKKAT  : Bu, mimarinin üç dilli KÜÇÜK MODELİDİR. Tam final projesi
          Mini-OBS 2 v3.0'dır (C; 91_Proje_MiniOBS2/v3.0).
Çalıştır: python3 H14_10_miniobs_cekirdek.py \\
          < ../girdiler/H14_10_miniobs_cekirdek.txt
Eşleri  : c/H14_10_miniobs_cekirdek.c · cpp/H14_10_miniobs_cekirdek.cpp
Çıktı   : üç dilde aynı (=)
"""
import sys

# ===== Modül 1: kayıt deposu (H8 dinamik dizi, kapasite × 2) ==========
kayit = []                          # [None] * kapasite; öğe: (no, ad, not)
kayit_sayisi = 0
kapasite = 0


def depo_ekle(no, ad, notu):
    global kayit, kayit_sayisi, kapasite
    if kayit_sayisi == kapasite:
        yeni = 2 * kapasite if kapasite else 2
        g = [None] * yeni
        for i in range(kayit_sayisi):
            g[i] = kayit[i]                      # öğeleri taşı
        kayit = g
        kapasite = yeni
    kayit[kayit_sayisi] = (no, ad, notu)
    kayit_sayisi += 1


# ===== Modül 2: numara dizini (H10 karma, doğrusal yoklama) ===========
dizin = []                          # kayıt indisi; -1 = boş
dizin_dolu = 0


def karma(no, kap):
    """Fibonacci; kap = 2^k (32 bit işaretsiz aritmetik)"""
    h = (no * 2654435769) & 0xFFFFFFFF
    bit = 0
    while (1 << bit) < kap:
        bit += 1
    return h >> (32 - bit)


def dizin_bul(no):
    """Dönen: (kayıt indisi ya da -1, yoklama)"""
    kap = len(dizin)
    yoklama = 0
    if kap == 0:
        return -1, yoklama
    h = karma(no, kap)
    while True:
        yoklama += 1
        if dizin[h] == -1:
            return -1, yoklama
        if kayit[dizin[h]][0] == no:
            return dizin[h], yoklama
        h = (h + 1) & (kap - 1)


def dizin_buyut():
    """yük > 1/2 olmasın"""
    global dizin
    eski = len(dizin)
    yeni = 2 * eski if eski else 8
    d = [-1] * yeni
    for i in range(eski):                        # yeniden yerleştir
        if dizin[i] != -1:
            h = karma(kayit[dizin[i]][0], yeni)
            while d[h] != -1:
                h = (h + 1) & (yeni - 1)
            d[h] = dizin[i]
    dizin = d


def dizin_ekle(i):
    """Kayıt i'yi dizine ekler; numara zaten varsa İLK kayıt kalır.
    Dönen: True eklendi, False numara zaten var"""
    global dizin_dolu
    if dizin_bul(kayit[i][0])[0] != -1:
        return False
    if 2 * (dizin_dolu + 1) > len(dizin):
        dizin_buyut()
    kap = len(dizin)
    h = karma(kayit[i][0], kap)
    while dizin[h] != -1:
        h = (h + 1) & (kap - 1)
    dizin[h] = i
    dizin_dolu += 1
    return True


# ===== Modül 3: sıralama (H6 birleştirmeli, kararlı) ==================
not_once = False                    # True: not azalan, no artan
karsilastirma = 0


def once_mi(a, b):
    """a, b'den önce mi gelir?"""
    global karsilastirma
    karsilastirma += 1
    if not_once and kayit[a][2] != kayit[b][2]:
        return kayit[a][2] > kayit[b][2]
    return kayit[a][0] <= kayit[b][0]            # eşitlikte girdi sırası


def birlestirmeli(s, g, lo, hi):
    if hi - lo < 2:
        return
    orta = lo + (hi - lo) // 2
    birlestirmeli(s, g, lo, orta)
    birlestirmeli(s, g, orta, hi)
    i, j, k = lo, orta, lo
    while i < orta and j < hi:
        if once_mi(s[i], s[j]):
            g[k] = s[i]
            i += 1
        else:
            g[k] = s[j]
            j += 1
        k += 1
    while i < orta:
        g[k] = s[i]
        i += 1
        k += 1
    while j < hi:
        g[k] = s[j]
        j += 1
        k += 1
    s[lo:hi] = g[lo:hi]


# ===== Modül 4: yinelenen (H10'un kütüphane karşılığı: dict) ==========
def yinelenen_bul():
    say = {}                                     # numara -> adet
    for i in range(kayit_sayisi):
        no = kayit[i][0]
        say[no] = say.get(no, 0) + 1
    sonuc = []                                   # artan sırada ekle
    for no, adet in say.items():
        if adet >= 2:
            j = len(sonuc)
            sonuc.append((no, adet))
            while j > 0 and sonuc[j - 1][0] > no:
                sonuc[j] = sonuc[j - 1]
                j -= 1
            sonuc[j] = (no, adet)
    return sonuc


# ===== Modül 5: önkoşul planı (H11 Kahn, en küçük kod önce) ===========
MAKS_DERS = 16
ders = []
onkosul = [[0] * MAKS_DERS for _ in range(MAKS_DERS)]


def ders_no(kod):
    """yoksa ekler; -1 dolu"""
    for i in range(len(ders)):
        if ders[i] == kod:
            return i
    if len(ders) == MAKS_DERS:
        return -1
    ders.append(kod)
    return len(ders) - 1


def plan_kur():
    """döngüde kısmi sıra"""
    D = len(ders)
    giris = [0] * D
    alindi = [0] * D
    sira = []
    for u in range(D):
        for v in range(D):
            giris[v] += onkosul[u][v]
    for _ in range(D):
        sec = -1
        for v in range(D):                       # alfabetik en küçük
            if (not alindi[v] and giris[v] == 0
                    and (sec == -1 or ders[v] < ders[sec])):
                sec = v
        if sec == -1:
            break                                # döngü
        alindi[sec] = 1
        sira.append(sec)
        for v in range(D):
            giris[v] -= onkosul[sec][v]
    return sira


# ===== Modül 6: öneri (H13 düzenleme uzaklığı, iki satır) =============
def duzenleme(a, b):
    m = len(b)
    onceki = list(range(m + 1))
    simdi = [0] * (m + 1)
    for i in range(1, len(a) + 1):
        simdi[0] = i
        for j in range(1, m + 1):
            en = onceki[j] + 1                               # silme
            if simdi[j - 1] + 1 < en:
                en = simdi[j - 1] + 1                        # ekleme
            fark = 1 if a[i - 1] != b[j - 1] else 0
            if onceki[j - 1] + fark < en:
                en = onceki[j - 1] + fark                    # değiştir
            simdi[j] = en
        onceki = simdi[:]
    return onceki[m]


# ===== Menü: komutu modüle yönlendir (dönen: True çık) ================
hata_sayisi = 0


def sayi_coz(s, alt, ust):
    """geçersizse None"""
    try:
        v = int(s)
    except ValueError:
        return None
    return v if alt <= v <= ust else None


def komut_isle(satir):
    global not_once, karsilastirma, hata_sayisi
    k = satir.split()[:4]
    t = len(k)
    print(f"> {satir}")
    if t >= 1 and k[0] == "cikis":
        return True
    if (t == 4 and k[0] == "ekle"
            and sayi_coz(k[1], 100000000, 999999999) is not None
            and len(k[2]) < 16 and sayi_coz(k[3], 0, 100) is not None):
        depo_ekle(int(k[1]), k[2], int(k[3]))
        e = dizin_ekle(kayit_sayisi - 1)
        print(f"  kayıt {kayit_sayisi} eklendi (depo kapasitesi {kapasite}, "
              f"dizin {dizin_dolu}/{len(dizin)})"
              + ("" if e else "; numara zaten var: dizin ilk kaydı gösterir"))
    elif (t == 2 and k[0] == "ara"
          and sayi_coz(k[1], 0, 999999999) is not None):
        i, y = dizin_bul(int(k[1]))
        if i >= 0:
            no, ad, notu = kayit[i]
            print(f"  bulundu: {no} {ad} {notu} ({y} yoklama)")
        else:
            print(f"  bulunamadı ({y} yoklama)")
    elif t == 2 and k[0] == "sirala" and k[1] in ("not", "no"):
        sira = list(range(kayit_sayisi))
        g = [0] * kayit_sayisi
        not_once = k[1] == "not"
        karsilastirma = 0
        birlestirmeli(sira, g, 0, kayit_sayisi)
        print(f"  {kayit_sayisi} kayıt, "
              + ("not azalan (eşitlikte no artan)" if not_once
                 else "no artan") + f"; {karsilastirma} karşılaştırma")
        for i in range(kayit_sayisi):
            no, ad, notu = kayit[sira[i]]
            print(f"  {i + 1:2d}. {no} {ad:<8s} {notu:3d}")
    elif t == 1 and k[0] == "yinelenen":
        sonuc = yinelenen_bul()
        print(f"  {len(sonuc)} yinelenen numara:"
              + "".join(f" {no} ({adet} kez)" for no, adet in sonuc))
    elif t == 3 and k[0] == "onkosul" and len(k[1]) < 16 and len(k[2]) < 16:
        u = ders_no(k[1])
        v = ders_no(k[2]) if u >= 0 else -1
        if v < 0:
            print(f"  HATA: ders sınırı ({MAKS_DERS})")
            hata_sayisi += 1
            return False
        onkosul[u][v] = 1
        print(f"  {k[1]} -> {k[2]} (ders {len(ders)})")
    elif t == 1 and k[0] == "plan":
        sira = plan_kur()
        bas = "döngü var, kısmi sıra" if len(sira) < len(ders) else "plan"
        print(f"  {bas}:" + "".join(f" {ders[v]}" for v in sira))
    elif t == 2 and k[0] == "oneri" and len(k[1]) < 16:
        en = -1
        uz = 0
        for i in range(kayit_sayisi):            # eşitlikte alfabetik
            d = duzenleme(k[1], kayit[i][1])
            if en == -1 or d < uz or (d == uz and kayit[i][1] < kayit[en][1]):
                en = i
                uz = d
        if en >= 0 and uz <= 2:
            print(f"  Bunu mu demek istediniz: {kayit[en][1]} (uzaklık {uz})")
        else:
            print(f"  öneri yok (en yakın uzaklık {uz})")
    else:
        print("  HATA: bilinmeyen ya da hatalı komut")
        hata_sayisi += 1
    return False


def main():
    komut = 0
    print("Mini-OBS çekirdeği (H14 Örnek 10; tam sürüm: Mini-OBS 2 v3.0)")
    for satir in sys.stdin:
        satir = satir.rstrip("\r\n")
        if not satir or satir[0] == "#":
            continue
        komut += 1
        if komut_isle(satir):
            break
    print(f"Özet: {komut} komut, {hata_sayisi} hata, {kayit_sayisi} kayıt, "
          f"{len(ders)} ders")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Kütüphane karşılığı: C — qsort (sıralama), POSIX hsearch (karma);
# C++ — std::vector, std::unordered_map, std::stable_sort; Python — list,
# dict, sorted, graphlib (yalnızca kâhin). C'de modüllerin hepsi elle;
# C++ ve Python'da yinelenen modülü H10'un kütüphane karşılığıyla
# (std::unordered_map / dict), öbürleri elle.

"""H14_K02_ornekleme_profili.py — AP-2 Hafta 14 · Kavram 2 (Kaputun Altında)
Amaç    : Örnekleme tabanlı profilleyicinin (ör. Linux perf) mantığı, bir
          benzetimle: program, süreleri BİLİNEN bir çağrı ağacıdır.
          Profilleyici her P zaman biriminde bir kez çağrı yığınına bakar
          ("örnek") ve yığınları sayar. Örnek payı ≈ zaman payı; P
          büyüdükçe örnek azalır ve kestirim gürültülenir (hata ≈
          1/√örnek). Sayılan
          yığınlar "katlanmış yığın" (folded stack) biçiminde yazılır: alev
          grafiği (flame graph) bu satırlardan çizilir. gprof ise -pg ile
          derlenen programda çağrıları da sayar (araçlama + örnekleme).
Çalıştır: python3 H14_K02_ornekleme_profili.py      (çıktı belirleyicidir)
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402

# (ad, öz süre, çocuklar): öz süre zaman birimi (ör. µs); Örnek 8'e benzer
AGAC = ("main", 2, [
    ("oku", 3, [("ayristir", 40, [])]),
    ("isle", 1, [("istatistik", 12, []), ("yinelenen_ciftler", 820, []),
                 ("harf_dagilimi", 15, [])]),
    ("rapor", 7, [("yaz", 10, [])]),
])


def zaman_cizgisi(dugum, yigin, cizgi):
    """Önce öz süre, sonra çocuklar (önce-kök sırası): her zaman biriminde
    hangi yığının çalıştığı"""
    ad, oz, cocuklar = dugum
    yigin = yigin + [ad]
    cizgi.extend([";".join(yigin)] * oz)
    for c in cocuklar:
        zaman_cizgisi(c, yigin, cizgi)
    return cizgi


def main():
    cizgi = zaman_cizgisi(AGAC, [], [])
    toplam = len(cizgi)
    gercek = {}
    for y in cizgi:
        gercek[y] = gercek.get(y, 0) + 1
    yiginlar = sorted(gercek)
    print(f"Program: {toplam} zaman birimi, {len(yiginlar)} farklı yığın")
    print("Gerçek pay (öz süre) ve örnekleme kestirimi (P = örnekleme "
          "aralığı; ilk örnek LCG ile rastgele kaydırılır)")
    periyotlar = [1, 10, 50, 200]
    kestirim = {}
    for P in periyotlar:
        rastgele_tohum(P)
        kayma = rastgele_aralik(0, P - 1)
        sayac = {}
        for t in range(kayma, toplam, P):
            sayac[cizgi[t]] = sayac.get(cizgi[t], 0) + 1
        kestirim[P] = (sayac, sum(sayac.values()))
    print((f"  {'yığın':<34}  gerçek" + "".join(f"  P={P:<4d}"
                                               for P in periyotlar)).rstrip())
    for y in yiginlar:
        satir = f"  {y:<34}  {100 * gercek[y] / toplam:5.1f}%"
        for P in periyotlar:
            sayac, k = kestirim[P]
            satir += f"  {100 * sayac.get(y, 0) / k:5.1f}%"
        print(satir)
    print("  örnek sayısı" + " " * 31
          + "".join(f"  {kestirim[P][1]:6d}" for P in periyotlar))
    print("\nEn çok zaman alan (öz süre) yığın, her P için:")
    for P in periyotlar:
        sayac, k = kestirim[P]
        en = max(sorted(sayac), key=lambda y: sayac[y])
        print(f"  P = {P:3d}: {en} ({sayac[en]}/{k} örnek)")
    print("\nKatlanmış yığınlar (P = 10; alev grafiği girdisi):")
    sayac, _ = kestirim[10]
    for y in sorted(sayac):
        print(f"  {y} {sayac[y]}")


if __name__ == "__main__":
    main()

"""H14_K03_python_kacis_yollari.py — AP-2 Hafta 14 · Kavram 3 (Dil Penceresi)
Amaç    : Python'da başarıma "kaçış yolları": aynı işi yapan el yazımı
          Python döngüsü ile C'de yazılmış yerleşik araç (sum, sorted,
          dict) arasındaki sabit çarpan. Algoritma sınıfı iki yanda da
          aynıdır (Θ(n), Θ(n log n), beklenen Θ(n)); fark yorumlayıcının
          her adımda ödediği bedeldedir (H1 deneyi, Örnek 9).
Ölçüm   : timeit; 1 ısınma + 5 tekrar, ortanca. Süreler "bu makinede,
          bu çalıştırmada" geçerlidir; sonuçların eşitliği her durumda
          denetlenir (aynı sonuç değilse kıyas anlamsızdır).
Çalıştır: python3 H14_K03_python_kacis_yollari.py
"""
import os
import statistics
import sys
import timeit

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "python"))
from ortak_rastgele import rastgele_aralik, rastgele_tohum  # noqa: E402

N = 100000                     # toplam ve sayma için
N_SIRA = 20000                 # sıralama için (el yazımı birleştirmeli)
TEKRAR = 5


def el_toplam(a):
    t = 0
    for x in a:
        t += x
    return t


def el_birlestirmeli(a):
    """H6'daki yukarıdan aşağı birleştirmeli sıralama (kararlı)"""
    if len(a) <= 1:
        return a[:]
    orta = len(a) // 2
    sol, sag = el_birlestirmeli(a[:orta]), el_birlestirmeli(a[orta:])
    c, i, j = [], 0, 0
    while i < len(sol) and j < len(sag):
        if sag[j] < sol[i]:
            c.append(sag[j])
            j += 1
        else:
            c.append(sol[i])
            i += 1
    c.extend(sol[i:])
    c.extend(sag[j:])
    return c


def el_sayma(a):
    """H10'daki açık adresleme (doğrusal yoklama) ile sıklık tablosu"""
    m = 1
    while m < 2 * len(a):
        m *= 2
    anahtar, deger = [None] * m, [0] * m
    for x in a:
        k = (x * 2654435769) % (1 << 32) % m
        while anahtar[k] is not None and anahtar[k] != x:
            k = (k + 1) % m
        anahtar[k] = x
        deger[k] += 1
    return {anahtar[k]: deger[k] for k in range(m) if anahtar[k] is not None}


def dict_sayma(a):
    d = {}
    for x in a:
        d[x] = d.get(x, 0) + 1
    return d


def olc(fonk, veri):
    fonk(veri)                                   # ısınma
    zam = timeit.repeat(lambda: fonk(veri), number=1, repeat=TEKRAR)
    return statistics.median(zam) * 1e3


def main():
    rastgele_tohum(14)
    a = [rastgele_aralik(0, 999999) for _ in range(N)]
    s = a[:N_SIRA]
    k = [rastgele_aralik(0, 9999) for _ in range(N)]
    isler = [
        ("toplam", f"n = {N}", "for döngüsü", el_toplam, "sum", sum, a),
        ("sıralama", f"n = {N_SIRA}", "el birleştirmeli",
         el_birlestirmeli, "sorted", sorted, s),
        ("sıklık", f"n = {N}", "el karma tablosu", el_sayma,
         "dict", dict_sayma, k),
    ]
    print("Python'da kaçış yolları: el yazımı ↔ yerleşik (C'de yazılmış)")
    print(f"  (timeit; 1 ısınma + {TEKRAR} tekrar, ortanca; bu makinede, "
          "bu çalıştırmada)")
    print(f"  {'iş':<10}{'boyut':<11}{'el yazımı':<19}{'ms':>9}  "
          f"{'yerleşik':<9}{'ms':>8}  {'kat':>6}  sonuç")
    for ad, boyut, el_ad, el, yer_ad, yer, veri in isler:
        ayni = el(veri) == yer(veri)
        t_el, t_yer = olc(el, veri), olc(yer, veri)
        print(f"  {ad:<10}{boyut:<11}{el_ad:<19}{t_el:9.2f}  {yer_ad:<9}"
              f"{t_yer:8.2f}  {t_el / t_yer:6.1f}  "
              + ("aynı" if ayni else "FARKLI"))
    print("Not: 'dict' satırında döngü yine Python'dadır; kazanç, yoklama ve "
          "karma\n     hesabının C'deki dict'e geçmesindendir. Algoritmayı "
          "değiştirmek\n     (Θ(n²) → Θ(n log n)) bu sabit çarpanlardan çok "
          "daha büyük kazanç verir.")


if __name__ == "__main__":
    main()

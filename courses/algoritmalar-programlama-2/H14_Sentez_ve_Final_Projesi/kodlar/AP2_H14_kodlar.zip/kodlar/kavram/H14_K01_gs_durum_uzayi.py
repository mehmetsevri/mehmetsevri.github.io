"""H14_K01_gs_durum_uzayi.py — AP-2 Hafta 14 · Kavram 1 (Kaputun Altında)
Amaç    : Gezgin satıcıda durum uzayı: şehir 0 sabit, tur ile tersi aynı
          sayılınca (n − 1)!/2 farklı tur. Saniyede 10⁹ tur değerlendiren
          (iyimser) bir makinede kaba kuvvetin süresi. Python tamsayısı
          taşmaz; C eşinin uint64_t sınırını (n <= 21) aynı çıktı için
          korur. Held–Karp'ın n²·2ⁿ geçişiyle karşılaştırma.
Çalıştır: python3 H14_K01_gs_durum_uzayi.py
Eşi     : H14_K01_gs_durum_uzayi.c (aynı çıktı)
"""


def sure_metni(saniye):
    """insan ölçeğinde süre"""
    dk, sa, gun, yil = 60.0, 3600.0, 86400.0, 365.25 * 86400.0
    if saniye < 1e-6:
        return f"{saniye * 1e9:.3g} ns"
    if saniye < 1e-3:
        return f"{saniye * 1e6:.3g} µs"
    if saniye < 1.0:
        return f"{saniye * 1e3:.3g} ms"
    if saniye < dk:
        return f"{saniye:.1f} s"
    if saniye < sa:
        return f"{saniye / dk:.1f} dk"
    if saniye < gun:
        return f"{saniye / sa:.1f} saat"
    if saniye < yil:
        return f"{saniye / gun:.1f} gün"
    return f"{saniye / yil:.3g} yıl"


def main():
    kesin = 1                                    # (n-1)!/2, n = 3'te 1
    faktoriyel = 2.0                             # (n-1)!, n = 3'te 2!
    tur20 = 0.0
    print("  n        (n-1)!/2 (kesin)   (n-1)!/2  Held-Karp n²·2ⁿ  "
          "kaba kuvvet, 10^9 tur/s")
    for n in range(3, 26):
        if n > 3:
            faktoriyel *= n - 1
            if n <= 21:
                kesin *= n - 1
        tur = faktoriyel / 2.0
        if n == 20:
            tur20 = tur
        kesin_metin = f"{kesin:24d}" if n <= 21 else f"{'-':>24s}"
        print(f" {n:2d}  {kesin_metin}  {tur:9.3e}        "
              f"{float(n) * n * float(1 << n):9.3e}  "
              + sure_metni(tur / 1e9))
    print(f"n = 20: 19!/2 ≈ {tur20:.2e} tur (Kaputun Altında: ≈ 6 × 10¹⁶)")


if __name__ == "__main__":
    main()

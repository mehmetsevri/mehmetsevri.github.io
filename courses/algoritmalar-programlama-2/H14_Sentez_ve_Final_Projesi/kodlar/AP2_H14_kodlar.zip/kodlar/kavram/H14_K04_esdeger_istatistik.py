"""H14_K04_esdeger_istatistik.py — AP-2 Hafta 14 · Kavram 4 (Dil Penceresi)
Amaç    : "Üç dilde aynı çıktı" kültürünün dönem bilançosu. Her haftanın
          kodlar/ornekler.json dosyası okunur: örnek sayısı, "=" (üç dilde
          bayt bayt aynı çıktı) ve "Δ" (bilinçli dil farkı) dağılımı,
          amiral örnekler, düzeyler ve "farklar" (dil eşlerinin ayrıştığı
          satır işaretleri). Kaynak dosyaları sayılıp satırları da sayılır.
          Bütün sayılar dosyalardan programla çıkarılır.
Çalıştır: python3 H14_K04_esdeger_istatistik.py [ders_kok]
          ders_kok varsayılanı: bu dosyadan üç üst klasör (out/)
"""
import glob
import json
import os
import sys

BURASI = os.path.dirname(os.path.abspath(__file__))
UZANTI = (("c", ".c"), ("cpp", ".cpp"), ("python", ".py"))


def satir_say(yol):
    with open(yol, encoding="utf-8") as f:
        return sum(1 for _ in f)


def hafta_oku(klasor):
    with open(os.path.join(klasor, "kodlar", "ornekler.json"),
              encoding="utf-8") as f:
        veri = json.load(f)
    ornekler = veri["ornekler"]
    s = {"hafta": veri.get("hafta"), "ornek": len(ornekler), "=": 0,
         "Δ": 0, "amiral": 0, "duzey": [0, 0, 0], "fark": 0, "delta": []}
    for kok in sorted(ornekler):
        o = ornekler[kok]
        s[o["tur"]] += 1
        s["amiral"] += 1 if o["amiral"] else 0
        s["duzey"][o["duzey"] - 1] += 1
        s["fark"] += sum(len(v) for v in o["farklar"].values())
        if o["tur"] == "Δ":
            s["delta"].append(kok)
        for alt, uz in UZANTI:
            yol = os.path.join(klasor, "kodlar", alt, kok + uz)
            if os.path.exists(yol):
                s[alt] = s.get(alt, 0) + 1
                s[alt + "_satir"] = s.get(alt + "_satir", 0) + satir_say(yol)
    return s


def main():
    kok = (sys.argv[1] if len(sys.argv) > 1 else
           os.path.normpath(os.path.join(BURASI, "..", "..", "..")))
    klasorler = sorted(k for k in glob.glob(os.path.join(kok, "H[0-9][0-9]_*"))
                       if os.path.exists(os.path.join(k, "kodlar",
                                                      "ornekler.json")))
    print("Dönemin eşdeğerlik bilançosu (kaynak: her haftanın "
          "kodlar/ornekler.json)")
    print(f"  {'hafta':<6}{'örnek':>6}{'=':>5}{'Δ':>4}{'amiral':>8}"
          f"{'düzey 1/2/3':>13}{'fark işareti':>14}{'C satır':>9}"
          f"{'C++ satır':>11}{'Py satır':>10}")
    T = {"ornek": 0, "=": 0, "Δ": 0, "amiral": 0, "duzey": [0, 0, 0],
         "fark": 0, "c_satir": 0, "cpp_satir": 0, "python_satir": 0,
         "c": 0, "cpp": 0, "python": 0}
    deltalar = []
    for k in klasorler:
        s = hafta_oku(k)
        for a in ("ornek", "=", "Δ", "amiral", "fark", "c", "cpp",
                  "python", "c_satir", "cpp_satir", "python_satir"):
            T[a] += s.get(a, 0)
        T["duzey"] = [x + y for x, y in zip(T["duzey"], s["duzey"])]
        deltalar += s["delta"]
        d = "/".join(str(x) for x in s["duzey"])
        print(f"  H{s['hafta']:<5d}{s['ornek']:>6d}{s['=']:>5d}{s['Δ']:>4d}"
              f"{s['amiral']:>8d}{d:>13}{s['fark']:>14d}"
              f"{s.get('c_satir', 0):>9d}{s.get('cpp_satir', 0):>11d}"
              f"{s.get('python_satir', 0):>10d}")
    d = "/".join(str(x) for x in T["duzey"])
    print(f"  {'toplam':<6}{T['ornek']:>6d}{T['=']:>5d}{T['Δ']:>4d}"
          f"{T['amiral']:>8d}{d:>13}{T['fark']:>14d}{T['c_satir']:>9d}"
          f"{T['cpp_satir']:>11d}{T['python_satir']:>10d}")
    print(f"\n{len(klasorler)} hafta, {T['ornek']} örnek, "
          f"{T['c'] + T['cpp'] + T['python']} kaynak dosya "
          f"(C {T['c']}, C++ {T['cpp']}, Python {T['python']})")
    print(f"'=' oranı: {T['=']}/{T['ornek']} = "
          f"%{100 * T['='] / T['ornek']:.1f}; 'Δ' örnekleri ({T['Δ']}): "
          "dil farkının kendisi konudur")
    for kok in deltalar:
        print(f"  {kok}")
    print(f"Örnek başına ortalama fark işareti: "
          f"{T['fark'] / T['ornek']:.1f} (C++ ve Python eşlerinde C'den "
          "ayrışan satırlar)")
    print("Satır oranı (C = 1): C++ "
          f"{T['cpp_satir'] / T['c_satir']:.2f}, Python "
          f"{T['python_satir'] / T['c_satir']:.2f}")


if __name__ == "__main__":
    main()

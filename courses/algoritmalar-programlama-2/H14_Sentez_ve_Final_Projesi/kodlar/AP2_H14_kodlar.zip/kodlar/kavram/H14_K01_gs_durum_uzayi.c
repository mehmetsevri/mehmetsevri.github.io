/* H14_K01_gs_durum_uzayi.c — AP-2 Hafta 14 · Kavram 1 (Kaputun Altında)
 * Amaç    : Gezgin satıcıda durum uzayı: şehir 0 sabit, tur ile tersi aynı
 *           sayılınca (n − 1)!/2 farklı tur. Saniyede 10⁹ tur değerlendiren
 *           (iyimser) bir makinede kaba kuvvetin süresi. Kesin değer
 *           uint64_t ile n <= 21'e dek; bilimsel gösterim double ile.
 *           Held–Karp'ın n²·2ⁿ geçişiyle karşılaştırma.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_K01_gs_durum_uzayi.c -o H14_K01_gs_durum_uzayi
 * Eşi     : H14_K01_gs_durum_uzayi.py (aynı çıktı)
 */
#include <stdint.h>
#include <stdio.h>

static void sure_yaz(double saniye)          /* insan ölçeğinde süre */
{
    const double dk = 60.0, sa = 3600.0, gun = 86400.0,
                 yil = 365.25 * 86400.0;
    if (saniye < 1e-6) {
        printf("%.3g ns", saniye * 1e9);
    } else if (saniye < 1e-3) {
        printf("%.3g µs", saniye * 1e6);
    } else if (saniye < 1.0) {
        printf("%.3g ms", saniye * 1e3);
    } else if (saniye < dk) {
        printf("%.1f s", saniye);
    } else if (saniye < sa) {
        printf("%.1f dk", saniye / dk);
    } else if (saniye < gun) {
        printf("%.1f saat", saniye / sa);
    } else if (saniye < yil) {
        printf("%.1f gün", saniye / gun);
    } else {
        printf("%.3g yıl", saniye / yil);
    }
}

int main(void)
{
    uint64_t kesin = 1;                          /* (n-1)!/2, n = 3'te 1 */
    double faktoriyel = 2.0;                     /* (n-1)!, n = 3'te 2!  */
    double tur20 = 0.0;
    printf("  n        (n-1)!/2 (kesin)   (n-1)!/2  Held-Karp n²·2ⁿ  "
           "kaba kuvvet, 10^9 tur/s\n");
    for (int n = 3; n <= 25; n++) {
        if (n > 3) {
            faktoriyel *= n - 1;
            if (n <= 21) {
                kesin *= (uint64_t)(n - 1);      /* 20!/2 < 2^64 */
            }
        }
        double tur = faktoriyel / 2.0;
        if (n == 20) {
            tur20 = tur;
        }
        printf(" %2d  ", n);
        if (n <= 21) {
            printf("%24llu", (unsigned long long)kesin);
        } else {
            printf("%24s", "-");
        }
        printf("  %9.3e        %9.3e  ", tur,
               (double)n * n * (double)(1ULL << n));
        sure_yaz(tur / 1e9);
        printf("\n");
    }
    printf("n = 20: 19!/2 ≈ %.2e tur (Kaputun Altında: ≈ 6 × 10¹⁶)\n",
           tur20);
    return 0;
}

# Hafta 14 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı ve beklenen çıktısıyla aşağıdadır. **Ders notu**, **Sunum** ve **Web** sütunları kodun gösterildiği yeri (bölüm, slayt, web kutusu) ve görünür metindeki anışları (PDF sayfası, slayt) verir. Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11.15 (örnekler 3.10 uyumludur).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program -lm` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. Örnek 10 standart girdiden `girdiler/H14_10_miniobs_cekirdek.txt` komut dosyasını okur (`./program < girdiler/H14_10_miniobs_cekirdek.txt`); Örnek 7 üç girdi dosyasını argüman olarak alır (`ornekler.json` → `arguman`).

Eşdeğerlik: `python3 esdeger_test.py .` → **10/10 GEÇTİ** (10 “=”: üç dilde bayt bayt aynı stdout), uyarı 0; `--asan` (AddressSanitizer + UBSan + LeakSanitizer) ile **10/10 GEÇTİ** (hatalı 0). Valgrind: 106/106 program temiz (0 hata, 0 bayt kayıp) (`BELLEK_DENETIMI.txt`).


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Girdi / argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H14_01_strateji_esleme` | ★★ | = | — | Problem–strateji eşleme: on kısa problem, on çözüm iskeleti (kaba kuvvet, geri izleme, ikili arama, böl ve fethet, karma, BFS, açgözlü, DP, sezgisel); strateji, karmaşıklık, gerekçe ve sonuç | — | Ek A.1; metin s. 2, 3, 7, 24, 51 | slayt metin: 13 | örnek kutusu (üç dil), metin |
| `H14_02_gs_kaba_kuvvet` | ★★ | = | evet | Gezgin satıcı, kaba kuvvet: şehir 0 sabit, permütasyonlar sözlük sırasıyla (H3 üreticisi); denenen tur = (n − 1)!, n ≤ 10; ters turlar ve (n − 1)!/2 simetri notu | — | Bölüm 4.1; Ek A.2; metin s. 2, 3, 11, 12, 13, 23 … | slayt kod: 22; metin: 11, 21, 24 | örnek kutusu (üç dil), metin |
| `H14_03_en_yakin_komsu` | ★★ | = | evet | En yakın komşu sezgiseli (eşitlikte küçük indeks, tamsayı kare uzaklık); kaba kuvvetle karşılaştırma: LCG ile 100 örnekte yaklaşım oranı (en kötü, ortalama, ortanca); aday incelemesi n(n − 1)/2 | — | Bölüm 4.2; Ek A.3; metin s. 2, 3, 11, 14, 15, 16 … | slayt kod: 25; metin: 26 | örnek kutusu (üç dil), metin |
| `H14_04_iki_opt` | ★★★ | = | evet | 2-opt yerel arama: en yakın komşu turundan, ilk iyileştirme, sabit (i, j) sırası; adımlar, iyileştirme sayısı, son uzunluk; yerel en iyinin genel en iyi olmadığı bir örnek | — | Bölüm 4.3; Ek A.4; metin s. 2, 3, 11, 18, 40, 42 … | slayt kod: 31; metin: 28 | örnek kutusu (üç dil), metin |
| `H14_05_held_karp` | ★★★ | = | evet | Held–Karp (merak): bit maskesi DP'si, n ≤ 16; dp[S][j] tablo kesiti ve geri çıkarma; n ≤ 10'da kaba kuvvetle aynı sonuç; durum ve geçiş sayaçları; n·2ⁿ tablo ve bellek hesabı | — | Bölüm 4.4; Ek A.5; metin s. 2, 3, 11, 20, 21, 47 … | slayt kod: 36; metin: 34 | örnek kutusu (üç dil), metin |
| `H14_06_dogrulama_bulma` | ★ | = | — | Doğrulama ile bulma (NP sezgisi): alt küme toplamı sertifikası O(n) adımda doğrulanır; bulma H3 geri izlemesi (düğüm) ve H13 DP'si (hücre); "evet" ve "hayır" örnekleri | — | Bölüm 5.2; Ek A.6; metin s. 2, 3, 10, 24, 58 | slayt kod: 38; metin: 14, 16 | örnek kutusu (üç dil), metin |
| `H14_07_indirgeme` | ★★ | = | — | İndirgeme örnekleri: sudoku → geri izleme (H3), labirent → BFS (H11), ders planı → topolojik sıralama (H11, Kahn); modelleme satırları, girdiler girdiler/ altında | girdiler/H14_07_sudoku.txt girdiler/H14_07_labirent.txt girdiler/H14_07_ders_plani.txt | Bölüm 5.3; Ek A.7; metin s. 2, 3, 6, 8, 9, 25 … | slayt metin: 4, 12 | örnek kutusu (üç dil), metin |
| `H14_08_profil_cikarma` | ★★★ | = | — | Profil çıkarma: kasıtlı darboğazlı kayıt işleme (O(n²) yinelenen tespiti); gprof / cProfile ile darboğaz; sırala + komşular sürümüyle aynı sonuç; adım süreleri stderr'e | — | Bölüm 5.4; Ek A.8; metin s. 2, 4, 11, 26, 27, 34 … | slayt metin: 39, 40 | örnek kutusu (üç dil), metin |
| `H14_09_donem_kiyas` | ★★★ | = | — | Dönem kıyaslama programı: ikili arama, birleştirmeli ve öbek sıralaması, karma tablosu, BFS, Dijkstra, LCS ve sırt çantası sabit boyutlarda; stdout'a yalnız denetim toplamları, süreler stderr'e ya da --csv | — | Ek A.9; metin s. 2, 4, 27, 29, 62 | slayt metin: 42 | örnek kutusu (üç dil), metin |
| `H14_10_miniobs_cekirdek` | ★★★ | = | — | Final projesi entegrasyonu: menü güdümlü Mini-OBS çekirdeği (ekle, ara, sırala, yinelenen, önkoşul planı, öneri); komutlar stdin'den; mimarinin küçük modeli (tam v3.0: 91_Proje_MiniOBS2/v3.0) | < girdiler/H14_10_miniobs_cekirdek.txt | Bölüm 5.6; Ek A.10; metin s. 2, 4, 28, 36, 62 | slayt kod: 41 | örnek kutusu (üç dil), metin |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt`. C++/Python'da C'den anlamca farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`.

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`. Kullananlar: ortak_rastgele — Örnek 1, 2, 3, 4, 5, 6, 8, 9; zamanlayici — Örnek 2, 5, 8, 9 (süreler yalnızca stderr'e).

Profil çıktıları (rehber 14.4): `kavram/ciktilar/H14_08_profil_cikarma_gprof.txt` (Örnek 8, gcc -pg + gprof; adım süreleri -pg'siz ikiliden), `kavram/ciktilar/H14_08_profil_cikarma_cprofile.txt` (cProfile), `kavram/ciktilar/H14_K05_miniobs_v2_1_gprof.txt` (Mini-OBS 2 v2.1 denetle, 40 000 kayıt). perf bu makinede yoktur; örnekleme mantığı Kavram 2'de benzetilir.


## 2. Kavram programları (kavram/)

Merdiven dışı küçük programlar (Kaputun Altında, Dil Penceresi). Çıktılar `kavram/ciktilar/`; “bu çalıştırmada” ya da “bu makinede” etiketli değerler eşdeğerlik kapsamı dışındadır. K01'in C ve Python eşleri aynı çıktıyı verir. `kavram/` içinde derlenir: `-I../c ../c/ortak_rastgele.c [../c/zamanlayici.c]`.

| Dosya | Dil | Amaç | Çıktı | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H14_K01_gs_durum_uzayi.c` | C | Gezgin satıcıda durum uzayı: şehir 0 sabit, tur ile tersi aynı sayılınca (n − 1)!/2 farklı tur. Saniyede 10⁹ tur değerlendiren (iyimser) bir makinede kaba kuvvetin süresi. Kesin değer uint64_t ile n <= 21'e dek; bilimsel gösterim double ile. | `ciktilar/H14_K01_gs_durum_uzayi_c.txt` | metin s. 5, 12, 44 | — | metin |
| `kavram/H14_K01_gs_durum_uzayi.py` | Python | Gezgin satıcıda durum uzayı: şehir 0 sabit, tur ile tersi aynı sayılınca (n − 1)!/2 farklı tur. Saniyede 10⁹ tur değerlendiren (iyimser) bir makinede kaba kuvvetin süresi. Python tamsayısı taşmaz; C eşinin uint64_t sınırını (n <= 21) aynı çıktı için korur. | `ciktilar/H14_K01_gs_durum_uzayi_py.txt` | metin s. 5, 12, 44 | — | metin |
| `kavram/H14_K02_ornekleme_profili.py` | Python | Örnekleme tabanlı profilleyicinin (ör. Linux perf) mantığı, bir benzetimle: program, süreleri BİLİNEN bir çağrı ağacıdır. Profilleyici her P zaman biriminde bir kez çağrı yığınına bakar ("örnek") ve yığınları sayar. | `ciktilar/H14_K02_ornekleme_profili.txt` | metin s. 11, 27 | — | metin |
| `kavram/H14_K03_python_kacis_yollari.py` | Python | Python'da başarıma "kaçış yolları": aynı işi yapan el yazımı Python döngüsü ile C'de yazılmış yerleşik araç (sum, sorted, dict) arasındaki sabit çarpan. | `ciktilar/H14_K03_python_kacis_yollari.txt` | metin s. 30, 34 | — | metin |
| `kavram/H14_K04_esdeger_istatistik.py` | Python | "Üç dilde aynı çıktı" kültürünün dönem bilançosu. Her haftanın kodlar/ornekler.json dosyası okunur: örnek sayısı, "=" (üç dilde bayt bayt aynı çıktı) ve "Δ" (bilinçli dil farkı) dağılımı, amiral örnekler, düzeyler ve "farklar" (dil eşlerinin ayrıştığı satır … | `ciktilar/H14_K04_esdeger_istatistik.txt` | metin s. 34 | — | metin |


## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir. Belirtiler bu makinede, bu çalıştırmada gözlenmiştir (`hata_avcisi/ciktilar/`). `hata_avcisi/` içinde derlenir: `-I../c ../c/ortak_rastgele.c [../c/zamanlayici.c]`, C++ için `-I../cpp`. HA5'in kâhinli çalıştırması `ciktilar/H14_HA5_kahinsiz_test_kahin.txt` (çıkış kodu 1: karşı örnek), HA3'ün cProfile çıktısı `ciktilar/H14_HA3_olcmeden_optimizasyon_cprofile.txt`.

| Dosya | Dil | Tür | Hata / amaç | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H14_HA1_np_yanilgisi.c` | C | kasıtlı hata | Problemleri karmaşıklık sınıfına ayıran küçük bir "rapor" programı. Hata: "NP, polinom OLMAYAN demektir" yanılgısı koda dökülmüş: np_mi = !polinom_cozum_biliniyor. | `ciktilar/H14_HA1_np_yanilgisi.txt` | Bölüm 7; metin s. 9 | slayt metin: 14 | satır içi kod, metin |
| `hata_avcisi/H14_HA1_np_yanilgisi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H14_HA1_np_yanilgisi_duzeltilmis.txt` | metin s. 9 | slayt metin: 14 | metin |
| `hata_avcisi/H14_HA2_sozde_polinom.c` | C | kasıtlı hata | 0/1 sırt çantası (H13) için "DP O(n·W), yani polinom; her girdide hızlı" varsayımı. Bütçe kararı girdi UZUNLUĞUYLA veriliyor: tahmin = n · b (b = W'nin bit sayısı). Oysa tablo n·(W + 1) hücredir ve W ≈ 2^b: süre b'ye göre ÜSTELDİR (sözde polinom). | `ciktilar/H14_HA2_sozde_polinom.txt` | Bölüm 7; metin s. 6, 10 | slayt kod: 45; metin: 4, 17 | satır içi kod, metin |
| `hata_avcisi/H14_HA2_sozde_polinom_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H14_HA2_sozde_polinom_duzeltilmis.txt` | metin s. 6, 10 | slayt metin: 4, 17, 45 | metin |
| `hata_avcisi/H14_HA3_olcmeden_optimizasyon.py` | Python | kasıtlı hata | Ölçmeden optimizasyon. Kayıt işleme programı yavaş bulununca "ortalama hesabı yavaştır" diye TAHMİN ediliyor ve ortalama 'hızlandırılıyor' (ortalama_hizli: dörder açılmış döngü). Ölçülmediği için asıl darboğaz — O(n²) yinelenen tespiti — yerinde kalıyor. | `ciktilar/H14_HA3_olcmeden_optimizasyon.txt` `ciktilar/H14_HA3_olcmeden_optimizasyon_cprofile.txt` | Bölüm 7; metin s. 11, 35 | — | satır içi kod, metin |
| `hata_avcisi/H14_HA3_olcmeden_optimizasyon_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H14_HA3_olcmeden_optimizasyon_duzeltilmis.txt` | metin s. 11, 35 | — | metin |
| `hata_avcisi/H14_HA4_sezgisel_en_iyi.cpp` | C++ | kasıtlı hata | Rota raporu: en yakın komşu sezgiselinin turu "EN KISA TUR" diye raporlanıyor; hiçbir doğrulama ya da sınır yok. | `ciktilar/H14_HA4_sezgisel_en_iyi.txt` | Bölüm 7; metin s. 17 | slayt metin: 27 | satır içi kod |
| `hata_avcisi/H14_HA4_sezgisel_en_iyi_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H14_HA4_sezgisel_en_iyi_duzeltilmis.txt` | metin s. 17 | slayt metin: 27 | — |
| `hata_avcisi/H14_HA5_kahinsiz_test.c` | C | kasıtlı hata | Final projesinde kâhin testi olmadan "çalışıyor" demek. Hızlı yinelenen numara denetimi (sırala + komşuları karşılaştır, H6) elle yazılmış üç testi geçiyor; geliştirici "çalışıyor" diyor. Hata: komşu döngüsü i = 1 .. n−2; SON çift hiç karşılaştırılmaz. | `ciktilar/H14_HA5_kahinsiz_test.txt` `ciktilar/H14_HA5_kahinsiz_test_kahin.txt` | Bölüm 7 | — | satır içi kod |
| `hata_avcisi/H14_HA5_kahinsiz_test_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H14_HA5_kahinsiz_test_duzeltilmis.txt` | — | — | — |


## 4. Haftanın Deneyi (deney/)

Sürücü `python3 deney/h14_olcum_calistir.py` (derler, çalıştırır, ham CSV'leri ve `OLCUM_ORTAMI.txt`'yi yazar), çözümleme `python3 deney/h14_cozumle.py` (özet CSV/JSON: katlar, kestirimler, proje belgeleriyle karşılaştırma, dönem sentezi), grafikler `python3 ../gorseller/kaynak/h14_deney_grafik.py`. Ortak modüllerin kopyaları `deney/{c,cpp,python}/` içindedir.

| Dosya | Dil | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `deney/c/H14_deney_kiyas.c` | C | Kazançların ölçeği: aynı çekirdeği farklı derlemeyle (-O0 / -O2) ve farklı dille (C / C++ / Python) ölçmek. | metin s. 2, 27, 29 | slayt metin: 42, 43 | metin |
| `deney/c/deney_islemci.c` | C | Mini-OBS 2 sürümlerinin (v2.0–v2.12) deney.c modülüyle AYNI arayüz (deney.h: deney_olc, DeneySonucu) ve aynı düzen (1 ısınma + tekrar ölçüm, ortanca). | metin s. 2, 27, 29 | slayt metin: 42, 43 | metin |
| `deney/cpp/H14_deney_kiyas.cpp` | C++ | Kazançların ölçeği: aynı çekirdeği farklı derlemeyle ve farklı dille ölçmek (C sürümüyle aynı algoritmalar, aynı tohumlar, aynı denetim toplamları). Örnek 9'un sekiz çekirdeği + Mini-OBS işlemlerinin dizi modeli (yinelenen ve arama) | metin s. 2, 27, 29 | slayt metin: 42, 43 | metin |
| `deney/python/H14_deney_kiyas.py` | Python | Kazançların ölçeği: aynı çekirdeği farklı dille ölçmek (C sürümüyle aynı algoritmalar, aynı tohumlar, aynı denetim toplamları). Örnek 9'un sekiz çekirdeği + Mini-OBS işlemlerinin dizi modeli (yinelenen ve arama) | metin s. 2, 27, 29 | slayt metin: 42, 43 | metin |
| `deney/h14_olcum_calistir.py` | Python | AP-2 Hafta 14 · Haftanın Deneyi: dönem kıyaslama raporu için ölçüm sürücüsü. | metin s. 2, 27, 29 | slayt metin: 42, 43 | metin |
| `deney/h14_cozumle.py` | Python | AP-2 Hafta 14 · Haftanın Deneyi: dönem kıyaslama raporunun çözümlemesi. Bütün oranlar, katlar ve kestirimler BURADA, ham CSV'lerden hesaplanır (elle sayı yok). | metin s. 2, 27, 29 | slayt metin: 42, 43 | metin |

Ham ve özet veriler (`deney/sonuclar/`): `h14_deney_kiyas.csv`, `h14_deney_miniobs.csv`, `h14_olcum_gunlugu.txt`, `h14_ozet.json`, `h14_ozet_katlar.csv`, `h14_ozet_kazanc.csv`, `h14_ozet_proje.csv`, `h14_ozet_sentez.csv`, `h14_ozet_surumler.csv`; ölçüm ortamı `deney/OLCUM_ORTAMI.txt`. Grafikler: `gorseller/h14_deney_{surumler,kazanc,dil}_{belge,sunum}.png`.


## 5. Girdiler (girdiler/)

| Dosya | Açıklama |
|---|---|
| `girdiler/H14_07_ders_plani.txt` | kurgusal ders kataloğu ve önkoşul satırları (Örnek 7: ders planı → Kahn) |
| `girdiler/H14_07_labirent.txt` | 9 × 15 ızgara labirent (Örnek 7: labirent → BFS) |
| `girdiler/H14_07_sudoku.txt` | 30 ipuçlu, tek çözümlü sudoku (Örnek 7: sudoku → geri izleme) |
| `girdiler/H14_10_miniobs_cekirdek.txt` | Mini-OBS çekirdeğinin komut dosyası (Örnek 10, standart girdi; kayıtlar kurgusal) |
| `girdiler/H14_A18_ornek_tur.txt` | Atölye 2'nin örnek tur dosyası (biçim örneği: 0, 1, …, 49) |


## 6. Alıştırma programları (alistirmalar/)

Alıştırmaların ve Atölye 2'nin kodlu dosyaları. Çıktıları (`alistirmalar/ciktilar/`) yanıt olduğu için öğrenci ZIP'inde yoktur. Parsons bulmacası (A10) bilerek derlenmez; “hata bul” dosyaları (A08, A09) kasıtlı mantık hatası içerir ama bellek açısından temizdir (ASan + Valgrind, `BELLEK_DENETIMI.txt`). `alistirmalar/` içinde derlenir: `../c/ortak_rastgele.c` gerekenlerde.

| Dosya | Dil | Kullanım | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `alistirmalar/H14_A01_nn_izleme.c` | C | Alıştırma 14.1 | Altı şehirde en yakın komşu sezgiseli (Örnek 3'ün kuralı: ziyaret edilmemiş en yakın şehir; karşılaştırma tamsayı kare uzaklıkla, eşitlikte KÜÇÜK indis). İki başlangıç şehri: 0 ve 3. Programı çalıştırmadan iki turu ve uzunluklarını tahmin edin. | Alıştırma 14.1; metin s. 40 | — | satır içi kod, metin |
| `alistirmalar/H14_A05_polinom_mu.c` | C | Alıştırma 14.5 | Dört fonksiyonun iş sayaçları, girdideki SAYININ bit uzunluğu b büyürken. Hangisi girdi uzunluğunda polinom, hangisi sözde polinom (sayının DEĞERİNDE polinom, bit uzunluğunda üstel)? Sayaçları b'ye göre tablolayıp sınıflandırın. | metin s. 41 | — | metin |
| `alistirmalar/H14_A08_hata_bul_nn.c` | C | Alıştırma 14.8 | En yakın komşu turunu kaba kuvvetin bulduğu en iyi turla karşılaştıran küçük bir test (LCG, tohum 2026, n = 8; Örnek 3'ün ilk beş örneği). Kâhinin raporu bir şeylerin yanlış olduğunu söylüyor: hangi satır, neden? | Alıştırma 14.8; metin s. 41 | — | satır içi kod, metin |
| `alistirmalar/H14_A09_hata_bul_iki_opt.c` | C | Alıştırma 14.9 | İlk iyileştirmeli 2-opt (Örnek 4'ün kuralı) en yakın komşu turlarına uygulanıyor (LCG, tohum 2026, n = 8; Örnek 3'ün 100 örneği). Sonra bir DENETİM taraması, bitmiş turda kısaltan bir 2-opt hamlesi kalıp kalmadığına bakıyor. | Alıştırma 14.9; metin s. 20, 42 | — | satır içi kod, metin |
| `alistirmalar/H14_A10_parsons_held_karp.c` | C | Alıştırma 14.10 | Parsons: tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar Held–Karp'ın GERİ ÇIKARMA fonksiyonunun KARIŞTIRILMIŞ satırlarıdır; iki satır fazladır (kullanılmayacak). | Alıştırma 14.10; metin s. 42 | — | metin |
| `alistirmalar/H14_A14_yavas_rapor.c` | C | Alıştırma 14.14 | Profil ödevi. Ders kayıtlarından rapor üreten, DOĞRU ama YAVAŞ bir program (m kayıt: öğrenci no, ders, puan; LCG tohum 14). | metin s. 43 | — | metin |
| `alistirmalar/H14_A14_yavas_rapor.py` | Python | Alıştırma 14.14 | Profil ödevi. Ders kayıtlarından rapor üreten, DOĞRU ama YAVAŞ bir program (m kayıt: öğrenci no, ders, puan; LCG tohum 14). | metin s. 43 | — | metin |
| `alistirmalar/H14_A16_esitlik_kirma.c` | C | Alıştırma 14.16 | Diller arası okuma: Örnek 2'nin beş şehrinde 24 tur sözlük sırasıyla üretilir (şehir 0 sabit) ve en kısası ile en uzunu döngüde <= ve >= ile seçilir. Eş dosya H14_A16_esitlik_kirma.py aynı turları min/max ile seçer. | metin s. 15, 43 | — | metin |
| `alistirmalar/H14_A16_esitlik_kirma.py` | Python | Alıştırma 14.16 | Diller arası okuma: Örnek 2'nin beş şehrinde 24 turun en kısası ve en uzunu Python'un min/max fonksiyonlarıyla seçiliyor; eş dosya H14_A16_esitlik_kirma.c aynı turları aynı sırayla bir döngüde karşılaştırıyor. | Alıştırma 14.16; metin s. 15, 43 | — | satır içi kod, metin |
| `alistirmalar/H14_A17_tur_sayisi.c` | C | Alıştırma 14.17 | Diller arası okuma: gezgin satıcıda farklı tur sayısı (n − 1)!/2, 32 bitlik İŞARETSİZ tamsayıyla (önce (n − 1)!, sonra 2'ye bölme). Eş dosya H14_A17_tur_sayisi.py aynı hesabı Python tamsayısıyla yapar. | Alıştırma 14.17; metin s. 44 | — | satır içi kod, metin |
| `alistirmalar/H14_A17_tur_sayisi.py` | Python | Alıştırma 14.17 | Diller arası okuma: gezgin satıcıda farklı tur sayısı (n − 1)!/2, Python tamsayısıyla (önce (n − 1)!, sonra 2'ye bölme). Eş dosya H14_A17_tur_sayisi.c aynı hesabı 32 bitlik işaretsiz tamsayıyla yapar. | metin s. 44 | — | metin |
| `alistirmalar/H14_A18_gs_yarismasi.c` | C | Atölye 2 (hakem programı) | Gezgin satıcı yarışması. 50 şehir ortak LCG ile üretilir (tohum 50, koordinatlar 0..999); her takım kendi sezgiselini yazar ve turunu bir dosyaya kaydeder. Bu program turu DOĞRULAR (her şehir tam bir kez) ve uzunluğunu hesaplar. | metin s. 3, 20, 44 | slayt metin: 53 | metin |
| `alistirmalar/H14_A18_gs_yarismasi.py` | Python | Atölye 2 (hakem programı) | Gezgin satıcı yarışması. 50 şehir ortak LCG ile üretilir (tohum 50, koordinatlar 0..999); her takım kendi sezgiselini yazar ve turunu bir dosyaya kaydeder. Bu program turu DOĞRULAR (her şehir tam bir kez) ve uzunluğunu hesaplar. | metin s. 3, 20, 44 | slayt metin: 53 | metin |


## 7. Quiz ve soru bankası programları (quiz/)

İki grup: (a) haftanın quiz'inin kodlu soruları (Q81, Q82; web “Kendini sına” bölümü) ve (b) final hazırlık soru bankasının (H1–H14, 73 soru; web oynatıcısı) kodlu sorularının doğrulama programları. Çıktıları (`quiz/ciktilar/`) yanıt olduğu için öğrenci ZIP'inde yoktur. `_bos` dosyaları boşluklu (tamamlanacak) kesitlerdir, bu hâlleriyle derlenmez; dört seçenek öğretim üyesinin betiğiyle ayrı ayrı derlenip çalıştırılmıştır. `quiz/` içinde derlenir (`../c/ortak_rastgele.c` gerekenlerde).

| Dosya | Dil | Kullanım | Ders notu | Web |
|---|---|---|---|---|
| `quiz/H14_Q01_h1_tek_toplam.c` | C | soru bankası: f01, f02 | — | soru bankası oynatıcısı (f01, f02) |
| `quiz/H14_Q03_h1_ortalama.c` | C | soru bankası: f03 | — | soru bankası oynatıcısı (f03) |
| `quiz/H14_Q04_h1_yuvarlama.c` | C | soru bankası: f04 | — | soru bankası oynatıcısı (f04) |
| `quiz/H14_Q04_h1_yuvarlama.py` | Python | soru bankası: f04 | — | soru bankası oynatıcısı (f04) |
| `quiz/H14_Q06_h2_katlanan.c` | C | soru bankası: f06 | — | soru bankası oynatıcısı (f06) |
| `quiz/H14_Q07_h2_ucte_bir.c` | C | soru bankası: f07 | Ek B.5 | soru bankası oynatıcısı (f07) |
| `quiz/H14_Q08_h2_egim_bos.c` | C | soru bankası: f08 | — | soru bankası oynatıcısı (f08) |
| `quiz/H14_Q09_h2_uzunluk.c` | C | soru bankası: f09 | — | soru bankası oynatıcısı (f09) |
| `quiz/H14_Q11_h3_bit_say.c` | C | soru bankası: f11 | — | soru bankası oynatıcısı (f11) |
| `quiz/H14_Q13_h3_vezir_bos.c` | C | soru bankası: f13 | — | soru bankası oynatıcısı (f13) |
| `quiz/H14_Q14_h3_sayac.c` | C | soru bankası: f14 | — | soru bankası oynatıcısı (f14) |
| `quiz/H14_Q14_h3_sayac.py` | Python | soru bankası: f14 | — | soru bankası oynatıcısı (f14) |
| `quiz/H14_Q15_h3_alt_kume_degismez.c` | C | soru bankası: f15 | — | soru bankası oynatıcısı (f15) |
| `quiz/H14_Q16_h4_ust_sinir.c` | C | soru bankası: f16 | — | soru bankası oynatıcısı (f16) |
| `quiz/H14_Q17_h4_ikiye_bolme.c` | C | soru bankası: f17 | — | soru bankası oynatıcısı (f17) |
| `quiz/H14_Q18_h4_merdiven_bos.c` | C | soru bankası: f18 | — | soru bankası oynatıcısı (f18) |
| `quiz/H14_Q20_h4_tekrar_say.c` | C | soru bankası: f20 | — | soru bankası oynatıcısı (f20) |
| `quiz/H14_Q21_h5_araya_iz.c` | C | soru bankası: f21 | — | soru bankası oynatıcısı (f21) |
| `quiz/H14_Q22_h5_kabarcik_degismez.c` | C | soru bankası: f22 | — | soru bankası oynatıcısı (f22) |
| `quiz/H14_Q23_h5_ters_kararli.cpp` | C++ | soru bankası: f23 | — | soru bankası oynatıcısı (f23) |
| `quiz/H14_Q23_h5_ters_kararli.py` | Python | soru bankası: f23 | — | soru bankası oynatıcısı (f23) |
| `quiz/H14_Q24_h5_araya_j0.c` | C | soru bankası: f24 | — | soru bankası oynatıcısı (f24) |
| `quiz/H14_Q25_h5_erken_cikis_bos.c` | C | soru bankası: f25 | — | soru bankası oynatıcısı (f25) |
| `quiz/H14_Q26_h6_ana_teorem.c` | C | soru bankası: f26 | — | soru bankası oynatıcısı (f26) |
| `quiz/H14_Q28_h6_orta_bos.c` | C | soru bankası: f28 | — | soru bankası oynatıcısı (f28) |
| `quiz/H14_Q29_h6_birlestirme_iz.c` | C | soru bankası: f29 | — | soru bankası oynatıcısı (f29) |
| `quiz/H14_Q30_h6_lomuto_degismez.c` | C | soru bankası: f30 | — | soru bankası oynatıcısı (f30) |
| `quiz/H14_Q31_h7_obek_cikar.c` | C | soru bankası: f31 | — | soru bankası oynatıcısı (f31) |
| `quiz/H14_Q32_h7_kurma_say.c` | C | soru bankası: f32 | — | soru bankası oynatıcısı (f32) |
| `quiz/H14_Q33_h7_kova.c` | C | soru bankası: f33 | — | soru bankası oynatıcısı (f33) |
| `quiz/H14_Q34_h7_bayt_sirasi.c` | C | soru bankası: f34 | — | soru bankası oynatıcısı (f34) |
| `quiz/H14_Q34_h7_bayt_sirasi.py` | Python | soru bankası: f34 | — | soru bankası oynatıcısı (f34) |
| `quiz/H14_Q36_h8_katlama.c` | C | soru bankası: f36 | — | soru bankası oynatıcısı (f36) |
| `quiz/H14_Q37_h8_liste_sil.c` | C | soru bankası: f37 | — | soru bankası oynatıcısı (f37) |
| `quiz/H14_Q38_h8_takma_ad.c` | C | soru bankası: f38 | — | soru bankası oynatıcısı (f38) |
| `quiz/H14_Q38_h8_takma_ad.py` | Python | soru bankası: f38 | — | soru bankası oynatıcısı (f38) |
| `quiz/H14_Q39_h8_ters_bos.c` | C | soru bankası: f39 | — | soru bankası oynatıcısı (f39) |
| `quiz/H14_Q40_h8_orta_dugum.c` | C | soru bankası: f40 | — | soru bankası oynatıcısı (f40) |
| `quiz/H14_Q41_h9_sonek.c` | C | soru bankası: f41 | — | soru bankası oynatıcısı (f41) |
| `quiz/H14_Q42_h9_dairesel_bos.c` | C | soru bankası: f42 | — | soru bankası oynatıcısı (f42) |
| `quiz/H14_Q44_h9_pop.py` | Python | soru bankası: f44 | — | soru bankası oynatıcısı (f44) |
| `quiz/H14_Q44_h9_pop_bos.cpp` | C++ | soru bankası: f44 | — | soru bankası oynatıcısı (f44) |
| `quiz/H14_Q45_h9_parantez.c` | C | soru bankası: f45 | — | soru bankası oynatıcısı (f45) |
| `quiz/H14_Q46_h10_yoklama_iz.c` | C | soru bankası: f46 | — | soru bankası oynatıcısı (f46) |
| `quiz/H14_Q48_h10_mezar.c` | C | soru bankası: f48 | — | soru bankası oynatıcısı (f48) |
| `quiz/H14_Q50_h10_dict_sira.py` | Python | soru bankası: f50 | — | soru bankası oynatıcısı (f50) |
| `quiz/H14_Q51_h11_bfs_iz.c` | C | soru bankası: f51 | — | soru bankası oynatıcısı (f51) |
| `quiz/H14_Q52_h11_bfs_bos.c` | C | soru bankası: f52 | — | soru bankası oynatıcısı (f52) |
| `quiz/H14_Q53_h11_dfs_dongu.c` | C | soru bankası: f53 | — | soru bankası oynatıcısı (f53) |
| `quiz/H14_Q55_h11_bfs_kuyruk.c` | C | soru bankası: f55 | — | soru bankası oynatıcısı (f55) |
| `quiz/H14_Q57_h12_dijkstra_iz.c` | C | soru bankası: f57 | — | soru bankası oynatıcısı (f57) |
| `quiz/H14_Q59_h12_negatif.c` | C | soru bankası: f59 | — | soru bankası oynatıcısı (f59) |
| `quiz/H14_Q60_h12_sonsuz.c` | C | soru bankası: f60 | — | soru bankası oynatıcısı (f60) |
| `quiz/H14_Q60_h12_sonsuz.py` | Python | soru bankası: f60 | — | soru bankası oynatıcısı (f60) |
| `quiz/H14_Q61_h13_cache.c` | C | soru bankası: f61 | — | soru bankası oynatıcısı (f61) |
| `quiz/H14_Q61_h13_cache.py` | Python | soru bankası: f61 | — | soru bankası oynatıcısı (f61) |
| `quiz/H14_Q62_h13_sirt_degismez.c` | C | soru bankası: f62 | — | soru bankası oynatıcısı (f62) |
| `quiz/H14_Q63_h13_ters_dongu_bos.c` | C | soru bankası: f63 | — | soru bankası oynatıcısı (f63) |
| `quiz/H14_Q68_h14_iki_opt_degismez.c` | C | soru bankası: f68 | — | soru bankası oynatıcısı (f68) |
| `quiz/H14_Q69_h14_dogrulayici.c` | C | soru bankası: f69 | — | soru bankası oynatıcısı (f69) |
| `quiz/H14_Q70_h14_nn_bos.c` | C | soru bankası: f70 | — | soru bankası oynatıcısı (f70) |
| `quiz/H14_Q72_h14_permutasyon.cpp` | C++ | soru bankası: f72 | Ek B.5 | soru bankası oynatıcısı (f72) |
| `quiz/H14_Q72_h14_permutasyon.py` | Python | soru bankası: f72 | — | soru bankası oynatıcısı (f72) |
| `quiz/H14_Q81_iki_opt_isaret.c` | C | haftalık quiz, soru 1 | — | satır içi kod |
| `quiz/H14_Q82_en_uzak_esitlik.c` | C | haftalık quiz, soru 2 | — | satır içi kod |
| `quiz/H14_Q82_en_uzak_esitlik.py` | Python | haftalık quiz, soru 2 | — | satır içi kod |


## 8. Diğer

- `BELLEK_DENETIMI.txt` — Valgrind (ve ASan) bellek denetimi sonuçları (betikle üretildi; doğrulama kanıtıdır).
- `ornekler.json` — örnek üst verisi (başlık, düzey, çıktı türü, fark satırları, Dil Penceresi notu).
- `esdeger_test.py` — eşdeğerlik testi (ortak; değiştirilmedi).
- `AP2_H14_kodlar.zip` — bu klasörün öğrenci kopyası (alıştırma ve quiz çıktıları hariç).

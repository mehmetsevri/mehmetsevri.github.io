/* H14_07_indirgeme.c — AP-2 Hafta 14 · Örnek 7 (★★)
 * Amaç    : İndirgeme (modelleme): yeni bir problemi BİLİNEN bir çözücüye
 *           çevirmek. (1) Sudoku → geri izleme (H3 Örnek 13); (2) labirent
 *           → ızgara grafında BFS (H11 Örnek 10); (3) ders planı → yönlü
 *           grafta topolojik sıralama (H11 Örnek 11, Kahn). Benzeri: sınav
 *           programı → graf boyama (H12 Örnek 13)
 * Kurallar: komşular artan köşe numarasıyla (yukarı, sol, sağ, aşağı);
 *           Kahn'da giriş derecesi 0 olanlardan EN KÜÇÜK numaralı seçilir
 *           (doğrusal tarama; V küçük); ders kodu → köşe: alfabetik sıra
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_07_indirgeme.c -o H14_07_indirgeme
 * Çalıştır: ./H14_07_indirgeme ../girdiler/H14_07_sudoku.txt \
 *           ../girdiler/H14_07_labirent.txt ../girdiler/H14_07_ders_plani.txt
 * Eşleri  : cpp/H14_07_indirgeme.cpp · python/H14_07_indirgeme.py
 * Çıktı   : üç dilde aynı (=); okunamayan/bozuk dosyada çıkış kodu 1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SATIR_UZ 256

/* Bir sonraki yorum olmayan, boş olmayan satırı okur (sondaki \r\n
 * silinir). Dönen: 1 satır var, 0 dosya sonu */
static int satir_al(FILE *f, char *satir)
{
    while (fgets(satir, SATIR_UZ, f) != NULL) {
        satir[strcspn(satir, "\r\n")] = '\0';
        if (satir[0] != '#' && satir[0] != '\0') {
            return 1;
        }
    }
    return 0;
}

/* Bir sonraki satırı olduğu gibi okur (ızgara satırı '#' ile başlayabilir).
 * Dönen: 1 satır var, 0 dosya sonu */
static int satir_ham(FILE *f, char *satir)
{
    if (fgets(satir, SATIR_UZ, f) == NULL) {
        return 0;
    }
    satir[strcspn(satir, "\r\n")] = '\0';
    return 1;
}

/* === 1) Sudoku -> geri izleme (H3 Örnek 13) ========================== */
static int tablo[9][9];                  /* 0 = boş kare */
static int satir_var[9][10], sutun_var[9][10], kutu_var[9][10];
static long long sudoku_dugum;

static int kutu_no(int r, int c)
{
    return (r / 3) * 3 + c / 3;
}

static void isaretle(int r, int c, int d, int deger)
{
    satir_var[r][d] = deger;
    sutun_var[c][d] = deger;
    kutu_var[kutu_no(r, c)][d] = deger;
}

/* Dönen: ipucu sayısı; -1 dosya yok, -2 biçim/kural hatası */
static int sudoku_oku(const char *yol)
{
    char satir[SATIR_UZ];
    FILE *f = fopen(yol, "r");
    if (f == NULL) {
        return -1;
    }
    int ipucu = 0;
    for (int r = 0; r < 9; r++) {
        if (!satir_al(f, satir) || strlen(satir) != 9) {
            fclose(f);
            return -2;
        }
        for (int c = 0; c < 9; c++) {
            int d = satir[c] == '.' ? 0 : satir[c] - '0';
            if (d < 0 || d > 9 || (satir[c] != '.' && d == 0)) {
                fclose(f);
                return -2;
            }
            if (d > 0) {
                if (satir_var[r][d] || sutun_var[c][d] ||
                    kutu_var[kutu_no(r, c)][d]) {
                    fclose(f);
                    return -2;                   /* ipuçları çelişiyor */
                }
                isaretle(r, c, d, 1);
                ipucu++;
            }
            tablo[r][c] = d;
        }
    }
    fclose(f);
    return ipucu;
}

/* İlk boş kareyi (satır satır) bul; 1..9'u dene; çıkmazda geri al */
static int sudoku_coz(int konum)
{
    sudoku_dugum++;
    while (konum < 81 && tablo[konum / 9][konum % 9] != 0) {
        konum++;
    }
    if (konum == 81) {
        return 1;                                /* bütün kareler dolu */
    }
    int r = konum / 9, c = konum % 9;
    for (int d = 1; d <= 9; d++) {
        if (!satir_var[r][d] && !sutun_var[c][d] &&
            !kutu_var[kutu_no(r, c)][d]) {
            tablo[r][c] = d;                     /* seç */
            isaretle(r, c, d, 1);
            if (sudoku_coz(konum + 1)) {         /* dene */
                return 1;
            }
            isaretle(r, c, d, 0);                /* geri al */
            tablo[r][c] = 0;
        }
    }
    return 0;
}

/* Çözüm sayısı (en çok sinir'e kadar): bulmaca iyi tanımlı mı? */
static int sudoku_say(int konum, int sinir)
{
    while (konum < 81 && tablo[konum / 9][konum % 9] != 0) {
        konum++;
    }
    if (konum == 81) {
        return 1;
    }
    int r = konum / 9, c = konum % 9, say = 0;
    for (int d = 1; d <= 9 && say < sinir; d++) {
        if (!satir_var[r][d] && !sutun_var[c][d] &&
            !kutu_var[kutu_no(r, c)][d]) {
            tablo[r][c] = d;
            isaretle(r, c, d, 1);
            say += sudoku_say(konum + 1, sinir - say);
            isaretle(r, c, d, 0);
            tablo[r][c] = 0;
        }
    }
    return say;
}

static void sudoku_yaz(void)
{
    for (int r = 0; r < 9; r++) {
        printf("   ");
        for (int c = 0; c < 9; c++) {
            printf("%c%s", tablo[r][c] ? '0' + tablo[r][c] : '.',
                   c == 8 ? "\n" : (c % 3 == 2 ? " | " : " "));
        }
        if (r % 3 == 2 && r < 8) {
            printf("   ------+-------+------\n");
        }
    }
}

/* === 2) Labirent -> BFS (H11 Örnek 10) =============================== */
#define MAKS_R 32
#define MAKS_C 64
static char izgara[MAKS_R][MAKS_C + 1];
static int R, C;

/* Dönen: 0 başarı; -1 dosya yok, -2 biçim hatası (S ve E tek olmalı) */
static int labirent_oku(const char *yol, int *bas, int *hedef)
{
    char satir[SATIR_UZ], *son;
    FILE *f = fopen(yol, "r");
    if (f == NULL) {
        return -1;
    }
    if (!satir_al(f, satir)) {
        fclose(f);
        return -2;
    }
    R = (int)strtol(satir, &son, 10);
    C = (int)strtol(son, &son, 10);
    if (R < 1 || R > MAKS_R || C < 1 || C > MAKS_C) {
        fclose(f);
        return -2;
    }
    *bas = *hedef = -1;
    for (int r = 0; r < R; r++) {
        if (!satir_ham(f, satir) || (int)strlen(satir) != C) {
            fclose(f);
            return -2;
        }
        for (int c = 0; c < C; c++) {
            if (satir[c] == 'S') {
                *bas = r * C + c;
            } else if (satir[c] == 'E') {
                *hedef = r * C + c;
            }
        }
        strcpy(izgara[r], satir);
    }
    fclose(f);
    return *bas >= 0 && *hedef >= 0 ? 0 : -2;
}

/* Ağırlıksız grafta BFS; köşe = r·C + c. Dönen: hedefe uzaklık (-1 yok) */
static int bfs(int bas, int hedef, int *uzaklik, int *ebeveyn,
               int *ziyaret_sayisi)
{
    static int kuyruk[MAKS_R * MAKS_C];
    int bas_i = 0, son_i = 0;
    const int dr[4] = {-1, 0, 0, 1}, dc[4] = {0, -1, 1, 0};
    for (int v = 0; v < R * C; v++) {
        uzaklik[v] = -1;
        ebeveyn[v] = -1;
    }
    uzaklik[bas] = 0;
    kuyruk[son_i++] = bas;
    *ziyaret_sayisi = 0;
    while (bas_i < son_i) {
        int u = kuyruk[bas_i++];
        (*ziyaret_sayisi)++;
        if (u == hedef) {
            break;
        }
        for (int k = 0; k < 4; k++) {           /* artan köşe numarası */
            int r = u / C + dr[k], c = u % C + dc[k];
            if (r < 0 || r >= R || c < 0 || c >= C || izgara[r][c] == '#') {
                continue;
            }
            int v = r * C + c;
            if (uzaklik[v] == -1) {
                uzaklik[v] = uzaklik[u] + 1;
                ebeveyn[v] = u;
                kuyruk[son_i++] = v;
            }
        }
    }
    return uzaklik[hedef];
}

/* === 3) Ders planı -> topolojik sıralama (H11 Örnek 11, Kahn) ======== */
#define MAKS_DERS 32
#define KOD_UZ 9
static char kod[MAKS_DERS][KOD_UZ];
static int V, E;
static int kenar_u[4 * MAKS_DERS], kenar_v[4 * MAKS_DERS];
static int komsu[MAKS_DERS][MAKS_DERS];          /* komşuluk matrisi */

static int kod_karsilastir(const void *p, const void *q)
{
    return strcmp((const char *)p, (const char *)q);
}

static int kod_bul(const char *k)                /* yoksa -1 */
{
    for (int i = 0; i < V; i++) {
        if (strcmp(kod[i], k) == 0) {
            return i;
        }
    }
    return -1;
}

/* İki geçiş: kodları topla ve alfabetik sırala (köşe numarası), sonra
 * kenarları kur. Dönen: 0 başarı; -1 dosya yok, -2 biçim hatası */
static int plan_oku(const char *yol)
{
    char satir[SATIR_UZ], ciftler[4 * MAKS_DERS][2][KOD_UZ];
    FILE *f = fopen(yol, "r");
    if (f == NULL) {
        return -1;
    }
    V = 0;
    E = 0;
    while (satir_al(f, satir)) {
        char a[SATIR_UZ], b[SATIR_UZ];
        if (E == 4 * MAKS_DERS || sscanf(satir, "%255s %255s", a, b) != 2
            || strlen(a) >= KOD_UZ || strlen(b) >= KOD_UZ) {
            fclose(f);
            return -2;
        }
        strcpy(ciftler[E][0], a);
        strcpy(ciftler[E][1], b);
        E++;
        for (int t = 0; t < 2; t++) {
            const char *k = t == 0 ? a : b;
            if (kod_bul(k) == -1) {
                if (V == MAKS_DERS) {
                    fclose(f);
                    return -2;
                }
                strcpy(kod[V++], k);
            }
        }
    }
    fclose(f);
    qsort(kod, (size_t)V, KOD_UZ, kod_karsilastir);   /* araç: sıralama */
    memset(komsu, 0, sizeof komsu);
    for (int e = 0; e < E; e++) {
        kenar_u[e] = kod_bul(ciftler[e][0]);
        kenar_v[e] = kod_bul(ciftler[e][1]);
        komsu[kenar_u[e]][kenar_v[e]] = 1;
    }
    return 0;
}

/* Kahn: dönen sıralanan köşe sayısı (< V ise döngü var) */
static int kahn(int *sira, int *donem)
{
    int giris[MAKS_DERS] = {0}, alindi[MAKS_DERS] = {0};
    for (int u = 0; u < V; u++) {
        for (int v = 0; v < V; v++) {
            giris[v] += komsu[u][v];
        }
        donem[u] = 1;
    }
    for (int k = 0; k < V; k++) {
        int sec = -1;
        for (int v = 0; v < V && sec == -1; v++) {   /* en küçük numara */
            if (!alindi[v] && giris[v] == 0) {
                sec = v;
            }
        }
        if (sec == -1) {
            return k;                            /* döngü: kalanlar */
        }
        alindi[sec] = 1;
        sira[k] = sec;
        for (int v = 0; v < V; v++) {
            if (komsu[sec][v]) {
                giris[v]--;
                if (donem[sec] + 1 > donem[v]) {
                    donem[v] = donem[sec] + 1;  /* en uzun önkoşul zinciri */
                }
            }
        }
    }
    return V;
}

static int hata(const char *yol, int kod_)
{
    fprintf(stderr, "%s: %s\n", yol, kod_ == -1 ? "dosya açılamadı"
                                               : "biçim hatası");
    return 1;
}

int main(int argc, char *argv[])
{
    if (argc != 4) {
        fprintf(stderr, "Kullanım: %s sudoku.txt labirent.txt plan.txt\n",
                argv[0]);
        return 2;
    }
    printf("1) Sudoku -> geri izleme (H3 Örnek 13)\n");
    printf("   Modelleme: boş kare = karar; aday = 1..9; kısıt = satır, "
           "sütun, 3x3 kutu\n");
    int ipucu = sudoku_oku(argv[1]);
    if (ipucu < 0) {
        return hata(argv[1], ipucu);
    }
    printf("   Bulmaca (%d ipucu, %d boş kare):\n", ipucu, 81 - ipucu);
    sudoku_yaz();
    printf("   çözüm sayısı (2'de durur): %d\n", sudoku_say(0, 2));
    sudoku_dugum = 0;
    int cozuldu = sudoku_coz(0);
    printf("   %s (ziyaret edilen düğüm = %lld):\n",
           cozuldu ? "Çözüm" : "Çözüm yok", sudoku_dugum);
    if (cozuldu) {
        sudoku_yaz();
    }

    printf("\n2) Labirent -> BFS (H11 Örnek 10)\n");
    printf("   Modelleme: boş hücre = köşe (r*C + c); yatay/dikey komşu boş "
           "hücre = kenar;\n   ağırlıksız en kısa yol = BFS\n");
    int bas = -1, hedef = -1, ziyaret = 0;
    int k = labirent_oku(argv[2], &bas, &hedef);
    if (k < 0) {
        return hata(argv[2], k);
    }
    int kose = 0, kenar = 0;
    for (int r = 0; r < R; r++) {
        for (int c = 0; c < C; c++) {
            if (izgara[r][c] != '#') {
                kose++;
                kenar += c + 1 < C && izgara[r][c + 1] != '#';
                kenar += r + 1 < R && izgara[r + 1][c] != '#';
            }
        }
    }
    static int uzaklik[MAKS_R * MAKS_C], ebeveyn[MAKS_R * MAKS_C];
    int u = bfs(bas, hedef, uzaklik, ebeveyn, &ziyaret);
    printf("   %d x %d ızgara: köşe = %d, kenar = %d; S = (%d, %d) köşe %d, "
           "E = (%d, %d) köşe %d\n", R, C, kose, kenar, bas / C, bas % C,
           bas, hedef / C, hedef % C, hedef);
    if (u < 0) {
        printf("   E'ye yol yok (ziyaret edilen köşe = %d)\n", ziyaret);
    } else {
        printf("   en kısa yol = %d adım; kuyruktan çıkan köşe = %d\n", u,
               ziyaret);
        for (int v = ebeveyn[hedef]; v != bas; v = ebeveyn[v]) {
            izgara[v / C][v % C] = '*';
        }
        for (int r = 0; r < R; r++) {
            printf("   %s\n", izgara[r]);
        }
    }

    printf("\n3) Ders planı -> topolojik sıralama (H11 Örnek 11, Kahn)\n");
    printf("   Modelleme: ders kodu = köşe (alfabetik numara); \"A B\" "
           "satırı = A -> B kenarı;\n   geçerli plan = topolojik sıra; "
           "döngü varsa plan yok\n");
    k = plan_oku(argv[3]);
    if (k < 0) {
        return hata(argv[3], k);
    }
    printf("   köşe = %d, kenar = %d:", V, E);
    for (int v = 0; v < V; v++) {
        printf(" %d %s%s", v, kod[v], v + 1 < V ? "," : "\n");
    }
    int sira[MAKS_DERS], donem[MAKS_DERS];
    int s = kahn(sira, donem);
    if (s < V) {
        printf("   döngü var: yalnız %d ders sıralanabildi; plan yok\n", s);
        return 0;
    }
    printf("   topolojik sıra:");
    for (int t = 0; t < V; t++) {
        printf(" %s", kod[sira[t]]);
    }
    printf("\n   dönemler (en erken dönem = en uzun önkoşul zinciri + 1):\n");
    for (int d = 1; d <= V; d++) {
        int var = 0;
        for (int t = 0; t < V; t++) {
            if (donem[sira[t]] == d) {
                if (!var) {
                    printf("     %d. dönem:", d);
                }
                printf(" %s", kod[sira[t]]);
                var = 1;
            }
        }
        if (var) {
            printf("\n");
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (Boost.Graph:
 * topological_sort); Python — graphlib.TopologicalSorter (3.9+; yalnızca
 * kâhin). Sıralama (qsort / std::sort / sorted) burada yalnız araçtır. */

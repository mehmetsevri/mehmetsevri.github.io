/* H14_08_profil_cikarma.c — AP-2 Hafta 14 · Örnek 8 (★★★)
 * Amaç    : Profil çıkarma: KASITLI darboğazlı küçük bir kayıt işleme
 *           programı (üretim, istatistik, O(n²) yinelenen tespiti, harf
 *           dağılımı, ilk 3). Profil (gprof / cProfile) asıl zamanın tüm
 *           çiftlerde geçtiğini gösterir; darboğaz "sırala + komşular"
 *           (H6, O(n log n)) ile giderilir. stdout belirleyicidir; adım
 *           süreleri (işlemci zamanı) stderr'e "bu çalıştırmada" yazılır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_08_profil_cikarma.c ortak_rastgele.c zamanlayici.c \
 *           -o H14_08_profil_cikarma
 * Profil  : gcc ... -O2 -pg -fno-inline ... ; ./H14_08_profil_cikarma
 *           30000 --surum yavas ; gprof -b ./H14_08_profil_cikarma gmon.out
 * Çalıştır: ./H14_08_profil_cikarma [n] [--surum yavas|hizli|ikisi]
 * Eşleri  : cpp/H14_08_profil_cikarma.cpp · python/H14_08_profil_cikarma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define TABAN_NO 220000000

static int *numara = NULL, *notlar = NULL, *gecici = NULL, *kopya = NULL;
static int n;

/* Sahiplik: dört dizi bu modülündür; birak() ile bırakılır. 0 / -1 */
static int ayir(int adet)
{
    n = adet;
    numara = malloc((size_t)n * sizeof *numara);
    notlar = malloc((size_t)n * sizeof *notlar);
    gecici = malloc((size_t)n * sizeof *gecici);
    kopya = malloc((size_t)n * sizeof *kopya);
    return numara && notlar && gecici && kopya ? 0 : -1;
}

static void birak(void)
{
    free(numara);
    free(notlar);
    free(gecici);
    free(kopya);
}

/* 1) Üretim: numaralar ardışık ve karışık; %1'i öncekilerden birinin
 * kopyası (kasıtlı yinelenen) */
static int kayitlari_uret(void)
{
    int yinelenen = 0;
    rastgele_tohum(8);
    for (int i = 0; i < n; i++) {
        numara[i] = TABAN_NO + i;
        notlar[i] = rastgele_aralik(0, 100);
    }
    rastgele_karistir(numara, (size_t)n);
    for (int i = 1; i < n; i++) {
        if (rastgele_aralik(0, 99) == 0) {
            numara[i] = numara[rastgele_aralik(0, i - 1)];
            yinelenen++;
        }
    }
    return yinelenen;
}

/* 2) İstatistik: toplam, en düşük, en yüksek — O(n) */
static long long istatistik(int *en_dusuk, int *en_yuksek)
{
    long long toplam = 0;
    *en_dusuk = 100;
    *en_yuksek = 0;
    for (int i = 0; i < n; i++) {
        toplam += notlar[i];
        *en_dusuk = notlar[i] < *en_dusuk ? notlar[i] : *en_dusuk;
        *en_yuksek = notlar[i] > *en_yuksek ? notlar[i] : *en_yuksek;
    }
    return toplam;
}

/* 3a) Yinelenen, YAVAŞ: tüm çiftler — n(n−1)/2 karşılaştırma (darboğaz) */
static long long yinelenen_ciftler(long long *kars)
{
    long long cift = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            (*kars)++;
            cift += numara[i] == numara[j];
        }
    }
    return cift;
}

/* Birleştirmeli sıralama (H6), a[lo..hi), artan */
static void birlestirmeli(int *a, int lo, int hi, long long *kars)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(a, lo, orta, kars);
    birlestirmeli(a, orta, hi, kars);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        (*kars)++;
        gecici[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i < orta) {
        gecici[k++] = a[i++];
    }
    while (j < hi) {
        gecici[k++] = a[j++];
    }
    memcpy(a + lo, gecici + lo, (size_t)(hi - lo) * sizeof *a);
}

/* 3b) Yinelenen, HIZLI: kopyayı sırala, eşit komşu gruplarını say */
static long long yinelenen_siralama(long long *kars)
{
    long long cift = 0;
    memcpy(kopya, numara, (size_t)n * sizeof *kopya);
    birlestirmeli(kopya, 0, n, kars);
    for (int i = 0, j; i < n; i = j) {
        for (j = i + 1; j < n && kopya[j] == kopya[i]; j++) {
            (*kars)++;
        }
        cift += (long long)(j - i) * (j - i - 1) / 2;   /* grup içi çift */
    }
    return cift;
}

/* 4) Harf dağılımı (örnek ölçek) — O(n) */
static const char *HARF[8] = {"AA", "BA", "BB", "CB", "CC", "DC", "DD",
                              "FF"};
static const int ALT[8] = {90, 85, 80, 70, 60, 55, 50, 0};

static void harf_dagilimi(int *say)
{
    for (int h = 0; h < 8; h++) {
        say[h] = 0;
    }
    for (int i = 0; i < n; i++) {
        int h = 0;
        while (notlar[i] < ALT[h]) {
            h++;
        }
        say[h]++;
    }
}

/* 5) İlk 3: en yüksek not, eşitlikte küçük numara — 3 doğrusal tarama */
static void ilk_uc(int *sec)
{
    for (int k = 0; k < 3; k++) {
        sec[k] = -1;
        for (int i = 0; i < n; i++) {
            int alindi = 0;
            for (int t = 0; t < k; t++) {
                alindi |= sec[t] == i;
            }
            if (!alindi && (sec[k] == -1 || notlar[i] > notlar[sec[k]] ||
                            (notlar[i] == notlar[sec[k]] &&
                             numara[i] < numara[sec[k]]))) {
                sec[k] = i;
            }
        }
    }
}

int main(int argc, char *argv[])
{
    int adet = 4000, yavas = 1, hizli = 1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--surum") == 0 && i + 1 < argc) {
            i++;
            yavas = strcmp(argv[i], "hizli") != 0;
            hizli = strcmp(argv[i], "yavas") != 0;
            if (strcmp(argv[i], "yavas") != 0 && strcmp(argv[i], "hizli") != 0
                && strcmp(argv[i], "ikisi") != 0) {
                fprintf(stderr, "--surum yavas|hizli|ikisi\n");
                return 2;
            }
        } else {
            char *son;
            long v = strtol(argv[i], &son, 10);
            if (*son != '\0' || v < 10 || v > 1000000) {
                fprintf(stderr, "Kullanım: %s [n] [--surum yavas|hizli|ikisi]"
                        " (10 <= n <= 10^6)\n", argv[0]);
                return 2;
            }
            adet = (int)v;
        }
    }
    if (ayir(adet) != 0) {
        birak();
        fprintf(stderr, "bellek yetmedi\n");
        return 1;
    }
    double t0 = islemci_sn(), t[6];
    int yin = kayitlari_uret();
    t[0] = islemci_sn();
    int dusuk, yuksek;
    long long toplam = istatistik(&dusuk, &yuksek);
    t[1] = islemci_sn();
    long long kars_y = 0, kars_h = 0, cift_y = -1, cift_h = -1;
    if (yavas) {
        cift_y = yinelenen_ciftler(&kars_y);
    }
    t[2] = islemci_sn();
    if (hizli) {
        cift_h = yinelenen_siralama(&kars_h);
    }
    t[3] = islemci_sn();
    int say[8];
    harf_dagilimi(say);
    t[4] = islemci_sn();
    int sec[3];
    ilk_uc(sec);
    t[5] = islemci_sn();

    printf("Kayıt işleme (n = %d, tohum 8)\n", n);
    printf("  1) üretim      : %d kayıt, %d kasıtlı yinelenen numara\n", n,
           yin);
    printf("  2) istatistik  : ortalama %.2f, en düşük %d, en yüksek %d\n",
           (double)toplam / n, dusuk, yuksek);
    if (yavas) {
        printf("  3) yinelenen   : %lld eşit çift (tüm çiftler, %lld "
               "karşılaştırma)\n", cift_y, kars_y);
    }
    if (hizli) {
        printf("  3) yinelenen   : %lld eşit çift (sırala + komşular, %lld "
               "karşılaştırma)\n", cift_h, kars_h);
    }
    if (yavas && hizli) {
        printf("     iki sürüm aynı mı: %s\n", cift_y == cift_h ? "evet"
                                                                : "HAYIR");
    }
    printf("  4) harf        :");
    for (int h = 0; h < 8; h++) {
        printf(" %s %d", HARF[h], say[h]);
    }
    printf("\n  5) ilk 3       :");
    for (int k = 0; k < 3; k++) {
        printf(" %d (%d)", numara[sec[k]], notlar[sec[k]]);
    }
    printf("\n");

    const char *ad[6] = {"üretim", "istatistik", "yinelenen (yavaş)",
                         "yinelenen (hızlı)", "harf", "ilk 3"};
    double onceki = t0, toplam_sn = t[5] - t0;
    fprintf(stderr, "Adım süreleri (işlemci, bu çalıştırmada; n = %d):\n", n);
    for (int k = 0; k < 6; k++) {
        fprintf(stderr, "  %-18s %10.3f ms  %%%5.1f\n", ad[k],
                (t[k] - onceki) * 1e3,
                toplam_sn > 0 ? 100.0 * (t[k] - onceki) / toplam_sn : 0.0);
        onceki = t[k];
    }
    if (yavas && hizli && t[3] > t[2]) {
        fprintf(stderr, "  yinelenen: yavaş / hızlı = %.1f kat\n",
                (t[2] - t[1]) / (t[3] - t[2]));
    }
    birak();
    return 0;
}

/* Kütüphane karşılığı: C — qsort ile sıralama; C++ — std::sort,
 * std::unordered_set (karma, H10); Python — sorted, set/collections.Counter.
 * Burada algoritmalar elle yazıldı; profil, darboğazın yerini gösterir. */

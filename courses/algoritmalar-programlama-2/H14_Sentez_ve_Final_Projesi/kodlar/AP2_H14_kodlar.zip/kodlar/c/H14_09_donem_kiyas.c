/* H14_09_donem_kiyas.c — AP-2 Hafta 14 · Örnek 9 (★★★)
 * Amaç    : Dönem kıyaslama programı: dönemin sekiz algoritmik çekirdeği
 *           sabit boyutlarda — ikili arama (H4), birleştirmeli sıralama
 *           (H6), öbek sıralaması (H7), karma tablosu (H10), BFS (H11),
 *           Dijkstra (H12), LCS (H13), 0/1 sırt çantası (H13). stdout'a
 *           YALNIZCA denetim toplamları; işlemci süreleri stderr'e ya da
 *           --csv ile CSV'ye. Girdiler ortak LCG'den (çekirdek başına tohum)
 * Kurallar: komşular artan köşe numarasıyla (eşitlikte ağırlık); öbekte
 *           (uzaklık, köşe) demetleri; karma: 32 bit Fibonacci çarpanı +
 *           doğrusal yoklama; denetim toplamlarının tanımı her çekirdekte
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_09_donem_kiyas.c ortak_rastgele.c zamanlayici.c \
 *           -o H14_09_donem_kiyas
 * Çalıştır: ./H14_09_donem_kiyas [--olcek K] [--tekrar T] [--csv dosya]
 * Eşleri  : cpp/H14_09_donem_kiyas.cpp · python/H14_09_donem_kiyas.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

static int n;                                   /* çekirdeğin boyutu */
static int *g1 = NULL, *g2 = NULL, *is = NULL, *yrd = NULL;  /* veriler */

static int ayir(size_t boyut)                   /* 0 başarı, -1 bellek */
{
    g1 = malloc(boyut * sizeof *g1);
    g2 = malloc(boyut * sizeof *g2);
    is = malloc(boyut * sizeof *is);
    yrd = malloc(boyut * sizeof *yrd);
    return g1 && g2 && is && yrd ? 0 : -1;
}

static void birak(void)                         /* sahiplik: bu modül */
{
    free(g1);
    free(g2);
    free(is);
    free(yrd);
    g1 = g2 = is = yrd = NULL;
}

/* --- 1) İkili arama (H4): a[i] = 3i + 1; kontrol = Σ (konum + 1) ----- */
static void arama_hazirla(void)
{
    rastgele_tohum(1);
    for (int i = 0; i < n; i++) {
        g1[i] = 3 * i + 1;
        g2[i] = rastgele_aralik(0, 3 * n);      /* sorgular: 1/3 bulunur */
    }
}

static long long arama_calistir(void)
{
    long long kontrol = 0;
    for (int q = 0; q < n; q++) {
        int lo = 0, hi = n - 1, x = g2[q], konum = -1;
        while (lo <= hi) {
            int orta = lo + (hi - lo) / 2;
            if (g1[orta] == x) {
                konum = orta;
                break;
            } else if (g1[orta] < x) {
                lo = orta + 1;
            } else {
                hi = orta - 1;
            }
        }
        kontrol += konum + 1;
    }
    return kontrol;
}

/* --- Sıralama girdisi; kontrol = Σ (i mod 1000 + 1)·a[i], sırasızsa -1 */
static void siralama_hazirla(void)
{
    rastgele_tohum(2);
    rastgele_dizi(g1, (size_t)n, 0, 1000000);
}

static long long siralama_kontrol(const int *a)
{
    long long k = 0;
    for (int i = 0; i < n; i++) {
        if (i > 0 && a[i - 1] > a[i]) {
            return -1;
        }
        k += (long long)(i % 1000 + 1) * a[i];
    }
    return k;
}

/* --- 2) Birleştirmeli sıralama (H6), a[lo..hi) ------------------------ */
static void birlestirmeli(int *a, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(a, lo, orta);
    birlestirmeli(a, orta, hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        yrd[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i < orta) {
        yrd[k++] = a[i++];
    }
    while (j < hi) {
        yrd[k++] = a[j++];
    }
    memcpy(a + lo, yrd + lo, (size_t)(hi - lo) * sizeof *a);
}

static long long birlestirmeli_calistir(void)
{
    memcpy(is, g1, (size_t)n * sizeof *is);
    birlestirmeli(is, 0, n);
    return siralama_kontrol(is);
}

/* --- 3) Öbek sıralaması (H7): en büyük öbek, aşağı süzme -------------- */
static void asagi_suz(int *a, int i, int boy)
{
    for (;;) {
        int b = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < boy && a[s] > a[b]) {
            b = s;
        }
        if (r < boy && a[r] > a[b]) {
            b = r;
        }
        if (b == i) {
            return;
        }
        int t = a[i];
        a[i] = a[b];
        a[b] = t;
        i = b;
    }
}

static long long obek_calistir(void)
{
    memcpy(is, g1, (size_t)n * sizeof *is);
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(is, i, n);
    }
    for (int son = n - 1; son > 0; son--) {
        int t = is[0];
        is[0] = is[son];
        is[son] = t;
        asagi_suz(is, 0, son);
    }
    return siralama_kontrol(is);
}

/* --- 4) Karma tablosu (H10): doğrusal yoklama, kapasite 2^k >= 2n ------
 * kontrol = farklı anahtar + bulunan sorgu + toplam yoklama */
static int karma_bit;

static void karma_hazirla(void)
{
    rastgele_tohum(4);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(0, n);          /* tekrarlı anahtarlar */
        g2[i] = rastgele_aralik(0, 2 * n);      /* sorgular */
    }
    karma_bit = 1;
    while ((1 << karma_bit) < 2 * n) {
        karma_bit++;
    }
}

static uint32_t karma(int anahtar)              /* Fibonacci karması */
{
    return (uint32_t)((uint32_t)anahtar * 2654435769u) >> (32 - karma_bit);
}

static long long karma_calistir(void)
{
    int kap = 1 << karma_bit;
    int *tablo = malloc((size_t)kap * sizeof *tablo);   /* -1 = boş */
    if (tablo == NULL) {
        return -1;
    }
    for (int i = 0; i < kap; i++) {
        tablo[i] = -1;
    }
    long long farkli = 0, bulunan = 0, yoklama = 0;
    for (int i = 0; i < n; i++) {               /* ekle (varsa geç) */
        uint32_t h = karma(g1[i]);
        yoklama++;
        while (tablo[h] != -1 && tablo[h] != g1[i]) {
            h = (h + 1) & (uint32_t)(kap - 1);
            yoklama++;
        }
        if (tablo[h] == -1) {
            tablo[h] = g1[i];
            farkli++;
        }
    }
    for (int q = 0; q < n; q++) {               /* ara */
        uint32_t h = karma(g2[q]);
        yoklama++;
        while (tablo[h] != -1 && tablo[h] != g2[q]) {
            h = (h + 1) & (uint32_t)(kap - 1);
            yoklama++;
        }
        bulunan += tablo[h] == g2[q];
    }
    free(tablo);
    return farkli + bulunan + yoklama;
}

/* --- Graf: V köşe, her köşeden 4 rastgele + (u+1) mod V kenarı (yönlü);
 * komşular (v, w) artan sırada; CSR: köşe u'nun kenarları 5u..5u+4 ---- */
#define DERECE 5

static void graf_hazirla(void)
{
    rastgele_tohum(5);
    for (int u = 0; u < n; u++) {
        int *v = g1 + DERECE * u, *w = g2 + DERECE * u;
        for (int k = 0; k < DERECE; k++) {
            v[k] = k == 0 ? (u + 1) % n : rastgele_aralik(0, n - 1);
            w[k] = rastgele_aralik(1, 100);
        }
        for (int k = 1; k < DERECE; k++) {      /* araya ekleme, (v, w) */
            int tv = v[k], tw = w[k], j = k - 1;
            while (j >= 0 && (v[j] > tv || (v[j] == tv && w[j] > tw))) {
                v[j + 1] = v[j];
                w[j + 1] = w[j];
                j--;
            }
            v[j + 1] = tv;
            w[j + 1] = tw;
        }
    }
}

/* --- 5) BFS (H11) 0'dan; kontrol = Σ (uzaklık + 1), ulaşılanlar ------- */
static long long bfs_calistir(void)
{
    int *uz = is, *kuyruk = yrd, bas = 0, son = 0;
    long long kontrol = 0;
    for (int v = 0; v < n; v++) {
        uz[v] = -1;
    }
    uz[0] = 0;
    kuyruk[son++] = 0;
    while (bas < son) {
        int u = kuyruk[bas++];
        kontrol += uz[u] + 1;
        for (int k = DERECE * u; k < DERECE * u + DERECE; k++) {
            if (uz[g1[k]] == -1) {
                uz[g1[k]] = uz[u] + 1;
                kuyruk[son++] = g1[k];
            }
        }
    }
    return kontrol;
}

/* --- 6) Dijkstra (H12), ikili öbek, tembel silme; (d, v) demetleri ---- */
typedef struct {
    long long d;
    int v;
} Oge;

static int oge_kucuk(Oge a, Oge b)
{
    return a.d < b.d || (a.d == b.d && a.v < b.v);
}

static long long dijkstra_calistir(void)
{
    Oge *obek = malloc(((size_t)DERECE * n + 1) * sizeof *obek);
    long long *uz = malloc((size_t)n * sizeof *uz);
    if (obek == NULL || uz == NULL) {
        free(obek);
        free(uz);
        return -1;
    }
    int boy = 0;
    for (int v = 0; v < n; v++) {
        uz[v] = -1;                              /* -1 = sonsuz */
    }
    uz[0] = 0;
    obek[boy++] = (Oge){0, 0};
    long long kontrol = 0;
    while (boy > 0) {
        Oge en = obek[0];                        /* en küçüğü çıkar */
        obek[0] = obek[--boy];
        for (int i = 0;;) {
            int b = i, s = 2 * i + 1, r = 2 * i + 2;
            if (s < boy && oge_kucuk(obek[s], obek[b])) {
                b = s;
            }
            if (r < boy && oge_kucuk(obek[r], obek[b])) {
                b = r;
            }
            if (b == i) {
                break;
            }
            Oge t = obek[i];
            obek[i] = obek[b];
            obek[b] = t;
            i = b;
        }
        if (en.d > uz[en.v]) {
            continue;                            /* eskimiş öğe */
        }
        kontrol += en.d;
        for (int k = DERECE * en.v; k < DERECE * en.v + DERECE; k++) {
            int v = g1[k];
            long long yeni = en.d + g2[k];
            if (uz[v] == -1 || yeni < uz[v]) {
                uz[v] = yeni;
                int i = boy++;                   /* ekle, yukarı süz */
                obek[i] = (Oge){yeni, v};
                while (i > 0 && oge_kucuk(obek[i], obek[(i - 1) / 2])) {
                    Oge t = obek[i];
                    obek[i] = obek[(i - 1) / 2];
                    obek[(i - 1) / 2] = t;
                    i = (i - 1) / 2;
                }
            }
        }
    }
    free(obek);
    free(uz);
    return kontrol;
}

/* --- 7) LCS (H13): iki satırlı tablo; kontrol = LCS uzunluğu --------- */
static void lcs_hazirla(void)
{
    rastgele_tohum(7);
    for (int i = 0; i < 2 * n; i++) {
        g1[i] = "ACGT"[rastgele_aralik(0, 3)];
    }
}

static long long lcs_calistir(void)
{
    int *onceki = is, *simdi = yrd;
    const int *a = g1, *b = g1 + n;
    for (int j = 0; j <= n; j++) {
        onceki[j] = 0;
    }
    for (int i = 1; i <= n; i++) {
        simdi[0] = 0;
        for (int j = 1; j <= n; j++) {
            if (a[i - 1] == b[j - 1]) {
                simdi[j] = onceki[j - 1] + 1;
            } else {
                simdi[j] = onceki[j] >= simdi[j - 1] ? onceki[j]
                                                       : simdi[j - 1];
            }
        }
        int *t = onceki;
        onceki = simdi;
        simdi = t;
    }
    return onceki[n];
}

/* --- 8) 0/1 sırt çantası (H13): tek satır, kapasite TERS sırada ------- */
#define SIRT_W 1000

static void sirt_hazirla(void)
{
    rastgele_tohum(8);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(1, 50);          /* ağırlık */
        g2[i] = rastgele_aralik(1, 100);         /* değer */
    }
}

static long long sirt_calistir(void)
{
    int *dp = is;
    for (int c = 0; c <= SIRT_W; c++) {
        dp[c] = 0;
    }
    for (int i = 0; i < n; i++) {
        for (int c = SIRT_W; c >= g1[i]; c--) {
            if (dp[c - g1[i]] + g2[i] > dp[c]) {
                dp[c] = dp[c - g1[i]] + g2[i];
            }
        }
    }
    return dp[SIRT_W];
}

typedef struct {
    const char *ad, *hafta, *aciklama;
    int boyut;                                   /* ölçek 1'deki n */
    void (*hazirla)(void);
    long long (*calistir)(void);
} Cekirdek;

static const Cekirdek CEKIRDEK[8] = {
    {"ikili_arama", "H4", "n sorgu, sıralı n dizide", 20000,
     arama_hazirla, arama_calistir},
    {"birlestirmeli", "H6", "n sayı", 20000, siralama_hazirla,
     birlestirmeli_calistir},
    {"obek_siralama", "H7", "n sayı", 20000, siralama_hazirla,
     obek_calistir},
    {"karma_tablosu", "H10", "n ekleme + n arama", 20000, karma_hazirla,
     karma_calistir},
    {"bfs", "H11", "V = n, E = 5n", 20000, graf_hazirla, bfs_calistir},
    {"dijkstra", "H12", "V = n, E = 5n, w 1..100", 20000, graf_hazirla,
     dijkstra_calistir},
    {"lcs", "H13", "n × n tablo", 600, lcs_hazirla, lcs_calistir},
    {"sirt_cantasi", "H13", "n nesne, W = 1000", 100, sirt_hazirla,
     sirt_calistir},
};

static int sayi_al(const char *s, int alt, int ust, int *deger)
{
    char *son;
    long v = strtol(s, &son, 10);
    if (*son != '\0' || v < alt || v > ust) {
        return 0;
    }
    *deger = (int)v;
    return 1;
}

int main(int argc, char *argv[])
{
    int olcek = 1, tekrar = 1;
    const char *csv = NULL;
    for (int i = 1; i < argc; i++) {
        int tamam = i + 1 < argc;
        if (tamam && strcmp(argv[i], "--olcek") == 0) {
            tamam = sayi_al(argv[++i], 1, 50, &olcek);
        } else if (tamam && strcmp(argv[i], "--tekrar") == 0) {
            tamam = sayi_al(argv[++i], 1, 101, &tekrar);
        } else if (tamam && strcmp(argv[i], "--csv") == 0) {
            csv = argv[++i];
        } else {
            tamam = 0;
        }
        if (!tamam) {
            fprintf(stderr, "Kullanım: %s [--olcek K] [--tekrar T] "
                    "[--csv dosya]\n", argv[0]);
            return 2;
        }
    }
    FILE *f = NULL;
    if (csv != NULL) {
        f = fopen(csv, "a");
        if (f == NULL) {
            fprintf(stderr, "%s açılamadı\n", csv);
            return 1;
        }
        if (ftell(f) == 0) {
            fprintf(f, "cekirdek;n;dil;tekrar;islemci_ms;kontrol\n");
        }
    }
    printf("Dönem kıyaslaması (ölçek %d): denetim toplamları\n", olcek);
    printf("  çekirdek        hafta         n              kontrol  "
           "boyut\n");
    for (int c = 0; c < 8; c++) {
        const Cekirdek *k = &CEKIRDEK[c];
        n = k->boyut * olcek;
        if (ayir((size_t)DERECE * n + SIRT_W + 2) != 0) {
            birak();
            fprintf(stderr, "bellek yetmedi\n");
            return 1;
        }
        k->hazirla();
        long long kontrol = k->calistir();       /* ısınma + sonuç */
        double sure[101];
        for (int t = 0; t < tekrar; t++) {
            double t0 = islemci_sn();
            long long k2 = k->calistir();
            sure[t] = islemci_sn() - t0;
            if (k2 != kontrol) {
                kontrol = -2;                    /* belirleyici değil! */
            }
        }
        double ort = ortanca(sure, tekrar);
        birak();
        printf("  %-14s  %-5s  %8d  %19lld  %s\n", k->ad, k->hafta, n,
               kontrol, k->aciklama);
        fprintf(stderr, "%-14s n = %8d: %10.3f ms (işlemci, ortanca, %d "
                "tekrar; bu çalıştırmada)\n", k->ad, n, ort * 1e3, tekrar);
        if (f != NULL) {
            fprintf(f, "%s;%d;C;%d;%.6f;%lld\n", k->ad, n, tekrar, ort * 1e3,
                    kontrol);
        }
    }
    if (f != NULL) {
        fclose(f);
    }
    return 0;
}

/* Kütüphane karşılığı: C — bsearch, qsort; C++ — std::binary_search,
 * std::stable_sort, std::make_heap/std::sort_heap, std::unordered_set,
 * std::priority_queue; Python — bisect, sorted, heapq, set/dict. */

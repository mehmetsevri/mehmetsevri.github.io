/* H14_01_strateji_esleme.c — AP-2 Hafta 14 · Örnek 1 (★★)
 * Amaç    : Problem–strateji eşleme: on kısa problem için çözüm
 *           iskeletleri tek programda. Her problemde seçilen strateji,
 *           karmaşıklık, gerekçe satırı ve küçük girdide sonuç yazdırılır.
 *           Yelpaze: kaba kuvvet, geri izleme, ikili arama, böl ve fethet,
 *           karma, graf dolaşma, açgözlü (iki problem), DP, sezgisel
 * Kurallar: eşitlikte küçük indeks; komşular artan numarayla; girdiler
 *           elle ya da ortak LCG'den (tohum yazılı)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_01_strateji_esleme.c ortak_rastgele.c -lm \
 *           -o H14_01_strateji_esleme
 * Çalıştır: ./H14_01_strateji_esleme
 * Eşleri  : cpp/H14_01_strateji_esleme.cpp · python/H14_01_strateji_esleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdio.h>
#include <string.h>

#include "ortak_rastgele.h"

typedef struct {
    const char *problem, *strateji, *karmasiklik, *hafta, *gerekce;
} Kart;

static const Kart KART[10] = {
    {"En yakın nokta çifti (8 nokta)", "kaba kuvvet", "O(n²)", "H2",
     "n küçük: 28 çiftin hepsi denenir; daha karmaşık yönteme gerek yok"},
    {"6 x 6 tahtada 6 vezir: kaç çözüm?", "geri izleme", "O(n!) budamalı",
     "H3", "kısıt ihlal eden kısmi yerleşim erken budanır"},
    {"Sıralı 15 notta 70 ve üstü kaç not?", "ikili arama", "O(log n)", "H4",
     "dizi sıralı: ilk >= 70 konumu (lower_bound) yeter"},
    {"Ters çevrim sayısı (8 sayı)", "böl ve fethet", "O(n log n)", "H6",
     "birleştirme adımı, sol yarıdan büyükleri toplu sayar"},
    {"Numaralarda yinelenen var mı?", "karma", "ortalama O(n)", "H10",
     "her numara bir kez eklenir; görülmüş mü sorusu O(1)"},
    {"Ağda 0'dan 6'ya en az aktarma", "graf dolaşma (BFS)", "O(V + E)",
     "H11", "kenarlar ağırlıksız: BFS katmanı = en az kenar"},
    {"En çok çakışmayan sınav (8 aralık)", "açgözlü", "O(n log n)", "H12",
     "en erken biteni seçmek güvenli (değiş tokuş kanıtı)"},
    {"{1, 3, 4} paralarla 6: en az para", "DP", "O(n·T)", "H13",
     "açgözlü 4+1+1 = 3 para verir; DP en iyiyi (3+3) bulur"},
    {"8 şehirde kısa tur (gezgin satıcı)", "sezgisel (en yakın komşu)",
     "O(n²)", "H14", "NP-zor; büyük n'de kesin yöntem yok: hızlı, iyi tur"},
    {"Ağırlıklı ağda 0'dan 5'e en kısa yol", "açgözlü (Dijkstra)", "O(V²)",
     "H12", "ağırlıklar negatif değil: en yakını kesinleştirmek güvenli"},
};

static void baslik(int p)
{
    printf("P%d  %s\n    strateji : %s · %s · %s\n    gerekçe  : %s\n",
           p + 1, KART[p].problem, KART[p].strateji, KART[p].karmasiklik,
           KART[p].hafta, KART[p].gerekce);
}

/* P1 — kaba kuvvet: tüm çiftler, en küçük kare uzaklık */
static void p1_en_yakin_cift(void)
{
    int x[8], y[8], bi = 0, bj = 1, cift = 0;
    long long en = -1;
    rastgele_tohum(11);
    for (int i = 0; i < 8; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    for (int i = 0; i < 8; i++) {
        for (int j = i + 1; j < 8; j++) {
            long long dx = x[i] - x[j], dy = y[i] - y[j];
            cift++;
            if (en == -1 || dx * dx + dy * dy < en) {
                en = dx * dx + dy * dy;
                bi = i;
                bj = j;
            }
        }
    }
    printf("    sonuç    : %d (%d, %d) ile %d (%d, %d); uzaklık %.2f; %d çift"
           "\n", bi, x[bi], y[bi], bj, x[bj], y[bj], sqrt((double)en), cift);
}

/* P2 — geri izleme: satır satır vezir koy; sütun ve çaprazlar dolu mu? */
static int sutun[6], capraz1[11], capraz2[11];
static long long dugum;

static int vezir(int r)
{
    dugum++;
    if (r == 6) {
        return 1;
    }
    int cozum = 0;
    for (int c = 0; c < 6; c++) {
        if (!sutun[c] && !capraz1[r + c] && !capraz2[r - c + 5]) {
            sutun[c] = capraz1[r + c] = capraz2[r - c + 5] = 1;   /* seç */
            cozum += vezir(r + 1);                                /* dene */
            sutun[c] = capraz1[r + c] = capraz2[r - c + 5] = 0;   /* geri */
        }
    }
    return cozum;
}

static void p2_vezir(void)
{
    int yaprak = 1;
    for (int i = 0; i < 6; i++) {
        yaprak *= 6;                             /* budamasız: 6^6 yaprak */
    }
    dugum = 0;
    int c = vezir(0);
    printf("    sonuç    : %d çözüm; %lld düğüm (budamasız ağaç 6^6 = %d "
           "yaprak)\n", c, dugum, yaprak);
}

/* P3 — ikili arama: ilk >= x konumu (yarı açık aralık) */
static void p3_alt_sinir(void)
{
    const int a[15] = {35, 41, 48, 52, 55, 60, 63, 67, 70, 70, 74, 81, 88,
                       90, 97};
    int lo = 0, hi = 15, yoklama = 0;
    while (lo < hi) {
        int orta = lo + (hi - lo) / 2;
        yoklama++;
        if (a[orta] < 70) {
            lo = orta + 1;
        } else {
            hi = orta;
        }
    }
    printf("    sonuç    : ilk >= 70 konumu %d; %d not; %d yoklama\n", lo,
           15 - lo, yoklama);
}

/* P4 — böl ve fethet: birleştirirken ters çevrim say */
static long long birlestir_say(int *a, int *g, int lo, int hi)
{
    if (hi - lo < 2) {
        return 0;
    }
    int orta = lo + (hi - lo) / 2;
    long long t = birlestir_say(a, g, lo, orta) + birlestir_say(a, g, orta,
                                                                hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        if (a[i] <= a[j]) {
            g[k++] = a[i++];
        } else {
            t += orta - i;              /* a[i..orta-1] hepsi a[j]'den büyük */
            g[k++] = a[j++];
        }
    }
    while (i < orta) {
        g[k++] = a[i++];
    }
    while (j < hi) {
        g[k++] = a[j++];
    }
    memcpy(a + lo, g + lo, (size_t)(hi - lo) * sizeof *a);
    return t;
}

static void p4_ters_cevrim(void)
{
    int a[8] = {8, 4, 2, 1, 7, 3, 6, 5}, g[8];
    long long t = birlestir_say(a, g, 0, 8);
    printf("    sonuç    : [8 4 2 1 7 3 6 5] -> %lld ters çevrim (en çok "
           "8·7/2 = 28)\n", t);
}

/* P5 — karma: doğrusal yoklamalı küme; ilk yineleneni bul */
static void p5_yinelenen(void)
{
    const int no[10] = {2201004, 2201017, 2201002, 2201033, 2201021,
                        2201008, 2201017, 2201040, 2201002, 2201011};
    int tablo[16], yoklama = 0, bulunan = -1;
    for (int i = 0; i < 16; i++) {
        tablo[i] = -1;
    }
    for (int i = 0; i < 10 && bulunan == -1; i++) {
        unsigned h = (unsigned)no[i] % 16u;    /* basit bölme karması */
        yoklama++;
        while (tablo[h] != -1 && tablo[h] != no[i]) {
            h = (h + 1) % 16u;
            yoklama++;
        }
        if (tablo[h] == no[i]) {
            bulunan = i;
        } else {
            tablo[h] = no[i];
        }
    }
    printf("    sonuç    : ilk yinelenen %d (konum %d); %d yoklama\n",
           no[bulunan], bulunan, yoklama);
}

/* P6 — BFS: ağırlıksız grafta en az kenar */
static void p6_bfs(void)
{
    const int kenar[9][2] = {{0, 1}, {0, 2}, {1, 3}, {2, 3}, {2, 4},
                             {3, 5}, {4, 5}, {5, 6}, {1, 4}};
    int kom[7][7] = {{0}}, uz[7], eb[7], kuyruk[7], bas = 0, son = 0;
    for (int e = 0; e < 9; e++) {
        kom[kenar[e][0]][kenar[e][1]] = kom[kenar[e][1]][kenar[e][0]] = 1;
    }
    for (int v = 0; v < 7; v++) {
        uz[v] = -1;
        eb[v] = -1;
    }
    uz[0] = 0;
    kuyruk[son++] = 0;
    while (bas < son) {
        int u = kuyruk[bas++];
        for (int v = 0; v < 7; v++) {          /* artan köşe numarası */
            if (kom[u][v] && uz[v] == -1) {
                uz[v] = uz[u] + 1;
                eb[v] = u;
                kuyruk[son++] = v;
            }
        }
    }
    int yol[7], k = 0;
    for (int v = 6; v != -1; v = eb[v]) {
        yol[k++] = v;
    }
    printf("    sonuç    : %d aktarma; yol", uz[6]);
    for (int i = k - 1; i >= 0; i--) {
        printf(" %d", yol[i]);
    }
    printf("\n");
}

/* P7 — açgözlü: (bitiş, başlangıç, no) sırasında en erken biteni seç */
static void p7_aralik(void)
{
    int bas_[8] = {1, 3, 0, 5, 3, 5, 6, 8}, bit[8] = {4, 5, 6, 7, 9, 9, 10,
                                                      11};
    int sira[8], secilen[8], k = 0, son_bitis = -1;
    for (int i = 0; i < 8; i++) {               /* araya ekleme (araç) */
        int j = i;
        while (j > 0 && (bit[sira[j - 1]] > bit[i] ||
                         (bit[sira[j - 1]] == bit[i] &&
                          bas_[sira[j - 1]] > bas_[i]))) {
            sira[j] = sira[j - 1];
            j--;
        }
        sira[j] = i;
    }
    for (int t = 0; t < 8; t++) {
        int i = sira[t];
        if (bas_[i] >= son_bitis) {
            secilen[k++] = i;
            son_bitis = bit[i];
        }
    }
    printf("    sonuç    : %d sınav:", k);
    for (int t = 0; t < k; t++) {
        printf(" s%d[%d, %d)", secilen[t], bas_[secilen[t]], bit[secilen[t]]);
    }
    printf("\n");
}

/* P8 — DP: en az para; karşılaştırma için açgözlü */
static void p8_bozuk_para(void)
{
    const int para[3] = {1, 3, 4};
    int enaz[7], son[7];
    enaz[0] = 0;
    for (int t = 1; t <= 6; t++) {
        enaz[t] = 1000;
        son[t] = -1;
        for (int c = 0; c < 3; c++) {
            if (para[c] <= t && enaz[t - para[c]] + 1 < enaz[t]) {
                enaz[t] = enaz[t - para[c]] + 1;
                son[t] = para[c];
            }
        }
    }
    int acgozlu = 0, kalan = 6;
    for (int c = 2; c >= 0; c--) {
        while (para[c] <= kalan) {
            kalan -= para[c];
            acgozlu++;
        }
    }
    printf("    sonuç    : DP %d para (", enaz[6]);
    for (int t = 6; t > 0; t -= son[t]) {
        printf(t == 6 ? "%d" : " + %d", son[t]);
    }
    printf("); açgözlü %d para\n", acgozlu);
}

/* P9 — sezgisel: en yakın komşu; küçük n'de kaba kuvvetle denetim */
static double d[8][8];
static int kullanildi[8], yol[8];
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == 8) {
        double t = kismi + d[yol[7]][0];
        if (t < en_iyi - 1e-9) {
            en_iyi = t;
        }
        return;
    }
    for (int s = 1; s < 8; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

static void p9_sezgisel(void)
{
    int x[8], y[8], ziyaret[8] = {0}, tur[8];
    rastgele_tohum(42);
    for (int i = 0; i < 8; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            double dx = x[i] - x[j], dy = y[i] - y[j];
            d[i][j] = sqrt(dx * dx + dy * dy);
        }
    }
    tur[0] = 0;
    ziyaret[0] = 1;
    for (int k = 1; k < 8; k++) {
        int sec = -1;
        for (int s = 0; s < 8; s++) {
            if (!ziyaret[s] && (sec == -1 || d[tur[k - 1]][s] <
                                                 d[tur[k - 1]][sec])) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
    double u = 0.0;
    for (int k = 1; k < 8; k++) {
        u += d[tur[k - 1]][tur[k]];
    }
    u += d[tur[7]][0];
    yol[0] = 0;
    kullanildi[0] = 1;
    en_iyi = 1e300;
    dene(1, 0.0);
    printf("    sonuç    : NN turu %.2f; en iyi (kaba kuvvet, 5040 tur) "
           "%.2f; oran %.4f\n", u, en_iyi, u / en_iyi);
}

/* P10 — Dijkstra, dizi sürümü (H12 Örnek 7), O(V²) */
static void p10_dijkstra(void)
{
    const int kenar[9][3] = {{0, 1, 7}, {0, 2, 9}, {0, 5, 14}, {1, 2, 10},
                             {1, 3, 15}, {2, 3, 11}, {2, 5, 2}, {3, 4, 6},
                             {4, 5, 9}};
    int w[6][6], uz[6], eb[6], bitti[6] = {0};
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            w[i][j] = -1;
        }
        uz[i] = -1;
        eb[i] = -1;
    }
    for (int e = 0; e < 9; e++) {
        w[kenar[e][0]][kenar[e][1]] = w[kenar[e][1]][kenar[e][0]] =
            kenar[e][2];
    }
    uz[0] = 0;
    for (int adim = 0; adim < 6; adim++) {
        int u = -1;
        for (int v = 0; v < 6; v++) {           /* eşitlikte küçük köşe */
            if (!bitti[v] && uz[v] != -1 && (u == -1 || uz[v] < uz[u])) {
                u = v;
            }
        }
        if (u == -1) {
            break;
        }
        bitti[u] = 1;
        for (int v = 0; v < 6; v++) {
            if (w[u][v] != -1 && (uz[v] == -1 || uz[u] + w[u][v] < uz[v])) {
                uz[v] = uz[u] + w[u][v];
                eb[v] = u;
            }
        }
    }
    int yol5[6], k = 0;
    for (int v = 5; v != -1; v = eb[v]) {
        yol5[k++] = v;
    }
    printf("    sonuç    : uzaklık %d; yol", uz[5]);
    for (int i = k - 1; i >= 0; i--) {
        printf(" %d", yol5[i]);
    }
    printf(" (doğrudan 0-5 kenarı %d)\n", w[0][5]);
}

int main(void)
{
    void (*cozucu[10])(void) = {p1_en_yakin_cift, p2_vezir, p3_alt_sinir,
                                p4_ters_cevrim, p5_yinelenen, p6_bfs,
                                p7_aralik, p8_bozuk_para, p9_sezgisel,
                                p10_dijkstra};
    printf("Problem–strateji eşleme: on problem, on iskelet\n\n");
    for (int p = 0; p < 10; p++) {
        baslik(p);
        cozucu[p]();
    }
    printf("\nÖzet tablo (problem · strateji · karmaşıklık · hafta)\n");
    for (int p = 0; p < 10; p++) {
        printf("  P%-2d %s · %s · %s · %s\n", p + 1, KART[p].problem,
               KART[p].strateji, KART[p].karmasiklik, KART[p].hafta);
    }
    return 0;
}

/* Kütüphane karşılığı: her iskeletin kütüphane karşılığı ilgili haftanın
 * örneğinde verildi (ör. bsearch/std::lower_bound/bisect_left, qsort/
 * std::sort/sorted, std::unordered_set/set, std::priority_queue/heapq). */

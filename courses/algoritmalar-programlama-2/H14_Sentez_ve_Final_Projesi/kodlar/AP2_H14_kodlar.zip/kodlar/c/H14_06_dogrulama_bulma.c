/* H14_06_dogrulama_bulma.c — AP-2 Hafta 14 · Örnek 6 (★)
 * Amaç    : NP sezgisi: alt küme toplamında verilen bir çözümü (sertifika:
 *           seçilen indisler) DOĞRULAMAK O(n) adımdır; çözümü BULMAK için
 *           bilinen yollar H3'ün geri izlemesi (en kötü 2^(n+1) − 1 düğüm) ve
 *           H13'ün sözde polinom DP'sidir ((n+1)·(T+1) hücre). "Evet"
 *           örneğinde sertifika vardır; "hayır" örneğinde gösterilecek
 *           sertifika yoktur (doğrulama yalnız "evet" yanıtları içindir)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_06_dogrulama_bulma.c ortak_rastgele.c \
 *           -o H14_06_dogrulama_bulma
 * Çalıştır: ./H14_06_dogrulama_bulma
 * Eşleri  : cpp/H14_06_dogrulama_bulma.cpp ·
 *           python/H14_06_dogrulama_bulma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define MAKS_N 40

static int a[MAKS_N];
static int n;

/* Doğrulayıcı: sertifika sec[0..k-1] (indisler) geçerli mi, tekrarsız mı,
 * toplamı hedef mi? Her öğe için bir adım + son karşılaştırma: O(n + k) */
static int dogrula(long long hedef, const int *sec, int k, long long *adim,
                   const char **neden)
{
    int goruldu[MAKS_N] = {0};
    long long toplam = 0;
    *adim = 0;
    if (k > n) {
        *neden = "öğe sayısı n'den fazla";
        return 0;
    }
    for (int t = 0; t < k; t++) {
        (*adim)++;
        if (sec[t] < 0 || sec[t] >= n) {
            *neden = "indis dizi dışında";
            return 0;
        }
        if (goruldu[sec[t]]) {
            *neden = "aynı indis iki kez";
            return 0;
        }
        goruldu[sec[t]] = 1;
        toplam += a[sec[t]];
    }
    (*adim)++;
    if (toplam != hedef) {
        *neden = "toplam hedefe eşit değil";
        return 0;
    }
    *neden = "toplam = hedef";
    return 1;
}

/* --- Bulma 1: H3'ün budamalı geri izlemesi, ilk çözümde dur ---------- */
static long long dugum;
static int yol[MAKS_N], yol_k;
static int bulunan[MAKS_N], bulunan_k;

static int geri_izle(int i, long long toplam, long long hedef)
{
    dugum++;
    if (toplam > hedef) {
        return 0;                          /* a_i > 0: torunlar da aşar */
    }
    if (i == n) {
        if (toplam == hedef) {
            for (int t = 0; t < yol_k; t++) {
                bulunan[t] = yol[t];
            }
            bulunan_k = yol_k;
            return 1;
        }
        return 0;
    }
    if (geri_izle(i + 1, toplam, hedef)) {           /* önce almadan */
        return 1;
    }
    yol[yol_k++] = i;                                /* sonra alarak */
    int bulundu = geri_izle(i + 1, toplam + a[i], hedef);
    yol_k--;
    return bulundu;
}

/* --- Bulma 2: H13'ün DP'si (bool tablo) + geri çıkarma -------------- */
static long long hucre;

/* Dönen: 1 çözüm var (sec, k doldurulur), 0 yok, -1 bellek yok */
static int dp_bul(long long hedef, int *sec, int *k)
{
    int T = (int)hedef, s = T + 1;
    unsigned char *v = calloc((size_t)(n + 1) * (size_t)s, 1);
    if (v == NULL) {
        return -1;
    }
    v[0] = 1;
    hucre = s;
    for (int i = 1; i <= n; i++) {
        for (int t = 0; t <= T; t++) {
            v[i * s + t] = v[(i - 1) * s + t] ||
                           (a[i - 1] <= t && v[(i - 1) * s + t - a[i - 1]]);
            hucre++;
        }
    }
    int var = v[n * s + T];
    *k = 0;
    if (var) {
        int t = T;
        for (int i = n; i >= 1; i--) {              /* eşitlikte almadan */
            if (!v[(i - 1) * s + t]) {
                sec[(*k)++] = i - 1;
                t -= a[i - 1];
            }
        }
        for (int p = 0, q = *k - 1; p < q; p++, q--) {   /* artan sıra */
            int gecici = sec[p];
            sec[p] = sec[q];
            sec[q] = gecici;
        }
    }
    free(v);
    return var;
}

static void kume_yaz(const int *sec, int k)
{
    printf("{");
    for (int t = 0; t < k; t++) {
        printf(t ? ", %d" : "%d", sec[t]);
    }
    printf("}");
}

int main(void)
{
    const int kucuk[6] = {13, 7, 21, 4, 18, 9};
    n = 6;
    for (int i = 0; i < n; i++) {
        a[i] = kucuk[i];
    }
    long long hedef = 38, adim;
    const char *neden;
    printf("1) a = {13, 7, 21, 4, 18, 9} (indis 0..5), hedef = 38\n");
    printf("   Doğrulama (sertifika = seçilen indisler):\n");
    const int s1[3] = {0, 1, 4}, s2[3] = {0, 1, 3}, s3[3] = {0, 0, 4},
              s4[2] = {2, 9};
    const int *sertifika[4] = {s1, s2, s3, s4};
    const int boy[4] = {3, 3, 3, 2};
    for (int c = 0; c < 4; c++) {
        int sonuc = dogrula(hedef, sertifika[c], boy[c], &adim, &neden);
        printf("   ");
        kume_yaz(sertifika[c], boy[c]);
        printf("%*s -> %-5s (%s); adım = %lld\n", 10 - 3 * boy[c], "",
               sonuc ? "KABUL" : "RED", neden, adim);
    }
    int sec[MAKS_N], k;
    dugum = 0;
    yol_k = 0;
    bulunan_k = 0;
    int bulundu = geri_izle(0, 0, hedef);
    printf("   Bulma, geri izleme (H3; önce almadan): %s ",
           bulundu ? "çözüm" : "yok");
    kume_yaz(bulunan, bulunan_k);
    printf("; düğüm = %lld (2^(n+1) - 1 = %d)\n", dugum, (1 << (n + 1)) - 1);
    if (dp_bul(hedef, sec, &k) < 0) {
        return 1;
    }
    printf("   Bulma, DP (H13): çözüm ");
    kume_yaz(sec, k);
    printf("; hücre = %lld = (n+1)(T+1)\n", hucre);
    printf("   DP'nin çözümü doğrulayıcıdan: %s\n",
           dogrula(hedef, sec, k, &adim, &neden) ? "KABUL" : "RED");

    printf("\n2) \"Evet\" örnekleri: a = LCG(1..1000), hedef = rastgele bir "
           "alt kümenin toplamı\n");
    printf("   n   hedef  doğrulama  geri izleme düğümü  DP hücresi"
           "    2^(n+1)-1\n");
    rastgele_tohum(14);
    for (int adet = 10; adet <= 30; adet += 4) {
        n = adet;
        rastgele_dizi(a, (size_t)n, 1, 1000);
        hedef = 0;
        for (int i = 0; i < n; i++) {
            if (rastgele_aralik(0, 1)) {
                hedef += a[i];
            }
        }
        dugum = 0;
        yol_k = 0;
        geri_izle(0, 0, hedef);
        if (dp_bul(hedef, sec, &k) < 0) {
            return 1;
        }
        int gecerli = dogrula(hedef, sec, k, &adim, &neden);
        printf("  %2d  %6lld  %4lld adım  %18lld  %10lld  %11lld%s\n", n,
               hedef, adim, dugum, hucre, (1LL << (n + 1)) - 1,
               gecerli ? "" : "  DOĞRULANAMADI");
    }

    printf("\n3) \"Hayır\" örnekleri: bütün sayılar çift, hedef tek "
           "(çözüm yok; sertifika da yok)\n");
    printf("   n   hedef  geri izleme düğümü  DP hücresi    2^(n+1)-1\n");
    for (int adet = 10; adet <= 18; adet += 4) {
        n = adet;
        long long toplam = 0;
        for (int i = 0; i < n; i++) {
            a[i] = 2 * rastgele_aralik(1, 500);
            toplam += a[i];
        }
        hedef = toplam / 2 + (toplam / 2 % 2 == 0);   /* tek sayı */
        dugum = 0;
        yol_k = 0;
        int var = geri_izle(0, 0, hedef);
        int dp_var = dp_bul(hedef, sec, &k);
        if (dp_var < 0) {
            return 1;
        }
        printf("  %2d  %6lld  %18lld  %10lld  %11lld  %s\n", n, hedef, dugum,
               hucre, (1LL << (n + 1)) - 1,
               var || dp_var ? "ÇÖZÜM VAR?" : "çözüm yok");
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Doğrulayıcı, H3'ün bit
 * maskesi kaba kuvvetinin "bu alt küme doğru mu?" adımıdır. */

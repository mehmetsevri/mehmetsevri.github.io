/* H14_05_held_karp.c — AP-2 Hafta 14 · Örnek 5 (★★★, merak)
 * Amaç    : Held–Karp: gezgin satıcı için bit maskesi DP'si. Üstel ama
 *           kaba kuvvetten çok hızlı: Θ(n²·2ⁿ) geçiş, n·2ⁿ tablo.
 *           n <= 10'da kaba kuvvetle (Örnek 2) aynı sonuç; tablo kesiti;
 *           bellek hesabı. İsteğe bağlı: --n N (4 <= N <= 16) tek ölçüm
 * DP      : durum dp[S][j] = 0'dan başlayıp S kümesindeki şehirleri birer
 *           kez gezerek j'de biten en kısa yol (0, j ∈ S) · geçiş dp[S][j]
 *           = min_i dp[S − {j}][i] + d(i, j) · temel dp[{0}][0] = 0 ·
 *           sıra S artan (alt küme her zaman daha küçük sayı) · cevap
 *           min_j dp[tümü][j] + d(j, 0) · geri çıkarma ebeveyn[S][j]
 *           (eşitlikte küçük i: katı "<")
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_05_held_karp.c ortak_rastgele.c zamanlayici.c -lm \
 *           -o H14_05_held_karp
 * Çalıştır: ./H14_05_held_karp        ./H14_05_held_karp --n 16
 * Eşleri  : cpp/H14_05_held_karp.cpp · python/H14_05_held_karp.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define MAKS_N 16
#define KB_MAKS 10
#define EPS 1e-9
#define SONSUZ 1e300

static int n;
static int x[MAKS_N], y[MAKS_N];
static double d[MAKS_N][MAKS_N];

static double *dp = NULL;          /* (1 << n) * n */
static signed char *ebeveyn = NULL;
static long long durum, gecis;     /* hesaplanan dp[S][j]; geçiş */

static void uzakliklari_hesapla(void)
{
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            double dx = x[i] - x[j], dy = y[i] - y[j];
            d[i][j] = sqrt(dx * dx + dy * dy);
        }
    }
}

static void tur_yaz(const int *tur)
{
    for (int k = 0; k < n; k++) {
        printf("%d-", tur[k]);
    }
    printf("0");
}

static void hk_birak(void)
{
    free(dp);
    free(ebeveyn);
    dp = NULL;
    ebeveyn = NULL;
}

/* Sahiplik: dp ve ebeveyn bu modülündür; hk_birak ile bırakılır.
 * Dönen: 0 başarı (sonuç *uzunluk, tur[]), -1 bellek yok */
static int held_karp(double *uzunluk, int *tur)
{
    size_t boyut = ((size_t)1 << n) * (size_t)n;
    dp = malloc(boyut * sizeof *dp);
    ebeveyn = malloc(boyut);
    if (dp == NULL || ebeveyn == NULL) {
        hk_birak();
        return -1;
    }
    for (size_t k = 0; k < boyut; k++) {
        dp[k] = SONSUZ;
        ebeveyn[k] = -1;
    }
    dp[1 * n + 0] = 0.0;                         /* S = {0}, j = 0 */
    durum = 0;
    gecis = 0;
    for (int S = 1; S < (1 << n); S += 2) {      /* 0'ı içeren kümeler */
        for (int j = 1; j < n; j++) {
            if (!(S & (1 << j))) {
                continue;
            }
            int onceki = S ^ (1 << j);
            double en = SONSUZ;
            int arg = -1;
            for (int i = 0; i < n; i++) {
                if (!(onceki & (1 << i)) || dp[onceki * n + i] >= SONSUZ) {
                    continue;
                }
                double aday = dp[onceki * n + i] + d[i][j];
                gecis++;
                if (aday < en) {
                    en = aday;
                    arg = i;
                }
            }
            dp[S * n + j] = en;
            ebeveyn[S * n + j] = (signed char)arg;
            durum++;
        }
    }
    int tum = (1 << n) - 1, son = -1;
    double en = SONSUZ;
    for (int j = 1; j < n; j++) {
        double aday = dp[tum * n + j] + d[j][0];
        if (aday < en) {
            en = aday;
            son = j;
        }
    }
    int S = tum;
    for (int k = n - 1; k >= 1; k--) {           /* geri çıkarma */
        tur[k] = son;
        int i = ebeveyn[S * n + son];
        S ^= 1 << son;
        son = i;
    }
    tur[0] = son;                                /* 0 olmalı */
    *uzunluk = en;
    return 0;
}

/* --- Kaba kuvvet (Örnek 2) ----------------------------------------- */
static int yol[KB_MAKS], kullanildi[KB_MAKS], kb_tur[KB_MAKS];
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == n) {
        double toplam = kismi + d[yol[n - 1]][0];
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
            memcpy(kb_tur, yol, sizeof yol);
        }
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

static double kaba_kuvvet(void)
{
    memset(kullanildi, 0, sizeof kullanildi);
    yol[0] = 0;
    kullanildi[0] = 1;
    en_iyi = SONSUZ;
    dene(1, 0.0);
    return en_iyi;
}

static void sehirleri_kur(int adet, uint64_t tohum)
{
    n = adet;
    rastgele_tohum(tohum);
    for (int i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    uzakliklari_hesapla();
}

static void kume_yaz(int S)
{
    char metin[64] = "{";
    for (int i = 0; i < n; i++) {
        if (S & (1 << i)) {
            char p[16];
            snprintf(p, sizeof p, "%s%d", metin[1] ? "," : "", i);
            strcat(metin, p);
        }
    }
    strcat(metin, "}");
    printf("  %-11s", metin);
}

static int tek_olcum(int adet)
{
    int tur[MAKS_N];
    double u;
    sehirleri_kur(adet, 42);
    double t0 = islemci_sn();
    if (held_karp(&u, tur) != 0) {
        fprintf(stderr, "bellek yetmedi\n");
        return 1;
    }
    double sure = islemci_sn() - t0;
    printf("n = %d: uzunluk %.2f, durum %lld, geçiş %lld; tur ", n, u,
           durum, gecis);
    tur_yaz(tur);
    printf("\n");
    fprintf(stderr, "Held-Karp n = %d: %.3f ms (işlemci, bu çalıştırmada)\n",
            n, sure * 1e3);
    hk_birak();
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc == 3 && strcmp(argv[1], "--n") == 0) {
        char *son;
        long v = strtol(argv[2], &son, 10);
        if (*son != '\0' || v < 4 || v > MAKS_N) {
            fprintf(stderr, "Kullanım: %s [--n N]  (4 <= N <= 16)\n",
                    argv[0]);
            return 2;
        }
        return tek_olcum((int)v);
    } else if (argc != 1) {
        fprintf(stderr, "Kullanım: %s [--n N]  (4 <= N <= 16)\n", argv[0]);
        return 2;
    }

    const int kx[5] = {0, 6, 1, 5, 3}, ky[5] = {0, 1, 4, 5, 2};
    int tur[MAKS_N];
    double u;
    n = 5;
    for (int i = 0; i < n; i++) {
        x[i] = kx[i];
        y[i] = ky[i];
    }
    uzakliklari_hesapla();
    if (held_karp(&u, tur) != 0) {
        return 1;
    }
    printf("1) Örnek 2'nin küçük örneği (n = 5): dp[S][j] tablosu "
           "(- = tanımsız)\n");
    printf("  S               j=1     j=2     j=3     j=4    ebeveyn "
           "(j=1..4)\n");
    for (int S = 1; S < (1 << n); S += 2) {
        kume_yaz(S);
        for (int j = 1; j < n; j++) {
            if (dp[S * n + j] >= SONSUZ) {
                printf("  %6s", "-");
            } else {
                printf("  %6.2f", dp[S * n + j]);
            }
        }
        printf("   ");
        for (int j = 1; j < n; j++) {
            printf(" %2d", ebeveyn[S * n + j]);
        }
        printf("\n");
    }
    printf("  cevap = min_j dp[{0..4}][j] + d(j, 0) = %.2f; tur ", u);
    tur_yaz(tur);
    printf("\n  durum = %lld = (n-1)·2^(n-2); geçiş = %lld\n", durum, gecis);
    hk_birak();

    printf("\n2) LCG şehirleri (tohum 42; Örnek 2 ile aynı örnekler)\n");
    printf("   n   durum    geçiş     n²·2ⁿ  Held-Karp  kaba kuvvet  "
           "sonuç\n");
    for (int adet = 4; adet <= 16; adet++) {
        sehirleri_kur(adet, 42);
        double t0 = islemci_sn();
        if (held_karp(&u, tur) != 0) {
            return 1;
        }
        double sure = islemci_sn() - t0;
        printf("  %2d  %6lld  %7lld  %8ld  %9.2f", n, durum, gecis,
               (long)n * n * (1L << n), u);
        if (n <= KB_MAKS) {
            double kb = kaba_kuvvet();
            printf("  %11.2f  %s\n", kb, fabs(kb - u) < 1e-6 ? "aynı"
                                                               : "FARKLI");
        } else {
            printf("  %11s  -\n", "-");
        }
        fprintf(stderr, "n = %2d: Held-Karp %.3f ms (işlemci, bu "
                "çalıştırmada)\n", adet, sure * 1e3);
        hk_birak();
    }
    printf("   n = 16 turu: ");
    sehirleri_kur(16, 42);
    if (held_karp(&u, tur) != 0) {
        return 1;
    }
    tur_yaz(tur);
    printf("\n");
    hk_birak();

    printf("\n3) Bellek: n·2ⁿ tablo hücresi × (8 bayt dp + 1 bayt "
           "ebeveyn)\n");
    printf("   n  tablo hücresi n·2ⁿ      bellek\n");
    const int nler[8] = {10, 12, 14, 16, 18, 20, 25, 30};
    for (int k = 0; k < 8; k++) {
        double h = (double)nler[k] * pow(2.0, nler[k]);
        double mib = h * 9.0 / 1048576.0;
        printf("  %2d  %18.0f  %10.1f MiB\n", nler[k], h, mib);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: Örnek 2'nin kaba
 * kuvveti (n <= 10). Uygulamada kesin çözücüler (ör. Concorde) dal-kesme
 * yöntemleri kullanır; Held–Karp ders kitabı ölçeğinde bir DP'dir. */

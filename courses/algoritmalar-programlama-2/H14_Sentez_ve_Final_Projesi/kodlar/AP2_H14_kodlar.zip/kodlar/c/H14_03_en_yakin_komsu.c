/* H14_03_en_yakin_komsu.c — AP-2 Hafta 14 · Örnek 3 (★★)
 * Amaç    : Gezgin satıcı için en yakın komşu sezgiseli: her adımda
 *           ziyaret edilmemiş en yakın şehre git (eşitlikte KÜÇÜK indeks;
 *           karşılaştırma tamsayı kare uzaklıkla). Kaba kuvvetle
 *           karşılaştırma: LCG ile 100 örnekte yaklaşım oranı (en kötü,
 *           ortalama, ortanca); aday incelemesi n(n−1)/2 → Θ(n²)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_03_en_yakin_komsu.c ortak_rastgele.c -lm \
 *           -o H14_03_en_yakin_komsu
 * Çalıştır: ./H14_03_en_yakin_komsu
 * Eşleri  : cpp/H14_03_en_yakin_komsu.cpp · python/H14_03_en_yakin_komsu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define MAKS_N 200
#define KB_MAKS 10                 /* kaba kuvvetin sınırı */
#define EPS 1e-9
#define ORNEK 100

static int n;
static int x[MAKS_N], y[MAKS_N];
static double d[MAKS_N][MAKS_N];
static long long aday_sayisi;      /* en yakın komşunun incelediği aday */

static long long d2(int i, int j)  /* kare uzaklık: tam, eşitlik güvenli */
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static void uzakliklari_hesapla(void)
{
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            d[i][j] = sqrt((double)d2(i, j));
        }
    }
}

static double tur_uzunlugu(const int *tur)
{
    double t = 0.0;
    for (int k = 1; k < n; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t + d[tur[n - 1]][tur[0]];            /* dönüş kenarı */
}

static void tur_yaz(const int *tur)
{
    for (int k = 0; k < n; k++) {
        printf("%d-", tur[k]);
    }
    printf("%d", tur[0]);
}

/* En yakın komşu: bas'tan başla; ayrinti = 1 ise her adımı yaz */
static void en_yakin_komsu(int bas, int *tur, int ayrinti)
{
    int ziyaret[MAKS_N] = {0};
    tur[0] = bas;
    ziyaret[bas] = 1;
    for (int k = 1; k < n; k++) {
        int son = tur[k - 1], sec = -1;
        long long en_az = 0;
        if (ayrinti) {
            printf("    %d     %d    ", k, son);
        }
        for (int s = 0; s < n; s++) {
            if (!ziyaret[s]) {
                long long dd = d2(son, s);
                aday_sayisi++;
                if (ayrinti) {
                    printf(" %d:%lld", s, dd);
                }
                if (sec == -1 || dd < en_az) {   /* eşitlikte ilk (küçük) */
                    sec = s;
                    en_az = dd;
                }
            }
        }
        if (ayrinti) {
            printf("  -> %d\n", sec);
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
}

/* --- Kaba kuvvet (Örnek 2) ----------------------------------------- */
static int yol[KB_MAKS], kullanildi[KB_MAKS], en_iyi_tur[KB_MAKS];
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == n) {
        double toplam = kismi + d[yol[n - 1]][0];
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
            for (int i = 0; i < n; i++) {
                en_iyi_tur[i] = yol[i];
            }
        }
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

static double kaba_kuvvet(void)
{
    for (int i = 0; i < n; i++) {
        kullanildi[i] = 0;
    }
    yol[0] = 0;
    kullanildi[0] = 1;
    en_iyi = 1e300;
    dene(1, 0.0);
    return en_iyi;
}

static void rastgele_sehirler(int adet)
{
    n = adet;
    for (int i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    uzakliklari_hesapla();
}

static int kesir_karsilastir(const void *p, const void *q)
{
    double a = *(const double *)p, b = *(const double *)q;
    return (a > b) - (a < b);
}

int main(void)
{
    const int kx[5] = {0, 6, 1, 5, 3}, ky[5] = {0, 1, 4, 5, 2};
    int tur[MAKS_N];
    n = 5;
    for (int i = 0; i < n; i++) {
        x[i] = kx[i];
        y[i] = ky[i];
    }
    uzakliklari_hesapla();
    printf("1) Örnek 2'nin küçük örneği (n = 5), şehir 0'dan; aday s:d²\n");
    printf("  adım  son   adaylar              seçilen\n");
    aday_sayisi = 0;
    en_yakin_komsu(0, tur, 1);
    double nn = tur_uzunlugu(tur), kb = kaba_kuvvet();
    printf("   NN turu: ");
    tur_yaz(tur);
    printf("  uzunluk %.2f\n   en iyi : ", nn);
    tur_yaz(en_iyi_tur);
    printf("  uzunluk %.2f\n   oran = %.4f; aday incelemesi = %lld = "
           "n(n-1)/2\n", kb, nn / kb, aday_sayisi);

    printf("\n2) LCG (tohum 2026), n = 8, %d örnek; oran = NN / en iyi\n",
           ORNEK);
    static double oran[2][ORNEK];
    int esit[2] = {0, 0}, en_kotu_no = 0;
    double toplam[2] = {0.0, 0.0};
    int kx8[ORNEK][8], ky8[ORNEK][8];
    rastgele_tohum(2026);
    for (int t = 0; t < ORNEK; t++) {
        rastgele_sehirler(8);
        for (int i = 0; i < n; i++) {
            kx8[t][i] = x[i];
            ky8[t][i] = y[i];
        }
        double opt = kaba_kuvvet();
        en_yakin_komsu(0, tur, 0);
        oran[0][t] = tur_uzunlugu(tur) / opt;
        double en_iyi_bas = 1e300;              /* her başlangıçtan NN */
        for (int b = 0; b < n; b++) {
            en_yakin_komsu(b, tur, 0);
            double u = tur_uzunlugu(tur);
            if (u < en_iyi_bas - EPS) {
                en_iyi_bas = u;
            }
        }
        oran[1][t] = en_iyi_bas / opt;
        for (int v = 0; v < 2; v++) {
            toplam[v] += oran[v][t];
            esit[v] += oran[v][t] < 1.0 + 1e-9;
        }
        if (oran[0][t] > oran[0][en_kotu_no]) {
            en_kotu_no = t;
        }
    }
    const char *ad[2] = {"NN (şehir 0'dan)     ", "NN (en iyi başlangıç)"};
    const double sinir[5] = {1.05, 1.10, 1.20, 1.30, 1e300};
    printf("                         en kötü  ortalama  ortanca  "
           "NN = en iyi\n");
    for (int v = 0; v < 2; v++) {
        double s[ORNEK];
        for (int t = 0; t < ORNEK; t++) {
            s[t] = oran[v][t];
        }
        qsort(s, ORNEK, sizeof s[0], kesir_karsilastir);
        printf("   %s   %.4f    %.4f   %.4f   %3d / %d\n", ad[v],
               s[ORNEK - 1], toplam[v] / ORNEK,
               (s[ORNEK / 2 - 1] + s[ORNEK / 2]) / 2.0, esit[v], ORNEK);
    }
    printf("   dağılım (şehir 0'dan): = 1: %d", esit[0]);
    double alt = 1.0;
    for (int b = 0; b < 5; b++) {
        int say = 0;
        for (int t = 0; t < ORNEK; t++) {
            say += oran[0][t] >= 1.0 + 1e-9 && oran[0][t] > alt &&
                   oran[0][t] <= sinir[b];
        }
        if (b < 4) {
            printf(" · (%.2f, %.2f]: %d", alt, sinir[b], say);
        } else {
            printf(" · > %.2f: %d\n", alt, say);
        }
        alt = sinir[b];
    }

    printf("\n3) En kötü örnek: #%d (oran %.4f)\n   şehir:", en_kotu_no + 1,
           oran[0][en_kotu_no]);
    n = 8;
    for (int i = 0; i < n; i++) {
        x[i] = kx8[en_kotu_no][i];
        y[i] = ky8[en_kotu_no][i];
        printf(" %d(%d, %d)", i, x[i], y[i]);
    }
    uzakliklari_hesapla();
    en_yakin_komsu(0, tur, 0);
    kb = kaba_kuvvet();
    printf("\n   NN    : ");
    tur_yaz(tur);
    printf("  uzunluk %.2f\n   en iyi: ", tur_uzunlugu(tur));
    tur_yaz(en_iyi_tur);
    printf("  uzunluk %.2f\n", kb);

    printf("\n4) Aday incelemesi n(n-1)/2: Θ(n²) (LCG, tohum 7)\n");
    printf("     n     aday  n(n-1)/2  NN uzunluğu\n");
    for (int adet = 10; adet <= 200; adet *= 2) {
        rastgele_tohum(7);
        rastgele_sehirler(adet);
        aday_sayisi = 0;
        en_yakin_komsu(0, tur, 0);
        printf("  %4d  %7lld  %8d  %11.2f\n", n, aday_sayisi,
               n * (n - 1) / 2, tur_uzunlugu(tur));
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: Örnek 2'nin kaba
 * kuvveti (n <= 10). */

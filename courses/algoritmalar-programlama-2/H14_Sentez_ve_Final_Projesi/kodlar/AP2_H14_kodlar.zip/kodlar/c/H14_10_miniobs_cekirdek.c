/* H14_10_miniobs_cekirdek.c — AP-2 Hafta 14 · Örnek 10 (★★★)
 * Amaç    : Final projesi entegrasyonu: menü güdümlü küçük bir "Mini-OBS
 *           çekirdeği". stdin'deki komut dosyasını okur ve her komutu
 *           dönemin bir modülüne yönlendirir: ekle (H8 dinamik dizi + H10
 *           karma dizini), ara (H10), sirala (H6 birleştirmeli), yinelenen
 *           (H10 karma kümesi), onkosul/plan (H11 Kahn), oneri (H13
 *           düzenleme uzaklığı). Modüller tek dosyada bölümlerle ayrılır.
 * DİKKAT  : Bu, mimarinin üç dilli KÜÇÜK MODELİDİR. Tam final projesi
 *           Mini-OBS 2 v3.0'dır (C; 91_Proje_MiniOBS2/v3.0).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_10_miniobs_cekirdek.c -o H14_10_miniobs_cekirdek
 * Çalıştır: ./H14_10_miniobs_cekirdek < ../girdiler/H14_10_miniobs_cekirdek.txt
 * Eşleri  : cpp/H14_10_miniobs_cekirdek.cpp ·
 *           python/H14_10_miniobs_cekirdek.py
 * Çıktı   : üç dilde aynı (=); bellek yetmezse çıkış kodu 1
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SATIR_UZ 256
#define AD_UZ 16

/* ===== Modül 1: kayıt deposu (H8 dinamik dizi, kapasite × 2) ======== */
typedef struct {
    int no;
    char ad[AD_UZ];
    int notu;
} Kayit;

static Kayit *kayit = NULL;          /* sahiplik: depo; depo_birak */
static int kayit_sayisi = 0, kapasite = 0;

static int depo_ekle(int no, const char *ad, int notu)  /* 0 / -1 */
{
    if (kayit_sayisi == kapasite) {
        int yeni = kapasite ? 2 * kapasite : 2;
        Kayit *g = realloc(kayit, (size_t)yeni * sizeof *g);
        if (g == NULL) {
            return -1;                           /* eski blok geçerli */
        }
        kayit = g;
        kapasite = yeni;
    }
    kayit[kayit_sayisi].no = no;
    strcpy(kayit[kayit_sayisi].ad, ad);
    kayit[kayit_sayisi].notu = notu;
    kayit_sayisi++;
    return 0;
}

/* ===== Modül 2: numara dizini (H10 karma, doğrusal yoklama) ========= */
static int *dizin = NULL;            /* kayıt indisi; -1 = boş */
static int dizin_kap = 0, dizin_dolu = 0;

static uint32_t karma(int no, int kap)       /* Fibonacci; kap = 2^k */
{
    uint32_t h = (uint32_t)no * 2654435769u;
    int bit = 0;
    while ((1 << bit) < kap) {
        bit++;
    }
    return h >> (32 - bit);
}

/* no'nun kaydı (yoksa -1); *yoklama: incelenen hücre */
static int dizin_bul(int no, int *yoklama)
{
    *yoklama = 0;
    if (dizin_kap == 0) {
        return -1;
    }
    uint32_t h = karma(no, dizin_kap);
    for (;;) {
        (*yoklama)++;
        if (dizin[h] == -1) {
            return -1;
        }
        if (kayit[dizin[h]].no == no) {
            return dizin[h];
        }
        h = (h + 1) & (uint32_t)(dizin_kap - 1);
    }
}

static int dizin_buyut(void)                 /* yük > 1/2 olmasın; 0/-1 */
{
    int yeni = dizin_kap ? 2 * dizin_kap : 8;
    int *d = malloc((size_t)yeni * sizeof *d);
    if (d == NULL) {
        return -1;
    }
    for (int i = 0; i < yeni; i++) {
        d[i] = -1;
    }
    for (int i = 0; i < dizin_kap; i++) {    /* yeniden yerleştir */
        if (dizin[i] != -1) {
            uint32_t h = karma(kayit[dizin[i]].no, yeni);
            while (d[h] != -1) {
                h = (h + 1) & (uint32_t)(yeni - 1);
            }
            d[h] = dizin[i];
        }
    }
    free(dizin);
    dizin = d;
    dizin_kap = yeni;
    return 0;
}

/* Kayıt i'yi dizine ekler; numara zaten varsa İLK kayıt kalır.
 * Dönen: 1 eklendi, 0 numara zaten var, -1 bellek yok */
static int dizin_ekle(int i)
{
    int y;
    if (dizin_bul(kayit[i].no, &y) != -1) {
        return 0;
    }
    if (2 * (dizin_dolu + 1) > dizin_kap && dizin_buyut() != 0) {
        return -1;
    }
    uint32_t h = karma(kayit[i].no, dizin_kap);
    while (dizin[h] != -1) {
        h = (h + 1) & (uint32_t)(dizin_kap - 1);
    }
    dizin[h] = i;
    dizin_dolu++;
    return 1;
}

/* ===== Modül 3: sıralama (H6 birleştirmeli, kararlı) ================ */
static int not_once;                 /* 1: not azalan, no artan; 0: no */
static long long karsilastirma;

static int once_mi(int a, int b)             /* a, b'den önce mi gelir? */
{
    karsilastirma++;
    if (not_once && kayit[a].notu != kayit[b].notu) {
        return kayit[a].notu > kayit[b].notu;
    }
    return kayit[a].no <= kayit[b].no;           /* eşitlikte girdi sırası */
}

static void birlestirmeli(int *s, int *g, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(s, g, lo, orta);
    birlestirmeli(s, g, orta, hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        g[k++] = once_mi(s[i], s[j]) ? s[i++] : s[j++];
    }
    while (i < orta) {
        g[k++] = s[i++];
    }
    while (j < hi) {
        g[k++] = s[j++];
    }
    memcpy(s + lo, g + lo, (size_t)(hi - lo) * sizeof *s);
}

/* ===== Modül 4: yinelenen (H10 karma kümesi: numara -> adet) ======== */
static int yinelenen_bul(int *sonuc, int *adet)  /* dönen: kaç numara */
{
    int kap = 8, k = 0;
    while (kap < 2 * kayit_sayisi) {
        kap *= 2;
    }
    int *no = malloc((size_t)kap * sizeof *no);
    int *say = calloc((size_t)kap, sizeof *say);   /* 0 = boş hücre */
    if (no == NULL || say == NULL) {
        free(no);
        free(say);
        return -1;
    }
    for (int i = 0; i < kayit_sayisi; i++) {
        uint32_t h = karma(kayit[i].no, kap);
        while (say[h] != 0 && no[h] != kayit[i].no) {
            h = (h + 1) & (uint32_t)(kap - 1);
        }
        no[h] = kayit[i].no;
        say[h]++;
    }
    for (int h = 0; h < kap; h++) {
        if (say[h] >= 2) {
            int j = k++;                         /* artan sırada ekle */
            while (j > 0 && sonuc[j - 1] > no[h]) {
                sonuc[j] = sonuc[j - 1];
                adet[j] = adet[j - 1];
                j--;
            }
            sonuc[j] = no[h];
            adet[j] = say[h];
        }
    }
    free(no);
    free(say);
    return k;
}

/* ===== Modül 5: önkoşul planı (H11 Kahn, en küçük kod önce) ========= */
#define MAKS_DERS 16
static char ders[MAKS_DERS][AD_UZ];
static int ders_sayisi = 0;
static int onkosul[MAKS_DERS][MAKS_DERS];

static int ders_no(const char *kod)          /* yoksa ekler; -1 dolu */
{
    for (int i = 0; i < ders_sayisi; i++) {
        if (strcmp(ders[i], kod) == 0) {
            return i;
        }
    }
    if (ders_sayisi == MAKS_DERS) {
        return -1;
    }
    strcpy(ders[ders_sayisi], kod);
    return ders_sayisi++;
}

static int plan_kur(int *sira)               /* dönen: sıralanan sayı */
{
    int giris[MAKS_DERS] = {0}, alindi[MAKS_DERS] = {0};
    for (int u = 0; u < ders_sayisi; u++) {
        for (int v = 0; v < ders_sayisi; v++) {
            giris[v] += onkosul[u][v];
        }
    }
    for (int k = 0; k < ders_sayisi; k++) {
        int sec = -1;
        for (int v = 0; v < ders_sayisi; v++) {  /* alfabetik en küçük */
            if (!alindi[v] && giris[v] == 0 &&
                (sec == -1 || strcmp(ders[v], ders[sec]) < 0)) {
                sec = v;
            }
        }
        if (sec == -1) {
            return k;                            /* döngü */
        }
        alindi[sec] = 1;
        sira[k] = sec;
        for (int v = 0; v < ders_sayisi; v++) {
            giris[v] -= onkosul[sec][v];
        }
    }
    return ders_sayisi;
}

/* ===== Modül 6: öneri (H13 düzenleme uzaklığı, iki satır) =========== */
static int duzenleme(const char *a, const char *b)
{
    int m = (int)strlen(b), onceki[AD_UZ + 1], simdi[AD_UZ + 1];
    for (int j = 0; j <= m; j++) {
        onceki[j] = j;
    }
    for (int i = 1; a[i - 1] != '\0'; i++) {
        simdi[0] = i;
        for (int j = 1; j <= m; j++) {
            int en = onceki[j] + 1;                          /* silme */
            if (simdi[j - 1] + 1 < en) {
                en = simdi[j - 1] + 1;                       /* ekleme */
            }
            if (onceki[j - 1] + (a[i - 1] != b[j - 1]) < en) {
                en = onceki[j - 1] + (a[i - 1] != b[j - 1]);  /* değiştir */
            }
            simdi[j] = en;
        }
        memcpy(onceki, simdi, sizeof onceki);
    }
    return onceki[m];
}

/* ===== Menü: komutu modüle yönlendir (dönen: 0 sürdür, 1 çık) ======= */
static int hata_sayisi = 0;

static int sayi_coz(const char *s, int alt, int ust, int *deger)
{
    char *son;
    long v = strtol(s, &son, 10);
    if (*s == '\0' || *son != '\0' || v < alt || v > ust) {
        return 0;
    }
    *deger = (int)v;
    return 1;
}

static int komut_isle(char *satir, int *bellek_hatasi)
{
    char k[4][SATIR_UZ];
    int t = sscanf(satir, "%255s %255s %255s %255s", k[0], k[1], k[2], k[3]);
    int no, notu, y;
    printf("> %s\n", satir);
    if (t >= 1 && strcmp(k[0], "cikis") == 0) {
        return 1;
    } else if (t == 4 && strcmp(k[0], "ekle") == 0 &&
               sayi_coz(k[1], 100000000, 999999999, &no) &&
               strlen(k[2]) < AD_UZ && sayi_coz(k[3], 0, 100, &notu)) {
        if (depo_ekle(no, k[2], notu) != 0) {
            *bellek_hatasi = 1;
            return 1;
        }
        int e = dizin_ekle(kayit_sayisi - 1);
        if (e < 0) {
            *bellek_hatasi = 1;
            return 1;
        }
        printf("  kayıt %d eklendi (depo kapasitesi %d, dizin %d/%d)%s\n",
               kayit_sayisi, kapasite, dizin_dolu, dizin_kap,
               e ? "" : "; numara zaten var: dizin ilk kaydı gösterir");
    } else if (t == 2 && strcmp(k[0], "ara") == 0 &&
               sayi_coz(k[1], 0, 999999999, &no)) {
        int i = dizin_bul(no, &y);
        if (i >= 0) {
            printf("  bulundu: %d %s %d (%d yoklama)\n", kayit[i].no,
                   kayit[i].ad, kayit[i].notu, y);
        } else {
            printf("  bulunamadı (%d yoklama)\n", y);
        }
    } else if (t == 2 && strcmp(k[0], "sirala") == 0 &&
               (strcmp(k[1], "not") == 0 || strcmp(k[1], "no") == 0)) {
        int *s = malloc((size_t)(kayit_sayisi + 1) * sizeof *s);
        int *g = malloc((size_t)(kayit_sayisi + 1) * sizeof *g);
        if (s == NULL || g == NULL) {
            free(s);
            free(g);
            *bellek_hatasi = 1;
            return 1;
        }
        for (int i = 0; i < kayit_sayisi; i++) {
            s[i] = i;
        }
        not_once = strcmp(k[1], "not") == 0;
        karsilastirma = 0;
        birlestirmeli(s, g, 0, kayit_sayisi);
        printf("  %d kayıt, %s; %lld karşılaştırma\n", kayit_sayisi,
               not_once ? "not azalan (eşitlikte no artan)" : "no artan",
               karsilastirma);
        for (int i = 0; i < kayit_sayisi; i++) {
            printf("  %2d. %d %-8s %3d\n", i + 1, kayit[s[i]].no,
                   kayit[s[i]].ad, kayit[s[i]].notu);
        }
        free(s);
        free(g);
    } else if (t == 1 && strcmp(k[0], "yinelenen") == 0) {
        int *no_l = malloc((size_t)(kayit_sayisi + 1) * sizeof *no_l);
        int *adet = malloc((size_t)(kayit_sayisi + 1) * sizeof *adet);
        int c = no_l && adet ? yinelenen_bul(no_l, adet) : -1;
        if (c < 0) {
            free(no_l);
            free(adet);
            *bellek_hatasi = 1;
            return 1;
        }
        printf("  %d yinelenen numara:", c);
        for (int i = 0; i < c; i++) {
            printf(" %d (%d kez)", no_l[i], adet[i]);
        }
        printf("\n");
        free(no_l);
        free(adet);
    } else if (t == 3 && strcmp(k[0], "onkosul") == 0 &&
               strlen(k[1]) < AD_UZ && strlen(k[2]) < AD_UZ) {
        int u = ders_no(k[1]), v = u >= 0 ? ders_no(k[2]) : -1;
        if (v < 0) {
            printf("  HATA: ders sınırı (%d)\n", MAKS_DERS);
            hata_sayisi++;
            return 0;
        }
        onkosul[u][v] = 1;
        printf("  %s -> %s (ders %d)\n", k[1], k[2], ders_sayisi);
    } else if (t == 1 && strcmp(k[0], "plan") == 0) {
        int sira[MAKS_DERS], s = plan_kur(sira);
        printf("  %s:", s < ders_sayisi ? "döngü var, kısmi sıra" : "plan");
        for (int i = 0; i < s; i++) {
            printf(" %s", ders[sira[i]]);
        }
        printf("\n");
    } else if (t == 2 && strcmp(k[0], "oneri") == 0 &&
               strlen(k[1]) < AD_UZ) {
        int en = -1, uz = 0;
        for (int i = 0; i < kayit_sayisi; i++) {  /* eşitlikte alfabetik */
            int d = duzenleme(k[1], kayit[i].ad);
            if (en == -1 || d < uz || (d == uz &&
                                       strcmp(kayit[i].ad, kayit[en].ad) < 0)) {
                en = i;
                uz = d;
            }
        }
        if (en >= 0 && uz <= 2) {
            printf("  Bunu mu demek istediniz: %s (uzaklık %d)\n",
                   kayit[en].ad, uz);
        } else {
            printf("  öneri yok (en yakın uzaklık %d)\n", uz);
        }
    } else {
        printf("  HATA: bilinmeyen ya da hatalı komut\n");
        hata_sayisi++;
    }
    return 0;
}

int main(void)
{
    char satir[SATIR_UZ];
    int komut = 0, bellek_hatasi = 0;
    printf("Mini-OBS çekirdeği (H14 Örnek 10; tam sürüm: Mini-OBS 2 v3.0)\n");
    while (fgets(satir, sizeof satir, stdin) != NULL) {
        satir[strcspn(satir, "\r\n")] = '\0';
        if (satir[0] == '#' || satir[0] == '\0') {
            continue;
        }
        komut++;
        if (komut_isle(satir, &bellek_hatasi)) {
            break;
        }
    }
    printf("Özet: %d komut, %d hata, %d kayıt, %d ders\n", komut,
           hata_sayisi, kayit_sayisi, ders_sayisi);
    free(kayit);
    free(dizin);
    if (bellek_hatasi) {
        fprintf(stderr, "bellek yetmedi\n");
        return 1;
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (sıralama), POSIX hsearch (karma);
 * C++ — std::vector, std::unordered_map, std::stable_sort; Python — list,
 * dict, sorted, graphlib (yalnızca kâhin). C'de modüllerin hepsi elle;
 * C++ ve Python'da yinelenen modülü H10'un kütüphane karşılığıyla
 * (std::unordered_map / dict), öbürleri elle. */

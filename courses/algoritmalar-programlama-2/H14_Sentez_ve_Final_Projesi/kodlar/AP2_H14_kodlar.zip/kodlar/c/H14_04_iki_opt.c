/* H14_04_iki_opt.c — AP-2 Hafta 14 · Örnek 4 (★★★)
 * Amaç    : 2-opt yerel arama: en yakın komşu turundan başla; iki kenarı
 *           (a-b, c-e) çıkarıp (a-c, b-e) ekle = tur[i..j]'yi ters çevir.
 *           İLK İYİLEŞTİRME: sabit sırayla (i = 1..n−2, j = i+1..n−1)
 *           taranır, kısaltan ilk hamle uygulanır ve tarama baştan başlar;
 *           hiçbir hamle kısaltmıyorsa tur bir 2-opt YEREL EN İYİSİDİR.
 *           Yerel en iyinin genel en iyi olmadığı bir örnek (kaba kuvvet)
 * Kurallar: kazanç = (d(a,c) + d(b,e)) − (d(a,b) + d(c,e)) < −1e-9 ise
 *           hamle uygulanır; tam tarama (n−1)(n−2)/2 hamle → O(n²)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H14_04_iki_opt.c ortak_rastgele.c -lm -o H14_04_iki_opt
 * Çalıştır: ./H14_04_iki_opt
 * Eşleri  : cpp/H14_04_iki_opt.cpp · python/H14_04_iki_opt.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdio.h>

#include "ortak_rastgele.h"

#define MAKS_N 100
#define KB_MAKS 10
#define EPS 1e-9
#define ORNEK 100

static int n;
static int x[MAKS_N], y[MAKS_N];
static double d[MAKS_N][MAKS_N];
static long long denenen;          /* incelenen 2-opt hamlesi */

static long long d2(int i, int j)
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static void uzakliklari_hesapla(void)
{
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            d[i][j] = sqrt((double)d2(i, j));
        }
    }
}

static double tur_uzunlugu(const int *tur)
{
    double t = 0.0;
    for (int k = 1; k < n; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t + d[tur[n - 1]][tur[0]];
}

static void tur_yaz(const int *tur)
{
    for (int k = 0; k < n; k++) {
        printf("%d-", tur[k]);
    }
    printf("%d", tur[0]);
}

/* Örnek 3: en yakın komşu, şehir 0'dan, eşitlikte küçük indeks */
static void en_yakin_komsu(int *tur)
{
    int ziyaret[MAKS_N] = {0};
    tur[0] = 0;
    ziyaret[0] = 1;
    for (int k = 1; k < n; k++) {
        int son = tur[k - 1], sec = -1;
        for (int s = 0; s < n; s++) {
            if (!ziyaret[s] && (sec == -1 || d2(son, s) < d2(son, sec))) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
}

static void ters_cevir(int *tur, int i, int j)
{
    while (i < j) {
        int gecici = tur[i];
        tur[i] = tur[j];
        tur[j] = gecici;
        i++;
        j--;
    }
}

/* İlk iyileştirmeli 2-opt; dönen: uygulanan hamle sayısı */
static int iki_opt(int *tur, int ayrinti)
{
    int iyilestirme = 0, degisti = 1;
    while (degisti) {
        degisti = 0;
        for (int i = 1; i < n - 1 && !degisti; i++) {
            for (int j = i + 1; j < n && !degisti; j++) {
                int a = tur[i - 1], b = tur[i], c = tur[j];
                int e = tur[(j + 1) % n];
                double kazanc = (d[a][c] + d[b][e])
                                - (d[a][b] + d[c][e]);
                denenen++;
                if (kazanc < -EPS) {
                    ters_cevir(tur, i, j);
                    iyilestirme++;
                    degisti = 1;
                    if (ayrinti) {
                        printf("    %2d  (%d, %d)  %d-%d, %d-%d  %d-%d, %d-%d"
                               "  %7.2f  %8.2f   ", iyilestirme, i, j, a, b,
                               c, e, a, c, b, e, -kazanc, tur_uzunlugu(tur));
                        tur_yaz(tur);
                        printf("\n");
                    }
                }
            }
        }
    }
    return iyilestirme;
}

/* --- Kaba kuvvet (Örnek 2) ----------------------------------------- */
static int yol[KB_MAKS], kullanildi[KB_MAKS], en_iyi_tur[KB_MAKS];
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == n) {
        double toplam = kismi + d[yol[n - 1]][0];
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
            for (int i = 0; i < n; i++) {
                en_iyi_tur[i] = yol[i];
            }
        }
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

static double kaba_kuvvet(void)
{
    for (int i = 0; i < n; i++) {
        kullanildi[i] = 0;
    }
    yol[0] = 0;
    kullanildi[0] = 1;
    en_iyi = 1e300;
    dene(1, 0.0);
    return en_iyi;
}

static void rastgele_sehirler(int adet)
{
    n = adet;
    for (int i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    uzakliklari_hesapla();
}

int main(void)
{
    int tur[MAKS_N];
    rastgele_tohum(2026);
    for (int t = 0; t < 24; t++) {
        rastgele_sehirler(8);                  /* 24. örneğe kadar ilerle */
    }
    printf("1) Örnek 3'ün en kötü örneği (#24; tohum 2026, n = 8)\n"
           "   şehir:");
    for (int i = 0; i < n; i++) {
        printf(" %d(%d, %d)", i, x[i], y[i]);
    }
    en_yakin_komsu(tur);
    printf("\n   NN turu: ");
    tur_yaz(tur);
    printf("  uzunluk %.2f\n", tur_uzunlugu(tur));
    printf("   2-opt adımları (ilk iyileştirme; i = 1..n-2, j = i+1..n-1)\n");
    printf("   adım  (i, j)  çıkan     giren     kazanç  uzunluk   tur\n");
    denenen = 0;
    int adim = iki_opt(tur, 1);
    double kb = kaba_kuvvet();
    printf("   iyileştirme = %d, denenen hamle = %lld (tam tarama = "
           "(n-1)(n-2)/2 = %d)\n", adim, denenen, (n - 1) * (n - 2) / 2);
    printf("   2-opt: %.2f; en iyi (kaba kuvvet): %.2f; oran %.4f\n",
           tur_uzunlugu(tur), kb, tur_uzunlugu(tur) / kb);

    printf("\n2) Örnek 3'ün 100 örneği (tohum 2026, n = 8): NN -> 2-opt\n");
    double top_nn = 0.0, top_2 = 0.0, kotu_nn = 0.0, kotu_2 = 0.0;
    int esit_nn = 0, esit_2 = 0, ilk_yerel = -1;
    long long top_adim = 0;
    int yerel_tur[MAKS_N], yerel_x[8], yerel_y[8];
    rastgele_tohum(2026);
    for (int t = 0; t < ORNEK; t++) {
        rastgele_sehirler(8);
        double opt = kaba_kuvvet();
        en_yakin_komsu(tur);
        double r1 = tur_uzunlugu(tur) / opt;
        top_adim += iki_opt(tur, 0);
        double r2 = tur_uzunlugu(tur) / opt;
        top_nn += r1;
        top_2 += r2;
        kotu_nn = r1 > kotu_nn ? r1 : kotu_nn;
        kotu_2 = r2 > kotu_2 ? r2 : kotu_2;
        esit_nn += r1 < 1.0 + 1e-9;
        esit_2 += r2 < 1.0 + 1e-9;
        if (r2 >= 1.0 + 1e-9 && ilk_yerel == -1) {
            ilk_yerel = t;
            for (int i = 0; i < n; i++) {
                yerel_tur[i] = tur[i];
                yerel_x[i] = x[i];
                yerel_y[i] = y[i];
            }
        }
    }
    printf("               en kötü  ortalama  = en iyi\n");
    printf("   NN          %.4f    %.4f   %3d / %d\n", kotu_nn,
           top_nn / ORNEK, esit_nn, ORNEK);
    printf("   NN + 2-opt  %.4f    %.4f   %3d / %d   (ortalama %.2f "
           "iyileştirme)\n", kotu_2, top_2 / ORNEK, esit_2, ORNEK,
           (double)top_adim / ORNEK);

    if (ilk_yerel >= 0) {
        n = 8;
        for (int i = 0; i < n; i++) {
            x[i] = yerel_x[i];
            y[i] = yerel_y[i];
        }
        uzakliklari_hesapla();
        printf("\n3) Yerel en iyi != genel en iyi: örnek #%d\n   şehir:",
               ilk_yerel + 1);
        for (int i = 0; i < n; i++) {
            printf(" %d(%d, %d)", i, x[i], y[i]);
        }
        denenen = 0;
        int ek = iki_opt(yerel_tur, 0);
        printf("\n   2-opt turu: ");
        tur_yaz(yerel_tur);
        printf("  uzunluk %.2f\n   yeniden tarama: %lld hamle, %d "
               "iyileştirme -> 2-opt yerel en iyisi\n",
               tur_uzunlugu(yerel_tur), denenen, ek);
        kb = kaba_kuvvet();
        printf("   genel en iyi: ");
        tur_yaz(en_iyi_tur);
        printf("  uzunluk %.2f (oran %.4f)\n", kb,
               tur_uzunlugu(yerel_tur) / kb);
    }

    printf("\n4) Büyük n (LCG, tohum 7): NN -> 2-opt\n");
    printf("     n   NN uzunluğu  2-opt uzunluğu  iyileştirme   denenen "
           "hamle\n");
    for (int adet = 25; adet <= 100; adet *= 2) {
        rastgele_tohum(7);
        rastgele_sehirler(adet);
        en_yakin_komsu(tur);
        double u0 = tur_uzunlugu(tur);
        denenen = 0;
        adim = iki_opt(tur, 0);
        printf("  %4d  %11.2f  %14.2f  %11d  %14lld\n", n, u0,
               tur_uzunlugu(tur), adim, denenen);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). 2-opt'un ilk iyileştirmeli
 * bu sürümü sabit tarama sırası sayesinde belirleyicidir. */

/* H14_10_miniobs_cekirdek.cpp — AP-2 Hafta 14 · Örnek 10 (★★★)
 * Amaç    : Final projesi entegrasyonu: menü güdümlü küçük bir "Mini-OBS
 *           çekirdeği". stdin'deki komut dosyasını okur ve her komutu
 *           dönemin bir modülüne yönlendirir: ekle (H8 dinamik dizi + H10
 *           karma dizini), ara (H10), sirala (H6 birleştirmeli), yinelenen
 *           (H10 karma kümesi), onkosul/plan (H11 Kahn), oneri (H13
 *           düzenleme uzaklığı). Modüller tek dosyada bölümlerle ayrılır.
 * DİKKAT  : Bu, mimarinin üç dilli KÜÇÜK MODELİDİR. Tam final projesi
 *           Mini-OBS 2 v3.0'dır (C; 91_Proje_MiniOBS2/v3.0).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_10_miniobs_cekirdek.cpp -o H14_10_miniobs_cekirdek
 * Çalıştır: ./H14_10_miniobs_cekirdek < ../girdiler/H14_10_miniobs_cekirdek.txt
 * Eşleri  : c/H14_10_miniobs_cekirdek.c · python/H14_10_miniobs_cekirdek.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

// ===== Modül 1: kayıt deposu (H8 dinamik dizi, kapasite × 2) ==========
struct Kayit {
    int no;
    std::string ad;
    int notu;
};

static std::unique_ptr<Kayit[]> kayit;   // sahiplik: depo (RAII)
static int kayit_sayisi = 0, kapasite = 0;

static void depo_ekle(int no, const std::string& ad, int notu)
{
    if (kayit_sayisi == kapasite) {
        int yeni = kapasite ? 2 * kapasite : 2;
        std::unique_ptr<Kayit[]> g(new Kayit[yeni]);
        for (int i = 0; i < kayit_sayisi; i++) {
            g[i] = kayit[i];                     // öğeleri taşı
        }
        kayit = std::move(g);
        kapasite = yeni;
    }
    kayit[kayit_sayisi++] = Kayit{no, ad, notu};
}

// ===== Modül 2: numara dizini (H10 karma, doğrusal yoklama) ===========
static std::vector<int> dizin;           // kayıt indisi; -1 = boş
static int dizin_dolu = 0;

static std::uint32_t karma(int no, int kap)  // Fibonacci; kap = 2^k
{
    std::uint32_t h = static_cast<std::uint32_t>(no) * 2654435769u;
    int bit = 0;
    while ((1 << bit) < kap) {
        bit++;
    }
    return h >> (32 - bit);
}

// no'nun kaydı (yoksa -1); yoklama: incelenen hücre
static int dizin_bul(int no, int& yoklama)
{
    const int kap = static_cast<int>(dizin.size());
    yoklama = 0;
    if (kap == 0) {
        return -1;
    }
    std::uint32_t h = karma(no, kap);
    for (;;) {
        yoklama++;
        if (dizin[h] == -1) {
            return -1;
        }
        if (kayit[dizin[h]].no == no) {
            return dizin[h];
        }
        h = (h + 1) & static_cast<std::uint32_t>(kap - 1);
    }
}

static void dizin_buyut()                    // yük > 1/2 olmasın
{
    const int eski = static_cast<int>(dizin.size());
    const int yeni = eski ? 2 * eski : 8;
    std::vector<int> d(yeni, -1);
    for (int i = 0; i < eski; i++) {         // yeniden yerleştir
        if (dizin[i] != -1) {
            std::uint32_t h = karma(kayit[dizin[i]].no, yeni);
            while (d[h] != -1) {
                h = (h + 1) & static_cast<std::uint32_t>(yeni - 1);
            }
            d[h] = dizin[i];
        }
    }
    dizin.swap(d);
}

// Kayıt i'yi dizine ekler; numara zaten varsa İLK kayıt kalır.
// Dönen: true eklendi, false numara zaten var
static bool dizin_ekle(int i)
{
    int y;
    if (dizin_bul(kayit[i].no, y) != -1) {
        return false;
    }
    if (2 * (dizin_dolu + 1) > static_cast<int>(dizin.size())) {
        dizin_buyut();
    }
    const int kap = static_cast<int>(dizin.size());
    std::uint32_t h = karma(kayit[i].no, kap);
    while (dizin[h] != -1) {
        h = (h + 1) & static_cast<std::uint32_t>(kap - 1);
    }
    dizin[h] = i;
    dizin_dolu++;
    return true;
}

// ===== Modül 3: sıralama (H6 birleştirmeli, kararlı) ==================
static bool not_once;                    // true: not azalan, no artan
static long long karsilastirma;

static bool once_mi(int a, int b)            // a, b'den önce mi gelir?
{
    karsilastirma++;
    if (not_once && kayit[a].notu != kayit[b].notu) {
        return kayit[a].notu > kayit[b].notu;
    }
    return kayit[a].no <= kayit[b].no;           // eşitlikte girdi sırası
}

static void birlestirmeli(std::vector<int>& s, std::vector<int>& g, int lo,
                          int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(s, g, lo, orta);
    birlestirmeli(s, g, orta, hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        g[k++] = once_mi(s[i], s[j]) ? s[i++] : s[j++];
    }
    while (i < orta) {
        g[k++] = s[i++];
    }
    while (j < hi) {
        g[k++] = s[j++];
    }
    for (k = lo; k < hi; k++) {
        s[k] = g[k];
    }
}

// ===== Modül 4: yinelenen (H10'un kütüphane karşılığı: unordered_map) =
static std::vector<std::pair<int, int>> yinelenen_bul()
{
    std::unordered_map<int, int> say;        // numara -> adet
    for (int i = 0; i < kayit_sayisi; i++) {
        say[kayit[i].no]++;
    }
    std::vector<std::pair<int, int>> sonuc;  // artan sırada ekle
    for (const auto& [no, adet] : say) {
        if (adet >= 2) {
            std::size_t j = sonuc.size();
            sonuc.push_back({no, adet});
            while (j > 0 && sonuc[j - 1].first > no) {
                sonuc[j] = sonuc[j - 1];
                j--;
            }
            sonuc[j] = {no, adet};
        }
    }
    return sonuc;
}

// ===== Modül 5: önkoşul planı (H11 Kahn, en küçük kod önce) ===========
constexpr int MAKS_DERS = 16;
static std::vector<std::string> ders;
static int onkosul[MAKS_DERS][MAKS_DERS];

static int ders_no(const std::string& kod)   // yoksa ekler; -1 dolu
{
    for (std::size_t i = 0; i < ders.size(); i++) {
        if (ders[i] == kod) {
            return static_cast<int>(i);
        }
    }
    if (static_cast<int>(ders.size()) == MAKS_DERS) {
        return -1;
    }
    ders.push_back(kod);
    return static_cast<int>(ders.size()) - 1;
}

static std::vector<int> plan_kur()           // döngüde kısmi sıra
{
    const int D = static_cast<int>(ders.size());
    std::vector<int> giris(D, 0), alindi(D, 0), sira;
    for (int u = 0; u < D; u++) {
        for (int v = 0; v < D; v++) {
            giris[v] += onkosul[u][v];
        }
    }
    for (int k = 0; k < D; k++) {
        int sec = -1;
        for (int v = 0; v < D; v++) {            // alfabetik en küçük
            if (!alindi[v] && giris[v] == 0 &&
                (sec == -1 || ders[v] < ders[sec])) {
                sec = v;
            }
        }
        if (sec == -1) {
            break;                               // döngü
        }
        alindi[sec] = 1;
        sira.push_back(sec);
        for (int v = 0; v < D; v++) {
            giris[v] -= onkosul[sec][v];
        }
    }
    return sira;
}

// ===== Modül 6: öneri (H13 düzenleme uzaklığı, iki satır) =============
static int duzenleme(const std::string& a, const std::string& b)
{
    const std::size_t m = b.size();
    std::vector<int> onceki(m + 1), simdi(m + 1);
    for (std::size_t j = 0; j <= m; j++) {
        onceki[j] = static_cast<int>(j);
    }
    for (std::size_t i = 1; i <= a.size(); i++) {
        simdi[0] = static_cast<int>(i);
        for (std::size_t j = 1; j <= m; j++) {
            int en = onceki[j] + 1;                          // silme
            if (simdi[j - 1] + 1 < en) {
                en = simdi[j - 1] + 1;                       // ekleme
            }
            if (onceki[j - 1] + (a[i - 1] != b[j - 1]) < en) {
                en = onceki[j - 1] + (a[i - 1] != b[j - 1]);  // değiştir
            }
            simdi[j] = en;
        }
        onceki = simdi;
    }
    return onceki[m];
}

// ===== Menü: komutu modüle yönlendir (dönen: true çık) ================
static int hata_sayisi = 0;

static bool sayi_coz(const std::string& s, int alt, int ust, int& deger)
{
    char* son;
    long v = std::strtol(s.c_str(), &son, 10);
    if (s.empty() || *son != '\0' || v < alt || v > ust) {
        return false;
    }
    deger = static_cast<int>(v);
    return true;
}

static bool komut_isle(const std::string& satir)
{
    std::istringstream ss(satir);
    std::vector<std::string> k;
    std::string s;
    while (k.size() < 4 && ss >> s) {
        k.push_back(s);
    }
    const std::size_t t = k.size();
    int no, notu, y;
    std::printf("> %s\n", satir.c_str());
    if (t >= 1 && k[0] == "cikis") {
        return true;
    } else if (t == 4 && k[0] == "ekle" &&
               sayi_coz(k[1], 100000000, 999999999, no) &&
               k[2].size() < 16 && sayi_coz(k[3], 0, 100, notu)) {
        depo_ekle(no, k[2], notu);
        bool e = dizin_ekle(kayit_sayisi - 1);
        std::printf("  kayıt %d eklendi (depo kapasitesi %d, dizin %d/%d)%s\n",
                    kayit_sayisi, kapasite, dizin_dolu,
                    static_cast<int>(dizin.size()),
                    e ? "" : "; numara zaten var: dizin ilk kaydı gösterir");
    } else if (t == 2 && k[0] == "ara" && sayi_coz(k[1], 0, 999999999, no)) {
        int i = dizin_bul(no, y);
        if (i >= 0) {
            std::printf("  bulundu: %d %s %d (%d yoklama)\n", kayit[i].no,
                        kayit[i].ad.c_str(), kayit[i].notu, y);
        } else {
            std::printf("  bulunamadı (%d yoklama)\n", y);
        }
    } else if (t == 2 && k[0] == "sirala" && (k[1] == "not" || k[1] == "no")) {
        std::vector<int> sira(kayit_sayisi), g(kayit_sayisi);
        for (int i = 0; i < kayit_sayisi; i++) {
            sira[i] = i;
        }
        not_once = k[1] == "not";
        karsilastirma = 0;
        birlestirmeli(sira, g, 0, kayit_sayisi);
        std::printf("  %d kayıt, %s; %lld karşılaştırma\n", kayit_sayisi,
                    not_once ? "not azalan (eşitlikte no artan)" : "no artan",
                    karsilastirma);
        for (int i = 0; i < kayit_sayisi; i++) {
            const Kayit& r = kayit[sira[i]];
            std::printf("  %2d. %d %-8s %3d\n", i + 1, r.no, r.ad.c_str(),
                        r.notu);
        }
    } else if (t == 1 && k[0] == "yinelenen") {
        auto sonuc = yinelenen_bul();
        std::printf("  %d yinelenen numara:", static_cast<int>(sonuc.size()));
        for (const auto& [no2, adet] : sonuc) {
            std::printf(" %d (%d kez)", no2, adet);
        }
        std::printf("\n");
    } else if (t == 3 && k[0] == "onkosul" && k[1].size() < 16 &&
               k[2].size() < 16) {
        int u = ders_no(k[1]), v = u >= 0 ? ders_no(k[2]) : -1;
        if (v < 0) {
            std::printf("  HATA: ders sınırı (%d)\n", MAKS_DERS);
            hata_sayisi++;
            return false;
        }
        onkosul[u][v] = 1;
        std::printf("  %s -> %s (ders %d)\n", k[1].c_str(), k[2].c_str(),
                    static_cast<int>(ders.size()));
    } else if (t == 1 && k[0] == "plan") {
        std::vector<int> sira = plan_kur();
        std::printf("  %s:", sira.size() < ders.size()
                    ? "döngü var, kısmi sıra" : "plan");
        for (int v : sira) {
            std::printf(" %s", ders[v].c_str());
        }
        std::printf("\n");
    } else if (t == 2 && k[0] == "oneri" && k[1].size() < 16) {
        int en = -1, uz = 0;
        for (int i = 0; i < kayit_sayisi; i++) {  // eşitlikte alfabetik
            int d = duzenleme(k[1], kayit[i].ad);
            if (en == -1 || d < uz || (d == uz && kayit[i].ad < kayit[en].ad)) {
                en = i;
                uz = d;
            }
        }
        if (en >= 0 && uz <= 2) {
            std::printf("  Bunu mu demek istediniz: %s (uzaklık %d)\n",
                        kayit[en].ad.c_str(), uz);
        } else {
            std::printf("  öneri yok (en yakın uzaklık %d)\n", uz);
        }
    } else {
        std::printf("  HATA: bilinmeyen ya da hatalı komut\n");
        hata_sayisi++;
    }
    return false;
}

int main()
{
    std::string satir;
    int komut = 0;
    std::printf("Mini-OBS çekirdeği (H14 Örnek 10; tam sürüm: Mini-OBS 2 "
                "v3.0)\n");
    while (std::getline(std::cin, satir)) {
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (satir.empty() || satir[0] == '#') {
            continue;
        }
        komut++;
        if (komut_isle(satir)) {
            break;
        }
    }
    std::printf("Özet: %d komut, %d hata, %d kayıt, %d ders\n", komut,
                hata_sayisi, kayit_sayisi, static_cast<int>(ders.size()));
    return 0;
}

/* Kütüphane karşılığı: C — qsort (sıralama), POSIX hsearch (karma);
 * C++ — std::vector, std::unordered_map, std::stable_sort; Python — list,
 * dict, sorted, graphlib (yalnızca kâhin). C'de modüllerin hepsi elle;
 * C++ ve Python'da yinelenen modülü H10'un kütüphane karşılığıyla
 * (std::unordered_map / dict), öbürleri elle. */

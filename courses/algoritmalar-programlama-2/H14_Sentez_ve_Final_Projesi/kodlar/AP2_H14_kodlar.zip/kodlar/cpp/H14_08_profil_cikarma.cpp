/* H14_08_profil_cikarma.cpp — AP-2 Hafta 14 · Örnek 8 (★★★)
 * Amaç    : Profil çıkarma: KASITLI darboğazlı küçük bir kayıt işleme
 *           programı (üretim, istatistik, O(n²) yinelenen tespiti, harf
 *           dağılımı, ilk 3). Profil (gprof / cProfile) asıl zamanın tüm
 *           çiftlerde geçtiğini gösterir; darboğaz "sırala + komşular"
 *           (H6, O(n log n)) ile giderilir. stdout belirleyicidir; adım
 *           süreleri (işlemci zamanı) stderr'e "bu çalıştırmada" yazılır
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_08_profil_cikarma.cpp -o H14_08_profil_cikarma
 * Profil  : g++ ... -O2 -pg -fno-inline ... ; gprof -b program gmon.out
 * Çalıştır: ./H14_08_profil_cikarma [n] [--surum yavas|hizli|ikisi]
 * Eşleri  : c/H14_08_profil_cikarma.c · python/H14_08_profil_cikarma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

constexpr int TABAN_NO = 220000000;

static std::vector<int> numara, notlar, gecici, kopya;
static int n;

// 1) Üretim: numaralar ardışık ve karışık; %1'i öncekilerden birinin
// kopyası (kasıtlı yinelenen)
static int kayitlari_uret()
{
    int yinelenen = 0;
    rastgele_tohum(8);
    numara.assign(n, 0);
    notlar.assign(n, 0);
    for (int i = 0; i < n; i++) {
        numara[i] = TABAN_NO + i;
        notlar[i] = rastgele_aralik(0, 100);
    }
    rastgele_karistir(numara);
    for (int i = 1; i < n; i++) {
        if (rastgele_aralik(0, 99) == 0) {
            numara[i] = numara[rastgele_aralik(0, i - 1)];
            yinelenen++;
        }
    }
    return yinelenen;
}

// 2) İstatistik: toplam, en düşük, en yüksek — O(n)
static long long istatistik(int& en_dusuk, int& en_yuksek)
{
    long long toplam = 0;
    en_dusuk = 100;
    en_yuksek = 0;
    for (int x : notlar) {
        toplam += x;
        en_dusuk = x < en_dusuk ? x : en_dusuk;
        en_yuksek = x > en_yuksek ? x : en_yuksek;
    }
    return toplam;
}

// 3a) Yinelenen, YAVAŞ: tüm çiftler — n(n−1)/2 karşılaştırma (darboğaz)
static long long yinelenen_ciftler(long long& kars)
{
    long long cift = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            kars++;
            cift += numara[i] == numara[j];
        }
    }
    return cift;
}

// Birleştirmeli sıralama (H6), a[lo..hi), artan
static void birlestirmeli(std::vector<int>& a, int lo, int hi,
                          long long& kars)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(a, lo, orta, kars);
    birlestirmeli(a, orta, hi, kars);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        kars++;
        gecici[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i < orta) {
        gecici[k++] = a[i++];
    }
    while (j < hi) {
        gecici[k++] = a[j++];
    }
    for (k = lo; k < hi; k++) {
        a[k] = gecici[k];
    }
}

// 3b) Yinelenen, HIZLI: kopyayı sırala, eşit komşu gruplarını say
static long long yinelenen_siralama(long long& kars)
{
    long long cift = 0;
    kopya = numara;
    gecici.assign(n, 0);
    birlestirmeli(kopya, 0, n, kars);
    for (int i = 0, j; i < n; i = j) {
        for (j = i + 1; j < n && kopya[j] == kopya[i]; j++) {
            kars++;
        }
        cift += static_cast<long long>(j - i) * (j - i - 1) / 2;
    }
    return cift;
}

// 4) Harf dağılımı (örnek ölçek) — O(n)
static const char* HARF[8] = {"AA", "BA", "BB", "CB", "CC", "DC", "DD",
                              "FF"};
static const int ALT[8] = {90, 85, 80, 70, 60, 55, 50, 0};

static std::vector<int> harf_dagilimi()
{
    std::vector<int> say(8, 0);
    for (int x : notlar) {
        int h = 0;
        while (x < ALT[h]) {
            h++;
        }
        say[h]++;
    }
    return say;
}

// 5) İlk 3: en yüksek not, eşitlikte küçük numara — 3 doğrusal tarama
static std::vector<int> ilk_uc()
{
    std::vector<int> sec(3, -1);
    for (int k = 0; k < 3; k++) {
        for (int i = 0; i < n; i++) {
            bool alindi = false;
            for (int t = 0; t < k; t++) {
                alindi = alindi || sec[t] == i;
            }
            if (!alindi && (sec[k] == -1 || notlar[i] > notlar[sec[k]] ||
                            (notlar[i] == notlar[sec[k]] &&
                             numara[i] < numara[sec[k]]))) {
                sec[k] = i;
            }
        }
    }
    return sec;
}

int main(int argc, char* argv[])
{
    int adet = 4000;
    bool yavas = true, hizli = true;
    for (int i = 1; i < argc; i++) {
        if (std::strcmp(argv[i], "--surum") == 0 && i + 1 < argc) {
            std::string s = argv[++i];
            yavas = s != "hizli";
            hizli = s != "yavas";
            if (s != "yavas" && s != "hizli" && s != "ikisi") {
                std::fprintf(stderr, "--surum yavas|hizli|ikisi\n");
                return 2;
            }
        } else {
            char* son;
            long v = std::strtol(argv[i], &son, 10);
            if (*son != '\0' || v < 10 || v > 1000000) {
                std::fprintf(stderr, "Kullanım: %s [n] [--surum "
                             "yavas|hizli|ikisi] (10 <= n <= 10^6)\n",
                             argv[0]);
                return 2;
            }
            adet = static_cast<int>(v);
        }
    }
    n = adet;
    double t0 = islemci_sn(), t[6];
    int yin = kayitlari_uret();
    t[0] = islemci_sn();
    int dusuk, yuksek;
    long long toplam = istatistik(dusuk, yuksek);
    t[1] = islemci_sn();
    long long kars_y = 0, kars_h = 0, cift_y = -1, cift_h = -1;
    if (yavas) {
        cift_y = yinelenen_ciftler(kars_y);
    }
    t[2] = islemci_sn();
    if (hizli) {
        cift_h = yinelenen_siralama(kars_h);
    }
    t[3] = islemci_sn();
    std::vector<int> say = harf_dagilimi();
    t[4] = islemci_sn();
    std::vector<int> sec = ilk_uc();
    t[5] = islemci_sn();

    std::printf("Kayıt işleme (n = %d, tohum 8)\n", n);
    std::printf("  1) üretim      : %d kayıt, %d kasıtlı yinelenen numara\n",
                n, yin);
    std::printf("  2) istatistik  : ortalama %.2f, en düşük %d, en yüksek "
                "%d\n", static_cast<double>(toplam) / n, dusuk, yuksek);
    if (yavas) {
        std::printf("  3) yinelenen   : %lld eşit çift (tüm çiftler, %lld "
                    "karşılaştırma)\n", cift_y, kars_y);
    }
    if (hizli) {
        std::printf("  3) yinelenen   : %lld eşit çift (sırala + komşular, "
                    "%lld karşılaştırma)\n", cift_h, kars_h);
    }
    if (yavas && hizli) {
        std::printf("     iki sürüm aynı mı: %s\n",
                    cift_y == cift_h ? "evet" : "HAYIR");
    }
    std::printf("  4) harf        :");
    for (int h = 0; h < 8; h++) {
        std::printf(" %s %d", HARF[h], say[h]);
    }
    std::printf("\n  5) ilk 3       :");
    for (int k = 0; k < 3; k++) {
        std::printf(" %d (%d)", numara[sec[k]], notlar[sec[k]]);
    }
    std::printf("\n");

    const char* ad[6] = {"üretim", "istatistik", "yinelenen (yavaş)",
                         "yinelenen (hızlı)", "harf", "ilk 3"};
    double onceki = t0, toplam_sn = t[5] - t0;
    std::fprintf(stderr, "Adım süreleri (işlemci, bu çalıştırmada; n = "
                 "%d):\n", n);
    for (int k = 0; k < 6; k++) {
        std::fprintf(stderr, "  %-18s %10.3f ms  %%%5.1f\n", ad[k],
                     (t[k] - onceki) * 1e3, toplam_sn > 0
                     ? 100.0 * (t[k] - onceki) / toplam_sn : 0.0);
        onceki = t[k];
    }
    if (yavas && hizli && t[3] > t[2]) {
        std::fprintf(stderr, "  yinelenen: yavaş / hızlı = %.1f kat\n",
                     (t[2] - t[1]) / (t[3] - t[2]));
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort ile sıralama; C++ — std::sort,
 * std::unordered_set (karma, H10); Python — sorted, set/collections.Counter.
 * Burada algoritmalar elle yazıldı; profil, darboğazın yerini gösterir. */

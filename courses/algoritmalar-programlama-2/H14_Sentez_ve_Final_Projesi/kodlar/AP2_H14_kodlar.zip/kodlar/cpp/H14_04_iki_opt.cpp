/* H14_04_iki_opt.cpp — AP-2 Hafta 14 · Örnek 4 (★★★)
 * Amaç    : 2-opt yerel arama: en yakın komşu turundan başla; iki kenarı
 *           (a-b, c-e) çıkarıp (a-c, b-e) ekle = tur[i..j]'yi ters çevir.
 *           İLK İYİLEŞTİRME: sabit sırayla (i = 1..n−2, j = i+1..n−1)
 *           taranır, kısaltan ilk hamle uygulanır ve tarama baştan başlar;
 *           hiçbir hamle kısaltmıyorsa tur bir 2-opt YEREL EN İYİSİDİR.
 *           Yerel en iyinin genel en iyi olmadığı bir örnek (kaba kuvvet)
 * Kurallar: kazanç = (d(a,c) + d(b,e)) − (d(a,b) + d(c,e)) < −1e-9 ise
 *           hamle uygulanır; tam tarama (n−1)(n−2)/2 hamle → O(n²)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_04_iki_opt.cpp -o H14_04_iki_opt
 * Çalıştır: ./H14_04_iki_opt
 * Eşleri  : c/H14_04_iki_opt.c · python/H14_04_iki_opt.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <cstdio>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

constexpr double EPS = 1e-9;
constexpr int ORNEK = 100;

static int n;
static std::vector<int> x, y;
static std::vector<std::vector<double>> d;
static long long denenen;          // incelenen 2-opt hamlesi

static long long d2(int i, int j)
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static void uzakliklari_hesapla()
{
    d.assign(n, std::vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            d[i][j] = std::sqrt(static_cast<double>(d2(i, j)));
        }
    }
}

static double tur_uzunlugu(const std::vector<int>& tur)
{
    double t = 0.0;
    for (int k = 1; k < n; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t + d[tur[n - 1]][tur[0]];
}

static void tur_yaz(const std::vector<int>& tur)
{
    for (int k = 0; k < n; k++) {
        std::printf("%d-", tur[k]);
    }
    std::printf("%d", tur[0]);
}

// Örnek 3: en yakın komşu, şehir 0'dan, eşitlikte küçük indeks
static void en_yakin_komsu(std::vector<int>& tur)
{
    std::vector<int> ziyaret(n, 0);
    tur.assign(n, 0);
    ziyaret[0] = 1;
    for (int k = 1; k < n; k++) {
        int son = tur[k - 1], sec = -1;
        for (int s = 0; s < n; s++) {
            if (!ziyaret[s] && (sec == -1 || d2(son, s) < d2(son, sec))) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
}

static void ters_cevir(std::vector<int>& tur, int i, int j)
{
    while (i < j) {
        std::swap(tur[i], tur[j]);
        i++;
        j--;
    }
}

// İlk iyileştirmeli 2-opt; dönen: uygulanan hamle sayısı
static int iki_opt(std::vector<int>& tur, bool ayrinti)
{
    int iyilestirme = 0;
    bool degisti = true;
    while (degisti) {
        degisti = false;
        for (int i = 1; i < n - 1 && !degisti; i++) {
            for (int j = i + 1; j < n && !degisti; j++) {
                int a = tur[i - 1], b = tur[i], c = tur[j];
                int e = tur[(j + 1) % n];
                double kazanc = (d[a][c] + d[b][e])
                                - (d[a][b] + d[c][e]);
                denenen++;
                if (kazanc < -EPS) {
                    ters_cevir(tur, i, j);
                    iyilestirme++;
                    degisti = true;
                    if (ayrinti) {
                        std::printf("    %2d  (%d, %d)  %d-%d, %d-%d  "
                                    "%d-%d, %d-%d  %7.2f  %8.2f   ",
                                    iyilestirme, i, j, a, b, c, e, a, c, b,
                                    e, -kazanc, tur_uzunlugu(tur));
                        tur_yaz(tur);
                        std::printf("\n");
                    }
                }
            }
        }
    }
    return iyilestirme;
}

// --- Kaba kuvvet (Örnek 2) -------------------------------------------
static std::vector<int> yol, kullanildi, en_iyi_tur;
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == n) {
        double toplam = kismi + d[yol[n - 1]][0];
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
            en_iyi_tur = yol;
        }
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

static double kaba_kuvvet()
{
    kullanildi.assign(n, 0);
    yol.assign(n, 0);
    kullanildi[0] = 1;
    en_iyi = 1e300;
    dene(1, 0.0);
    return en_iyi;
}

static void rastgele_sehirler(int adet)
{
    n = adet;
    x.assign(n, 0);
    y.assign(n, 0);
    for (int i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    uzakliklari_hesapla();
}

int main()
{
    std::vector<int> tur;
    rastgele_tohum(2026);
    for (int t = 0; t < 24; t++) {
        rastgele_sehirler(8);                  // 24. örneğe kadar ilerle
    }
    std::printf("1) Örnek 3'ün en kötü örneği (#24; tohum 2026, n = 8)\n"
                "   şehir:");
    for (int i = 0; i < n; i++) {
        std::printf(" %d(%d, %d)", i, x[i], y[i]);
    }
    en_yakin_komsu(tur);
    std::printf("\n   NN turu: ");
    tur_yaz(tur);
    std::printf("  uzunluk %.2f\n", tur_uzunlugu(tur));
    std::printf("   2-opt adımları (ilk iyileştirme; i = 1..n-2, "
                "j = i+1..n-1)\n");
    std::printf("   adım  (i, j)  çıkan     giren     kazanç  uzunluk   "
                "tur\n");
    denenen = 0;
    int adim = iki_opt(tur, true);
    double kb = kaba_kuvvet();
    std::printf("   iyileştirme = %d, denenen hamle = %lld (tam tarama = "
                "(n-1)(n-2)/2 = %d)\n", adim, denenen, (n - 1) * (n - 2) / 2);
    std::printf("   2-opt: %.2f; en iyi (kaba kuvvet): %.2f; oran %.4f\n",
                tur_uzunlugu(tur), kb, tur_uzunlugu(tur) / kb);

    std::printf("\n2) Örnek 3'ün 100 örneği (tohum 2026, n = 8): NN -> "
                "2-opt\n");
    double top_nn = 0.0, top_2 = 0.0, kotu_nn = 0.0, kotu_2 = 0.0;
    int esit_nn = 0, esit_2 = 0, ilk_yerel = -1;
    long long top_adim = 0;
    std::vector<int> yerel_tur, yerel_x, yerel_y;
    rastgele_tohum(2026);
    for (int t = 0; t < ORNEK; t++) {
        rastgele_sehirler(8);
        double opt = kaba_kuvvet();
        en_yakin_komsu(tur);
        double r1 = tur_uzunlugu(tur) / opt;
        top_adim += iki_opt(tur, false);
        double r2 = tur_uzunlugu(tur) / opt;
        top_nn += r1;
        top_2 += r2;
        kotu_nn = r1 > kotu_nn ? r1 : kotu_nn;
        kotu_2 = r2 > kotu_2 ? r2 : kotu_2;
        esit_nn += r1 < 1.0 + 1e-9;
        esit_2 += r2 < 1.0 + 1e-9;
        if (r2 >= 1.0 + 1e-9 && ilk_yerel == -1) {
            ilk_yerel = t;
            yerel_tur = tur;
            yerel_x = x;
            yerel_y = y;
        }
    }
    std::printf("               en kötü  ortalama  = en iyi\n");
    std::printf("   NN          %.4f    %.4f   %3d / %d\n", kotu_nn,
                top_nn / ORNEK, esit_nn, ORNEK);
    std::printf("   NN + 2-opt  %.4f    %.4f   %3d / %d   (ortalama %.2f "
                "iyileştirme)\n", kotu_2, top_2 / ORNEK, esit_2, ORNEK,
                static_cast<double>(top_adim) / ORNEK);

    if (ilk_yerel >= 0) {
        n = 8;
        x = yerel_x;
        y = yerel_y;
        uzakliklari_hesapla();
        std::printf("\n3) Yerel en iyi != genel en iyi: örnek #%d\n"
                    "   şehir:", ilk_yerel + 1);
        for (int i = 0; i < n; i++) {
            std::printf(" %d(%d, %d)", i, x[i], y[i]);
        }
        denenen = 0;
        int ek = iki_opt(yerel_tur, false);
        std::printf("\n   2-opt turu: ");
        tur_yaz(yerel_tur);
        std::printf("  uzunluk %.2f\n   yeniden tarama: %lld hamle, %d "
                    "iyileştirme -> 2-opt yerel en iyisi\n",
                    tur_uzunlugu(yerel_tur), denenen, ek);
        kb = kaba_kuvvet();
        std::printf("   genel en iyi: ");
        tur_yaz(en_iyi_tur);
        std::printf("  uzunluk %.2f (oran %.4f)\n", kb,
                    tur_uzunlugu(yerel_tur) / kb);
    }

    std::printf("\n4) Büyük n (LCG, tohum 7): NN -> 2-opt\n");
    std::printf("     n   NN uzunluğu  2-opt uzunluğu  iyileştirme   "
                "denenen hamle\n");
    for (int adet = 25; adet <= 100; adet *= 2) {
        rastgele_tohum(7);
        rastgele_sehirler(adet);
        en_yakin_komsu(tur);
        double u0 = tur_uzunlugu(tur);
        denenen = 0;
        adim = iki_opt(tur, false);
        std::printf("  %4d  %11.2f  %14.2f  %11d  %14lld\n", n, u0,
                    tur_uzunlugu(tur), adim, denenen);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). 2-opt'un ilk iyileştirmeli
 * bu sürümü sabit tarama sırası sayesinde belirleyicidir. */

/* H14_06_dogrulama_bulma.cpp — AP-2 Hafta 14 · Örnek 6 (★)
 * Amaç    : NP sezgisi: alt küme toplamında verilen bir çözümü (sertifika:
 *           seçilen indisler) DOĞRULAMAK O(n) adımdır; çözümü BULMAK için
 *           bilinen yollar H3'ün geri izlemesi (en kötü 2^(n+1) − 1 düğüm) ve
 *           H13'ün sözde polinom DP'sidir ((n+1)·(T+1) hücre). "Evet"
 *           örneğinde sertifika vardır; "hayır" örneğinde gösterilecek
 *           sertifika yoktur (doğrulama yalnız "evet" yanıtları içindir)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_06_dogrulama_bulma.cpp -o H14_06_dogrulama_bulma
 * Çalıştır: ./H14_06_dogrulama_bulma
 * Eşleri  : c/H14_06_dogrulama_bulma.c · python/H14_06_dogrulama_bulma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstdio>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static std::vector<int> a;

// Doğrulayıcı: sertifika sec (indisler) geçerli mi, tekrarsız mı, toplamı
// hedef mi? Her öğe için bir adım + son karşılaştırma: O(n + k)
static bool dogrula(long long hedef, const std::vector<int>& sec,
                    long long& adim, std::string& neden)
{
    const int n = static_cast<int>(a.size());
    std::vector<bool> goruldu(n, false);
    long long toplam = 0;
    adim = 0;
    if (static_cast<int>(sec.size()) > n) {
        neden = "öğe sayısı n'den fazla";
        return false;
    }
    for (int i : sec) {
        adim++;
        if (i < 0 || i >= n) {
            neden = "indis dizi dışında";
            return false;
        }
        if (goruldu[i]) {
            neden = "aynı indis iki kez";
            return false;
        }
        goruldu[i] = true;
        toplam += a[i];
    }
    adim++;
    if (toplam != hedef) {
        neden = "toplam hedefe eşit değil";
        return false;
    }
    neden = "toplam = hedef";
    return true;
}

// --- Bulma 1: H3'ün budamalı geri izlemesi, ilk çözümde dur ------------
static long long dugum;
static std::vector<int> yol, bulunan;

static bool geri_izle(std::size_t i, long long toplam, long long hedef)
{
    dugum++;
    if (toplam > hedef) {
        return false;                      // a_i > 0: torunlar da aşar
    }
    if (i == a.size()) {
        if (toplam == hedef) {
            bulunan = yol;
            return true;
        }
        return false;
    }
    if (geri_izle(i + 1, toplam, hedef)) {           // önce almadan
        return true;
    }
    yol.push_back(static_cast<int>(i));              // sonra alarak
    bool bulundu = geri_izle(i + 1, toplam + a[i], hedef);
    yol.pop_back();
    return bulundu;
}

// --- Bulma 2: H13'ün DP'si (bool tablo) + geri çıkarma ----------------
static long long hucre;

// Dönen: true çözüm var (sec doldurulur), false yok
static bool dp_bul(long long hedef, std::vector<int>& sec)
{
    const int n = static_cast<int>(a.size());
    const int T = static_cast<int>(hedef);
    std::vector<std::vector<bool>> v(n + 1, std::vector<bool>(T + 1, false));
    v[0][0] = true;
    hucre = T + 1;
    for (int i = 1; i <= n; i++) {
        for (int t = 0; t <= T; t++) {
            v[i][t] = v[i - 1][t] || (a[i - 1] <= t && v[i - 1][t - a[i - 1]]);
            hucre++;
        }
    }
    sec.clear();
    if (v[n][T]) {
        int t = T;
        for (int i = n; i >= 1; i--) {              // eşitlikte almadan
            if (!v[i - 1][t]) {
                sec.push_back(i - 1);
                t -= a[i - 1];
            }
        }
        for (std::size_t p = 0, q = sec.size(); p + 1 < q; p++, q--) {
            std::swap(sec[p], sec[q - 1]);           // artan sıra
        }
    }
    return v[n][T];
}

static std::string kume_metni(const std::vector<int>& sec)
{
    std::string m = "{";
    for (std::size_t t = 0; t < sec.size(); t++) {
        m += (t ? ", " : "") + std::to_string(sec[t]);
    }
    return m + "}";
}

int main()
{
    a = {13, 7, 21, 4, 18, 9};
    long long hedef = 38, adim;
    std::string neden;
    std::printf("1) a = {13, 7, 21, 4, 18, 9} (indis 0..5), hedef = 38\n");
    std::printf("   Doğrulama (sertifika = seçilen indisler):\n");
    const std::vector<std::vector<int>> sertifika = {
        {0, 1, 4}, {0, 1, 3}, {0, 0, 4}, {2, 9}};
    for (const auto& s : sertifika) {
        bool sonuc = dogrula(hedef, s, adim, neden);
        std::printf("   %-10s -> %-5s (%s); adım = %lld\n",
                    kume_metni(s).c_str(), sonuc ? "KABUL" : "RED",
                    neden.c_str(), adim);
    }
    std::vector<int> sec;
    dugum = 0;
    yol.clear();
    bulunan.clear();
    bool bulundu = geri_izle(0, 0, hedef);
    std::printf("   Bulma, geri izleme (H3; önce almadan): %s %s; düğüm = "
                "%lld (2^(n+1) - 1 = %d)\n", bulundu ? "çözüm" : "yok",
                kume_metni(bulunan).c_str(), dugum,
                (1 << (a.size() + 1)) - 1);
    dp_bul(hedef, sec);
    std::printf("   Bulma, DP (H13): çözüm %s; hücre = %lld = (n+1)(T+1)\n",
                kume_metni(sec).c_str(), hucre);
    std::printf("   DP'nin çözümü doğrulayıcıdan: %s\n",
                dogrula(hedef, sec, adim, neden) ? "KABUL" : "RED");

    std::printf("\n2) \"Evet\" örnekleri: a = LCG(1..1000), hedef = rastgele "
                "bir alt kümenin toplamı\n");
    std::printf("   n   hedef  doğrulama  geri izleme düğümü  DP hücresi"
                "    2^(n+1)-1\n");
    rastgele_tohum(14);
    for (int n = 10; n <= 30; n += 4) {
        a = rastgele_dizi(n, 1, 1000);
        hedef = 0;
        for (int i = 0; i < n; i++) {
            if (rastgele_aralik(0, 1)) {
                hedef += a[i];
            }
        }
        dugum = 0;
        yol.clear();
        geri_izle(0, 0, hedef);
        dp_bul(hedef, sec);
        bool gecerli = dogrula(hedef, sec, adim, neden);
        std::printf("  %2d  %6lld  %4lld adım  %18lld  %10lld  %11lld%s\n",
                    n, hedef, adim, dugum, hucre, (1LL << (n + 1)) - 1,
                    gecerli ? "" : "  DOĞRULANAMADI");
    }

    std::printf("\n3) \"Hayır\" örnekleri: bütün sayılar çift, hedef tek "
                "(çözüm yok; sertifika da yok)\n");
    std::printf("   n   hedef  geri izleme düğümü  DP hücresi    "
                "2^(n+1)-1\n");
    for (int n = 10; n <= 18; n += 4) {
        a.assign(n, 0);
        long long toplam = 0;
        for (int i = 0; i < n; i++) {
            a[i] = 2 * rastgele_aralik(1, 500);
            toplam += a[i];
        }
        hedef = toplam / 2 + (toplam / 2 % 2 == 0);   // tek sayı
        dugum = 0;
        yol.clear();
        bool var = geri_izle(0, 0, hedef);
        bool dp_var = dp_bul(hedef, sec);
        std::printf("  %2d  %6lld  %18lld  %10lld  %11lld  %s\n", n, hedef,
                    dugum, hucre, (1LL << (n + 1)) - 1,
                    var || dp_var ? "ÇÖZÜM VAR?" : "çözüm yok");
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Doğrulayıcı, H3'ün bit
 * maskesi kaba kuvvetinin "bu alt küme doğru mu?" adımıdır. */

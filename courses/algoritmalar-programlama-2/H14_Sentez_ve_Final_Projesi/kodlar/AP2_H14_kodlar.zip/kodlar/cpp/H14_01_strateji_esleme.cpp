/* H14_01_strateji_esleme.cpp — AP-2 Hafta 14 · Örnek 1 (★★)
 * Amaç    : Problem–strateji eşleme: on kısa problem için çözüm
 *           iskeletleri tek programda. Her problemde seçilen strateji,
 *           karmaşıklık, gerekçe satırı ve küçük girdide sonuç yazdırılır.
 *           Yelpaze: kaba kuvvet, geri izleme, ikili arama, böl ve fethet,
 *           karma, graf dolaşma, açgözlü (iki problem), DP, sezgisel
 * Kurallar: eşitlikte küçük indeks; komşular artan numarayla; girdiler
 *           elle ya da ortak LCG'den (tohum yazılı)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_01_strateji_esleme.cpp -o H14_01_strateji_esleme
 * Çalıştır: ./H14_01_strateji_esleme
 * Eşleri  : c/H14_01_strateji_esleme.c · python/H14_01_strateji_esleme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <cstdio>
#include <queue>
#include <vector>

#include "ortak_rastgele.hpp"

struct Kart {
    const char* problem;
    const char* strateji;
    const char* karmasiklik;
    const char* hafta;
    const char* gerekce;
};

static const Kart KART[10] = {
    {"En yakın nokta çifti (8 nokta)", "kaba kuvvet", "O(n²)", "H2",
     "n küçük: 28 çiftin hepsi denenir; daha karmaşık yönteme gerek yok"},
    {"6 x 6 tahtada 6 vezir: kaç çözüm?", "geri izleme", "O(n!) budamalı",
     "H3", "kısıt ihlal eden kısmi yerleşim erken budanır"},
    {"Sıralı 15 notta 70 ve üstü kaç not?", "ikili arama", "O(log n)", "H4",
     "dizi sıralı: ilk >= 70 konumu (lower_bound) yeter"},
    {"Ters çevrim sayısı (8 sayı)", "böl ve fethet", "O(n log n)", "H6",
     "birleştirme adımı, sol yarıdan büyükleri toplu sayar"},
    {"Numaralarda yinelenen var mı?", "karma", "ortalama O(n)", "H10",
     "her numara bir kez eklenir; görülmüş mü sorusu O(1)"},
    {"Ağda 0'dan 6'ya en az aktarma", "graf dolaşma (BFS)", "O(V + E)",
     "H11", "kenarlar ağırlıksız: BFS katmanı = en az kenar"},
    {"En çok çakışmayan sınav (8 aralık)", "açgözlü", "O(n log n)", "H12",
     "en erken biteni seçmek güvenli (değiş tokuş kanıtı)"},
    {"{1, 3, 4} paralarla 6: en az para", "DP", "O(n·T)", "H13",
     "açgözlü 4+1+1 = 3 para verir; DP en iyiyi (3+3) bulur"},
    {"8 şehirde kısa tur (gezgin satıcı)", "sezgisel (en yakın komşu)",
     "O(n²)", "H14", "NP-zor; büyük n'de kesin yöntem yok: hızlı, iyi tur"},
    {"Ağırlıklı ağda 0'dan 5'e en kısa yol", "açgözlü (Dijkstra)", "O(V²)",
     "H12", "ağırlıklar negatif değil: en yakını kesinleştirmek güvenli"},
};

static void baslik(int p)
{
    std::printf("P%d  %s\n    strateji : %s · %s · %s\n    gerekçe  : %s\n",
                p + 1, KART[p].problem, KART[p].strateji,
                KART[p].karmasiklik, KART[p].hafta, KART[p].gerekce);
}

// P1 — kaba kuvvet: tüm çiftler, en küçük kare uzaklık
static void p1_en_yakin_cift()
{
    std::vector<int> x(8), y(8);
    int bi = 0, bj = 1, cift = 0;
    long long en = -1;
    rastgele_tohum(11);
    for (int i = 0; i < 8; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    for (int i = 0; i < 8; i++) {
        for (int j = i + 1; j < 8; j++) {
            long long dx = x[i] - x[j], dy = y[i] - y[j];
            cift++;
            if (en == -1 || dx * dx + dy * dy < en) {
                en = dx * dx + dy * dy;
                bi = i;
                bj = j;
            }
        }
    }
    std::printf("    sonuç    : %d (%d, %d) ile %d (%d, %d); uzaklık %.2f; "
                "%d çift\n", bi, x[bi], y[bi], bj, x[bj], y[bj],
                std::sqrt(static_cast<double>(en)), cift);
}

// P2 — geri izleme: satır satır vezir koy; sütun ve çaprazlar dolu mu?
static bool sutun[6], capraz1[11], capraz2[11];
static long long dugum;

static int vezir(int r)
{
    dugum++;
    if (r == 6) {
        return 1;
    }
    int cozum = 0;
    for (int c = 0; c < 6; c++) {
        if (!sutun[c] && !capraz1[r + c] && !capraz2[r - c + 5]) {
            sutun[c] = capraz1[r + c] = capraz2[r - c + 5] = true;   // seç
            cozum += vezir(r + 1);                                   // dene
            sutun[c] = capraz1[r + c] = capraz2[r - c + 5] = false;  // geri
        }
    }
    return cozum;
}

static void p2_vezir()
{
    int yaprak = 1;
    for (int i = 0; i < 6; i++) {
        yaprak *= 6;                             // budamasız: 6^6 yaprak
    }
    dugum = 0;
    int c = vezir(0);
    std::printf("    sonuç    : %d çözüm; %lld düğüm (budamasız ağaç 6^6 = "
                "%d yaprak)\n", c, dugum, yaprak);
}

// P3 — ikili arama: ilk >= x konumu (yarı açık aralık)
static void p3_alt_sinir()
{
    const std::vector<int> a = {35, 41, 48, 52, 55, 60, 63, 67, 70, 70, 74,
                                81, 88, 90, 97};
    int lo = 0, hi = 15, yoklama = 0;
    while (lo < hi) {
        int orta = lo + (hi - lo) / 2;
        yoklama++;
        if (a[orta] < 70) {
            lo = orta + 1;
        } else {
            hi = orta;
        }
    }
    std::printf("    sonuç    : ilk >= 70 konumu %d; %d not; %d yoklama\n",
                lo, 15 - lo, yoklama);
}

// P4 — böl ve fethet: birleştirirken ters çevrim say
static long long birlestir_say(std::vector<int>& a, std::vector<int>& g,
                               int lo, int hi)
{
    if (hi - lo < 2) {
        return 0;
    }
    int orta = lo + (hi - lo) / 2;
    long long t = birlestir_say(a, g, lo, orta) + birlestir_say(a, g, orta,
                                                                hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        if (a[i] <= a[j]) {
            g[k++] = a[i++];
        } else {
            t += orta - i;              // a[i..orta-1] hepsi a[j]'den büyük
            g[k++] = a[j++];
        }
    }
    while (i < orta) {
        g[k++] = a[i++];
    }
    while (j < hi) {
        g[k++] = a[j++];
    }
    for (k = lo; k < hi; k++) {
        a[k] = g[k];
    }
    return t;
}

static void p4_ters_cevrim()
{
    std::vector<int> a = {8, 4, 2, 1, 7, 3, 6, 5}, g(8);
    long long t = birlestir_say(a, g, 0, 8);
    std::printf("    sonuç    : [8 4 2 1 7 3 6 5] -> %lld ters çevrim (en "
                "çok 8·7/2 = 28)\n", t);
}

// P5 — karma: doğrusal yoklamalı küme; ilk yineleneni bul
static void p5_yinelenen()
{
    const std::vector<int> no = {2201004, 2201017, 2201002, 2201033,
                                 2201021, 2201008, 2201017, 2201040,
                                 2201002, 2201011};
    std::vector<int> tablo(16, -1);
    int yoklama = 0, bulunan = -1;
    for (int i = 0; i < 10 && bulunan == -1; i++) {
        unsigned h = static_cast<unsigned>(no[i]) % 16u;  // bölme karması
        yoklama++;
        while (tablo[h] != -1 && tablo[h] != no[i]) {
            h = (h + 1) % 16u;
            yoklama++;
        }
        if (tablo[h] == no[i]) {
            bulunan = i;
        } else {
            tablo[h] = no[i];
        }
    }
    std::printf("    sonuç    : ilk yinelenen %d (konum %d); %d yoklama\n",
                no[bulunan], bulunan, yoklama);
}

// P6 — BFS: ağırlıksız grafta en az kenar
static void p6_bfs()
{
    const int kenar[9][2] = {{0, 1}, {0, 2}, {1, 3}, {2, 3}, {2, 4},
                             {3, 5}, {4, 5}, {5, 6}, {1, 4}};
    std::vector<std::vector<int>> kom(7, std::vector<int>(7, 0));
    std::vector<int> uz(7, -1), eb(7, -1);
    for (const auto& e : kenar) {
        kom[e[0]][e[1]] = kom[e[1]][e[0]] = 1;
    }
    std::queue<int> kuyruk;                       // H9'un kuyruğu
    uz[0] = 0;
    kuyruk.push(0);
    while (!kuyruk.empty()) {
        int u = kuyruk.front();
        kuyruk.pop();
        for (int v = 0; v < 7; v++) {          // artan köşe numarası
            if (kom[u][v] && uz[v] == -1) {
                uz[v] = uz[u] + 1;
                eb[v] = u;
                kuyruk.push(v);
            }
        }
    }
    std::vector<int> yol;
    for (int v = 6; v != -1; v = eb[v]) {
        yol.push_back(v);
    }
    std::printf("    sonuç    : %d aktarma; yol", uz[6]);
    for (auto it = yol.rbegin(); it != yol.rend(); ++it) {
        std::printf(" %d", *it);
    }
    std::printf("\n");
}

// P7 — açgözlü: (bitiş, başlangıç, no) sırasında en erken biteni seç
static void p7_aralik()
{
    const std::vector<int> bas_ = {1, 3, 0, 5, 3, 5, 6, 8};
    const std::vector<int> bit = {4, 5, 6, 7, 9, 9, 10, 11};
    std::vector<int> sira(8), secilen;
    int son_bitis = -1;
    for (int i = 0; i < 8; i++) {               // araya ekleme (araç)
        int j = i;
        while (j > 0 && (bit[sira[j - 1]] > bit[i] ||
                         (bit[sira[j - 1]] == bit[i] &&
                          bas_[sira[j - 1]] > bas_[i]))) {
            sira[j] = sira[j - 1];
            j--;
        }
        sira[j] = i;
    }
    for (int i : sira) {
        if (bas_[i] >= son_bitis) {
            secilen.push_back(i);
            son_bitis = bit[i];
        }
    }
    std::printf("    sonuç    : %d sınav:", static_cast<int>(secilen.size()));
    for (int i : secilen) {
        std::printf(" s%d[%d, %d)", i, bas_[i], bit[i]);
    }
    std::printf("\n");
}

// P8 — DP: en az para; karşılaştırma için açgözlü
static void p8_bozuk_para()
{
    const int para[3] = {1, 3, 4};
    std::vector<int> enaz(7, 1000), son(7, -1);
    enaz[0] = 0;
    for (int t = 1; t <= 6; t++) {
        for (int c : para) {
            if (c <= t && enaz[t - c] + 1 < enaz[t]) {
                enaz[t] = enaz[t - c] + 1;
                son[t] = c;
            }
        }
    }
    int acgozlu = 0, kalan = 6;
    for (int c = 2; c >= 0; c--) {
        while (para[c] <= kalan) {
            kalan -= para[c];
            acgozlu++;
        }
    }
    std::printf("    sonuç    : DP %d para (", enaz[6]);
    for (int t = 6; t > 0; t -= son[t]) {
        std::printf(t == 6 ? "%d" : " + %d", son[t]);
    }
    std::printf("); açgözlü %d para\n", acgozlu);
}

// P9 — sezgisel: en yakın komşu; küçük n'de kaba kuvvetle denetim
static double d[8][8];
static bool kullanildi[8];
static int yol[8];
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == 8) {
        double t = kismi + d[yol[7]][0];
        if (t < en_iyi - 1e-9) {
            en_iyi = t;
        }
        return;
    }
    for (int s = 1; s < 8; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = true;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = false;
        }
    }
}

static void p9_sezgisel()
{
    std::vector<int> x(8), y(8), tur(8);
    std::vector<bool> ziyaret(8, false);
    rastgele_tohum(42);
    for (int i = 0; i < 8; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            double dx = x[i] - x[j], dy = y[i] - y[j];
            d[i][j] = std::sqrt(dx * dx + dy * dy);
        }
    }
    tur[0] = 0;
    ziyaret[0] = true;
    for (int k = 1; k < 8; k++) {
        int sec = -1;
        for (int s = 0; s < 8; s++) {
            if (!ziyaret[s] && (sec == -1 || d[tur[k - 1]][s] <
                                                 d[tur[k - 1]][sec])) {
                sec = s;
            }
        }
        tur[k] = sec;
        ziyaret[sec] = true;
    }
    double u = 0.0;
    for (int k = 1; k < 8; k++) {
        u += d[tur[k - 1]][tur[k]];
    }
    u += d[tur[7]][0];
    yol[0] = 0;
    kullanildi[0] = true;
    en_iyi = 1e300;
    dene(1, 0.0);
    std::printf("    sonuç    : NN turu %.2f; en iyi (kaba kuvvet, 5040 tur) "
                "%.2f; oran %.4f\n", u, en_iyi, u / en_iyi);
}

// P10 — Dijkstra, dizi sürümü (H12 Örnek 7), O(V²)
static void p10_dijkstra()
{
    const int kenar[9][3] = {{0, 1, 7}, {0, 2, 9}, {0, 5, 14}, {1, 2, 10},
                             {1, 3, 15}, {2, 3, 11}, {2, 5, 2}, {3, 4, 6},
                             {4, 5, 9}};
    std::vector<std::vector<int>> w(6, std::vector<int>(6, -1));
    std::vector<int> uz(6, -1), eb(6, -1);
    std::vector<bool> bitti(6, false);
    for (const auto& e : kenar) {
        w[e[0]][e[1]] = w[e[1]][e[0]] = e[2];
    }
    uz[0] = 0;
    for (int adim = 0; adim < 6; adim++) {
        int u = -1;
        for (int v = 0; v < 6; v++) {           // eşitlikte küçük köşe
            if (!bitti[v] && uz[v] != -1 && (u == -1 || uz[v] < uz[u])) {
                u = v;
            }
        }
        if (u == -1) {
            break;
        }
        bitti[u] = true;
        for (int v = 0; v < 6; v++) {
            if (w[u][v] != -1 && (uz[v] == -1 || uz[u] + w[u][v] < uz[v])) {
                uz[v] = uz[u] + w[u][v];
                eb[v] = u;
            }
        }
    }
    std::vector<int> yol5;
    for (int v = 5; v != -1; v = eb[v]) {
        yol5.push_back(v);
    }
    std::printf("    sonuç    : uzaklık %d; yol", uz[5]);
    for (auto it = yol5.rbegin(); it != yol5.rend(); ++it) {
        std::printf(" %d", *it);
    }
    std::printf(" (doğrudan 0-5 kenarı %d)\n", w[0][5]);
}

int main()
{
    void (*cozucu[10])() = {p1_en_yakin_cift, p2_vezir, p3_alt_sinir,
                            p4_ters_cevrim, p5_yinelenen, p6_bfs,
                            p7_aralik, p8_bozuk_para, p9_sezgisel,
                            p10_dijkstra};
    std::printf("Problem–strateji eşleme: on problem, on iskelet\n\n");
    for (int p = 0; p < 10; p++) {
        baslik(p);
        cozucu[p]();
    }
    std::printf("\nÖzet tablo (problem · strateji · karmaşıklık · hafta)\n");
    for (int p = 0; p < 10; p++) {
        std::printf("  P%-2d %s · %s · %s · %s\n", p + 1, KART[p].problem,
                    KART[p].strateji, KART[p].karmasiklik, KART[p].hafta);
    }
    return 0;
}

/* Kütüphane karşılığı: her iskeletin kütüphane karşılığı ilgili haftanın
 * örneğinde verildi (ör. bsearch/std::lower_bound/bisect_left, qsort/
 * std::sort/sorted, std::unordered_set/set, std::priority_queue/heapq). */

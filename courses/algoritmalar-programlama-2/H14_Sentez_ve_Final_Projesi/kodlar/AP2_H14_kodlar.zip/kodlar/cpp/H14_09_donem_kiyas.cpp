/* H14_09_donem_kiyas.cpp — AP-2 Hafta 14 · Örnek 9 (★★★)
 * Amaç    : Dönem kıyaslama programı: dönemin sekiz algoritmik çekirdeği
 *           sabit boyutlarda — ikili arama (H4), birleştirmeli sıralama
 *           (H6), öbek sıralaması (H7), karma tablosu (H10), BFS (H11),
 *           Dijkstra (H12), LCS (H13), 0/1 sırt çantası (H13). stdout'a
 *           YALNIZCA denetim toplamları; işlemci süreleri stderr'e ya da
 *           --csv ile CSV'ye. Girdiler ortak LCG'den (çekirdek başına tohum)
 * Kurallar: komşular artan köşe numarasıyla (eşitlikte ağırlık); öbekte
 *           (uzaklık, köşe) demetleri; karma: 32 bit Fibonacci çarpanı +
 *           doğrusal yoklama; denetim toplamlarının tanımı her çekirdekte
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_09_donem_kiyas.cpp -o H14_09_donem_kiyas
 * Çalıştır: ./H14_09_donem_kiyas [--olcek K] [--tekrar T] [--csv dosya]
 * Eşleri  : c/H14_09_donem_kiyas.c · python/H14_09_donem_kiyas.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <queue>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static int n;                                    // çekirdeğin boyutu
static std::vector<int> g1, g2, is, yrd;         // veriler

// --- 1) İkili arama (H4): a[i] = 3i + 1; kontrol = Σ (konum + 1) -------
static void arama_hazirla()
{
    rastgele_tohum(1);
    for (int i = 0; i < n; i++) {
        g1[i] = 3 * i + 1;
        g2[i] = rastgele_aralik(0, 3 * n);       // sorgular: 1/3 bulunur
    }
}

static long long arama_calistir()
{
    long long kontrol = 0;
    for (int q = 0; q < n; q++) {
        int lo = 0, hi = n - 1, x = g2[q], konum = -1;
        while (lo <= hi) {
            int orta = lo + (hi - lo) / 2;
            if (g1[orta] == x) {
                konum = orta;
                break;
            } else if (g1[orta] < x) {
                lo = orta + 1;
            } else {
                hi = orta - 1;
            }
        }
        kontrol += konum + 1;
    }
    return kontrol;
}

// --- Sıralama girdisi; kontrol = Σ (i mod 1000 + 1)·a[i], sırasızsa -1 -
static void siralama_hazirla()
{
    rastgele_tohum(2);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(0, 1000000);
    }
}

static long long siralama_kontrol(const std::vector<int>& a)
{
    long long k = 0;
    for (int i = 0; i < n; i++) {
        if (i > 0 && a[i - 1] > a[i]) {
            return -1;
        }
        k += static_cast<long long>(i % 1000 + 1) * a[i];
    }
    return k;
}

// --- 2) Birleştirmeli sıralama (H6), a[lo..hi) -------------------------
static void birlestirmeli(std::vector<int>& a, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli(a, lo, orta);
    birlestirmeli(a, orta, hi);
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        yrd[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    }
    while (i < orta) {
        yrd[k++] = a[i++];
    }
    while (j < hi) {
        yrd[k++] = a[j++];
    }
    for (k = lo; k < hi; k++) {
        a[k] = yrd[k];
    }
}

static long long birlestirmeli_calistir()
{
    std::copy(g1.begin(), g1.begin() + n, is.begin());
    birlestirmeli(is, 0, n);
    return siralama_kontrol(is);
}

// --- 3) Öbek sıralaması (H7): en büyük öbek, aşağı süzme ---------------
static void asagi_suz(std::vector<int>& a, int i, int boy)
{
    for (;;) {
        int b = i, s = 2 * i + 1, r = 2 * i + 2;
        if (s < boy && a[s] > a[b]) {
            b = s;
        }
        if (r < boy && a[r] > a[b]) {
            b = r;
        }
        if (b == i) {
            return;
        }
        std::swap(a[i], a[b]);
        i = b;
    }
}

static long long obek_calistir()
{
    std::copy(g1.begin(), g1.begin() + n, is.begin());
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(is, i, n);
    }
    for (int son = n - 1; son > 0; son--) {
        std::swap(is[0], is[son]);
        asagi_suz(is, 0, son);
    }
    return siralama_kontrol(is);
}

// --- 4) Karma tablosu (H10): doğrusal yoklama, kapasite 2^k >= 2n -------
// kontrol = farklı anahtar + bulunan sorgu + toplam yoklama
static int karma_bit;

static void karma_hazirla()
{
    rastgele_tohum(4);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(0, n);           // tekrarlı anahtarlar
        g2[i] = rastgele_aralik(0, 2 * n);       // sorgular
    }
    karma_bit = 1;
    while ((1 << karma_bit) < 2 * n) {
        karma_bit++;
    }
}

static std::uint32_t karma(int anahtar)          // Fibonacci karması
{
    return static_cast<std::uint32_t>(static_cast<std::uint32_t>(anahtar) *
                                      2654435769u) >> (32 - karma_bit);
}

static long long karma_calistir()
{
    const int kap = 1 << karma_bit;
    std::vector<int> tablo(kap, -1);             // -1 = boş
    const std::uint32_t maske = static_cast<std::uint32_t>(kap - 1);
    long long farkli = 0, bulunan = 0, yoklama = 0;
    for (int i = 0; i < n; i++) {                // ekle (varsa geç)
        std::uint32_t h = karma(g1[i]);
        yoklama++;
        while (tablo[h] != -1 && tablo[h] != g1[i]) {
            h = (h + 1) & maske;
            yoklama++;
        }
        if (tablo[h] == -1) {
            tablo[h] = g1[i];
            farkli++;
        }
    }
    for (int q = 0; q < n; q++) {                // ara
        std::uint32_t h = karma(g2[q]);
        yoklama++;
        while (tablo[h] != -1 && tablo[h] != g2[q]) {
            h = (h + 1) & maske;
            yoklama++;
        }
        bulunan += tablo[h] == g2[q];
    }
    return farkli + bulunan + yoklama;
}

// --- Graf: V köşe, her köşeden 4 rastgele + (u+1) mod V kenarı (yönlü);
// komşular (v, w) artan sırada; CSR: köşe u'nun kenarları 5u..5u+4 -----
constexpr int DERECE = 5;

static void graf_hazirla()
{
    rastgele_tohum(5);
    for (int u = 0; u < n; u++) {
        int* v = &g1[DERECE * u];
        int* w = &g2[DERECE * u];
        for (int k = 0; k < DERECE; k++) {
            v[k] = k == 0 ? (u + 1) % n : rastgele_aralik(0, n - 1);
            w[k] = rastgele_aralik(1, 100);
        }
        for (int k = 1; k < DERECE; k++) {       // araya ekleme, (v, w)
            int tv = v[k], tw = w[k], j = k - 1;
            while (j >= 0 && (v[j] > tv || (v[j] == tv && w[j] > tw))) {
                v[j + 1] = v[j];
                w[j + 1] = w[j];
                j--;
            }
            v[j + 1] = tv;
            w[j + 1] = tw;
        }
    }
}

// --- 5) BFS (H11) 0'dan; kontrol = Σ (uzaklık + 1), ulaşılanlar --------
static long long bfs_calistir()
{
    std::vector<int> uz(n, -1);
    std::queue<int> kuyruk;                      // H9'un kuyruğu
    long long kontrol = 0;
    uz[0] = 0;
    kuyruk.push(0);
    while (!kuyruk.empty()) {
        int u = kuyruk.front();
        kuyruk.pop();
        kontrol += uz[u] + 1;
        for (int k = DERECE * u; k < DERECE * u + DERECE; k++) {
            if (uz[g1[k]] == -1) {
                uz[g1[k]] = uz[u] + 1;
                kuyruk.push(g1[k]);
            }
        }
    }
    return kontrol;
}

// --- 6) Dijkstra (H12), öncelik kuyruğu, tembel silme; (d, v) çiftleri -
static long long dijkstra_calistir()
{
    using Oge = std::pair<long long, int>;
    std::priority_queue<Oge, std::vector<Oge>, std::greater<Oge>> obek;
    std::vector<long long> uz(n, -1);            // -1 = sonsuz
    uz[0] = 0;
    obek.push({0, 0});
    long long kontrol = 0;
    while (!obek.empty()) {
        Oge en = obek.top();                     // en küçüğü çıkar
        obek.pop();
        if (en.first > uz[en.second]) {
            continue;                            // eskimiş öğe
        }
        kontrol += en.first;
        for (int k = DERECE * en.second; k < DERECE * en.second + DERECE;
             k++) {
            int v = g1[k];
            long long yeni = en.first + g2[k];
            if (uz[v] == -1 || yeni < uz[v]) {
                uz[v] = yeni;
                obek.push({yeni, v});
            }
        }
    }
    return kontrol;
}

// --- 7) LCS (H13): iki satırlı tablo; kontrol = LCS uzunluğu ----------
static void lcs_hazirla()
{
    rastgele_tohum(7);
    for (int i = 0; i < 2 * n; i++) {
        g1[i] = "ACGT"[rastgele_aralik(0, 3)];
    }
}

static long long lcs_calistir()
{
    std::vector<int> onceki(n + 1, 0), simdi(n + 1, 0);
    const int* a = &g1[0];
    const int* b = &g1[n];
    for (int i = 1; i <= n; i++) {
        simdi[0] = 0;
        for (int j = 1; j <= n; j++) {
            if (a[i - 1] == b[j - 1]) {
                simdi[j] = onceki[j - 1] + 1;
            } else {
                simdi[j] = onceki[j] >= simdi[j - 1] ? onceki[j]
                                                       : simdi[j - 1];
            }
        }
        std::swap(onceki, simdi);
    }
    return onceki[n];
}

// --- 8) 0/1 sırt çantası (H13): tek satır, kapasite TERS sırada -------
constexpr int SIRT_W = 1000;

static void sirt_hazirla()
{
    rastgele_tohum(8);
    for (int i = 0; i < n; i++) {
        g1[i] = rastgele_aralik(1, 50);          // ağırlık
        g2[i] = rastgele_aralik(1, 100);         // değer
    }
}

static long long sirt_calistir()
{
    std::vector<int> dp(SIRT_W + 1, 0);
    for (int i = 0; i < n; i++) {
        for (int c = SIRT_W; c >= g1[i]; c--) {
            if (dp[c - g1[i]] + g2[i] > dp[c]) {
                dp[c] = dp[c - g1[i]] + g2[i];
            }
        }
    }
    return dp[SIRT_W];
}

struct Cekirdek {
    const char* ad;
    const char* hafta;
    const char* aciklama;
    int boyut;                                   // ölçek 1'deki n
    void (*hazirla)();
    long long (*calistir)();
};

static const Cekirdek CEKIRDEK[8] = {
    {"ikili_arama", "H4", "n sorgu, sıralı n dizide", 20000,
     arama_hazirla, arama_calistir},
    {"birlestirmeli", "H6", "n sayı", 20000, siralama_hazirla,
     birlestirmeli_calistir},
    {"obek_siralama", "H7", "n sayı", 20000, siralama_hazirla,
     obek_calistir},
    {"karma_tablosu", "H10", "n ekleme + n arama", 20000, karma_hazirla,
     karma_calistir},
    {"bfs", "H11", "V = n, E = 5n", 20000, graf_hazirla, bfs_calistir},
    {"dijkstra", "H12", "V = n, E = 5n, w 1..100", 20000, graf_hazirla,
     dijkstra_calistir},
    {"lcs", "H13", "n × n tablo", 600, lcs_hazirla, lcs_calistir},
    {"sirt_cantasi", "H13", "n nesne, W = 1000", 100, sirt_hazirla,
     sirt_calistir},
};

static bool sayi_al(const char* s, int alt, int ust, int& deger)
{
    char* son;
    long v = std::strtol(s, &son, 10);
    if (*son != '\0' || v < alt || v > ust) {
        return false;
    }
    deger = static_cast<int>(v);
    return true;
}

int main(int argc, char* argv[])
{
    int olcek = 1, tekrar = 1;
    const char* csv = nullptr;
    for (int i = 1; i < argc; i++) {
        bool tamam = i + 1 < argc;
        if (tamam && std::strcmp(argv[i], "--olcek") == 0) {
            tamam = sayi_al(argv[++i], 1, 50, olcek);
        } else if (tamam && std::strcmp(argv[i], "--tekrar") == 0) {
            tamam = sayi_al(argv[++i], 1, 101, tekrar);
        } else if (tamam && std::strcmp(argv[i], "--csv") == 0) {
            csv = argv[++i];
        } else {
            tamam = false;
        }
        if (!tamam) {
            std::fprintf(stderr, "Kullanım: %s [--olcek K] [--tekrar T] "
                         "[--csv dosya]\n", argv[0]);
            return 2;
        }
    }
    std::FILE* f = nullptr;
    if (csv != nullptr) {
        f = std::fopen(csv, "a");
        if (f == nullptr) {
            std::fprintf(stderr, "%s açılamadı\n", csv);
            return 1;
        }
        if (std::ftell(f) == 0) {
            std::fprintf(f, "cekirdek;n;dil;tekrar;islemci_ms;kontrol\n");
        }
    }
    std::printf("Dönem kıyaslaması (ölçek %d): denetim toplamları\n", olcek);
    std::printf("  çekirdek        hafta         n              kontrol  "
                "boyut\n");
    for (const Cekirdek& k : CEKIRDEK) {
        n = k.boyut * olcek;
        const std::size_t boyut = static_cast<std::size_t>(DERECE) * n +
                                  SIRT_W + 2;
        g1.assign(boyut, 0);
        g2.assign(boyut, 0);
        is.assign(boyut, 0);
        yrd.assign(boyut, 0);
        k.hazirla();
        long long kontrol = k.calistir();        // ısınma + sonuç
        std::vector<double> sure;
        for (int t = 0; t < tekrar; t++) {
            double t0 = islemci_sn();
            long long k2 = k.calistir();
            sure.push_back(islemci_sn() - t0);
            if (k2 != kontrol) {
                kontrol = -2;                    // belirleyici değil!
            }
        }
        double ort = ortanca(sure);
        std::printf("  %-14s  %-5s  %8d  %19lld  %s\n", k.ad, k.hafta, n,
                    kontrol, k.aciklama);
        std::fprintf(stderr, "%-14s n = %8d: %10.3f ms (işlemci, ortanca, "
                     "%d tekrar; bu çalıştırmada)\n", k.ad, n, ort * 1e3,
                     tekrar);
        if (f != nullptr) {
            std::fprintf(f, "%s;%d;C++;%d;%.6f;%lld\n", k.ad, n, tekrar,
                         ort * 1e3, kontrol);
        }
    }
    if (f != nullptr) {
        std::fclose(f);
    }
    return 0;
}

/* Kütüphane karşılığı: C — bsearch, qsort; C++ — std::binary_search,
 * std::stable_sort, std::make_heap/std::sort_heap, std::unordered_set,
 * std::priority_queue; Python — bisect, sorted, heapq, set/dict. */

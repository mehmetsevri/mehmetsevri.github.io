/* H14_03_en_yakin_komsu.cpp — AP-2 Hafta 14 · Örnek 3 (★★)
 * Amaç    : Gezgin satıcı için en yakın komşu sezgiseli: her adımda
 *           ziyaret edilmemiş en yakın şehre git (eşitlikte KÜÇÜK indeks;
 *           karşılaştırma tamsayı kare uzaklıkla). Kaba kuvvetle
 *           karşılaştırma: LCG ile 100 örnekte yaklaşım oranı (en kötü,
 *           ortalama, ortanca); aday incelemesi n(n−1)/2 → Θ(n²)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_03_en_yakin_komsu.cpp -o H14_03_en_yakin_komsu
 * Çalıştır: ./H14_03_en_yakin_komsu
 * Eşleri  : c/H14_03_en_yakin_komsu.c · python/H14_03_en_yakin_komsu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "ortak_rastgele.hpp"

constexpr double EPS = 1e-9;
constexpr int ORNEK = 100;

static int n;
static std::vector<int> x, y;
static std::vector<std::vector<double>> d;
static long long aday_sayisi;      // en yakın komşunun incelediği aday

static long long d2(int i, int j)  // kare uzaklık: tam, eşitlik güvenli
{
    long long dx = x[i] - x[j], dy = y[i] - y[j];
    return dx * dx + dy * dy;
}

static void uzakliklari_hesapla()
{
    d.assign(n, std::vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            d[i][j] = std::sqrt(static_cast<double>(d2(i, j)));
        }
    }
}

static double tur_uzunlugu(const std::vector<int>& tur)
{
    double t = 0.0;
    for (int k = 1; k < n; k++) {
        t += d[tur[k - 1]][tur[k]];
    }
    return t + d[tur[n - 1]][tur[0]];            // dönüş kenarı
}

static void tur_yaz(const std::vector<int>& tur)
{
    for (int k = 0; k < n; k++) {
        std::printf("%d-", tur[k]);
    }
    std::printf("%d", tur[0]);
}

// En yakın komşu: bas'tan başla; ayrinti = true ise her adımı yaz
static void en_yakin_komsu(int bas, std::vector<int>& tur, bool ayrinti)
{
    std::vector<int> ziyaret(n, 0);
    tur.assign(n, 0);
    tur[0] = bas;
    ziyaret[bas] = 1;
    for (int k = 1; k < n; k++) {
        int son = tur[k - 1], sec = -1;
        long long en_az = 0;
        if (ayrinti) {
            std::printf("    %d     %d    ", k, son);
        }
        for (int s = 0; s < n; s++) {
            if (!ziyaret[s]) {
                long long dd = d2(son, s);
                aday_sayisi++;
                if (ayrinti) {
                    std::printf(" %d:%lld", s, dd);
                }
                if (sec == -1 || dd < en_az) {   // eşitlikte ilk (küçük)
                    sec = s;
                    en_az = dd;
                }
            }
        }
        if (ayrinti) {
            std::printf("  -> %d\n", sec);
        }
        tur[k] = sec;
        ziyaret[sec] = 1;
    }
}

// --- Kaba kuvvet (Örnek 2) -------------------------------------------
static std::vector<int> yol, kullanildi, en_iyi_tur;
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == n) {
        double toplam = kismi + d[yol[n - 1]][0];
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
            en_iyi_tur = yol;
        }
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

static double kaba_kuvvet()
{
    kullanildi.assign(n, 0);
    yol.assign(n, 0);
    kullanildi[0] = 1;
    en_iyi = 1e300;
    dene(1, 0.0);
    return en_iyi;
}

static void rastgele_sehirler(int adet)
{
    n = adet;
    x.assign(n, 0);
    y.assign(n, 0);
    for (int i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    uzakliklari_hesapla();
}

int main()
{
    std::vector<int> tur;
    x = {0, 6, 1, 5, 3};
    y = {0, 1, 4, 5, 2};
    n = 5;
    uzakliklari_hesapla();
    std::printf("1) Örnek 2'nin küçük örneği (n = 5), şehir 0'dan; aday "
                "s:d²\n");
    std::printf("  adım  son   adaylar              seçilen\n");
    aday_sayisi = 0;
    en_yakin_komsu(0, tur, true);
    double nn = tur_uzunlugu(tur), kb = kaba_kuvvet();
    std::printf("   NN turu: ");
    tur_yaz(tur);
    std::printf("  uzunluk %.2f\n   en iyi : ", nn);
    tur_yaz(en_iyi_tur);
    std::printf("  uzunluk %.2f\n   oran = %.4f; aday incelemesi = %lld = "
                "n(n-1)/2\n", kb, nn / kb, aday_sayisi);

    std::printf("\n2) LCG (tohum 2026), n = 8, %d örnek; oran = NN / en "
                "iyi\n", ORNEK);
    std::vector<std::vector<double>> oran(2, std::vector<double>(ORNEK));
    int esit[2] = {0, 0}, en_kotu_no = 0;
    double toplam[2] = {0.0, 0.0};
    std::vector<std::vector<int>> kx8(ORNEK), ky8(ORNEK);
    rastgele_tohum(2026);
    for (int t = 0; t < ORNEK; t++) {
        rastgele_sehirler(8);
        kx8[t] = x;
        ky8[t] = y;
        double opt = kaba_kuvvet();
        en_yakin_komsu(0, tur, false);
        oran[0][t] = tur_uzunlugu(tur) / opt;
        double en_iyi_bas = 1e300;              // her başlangıçtan NN
        for (int b = 0; b < n; b++) {
            en_yakin_komsu(b, tur, false);
            double u = tur_uzunlugu(tur);
            if (u < en_iyi_bas - EPS) {
                en_iyi_bas = u;
            }
        }
        oran[1][t] = en_iyi_bas / opt;
        for (int v = 0; v < 2; v++) {
            toplam[v] += oran[v][t];
            esit[v] += oran[v][t] < 1.0 + 1e-9;
        }
        if (oran[0][t] > oran[0][en_kotu_no]) {
            en_kotu_no = t;
        }
    }
    const char* ad[2] = {"NN (şehir 0'dan)     ", "NN (en iyi başlangıç)"};
    const double sinir[5] = {1.05, 1.10, 1.20, 1.30, 1e300};
    std::printf("                         en kötü  ortalama  ortanca  "
                "NN = en iyi\n");
    for (int v = 0; v < 2; v++) {
        std::vector<double> s = oran[v];
        std::sort(s.begin(), s.end());
        std::printf("   %s   %.4f    %.4f   %.4f   %3d / %d\n", ad[v],
                    s[ORNEK - 1], toplam[v] / ORNEK,
                    (s[ORNEK / 2 - 1] + s[ORNEK / 2]) / 2.0, esit[v], ORNEK);
    }
    std::printf("   dağılım (şehir 0'dan): = 1: %d", esit[0]);
    double alt = 1.0;
    for (int b = 0; b < 5; b++) {
        int say = 0;
        for (int t = 0; t < ORNEK; t++) {
            say += oran[0][t] >= 1.0 + 1e-9 && oran[0][t] > alt &&
                   oran[0][t] <= sinir[b];
        }
        if (b < 4) {
            std::printf(" · (%.2f, %.2f]: %d", alt, sinir[b], say);
        } else {
            std::printf(" · > %.2f: %d\n", alt, say);
        }
        alt = sinir[b];
    }

    std::printf("\n3) En kötü örnek: #%d (oran %.4f)\n   şehir:",
                en_kotu_no + 1, oran[0][en_kotu_no]);
    n = 8;
    x = kx8[en_kotu_no];
    y = ky8[en_kotu_no];
    for (int i = 0; i < n; i++) {
        std::printf(" %d(%d, %d)", i, x[i], y[i]);
    }
    uzakliklari_hesapla();
    en_yakin_komsu(0, tur, false);
    kb = kaba_kuvvet();
    std::printf("\n   NN    : ");
    tur_yaz(tur);
    std::printf("  uzunluk %.2f\n   en iyi: ", tur_uzunlugu(tur));
    tur_yaz(en_iyi_tur);
    std::printf("  uzunluk %.2f\n", kb);

    std::printf("\n4) Aday incelemesi n(n-1)/2: Θ(n²) (LCG, tohum 7)\n");
    std::printf("     n     aday  n(n-1)/2  NN uzunluğu\n");
    for (int adet = 10; adet <= 200; adet *= 2) {
        rastgele_tohum(7);
        rastgele_sehirler(adet);
        aday_sayisi = 0;
        en_yakin_komsu(0, tur, false);
        std::printf("  %4d  %7lld  %8d  %11.2f\n", n, aday_sayisi,
                    n * (n - 1) / 2, tur_uzunlugu(tur));
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: Örnek 2'nin kaba
 * kuvveti (n <= 10). */

/* H14_07_indirgeme.cpp — AP-2 Hafta 14 · Örnek 7 (★★)
 * Amaç    : İndirgeme (modelleme): yeni bir problemi BİLİNEN bir çözücüye
 *           çevirmek. (1) Sudoku → geri izleme (H3 Örnek 13); (2) labirent
 *           → ızgara grafında BFS (H11 Örnek 10); (3) ders planı → yönlü
 *           grafta topolojik sıralama (H11 Örnek 11, Kahn). Benzeri: sınav
 *           programı → graf boyama (H12 Örnek 13)
 * Kurallar: komşular artan köşe numarasıyla (yukarı, sol, sağ, aşağı);
 *           Kahn'da giriş derecesi 0 olanlardan EN KÜÇÜK numaralı seçilir
 *           (doğrusal tarama; V küçük); ders kodu → köşe: alfabetik sıra
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_07_indirgeme.cpp -o H14_07_indirgeme
 * Çalıştır: ./H14_07_indirgeme ../girdiler/H14_07_sudoku.txt \
 *           ../girdiler/H14_07_labirent.txt ../girdiler/H14_07_ders_plani.txt
 * Eşleri  : c/H14_07_indirgeme.c · python/H14_07_indirgeme.py
 * Çıktı   : üç dilde aynı (=); okunamayan/bozuk dosyada çıkış kodu 1
 */
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <queue>
#include <sstream>
#include <string>
#include <vector>

// Bir sonraki yorum olmayan, boş olmayan satırı okur (sondaki \r silinir)
static bool satir_al(std::ifstream& f, std::string& satir)
{
    while (std::getline(f, satir)) {
        if (!satir.empty() && satir.back() == '\r') {
            satir.pop_back();
        }
        if (!satir.empty() && satir[0] != '#') {
            return true;
        }
    }
    return false;
}

// Bir sonraki satırı olduğu gibi okur (ızgara satırı '#' ile başlayabilir)
static bool satir_ham(std::ifstream& f, std::string& satir)
{
    if (!std::getline(f, satir)) {
        return false;
    }
    if (!satir.empty() && satir.back() == '\r') {
        satir.pop_back();
    }
    return true;
}

// === 1) Sudoku -> geri izleme (H3 Örnek 13) ===========================
static int tablo[9][9];                  // 0 = boş kare
static bool satir_var[9][10], sutun_var[9][10], kutu_var[9][10];
static long long sudoku_dugum;

static int kutu_no(int r, int c)
{
    return (r / 3) * 3 + c / 3;
}

static void isaretle(int r, int c, int d, bool deger)
{
    satir_var[r][d] = deger;
    sutun_var[c][d] = deger;
    kutu_var[kutu_no(r, c)][d] = deger;
}

// Dönen: ipucu sayısı; -1 dosya yok, -2 biçim/kural hatası
static int sudoku_oku(const char* yol)
{
    std::ifstream f(yol);
    if (!f) {
        return -1;
    }
    std::string satir;
    int ipucu = 0;
    for (int r = 0; r < 9; r++) {
        if (!satir_al(f, satir) || satir.size() != 9) {
            return -2;
        }
        for (int c = 0; c < 9; c++) {
            int d = satir[c] == '.' ? 0 : satir[c] - '0';
            if (d < 0 || d > 9 || (satir[c] != '.' && d == 0)) {
                return -2;
            }
            if (d > 0) {
                if (satir_var[r][d] || sutun_var[c][d] ||
                    kutu_var[kutu_no(r, c)][d]) {
                    return -2;                   // ipuçları çelişiyor
                }
                isaretle(r, c, d, true);
                ipucu++;
            }
            tablo[r][c] = d;
        }
    }
    return ipucu;
}

// İlk boş kareyi (satır satır) bul; 1..9'u dene; çıkmazda geri al
static bool sudoku_coz(int konum)
{
    sudoku_dugum++;
    while (konum < 81 && tablo[konum / 9][konum % 9] != 0) {
        konum++;
    }
    if (konum == 81) {
        return true;                             // bütün kareler dolu
    }
    int r = konum / 9, c = konum % 9;
    for (int d = 1; d <= 9; d++) {
        if (!satir_var[r][d] && !sutun_var[c][d] &&
            !kutu_var[kutu_no(r, c)][d]) {
            tablo[r][c] = d;                     // seç
            isaretle(r, c, d, true);
            if (sudoku_coz(konum + 1)) {         // dene
                return true;
            }
            isaretle(r, c, d, false);            // geri al
            tablo[r][c] = 0;
        }
    }
    return false;
}

// Çözüm sayısı (en çok sinir'e kadar): bulmaca iyi tanımlı mı?
static int sudoku_say(int konum, int sinir)
{
    while (konum < 81 && tablo[konum / 9][konum % 9] != 0) {
        konum++;
    }
    if (konum == 81) {
        return 1;
    }
    int r = konum / 9, c = konum % 9, say = 0;
    for (int d = 1; d <= 9 && say < sinir; d++) {
        if (!satir_var[r][d] && !sutun_var[c][d] &&
            !kutu_var[kutu_no(r, c)][d]) {
            tablo[r][c] = d;
            isaretle(r, c, d, true);
            say += sudoku_say(konum + 1, sinir - say);
            isaretle(r, c, d, false);
            tablo[r][c] = 0;
        }
    }
    return say;
}

static void sudoku_yaz()
{
    for (int r = 0; r < 9; r++) {
        std::printf("   ");
        for (int c = 0; c < 9; c++) {
            std::printf("%c%s", tablo[r][c] ? '0' + tablo[r][c] : '.',
                        c == 8 ? "\n" : (c % 3 == 2 ? " | " : " "));
        }
        if (r % 3 == 2 && r < 8) {
            std::printf("   ------+-------+------\n");
        }
    }
}

// === 2) Labirent -> BFS (H11 Örnek 10) ================================
static std::vector<std::string> izgara;
static int R, C;

// Dönen: 0 başarı; -1 dosya yok, -2 biçim hatası (S ve E tek olmalı)
static int labirent_oku(const char* yol, int& bas, int& hedef)
{
    std::ifstream f(yol);
    if (!f) {
        return -1;
    }
    std::string satir;
    if (!satir_al(f, satir)) {
        return -2;
    }
    std::istringstream ss(satir);
    if (!(ss >> R >> C) || R < 1 || R > 32 || C < 1 || C > 64) {
        return -2;
    }
    bas = hedef = -1;
    izgara.assign(R, "");
    for (int r = 0; r < R; r++) {
        if (!satir_ham(f, satir) || static_cast<int>(satir.size()) != C) {
            return -2;
        }
        for (int c = 0; c < C; c++) {
            if (satir[c] == 'S') {
                bas = r * C + c;
            } else if (satir[c] == 'E') {
                hedef = r * C + c;
            }
        }
        izgara[r] = satir;
    }
    return bas >= 0 && hedef >= 0 ? 0 : -2;
}

// Ağırlıksız grafta BFS; köşe = r·C + c. Dönen: hedefe uzaklık (-1 yok)
static int bfs(int bas, int hedef, std::vector<int>& uzaklik,
               std::vector<int>& ebeveyn, int& ziyaret_sayisi)
{
    std::queue<int> kuyruk;                       // H9'un kuyruğu
    const int dr[4] = {-1, 0, 0, 1}, dc[4] = {0, -1, 1, 0};
    uzaklik.assign(R * C, -1);
    ebeveyn.assign(R * C, -1);
    uzaklik[bas] = 0;
    kuyruk.push(bas);
    ziyaret_sayisi = 0;
    while (!kuyruk.empty()) {
        int u = kuyruk.front();
        kuyruk.pop();
        ziyaret_sayisi++;
        if (u == hedef) {
            break;
        }
        for (int k = 0; k < 4; k++) {           // artan köşe numarası
            int r = u / C + dr[k], c = u % C + dc[k];
            if (r < 0 || r >= R || c < 0 || c >= C || izgara[r][c] == '#') {
                continue;
            }
            int v = r * C + c;
            if (uzaklik[v] == -1) {
                uzaklik[v] = uzaklik[u] + 1;
                ebeveyn[v] = u;
                kuyruk.push(v);
            }
        }
    }
    return uzaklik[hedef];
}

// === 3) Ders planı -> topolojik sıralama (H11 Örnek 11, Kahn) =========
static std::vector<std::string> kod;
static int V, E;
static std::vector<std::vector<int>> komsu;      // komşuluk matrisi

static int kod_bul(const std::string& k)         // yoksa -1
{
    for (int i = 0; i < V; i++) {
        if (kod[i] == k) {
            return i;
        }
    }
    return -1;
}

// İki geçiş: kodları topla ve alfabetik sırala (köşe numarası), sonra
// kenarları kur. Dönen: 0 başarı; -1 dosya yok, -2 biçim hatası
static int plan_oku(const char* yol)
{
    std::ifstream f(yol);
    if (!f) {
        return -1;
    }
    std::vector<std::pair<std::string, std::string>> ciftler;
    std::string satir;
    kod.clear();
    V = 0;
    E = 0;
    while (satir_al(f, satir)) {
        std::istringstream ss(satir);
        std::string a, b;
        if (E == 128 || !(ss >> a >> b) || a.size() >= 9 || b.size() >= 9) {
            return -2;
        }
        ciftler.push_back({a, b});
        E++;
        for (const std::string& k : {a, b}) {
            if (kod_bul(k) == -1) {
                if (V == 32) {
                    return -2;
                }
                kod.push_back(k);
                V++;
            }
        }
    }
    std::sort(kod.begin(), kod.end());           // araç: sıralama
    komsu.assign(V, std::vector<int>(V, 0));
    for (const auto& c : ciftler) {
        komsu[kod_bul(c.first)][kod_bul(c.second)] = 1;
    }
    return 0;
}

// Kahn: dönen sıralanan köşe sayısı (< V ise döngü var)
static int kahn(std::vector<int>& sira, std::vector<int>& donem)
{
    std::vector<int> giris(V, 0), alindi(V, 0);
    donem.assign(V, 1);
    sira.assign(V, -1);
    for (int u = 0; u < V; u++) {
        for (int v = 0; v < V; v++) {
            giris[v] += komsu[u][v];
        }
    }
    for (int k = 0; k < V; k++) {
        int sec = -1;
        for (int v = 0; v < V && sec == -1; v++) {   // en küçük numara
            if (!alindi[v] && giris[v] == 0) {
                sec = v;
            }
        }
        if (sec == -1) {
            return k;                            // döngü: kalanlar
        }
        alindi[sec] = 1;
        sira[k] = sec;
        for (int v = 0; v < V; v++) {
            if (komsu[sec][v]) {
                giris[v]--;
                if (donem[sec] + 1 > donem[v]) {
                    donem[v] = donem[sec] + 1;  // en uzun önkoşul zinciri
                }
            }
        }
    }
    return V;
}

static int hata(const char* yol, int kod_)
{
    std::fprintf(stderr, "%s: %s\n", yol, kod_ == -1 ? "dosya açılamadı"
                                                    : "biçim hatası");
    return 1;
}

int main(int argc, char* argv[])
{
    if (argc != 4) {
        std::fprintf(stderr, "Kullanım: %s sudoku.txt labirent.txt "
                     "plan.txt\n", argv[0]);
        return 2;
    }
    std::printf("1) Sudoku -> geri izleme (H3 Örnek 13)\n");
    std::printf("   Modelleme: boş kare = karar; aday = 1..9; kısıt = "
                "satır, sütun, 3x3 kutu\n");
    int ipucu = sudoku_oku(argv[1]);
    if (ipucu < 0) {
        return hata(argv[1], ipucu);
    }
    std::printf("   Bulmaca (%d ipucu, %d boş kare):\n", ipucu, 81 - ipucu);
    sudoku_yaz();
    std::printf("   çözüm sayısı (2'de durur): %d\n", sudoku_say(0, 2));
    sudoku_dugum = 0;
    bool cozuldu = sudoku_coz(0);
    std::printf("   %s (ziyaret edilen düğüm = %lld):\n",
                cozuldu ? "Çözüm" : "Çözüm yok", sudoku_dugum);
    if (cozuldu) {
        sudoku_yaz();
    }

    std::printf("\n2) Labirent -> BFS (H11 Örnek 10)\n");
    std::printf("   Modelleme: boş hücre = köşe (r*C + c); yatay/dikey komşu "
                "boş hücre = kenar;\n   ağırlıksız en kısa yol = BFS\n");
    int bas = -1, hedef = -1, ziyaret = 0;
    int k = labirent_oku(argv[2], bas, hedef);
    if (k < 0) {
        return hata(argv[2], k);
    }
    int kose = 0, kenar = 0;
    for (int r = 0; r < R; r++) {
        for (int c = 0; c < C; c++) {
            if (izgara[r][c] != '#') {
                kose++;
                kenar += c + 1 < C && izgara[r][c + 1] != '#';
                kenar += r + 1 < R && izgara[r + 1][c] != '#';
            }
        }
    }
    std::vector<int> uzaklik, ebeveyn;
    int u = bfs(bas, hedef, uzaklik, ebeveyn, ziyaret);
    std::printf("   %d x %d ızgara: köşe = %d, kenar = %d; S = (%d, %d) köşe "
                "%d, E = (%d, %d) köşe %d\n", R, C, kose, kenar, bas / C,
                bas % C, bas, hedef / C, hedef % C, hedef);
    if (u < 0) {
        std::printf("   E'ye yol yok (ziyaret edilen köşe = %d)\n", ziyaret);
    } else {
        std::printf("   en kısa yol = %d adım; kuyruktan çıkan köşe = %d\n",
                    u, ziyaret);
        for (int v = ebeveyn[hedef]; v != bas; v = ebeveyn[v]) {
            izgara[v / C][v % C] = '*';
        }
        for (const std::string& s : izgara) {
            std::printf("   %s\n", s.c_str());
        }
    }

    std::printf("\n3) Ders planı -> topolojik sıralama (H11 Örnek 11, "
                "Kahn)\n");
    std::printf("   Modelleme: ders kodu = köşe (alfabetik numara); \"A B\" "
                "satırı = A -> B kenarı;\n   geçerli plan = topolojik sıra; "
                "döngü varsa plan yok\n");
    k = plan_oku(argv[3]);
    if (k < 0) {
        return hata(argv[3], k);
    }
    std::printf("   köşe = %d, kenar = %d:", V, E);
    for (int v = 0; v < V; v++) {
        std::printf(" %d %s%s", v, kod[v].c_str(), v + 1 < V ? "," : "\n");
    }
    std::vector<int> sira, donem;
    int s = kahn(sira, donem);
    if (s < V) {
        std::printf("   döngü var: yalnız %d ders sıralanabildi; plan yok\n",
                    s);
        return 0;
    }
    std::printf("   topolojik sıra:");
    for (int t = 0; t < V; t++) {
        std::printf(" %s", kod[sira[t]].c_str());
    }
    std::printf("\n   dönemler (en erken dönem = en uzun önkoşul zinciri + "
                "1):\n");
    for (int d = 1; d <= V; d++) {
        bool var = false;
        for (int t = 0; t < V; t++) {
            if (donem[sira[t]] == d) {
                if (!var) {
                    std::printf("     %d. dönem:", d);
                }
                std::printf(" %s", kod[sira[t]].c_str());
                var = true;
            }
        }
        if (var) {
            std::printf("\n");
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (Boost.Graph:
 * topological_sort); Python — graphlib.TopologicalSorter (3.9+; yalnızca
 * kâhin). Sıralama (qsort / std::sort / sorted) burada yalnız araçtır. */

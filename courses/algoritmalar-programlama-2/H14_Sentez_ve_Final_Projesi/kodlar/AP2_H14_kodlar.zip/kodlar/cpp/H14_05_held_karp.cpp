/* H14_05_held_karp.cpp — AP-2 Hafta 14 · Örnek 5 (★★★, merak)
 * Amaç    : Held–Karp: gezgin satıcı için bit maskesi DP'si. Üstel ama
 *           kaba kuvvetten çok hızlı: Θ(n²·2ⁿ) geçiş, n·2ⁿ tablo.
 *           n <= 10'da kaba kuvvetle (Örnek 2) aynı sonuç; tablo kesiti;
 *           bellek hesabı. İsteğe bağlı: --n N (4 <= N <= 16) tek ölçüm
 * DP      : durum dp[S][j] = 0'dan başlayıp S kümesindeki şehirleri birer
 *           kez gezerek j'de biten en kısa yol (0, j ∈ S) · geçiş dp[S][j]
 *           = min_i dp[S − {j}][i] + d(i, j) · temel dp[{0}][0] = 0 ·
 *           sıra S artan (alt küme her zaman daha küçük sayı) · cevap
 *           min_j dp[tümü][j] + d(j, 0) · geri çıkarma ebeveyn[S][j]
 *           (eşitlikte küçük i: katı "<")
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_05_held_karp.cpp -o H14_05_held_karp
 * Çalıştır: ./H14_05_held_karp        ./H14_05_held_karp --n 16
 * Eşleri  : c/H14_05_held_karp.c · python/H14_05_held_karp.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

constexpr int MAKS_N = 16;
constexpr int KB_MAKS = 10;
constexpr double EPS = 1e-9;
constexpr double SONSUZ = 1e300;

static int n;
static std::vector<int> x, y;
static std::vector<std::vector<double>> d;

static std::vector<double> dp;           // (1 << n) * n
static std::vector<signed char> ebeveyn;
static long long durum, gecis;           // hesaplanan dp[S][j]; geçiş

static void uzakliklari_hesapla()
{
    d.assign(n, std::vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            double dx = x[i] - x[j], dy = y[i] - y[j];
            d[i][j] = std::sqrt(dx * dx + dy * dy);
        }
    }
}

static void tur_yaz(const std::vector<int>& tur)
{
    for (int k = 0; k < n; k++) {
        std::printf("%d-", tur[k]);
    }
    std::printf("0");
}

// Tablolar vektörlerdedir (RAII); yeni çağrıda yeniden boyutlanır
static double held_karp(std::vector<int>& tur)
{
    const std::size_t boyut = (std::size_t{1} << n) * n;
    dp.assign(boyut, SONSUZ);
    ebeveyn.assign(boyut, -1);
    dp[1 * n + 0] = 0.0;                         // S = {0}, j = 0
    durum = 0;
    gecis = 0;
    for (int S = 1; S < (1 << n); S += 2) {      // 0'ı içeren kümeler
        for (int j = 1; j < n; j++) {
            if (!(S & (1 << j))) {
                continue;
            }
            int onceki = S ^ (1 << j);
            double en = SONSUZ;
            int arg = -1;
            for (int i = 0; i < n; i++) {
                if (!(onceki & (1 << i)) || dp[onceki * n + i] >= SONSUZ) {
                    continue;
                }
                double aday = dp[onceki * n + i] + d[i][j];
                gecis++;
                if (aday < en) {
                    en = aday;
                    arg = i;
                }
            }
            dp[S * n + j] = en;
            ebeveyn[S * n + j] = static_cast<signed char>(arg);
            durum++;
        }
    }
    int tum = (1 << n) - 1, son = -1;
    double en = SONSUZ;
    for (int j = 1; j < n; j++) {
        double aday = dp[tum * n + j] + d[j][0];
        if (aday < en) {
            en = aday;
            son = j;
        }
    }
    tur.assign(n, 0);
    int S = tum;
    for (int k = n - 1; k >= 1; k--) {           // geri çıkarma
        tur[k] = son;
        int i = ebeveyn[S * n + son];
        S ^= 1 << son;
        son = i;
    }
    tur[0] = son;                                // 0 olmalı
    return en;
}

// --- Kaba kuvvet (Örnek 2) -------------------------------------------
static std::vector<int> yol, kullanildi, kb_tur;
static double en_iyi;

static void dene(int k, double kismi)
{
    if (k == n) {
        double toplam = kismi + d[yol[n - 1]][0];
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
            kb_tur = yol;
        }
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);
            kullanildi[s] = 0;
        }
    }
}

static double kaba_kuvvet()
{
    kullanildi.assign(n, 0);
    yol.assign(n, 0);
    kullanildi[0] = 1;
    en_iyi = SONSUZ;
    dene(1, 0.0);
    return en_iyi;
}

static void sehirleri_kur(int adet, std::uint64_t tohum)
{
    n = adet;
    rastgele_tohum(tohum);
    x.assign(n, 0);
    y.assign(n, 0);
    for (int i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    uzakliklari_hesapla();
}

static void kume_yaz(int S)
{
    std::string metin = "{";
    for (int i = 0; i < n; i++) {
        if (S & (1 << i)) {
            metin += (metin.size() > 1 ? "," : "") + std::to_string(i);
        }
    }
    metin += "}";
    std::printf("  %-11s", metin.c_str());
}

static int tek_olcum(int adet)
{
    std::vector<int> tur;
    sehirleri_kur(adet, 42);
    double t0 = islemci_sn();
    double u = held_karp(tur);
    double sure = islemci_sn() - t0;
    std::printf("n = %d: uzunluk %.2f, durum %lld, geçiş %lld; tur ", n, u,
                durum, gecis);
    tur_yaz(tur);
    std::printf("\n");
    std::fprintf(stderr, "Held-Karp n = %d: %.3f ms (işlemci, bu "
                 "çalıştırmada)\n", n, sure * 1e3);
    return 0;
}

int main(int argc, char* argv[])
{
    if (argc == 3 && std::strcmp(argv[1], "--n") == 0) {
        char* son;
        long v = std::strtol(argv[2], &son, 10);
        if (*son != '\0' || v < 4 || v > MAKS_N) {
            std::fprintf(stderr, "Kullanım: %s [--n N]  (4 <= N <= 16)\n",
                         argv[0]);
            return 2;
        }
        return tek_olcum(static_cast<int>(v));
    } else if (argc != 1) {
        std::fprintf(stderr, "Kullanım: %s [--n N]  (4 <= N <= 16)\n",
                     argv[0]);
        return 2;
    }

    std::vector<int> tur;
    x = {0, 6, 1, 5, 3};
    y = {0, 1, 4, 5, 2};
    n = 5;
    uzakliklari_hesapla();
    double u = held_karp(tur);
    std::printf("1) Örnek 2'nin küçük örneği (n = 5): dp[S][j] tablosu "
                "(- = tanımsız)\n");
    std::printf("  S               j=1     j=2     j=3     j=4    ebeveyn "
                "(j=1..4)\n");
    for (int S = 1; S < (1 << n); S += 2) {
        kume_yaz(S);
        for (int j = 1; j < n; j++) {
            if (dp[S * n + j] >= SONSUZ) {
                std::printf("  %6s", "-");
            } else {
                std::printf("  %6.2f", dp[S * n + j]);
            }
        }
        std::printf("   ");
        for (int j = 1; j < n; j++) {
            std::printf(" %2d", ebeveyn[S * n + j]);
        }
        std::printf("\n");
    }
    std::printf("  cevap = min_j dp[{0..4}][j] + d(j, 0) = %.2f; tur ", u);
    tur_yaz(tur);
    std::printf("\n  durum = %lld = (n-1)·2^(n-2); geçiş = %lld\n", durum,
                gecis);

    std::printf("\n2) LCG şehirleri (tohum 42; Örnek 2 ile aynı "
                "örnekler)\n");
    std::printf("   n   durum    geçiş     n²·2ⁿ  Held-Karp  kaba kuvvet  "
                "sonuç\n");
    for (int adet = 4; adet <= 16; adet++) {
        sehirleri_kur(adet, 42);
        double t0 = islemci_sn();
        u = held_karp(tur);
        double sure = islemci_sn() - t0;
        std::printf("  %2d  %6lld  %7lld  %8ld  %9.2f", n, durum, gecis,
                    static_cast<long>(n) * n * (1L << n), u);
        if (n <= KB_MAKS) {
            double kb = kaba_kuvvet();
            std::printf("  %11.2f  %s\n", kb,
                        std::fabs(kb - u) < 1e-6 ? "aynı" : "FARKLI");
        } else {
            std::printf("  %11s  -\n", "-");
        }
        std::fprintf(stderr, "n = %2d: Held-Karp %.3f ms (işlemci, bu "
                     "çalıştırmada)\n", adet, sure * 1e3);
    }
    std::printf("   n = 16 turu: ");
    sehirleri_kur(16, 42);
    held_karp(tur);
    tur_yaz(tur);
    std::printf("\n");

    std::printf("\n3) Bellek: n·2ⁿ tablo hücresi × (8 bayt dp + 1 bayt "
                "ebeveyn)\n");
    std::printf("   n  tablo hücresi n·2ⁿ      bellek\n");
    const int nler[8] = {10, 12, 14, 16, 18, 20, 25, 30};
    for (int k = 0; k < 8; k++) {
        double h = static_cast<double>(nler[k]) * std::pow(2.0, nler[k]);
        double mib = h * 9.0 / 1048576.0;
        std::printf("  %2d  %18.0f  %10.1f MiB\n", nler[k], h, mib);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (C, C++, Python). Kâhin: Örnek 2'nin kaba
 * kuvveti (n <= 10). Uygulamada kesin çözücüler (ör. Concorde) dal-kesme
 * yöntemleri kullanır; Held–Karp ders kitabı ölçeğinde bir DP'dir. */

/* H14_02_gs_kaba_kuvvet.cpp — AP-2 Hafta 14 · Örnek 2 (★★)
 * Amaç    : Gezgin satıcı, kaba kuvvet: şehir 0 sabit, 1..n−1'in bütün
 *           permütasyonları H3'ün üreticisiyle SÖZLÜK SIRASINDA denenir;
 *           denenen tur = (n − 1)!, ters turlar aynı uzunlukta (simetri)
 * Kurallar: tamsayı koordinatlar, Öklid uzaklığı sqrt; tur uzunluğu
 *           şehir 0'dan başlayıp soldan sağa toplanır; eşitlikte (fark
 *           < 1e-9) sözlük sırasında İLK bulunan tur korunur
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H14_02_gs_kaba_kuvvet.cpp -o H14_02_gs_kaba_kuvvet
 * Çalıştır: ./H14_02_gs_kaba_kuvvet        (süreler stderr'e)
 * Eşleri  : c/H14_02_gs_kaba_kuvvet.c · python/H14_02_gs_kaba_kuvvet.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

constexpr double EPS = 1e-9;

static int n;
static std::vector<int> x, y;
static std::vector<std::vector<double>> d;   // Öklid uzaklığı

static std::vector<int> yol;                  // kurulmakta olan tur
static std::vector<int> kullanildi;
static std::vector<int> en_iyi_tur;
static double en_iyi;
static long long tur_sayisi, cagri_sayisi;
static bool yaz_mi = false, yalniz_yari = false;  // yol[1] < yol[n-1]

static void uzakliklari_hesapla()
{
    d.assign(n, std::vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            double dx = x[i] - x[j], dy = y[i] - y[j];
            d[i][j] = std::sqrt(dx * dx + dy * dy);
        }
    }
}

static void tur_yaz(const std::vector<int>& tur)
{
    for (int k = 0; k < n; k++) {
        std::printf("%d-", tur[k]);
    }
    std::printf("0");
}

// yol[0..k-1] dolu (yol[0] = 0); kismi = yol boyunca uzunluk
static void dene(int k, double kismi)
{
    cagri_sayisi++;
    if (k == n) {                                    // yaprak: tam tur
        if (yalniz_yari && yol[1] > yol[n - 1]) {
            return;                                  // tersi zaten sayıldı
        }
        double toplam = kismi + d[yol[n - 1]][0];    // dönüş kenarı
        tur_sayisi++;
        if (yaz_mi) {
            std::printf("    %3lld  ", tur_sayisi);
            tur_yaz(yol);
            std::printf("  %7.2f\n", toplam);
        }
        if (toplam < en_iyi - EPS) {
            en_iyi = toplam;
            en_iyi_tur = yol;
        }
        return;
    }
    for (int s = 1; s < n; s++) {
        if (!kullanildi[s]) {
            kullanildi[s] = 1;                       // seç
            yol[k] = s;
            dene(k + 1, kismi + d[yol[k - 1]][s]);   // dene
            kullanildi[s] = 0;                       // geri al
        }
    }
}

static void kaba_kuvvet()
{
    kullanildi.assign(n, 0);
    yol.assign(n, 0);
    kullanildi[0] = 1;
    en_iyi = 1e300;
    tur_sayisi = 0;
    cagri_sayisi = 0;
    dene(1, 0.0);
}

static void sehirleri_kur(int adet, std::uint64_t tohum)
{
    n = adet;
    rastgele_tohum(tohum);
    x.assign(n, 0);
    y.assign(n, 0);
    for (int i = 0; i < n; i++) {
        x[i] = rastgele_aralik(0, 99);
        y[i] = rastgele_aralik(0, 99);
    }
    uzakliklari_hesapla();
}

int main()
{
    x = {0, 6, 1, 5, 3};
    y = {0, 1, 4, 5, 2};
    n = 5;
    uzakliklari_hesapla();
    std::printf("1) Küçük örnek: n = 5 şehir\n   şehir:");
    for (int i = 0; i < n; i++) {
        std::printf("  %d(%d, %d)", i, x[i], y[i]);
    }
    std::printf("\n   d[i][j]  :");
    for (int j = 0; j < n; j++) {
        std::printf(" %6d", j);
    }
    std::printf("\n");
    for (int i = 0; i < n; i++) {
        std::printf("   %d        :", i);
        for (int j = 0; j < n; j++) {
            std::printf(" %6.2f", d[i][j]);
        }
        std::printf("\n");
    }
    std::printf("   Turlar (şehir 0 sabit; 1..4 sözlük sırasıyla):\n");
    std::printf("     no  tur          uzunluk\n");
    yaz_mi = true;
    kaba_kuvvet();
    yaz_mi = false;
    std::printf("   denenen tur = %lld = 4!; çağrı = %lld\n", tur_sayisi,
                cagri_sayisi);
    std::printf("   en iyi: ");
    tur_yaz(en_iyi_tur);
    std::printf("  uzunluk %.2f\n", en_iyi);
    yalniz_yari = true;
    kaba_kuvvet();
    yalniz_yari = false;
    std::printf("   yol[1] < yol[n-1] olanlar (her tur ile tersinden biri): "
                "%lld = 4!/2\n", tur_sayisi);

    std::printf("\n2) LCG şehirleri (tohum 42, koordinat 0..99)\n");
    std::printf("   n  denenen tur     (n-1)!      çağrı   en iyi   "
                "en iyi tur\n");
    long long faktoriyel = 2;                       // (3 - 1)!
    for (int adet = 4; adet <= 10; adet++) {
        faktoriyel *= adet - 1;
        sehirleri_kur(adet, 42);
        double t0 = islemci_sn();
        kaba_kuvvet();
        double sure = islemci_sn() - t0;
        std::printf("  %2d  %11lld  %9lld  %9lld  %7.2f   ", n, tur_sayisi,
                    faktoriyel, cagri_sayisi, en_iyi);
        tur_yaz(en_iyi_tur);
        std::printf("%s\n", tur_sayisi == faktoriyel ? "" : "  FARKLI");
        std::fprintf(stderr, "n = %2d: %.3f ms (işlemci, bu çalıştırmada)\n",
                     adet, sure * 1e3);
    }

    std::printf("\n3) Simetri: n = 10'da yalnız yol[1] < yol[9] olan "
                "turlar\n");
    double tam = en_iyi;
    yalniz_yari = true;
    kaba_kuvvet();
    std::printf("   değerlendirilen tur = %lld = 9!/2; en iyi = %.2f (%s)\n",
                tur_sayisi, en_iyi,
                std::fabs(en_iyi - tam) < 1e-6 ? "aynı" : "FARKLI");
    std::printf("   (yapraklar yine üretildi: çağrı = %lld; gerçek kazanç "
                "için dal erken kesilmeli)\n", cagri_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::next_permutation (sözlük
 * sırasında sonraki); Python — itertools.permutations (yalnızca kâhin). */

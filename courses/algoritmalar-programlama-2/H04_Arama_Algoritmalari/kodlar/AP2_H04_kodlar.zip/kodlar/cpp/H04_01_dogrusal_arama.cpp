/* H04_01_dogrusal_arama.cpp — AP-2 Hafta 4 · Örnek 1 (★)
 * Amaç    : Doğrusal arama: ilk konum, "bulunamadı" sözleşmesi (-1);
 *           sıralı dizide erken çıkış ve karşılaştırma sayacı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_01_dogrusal_arama.cpp -o H04_01_dogrusal_arama
 * Çalıştır: ./H04_01_dogrusal_arama
 * Eşleri  : c/H04_01_dogrusal_arama.c · python/H04_01_dogrusal_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

static const int N_BUYUK = 1000;

static long karsilastirma = 0;  // incelenen eleman sayısı

// x'in a[0..n-1] içindeki İLK konumu; x yoksa -1 ("bulunamadı").
// Değişmez: döngü başında x, a[0..i-1] içinde yok.
static long dogrusal_ara(const std::vector<int>& a,
                         int x)
{
    for (std::size_t i = 0; i < a.size(); i++) {
        karsilastirma++;
        if (a[i] == x) {
            return static_cast<long>(i);
        }
    }
    return -1;
}

// Ön koşul: a artan sıralı. a[i] >= x görülünce durulur: x varsa
// buradadır, yoksa ileride de olamaz (erken çıkış).
// Değişmez: döngü başında a[0..i-1] < x.
static long sirali_dogrusal_ara(const std::vector<int>& a, int x)
{
    for (std::size_t i = 0; i < a.size(); i++) {
        karsilastirma++;               // bir eleman: bir sayım
        if (a[i] >= x) {
            return a[i] == x ? static_cast<long>(i) : -1;
        }
    }
    return -1;
}

static void dizi_yaz(const std::string& ad, const std::vector<int>& a)
{
    std::cout << ad << " = [";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << a[i];
    }
    std::cout << "]   (n = " << a.size() << ")\n";
}

static void sonuc_yaz(int x, long k)
{
    if (k == -1) {
        std::cout << "  x = " << std::setw(2) << x << ": bulunamadı";
    } else {
        std::cout << "  x = " << std::setw(2) << x << ": konum " << k;
    }
    std::cout << ", karşılaştırma " << karsilastirma << "\n";
}

static void kisa_yaz(const std::string& ad, long k)
{
    std::cout << "  " << ad << " ";
    if (k == -1) {
        std::cout << "yok";
    } else {
        std::cout << k;
    }
    std::cout << " (" << karsilastirma << ")";
}

int main()
{
    const std::vector<int> a = {7, 3, 9, 3, 5, 1, 8};
    const std::vector<int> sorgu_a = {7, 3, 8, 6};
    const std::vector<int> b = {1, 3, 3, 5, 7, 8, 9};
    const std::vector<int> sorgu_b = {4, 9, 10, 0};
    std::vector<int> c(N_BUYUK);

    std::cout << "1) Sırasız dizide doğrusal arama (ilk konum)\n";
    dizi_yaz("a", a);
    for (int x : sorgu_a) {
        karsilastirma = 0;
        long k = dogrusal_ara(a, x);
        sonuc_yaz(x, k);
    }
    karsilastirma = 0;
    std::cout << "  boş dizi:";
    sonuc_yaz(7, dogrusal_ara(std::vector<int>(), 7));

    std::cout << "\n2) Sıralı dizide erken çıkış\n";
    dizi_yaz("b", b);
    std::cout << "  konum (karşılaştırma)\n";
    for (int x : sorgu_b) {
        std::cout << "  x = " << std::setw(2) << x << ":";
        karsilastirma = 0;
        kisa_yaz("dogrusal_ara", dogrusal_ara(b, x));
        karsilastirma = 0;
        kisa_yaz("sirali_dogrusal_ara", sirali_dogrusal_ara(b, x));
        std::cout << "\n";
    }

    std::cout << "\n3) Ortalama karşılaştırma: c[i] = 2i + 1, n = "
              << N_BUYUK << "\n";
    for (int i = 0; i < N_BUYUK; i++) {
        c[i] = 2 * i + 1;
    }
    // top: dogrusal başarılı, başarısız; sirali başarılı, başarısız
    long top[4] = {0, 0, 0, 0};
    for (int i = 0; i <= N_BUYUK; i++) {
        if (i < N_BUYUK) {         // başarılı: tek sayılar c[i]
            karsilastirma = 0;
            dogrusal_ara(c, c[i]);
            top[0] += karsilastirma;
            karsilastirma = 0;
            sirali_dogrusal_ara(c, c[i]);
            top[2] += karsilastirma;
        }
        karsilastirma = 0;         // başarısız: çift sayılar 0..2n
        dogrusal_ara(c, 2 * i);
        top[1] += karsilastirma;
        karsilastirma = 0;
        sirali_dogrusal_ara(c, 2 * i);
        top[3] += karsilastirma;
    }
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "  yöntem                 başarılı (n)  başarısız (n + 1)\n";
    std::cout << "  dogrusal_ara        " << std::setw(12)
              << static_cast<double>(top[0]) / N_BUYUK << " "
              << std::setw(17)
              << static_cast<double>(top[1]) / (N_BUYUK + 1) << "\n";
    std::cout << "  sirali_dogrusal_ara " << std::setw(12)
              << static_cast<double>(top[2]) / N_BUYUK << " "
              << std::setw(17)
              << static_cast<double>(top[3]) / (N_BUYUK + 1) << "\n";
    std::cout << "  kuram: başarılı (n + 1) / 2 = " << (N_BUYUK + 1) / 2.0
              << "; başarısız n = " << N_BUYUK
              << " (erken çıkışla ≈ n / 2)\n";
    return 0;
}

/* Kütüphane karşılığı: C — standart C'de yok (POSIX lfind);
 * C++ — std::find (bulamazsa end()); Python — a.index(x) (bulamazsa
 * ValueError), x in a. */

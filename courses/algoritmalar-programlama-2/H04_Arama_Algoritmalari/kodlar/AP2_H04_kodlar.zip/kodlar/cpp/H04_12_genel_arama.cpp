/* H04_12_genel_arama.cpp — AP-2 Hafta 4 · Örnek 12 (★★★)
 * Amaç    : Genel (generic) ikili arama: şablon + "küçüktür" yüklemi
 *           (lambda) ile struct dizisinde arama; ada göre arama, önek
 *           araması (lower_bound); kâhin: std::lower_bound
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_12_genel_arama.cpp -o H04_12_genel_arama
 * Çalıştır: ./H04_12_genel_arama
 * Eşleri  : c/H04_12_genel_arama.c · python/H04_12_genel_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <cstdio>
#include <string>
#include <vector>

struct ogrenci {
    int numara;
    std::string ad;
    double ortalama;
};

static long yoklama = 0;        // karşılaştırma adımı (yoklama)

// Karşılaştırıcı sözleşmesi: "küçüktür" yüklemi (katı zayıf sıralama).
// kucuk(a, b) == false ve kucuk(b, a) == false ise a ile b eşdeğerdir.
static bool numara_kucuk(const ogrenci& a, const ogrenci& b)
{
    return a.numara < b.numara;
}

static bool ad_kucuk(const ogrenci& a, const ogrenci& b)
{
    return a.ad < b.ad;
}

// Genel ikili arama: T ve Kucuk derleme zamanında belirlenir (şablon).
// Ön koşul: a, kucuk'a göre sıralı.
template <class T, class Kucuk>
long genel_ara(const T& anahtar,
               const std::vector<T>& a, Kucuk kucuk)
{
    std::size_t lo = 0, hi = a.size();
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (kucuk(a[mid], anahtar)) {
            lo = mid + 1;   // anahtar > öge
        } else if (kucuk(anahtar, a[mid])) {
            hi = mid;       // anahtar < öge
        } else {
            return static_cast<long>(mid);  // eşdeğer
        }
    }
    return -1;
}

// Genel lower_bound: kucuk(öge, anahtar) yanlış olan ilk konum (ya da n)
template <class T, class Kucuk>
std::size_t genel_alt_sinir(const T& anahtar, const std::vector<T>& a,
                            Kucuk kucuk)
{
    std::size_t lo = 0, hi = a.size();
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (kucuk(a[mid], anahtar)) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

// Ön koşul denetimi: dizi kucuk'a göre artan (eşitler serbest) mı?
template <class T, class Kucuk>
bool sirali_mi(const std::vector<T>& a, Kucuk kucuk)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (kucuk(a[i], a[i - 1])) {
            return false;
        }
    }
    return true;
}

static void kayit_yaz(const ogrenci& o)
{
    std::printf("%d %-6s %.2f", o.numara, o.ad.c_str(), o.ortalama);
}

// Kâhin: std::lower_bound + eşdeğerlik denetimi (yalnızca test için)
template <class T, class Kucuk>
long kahin(const T& anahtar, const std::vector<T>& a, Kucuk kucuk)
{
    auto it = std::lower_bound(a.begin(), a.end(), anahtar, kucuk);
    if (it == a.end() || kucuk(anahtar, *it)) {
        return -1;
    }
    return static_cast<long>(it - a.begin());
}

int main()
{
    const std::vector<ogrenci> kayitlar = {         // numaraya göre
        {1001, "Kerem", 2.85}, {1004, "Ayla", 3.40}, {1009, "Zeynep", 3.75},
        {1013, "Can", 2.10}, {1020, "Selin", 3.05}, {1027, "Ali", 3.90},
        {1031, "Ece", 2.60}, {1046, "Tolga", 3.20}, {1052, "Deniz", 2.95},
        {1068, "Emre", 3.55}};
    const std::vector<ogrenci> ada_gore = {         // ada göre
        {1027, "Ali", 3.90}, {1004, "Ayla", 3.40}, {1013, "Can", 2.10},
        {1052, "Deniz", 2.95}, {1031, "Ece", 2.60}, {1068, "Emre", 3.55},
        {1001, "Kerem", 2.85}, {1020, "Selin", 3.05}, {1046, "Tolga", 3.20},
        {1009, "Zeynep", 3.75}};
    const std::vector<int> numaralar = {1027, 1030, 1001, 1068};
    const std::vector<std::string> adlar = {"Selin", "Ayse", "Zeynep"};

    std::printf("Kayıtlar (numaraya göre):\n");
    for (std::size_t i = 0; i < kayitlar.size(); i++) {
        std::printf("  [%zu] ", i);
        kayit_yaz(kayitlar[i]);
        std::printf("\n");
    }
    std::printf("numaraya göre sıralı mı? %s; ada göre kopya sıralı mı? %s\n",
                sirali_mi(kayitlar, numara_kucuk) ? "evet" : "HAYIR",
                sirali_mi(ada_gore, ad_kucuk) ? "evet" : "HAYIR");

    std::printf("\nNumaraya göre arama\n");
    bool kahin_ayni = true;
    for (int no : numaralar) {
        ogrenci anahtar = {no, "", 0.0};
        yoklama = 0;
        long k = genel_ara(anahtar, kayitlar, numara_kucuk);
        std::printf("  numara %d: ", no);
        if (k >= 0) {
            std::printf("konum %ld -> ", k);
            kayit_yaz(kayitlar[k]);
        } else {
            std::printf("bulunamadı");
        }
        std::printf(" (%ld yoklama)\n", yoklama);
        kahin_ayni = kahin_ayni && kahin(anahtar, kayitlar, numara_kucuk) == k;
    }

    std::printf("\nAda göre arama (aynı genel_ara, başka "
                "karşılaştırıcı)\n");
    for (const std::string& ad : adlar) {
        ogrenci anahtar = {0, ad, 0.0};
        yoklama = 0;
        // Yüklem lambda olarak da verilebilir (adsız fonksiyon):
        long k = genel_ara(anahtar, ada_gore,
                           [](const ogrenci& a, const ogrenci& b) {
                               return a.ad < b.ad;
                           });
        std::printf("  ad %-6s: ", ad.c_str());
        if (k >= 0) {
            std::printf("konum %ld -> ", k);
            kayit_yaz(ada_gore[k]);
        } else {
            std::printf("bulunamadı");
        }
        std::printf(" (%ld yoklama)\n", yoklama);
        kahin_ayni = kahin_ayni && kahin(anahtar, ada_gore, ad_kucuk) == k;
    }

    std::printf("\nÖnek araması: \"E\" ile başlayan adlar (lower_bound + "
                "tarama)\n");
    ogrenci onek = {0, "E", 0.0};
    yoklama = 0;
    std::size_t i = genel_alt_sinir(onek, ada_gore, ad_kucuk);
    std::printf("  lower_bound konum %zu (%ld yoklama); eşleşenler:", i,
                yoklama);
    for (; i < ada_gore.size() &&
           ada_gore[i].ad.compare(0, onek.ad.size(), onek.ad) == 0;
         i++) {
        std::printf(" %s", ada_gore[i].ad.c_str());
    }
    std::printf("\nkâhin (bsearch / std::lower_bound / bisect) ile aynı mı? "
                "%s\n", kahin_ayni ? "evet" : "HAYIR");
    return 0;
}

/* Kütüphane karşılığı: C — bsearch(anahtar, taban, n, boyut, kars)
 * (bulunan ögenin işaretçisi ya da NULL; eşitlerden hangisi döneceği
 * belirsiz); C++ — std::lower_bound, std::binary_search (lambda ile
 * "küçüktür"); Python — bisect.bisect_left(a, x, key=...) (3.10+). */

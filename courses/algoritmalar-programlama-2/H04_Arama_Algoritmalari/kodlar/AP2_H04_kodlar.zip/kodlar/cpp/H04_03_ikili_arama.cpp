/* H04_03_ikili_arama.cpp — AP-2 Hafta 4 · Örnek 3 (★)
 * Amaç    : İkili arama, yinelemeli, kapalı aralık [lo, hi]: her adımda
 *           aday aralık yarıya iner; yoklama sayısı <= ⌊log2 n⌋ + 1
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_03_ikili_arama.cpp -o H04_03_ikili_arama
 * Çalıştır: ./H04_03_ikili_arama
 * Eşleri  : c/H04_03_ikili_arama.c · python/H04_03_ikili_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdio>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

static long yoklama = 0;        // incelenen a[mid] sayısı

// Ön koşul: a[0..n-1] artan sıralı. x'in konumu ya da -1.
// Değişmez: x dizideyse a[lo..hi] içindedir.
static long ikili_ara(const std::vector<int>& a, int x)
{
    long lo = 0, hi = static_cast<long>(a.size()) - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2; // taşmasız
        yoklama++;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;   // a[lo..mid] elendi
        } else {
            hi = mid - 1;   // a[mid..hi] elendi
        }
    }
    return -1;                          // aralık boş: lo == hi + 1
}

// Aynı algoritma; her adımı yazar (elle izleme tablosu)
static long ikili_ara_izle(const std::vector<int>& a, int x)
{
    long lo = 0, hi = static_cast<long>(a.size()) - 1;
    int adim = 0;
    std::printf("x = %d\n  adım  lo  hi  mid  a[mid]  karar\n", x);
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        adim++;
        std::printf("  %4d %3ld %3ld %4ld %7d  ", adim, lo, hi, mid, a[mid]);
        if (a[mid] == x) {
            std::printf("a[mid] == x: bulundu\n");
            return mid;
        } else if (a[mid] < x) {
            std::printf("a[mid] < x: lo = %ld\n", mid + 1);
            lo = mid + 1;
        } else {
            std::printf("a[mid] > x: hi = %ld\n", mid - 1);
            hi = mid - 1;
        }
    }
    std::printf("  lo = %ld > hi = %ld: aralık boş, bulunamadı\n", lo, hi);
    return -1;
}

// 2^k <= n olan en büyük k (n >= 1): ⌊log2 n⌋
static int taban_log2(std::size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main()
{
    const std::vector<int> a = {3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61,
                                67, 73, 80, 88, 95};
    const std::vector<int> sorgular = {61, 45, 3, 95};
    const std::vector<std::size_t> boyutlar = {1, 2, 3, 4, 5, 7, 8, 15, 16,
                                               17, 100, 1000, 1023, 1024,
                                               4096};

    std::cout << "a = [";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? ", " : "") << a[i];
    }
    std::cout << "]   (n = " << a.size() << ")\n";
    for (std::size_t t = 0; t < 2; t++) {
        ikili_ara_izle(a, sorgular[t]);
    }
    for (int x : sorgular) {
        yoklama = 0;
        long k = ikili_ara(a, x);
        std::cout << "ikili_ara(" << x << ") = " << k << "   yoklama = "
                  << yoklama << "\n";
    }
    yoklama = 0;
    long bos = ikili_ara(std::vector<int>(), 7);
    std::cout << "boş dizi: ikili_ara(7) = " << bos << "   yoklama = "
              << yoklama << "\n";

    std::cout << "\nTüm sorgular, b[i] = 2i + 1:\n"
                 "  B (başarılı) : x = b[i], n sorgu\n"
                 "  S (başarısız): x = 0, 2, …, 2n, n + 1 sorgu\n";
    std::cout << "     n  en çok B  en çok S  ortalama B  ⌊log2 n⌋+1  "
                 "doğru\n";
    std::vector<int> b;
    for (std::size_t m : boyutlar) {
        b.assign(m, 0);
        for (std::size_t i = 0; i < m; i++) {
            b[i] = static_cast<int>(2 * i + 1);
        }
        long en_cok_b = 0, en_cok_s = 0, toplam_b = 0;
        bool dogru = true;
        for (std::size_t i = 0; i <= 2 * m; i++) {
            int x = static_cast<int>(i);
            long beklenen = (x % 2 == 1) ? (x - 1) / 2 : -1;
            yoklama = 0;
            if (ikili_ara(b, x) != beklenen) {
                dogru = false;
            }
            if (beklenen >= 0) {
                toplam_b += yoklama;
                en_cok_b = yoklama > en_cok_b ? yoklama : en_cok_b;
            } else {
                en_cok_s = yoklama > en_cok_s ? yoklama : en_cok_s;
            }
        }
        std::printf("%6zu %9ld %9ld %11.3f %11d  %s\n", m, en_cok_b,
                    en_cok_s, static_cast<double>(toplam_b) / m,
                    taban_log2(m) + 1, dogru ? "evet" : "HAYIR");
    }

    const std::size_t milyon = 1000000;
    b.assign(milyon, 0);
    for (std::size_t i = 0; i < milyon; i++) {
        b[i] = static_cast<int>(2 * i + 1);
    }
    rastgele_tohum(42);
    long en_cok = 0;
    for (int q = 0; q < 1000; q++) {    // yarısı başarılı, yarısı değil
        int r = rastgele_aralik(0, static_cast<int>(milyon) - 1);
        int x = (q % 2 == 0) ? 2 * r + 1 : 2 * r;
        yoklama = 0;
        ikili_ara(b, x);
        en_cok = yoklama > en_cok ? yoklama : en_cok;
    }
    std::cout << "\nn = " << milyon << ", 1000 sorgu (LCG, tohum 42): en çok "
              << en_cok << " yoklama; ⌊log2 n⌋ + 1 = "
              << taban_log2(milyon) + 1 << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — bsearch (stdlib.h; void * ve karşılaştırıcı,
 * Örnek 12); C++ — std::binary_search (yalnız var/yok),
 * std::lower_bound; Python — bisect.bisect_left. */

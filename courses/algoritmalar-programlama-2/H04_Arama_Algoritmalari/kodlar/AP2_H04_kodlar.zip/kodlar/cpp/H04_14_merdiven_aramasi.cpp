/* H04_14_merdiven_aramasi.cpp — AP-2 Hafta 4 · Örnek 14 (★★★)
 * Amaç    : Satırları ve sütunları sıralı matriste merdiven araması:
 *           sağ üst köşeden başla, her adımda bir satır ya da bir sütun
 *           ele; en çok m + n - 1 adım. Satır satır ikili aramayla kıyas
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_14_merdiven_aramasi.cpp -o H04_14_merdiven_aramasi
 * Çalıştır: ./H04_14_merdiven_aramasi
 * Eşleri  : c/H04_14_merdiven_aramasi.c ·
 *           python/H04_14_merdiven_aramasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdio>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

using Matris = std::vector<std::vector<int>>;

static long adim = 0;           // incelenen hücre sayısı

// m x n matris: satırlar ve sütunlar kesin artan:
// a[r][c] = max(üst, sol) + 1..4.
static Matris matris_uret(std::size_t m, std::size_t n)
{
    Matris a(m, std::vector<int>(n));
    for (std::size_t r = 0; r < m; r++) {
        for (std::size_t c = 0; c < n; c++) {
            int ust = r > 0 ? a[r - 1][c] : 0;
            int sol = c > 0 ? a[r][c - 1] : 0;
            a[r][c] = (ust > sol ? ust : sol) + rastgele_aralik(1, 4);
        }
    }
    return a;
}

// Ön koşul: her satır soldan sağa, her sütun yukarıdan aşağıya artan.
// Değişmez: x matristeyse a[r..m-1][0..c] alt matrisindedir.
// Bulunursa true döndürür ve konumu kon'a yazar.
static bool merdiven_ara(const Matris& a, int x,
                         std::pair<std::size_t, std::size_t>& kon)
{
    std::size_t m = a.size(), n = m > 0 ? a[0].size() : 0;
    std::size_t r = 0, c = n;   // c: sütun + 1 (size_t)
    while (r < m && c > 0) {
        int v = a[r][c - 1];
        adim++;
        if (v == x) {
            kon = {r, c - 1};
            return true;
        } else if (v > x) {
            c--;            // sütunu ele
        } else {
            r++;            // satırı ele
        }
    }
    return false;
}

// Aynı arama; her adımı yazar
static void merdiven_izle(const Matris& a, int x)
{
    std::size_t m = a.size(), n = a[0].size();
    std::size_t r = 0, c = n;
    int k = 0;
    std::printf("x = %d\n  adım  (r, c)  a[r][c]  karar\n", x);
    while (r < m && c > 0) {
        int v = a[r][c - 1];
        std::printf("  %4d  (%zu, %zu)  %7d  ", ++k, r, c - 1, v);
        if (v == x) {
            std::printf("bulundu\n");
            return;
        } else if (v > x) {
            std::printf("> x: sola (sütun %zu elendi)\n", c - 1);
            c--;
        } else {
            std::printf("< x: aşağı (satır %zu elendi)\n", r);
            r++;
        }
    }
    std::printf("  matristen çıkıldı (r = %zu, c = %ld): x yok\n", r,
                static_cast<long>(c) - 1);
}

// Karşılaştırma için: her satırda ikili arama, en çok m(⌊log2 n⌋+1)
static bool satir_ikili_ara(const Matris& a, int x)
{
    for (const std::vector<int>& satir : a) {
        std::size_t lo = 0, hi = satir.size();
        while (lo < hi) {
            std::size_t mid = lo + (hi - lo) / 2;
            int v = satir[mid];
            adim++;
            if (v == x) {
                return true;
            } else if (v < x) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
    }
    return false;
}

int main()
{
    const std::vector<std::pair<std::size_t, std::size_t>> boyutlar = {
        {5, 6}, {10, 10}, {100, 100}, {4, 1000}, {1000, 4}};
    rastgele_tohum(42);
    Matris a = matris_uret(5, 6);
    std::printf("Matris (%zu x %zu), satırlar ve sütunlar artan:\n",
                a.size(), a[0].size());
    for (const std::vector<int>& satir : a) {
        std::printf("  ");
        for (int v : satir) {
            std::printf("%4d", v);
        }
        std::printf("\n");
    }
    merdiven_izle(a, 15);
    merdiven_izle(a, 19);

    std::printf("\nTüm x (en küçük - 1 .. en büyük + 1), kâhin: değer "
                "tablosu\n");
    std::printf("  boyut       sorgu  hatalı  merdiven en çok  m + n - 1"
                "  satır satır ikili en çok\n");
    for (const auto& [m, n] : boyutlar) {
        rastgele_tohum(42);
        a = matris_uret(m, n);
        int en_buyuk = a[m - 1][n - 1];
        std::vector<char> var(en_buyuk + 2, 0);     // kâhin tablosu
        for (const std::vector<int>& satir : a) {
            for (int v : satir) {
                var[v] = 1;
            }
        }
        long sorgu = 0, hata = 0, en_cok = 0, en_cok_satir = 0;
        for (int x = a[0][0] - 1; x <= en_buyuk + 1; x++) {
            std::pair<std::size_t, std::size_t> kon{0, 0};
            adim = 0;
            bool bulundu = merdiven_ara(a, x, kon);
            sorgu++;
            bool olmali = x >= 0 && x <= en_buyuk && var[x];
            if (bulundu != olmali ||
                (bulundu && a[kon.first][kon.second] != x)) {
                hata++;
            }
            en_cok = adim > en_cok ? adim : en_cok;
            adim = 0;
            satir_ikili_ara(a, x);
            en_cok_satir = adim > en_cok_satir ? adim : en_cok_satir;
        }
        std::printf("  %4zu x %-4zu %6ld %7ld %16ld %10zu %25ld\n", m, n,
                    sorgu, hata, en_cok, m + n - 1, en_cok_satir);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (satır başına
 * std::lower_bound yazılabilir); Python — yok (satır başına bisect). */

/* H04_11_ikiye_bolme.cpp — AP-2 Hafta 4 · Örnek 11 (★★)
 * Amaç    : Gerçel sayılarda ikili arama: ikiye bölme (bisection) ile
 *           x^3 - x - 2 = 0 kökü; tolerans, yineleme sayısı, kayan nokta
 *           sınırı (aralık artık bölünemiyor)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_11_ikiye_bolme.cpp -o H04_11_ikiye_bolme
 * Çalıştır: ./H04_11_ikiye_bolme
 * Eşleri  : c/H04_11_ikiye_bolme.c · python/H04_11_ikiye_bolme.py
 * Çıktı   : üç dilde aynı (=) — aynı IEEE 754 double işlemleri, aynı sıra
 */
#include <cstdio>
#include <string>
#include <vector>

static const int EN_COK_YINELEME = 200;

static int yineleme = 0;        // f(m) değerlendirme sayısı
static std::string durma;       // durma nedeni
static int denklem = 1;         // 1: x^3 - x - 2; 2: x^2 - 2 (kök √2)

static double f(double x)
{
    if (denklem == 2) {
        return x * x - 2.0;
    }
    return x * x * x - x - 2.0;
}

// Ön koşul: f sürekli, f(a) ve f(b) ters işaretli => [a, b]'de kök var.
// Değişmez: f(a) ile f(b) ters işaretli (kök [a, b] içinde).
// Durma: b - a <= tol, f(m) == 0 ya da aralık bölünemez olunca.
static double ikiye_bolme(double a, double b, double tol, bool yaz)
{
    double fa = f(a);
    yineleme = 0;
    durma = "tolerans";
    while (b - a > tol && yineleme < EN_COK_YINELEME) {
        double m = a + (b - a) / 2;
        if (m <= a || m >= b) {         // a ile b komşu double: dur
            durma = "kayan nokta sınırı";
            break;
        }
        double fm = f(m);
        yineleme++;
        if (yaz) {
            std::printf("  %2d  %.9f  %.9f  %.9f  %10.3e\n", yineleme, a, b,
                        m, fm);
        }
        if (fm == 0.0) {                // double'da tam sıfır
            durma = "f(m) == 0";
            return m;
        }
        if ((fa < 0.0) == (fm < 0.0)) { // kök sağ yarıda
            a = m;
            fa = fm;
        } else {                        // kök sol yarıda
            b = m;
        }
    }
    return a + (b - a) / 2;
}

// (b - a) / 2^k <= tol olan en küçük k: kuramsal yineleme sayısı
static int kuramsal_yineleme(double genislik, double tol)
{
    int k = 0;
    while (genislik > tol) {
        genislik /= 2;
        k++;
    }
    return k;
}

int main()
{
    const std::vector<double> toleranslar = {1e-2, 1e-4, 1e-6, 1e-8, 1e-10,
                                             1e-12, 1e-15, 1e-16, 1e-20};
    std::printf("f(x) = x^3 - x - 2,  f(1) = %.1f,  f(2) = %.1f\n", f(1.0),
                f(2.0));
    std::printf("tol = 1e-6 ile adımlar\n   k  a            b            m"
                "            f(m)\n");
    double kok = ikiye_bolme(1.0, 2.0, 1e-6, true);
    std::printf("kök ≈ %.9f  (%d yineleme)\n\n", kok, yineleme);

    std::printf("       tol  yineleme  ⌈log2(1/tol)⌉  kök              "
                "durma\n");
    for (double tol : toleranslar) {
        kok = ikiye_bolme(1.0, 2.0, tol, false);
        std::printf("  %8.0e  %8d  %13d  %.15f  %s\n", tol, yineleme,
                    kuramsal_yineleme(1.0, tol), kok, durma.c_str());
    }
    kok = ikiye_bolme(1.0, 2.0, 1e-15, false);
    std::printf("\nx^3 - x - 2, tol = 1e-15: f(kök) = %.3e\n", f(kok));
    kok = ikiye_bolme(1.0, 2.0, 0.0, false);
    std::printf("x^3 - x - 2, tol = 0    : %d yineleme, durma: %s\n",
                yineleme, durma.c_str());
    denklem = 2;
    kok = ikiye_bolme(1.0, 2.0, 0.0, false);
    std::printf("x^2 - 2,     tol = 0    : %d yineleme, durma: %s\n",
                yineleme, durma.c_str());
    std::printf("                          kök = %.15f, f(kök) = %.3e\n",
                kok, f(kok));
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (C++20 std::midpoint yalnız
 * orta noktayı taşmasız verir); Python — yok (SciPy'deki
 * scipy.optimize.bisect üçüncü taraf kitaplık, derste kullanılmaz). */

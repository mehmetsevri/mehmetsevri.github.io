/* H04_07_alt_ust_sinir.cpp — AP-2 Hafta 4 · Örnek 7 (★★)
 * Amaç    : lower_bound (ilk a[i] >= x) ve upper_bound (ilk a[i] > x);
 *           ilk/son konum ve tekrar sayısı = upper - lower; kâhin testi
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_07_alt_ust_sinir.cpp -o H04_07_alt_ust_sinir
 * Çalıştır: ./H04_07_alt_ust_sinir
 * Eşleri  : c/H04_07_alt_ust_sinir.c · python/H04_07_alt_ust_sinir.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cstddef>
#include <cstdio>
#include <vector>

#include "ortak_rastgele.hpp"

static long yoklama = 0;        // incelenen a[mid] sayısı

// lower_bound: ilk a[i] >= x konumu; hepsi < x ise n.
// Değişmez: a[0..lo-1] < x <= a[hi..n-1]
static std::size_t alt_sinir(const std::vector<int>& a, int x)
{
    std::size_t lo = 0, hi = a.size();
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

// upper_bound: ilk a[i] > x konumu; hepsi <= x ise n.
// Değişmez: a[0..lo-1] <= x < a[hi..n-1]
static std::size_t ust_sinir(const std::vector<int>& a, int x)
{
    std::size_t lo = 0, hi = a.size();
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] <= x) {  // tek fark: <=
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

// Kâhin: std::lower_bound / std::upper_bound yineleyici döndürür;
// başlangıçtan uzaklık konumdur (yalnızca test için kullanılır).
static std::size_t kahin_kucuk_say(const std::vector<int>& a, int x,
                                   bool esit_dahil)
{
    auto it = esit_dahil ? std::upper_bound(a.begin(), a.end(), x)
                         : std::lower_bound(a.begin(), a.end(), x);
    return static_cast<std::size_t>(it - a.begin());
}

// Aynı arama; her adımı yazar (ust = false: alt_sinir, true: ust_sinir)
static void sinir_izle(const std::vector<int>& a, int x, bool ust)
{
    std::size_t lo = 0, hi = a.size();
    std::printf("%s(%d)\n  lo  hi  mid  a[mid]  karar\n",
                ust ? "ust_sinir" : "alt_sinir", x);
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        bool sola = ust ? a[mid] <= x : a[mid] < x;
        std::printf("  %2zu  %2zu  %3zu  %6d  a[mid] %s x: ", lo, hi, mid,
                    a[mid], ust ? (sola ? "<=" : "> ")
                                : (sola ? "< " : ">="));
        if (sola) {
            std::printf("lo = %zu\n", mid + 1);
            lo = mid + 1;
        } else {
            std::printf("hi = %zu\n", mid);
            hi = mid;
        }
    }
    std::printf("  sonuç: %zu\n", lo);
}

int main()
{
    const std::vector<int> a = {1, 2, 2, 2, 4, 4, 7, 9, 9, 9, 9, 12};
    const std::vector<int> sorgular = {0, 1, 2, 3, 4, 5, 7, 9, 12, 13};

    std::printf("a = [");
    for (std::size_t i = 0; i < a.size(); i++) {
        std::printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    std::printf("]   (n = %zu)\n", a.size());
    std::printf("   x  alt  üst  adet  ilk  son  yoklama (alt + üst)\n");
    for (int x : sorgular) {
        yoklama = 0;
        std::size_t alt = alt_sinir(a, x);
        long y1 = yoklama;
        yoklama = 0;
        std::size_t ust = ust_sinir(a, x);
        std::size_t adet = ust - alt;
        std::printf("  %2d  %3zu  %3zu  %4zu  ", x, alt, ust, adet);
        if (adet > 0) {
            std::printf("%3zu  %3zu", alt, ust - 1);
        } else {
            std::printf("yok  yok");
        }
        std::printf("  %ld + %ld\n", y1, yoklama);
    }
    sinir_izle(a, 9, false);
    sinir_izle(a, 9, true);

    // Büyük dizi: b[i] = i / 10, her değer 10 kez
    const std::size_t m = 1000000;
    std::vector<int> b(m);
    for (std::size_t i = 0; i < m; i++) {
        b[i] = static_cast<int>(i / 10);
    }
    yoklama = 0;
    std::size_t alt = alt_sinir(b, 12345), ust = ust_sinir(b, 12345);
    std::printf("\nb[i] = i / 10, n = %zu: 12345 değeri %zu kez (konum "
                "%zu..%zu), %ld yoklama\n", m, ust - alt, alt, ust - 1,
                yoklama);

    // Kâhinle karşılaştırmalı rastgele test (tekrarlı sıralı diziler)
    long sorgu = 0, uyusmazlik = 0;
    rastgele_tohum(42);
    for (int deneme = 0; deneme < 200; deneme++) {
        std::size_t k = static_cast<std::size_t>(rastgele_aralik(0, 60));
        std::vector<int> c(k);
        int deger = 0;
        for (std::size_t i = 0; i < k; i++) {
            deger += rastgele_aralik(0, 2);     // 0: tekrar eden değer
            c[i] = deger;
        }
        for (int q = 0; q < 50; q++) {
            int x = rastgele_aralik(-1, deger + 1);
            sorgu++;
            if (alt_sinir(c, x) != kahin_kucuk_say(c, x, false) ||
                ust_sinir(c, x) != kahin_kucuk_say(c, x, true)) {
                uyusmazlik++;
            }
        }
    }
    std::printf("Kâhinle karşılaştırma: 200 rastgele dizi, %ld sorgu, "
                "uyuşmazlık %ld\n", sorgu, uyusmazlik);
    return 0;
}

/* Kütüphane karşılığı: C — yok (bsearch yalnız "herhangi bir" eşit
 * elemanı bulur); C++ — std::lower_bound, std::upper_bound,
 * std::equal_range; Python — bisect.bisect_left, bisect.bisect_right. */

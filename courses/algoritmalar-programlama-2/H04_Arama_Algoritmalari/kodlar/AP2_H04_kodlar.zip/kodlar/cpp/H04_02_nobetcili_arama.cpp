/* H04_02_nobetcili_arama.cpp — AP-2 Hafta 4 · Örnek 2 (★)
 * Amaç    : Nöbetçili (sentinel) doğrusal arama: x dizinin sonuna
 *           yazılır, döngüdeki sınır denetimi (i < n) kalkar
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_02_nobetcili_arama.cpp -o H04_02_nobetcili_arama
 * Çalıştır: ./H04_02_nobetcili_arama
 * Eşleri  : c/H04_02_nobetcili_arama.c · python/H04_02_nobetcili_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

static long indis_kars = 0;     // i < n karşılaştırmaları
static long eleman_kars = 0;    // a[i] == x karşılaştırmaları

// Standart doğrusal arama: her adımda İKİ karşılaştırma.
static long dogrusal_ara(const std::vector<int>& a, std::size_t n, int x)
{
    std::size_t i = 0;
    while (i < n) {
        indis_kars++;
        eleman_kars++;
        if (a[i] == x) {
            return static_cast<long>(i);
        }
        i++;
    }
    indis_kars++;               // döngüyü bitiren i < n (yanlış)
    return -1;
}

// Nöbetçili arama. Ön koşul: a[n] yazılabilir boş bir yer.
// x a[n]'ye yazıldığı için döngü x'i MUTLAKA bulur: i < n gerekmez.
static long nobetcili_ara(std::vector<int>& a, std::size_t n, int x)
{
    int eski = a[n];
    a[n] = x;               // nöbetçi
    std::size_t i = 0;
    eleman_kars++;
    while (a[i] != x) {
        i++;
        eleman_kars++;
    }
    a[n] = eski;            // geri yükle
    indis_kars++;           // tek sınır denetimi
    return i < n ? static_cast<long>(i) : -1;
}

static void yaz(const std::string& ad, long k)
{
    std::cout << "  " << ad << " -> ";
    if (k == -1) {
        std::cout << "yok     ";
    } else {
        std::cout << "konum " << k;
    }
    std::cout << "  indis " << indis_kars << " + eleman " << eleman_kars
              << " = " << indis_kars + eleman_kars << "\n";
}

int main()
{
    const std::vector<int> ilk = {12, 45, 7, 23, 56, 89, 34, 11, 70, 5};
    const std::vector<int> sorgular = {34, 12, 99};
    const std::vector<std::size_t> boyutlar = {10, 100, 1000, 10000,
                                               100000, 1000000};
    std::size_t n = ilk.size();
    std::vector<int> a = ilk;
    a.push_back(0);             // nöbetçi yeri (dizinin parçası değil)

    std::cout << "a = [";
    for (std::size_t i = 0; i < n; i++) {
        std::cout << (i > 0 ? ", " : "") << a[i];
    }
    std::cout << "]   (n = " << n << ", kapasite n + 1)\n";
    for (int x : sorgular) {
        std::cout << "x = " << x << "\n";
        indis_kars = eleman_kars = 0;
        yaz("dogrusal_ara ", dogrusal_ara(a, n, x));
        indis_kars = eleman_kars = 0;
        yaz("nobetcili_ara", nobetcili_ara(a, n, x));
    }
    std::cout << "a[" << n << "] (nöbetçi yeri) aramalardan sonra: " << a[n]
              << "\n\n";

    std::cout << "Başarısız arama (en kötü durum): toplam karşılaştırma\n";
    std::cout << "        n  dogrusal  2n + 1  nobetcili   n + 2   oran\n";
    for (std::size_t m : boyutlar) {
        n = m;
        a.assign(n + 1, 0);     // n eleman + nöbetçi yeri
        for (std::size_t i = 0; i < n; i++) {
            a[i] = static_cast<int>(2 * i + 1);  // tek sayılar; aranan çift
        }
        indis_kars = eleman_kars = 0;
        dogrusal_ara(a, n, 0);
        long d = indis_kars + eleman_kars;
        indis_kars = eleman_kars = 0;
        nobetcili_ara(a, n, 0);
        long s = indis_kars + eleman_kars;
        std::printf("%9zu %9ld %7zu %10ld %7zu %6.3f\n", n, d, 2 * n + 1, s,
                    n + 2, static_cast<double>(d) / s);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX lfind; nöbetçi kullanmaz);
 * C++ — std::find; Python — a.index(x), x in a (C'de yazılmış döngü). */

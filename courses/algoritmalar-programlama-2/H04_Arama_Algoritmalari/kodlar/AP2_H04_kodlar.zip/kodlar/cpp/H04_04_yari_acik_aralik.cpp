/* H04_04_yari_acik_aralik.cpp — AP-2 Hafta 4 · Örnek 4 (★★)
 * Amaç    : İkili arama, yarı açık aralık [lo, hi): değişmezi assert ile
 *           denetleyerek tasarım; sonlanma denetimi; ekleme konumu
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_04_yari_acik_aralik.cpp -o H04_04_yari_acik_aralik
 * Çalıştır: ./H04_04_yari_acik_aralik      [bozuk: sırasız dizi, assert]
 * Eşleri  : c/H04_04_yari_acik_aralik.c ·
 *           python/H04_04_yari_acik_aralik.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cassert>
#include <cstddef>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

static long yoklama = 0;        // incelenen a[mid] sayısı
static long denetim = 0;        // değişmez denetimi sayısı

// Değişmez (yalnız hata ayıklama; O(n) maliyetli):
// 0 <= lo <= hi <= n, a[0..lo-1] < x ve a[hi..n-1] > x
static bool degismez_mi(const std::vector<int>& a, std::size_t lo,
                        std::size_t hi, int x)
{
    denetim++;
    if (lo > hi || hi > a.size()) {
        return false;
    }
    for (std::size_t i = 0; i < lo; i++) {
        if (a[i] >= x) {
            return false;
        }
    }
    for (std::size_t i = hi; i < a.size(); i++) {
        if (a[i] <= x) {
            return false;
        }
    }
    return true;
}

// Ön koşul: a[0..n-1] artan sıralı. x'in konumu ya da -1.
// Sözleşme: aday bölge a[lo..hi-1]; hi aralığa DAHİL DEĞİL.
static long ikili_ara_yari(const std::vector<int>& a, int x)
{
    std::size_t lo = 0, hi = a.size();  // başlangıç: tüm dizi [0, n)
    while (lo < hi) {                   // aralık boş değil
        assert(degismez_mi(a, lo, hi, x));
        std::size_t mid = lo + (hi - lo) / 2;   // lo <= mid < hi
        std::size_t eski = hi - lo;
        yoklama++;
        if (a[mid] == x) {
            return static_cast<long>(mid);
        } else if (a[mid] < x) {
            lo = mid + 1;               // a[lo..mid] < x
        } else {
            hi = mid;                   // a[mid..hi-1] > x
        }
        assert(hi - lo < eski);         // sonlanma: aralık daraldı
        (void)eski;                     // -DNDEBUG ile uyarı olmasın
    }
    assert(degismez_mi(a, lo, hi, x));
    return -1;                          // lo == hi: x buraya eklenir
}

// Aynı algoritma; her adımda üç bölgeyi ve değişmezi yazar
static long ikili_ara_yari_izle(const std::vector<int>& a, int x)
{
    std::size_t lo = 0, hi = a.size(), n = a.size();
    std::printf("x = %d\n  lo  hi  mid  a[mid]   <x | aday | >x  değişmez"
                "  karar\n", x);
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        bool d = degismez_mi(a, lo, hi, x);
        std::printf("  %2zu  %2zu  %3zu  %6d  %4zu | %4zu | %2zu  %-8s  ",
                    lo, hi, mid, a[mid], lo, hi - lo, n - hi,
                    d ? "evet" : "HAYIR");
        if (a[mid] == x) {
            std::printf("bulundu\n");
            return static_cast<long>(mid);
        } else if (a[mid] < x) {
            std::printf("lo = mid + 1 = %zu\n", mid + 1);
            lo = mid + 1;
        } else {
            std::printf("hi = mid = %zu\n", mid);
            hi = mid;
        }
    }
    std::printf("  lo == hi == %zu: aralık boş; x yok, ekleme konumu %zu\n",
                lo, lo);
    return -1;
}

int main(int argc, char* argv[])
{
    const std::vector<int> a = {3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61,
                                67, 73, 80, 88, 95};

    if (argc > 1 && std::string(argv[1]) == "bozuk") {
        const std::vector<int> s = {5, 1, 4, 2, 3};   // SIRALI DEĞİL
        std::cout << "sırasız dizide arama: değişmez bozulur, assert "
                     "durdurur" << std::endl;
        ikili_ara_yari(s, 2);
        return 0;
    }
    ikili_ara_yari_izle(a, 61);
    ikili_ara_yari_izle(a, 45);

    std::cout << "\nYoklama: 61 -> ";
    yoklama = 0;
    long k = ikili_ara_yari(a, 61);
    std::cout << k << " (" << yoklama << " yoklama), 95 -> ";
    yoklama = 0;
    k = ikili_ara_yari(a, 95);
    std::cout << k << " (" << yoklama << " yoklama), 2 -> ";
    yoklama = 0;
    k = ikili_ara_yari(a, 2);
    std::cout << k << " (" << yoklama << " yoklama)\n";

    long sorgu = 0, hata = 0;
    denetim = 0;
    std::vector<int> b;
    for (int m = 0; m <= 64; m++) {
        b.assign(m, 0);
        for (int i = 0; i < m; i++) {
            b[i] = 2 * i + 1;
        }
        for (int x = -1; x <= 2 * m + 1; x++) {
            long beklenen = (x > 0 && x % 2 == 1 && x < 2 * m)
                            ? (x - 1) / 2 : -1;
            sorgu++;
            if (ikili_ara_yari(b, x) != beklenen) {
                hata++;
            }
        }
    }
    std::cout << "n = 0..64, x = -1..2n+1: " << sorgu << " sorgu, hatalı "
              << "sonuç " << hata << "\ndeğişmez " << denetim
              << " kez denetlendi (assert hiç durdurmadı)\n";
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::binary_search,
 * std::lower_bound (yarı açık [first, last) sözleşmesi); Python —
 * bisect.bisect_left (lo, hi parametreleri de yarı açık). */

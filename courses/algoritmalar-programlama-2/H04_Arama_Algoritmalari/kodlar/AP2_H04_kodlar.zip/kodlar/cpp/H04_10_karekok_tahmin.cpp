/* H04_10_karekok_tahmin.cpp — AP-2 Hafta 4 · Örnek 10 (★★)
 * Amaç    : Cevap üzerinde ikili arama: monoton yüklem (Y…Y D…D) ve ilk D;
 *           tamsayı karekök; sayı tahmin oyunu (en çok ⌊log2 N⌋ + 1 soru)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_10_karekok_tahmin.cpp -o H04_10_karekok_tahmin
 * Çalıştır: ./H04_10_karekok_tahmin
 * Eşleri  : c/H04_10_karekok_tahmin.c · python/H04_10_karekok_tahmin.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <map>
#include <vector>

#include "ortak_rastgele.hpp"

static long adim = 0;           // yüklem değerlendirme / soru sayısı

// Monoton yüklem P(r) = "r * r > n" (r >= 1): r büyüdükçe Y…Y D…D.
// r * r taşabileceğinden eşdeğeri r > n / r sınanır.
static bool cok_buyuk_mu(std::uint64_t r, std::uint64_t n)
{
    return r > n / r;
}

// ⌊√n⌋ = (P'nin doğru olduğu ilk r) - 1. Aranan bir dizi elemanı değil,
// [lo, hi] aralığındaki ilk D'dir. Değişmez: P(lo - 1) = Y, P(hi) = D.
static std::uint64_t tamsayi_karekok(std::uint64_t n)
{
    if (n < 2) {
        return n;
    }
    std::uint64_t lo = 1;                       // P(0) tanım gereği Y
    std::uint64_t hi = n < 4294967296u ? n : 4294967296u;   // P(hi) = D
    while (lo < hi) {
        std::uint64_t mid = lo + (hi - lo) / 2;
        adim++;
        if (cok_buyuk_mu(mid, n)) {
            hi = mid;       // ilk D: mid ya da solu
        } else {
            lo = mid + 1;   // ilk D: mid'in sağı
        }
    }
    return lo - 1;
}

// Tutulan sayıyı [1, N] içinde ikili aramayla bulur; soru sayısı.
// yaz = true ise her soruyu ve yanıtı yazar.
static int tahmin_oyunu(long N, long tutulan, bool yaz)
{
    long lo = 1, hi = N;
    int soru = 0;
    while (lo <= hi) {
        long tahmin = lo + (hi - lo) / 2;
        soru++;
        if (yaz) {
            std::printf("    soru %d: %ld mi?", soru, tahmin);
        }
        if (tahmin == tutulan) {
            if (yaz) {
                std::printf(" -> doğru\n");
            }
            return soru;
        } else if (tahmin < tutulan) {
            if (yaz) {
                std::printf(" -> daha büyük\n");
            }
            lo = tahmin + 1;
        } else {
            if (yaz) {
                std::printf(" -> daha küçük\n");
            }
            hi = tahmin - 1;
        }
    }
    return -1;                                  // olmaz: 1 <= tutulan <= N
}

// 1..N oyunlarının soru sayısı dağılımı, oyunları tek tek oynamadan:
// aynı boyuttaki aralık aynı soru ağacını verir ve her düzeyde en çok iki
// farklı boyut vardır. dagilim[k] = k soruda biten oyun sayısı.
static std::vector<long> dagilim_hesapla(long N)
{
    std::vector<long> dagilim(1, 0);            // dagilim[0] kullanılmaz
    std::map<long, long> duzey = {{N, 1}};      // boyut -> aralık adedi
    while (!duzey.empty()) {
        std::map<long, long> yeni;
        long biten = 0;
        for (const auto& [boyut, adet] : duzey) {
            biten += adet;              // her aralıkta bir oyun biter
            long sol = (boyut - 1) / 2, sag = boyut - 1 - sol;
            if (sol > 0) {
                yeni[sol] += adet;
            }
            if (sag > 0) {
                yeni[sag] += adet;
            }
        }
        dagilim.push_back(biten);
        duzey = yeni;
    }
    return dagilim;                     // en çok soru: dagilim.size() - 1
}

static int taban_log2(long n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main()
{
    const std::vector<std::uint64_t> sayilar = {
        0, 1, 2, 3, 4, 15, 16, 17, 40, 99, 100, 1000000, 2147483647,
        1000000000000u, 1000000000000000000u, 18446744073709551615u};
    const std::vector<long> boyutlar = {100, 1000, 1000000};

    std::printf("1) Monoton yüklem: P(r) = r * r > 40\n   r:");
    for (std::uint64_t r = 1; r <= 10; r++) {
        std::printf(" %2" PRIu64, r);
    }
    std::printf("\n   P:");
    for (std::uint64_t r = 1; r <= 10; r++) {
        std::printf("  %s", cok_buyuk_mu(r, 40) ? "D" : "Y");
    }
    std::printf("\n   ilk D: r = %" PRIu64 "  =>  ⌊√40⌋ = %" PRIu64 "\n",
                tamsayi_karekok(40) + 1, tamsayi_karekok(40));

    std::printf("\n2) Tamsayı karekök (cevap üzerinde ikili arama)\n");
    std::printf("                     n          ⌊√n⌋  adım  doğrulama\n");
    for (std::uint64_t n : sayilar) {
        adim = 0;
        std::uint64_t r = tamsayi_karekok(n);
        // r² <= n < (r + 1)², taşmadan: bölmeyle
        bool dogru = (r == 0 || r <= n / r) && (r + 1 > n / (r + 1));
        std::printf("  %20" PRIu64 "  %12" PRIu64 "  %4ld  %s\n", n, r, adim,
                    dogru ? "evet" : "HAYIR");
    }

    std::printf("\n3) Sayı tahmin oyunu: 1..100, tutulan sayılar LCG "
                "(tohum 42)\n");
    rastgele_tohum(42);
    for (int oyun = 1; oyun <= 3; oyun++) {
        long tutulan = rastgele_aralik(1, 100);
        std::printf("  oyun %d: tutulan %ld\n", oyun, tutulan);
        int s = tahmin_oyunu(100, tutulan, true);
        std::printf("    %d soruda bulundu\n", s);
    }

    std::printf("\n4) Tüm tutulan sayılar için soru sayısı dağılımı\n");
    for (long N : boyutlar) {
        std::vector<long> dagilim = dagilim_hesapla(N);
        int en_cok = static_cast<int>(dagilim.size()) - 1;
        long toplam = 0;
        for (int k = 1; k <= en_cok; k++) {
            toplam += k * dagilim[k];
        }
        std::printf("  N = %ld: en çok %d soru (⌊log2 N⌋ + 1 = %d), ortalama "
                    "%.3f\n", N, en_cok, taban_log2(N) + 1,
                    static_cast<double>(toplam) / N);
        if (N <= 1000) {                // oyunları tek tek oyna, denetle
            std::vector<long> oynanan(en_cok + 1, 0);
            for (long s = 1; s <= N; s++) {
                oynanan[tahmin_oyunu(N, s, false)]++;
            }
            std::printf("    soru:");
            for (int k = 1; k <= en_cok; k++) {
                std::printf(" %4d", k);
            }
            std::printf("\n    oyun:");
            for (int k = 1; k <= en_cok; k++) {
                std::printf(" %4ld", dagilim[k]);
            }
            std::printf("\n    %ld oyun tek tek oynandı: dağılım aynı mı? "
                        "%s\n", N, oynanan == dagilim ? "evet" : "HAYIR");
        } else {
            bool tam = true;
            for (int k = 1; k < en_cok; k++) {
                tam = tam && dagilim[k] == (1L << (k - 1));
            }
            std::printf("    1..%d soru: 2^(k-1) oyun (dolu düzeyler)? %s;"
                        " %d soru: %ld oyun\n", en_cok - 1,
                        tam ? "evet" : "HAYIR", en_cok, dagilim[en_cok]);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (sqrt kayan noktalıdır; büyük n'de
 * yuvarlama hatası verebilir); C++ — yok (std::sqrt aynı uyarıyla);
 * Python — math.isqrt(n) (kesin tamsayı karekök). */

/* H04_08_ekleme_konumu.cpp — AP-2 Hafta 4 · Örnek 8 (★★)
 * Amaç    : Ekleme konumu (ilk a[i] >= x) ve sıralı diziye ekleme:
 *           arama O(log n) yoklama, kaydırma O(n): maliyeti kaydırma belirler
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_08_ekleme_konumu.cpp -o H04_08_ekleme_konumu
 * Çalıştır: ./H04_08_ekleme_konumu
 * Eşleri  : c/H04_08_ekleme_konumu.c · python/H04_08_ekleme_konumu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdio>
#include <vector>

#include "ortak_rastgele.hpp"

static long yoklama = 0;        // incelenen a[mid] sayısı
static long kaydirma = 0;       // bir sağa taşınan eleman sayısı

// x'in sırayı bozmadan girebileceği İLK konum: ilk a[i] >= x (ya da n).
// Değişmez: a[0..lo-1] < x <= a[hi..n-1]
static std::size_t ekleme_konumu(const std::vector<int>& a, int x)
{
    std::size_t lo = 0, hi = a.size();
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

// Ön koşul: a sıralı. x'i yerine ekler ve konumunu döndürür.
// Sona bir yer açılır (push_back), a[k..n-1] bir sağa kayar:
// SONDAN başa doğru (üzerine yazmamak için).
static std::size_t sirali_ekle(std::vector<int>& a, int x)
{
    std::size_t k = ekleme_konumu(a, x);
    std::size_t n = a.size();
    a.push_back(x);                     // yeni boyut n + 1
    for (std::size_t i = n; i > k; i--) {
        a[i] = a[i - 1];
        kaydirma++;
    }
    a[k] = x;
    return k;
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (a[i - 1] > a[i]) {
            return false;
        }
    }
    return true;
}

static void dizi_yaz(const std::vector<int>& a)
{
    std::printf("[");
    for (std::size_t i = 0; i < a.size(); i++) {
        std::printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    std::printf("]");
}

int main()
{
    std::vector<int> a;
    const std::vector<int> ekle = {50, 20, 70, 20, 10, 90, 60, 40};
    const std::vector<int> sorgular = {5, 20, 45, 90, 95};
    const std::vector<std::size_t> boyutlar = {1000, 2000, 4000};

    std::printf("Boş diziye sırayla ekleme\n");
    for (int x : ekle) {
        yoklama = 0;
        kaydirma = 0;
        std::size_t k = sirali_ekle(a, x);
        std::printf("  ekle %2d: konum %zu, yoklama %ld, kaydırma %ld -> ",
                    x, k, yoklama, kaydirma);
        dizi_yaz(a);
        std::printf("\n");
    }

    std::printf("\nEkleme konumu sorguları (dizi değişmez)\n");
    for (int x : sorgular) {
        std::size_t k = ekleme_konumu(a, x);
        std::printf("  x = %2d -> konum %zu", x, k);
        if (k < a.size() && a[k] == x) {
            std::printf(" (x zaten var: ilk kopyanın önüne girer)");
        }
        std::printf("\n");
    }

    std::printf("\nRastgele n ekleme (LCG, tohum 42, değerler "
                "0..1000000)\n");
    std::printf("     n  toplam yoklama  toplam kaydırma     n²/4"
                "  kaydırma/(n²/4)  sıralı\n");
    for (std::size_t m : boyutlar) {
        rastgele_tohum(42);
        yoklama = 0;
        kaydirma = 0;
        a.clear();
        for (std::size_t i = 0; i < m; i++) {
            sirali_ekle(a, rastgele_aralik(0, 1000000));
        }
        std::size_t ceyrek = m * m / 4;
        std::printf("%6zu %15ld %16ld %8zu %16.3f  %s\n", m, yoklama,
                    kaydirma, ceyrek,
                    static_cast<double>(kaydirma) / ceyrek,
                    sirali_mi(a) ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (kaydırma için memmove);
 * C++ — std::lower_bound + std::vector::insert; Python —
 * bisect.bisect_left, bisect.insort (arama + list.insert). */

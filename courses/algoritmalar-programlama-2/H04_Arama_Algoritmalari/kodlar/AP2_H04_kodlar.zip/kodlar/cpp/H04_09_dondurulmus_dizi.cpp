/* H04_09_dondurulmus_dizi.cpp — AP-2 Hafta 4 · Örnek 9 (★★★)
 * Amaç    : Döndürülmüş sıralı dizide arama: her adımda yarılardan biri
 *           sıralıdır, değişmez buna göre uyarlanır; döndürme noktası;
 *           tekrar eden elemanlarda en kötü durumun O(n)'e çıkması
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_09_dondurulmus_dizi.cpp -o H04_09_dondurulmus_dizi
 * Çalıştır: ./H04_09_dondurulmus_dizi
 * Eşleri  : c/H04_09_dondurulmus_dizi.c ·
 *           python/H04_09_dondurulmus_dizi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdio>
#include <vector>

static long yoklama = 0;        // döngü adımı (a[mid] incelemesi)

// Ön koşul: a, FARKLI elemanlı artan sıralı bir dizinin döndürülmüşü.
// Değişmez: x dizideyse a[lo..hi] içindedir.
static long dondurulmus_ara(const std::vector<int>& a, int x)
{
    long lo = 0, hi = static_cast<long>(a.size()) - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] == x) {
            return mid;
        }
        if (a[lo] <= a[mid]) {              // sol yarı a[lo..mid] sıralı
            if (a[lo] <= x && x < a[mid]) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        } else {                            // sağ yarı a[mid..hi] sıralı
            if (a[mid] < x && x <= a[hi]) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
    }
    return -1;
}

// Döndürme noktası = en küçük elemanın konumu (n >= 1, farklı elemanlar).
// Değişmez: en küçük eleman a[lo..hi] içindedir.
static std::size_t en_kucuk_konum(const std::vector<int>& a)
{
    std::size_t lo = 0, hi = a.size() - 1;
    while (lo < hi) {
        std::size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] > a[hi]) {
            lo = mid + 1;                   // en küçük mid'in sağında
        } else {
            hi = mid;                       // mid ya da solunda
        }
    }
    return lo;
}

// Tekrarlı sürüm: a[lo] == a[mid] == a[hi] iken hangi yarının sıralı
// olduğu anlaşılamaz; iki uç birer daraltılır. En kötü durum O(n).
static long dondurulmus_ara_tekrarli(const std::vector<int>& a, int x)
{
    long lo = 0, hi = static_cast<long>(a.size()) - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] == x) {
            return mid;
        }
        if (a[lo] == a[mid] && a[mid] == a[hi]) {
            lo++;
            hi--;
        } else if (a[lo] <= a[mid]) {
            if (a[lo] <= x && x < a[mid]) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        } else {
            if (a[mid] < x && x <= a[hi]) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
    }
    return -1;
}

// Aynı arama (farklı elemanlar); her adımı yazar
static void dondurulmus_izle(const std::vector<int>& a, int x)
{
    long lo = 0, hi = static_cast<long>(a.size()) - 1;
    std::printf("x = %d\n  lo  hi  mid  a[mid]  sıralı yarı      karar\n",
                x);
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        std::printf("  %2ld  %2ld  %3ld  %6d  ", lo, hi, mid, a[mid]);
        if (a[mid] == x) {
            std::printf("—                bulundu\n");
            return;
        }
        if (a[lo] <= a[mid]) {
            bool icinde = a[lo] <= x && x < a[mid];
            std::printf("sol [%2d .. %2d]   %s\n", a[lo], a[mid],
                        icinde ? "içinde: hi = mid - 1"
                               : "dışında: lo = mid + 1");
            if (icinde) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        } else {
            bool icinde = a[mid] < x && x <= a[hi];
            std::printf("sağ [%2d .. %2d]   %s\n", a[mid], a[hi],
                        icinde ? "içinde: lo = mid + 1"
                               : "dışında: hi = mid - 1");
            if (icinde) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
    }
    std::printf("  lo > hi: bulunamadı\n");
}

static int taban_log2(std::size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main()
{
    const std::vector<int> a = {40, 50, 60, 70, 80, 10, 20, 30};

    std::printf("a = [");
    for (std::size_t i = 0; i < a.size(); i++) {
        std::printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    std::printf("]   (10, 20, …, 80 dizisi 3 adım sola döndürüldü)\n");
    dondurulmus_izle(a, 20);
    dondurulmus_izle(a, 65);
    yoklama = 0;
    std::size_t k = en_kucuk_konum(a);
    std::printf("döndürme noktası: konum %zu (a[%zu] = %d), %ld yoklama\n",
                k, k, a[k], yoklama);

    std::printf("\nTüm döndürmeler, tüm x: taban 1, 3, …, 2m - 1\n");
    std::printf("     m  sorgu  hatalı  en çok yoklama  ⌊log2 m⌋+1"
                "  döndürme noktası doğru\n");
    const std::vector<std::size_t> boyutlar = {1, 2, 3, 8, 12, 100};
    for (std::size_t m : boyutlar) {
        long sorgu = 0, hata = 0, en_cok = 0;
        bool nokta_dogru = true;
        std::vector<int> b(m);
        for (std::size_t r = 0; r < m; r++) {   // r adım sola döndür
            for (std::size_t i = 0; i < m; i++) {
                b[i] = static_cast<int>(2 * ((i + r) % m) + 1);
            }
            if (en_kucuk_konum(b) != (m - r) % m) {
                nokta_dogru = false;
            }
            for (int x = 0; x <= static_cast<int>(2 * m); x++) {
                long beklenen = -1;     // kâhin: doğrusal tarama
                for (std::size_t i = 0; i < m; i++) {
                    if (b[i] == x) {
                        beklenen = static_cast<long>(i);
                    }
                }
                yoklama = 0;
                sorgu++;
                if (dondurulmus_ara(b, x) != beklenen) {
                    hata++;
                }
                en_cok = yoklama > en_cok ? yoklama : en_cok;
            }
        }
        std::printf("%6zu %6ld %7ld %15ld %11d  %s\n", m, sorgu, hata,
                    en_cok, taban_log2(m) + 1, nokta_dogru ? "evet" : "HAYIR");
    }

    std::printf("\nTekrar eden elemanlar: 999 tane 2 ve tek bir 1\n");
    std::printf("  1'in konumu  dondurulmus_ara_tekrarli  yoklama\n");
    const std::vector<std::size_t> konumlar = {0, 1, 500, 998, 999};
    std::vector<int> b(1000);
    for (std::size_t p : konumlar) {
        b.assign(1000, 2);
        b[p] = 1;
        yoklama = 0;
        long s = dondurulmus_ara_tekrarli(b, 1);
        std::printf("  %11zu  %24ld  %7ld\n", p, s, yoklama);
    }
    b.assign(1000, 2);
    yoklama = 0;
    long s = dondurulmus_ara_tekrarli(b, 3);
    std::printf("  hepsi 2, x = 3: sonuç %ld, %ld yoklama (n = 1000)\n", s,
                yoklama);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::rotate döndürür,
 * aramaz); Python — yok. Döndürme noktası bulunup iki parçada bsearch /
 * std::lower_bound / bisect de kullanılabilir. */

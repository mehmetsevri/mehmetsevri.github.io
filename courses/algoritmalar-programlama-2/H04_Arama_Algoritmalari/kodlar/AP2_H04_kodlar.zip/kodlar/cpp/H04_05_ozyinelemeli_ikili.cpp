/* H04_05_ozyinelemeli_ikili.cpp — AP-2 Hafta 4 · Örnek 5 (★★)
 * Amaç    : Özyinelemeli ikili arama [lo, hi): T(n) = T(n/2) + c;
 *           çağrı ve derinlik sayaçları, bağıntının açılımı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_05_ozyinelemeli_ikili.cpp -o H04_05_ozyinelemeli_ikili
 * Çalıştır: ./H04_05_ozyinelemeli_ikili
 * Eşleri  : c/H04_05_ozyinelemeli_ikili.c ·
 *           python/H04_05_ozyinelemeli_ikili.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cstddef>
#include <cstdio>
#include <vector>

static long cagri = 0;          // toplam çağrı sayısı
static int en_derin = 0;        // en büyük özyineleme derinliği

// x'i a[lo..hi-1] içinde arar; konum ya da -1. derinlik: 1, 2, ...
static long ikili_ara_oz(const std::vector<int>& a, std::size_t lo,
                         std::size_t hi, int x, int derinlik)
{
    cagri++;
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (lo >= hi) {                     // temel durum: boş aralık
        return -1;
    }
    std::size_t mid = lo + (hi - lo) / 2;
    if (a[mid] == x) {                  // temel durum: bulundu
        return static_cast<long>(mid);
    }
    if (a[mid] < x) {                   // sağ yarı: [mid + 1, hi)
        return ikili_ara_oz(a, mid + 1, hi, x, derinlik + 1);
    }
    return ikili_ara_oz(a, lo, mid, x, derinlik + 1);   // [lo, mid)
}

// Aynı özyineleme; her çağrıyı derinliğe göre girintili yazar
static long ikili_ara_oz_izle(const std::vector<int>& a, std::size_t lo,
                              std::size_t hi, int x, int derinlik)
{
    for (int i = 1; i < derinlik; i++) {
        std::printf("  ");
    }
    std::printf("ara([%zu, %zu))", lo, hi);
    if (lo >= hi) {
        std::printf(" boş aralık: -1\n");
        return -1;
    }
    std::size_t mid = lo + (hi - lo) / 2;
    std::printf(" mid = %zu, a[mid] = %d", mid, a[mid]);
    if (a[mid] == x) {
        std::printf(": bulundu\n");
        return static_cast<long>(mid);
    }
    if (a[mid] < x) {
        std::printf(" < %d\n", x);
        return ikili_ara_oz_izle(a, mid + 1, hi, x, derinlik + 1);
    }
    std::printf(" > %d\n", x);
    return ikili_ara_oz_izle(a, lo, mid, x, derinlik + 1);
}

// 2^k <= n olan en büyük k (n >= 1)
static int taban_log2(std::size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main()
{
    const std::vector<int> a = {3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61,
                                67, 73, 80, 88, 95};
    const std::vector<int> sorgular = {61, 45};
    const std::vector<std::size_t> boyutlar = {1, 2, 3, 4, 7, 8, 16, 100,
                                               1000, 4096};
    const std::size_t n = a.size();

    for (int x : sorgular) {
        std::printf("x = %d\n", x);
        long k = ikili_ara_oz_izle(a, 0, n, x, 1);
        cagri = 0;
        en_derin = 0;
        ikili_ara_oz(a, 0, n, x, 1);
        std::printf("  sonuç %ld: %ld çağrı, en büyük derinlik %d\n", k,
                    cagri, en_derin);
    }

    std::printf("\nAçılım (en kötü yol: her adımda sol yarı, boyut "
                "⌊n/2⌋):\n");
    std::size_t s = n;
    int c = 0;
    std::printf("T(%zu)", s);
    while (s > 0) {
        s /= 2;
        c++;
        if (c == 1) {
            std::printf(" = T(%zu) + c", s);
        } else {
            std::printf(" = T(%zu) + %dc", s, c);
        }
    }
    std::printf("\n=> %d çağrı = ⌊log2 %zu⌋ + 2 (son çağrı boş aralık)\n",
                c + 1, n);

    std::printf("\n     n  en çok çağrı  en büyük derinlik  ⌊log2 n⌋+2  "
                "doğru\n");
    std::vector<int> b;
    for (std::size_t m : boyutlar) {
        b.assign(m, 0);
        for (std::size_t i = 0; i < m; i++) {
            b[i] = static_cast<int>(2 * i + 1);
        }
        long en_cok = 0;
        bool dogru = true;
        en_derin = 0;
        for (std::size_t i = 0; i <= 2 * m; i++) {
            int x = static_cast<int>(i);
            long beklenen = (x % 2 == 1) ? (x - 1) / 2 : -1;
            cagri = 0;
            if (ikili_ara_oz(b, 0, m, x, 1) != beklenen) {
                dogru = false;
            }
            en_cok = cagri > en_cok ? cagri : en_cok;
        }
        std::printf("%6zu %13ld %18d %11d  %s\n", m, en_cok, en_derin,
                    taban_log2(m) + 2, dogru ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::binary_search;
 * Python — bisect.bisect_left (özyinelemeli sürüm yok). */

/* H04_13_sure_karsilastirma.cpp — AP-2 Hafta 4 · Örnek 13 (★★★)
 * Amaç    : Doğrusal ve ikili arama: aynı sorgu karışımında karşılaştırma
 *           sayıları (stdout, kuramla) ve --olc ile süreler ve kesişim
 *           noktası kestirimi (stderr). Tam deney: deney/ klasörü
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_13_sure_karsilastirma.cpp -o H04_13_sure_karsilastirma
 * Çalıştır: ./H04_13_sure_karsilastirma [--olc]
 * Eşleri  : c/H04_13_sure_karsilastirma.c ·
 *           python/H04_13_sure_karsilastirma.py
 * Çıktı   : üç dilde aynı (=) — süreler yalnız stderr'e (--olc)
 */
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static const int SORGU = 1000;

// Ölçülen fonksiyonlar: sayaçsız (sayaç artırımı da süreye girer)
static long dogrusal_ara(const std::vector<int>& a, int x)
{
    for (std::size_t i = 0; i < a.size(); i++) {
        if (a[i] == x) {
            return static_cast<long>(i);
        }
    }
    return -1;
}

static long ikili_ara(const std::vector<int>& a, int x)
{
    long lo = 0, hi = static_cast<long>(a.size()) - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

// Sayaçlı eşleri: aynı adımlar; kars karşılaştırma/yoklama sayısı
static long dogrusal_ara_say(const std::vector<int>& a, int x, long& kars)
{
    for (std::size_t i = 0; i < a.size(); i++) {
        kars++;
        if (a[i] == x) {
            return static_cast<long>(i);
        }
    }
    return -1;
}

static long ikili_ara_say(const std::vector<int>& a, int x, long& kars)
{
    long lo = 0, hi = static_cast<long>(a.size()) - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        kars++;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

// Sorgu karışımı: çift sıradakiler başarılı (tek sayı 2r + 1, r < n),
// tek sıradakiler başarısız (çift sayı 2r, r <= n); a[i] = 2i + 1.
static std::vector<int> sorgu_uret(std::size_t n)
{
    std::vector<int> q(SORGU);
    rastgele_tohum(42);
    for (int k = 0; k < SORGU; k++) {
        if (k % 2 == 0) {
            q[k] = 2 * rastgele_aralik(0, static_cast<int>(n) - 1) + 1;
        } else {
            q[k] = 2 * rastgele_aralik(0, static_cast<int>(n));
        }
    }
    return q;
}

static int taban_log2(std::size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main(int argc, char* argv[])
{
    const std::vector<std::size_t> boyutlar = {8, 16, 32, 64, 128, 256, 512,
                                               1024, 2048, 4096};
    bool olc = argc > 1 && std::string(argv[1]) == "--olc";
    std::vector<double> oran;

    std::printf("Sorgu karışımı: %d sorgu, yarısı başarılı, yarısı başarısız"
                " (LCG, tohum 42)\n", SORGU);
    std::printf("     n  doğrusal ort.  (3n+1)/4  ikili ort.  ikili en çok"
                "  ⌊log2 n⌋+1  aynı\n");
    for (std::size_t n : boyutlar) {
        std::vector<int> a(n);
        for (std::size_t i = 0; i < n; i++) {
            a[i] = static_cast<int>(2 * i + 1);
        }
        std::vector<int> q = sorgu_uret(n);
        long kd = 0, ki_top = 0, ki_cok = 0;
        bool ayni = true;
        for (int x : q) {
            long ki = 0;
            long r1 = dogrusal_ara_say(a, x, kd);
            long r2 = ikili_ara_say(a, x, ki);
            ayni = ayni && r1 == r2;
            ki_top += ki;
            ki_cok = ki > ki_cok ? ki : ki_cok;
        }
        std::printf("%6zu %14.2f %9.2f %11.2f %13ld %11d  %s\n", n,
                    static_cast<double>(kd) / SORGU, (3.0 * n + 1) / 4,
                    static_cast<double>(ki_top) / SORGU, ki_cok,
                    taban_log2(n) + 1, ayni ? "evet" : "HAYIR");
        if (olc) {
            // Sonuç toplamları: derleyicinin döngüyü silmesini engeller
            // ve iki yöntemin aynı sonuçları verdiğini denetler.
            long long toplam_d = 0, toplam_i = 0;
            double td = olc_ortanca([&] {
                for (int x : q) {
                    toplam_d += dogrusal_ara(a, x);
                }
            }, 5) / SORGU;
            double ti = olc_ortanca([&] {
                for (int x : q) {
                    toplam_i += ikili_ara(a, x);
                }
            }, 5) / SORGU;
            oran.push_back(td / ti);
            std::fprintf(stderr, "n = %5zu: doğrusal %9.1f ns, ikili %7.1f "
                         "ns, oran %.2f%s\n", n, td * 1e9, ti * 1e9,
                         oran.back(), toplam_d == toplam_i ? "" : " (FARK!)");
        }
    }
    for (std::size_t t = 1; t < oran.size(); t++) {
        if (oran[t - 1] < 1.0 && oran[t] >= 1.0) {   // 1'i geçtiği yer
            double u = -std::log(oran[t - 1]) /
                       (std::log(oran[t]) - std::log(oran[t - 1]));
            double ln = std::log(static_cast<double>(boyutlar[t - 1])) +
                        u * (std::log(static_cast<double>(boyutlar[t])) -
                             std::log(static_cast<double>(boyutlar[t - 1])));
            std::fprintf(stderr, "kesişim ≈ n = %.0f (%zu ile %zu arası; bu "
                         "makinede, bu çalıştırmada)\n", std::exp(ln),
                         boyutlar[t - 1], boyutlar[t]);
            break;
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — lfind (POSIX) / bsearch; C++ — std::find /
 * std::lower_bound; Python — list.index, x in a / bisect.bisect_left. */

/* H04_deney_arama.cpp — AP-2 Hafta 4 · Haftanın Deneyi (C++)
 * Amaç    : Doğrusal, nöbetçili doğrusal ve ikili aramanın ortalama arama
 *           süresi (ns/arama) ve karşılaştırma sayıları; kesişim noktası
 * Veri    : a[i] = 2i + 1 (i = 0..n-1), boyut n + 1 (nöbetçi yeri)
 * Sorgular: ortak LCG, tohum 42; k. sorgu k çiftse BAŞARILI x = 2r + 1
 *           (r ∈ [0, n-1]), k tekse BAŞARISIZ x = 2r (r ∈ [0, n]): %50/%50
 * Kullanım: ./H04_deney_arama sayac N
 *           ./H04_deney_arama olc YONTEM N SORGU TEKRAR
 *           (çıktı biçimi C sürümüyle aynı; bkz. c/H04_deney_arama.c)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_deney_arama.cpp -o H04_deney_arama
 */
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

static const std::size_t SAYAC_SORGU = 10000;

// ---- ölçülen fonksiyonlar (sayaçsız; merdiven Örnek 1, 2, 3) ----
static long dogrusal_ara(const std::vector<int>& a, std::size_t n, int x)
{
    for (std::size_t i = 0; i < n; i++) {
        if (a[i] == x) {
            return static_cast<long>(i);
        }
    }
    return -1;
}

static long nobetcili_ara(std::vector<int>& a, std::size_t n, int x)
{
    int eski = a[n];
    a[n] = x;
    std::size_t i = 0;
    while (a[i] != x) {
        i++;
    }
    a[n] = eski;
    return i < n ? static_cast<long>(i) : -1;
}

static long ikili_ara(const std::vector<int>& a, std::size_t n, int x)
{
    long lo = 0, hi = static_cast<long>(n) - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

// Sayaçlı ikili arama: yoklama sayısını döndürür
static long ikili_yoklama(const std::vector<int>& a, std::size_t n, int x)
{
    long lo = 0, hi = static_cast<long>(n) - 1, y = 0;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        y++;
        if (a[mid] == x) {
            return y;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return y;
}

static std::vector<int> sorgu_uret(std::size_t sorgu, std::size_t n)
{
    std::vector<int> q(sorgu);
    rastgele_tohum(42);
    for (std::size_t k = 0; k < sorgu; k++) {
        if (k % 2 == 0) {
            q[k] = 2 * rastgele_aralik(0, static_cast<int>(n) - 1) + 1;
        } else {
            q[k] = 2 * rastgele_aralik(0, static_cast<int>(n));
        }
    }
    return q;
}

static int taban_log2(std::size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

static std::vector<int> dizi_kur(std::size_t n)
{
    std::vector<int> a(n + 1, 0);       // son öge: nöbetçi yeri
    for (std::size_t i = 0; i < n; i++) {
        a[i] = static_cast<int>(2 * i + 1);
    }
    return a;
}

// Sayaç kipi (bkz. C sürümü: doğrusal sayaçlar sorgudan kesin bellidir)
static int sayac(std::size_t n)
{
    std::vector<int> a = dizi_kur(n);
    std::vector<int> q = sorgu_uret(SAYAC_SORGU, n);
    long long d = 0, s = 0, ib = 0, is = 0, yb = 0, ys = 0;
    long en_cok = 0;
    for (int x : q) {
        long y = ikili_yoklama(a, n, x);
        en_cok = y > en_cok ? y : en_cok;
        if (x % 2 == 1) {               // başarılı: konum r = (x - 1) / 2
            long r = (x - 1) / 2;
            d += r + 1;
            s += r + 2;
            ib += y;
            yb++;
        } else {
            d += static_cast<long long>(n);
            s += static_cast<long long>(n) + 2;
            is += y;
            ys++;
        }
    }
    const double S = static_cast<double>(SAYAC_SORGU);
    std::printf("%zu;%zu;%.3f;%.3f;%.3f;%.3f;%.3f;%ld;%d\n", n, SAYAC_SORGU,
                d / S, s / S, (ib + is) / S,
                static_cast<double>(ib) / static_cast<double>(yb),
                static_cast<double>(is) / static_cast<double>(ys), en_cok,
                taban_log2(n) + 1);
    return 0;
}

static int olc(const std::string& yontem, std::size_t n, std::size_t sorgu,
               int tekrar)
{
    if (tekrar < 1) {
        return 2;
    }
    std::vector<int> a = dizi_kur(n);
    std::vector<int> q = sorgu_uret(sorgu, n);
    int y = yontem == "dogrusal" ? 0 : yontem == "nobetcili" ? 1 : 2;
    std::vector<double> islem, duvar;   // işlemci zamanı, duvar saati
    long long denetim = 0;
    for (int t = -1; t < tekrar; t++) {         // t = -1: ısınma
        long long toplam = 0;
        double t0 = zaman_sn(), c0 = islemci_sn();
        for (int x : q) {
            toplam += y == 0 ? dogrusal_ara(a, n, x)
                      : y == 1 ? nobetcili_ara(a, n, x)
                               : ikili_ara(a, n, x);
        }
        double c1 = islemci_sn(), t1 = zaman_sn();
        if (t >= 0) {
            islem.push_back(c1 - c0);
            duvar.push_back(t1 - t0);
        }
        denetim = toplam;
    }
    double en_az = islem[0], en_cok = islem[0];
    for (double s : islem) {
        en_az = s < en_az ? s : en_az;
        en_cok = s > en_cok ? s : en_cok;
    }
    const double S = static_cast<double>(sorgu);
    std::printf("%s;%zu;%zu;%d;%.3f;%.3f;%.3f;%.3f;%lld\n", yontem.c_str(),
                n, sorgu, tekrar, ortanca(islem) / S * 1e9, en_az / S * 1e9,
                en_cok / S * 1e9, ortanca(duvar) / S * 1e9, denetim);
    return 0;
}

int main(int argc, char* argv[])
{
    if (argc == 3 && std::string(argv[1]) == "sayac") {
        return sayac(std::strtoull(argv[2], nullptr, 10));
    }
    if (argc == 6 && std::string(argv[1]) == "olc") {
        return olc(argv[2], std::strtoull(argv[3], nullptr, 10),
                   std::strtoull(argv[4], nullptr, 10), std::atoi(argv[5]));
    }
    std::fprintf(stderr, "kullanım: %s sayac N | olc YONTEM N SORGU "
                 "TEKRAR\n", argv[0]);
    return 2;
}

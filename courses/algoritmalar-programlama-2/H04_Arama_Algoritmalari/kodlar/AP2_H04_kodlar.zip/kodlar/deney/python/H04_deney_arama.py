"""H04_deney_arama.py — AP-2 Hafta 4 · Haftanın Deneyi (Python)
Amaç    : Doğrusal, nöbetçili doğrusal ve ikili aramanın ortalama arama
          süresi (ns/arama) ve karşılaştırma sayıları; kesişim noktası
Veri    : a[i] = 2i + 1 (i = 0..n-1), uzunluk n + 1 (nöbetçi yeri)
Sorgular: ortak LCG, tohum 42; k. sorgu k çiftse BAŞARILI x = 2r + 1
          (r ∈ [0, n-1]), k tekse BAŞARISIZ x = 2r (r ∈ [0, n]): %50/%50
Kullanım: python3 H04_deney_arama.py sayac N
          python3 H04_deney_arama.py olc YONTEM N SORGU TEKRAR
          (çıktı biçimi C sürümüyle aynı; bkz. c/H04_deney_arama.c)
"""

import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

SAYAC_SORGU = 10000


# ---- ölçülen fonksiyonlar (sayaçsız; merdiven Örnek 1, 2, 3) ----
def dogrusal_ara(a, n, x):
    for i in range(n):
        if a[i] == x:
            return i
    return -1


def nobetcili_ara(a, n, x):
    eski = a[n]
    a[n] = x
    i = 0
    while a[i] != x:
        i += 1
    a[n] = eski
    return i if i < n else -1


def ikili_ara(a, n, x):
    lo, hi = 0, n - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if a[mid] == x:
            return mid
        elif a[mid] < x:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1


# Sayaçlı ikili arama: yoklama sayısını döndürür
def ikili_yoklama(a, n, x):
    lo, hi, y = 0, n - 1, 0
    while lo <= hi:
        mid = (lo + hi) // 2
        y += 1
        if a[mid] == x:
            return y
        elif a[mid] < x:
            lo = mid + 1
        else:
            hi = mid - 1
    return y


def sorgu_uret(sorgu, n):
    rastgele_tohum(42)
    q = [0] * sorgu
    for k in range(sorgu):
        if k % 2 == 0:
            q[k] = 2 * rastgele_aralik(0, n - 1) + 1
        else:
            q[k] = 2 * rastgele_aralik(0, n)
    return q


def taban_log2(n):
    k = 0
    while n > 1:
        n //= 2
        k += 1
    return k


def dizi_kur(n):
    a = list(range(1, 2 * n, 2))        # a[i] = 2i + 1
    a.append(0)                         # nöbetçi yeri
    return a


# Sayaç kipi (bkz. C sürümü: doğrusal sayaçlar sorgudan kesin bellidir)
def sayac(n):
    a = dizi_kur(n)
    q = sorgu_uret(SAYAC_SORGU, n)
    d = s = ib = is_ = yb = ys = 0
    en_cok = 0
    for x in q:
        y = ikili_yoklama(a, n, x)
        en_cok = max(en_cok, y)
        if x % 2 == 1:                  # başarılı: konum r = (x - 1) / 2
            r = (x - 1) // 2
            d += r + 1
            s += r + 2
            ib += y
            yb += 1
        else:
            d += n
            s += n + 2
            is_ += y
            ys += 1
    S = SAYAC_SORGU
    print(f"{n};{S};{d / S:.3f};{s / S:.3f};{(ib + is_) / S:.3f};"
          f"{ib / yb:.3f};{is_ / ys:.3f};{en_cok};{taban_log2(n) + 1}")
    return 0


def olc(yontem, n, sorgu, tekrar):
    if tekrar < 1:
        return 2
    a = dizi_kur(n)
    q = sorgu_uret(sorgu, n)
    ara = {"dogrusal": dogrusal_ara, "nobetcili": nobetcili_ara}.get(
        yontem, ikili_ara)
    islem, duvar = [], []               # işlemci zamanı, duvar saati
    denetim = 0
    for t in range(-1, tekrar):         # t = -1: ısınma
        toplam = 0
        t0, c0 = zaman_sn(), islemci_sn()
        for x in q:
            toplam += ara(a, n, x)
        c1, t1 = islemci_sn(), zaman_sn()
        if t >= 0:
            islem.append(c1 - c0)
            duvar.append(t1 - t0)
        denetim = toplam
    S = sorgu
    print(f"{yontem};{n};{sorgu};{tekrar};{ortanca(islem) / S * 1e9:.3f};"
          f"{min(islem) / S * 1e9:.3f};{max(islem) / S * 1e9:.3f};"
          f"{ortanca(duvar) / S * 1e9:.3f};{denetim}")
    return 0


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "sayac":
        return sayac(int(sys.argv[2]))
    if len(sys.argv) == 6 and sys.argv[1] == "olc":
        return olc(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]),
                   int(sys.argv[5]))
    print(f"kullanım: {sys.argv[0]} sayac N | olc YONTEM N SORGU TEKRAR",
          file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""olcum_calistir.py — AP-2 Hafta 4 · Haftanın Deneyi: ölçüm sürücüsü

Doğrusal, nöbetçili doğrusal ve ikili aramanın ortalama arama süresini
n = 2 … 10^7 için üç dilde ölçer; ham sonuçları sonuclar/h04_deney_olcum.csv,
deterministik sayaçları sonuclar/h04_deney_sayac.csv, makine bilgisini
OLCUM_ORTAMI.txt dosyasına yazar.

Düzen (AP-2 Ajan Rehberi, Bölüm 3):
  * C ve C++ -O2 ile; karşılaştırma için C ayrıca -O0 ile derlenir.
  * Her ölçüm: 1 ısınma + 5 tekrar; her tekrarda SORGU arama (önceden
    üretilmiş, %50 başarılı / %50 başarısız); ORTANCA / SORGU = ns/arama.
  * Süre İŞLEMCİ zamanıdır (islemci_sn: clock / process_time): makine
    başka ajanlarla paylaşıldığından süreç bekletildiği süreyi saymaz;
    duvar saati ortancası da "duvar_ortanca_ns" sütununa yazılır.
  * Aynı n'de üç yöntem art arda ölçülür (oranlar benzer yük altında).
  * Tüm plan GECIS = 3 kez yürütülür (2. ve 3. geçiş, 1. geçişin planını
    — aynı n, sorgu, tekrar, tür — yineler); her nokta için geçişlerin EN
    KÜÇÜK ortancası tutulur (ham geçişler:
    sonuclar/h04_deney_olcum_gecisler.csv).
  * Tutarsız ölçüm (en_cok / en_az > 1,5 ve tekrar başına süre > 1 ms) en
    çok iki kez yinelenir; yayılımı en küçük deneme tutulur.
  * Aykırı denetimi: her serinin her noktası komşularından log–log
    ara/dış değerlemeyle beklenenden 1,3 kattan fazla saparsa iki kez daha
    ölçülür ve ortancaların EN KÜÇÜĞÜ tutulur: paylaşımlı makinede başka
    süreçlerin yükü ölçümü yalnızca yavaşlatır, en az etkilenen ölçüm
    gerçek maliyete en yakındır. Denetim, düzeltilmiş değerlerle bir tur
    daha yapılır (en çok 2 tur; CSV'de "aykiri" = yinelendiği tur sayısı,
    "deneme" toplam; ölçümlerin ortanca ve aralığı standart çıktıya yazılır).
  * Python'da doğrusal aramalar süre bütçesiyle sınırlıdır: bir sonraki
    n'nin tekrar başına tahmini süresi 0,15 s'yi aşarsa ölçülmez (kestirim
    cozumle.py'de yapılır); kestirimi sınamak için ilk ölçülmeyen n'de bir
    "dogrulama" ölçümü (1 tekrar) alınır.
Kullanım (deney/ klasöründe):  python3 olcum_calistir.py
"""
import datetime
import math
import os
import platform
import subprocess
import sys
import tempfile

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C_DERLE = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP_DERLE = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]
BOYUTLAR = [2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 30, 40, 50, 70, 100, 150,
            200, 300, 500, 700, 1000, 2000, 5000, 10000, 20000, 50000,
            100000, 200000, 500000, 1000000, 2000000, 5000000, 10000000]
YONTEMLER = ["dogrusal", "nobetcili", "ikili"]
TEKRAR = 5
GECIS = 3                   # tüm plan üç kez; nokta başına en küçük ortanca
PY_BUTCE_SN = 0.15          # Python doğrusal: tekrar başına süre bütçesi


def derle(gecici):
    """İkilileri derler; {(dil, derleme): komut önü} döndürür."""
    c = os.path.join(KOK, "c")
    ikili = {}
    for bayrak in ("-O2", "-O0"):
        hedef = os.path.join(gecici, f"deney_c{bayrak}")
        kaynak = [os.path.join(c, "H04_deney_arama.c"),
                  os.path.join(c, "ortak_rastgele.c"),
                  os.path.join(c, "zamanlayici.c")]
        subprocess.run(C_DERLE + [bayrak] + kaynak + ["-o", hedef],
                       check=True)
        ikili[("C", bayrak)] = [hedef]
    hedef = os.path.join(gecici, "deney_cpp")
    subprocess.run(CPP_DERLE + ["-O2", os.path.join(
        KOK, "cpp", "H04_deney_arama.cpp"), "-o", hedef], check=True)
    ikili[("C++", "-O2")] = [hedef]
    ikili[("Python", "-")] = [sys.executable, os.path.join(
        KOK, "python", "H04_deney_arama.py")]
    return ikili


def sorgu_sayisi(dil, yontem, n):
    if dil == "Python":
        if yontem == "ikili":
            return 5000
        return max(5, min(5000, round(1e6 / n)))
    if yontem == "ikili":
        return 50000
    return max(10, min(50000, round(1e7 / n)))


def olc(komut, yontem, n, sorgu, tekrar):
    p = subprocess.run(komut + ["olc", yontem, str(n), str(sorgu),
                                str(tekrar)],
                       capture_output=True, text=True, check=True)
    y, nn, s, t, orta, az, cok, duvar, den = p.stdout.strip().split(";")
    return {"yontem": y, "n": int(nn), "sorgu": int(s), "tekrar": int(t),
            "ortanca_ns": float(orta), "en_az_ns": float(az),
            "en_cok_ns": float(cok), "duvar_ortanca_ns": float(duvar),
            "denetim": int(den)}


def olc_tutarli(komut, yontem, n, sorgu, tekrar):
    en_iyi, deneme = None, 0
    for deneme in range(1, 4):
        s = olc(komut, yontem, n, sorgu, tekrar)
        yayilim = s["en_cok_ns"] / max(s["en_az_ns"], 1e-9)
        if en_iyi is None or yayilim < en_iyi[0]:
            en_iyi = (yayilim, s)
        tekrar_ms = s["ortanca_ns"] * sorgu / 1e6
        if yayilim <= 1.5 or tekrar_ms <= 1.0 or tekrar == 1:
            break
    sonuc = dict(en_iyi[1])
    sonuc["deneme"] = deneme
    return sonuc


def beklenen(nler, tler, i):
    """i. noktanın komşularından log–log beklenen değeri"""
    if len(nler) < 3:
        return None
    if i == 0:
        a, b = 1, 2
    elif i == len(nler) - 1:
        a, b = i - 2, i - 1
    else:
        a, b = i - 1, i + 1
    la, lb = math.log(nler[a]), math.log(nler[b])
    u = (math.log(nler[i]) - la) / (lb - la)
    return math.exp(math.log(tler[a]) + u * (math.log(tler[b])
                                             - math.log(tler[a])))


def aykiri_duzelt(satirlar, ikili, tur_no=1):
    """Komşularından 1,3 kattan çok sapan ölçümleri iki kez yineler."""
    seriler = {}
    for s in satirlar:
        if s["tur"] == "olcum":
            seriler.setdefault((s["dil"], s["derleme"], s["yontem"]),
                               []).append(s)
    yinelenen = 0
    for (dil, der, yontem), seri in seriler.items():
        seri.sort(key=lambda s: s["n"])
        nler = [s["n"] for s in seri]
        tler = [s["ortanca_ns"] for s in seri]
        for i, s in enumerate(seri):
            b = beklenen(nler, tler, i)
            if b is None or abs(math.log(s["ortanca_ns"] / b)) <= \
                    math.log(1.3):
                continue
            olcumler = [s]
            for _ in range(2):
                olcumler.append(olc_tutarli(ikili[(dil, der)], yontem,
                                            s["n"], s["sorgu"],
                                            s["tekrar"]))
            ortancalar = sorted(o["ortanca_ns"] for o in olcumler)
            eski = s["ortanca_ns"]
            secilen = min(olcumler, key=lambda o: o["ortanca_ns"])
            s["ortanca_ns"] = secilen["ortanca_ns"]
            s["en_az_ns"] = secilen["en_az_ns"]
            s["en_cok_ns"] = secilen["en_cok_ns"]
            s["duvar_ortanca_ns"] = secilen["duvar_ortanca_ns"]
            s["deneme"] += sum(o["deneme"] for o in olcumler[1:])
            s["aykiri"] += 1
            yinelenen += 1
            print(f"aykırı ({tur_no}. tur): {dil} {der} {yontem} "
                  f"n={s['n']}: {eski:.1f} ns "
                  f"(beklenen ≈ {b:.1f}) -> ortancalar "
                  + ", ".join(f"{x:.1f}" for x in ortancalar), flush=True)
    print(f"aykırı denetimi ({tur_no}. tur): {yinelenen} nokta yinelendi",
          flush=True)
    return yinelenen


def sayaclar(ikili):
    """Üç dilin sayaç çıktısı; aynı mı?"""
    satirlar = []
    for n in BOYUTLAR:
        cikti = {}
        for anahtar in (("C", "-O2"), ("C++", "-O2"), ("Python", "-")):
            p = subprocess.run(ikili[anahtar] + ["sayac", str(n)],
                               capture_output=True, text=True, check=True)
            cikti[anahtar[0]] = p.stdout.strip()
        ayni = len(set(cikti.values())) == 1
        satirlar.append(cikti["C"] + ";" + ("evet" if ayni else "HAYIR"))
    with open(os.path.join(SONUC, "h04_deney_sayac.csv"), "w",
              encoding="utf-8") as f:
        f.write("n;sorgu;dogrusal_kars_ort;nobetcili_kars_ort;"
                "ikili_yoklama_ort;ikili_yoklama_ort_basarili;"
                "ikili_yoklama_ort_basarisiz;ikili_yoklama_en_cok;"
                "taban_log2_arti_1;uc_dil_ayni\n")
        for s in satirlar:
            f.write(s + "\n")
    print(f"sayaçlar: {len(satirlar)} n, üç dilde aynı: "
          f"{sum(s.endswith('evet') for s in satirlar)}/{len(satirlar)}",
          flush=True)


def ortam_yaz(sure_sn):
    def ilk(komut):
        try:
            return subprocess.run(komut, capture_output=True, text=True
                                  ).stdout.strip().splitlines()[0]
        except (OSError, IndexError):
            return "?"
    model = "?"
    for satir in subprocess.run(["lscpu"], capture_output=True, text=True
                                ).stdout.splitlines():
        if satir.startswith("Model name:"):
            model = satir.split(":", 1)[1].strip()
    onbellek = []
    for satir in subprocess.run(["lscpu"], capture_output=True, text=True
                                ).stdout.splitlines():
        ad = satir.split(":")[0].strip()
        if ad in ("L1d cache", "L2 cache", "L3 cache"):
            onbellek.append(" ".join(satir.split()))
    metin = (
        "AP-2 Hafta 4 · Haftanın Deneyi — ölçüm ortamı\n"
        f"Tarih          : {datetime.date.today().isoformat()}\n"
        f"İşlemci        : {model}\n"
        f"Önbellek       : {'; '.join(onbellek) or '?'}\n"
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine; başka süreçler "
        "de çalışıyordu)\n"
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})\n"
        f"C derleyicisi  : {ilk(['gcc', '--version'])}\n"
        f"C++ derleyicisi: {ilk(['g++', '--version'])}\n"
        f"Python         : {ilk([sys.executable, '--version'])}\n"
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra "
        "-pedantic -O2 (C ayrıca -O0)\n"
        "Veri           : a[i] = 2i + 1 (int), n + 1 kapasite; sorgular "
        "LCG (tohum 42), %50 başarılı / %50 başarısız\n"
        "Yöntem         : 3 geçiş × (1 ısınma + 5 tekrar), ortanca; nokta "
        "başına geçişlerin en küçük ortancası;\n"
        "                 tekrar başına "
        "SORGU arama; en_cok/en_az > 1,5 ise en çok 2 kez yineleme;\n"
        "                 komşularından 1,3 kattan çok sapan nokta 2 kez "
        "daha ölçülür, ortancaların en küçüğü (en çok 2 tur)\n"
        "Saat           : işlemci zamanı (birincil): C/C++ clock(), Python "
        "time.process_time; duvar saati (ikincil): C timespec_get, C++ "
        "steady_clock, Python time.perf_counter\n"
        f"Toplam deney süresi: {sure_sn:.1f} s\n")
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)
    print(metin)


def plan_gecisi(ikili, plan):
    """İlk geçişte kurulan planı (aynı n, tür, sorgu, tekrar) yineler."""
    satirlar = []
    for dil, der, yontem, n, sorgu, tekrar, tur in plan:
        s = olc_tutarli(ikili[(dil, der)], yontem, n, sorgu, tekrar)
        s.update(dil=dil, derleme=der, tur=tur, aykiri=0,
                 gecis=plan_gecisi.no)
        satirlar.append(s)
        print(f"[{plan_gecisi.no}] {dil:<6} {der:<3} {yontem:<9} n={n:>8} "
              f"ortanca={s['ortanca_ns']:12.1f} ns", flush=True)
    return satirlar


def gecis(ikili, no):
    """Ölçüm planının ilk tam geçişi (plan burada kurulur)."""
    satirlar = []
    for (dil, der), komut in ikili.items():
        ns_eleman = {}                  # Python bütçe tahmini için
        dogrulama = set()
        for n in BOYUTLAR:
            # Aynı n için üç yöntem art arda ölçülür: oranlar (kesişim)
            # benzer makine yükü altında alınmış olur.
            for yontem in YONTEMLER:
                sorgu = sorgu_sayisi(dil, yontem, n)
                tur, tekrar = "olcum", TEKRAR
                if dil == "Python" and yontem != "ikili" and \
                        yontem in ns_eleman:
                    tahmin = ns_eleman[yontem] * 0.75 * n * sorgu / 1e9
                    if tahmin > PY_BUTCE_SN:
                        if yontem in dogrulama:
                            continue
                        tur, tekrar = "dogrulama", 1
                        dogrulama.add(yontem)
                s = olc_tutarli(komut, yontem, n, sorgu, tekrar)
                s.update(dil=dil, derleme=der, tur=tur, aykiri=0, gecis=no)
                satirlar.append(s)
                if n >= 1000:
                    ns_eleman[yontem] = s["ortanca_ns"] / (0.75 * n)
                print(f"[{no}] {dil:<6} {der:<3} {yontem:<9} n={n:>8} "
                      f"sorgu={sorgu:>6} {tur:<9} "
                      f"ortanca={s['ortanca_ns']:12.1f} ns "
                      f"[{s['en_az_ns']:.1f} … {s['en_cok_ns']:.1f}] "
                      f"deneme={s['deneme']}", flush=True)
    return satirlar


def birlestir(gecisler):
    """Her nokta için geçişlerin EN KÜÇÜK ortancası (yük yalnızca
    yavaşlatır); tüm geçiş ortancaları 'gecis_ortancalar' sütununda."""
    def anahtar(s):
        return (s["dil"], s["derleme"], s["yontem"], s["n"], s["tur"])
    sonuc = []
    for s in gecisler[0]:
        adaylar = [s] + [t for g in gecisler[1:] for t in g
                         if anahtar(t) == anahtar(s)]
        secilen = dict(min(adaylar, key=lambda a: a["ortanca_ns"]))
        secilen["gecis_ortancalar"] = "|".join(
            f"{a['ortanca_ns']:.3f}" for a in adaylar)
        secilen["deneme"] = sum(a["deneme"] for a in adaylar)
        sonuc.append(secilen)
    return sonuc


def csv_yaz(ad, satirlar, alanlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join(f"{s[a]:.3f}" if isinstance(s[a], float)
                             else str(s[a]) for a in alanlar) + "\n")


def main():
    os.makedirs(SONUC, exist_ok=True)
    baslangic = datetime.datetime.now()
    with tempfile.TemporaryDirectory(prefix="h04_deney_") as gecici:
        ikili = derle(gecici)
        sayaclar(ikili)
        gecisler = [gecis(ikili, 1)]
        plan = [(s["dil"], s["derleme"], s["yontem"], s["n"], s["sorgu"],
                 s["tekrar"], s["tur"]) for s in gecisler[0]]
        for k in range(2, GECIS + 1):
            plan_gecisi.no = k
            gecisler.append(plan_gecisi(ikili, plan))
        satirlar = birlestir(gecisler)
        for tur_no in (1, 2):           # 2. tur: düzeltilmiş komşularla
            if aykiri_duzelt(satirlar, ikili, tur_no) == 0:
                break
    temel = ["n", "dil", "derleme", "yontem", "tur", "sorgu", "tekrar",
             "deneme"]
    csv_yaz("h04_deney_olcum_gecisler.csv", [s for g in gecisler for s in g],
            temel + ["gecis", "ortanca_ns", "en_az_ns", "en_cok_ns",
                     "duvar_ortanca_ns", "denetim"])
    csv_yaz("h04_deney_olcum.csv", satirlar,
            temel + ["aykiri", "gecis", "ortanca_ns", "en_az_ns",
                     "en_cok_ns", "duvar_ortanca_ns", "denetim",
                     "gecis_ortancalar"])
    ortam_yaz((datetime.datetime.now() - baslangic).total_seconds())


if __name__ == "__main__":
    main()

/* H04_deney_arama.c — AP-2 Hafta 4 · Haftanın Deneyi (C)
 * Amaç    : Doğrusal, nöbetçili doğrusal ve ikili aramanın ortalama arama
 *           süresi (ns/arama) ve karşılaştırma sayıları; kesişim noktası
 * Veri    : a[i] = 2i + 1 (i = 0..n-1), kapasite n + 1 (nöbetçi yeri)
 * Sorgular: ortak LCG, tohum 42; k. sorgu k çiftse BAŞARILI x = 2r + 1
 *           (r ∈ [0, n-1]), k tekse BAŞARISIZ x = 2r (r ∈ [0, n]): %50/%50
 * Kullanım: ./H04_deney_arama sayac N
 *               -> deterministik sayaçlar (stdout; üç dilde aynı)
 *           ./H04_deney_arama olc YONTEM N SORGU TEKRAR
 *               -> CSV: yontem;n;sorgu;tekrar;ortanca_ns;en_az_ns;
 *                  en_cok_ns;duvar_ortanca_ns;denetim
 *                  (YONTEM: dogrusal|nobetcili|ikili)
 * Ölçüm   : 1 ısınma + TEKRAR çalıştırma; her çalıştırmada SORGU arama
 *           (önceden üretilmiş sorgular); ortanca / SORGU = ns/arama.
 *           ortanca/en_az/en_cok: İŞLEMCİ zamanı (islemci_sn; paylaşımlı
 *           makinede beklenen süreyi içermez); duvar_: duvar saati
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H04_deney_arama.c \
 *           ortak_rastgele.c zamanlayici.c -o H04_deney_arama
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define SAYAC_SORGU 10000
#define EN_COK_TEKRAR 101

/* ---- ölçülen fonksiyonlar (sayaçsız; merdiven Örnek 1, 2, 3) ---- */
static long dogrusal_ara(const int a[], size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

static long nobetcili_ara(int a[], size_t n, int x)
{
    int eski = a[n];
    a[n] = x;
    size_t i = 0;
    while (a[i] != x) {
        i++;
    }
    a[n] = eski;
    return i < n ? (long)i : -1;
}

static long ikili_ara(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

/* Sayaçlı ikili arama: yoklama sayısını döndürür */
static long ikili_yoklama(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1, y = 0;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        y++;
        if (a[mid] == x) {
            return y;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return y;
}

static void sorgu_uret(int q[], size_t sorgu, size_t n)
{
    rastgele_tohum(42);
    for (size_t k = 0; k < sorgu; k++) {
        if (k % 2 == 0) {
            q[k] = 2 * rastgele_aralik(0, (int)n - 1) + 1;
        } else {
            q[k] = 2 * rastgele_aralik(0, (int)n);
        }
    }
}

static int taban_log2(size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

static int *dizi_kur(size_t n)
{
    int *a = malloc((n + 1) * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "bellek yetersiz (n = %zu)\n", n);
        exit(1);
    }
    for (size_t i = 0; i < n; i++) {
        a[i] = (int)(2 * i + 1);
    }
    a[n] = 0;
    return a;
}

/* Sayaç kipi. Doğrusal aramanın karşılaştırma sayısı sorgudan kesin
 * olarak bellidir (başarılı x = 2r + 1: r + 1; başarısız: n; nöbetçili:
 * eleman r + 1 ya da n + 1, artı 1 sınır denetimi). İkili arama sayılır. */
static int sayac(size_t n)
{
    int *a = dizi_kur(n);
    int *q = malloc(SAYAC_SORGU * sizeof *q);
    if (q == NULL) {
        return 1;
    }
    sorgu_uret(q, SAYAC_SORGU, n);
    long long d = 0, s = 0, ib = 0, is = 0, yb = 0, ys = 0;
    long en_cok = 0;
    for (size_t k = 0; k < SAYAC_SORGU; k++) {
        long y = ikili_yoklama(a, n, q[k]);
        en_cok = y > en_cok ? y : en_cok;
        if (q[k] % 2 == 1) {            /* başarılı: konum r = (x - 1) / 2 */
            long r = (q[k] - 1) / 2;
            d += r + 1;
            s += r + 2;
            ib += y;
            yb++;
        } else {
            d += (long long)n;
            s += (long long)n + 2;
            is += y;
            ys++;
        }
    }
    printf("%zu;%d;%.3f;%.3f;%.3f;%.3f;%.3f;%ld;%d\n", n, SAYAC_SORGU,
           (double)d / SAYAC_SORGU, (double)s / SAYAC_SORGU,
           (double)(ib + is) / SAYAC_SORGU, (double)ib / (double)yb,
           (double)is / (double)ys, en_cok, taban_log2(n) + 1);
    free(q);
    free(a);
    return 0;
}

static int olc(const char *yontem, size_t n, size_t sorgu, int tekrar)
{
    int *a = dizi_kur(n);
    int *q = malloc(sorgu * sizeof *q);
    double islem[EN_COK_TEKRAR], duvar[EN_COK_TEKRAR];
    if (q == NULL || tekrar < 1 || tekrar > EN_COK_TEKRAR) {
        return 2;
    }
    sorgu_uret(q, sorgu, n);
    int y = strcmp(yontem, "dogrusal") == 0 ? 0
            : strcmp(yontem, "nobetcili") == 0 ? 1 : 2;
    long long denetim = 0;
    for (int t = -1; t < tekrar; t++) {         /* t = -1: ısınma */
        long long toplam = 0;
        double t0 = zaman_sn(), c0 = islemci_sn();
        for (size_t k = 0; k < sorgu; k++) {
            toplam += y == 0 ? dogrusal_ara(a, n, q[k])
                      : y == 1 ? nobetcili_ara(a, n, q[k])
                               : ikili_ara(a, n, q[k]);
        }
        double c1 = islemci_sn(), t1 = zaman_sn();
        if (t >= 0) {
            islem[t] = c1 - c0;
            duvar[t] = t1 - t0;
        }
        denetim = toplam;
    }
    double orta = ortanca(islem, tekrar);       /* islem sıralanır */
    double orta_duvar = ortanca(duvar, tekrar);
    printf("%s;%zu;%zu;%d;%.3f;%.3f;%.3f;%.3f;%lld\n", yontem, n, sorgu,
           tekrar, orta / sorgu * 1e9, islem[0] / sorgu * 1e9,
           islem[tekrar - 1] / sorgu * 1e9, orta_duvar / sorgu * 1e9,
           denetim);
    free(q);
    free(a);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc == 3 && strcmp(argv[1], "sayac") == 0) {
        return sayac((size_t)strtoull(argv[2], NULL, 10));
    }
    if (argc == 6 && strcmp(argv[1], "olc") == 0) {
        return olc(argv[2], (size_t)strtoull(argv[3], NULL, 10),
                   (size_t)strtoull(argv[4], NULL, 10), atoi(argv[5]));
    }
    fprintf(stderr, "kullanım: %s sayac N | olc YONTEM N SORGU TEKRAR\n",
            argv[0]);
    return 2;
}

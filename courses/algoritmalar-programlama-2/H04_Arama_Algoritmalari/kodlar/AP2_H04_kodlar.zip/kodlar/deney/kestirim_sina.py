#!/usr/bin/env python3
"""kestirim_sina.py — AP-2 Hafta 4 · Haftanın Deneyi: Python kestirim sınaması

olcum_calistir.py, Python doğrusal aramalarını süre bütçesiyle sınırlar ve
ilk ölçülmeyen n'de TEK tekrarlı bir doğrulama ölçümü alır; yüklü makinede
bu tek ölçüm kolayca bozulur. Bu betik kestirimi daha sağlam sınar:
n = 2·10^6 ve 5·10^6 için doğrusal ve nöbetçili arama, her biri
SORGU = 5 arama, 1 ısınma + 3 tekrar, 2 bağımsız çalıştırma; nokta başına
ortancaların EN KÜÇÜĞÜ (yük yalnızca yavaşlatır). Süre işlemci zamanıdır.
Çıktı: sonuclar/h04_deney_kestirim_sinama.csv (cozumle.py okur).
Süre: ≈ 15–30 s; bellek: n = 5·10^6 listesi ≈ 0,2 GB.
Kullanım (deney/ klasöründe):  python3 kestirim_sina.py
"""
import os
import subprocess
import sys

KOK = os.path.dirname(os.path.abspath(__file__))
PROG = os.path.join(KOK, "python", "H04_deney_arama.py")
NLER = [2000000, 5000000]
YONTEMLER = ["dogrusal", "nobetcili"]
SORGU, TEKRAR, CALISTIRMA = 5, 3, 2


def main():
    satirlar = []
    for n in NLER:
        for yontem in YONTEMLER:
            olcumler = []
            for _ in range(CALISTIRMA):
                p = subprocess.run([sys.executable, PROG, "olc", yontem,
                                    str(n), str(SORGU), str(TEKRAR)],
                                   capture_output=True, text=True,
                                   check=True)
                alan = p.stdout.strip().split(";")
                olcumler.append((float(alan[4]), float(alan[7]), alan[8]))
            en_iyi = min(olcumler)
            hepsi = "|".join(f"{o[0]:.3f}" for o in olcumler)
            satirlar.append(f"Python;{yontem};{n};{SORGU};{TEKRAR};"
                            f"{CALISTIRMA};{en_iyi[0]:.3f};{en_iyi[1]:.3f};"
                            f"{en_iyi[2]};{hepsi}")
            print(satirlar[-1], flush=True)
    with open(os.path.join(KOK, "sonuclar", "h04_deney_kestirim_sinama.csv"),
              "w", encoding="utf-8") as f:
        f.write("dil;yontem;n;sorgu;tekrar;calistirma;ortanca_ns;"
                "duvar_ortanca_ns;denetim;calistirma_ortancalar\n")
        for s in satirlar:
            f.write(s + "\n")


if __name__ == "__main__":
    main()

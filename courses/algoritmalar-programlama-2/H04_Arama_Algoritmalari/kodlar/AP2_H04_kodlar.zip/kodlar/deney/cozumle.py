#!/usr/bin/env python3
"""cozumle.py — AP-2 Hafta 4 · Haftanın Deneyi: çözümleme

sonuclar/h04_deney_olcum.csv ve h04_deney_sayac.csv dosyalarından
türetilmiş tabloları üretir (tüm sayılar CSV'den hesaplanır):
  sonuclar/h04_deney_kesisim.csv  — doğrusal/ikili kesişim noktaları
  sonuclar/h04_deney_kestirim.csv — Python doğrusal aramalarında
                                    ölçülmeyen n için kestirim ve sınama
                                    (t ≈ c · karşılaştırma sayısı; ek
                                    sınama: kestirim_sina.py çıktısı
                                    h04_deney_kestirim_sinama.csv)
  sonuclar/h04_deney_oran.csv     — seçili n'lerde süre oranları
  sonuclar/h04_deney_turetilmis.csv — yoklama başına süre, log–log eğim
Kesişim: oran r(n) = t_doğrusal(n) / t_ikili(n). "Kalıcı kesişim", r'nin
kendisinden sonraki TÜM ölçülen n'lerde >= 1 kaldığı ilk noktadır;
kesişim n'i iki komşu nokta arasında log–log doğrusal ara değerlemeyle
kestirilir. Gürültüden doğan erken geçişler ayrıca raporlanır.
Kullanım (deney/ klasöründe):  python3 cozumle.py
"""
import csv
import math
import os

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
SECILI_N = [10, 100, 1000, 10000, 100000, 1000000, 10000000]
DIZILIS = [("C", "-O2"), ("C++", "-O2"), ("C", "-O0"), ("Python", "-")]


def oku(ad):
    with open(os.path.join(SONUC, ad), encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


def yaz(ad, alanlar, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join(f"{s[a]:.4g}" if isinstance(s[a], float)
                             else str(s[a]) for a in alanlar) + "\n")


def seriler(olcum):
    """{(dil, derleme, yontem): {n: ortanca_ns}} (yalnız tur = olcum)"""
    t = {}
    for s in olcum:
        if s["tur"] == "olcum":
            t.setdefault((s["dil"], s["derleme"], s["yontem"]), {})[
                int(s["n"])] = float(s["ortanca_ns"])
    return t


def kesisim(t_lin, t_bin):
    ortak = sorted(set(t_lin) & set(t_bin))
    r = [t_lin[n] / t_bin[n] for n in ortak]
    ilk = next((i for i, x in enumerate(r) if x >= 1.0), None)
    kalici = None
    for i in range(len(r)):
        if all(x >= 1.0 for x in r[i:]):
            kalici = i
            break
    sonuc = {"ilk_gecis_n": ortak[ilk] if ilk is not None else "—",
             "erken_gecis": "evet" if ilk is not None and kalici is not None
             and ilk < kalici else "hayır"}
    if kalici is None:
        sonuc.update(n_alt="—", n_ust="—", kesisim_n="—", oran_alt="—",
                     oran_ust="—", durum="kesişim yok (ölçülen aralıkta)")
    elif kalici == 0:
        sonuc.update(n_alt="—", n_ust=ortak[0], kesisim_n=f"<= {ortak[0]}",
                     oran_alt="—", oran_ust=r[0],
                     durum="en küçük n'de bile ikili arama hızlı")
    else:
        a, b = kalici - 1, kalici
        u = -math.log(r[a]) / (math.log(r[b]) - math.log(r[a]))
        ln = math.log(ortak[a]) + u * (math.log(ortak[b])
                                       - math.log(ortak[a]))
        sonuc.update(n_alt=ortak[a], n_ust=ortak[b],
                     kesisim_n=round(math.exp(ln)), oran_alt=r[a],
                     oran_ust=r[b], durum="kalıcı kesişim")
    return sonuc


def egim(t, n1, n2):
    return math.log(t[n2] / t[n1]) / math.log(n2 / n1)


def main():
    olcum = oku("h04_deney_olcum.csv")
    sayac = {int(s["n"]): s for s in oku("h04_deney_sayac.csv")}
    t = seriler(olcum)
    sinama = (oku("h04_deney_kestirim_sinama.csv") if os.path.exists(
        os.path.join(SONUC, "h04_deney_kestirim_sinama.csv")) else [])

    # 1) Kesişim noktaları
    kes = []
    for dil, der in DIZILIS:
        for yontem in ("dogrusal", "nobetcili"):
            k = kesisim(t[(dil, der, yontem)], t[(dil, der, "ikili")])
            k.update(dil=dil, derleme=der, karsilastirma=f"{yontem}/ikili")
            kes.append(k)
    yaz("h04_deney_kesisim.csv", ["dil", "derleme", "karsilastirma",
                                  "n_alt", "n_ust", "kesisim_n", "oran_alt",
                                  "oran_ust", "durum", "ilk_gecis_n",
                                  "erken_gecis"], kes)

    # 2) Python doğrusal kestirimi: t(n) ≈ c · K(n). K(n) = sorgu başına
    #    ortalama karşılaştırma (sayaç CSV'si, kesin), c = n >= 10^4
    #    ölçümlerinde t / K'nin ortancası (gürültüye dayanıklı); aralık
    #    en küçük ve en büyük c ile. Sınama: "dogrulama" ölçümü.
    kest = []
    for yontem in ("dogrusal", "nobetcili"):
        seri = t[("Python", "-", yontem)]
        sutun = f"{yontem}_kars_ort"
        xs = [n for n in sorted(seri) if n >= 10000]
        cler = sorted(seri[n] / float(sayac[n][sutun]) for n in xs)
        orta = len(cler) // 2
        c = cler[orta] if len(cler) % 2 else \
            (cler[orta - 1] + cler[orta]) / 2
        dogrulama = {int(s["n"]): float(s["ortanca_ns"]) for s in olcum
                     if s["dil"] == "Python" and s["yontem"] == yontem
                     and s["tur"] == "dogrulama"}
        ek = {int(s["n"]): float(s["ortanca_ns"]) for s in sinama
              if s["yontem"] == yontem}
        for n in [m for m in (1000000, 2000000, 5000000, 10000000)
                  if m not in seri]:
            kars = float(sayac[n][sutun])
            k, alt, ust = c * kars, cler[0] * kars, cler[-1] * kars
            olculen = dogrulama.get(n)
            ek_olc = ek.get(n)
            kest.append({"dil": "Python", "yontem": yontem, "n": n,
                         "model": "t = c·K(n)", "taban_n":
                         f"{xs[0]}..{xs[-1]} ({len(xs)} nokta)",
                         "kars_ort": kars, "ns_kars": c,
                         "ns_kars_az": cler[0], "ns_kars_cok": cler[-1],
                         "kestirim_ns": k, "kestirim_alt_ns": alt,
                         "kestirim_ust_ns": ust,
                         "olculen_ns": olculen if olculen else "—",
                         "hata_yuzde": (k - olculen) / olculen * 100
                         if olculen else "—",
                         "aralikta": ("evet" if alt <= olculen <= ust
                                      else "hayır") if olculen else "—",
                         "ek_olculen_ns": ek_olc if ek_olc else "—",
                         "ek_hata_yuzde": (k - ek_olc) / ek_olc * 100
                         if ek_olc else "—",
                         "ek_aralikta": ("evet" if alt <= ek_olc <= ust
                                         else "hayır") if ek_olc else "—",
                         "tur": "kestirim sınaması" if olculen or ek_olc
                         else "kestirim"})
    yaz("h04_deney_kestirim.csv", ["dil", "yontem", "n", "model", "taban_n",
                                   "kars_ort", "ns_kars", "ns_kars_az",
                                   "ns_kars_cok", "kestirim_ns",
                                   "kestirim_alt_ns", "kestirim_ust_ns",
                                   "olculen_ns", "hata_yuzde", "aralikta",
                                   "ek_olculen_ns", "ek_hata_yuzde",
                                   "ek_aralikta", "tur"], kest)

    # 3) Oranlar (seçili n)
    oran = []
    c2 = ("C", "-O2")
    for n in SECILI_N:
        s = {"n": n}
        for dil, der in DIZILIS:
            ad = {"C-O2": "c", "C++-O2": "cpp", "C-O0": "c_O0",
                  "Python-": "py"}[dil + der]
            d, nb, ik = (t[(dil, der, y)].get(n) for y in
                         ("dogrusal", "nobetcili", "ikili"))
            s[f"{ad}_dogrusal_ikili"] = d / ik if d and ik else "—"
            s[f"{ad}_nobetcili_dogrusal"] = nb / d if d and nb else "—"
        for y in ("dogrusal", "ikili"):
            c = t[c2 + (y,)].get(n)
            s[f"O0_O2_{y}"] = t[("C", "-O0", y)][n] / c if c else "—"
            s[f"cpp_c_{y}"] = t[("C++", "-O2", y)][n] / c if c else "—"
            p = t[("Python", "-", y)].get(n)
            s[f"py_c_{y}"] = p / c if p and c else "—"
        oran.append(s)
    yaz("h04_deney_oran.csv", list(oran[0].keys()), oran)

    # 4) Türetilmiş: yoklama başına süre (ikili), eleman başına süre
    #    (doğrusal), log–log eğimler
    tur = []
    for n in sorted(sayac):
        s = {"n": n,
             "ikili_yoklama_ort": float(sayac[n]["ikili_yoklama_ort"]),
             "dogrusal_kars_ort": float(sayac[n]["dogrusal_kars_ort"])}
        for dil, der in DIZILIS:
            ad = {"C-O2": "c", "C++-O2": "cpp", "C-O0": "c_O0",
                  "Python-": "py"}[dil + der]
            ik = t[(dil, der, "ikili")].get(n)
            d = t[(dil, der, "dogrusal")].get(n)
            s[f"{ad}_ns_yoklama"] = ik / s["ikili_yoklama_ort"] if ik \
                else "—"
            s[f"{ad}_ns_eleman"] = d / s["dogrusal_kars_ort"] if d else "—"
        tur.append(s)
    yaz("h04_deney_turetilmis.csv", list(tur[0].keys()), tur)

    print("Kesişim noktaları:")
    for k in kes:
        print(f"  {k['dil']:<6} {k['derleme']:<3} {k['karsilastirma']:<15} "
              f"{k['durum']:<36} n* = {k['kesisim_n']} "
              f"({k['n_alt']}..{k['n_ust']}); ilk geçiş {k['ilk_gecis_n']}")
    print("Python kestirimleri:")
    for k in kest:
        print(f"  {k['yontem']:<9} n = {k['n']:>8}: {k['kestirim_ns']:.4g} ns"
              f" [{k['kestirim_alt_ns']:.4g} … {k['kestirim_ust_ns']:.4g}]"
              f" ({k['tur']}; ölçülen {k['olculen_ns']}, hata "
              f"{k['hata_yuzde']}, aralıkta {k['aralikta']}; ek sınama "
              f"{k['ek_olculen_ns']}, hata {k['ek_hata_yuzde']}, aralıkta "
              f"{k['ek_aralikta']})")
    print("Log–log eğimler (doğrusal, 10^4..10^6):")
    for dil, der in DIZILIS:
        seri = t[(dil, der, "dogrusal")]
        if 10000 in seri and 1000000 in seri:
            print(f"  {dil} {der}: {egim(seri, 10000, 1000000):.3f}")
    print("Log–log eğimler (ikili, 10^3..10^7 ve 10^3..10^5):")
    for dil, der in DIZILIS:
        seri = t[(dil, der, "ikili")]
        print(f"  {dil} {der}: {egim(seri, 1000, 10000000):.3f}, "
              f"{egim(seri, 1000, 100000):.3f}")


if __name__ == "__main__":
    main()

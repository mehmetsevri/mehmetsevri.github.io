/* H04_HA4_sirasiz_dizi.c — AP-2 Hafta 4 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR: ikili arama SIRALI OLMAYAN diziye
 * uygulanıyor. Program çökmez, uyarı da vermez: yalnızca bazı elemanları
 * "yok" der. Ön koşul (a sıralı) bozulunca "x varsa a[lo..hi] içinde"
 * değişmezi de bozulur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA4_sirasiz_dizi.c -o H04_HA4_sirasiz_dizi
 * Düzeltme: H04_HA4_sirasiz_dizi_duzeltilmis.c
 */
#include <stdio.h>

static long ikili_ara(const int a[], long n, int x)
{
    long lo = 0, hi = n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    static const int a[] = {9, 2, 7, 4, 1, 8, 3};   /* HATA: sırasız */
    const long n = sizeof a / sizeof a[0];
    int bulunan = 0;
    printf("a = [9, 2, 7, 4, 1, 8, 3]   (sıralı DEĞİL)\n");
    for (long i = 0; i < n; i++) {
        long k = ikili_ara(a, n, a[i]);
        printf("  ara(%d) = %2ld", a[i], k);
        if (k == -1) {
            printf("   <- dizide VAR (konum %ld)", i);
        }
        printf("\n");
        bulunan += k != -1;
    }
    printf("dizideki %ld elemandan %d tanesi bulunabildi\n", n, bulunan);
    return 0;
}

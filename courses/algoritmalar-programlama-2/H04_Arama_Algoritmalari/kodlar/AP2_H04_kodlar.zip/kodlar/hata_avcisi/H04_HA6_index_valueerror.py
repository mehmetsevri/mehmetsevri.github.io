"""H04_HA6_index_valueerror.py — AP-2 Hafta 4 · Hata Avcısı 6 (Python)
BU DOSYA KASITLI HATA İÇERİR: list.index(x) "bulunamadı" için -1 ya da
None döndürmez; ValueError FIRLATIR. Yakalanmazsa program ilk bulunamayan
değerde durur ve sonraki sorgular hiç yapılmaz.
Çalıştır: python3 H04_HA6_index_valueerror.py
Düzeltme: H04_HA6_index_valueerror_duzeltilmis.py
"""

a = [7, 3, 9, 3, 5]
for x in [9, 3, 6, 5]:
    k = a.index(x)              # HATA: 6 yok -> ValueError
    print(f"a.index({x}) = {k}")
print("tüm sorgular bitti")

/* H04_HA9_size_t_sarmasi_duzeltilmis.c — AP-2 Hafta 4 · Hata Avcısı 9
 * (düzeltilmiş): size_t ile YARI AÇIK aralık [lo, hi) kullanılır:
 * hi = n (n = 0 da sorunsuz), while (lo < hi), hi = mid. Hiçbir adımda
 * çıkarma yapılmadığından sarma olmaz; mid her zaman lo <= mid < hi <= n.
 * (Kapalı aralık isteniyorsa indisler işaretli tutulur: long lo, hi.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA9_size_t_sarmasi_duzeltilmis.c \
 *           -o H04_HA9_size_t_sarmasi_duzeltilmis
 */
#include <stddef.h>
#include <stdio.h>

static long ikili_ara(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;              /* yarı açık: [0, n) */
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        printf("  lo = %zu, hi = %zu, mid = %zu\n", lo, hi, mid);
        if (a[mid] == x) {
            return (long)mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;                   /* çıkarma yok: sarma yok */
        }
    }
    return -1;
}

int main(void)
{
    static const int a[] = {10, 20, 30, 40, 50};
    printf("ara(20):\n");
    printf("  sonuç: %ld\n", ikili_ara(a, 5, 20));
    printf("ara(5) (a[0]'dan küçük):\n");
    printf("  sonuç: %ld\n", ikili_ara(a, 5, 5));
    printf("boş dizi, ara(7):\n");
    printf("  sonuç: %ld\n", ikili_ara(a, 0, 7));
    return 0;
}

/* H04_HA3_orta_nokta_tasmasi_duzeltilmis.c — AP-2 Hafta 4 · Hata
 * Avcısı 3 (düzeltilmiş): mid = lo + (hi - lo) / 2. 0 <= lo <= hi iken
 * hi - lo taşmaz ve sonuç [lo, hi] içinde kalır (Bloch, 2006). Diğer
 * seçenekler: daha geniş tür (long long) ya da işaretsiz toplam ve
 * kaydırma: (int)(((unsigned)lo + (unsigned)hi) >> 1).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA3_orta_nokta_tasmasi_duzeltilmis.c \
 *           -o H04_HA3_orta_nokta_tasmasi_duzeltilmis
 */
#include <limits.h>
#include <stdio.h>

static int sanal_eleman(int i)          /* a[i] = i; sanal dizi */
{
    return i;
}

static int ikili_ara(int n, int x)
{
    int lo = 0, hi = n - 1;
    int adim = 0;
    while (lo <= hi) {
        adim++;
        int mid = lo + (hi - lo) / 2;   /* taşmasız orta nokta */
        if (adim <= 6) {
            printf("  adım %d: lo = %d, hi = %d, mid = %d\n", adim, lo, hi,
                   mid);
        }
        int v = sanal_eleman(mid);
        if (v == x) {
            printf("  %d adımda bulundu\n", adim);
            return mid;
        } else if (v < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    const int n = 2000000000;           /* sanal dizi: a[i] = i */
    printf("INT_MAX = %d, n = %d\n", INT_MAX, n);
    printf("ara(1000) (küçük indis):\n");
    printf("  sonuç: %d\n", ikili_ara(n, 1000));
    printf("ara(n - 1) (son eleman):\n");
    printf("  sonuç: %d\n", ikili_ara(n, n - 1));
    return 0;
}

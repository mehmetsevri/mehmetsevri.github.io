/* H04_HA5_karsilastirici_tasmasi.c — AP-2 Hafta 4 · Hata Avcısı 5
 * BU DOSYA KASITLI HATA İÇERİR: karşılaştırıcı "return x - y;" yazılmış.
 * x ve y ters işaretli ve büyükse x - y int'e sığmaz: İŞARETLİ TAŞMA,
 * TANIMSIZ DAVRANIŞ. Bu derleyicide/bu çalıştırmada fark negatif çıkar,
 * bsearch yanlış yöne gider ve var olan eleman bulunamaz.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA5_karsilastirici_tasmasi.c \
 *           -o H04_HA5_karsilastirici_tasmasi
 *           (tanı: -fsanitize=undefined ekleyin)
 * Düzeltme: H04_HA5_karsilastirici_tasmasi_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

static int kars(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return x - y;               /* HATA: x - y taşabilir (UB) */
}

int main(void)
{
    static const int a[] = {-2000000000, -1900000000, -1800000000,
                            -1700000000, 2000000000};          /* sıralı */
    const size_t n = sizeof a / sizeof a[0];
    for (size_t i = 0; i < n; i++) {
        const int *p = bsearch(&a[i], a, n, sizeof a[0], kars);
        printf("bsearch(%d): %s\n", a[i],
               p == NULL ? "bulunamadı   <- dizide VAR" : "bulundu");
    }
    int x = 2000000000, y = -1800000000;
    printf("kars(%d, %d) = %d (gerçek fark %lld)\n", x, y, kars(&x, &y),
           (long long)x - y);
    return 0;
}

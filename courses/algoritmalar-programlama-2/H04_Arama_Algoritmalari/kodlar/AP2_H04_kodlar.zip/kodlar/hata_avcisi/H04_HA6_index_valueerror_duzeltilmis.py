"""H04_HA6_index_valueerror_duzeltilmis.py — AP-2 Hafta 4 · Hata Avcısı 6
(düzeltilmiş): üç doğru yol. (1) Önce "x in a" sınanır (iki tarama:
in + index); (2) ValueError try/except ile yakalanır (tek tarama);
(3) sözleşmesi açık kendi fonksiyonumuz: bulunamazsa None (Örnek 1).
C++'ta std::find bulamazsa end() döndürür; end() hiçbir zaman
başvurulmamalıdır (tanımsız davranış).
Çalıştır: python3 H04_HA6_index_valueerror_duzeltilmis.py
"""


def dogrusal_ara(a, x):
    for i in range(len(a)):
        if a[i] == x:
            return i
    return None


def main():
    a = [7, 3, 9, 3, 5]
    for x in [9, 3, 6, 5]:
        k1 = a.index(x) if x in a else None         # (1)
        try:                                        # (2)
            k2 = a.index(x)
        except ValueError:
            k2 = None
        k3 = dogrusal_ara(a, x)                     # (3)
        print(f"x = {x}: (1) {k1}  (2) {k2}  (3) {k3}")
    print("tüm sorgular bitti")


if __name__ == "__main__":
    main()

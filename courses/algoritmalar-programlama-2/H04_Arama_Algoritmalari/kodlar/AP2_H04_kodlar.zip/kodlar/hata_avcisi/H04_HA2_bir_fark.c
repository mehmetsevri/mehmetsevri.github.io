/* H04_HA2_bir_fark.c — AP-2 Hafta 4 · Hata Avcısı 2
 * BU DOSYA KASITLI HATA İÇERİR: aralık sözleşmesi ile döngü koşulu
 * uyuşmuyor (bir-fark hataları).
 *  (a) hi = n (yarı açık başlangıç) + while (lo <= hi) (kapalı döngü):
 *      a[n] okunur — dizi dışı erişim (tanımsız davranış).
 *  (b) hi = n - 1 (kapalı başlangıç) + while (lo < hi) (yarı açık döngü):
 *      lo == hi kalan son aday hiç incelenmez — eleman kaçar.
 * Güvenli gösterim: dizi n + 1'lik bir tamponun başındadır; tampon[n]
 * = 999 dizinin parçası değildir, okunduğu görülür (tanımlı okuma).
 * Gerçek belirti: ./H04_HA2_bir_fark asan (tam n'lik malloc; ASan ile)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA2_bir_fark.c -o H04_HA2_bir_fark
 * Düzeltme: H04_HA2_bir_fark_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static long en_buyuk_indis = -1;    /* okunan en büyük indis (gözlem) */

static int oku(const int a[], long i)
{
    if (i > en_buyuk_indis) {
        en_buyuk_indis = i;
    }
    return a[i];
}

/* (a) HATA: [0, n) başlangıcı ile [lo, hi] döngüsü karışmış */
static long ara_a(const int a[], long n, int x)
{
    long lo = 0, hi = n;                /* HATA: kapalı aralıkta n - 1 */
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        int v = oku(a, mid);
        if (v == x) {
            return mid;
        } else if (v < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

/* (b) HATA: [0, n - 1] başlangıcı ile [lo, hi) döngüsü karışmış */
static long ara_b(const int a[], long n, int x)
{
    long lo = 0, hi = n - 1;
    while (lo < hi) {                   /* HATA: lo == hi adayı kaçar */
        long mid = lo + (hi - lo) / 2;
        int v = oku(a, mid);
        if (v == x) {
            return mid;
        } else if (v < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(int argc, char *argv[])
{
    const long n = 5;
    int asan = argc > 1 && strcmp(argv[1], "asan") == 0;
    int *a = malloc((size_t)(asan ? n : n + 1) * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (long i = 0; i < n; i++) {
        a[i] = 10 * (int)(i + 1);       /* 10 20 30 40 50 */
    }
    if (!asan) {
        a[n] = 999;                     /* dizinin parçası değil */
    }
    printf("a = [10, 20, 30, 40, 50]   (n = 5)\n");
    printf("(a) hi = n ve lo <= hi:\n");
    static const int sorgu_a[] = {30, 60, 999};
    for (int t = 0; t < 3; t++) {
        en_buyuk_indis = -1;
        fflush(stdout);
        long k = ara_a(a, n, sorgu_a[t]);
        printf("  ara(%d) = %ld, okunan en büyük indis = %ld%s\n",
               sorgu_a[t], k, en_buyuk_indis,
               en_buyuk_indis >= n ? "  <- DİZİ DIŞI" : "");
    }
    printf("(b) hi = n - 1 ve lo < hi:\n");
    static const int sorgu_b[] = {30, 10, 50, 40};
    for (int t = 0; t < 4; t++) {
        long k = ara_b(a, n, sorgu_b[t]);
        printf("  ara(%d) = %ld%s\n", sorgu_b[t], k,
               k == -1 ? "  <- dizide VAR, bulunamadı" : "");
    }
    int tek[1] = {7};
    printf("  tek elemanlı [7]: ara(7) = %ld\n", ara_b(tek, 1, 7));
    free(a);
    return 0;
}

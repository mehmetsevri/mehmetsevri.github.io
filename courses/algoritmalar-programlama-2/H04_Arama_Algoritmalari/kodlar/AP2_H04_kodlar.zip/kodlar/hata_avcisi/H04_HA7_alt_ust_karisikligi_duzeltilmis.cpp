/* H04_HA7_alt_ust_karisikligi_duzeltilmis.cpp — AP-2 Hafta 4 · Hata
 * Avcısı 7 (düzeltilmiş): ilk konum = lower_bound, son konum =
 * upper_bound - 1, adet = upper_bound - lower_bound. Önce varlık
 * denetlenir: lower_bound == upper_bound ise x yoktur. İki sınır tek
 * çağrıda std::equal_range ile de alınabilir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA7_alt_ust_karisikligi_duzeltilmis.cpp \
 *           -o H04_HA7_alt_ust_karisikligi_duzeltilmis
 */
#include <algorithm>
#include <cstdio>
#include <vector>

int main()
{
    const std::vector<int> a = {1, 2, 2, 2, 4, 7, 7, 9};
    std::printf("a = [1, 2, 2, 2, 4, 7, 7, 9]\n");
    for (int x : {2, 4, 7, 1, 5}) {
        long alt = std::lower_bound(a.begin(), a.end(), x) - a.begin();
        long ust = std::upper_bound(a.begin(), a.end(), x) - a.begin();
        if (alt == ust) {
            std::printf("x = %d: yok (ekleme konumu %ld)\n", x, alt);
            continue;
        }
        auto aralik = std::equal_range(a.begin(), a.end(), x);
        std::printf("x = %d: ilk %ld, son %ld, adet %ld (equal_range: "
                    "%ld..%ld)\n", x, alt, ust - 1, ust - alt,
                    static_cast<long>(aralik.first - a.begin()),
                    static_cast<long>(aralik.second - a.begin()) - 1);
    }
    return 0;
}

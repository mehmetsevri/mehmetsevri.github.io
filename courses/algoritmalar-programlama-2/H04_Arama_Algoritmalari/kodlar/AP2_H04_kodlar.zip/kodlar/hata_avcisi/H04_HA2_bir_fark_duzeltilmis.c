/* H04_HA2_bir_fark_duzeltilmis.c — AP-2 Hafta 4 · Hata Avcısı 2
 * (düzeltilmiş): aralık sözleşmesi tek bir yerde seçilir ve dört öge
 * birlikte ona uyar — başlangıç, döngü koşulu, iki güncelleme:
 *   kapalı [lo, hi]   : hi = n - 1, while (lo <= hi), hi = mid - 1
 *   yarı açık [lo, hi): hi = n,     while (lo < hi),  hi = mid
 * Denetim: n = 0, n = 1, ilk ve son eleman, en küçükten küçük ve en
 * büyükten büyük değer (sınır durumları) her iki sürümde sınanır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA2_bir_fark_duzeltilmis.c -o H04_HA2_bir_fark_duzeltilmis
 */
#include <stdio.h>

static long en_buyuk_indis = -1;    /* okunan en büyük indis (gözlem) */

static int oku(const int a[], long i)
{
    if (i > en_buyuk_indis) {
        en_buyuk_indis = i;
    }
    return a[i];
}

/* Kapalı aralık: aday bölge a[lo..hi] */
static long ara_kapali(const int a[], long n, int x)
{
    long lo = 0, hi = n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        int v = oku(a, mid);
        if (v == x) {
            return mid;
        } else if (v < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

/* Yarı açık aralık: aday bölge a[lo..hi-1] */
static long ara_yari_acik(const int a[], long n, int x)
{
    long lo = 0, hi = n;
    while (lo < hi) {
        long mid = lo + (hi - lo) / 2;
        int v = oku(a, mid);
        if (v == x) {
            return mid;
        } else if (v < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return -1;
}

int main(void)
{
    static const int a[] = {10, 20, 30, 40, 50};
    static const int sorgular[] = {30, 60, 10, 50, 5};
    const long n = 5;
    printf("a = [10, 20, 30, 40, 50]   (n = 5)\n");
    printf("     x  kapalı  yarı açık  okunan en büyük indis\n");
    for (int t = 0; t < 5; t++) {
        en_buyuk_indis = -1;
        long k1 = ara_kapali(a, n, sorgular[t]);
        long e1 = en_buyuk_indis;
        en_buyuk_indis = -1;
        long k2 = ara_yari_acik(a, n, sorgular[t]);
        long e2 = en_buyuk_indis > e1 ? en_buyuk_indis : e1;
        printf("  %4d  %6ld  %9ld  %ld (< n)\n", sorgular[t], k1, k2, e2);
    }
    static const int tek[1] = {7};
    printf("  tek elemanlı [7]: ara(7) = %ld / %ld; boş dizi: %ld / %ld\n",
           ara_kapali(tek, 1, 7), ara_yari_acik(tek, 1, 7),
           ara_kapali(tek, 0, 7), ara_yari_acik(tek, 0, 7));
    return 0;
}

/* H04_HA7_alt_ust_karisikligi.cpp — AP-2 Hafta 4 · Hata Avcısı 7 (C++)
 * BU DOSYA KASITLI HATA İÇERİR: x'in SON konumu lower_bound - 1 ile
 * hesaplanmış; doğrusu upper_bound - 1'dir. lower_bound ilk >= x'i,
 * upper_bound ilk > x'i gösterir; lower_bound - 1 x'ten ÖNCEKİ elemandır.
 * Derleyici uyarmaz; tek kopyalı değerlerde bile sonuç yanlıştır.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA7_alt_ust_karisikligi.cpp -o H04_HA7_alt_ust_karisikligi
 * Düzeltme: H04_HA7_alt_ust_karisikligi_duzeltilmis.cpp
 */
#include <algorithm>
#include <cstdio>
#include <vector>

int main()
{
    const std::vector<int> a = {1, 2, 2, 2, 4, 7, 7, 9};
    std::printf("a = [1, 2, 2, 2, 4, 7, 7, 9]\n");
    for (int x : {2, 4, 7, 1}) {
        long ilk = std::lower_bound(a.begin(), a.end(), x) - a.begin();
        long son = std::lower_bound(a.begin(), a.end(), x) - a.begin() - 1;
        //         HATA: ^^^^^^^^^^^ son konum için upper_bound gerekir
        long adet = son - ilk + 1;
        std::printf("x = %d: ilk %ld, son %ld, adet %ld", x, ilk, son, adet);
        if (son >= 0 && a[son] != x) {
            std::printf("   <- a[son] = %d, x değil", a[son]);
        } else if (son < 0) {
            std::printf("   <- son = -1: dizi dışı indis");
        }
        std::printf("\n");
    }
    return 0;
}

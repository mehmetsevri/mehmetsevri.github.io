/* H04_HA1_sonsuz_dongu_duzeltilmis.c — AP-2 Hafta 4 · Hata Avcısı 1
 * (düzeltilmiş): kapalı aralıkta [lo, hi] mid incelendikten sonra aday
 * aralıktan ÇIKARILMALIDIR: lo = mid + 1 ya da hi = mid - 1. Denetim
 * sorusu: "her adımda hi - lo kesin olarak küçülüyor mu?" (sonlanma).
 * Yarı açık aralıkta [lo, hi) ise lo = mid + 1 ve hi = mid doğrudur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA1_sonsuz_dongu_duzeltilmis.c \
 *           -o H04_HA1_sonsuz_dongu_duzeltilmis
 */
#include <stdio.h>

static long ikili_ara(const int a[], long n, int x)
{
    long lo = 0, hi = n - 1;
    int adim = 0;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        if (++adim <= 4) {
            printf("  lo = %ld, hi = %ld, mid = %ld\n", lo, hi, mid);
        }
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;           /* mid aralıktan çıkarılır */
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    static const int a[] = {10, 20, 30, 40, 50};
    static const int sorgular[] = {30, 40, 50, 45};
    for (int t = 0; t < 4; t++) {
        printf("ara(%d):\n", sorgular[t]);
        long k = ikili_ara(a, 5, sorgular[t]);
        printf("  sonuç: %ld\n", k);
    }
    return 0;
}

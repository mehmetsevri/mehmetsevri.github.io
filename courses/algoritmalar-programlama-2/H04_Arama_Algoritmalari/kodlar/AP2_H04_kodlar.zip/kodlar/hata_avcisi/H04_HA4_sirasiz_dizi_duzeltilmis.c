/* H04_HA4_sirasiz_dizi_duzeltilmis.c — AP-2 Hafta 4 · Hata Avcısı 4
 * (düzeltilmiş): ikili aramanın ön koşulu "dizi sıralı"dır. Ya veri bir
 * kez sıralanır (ön işleme; sıralama H5'te) ve sonra ikili arama yapılır,
 * ya da sırasız veride doğrusal arama kullanılır. Ön koşulu her aramada
 * denetlemek O(n) tutar ve ikili aramanın kazancını yok eder: denetim
 * yalnız geliştirmede (assert) ya da veri değiştiğinde bir kez yapılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA4_sirasiz_dizi_duzeltilmis.c \
 *           -o H04_HA4_sirasiz_dizi_duzeltilmis
 */
#include <stdio.h>

static int sirali_mi(const int a[], long n)
{
    for (long i = 1; i < n; i++) {
        if (a[i - 1] > a[i]) {
            return 0;
        }
    }
    return 1;
}

static long dogrusal_ara(const int a[], long n, int x)
{
    for (long i = 0; i < n; i++) {
        if (a[i] == x) {
            return i;
        }
    }
    return -1;
}

static long ikili_ara(const int a[], long n, int x)
{
    long lo = 0, hi = n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    static const int a[] = {9, 2, 7, 4, 1, 8, 3};
    static const int s[] = {1, 2, 3, 4, 7, 8, 9};   /* aynı veri, sıralı */
    const long n = sizeof a / sizeof a[0];
    int b1 = 0, b2 = 0;
    printf("a sıralı mı? %s -> doğrusal arama\n",
           sirali_mi(a, n) ? "evet" : "hayır");
    printf("s sıralı mı? %s -> ikili arama\n",
           sirali_mi(s, n) ? "evet" : "hayır");
    for (long i = 0; i < n; i++) {
        b1 += dogrusal_ara(a, n, a[i]) != -1;
        b2 += ikili_ara(s, n, a[i]) != -1;
    }
    printf("bulunan: doğrusal (a) %d/%ld, ikili (s) %d/%ld\n", b1, n, b2, n);
    return 0;
}

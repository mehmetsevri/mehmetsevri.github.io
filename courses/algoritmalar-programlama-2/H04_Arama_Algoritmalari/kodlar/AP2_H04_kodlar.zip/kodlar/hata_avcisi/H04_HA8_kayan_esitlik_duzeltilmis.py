"""H04_HA8_kayan_esitlik_duzeltilmis.py — AP-2 Hafta 4 · Hata Avcısı 8
(düzeltilmiş): kayan noktalı aramada durma koşulu TAM EŞİTLİK değil,
(1) aralık genişliği için tolerans, (2) en çok yineleme sayısı ve
(3) aralığın artık bölünemediği (m == a ya da m == b) durumudur.
f(m) == 0.0 yalnızca erken çıkış kısayolu olarak kullanılabilir.
Çalıştır: python3 H04_HA8_kayan_esitlik_duzeltilmis.py
"""

EN_COK = 200


def f(x):
    return x * x - 2.0


def ikiye_bolme(a, b, tol):
    k = 0
    while b - a > tol and k < EN_COK:
        m = a + (b - a) / 2
        if m <= a or m >= b:            # a ile b komşu double
            break
        k += 1
        if f(m) == 0.0:
            return m, k
        if f(m) < 0:
            a = m
        else:
            b = m
    return a + (b - a) / 2, k


def main():
    for tol in [1e-6, 1e-12, 0.0]:
        kok, k = ikiye_bolme(1.0, 2.0, tol)
        print(f"tol = {tol:g}: kök = {kok!r}, {k} yineleme, "
              f"f(kök) = {f(kok):.3e}")


if __name__ == "__main__":
    main()

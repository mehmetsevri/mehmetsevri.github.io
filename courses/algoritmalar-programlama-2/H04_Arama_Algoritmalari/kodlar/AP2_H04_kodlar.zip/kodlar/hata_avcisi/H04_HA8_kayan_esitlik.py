"""H04_HA8_kayan_esitlik.py — AP-2 Hafta 4 · Hata Avcısı 8 (Python)
BU DOSYA KASITLI HATA İÇERİR: ikiye bölme "while f(m) != 0.0" ile
durduruluyor. √2 bir double olarak tam gösterilemez; √2'nin iki yanındaki
komşu double'lar için bile m * m - 2.0 = ∓4.44e-16 olur, 0.0 olmaz. a ile
b komşu olunca (bu örnekte 53. yinelemede) m artık değişmez: döngü
SONSUZA dek sürer.
Güvenli gösterim: 200 yinelemede durdurulur.
Korumasız (gerçek belirti): python3 H04_HA8_kayan_esitlik.py korumasiz
Düzeltme: H04_HA8_kayan_esitlik_duzeltilmis.py
"""

import sys

SINIR = 200


def f(x):
    return x * x - 2.0


def main():
    korumali = not (len(sys.argv) > 1 and sys.argv[1] == "korumasiz")
    a, b = 1.0, 2.0
    m = a + (b - a) / 2
    k = 0
    onceki = None
    degismedi_ilk = None
    while f(m) != 0.0:              # HATA: kayan noktada tam eşitlik
        if f(m) < 0:
            a = m
        else:
            b = m
        m = a + (b - a) / 2
        k += 1
        if m == onceki and degismedi_ilk is None:
            degismedi_ilk = k
            print(f"{k}. yineleme: m artık değişmiyor: m = {m!r}, "
                  f"f(m) = {f(m)!r}", flush=True)
        onceki = m
        if korumali and k >= SINIR:     # yalnızca gösterim koruması
            print(f"{SINIR} yinelemede f(m) == 0 olmadı; döngü durduruldu")
            return
    print(f"kök bulundu: {m!r}")


if __name__ == "__main__":
    main()

/* H04_HA3_orta_nokta_tasmasi.c — AP-2 Hafta 4 · Hata Avcısı 3
 * BU DOSYA KASITLI HATA İÇERİR: int mid = (lo + hi) / 2. lo + hi,
 * INT_MAX'ı aşınca İŞARETLİ TAŞMA olur: C'de TANIMSIZ DAVRANIŞ.
 * Derleyici her şeyi yapabilir; çıktı yalnızca "bu derleyicide, bu
 * çalıştırmada" gözlenendir. Dizi sanaldır (a[i] = i; bellek okunmaz).
 * Güvenli gösterim: 40 adımda bitmeyen arama durdurulur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA3_orta_nokta_tasmasi.c -o H04_HA3_orta_nokta_tasmasi
 *           (tanı: -fsanitize=undefined ekleyin)
 * Düzeltme: H04_HA3_orta_nokta_tasmasi_duzeltilmis.c
 */
#include <limits.h>
#include <stdio.h>

#define ADIM_SINIRI 40

static int sanal_eleman(int i)          /* a[i] = i; sanal dizi */
{
    return i;
}

static int ikili_ara(int n, int x)
{
    int lo = 0, hi = n - 1;
    int adim = 0;
    while (lo <= hi) {
        if (++adim > ADIM_SINIRI) {     /* yalnızca gösterim koruması */
            printf("  %d adımda bitmedi\n", ADIM_SINIRI);
            return -2;
        }
        int mid = (lo + hi) / 2;        /* HATA: lo + hi taşabilir (UB) */
        if (adim <= 6) {
            printf("  adım %d: lo = %d, hi = %d, mid = %d\n", adim, lo, hi,
                   mid);
        }
        int v = sanal_eleman(mid);
        if (v == x) {
            return mid;
        } else if (v < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    const int n = 2000000000;           /* sanal dizi: a[i] = i */
    printf("INT_MAX = %d, n = %d\n", INT_MAX, n);
    printf("ara(1000) (küçük indis, toplam taşmaz):\n");
    printf("  sonuç: %d\n", ikili_ara(n, 1000));
    printf("ara(n - 1) (son eleman):\n");
    printf("  sonuç: %d\n", ikili_ara(n, n - 1));
    return 0;
}

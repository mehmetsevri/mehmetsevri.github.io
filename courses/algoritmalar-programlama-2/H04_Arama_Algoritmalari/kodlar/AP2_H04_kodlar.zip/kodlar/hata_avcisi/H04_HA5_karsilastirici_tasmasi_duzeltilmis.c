/* H04_HA5_karsilastirici_tasmasi_duzeltilmis.c — AP-2 Hafta 4 · Hata
 * Avcısı 5 (düzeltilmiş): karşılaştırıcı yalnızca İŞARET bildirmelidir;
 * fark hesaplamaz. (x > y) - (x < y) her zaman -1, 0 ya da 1'dir ve
 * taşmaz. (Fark yalnızca değer aralığı küçük türlerde, ör. iki unsigned
 * char'ın int'e yükseltilmiş farkında güvenlidir.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA5_karsilastirici_tasmasi_duzeltilmis.c \
 *           -o H04_HA5_karsilastirici_tasmasi_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

static int kars(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);   /* -1, 0, 1: taşma yok */
}

int main(void)
{
    static const int a[] = {-2000000000, -1900000000, -1800000000,
                            -1700000000, 2000000000};          /* sıralı */
    const size_t n = sizeof a / sizeof a[0];
    for (size_t i = 0; i < n; i++) {
        const int *p = bsearch(&a[i], a, n, sizeof a[0], kars);
        printf("bsearch(%d): %s\n", a[i],
               p == NULL ? "bulunamadı" : "bulundu");
    }
    int x = 2000000000, y = -1800000000;
    printf("kars(%d, %d) = %d\n", x, y, kars(&x, &y));
    return 0;
}

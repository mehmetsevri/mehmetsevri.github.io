/* H04_HA9_size_t_sarmasi.c — AP-2 Hafta 4 · Hata Avcısı 9
 * BU DOSYA KASITLI HATA İÇERİR: kapalı aralık [lo, hi] size_t ile
 * yazılmış. x, a[0]'dan küçükse mid = 0 iken hi = mid - 1 SARAR:
 * SIZE_MAX olur (işaretsiz aritmetik tanımlıdır), lo <= hi doğru kalır,
 * sonraki mid devasa bir indistir ve a[mid] okuması DİZİ DIŞI ERİŞİMDİR
 * (tanımsız davranış). n = 0 iken de hi = 0 - 1 = SIZE_MAX başlar.
 * Güvenli gösterim: a[mid] okunmadan önce mid >= n denetlenip yazılır.
 * Korumasız (gerçek belirti): ./H04_HA9_size_t_sarmasi korumasiz
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA9_size_t_sarmasi.c -o H04_HA9_size_t_sarmasi
 * Düzeltme: H04_HA9_size_t_sarmasi_duzeltilmis.c
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int korumali = 1;

static long ikili_ara(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n - 1;          /* HATA: n = 0 iken SIZE_MAX */
    while (lo <= hi) {
        size_t mid = lo + (hi - lo) / 2;
        printf("  lo = %zu, hi = %zu, mid = %zu\n", lo, hi, mid);
        fflush(stdout);
        if (korumali && mid >= n) {     /* yalnızca gösterim koruması */
            printf("  mid >= n: a[mid] dizi dışı olurdu; durduruldu\n");
            return -2;
        }
        if (a[mid] == x) {
            return (long)mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;               /* HATA: mid = 0 iken sarar */
        }
    }
    return -1;
}

int main(int argc, char *argv[])
{
    static const int a[] = {10, 20, 30, 40, 50};
    if (argc > 1 && strcmp(argv[1], "korumasiz") == 0) {
        korumali = 0;
    }
    printf("SIZE_MAX = %zu\n", (size_t)SIZE_MAX);
    printf("ara(20):\n");
    printf("  sonuç: %ld\n", ikili_ara(a, 5, 20));
    printf("ara(5) (a[0]'dan küçük):\n");
    fflush(stdout);
    printf("  sonuç: %ld\n", ikili_ara(a, 5, 5));
    printf("boş dizi, ara(7):\n");
    fflush(stdout);
    printf("  sonuç: %ld\n", ikili_ara(a, 0, 7));
    return 0;
}

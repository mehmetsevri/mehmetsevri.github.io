/* H04_HA1_sonsuz_dongu.c — AP-2 Hafta 4 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR: kapalı aralıkta [lo, hi] "lo = mid"
 * yazılmış (doğrusu lo = mid + 1). lo == mid olduğunda aralık daralmaz:
 * son elemanı ya da en büyükten büyük bir değeri ararken sonsuz döngü.
 * Güvenli gösterim: 20 adımda bitmeyen arama durdurulur.
 * Korumasız (gerçek belirti): ./H04_HA1_sonsuz_dongu korumasiz
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_HA1_sonsuz_dongu.c -o H04_HA1_sonsuz_dongu
 * Düzeltme: H04_HA1_sonsuz_dongu_duzeltilmis.c
 */
#include <stdio.h>
#include <string.h>

#define ADIM_SINIRI 20

static int korumali = 1;

static long ikili_ara(const int a[], long n, int x)
{
    long lo = 0, hi = n - 1;
    long adim = 0;
    while (lo <= hi) {
        adim++;
        if (korumali && adim > ADIM_SINIRI) {     /* yalnızca gösterim */
            printf("  %d adımda bitmedi: lo = %ld, hi = %ld değişmiyor\n",
                   ADIM_SINIRI, lo, hi);
            return -2;
        }
        long mid = lo + (hi - lo) / 2;
        if (adim <= 4) {
            printf("  lo = %ld, hi = %ld, mid = %ld\n", lo, hi, mid);
            fflush(stdout);
        }
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid;               /* HATA: mid zaten elendi; mid + 1 */
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(int argc, char *argv[])
{
    static const int a[] = {10, 20, 30, 40, 50};
    static const int sorgular[] = {30, 40, 50, 45};
    if (argc > 1 && strcmp(argv[1], "korumasiz") == 0) {
        korumali = 0;
    }
    for (int t = 0; t < 4; t++) {
        printf("ara(%d):\n", sorgular[t]);
        fflush(stdout);
        long k = ikili_ara(a, 5, sorgular[t]);
        printf("  sonuç: %ld\n", k);
    }
    return 0;
}

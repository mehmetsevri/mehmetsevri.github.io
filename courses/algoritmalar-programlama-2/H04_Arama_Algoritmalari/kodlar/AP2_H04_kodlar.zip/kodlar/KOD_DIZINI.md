# Hafta 4 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, çıktı türü, amacı ve derleme durumuyla aşağıdadır. **Ders notu / Sunum / Web** sütunları dosyanın kodunun gösterildiği yerleri verir: ders notu bölümü (Ek A: C++ ve Python karşılıkları), slayt numarası, web sayfasındaki bölüm kimliği. Ortam: gcc/g++ 13.3 (x86-64 Linux, glibc), Python 3.11.15 (örnekler 3.10 uyumludur; 3.10, 3.12 ve 3.13 ile de aynı stdout doğrulandı).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program [-lm]` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`.

Eşdeğerlik: `python3 esdeger_test.py .` → **14/14 GEÇTİ** (13 “=”, 1 “Δ”), derleyici uyarısı ve sütun aşımı notu 0; `--asan` (AddressSanitizer + UBSan) ile de tümü GEÇTİ.


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Ortak modül | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H04_01_dogrusal_arama` | ★ | = | evet | Doğrusal arama: ilk konum, bulunamazsa −1 / None; sıralı dizide erken çıkış | — | 4.1, Ek A | slayt 39 | `#h04-dogrusal` |
| `H04_02_nobetcili_arama` | ★ | = | evet | Nöbetçili doğrusal arama: sınır denetimi kalkar, karşılaştırma sayısı 2n + 1'den n + 2'ye iner | — | 4.1, Ek A | slayt 13 | `#h04-dogrusal` |
| `H04_03_ikili_arama` | ★ | = | evet | İkili arama — yinelemeli, kapalı aralık [lo, hi]; yoklama sayısı ≤ ⌊log₂ n⌋ + 1 | ortak_rastgele | 4.2, Ek A | slayt 23 | `#h04-ikili` |
| `H04_04_yari_acik_aralik` | ★★ | = | evet | İkili arama — yarı açık aralık [lo, hi) ve değişmez assert'leri; ekleme konumu | — | 4.2, Ek A | — | `#h04-ikili` |
| `H04_05_ozyinelemeli_ikili` | ★★ | = | evet | İkili arama — özyinelemeli: T(n) = T(n/2) + c; çağrı ve derinlik sayaçları | — | 4.2, Ek A | — | `#h04-ikili` |
| `H04_06_orta_nokta_tasmasi` | ★★ | Δ | — | Orta nokta taşması: (lo + hi) / 2 ile int32 sınırında hata ve güvenli lo + (hi − lo) / 2 | — | 5.1, Ek A | — | `#h04-ikili` |
| `H04_07_alt_ust_sinir` | ★★ | = | evet | lower_bound ve upper_bound; ilk/son konum ve bir değerin kaç kez geçtiği | ortak_rastgele | 4.3, Ek A | slayt 28, 38 | `#h04-varyantlar` |
| `H04_08_ekleme_konumu` | ★★ | = | — | Ekleme konumu ve sıralı diziye ekleme: arama O(log n), kaydırma O(n) | ortak_rastgele | 5.2, Ek A | — | `#h04-varyantlar` |
| `H04_09_dondurulmus_dizi` | ★★★ | = | — | Döndürülmüş sıralı dizide arama; döndürme noktası; tekrar eden elemanlarda O(n) | — | 5.3, Ek A | — | `#h04-varyantlar` |
| `H04_10_karekok_tahmin` | ★★ | = | evet | Cevap üzerinde ikili arama: tamsayı karekök ve sayı tahmin oyunu (en çok ⌊log₂ N⌋ + 1 soru) | ortak_rastgele | 4.4, Ek A | slayt 30 | `#h04-cevap` |
| `H04_11_ikiye_bolme` | ★★ | = | evet | İkiye bölme yöntemiyle denklem kökü: x³ − x − 2 = 0; tolerans ve yineleme sayısı | — | 4.5, Ek A | — | `#h04-cevap` |
| `H04_12_genel_arama` | ★★★ | = | — | Genel arama: karşılaştırıcı işaretçisiyle struct dizisinde arama; bsearch / std::lower_bound / bisect | — | 5.4, Ek A | — | `#h04-genel` |
| `H04_13_sure_karsilastirma` | ★★★ | = | — | Doğrusal ve ikili arama süre karşılaştırması ve kesişim noktası | ortak_rastgele, zamanlayici | Ek A | — | `#h04-deney` |
| `H04_14_merdiven_aramasi` | ★★★ | = | evet | Satır ve sütunları sıralı matriste merdiven araması: en çok m + n − 1 adım | ortak_rastgele | 4.6, Ek A | slayt 36 | `#h04-merdiven-arama` |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`. Beklenen çıktılar: `ciktilar/KÖK.txt` (“=”), Örnek 6 için `ciktilar/H04_06_orta_nokta_tasmasi_{c,cpp,py}.txt` (Δ). C++/Python'da öğretilen dil farkı satırları ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`. İsteğe bağlı argümanlar: Örnek 4 `bozuk` (sırasız dizi: assert durdurur), Örnek 13 `--olc` (süreler ve kesişim kestirimi stderr'e).

Ortak modüller (90_Ortak_Varliklar/kod_ortak kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`.


## 2. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir (hata mantıksaldır ya da tanımsız davranıştır). Gerçek belirtiler (derleme komutu, çıktı, çıkış kodu/sinyal, sanitizer raporu) `hata_avcisi/ciktilar/` altındadır.

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H04_HA1_sonsuz_dongu.c` | C | kasıtlı hata | Kapalı aralıkta lo = mid (mid + 1 yerine): son eleman ve en büyükten büyük değer aranırken sonsuz döngü (adım sınırlı varsayılan; korumasiz argümanıyla zaman aşımı) | `ciktilar/H04_HA1_sonsuz_dongu.txt` | 7 | slayt 45 | `#h04-hata-avcisi` |
| `hata_avcisi/H04_HA1_sonsuz_dongu_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H04_HA1_sonsuz_dongu_duzeltilmis.txt` | — | slayt 45 | — |
| `hata_avcisi/H04_HA2_bir_fark.c` | C | kasıtlı hata | Bir-fark hataları: hi = n + lo <= hi (a[n] okunur; ASan: heap-buffer-overflow) ve hi = n - 1 + lo < hi (son aday kaçar: 50 ve tek elemanlı dizi bulunamaz) | `ciktilar/H04_HA2_bir_fark.txt` | 7 | — | — |
| `hata_avcisi/H04_HA2_bir_fark_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H04_HA2_bir_fark_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H04_HA3_orta_nokta_tasmasi.c` | C | kasıtlı hata | int mid = (lo + hi) / 2: işaretli taşma (tanımsız davranış); sanal 2·10⁹'luk dizide mid negatif, arama 40 adımda bitmez; UBSan iletisi | `ciktilar/H04_HA3_orta_nokta_tasmasi.txt` | 7 | — | `#h04-hata-avcisi` |
| `hata_avcisi/H04_HA3_orta_nokta_tasmasi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H04_HA3_orta_nokta_tasmasi_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H04_HA4_sirasiz_dizi.c` | C | kasıtlı hata | Sırasız diziye ikili arama: 7 elemandan 3'ü bulunabildi; uyarı/çökme yok | `ciktilar/H04_HA4_sirasiz_dizi.txt` | 7 | — | — |
| `hata_avcisi/H04_HA4_sirasiz_dizi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H04_HA4_sirasiz_dizi_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H04_HA5_karsilastirici_tasmasi.c` | C | kasıtlı hata | bsearch karşılaştırıcısında return x - y: taşma (tanımsız davranış); iki eleman bulunamaz; UBSan iletisi; düzeltme (x > y) - (x < y) | `ciktilar/H04_HA5_karsilastirici_tasmasi.txt` | 7 | — | `#h04-hata-avcisi` |
| `hata_avcisi/H04_HA5_karsilastirici_tasmasi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H04_HA5_karsilastirici_tasmasi_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H04_HA6_index_valueerror.py` | Python | kasıtlı hata | Python list.index bulamayınca ValueError fırlatır: program ilk bulunamayan değerde durur | `ciktilar/H04_HA6_index_valueerror.txt` | 7 | — | `#h04-hata-avcisi` |
| `hata_avcisi/H04_HA6_index_valueerror_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H04_HA6_index_valueerror_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H04_HA7_alt_ust_karisikligi.cpp` | C++ | kasıtlı hata | Son konum için lower_bound - 1 (doğrusu upper_bound - 1): yanlış konum ve adet; x = 1'de -1 | `ciktilar/H04_HA7_alt_ust_karisikligi.txt` | 7 | — | — |
| `hata_avcisi/H04_HA7_alt_ust_karisikligi_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H04_HA7_alt_ust_karisikligi_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H04_HA8_kayan_esitlik.py` | Python | kasıtlı hata | İkiye bölmede while f(m) != 0.0: 53. yinelemeden sonra m değişmez, döngü sonsuz (sınırlı varsayılan; korumasiz argümanıyla zaman aşımı) | `ciktilar/H04_HA8_kayan_esitlik.txt` | 7 | — | — |
| `hata_avcisi/H04_HA8_kayan_esitlik_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H04_HA8_kayan_esitlik_duzeltilmis.txt` | — | — | — |
| `hata_avcisi/H04_HA9_size_t_sarmasi.c` | C | kasıtlı hata | size_t ile kapalı aralık: hi = mid - 1 sarar (SIZE_MAX); korumasız: SIGSEGV; ASan: global-buffer-overflow | `ciktilar/H04_HA9_size_t_sarmasi.txt` | 7 | — | `#h04-hata-avcisi` |
| `hata_avcisi/H04_HA9_size_t_sarmasi_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H04_HA9_size_t_sarmasi_duzeltilmis.txt` | — | — | — |

## 3. Haftanın Deneyi (deney/)

| Dosya | Tür | Açıklama |
|---|---|---|
| `deney/c/H04_deney_arama.c (+ ortak_rastgele, zamanlayici)` | deney programı (C) | `sayac N` (deterministik sayaçlar) ya da `olc YONTEM N SORGU TEKRAR` (CSV satırı); sıfır uyarı |
| `deney/cpp/H04_deney_arama.cpp (+ .hpp)` | deney programı (C++) | aynı arayüz; sıfır uyarı |
| `deney/python/H04_deney_arama.py (+ .py)` | deney programı (Python) | aynı arayüz |
| `deney/olcum_calistir.py` | ölçüm sürücüsü | derler, ölçer, aykırıları yineler; `sonuclar/h04_deney_olcum.csv`, `h04_deney_sayac.csv`, `OLCUM_ORTAMI.txt` |
| `deney/kestirim_sina.py` | kestirim sınaması | Python doğrusal ve nöbetçili, n = 2·10⁶ ve 5·10⁶ (2 × 3 tekrar): `sonuclar/h04_deney_kestirim_sinama.csv` |
| `deney/cozumle.py` | çözümleme | kesişim, kestirim, oranlar: `sonuclar/h04_deney_{kesisim,kestirim,oran,turetilmis}.csv` |
| `deney/sonuclar/*.csv` | ham ve türetilmiş veri | ayırıcı `;`, birimler sütun adında (`_ns`) |
| `deney/OLCUM_ORTAMI.txt` | ölçüm ortamı | işlemci, önbellek, derleyici sürümleri, tarih, toplam süre |

Grafikler: `gorseller/h04_deney_{sure,oran,sayac}_{belge,sunum}.png` (kaynak `gorseller/kaynak/h04_deney_grafik.py`).


## 4. Kavram, alıştırma ve quiz programları (kavram/, alistirmalar/, quiz/)

Ders notunda, sunumda ya da web sayfasında gösterilen ve merdivende olmayan her kod parçası buradaki küçük, derlenip çalışan programlardandır. Kavram programlarının çıktıları `kavram/ciktilar/` altındadır (ilk satır ortam bilgisi); alıştırma ve quiz programlarının çıktıları yanıtı verdiği için bu klasörde yoktur, öğrenci programı kendisi çalıştırır. Kasıtlı hatalı alıştırmanın başlığında “BU DOSYA KASITLI HATA İÇERİR”, Parsons dosyasında “Tamamlanacak; bu hâliyle derlenmez” yazar. Atölye dosyaları (A06–A08) bu hâliyle doğru ama yavaş bir yer tutucuyla çalışır; öğrenci yer tutucuyu kendi çözümüyle değiştirir. Kodu gösterilmeyip yalnızca çıktısı (sayılar, şekiller) kullanılan programlarda yer “çıktısı:” ile verilir.

| Dosya | Tür | Amaç | Derleme | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|
| `kavram/H04_K01_bsearch.c` | kavram programı | C standart kütüphanesindeki bsearch: void * taban, öge sayısı, öge boyutu ve karşılaştırıcı; dönüş bir işaretçidir (NULL: yok) | sıfır uyarı | 8 | — | `#h04-genel` |
| `kavram/H04_K02_lower_bound.cpp` | kavram programı | C++ <algorithm> ikili arama ailesi: lower_bound, upper_bound, equal_range, binary_search; "küçüktür" yüklemi ve partition_point (monoton yüklemde ilk "doğru") | sıfır uyarı | 8 | — | `#h04-genel` |
| `kavram/H04_K03_bisect.py` | kavram programı | Python bisect modülü: bisect_left / bisect_right, insort ve key= (3.10+); list.index'in "bulunamadı" sözleşmesi (ValueError) | — | 8 | — | `#h04-genel` |
| `kavram/H04_K04_ustel_arama.c` | kavram programı | Üstel (galloping) arama: sınır 1, 2, 4, 8, ... ikiye katlanır; x'i aşan ilk sınırdan sonra yalnızca son aralıkta ikili arama. x'in konumu k ise yoklama sayısı O(log k) (n'den bağımsız) | sıfır uyarı | çıktısı: 5.6 | çıktısı: slayt 52 | çıktısı: `#h04-ileri` |
| `kavram/H04_K05_interpolasyon.c` | kavram programı | İnterpolasyon araması: mid yerine değere göre kestirilen konum (telefon rehberinde "S" harfini sona yakın açmak). Düzgün dağılımlı veride çok az yoklama, çarpık veride çok fazla | sıfır uyarı | çıktısı: 5.6 | çıktısı: slayt 52 | çıktısı: `#h04-ileri` |
| `kavram/H04_K06_fonksiyon_isaretcisi.c` | kavram programı | Fonksiyonu değer olarak aktarmak: ikiye bölme yöntemine denklem bir fonksiyon işaretçisi (double (*)(double)) ile verilir | sıfır uyarı | 13 | slayt 48; çıktısı: slayt 49 | `#h04-ileri` |
| `kavram/H04_K07_kapasite.c` | kavram programı | Cevap üzerinde ikili arama ile bir kapasite problemi: n paket SIRAYLA en çok D seferde taşınacak; en küçük kamyon kapasitesi? Yüklem "kapasite c yeter" monotondur: Y…Y D…D; ilk D aranır | sıfır uyarı | çıktısı: 4.4 | çıktısı: slayt 34 | `#h04-cevap` |
| `kavram/H04_K08_ilk_kotu_surum.py` | kavram programı | git bisect'in fikri: sürümler 1..k sıralı, "hata var mı?" yüklemi monoton (iyi…iyi kötü…kötü); ilk kötü sürüm ikili aramayla en çok ⌈log2 k⌉ testte bulunur. Yüklem bir fonksiyon olarak aktarılır. | — | 9 | çıktısı: slayt 48 | `#h04-muhendis` |
| `kavram/H04_K09_on_isleme.c` | kavram programı | Ön işleme ile sorgu maliyeti ödünleşimi: k sorgu için (a) her sorguda doğrusal arama, (b) bir kez sırala (qsort) + her sorguda ikili arama. Karşılaştırmalar SAYILIR; hangi k'den sonra sıralamak kâr eder? | sıfır uyarı | çıktısı: 3.1, 9 | çıktısı: slayt 48 | çıktısı: `#h04-kavramlar`, `#h04-muhendis` |
| `kavram/H04_K10_adres_formulu.c` | kavram programı | Genel aramanın adres hesabı: i. öge taban + i × boyut baytta (AP-1 H10 adres formülü). struct ogrenci'nin boyutu, alan konumları (offsetof) ve dolgu (padding) bu makinede | sıfır uyarı | çıktısı: 3.5, 5.4 | çıktısı: slayt 42 | çıktısı: `#h04-genel` |
| `alistirmalar/H04_A01_cikti_tahmini.c` | alıştırma | Kapalı aralıklı ikili aramanın incelediği mid değerlerini ÇALIŞTIRMADAN tahmin edin; sonra çalıştırıp karşılaştırın | sıfır uyarı | Alıştırma 4.1 | — | `#h04-alistirmalar` |
| `alistirmalar/H04_A02_hata_bul_karekok.c` | alıştırma | Kasıtlı hata: tamsayı karekök ⌊√n⌋ bazı n değerlerinde bir eksik çıkıyor. Hangi n'lerde? Yüklemin tanımına bakın (Örnek 10). | sıfır uyarı | Alıştırma 4.7 | — | `#h04-alistirmalar` |
| `alistirmalar/H04_A03_parsons_ust_sinir.c` | alıştırma | Tamamlanacak (derlenmez): Aşağıdaki satırlar upper_bound'un (ilk a[i] > x konumu; hepsi <= x ise n) KARIŞTIRILMIŞ satırlarıdır. Doğru sıraya ve girintiye koyun; değişmezi yorum olarak yazın. | tamamlanacak (derlenmez) | Alıştırma 4.9 | — | `#h04-alistirmalar` |
| `alistirmalar/H04_A04_orta_nokta.c` | alıştırma | İki orta nokta ifadesi negatif indislerde aynı mı? C sürümü; eşi H04_A04_orta_nokta.py. Önce iki programın çıktısını tahmin edin, sonra çalıştırın. | sıfır uyarı | Alıştırma 4.13 | — | `#h04-alistirmalar` |
| `alistirmalar/H04_A04_orta_nokta.py` | alıştırma | İki orta nokta ifadesi negatif indislerde aynı mı? Python sürümü; eşi H04_A04_orta_nokta.c. Önce iki programın çıktısını tahmin edin, sonra çalıştırın. | — | Alıştırma 4.13 | — | `#h04-alistirmalar` |
| `alistirmalar/H04_A05_iki_yari.c` | alıştırma | Sıralı olmayan dizide "ikiye böl, İKİ yarıda da ara" yapan özyinelemeli arama. Çağrı sayısı için bir yineleme bağıntısı yazın ve çözün; sonra programın sayaçlarıyla karşılaştırın | sıfır uyarı | Alıştırma 4.3 | — | `#h04-alistirmalar` |
| `alistirmalar/H04_A06_test_paketi.c` | alıştırma | "Doğru ikili aramayı yaz" meydan okumasının ortak test paketi. ogrenci_ara fonksiyonunu KENDİ ikili aramanızla değiştirin. Diziye yalnızca eleman(i) ile erişin ve her adımda eleman(mid)'i BİR KEZ çağırın: yoklamalar sayılır, dizi dışı okuma ve sonsuz döngü yakalanır. Yer tutucu doğru ama yavaş bir doğrusal aramadır. | sıfır uyarı | Atölye 1 (11.8) | — | — |
| `alistirmalar/H04_A06_test_paketi.py` | alıştırma | "Doğru ikili aramayı yaz" meydan okumasının ortak test paketi. ogrenci_ara fonksiyonunu KENDİ ikili aramanızla değiştirin. Diziye yalnızca a.eleman(i) ile erişin ve her adımda eleman(mid)'i BİR KEZ çağırın: yoklamalar sayılır, dizi dışı okuma (negatif indis dahil) ve sonsuz döngü yakalanır. Yer tutucu doğru ama yavaş bir doğrusal aramadır. | — | Atölye 1 (11.8) | — | — |
| `alistirmalar/H04_A07_sayi_tahmin.c` | alıştırma | İki kip. "bilgisayar": bilgisayar 1..N arasında bir sayı tutar (ortak LCG), siz tahmin edersiniz. "ogrenci": siz bir sayı tutarsınız, bilgisayar ikili aramayla sorar; b (daha büyük), k (daha küçük), d (doğru) yanıtlarını verirsiniz. | sıfır uyarı | Atölye 2 (11.9) | — | — |
| `alistirmalar/H04_A08_varyant_avi.c` | alıştırma | Beş problemi lower_bound ile O(log n)'de çözün: 1–3 yalnızca alt_sinir çağrılarıyla; 4–5 alt_sinir'in koşulu değiştirilmiş bir kopyasıyla (4'te yoklama++ satırını koruyun; 5'te yoklamayı kotu_mu sayar). Şimdilik her çözüm doğrusal kâhini çağırır: sonuçlar doğrudur ama yoklama sınırı aşılır. | sıfır uyarı | Atölye 3 (11.10) | — | — |
| `quiz/H04_Q01_alt_sinir_izle.c` | quiz | lower_bound'un incelediği mid değerlerini izleme | sıfır uyarı | — | — | `#h04-quiz` |
| `quiz/H04_Q02_bisect.py` | quiz | bisect_left ve bisect_right'ın tekrar eden değerdeki sonuçları | — | — | — | `#h04-quiz` |


## 5. Diğer dosyalar

- `ornekler.json` — örnek üst verisi (başlık, düzey, tür, amiral, ortak modül, farklar satır numaraları, dil_notu).
- `esdeger_test.py` — üç dilin derlenip aynı çıktıyı verdiğini (Δ örneğinde beklenen dil farkını) sınar; `--asan` ile AddressSanitizer + UBSan.
- Diyagramlar: `gorseller/kaynak/h04_diyagramlar.py` (izleme verisi `h04_izlemeler.json`, kavram programı çıktıları `h04_ek_kodlar.json`) ve `gorseller/kaynak/h04_deney_grafik.py`; ortak gösterim `gorseller/kaynak/diag.py`.

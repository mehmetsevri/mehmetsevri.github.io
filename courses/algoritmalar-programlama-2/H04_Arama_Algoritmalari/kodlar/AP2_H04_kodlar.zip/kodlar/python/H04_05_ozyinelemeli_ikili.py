"""H04_05_ozyinelemeli_ikili.py — AP-2 Hafta 4 · Örnek 5 (★★)
Amaç    : Özyinelemeli ikili arama [lo, hi): T(n) = T(n/2) + c;
          çağrı ve derinlik sayaçları, bağıntının açılımı
Çalıştır: python3 H04_05_ozyinelemeli_ikili.py
Eşleri  : c/H04_05_ozyinelemeli_ikili.c · cpp/H04_05_ozyinelemeli_ikili.cpp
Çıktı   : üç dilde aynı (=)
"""

cagri = 0           # toplam çağrı sayısı
en_derin = 0        # en büyük özyineleme derinliği


# x'i a[lo..hi-1] içinde arar; konum ya da -1. derinlik: 1, 2, ...
def ikili_ara_oz(a, lo, hi, x, derinlik):
    global cagri, en_derin
    cagri += 1
    if derinlik > en_derin:
        en_derin = derinlik
    if lo >= hi:                        # temel durum: boş aralık
        return -1
    mid = (lo + hi) // 2
    if a[mid] == x:                     # temel durum: bulundu
        return mid
    if a[mid] < x:                      # sağ yarı: [mid + 1, hi)
        return ikili_ara_oz(a, mid + 1, hi, x, derinlik + 1)
    return ikili_ara_oz(a, lo, mid, x, derinlik + 1)    # [lo, mid)


# Aynı özyineleme; her çağrıyı derinliğe göre girintili yazar
def ikili_ara_oz_izle(a, lo, hi, x, derinlik):
    print("  " * (derinlik - 1) + f"ara([{lo}, {hi}))", end="")
    if lo >= hi:
        print(" boş aralık: -1")
        return -1
    mid = (lo + hi) // 2
    print(f" mid = {mid}, a[mid] = {a[mid]}", end="")
    if a[mid] == x:
        print(": bulundu")
        return mid
    if a[mid] < x:
        print(f" < {x}")
        return ikili_ara_oz_izle(a, mid + 1, hi, x, derinlik + 1)
    print(f" > {x}")
    return ikili_ara_oz_izle(a, lo, mid, x, derinlik + 1)


# 2^k <= n olan en büyük k (n >= 1)
def taban_log2(n):
    k = 0
    while n > 1:
        n //= 2
        k += 1
    return k


def main():
    global cagri, en_derin
    a = [3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61, 67, 73, 80, 88, 95]
    sorgular = [61, 45]
    boyutlar = [1, 2, 3, 4, 7, 8, 16, 100, 1000, 4096]
    n = len(a)

    for x in sorgular:
        print(f"x = {x}")
        k = ikili_ara_oz_izle(a, 0, n, x, 1)
        cagri = 0
        en_derin = 0
        ikili_ara_oz(a, 0, n, x, 1)
        print(f"  sonuç {k}: {cagri} çağrı, en büyük derinlik {en_derin}")

    print("\nAçılım (en kötü yol: her adımda sol yarı, boyut ⌊n/2⌋):")
    s = n
    c = 0
    print(f"T({s})", end="")
    while s > 0:
        s //= 2
        c += 1
        if c == 1:
            print(f" = T({s}) + c", end="")
        else:
            print(f" = T({s}) + {c}c", end="")
    print(f"\n=> {c + 1} çağrı = ⌊log2 {n}⌋ + 2 (son çağrı boş aralık)")

    print("\n     n  en çok çağrı  en büyük derinlik  ⌊log2 n⌋+2  doğru")
    for m in boyutlar:
        b = [2 * i + 1 for i in range(m)]
        en_cok = 0
        dogru = True
        en_derin = 0
        for x in range(2 * m + 1):
            beklenen = (x - 1) // 2 if x % 2 == 1 else -1
            cagri = 0
            if ikili_ara_oz(b, 0, m, x, 1) != beklenen:
                dogru = False
            en_cok = max(en_cok, cagri)
        print(f"{m:6d} {en_cok:13d} {en_derin:18d} {taban_log2(m) + 2:11d}"
              "  " + ("evet" if dogru else "HAYIR"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — bsearch; C++ — std::binary_search;
# Python — bisect.bisect_left (özyinelemeli sürüm yok).

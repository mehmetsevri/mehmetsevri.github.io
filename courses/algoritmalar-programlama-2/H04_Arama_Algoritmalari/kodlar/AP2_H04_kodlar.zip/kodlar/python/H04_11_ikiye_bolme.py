"""H04_11_ikiye_bolme.py — AP-2 Hafta 4 · Örnek 11 (★★)
Amaç    : Gerçel sayılarda ikili arama: ikiye bölme (bisection) ile
          x^3 - x - 2 = 0 kökü; tolerans, yineleme sayısı, kayan nokta
          sınırı (aralık artık bölünemiyor)
Çalıştır: python3 H04_11_ikiye_bolme.py
Eşleri  : c/H04_11_ikiye_bolme.c · cpp/H04_11_ikiye_bolme.cpp
Çıktı   : üç dilde aynı (=) — aynı IEEE 754 double işlemleri, aynı sıra
"""

EN_COK_YINELEME = 200

yineleme = 0        # f(m) değerlendirme sayısı
durma = ""          # durma nedeni
denklem = 1         # 1: x^3 - x - 2; 2: x^2 - 2 (kök √2)


def f(x):
    if denklem == 2:
        return x * x - 2.0
    return x * x * x - x - 2.0


# Ön koşul: f sürekli, f(a) ve f(b) ters işaretli => [a, b]'de kök var.
# Değişmez: f(a) ile f(b) ters işaretli (kök [a, b] içinde).
# Durma: b - a <= tol, f(m) == 0 ya da aralık bölünemez olunca.
def ikiye_bolme(a, b, tol, yaz):
    global yineleme, durma
    fa = f(a)
    yineleme = 0
    durma = "tolerans"
    while b - a > tol and yineleme < EN_COK_YINELEME:
        m = a + (b - a) / 2             # Python float = IEEE 754 double
        if m <= a or m >= b:            # a ile b komşu double: dur
            durma = "kayan nokta sınırı"
            break
        fm = f(m)
        yineleme += 1
        if yaz:
            print(f"  {yineleme:2d}  {a:.9f}  {b:.9f}  {m:.9f}  {fm:10.3e}")
        if fm == 0.0:                   # double'da tam sıfır
            durma = "f(m) == 0"
            return m
        if (fa < 0.0) == (fm < 0.0):    # kök sağ yarıda
            a = m
            fa = fm
        else:                           # kök sol yarıda
            b = m
    return a + (b - a) / 2


# (b - a) / 2^k <= tol olan en küçük k: kuramsal yineleme sayısı
def kuramsal_yineleme(genislik, tol):
    k = 0
    while genislik > tol:
        genislik /= 2
        k += 1
    return k


def main():
    global denklem
    toleranslar = [1e-2, 1e-4, 1e-6, 1e-8, 1e-10, 1e-12, 1e-15, 1e-16,
                   1e-20]
    print(f"f(x) = x^3 - x - 2,  f(1) = {f(1.0):.1f},  f(2) = {f(2.0):.1f}")
    print("tol = 1e-6 ile adımlar\n   k  a            b            m"
          "            f(m)")
    kok = ikiye_bolme(1.0, 2.0, 1e-6, True)
    print(f"kök ≈ {kok:.9f}  ({yineleme} yineleme)\n")

    print("       tol  yineleme  ⌈log2(1/tol)⌉  kök              durma")
    for tol in toleranslar:
        kok = ikiye_bolme(1.0, 2.0, tol, False)
        print(f"  {tol:8.0e}  {yineleme:8d}  "
              f"{kuramsal_yineleme(1.0, tol):13d}  {kok:.15f}  {durma}")
    kok = ikiye_bolme(1.0, 2.0, 1e-15, False)
    print(f"\nx^3 - x - 2, tol = 1e-15: f(kök) = {f(kok):.3e}")
    kok = ikiye_bolme(1.0, 2.0, 0.0, False)
    print(f"x^3 - x - 2, tol = 0    : {yineleme} yineleme, durma: {durma}")
    denklem = 2
    kok = ikiye_bolme(1.0, 2.0, 0.0, False)
    print(f"x^2 - 2,     tol = 0    : {yineleme} yineleme, durma: {durma}")
    print(f"                          kök = {kok:.15f}, f(kök) = "
          f"{f(kok):.3e}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (C++20 std::midpoint yalnız
# orta noktayı taşmasız verir); Python — yok (SciPy'deki
# scipy.optimize.bisect üçüncü taraf kitaplık, derste kullanılmaz).

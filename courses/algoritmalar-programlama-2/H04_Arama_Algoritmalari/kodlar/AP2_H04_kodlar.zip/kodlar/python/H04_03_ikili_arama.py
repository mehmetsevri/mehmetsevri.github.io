"""H04_03_ikili_arama.py — AP-2 Hafta 4 · Örnek 3 (★)
Amaç    : İkili arama, yinelemeli, kapalı aralık [lo, hi]: her adımda
          aday aralık yarıya iner; yoklama sayısı <= ⌊log2 n⌋ + 1
Çalıştır: python3 H04_03_ikili_arama.py
Eşleri  : c/H04_03_ikili_arama.c · cpp/H04_03_ikili_arama.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_tohum

yoklama = 0         # incelenen a[mid] sayısı


# Ön koşul: a[0..n-1] artan sıralı. x'in konumu ya da -1.
# Değişmez: x dizideyse a[lo..hi] içindedir.
def ikili_ara(a, x):
    global yoklama
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2    # taşma yok
        yoklama += 1
        if a[mid] == x:
            return mid
        elif a[mid] < x:
            lo = mid + 1    # a[lo..mid] elendi
        else:
            hi = mid - 1    # a[mid..hi] elendi
    return -1                           # aralık boş: lo == hi + 1


# Aynı algoritma; her adımı yazar (elle izleme tablosu)
def ikili_ara_izle(a, x):
    lo, hi = 0, len(a) - 1
    adim = 0
    print(f"x = {x}\n  adım  lo  hi  mid  a[mid]  karar")
    while lo <= hi:
        mid = (lo + hi) // 2
        adim += 1
        print(f"  {adim:4d} {lo:3d} {hi:3d} {mid:4d} {a[mid]:7d}  ", end="")
        if a[mid] == x:
            print("a[mid] == x: bulundu")
            return mid
        elif a[mid] < x:
            print(f"a[mid] < x: lo = {mid + 1}")
            lo = mid + 1
        else:
            print(f"a[mid] > x: hi = {mid - 1}")
            hi = mid - 1
    print(f"  lo = {lo} > hi = {hi}: aralık boş, bulunamadı")
    return -1


# 2^k <= n olan en büyük k (n >= 1): ⌊log2 n⌋
def taban_log2(n):
    k = 0
    while n > 1:
        n //= 2
        k += 1
    return k


def main():
    global yoklama
    a = [3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61, 67, 73, 80, 88, 95]
    sorgular = [61, 45, 3, 95]
    boyutlar = [1, 2, 3, 4, 5, 7, 8, 15, 16, 17, 100, 1000, 1023, 1024,
                4096]

    print("a = [" + ", ".join(str(v) for v in a) + f"]   (n = {len(a)})")
    for x in sorgular[:2]:
        ikili_ara_izle(a, x)
    for x in sorgular:
        yoklama = 0
        k = ikili_ara(a, x)
        print(f"ikili_ara({x}) = {k}   yoklama = {yoklama}")
    yoklama = 0
    bos = ikili_ara([], 7)
    print(f"boş dizi: ikili_ara(7) = {bos}   yoklama = {yoklama}")

    print("\nTüm sorgular, b[i] = 2i + 1:\n"
          "  B (başarılı) : x = b[i], n sorgu\n"
          "  S (başarısız): x = 0, 2, …, 2n, n + 1 sorgu")
    print("     n  en çok B  en çok S  ortalama B  ⌊log2 n⌋+1  doğru")
    for m in boyutlar:
        b = [2 * i + 1 for i in range(m)]
        en_cok_b = en_cok_s = toplam_b = 0
        dogru = True
        for x in range(2 * m + 1):
            beklenen = (x - 1) // 2 if x % 2 == 1 else -1
            yoklama = 0
            if ikili_ara(b, x) != beklenen:
                dogru = False
            if beklenen >= 0:
                toplam_b += yoklama
                en_cok_b = max(en_cok_b, yoklama)
            else:
                en_cok_s = max(en_cok_s, yoklama)
        print(f"{m:6d} {en_cok_b:9d} {en_cok_s:9d} {toplam_b / m:11.3f} "
              f"{taban_log2(m) + 1:11d}  " + ("evet" if dogru else "HAYIR"))

    milyon = 1000000
    b = [2 * i + 1 for i in range(milyon)]
    rastgele_tohum(42)
    en_cok = 0
    for q in range(1000):               # yarısı başarılı, yarısı değil
        r = rastgele_aralik(0, milyon - 1)
        x = 2 * r + 1 if q % 2 == 0 else 2 * r
        yoklama = 0
        ikili_ara(b, x)
        en_cok = max(en_cok, yoklama)
    print(f"\nn = {milyon}, 1000 sorgu (LCG, tohum 42): en çok {en_cok} "
          f"yoklama; ⌊log2 n⌋ + 1 = {taban_log2(milyon) + 1}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — bsearch (stdlib.h; void * ve karşılaştırıcı,
# Örnek 12); C++ — std::binary_search (yalnız var/yok),
# std::lower_bound; Python — bisect.bisect_left.

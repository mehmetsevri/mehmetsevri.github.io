"""H04_10_karekok_tahmin.py — AP-2 Hafta 4 · Örnek 10 (★★)
Amaç    : Cevap üzerinde ikili arama: monoton yüklem (Y…Y D…D) ve ilk D;
          tamsayı karekök; sayı tahmin oyunu (en çok ⌊log2 N⌋ + 1 soru)
Çalıştır: python3 H04_10_karekok_tahmin.py
Eşleri  : c/H04_10_karekok_tahmin.c · cpp/H04_10_karekok_tahmin.cpp
Çıktı   : üç dilde aynı (=)
"""

import math

from ortak_rastgele import rastgele_aralik, rastgele_tohum

adim = 0            # yüklem değerlendirme / soru sayısı


# Monoton yüklem P(r) = "r * r > n" (r >= 1): r büyüdükçe Y…Y D…D.
# Python'da r * r taşmaz; C ile aynı adımlar için r > n // r sınanır.
def cok_buyuk_mu(r, n):
    return r > n // r


# ⌊√n⌋ = (P'nin doğru olduğu ilk r) - 1. Aranan bir dizi elemanı değil,
# [lo, hi] aralığındaki ilk D'dir. Değişmez: P(lo - 1) = Y, P(hi) = D.
def tamsayi_karekok(n):
    global adim
    if n < 2:
        return n
    lo = 1                                      # P(0) tanım gereği Y
    hi = min(n, 4294967296)                     # P(hi) = D
    while lo < hi:
        mid = (lo + hi) // 2
        adim += 1
        if cok_buyuk_mu(mid, n):
            hi = mid        # ilk D: mid ya da solu
        else:
            lo = mid + 1    # ilk D: mid'in sağı
    return lo - 1


# Tutulan sayıyı [1, N] içinde ikili aramayla bulur; soru sayısı.
# yaz = True ise her soruyu ve yanıtı yazar.
def tahmin_oyunu(N, tutulan, yaz):
    lo, hi = 1, N
    soru = 0
    while lo <= hi:
        tahmin = (lo + hi) // 2
        soru += 1
        if yaz:
            print(f"    soru {soru}: {tahmin} mi?", end="")
        if tahmin == tutulan:
            if yaz:
                print(" -> doğru")
            return soru
        elif tahmin < tutulan:
            if yaz:
                print(" -> daha büyük")
            lo = tahmin + 1
        else:
            if yaz:
                print(" -> daha küçük")
            hi = tahmin - 1
    return -1                                   # olmaz: 1 <= tutulan <= N


# 1..N oyunlarının soru sayısı dağılımı, oyunları tek tek oynamadan:
# aynı boyuttaki aralık aynı soru ağacını verir ve her düzeyde en çok iki
# farklı boyut vardır. dagilim[k] = k soruda biten oyun sayısı.
def dagilim_hesapla(N):
    dagilim = [0]                               # dagilim[0] kullanılmaz
    duzey = {N: 1}                              # boyut -> aralık adedi
    while duzey:
        yeni = {}
        biten = 0
        for boyut, adet in duzey.items():
            biten += adet               # her aralıkta bir oyun biter
            sol = (boyut - 1) // 2
            sag = boyut - 1 - sol
            if sol > 0:
                yeni[sol] = yeni.get(sol, 0) + adet
            if sag > 0:
                yeni[sag] = yeni.get(sag, 0) + adet
        dagilim.append(biten)
        duzey = yeni
    return dagilim                      # en çok soru: len(dagilim) - 1


def taban_log2(n):
    k = 0
    while n > 1:
        n //= 2
        k += 1
    return k


def main():
    global adim
    sayilar = [0, 1, 2, 3, 4, 15, 16, 17, 40, 99, 100, 1000000, 2147483647,
               10**12, 10**18, 2**64 - 1]

    print("1) Monoton yüklem: P(r) = r * r > 40\n   r:"
          + "".join(f" {r:2d}" for r in range(1, 11)))
    print("   P:" + "".join("  " + ("D" if cok_buyuk_mu(r, 40) else "Y")
                            for r in range(1, 11)))
    print(f"   ilk D: r = {tamsayi_karekok(40) + 1}  =>  "
          f"⌊√40⌋ = {tamsayi_karekok(40)}")

    print("\n2) Tamsayı karekök (cevap üzerinde ikili arama)")
    print("                     n          ⌊√n⌋  adım  doğrulama")
    for n in sayilar:
        adim = 0
        r = tamsayi_karekok(n)
        dogru = r == math.isqrt(n)              # kâhin
        print(f"  {n:20d}  {r:12d}  {adim:4d}  "
              + ("evet" if dogru else "HAYIR"))

    print("\n3) Sayı tahmin oyunu: 1..100, tutulan sayılar LCG (tohum 42)")
    rastgele_tohum(42)
    for oyun in range(1, 4):
        tutulan = rastgele_aralik(1, 100)
        print(f"  oyun {oyun}: tutulan {tutulan}")
        s = tahmin_oyunu(100, tutulan, True)
        print(f"    {s} soruda bulundu")

    print("\n4) Tüm tutulan sayılar için soru sayısı dağılımı")
    for N in [100, 1000, 1000000]:
        dagilim = dagilim_hesapla(N)
        en_cok = len(dagilim) - 1
        toplam = sum(k * dagilim[k] for k in range(1, en_cok + 1))
        print(f"  N = {N}: en çok {en_cok} soru (⌊log2 N⌋ + 1 = "
              f"{taban_log2(N) + 1}), ortalama {toplam / N:.3f}")
        if N <= 1000:                   # oyunları tek tek oyna, denetle
            oynanan = [0] * (en_cok + 1)
            for s in range(1, N + 1):
                oynanan[tahmin_oyunu(N, s, False)] += 1
            print("    soru:" + "".join(f" {k:4d}"
                                        for k in range(1, en_cok + 1)))
            print("    oyun:" + "".join(f" {dagilim[k]:4d}"
                                        for k in range(1, en_cok + 1)))
            print(f"    {N} oyun tek tek oynandı: dağılım aynı mı? "
                  + ("evet" if oynanan == dagilim else "HAYIR"))
        else:
            tam = all(dagilim[k] == 2 ** (k - 1) for k in range(1, en_cok))
            print(f"    1..{en_cok - 1} soru: 2^(k-1) oyun (dolu düzeyler)? "
                  + ("evet" if tam else "HAYIR")
                  + f"; {en_cok} soru: {dagilim[en_cok]} oyun")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (sqrt kayan noktalıdır; büyük n'de
# yuvarlama hatası verebilir); C++ — yok (std::sqrt aynı uyarıyla);
# Python — math.isqrt(n) (kesin tamsayı karekök).

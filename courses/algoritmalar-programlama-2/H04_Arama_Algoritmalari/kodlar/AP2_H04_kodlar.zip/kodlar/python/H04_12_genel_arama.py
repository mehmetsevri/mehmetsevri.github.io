"""H04_12_genel_arama.py — AP-2 Hafta 4 · Örnek 12 (★★★)
Amaç    : Genel (generic) ikili arama: anahtar çıkaran key fonksiyonu
          (birinci sınıf fonksiyon) ile kayıt listesinde arama; ada göre
          arama, önek araması (lower_bound); kâhin: bisect_left(key=...)
Çalıştır: python3 H04_12_genel_arama.py
Eşleri  : c/H04_12_genel_arama.c · cpp/H04_12_genel_arama.cpp
Çıktı   : üç dilde aynı (=)
"""

from bisect import bisect_left

yoklama = 0         # karşılaştırma adımı (yoklama)


# Kayıt: (numara, ad, ortalama) demeti. key fonksiyonu kayıttan
# karşılaştırılacak anahtarı çıkarır; karşılaştırma < ve == ile yapılır.
def numara_al(o):
    return o[0]


def ad_al(o):
    return o[1]


# Genel ikili arama: key herhangi bir fonksiyon olabilir (değer olarak
# aktarılır). Ön koşul: a, key'e göre sıralı.
def genel_ara(anahtar, a, key):
    global yoklama
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        k = key(a[mid])
        yoklama += 1
        if anahtar == k:
            return mid
        elif anahtar > k:
            lo = mid + 1    # anahtar > öge
        else:
            hi = mid        # anahtar < öge
    return -1


# Genel lower_bound: key(öge) >= anahtar olan ilk konum (ya da n)
def genel_alt_sinir(anahtar, a, key):
    global yoklama
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        yoklama += 1
        if key(a[mid]) < anahtar:
            lo = mid + 1
        else:
            hi = mid
    return lo


# Ön koşul denetimi: liste key'e göre artan (eşitler serbest) mı?
def sirali_mi(a, key):
    for i in range(1, len(a)):
        if key(a[i]) < key(a[i - 1]):
            return False
    return True


def kayit_metni(o):
    return f"{o[0]} {o[1]:<6s} {o[2]:.2f}"


# Kâhin: bisect_left(..., key=...) (Python 3.10+; yalnızca test için)
def kahin(anahtar, a, key):
    i = bisect_left(a, anahtar, key=key)
    return i if i < len(a) and key(a[i]) == anahtar else -1


def main():
    global yoklama
    kayitlar = [                                    # numaraya göre
        (1001, "Kerem", 2.85), (1004, "Ayla", 3.40), (1009, "Zeynep", 3.75),
        (1013, "Can", 2.10), (1020, "Selin", 3.05), (1027, "Ali", 3.90),
        (1031, "Ece", 2.60), (1046, "Tolga", 3.20), (1052, "Deniz", 2.95),
        (1068, "Emre", 3.55)]
    ada_gore = [                                    # ada göre
        (1027, "Ali", 3.90), (1004, "Ayla", 3.40), (1013, "Can", 2.10),
        (1052, "Deniz", 2.95), (1031, "Ece", 2.60), (1068, "Emre", 3.55),
        (1001, "Kerem", 2.85), (1020, "Selin", 3.05), (1046, "Tolga", 3.20),
        (1009, "Zeynep", 3.75)]
    numaralar = [1027, 1030, 1001, 1068]
    adlar = ["Selin", "Ayse", "Zeynep"]

    print("Kayıtlar (numaraya göre):")
    for i, o in enumerate(kayitlar):
        print(f"  [{i}] " + kayit_metni(o))
    print("numaraya göre sıralı mı? "
          + ("evet" if sirali_mi(kayitlar, numara_al) else "HAYIR")
          + "; ada göre kopya sıralı mı? "
          + ("evet" if sirali_mi(ada_gore, ad_al) else "HAYIR"))

    print("\nNumaraya göre arama")
    kahin_ayni = True
    for no in numaralar:
        yoklama = 0
        k = genel_ara(no, kayitlar, numara_al)
        print(f"  numara {no}: ", end="")
        if k >= 0:
            print(f"konum {k} -> " + kayit_metni(kayitlar[k]), end="")
        else:
            print("bulunamadı", end="")
        print(f" ({yoklama} yoklama)")
        kahin_ayni = kahin_ayni and kahin(no, kayitlar, numara_al) == k

    print("\nAda göre arama (aynı genel_ara, başka karşılaştırıcı)")
    for ad in adlar:
        yoklama = 0
        # key adsız fonksiyon (lambda) olarak da verilebilir:
        k = genel_ara(ad, ada_gore, lambda o: o[1])
        print(f"  ad {ad:<6s}: ", end="")
        if k >= 0:
            print(f"konum {k} -> " + kayit_metni(ada_gore[k]), end="")
        else:
            print("bulunamadı", end="")
        print(f" ({yoklama} yoklama)")
        kahin_ayni = kahin_ayni and kahin(ad, ada_gore, ad_al) == k

    print('\nÖnek araması: "E" ile başlayan adlar (lower_bound + tarama)')
    onek = "E"
    yoklama = 0
    i = genel_alt_sinir(onek, ada_gore, ad_al)
    print(f"  lower_bound konum {i} ({yoklama} yoklama); eşleşenler:", end="")
    while i < len(ada_gore) and ada_gore[i][1].startswith(onek):
        print(" " + ada_gore[i][1], end="")
        i += 1
    print("\nkâhin (bsearch / std::lower_bound / bisect) ile aynı mı? "
          + ("evet" if kahin_ayni else "HAYIR"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — bsearch(anahtar, taban, n, boyut, kars)
# (bulunan ögenin işaretçisi ya da NULL; eşitlerden hangisi döneceği
# belirsiz); C++ — std::lower_bound, std::binary_search (lambda ile
# "küçüktür"); Python — bisect.bisect_left(a, x, key=...) (3.10+).

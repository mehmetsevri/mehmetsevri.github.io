"""H04_04_yari_acik_aralik.py — AP-2 Hafta 4 · Örnek 4 (★★)
Amaç    : İkili arama, yarı açık aralık [lo, hi): değişmezi assert ile
          denetleyerek tasarım; sonlanma denetimi; ekleme konumu
Çalıştır: python3 H04_04_yari_acik_aralik.py   [bozuk: sırasız dizi]
Eşleri  : c/H04_04_yari_acik_aralik.c · cpp/H04_04_yari_acik_aralik.cpp
Çıktı   : üç dilde aynı (=)
"""

import sys

yoklama = 0         # incelenen a[mid] sayısı
denetim = 0         # değişmez denetimi sayısı


# Değişmez (yalnız hata ayıklama; O(n) maliyetli):
# 0 <= lo <= hi <= n, a[0..lo-1] < x ve a[hi..n-1] > x
def degismez_mi(a, lo, hi, x):
    global denetim
    denetim += 1
    if lo > hi or hi > len(a):
        return False
    for i in range(lo):
        if a[i] >= x:
            return False
    for i in range(hi, len(a)):
        if a[i] <= x:
            return False
    return True


# Ön koşul: a[0..n-1] artan sıralı. x'in konumu ya da -1.
# Sözleşme: aday bölge a[lo..hi-1]; hi aralığa DAHİL DEĞİL.
def ikili_ara_yari(a, x):
    global yoklama
    lo, hi = 0, len(a)                  # başlangıç: tüm dizi [0, n)
    while lo < hi:                      # aralık boş değil
        assert degismez_mi(a, lo, hi, x), "değişmez bozuldu"
        mid = (lo + hi) // 2            # lo <= mid < hi
        eski = hi - lo
        yoklama += 1
        if a[mid] == x:
            return mid
        elif a[mid] < x:
            lo = mid + 1                # a[lo..mid] < x
        else:
            hi = mid                    # a[mid..hi-1] > x
        assert hi - lo < eski, "aralık daralmadı"   # sonlanma
    assert degismez_mi(a, lo, hi, x), "değişmez bozuldu"
    return -1                           # lo == hi: x buraya eklenir


# Aynı algoritma; her adımda üç bölgeyi ve değişmezi yazar
def ikili_ara_yari_izle(a, x):
    lo, hi, n = 0, len(a), len(a)
    print(f"x = {x}\n  lo  hi  mid  a[mid]   <x | aday | >x  değişmez"
          "  karar")
    while lo < hi:
        mid = (lo + hi) // 2
        d = degismez_mi(a, lo, hi, x)
        print(f"  {lo:2d}  {hi:2d}  {mid:3d}  {a[mid]:6d}  {lo:4d} | "
              f"{hi - lo:4d} | {n - hi:2d}  "
              + f"{'evet' if d else 'HAYIR':<8s}  ", end="")
        if a[mid] == x:
            print("bulundu")
            return mid
        elif a[mid] < x:
            print(f"lo = mid + 1 = {mid + 1}")
            lo = mid + 1
        else:
            print(f"hi = mid = {mid}")
            hi = mid
    print(f"  lo == hi == {lo}: aralık boş; x yok, ekleme konumu {lo}")
    return -1


def main():
    global yoklama, denetim
    a = [3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61, 67, 73, 80, 88, 95]

    if len(sys.argv) > 1 and sys.argv[1] == "bozuk":
        s = [5, 1, 4, 2, 3]                 # SIRALI DEĞİL
        print("sırasız dizide arama: değişmez bozulur, assert durdurur",
              flush=True)
        ikili_ara_yari(s, 2)
        return
    ikili_ara_yari_izle(a, 61)
    ikili_ara_yari_izle(a, 45)

    print("\nYoklama: 61 -> ", end="")
    yoklama = 0
    k = ikili_ara_yari(a, 61)
    print(f"{k} ({yoklama} yoklama), 95 -> ", end="")
    yoklama = 0
    k = ikili_ara_yari(a, 95)
    print(f"{k} ({yoklama} yoklama), 2 -> ", end="")
    yoklama = 0
    k = ikili_ara_yari(a, 2)
    print(f"{k} ({yoklama} yoklama)")

    sorgu = hata = 0
    denetim = 0
    for m in range(65):
        b = [2 * i + 1 for i in range(m)]
        for x in range(-1, 2 * m + 2):
            beklenen = ((x - 1) // 2 if x > 0 and x % 2 == 1 and x < 2 * m
                        else -1)
            sorgu += 1
            if ikili_ara_yari(b, x) != beklenen:
                hata += 1
    print(f"n = 0..64, x = -1..2n+1: {sorgu} sorgu, hatalı sonuç {hata}\n"
          f"değişmez {denetim} kez denetlendi (assert hiç durdurmadı)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — bsearch; C++ — std::binary_search,
# std::lower_bound (yarı açık [first, last) sözleşmesi); Python —
# bisect.bisect_left (lo, hi parametreleri de yarı açık).

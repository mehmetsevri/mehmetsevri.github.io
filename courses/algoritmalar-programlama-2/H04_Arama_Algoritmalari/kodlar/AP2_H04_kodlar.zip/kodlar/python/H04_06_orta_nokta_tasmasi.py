"""H04_06_orta_nokta_tasmasi.py — AP-2 Hafta 4 · Örnek 6 (★★)
Amaç    : Orta nokta taşması: int32 sınırında (lo + hi) / 2 negatif
          olur; güvenli lo + (hi - lo) / 2. Python tamsayıları sınırsızdır:
          taşma yoktur; C'deki 32 bit sarma ayrıca taklit edilir
Çalıştır: python3 H04_06_orta_nokta_tasmasi.py
Eşleri  : c/H04_06_orta_nokta_tasmasi.c · cpp/H04_06_orta_nokta_tasmasi.cpp
Çıktı   : Δ — Python tamsayıları taşmaz; bkz. Dil Penceresi
"""

INT32_MAX = 2**31 - 1


# Sanal sıralı dizi: a[i] = i. 2^30'dan büyük dizi AYRILMAZ; yalnızca
# indis aritmetiği benzetilir.
def sanal_eleman(i):
    return i


# C'deki tamsayı bölmesi: sıfıra doğru keser (Python // aşağı yuvarlar)
def sifira_dogru_bol(a, b):
    q = abs(a) // abs(b)
    return q if (a >= 0) == (b > 0) else -q


# (lo + hi) / 2'nin 32 bitlik ikiye tümleyen makinedeki sonucunun
# TAKLİDİ: toplam 2^32 modunda alınır, işaretli aralığa kaydırılır.
def sarmali_orta(lo, hi):
    toplam = (lo + hi) & 0xFFFFFFFF  # uint32_t toplamı
    if toplam > INT32_MAX:
        toplam -= 2**32                 # int32_t'ye
    return sifira_dogru_bol(toplam, 2)


# Güvenli: 0 <= lo <= hi iken sonuç [lo, hi] içinde (her dilde)
def guvenli_orta(lo, hi):
    return lo + (hi - lo) // 2


# Bloch'un (2006) ikinci önerisi: işaretsiz toplam, 1 bit sağa kaydırma
def kaydirmali_orta(lo, hi):
    return ((lo + hi) & 0xFFFFFFFF) >> 1


# Python'un kendi tamsayısıyla: taşma yok, sonuç her zaman doğru
def python_orta(lo, hi):
    return (lo + hi) // 2


# Sanal dizide kapalı aralıklı ikili arama.
# yontem: "taklit" (32 bit sarma), "guvenli" ya da "python".
def ara_benzet(yontem, n, x):
    lo, hi = 0, n - 1
    adim = 0
    while lo <= hi:
        if yontem == "taklit":
            mid = sarmali_orta(lo, hi)
        elif yontem == "guvenli":
            mid = guvenli_orta(lo, hi)
        else:
            mid = python_orta(lo, hi)
        adim += 1
        if yontem == "taklit":
            print(f"  adım {adim}: lo = {lo}, hi = {hi}, mid = {mid}")
        if mid < lo or mid > hi:
            print("  mid aralık dışında (negatif indis): a[mid] okunsaydı"
                  "\n  dizi dışı erişim olurdu; durduruldu")
            return
        deger = sanal_eleman(mid)
        if deger == x:
            print(f"  {adim} adımda bulundu: konum {mid}")
            return
        if deger < x:
            lo = mid + 1
        else:
            hi = mid - 1
    print("  bulunamadı")


# x = n - 1 aranırken (en büyük lo + hi) ve 32 bitte taşma olur mu?
def sinir_denetle(n):
    lo, hi, en_buyuk, x = 0, n - 1, 0, n - 1
    while lo <= hi:
        toplam = lo + hi                # Python'da her zaman kesin
        en_buyuk = max(en_buyuk, toplam)
        mid = lo + (hi - lo) // 2
        if mid == x:
            break
        if mid < x:
            lo = mid + 1
        else:
            hi = mid - 1
    durum = ("> INT32_MAX: TAŞAR" if en_buyuk > INT32_MAX
             else "<= INT32_MAX: taşmaz")
    print(f"  n = {n:10d}: en büyük lo + hi = {en_buyuk:10d}  {durum}")


def main():
    lo, hi = 1500000000, 2000000000

    print(f"INT32_MAX = {INT32_MAX}")
    print(f"lo = {lo}, hi = {hi}")
    print(f"gerçek lo + hi               = {lo + hi}")
    print(f"(lo + hi) // 2 (Python)      = {python_orta(lo, hi)}"
          "   <- taşma yok")
    print(f"(lo + hi) / 2, 32 bit taklit = {sarmali_orta(lo, hi)}")
    print(f"lo + (hi - lo) // 2          = {guvenli_orta(lo, hi)}")
    print(f"(lo + hi) >> 1 (32 bit)      = {kaydirmali_orta(lo, hi)}")

    n = 2000000000                      # sanal dizi: a[i] = i
    print(f"\nSanal dizide (n = {n}) x = n - 1 aranıyor")
    print("Python (lo + hi) // 2:")
    ara_benzet("python", n, n - 1)
    print("32 bit sarma taklidi (C/C++'taki tipik sonuç):")
    ara_benzet("taklit", n, n - 1)
    print("güvenli orta nokta:")
    ara_benzet("guvenli", n, n - 1)

    print("\nHata hangi n'de başlar? (son eleman aranırken; C/C++ int32)")
    sinir_denetle(1 << 30)
    sinir_denetle((1 << 30) + 1)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — bsearch; C++ — std::binary_search,
# std::lower_bound; Python — bisect.bisect_left (tamsayılar taşmaz).

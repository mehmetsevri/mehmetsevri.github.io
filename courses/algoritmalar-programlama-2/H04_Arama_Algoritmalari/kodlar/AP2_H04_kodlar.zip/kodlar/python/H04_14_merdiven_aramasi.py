"""H04_14_merdiven_aramasi.py — AP-2 Hafta 4 · Örnek 14 (★★★)
Amaç    : Satırları ve sütunları sıralı matriste merdiven araması:
          sağ üst köşeden başla, her adımda bir satır ya da bir sütun
          ele; en çok m + n - 1 adım. Satır satır ikili aramayla kıyas
Çalıştır: python3 H04_14_merdiven_aramasi.py
Eşleri  : c/H04_14_merdiven_aramasi.c · cpp/H04_14_merdiven_aramasi.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_tohum

adim = 0            # incelenen hücre sayısı


# m x n matris (liste listesi): satırlar ve sütunlar kesin artan:
# a[r][c] = max(üst, sol) + 1..4.
def matris_uret(m, n):
    a = [[0] * n for _ in range(m)]
    for r in range(m):
        for c in range(n):
            ust = a[r - 1][c] if r > 0 else 0
            sol = a[r][c - 1] if c > 0 else 0
            a[r][c] = max(ust, sol) + rastgele_aralik(1, 4)
    return a


# Ön koşul: her satır soldan sağa, her sütun yukarıdan aşağıya artan.
# Değişmez: x matristeyse a[r..m-1][0..c] alt matrisindedir.
# Bulunursa (r, c), yoksa None döndürür.
def merdiven_ara(a, x):
    global adim
    m, n = len(a), len(a[0]) if a else 0
    r, c = 0, n - 1             # Python'da c = -1 sorun değil
    while r < m and c >= 0:
        v = a[r][c]
        adim += 1
        if v == x:
            return r, c
        elif v > x:
            c -= 1          # sütunu ele
        else:
            r += 1          # satırı ele
    return None


# Aynı arama; her adımı yazar
def merdiven_izle(a, x):
    m, n = len(a), len(a[0])
    r, c = 0, n - 1
    k = 0
    print(f"x = {x}\n  adım  (r, c)  a[r][c]  karar")
    while r < m and c >= 0:
        v = a[r][c]
        k += 1
        print(f"  {k:4d}  ({r}, {c})  {v:7d}  ", end="")
        if v == x:
            print("bulundu")
            return
        elif v > x:
            print(f"> x: sola (sütun {c} elendi)")
            c -= 1
        else:
            print(f"< x: aşağı (satır {r} elendi)")
            r += 1
    print(f"  matristen çıkıldı (r = {r}, c = {c}): x yok")


# Karşılaştırma için: her satırda ikili arama, en çok m(⌊log2 n⌋+1)
def satir_ikili_ara(a, x):
    global adim
    for satir in a:
        lo, hi = 0, len(satir)
        while lo < hi:
            mid = (lo + hi) // 2
            v = satir[mid]
            adim += 1
            if v == x:
                return True
            elif v < x:
                lo = mid + 1
            else:
                hi = mid
    return False


def main():
    global adim
    boyutlar = [(5, 6), (10, 10), (100, 100), (4, 1000), (1000, 4)]
    rastgele_tohum(42)
    a = matris_uret(5, 6)
    print(f"Matris ({len(a)} x {len(a[0])}), satırlar ve sütunlar artan:")
    for satir in a:
        print("  " + "".join(f"{v:4d}" for v in satir))
    merdiven_izle(a, 15)
    merdiven_izle(a, 19)

    print("\nTüm x (en küçük - 1 .. en büyük + 1), kâhin: değer tablosu")
    print("  boyut       sorgu  hatalı  merdiven en çok  m + n - 1"
          "  satır satır ikili en çok")
    for m, n in boyutlar:
        rastgele_tohum(42)
        a = matris_uret(m, n)
        en_buyuk = a[m - 1][n - 1]
        var = set(v for satir in a for v in satir)  # kâhin tablosu
        sorgu = hata = en_cok = en_cok_satir = 0
        for x in range(a[0][0] - 1, en_buyuk + 2):
            adim = 0
            kon = merdiven_ara(a, x)
            sorgu += 1
            if (kon is not None) != (x in var) or (
                    kon is not None and a[kon[0]][kon[1]] != x):
                hata += 1
            en_cok = max(en_cok, adim)
            adim = 0
            satir_ikili_ara(a, x)
            en_cok_satir = max(en_cok_satir, adim)
        print(f"  {m:4d} x {n:<4d} {sorgu:6d} {hata:7d} {en_cok:16d} "
              f"{m + n - 1:10d} {en_cok_satir:25d}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (satır başına
# std::lower_bound yazılabilir); Python — yok (satır başına bisect).

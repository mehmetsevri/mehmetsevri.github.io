"""H04_09_dondurulmus_dizi.py — AP-2 Hafta 4 · Örnek 9 (★★★)
Amaç    : Döndürülmüş sıralı dizide arama: her adımda yarılardan biri
          sıralıdır, değişmez buna göre uyarlanır; döndürme noktası;
          tekrar eden elemanlarda en kötü durumun O(n)'e çıkması
Çalıştır: python3 H04_09_dondurulmus_dizi.py
Eşleri  : c/H04_09_dondurulmus_dizi.c · cpp/H04_09_dondurulmus_dizi.cpp
Çıktı   : üç dilde aynı (=)
"""

yoklama = 0         # döngü adımı (a[mid] incelemesi)


# Ön koşul: a, FARKLI elemanlı artan sıralı bir dizinin döndürülmüşü.
# Değişmez: x dizideyse a[lo..hi] içindedir.
def dondurulmus_ara(a, x):
    global yoklama
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        yoklama += 1
        if a[mid] == x:
            return mid
        if a[lo] <= a[mid]:                 # sol yarı a[lo..mid] sıralı
            if a[lo] <= x < a[mid]:
                hi = mid - 1
            else:
                lo = mid + 1
        else:                               # sağ yarı a[mid..hi] sıralı
            if a[mid] < x <= a[hi]:
                lo = mid + 1
            else:
                hi = mid - 1
    return -1


# Döndürme noktası = en küçük elemanın konumu (n >= 1, farklı elemanlar).
# Değişmez: en küçük eleman a[lo..hi] içindedir.
def en_kucuk_konum(a):
    global yoklama
    lo, hi = 0, len(a) - 1
    while lo < hi:
        mid = (lo + hi) // 2
        yoklama += 1
        if a[mid] > a[hi]:
            lo = mid + 1                    # en küçük mid'in sağında
        else:
            hi = mid                        # mid ya da solunda
    return lo


# Tekrarlı sürüm: a[lo] == a[mid] == a[hi] iken hangi yarının sıralı
# olduğu anlaşılamaz; iki uç birer daraltılır. En kötü durum O(n).
def dondurulmus_ara_tekrarli(a, x):
    global yoklama
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        yoklama += 1
        if a[mid] == x:
            return mid
        if a[lo] == a[mid] == a[hi]:
            lo += 1
            hi -= 1
        elif a[lo] <= a[mid]:
            if a[lo] <= x < a[mid]:
                hi = mid - 1
            else:
                lo = mid + 1
        else:
            if a[mid] < x <= a[hi]:
                lo = mid + 1
            else:
                hi = mid - 1
    return -1


# Aynı arama (farklı elemanlar); her adımı yazar
def dondurulmus_izle(a, x):
    lo, hi = 0, len(a) - 1
    print(f"x = {x}\n  lo  hi  mid  a[mid]  sıralı yarı      karar")
    while lo <= hi:
        mid = (lo + hi) // 2
        print(f"  {lo:2d}  {hi:2d}  {mid:3d}  {a[mid]:6d}  ", end="")
        if a[mid] == x:
            print("—                bulundu")
            return
        if a[lo] <= a[mid]:
            icinde = a[lo] <= x < a[mid]
            print(f"sol [{a[lo]:2d} .. {a[mid]:2d}]   "
                  + ("içinde: hi = mid - 1" if icinde
                     else "dışında: lo = mid + 1"))
            if icinde:
                hi = mid - 1
            else:
                lo = mid + 1
        else:
            icinde = a[mid] < x <= a[hi]
            print(f"sağ [{a[mid]:2d} .. {a[hi]:2d}]   "
                  + ("içinde: lo = mid + 1" if icinde
                     else "dışında: hi = mid - 1"))
            if icinde:
                lo = mid + 1
            else:
                hi = mid - 1
    print("  lo > hi: bulunamadı")


def taban_log2(n):
    k = 0
    while n > 1:
        n //= 2
        k += 1
    return k


def main():
    global yoklama
    a = [40, 50, 60, 70, 80, 10, 20, 30]

    print("a = [" + ", ".join(str(v) for v in a)
          + "]   (10, 20, …, 80 dizisi 3 adım sola döndürüldü)")
    dondurulmus_izle(a, 20)
    dondurulmus_izle(a, 65)
    yoklama = 0
    k = en_kucuk_konum(a)
    print(f"döndürme noktası: konum {k} (a[{k}] = {a[k]}), {yoklama} "
          "yoklama")

    print("\nTüm döndürmeler, tüm x: taban 1, 3, …, 2m - 1")
    print("     m  sorgu  hatalı  en çok yoklama  ⌊log2 m⌋+1"
          "  döndürme noktası doğru")
    for m in [1, 2, 3, 8, 12, 100]:
        sorgu = hata = en_cok = 0
        nokta_dogru = True
        for r in range(m):                  # r adım sola döndür
            b = [2 * ((i + r) % m) + 1 for i in range(m)]
            if en_kucuk_konum(b) != (m - r) % m:
                nokta_dogru = False
            for x in range(2 * m + 1):
                beklenen = -1               # kâhin: doğrusal tarama
                for i in range(m):
                    if b[i] == x:
                        beklenen = i
                yoklama = 0
                sorgu += 1
                if dondurulmus_ara(b, x) != beklenen:
                    hata += 1
                en_cok = max(en_cok, yoklama)
        print(f"{m:6d} {sorgu:6d} {hata:7d} {en_cok:15d} "
              f"{taban_log2(m) + 1:11d}  "
              + ("evet" if nokta_dogru else "HAYIR"))

    print("\nTekrar eden elemanlar: 999 tane 2 ve tek bir 1")
    print("  1'in konumu  dondurulmus_ara_tekrarli  yoklama")
    for p in [0, 1, 500, 998, 999]:
        b = [2] * 1000
        b[p] = 1
        yoklama = 0
        s = dondurulmus_ara_tekrarli(b, 1)
        print(f"  {p:11d}  {s:24d}  {yoklama:7d}")
    b = [2] * 1000
    yoklama = 0
    s = dondurulmus_ara_tekrarli(b, 3)
    print(f"  hepsi 2, x = 3: sonuç {s}, {yoklama} yoklama (n = 1000)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (std::rotate döndürür,
# aramaz); Python — yok. Döndürme noktası bulunup iki parçada bsearch /
# std::lower_bound / bisect de kullanılabilir.

"""H04_01_dogrusal_arama.py — AP-2 Hafta 4 · Örnek 1 (★)
Amaç    : Doğrusal arama: ilk konum, "bulunamadı" sözleşmesi (None);
          sıralı dizide erken çıkış ve karşılaştırma sayacı
Çalıştır: python3 H04_01_dogrusal_arama.py
Eşleri  : c/H04_01_dogrusal_arama.c · cpp/H04_01_dogrusal_arama.cpp
Çıktı   : üç dilde aynı (=)
"""

N_BUYUK = 1000

karsilastirma = 0  # incelenen eleman sayısı


# x'in a[0..n-1] içindeki İLK konumu; x yoksa None ("bulunamadı").
# Değişmez: döngü başında x, a[0..i-1] içinde yok.
def dogrusal_ara(a, x):
    global karsilastirma
    for i in range(len(a)):
        karsilastirma += 1
        if a[i] == x:
            return i
    return None


# Ön koşul: a artan sıralı. a[i] >= x görülünce durulur: x varsa
# buradadır, yoksa ileride de olamaz (erken çıkış).
# Değişmez: döngü başında a[0..i-1] < x.
def sirali_dogrusal_ara(a, x):
    global karsilastirma
    for i in range(len(a)):
        karsilastirma += 1             # bir eleman: bir sayım
        if a[i] >= x:
            return i if a[i] == x else None
    return None


def dizi_yaz(ad, a):
    print(f"{ad} = [" + ", ".join(str(v) for v in a)
          + f"]   (n = {len(a)})")


def sonuc_yaz(x, k):
    if k is None:
        print(f"  x = {x:2d}: bulunamadı", end="")
    else:
        print(f"  x = {x:2d}: konum {k}", end="")
    print(f", karşılaştırma {karsilastirma}")


def kisa_yaz(ad, k):
    print(f"  {ad} ", end="")
    if k is None:
        print("yok", end="")
    else:
        print(k, end="")
    print(f" ({karsilastirma})", end="")


def main():
    global karsilastirma
    a = [7, 3, 9, 3, 5, 1, 8]
    sorgu_a = [7, 3, 8, 6]
    b = [1, 3, 3, 5, 7, 8, 9]
    sorgu_b = [4, 9, 10, 0]

    print("1) Sırasız dizide doğrusal arama (ilk konum)")
    dizi_yaz("a", a)
    for x in sorgu_a:
        karsilastirma = 0
        k = dogrusal_ara(a, x)
        sonuc_yaz(x, k)
    karsilastirma = 0
    print("  boş dizi:", end="")
    sonuc_yaz(7, dogrusal_ara([], 7))

    print("\n2) Sıralı dizide erken çıkış")
    dizi_yaz("b", b)
    print("  konum (karşılaştırma)")
    for x in sorgu_b:
        print(f"  x = {x:2d}:", end="")
        karsilastirma = 0
        kisa_yaz("dogrusal_ara", dogrusal_ara(b, x))
        karsilastirma = 0
        kisa_yaz("sirali_dogrusal_ara", sirali_dogrusal_ara(b, x))
        print()

    print(f"\n3) Ortalama karşılaştırma: c[i] = 2i + 1, n = {N_BUYUK}")
    c = [2 * i + 1 for i in range(N_BUYUK)]
    # top: dogrusal başarılı, başarısız; sirali başarılı, başarısız
    top = [0, 0, 0, 0]
    for i in range(N_BUYUK + 1):
        if i < N_BUYUK:            # başarılı: tek sayılar c[i]
            karsilastirma = 0
            dogrusal_ara(c, c[i])
            top[0] += karsilastirma
            karsilastirma = 0
            sirali_dogrusal_ara(c, c[i])
            top[2] += karsilastirma
        karsilastirma = 0          # başarısız: çift sayılar 0..2n
        dogrusal_ara(c, 2 * i)
        top[1] += karsilastirma
        karsilastirma = 0
        sirali_dogrusal_ara(c, 2 * i)
        top[3] += karsilastirma
    print("  yöntem                 başarılı (n)  başarısız (n + 1)")
    print(f"  dogrusal_ara        {top[0] / N_BUYUK:12.2f} "
          f"{top[1] / (N_BUYUK + 1):17.2f}")
    print(f"  sirali_dogrusal_ara {top[2] / N_BUYUK:12.2f} "
          f"{top[3] / (N_BUYUK + 1):17.2f}")
    print(f"  kuram: başarılı (n + 1) / 2 = {(N_BUYUK + 1) / 2.0:.2f}; "
          f"başarısız n = {N_BUYUK} (erken çıkışla ≈ n / 2)")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — standart C'de yok (POSIX lfind);
# C++ — std::find (bulamazsa end()); Python — a.index(x) (bulamazsa
# ValueError), x in a.

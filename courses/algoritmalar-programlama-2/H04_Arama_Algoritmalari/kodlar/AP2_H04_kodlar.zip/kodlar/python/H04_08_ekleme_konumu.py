"""H04_08_ekleme_konumu.py — AP-2 Hafta 4 · Örnek 8 (★★)
Amaç    : Ekleme konumu (ilk a[i] >= x) ve sıralı diziye ekleme:
          arama O(log n) yoklama, kaydırma O(n): maliyeti kaydırma belirler
Çalıştır: python3 H04_08_ekleme_konumu.py
Eşleri  : c/H04_08_ekleme_konumu.c · cpp/H04_08_ekleme_konumu.cpp
Çıktı   : üç dilde aynı (=)
"""

from ortak_rastgele import rastgele_aralik, rastgele_tohum

yoklama = 0         # incelenen a[mid] sayısı
kaydirma = 0        # bir sağa taşınan eleman sayısı


# x'in sırayı bozmadan girebileceği İLK konum: ilk a[i] >= x (ya da n).
# Değişmez: a[0..lo-1] < x <= a[hi..n-1]
def ekleme_konumu(a, x):
    global yoklama
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        yoklama += 1
        if a[mid] < x:
            lo = mid + 1
        else:
            hi = mid
    return lo


# Ön koşul: a sıralı. x'i yerine ekler ve konumunu döndürür.
# Sona bir yer açılır (append), a[k..n-1] bir sağa kayar:
# SONDAN başa doğru (üzerine yazmamak için).
def sirali_ekle(a, x):
    global kaydirma
    k = ekleme_konumu(a, x)
    n = len(a)
    a.append(x)                         # yeni boyut n + 1
    for i in range(n, k, -1):
        a[i] = a[i - 1]
        kaydirma += 1
    a[k] = x
    return k


def sirali_mi(a):
    for i in range(1, len(a)):
        if a[i - 1] > a[i]:
            return False
    return True


def dizi_metni(a):
    return "[" + ", ".join(str(v) for v in a) + "]"


def main():
    global yoklama, kaydirma
    a = []
    ekle = [50, 20, 70, 20, 10, 90, 60, 40]
    sorgular = [5, 20, 45, 90, 95]
    boyutlar = [1000, 2000, 4000]

    print("Boş diziye sırayla ekleme")
    for x in ekle:
        yoklama = 0
        kaydirma = 0
        k = sirali_ekle(a, x)
        print(f"  ekle {x:2d}: konum {k}, yoklama {yoklama}, kaydırma "
              f"{kaydirma} -> " + dizi_metni(a))

    print("\nEkleme konumu sorguları (dizi değişmez)")
    for x in sorgular:
        k = ekleme_konumu(a, x)
        print(f"  x = {x:2d} -> konum {k}", end="")
        if k < len(a) and a[k] == x:
            print(" (x zaten var: ilk kopyanın önüne girer)", end="")
        print()

    print("\nRastgele n ekleme (LCG, tohum 42, değerler 0..1000000)")
    print("     n  toplam yoklama  toplam kaydırma     n²/4"
          "  kaydırma/(n²/4)  sıralı")
    for m in boyutlar:
        rastgele_tohum(42)
        yoklama = 0
        kaydirma = 0
        a = []
        for _ in range(m):
            sirali_ekle(a, rastgele_aralik(0, 1000000))
        ceyrek = m * m // 4
        print(f"{m:6d} {yoklama:15d} {kaydirma:16d} {ceyrek:8d} "
              f"{kaydirma / ceyrek:16.3f}  "
              + ("evet" if sirali_mi(a) else "HAYIR"))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (kaydırma için memmove);
# C++ — std::lower_bound + std::vector::insert; Python —
# bisect.bisect_left, bisect.insort (arama + list.insert).

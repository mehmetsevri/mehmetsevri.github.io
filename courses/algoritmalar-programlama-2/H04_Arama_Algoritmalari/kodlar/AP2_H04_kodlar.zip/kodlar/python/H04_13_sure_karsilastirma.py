"""H04_13_sure_karsilastirma.py — AP-2 Hafta 4 · Örnek 13 (★★★)
Amaç    : Doğrusal ve ikili arama: aynı sorgu karışımında karşılaştırma
          sayıları (stdout, kuramla) ve --olc ile süreler ve kesişim
          noktası kestirimi (stderr). Tam deney: deney/ klasörü
Çalıştır: python3 H04_13_sure_karsilastirma.py [--olc]
Eşleri  : c/H04_13_sure_karsilastirma.c · cpp/H04_13_sure_karsilastirma.cpp
Çıktı   : üç dilde aynı (=) — süreler yalnız stderr'e (--olc)
"""

import math
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import olc_ortanca

SORGU = 1000


# Ölçülen fonksiyonlar: sayaçsız (sayaç artırımı da süreye girer)
def dogrusal_ara(a, x):
    for i in range(len(a)):
        if a[i] == x:
            return i
    return -1


def ikili_ara(a, x):
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if a[mid] == x:
            return mid
        elif a[mid] < x:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1


# Sayaçlı eşleri: aynı adımlar; (sonuç, karşılaştırma/yoklama) döndürür
def dogrusal_ara_say(a, x):
    kars = 0
    for i in range(len(a)):
        kars += 1
        if a[i] == x:
            return i, kars
    return -1, kars


def ikili_ara_say(a, x):
    kars = 0
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        kars += 1
        if a[mid] == x:
            return mid, kars
        elif a[mid] < x:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1, kars


# Sorgu karışımı: çift sıradakiler başarılı (tek sayı 2r + 1, r < n),
# tek sıradakiler başarısız (çift sayı 2r, r <= n); a[i] = 2i + 1.
def sorgu_uret(n):
    rastgele_tohum(42)
    q = [0] * SORGU
    for k in range(SORGU):
        if k % 2 == 0:
            q[k] = 2 * rastgele_aralik(0, n - 1) + 1
        else:
            q[k] = 2 * rastgele_aralik(0, n)
    return q


def taban_log2(n):
    k = 0
    while n > 1:
        n //= 2
        k += 1
    return k


def tum_sorgular(ara, a, q):
    toplam = 0                      # sonuçların toplamı (eleme engeli)
    for x in q:
        toplam += ara(a, x)
    return toplam


def main():
    boyutlar = [8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
    olc = len(sys.argv) > 1 and sys.argv[1] == "--olc"
    oran = []

    print(f"Sorgu karışımı: {SORGU} sorgu, yarısı başarılı, yarısı başarısız"
          " (LCG, tohum 42)")
    print("     n  doğrusal ort.  (3n+1)/4  ikili ort.  ikili en çok"
          "  ⌊log2 n⌋+1  aynı")
    for n in boyutlar:
        a = [2 * i + 1 for i in range(n)]
        q = sorgu_uret(n)
        kd = ki_top = ki_cok = 0
        ayni = True
        for x in q:
            r1, k1 = dogrusal_ara_say(a, x)
            r2, k2 = ikili_ara_say(a, x)
            ayni = ayni and r1 == r2
            kd += k1
            ki_top += k2
            ki_cok = max(ki_cok, k2)
        print(f"{n:6d} {kd / SORGU:14.2f} {(3.0 * n + 1) / 4:9.2f} "
              f"{ki_top / SORGU:11.2f} {ki_cok:13d} {taban_log2(n) + 1:11d}"
              "  " + ("evet" if ayni else "HAYIR"))
        if olc:
            td = olc_ortanca(lambda: tum_sorgular(dogrusal_ara, a, q),
                             5) / SORGU
            ti = olc_ortanca(lambda: tum_sorgular(ikili_ara, a, q),
                             5) / SORGU
            oran.append(td / ti)
            fark = (tum_sorgular(dogrusal_ara, a, q)
                    != tum_sorgular(ikili_ara, a, q))
            print(f"n = {n:5d}: doğrusal {td * 1e9:9.1f} ns, ikili "
                  f"{ti * 1e9:7.1f} ns, oran {oran[-1]:.2f}"
                  + (" (FARK!)" if fark else ""), file=sys.stderr)
    for t in range(1, len(oran)):
        if oran[t - 1] < 1.0 <= oran[t]:            # 1'i geçtiği yer
            u = -math.log(oran[t - 1]) / (math.log(oran[t])
                                          - math.log(oran[t - 1]))
            ln = math.log(boyutlar[t - 1]) + u * (
                math.log(boyutlar[t]) - math.log(boyutlar[t - 1]))
            print(f"kesişim ≈ n = {math.exp(ln):.0f} ({boyutlar[t - 1]} ile "
                  f"{boyutlar[t]} arası; bu makinede, bu çalıştırmada)",
                  file=sys.stderr)
            break


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — lfind (POSIX) / bsearch; C++ — std::find /
# std::lower_bound; Python — list.index, x in a / bisect.bisect_left.

"""H04_02_nobetcili_arama.py — AP-2 Hafta 4 · Örnek 2 (★)
Amaç    : Nöbetçili (sentinel) doğrusal arama: x dizinin sonuna
          yazılır, döngüdeki sınır denetimi (i < n) kalkar
Çalıştır: python3 H04_02_nobetcili_arama.py
Eşleri  : c/H04_02_nobetcili_arama.c · cpp/H04_02_nobetcili_arama.cpp
Çıktı   : üç dilde aynı (=)
"""

indis_kars = 0      # i < n karşılaştırmaları
eleman_kars = 0     # a[i] == x karşılaştırmaları


# Standart doğrusal arama: her adımda İKİ karşılaştırma.
def dogrusal_ara(a, n, x):
    global indis_kars, eleman_kars
    i = 0
    while i < n:
        indis_kars += 1
        eleman_kars += 1
        if a[i] == x:
            return i
        i += 1
    indis_kars += 1             # döngüyü bitiren i < n (yanlış)
    return None


# Nöbetçili arama. Ön koşul: a[n] yazılabilir boş bir yer.
# x a[n]'ye yazıldığı için döngü x'i MUTLAKA bulur: i < n gerekmez.
def nobetcili_ara(a, n, x):
    global indis_kars, eleman_kars
    eski = a[n]
    a[n] = x                # nöbetçi
    i = 0
    eleman_kars += 1
    while a[i] != x:
        i += 1
        eleman_kars += 1
    a[n] = eski             # geri yükle
    indis_kars += 1         # tek sınır denetimi
    return i if i < n else None


def yaz(ad, k):
    print(f"  {ad} -> ", end="")
    if k is None:
        print("yok     ", end="")
    else:
        print(f"konum {k}", end="")
    print(f"  indis {indis_kars} + eleman {eleman_kars} = "
          f"{indis_kars + eleman_kars}")


def main():
    global indis_kars, eleman_kars
    ilk = [12, 45, 7, 23, 56, 89, 34, 11, 70, 5]
    sorgular = [34, 12, 99]
    boyutlar = [10, 100, 1000, 10000, 100000, 1000000]
    n = len(ilk)
    a = ilk + [0]               # nöbetçi yeri (dizinin parçası değil)

    print("a = [" + ", ".join(str(a[i]) for i in range(n))
          + f"]   (n = {n}, kapasite n + 1)")
    for x in sorgular:
        print(f"x = {x}")
        indis_kars = eleman_kars = 0
        yaz("dogrusal_ara ", dogrusal_ara(a, n, x))
        indis_kars = eleman_kars = 0
        yaz("nobetcili_ara", nobetcili_ara(a, n, x))
    print(f"a[{n}] (nöbetçi yeri) aramalardan sonra: {a[n]}\n")

    print("Başarısız arama (en kötü durum): toplam karşılaştırma")
    print("        n  dogrusal  2n + 1  nobetcili   n + 2   oran")
    for n in boyutlar:
        a = [2 * i + 1 for i in range(n)] + [0]  # tek sayılar; aranan çift
        indis_kars = eleman_kars = 0
        dogrusal_ara(a, n, 0)
        d = indis_kars + eleman_kars
        indis_kars = eleman_kars = 0
        nobetcili_ara(a, n, 0)
        s = indis_kars + eleman_kars
        print(f"{n:9d} {d:9d} {2 * n + 1:7d} {s:10d} {n + 2:7d} "
              f"{d / s:6.3f}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (POSIX lfind; nöbetçi kullanmaz);
# C++ — std::find; Python — a.index(x), x in a (C'de yazılmış döngü).

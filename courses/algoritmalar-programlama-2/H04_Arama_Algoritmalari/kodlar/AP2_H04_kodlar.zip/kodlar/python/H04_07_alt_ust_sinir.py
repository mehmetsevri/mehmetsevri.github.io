"""H04_07_alt_ust_sinir.py — AP-2 Hafta 4 · Örnek 7 (★★)
Amaç    : lower_bound (ilk a[i] >= x) ve upper_bound (ilk a[i] > x);
          ilk/son konum ve tekrar sayısı = upper - lower; kâhin testi
Çalıştır: python3 H04_07_alt_ust_sinir.py
Eşleri  : c/H04_07_alt_ust_sinir.c · cpp/H04_07_alt_ust_sinir.cpp
Çıktı   : üç dilde aynı (=)
"""

from bisect import bisect_left, bisect_right

from ortak_rastgele import rastgele_aralik, rastgele_tohum

yoklama = 0         # incelenen a[mid] sayısı


# lower_bound: ilk a[i] >= x konumu; hepsi < x ise n.
# Değişmez: a[0..lo-1] < x <= a[hi..n-1]
def alt_sinir(a, x):
    global yoklama
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        yoklama += 1
        if a[mid] < x:
            lo = mid + 1
        else:
            hi = mid
    return lo


# upper_bound: ilk a[i] > x konumu; hepsi <= x ise n.
# Değişmez: a[0..lo-1] <= x < a[hi..n-1]
def ust_sinir(a, x):
    global yoklama
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        yoklama += 1
        if a[mid] <= x:     # tek fark: <=
            lo = mid + 1
        else:
            hi = mid
    return lo


# Kâhin: bisect_left / bisect_right (yalnızca test için kullanılır)
def kahin_kucuk_say(a, x, esit_dahil):
    return bisect_right(a, x) if esit_dahil else bisect_left(a, x)


# Aynı arama; her adımı yazar (ust = False: alt_sinir, True: ust_sinir)
def sinir_izle(a, x, ust):
    lo, hi = 0, len(a)
    print(("ust_sinir" if ust else "alt_sinir") + f"({x})\n"
          "  lo  hi  mid  a[mid]  karar")
    while lo < hi:
        mid = (lo + hi) // 2
        sola = a[mid] <= x if ust else a[mid] < x
        if ust:
            isaret = "<=" if sola else "> "
        else:
            isaret = "< " if sola else ">="
        print(f"  {lo:2d}  {hi:2d}  {mid:3d}  {a[mid]:6d}  "
              f"a[mid] {isaret} x: ", end="")
        if sola:
            print(f"lo = {mid + 1}")
            lo = mid + 1
        else:
            print(f"hi = {mid}")
            hi = mid
    print(f"  sonuç: {lo}")


def main():
    global yoklama
    a = [1, 2, 2, 2, 4, 4, 7, 9, 9, 9, 9, 12]
    sorgular = [0, 1, 2, 3, 4, 5, 7, 9, 12, 13]

    print("a = [" + ", ".join(str(v) for v in a) + f"]   (n = {len(a)})")
    print("   x  alt  üst  adet  ilk  son  yoklama (alt + üst)")
    for x in sorgular:
        yoklama = 0
        alt = alt_sinir(a, x)
        y1 = yoklama
        yoklama = 0
        ust = ust_sinir(a, x)
        adet = ust - alt
        print(f"  {x:2d}  {alt:3d}  {ust:3d}  {adet:4d}  ", end="")
        if adet > 0:
            print(f"{alt:3d}  {ust - 1:3d}", end="")
        else:
            print("yok  yok", end="")
        print(f"  {y1} + {yoklama}")
    sinir_izle(a, 9, False)
    sinir_izle(a, 9, True)

    # Büyük dizi: b[i] = i / 10, her değer 10 kez
    m = 1000000
    b = [i // 10 for i in range(m)]
    yoklama = 0
    alt, ust = alt_sinir(b, 12345), ust_sinir(b, 12345)
    print(f"\nb[i] = i / 10, n = {m}: 12345 değeri {ust - alt} kez (konum "
          f"{alt}..{ust - 1}), {yoklama} yoklama")

    # Kâhinle karşılaştırmalı rastgele test (tekrarlı sıralı diziler)
    sorgu = uyusmazlik = 0
    rastgele_tohum(42)
    for _ in range(200):
        k = rastgele_aralik(0, 60)
        c = [0] * k
        deger = 0
        for i in range(k):
            deger += rastgele_aralik(0, 2)      # 0: tekrar eden değer
            c[i] = deger
        for _ in range(50):
            x = rastgele_aralik(-1, deger + 1)
            sorgu += 1
            if (alt_sinir(c, x) != kahin_kucuk_say(c, x, False)
                    or ust_sinir(c, x) != kahin_kucuk_say(c, x, True)):
                uyusmazlik += 1
    print(f"Kâhinle karşılaştırma: 200 rastgele dizi, {sorgu} sorgu, "
          f"uyuşmazlık {uyusmazlik}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (bsearch yalnız "herhangi bir" eşit
# elemanı bulur); C++ — std::lower_bound, std::upper_bound,
# std::equal_range; Python — bisect.bisect_left, bisect.bisect_right.

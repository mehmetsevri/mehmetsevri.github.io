/* H04_A01_cikti_tahmini.c — AP-2 Hafta 4 · Alıştırma (Çıktı tahmini)
 * Amaç    : Kapalı aralıklı ikili aramanın incelediği mid değerlerini
 *           ÇALIŞTIRMADAN tahmin edin; sonra çalıştırıp karşılaştırın
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_A01_cikti_tahmini.c -o H04_A01_cikti_tahmini
 * Çalıştır: ./H04_A01_cikti_tahmini
 */
#include <stdio.h>

static int ara(const int a[], int n, int x)
{
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        printf("%d ", mid);
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    const int a[] = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
    printf("-> %d\n", ara(a, 10, 23));
    printf("-> %d\n", ara(a, 10, 7));
    printf("-> %d\n", ara(a, 10, 100));
    return 0;
}

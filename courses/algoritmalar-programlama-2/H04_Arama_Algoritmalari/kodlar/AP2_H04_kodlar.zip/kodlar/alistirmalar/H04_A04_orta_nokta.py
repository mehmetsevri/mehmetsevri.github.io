"""H04_A04_orta_nokta.py — AP-2 Hafta 4 · Alıştırma (Diller arası okuma)
Amaç    : İki orta nokta ifadesi negatif indislerde aynı mı? Python sürümü;
          eşi H04_A04_orta_nokta.c. Önce iki programın çıktısını tahmin
          edin, sonra çalıştırın.
Çalıştır: python3 H04_A04_orta_nokta.py
"""


def main():
    lo, hi = [0, -5, -7], [9, 0, -2]
    for i in range(3):
        m1 = (lo[i] + hi[i]) // 2
        m2 = lo[i] + (hi[i] - lo[i]) // 2
        print(f"lo = {lo[i]}, hi = {hi[i]}: {m1} {m2}")


if __name__ == "__main__":
    main()

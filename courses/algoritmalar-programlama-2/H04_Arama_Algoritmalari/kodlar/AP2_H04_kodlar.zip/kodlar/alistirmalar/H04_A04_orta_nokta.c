/* H04_A04_orta_nokta.c — AP-2 Hafta 4 · Alıştırma (Diller arası okuma)
 * Amaç    : İki orta nokta ifadesi negatif indislerde aynı mı? C sürümü;
 *           eşi H04_A04_orta_nokta.py. Önce iki programın çıktısını tahmin
 *           edin, sonra çalıştırın.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_A04_orta_nokta.c -o H04_A04_orta_nokta
 * Çalıştır: ./H04_A04_orta_nokta
 */
#include <stdio.h>

int main(void)
{
    const int lo[] = {0, -5, -7}, hi[] = {9, 0, -2};
    for (int i = 0; i < 3; i++) {
        int m1 = (lo[i] + hi[i]) / 2;
        int m2 = lo[i] + (hi[i] - lo[i]) / 2;
        printf("lo = %d, hi = %d: %d %d\n", lo[i], hi[i], m1, m2);
    }
    return 0;
}

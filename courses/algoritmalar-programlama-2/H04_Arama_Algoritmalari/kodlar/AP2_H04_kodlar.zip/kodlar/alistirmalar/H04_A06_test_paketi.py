"""H04_A06_test_paketi.py — AP-2 Hafta 4 · Atölye 1 (ortak test paketi)
Amaç    : "Doğru ikili aramayı yaz" meydan okumasının ortak test paketi.
          ogrenci_ara fonksiyonunu KENDİ ikili aramanızla değiştirin. Diziye
          yalnızca a.eleman(i) ile erişin ve her adımda eleman(mid)'i BİR KEZ
          çağırın: yoklamalar sayılır, dizi dışı okuma (negatif indis dahil)
          ve sonsuz döngü yakalanır. Yer tutucu doğru ama yavaş bir doğrusal
          aramadır.
Çalıştır: python3 H04_A06_test_paketi.py
"""

EN_COK_N = 64
YOKLAMA_SINIRI = 200


class SonsuzDongu(Exception):
    pass


class Dizi:
    def __init__(self, n):
        self.veri = [2 * i + 1 for i in range(n)]   # 1, 3, 5, ...
        self.yoklama = 0
        self.disari = 0

    def eleman(self, i):
        """Diziye TEK erişim yolu: a[i] yerine a.eleman(i)."""
        self.yoklama += 1
        if self.yoklama > YOKLAMA_SINIRI:
            raise SonsuzDongu()
        if i < 0 or i >= len(self.veri):   # Python'da a[-1] geçerlidir!
            self.disari += 1
            return 0
        return self.veri[i]


# ===== SİZİN FONKSİYONUNUZ: dizi artan sıralı; konum ya da None =====
def ogrenci_ara(a, n, x):
    for i in range(n):                      # yer tutucu: doğrusal arama
        if a.eleman(i) == x:
            return i
    return None
# =====================================================================


def main():
    sorgu = yanlis = tasan = dongu = yavas = 0
    ilk = None
    for n in range(EN_COK_N + 1):
        sinir = 1 if n == 0 else n.bit_length()     # ⌊log2 n⌋ + 1
        for x in range(-1, 2 * n + 2):
            bek = x // 2 if x > 0 and x % 2 == 1 and x // 2 < n else None
            a = Dizi(n)
            sorgu += 1
            tur = None
            try:
                s = ogrenci_ara(a, n, x)
                if s != bek:
                    yanlis += 1
                    tur = "yanlış sonuç"
                if a.disari > 0:
                    tasan += 1
                    tur = tur or "dizi dışı okuma"
                if a.yoklama > sinir:
                    yavas += 1
                    tur = tur or "çok yoklama"
            except SonsuzDongu:
                dongu += 1
                tur = "sonsuz döngü"
            if tur and ilk is None:
                ilk = (n, x, tur)
    print(f"n = 0..{EN_COK_N}, x = -1..2n+1: {sorgu} sorgu")
    print(f"  yanlış sonuç                      : {yanlis}")
    print(f"  dizi dışı okuma yapan arama       : {tasan}")
    print(f"  {YOKLAMA_SINIRI} yoklamayı aşan (sonsuz döngü)  : {dongu}")
    print(f"  ⌊log2 n⌋ + 1 yoklamayı aşan       : {yavas}")
    if ilk:
        print(f"ilk sorun: n = {ilk[0]}, x = {ilk[1]} ({ilk[2]})")
    toplam = yanlis + tasan + dongu + yavas
    print("sonuç:", "GEÇTİ" if toplam == 0 else "KALDI")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — bsearch; C++ — std::binary_search;
# Python — bisect.bisect_left

/* H04_A07_sayi_tahmin.c — AP-2 Hafta 4 · Atölye 2 (sayı tahmin oyunu)
 * Amaç    : İki kip. "bilgisayar": bilgisayar 1..N arasında bir sayı tutar
 *           (ortak LCG), siz tahmin edersiniz. "ogrenci": siz bir sayı
 *           tutarsınız, bilgisayar ikili aramayla sorar; b (daha büyük),
 *           k (daha küçük), d (doğru) yanıtlarını verirsiniz.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -I../c \
 *           H04_A07_sayi_tahmin.c ../c/ortak_rastgele.c -o H04_A07_sayi_tahmin
 * Çalıştır: ./H04_A07_sayi_tahmin bilgisayar [N] [tohum]
 *           ./H04_A07_sayi_tahmin ogrenci [N]
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

/* stdin'den bir satır; başarıda 1, dosya sonunda 0 */
static int satir_oku(char *tampon, size_t boyut)
{
    if (fgets(tampon, (int)boyut, stdin) == NULL) {
        return 0;
    }
    tampon[strcspn(tampon, "\r\n")] = '\0';
    return 1;
}

/* Argümanı ya da satırı tamsayıya çevirir; hatalıysa 0 döndürür */
static int sayi_mi(const char *s, long *deger)
{
    char *son;
    errno = 0;
    long v = strtol(s, &son, 10);
    if (son == s || *son != '\0' || errno != 0) {
        return 0;
    }
    *deger = v;
    return 1;
}

static int en_cok_soru(long n)          /* ⌊log2 N⌋ + 1 */
{
    int k = 0;
    while (n > 0) {
        n /= 2;
        k++;
    }
    return k;
}

static int bilgisayar_tutar(long n, long tohum)
{
    char t[64];
    rastgele_tohum((uint64_t)tohum);
    long tutulan = rastgele_aralik(1, (int)n);
    int soru = 0;
    printf("1..%ld arasında bir sayı tuttum. Tahmininiz?\n", n);
    while (satir_oku(t, sizeof t)) {
        long x;
        if (!sayi_mi(t, &x) || x < 1 || x > n) {
            printf("  1..%ld arasında bir tamsayı yazın\n", n);
            continue;
        }
        soru++;
        if (x == tutulan) {
            printf("  %ld: doğru! %d soruda buldunuz ", x, soru);
            printf("(ikili aramayla en çok %d)\n", en_cok_soru(n));
            return 0;
        }
        printf("  %ld: daha %s\n", x, x < tutulan ? "büyük" : "küçük");
    }
    printf("girdi bitti; tutulan sayı %ld idi\n", tutulan);
    return 1;
}

static int ogrenci_tutar(long n)
{
    char t[64];
    long lo = 1, hi = n;
    int soru = 0;
    printf("1..%ld arasında bir sayı tutun. Yanıtlar: b / k / d\n", n);
    while (lo <= hi) {
        long tahmin = lo + (hi - lo) / 2;
        soru++;
        printf("  soru %d: %ld mi? ", soru, tahmin);
        if (!satir_oku(t, sizeof t)) {
            printf("\ngirdi bitti\n");
            return 1;
        }
        printf("%s\n", t);
        if (strcmp(t, "d") == 0) {
            printf("buldum: %ld (%d soru; en çok %d)\n", tahmin, soru,
                   en_cok_soru(n));
            return 0;
        } else if (strcmp(t, "b") == 0) {
            lo = tahmin + 1;
        } else if (strcmp(t, "k") == 0) {
            hi = tahmin - 1;
        } else {
            printf("  yalnızca b, k ya da d\n");
            soru--;
        }
    }
    printf("yanıtlar çelişkili: aralık boşaldı (lo = %ld > hi = %ld)\n", lo,
           hi);
    return 1;
}

int main(int argc, char *argv[])
{
    long n = 100, tohum = 42;
    if (argc < 2 || (strcmp(argv[1], "bilgisayar") != 0 &&
                     strcmp(argv[1], "ogrenci") != 0)) {
        fprintf(stderr, "kullanım: %s bilgisayar|ogrenci [N] [tohum]\n",
                argv[0]);
        return 2;
    }
    if ((argc > 2 && (!sayi_mi(argv[2], &n) || n < 1 || n > 1000000000)) ||
        (argc > 3 && !sayi_mi(argv[3], &tohum))) {
        fprintf(stderr, "N 1..10^9 arasında, tohum bir tamsayı olmalı\n");
        return 2;
    }
    if (strcmp(argv[1], "bilgisayar") == 0) {
        return bilgisayar_tutar(n, tohum);
    }
    return ogrenci_tutar(n);
}

/* Kütüphane karşılığı: yok (etkileşimli oyun) */

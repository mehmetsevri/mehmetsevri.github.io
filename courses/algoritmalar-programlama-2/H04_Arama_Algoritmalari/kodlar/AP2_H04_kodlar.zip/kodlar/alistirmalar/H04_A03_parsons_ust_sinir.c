/* H04_A03_parsons_ust_sinir.c — AP-2 Hafta 4 · Alıştırma (Parsons)
 * Tamamlanacak; bu hâliyle derlenmez. Aşağıdaki satırlar upper_bound'un
 * (ilk a[i] > x konumu; hepsi <= x ise n) KARIŞTIRILMIŞ satırlarıdır.
 * Doğru sıraya ve girintiye koyun; değişmezi yorum olarak yazın.
 */
            hi = mid;
    return lo;
    while (lo < hi) {
static size_t ust_sinir(const int a[], size_t n, int x)
        } else {
    size_t lo = 0, hi = n;
        size_t mid = lo + (hi - lo) / 2;
        }
        if (a[mid] <= x) {
    }
            lo = mid + 1;
{
}

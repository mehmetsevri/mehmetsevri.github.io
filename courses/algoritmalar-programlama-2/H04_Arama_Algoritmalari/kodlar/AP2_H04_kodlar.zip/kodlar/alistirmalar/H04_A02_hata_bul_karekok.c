/* H04_A02_hata_bul_karekok.c — AP-2 Hafta 4 · Alıştırma (Hata bulma)
 * BU DOSYA KASITLI HATA İÇERİR: tamsayı karekök ⌊√n⌋ bazı n değerlerinde
 * bir eksik çıkıyor. Hangi n'lerde? Yüklemin tanımına bakın (Örnek 10).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_A02_hata_bul_karekok.c -o H04_A02_hata_bul_karekok
 * Çalıştır: ./H04_A02_hata_bul_karekok
 */
#include <stdio.h>

/* "İlk D" aranıyor: P(r) doğru olan en küçük r; yanıt r - 1 */
static long karekok(long n)
{
    long lo = 1, hi = n + 1;
    while (lo < hi) {
        long mid = lo + (hi - lo) / 2;
        if (mid * mid >= n) {
            hi = mid;
        } else {
            lo = mid + 1;
        }
    }
    return lo - 1;
}

int main(void)
{
    const long n[] = {15, 16, 17, 24, 25, 26, 99, 100};
    for (int i = 0; i < 8; i++) {
        printf("karekok(%ld) = %ld\n", n[i], karekok(n[i]));
    }
    return 0;
}

/* H04_A05_iki_yari.c — AP-2 Hafta 4 · Alıştırma (Karmaşıklık)
 * Amaç    : Sıralı olmayan dizide "ikiye böl, İKİ yarıda da ara" yapan
 *           özyinelemeli arama. Çağrı sayısı için bir yineleme bağıntısı
 *           yazın ve çözün; sonra programın sayaçlarıyla karşılaştırın
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_A05_iki_yari.c -o H04_A05_iki_yari
 * Çalıştır: ./H04_A05_iki_yari
 */
#include <stddef.h>
#include <stdio.h>

static long cagri = 0;

/* x, a[lo..hi-1] içinde var mı? Sıralama varsayımı YOK. */
static int iki_yari_ara(const int a[], size_t lo, size_t hi, int x)
{
    cagri++;
    if (hi - lo == 0) {
        return 0;
    }
    if (hi - lo == 1) {
        return a[lo] == x;
    }
    size_t mid = lo + (hi - lo) / 2;
    return iki_yari_ara(a, lo, mid, x) || iki_yari_ara(a, mid, hi, x);
}

int main(void)
{
    static int a[1024];
    for (size_t i = 0; i < 1024; i++) {
        a[i] = (int)(1024 - i);         /* azalan: ikili arama işe yaramaz */
    }
    const size_t n[] = {1, 2, 4, 8, 16, 1024};
    for (int k = 0; k < 6; k++) {
        cagri = 0;
        int var = iki_yari_ara(a, 0, n[k], -1);     /* -1 dizide yok */
        printf("n = %4zu: %s, %ld çağrı\n", n[k], var ? "var" : "yok",
               cagri);
    }
    return 0;
}

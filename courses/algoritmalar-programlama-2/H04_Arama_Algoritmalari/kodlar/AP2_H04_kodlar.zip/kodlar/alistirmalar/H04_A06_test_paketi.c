/* H04_A06_test_paketi.c — AP-2 Hafta 4 · Atölye 1 (ortak test paketi)
 * Amaç    : "Doğru ikili aramayı yaz" meydan okumasının ortak test paketi.
 *           ogrenci_ara fonksiyonunu KENDİ ikili aramanızla değiştirin.
 *           Diziye yalnızca eleman(i) ile erişin ve her adımda eleman(mid)'i
 *           BİR KEZ çağırın: yoklamalar sayılır, dizi dışı okuma ve sonsuz
 *           döngü yakalanır. Yer tutucu doğru ama yavaş bir doğrusal aramadır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_A06_test_paketi.c -o H04_A06_test_paketi
 * Çalıştır: ./H04_A06_test_paketi
 */
#include <setjmp.h>
#include <stddef.h>
#include <stdio.h>

#define EN_COK_N 64
#define YOKLAMA_SINIRI 200      /* aşan arama "sonsuz döngü" sayılır */

static int dizi[EN_COK_N];
static size_t dizi_n;
static int sorgu_x;
static long yoklama;            /* bu aramadaki eleman() çağrısı */
static long disari;             /* bu aramadaki dizi dışı okuma */
static jmp_buf kacis;

/* Diziye TEK erişim yolu: a[i] yerine eleman(i) yazın */
static int eleman(long i)
{
    yoklama++;
    if (yoklama > YOKLAMA_SINIRI) {
        longjmp(kacis, 1);      /* sonsuz döngü: aramadan çık */
    }
    if (i < 0 || (size_t)i >= dizi_n) {
        disari++;               /* gerçek bir dizide tanımsız davranış */
        return 0;
    }
    return dizi[i];
}

/* ===== SİZİN FONKSİYONUNUZ: dizi artan sıralı; x'in konumu ya da -1 ===== */
static long ogrenci_ara(size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {    /* yer tutucu: doğrusal arama */
        if (eleman((long)i) == x) {
            return (long)i;
        }
    }
    return -1;
}
/* ========================================================================= */

/* Bir sorgu; sonsuz döngüde -2 */
static long calistir(void)
{
    if (setjmp(kacis) != 0) {
        return -2;
    }
    return ogrenci_ara(dizi_n, sorgu_x);
}

static long taban_log2(size_t n)
{
    long k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main(void)
{
    long sorgu = 0, yanlis = 0, tasan = 0, dongu = 0, yavas = 0;
    long ilk_n = -1, ilk_x = 0;
    const char *ilk_tur = "";
    for (size_t n = 0; n <= EN_COK_N; n++) {
        dizi_n = n;
        for (size_t i = 0; i < n; i++) {
            dizi[i] = (int)(2 * i + 1);         /* 1, 3, 5, ... */
        }
        long sinir = n == 0 ? 1 : taban_log2(n) + 1;
        for (int x = -1; x <= (int)(2 * n + 1); x++) {
            long bek = x > 0 && x % 2 == 1 && (size_t)(x / 2) < n
                       ? x / 2 : -1;      /* beklenen konum */
            sorgu_x = x;
            yoklama = 0;
            disari = 0;
            long s = calistir();
            const char *tur = NULL;
            sorgu++;
            if (s == -2) {
                dongu++;
                tur = "sonsuz döngü";
            } else {
                if (s != bek) {
                    yanlis++;
                    tur = "yanlış sonuç";
                }
                if (disari > 0) {
                    tasan++;
                    tur = tur ? tur : "dizi dışı okuma";
                }
                if (yoklama > sinir) {
                    yavas++;
                    tur = tur ? tur : "çok yoklama";
                }
            }
            if (tur != NULL && ilk_n < 0) {
                ilk_n = (long)n;
                ilk_x = x;
                ilk_tur = tur;
            }
        }
    }
    printf("n = 0..%d, x = -1..2n+1: %ld sorgu\n", EN_COK_N, sorgu);
    printf("  yanlış sonuç                      : %ld\n", yanlis);
    printf("  dizi dışı okuma yapan arama       : %ld\n", tasan);
    printf("  %d yoklamayı aşan (sonsuz döngü)  : %ld\n", YOKLAMA_SINIRI,
           dongu);
    printf("  ⌊log2 n⌋ + 1 yoklamayı aşan       : %ld\n", yavas);
    if (ilk_n >= 0) {
        printf("ilk sorun: n = %ld, x = %ld (%s)\n", ilk_n, ilk_x, ilk_tur);
    }
    printf("sonuç: %s\n",
           yanlis + tasan + dongu + yavas == 0 ? "GEÇTİ" : "KALDI");
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::binary_search;
 * Python — bisect.bisect_left */

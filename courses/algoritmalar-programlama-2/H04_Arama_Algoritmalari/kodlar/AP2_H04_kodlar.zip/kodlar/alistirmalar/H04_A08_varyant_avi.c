/* H04_A08_varyant_avi.c — AP-2 Hafta 4 · Atölye 3 (varyant avı)
 * Amaç    : Beş problemi lower_bound ile O(log n)'de çözün: 1–3 yalnızca
 *           alt_sinir çağrılarıyla; 4–5 alt_sinir'in koşulu değiştirilmiş
 *           bir kopyasıyla (4'te yoklama++ satırını koruyun; 5'te yoklamayı
 *           kotu_mu sayar). Şimdilik her çözüm doğrusal kâhini çağırır:
 *           sonuçlar doğrudur ama yoklama sınırı aşılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_A08_varyant_avi.c -o H04_A08_varyant_avi
 * Çalıştır: ./H04_A08_varyant_avi
 */
#include <stddef.h>
#include <stdio.h>

#define N 1000

static long yoklama = 0;        /* dizi elemanı ya da yüklem incelemesi */

/* VERİLEN: ilk a[i] >= x konumu (hepsi < x ise n). a artan sıralı. */
static size_t alt_sinir(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

/* ---------------- kâhinler: doğru ama Θ(n) ---------------- */
static size_t kahin_adet(const int a[], size_t n, int x)
{
    size_t say = 0;
    for (size_t i = 0; i < n; i++) {
        yoklama++;
        say += a[i] == x;
    }
    return say;
}

static size_t kahin_aralik(const int a[], size_t n, int L, int R)
{
    size_t say = 0;
    for (size_t i = 0; i < n; i++) {
        yoklama++;
        say += L <= a[i] && a[i] <= R;
    }
    return say;
}

static int kahin_en_yakin(const int a[], size_t n, int x)   /* n >= 1 */
{
    int en = a[0];
    for (size_t i = 0; i < n; i++) {
        yoklama++;
        long d1 = (long)a[i] - x, d2 = (long)en - x;
        if ((d1 < 0 ? -d1 : d1) < (d2 < 0 ? -d2 : d2)) {
            en = a[i];
        }
    }
    return en;
}

static int kahin_eksik(const int a[], size_t n)   /* 1..n+1'den biri yok */
{
    for (size_t i = 0; i < n; i++) {
        yoklama++;
        if (a[i] != (int)i + 1) {
            return (int)i + 1;
        }
    }
    return (int)n + 1;
}

static long gizli_ilk_kotu = 1;

static int kotu_mu(long surum)  /* sürüm >= gizli_ilk_kotu ise "kötü" */
{
    yoklama++;
    return surum >= gizli_ilk_kotu;
}

static long kahin_ilk_kotu(long k, int (*kotu)(long))   /* kotu(k) doğru */
{
    for (long s = 1; s < k; s++) {
        if (kotu(s)) {
            return s;
        }
    }
    return k;
}

/* ===================== SİZİN ÇÖZÜMLERİNİZ ===================== */
/* 1) x kaç kez geçer? */
static size_t adet(const int a[], size_t n, int x)
{
    return kahin_adet(a, n, x);
}

/* 2) L <= a[i] <= R olan kaç eleman var? (L <= R) */
static size_t aralik_say(const int a[], size_t n, int L, int R)
{
    return kahin_aralik(a, n, L, R);
}

/* 3) x'e en yakın eleman (eşit uzaklıkta küçük olan); n >= 1 */
static int en_yakin(const int a[], size_t n, int x)
{
    return kahin_en_yakin(a, n, x);
}

/* 4) a: 1..n+1 sayılarından biri eksik, artan sıralı; eksik olan?
 *    (ipucu: a[i] > i + 1 yüklemi monotondur) */
static int eksik_sayi(const int a[], size_t n)
{
    return kahin_eksik(a, n);
}

/* 5) Sürümler 1..k; kotu monoton; kotu(k) doğru. İlk kötü sürüm? */
static long ilk_kotu(long k, int (*kotu)(long))
{
    return kahin_ilk_kotu(k, kotu);
}
/* ===================================================================== */

static int taban_log2(size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

static void rapor(const char *ad, int dogru, int toplam, long en_cok,
                  long sinir)
{
    printf("%-14s doğru %3d/%3d  en çok yoklama %5ld (sınır %3ld)  %s\n",
           ad, dogru, toplam, en_cok, sinir,
           dogru == toplam && en_cok <= sinir ? "GEÇTİ" : "KALDI");
}

int main(void)
{
    static int a[N], e[N];
    for (size_t i = 0; i < N; i++) {
        a[i] = (int)(i / 3) * 2;        /* 0 0 0 2 2 2 4 ... (tekrarlı) */
    }
    long s1 = 2 * (taban_log2(N) + 1), s3 = taban_log2(N) + 3;
    printf("a = 0 0 0 2 2 2 4 ... (n = %d); alt_sinir(a, n, 4) = %zu\n", N,
           alt_sinir(a, N, 4));
    int d = 0, t = 0;
    long m = 0;
    for (int x = -2; x <= 2 * N / 3 + 2; x += 3) {      /* 1) adet */
        size_t bek = kahin_adet(a, N, x);
        yoklama = 0;
        d += adet(a, N, x) == bek;
        t++;
        m = yoklama > m ? yoklama : m;
    }
    rapor("1) adet", d, t, m, s1);
    d = t = 0;
    m = 0;
    for (int L = -5; L <= 700; L += 47) {               /* 2) aralık */
        int R = L + 37;
        size_t bek = kahin_aralik(a, N, L, R);
        yoklama = 0;
        d += aralik_say(a, N, L, R) == bek;
        t++;
        m = yoklama > m ? yoklama : m;
    }
    rapor("2) aralik_say", d, t, m, s1);
    d = t = 0;
    m = 0;
    for (int x = -3; x <= 2 * N / 3 + 3; x += 7) {      /* 3) en yakın */
        int bek = kahin_en_yakin(a, N, x);
        yoklama = 0;
        d += en_yakin(a, N, x) == bek;
        t++;
        m = yoklama > m ? yoklama : m;
    }
    rapor("3) en_yakin", d, t, m, s3);
    d = t = 0;
    m = 0;
    for (int yok = 1; yok <= N + 1; yok += 50) {        /* 4) eksik */
        for (size_t i = 0; i < N; i++) {
            e[i] = (int)i + 1 + ((int)i + 1 >= yok);
        }
        yoklama = 0;
        d += eksik_sayi(e, N) == yok;
        t++;
        m = yoklama > m ? yoklama : m;
    }
    rapor("4) eksik_sayi", d, t, m, taban_log2(N) + 1);
    d = t = 0;
    m = 0;
    for (long g = 1; g <= 1000000; g += 49999) {        /* 5) ilk kötü */
        gizli_ilk_kotu = g;
        yoklama = 0;
        d += ilk_kotu(1000000, kotu_mu) == g;
        t++;
        m = yoklama > m ? yoklama : m;
    }
    rapor("5) ilk_kotu", d, t, m, taban_log2(1000000) + 1);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::lower_bound, std::upper_bound,
 * std::partition_point; Python — bisect_left, bisect_right */

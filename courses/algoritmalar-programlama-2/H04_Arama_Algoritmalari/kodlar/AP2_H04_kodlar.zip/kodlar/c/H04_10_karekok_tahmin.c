/* H04_10_karekok_tahmin.c — AP-2 Hafta 4 · Örnek 10 (★★)
 * Amaç    : Cevap üzerinde ikili arama: monoton yüklem (Y…Y D…D) ve ilk D;
 *           tamsayı karekök; sayı tahmin oyunu (en çok ⌊log2 N⌋ + 1 soru)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_10_karekok_tahmin.c ortak_rastgele.c -o H04_10_karekok_tahmin
 * Çalıştır: ./H04_10_karekok_tahmin
 * Eşleri  : cpp/H04_10_karekok_tahmin.cpp · python/H04_10_karekok_tahmin.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

#include "ortak_rastgele.h"

#define EN_COK_DUZEY 64

static long adim = 0;           /* yüklem değerlendirme / soru sayısı */

/* Monoton yüklem P(r) = "r * r > n" (r >= 1): r büyüdükçe Y…Y D…D.
 * r * r taşabileceğinden eşdeğeri r > n / r sınanır. */
static int cok_buyuk_mu(uint64_t r, uint64_t n)
{
    return r > n / r;
}

/* ⌊√n⌋ = (P'nin doğru olduğu ilk r) - 1. Aranan bir dizi elemanı değil,
 * [lo, hi] aralığındaki ilk D'dir. Değişmez: P(lo - 1) = Y, P(hi) = D. */
static uint64_t tamsayi_karekok(uint64_t n)
{
    if (n < 2) {
        return n;
    }
    uint64_t lo = 1;                            /* P(0) tanım gereği Y */
    uint64_t hi = n < 4294967296u ? n : 4294967296u;    /* P(hi) = D */
    while (lo < hi) {
        uint64_t mid = lo + (hi - lo) / 2;
        adim++;
        if (cok_buyuk_mu(mid, n)) {
            hi = mid;       /* ilk D: mid ya da solu */
        } else {
            lo = mid + 1;   /* ilk D: mid'in sağı */
        }
    }
    return lo - 1;
}

/* Tutulan sayıyı [1, N] içinde ikili aramayla bulur; soru sayısı.
 * yaz = 1 ise her soruyu ve yanıtı yazar. */
static int tahmin_oyunu(long N, long tutulan, int yaz)
{
    long lo = 1, hi = N;
    int soru = 0;
    while (lo <= hi) {
        long tahmin = lo + (hi - lo) / 2;
        soru++;
        if (yaz) {
            printf("    soru %d: %ld mi?", soru, tahmin);
        }
        if (tahmin == tutulan) {
            if (yaz) {
                printf(" -> doğru\n");
            }
            return soru;
        } else if (tahmin < tutulan) {
            if (yaz) {
                printf(" -> daha büyük\n");
            }
            lo = tahmin + 1;
        } else {
            if (yaz) {
                printf(" -> daha küçük\n");
            }
            hi = tahmin - 1;
        }
    }
    return -1;                                  /* olmaz: 1 <= tutulan <= N */
}

/* (boyut, adet) çiftini listeye ekler; aynı boyut varsa adedi birleştirir */
static void boyut_ekle(long boyut[], long adet[], int *m, long s, long c)
{
    if (s == 0) {
        return;
    }
    for (int i = 0; i < *m; i++) {
        if (boyut[i] == s) {
            adet[i] += c;
            return;
        }
    }
    boyut[*m] = s;
    adet[*m] = c;
    (*m)++;
}

/* 1..N oyunlarının soru sayısı dağılımı, oyunları tek tek oynamadan:
 * aynı boyuttaki aralık aynı soru ağacını verir ve her düzeyde en çok iki
 * farklı boyut vardır. dagilim[k] = k soruda biten oyun sayısı. */
static int dagilim_hesapla(long N, long dagilim[])
{
    long boyut[4] = {N}, adet[4] = {1};
    int m = 1, k = 0;
    while (m > 0 && k < EN_COK_DUZEY) {
        long yb[4], ya[4];
        int ym = 0;
        k++;
        dagilim[k] = 0;
        for (int i = 0; i < m; i++) {
            dagilim[k] += adet[i];      /* her aralıkta bir oyun biter */
            long sol = (boyut[i] - 1) / 2;
            boyut_ekle(yb, ya, &ym, sol, adet[i]);
            boyut_ekle(yb, ya, &ym, boyut[i] - 1 - sol, adet[i]);
        }
        for (int i = 0; i < ym; i++) {
            boyut[i] = yb[i];
            adet[i] = ya[i];
        }
        m = ym;
    }
    return k;                                   /* en çok soru sayısı */
}

static int taban_log2(long n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main(void)
{
    static const uint64_t sayilar[] = {
        0, 1, 2, 3, 4, 15, 16, 17, 40, 99, 100, 1000000, 2147483647,
        1000000000000u, 1000000000000000000u, 18446744073709551615u};
    static const long boyutlar[] = {100, 1000, 1000000};

    printf("1) Monoton yüklem: P(r) = r * r > 40\n   r:");
    for (uint64_t r = 1; r <= 10; r++) {
        printf(" %2" PRIu64, r);
    }
    printf("\n   P:");
    for (uint64_t r = 1; r <= 10; r++) {
        printf("  %s", cok_buyuk_mu(r, 40) ? "D" : "Y");
    }
    printf("\n   ilk D: r = %" PRIu64 "  =>  ⌊√40⌋ = %" PRIu64 "\n",
           tamsayi_karekok(40) + 1, tamsayi_karekok(40));

    printf("\n2) Tamsayı karekök (cevap üzerinde ikili arama)\n");
    printf("                     n          ⌊√n⌋  adım  doğrulama\n");
    for (size_t t = 0; t < sizeof sayilar / sizeof sayilar[0]; t++) {
        uint64_t n = sayilar[t];
        adim = 0;
        uint64_t r = tamsayi_karekok(n);
        /* r² <= n < (r + 1)², taşmadan: bölmeyle */
        int dogru = (r == 0 || r <= n / r) && (r + 1 > n / (r + 1));
        printf("  %20" PRIu64 "  %12" PRIu64 "  %4ld  %s\n", n, r, adim,
               dogru ? "evet" : "HAYIR");
    }

    printf("\n3) Sayı tahmin oyunu: 1..100, tutulan sayılar LCG (tohum 42)\n");
    rastgele_tohum(42);
    for (int oyun = 1; oyun <= 3; oyun++) {
        long tutulan = rastgele_aralik(1, 100);
        printf("  oyun %d: tutulan %ld\n", oyun, tutulan);
        int s = tahmin_oyunu(100, tutulan, 1);
        printf("    %d soruda bulundu\n", s);
    }

    printf("\n4) Tüm tutulan sayılar için soru sayısı dağılımı\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        long N = boyutlar[t];
        long dagilim[EN_COK_DUZEY + 1] = {0};
        int en_cok = dagilim_hesapla(N, dagilim);
        long toplam = 0;
        for (int k = 1; k <= en_cok; k++) {
            toplam += k * dagilim[k];
        }
        printf("  N = %ld: en çok %d soru (⌊log2 N⌋ + 1 = %d), ortalama "
               "%.3f\n", N, en_cok, taban_log2(N) + 1, (double)toplam / N);
        if (N <= 1000) {                /* oyunları tek tek oyna, denetle */
            long oynanan[EN_COK_DUZEY + 1] = {0};
            for (long s = 1; s <= N; s++) {
                oynanan[tahmin_oyunu(N, s, 0)]++;
            }
            int ayni = 1;
            printf("    soru:");
            for (int k = 1; k <= en_cok; k++) {
                printf(" %4d", k);
                ayni = ayni && oynanan[k] == dagilim[k];
            }
            printf("\n    oyun:");
            for (int k = 1; k <= en_cok; k++) {
                printf(" %4ld", dagilim[k]);
            }
            printf("\n    %ld oyun tek tek oynandı: dağılım aynı mı? %s\n",
                   N, ayni ? "evet" : "HAYIR");
        } else {
            int tam = 1;
            for (int k = 1; k < en_cok; k++) {
                tam = tam && dagilim[k] == (1L << (k - 1));
            }
            printf("    1..%d soru: 2^(k-1) oyun (dolu düzeyler)? %s;"
                   " %d soru: %ld oyun\n", en_cok - 1, tam ? "evet" : "HAYIR",
                   en_cok, dagilim[en_cok]);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (sqrt kayan noktalıdır; büyük n'de
 * yuvarlama hatası verebilir); C++ — yok (std::sqrt aynı uyarıyla);
 * Python — math.isqrt(n) (kesin tamsayı karekök). */

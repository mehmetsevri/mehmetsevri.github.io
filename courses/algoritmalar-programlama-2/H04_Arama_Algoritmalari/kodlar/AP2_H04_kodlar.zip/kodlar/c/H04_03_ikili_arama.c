/* H04_03_ikili_arama.c — AP-2 Hafta 4 · Örnek 3 (★)
 * Amaç    : İkili arama, yinelemeli, kapalı aralık [lo, hi]: her adımda
 *           aday aralık yarıya iner; yoklama sayısı <= ⌊log2 n⌋ + 1
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_03_ikili_arama.c ortak_rastgele.c -o H04_03_ikili_arama
 * Çalıştır: ./H04_03_ikili_arama
 * Eşleri  : cpp/H04_03_ikili_arama.cpp · python/H04_03_ikili_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long yoklama = 0;        /* incelenen a[mid] sayısı */

/* Ön koşul: a[0..n-1] artan sıralı. x'in konumu ya da -1.
 * Değişmez: x dizideyse a[lo..hi] içindedir. */
static long ikili_ara(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1;  /* hi = -1 olabilir: işaretli */
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2; /* taşmasız */
        yoklama++;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;   /* a[lo..mid] elendi */
        } else {
            hi = mid - 1;   /* a[mid..hi] elendi */
        }
    }
    return -1;                          /* aralık boş: lo == hi + 1 */
}

/* Aynı algoritma; her adımı yazar (elle izleme tablosu) */
static long ikili_ara_izle(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1;
    int adim = 0;
    printf("x = %d\n  adım  lo  hi  mid  a[mid]  karar\n", x);
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        adim++;
        printf("  %4d %3ld %3ld %4ld %7d  ", adim, lo, hi, mid, a[mid]);
        if (a[mid] == x) {
            printf("a[mid] == x: bulundu\n");
            return mid;
        } else if (a[mid] < x) {
            printf("a[mid] < x: lo = %ld\n", mid + 1);
            lo = mid + 1;
        } else {
            printf("a[mid] > x: hi = %ld\n", mid - 1);
            hi = mid - 1;
        }
    }
    printf("  lo = %ld > hi = %ld: aralık boş, bulunamadı\n", lo, hi);
    return -1;
}

/* 2^k <= n olan en büyük k (n >= 1): ⌊log2 n⌋ */
static int taban_log2(size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main(void)
{
    static const int a[] = {3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61, 67,
                            73, 80, 88, 95};
    static const int sorgular[] = {61, 45, 3, 95};
    static const size_t boyutlar[] = {1, 2, 3, 4, 5, 7, 8, 15, 16, 17, 100,
                                      1000, 1023, 1024, 4096};
    const size_t n = sizeof a / sizeof a[0];

    printf("a = [");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]   (n = %zu)\n", n);
    for (size_t t = 0; t < 2; t++) {
        ikili_ara_izle(a, n, sorgular[t]);
    }
    for (size_t t = 0; t < 4; t++) {
        yoklama = 0;
        long k = ikili_ara(a, n, sorgular[t]);
        printf("ikili_ara(%d) = %ld   yoklama = %ld\n", sorgular[t], k,
               yoklama);
    }
    yoklama = 0;
    printf("boş dizi: ikili_ara(7) = %ld   yoklama = %ld\n",
           ikili_ara(a, 0, 7), yoklama);

    printf("\nTüm sorgular, b[i] = 2i + 1:\n"
           "  B (başarılı) : x = b[i], n sorgu\n"
           "  S (başarısız): x = 0, 2, …, 2n, n + 1 sorgu\n");
    printf("     n  en çok B  en çok S  ortalama B  ⌊log2 n⌋+1  doğru\n");
    int *b = malloc(1000000 * sizeof *b);
    if (b == NULL) {
        return 1;
    }
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        size_t m = boyutlar[t];
        for (size_t i = 0; i < m; i++) {
            b[i] = (int)(2 * i + 1);
        }
        long en_cok_b = 0, en_cok_s = 0, toplam_b = 0;
        int dogru = 1;
        for (size_t i = 0; i <= 2 * m; i++) {
            int x = (int)i;
            long beklenen = (x % 2 == 1) ? (x - 1) / 2 : -1;
            yoklama = 0;
            if (ikili_ara(b, m, x) != beklenen) {
                dogru = 0;
            }
            if (beklenen >= 0) {
                toplam_b += yoklama;
                en_cok_b = yoklama > en_cok_b ? yoklama : en_cok_b;
            } else {
                en_cok_s = yoklama > en_cok_s ? yoklama : en_cok_s;
            }
        }
        printf("%6zu %9ld %9ld %11.3f %11d  %s\n", m, en_cok_b, en_cok_s,
               (double)toplam_b / m, taban_log2(m) + 1,
               dogru ? "evet" : "HAYIR");
    }

    const size_t milyon = 1000000;
    for (size_t i = 0; i < milyon; i++) {
        b[i] = (int)(2 * i + 1);
    }
    rastgele_tohum(42);
    long en_cok = 0;
    for (int q = 0; q < 1000; q++) {    /* yarısı başarılı, yarısı değil */
        int r = rastgele_aralik(0, (int)milyon - 1);
        int x = (q % 2 == 0) ? 2 * r + 1 : 2 * r;
        yoklama = 0;
        ikili_ara(b, milyon, x);
        en_cok = yoklama > en_cok ? yoklama : en_cok;
    }
    printf("\nn = %zu, 1000 sorgu (LCG, tohum 42): en çok %ld yoklama;"
           " ⌊log2 n⌋ + 1 = %d\n", milyon, en_cok, taban_log2(milyon) + 1);
    free(b);
    return 0;
}

/* Kütüphane karşılığı: C — bsearch (stdlib.h; void * ve karşılaştırıcı,
 * Örnek 12); C++ — std::binary_search (yalnız var/yok),
 * std::lower_bound; Python — bisect.bisect_left. */

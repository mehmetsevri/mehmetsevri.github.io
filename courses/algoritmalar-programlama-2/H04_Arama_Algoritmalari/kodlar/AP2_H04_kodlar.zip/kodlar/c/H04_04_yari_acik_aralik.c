/* H04_04_yari_acik_aralik.c — AP-2 Hafta 4 · Örnek 4 (★★)
 * Amaç    : İkili arama, yarı açık aralık [lo, hi): değişmezi assert ile
 *           denetleyerek tasarım; sonlanma denetimi; ekleme konumu
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_04_yari_acik_aralik.c -o H04_04_yari_acik_aralik
 * Çalıştır: ./H04_04_yari_acik_aralik      [bozuk: sırasız dizi, assert]
 * Eşleri  : cpp/H04_04_yari_acik_aralik.cpp ·
 *           python/H04_04_yari_acik_aralik.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

static long yoklama = 0;        /* incelenen a[mid] sayısı */
static long denetim = 0;        /* değişmez denetimi sayısı */

/* Değişmez (yalnız hata ayıklama; O(n) maliyetli):
 * 0 <= lo <= hi <= n, a[0..lo-1] < x ve a[hi..n-1] > x */
static int degismez_mi(const int a[], size_t n, size_t lo, size_t hi,
                       int x)
{
    denetim++;
    if (lo > hi || hi > n) {
        return 0;
    }
    for (size_t i = 0; i < lo; i++) {
        if (a[i] >= x) {
            return 0;
        }
    }
    for (size_t i = hi; i < n; i++) {
        if (a[i] <= x) {
            return 0;
        }
    }
    return 1;
}

/* Ön koşul: a[0..n-1] artan sıralı. x'in konumu ya da -1.
 * Sözleşme: aday bölge a[lo..hi-1]; hi aralığa DAHİL DEĞİL. */
static long ikili_ara_yari(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;              /* başlangıç: tüm dizi [0, n) */
    while (lo < hi) {                   /* aralık boş değil */
        assert(degismez_mi(a, n, lo, hi, x));
        size_t mid = lo + (hi - lo) / 2;    /* lo <= mid < hi */
        size_t eski = hi - lo;
        yoklama++;
        if (a[mid] == x) {
            return (long)mid;
        } else if (a[mid] < x) {
            lo = mid + 1;               /* a[lo..mid] < x */
        } else {
            hi = mid;                   /* a[mid..hi-1] > x */
        }
        assert(hi - lo < eski);         /* sonlanma: aralık daraldı */
        (void)eski;                     /* -DNDEBUG ile uyarı olmasın */
    }
    assert(degismez_mi(a, n, lo, hi, x));
    return -1;                          /* lo == hi: x buraya eklenir */
}

/* Aynı algoritma; her adımda üç bölgeyi ve değişmezi yazar */
static long ikili_ara_yari_izle(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;
    printf("x = %d\n  lo  hi  mid  a[mid]   <x | aday | >x  değişmez"
           "  karar\n", x);
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        int d = degismez_mi(a, n, lo, hi, x);
        printf("  %2zu  %2zu  %3zu  %6d  %4zu | %4zu | %2zu  %-8s  ", lo,
               hi, mid, a[mid], lo, hi - lo, n - hi, d ? "evet" : "HAYIR");
        if (a[mid] == x) {
            printf("bulundu\n");
            return (long)mid;
        } else if (a[mid] < x) {
            printf("lo = mid + 1 = %zu\n", mid + 1);
            lo = mid + 1;
        } else {
            printf("hi = mid = %zu\n", mid);
            hi = mid;
        }
    }
    printf("  lo == hi == %zu: aralık boş; x yok, ekleme konumu %zu\n", lo,
           lo);
    return -1;
}

int main(int argc, char *argv[])
{
    static const int a[] = {3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61, 67,
                            73, 80, 88, 95};
    static int b[64];
    const size_t n = sizeof a / sizeof a[0];

    if (argc > 1 && strcmp(argv[1], "bozuk") == 0) {
        static const int s[] = {5, 1, 4, 2, 3};    /* SIRALI DEĞİL */
        printf("sırasız dizide arama: değişmez bozulur, assert durdurur\n");
        fflush(stdout);
        ikili_ara_yari(s, 5, 2);
        return 0;
    }
    ikili_ara_yari_izle(a, n, 61);
    ikili_ara_yari_izle(a, n, 45);

    printf("\nYoklama: 61 -> ");
    yoklama = 0;
    long k = ikili_ara_yari(a, n, 61);
    printf("%ld (%ld yoklama), 95 -> ", k, yoklama);
    yoklama = 0;
    k = ikili_ara_yari(a, n, 95);
    printf("%ld (%ld yoklama), 2 -> ", k, yoklama);
    yoklama = 0;
    k = ikili_ara_yari(a, n, 2);
    printf("%ld (%ld yoklama)\n", k, yoklama);

    long sorgu = 0, hata = 0;
    denetim = 0;
    for (size_t m = 0; m <= 64; m++) {
        for (size_t i = 0; i < m; i++) {
            b[i] = (int)(2 * i + 1);
        }
        for (int x = -1; x <= (int)(2 * m + 1); x++) {
            long beklenen = (x > 0 && x % 2 == 1 && x < (int)(2 * m))
                            ? (x - 1) / 2 : -1;
            sorgu++;
            if (ikili_ara_yari(b, m, x) != beklenen) {
                hata++;
            }
        }
    }
    printf("n = 0..64, x = -1..2n+1: %ld sorgu, hatalı sonuç %ld\n"
           "değişmez %ld kez denetlendi (assert hiç durdurmadı)\n", sorgu,
           hata, denetim);
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::binary_search,
 * std::lower_bound (yarı açık [first, last) sözleşmesi); Python —
 * bisect.bisect_left (lo, hi parametreleri de yarı açık). */

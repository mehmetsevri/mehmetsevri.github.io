/* H04_12_genel_arama.c — AP-2 Hafta 4 · Örnek 12 (★★★)
 * Amaç    : Genel (generic) ikili arama: void * taban, öge boyutu ve
 *           karşılaştırıcı işaretçisiyle struct dizisinde arama; ada göre
 *           arama, önek araması (lower_bound); kâhin: bsearch
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_12_genel_arama.c -o H04_12_genel_arama
 * Çalıştır: ./H04_12_genel_arama
 * Eşleri  : cpp/H04_12_genel_arama.cpp · python/H04_12_genel_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct ogrenci {
    int numara;
    char ad[16];
    double ortalama;
};

static long yoklama = 0;        /* karşılaştırıcı çağrısı (yoklama) */

/* Karşılaştırıcı sözleşmesi: a < b ise negatif, eşitse 0, a > b ise
 * pozitif. a - b yerine (a > b) - (a < b): taşmaz (Hata Avcısı 5). */
static int numara_kars(const void *a, const void *b)
{
    const struct ogrenci *x = a, *y = b;
    return (x->numara > y->numara) - (x->numara < y->numara);
}

static int ad_kars(const void *a, const void *b)
{
    const struct ogrenci *x = a, *y = b;
    return strcmp(x->ad, y->ad);
}

/* Genel ikili arama (bsearch ile aynı parametre sırası). i. ögenin adresi
 * taban + i * boyut baytıdır. Ön koşul: dizi kars'a göre sıralı. */
static long genel_ara(const void *anahtar,
                      const void *taban, size_t n,
                      size_t boyut,
                      int (*kars)(const void *,
                                  const void *))
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        const char *oge = (const char *)taban
                          + mid * boyut;
        int s = kars(anahtar, oge);
        yoklama++;
        if (s == 0) {
            return (long)mid;
        } else if (s > 0) {
            lo = mid + 1;   /* anahtar > öge */
        } else {
            hi = mid;       /* anahtar < öge */
        }
    }
    return -1;
}

/* Genel lower_bound: kars(öge, anahtar) >= 0 olan ilk konum (ya da n) */
static size_t genel_alt_sinir(const void *anahtar, const void *taban,
                              size_t n, size_t boyut,
                              int (*kars)(const void *, const void *))
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        const char *oge = (const char *)taban
                          + mid * boyut;
        yoklama++;
        if (kars(oge, anahtar) < 0) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

/* Ön koşul denetimi: dizi kars'a göre artan (eşitler serbest) mı? */
static int sirali_mi(const void *taban, size_t n, size_t boyut,
                     int (*kars)(const void *, const void *))
{
    for (size_t i = 1; i < n; i++) {
        const char *onceki = (const char *)taban + (i - 1) * boyut;
        if (kars(onceki, onceki + boyut) > 0) {
            return 0;
        }
    }
    return 1;
}

static void kayit_yaz(const struct ogrenci *o)
{
    printf("%d %-6s %.2f", o->numara, o->ad, o->ortalama);
}

int main(void)
{
    static const struct ogrenci kayitlar[] = {      /* numaraya göre */
        {1001, "Kerem", 2.85}, {1004, "Ayla", 3.40}, {1009, "Zeynep", 3.75},
        {1013, "Can", 2.10}, {1020, "Selin", 3.05}, {1027, "Ali", 3.90},
        {1031, "Ece", 2.60}, {1046, "Tolga", 3.20}, {1052, "Deniz", 2.95},
        {1068, "Emre", 3.55}};
    static const struct ogrenci ada_gore[] = {      /* ada göre */
        {1027, "Ali", 3.90}, {1004, "Ayla", 3.40}, {1013, "Can", 2.10},
        {1052, "Deniz", 2.95}, {1031, "Ece", 2.60}, {1068, "Emre", 3.55},
        {1001, "Kerem", 2.85}, {1020, "Selin", 3.05}, {1046, "Tolga", 3.20},
        {1009, "Zeynep", 3.75}};
    static const int numaralar[] = {1027, 1030, 1001, 1068};
    static const char *const adlar[] = {"Selin", "Ayse", "Zeynep"};
    const size_t n = sizeof kayitlar / sizeof kayitlar[0];
    const size_t boyut = sizeof kayitlar[0];

    printf("Kayıtlar (numaraya göre):\n");
    for (size_t i = 0; i < n; i++) {
        printf("  [%zu] ", i);
        kayit_yaz(&kayitlar[i]);
        printf("\n");
    }
    printf("numaraya göre sıralı mı? %s; ada göre kopya sıralı mı? %s\n",
           sirali_mi(kayitlar, n, boyut, numara_kars) ? "evet" : "HAYIR",
           sirali_mi(ada_gore, n, boyut, ad_kars) ? "evet" : "HAYIR");

    printf("\nNumaraya göre arama\n");
    int kahin_ayni = 1;
    for (size_t t = 0; t < sizeof numaralar / sizeof numaralar[0]; t++) {
        struct ogrenci anahtar = {numaralar[t], "", 0.0};
        yoklama = 0;
        long k = genel_ara(&anahtar, kayitlar, n, boyut, numara_kars);
        printf("  numara %d: ", numaralar[t]);
        if (k >= 0) {
            printf("konum %ld -> ", k);
            kayit_yaz(&kayitlar[k]);
        } else {
            printf("bulunamadı");
        }
        printf(" (%ld yoklama)\n", yoklama);
        /* kâhin: C standart kütüphanesi bsearch */
        const struct ogrenci *p = bsearch(&anahtar, kayitlar, n, boyut,
                                          numara_kars);
        long kk = p == NULL ? -1 : (long)(p - kayitlar);
        kahin_ayni = kahin_ayni && kk == k;
    }

    printf("\nAda göre arama (aynı genel_ara, başka karşılaştırıcı)\n");
    for (size_t t = 0; t < sizeof adlar / sizeof adlar[0]; t++) {
        struct ogrenci anahtar = {0, "", 0.0};
        strcpy(anahtar.ad, adlar[t]);
        yoklama = 0;
        long k = genel_ara(&anahtar, ada_gore, n, boyut, ad_kars);
        printf("  ad %-6s: ", adlar[t]);
        if (k >= 0) {
            printf("konum %ld -> ", k);
            kayit_yaz(&ada_gore[k]);
        } else {
            printf("bulunamadı");
        }
        printf(" (%ld yoklama)\n", yoklama);
        const struct ogrenci *p = bsearch(&anahtar, ada_gore, n, boyut,
                                          ad_kars);
        long kk = p == NULL ? -1 : (long)(p - ada_gore);
        kahin_ayni = kahin_ayni && kk == k;
    }

    printf("\nÖnek araması: \"E\" ile başlayan adlar (lower_bound + tarama)\n");
    struct ogrenci onek = {0, "E", 0.0};
    yoklama = 0;
    size_t i = genel_alt_sinir(&onek, ada_gore, n, boyut, ad_kars);
    printf("  lower_bound konum %zu (%ld yoklama); eşleşenler:", i, yoklama);
    for (; i < n && strncmp(ada_gore[i].ad, onek.ad, strlen(onek.ad)) == 0;
         i++) {
        printf(" %s", ada_gore[i].ad);
    }
    printf("\nkâhin (bsearch / std::lower_bound / bisect) ile aynı mı? %s\n",
           kahin_ayni ? "evet" : "HAYIR");
    return 0;
}

/* Kütüphane karşılığı: C — bsearch(anahtar, taban, n, boyut, kars)
 * (bulunan ögenin işaretçisi ya da NULL; eşitlerden hangisi döneceği
 * belirsiz); C++ — std::lower_bound, std::binary_search (lambda ile
 * "küçüktür"); Python — bisect.bisect_left(a, x, key=...) (3.10+). */

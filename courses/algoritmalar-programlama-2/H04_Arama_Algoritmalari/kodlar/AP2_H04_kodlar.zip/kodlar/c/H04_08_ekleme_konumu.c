/* H04_08_ekleme_konumu.c — AP-2 Hafta 4 · Örnek 8 (★★)
 * Amaç    : Ekleme konumu (ilk a[i] >= x) ve sıralı diziye ekleme:
 *           arama O(log n) yoklama, kaydırma O(n): maliyeti kaydırma belirler
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_08_ekleme_konumu.c ortak_rastgele.c -o H04_08_ekleme_konumu
 * Çalıştır: ./H04_08_ekleme_konumu
 * Eşleri  : cpp/H04_08_ekleme_konumu.cpp · python/H04_08_ekleme_konumu.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

#include "ortak_rastgele.h"

#define KAPASITE 4000

static long yoklama = 0;        /* incelenen a[mid] sayısı */
static long kaydirma = 0;       /* bir sağa taşınan eleman sayısı */

/* x'in sırayı bozmadan girebileceği İLK konum: ilk a[i] >= x (ya da n).
 * Değişmez: a[0..lo-1] < x <= a[hi..n-1] */
static size_t ekleme_konumu(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

/* Ön koşul: a[0..n-1] sıralı ve kapasite > n. x'i yerine ekler ve
 * konumunu döndürür (yeni boyut n + 1). a[k..n-1] bir sağa kayar:
 * SONDAN başa doğru (üzerine yazmamak için). */
static size_t sirali_ekle(int a[], size_t n, int x)
{
    size_t k = ekleme_konumu(a, n, x);
    for (size_t i = n; i > k; i--) {
        a[i] = a[i - 1];
        kaydirma++;
    }
    a[k] = x;
    return k;
}

static int sirali_mi(const int a[], size_t n)
{
    for (size_t i = 1; i < n; i++) {
        if (a[i - 1] > a[i]) {
            return 0;
        }
    }
    return 1;
}

static void dizi_yaz(const int a[], size_t n)
{
    printf("[");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]");
}

int main(void)
{
    static int a[KAPASITE];
    static const int ekle[] = {50, 20, 70, 20, 10, 90, 60, 40};
    static const int sorgular[] = {5, 20, 45, 90, 95};
    static const size_t boyutlar[] = {1000, 2000, 4000};
    size_t n = 0;

    printf("Boş diziye sırayla ekleme\n");
    for (size_t t = 0; t < sizeof ekle / sizeof ekle[0]; t++) {
        yoklama = 0;
        kaydirma = 0;
        size_t k = sirali_ekle(a, n, ekle[t]);
        n++;
        printf("  ekle %2d: konum %zu, yoklama %ld, kaydırma %ld -> ",
               ekle[t], k, yoklama, kaydirma);
        dizi_yaz(a, n);
        printf("\n");
    }

    printf("\nEkleme konumu sorguları (dizi değişmez)\n");
    for (size_t t = 0; t < sizeof sorgular / sizeof sorgular[0]; t++) {
        size_t k = ekleme_konumu(a, n, sorgular[t]);
        printf("  x = %2d -> konum %zu", sorgular[t], k);
        if (k < n && a[k] == sorgular[t]) {
            printf(" (x zaten var: ilk kopyanın önüne girer)");
        }
        printf("\n");
    }

    printf("\nRastgele n ekleme (LCG, tohum 42, değerler 0..1000000)\n");
    printf("     n  toplam yoklama  toplam kaydırma     n²/4"
           "  kaydırma/(n²/4)  sıralı\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        size_t m = boyutlar[t];
        rastgele_tohum(42);
        yoklama = 0;
        kaydirma = 0;
        n = 0;
        for (size_t i = 0; i < m; i++) {
            sirali_ekle(a, n, rastgele_aralik(0, 1000000));
            n++;
        }
        size_t ceyrek = m * m / 4;
        printf("%6zu %15ld %16ld %8zu %16.3f  %s\n", m, yoklama, kaydirma,
               ceyrek, (double)kaydirma / (double)ceyrek,
               sirali_mi(a, n) ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (kaydırma için memmove);
 * C++ — std::lower_bound + std::vector::insert; Python —
 * bisect.bisect_left, bisect.insort (arama + list.insert). */

/* H04_01_dogrusal_arama.c — AP-2 Hafta 4 · Örnek 1 (★)
 * Amaç    : Doğrusal arama: ilk konum, "bulunamadı" sözleşmesi (-1);
 *           sıralı dizide erken çıkış ve karşılaştırma sayacı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_01_dogrusal_arama.c -o H04_01_dogrusal_arama
 * Çalıştır: ./H04_01_dogrusal_arama
 * Eşleri  : cpp/H04_01_dogrusal_arama.cpp · python/H04_01_dogrusal_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

#define N_BUYUK 1000

static long karsilastirma = 0;  /* incelenen eleman sayısı */

/* x'in a[0..n-1] içindeki İLK konumu; x yoksa -1 ("bulunamadı").
 * Değişmez: döngü başında x, a[0..i-1] içinde yok. */
static long dogrusal_ara(const int a[], size_t n,
                         int x)
{
    for (size_t i = 0; i < n; i++) {
        karsilastirma++;
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

/* Ön koşul: a artan sıralı. a[i] >= x görülünce durulur: x varsa
 * buradadır, yoksa ileride de olamaz (erken çıkış).
 * Değişmez: döngü başında a[0..i-1] < x. */
static long sirali_dogrusal_ara(const int a[], size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {
        karsilastirma++;               /* bir eleman: bir sayım */
        if (a[i] >= x) {
            return a[i] == x ? (long)i : -1;
        }
    }
    return -1;
}

static void dizi_yaz(const char *ad, const int a[], size_t n)
{
    printf("%s = [", ad);
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]   (n = %zu)\n", n);
}

static void sonuc_yaz(int x, long k)
{
    if (k == -1) {
        printf("  x = %2d: bulunamadı", x);
    } else {
        printf("  x = %2d: konum %ld", x, k);
    }
    printf(", karşılaştırma %ld\n", karsilastirma);
}

static void kisa_yaz(const char *ad, long k)
{
    printf("  %s ", ad);
    if (k == -1) {
        printf("yok");
    } else {
        printf("%ld", k);
    }
    printf(" (%ld)", karsilastirma);
}

int main(void)
{
    static const int a[] = {7, 3, 9, 3, 5, 1, 8};
    static const int sorgu_a[] = {7, 3, 8, 6};
    static const int b[] = {1, 3, 3, 5, 7, 8, 9};
    static const int sorgu_b[] = {4, 9, 10, 0};
    static int c[N_BUYUK];
    const size_t n = sizeof a / sizeof a[0];
    const size_t nb = sizeof b / sizeof b[0];

    printf("1) Sırasız dizide doğrusal arama (ilk konum)\n");
    dizi_yaz("a", a, n);
    for (size_t t = 0; t < 4; t++) {
        karsilastirma = 0;
        long k = dogrusal_ara(a, n, sorgu_a[t]);
        sonuc_yaz(sorgu_a[t], k);
    }
    karsilastirma = 0;
    printf("  boş dizi:");
    sonuc_yaz(7, dogrusal_ara(a, 0, 7));

    printf("\n2) Sıralı dizide erken çıkış\n");
    dizi_yaz("b", b, nb);
    printf("  konum (karşılaştırma)\n");
    for (size_t t = 0; t < 4; t++) {
        printf("  x = %2d:", sorgu_b[t]);
        karsilastirma = 0;
        kisa_yaz("dogrusal_ara", dogrusal_ara(b, nb, sorgu_b[t]));
        karsilastirma = 0;
        kisa_yaz("sirali_dogrusal_ara", sirali_dogrusal_ara(b, nb,
                                                            sorgu_b[t]));
        printf("\n");
    }

    printf("\n3) Ortalama karşılaştırma: c[i] = 2i + 1, n = %d\n", N_BUYUK);
    for (int i = 0; i < N_BUYUK; i++) {
        c[i] = 2 * i + 1;
    }
    /* top: dogrusal başarılı, başarısız; sirali başarılı, başarısız */
    long top[4] = {0, 0, 0, 0};
    for (int i = 0; i <= N_BUYUK; i++) {
        if (i < N_BUYUK) {         /* başarılı: tek sayılar c[i] */
            karsilastirma = 0;
            dogrusal_ara(c, N_BUYUK, c[i]);
            top[0] += karsilastirma;
            karsilastirma = 0;
            sirali_dogrusal_ara(c, N_BUYUK, c[i]);
            top[2] += karsilastirma;
        }
        karsilastirma = 0;         /* başarısız: çift sayılar 0..2n */
        dogrusal_ara(c, N_BUYUK, 2 * i);
        top[1] += karsilastirma;
        karsilastirma = 0;
        sirali_dogrusal_ara(c, N_BUYUK, 2 * i);
        top[3] += karsilastirma;
    }
    printf("  yöntem                 başarılı (n)  başarısız (n + 1)\n");
    printf("  dogrusal_ara        %12.2f %17.2f\n",
           (double)top[0] / N_BUYUK, (double)top[1] / (N_BUYUK + 1));
    printf("  sirali_dogrusal_ara %12.2f %17.2f\n",
           (double)top[2] / N_BUYUK, (double)top[3] / (N_BUYUK + 1));
    printf("  kuram: başarılı (n + 1) / 2 = %.2f; başarısız n = %d"
           " (erken çıkışla ≈ n / 2)\n", (N_BUYUK + 1) / 2.0, N_BUYUK);
    return 0;
}

/* Kütüphane karşılığı: C — standart C'de yok (POSIX lfind);
 * C++ — std::find (bulamazsa end()); Python — a.index(x) (bulamazsa
 * ValueError), x in a. */

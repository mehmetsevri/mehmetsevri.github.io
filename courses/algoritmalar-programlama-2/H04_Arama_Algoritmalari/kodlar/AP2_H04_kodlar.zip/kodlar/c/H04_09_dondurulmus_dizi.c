/* H04_09_dondurulmus_dizi.c — AP-2 Hafta 4 · Örnek 9 (★★★)
 * Amaç    : Döndürülmüş sıralı dizide arama: her adımda yarılardan biri
 *           sıralıdır, değişmez buna göre uyarlanır; döndürme noktası;
 *           tekrar eden elemanlarda en kötü durumun O(n)'e çıkması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_09_dondurulmus_dizi.c -o H04_09_dondurulmus_dizi
 * Çalıştır: ./H04_09_dondurulmus_dizi
 * Eşleri  : cpp/H04_09_dondurulmus_dizi.cpp ·
 *           python/H04_09_dondurulmus_dizi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

static long yoklama = 0;        /* döngü adımı (a[mid] incelemesi) */

/* Ön koşul: a, FARKLI elemanlı artan sıralı bir dizinin döndürülmüşü.
 * Değişmez: x dizideyse a[lo..hi] içindedir. */
static long dondurulmus_ara(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] == x) {
            return mid;
        }
        if (a[lo] <= a[mid]) {              /* sol yarı a[lo..mid] sıralı */
            if (a[lo] <= x && x < a[mid]) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        } else {                            /* sağ yarı a[mid..hi] sıralı */
            if (a[mid] < x && x <= a[hi]) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
    }
    return -1;
}

/* Döndürme noktası = en küçük elemanın konumu (n >= 1, farklı elemanlar).
 * Değişmez: en küçük eleman a[lo..hi] içindedir. */
static size_t en_kucuk_konum(const int a[], size_t n)
{
    size_t lo = 0, hi = n - 1;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] > a[hi]) {
            lo = mid + 1;                   /* en küçük mid'in sağında */
        } else {
            hi = mid;                       /* mid ya da solunda */
        }
    }
    return lo;
}

/* Tekrarlı sürüm: a[lo] == a[mid] == a[hi] iken hangi yarının sıralı
 * olduğu anlaşılamaz; iki uç birer daraltılır. En kötü durum O(n). */
static long dondurulmus_ara_tekrarli(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] == x) {
            return mid;
        }
        if (a[lo] == a[mid] && a[mid] == a[hi]) {
            lo++;
            hi--;
        } else if (a[lo] <= a[mid]) {
            if (a[lo] <= x && x < a[mid]) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        } else {
            if (a[mid] < x && x <= a[hi]) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
    }
    return -1;
}

/* Aynı arama (farklı elemanlar); her adımı yazar */
static void dondurulmus_izle(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1;
    printf("x = %d\n  lo  hi  mid  a[mid]  sıralı yarı      karar\n", x);
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        printf("  %2ld  %2ld  %3ld  %6d  ", lo, hi, mid, a[mid]);
        if (a[mid] == x) {
            printf("—                bulundu\n");
            return;
        }
        if (a[lo] <= a[mid]) {
            int icinde = a[lo] <= x && x < a[mid];
            printf("sol [%2d .. %2d]   %s\n", a[lo], a[mid],
                   icinde ? "içinde: hi = mid - 1" : "dışında: lo = mid + 1");
            if (icinde) {
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        } else {
            int icinde = a[mid] < x && x <= a[hi];
            printf("sağ [%2d .. %2d]   %s\n", a[mid], a[hi],
                   icinde ? "içinde: lo = mid + 1" : "dışında: hi = mid - 1");
            if (icinde) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
    }
    printf("  lo > hi: bulunamadı\n");
}

static int taban_log2(size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main(void)
{
    static const int a[] = {40, 50, 60, 70, 80, 10, 20, 30};
    static int b[1000];
    const size_t n = sizeof a / sizeof a[0];

    printf("a = [");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]   (10, 20, …, 80 dizisi 3 adım sola döndürüldü)\n");
    dondurulmus_izle(a, n, 20);
    dondurulmus_izle(a, n, 65);
    yoklama = 0;
    size_t k = en_kucuk_konum(a, n);
    printf("döndürme noktası: konum %zu (a[%zu] = %d), %ld yoklama\n", k, k,
           a[k], yoklama);

    printf("\nTüm döndürmeler, tüm x: taban 1, 3, …, 2m - 1\n");
    printf("     m  sorgu  hatalı  en çok yoklama  ⌊log2 m⌋+1"
           "  döndürme noktası doğru\n");
    static const size_t boyutlar[] = {1, 2, 3, 8, 12, 100};
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        size_t m = boyutlar[t];
        long sorgu = 0, hata = 0, en_cok = 0;
        int nokta_dogru = 1;
        for (size_t r = 0; r < m; r++) {        /* r adım sola döndür */
            for (size_t i = 0; i < m; i++) {
                b[i] = (int)(2 * ((i + r) % m) + 1);
            }
            if (en_kucuk_konum(b, m) != (m - r) % m) {
                nokta_dogru = 0;
            }
            for (int x = 0; x <= (int)(2 * m); x++) {
                long beklenen = -1;     /* kâhin: doğrusal tarama */
                for (size_t i = 0; i < m; i++) {
                    if (b[i] == x) {
                        beklenen = (long)i;
                    }
                }
                yoklama = 0;
                sorgu++;
                if (dondurulmus_ara(b, m, x) != beklenen) {
                    hata++;
                }
                en_cok = yoklama > en_cok ? yoklama : en_cok;
            }
        }
        printf("%6zu %6ld %7ld %15ld %11d  %s\n", m, sorgu, hata, en_cok,
               taban_log2(m) + 1, nokta_dogru ? "evet" : "HAYIR");
    }

    printf("\nTekrar eden elemanlar: 999 tane 2 ve tek bir 1\n");
    printf("  1'in konumu  dondurulmus_ara_tekrarli  yoklama\n");
    static const size_t konumlar[] = {0, 1, 500, 998, 999};
    for (size_t t = 0; t < sizeof konumlar / sizeof konumlar[0]; t++) {
        for (size_t i = 0; i < 1000; i++) {
            b[i] = 2;
        }
        b[konumlar[t]] = 1;
        yoklama = 0;
        long s = dondurulmus_ara_tekrarli(b, 1000, 1);
        printf("  %11zu  %24ld  %7ld\n", konumlar[t], s, yoklama);
    }
    for (size_t i = 0; i < 1000; i++) {
        b[i] = 2;
    }
    yoklama = 0;
    long s = dondurulmus_ara_tekrarli(b, 1000, 3);
    printf("  hepsi 2, x = 3: sonuç %ld, %ld yoklama (n = 1000)\n", s,
           yoklama);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::rotate döndürür,
 * aramaz); Python — yok. Döndürme noktası bulunup iki parçada bsearch /
 * std::lower_bound / bisect de kullanılabilir. */

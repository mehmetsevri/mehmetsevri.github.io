/* H04_07_alt_ust_sinir.c — AP-2 Hafta 4 · Örnek 7 (★★)
 * Amaç    : lower_bound (ilk a[i] >= x) ve upper_bound (ilk a[i] > x);
 *           ilk/son konum ve tekrar sayısı = upper - lower; kâhin testi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_07_alt_ust_sinir.c ortak_rastgele.c -o H04_07_alt_ust_sinir
 * Çalıştır: ./H04_07_alt_ust_sinir
 * Eşleri  : cpp/H04_07_alt_ust_sinir.cpp · python/H04_07_alt_ust_sinir.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long yoklama = 0;        /* incelenen a[mid] sayısı */

/* lower_bound: ilk a[i] >= x konumu; hepsi < x ise n.
 * Değişmez: a[0..lo-1] < x <= a[hi..n-1] */
static size_t alt_sinir(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

/* upper_bound: ilk a[i] > x konumu; hepsi <= x ise n.
 * Değişmez: a[0..lo-1] <= x < a[hi..n-1] */
static size_t ust_sinir(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] <= x) {  /* tek fark: <= */
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

/* Kâhin (C'de kütüphane karşılığı yok): x'ten küçük eleman sayısı
 * lower_bound'dur; esit_dahil ise (<= x) sayısı upper_bound'dur. Θ(n). */
static size_t kahin_kucuk_say(const int a[], size_t n, int x, int esit_dahil)
{
    size_t say = 0;
    for (size_t i = 0; i < n; i++) {
        if (a[i] < x || (esit_dahil && a[i] == x)) {
            say++;
        }
    }
    return say;
}

/* Aynı arama; her adımı yazar (ust = 0: alt_sinir, 1: ust_sinir) */
static void sinir_izle(const int a[], size_t n, int x, int ust)
{
    size_t lo = 0, hi = n;
    printf("%s(%d)\n  lo  hi  mid  a[mid]  karar\n",
           ust ? "ust_sinir" : "alt_sinir", x);
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        int sola = ust ? a[mid] <= x : a[mid] < x;
        printf("  %2zu  %2zu  %3zu  %6d  a[mid] %s x: ", lo, hi, mid, a[mid],
               ust ? (sola ? "<=" : "> ") : (sola ? "< " : ">="));
        if (sola) {
            printf("lo = %zu\n", mid + 1);
            lo = mid + 1;
        } else {
            printf("hi = %zu\n", mid);
            hi = mid;
        }
    }
    printf("  sonuç: %zu\n", lo);
}

int main(void)
{
    static const int a[] = {1, 2, 2, 2, 4, 4, 7, 9, 9, 9, 9, 12};
    static const int sorgular[] = {0, 1, 2, 3, 4, 5, 7, 9, 12, 13};
    const size_t n = sizeof a / sizeof a[0];

    printf("a = [");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]   (n = %zu)\n", n);
    printf("   x  alt  üst  adet  ilk  son  yoklama (alt + üst)\n");
    for (size_t t = 0; t < sizeof sorgular / sizeof sorgular[0]; t++) {
        int x = sorgular[t];
        yoklama = 0;
        size_t alt = alt_sinir(a, n, x);
        long y1 = yoklama;
        yoklama = 0;
        size_t ust = ust_sinir(a, n, x);
        size_t adet = ust - alt;
        printf("  %2d  %3zu  %3zu  %4zu  ", x, alt, ust, adet);
        if (adet > 0) {
            printf("%3zu  %3zu", alt, ust - 1);
        } else {
            printf("yok  yok");
        }
        printf("  %ld + %ld\n", y1, yoklama);
    }
    sinir_izle(a, n, 9, 0);
    sinir_izle(a, n, 9, 1);

    /* Büyük dizi: b[i] = i / 10, her değer 10 kez */
    const size_t m = 1000000;
    int *b = malloc(m * sizeof *b);
    if (b == NULL) {
        return 1;
    }
    for (size_t i = 0; i < m; i++) {
        b[i] = (int)(i / 10);
    }
    yoklama = 0;
    size_t alt = alt_sinir(b, m, 12345), ust = ust_sinir(b, m, 12345);
    printf("\nb[i] = i / 10, n = %zu: 12345 değeri %zu kez (konum %zu..%zu),"
           " %ld yoklama\n", m, ust - alt, alt, ust - 1, yoklama);
    free(b);

    /* Kâhinle karşılaştırmalı rastgele test (tekrarlı sıralı diziler) */
    int c[60];
    long sorgu = 0, uyusmazlik = 0;
    rastgele_tohum(42);
    for (int deneme = 0; deneme < 200; deneme++) {
        size_t k = (size_t)rastgele_aralik(0, 60);
        int deger = 0;
        for (size_t i = 0; i < k; i++) {
            deger += rastgele_aralik(0, 2);     /* 0: tekrar eden değer */
            c[i] = deger;
        }
        for (int q = 0; q < 50; q++) {
            int x = rastgele_aralik(-1, deger + 1);
            sorgu++;
            if (alt_sinir(c, k, x) != kahin_kucuk_say(c, k, x, 0) ||
                ust_sinir(c, k, x) != kahin_kucuk_say(c, k, x, 1)) {
                uyusmazlik++;
            }
        }
    }
    printf("Kâhinle karşılaştırma: 200 rastgele dizi, %ld sorgu, "
           "uyuşmazlık %ld\n", sorgu, uyusmazlik);
    return 0;
}

/* Kütüphane karşılığı: C — yok (bsearch yalnız "herhangi bir" eşit
 * elemanı bulur); C++ — std::lower_bound, std::upper_bound,
 * std::equal_range; Python — bisect.bisect_left, bisect.bisect_right. */

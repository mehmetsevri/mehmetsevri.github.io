/* H04_06_orta_nokta_tasmasi.c — AP-2 Hafta 4 · Örnek 6 (★★)
 * Amaç    : Orta nokta taşması: int32 sınırında (lo + hi) / 2 negatif
 *           olur; güvenli lo + (hi - lo) / 2. İşaretli taşma tanımsız
 *           davranıştır: burada ÇALIŞTIRILMAZ, işaretsizle benzetilir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_06_orta_nokta_tasmasi.c -o H04_06_orta_nokta_tasmasi
 * Çalıştır: ./H04_06_orta_nokta_tasmasi
 * Eşleri  : cpp/H04_06_orta_nokta_tasmasi.cpp ·
 *           python/H04_06_orta_nokta_tasmasi.py
 * Çıktı   : Δ — Python tamsayıları taşmaz; bkz. Dil Penceresi
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

/* Sanal sıralı dizi: a[i] = i. 2^30'dan büyük dizi AYRILMAZ; yalnızca
 * indis aritmetiği benzetilir. */
static int32_t sanal_eleman(int32_t i)
{
    return i;
}

/* (lo + hi) / 2'nin 32 bitlik ikiye tümleyen makinedeki sonucu.
 * int32_t toplamı taşarsa TANIMSIZ DAVRANIŞ olur; burada taşma yok:
 *  - uint32_t toplamı (int 32 bitken) 2^32 modunda sarar: TANIMLI
 *    (C17 6.2.5p9);
 *  - sığmayan değerin int32_t'ye dönüşümü UYGULAMA TANIMLI
 *    (C17 6.3.1.3p3); GCC değeri 2^32 modunda indirger. */
static int32_t sarmali_orta(int32_t lo, int32_t hi)
{
    uint32_t toplam = (uint32_t)lo + (uint32_t)hi;
    return (int32_t)toplam / 2;
}

/* Güvenli: 0 <= lo <= hi iken hi - lo taşmaz, sonuç [lo, hi] içinde */
static int32_t guvenli_orta(int32_t lo, int32_t hi)
{
    return lo + (hi - lo) / 2;
}

/* Bloch'un (2006) ikinci önerisi: işaretsiz toplam, 1 bit sağa kaydırma
 * (Java'da >>>). Toplam < 2^32 olduğundan sonuç int32_t'ye sığar. */
static int32_t kaydirmali_orta(int32_t lo, int32_t hi)
{
    return (int32_t)(((uint32_t)lo + (uint32_t)hi) >> 1);
}

/* Sanal dizide kapalı aralıklı ikili arama (n <= INT32_MAX).
 * guvenli = 0: sarmalı orta nokta; 1: güvenli orta nokta. */
static void ara_benzet(int guvenli, int32_t n, int32_t x)
{
    int32_t lo = 0, hi = n - 1;
    int adim = 0;
    while (lo <= hi) {
        int32_t mid = guvenli ? guvenli_orta(lo, hi) : sarmali_orta(lo, hi);
        adim++;
        if (!guvenli) {
            printf("  adım %d: lo = %" PRId32 ", hi = %" PRId32
                   ", mid = %" PRId32 "\n", adim, lo, hi, mid);
        }
        if (mid < lo || mid > hi) {
            printf("  mid aralık dışında (negatif indis): a[mid] okunsaydı"
                   "\n  dizi dışı erişim olurdu; durduruldu\n");
            return;
        }
        int32_t deger = sanal_eleman(mid);
        if (deger == x) {
            printf("  %d adımda bulundu: konum %" PRId32 "\n", adim, mid);
            return;
        }
        if (deger < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    printf("  bulunamadı\n");
}

/* x = n - 1 aranırken (en büyük lo + hi) ve 32 bitte taşma olur mu? */
static void sinir_denetle(int64_t n)
{
    int64_t lo = 0, hi = n - 1, en_buyuk = 0, x = n - 1;
    while (lo <= hi) {
        int64_t toplam = lo + hi;       /* 64 bitte kesin değer */
        en_buyuk = toplam > en_buyuk ? toplam : en_buyuk;
        int64_t mid = lo + (hi - lo) / 2;
        if (mid == x) {
            break;
        }
        if (mid < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    printf("  n = %10" PRId64 ": en büyük lo + hi = %10" PRId64 "  %s\n",
           n, en_buyuk, en_buyuk > INT32_MAX ? "> INT32_MAX: TAŞAR"
                                             : "<= INT32_MAX: taşmaz");
}

int main(void)
{
    const int32_t lo = 1500000000, hi = 2000000000;

    printf("INT32_MAX = %" PRId32 "\n", INT32_MAX);
    printf("lo = %" PRId32 ", hi = %" PRId32 "\n", lo, hi);
    printf("gerçek lo + hi (64 bit)      = %" PRId64 "\n",
           (int64_t)lo + (int64_t)hi);
    printf("(lo + hi) / 2, 32 bit sarma  = %" PRId32 "   <- negatif!\n",
           sarmali_orta(lo, hi));
    printf("lo + (hi - lo) / 2           = %" PRId32 "\n",
           guvenli_orta(lo, hi));
    printf("(lo + hi) >>> 1 (işaretsiz)  = %" PRId32 "\n",
           kaydirmali_orta(lo, hi));

    const int32_t n = 2000000000;       /* sanal dizi: a[i] = i */
    printf("\nSanal dizide (n = %" PRId32 ") x = n - 1 aranıyor\n", n);
    printf("sarmalı orta nokta (32 bit int ile tipik sonuç):\n");
    ara_benzet(0, n, n - 1);
    printf("güvenli orta nokta:\n");
    ara_benzet(1, n, n - 1);

    printf("\nHata hangi n'de başlar? (son eleman aranırken)\n");
    sinir_denetle((int64_t)1 << 30);
    sinir_denetle(((int64_t)1 << 30) + 1);
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::binary_search,
 * std::lower_bound; Python — bisect.bisect_left (tamsayılar taşmaz). */

/* H04_05_ozyinelemeli_ikili.c — AP-2 Hafta 4 · Örnek 5 (★★)
 * Amaç    : Özyinelemeli ikili arama [lo, hi): T(n) = T(n/2) + c;
 *           çağrı ve derinlik sayaçları, bağıntının açılımı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_05_ozyinelemeli_ikili.c -o H04_05_ozyinelemeli_ikili
 * Çalıştır: ./H04_05_ozyinelemeli_ikili
 * Eşleri  : cpp/H04_05_ozyinelemeli_ikili.cpp ·
 *           python/H04_05_ozyinelemeli_ikili.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

static long cagri = 0;          /* toplam çağrı sayısı */
static int en_derin = 0;        /* en büyük özyineleme derinliği */

/* x'i a[lo..hi-1] içinde arar; konum ya da -1. derinlik: 1, 2, ... */
static long ikili_ara_oz(const int a[], size_t lo, size_t hi, int x,
                         int derinlik)
{
    cagri++;
    if (derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (lo >= hi) {                     /* temel durum: boş aralık */
        return -1;
    }
    size_t mid = lo + (hi - lo) / 2;
    if (a[mid] == x) {                  /* temel durum: bulundu */
        return (long)mid;
    }
    if (a[mid] < x) {                   /* sağ yarı: [mid + 1, hi) */
        return ikili_ara_oz(a, mid + 1, hi, x, derinlik + 1);
    }
    return ikili_ara_oz(a, lo, mid, x, derinlik + 1);   /* [lo, mid) */
}

/* Aynı özyineleme; her çağrıyı derinliğe göre girintili yazar */
static long ikili_ara_oz_izle(const int a[], size_t lo, size_t hi, int x,
                              int derinlik)
{
    for (int i = 1; i < derinlik; i++) {
        printf("  ");
    }
    printf("ara([%zu, %zu))", lo, hi);
    if (lo >= hi) {
        printf(" boş aralık: -1\n");
        return -1;
    }
    size_t mid = lo + (hi - lo) / 2;
    printf(" mid = %zu, a[mid] = %d", mid, a[mid]);
    if (a[mid] == x) {
        printf(": bulundu\n");
        return (long)mid;
    }
    if (a[mid] < x) {
        printf(" < %d\n", x);
        return ikili_ara_oz_izle(a, mid + 1, hi, x, derinlik + 1);
    }
    printf(" > %d\n", x);
    return ikili_ara_oz_izle(a, lo, mid, x, derinlik + 1);
}

/* 2^k <= n olan en büyük k (n >= 1) */
static int taban_log2(size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main(void)
{
    static const int a[] = {3, 8, 14, 19, 23, 31, 37, 42, 50, 56, 61, 67,
                            73, 80, 88, 95};
    static const int sorgular[] = {61, 45};
    static const size_t boyutlar[] = {1, 2, 3, 4, 7, 8, 16, 100, 1000,
                                      4096};
    static int b[4096];
    const size_t n = sizeof a / sizeof a[0];

    for (size_t t = 0; t < 2; t++) {
        printf("x = %d\n", sorgular[t]);
        long k = ikili_ara_oz_izle(a, 0, n, sorgular[t], 1);
        cagri = 0;
        en_derin = 0;
        ikili_ara_oz(a, 0, n, sorgular[t], 1);
        printf("  sonuç %ld: %ld çağrı, en büyük derinlik %d\n", k, cagri,
               en_derin);
    }

    printf("\nAçılım (en kötü yol: her adımda sol yarı, boyut ⌊n/2⌋):\n");
    size_t s = n;
    int c = 0;
    printf("T(%zu)", s);
    while (s > 0) {
        s /= 2;
        c++;
        if (c == 1) {
            printf(" = T(%zu) + c", s);
        } else {
            printf(" = T(%zu) + %dc", s, c);
        }
    }
    printf("\n=> %d çağrı = ⌊log2 %zu⌋ + 2 (son çağrı boş aralık)\n",
           c + 1, n);

    printf("\n     n  en çok çağrı  en büyük derinlik  ⌊log2 n⌋+2  doğru\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        size_t m = boyutlar[t];
        for (size_t i = 0; i < m; i++) {
            b[i] = (int)(2 * i + 1);
        }
        long en_cok = 0;
        int dogru = 1;
        en_derin = 0;
        for (size_t i = 0; i <= 2 * m; i++) {
            int x = (int)i;
            long beklenen = (x % 2 == 1) ? (x - 1) / 2 : -1;
            cagri = 0;
            if (ikili_ara_oz(b, 0, m, x, 1) != beklenen) {
                dogru = 0;
            }
            en_cok = cagri > en_cok ? cagri : en_cok;
        }
        printf("%6zu %13ld %18d %11d  %s\n", m, en_cok, en_derin,
               taban_log2(m) + 2, dogru ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::binary_search;
 * Python — bisect.bisect_left (özyinelemeli sürüm yok). */

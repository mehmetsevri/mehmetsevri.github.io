/* H04_14_merdiven_aramasi.c — AP-2 Hafta 4 · Örnek 14 (★★★)
 * Amaç    : Satırları ve sütunları sıralı matriste merdiven araması:
 *           sağ üst köşeden başla, her adımda bir satır ya da bir sütun
 *           ele; en çok m + n - 1 adım. Satır satır ikili aramayla kıyas
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_14_merdiven_aramasi.c ortak_rastgele.c \
 *           -o H04_14_merdiven_aramasi
 * Çalıştır: ./H04_14_merdiven_aramasi
 * Eşleri  : cpp/H04_14_merdiven_aramasi.cpp ·
 *           python/H04_14_merdiven_aramasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long adim = 0;           /* incelenen hücre sayısı */

/* m x n matris satır öncelikli düz dizide: a[r][c] = a[r * n + c].
 * Satırlar ve sütunlar kesin artan: a[r][c] = max(üst, sol) + 1..4. */
static void matris_uret(int a[], size_t m, size_t n)
{
    for (size_t r = 0; r < m; r++) {
        for (size_t c = 0; c < n; c++) {
            int ust = r > 0 ? a[(r - 1) * n + c] : 0;
            int sol = c > 0 ? a[r * n + c - 1] : 0;
            a[r * n + c] = (ust > sol ? ust : sol) + rastgele_aralik(1, 4);
        }
    }
}

/* Ön koşul: her satır soldan sağa, her sütun yukarıdan aşağıya artan.
 * Değişmez: x matristeyse a[r..m-1][0..c] alt matrisindedir.
 * Bulunursa düz dizideki konumu (r * n + c), yoksa -1 döndürür.
 * c "sütun + 1" tutulur: size_t sütun indisi -1 olamaz. */
static long merdiven_ara(const int a[], size_t m, size_t n,
                         int x)
{
    size_t r = 0, c = n;        /* sağ üst köşe: (0, n - 1) */
    while (r < m && c > 0) {
        int v = a[r * n + c - 1];
        adim++;
        if (v == x) {
            return (long)(r * n + c - 1);
        } else if (v > x) {
            c--;            /* sütunu ele */
        } else {
            r++;            /* satırı ele */
        }
    }
    return -1;
}

/* Aynı arama; her adımı yazar */
static void merdiven_izle(const int a[], size_t m, size_t n, int x)
{
    size_t r = 0, c = n;
    int k = 0;
    printf("x = %d\n  adım  (r, c)  a[r][c]  karar\n", x);
    while (r < m && c > 0) {
        int v = a[r * n + c - 1];
        printf("  %4d  (%zu, %zu)  %7d  ", ++k, r, c - 1, v);
        if (v == x) {
            printf("bulundu\n");
            return;
        } else if (v > x) {
            printf("> x: sola (sütun %zu elendi)\n", c - 1);
            c--;
        } else {
            printf("< x: aşağı (satır %zu elendi)\n", r);
            r++;
        }
    }
    printf("  matristen çıkıldı (r = %zu, c = %ld): x yok\n", r,
           (long)c - 1);
}

/* Karşılaştırma için: her satırda ikili arama, en çok m(⌊log2 n⌋+1) */
static int satir_ikili_ara(const int a[], size_t m, size_t n, int x)
{
    for (size_t r = 0; r < m; r++) {
        size_t lo = 0, hi = n;
        while (lo < hi) {
            size_t mid = lo + (hi - lo) / 2;
            int v = a[r * n + mid];
            adim++;
            if (v == x) {
                return 1;
            } else if (v < x) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
    }
    return 0;
}

int main(void)
{
    static const size_t boyutlar[][2] = {{5, 6}, {10, 10}, {100, 100},
                                         {4, 1000}, {1000, 4}};
    rastgele_tohum(42);
    size_t m = 5, n = 6;
    int *a = malloc(m * n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    matris_uret(a, m, n);
    printf("Matris (%zu x %zu), satırlar ve sütunlar artan:\n", m, n);
    for (size_t r = 0; r < m; r++) {
        printf("  ");
        for (size_t c = 0; c < n; c++) {
            printf("%4d", a[r * n + c]);
        }
        printf("\n");
    }
    merdiven_izle(a, m, n, 15);
    merdiven_izle(a, m, n, 19);
    free(a);

    printf("\nTüm x (en küçük - 1 .. en büyük + 1), kâhin: değer tablosu\n");
    printf("  boyut       sorgu  hatalı  merdiven en çok  m + n - 1"
           "  satır satır ikili en çok\n");
    for (size_t t = 0; t < sizeof boyutlar / sizeof boyutlar[0]; t++) {
        m = boyutlar[t][0];
        n = boyutlar[t][1];
        a = malloc(m * n * sizeof *a);
        if (a == NULL) {
            return 1;
        }
        rastgele_tohum(42);
        matris_uret(a, m, n);
        int en_buyuk = a[m * n - 1];
        char *var = calloc((size_t)en_buyuk + 2, 1);    /* kâhin tablosu */
        if (var == NULL) {
            free(a);
            return 1;
        }
        for (size_t i = 0; i < m * n; i++) {
            var[a[i]] = 1;
        }
        long sorgu = 0, hata = 0, en_cok = 0, en_cok_satir = 0;
        for (int x = a[0] - 1; x <= en_buyuk + 1; x++) {
            adim = 0;
            long k = merdiven_ara(a, m, n, x);
            sorgu++;
            if ((k >= 0) != (x >= 0 && x <= en_buyuk && var[x]) ||
                (k >= 0 && a[k] != x)) {
                hata++;
            }
            en_cok = adim > en_cok ? adim : en_cok;
            adim = 0;
            satir_ikili_ara(a, m, n, x);
            en_cok_satir = adim > en_cok_satir ? adim : en_cok_satir;
        }
        printf("  %4zu x %-4zu %6ld %7ld %16ld %10zu %25ld\n", m, n, sorgu,
               hata, en_cok, m + n - 1, en_cok_satir);
        free(var);
        free(a);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (satır başına
 * std::lower_bound yazılabilir); Python — yok (satır başına bisect). */

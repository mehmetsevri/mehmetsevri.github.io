/* H04_02_nobetcili_arama.c — AP-2 Hafta 4 · Örnek 2 (★)
 * Amaç    : Nöbetçili (sentinel) doğrusal arama: x dizinin sonuna
 *           yazılır, döngüdeki sınır denetimi (i < n) kalkar
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_02_nobetcili_arama.c -o H04_02_nobetcili_arama
 * Çalıştır: ./H04_02_nobetcili_arama
 * Eşleri  : cpp/H04_02_nobetcili_arama.cpp · python/H04_02_nobetcili_arama.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stddef.h>
#include <stdio.h>

#define KAPASITE 1000001        /* en büyük n + 1 (nöbetçi yeri) */

static long indis_kars = 0;     /* i < n karşılaştırmaları */
static long eleman_kars = 0;    /* a[i] == x karşılaştırmaları */

/* Standart doğrusal arama: her adımda İKİ karşılaştırma. */
static long dogrusal_ara(const int a[], size_t n, int x)
{
    size_t i = 0;
    while (i < n) {
        indis_kars++;
        eleman_kars++;
        if (a[i] == x) {
            return (long)i;
        }
        i++;
    }
    indis_kars++;               /* döngüyü bitiren i < n (yanlış) */
    return -1;
}

/* Nöbetçili arama. Ön koşul: a[n] yazılabilir boş bir yer.
 * x a[n]'ye yazıldığı için döngü x'i MUTLAKA bulur: i < n gerekmez. */
static long nobetcili_ara(int a[], size_t n, int x)
{
    int eski = a[n];
    a[n] = x;               /* nöbetçi */
    size_t i = 0;
    eleman_kars++;
    while (a[i] != x) {
        i++;
        eleman_kars++;
    }
    a[n] = eski;            /* geri yükle */
    indis_kars++;           /* tek sınır denetimi */
    return i < n ? (long)i : -1;
}

static void yaz(const char *ad, long k)
{
    printf("  %s -> ", ad);
    if (k == -1) {
        printf("yok     ");
    } else {
        printf("konum %ld", k);
    }
    printf("  indis %ld + eleman %ld = %ld\n", indis_kars, eleman_kars,
           indis_kars + eleman_kars);
}

int main(void)
{
    static int a[KAPASITE];
    static const int ilk[] = {12, 45, 7, 23, 56, 89, 34, 11, 70, 5};
    static const int sorgular[] = {34, 12, 99};
    static const size_t boyutlar[] = {10, 100, 1000, 10000, 100000,
                                      1000000};
    size_t n = sizeof ilk / sizeof ilk[0];

    for (size_t i = 0; i < n; i++) {
        a[i] = ilk[i];
    }
    a[n] = 0;                   /* nöbetçi yeri (dizinin parçası değil) */
    printf("a = [");
    for (size_t i = 0; i < n; i++) {
        printf(i > 0 ? ", %d" : "%d", a[i]);
    }
    printf("]   (n = %zu, kapasite n + 1)\n", n);
    for (size_t t = 0; t < 3; t++) {
        int x = sorgular[t];
        printf("x = %d\n", x);
        indis_kars = eleman_kars = 0;
        yaz("dogrusal_ara ", dogrusal_ara(a, n, x));
        indis_kars = eleman_kars = 0;
        yaz("nobetcili_ara", nobetcili_ara(a, n, x));
    }
    printf("a[%zu] (nöbetçi yeri) aramalardan sonra: %d\n\n", n, a[n]);

    printf("Başarısız arama (en kötü durum): toplam karşılaştırma\n");
    printf("        n  dogrusal  2n + 1  nobetcili   n + 2   oran\n");
    for (size_t t = 0; t < 6; t++) {
        n = boyutlar[t];
        for (size_t i = 0; i < n; i++) {
            a[i] = (int)(2 * i + 1);    /* tek sayılar; aranan çift */
        }
        indis_kars = eleman_kars = 0;
        dogrusal_ara(a, n, 0);
        long d = indis_kars + eleman_kars;
        indis_kars = eleman_kars = 0;
        nobetcili_ara(a, n, 0);
        long s = indis_kars + eleman_kars;
        printf("%9zu %9ld %7zu %10ld %7zu %6.3f\n", n, d, 2 * n + 1, s,
               n + 2, (double)d / s);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX lfind; nöbetçi kullanmaz);
 * C++ — std::find; Python — a.index(x), x in a (C'de yazılmış döngü). */

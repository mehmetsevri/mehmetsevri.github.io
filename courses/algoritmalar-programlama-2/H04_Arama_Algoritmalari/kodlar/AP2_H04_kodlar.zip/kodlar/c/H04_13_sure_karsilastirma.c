/* H04_13_sure_karsilastirma.c — AP-2 Hafta 4 · Örnek 13 (★★★)
 * Amaç    : Doğrusal ve ikili arama: aynı sorgu karışımında karşılaştırma
 *           sayıları (stdout, kuramla) ve --olc ile süreler ve kesişim
 *           noktası kestirimi (stderr). Tam deney: deney/ klasörü
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_13_sure_karsilastirma.c ortak_rastgele.c zamanlayici.c \
 *           -o H04_13_sure_karsilastirma -lm
 * Çalıştır: ./H04_13_sure_karsilastirma [--olc]
 * Eşleri  : cpp/H04_13_sure_karsilastirma.cpp ·
 *           python/H04_13_sure_karsilastirma.py
 * Çıktı   : üç dilde aynı (=) — süreler yalnız stderr'e (--olc)
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define SORGU 1000
#define BOYUT_SAYISI 10

/* Ölçülen fonksiyonlar: sayaçsız (sayaç artırımı da süreye girer) */
static long dogrusal_ara(const int a[], size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

static long ikili_ara(const int a[], size_t n, int x)
{
    long lo = 0, hi = (long)n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

/* Sayaçlı eşleri: aynı adımlar; *kars karşılaştırma/yoklama sayısı */
static long dogrusal_ara_say(const int a[], size_t n, int x, long *kars)
{
    for (size_t i = 0; i < n; i++) {
        (*kars)++;
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

static long ikili_ara_say(const int a[], size_t n, int x, long *kars)
{
    long lo = 0, hi = (long)n - 1;
    while (lo <= hi) {
        long mid = lo + (hi - lo) / 2;
        (*kars)++;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

/* Sorgu karışımı: çift sıradakiler başarılı (tek sayı 2r + 1, r < n),
 * tek sıradakiler başarısız (çift sayı 2r, r <= n); a[i] = 2i + 1. */
static void sorgu_uret(int q[], size_t n)
{
    rastgele_tohum(42);
    for (int k = 0; k < SORGU; k++) {
        if (k % 2 == 0) {
            q[k] = 2 * rastgele_aralik(0, (int)n - 1) + 1;
        } else {
            q[k] = 2 * rastgele_aralik(0, (int)n);
        }
    }
}

struct is_verisi {
    const int *a;
    const int *q;
    size_t n;
    int dogrusal;               /* 1: doğrusal, 0: ikili */
    long long toplam;           /* sonuçların toplamı (eleme engeli) */
};

static void tum_sorgular(void *v)
{
    struct is_verisi *d = v;
    long long t = 0;
    for (int k = 0; k < SORGU; k++) {
        t += d->dogrusal ? dogrusal_ara(d->a, d->n, d->q[k])
                         : ikili_ara(d->a, d->n, d->q[k]);
    }
    d->toplam = t;
}

static int taban_log2(size_t n)
{
    int k = 0;
    while (n > 1) {
        n /= 2;
        k++;
    }
    return k;
}

int main(int argc, char *argv[])
{
    static const size_t boyutlar[BOYUT_SAYISI] = {8, 16, 32, 64, 128, 256,
                                                  512, 1024, 2048, 4096};
    static int a[4096];
    static int q[SORGU];
    int olc = argc > 1 && strcmp(argv[1], "--olc") == 0;
    double oran[BOYUT_SAYISI];

    printf("Sorgu karışımı: %d sorgu, yarısı başarılı, yarısı başarısız"
           " (LCG, tohum 42)\n", SORGU);
    printf("     n  doğrusal ort.  (3n+1)/4  ikili ort.  ikili en çok"
           "  ⌊log2 n⌋+1  aynı\n");
    for (int t = 0; t < BOYUT_SAYISI; t++) {
        size_t n = boyutlar[t];
        for (size_t i = 0; i < n; i++) {
            a[i] = (int)(2 * i + 1);
        }
        sorgu_uret(q, n);
        long kd = 0, ki_top = 0, ki_cok = 0;
        int ayni = 1;
        for (int k = 0; k < SORGU; k++) {
            long ki = 0;
            long r1 = dogrusal_ara_say(a, n, q[k], &kd);
            long r2 = ikili_ara_say(a, n, q[k], &ki);
            ayni = ayni && r1 == r2;
            ki_top += ki;
            ki_cok = ki > ki_cok ? ki : ki_cok;
        }
        printf("%6zu %14.2f %9.2f %11.2f %13ld %11d  %s\n", n,
               (double)kd / SORGU, (3.0 * n + 1) / 4, (double)ki_top / SORGU,
               ki_cok, taban_log2(n) + 1, ayni ? "evet" : "HAYIR");
        if (olc) {
            struct is_verisi d = {a, q, n, 1, 0};
            double td = olc_ortanca(tum_sorgular, &d, 5) / SORGU;
            long long toplam_d = d.toplam;
            d.dogrusal = 0;
            double ti = olc_ortanca(tum_sorgular, &d, 5) / SORGU;
            oran[t] = td / ti;
            fprintf(stderr, "n = %5zu: doğrusal %9.1f ns, ikili %7.1f ns, "
                    "oran %.2f%s\n", n, td * 1e9, ti * 1e9, oran[t],
                    toplam_d == d.toplam ? "" : " (FARK!)");
        }
    }
    if (olc) {                  /* oran = doğrusal / ikili; 1'i geçtiği yer */
        for (int t = 1; t < BOYUT_SAYISI; t++) {
            if (oran[t - 1] < 1.0 && oran[t] >= 1.0) {
                double u = -log(oran[t - 1]) /
                           (log(oran[t]) - log(oran[t - 1]));
                double ln = log((double)boyutlar[t - 1]) +
                            u * (log((double)boyutlar[t]) -
                                 log((double)boyutlar[t - 1]));
                fprintf(stderr, "kesişim ≈ n = %.0f (%zu ile %zu arası; "
                        "bu makinede, bu çalıştırmada)\n", exp(ln),
                        boyutlar[t - 1], boyutlar[t]);
                break;
            }
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — lfind (POSIX) / bsearch; C++ — std::find /
 * std::lower_bound; Python — list.index, x in a / bisect.bisect_left. */

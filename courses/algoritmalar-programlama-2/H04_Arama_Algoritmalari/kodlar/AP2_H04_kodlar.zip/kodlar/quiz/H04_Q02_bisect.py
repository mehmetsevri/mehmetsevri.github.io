"""H04_Q02_bisect.py — AP-2 Hafta 4 · Quiz kodu
Amaç    : bisect_left ve bisect_right'ın tekrar eden değerdeki sonuçları
Çalıştır: python3 H04_Q02_bisect.py
"""
import bisect


def main():
    a = [10, 20, 20, 30]
    print(bisect.bisect_left(a, 20), bisect.bisect_right(a, 20),
          bisect.bisect_left(a, 25))


if __name__ == "__main__":
    main()

/* H04_Q01_alt_sinir_izle.c — AP-2 Hafta 4 · Quiz kodu
 * Amaç    : lower_bound'un incelediği mid değerlerini izleme
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_Q01_alt_sinir_izle.c -o H04_Q01_alt_sinir_izle
 * Çalıştır: ./H04_Q01_alt_sinir_izle
 */
#include <stddef.h>
#include <stdio.h>

static size_t alt_sinir(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        printf("%zu ", mid);
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

int main(void)
{
    const int a[] = {1, 3, 3, 3, 5, 8, 13};
    printf("-> %zu\n", alt_sinir(a, 7, 3));
    return 0;
}

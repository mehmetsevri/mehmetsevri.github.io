/* H04_K06_fonksiyon_isaretcisi.c — AP-2 Hafta 4 · Kavram 6 (Merak Kutusu)
 * Amaç    : Fonksiyonu değer olarak aktarmak: ikiye bölme yöntemine
 *           denklem bir fonksiyon işaretçisi (double (*)(double)) ile verilir
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_K06_fonksiyon_isaretcisi.c -o H04_K06_fonksiyon_isaretcisi
 * Çalıştır: ./H04_K06_fonksiyon_isaretcisi
 */
#include <stdio.h>

typedef double (*fonk_t)(double);   /* double alıp double döndüren fonk. */

static double kup(double x)
{
    return x * x * x - x - 2.0;     /* kök ≈ 1.5214 */
}

static double kare(double x)
{
    return x * x - 2.0;             /* kök √2 */
}

/* Örnek 11'in yöntemi; f artık bir parametre. f(a) ile f(b) ters işaretli. */
static double ikiye_bolme(fonk_t f, double a, double b, double tol,
                          int *yineleme)
{
    double fa = f(a);
    *yineleme = 0;
    while (b - a > tol) {
        double m = a + (b - a) / 2;
        double fm = f(m);
        (*yineleme)++;
        if (fm == 0.0) {
            return m;
        }
        if ((fa < 0.0) == (fm < 0.0)) {
            a = m;
            fa = fm;
        } else {
            b = m;
        }
    }
    return a + (b - a) / 2;
}

int main(void)
{
    const struct {
        const char *ad;
        fonk_t f;
    } denklem[] = {{"x^3 - x - 2", kup}, {"x^2 - 2", kare}};
    for (int i = 0; i < 2; i++) {
        int k;
        double r = ikiye_bolme(denklem[i].f, 1.0, 2.0, 1e-9, &k);
        printf("%-12s kök ≈ %.9f  (%d yineleme)\n", denklem[i].ad, r, k);
    }
    fonk_t g = kare;
    printf("g = kare: g(3.0) = %.1f, (*g)(3.0) = %.1f\n", g(3.0),
           (*g)(3.0));
    printf("g == kare: %s, g == kup: %s\n", g == kare ? "evet" : "hayır",
           g == kup ? "evet" : "hayır");
    return 0;
}

/* Kütüphane karşılığı: C — qsort/bsearch karşılaştırıcısı da bir fonksiyon
 * işaretçisidir; C++ — lambda / şablon; Python — birinci sınıf fonksiyon */

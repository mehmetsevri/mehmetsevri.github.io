"""H04_K08_ilk_kotu_surum.py — AP-2 Hafta 4 · Kavram 8 (Mühendis Gözüyle)
Amaç    : git bisect'in fikri: sürümler 1..k sıralı, "hata var mı?" yüklemi
          monoton (iyi…iyi kötü…kötü); ilk kötü sürüm ikili aramayla en çok
          ⌈log2 k⌉ testte bulunur. Yüklem bir fonksiyon olarak aktarılır.
Çalıştır: python3 H04_K08_ilk_kotu_surum.py
"""


def ilk_dogru(lo, hi, yuklem):
    """[lo, hi] içinde yuklem(s) doğru olan en küçük s (yuklem(hi) doğru).
    Değişmez: yuklem(lo - 1) yanlış, yuklem(hi) doğru."""
    while lo < hi:
        mid = (lo + hi) // 2
        if yuklem(mid):
            hi = mid
        else:
            lo = mid + 1
    return lo


def deneme(k, ilk_kotu, yaz):
    testler = []

    def kotu_mu(s):                 # bir test: s. sürümü derle ve sına
        sonuc = s >= ilk_kotu
        testler.append((s, sonuc))
        return sonuc

    bulunan = ilk_dogru(1, k, kotu_mu)
    if yaz:
        for i, (s, kotu) in enumerate(testler, 1):
            durum = "kötü" if kotu else "iyi"
            print(f"  test {i:2d}: sürüm {s:4d} -> {durum}")
    print(f"k = {k}: ilk kötü sürüm {bulunan}, {len(testler)} test "
          f"(⌈log2 k⌉ = {(k - 1).bit_length()})")


def main():
    deneme(1000, 731, True)
    deneme(1000000, 765432, False)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: git bisect start / good / bad (sürüm denetiminde)

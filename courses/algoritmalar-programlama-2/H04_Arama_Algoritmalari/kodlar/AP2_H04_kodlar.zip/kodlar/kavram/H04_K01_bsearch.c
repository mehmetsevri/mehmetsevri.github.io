/* H04_K01_bsearch.c — AP-2 Hafta 4 · Kavram 1
 * Amaç    : C standart kütüphanesindeki bsearch: void * taban, öge sayısı,
 *           öge boyutu ve karşılaştırıcı; dönüş bir işaretçidir (NULL: yok)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_K01_bsearch.c -o H04_K01_bsearch
 * Çalıştır: ./H04_K01_bsearch
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Sözleşme: *a < *b ise negatif, eşitse 0, *a > *b ise pozitif */
static int int_kars(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

int main(void)
{
    const int a[] = {1, 2, 2, 2, 4, 4, 7, 9, 9, 9, 9, 12};
    size_t n = sizeof a / sizeof a[0];
    const int sorgu[] = {7, 9, 2, 5};
    for (size_t k = 0; k < sizeof sorgu / sizeof sorgu[0]; k++) {
        int x = sorgu[k];
        const int *p = bsearch(&x, a, n, sizeof a[0], int_kars);
        if (p != NULL) {
            printf("bsearch(%d): konum %td\n", x, p - a);
        } else {
            printf("bsearch(%d): NULL (dizide yok)\n", x);
        }
    }
    printf("öge boyutu %zu bayt, n = %zu\n", sizeof a[0], n);
    return 0;
}

/* Kütüphane karşılığı: C — bsearch (eşit anahtarlardan HANGİSİNİ döndüreceği
 * belirtilmemiştir); C++ — std::binary_search / std::lower_bound;
 * Python — bisect.bisect_left */

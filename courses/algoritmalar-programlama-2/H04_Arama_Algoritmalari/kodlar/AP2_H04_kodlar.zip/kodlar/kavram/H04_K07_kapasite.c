/* H04_K07_kapasite.c — AP-2 Hafta 4 · Kavram 7
 * Amaç    : Cevap üzerinde ikili arama ile bir kapasite problemi: n paket
 *           SIRAYLA en çok D seferde taşınacak; en küçük kamyon kapasitesi?
 *           Yüklem "kapasite c yeter" monotondur: Y…Y D…D; ilk D aranır
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -I../c \
 *           H04_K07_kapasite.c ../c/ortak_rastgele.c -o H04_K07_kapasite
 * Çalıştır: ./H04_K07_kapasite
 */
#include <stdio.h>

#include "ortak_rastgele.h"

#define N 12
#define D 4

static long yuklem_cagrisi = 0;

/* c kapasiteyle paketler sırayla kaç seferde taşınır? (c >= en ağır) */
static int sefer_sayisi(const int w[], int n, long c)
{
    int sefer = 1;
    long yuk = 0;
    for (int i = 0; i < n; i++) {
        if (yuk + w[i] > c) {
            sefer++;            /* yeni kamyon */
            yuk = 0;
        }
        yuk += w[i];
    }
    return sefer;
}

/* Monoton yüklem: P(c) = "c kapasite D seferde yeter" */
static int yeter_mi(const int w[], int n, long c)
{
    yuklem_cagrisi++;
    return sefer_sayisi(w, n, c) <= D;
}

/* İlk D: [lo, hi] içinde P(c) doğru olan en küçük c.
 * Değişmez: P(lo - 1) = Y, P(hi) = D. */
static long en_kucuk_kapasite(const int w[], int n, long lo, long hi)
{
    while (lo < hi) {
        long mid = lo + (hi - lo) / 2;
        if (yeter_mi(w, n, mid)) {
            hi = mid;
        } else {
            lo = mid + 1;
        }
    }
    return lo;
}

int main(void)
{
    int w[N];
    long en_agir = 0, toplam = 0;
    rastgele_tohum(42);
    printf("paketler:");
    for (int i = 0; i < N; i++) {
        w[i] = rastgele_aralik(1, 20);
        printf(" %d", w[i]);
        en_agir = w[i] > en_agir ? w[i] : en_agir;
        toplam += w[i];
    }
    printf("\nD = %d sefer; yanıt aralığı [%ld, %ld] (en ağır, toplam)\n",
           D, en_agir, toplam);
    long c = en_kucuk_kapasite(w, N, en_agir, toplam);
    long ikili = yuklem_cagrisi;
    printf("ikili arama: kapasite %ld (%d sefer), %ld yüklem çağrısı\n", c,
           sefer_sayisi(w, N, c), ikili);
    yuklem_cagrisi = 0;
    long k = en_agir;                   /* kâhin: c'yi birer artır */
    while (!yeter_mi(w, N, k)) {
        k++;
    }
    printf("doğrusal kâhin: kapasite %ld, %ld yüklem çağrısı\n", k,
           yuklem_cagrisi);
    printf("yüklem şeridi (c = %ld .. %ld):", c - 3, c + 2);
    for (long t = c - 3; t <= c + 2; t++) {
        printf(" %ld:%c", t, sefer_sayisi(w, N, t) <= D ? 'D' : 'Y');
    }
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::partition_point (yüklemle);
 * Python — bisect.bisect_left(range(lo, hi + 1), True, key=...) (3.10+) */

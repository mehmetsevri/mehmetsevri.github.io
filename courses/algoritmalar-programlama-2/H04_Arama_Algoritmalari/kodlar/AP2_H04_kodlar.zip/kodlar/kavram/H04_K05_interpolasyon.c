/* H04_K05_interpolasyon.c — AP-2 Hafta 4 · Kavram 5
 * Amaç    : İnterpolasyon araması: mid yerine değere göre kestirilen konum
 *           (telefon rehberinde "S" harfini sona yakın açmak). Düzgün
 *           dağılımlı veride çok az yoklama, çarpık veride çok fazla
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -I../c \
 *           H04_K05_interpolasyon.c ../c/ortak_rastgele.c \
 *           -o H04_K05_interpolasyon
 * Çalıştır: ./H04_K05_interpolasyon
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define N 100000
#define SORGU 1000

static long yoklama = 0;

/* Kapalı aralık [lo, hi]; konum = lo + (x - a[lo]) / (a[hi] - a[lo])
 * oranıyla kestirilir. Ön koşul: a artan sıralı. */
static long interpolasyon_ara(const long long a[], size_t n, long long x)
{
    if (n == 0) {
        return -1;
    }
    size_t lo = 0, hi = n - 1;
    while (lo <= hi && x >= a[lo] && x <= a[hi]) {
        size_t pos = lo;
        if (a[hi] != a[lo]) {
            double oran = (double)(x - a[lo]) / (double)(a[hi] - a[lo]);
            pos = lo + (size_t)(oran * (double)(hi - lo));
        }
        yoklama++;
        if (a[pos] == x) {
            return (long)pos;
        } else if (a[pos] < x) {
            lo = pos + 1;
        } else {
            if (pos == 0) {
                break;
            }
            hi = pos - 1;
        }
    }
    return -1;
}

static long ikili_ara(const long long a[], size_t n, long long x)
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] == x) {
            return (long)mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return -1;
}

/* SORGU başarılı aramada (LCG ile seçilen konumlar) ortalama yoklama */
static void karsilastir(const char *ad, const long long a[])
{
    long ti = 0, tb = 0, hata = 0;
    rastgele_tohum(42);
    for (int s = 0; s < SORGU; s++) {
        size_t k = (size_t)rastgele_aralik(0, N - 1);
        yoklama = 0;
        long r1 = interpolasyon_ara(a, N, a[k]);
        ti += yoklama;
        yoklama = 0;
        long r2 = ikili_ara(a, N, a[k]);
        tb += yoklama;
        if (r1 != (long)k || r2 != (long)k) {
            hata++;
        }
    }
    printf("  %-28s %10.2f %10.2f %6ld\n", ad, (double)ti / SORGU,
           (double)tb / SORGU, hata);
}

int main(void)
{
    long long *a = malloc(N * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "bellek yok\n");
        return 1;
    }
    printf("n = %d, %d başarılı arama: ortalama yoklama\n", N, SORGU);
    printf("  %-28s %10s %10s %6s\n", "dizi", "interp.", "ikili", "hatalı");
    rastgele_tohum(7);
    a[0] = 0;
    for (size_t i = 1; i < N; i++) {
        a[i] = a[i - 1] + rastgele_aralik(1, 20);   /* düzgün artış */
    }
    karsilastir("düzgün: aralıklar 1..20", a);
    for (size_t i = 0; i < N; i++) {
        a[i] = (long long)i * (long long)i * (long long)i;   /* i^3 */
    }
    karsilastir("çarpık: a[i] = i^3", a);
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok */

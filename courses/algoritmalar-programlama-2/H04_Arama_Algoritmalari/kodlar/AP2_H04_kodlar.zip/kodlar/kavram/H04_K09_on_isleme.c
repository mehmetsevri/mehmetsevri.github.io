/* H04_K09_on_isleme.c — AP-2 Hafta 4 · Kavram 9 (Mühendis Gözüyle)
 * Amaç    : Ön işleme ile sorgu maliyeti ödünleşimi: k sorgu için
 *           (a) her sorguda doğrusal arama, (b) bir kez sırala (qsort)
 *           + her sorguda ikili arama. Karşılaştırmalar SAYILIR; hangi k'den
 *           sonra sıralamak kâr eder?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -I../c \
 *           H04_K09_on_isleme.c ../c/ortak_rastgele.c -o H04_K09_on_isleme
 * Çalıştır: ./H04_K09_on_isleme
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"

#define N 100000

static long long kars = 0;      /* sayılan karşılaştırma */

static int sayan_kars(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    kars++;
    return (x > y) - (x < y);
}

static long dogrusal_ara(const int a[], size_t n, int x)
{
    for (size_t i = 0; i < n; i++) {
        kars++;
        if (a[i] == x) {
            return (long)i;
        }
    }
    return -1;
}

static long ikili_ara(const int a[], size_t n, int x)
{
    size_t lo = 0, hi = n;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        kars++;
        if (a[mid] == x) {
            return (long)mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return -1;
}

int main(void)
{
    static int a[N], s[N];
    static int sorgu[1000];
    rastgele_tohum(42);
    for (size_t i = 0; i < N; i++) {
        a[i] = (int)(2 * i + 1);        /* farklı değerler */
    }
    rastgele_karistir(a, N);            /* sırasız veri */
    for (int q = 0; q < 1000; q++) {    /* yarısı var, yarısı yok */
        int r = rastgele_aralik(0, N - 1);
        sorgu[q] = q % 2 == 0 ? 2 * r + 1 : 2 * r;
    }
    memcpy(s, a, sizeof a);
    kars = 0;
    qsort(s, N, sizeof s[0], sayan_kars);
    long long siralama = kars;
    printf("n = %d; qsort karşılaştırması: %lld\n", N, siralama);
    printf("     k   doğrusal toplam   sırala + ikili   ucuz olan\n");
    const int ks[] = {1, 5, 10, 15, 20, 25, 30, 50, 100, 1000};
    int kesisim = -1;
    long long dog = 0, iki = 0;
    int yapilan = 0;
    for (size_t j = 0; j < sizeof ks / sizeof ks[0]; j++) {
        for (; yapilan < ks[j]; yapilan++) {
            kars = 0;
            dogrusal_ara(a, N, sorgu[yapilan]);
            dog += kars;
            kars = 0;
            ikili_ara(s, N, sorgu[yapilan]);
            iki += kars;
        }
        long long b = siralama + iki;
        if (kesisim < 0 && b < dog) {
            kesisim = ks[j];
        }
        printf("  %4d %17lld %16lld   %s\n", ks[j], dog, b,
               b < dog ? "sırala + ikili" : "doğrusal");
    }
    printf("bu girdide sıralama k = %d sorgudan itibaren kâr eder\n",
           kesisim);
    return 0;
}

/* Kütüphane karşılığı: C — qsort + bsearch; C++ — std::sort +
 * std::lower_bound; Python — sorted + bisect */

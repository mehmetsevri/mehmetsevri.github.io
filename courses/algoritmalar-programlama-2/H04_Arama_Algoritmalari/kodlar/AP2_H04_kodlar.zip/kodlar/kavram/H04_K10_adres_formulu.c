/* H04_K10_adres_formulu.c — AP-2 Hafta 4 · Kavram 10 (Kaputun Altında)
 * Amaç    : Genel aramanın adres hesabı: i. öge taban + i × boyut baytta
 *           (AP-1 H10 adres formülü). struct ogrenci'nin boyutu, alan
 *           konumları (offsetof) ve dolgu (padding) bu makinede
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H04_K10_adres_formulu.c -o H04_K10_adres_formulu
 * Çalıştır: ./H04_K10_adres_formulu
 */
#include <stddef.h>
#include <stdio.h>

struct ogrenci {                /* Örnek 12 ile aynı yapı */
    int numara;
    char ad[16];
    double ortalama;
};

int main(void)
{
    struct ogrenci d[4] = {{1001, "Kerem", 2.85}, {1009, "Zeynep", 3.75},
                           {1020, "Selin", 3.05}, {1027, "Ali", 3.90}};
    const void *taban = d;
    size_t boyut = sizeof d[0];
    printf("sizeof(struct ogrenci) = %zu bayt\n", boyut);
    printf("offsetof: numara %zu, ad %zu, ortalama %zu\n",
           offsetof(struct ogrenci, numara), offsetof(struct ogrenci, ad),
           offsetof(struct ogrenci, ortalama));
    printf("alanların toplamı %zu bayt; dolgu %zu bayt\n",
           sizeof(int) + 16 + sizeof(double),
           boyut - (sizeof(int) + 16 + sizeof(double)));
    for (size_t i = 0; i < 4; i++) {
        const char *oge = (const char *)taban + i * boyut;
        const struct ogrenci *o = (const struct ogrenci *)oge;
        printf("  i = %zu: taban + %3zu bayt -> %d %s (&d[i] ile aynı: %s)\n",
               i, i * boyut, o->numara, o->ad,
               (const void *)oge == (const void *)&d[i] ? "evet" : "hayır");
    }
    return 0;
}

/* Kütüphane karşılığı: C — bsearch/qsort aynı hesabı içeride yapar;
 * C++ — std::vector<T> ve yineleyiciler; Python — liste ögeleri nesne
 * başvurularıdır (adres aritmetiği yok) */

"""H04_K03_bisect.py — AP-2 Hafta 4 · Kavram 3
Amaç    : Python bisect modülü: bisect_left / bisect_right, insort ve
          key= (3.10+); list.index'in "bulunamadı" sözleşmesi (ValueError)
Çalıştır: python3 H04_K03_bisect.py
"""
import bisect


def main():
    a = [1, 2, 2, 2, 4, 4, 7, 9, 9, 9, 9, 12]
    for x in (9, 3, 13):
        alt = bisect.bisect_left(a, x)
        ust = bisect.bisect_right(a, x)
        print(f"x = {x}: left {alt}, right {ust}, adet {ust - alt}")
    b = [10, 20, 30]
    bisect.insort(b, 25)
    print("insort(b, 25):", b)
    kayitlar = [(1001, "Kerem"), (1009, "Zeynep"), (1027, "Ali")]
    k = bisect.bisect_left(kayitlar, 1009, key=lambda r: r[0])
    print("key ile 1009:", k, kayitlar[k][1])
    print("5 in a:", 5 in a)
    try:
        a.index(5)
    except ValueError as e:
        print("a.index(5):", type(e).__name__, "-", e)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — bsearch; C++ — std::lower_bound / upper_bound

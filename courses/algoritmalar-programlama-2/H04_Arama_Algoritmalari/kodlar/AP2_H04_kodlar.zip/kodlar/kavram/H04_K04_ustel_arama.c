/* H04_K04_ustel_arama.c — AP-2 Hafta 4 · Kavram 4
 * Amaç    : Üstel (galloping) arama: sınır 1, 2, 4, 8, ... ikiye katlanır;
 *           x'i aşan ilk sınırdan sonra yalnızca son aralıkta ikili arama.
 *           x'in konumu k ise yoklama sayısı O(log k) (n'den bağımsız)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 -I../c \
 *           H04_K04_ustel_arama.c ../c/ortak_rastgele.c \
 *           -o H04_K04_ustel_arama
 * Çalıştır: ./H04_K04_ustel_arama
 */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

#define N 1000000

static long yoklama = 0;        /* incelenen a[i] sayısı */

/* [lo, hi) içinde lower_bound: ilk a[i] >= x (yoksa hi) */
static size_t alt_sinir(const int a[], size_t lo, size_t hi, int x)
{
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        yoklama++;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

/* Üstel arama. Değişmez: döngü başında a[0..sinir/2 - 1] < x */
static size_t ustel_ara(const int a[], size_t n, int x)
{
    size_t sinir = 1;
    while (sinir <= n) {
        yoklama++;
        if (a[sinir - 1] >= x) {
            break;              /* ilk a[i] >= x: [sinir/2, sinir) */
        }
        sinir *= 2;
    }
    size_t hi = sinir < n ? sinir : n;
    return alt_sinir(a, sinir / 2, hi, x);
}

int main(void)
{
    int *a = malloc(N * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "bellek yok\n");
        return 1;
    }
    for (size_t i = 0; i < N; i++) {
        a[i] = (int)(2 * i + 1);
    }
    printf("n = %d, a[i] = 2i + 1\n", N);
    printf("  konum k   üstel yoklama   ikili yoklama\n");
    const size_t konum[] = {0, 1, 5, 100, 1000, 100000, 999999};
    for (size_t j = 0; j < sizeof konum / sizeof konum[0]; j++) {
        int x = a[konum[j]];
        yoklama = 0;
        size_t u = ustel_ara(a, N, x);
        long yu = yoklama;
        yoklama = 0;
        size_t b = alt_sinir(a, 0, N, x);
        printf("  %7zu %15ld %15ld%s\n", konum[j], yu, yoklama,
               u == b && u == konum[j] ? "" : "  HATA");
    }
    rastgele_tohum(42);
    long fark = 0;
    for (int t = 0; t < 10000; t++) {
        int x = rastgele_aralik(-1, 2 * N + 1);
        if (ustel_ara(a, N, x) != alt_sinir(a, 0, N, x)) {
            fark++;
        }
    }
    printf("10000 rastgele sorgu, alt_sinir kâhiniyle uyuşmazlık: %ld\n",
           fark);
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::lower_bound);
 * Python — yok (bisect.bisect_left lo/hi parametreleriyle aralıkta arar) */

/* H04_K02_lower_bound.cpp — AP-2 Hafta 4 · Kavram 2
 * Amaç    : C++ <algorithm> ikili arama ailesi: lower_bound, upper_bound,
 *           equal_range, binary_search; "küçüktür" yüklemi ve
 *           partition_point (monoton yüklemde ilk "doğru")
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H04_K02_lower_bound.cpp -o H04_K02_lower_bound
 * Çalıştır: ./H04_K02_lower_bound
 */
#include <algorithm>
#include <functional>
#include <iostream>
#include <vector>

int main()
{
    const std::vector<int> a = {1, 2, 2, 2, 4, 4, 7, 9, 9, 9, 9, 12};
    for (int x : {9, 3, 13}) {
        auto alt = std::lower_bound(a.begin(), a.end(), x);
        auto ust = std::upper_bound(a.begin(), a.end(), x);
        auto [ilk, son] = std::equal_range(a.begin(), a.end(), x);
        bool var = std::binary_search(a.begin(), a.end(), x);
        std::cout << "x = " << x << ": lower " << (alt - a.begin())
                  << ", upper " << (ust - a.begin())
                  << ", adet " << (ust - alt) << ", equal_range "
                  << (ilk - a.begin()) << ".." << (son - a.begin())
                  << ", binary_search " << (var ? "true" : "false")
                  << "\n";
    }
    // Azalan sıralı dizide yüklem std::greater: "önce gelir" = "büyüktür"
    const std::vector<int> b = {12, 9, 9, 7, 4, 2, 1};
    auto k = std::lower_bound(b.begin(), b.end(), 7, std::greater<int>());
    std::cout << "azalan dizide lower_bound(7): " << (k - b.begin())
              << "\n";
    // partition_point: r * r <= 40 doğru olduğu sürece sol taraftayız
    const std::vector<int> r = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    auto p = std::partition_point(r.begin(), r.end(),
                                  [](int v) { return v * v <= 40; });
    std::cout << "ilk r * r > 40: r = " << *p << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (bsearch yalnızca var/yok);
 * Python — bisect.bisect_left / bisect.bisect_right */

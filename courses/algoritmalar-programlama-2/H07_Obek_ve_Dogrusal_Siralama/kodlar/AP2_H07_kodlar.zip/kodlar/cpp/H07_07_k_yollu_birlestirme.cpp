/* H07_07_k_yollu_birlestirme.cpp — AP-2 Hafta 7 · Örnek 7 (★★★)
 * Amaç    : k sıralı listenin en küçük öbekle birleştirilmesi: öbekte her
 *           listenin sıradaki elemanı; çıktı başına O(log k) — toplam
 *           O(N log k); k başı doğrusal taramayla (O(N k)) karşılaştırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_07_k_yollu_birlestirme.cpp -o H07_07_k_yollu_birlestirme
 * Çalıştır: ./H07_07_k_yollu_birlestirme
 * Eşleri  : c/H07_07_k_yollu_birlestirme.c ·
 *           python/H07_07_k_yollu_birlestirme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

struct Oge {
    int deger;
    int liste;                         // hangi listeden
    int konum;                         // o listedeki indisi
};

static long long karsilastirma_sayisi = 0;

// x, y'den önce mi gelir? (küçük değer; eşitse küçük liste no)
static bool once_mi(const Oge& x, const Oge& y)
{
    karsilastirma_sayisi++;
    return x.deger < y.deger || (x.deger == y.deger && x.liste < y.liste);
}

static void yukari_suz(std::vector<Oge>& h, int i)
{
    while (i > 0 && once_mi(h[i], h[(i - 1) / 2])) {
        std::swap(h[i], h[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

static void asagi_suz(std::vector<Oge>& h, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && once_mi(h[c + 1], h[c])) {
            c++;
        }
        if (!once_mi(h[c], h[i])) {
            break;
        }
        std::swap(h[i], h[c]);
        i = c;
    }
}

static void obek_yaz(const std::vector<Oge>& h)
{
    for (const Oge& o : h) {
        std::cout << " " << o.deger << "/" << static_cast<char>('A' + o.liste);
    }
    std::cout << "\n";
}

using Listeler = std::vector<std::vector<int>>;

// Her listenin ilk elemanı öbeğe; sonra kökü çıktıya yaz ve yerine aynı
// listenin sonraki elemanını koy (liste bittiyse son öğeyi köke taşı)
static std::vector<int> k_yollu_birlestir(const Listeler& liste, bool izle)
{
    int k = static_cast<int>(liste.size());
    std::vector<Oge> h;
    std::vector<int> cikti;
    for (int j = 0; j < k; j++) {
        if (!liste[j].empty()) {
            h.push_back({liste[j][0], j, 0});
            yukari_suz(h, static_cast<int>(h.size()) - 1);
        }
    }
    if (izle) {
        std::cout << "  başlangıç öbeği:";
        obek_yaz(h);
    }
    while (!h.empty()) {
        Oge en = h[0];
        cikti.push_back(en.deger);
        const std::vector<int>& lis = liste[en.liste];
        if (en.konum + 1 < static_cast<int>(lis.size())) {
            int s = en.konum + 1;
            h[0] = {lis[s], en.liste, s};
        } else {
            h[0] = h.back();               // liste bitti
            h.pop_back();
        }
        asagi_suz(h, static_cast<int>(h.size()), 0);
        if (izle) {
            std::cout << "  " << std::setw(2) << cikti.size() << ". çıktı "
                      << en.deger << "/" << static_cast<char>('A' + en.liste)
                      << "  öbek:";
            obek_yaz(h);
        }
    }
    return cikti;
}

// Karşılaştırma için: her adımda k listenin başını tek tek tara
static std::vector<int> dogrusal_birlestir(const Listeler& liste)
{
    int k = static_cast<int>(liste.size());
    std::vector<int> konum(k, 0), cikti;
    for (;;) {
        int en = -1;
        for (int j = 0; j < k; j++) {
            if (konum[j] < static_cast<int>(liste[j].size())) {
                Oge aday = {liste[j][konum[j]], j, konum[j]};
                if (en == -1 ||
                    once_mi(aday, {liste[en][konum[en]], en, 0})) {
                    en = j;
                }
            }
        }
        if (en == -1) {
            break;
        }
        cikti.push_back(liste[en][konum[en]]);
        konum[en]++;
    }
    return cikti;
}

static bool sirali_mi(const std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (a[i - 1] > a[i]) {
            return false;
        }
    }
    return true;
}

int main()
{
    Listeler liste = {{45, 62, 78, 91}, {50, 50, 83}, {38, 70, 95}, {},
                      {66}};

    std::cout << "1) 5 şubenin sıralı not listeleri (D şubesi boş), "
                 "k = 5\n";
    for (int j = 0; j < 5; j++) {
        std::cout << "  " << static_cast<char>('A' + j) << ":";
        for (int x : liste[j]) {
            std::cout << " " << x;
        }
        std::cout << (liste[j].empty() ? " (boş)\n" : "\n");
    }
    karsilastirma_sayisi = 0;
    std::vector<int> cikti = k_yollu_birlestir(liste, true);
    std::cout << "  birleşik:";
    for (int x : cikti) {
        std::cout << " " << x;
    }
    std::cout << "\n  eleman = " << cikti.size() << ", karşılaştırma = "
              << karsilastirma_sayisi << ", sıralı mı? "
              << (sirali_mi(cikti) ? "evet" : "HAYIR") << "\n";

    std::cout << "\n2) N = 16384 eleman, k eşit uzunlukta sıralı liste\n";
    std::cout << "     k  öbek karş.  öbek/N  log2 k  tarama karş.  "
                 "tarama/N  aynı mı\n";
    const int n = 16384;
    std::cout << std::fixed << std::setprecision(3);
    for (int k = 2; k <= 64; k *= 2) {
        rastgele_tohum(42);
        Listeler ls(k, std::vector<int>(n / k));
        for (int j = 0; j < k; j++) {  // artan adımlarla sıralı liste
            int x = 0;
            for (int i = 0; i < n / k; i++) {
                x += rastgele_aralik(0, 9);
                ls[j][i] = x;
            }
        }
        karsilastirma_sayisi = 0;
        std::vector<int> c1 = k_yollu_birlestir(ls, false);
        long long ko = karsilastirma_sayisi;
        karsilastirma_sayisi = 0;
        std::vector<int> c2 = dogrusal_birlestir(ls);
        long long kt = karsilastirma_sayisi;
        bool ayni = static_cast<int>(c1.size()) == n && c1 == c2 &&
                    sirali_mi(c1);
        std::cout << std::setw(6) << k << " " << std::setw(11) << ko << " "
                  << std::setw(7) << static_cast<double>(ko) / n << " "
                  << std::setw(7) << std::log2(k) << " " << std::setw(13)
                  << kt << " " << std::setw(9) << static_cast<double>(kt) / n
                  << "  " << (ayni ? "evet" : "HAYIR") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue +
 * std::greater (en küçük öbek), iki liste için std::merge; Python —
 * heapq.merge(*listeler) (yalnızca kâhin). */

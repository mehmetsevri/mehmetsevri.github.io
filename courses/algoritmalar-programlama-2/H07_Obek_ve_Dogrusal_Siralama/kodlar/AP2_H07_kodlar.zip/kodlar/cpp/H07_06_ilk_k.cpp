/* H07_06_ilk_k.cpp — AP-2 Hafta 7 · Örnek 6 (★★)
 * Amaç    : Öncelik kuyruğuyla ilk-k en yüksek not: boyutu k olan EN KÜÇÜK
 *           öbek (kökte listenin en kötüsü); O(n log k) zaman, O(k) bellek
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H07_06_ilk_k.cpp \
 *           -o H07_06_ilk_k
 * Çalıştır: ./H07_06_ilk_k
 * Eşleri  : c/H07_06_ilk_k.c · python/H07_06_ilk_k.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

struct Ogrenci {
    int no;
    int not_;
};

static long long karsilastirma_sayisi = 0;
static long long degisim_sayisi = 0;      // köke yazılan yeni kayıt

// x, y'den daha mı kötü? (düşük not; eşit notta büyük numara)
static bool kotu_mu(const Ogrenci& x, const Ogrenci& y)
{
    karsilastirma_sayisi++;
    return x.not_ < y.not_ || (x.not_ == y.not_ && x.no > y.no);
}

// En küçük öbek: kökte en kötü kayıt
static void yukari_suz(std::vector<Ogrenci>& h, int i)
{
    while (i > 0 && kotu_mu(h[i], h[(i - 1) / 2])) {
        std::swap(h[i], h[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

static void asagi_suz(std::vector<Ogrenci>& h, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && kotu_mu(h[c + 1], h[c])) {
            c++;                           // daha kötü çocuk
        }
        if (!kotu_mu(h[c], h[i])) {
            break;
        }
        std::swap(h[i], h[c]);
        i = c;
    }
}

// Her kayıt için: öbek dolmadıysa ekle; doluysa ve kökten iyiyse kökü
// değiştir. Sonunda öbek yerinde sıralanır: h[0] en iyi.
static std::vector<Ogrenci> ilk_k(const std::vector<Ogrenci>& a, int k,
                                  bool izle)
{
    std::vector<Ogrenci> h;
    h.reserve(k);
    for (const Ogrenci& x : a) {
        std::string ne;
        if (static_cast<int>(h.size()) < k) {
            h.push_back(x);
            yukari_suz(h, static_cast<int>(h.size()) - 1);
            ne = "eklendi";
        } else if (kotu_mu(h[0], x)) {
            h[0] = x;                      // en kötüyü at
            asagi_suz(h, k, 0);
            degisim_sayisi++;
            ne = "köke yazıldı";
        } else {
            ne = "atlandı";
        }
        if (izle) {
            std::cout << "  " << x.no << " (" << std::setw(3) << x.not_
                      << ")  kök = " << std::setw(3) << h[0].not_
                      << "  öbek:";
            for (const Ogrenci& y : h) {
                std::cout << " " << y.not_;
            }
            std::cout << "  <- " << ne << "\n";
        }
    }
    for (int son = static_cast<int>(h.size()) - 1; son > 0; son--) {
        std::swap(h[0], h[son]);                    // en kötü sona
        asagi_suz(h, son, 0);
    }
    return h;
}

static bool iyiden_kotuye(const Ogrenci& p, const Ogrenci& q)  // kâhin için
{
    if (p.not_ != q.not_) {
        return p.not_ > q.not_;
    }
    return p.no < q.no;
}

// artan = false: notlar rastgele 0..100; artan = true: puan = i (en kötü
// durum: her yeni kayıt kökten iyidir)
static std::vector<Ogrenci> ogrenciler(int n, bool artan)
{
    std::vector<Ogrenci> a(n);
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        a[i].no = 2400001 + i;
        a[i].not_ = artan ? i : rastgele_aralik(0, 100);
    }
    return a;
}

int main()
{
    std::cout << "1) İlk 12 öğrenci, k = 3 (kökte listenin en kötüsü)\n";
    std::vector<Ogrenci> a = ogrenciler(12, false);
    std::vector<Ogrenci> h = ilk_k(a, 3, true);
    std::cout << "  ilk 3:";
    for (const Ogrenci& y : h) {
        std::cout << " " << y.no << " (" << y.not_ << ")";
    }
    std::cout << "\n";

    std::cout << "\n2) 200 öğrenci, k = 5; eşit notta küçük numara önce\n";
    a = ogrenciler(200, false);
    karsilastirma_sayisi = 0;
    h = ilk_k(a, 5, false);
    std::sort(a.begin(), a.end(), iyiden_kotuye);   // kâhin
    bool ayni = true;
    for (std::size_t j = 0; j < h.size(); j++) {
        std::cout << "  " << j + 1 << ". " << h[j].no << "  not = "
                  << h[j].not_ << "\n";
        ayni = ayni && h[j].no == a[j].no;
    }
    std::cout << "  karşılaştırma = " << karsilastirma_sayisi
              << "; tam sıralamanın ilk 5'iyle aynı mı? "
              << (ayni ? "evet" : "HAYIR") << "\n";

    std::cout << "\n3) n = 100000: k büyüdükçe iş; r: rastgele notlar, a: "
                 "artan puan (en kötü durum)\n";
    std::cout << "     k  karş. r  karş./n r köke yazma r  karş./n a  "
                 "2 log2 k  kâhin\n";
    const int n = 100000;
    const int kler[] = {1, 10, 100, 1000};
    a = ogrenciler(n, false);
    std::vector<Ogrenci> s = a;
    std::vector<Ogrenci> e = ogrenciler(n, true);
    std::sort(s.begin(), s.end(), iyiden_kotuye);   // kâhin
    std::cout << std::fixed << std::setprecision(3);
    for (int k : kler) {
        karsilastirma_sayisi = 0;
        degisim_sayisi = 0;
        h = ilk_k(a, k, false);
        long long kr = karsilastirma_sayisi, dr = degisim_sayisi;
        ayni = true;
        for (std::size_t j = 0; j < h.size(); j++) {
            ayni = ayni && h[j].no == s[j].no;
        }
        karsilastirma_sayisi = 0;
        h = ilk_k(e, k, false);
        for (std::size_t j = 0; j < h.size(); j++) {
            ayni = ayni && h[j].not_ == n - 1 - static_cast<int>(j);
        }
        std::cout << std::setw(6) << k << " " << std::setw(8) << kr << " "
                  << std::setw(10) << static_cast<double>(kr) / n << " "
                  << std::setw(12) << dr << " " << std::setw(10)
                  << static_cast<double>(karsilastirma_sayisi) / n << " "
                  << std::setw(9) << 2 * std::log2(k) << "  "
                  << (ayni ? "evet" : "HAYIR") << "\n";
    }
    std::cout << std::setprecision(0) << "  tam sıralama ölçeği: n log2 n = "
              << n * std::log2(n) << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue<T,
 * std::vector<T>, std::greater<T>> (en küçük öbek), std::partial_sort,
 * std::nth_element; Python — heapq.nlargest(k, a) (yalnızca kâhin). */

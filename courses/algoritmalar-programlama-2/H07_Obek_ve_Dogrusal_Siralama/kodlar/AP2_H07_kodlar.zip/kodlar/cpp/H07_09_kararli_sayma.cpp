/* H07_09_kararli_sayma.cpp — AP-2 Hafta 7 · Örnek 9 (★★)
 * Amaç    : Kararlı sayma sıralaması: kayıtlar, sıklık dizisi, önek toplam
 *           ve sağdan sola yerleştirme; yön yanlış seçilirse kararlılık
 *           kaybolur
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_09_kararli_sayma.cpp -o H07_09_kararli_sayma
 * Çalıştır: ./H07_09_kararli_sayma
 * Eşleri  : c/H07_09_kararli_sayma.c · python/H07_09_kararli_sayma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

struct Kayit {
    int no;
    int not_;                          // anahtar: 0..k
};

static void dizi_yaz(const std::string& ad, const std::vector<int>& x)
{
    std::cout << "  " << ad << ":";
    for (int v : x) {
        std::cout << " " << v;
    }
    std::cout << "\n";
}

// Yol 1: önek[v] = anahtarı <= v olan kayıt sayısı; sağdan sola yerleştir
static std::vector<Kayit> kararli_sayma(const std::vector<Kayit>& a, int k,
                                        bool izle)
{
    int n = static_cast<int>(a.size());
    std::vector<Kayit> b(n);
    std::vector<int> onek(k + 1, 0);
    for (const Kayit& r : a) {
        onek[r.not_]++;                    // sıklık
    }
    if (izle) {
        dizi_yaz("sayaç    ", onek);
    }
    for (int v = 1; v <= k; v++) {
        onek[v] += onek[v - 1];            // önek toplam
    }
    if (izle) {
        dizi_yaz("önek top.", onek);
    }
    for (int i = n - 1; i >= 0; i--) {     // sağdan sola: kararlı
        int v = a[i].not_;
        onek[v]--;
        b[onek[v]] = a[i];
        if (izle) {
            std::cout << "  a[" << i << "] = (" << a[i].no << ", " << v
                      << ") -> b[" << onek[v] << "]\n";
        }
    }
    return b;
}

// Yol 2: başlangıç[v] = anahtarı < v olan kayıt sayısı; soldan sağa
static std::vector<Kayit> kararli_sayma_bas(const std::vector<Kayit>& a,
                                            int k)
{
    std::vector<Kayit> b(a.size());
    std::vector<int> bas(k + 2, 0);
    for (const Kayit& r : a) {
        bas[r.not_ + 1]++;
    }
    for (int v = 1; v <= k; v++) {
        bas[v] += bas[v - 1];
    }
    for (const Kayit& r : a) {             // soldan sağa, artırarak
        b[bas[r.not_]++] = r;
    }
    return b;
}

// Yol 3: Yol 1'in önek dizisi, ama soldan sağa: eşitler ters döner
static std::vector<Kayit> kararsiz_sayma(const std::vector<Kayit>& a, int k)
{
    std::vector<Kayit> b(a.size());
    std::vector<int> onek(k + 1, 0);
    for (const Kayit& r : a) {
        onek[r.not_]++;
    }
    for (int v = 1; v <= k; v++) {
        onek[v] += onek[v - 1];
    }
    for (const Kayit& r : a) {             // YANLIŞ yön
        b[--onek[r.not_]] = r;
    }
    return b;
}

static void kayit_yaz(const std::string& ad, const std::vector<Kayit>& a)
{
    std::cout << "  " << ad << ":";
    for (const Kayit& r : a) {
        std::cout << " (" << r.no << ", " << r.not_ << ")";
    }
    std::cout << "\n";
}

// Sıralı mı ve eşit anahtarlı kayıtlar girdi sırasını (no artan) korumuş
// mu? Numaralar girdide artan verildiği için no karşılaştırması yeter.
static void denetle(const std::string& ad, const std::vector<Kayit>& b)
{
    bool sirali = true, kararli = true;
    for (std::size_t i = 1; i < b.size(); i++) {
        if (b[i - 1].not_ > b[i].not_) {
            sirali = false;
        } else if (b[i - 1].not_ == b[i].not_ && b[i - 1].no > b[i].no) {
            kararli = false;
        }
    }
    std::cout << "  " << ad << ": sıralı mı? " << (sirali ? "evet" : "HAYIR")
              << ", kararlı mı? " << (kararli ? "evet" : "HAYIR") << "\n";
}

int main()
{
    std::vector<Kayit> a = {{1001, 3}, {1002, 1}, {1003, 3}, {1004, 0},
                            {1005, 2}, {1006, 1}, {1007, 3}, {1008, 2}};
    const int k = 5;

    std::cout << "1) Kayıtlar (no, not), anahtarlar 0.." << k << "\n";
    kayit_yaz("girdi", a);
    std::vector<Kayit> b = kararli_sayma(a, k, true);
    kayit_yaz("yol 1", b);
    denetle("yol 1 sağdan sola   ", b);
    b = kararli_sayma_bas(a, k);
    kayit_yaz("yol 2", b);
    denetle("yol 2 başlangıçlarla", b);
    b = kararsiz_sayma(a, k);
    kayit_yaz("yol 3", b);
    denetle("yol 3 yanlış yön    ", b);

    std::cout << "\n2) 100000 kayıt, notlar 0..100 (tohum 42)\n";
    const int m = 100000;
    std::vector<Kayit> x(m);
    rastgele_tohum(42);
    for (int i = 0; i < m; i++) {
        x[i].no = 2400001 + i;
        x[i].not_ = rastgele_aralik(0, 100);
    }
    denetle("yol 1 sağdan sola   ", kararli_sayma(x, 100, false));
    denetle("yol 2 başlangıçlarla", kararli_sayma_bas(x, 100));
    denetle("yol 3 yanlış yön    ", kararsiz_sayma(x, 100));
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort kararlı olmak zorunda değildir);
 * C++ — std::stable_sort (karşılaştırmalı, kararlı); Python — sorted /
 * list.sort (kararlı, karşılaştırmalı; yalnızca kâhin). */

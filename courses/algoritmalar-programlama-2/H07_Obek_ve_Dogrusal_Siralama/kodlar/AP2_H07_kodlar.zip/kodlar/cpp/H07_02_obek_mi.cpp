/* H07_02_obek_mi.cpp — AP-2 Hafta 7 · Örnek 2 (★)
 * Amaç    : Öbek özelliği denetimi (is_heap): her i > 0 için
 *           a[ebeveyn(i)] >= a[i]; ilk ihlalin yeri ve karşılaştırma sayısı;
 *           1..n'nin kaç permütasyonu öbektir?
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H07_02_obek_mi.cpp \
 *           -o H07_02_obek_mi
 * Çalıştır: ./H07_02_obek_mi
 * Eşleri  : c/H07_02_obek_mi.c · python/H07_02_obek_mi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

static long long karsilastirma_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

// İlk ihlal: a[ebeveyn(i)] < a[i] olan en küçük i; ihlal yoksa -1
static int ilk_ihlal(const std::vector<int>& a, int n)
{
    for (int i = 1; i < n; i++) {
        karsilastirma_sayisi++;
        if (a[ebeveyn(i)] < a[i]) {
            return i;
        }
    }
    return -1;
}

static bool obek_mi(const std::vector<int>& a, int n)
{
    return ilk_ihlal(a, n) == -1;
}

// Aynı özellik çocuklardan bakarak: iç düğümler 0 .. n/2 - 1 (kâhin)
static bool obek_mi_cocuklar(const std::vector<int>& a, int n)
{
    for (int i = 0; i < n / 2; i++) {
        int sol = 2 * i + 1, sag = 2 * i + 2;
        if (a[i] < a[sol] || (sag < n && a[i] < a[sag])) {
            return false;
        }
    }
    return true;
}

// Sözlük sırasında sonraki permütasyon; son permütasyondaysa false
static bool sonraki_permutasyon(std::vector<int>& p, int n)
{
    int i = n - 2;
    while (i >= 0 && p[i] >= p[i + 1]) {
        i--;
    }
    if (i < 0) {
        return false;
    }
    int j = n - 1;
    while (p[j] <= p[i]) {
        j--;
    }
    std::swap(p[i], p[j]);
    for (int s = i + 1, t = n - 1; s < t; s++, t--) {
        std::swap(p[s], p[t]);
    }
    return true;
}

static void denetle(const std::string& ad, const std::vector<int>& a, int n)
{
    karsilastirma_sayisi = 0;
    int i = ilk_ihlal(a, n);
    std::cout << ad << " (n = " << n << "): ";
    if (i == -1) {
        std::cout << "öbek: evet";
    } else {
        std::cout << "öbek: HAYIR (i = " << i << ": a[" << ebeveyn(i)
                  << "] = " << a[ebeveyn(i)] << " < a[" << i << "] = "
                  << a[i] << ")";
    }
    std::cout << ", karşılaştırma = " << karsilastirma_sayisi << "\n";
}

int main()
{
    const std::vector<int> obek = {95, 88, 92, 71, 84, 63, 90, 45, 52, 79};
    const std::vector<int> azalan = {95, 92, 90, 88, 84, 79, 71, 63, 52, 45};
    const std::vector<int> artan = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    const std::vector<int> derinde = {95, 88, 92, 71, 84, 63, 90, 45, 52,
                                      85};
    const std::vector<int> esit = {7, 7, 7, 7, 7};
    const std::vector<int> tek = {42};

    std::cout << "1) Öbek özelliği: her i > 0 için a[(i - 1) / 2] >= a[i]\n";
    denetle("Örnek 1'in öbeği", obek, 10);
    denetle("azalan sıralı", azalan, 10);
    denetle("artan sıralı", artan, 10);
    denetle("son yaprakta ihlal", derinde, 10);
    denetle("eşit elemanlar", esit, 5);
    denetle("tek eleman", tek, 1);
    denetle("boş dizi", tek, 0);

    std::cout << "\n2) 1..n'nin permütasyonlarından kaçı en büyük "
                 "öbektir?\n";
    std::cout << "  n        n!    öbek    oran (%)   ort. karş.  uyumsuz\n";
    std::cout << std::fixed;
    for (int n = 1; n <= 8; n++) {
        std::vector<int> p(n);
        long long toplam = 0, obek_sayisi = 0, uyumsuz = 0;
        for (int i = 0; i < n; i++) {
            p[i] = i + 1;
        }
        karsilastirma_sayisi = 0;
        do {
            toplam++;
            bool b1 = obek_mi(p, n);
            if (b1) {
                obek_sayisi++;
            }
            if (b1 != obek_mi_cocuklar(p, n)) {
                uyumsuz++;
            }
        } while (sonraki_permutasyon(p, n));
        std::cout << std::setw(3) << n << " " << std::setw(9) << toplam
                  << " " << std::setw(7) << obek_sayisi << " "
                  << std::setw(10) << std::setprecision(4)
                  << 100.0 * obek_sayisi / toplam << " " << std::setw(12)
                  << std::setprecision(3)
                  << static_cast<double>(karsilastirma_sayisi) / toplam
                  << " " << std::setw(8) << uyumsuz << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::is_heap,
 * std::is_heap_until (ilk ihlalin konumu); Python — yok (heapq'da
 * denetim fonksiyonu yoktur; en küçük öbek için elle yazılır). */

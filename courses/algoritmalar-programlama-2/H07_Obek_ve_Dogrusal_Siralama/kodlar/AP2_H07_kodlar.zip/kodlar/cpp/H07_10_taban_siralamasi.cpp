/* H07_10_taban_siralamasi.cpp — AP-2 Hafta 7 · Örnek 10 (★★★)
 * Amaç    : Taban sıralaması (LSD): en düşük basamaktan başlayarak her
 *           basamakta KARARLI sayma; 32 bitlik işaretsiz tamsayılar bayt
 *           bayt (256 tabanı, 4 geçiş); Θ(d(n + b)); taban seçimi
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_10_taban_siralamasi.cpp -o H07_10_taban_siralamasi
 * Çalıştır: ./H07_10_taban_siralamasi
 * Eşleri  : c/H07_10_taban_siralamasi.c ·
 *           python/H07_10_taban_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long adim_sayisi = 0;

// Ondalık gösterim (kart sıralayıcı benzetmesi): bolen = 1, 10, 100
static void ondalik_gecis(const std::vector<int>& a, std::vector<int>& b,
                          int bolen)
{
    int onek[10] = {0};
    int n = static_cast<int>(a.size());
    for (int i = 0; i < n; i++) {
        onek[a[i] / bolen % 10]++;
    }
    for (int v = 1; v < 10; v++) {
        onek[v] += onek[v - 1];
    }
    // sağdan sola: kararlı
    for (int i = n - 1; i >= 0; i--) {
        b[--onek[a[i] / bolen % 10]] = a[i];
    }
}

// Bir geçiş: (x >> kaydir) & maske basamağına göre kararlı sayma
static void gecis(const std::vector<std::uint32_t>& a,
                  std::vector<std::uint32_t>& b, int kaydir,
                  std::uint32_t maske, std::vector<int>& onek)
{
    int n = static_cast<int>(a.size());
    std::fill(onek.begin(), onek.end(), 0);
    for (int i = 0; i < n; i++) {
        onek[(a[i] >> kaydir) & maske]++;
        adim_sayisi++;
    }
    for (std::uint32_t v = 1; v <= maske; v++) {
        onek[v] += onek[v - 1];
        adim_sayisi++;
    }
    for (int i = n - 1; i >= 0; i--) {
        std::uint32_t v = (a[i] >> kaydir) & maske;
        b[--onek[v]] = a[i];
        adim_sayisi++;
    }
}

// bit: basamak genişliği (4, 8 ya da 16); 32 / bit geçiş (çift sayı:
// sonuç yeniden a'da). izle: her geçişten sonra yazdır
static void taban_siralamasi(std::vector<std::uint32_t>& a, int bit,
                             bool izle)
{
    std::uint32_t maske = (1u << bit) - 1;
    std::vector<std::uint32_t> b(a.size());
    std::vector<int> onek(maske + 1);
    for (int kaydir = 0; kaydir < 32; kaydir += bit) {
        gecis(a, b, kaydir, maske, onek);
        std::swap(a, b);               // rolleri değiştir (O(1))
        if (izle) {
            std::cout << "  bayt " << kaydir / 8 << "   :" << std::hex
                      << std::uppercase << std::setfill('0');
            for (std::uint32_t x : a) {
                std::cout << " " << std::setw(8) << x;
            }
            std::cout << std::dec << std::setfill(' ') << "\n";
        }
    }
}

static std::uint32_t rastgele_u32()
{
    std::uint32_t ust = rastgele_sayi() >> 15;   // 16 bit
    std::uint32_t alt = rastgele_sayi() >> 15;   // ayrı deyim: sıra belli
    return (ust << 16) | alt;
}

static void olcek_satiri(int n, int bit)
{
    std::vector<std::uint32_t> a(n);
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        a[i] = rastgele_u32();
    }
    std::vector<std::uint32_t> k = a;
    std::sort(k.begin(), k.end());                      // kâhin
    adim_sayisi = 0;
    taban_siralamasi(a, bit, false);
    bool dogru = (a == k);
    int d = 32 / bit, b = 1 << bit;
    std::cout << std::fixed << std::setw(8) << n << " " << std::setw(4) << bit
              << " " << std::setw(6) << b << " " << std::setw(3) << d << " "
              << std::setw(10) << adim_sayisi << " " << std::setw(10)
              << static_cast<long long>(d) * (2LL * n + b - 1) << " "
              << std::setprecision(3) << std::setw(8)
              << static_cast<double>(adim_sayisi) / n << " "
              << std::setprecision(0) << std::setw(11) << n * std::log2(n)
              << "  " << (dogru ? "evet" : "HAYIR") << "\n";
}

int main()
{
    std::vector<int> o = {532, 418, 207, 351, 842, 135, 600, 214};
    std::vector<int> t(8);
    const char* ad[] = {"birler", "onlar ", "yüzler"};
    std::cout << "1) Ondalık LSD: önce birler, sonra onlar, sonra yüzler\n";
    std::cout << "  girdi        :";
    for (int x : o) {
        std::cout << " " << x;
    }
    std::cout << "\n";
    for (int d = 0, bolen = 1; d < 3; d++, bolen *= 10) {
        ondalik_gecis(o, t, bolen);
        o = t;
        std::cout << "  " << d + 1 << ". geçiş " << ad[d] << ":";
        for (int x : o) {
            std::cout << " " << x;
        }
        std::cout << "\n";
    }

    std::cout << "\n2) 32 bit, 256 tabanı: bayt 0 (en düşük) -> bayt 3\n";
    std::vector<std::uint32_t> a = {0x2A00FF10u, 0x00C0FFEEu, 0x12345678u,
                                    0xDEADBEEFu, 0x0000002Au, 0xFFFFFFFFu,
                                    0x12340078u, 0x80000000u};
    std::cout << "  girdi    :" << std::hex << std::uppercase
              << std::setfill('0');
    for (std::uint32_t x : a) {
        std::cout << " " << std::setw(8) << x;
    }
    std::cout << std::dec << std::setfill(' ') << "\n";
    adim_sayisi = 0;
    taban_siralamasi(a, 8, true);
    std::cout << "  onluk    :";
    for (std::uint32_t x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n  adım = " << adim_sayisi
              << " = 4 (2n + b - 1), n = 8, b = 256\n";

    std::cout << "\n3) Rastgele 32 bitlik sayılar: adım = d (2n + b - 1)\n";
    std::cout << "       n  bit  taban   d       adım    formül   adım/n"
                 "     n log2 n  kâhin\n";
    for (int n = 1000; n <= 100000; n *= 10) {
        olcek_satiri(n, 8);
    }
    std::cout << "  taban seçimi (n = 100000): az geçiş <-> büyük sayaç "
                 "dizisi\n";
    olcek_satiri(100000, 4);
    olcek_satiri(100000, 8);
    olcek_satiri(100000, 16);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::sort karşılaştırmalıdır);
 * Python — yok (sorted karşılaştırmalıdır; yalnızca kâhin). */

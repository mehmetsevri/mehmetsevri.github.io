/* H07_13_akan_ortanca.cpp — AP-2 Hafta 7 · Örnek 13 (★★★, merak)
 * Amaç    : Akan veride ortanca: küçük yarı EN BÜYÜK öbekte, büyük yarı
 *           EN KÜÇÜK öbekte; boylar en çok 1 farklı; ekleme O(log n),
 *           ortanca O(1). Sıralı dizide araya eklemeyle (O(n)) karşılaştırma
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_13_akan_ortanca.cpp -o H07_13_akan_ortanca
 * Çalıştır: ./H07_13_akan_ortanca
 * Eşleri  : c/H07_13_akan_ortanca.c · python/H07_13_akan_ortanca.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

struct Obek {
    std::vector<int> a;
    bool en_buyuk;                     // true: en büyük öbek
};

static long long karsilastirma_sayisi = 0;

// x, öbekte y'nin üstünde mi durmalı?
static bool ustte_mi(const Obek& h, int x, int y)
{
    karsilastirma_sayisi++;
    return h.en_buyuk ? x > y : x < y;
}

static void ekle(Obek& h, int x)
{
    h.a.push_back(x);
    int i = static_cast<int>(h.a.size()) - 1;
    while (i > 0 && ustte_mi(h, h.a[i], h.a[(i - 1) / 2])) {
        std::swap(h.a[i], h.a[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

static int cikar(Obek& h)
{
    int tepe = h.a[0];
    h.a[0] = h.a.back();
    h.a.pop_back();
    int n = static_cast<int>(h.a.size());
    int i = 0;
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && ustte_mi(h, h.a[c + 1], h.a[c])) {
            c++;
        }
        if (!ustte_mi(h, h.a[c], h.a[i])) {
            break;
        }
        std::swap(h.a[i], h.a[c]);
        i = c;
    }
    return tepe;
}

// Değişmez: alt'taki her değer <= ust'teki her değer ve
// alt boyu == ust boyu ya da alt boyu == ust boyu + 1
static void ortancaya_ekle(Obek& alt, Obek& ust, int x)
{
    if (alt.a.empty() || !ustte_mi(alt, x, alt.a[0])) {
        ekle(alt, x);  // x <= alt'ın tepesi
    } else {
        ekle(ust, x);
    }
    if (alt.a.size() > ust.a.size() + 1) {  // dengele
        ekle(ust, cikar(alt));
    } else if (ust.a.size() > alt.a.size()) {
        ekle(alt, cikar(ust));
    }
}

static double ortanca(const Obek& alt, const Obek& ust)
{
    if (alt.a.size() > ust.a.size()) {
        return alt.a[0];
    }
    return (alt.a[0] + ust.a[0]) / 2.0;
}

static void obek_yaz(const std::string& ad, const Obek& h)
{
    std::cout << ad << "[";
    for (std::size_t i = 0; i < h.a.size(); i++) {
        std::cout << (i > 0 ? " " : "") << h.a[i];
    }
    std::cout << "]";
}

static double kahin_ortanca(const std::vector<int>& a, int n)
{
    std::vector<int> b(a.begin(), a.begin() + n);
    std::sort(b.begin(), b.end());
    return n % 2 ? b[n / 2] : (b[n / 2 - 1] + b[n / 2]) / 2.0;
}

// Karşılaştırma için: sıralı dizide araya ekleme; kaydırma sayısı
static long long sirali_dizi_kaydirma(const std::vector<int>& a, int n)
{
    std::vector<int> s(n);
    long long kaydirma = 0;
    for (int m = 0; m < n; m++) {
        int j = m - 1;
        while (j >= 0 && s[j] > a[m]) {
            s[j + 1] = s[j];
            kaydirma++;
            j--;
        }
        s[j + 1] = a[m];
    }
    return kaydirma;
}

int main()
{
    std::cout << "1) 15 değerlik akış (0..99, tohum 42)\n";
    Obek alt{{}, true}, ust{{}, false};
    rastgele_tohum(42);
    std::cout << std::fixed << std::setprecision(1);
    for (int k = 0; k < 15; k++) {
        int x = rastgele_aralik(0, 99);
        ortancaya_ekle(alt, ust, x);
        std::cout << "  " << std::setw(2) << k + 1 << ". gelen "
                  << std::setw(2) << x << "  ortanca = " << std::setw(5)
                  << ortanca(alt, ust) << "  ";
        obek_yaz("alt (en büyük) ", alt);
        obek_yaz("  üst (en küçük) ", ust);
        std::cout << "\n";
    }

    std::cout << "\n2) 100000 değerlik akış (0..1000000): denetim "
                 "noktaları\n";
    std::cout << "        n    ortanca  kâhin  alt boy  üst boy  karş./n  "
                 "log2 n\n";
    const int n = 100000;
    rastgele_tohum(42);
    std::vector<int> a = rastgele_dizi(n, 0, 1000000);
    alt = {{}, true};
    ust = {{}, false};
    karsilastirma_sayisi = 0;
    int nokta = 10;
    for (int m = 1; m <= n; m++) {
        ortancaya_ekle(alt, ust, a[m - 1]);
        if (m == nokta) {
            double o = ortanca(alt, ust);
            std::cout << std::setw(9) << m << " " << std::setprecision(1)
                      << std::setw(10) << o << "  " << std::setw(5)
                      << (o == kahin_ortanca(a, m) ? "evet" : "HAYIR") << " "
                      << std::setw(8) << alt.a.size() << " " << std::setw(8)
                      << ust.a.size() << " " << std::setprecision(3)
                      << std::setw(8)
                      << static_cast<double>(karsilastirma_sayisi) / m << " "
                      << std::setw(7) << std::log2(m) << "\n";
            nokta *= 10;
        }
    }

    std::cout << "\n3) İki öbek ve sıralı dizi: toplam iş\n";
    std::cout << "        n  iki öbek karş.  sıralı dizi kaydırma\n";
    for (int m = 500; m <= 2000; m *= 2) {
        alt = {{}, true};
        ust = {{}, false};
        karsilastirma_sayisi = 0;
        for (int i = 0; i < m; i++) {
            ortancaya_ekle(alt, ust, a[i]);
        }
        std::cout << std::setw(9) << m << " " << std::setw(15)
                  << karsilastirma_sayisi << " " << std::setw(21)
                  << sirali_dizi_kaydirma(a, m) << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — iki std::priority_queue
 * (biri std::greater ile); Python — iki heapq listesi (alt yarı için -x
 * hilesiyle en büyük öbek); statistics.median yalnızca kâhin. */

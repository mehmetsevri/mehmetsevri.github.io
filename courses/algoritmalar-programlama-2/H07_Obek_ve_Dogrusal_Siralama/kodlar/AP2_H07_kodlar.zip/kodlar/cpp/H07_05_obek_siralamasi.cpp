/* H07_05_obek_siralamasi.cpp — AP-2 Hafta 7 · Örnek 5 (★★)
 * Amaç    : Öbek sıralaması: öbek kur, kökü sona al, kalanı aşağı süz;
 *           yerinde ve en kötü durumda O(n log n); kararsızlık gösterimi
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_05_obek_siralamasi.cpp -o H07_05_obek_siralamasi
 * Çalıştır: ./H07_05_obek_siralamasi [n_ust=10000]
 * Eşleri  : c/H07_05_obek_siralamasi.c ·
 *           python/H07_05_obek_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma_sayisi = 0;
static long long takas_sayisi = 0;

static bool buyuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x > y;
}

static void takas(int& x, int& y)
{
    std::swap(x, y);
    takas_sayisi++;
}

static void asagi_suz(std::vector<int>& a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;  // sol çocuk
        if (c + 1 < n && buyuk_mu(a[c + 1], a[c])) {
            c++;  // sağ çocuk daha büyük
        }
        if (!buyuk_mu(a[c], a[i])) {
            break;
        }
        takas(a[i], a[c]);
        i = c;
    }
}

static void obek_kur(std::vector<int>& a, int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
}

// a[son+1..n-1] sıralı ve en büyükler; a[0..son] en büyük öbek
static void obek_siralamasi(std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    obek_kur(a, n);
    for (int son = n - 1; son > 0; son--) {
        takas(a[0], a[son]);  // en büyük yerine
        asagi_suz(a, son, 0);  // kalan öbeği onar
    }
}

// --- Kararlılık gösterimi: aynı algoritma, kayıtlar (anahtar: not) ---
struct Kayit {
    int not_;
    std::string ad;
};

static void kayit_suz(std::vector<Kayit>& a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c + 1].not_ > a[c].not_) {
            c++;
        }
        if (a[c].not_ <= a[i].not_) {
            break;
        }
        std::swap(a[i], a[c]);
        i = c;
    }
}

static void kayit_siralamasi(std::vector<Kayit>& a)
{
    int n = static_cast<int>(a.size());
    for (int i = n / 2 - 1; i >= 0; i--) {
        kayit_suz(a, n, i);
    }
    for (int son = n - 1; son > 0; son--) {
        std::swap(a[0], a[son]);
        kayit_suz(a, son, 0);
    }
}

static void kayitlari_yaz(const std::vector<Kayit>& a)
{
    for (const Kayit& k : a) {
        std::cout << " (" << k.not_ << " " << k.ad << ")";
    }
    std::cout << "\n";
}

static void dizi_yaz(const std::vector<int>& a, int ayrac)
{
    std::cout << "[";
    for (int i = 0; i < static_cast<int>(a.size()); i++) {
        std::cout << (i > 0 ? (i == ayrac ? " | " : " ") : "") << a[i];
    }
    std::cout << "]\n";
}

// tur: 0 rastgele, 1 sıralı, 2 ters sıralı, 3 çok tekrarlı (0..9)
static std::vector<int> doldur(int n, int tur)
{
    rastgele_tohum(42);
    std::vector<int> a(n);
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = static_cast<int>(rastgele_sayi());
        } else if (tur == 1) {
            a[i] = i;
        } else if (tur == 2) {
            a[i] = n - i;
        } else {
            a[i] = rastgele_aralik(0, 9);
        }
    }
    return a;
}

static void sayac_satiri(int n, int tur)
{
    static const char* const ad[] = {"rastgele", "sıralı", "ters sıralı",
                                     "çok tekrarlı"};
    std::vector<int> a = doldur(n, tur);
    std::vector<int> k = a;
    std::sort(k.begin(), k.end());                  // kâhin
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
    obek_siralamasi(a);
    bool dogru = (a == k);
    double nlogn = n * std::log2(n);
    std::cout << std::fixed << std::setprecision(3) << std::setw(7) << n
              << " " << std::setw(10) << karsilastirma_sayisi << " "
              << std::setw(10) << takas_sayisi << " " << std::setw(8)
              << karsilastirma_sayisi / nlogn << " " << std::setw(8)
              << takas_sayisi / nlogn << "  " << (dogru ? "evet" : "HAYIR")
              << "  " << ad[tur] << "\n";
}

int main(int argc, char* argv[])
{
    long n_ust = 10000;
    if (argc > 1) {
        std::string s = argv[1];
        std::size_t son = 0;
        try {
            n_ust = std::stol(s, &son);
        } catch (...) {
            son = 0;
        }
        if (son != s.size() || n_ust < 1000 || n_ust > 100000000) {
            std::cerr << "kullanım: " << argv[0]
                      << " [n_ust: 1000..100000000]\n";
            return 2;
        }
    }
    std::vector<int> a = {71, 84, 63, 95, 52, 90, 45, 88, 79, 92};
    const int n = 10;

    std::cout << "1) Öbek sıralaması adım adım (| sağı: sıralı bölge)\n";
    std::cout << "  girdi       : ";
    dizi_yaz(a, n);
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
    obek_kur(a, n);
    std::cout << "  öbek kuruldu: ";
    dizi_yaz(a, n);
    for (int son = n - 1; son > 0; son--) {
        takas(a[0], a[son]);
        asagi_suz(a, son, 0);
        std::cout << "  son = " << son << "     : ";
        dizi_yaz(a, son);
    }
    std::cout << "  karşılaştırma = " << karsilastirma_sayisi << ", takas = "
              << takas_sayisi << " (öbek kurma dahil)\n";

    std::cout << "\n2) Kararlı mı? Eşit notlu kayıtların sırası korunuyor "
                 "mu?\n";
    std::vector<Kayit> k = {{70, "Ada"}, {85, "Banu"}, {70, "Cem"},
                            {90, "Defne"}, {85, "Emre"}, {70, "Filiz"},
                            {85, "Gül"}};
    std::cout << "  girdi :";
    kayitlari_yaz(k);
    kayit_siralamasi(k);
    std::cout << "  çıktı :";
    kayitlari_yaz(k);
    std::cout << "  70'ler girdide Ada, Cem, Filiz sırasındaydı: öbek "
                 "sıralaması kararsızdır\n";

    std::cout << "\n3) Sayaçlar: girdi düzeninden neredeyse bağımsız "
                 "(uyarlanabilir değil)\n";
    std::cout << "      n karşılaştır.      takas  k/nlogn  t/nlogn  kâhin  "
                 "girdi\n";
    for (int tur = 0; tur < 4; tur++) {
        for (long m = 1000; m <= n_ust; m *= 10) {
            sayac_satiri(static_cast<int>(m), tur);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort algoritmayı belirtmez; yalnızca
 * kâhin); C++ — std::make_heap + std::sort_heap, std::partial_sort;
 * Python — heapq ile (heapify + n kez heappop; yerinde değil). */

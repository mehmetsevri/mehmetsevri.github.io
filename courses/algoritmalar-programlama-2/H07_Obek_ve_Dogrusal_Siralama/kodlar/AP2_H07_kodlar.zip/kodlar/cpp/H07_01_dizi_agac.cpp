/* H07_01_dizi_agac.cpp — AP-2 Hafta 7 · Örnek 1 (★)
 * Amaç    : Tam ikili ağacın dizi gösterimi: ebeveyn (i-1)/2, çocuklar 2i+1
 *           ve 2i+2; öbeğin düzeyler ve ağaç biçiminde yazdırılması
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H07_01_dizi_agac.cpp \
 *           -o H07_01_dizi_agac
 * Çalıştır: ./H07_01_dizi_agac
 * Eşleri  : c/H07_01_dizi_agac.c · python/H07_01_dizi_agac.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

const int HUCRE = 4;               // son düzeyde düğüm başına sütun

// 0 tabanlı indis formülleri
static int ebeveyn(int i) { return (i - 1) / 2; }
static int sol_cocuk(int i) { return 2 * i + 1; }
static int sag_cocuk(int i) { return 2 * i + 2; }

// i. düğümün düzeyi (kök 0): i + 1'in ikilik basamak sayısı - 1
static int duzey(int i)
{
    int d = 0;
    while (i > 0) {
        i = ebeveyn(i);
        d++;
    }
    return d;
}

static void tablo_yaz(const std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    std::cout << "  i  a[i]  ebeveyn  sol  sağ  düzey\n";
    for (int i = 0; i < n; i++) {
        std::cout << std::setw(3) << i << "  " << std::setw(4) << a[i];
        if (i == 0) {
            std::cout << "  " << std::setw(7) << "-";
        } else {
            std::cout << "  " << std::setw(7) << ebeveyn(i);
        }
        if (sol_cocuk(i) < n) {
            std::cout << "  " << std::setw(3) << sol_cocuk(i);
        } else {
            std::cout << "  " << std::setw(3) << "-";
        }
        if (sag_cocuk(i) < n) {
            std::cout << "  " << std::setw(3) << sag_cocuk(i);
        } else {
            std::cout << "  " << std::setw(3) << "-";
        }
        std::cout << "  " << std::setw(5) << duzey(i) << "\n";
    }
}

static void duzeyleri_yaz(const std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    int bas = 0, d = 0;
    while (bas < n) {
        int son = 2 * bas + 1;     // sonraki düzeyin başı
        if (son > n) {
            son = n;
        }
        std::cout << "  düzey " << d << " (a[" << bas << ".." << son - 1
                  << "]):";
        for (int i = bas; i < son; i++) {
            std::cout << " " << a[i];
        }
        std::cout << "\n";
        bas = 2 * bas + 1;
        d++;
    }
}

// Satır sonundaki boşlukları silip yazdırır
static void satir_bas(std::string s)
{
    while (!s.empty() && s.back() == ' ') {
        s.pop_back();
    }
    std::cout << s << "\n";
}

// Ortalanmış ağaç: d. düzeyde 2^d yuva, yuva genişliği G / 2^d
static void agac_yaz(const std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    int yukseklik = duzey(n - 1);
    int g = HUCRE << yukseklik;    // toplam genişlik
    for (int d = 0; d <= yukseklik; d++) {
        int bas = (1 << d) - 1;
        int yuva = g >> d;
        std::string satir(g, ' ');
        for (int j = 0; j < (1 << d) && bas + j < n; j++) {
            std::string sayi = std::to_string(a[bas + j]);
            int u = static_cast<int>(sayi.size());
            int hedef = yuva * j + (yuva - u) / 2;
            satir.replace(hedef, u, sayi);
        }
        satir_bas(satir);
        if (d == yukseklik) {
            break;
        }
        satir.assign(g, ' ');      // bağlantı çizgileri
        for (int j = 0; j < (1 << d) && bas + j < n; j++) {
            if (sol_cocuk(bas + j) < n) {
                satir[yuva * j + 3 * yuva / 8] = '/';
            }
            if (sag_cocuk(bas + j) < n) {
                satir[yuva * j + 5 * yuva / 8] = '\\';
            }
        }
        satir_bas(satir);
    }
}

// Yan yatırılmış ağaç: önce sağ alt ağaç (üstte), sonra düğüm, sonra sol
static void yan_agac(const std::vector<int>& a, int i, int derinlik)
{
    int n = static_cast<int>(a.size());
    if (i >= n) {
        return;
    }
    yan_agac(a, sag_cocuk(i), derinlik + 1);
    std::cout << std::string(6 * derinlik, ' ') << a[i] << "\n";
    yan_agac(a, sol_cocuk(i), derinlik + 1);
}

// Formüllerin tutarlılığı: her i > 0 için i, ebeveyninin bir çocuğu mu?
// Bit kaydırmalı biçimler aynı sonucu veriyor mu?
static long long formul_denetimi(int n)
{
    long long hata = 0;
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            int e = ebeveyn(i);
            if (sol_cocuk(e) != i && sag_cocuk(e) != i) {
                hata++;
            }
            if (((i - 1) >> 1) != e) {
                hata++;
            }
        }
        if (((i << 1) | 1) != sol_cocuk(i)) {
            hata++;
        }
        if (((i + 1) << 1) != sag_cocuk(i)) {
            hata++;
        }
    }
    return hata;
}

int main()
{
    const std::vector<int> a = {95, 88, 92, 71, 84, 63, 90, 45, 52, 79};
    const int n = static_cast<int>(a.size());

    std::cout << "Öbek dizisi (n = " << n << "):";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n\n1) İndis ilişkileri (0 tabanlı)\n";
    tablo_yaz(a);

    std::cout << "\n2) Düzeyler: d. düzey a[2^d - 1 .. 2^(d+1) - 2]\n";
    duzeyleri_yaz(a);

    std::cout << "\n3) Ağaç biçimi (dizi sırası = düzey düzey, soldan "
                 "sağa)\n";
    agac_yaz(a);

    std::cout << "\n4) Yan yatırılmış ağaç (sağ çocuk üstte)\n";
    yan_agac(a, 0, 0);

    std::cout << "\n5) Bit kaydırmayla: sol = (i << 1) | 1, sağ = (i + 1) "
                 "<< 1, ebeveyn = (i - 1) >> 1\n";
    std::cout << "   i = 3: sol = " << ((3 << 1) | 1) << ", sağ = "
              << ((3 + 1) << 1) << ", ebeveyn = " << ((3 - 1) >> 1) << "\n";
    std::cout << "   i = 0 .. 999999 için tutarsızlık sayısı: "
              << formul_denetimi(1000000) << "\n";
    std::cout << "   düzey sayısı (yükseklik + 1): n = 10 -> "
              << duzey(9) + 1 << ", n = 1000000 -> " << duzey(999999) + 1
              << "\n";
    return 0;
}

/* Kütüphane karşılığı: C — yok (dizi + indis aritmetiği elle);
 * C++ — std::make_heap aynı 0 tabanlı yerleşimi kullanır; Python — heapq
 * aynı yerleşimi kullanır (heap[k] <= heap[2k+1], heap[2k+2]). */

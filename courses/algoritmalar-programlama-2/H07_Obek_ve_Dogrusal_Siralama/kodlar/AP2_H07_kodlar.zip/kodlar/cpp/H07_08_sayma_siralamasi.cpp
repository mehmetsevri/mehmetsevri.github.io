/* H07_08_sayma_siralamasi.cpp — AP-2 Hafta 7 · Örnek 8 (★)
 * Amaç    : Sayma sıralaması (0–100 notlar): değeri indis olarak kullan,
 *           say, sayaçları sırayla geri yaz; Θ(n + k), anahtar
 *           karşılaştırması yok; not dağılımı (histogram)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_08_sayma_siralamasi.cpp -o H07_08_sayma_siralamasi
 * Çalıştır: ./H07_08_sayma_siralamasi
 * Eşleri  : c/H07_08_sayma_siralamasi.c ·
 *           python/H07_08_sayma_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "ortak_rastgele.hpp"

static long long adim_sayisi = 0;

// a içindeki anahtarlar 0..k aralığında olmalı (bkz. Hata Avcısı)
static void sayma_siralamasi(std::vector<int>& a, int k)
{
    std::vector<int> sayac(k + 1, 0);  // sıfırlı
    for (int x : a) {
        sayac[x]++;  // değer = indis
        adim_sayisi++;
    }
    std::size_t j = 0;
    // sayaçları sırayla geri yaz
    for (int v = 0; v <= k; v++) {
        adim_sayisi++;
        for (int c = 0; c < sayac[v]; c++) {
            a[j++] = v;
            adim_sayisi++;
        }
    }
}

static std::vector<int> rastgele_notlar(int n, int k)
{
    rastgele_tohum(42);
    return rastgele_dizi(n, 0, k);
}

static void maliyet_satiri(int n, int k)
{
    std::vector<int> a = rastgele_notlar(n, k);
    std::vector<int> b = a;
    std::sort(b.begin(), b.end());                       // kâhin
    adim_sayisi = 0;
    sayma_siralamasi(a, k);
    bool dogru = (a == b);
    std::cout << std::fixed << std::setprecision(3) << std::setw(9) << n
              << " " << std::setw(9) << k << " " << std::setw(12)
              << adim_sayisi << " " << std::setw(12) << 2LL * n + k + 1
              << " " << std::setw(9) << static_cast<double>(adim_sayisi) / n
              << " " << std::setw(10) << 4LL * (k + 1) << "  "
              << (dogru ? "evet" : "HAYIR") << "\n";
}

int main()
{
    std::vector<int> a = {85, 70, 100, 45, 70, 90, 85, 0, 55, 70, 100, 85,
                          62, 45, 90};
    const int n = static_cast<int>(a.size());

    std::cout << "1) " << n << " not, anahtarlar 0..100\n  girdi :";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::vector<int> sayac(101, 0);
    for (int x : a) {
        sayac[x]++;
    }
    std::cout << "\n  sıfır olmayan sayaçlar:";
    for (int v = 0; v <= 100; v++) {
        if (sayac[v] > 0) {
            std::cout << " [" << v << "]=" << sayac[v];
        }
    }
    adim_sayisi = 0;
    sayma_siralamasi(a, 100);
    std::cout << "\n  çıktı :";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n  adım = " << adim_sayisi << " = 2n + k + 1 = "
              << 2 * n + 100 + 1 << "; anahtar karşılaştırması: 0\n";

    std::cout << "\n2) Not dağılımı: 1000 öğrenci (tohum 42), 10'luk "
                 "aralıklar\n";
    std::vector<int> b = rastgele_notlar(1000, 100);
    sayma_siralamasi(b, 100);
    int i = 0;
    for (int alt = 0; alt <= 90; alt += 10) {
        int ust = alt == 90 ? 100 : alt + 9;
        int adet = 0;
        while (i < 1000 && b[i] <= ust) {   // sıralı: aralık ardışık
            adet++;
            i++;
        }
        std::cout << "  " << std::setw(3) << alt << "-" << std::setw(3)
                  << ust << " " << std::setw(4) << adet << " "
                  << std::string(adet / 5, '#') << "\n";
    }
    std::cout << "  ortanca (500. ve 501. not): " << b[499] << ", " << b[500]
              << "\n";

    std::cout << "\n3) Maliyet: adım = 2n + k + 1 (sayma n, tarama k + 1, "
                 "yazma n);\n   4(k+1) B: C'deki int sayaç dizisinin baytı\n";
    std::cout << "        n         k         adım   2n + k + 1    adım/n"
                 "   4(k+1) B  kâhin\n";
    for (int m = 1000; m <= 1000000; m *= 10) {
        maliyet_satiri(m, 100);
    }
    std::cout << "  k büyürse (n = 1000): adım ve bellek k ile büyür\n";
    for (int k = 100; k <= 1000000; k *= 100) {
        maliyet_satiri(1000, k);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort karşılaştırmalıdır; yalnızca
 * kâhin); C++ — yok (std::sort karşılaştırmalıdır); Python — yok
 * (sorted karşılaştırmalıdır; collections.Counter yalnızca sayar). */

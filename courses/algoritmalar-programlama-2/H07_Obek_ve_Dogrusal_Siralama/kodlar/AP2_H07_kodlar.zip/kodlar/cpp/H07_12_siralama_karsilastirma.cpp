/* H07_12_siralama_karsilastirma.cpp — AP-2 Hafta 7 · Örnek 12 (★★★)
 * Amaç    : Sıralama karşılaştırma deneyi: sekiz algoritma × dört girdi
 *           türü × n. Varsayılan: deterministik sayaçlar + kâhin denetimi
 *           + oran testi; "olc N [tekrar]": süre tablosu (stderr)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_12_siralama_karsilastirma.cpp \
 *           -o H07_12_siralama_karsilastirma
 * Çalıştır: ./H07_12_siralama_karsilastirma  |  ... olc 100000 5
 * Eşleri  : c/H07_12_siralama_karsilastirma.c ·
 *           python/H07_12_siralama_karsilastirma.py
 * Çıktı   : üç dilde aynı (=) — süreler stderr'e
 */
#include <algorithm>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

const int ALG_SAYISI = 8;
const int TUR_SAYISI = 4;
const int ANAHTAR = 1000000;       // rastgele/sıralı/ters: 0..999999

static long long karsilastirma_sayisi = 0;
static long long yazma_sayisi = 0;         // diziye eleman yazma
static long long sayac_islemi = 0;         // sayaç dizisi adımları

using Dizi = std::vector<int>;

static bool kucuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x < y;
}

static void takas(int& x, int& y)
{
    std::swap(x, y);
    yazma_sayisi += 2;
}

// 1. Seçmeli: a[i..n-1]'in en küçüğünü i'ye getir
static void secmeli_siralama(Dizi& a)
{
    int n = static_cast<int>(a.size());
    for (int i = 0; i + 1 < n; i++) {
        int m = i;
        for (int j = i + 1; j < n; j++) {
            if (kucuk_mu(a[j], a[m])) {
                m = j;
            }
        }
        if (m != i) {
            takas(a[i], a[m]);
        }
    }
}

// 2. Araya ekleme: a[i]'yi sıralı a[0..i-1] içine kaydırarak yerleştir
static void araya_ekleme_siralamasi(Dizi& a)
{
    int n = static_cast<int>(a.size());
    for (int i = 1; i < n; i++) {
        int x = a[i];
        int j = i - 1;
        while (j >= 0 && kucuk_mu(x, a[j])) {
            a[j + 1] = a[j];
            yazma_sayisi++;
            j--;
        }
        a[j + 1] = x;
        yazma_sayisi++;
    }
}

// 3. Birleştirmeli: a[lo..orta) ve a[orta..hi) -> g -> a (kararlı)
static void birlestir(Dizi& a, Dizi& g, int lo, int orta, int hi)
{
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        g[k++] = kucuk_mu(a[j], a[i]) ? a[j++] : a[i++];
    }
    while (i < orta) {
        g[k++] = a[i++];
    }
    while (j < hi) {
        g[k++] = a[j++];
    }
    for (k = lo; k < hi; k++) {
        a[k] = g[k];
    }
    yazma_sayisi += 2LL * (hi - lo);
}

static void birlestirmeli_ozyineli(Dizi& a, Dizi& g, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli_ozyineli(a, g, lo, orta);
    birlestirmeli_ozyineli(a, g, orta, hi);
    birlestir(a, g, lo, orta, hi);
}

static void birlestirmeli_siralama(Dizi& a)
{
    Dizi g(a.size());
    birlestirmeli_ozyineli(a, g, 0, static_cast<int>(a.size()));
}

// 4. Hızlı: üçün ortancası pivot, Hoare bölümlemesi (a[lo..hi] kapalı)
static int bolumle(Dizi& a, int lo, int hi)
{
    int orta = lo + (hi - lo) / 2;
    if (kucuk_mu(a[orta], a[lo])) {
        takas(a[orta], a[lo]);
    }
    if (kucuk_mu(a[hi], a[lo])) {
        takas(a[hi], a[lo]);
    }
    if (kucuk_mu(a[hi], a[orta])) {
        takas(a[hi], a[orta]);
    }
    int pivot = a[orta];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {
            i++;
        } while (kucuk_mu(a[i], pivot));
        do {
            j--;
        } while (kucuk_mu(pivot, a[j]));
        if (i >= j) {
            return j;              // a[lo..j] <= pivot <= a[j+1..hi]
        }
        takas(a[i], a[j]);
    }
}

// Küçük parçada özyineleme, büyük parçada döngü: yığın derinliği O(log n)
static void hizli_ozyineli(Dizi& a, int lo, int hi)
{
    while (lo < hi) {
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            hizli_ozyineli(a, lo, p);
            lo = p + 1;
        } else {
            hizli_ozyineli(a, p + 1, hi);
            hi = p;
        }
    }
}

static void hizli_siralama(Dizi& a)
{
    hizli_ozyineli(a, 0, static_cast<int>(a.size()) - 1);
}

// 5. Öbek (Örnek 5)
static void asagi_suz(Dizi& a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && kucuk_mu(a[c], a[c + 1])) {
            c++;
        }
        if (!kucuk_mu(a[i], a[c])) {
            break;
        }
        takas(a[i], a[c]);
        i = c;
    }
}

static void obek_siralamasi(Dizi& a)
{
    int n = static_cast<int>(a.size());
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
    for (int son = n - 1; son > 0; son--) {
        takas(a[0], a[son]);
        asagi_suz(a, son, 0);
    }
}

// 6. Sayma (Örnek 8): anahtarlar 0..k
static void sayma_siralamasi(Dizi& a, int k)
{
    int n = static_cast<int>(a.size());
    std::vector<int> sayac(k + 1, 0);
    for (int x : a) {
        sayac[x]++;
    }
    int j = 0;
    for (int v = 0; v <= k; v++) {
        for (int c = 0; c < sayac[v]; c++) {
            a[j++] = v;
        }
    }
    sayac_islemi += n + k + 1;
    yazma_sayisi += n;
}

// 7. Taban (Örnek 10): 256 tabanı, 4 kararlı geçiş (anahtarlar >= 0)
static void taban_siralamasi(Dizi& a)
{
    int n = static_cast<int>(a.size());
    Dizi b(n);
    for (int kaydir = 0; kaydir < 32; kaydir += 8) {
        int onek[256] = {0};
        for (int i = 0; i < n; i++) {
            onek[(static_cast<std::uint32_t>(a[i]) >> kaydir) & 0xFF]++;
        }
        for (int v = 1; v < 256; v++) {
            onek[v] += onek[v - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            auto v = (static_cast<std::uint32_t>(a[i]) >> kaydir) & 0xFF;
            b[--onek[v]] = a[i];
        }
        std::swap(a, b);           // O(1): vektörlerin içeriği yer değişir
        sayac_islemi += n + 255;
        yazma_sayisi += n;
    }
}

// 8. Kütüphane: std::sort (introsort; sayaç yok)
static void kutuphane_siralamasi(Dizi& a)
{
    std::sort(a.begin(), a.end());
}

static const char* const ALG_AD[ALG_SAYISI] = {
    "seçmeli       ", "araya ekleme  ", "birleştirmeli ", "hızlı         ",
    "öbek          ", "sayma         ", "taban (LSD)   ", "kütüphane     "};

static int en_buyuk_anahtar(int tur)
{
    return tur == 3 ? 9 : ANAHTAR - 1;
}

// tur: 0 rastgele 0..999999, 1 sıralı, 2 ters sıralı, 3 çok tekrarlı
// 0..9 (sıralı ve ters: eşit aralıklı, aynı anahtar aralığı)
static Dizi girdi_uret(int n, int tur)
{
    rastgele_tohum(42);
    Dizi a(n);
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = rastgele_aralik(0, ANAHTAR - 1);
        } else if (tur == 1) {
            a[i] = static_cast<int>(static_cast<long long>(i) * ANAHTAR / n);
        } else if (tur == 2) {
            a[i] = static_cast<int>(static_cast<long long>(n - 1 - i) *
                                    ANAHTAR / n);
        } else {
            a[i] = rastgele_aralik(0, 9);
        }
    }
    return a;
}

static void calistir(int alg, Dizi& a, int tur)
{
    switch (alg) {
    case 0: secmeli_siralama(a); break;
    case 1: araya_ekleme_siralamasi(a); break;
    case 2: birlestirmeli_siralama(a); break;
    case 3: hizli_siralama(a); break;
    case 4: obek_siralamasi(a); break;
    case 5: sayma_siralamasi(a, en_buyuk_anahtar(tur)); break;
    case 6: taban_siralamasi(a); break;
    default: kutuphane_siralamasi(a); break;
    }
}

struct Sonuc {
    long long kar, yaz, say;
    bool dogru;
};

using Tablo = std::vector<std::vector<Sonuc>>;

static Sonuc olcum_yap(int alg, int n, int tur)
{
    Dizi a = girdi_uret(n, tur);
    Dizi k = a;
    kutuphane_siralamasi(k);                           // kâhin
    karsilastirma_sayisi = yazma_sayisi = sayac_islemi = 0;
    calistir(alg, a, tur);
    return {karsilastirma_sayisi, yazma_sayisi, sayac_islemi, a == k};
}

static Tablo sayac_tablolari(int n)
{
    Tablo s(ALG_SAYISI, std::vector<Sonuc>(TUR_SAYISI));
    for (int alg = 0; alg < ALG_SAYISI; alg++) {
        for (int t = 0; t < TUR_SAYISI; t++) {
            s[alg][t] = olcum_yap(alg, n, t);
        }
    }
    const char* baslik = "  algoritma          rastgele      sıralı"
                         "  ters sıralı  çok tekrarlı\n";
    for (int tablo = 0; tablo < 3; tablo++) {
        static const char* const ad[] = {
            "karşılaştırma", "yazma (eleman)", "sayaç işlemi"};
        std::cout << "  " << ad[tablo] << ", n = " << n << "\n" << baslik;
        for (int alg = 0; alg < ALG_SAYISI; alg++) {
            std::cout << "  " << ALG_AD[alg];
            for (int t = 0; t < TUR_SAYISI; t++) {
                long long v = tablo == 0 ? s[alg][t].kar
                              : tablo == 1 ? s[alg][t].yaz : s[alg][t].say;
                if (alg == 7) {
                    std::cout << " " << std::setw(12) << "-";
                } else {
                    std::cout << " " << std::setw(12) << v;
                }
            }
            std::cout << "\n";
        }
    }
    int dogru = 0;
    for (const auto& satir : s) {
        for (const Sonuc& r : satir) {
            dogru += r.dogru;
        }
    }
    std::cout << "  kâhinle aynı mı (4 girdi türü): " << dogru << " / "
              << ALG_SAYISI * TUR_SAYISI << " evet\n";
    return s;
}

static void sure_tablosu(int n, int tekrar)
{
    std::cerr << "Süre (ms, ortanca; 1 ısınma + " << tekrar << " tekrar), "
              << "n = " << n << "; -: karesel, n > 50000 atlandı\n";
    std::cerr << "  algoritma          rastgele      sıralı"
                 "  ters sıralı  çok tekrarlı\n";
    std::cerr << std::fixed << std::setprecision(3);
    for (int alg = 0; alg < ALG_SAYISI; alg++) {
        std::cerr << "  " << ALG_AD[alg];
        for (int tur = 0; tur < TUR_SAYISI; tur++) {
            if (alg < 2 && n > 50000) {
                std::cerr << " " << std::setw(12) << "-";
                continue;
            }
            Dizi g = girdi_uret(n, tur), a;
            std::vector<double> t;
            for (int r = -1; r < tekrar; r++) {    // r = -1: ısınma
                a = g;
                double t0 = zaman_sn();
                calistir(alg, a, tur);
                if (r >= 0) {
                    t.push_back((zaman_sn() - t0) * 1000.0);
                }
            }
            std::cerr << " " << std::setw(12) << ortanca(t);
        }
        std::cerr << "\n";
    }
}

static bool sayi_oku(const char* s, long& deger)
{
    std::string m = s;
    std::size_t son = 0;
    try {
        deger = std::stol(m, &son);
    } catch (...) {
        return false;
    }
    return son == m.size();
}

int main(int argc, char* argv[])
{
    if (argc > 1) {                        // ölçüm kipi
        long n = 100000, tekrar = 5;
        bool ok = std::string(argv[1]) == "olc";
        ok = ok && (argc <= 2 || sayi_oku(argv[2], n));
        ok = ok && (argc <= 3 || sayi_oku(argv[3], tekrar));
        if (!ok || n < 10 || n > 10000000 || tekrar < 1 || tekrar > 101) {
            std::cerr << "kullanım: " << argv[0]
                      << " [olc [n=100000] [tekrar=5]]\n";
            return 2;
        }
        std::cout << "Ölçüm kipi: sayaçlar stdout'a, süreler stderr'e\n";
        if (n <= 50000) {
            sayac_tablolari(static_cast<int>(n));
        }
        sure_tablosu(static_cast<int>(n), static_cast<int>(tekrar));
        return 0;
    }
    std::cout << "Sıralama karşılaştırma deneyi (sayaçlar; süre için: olc "
                 "N)\n";
    std::cout << "Girdi türleri: rastgele 0..999999 (tohum 42), sıralı ve "
                 "ters sıralı (eşit aralıklı), çok tekrarlı 0..9\n\n";
    std::cout << "1) n = 1000\n";
    Tablo s1 = sayac_tablolari(1000);
    std::cout << "\n2) n = 2000\n";
    Tablo s2 = sayac_tablolari(2000);

    std::cout << "\n3) Oran testi: iş(2000) / iş(1000), iş = karş. + yazma "
                 "+ sayaç işlemi\n";
    std::cout << "   beklenen: karesel ~4, n log n ~2,2, doğrusal ~2; sayma "
                 "(k = 10^6) ~1\n";
    std::cout << "  algoritma          rastgele      sıralı  ters sıralı  "
                 "çok tekrarlı\n";
    std::cout << std::fixed << std::setprecision(3);
    for (int alg = 0; alg < ALG_SAYISI - 1; alg++) {
        std::cout << "  " << ALG_AD[alg];
        for (int t = 0; t < TUR_SAYISI; t++) {
            long long i1 = s1[alg][t].kar + s1[alg][t].yaz + s1[alg][t].say;
            long long i2 = s2[alg][t].kar + s2[alg][t].yaz + s2[alg][t].say;
            std::cout << " " << std::setw(12)
                      << static_cast<double>(i2) / static_cast<double>(i1);
        }
        std::cout << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritma ve kararlılık belirtilmez);
 * C++ — std::sort (introsort; en kötü O(n log n)), std::stable_sort;
 * Python — list.sort / sorted (Timsort; kararlı). */

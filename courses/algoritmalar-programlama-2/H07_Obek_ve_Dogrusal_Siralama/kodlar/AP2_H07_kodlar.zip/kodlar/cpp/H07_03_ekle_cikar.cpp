/* H07_03_ekle_cikar.cpp — AP-2 Hafta 7 · Örnek 3 (★★)
 * Amaç    : En büyük öbeğe ekleme (yukarı süzme) ve en büyüğü çıkarma
 *           (aşağı süzme); adım adım izleme ve rastgele anahtarlarda
 *           işlem başına ortalama takas sayısı
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_03_ekle_cikar.cpp -o H07_03_ekle_cikar
 * Çalıştır: ./H07_03_ekle_cikar
 * Eşleri  : c/H07_03_ekle_cikar.c · python/H07_03_ekle_cikar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma_sayisi = 0;
static long long takas_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

static bool buyuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x > y;
}

static void takas(int& x, int& y)
{
    std::swap(x, y);
    takas_sayisi++;
}

// a[i] ebeveyninden büyük oldukça yukarı taşınır; son konumu döndürür
static int yukari_suz(std::vector<int>& a, int i)
{
    while (i > 0 && buyuk_mu(a[i], a[ebeveyn(i)])) {
        takas(a[i], a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
    return i;
}

// a[i], büyük çocuğundan küçük oldukça aşağı taşınır (a[0..n-1])
static int asagi_suz(std::vector<int>& a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;  // sol çocuk
        if (c + 1 < n && buyuk_mu(a[c + 1], a[c])) {
            c++;  // sağ çocuk daha büyük
        }
        if (!buyuk_mu(a[c], a[i])) {
            break;  // öbek özelliği sağlandı
        }
        takas(a[i], a[c]);
        i = c;
    }
    return i;
}

// Yeni eleman ilk boş yaprağa konur, sonra yukarı süzülür
static int obege_ekle(std::vector<int>& a, int x)
{
    a.push_back(x);
    return yukari_suz(a, static_cast<int>(a.size()) - 1);
}

// Kök çıkarılır; son eleman köke taşınıp aşağı süzülür (a boş olmamalı)
static int en_buyugu_cikar(std::vector<int>& a)
{
    int en_buyuk = a[0];
    a[0] = a.back();
    a.pop_back();
    asagi_suz(a, static_cast<int>(a.size()), 0);
    return en_buyuk;
}

static void dizi_yaz(const std::vector<int>& a)
{
    std::cout << "[";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? " " : "") << a[i];
    }
    std::cout << "]\n";
}

static void sayaclari_sifirla()
{
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
}

// n rastgele anahtar: ekleme, artan girdiyle ekleme ve tümünü çıkarma
static void ortalama_satiri(int n)
{
    std::vector<int> a;
    a.reserve(n);
    rastgele_tohum(42);
    sayaclari_sifirla();
    for (int k = 0; k < n; k++) {
        obege_ekle(a, static_cast<int>(rastgele_sayi()));
    }
    double ekleme = static_cast<double>(takas_sayisi) / n;
    sayaclari_sifirla();
    while (!a.empty()) {
        en_buyugu_cikar(a);
    }
    double cikar_t = static_cast<double>(takas_sayisi) / n;
    double cikar_k = static_cast<double>(karsilastirma_sayisi) / n;
    sayaclari_sifirla();
    for (int k = 0; k < n; k++) {
        obege_ekle(a, k);              // artan: her eleman köke çıkar
    }
    double artan = static_cast<double>(takas_sayisi) / n;
    std::cout << std::fixed << std::setprecision(3) << std::setw(7) << n
              << " " << std::setw(10) << ekleme << " " << std::setw(10)
              << artan << " " << std::setw(8) << std::log2(n) << " "
              << std::setw(11) << cikar_t << " " << std::setw(11) << cikar_k
              << "\n";
}

int main()
{
    const std::vector<int> sira = {45, 79, 63, 90, 84, 92, 95, 52, 71, 88};
    const std::vector<int> ornek1 = {95, 88, 92, 71, 84, 63, 90, 45, 52, 79};
    std::vector<int> a;

    std::cout << "1) Boş öbeğe sırayla ekleme (yukarı süzme)\n";
    for (int x : sira) {
        sayaclari_sifirla();
        int son = obege_ekle(a, x);
        std::cout << "  ekle " << x << ": konum " << a.size() - 1 << " -> "
                  << son << ", takas = " << takas_sayisi << "  ";
        dizi_yaz(a);
    }
    bool ayni = (a == ornek1);
    std::cout << "  Örnek 1'in öbeğiyle aynı mı? " << (ayni ? "evet" : "HAYIR")
              << "\n";

    std::cout << "\n2) En kötü durum: yeni eleman köke kadar çıkar\n";
    sayaclari_sifirla();
    int son = obege_ekle(a, 97);
    std::cout << "  ekle 97: konum " << a.size() - 1 << " -> " << son
              << ", takas = " << takas_sayisi << " (düzey sayısı - 1)  ";
    dizi_yaz(a);

    std::cout << "\n3) En büyüğü çıkarma (son eleman köke, aşağı süzme)\n";
    for (int k = 0; k < 3; k++) {
        int kok_adayi = a.back();
        sayaclari_sifirla();
        int en_buyuk = en_buyugu_cikar(a);
        std::cout << "  çıkar -> " << en_buyuk << " (köke " << kok_adayi
                  << " taşındı), karşılaştırma = " << karsilastirma_sayisi
                  << ", takas = " << takas_sayisi << "\n    ";
        dizi_yaz(a);
    }
    std::cout << "  kalanlar sırayla çıkarılınca:";
    while (!a.empty()) {
        std::cout << " " << en_buyugu_cikar(a);
    }
    std::cout << "\n";

    std::cout << "\n4) İşlem başına ortalama (rastgele anahtarlar, tohum "
                 "42)\n";
    std::cout << "      n   ekle/takas  artan/takas   log2 n  çıkar/takas"
                 "  çıkar/karş.\n";
    ortalama_satiri(1000);
    ortalama_satiri(10000);
    ortalama_satiri(100000);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue
 * (push/top/pop; varsayılan en büyük öbek), std::push_heap/std::pop_heap;
 * Python — heapq.heappush/heapq.heappop (en küçük öbek). */

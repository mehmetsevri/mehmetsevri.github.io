/* H07_04_obek_kur.cpp — AP-2 Hafta 7 · Örnek 4 (★★)
 * Amaç    : Aşağıdan yukarıya öbek kurma (son iç düğümden köke aşağı
 *           süzme) ve takas sayısı: takas <= Σ yükseklik = n - popcount(n)
 *           < n, yani O(n); tek tek eklemeyle kurmanın O(n log n) en kötüsü
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 H07_04_obek_kur.cpp \
 *           -o H07_04_obek_kur
 * Çalıştır: ./H07_04_obek_kur [n_ust=100000]
 * Eşleri  : c/H07_04_obek_kur.c · python/H07_04_obek_kur.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma_sayisi = 0;
static long long takas_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

static bool buyuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x > y;
}

static void takas(int& x, int& y)
{
    std::swap(x, y);
    takas_sayisi++;
}

static void asagi_suz(std::vector<int>& a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;  // sol çocuk
        if (c + 1 < n && buyuk_mu(a[c + 1], a[c])) {
            c++;  // sağ çocuk daha büyük
        }
        if (!buyuk_mu(a[c], a[i])) {
            break;
        }
        takas(a[i], a[c]);
        i = c;
    }
}

static void yukari_suz(std::vector<int>& a, int i)
{
    while (i > 0 && buyuk_mu(a[i], a[ebeveyn(i)])) {
        takas(a[i], a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
}

// Aşağıdan yukarıya: yapraklar zaten öbektir; son iç düğümden köke
static void obek_kur(std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
}

// Yukarıdan aşağıya: a[0..i-1] öbeğine a[i]'yi ekler gibi yukarı süz
static void obek_kur_ekleyerek(std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    for (int i = 1; i < n; i++) {
        yukari_suz(a, i);
    }
}

static bool obek_mi(const std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (a[ebeveyn(static_cast<int>(i))] < a[i]) {
            return false;
        }
    }
    return true;
}

// i. düğümün yüksekliği: altındaki en uzun yol (en soldaki yol)
static int yukseklik(int i, int n)
{
    int h = 0;
    while (2 * i + 1 < n) {
        i = 2 * i + 1;
        h++;
    }
    return h;
}

static long long yukseklik_toplami(int n)
{
    long long t = 0;
    for (int i = 0; i < n; i++) {
        t += yukseklik(i, n);
    }
    return t;
}

static int birler(int n)             // ikilik gösterimdeki 1 sayısı
{
    int b = 0;
    for (; n > 0; n >>= 1) {
        b += n & 1;
    }
    return b;
}

static void dizi_yaz(const std::vector<int>& a)
{
    std::cout << "[";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? " " : "") << a[i];
    }
    std::cout << "]\n";
}

static void sayaclari_sifirla()
{
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
}

static void doldur(std::vector<int>& a, int n, bool artan)
{
    rastgele_tohum(42);
    a.assign(n, 0);
    for (int i = 0; i < n; i++) {
        a[i] = artan ? i : static_cast<int>(rastgele_sayi());
    }
}

static void izleme()
{
    std::vector<int> a = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    const int n = 10;
    std::cout << "1) Aşağıdan yukarıya kurma, artan girdi (n = 10)\n   ";
    dizi_yaz(a);
    sayaclari_sifirla();
    for (int i = n / 2 - 1; i >= 0; i--) {
        long long once = takas_sayisi;
        asagi_suz(a, n, i);
        std::cout << "  i = " << i << " (a[i] süzüldü, takas = "
                  << takas_sayisi - once << ")  ";
        dizi_yaz(a);
    }
    std::cout << "  toplam: karşılaştırma = " << karsilastirma_sayisi
              << ", takas = " << takas_sayisi << ", öbek mi? "
              << (obek_mi(a) ? "evet" : "HAYIR") << "\n";
    std::cout << "  üst sınır Σ yükseklik = " << yukseklik_toplami(n)
              << " (n - popcount(n) = " << n - birler(n) << ")\n";
    std::vector<int> b = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    sayaclari_sifirla();
    obek_kur_ekleyerek(b);
    std::cout << "  aynı girdi tek tek eklemeyle: takas = " << takas_sayisi
              << ", öbek mi? " << (obek_mi(b) ? "evet" : "HAYIR") << "  ";
    dizi_yaz(b);
}

// Mükemmel ağaçta (n = 2^(H+1) - 1) düzeylere göre iş
static void duzey_tablosu(int buyuk_h)
{
    int n = (1 << (buyuk_h + 1)) - 1;
    std::vector<int> a, r;
    std::vector<long long> ta(buyuk_h + 1, 0), tr(buyuk_h + 1, 0);
    doldur(a, n, true);
    doldur(r, n, false);
    for (int i = n / 2 - 1; i >= 0; i--) {
        int d = 0;
        for (int j = i; j > 0; j = ebeveyn(j)) {
            d++;
        }
        long long once = takas_sayisi;
        asagi_suz(a, n, i);
        ta[d] += takas_sayisi - once;
        once = takas_sayisi;
        asagi_suz(r, n, i);
        tr[d] += takas_sayisi - once;
    }
    std::cout << "\n2) Düzeylere göre iş: mükemmel ağaç, n = " << n << "\n";
    std::cout << "  düzey  düğüm  yükseklik  üst sınır  artan girdi  "
                 "rastgele\n";
    long long top_s = 0, top_a = 0, top_r = 0;
    for (int d = 0; d <= buyuk_h; d++) {
        long long dugum = 1LL << d, h = buyuk_h - d;
        std::cout << std::setw(7) << d << " " << std::setw(6) << dugum << " "
                  << std::setw(10) << h << " " << std::setw(10) << dugum * h
                  << " " << std::setw(12) << ta[d] << " " << std::setw(9)
                  << tr[d] << "\n";
        top_s += dugum * h;
        top_a += ta[d];
        top_r += tr[d];
    }
    std::cout << "  toplam " << std::setw(6) << n << " " << std::setw(10)
              << "" << " " << std::setw(10) << top_s << " " << std::setw(12)
              << top_a << " " << std::setw(9) << top_r << "\n";
}

static void asagidan_satiri(int n)
{
    std::vector<int> a;
    doldur(a, n, false);
    sayaclari_sifirla();
    obek_kur(a);
    long long t_r = takas_sayisi, k_r = karsilastirma_sayisi;
    bool ok = obek_mi(a);
    doldur(a, n, true);
    sayaclari_sifirla();
    obek_kur(a);
    long long t_a = takas_sayisi;
    ok = ok && obek_mi(a);
    long long s = yukseklik_toplami(n);
    std::cout << std::fixed << std::setprecision(3) << std::setw(9) << n
              << " " << std::setw(10) << t_r << " " << std::setw(10) << t_a
              << " " << std::setw(10) << s << " " << std::setw(6)
              << (s == n - birler(n) ? "evet" : "HAYIR") << " "
              << std::setw(7) << static_cast<double>(t_r) / n << " "
              << std::setw(7) << static_cast<double>(t_a) / n << " "
              << std::setw(7) << static_cast<double>(k_r) / n << " "
              << (ok ? "evet" : "HAYIR") << "\n";
}

static void ekleyerek_satiri(int n)
{
    std::vector<int> a;
    doldur(a, n, false);
    sayaclari_sifirla();
    obek_kur_ekleyerek(a);
    long long e_r = takas_sayisi;
    doldur(a, n, true);
    sayaclari_sifirla();
    obek_kur_ekleyerek(a);
    long long e_a = takas_sayisi;
    std::cout << std::fixed << std::setprecision(3) << std::setw(9) << n
              << " " << std::setw(10) << e_r << " " << std::setw(10) << e_a
              << " " << std::setw(7) << static_cast<double>(e_r) / n << " "
              << std::setw(7) << static_cast<double>(e_a) / n << " "
              << std::setw(7) << std::log2(n) << "\n";
}

int main(int argc, char* argv[])
{
    long n_ust = 100000;
    if (argc > 1) {
        std::string s = argv[1];
        std::size_t son = 0;
        try {
            n_ust = std::stol(s, &son);
        } catch (...) {
            son = 0;
        }
        if (son != s.size() || n_ust < 10 || n_ust > 100000000) {
            std::cerr << "kullanım: " << argv[0]
                      << " [n_ust: 10..100000000]\n";
            return 2;
        }
    }
    izleme();
    duzey_tablosu(9);
    std::cout << "\n3) Aşağıdan yukarıya: takas / n sabit kalıyor mu?\n";
    std::cout << "  r: rastgele, a: artan girdi; t: takas, k: "
                 "karşılaştırma; n-pc?: Σ yüks. = n - popcount(n) mi?\n";
    std::cout << "        n    takas r    takas a    Σ yüks.  n-pc?   t/n r"
                 "   t/n a   k/n r öbek?\n";
    for (long n = 10; n <= n_ust; n *= 10) {
        asagidan_satiri(static_cast<int>(n));
    }
    std::cout << "\n4) Tek tek ekleyerek kurma (yukarı süzme)\n";
    std::cout << "        n    takas r    takas a   t/n r   t/n a  log2 n\n";
    for (long n = 10; n <= n_ust; n *= 10) {
        ekleyerek_satiri(static_cast<int>(n));
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::make_heap (doğrusal
 * zamanda kurar: en çok 3n karşılaştırma); Python — heapq.heapify(a)
 * (en küçük öbek, doğrusal zaman). */

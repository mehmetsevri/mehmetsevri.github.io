/* H07_11_kova_siralamasi.cpp — AP-2 Hafta 7 · Örnek 11 (★★)
 * Amaç    : Kova sıralaması: [0, 1) aralığındaki n değer n kovaya
 *           dağıtılır (kova = ⌊x · n⌋), kova içleri araya eklemeyle
 *           sıralanır; düzgün dağılımda Θ(n), varsayım bozulursa Θ(n²)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_11_kova_siralamasi.cpp -o H07_11_kova_siralamasi
 * Çalıştır: ./H07_11_kova_siralamasi
 * Eşleri  : c/H07_11_kova_siralamasi.c ·
 *           python/H07_11_kova_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <vector>

#include "ortak_rastgele.hpp"

static long long karsilastirma_sayisi = 0;
static int en_dolu = 0;                    // en kalabalık kovanın boyu
static int bos_kova = 0;

// a[bas..son-1] dilimini araya eklemeyle sıralar
static void araya_ekleme(std::vector<double>& a, int bas, int son)
{
    for (int i = bas + 1; i < son; i++) {
        double x = a[i];
        int j = i - 1;
        while (j >= bas) {
            karsilastirma_sayisi++;
            if (a[j] <= x) {
                break;
            }
            a[j + 1] = a[j];               // kaydır
            j--;
        }
        a[j + 1] = x;
    }
}

static int kova_no(double x, int n)
{
    int k = static_cast<int>(x * n);       // 0 <= x < 1
    return k < n ? k : n - 1;
}

// Kovalar ayrı listeler yerine tek dizide ardışık dilimlerdir: kova
// boyları sayılır, önek toplamla başlangıçlar bulunur (Örnek 9)
static void kova_siralamasi(std::vector<double>& a, bool izle)
{
    int n = static_cast<int>(a.size());
    std::vector<int> bas(n + 1, 0);
    std::vector<double> b(n);
    for (double x : a) {
        bas[kova_no(x, n) + 1]++;          // kova boyları
    }
    for (int v = 1; v <= n; v++) {
        bas[v] += bas[v - 1];              // kova v: b[bas[v]..bas[v+1])
    }
    std::vector<int> yer(bas.begin(), bas.end() - 1);
    for (double x : a) {                   // dağıt (kararlı)
        b[yer[kova_no(x, n)]++] = x;
    }
    en_dolu = 0;
    bos_kova = 0;
    for (int v = 0; v < n; v++) {
        int boy = bas[v + 1] - bas[v];
        en_dolu = std::max(boy, en_dolu);
        bos_kova += boy == 0;
        if (izle) {
            std::cout << std::fixed << std::setprecision(1) << "  kova " << v
                      << " [" << static_cast<double>(v) / n << ", "
                      << static_cast<double>(v + 1) / n << "):"
                      << std::setprecision(4);
            for (int i = bas[v]; i < bas[v + 1]; i++) {
                std::cout << " " << b[i];
            }
            std::cout << "\n";
        }
        araya_ekleme(b, bas[v], bas[v + 1]);
    }
    a = b;
}

// dagilim: 0 düzgün (u), 1 çarpık (u^4), 2 tek kova (0.5 + u / 2n)
static std::vector<double> uret(int n, int dagilim)
{
    std::vector<double> a(n);
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        double u = rastgele_kesir();
        if (dagilim == 0) {
            a[i] = u;
        } else if (dagilim == 1) {
            a[i] = u * u * u * u;
        } else {
            a[i] = 0.5 + u / (2.0 * n);
        }
    }
    return a;
}

static bool dogru_mu(const std::vector<double>& a, int dagilim)
{
    std::vector<double> k = uret(static_cast<int>(a.size()), dagilim);
    std::sort(k.begin(), k.end());                      // kâhin
    return a == k;
}

int main()
{
    std::cout << "1) 10 değer, 10 kova (tohum 42)\n  girdi:";
    std::vector<double> a = uret(10, 0);
    std::cout << std::fixed << std::setprecision(4);
    for (double x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
    karsilastirma_sayisi = 0;
    kova_siralamasi(a, true);
    std::cout << "  çıktı:" << std::setprecision(4);
    for (double x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n  karşılaştırma = " << karsilastirma_sayisi
              << ", boş kova = " << bos_kova << ", en dolu kova = " << en_dolu
              << "\n";

    std::cout << "\n2) Düzgün dağılım: kova başına ortalama 1 eleman\n";
    std::cout << "        n  karşılaştırma  karş./n  en dolu  boş kova oranı"
                 "  kâhin\n";
    for (int n = 1000; n <= 100000; n *= 10) {
        a = uret(n, 0);
        karsilastirma_sayisi = 0;
        kova_siralamasi(a, false);
        std::cout << std::setw(9) << n << " " << std::setw(14)
                  << karsilastirma_sayisi << " " << std::setprecision(3)
                  << std::setw(8)
                  << static_cast<double>(karsilastirma_sayisi) / n << " "
                  << std::setw(8) << en_dolu << " " << std::setprecision(4)
                  << std::setw(15) << static_cast<double>(bos_kova) / n
                  << "  " << (dogru_mu(a, 0) ? "evet" : "HAYIR") << "\n";
    }

    std::cout << "\n3) Dağılım varsayımı bozulursa (karş./n)\n";
    std::cout << "        n    düzgün  çarpık u^4   tek kova  kâhin\n";
    std::cout << std::setprecision(3);
    for (int n = 1000; n <= 4000; n *= 2) {
        double oran[3];
        bool hepsi = true;
        for (int d = 0; d < 3; d++) {
            a = uret(n, d);
            karsilastirma_sayisi = 0;
            kova_siralamasi(a, false);
            oran[d] = static_cast<double>(karsilastirma_sayisi) / n;
            hepsi = hepsi && dogru_mu(a, d);
        }
        std::cout << std::setw(9) << n << " " << std::setw(9) << oran[0]
                  << " " << std::setw(11) << oran[1] << " " << std::setw(10)
                  << oran[2] << "  " << (hepsi ? "evet" : "HAYIR") << "\n";
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::sort karşılaştırmalıdır);
 * Python — yok (sorted yalnızca kâhin). */

"""H07_deney_siralama.py — AP-2 Hafta 7 · Haftanın Deneyi (Python)
Amaç    : Sıralama algoritmalarının süre ölçümü (sayaçsız sürümler;
          algoritmalar Örnek 12 ile aynıdır). Üç deney:
  karsilastir ALG TUR N TEKRAR  — 8 algoritma × 4 girdi türü × n
  aralik ALG K N TEKRAR         — sayma/taban: anahtar aralığı [0, K)
  kurma YONTEM TUR N TEKRAR     — öbek kurma: asagidan | ekleyerek
Çıktı   : stdout'a tek CSV satırı (C sürümüyle aynı sütunlar):
  deney;algoritma;girdi;n;tekrar;ortanca_ms;en_az_ms;en_cok_ms;dogru;
  takas;islemci_ortanca_ms;islemci_en_az_ms;islemci_en_cok_ms.
  Çıkış kodu 3: uygulanamaz (Python'da sayma
  sıralaması K <= 10^7 ile sınırlıdır: liste yuvası 8 bayt).
Çalıştır: python3 H07_deney_siralama.py karsilastir hizli rastgele 10000 5
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum
from zamanlayici import islemci_sn, ortanca, zaman_sn

SAYAC_SINIRI = 10 ** 7

sys.setrecursionlimit(10000)


# ---------- Algoritmalar (Örnek 12 ile aynı adımlar, sayaçsız) ----------
def secmeli_siralama(a):
    n = len(a)
    for i in range(n - 1):
        m = i
        for j in range(i + 1, n):
            if a[j] < a[m]:
                m = j
        if m != i:
            a[i], a[m] = a[m], a[i]


def araya_ekleme_siralamasi(a):
    for i in range(1, len(a)):
        x = a[i]
        j = i - 1
        while j >= 0 and x < a[j]:
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = x


def birlestir(a, g, lo, orta, hi):
    i, j, k = lo, orta, lo
    while i < orta and j < hi:
        if a[j] < a[i]:
            g[k] = a[j]
            j += 1
        else:
            g[k] = a[i]
            i += 1
        k += 1
    while i < orta:
        g[k] = a[i]
        i, k = i + 1, k + 1
    while j < hi:
        g[k] = a[j]
        j, k = j + 1, k + 1
    a[lo:hi] = g[lo:hi]


def birlestirmeli_ozyineli(a, g, lo, hi):
    if hi - lo < 2:
        return
    orta = lo + (hi - lo) // 2
    birlestirmeli_ozyineli(a, g, lo, orta)
    birlestirmeli_ozyineli(a, g, orta, hi)
    birlestir(a, g, lo, orta, hi)


def birlestirmeli_siralama(a):
    birlestirmeli_ozyineli(a, [0] * len(a), 0, len(a))


def bolumle(a, lo, hi):
    orta = lo + (hi - lo) // 2
    if a[orta] < a[lo]:
        a[orta], a[lo] = a[lo], a[orta]
    if a[hi] < a[lo]:
        a[hi], a[lo] = a[lo], a[hi]
    if a[hi] < a[orta]:
        a[hi], a[orta] = a[orta], a[hi]
    pivot = a[orta]
    i, j = lo - 1, hi + 1
    while True:
        i += 1
        while a[i] < pivot:
            i += 1
        j -= 1
        while pivot < a[j]:
            j -= 1
        if i >= j:
            return j
        a[i], a[j] = a[j], a[i]


def hizli_ozyineli(a, lo, hi):
    while lo < hi:
        p = bolumle(a, lo, hi)
        if p - lo < hi - p:
            hizli_ozyineli(a, lo, p)
            lo = p + 1
        else:
            hizli_ozyineli(a, p + 1, hi)
            hi = p


def hizli_siralama(a):
    hizli_ozyineli(a, 0, len(a) - 1)


def asagi_suz(a, n, i):
    t = 0
    while 2 * i + 1 < n:
        c = 2 * i + 1
        if c + 1 < n and a[c] < a[c + 1]:
            c += 1
        if not a[i] < a[c]:
            break
        a[i], a[c] = a[c], a[i]
        t += 1
        i = c
    return t


def obek_kur(a):                                   # aşağıdan yukarıya
    n = len(a)
    t = 0
    for i in range(n // 2 - 1, -1, -1):
        t += asagi_suz(a, n, i)
    return t


def obek_kur_ekleyerek(a):                         # yukarı süzme
    t = 0
    for i in range(1, len(a)):
        j = i
        while j > 0 and a[(j - 1) // 2] < a[j]:
            a[j], a[(j - 1) // 2] = a[(j - 1) // 2], a[j]
            t += 1
            j = (j - 1) // 2
    return t


def obek_siralamasi(a):
    obek_kur(a)
    for son in range(len(a) - 1, 0, -1):
        a[0], a[son] = a[son], a[0]
        asagi_suz(a, son, 0)


def sayma_siralamasi(a, k):
    """anahtarlar 0 .. k-1; sayaç dizisi k elemanlı"""
    sayac = [0] * k
    for x in a:
        sayac[x] += 1
    j = 0
    for v in range(k):
        for _ in range(sayac[v]):
            a[j] = v
            j += 1


def taban_siralamasi(a, gecis_sayisi):
    """gecis_sayisi bayt geçişi (4: tam 32 bit)"""
    n = len(a)
    kaynak, hedef = a, [0] * n
    for d in range(gecis_sayisi):
        kaydir = 8 * d
        onek = [0] * 256
        for x in kaynak:
            onek[(x >> kaydir) & 0xFF] += 1
        for v in range(1, 256):
            onek[v] += onek[v - 1]
        for i in range(n - 1, -1, -1):
            v = (kaynak[i] >> kaydir) & 0xFF
            onek[v] -= 1
            hedef[onek[v]] = kaynak[i]
        kaynak, hedef = hedef, kaynak
    if kaynak is not a:
        a[:] = kaynak


def kutuphane_siralamasi(a):
    a.sort()


# ---------- Girdiler ----------
def rastgele_u32():
    ust = rastgele_sayi() >> 15
    alt = rastgele_sayi() >> 15
    return (ust << 16) | alt


def girdi_uret(n, tur):
    """karsilastir: Örnek 12 ile aynı girdiler (0..999999 / 0..9)"""
    rastgele_tohum(42)
    a = [0] * n
    for i in range(n):
        if tur == "rastgele":
            a[i] = rastgele_aralik(0, 999999)
        elif tur == "sirali":
            a[i] = i * 1000000 // n
        elif tur == "ters":
            a[i] = (n - 1 - i) * 1000000 // n
        else:
            a[i] = rastgele_aralik(0, 9)
    return a


def gecis_icin(k):
    """k - 1'i taşıyan bayt sayısı"""
    d = 1
    while d < 4 and (k - 1) >> (8 * d) != 0:
        d += 1
    return d


# ---------- Ölçüm ----------
def calistir(alg, k, a):
    if alg == "secmeli":
        secmeli_siralama(a)
    elif alg == "araya_ekleme":
        araya_ekleme_siralamasi(a)
    elif alg == "birlestirmeli":
        birlestirmeli_siralama(a)
    elif alg == "hizli":
        hizli_siralama(a)
    elif alg == "obek":
        obek_siralamasi(a)
    elif alg == "sayma":
        sayma_siralamasi(a, k)
    elif alg == "taban":
        taban_siralamasi(a, 4)
    elif alg == "taban_d":
        taban_siralamasi(a, gecis_icin(k))
    elif alg == "kutuphane":
        kutuphane_siralamasi(a)
    elif alg == "asagidan":
        return obek_kur(a)
    else:
        return obek_kur_ekleyerek(a)
    return -1


def obek_mi(a):
    return all(a[(i - 1) // 2] >= a[i] for i in range(1, len(a)))


def kullanim():
    print(f"kullanım: {sys.argv[0]} karsilastir ALG TUR N TEKRAR | aralik "
          "ALG K N TEKRAR | kurma YONTEM TUR N TEKRAR", file=sys.stderr)
    sys.exit(2)


def main():
    if len(sys.argv) != 6:
        kullanim()
    deney, alg, tur = sys.argv[1], sys.argv[2], sys.argv[3]
    try:
        n, tekrar = int(sys.argv[4]), int(sys.argv[5])
        k = int(tur) if deney == "aralik" else 0
    except ValueError:
        kullanim()
    if not 2 <= n <= 100000000 or not 1 <= tekrar <= 101:
        kullanim()
    if deney == "karsilastir":
        g = girdi_uret(n, tur)
        k = 10 if tur == "tekrarli" else 1000000
    elif deney == "aralik":
        if not 2 <= k <= 2 ** 32:
            kullanim()
        if alg == "sayma" and k > SAYAC_SINIRI:
            print(f"aralik;sayma;{tur};{n};0;;;;uygulanamaz;;;;")
            sys.exit(3)
        rastgele_tohum(42)
        g = [rastgele_u32() % k for _ in range(n)]
    elif deney == "kurma":
        rastgele_tohum(42)
        g = [i if tur == "artan" else rastgele_sayi() for i in range(n)]
    else:
        kullanim()
    kahin = g[:] if deney == "kurma" else sorted(g)
    t, c = [], []
    takas = -1
    for r in range(-1, tekrar):                    # r = -1: ısınma
        a = g[:]
        c0 = islemci_sn()
        t0 = zaman_sn()
        takas = calistir(alg, k, a)
        t1 = zaman_sn()
        c1 = islemci_sn()
        if r >= 0:
            t.append((t1 - t0) * 1000.0)
            c.append((c1 - c0) * 1000.0)
    dogru = obek_mi(a) if deney == "kurma" else a == kahin
    print(f"{deney};{alg};{tur};{n};{tekrar};{ortanca(t):.6f};"
          f"{min(t):.6f};{max(t):.6f};" + ("evet" if dogru else "HAYIR")
          + ";" + (str(takas) if takas >= 0 else "")
          + f";{ortanca(c):.6f};{min(c):.6f};{max(c):.6f}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: Python — list.sort / sorted (kâhin ve "kutuphane").

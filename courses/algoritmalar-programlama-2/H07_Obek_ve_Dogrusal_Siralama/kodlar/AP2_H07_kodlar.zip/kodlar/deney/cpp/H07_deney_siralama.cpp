/* H07_deney_siralama.cpp — AP-2 Hafta 7 · Haftanın Deneyi (C++)
 * Amaç    : Sıralama algoritmalarının süre ölçümü (sayaçsız sürümler;
 *           algoritmalar Örnek 12 ile aynıdır). Üç deney:
 *   karsilastir ALG TUR N TEKRAR  — 8 algoritma × 4 girdi türü × n
 *   aralik ALG K N TEKRAR         — sayma/taban: anahtar aralığı [0, K)
 *   kurma YONTEM TUR N TEKRAR     — öbek kurma: asagidan | ekleyerek
 * Çıktı   : stdout'a tek CSV satırı (C sürümüyle aynı sütunlar):
 *   deney;algoritma;girdi;n;tekrar;ortanca_ms;en_az_ms;en_cok_ms;dogru;
 *   takas;islemci_ortanca_ms;islemci_en_az_ms;islemci_en_cok_ms.
 *   Çıkış kodu 3: uygulanamaz.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_deney_siralama.cpp -o H07_deney_siralama
 */
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "ortak_rastgele.hpp"
#include "zamanlayici.hpp"

using Anahtar = std::uint32_t;
using Dizi = std::vector<Anahtar>;

const std::uint64_t SAYAC_SINIRI = 1ULL << 28;   // en çok 2^28 sayaç

// ---------- Algoritmalar (Örnek 12 ile aynı adımlar, sayaçsız) ----------
static void secmeli_siralama(Dizi& a)
{
    int n = static_cast<int>(a.size());
    for (int i = 0; i + 1 < n; i++) {
        int m = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[m]) {
                m = j;
            }
        }
        if (m != i) {
            std::swap(a[i], a[m]);
        }
    }
}

static void araya_ekleme_siralamasi(Dizi& a)
{
    int n = static_cast<int>(a.size());
    for (int i = 1; i < n; i++) {
        Anahtar x = a[i];
        int j = i - 1;
        while (j >= 0 && x < a[j]) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}

static void birlestir(Dizi& a, Dizi& g, int lo, int orta, int hi)
{
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        g[k++] = a[j] < a[i] ? a[j++] : a[i++];
    }
    while (i < orta) {
        g[k++] = a[i++];
    }
    while (j < hi) {
        g[k++] = a[j++];
    }
    std::copy(g.begin() + lo, g.begin() + hi, a.begin() + lo);
}

static void birlestirmeli_ozyineli(Dizi& a, Dizi& g, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli_ozyineli(a, g, lo, orta);
    birlestirmeli_ozyineli(a, g, orta, hi);
    birlestir(a, g, lo, orta, hi);
}

static Dizi gecici_dizi;               // birleştirme ve taban için

static void birlestirmeli_siralama(Dizi& a)
{
    birlestirmeli_ozyineli(a, gecici_dizi, 0, static_cast<int>(a.size()));
}

static int bolumle(Dizi& a, int lo, int hi)
{
    int orta = lo + (hi - lo) / 2;
    if (a[orta] < a[lo]) {
        std::swap(a[orta], a[lo]);
    }
    if (a[hi] < a[lo]) {
        std::swap(a[hi], a[lo]);
    }
    if (a[hi] < a[orta]) {
        std::swap(a[hi], a[orta]);
    }
    Anahtar pivot = a[orta];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {
            i++;
        } while (a[i] < pivot);
        do {
            j--;
        } while (pivot < a[j]);
        if (i >= j) {
            return j;
        }
        std::swap(a[i], a[j]);
    }
}

static void hizli_ozyineli(Dizi& a, int lo, int hi)
{
    while (lo < hi) {
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            hizli_ozyineli(a, lo, p);
            lo = p + 1;
        } else {
            hizli_ozyineli(a, p + 1, hi);
            hi = p;
        }
    }
}

static void hizli_siralama(Dizi& a)
{
    hizli_ozyineli(a, 0, static_cast<int>(a.size()) - 1);
}

static long long asagi_suz(Dizi& a, int n, int i)
{
    long long t = 0;
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c] < a[c + 1]) {
            c++;
        }
        if (!(a[i] < a[c])) {
            break;
        }
        std::swap(a[i], a[c]);
        t++;
        i = c;
    }
    return t;
}

static long long obek_kur(Dizi& a)                 // aşağıdan yukarıya
{
    int n = static_cast<int>(a.size());
    long long t = 0;
    for (int i = n / 2 - 1; i >= 0; i--) {
        t += asagi_suz(a, n, i);
    }
    return t;
}

static long long obek_kur_ekleyerek(Dizi& a)       // yukarı süzme
{
    int n = static_cast<int>(a.size());
    long long t = 0;
    for (int i = 1; i < n; i++) {
        int j = i;
        while (j > 0 && a[(j - 1) / 2] < a[j]) {
            std::swap(a[j], a[(j - 1) / 2]);
            t++;
            j = (j - 1) / 2;
        }
    }
    return t;
}

static void obek_siralamasi(Dizi& a)
{
    int n = static_cast<int>(a.size());
    obek_kur(a);
    for (int son = n - 1; son > 0; son--) {
        std::swap(a[0], a[son]);
        asagi_suz(a, son, 0);
    }
}

// anahtarlar 0 .. k-1; sayaç dizisi k elemanlı
static void sayma_siralamasi(Dizi& a, std::uint64_t k)
{
    std::vector<std::uint32_t> sayac(k, 0);
    for (Anahtar x : a) {
        sayac[x]++;
    }
    std::size_t j = 0;
    for (std::uint64_t v = 0; v < k; v++) {
        for (std::uint32_t c = 0; c < sayac[v]; c++) {
            a[j++] = static_cast<Anahtar>(v);
        }
    }
}

// gecis_sayisi bayt geçişi (4: tam 32 bit)
static void taban_siralamasi(Dizi& a, int gecis_sayisi)
{
    int n = static_cast<int>(a.size());
    Dizi& b = gecici_dizi;
    for (int d = 0; d < gecis_sayisi; d++) {
        int kaydir = 8 * d;
        int onek[256] = {0};
        for (int i = 0; i < n; i++) {
            onek[(a[i] >> kaydir) & 0xFF]++;
        }
        for (int v = 1; v < 256; v++) {
            onek[v] += onek[v - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            b[--onek[(a[i] >> kaydir) & 0xFF]] = a[i];
        }
        std::swap(a, b);               // O(1)
    }
}

static void kutuphane_siralamasi(Dizi& a)
{
    std::sort(a.begin(), a.end());
}

// ---------- Girdiler ----------
static Anahtar rastgele_u32()
{
    std::uint32_t ust = rastgele_sayi() >> 15;
    std::uint32_t alt = rastgele_sayi() >> 15;
    return (ust << 16) | alt;
}

// karsilastir: Örnek 12 ile aynı girdiler (anahtarlar 0..999999 / 0..9)
static Dizi girdi_uret(int n, const std::string& tur)
{
    rastgele_tohum(42);
    Dizi a(n);
    for (int i = 0; i < n; i++) {
        if (tur == "rastgele") {
            a[i] = static_cast<Anahtar>(rastgele_aralik(0, 999999));
        } else if (tur == "sirali") {
            a[i] = static_cast<Anahtar>(static_cast<long long>(i) * 1000000
                                        / n);
        } else if (tur == "ters") {
            a[i] = static_cast<Anahtar>(static_cast<long long>(n - 1 - i) *
                                        1000000 / n);
        } else {
            a[i] = static_cast<Anahtar>(rastgele_aralik(0, 9));
        }
    }
    return a;
}

static int gecis_icin(std::uint64_t k)  // k - 1'i taşıyan bayt sayısı
{
    int d = 1;
    while (d < 4 && (k - 1) >> (8 * d) != 0) {
        d++;
    }
    return d;
}

// ---------- Ölçüm ----------
static long long calistir(const std::string& alg, std::uint64_t k, Dizi& a)
{
    if (alg == "secmeli") {
        secmeli_siralama(a);
    } else if (alg == "araya_ekleme") {
        araya_ekleme_siralamasi(a);
    } else if (alg == "birlestirmeli") {
        birlestirmeli_siralama(a);
    } else if (alg == "hizli") {
        hizli_siralama(a);
    } else if (alg == "obek") {
        obek_siralamasi(a);
    } else if (alg == "sayma") {
        sayma_siralamasi(a, k);
    } else if (alg == "taban") {
        taban_siralamasi(a, 4);
    } else if (alg == "taban_d") {
        taban_siralamasi(a, gecis_icin(k));
    } else if (alg == "kutuphane") {
        kutuphane_siralamasi(a);
    } else if (alg == "asagidan") {
        return obek_kur(a);
    } else {
        return obek_kur_ekleyerek(a);
    }
    return -1;
}

static bool obek_mi(const Dizi& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (a[(i - 1) / 2] < a[i]) {
            return false;
        }
    }
    return true;
}

static int kullanim(const char* ad)
{
    std::cerr << "kullanım: " << ad << " karsilastir ALG TUR N TEKRAR | "
              << "aralik ALG K N TEKRAR | kurma YONTEM TUR N TEKRAR\n";
    return 2;
}

int main(int argc, char* argv[])
{
    if (argc != 6) {
        return kullanim(argv[0]);
    }
    std::string deney = argv[1], alg = argv[2], tur = argv[3];
    long n = 0, tekrar = 0;
    std::uint64_t k = 0;
    try {
        n = std::stol(argv[4]);
        tekrar = std::stol(argv[5]);
        if (deney == "aralik") {
            k = std::stoull(tur);
        }
    } catch (...) {
        return kullanim(argv[0]);
    }
    if (n < 2 || n > 100000000 || tekrar < 1 || tekrar > 101) {
        return kullanim(argv[0]);
    }
    Dizi g;
    if (deney == "karsilastir") {
        g = girdi_uret(static_cast<int>(n), tur);
        k = tur == "tekrarli" ? 10 : 1000000;
    } else if (deney == "aralik") {
        if (k < 2 || k > (1ULL << 32)) {
            return kullanim(argv[0]);
        }
        if (alg == "sayma" && k > SAYAC_SINIRI) {
            std::cout << "aralik;sayma;" << tur << ";" << n
                      << ";0;;;;uygulanamaz;;;;\n";
            return 3;
        }
        rastgele_tohum(42);
        g.resize(n);
        for (long i = 0; i < n; i++) {
            Anahtar x = rastgele_u32();
            g[i] = k == (1ULL << 32) ? x : static_cast<Anahtar>(x % k);
        }
    } else if (deney == "kurma") {
        rastgele_tohum(42);
        g.resize(n);
        for (long i = 0; i < n; i++) {
            g[i] = tur == "artan" ? static_cast<Anahtar>(i) : rastgele_sayi();
        }
    } else {
        return kullanim(argv[0]);
    }
    Dizi kahin = g;
    if (deney != "kurma") {
        kutuphane_siralamasi(kahin);
    }
    gecici_dizi.assign(n, 0);
    std::vector<double> t, c;
    Dizi a;
    long long takas = -1;
    for (int r = -1; r < tekrar; r++) {               // r = -1: ısınma
        a = g;
        double c0 = islemci_sn();
        double t0 = zaman_sn();
        takas = calistir(alg, k, a);
        double t1 = zaman_sn();
        double c1 = islemci_sn();
        if (r >= 0) {
            t.push_back((t1 - t0) * 1000.0);
            c.push_back((c1 - c0) * 1000.0);
        }
    }
    bool dogru = deney == "kurma" ? obek_mi(a) : a == kahin;
    double en_az = *std::min_element(t.begin(), t.end());
    double en_cok = *std::max_element(t.begin(), t.end());
    std::printf("%s;%s;%s;%ld;%ld;%.6f;%.6f;%.6f;%s;", deney.c_str(),
                alg.c_str(), tur.c_str(), n, tekrar, ortanca(t), en_az,
                en_cok, dogru ? "evet" : "HAYIR");
    if (takas >= 0) {
        std::printf("%lld", takas);
    }
    std::printf(";%.6f;%.6f;%.6f\n", ortanca(c),
                *std::min_element(c.begin(), c.end()),
                *std::max_element(c.begin(), c.end()));
    return 0;
}

/* Kütüphane karşılığı: C++ — std::sort (kâhin ve "kutuphane" satırı). */

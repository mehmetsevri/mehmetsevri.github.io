#!/usr/bin/env python3
"""h07_olcum_calistir.py — AP-2 Hafta 7 · Haftanın Deneyi: ölçüm sürücüsü

Üç deneyi üç dilde çalıştırır ve ham sonuçları sonuclar/ altına yazar:
  1) karsilastir: 8 algoritma × 4 girdi türü × n
       -> sonuclar/h07_deney_karsilastirma.csv
  2) aralik: sayma / taban / kütüphane / hızlı, anahtar aralığı K
       -> sonuclar/h07_deney_anahtar_araligi.csv
  3) kurma: öbek kurma (aşağıdan yukarıya / tek tek ekleyerek)
       -> sonuclar/h07_deney_obek_kurma.csv
Makine bilgisi: OLCUM_ORTAMI.txt (ölçüm öncesi ve sonrası yük ortalaması).

Düzen (AP-2 Ajan Rehberi, Bölüm 3):
  * C ve C++ -O2; karşılaştırma için C ayrıca -O0 (n = 10^5 / 10^4).
  * Her ölçüm: 1 ısınma + 5 tekrar (tek çalıştırması ~1 s'yi aşan
    büyüklüklerde 3 tekrar), ORTANCA. Hem duvar saati hem işlemci zamanı
    kaydedilir.
  * Tutarsız ölçüm (işlemci zamanı en_cok / en_az > 1,5 ve ortanca > 2 ms)
    en çok iki kez yinelenir; yayılımı en küçük deneme tutulur. Duvar
    saati, makinedeki başka süreçlerin yükünü de içerdiğinden çözümlemede
    işlemci zamanı ortancası kullanılır; ikisi de CSV'dedir.
  * Izgara: n log n ve doğrusal algoritmalar C/C++'ta n = 10^3 … 10^6
    (C'de rastgele girdi için ayrıca 10^7), Python'da 10^3 … 10^5
    (kütüphane 10^6); karesel algoritmalar C/C++'ta n = 10^3, 3·10^3,
    10^4, 3·10^4, Python'da 10^3, 3·10^3. Kestirimi sınamak için
    "dogrulama" ölçümleri (tek tekrar): C ve C++ araya ekleme n = 10^5,
    Python seçmeli ve araya ekleme n = 10^4 (rastgele).
Kullanım (deney/ klasöründe): python3 h07_olcum_calistir.py [--hizli]
                                                         [--devam]
  --hizli: küçük ızgara (betiği sınamak için; sonuç dosyaları yazılmaz)
  --devam: yarıda kalan ölçüme devam (sonuclar/h07_ham.jsonl'deki
           ölçümler yinelenmez); ölçümler bu dosyaya anında eklenir
  --ikinci-oturum DIL: DIL (C, C++ ya da Python) ölçümlerini bağımsız bir
           ikinci oturumda yineler; her ölçüm için işlemci zamanı ortancası
           KÜÇÜK olan oturum CSV'ye yazılır (başka süreçlerin etkisi süreyi
           yalnızca artırabilir). CSV'deki "oturum" sütunu seçileni gösterir.
"""
import datetime
import json
import os
import platform
import subprocess
import sys
import tempfile

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
C_DERLE = ["gcc", "-std=c17", "-Wall", "-Wextra", "-pedantic"]
CPP_DERLE = ["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic"]

KARESEL = ["secmeli", "araya_ekleme"]
HIZLI = ["birlestirmeli", "hizli", "obek", "sayma", "taban", "kutuphane"]
TURLER = ["rastgele", "sirali", "ters", "tekrarli"]
ALANLAR = ["n", "dil", "derleme", "deney", "algoritma", "girdi", "tur",
           "tekrar", "deneme", "oturum", "ortanca_ms", "en_az_ms", "en_cok_ms",
           "islemci_ortanca_ms", "islemci_en_az_ms", "islemci_en_cok_ms",
           "dogru", "takas"]


def derle(gecici):
    """İkilileri derler; {(dil, derleme): komut önü} döndürür."""
    c, cpp, py = (os.path.join(KOK, d) for d in ("c", "cpp", "python"))
    ikili = {}
    for bayrak in ("-O2", "-O0"):
        hedef = os.path.join(gecici, f"h07ikili_c{bayrak}")
        kaynak = [os.path.join(c, f) for f in (
            "H07_deney_siralama.c", "ortak_rastgele.c", "zamanlayici.c")]
        subprocess.run(C_DERLE + [bayrak] + kaynak + ["-o", hedef],
                       check=True)
        ikili[("C", bayrak)] = [hedef]
    hedef = os.path.join(gecici, "h07ikili_cpp")
    subprocess.run(CPP_DERLE + ["-O2", os.path.join(
        cpp, "H07_deney_siralama.cpp"), "-o", hedef], check=True)
    ikili[("C++", "-O2")] = [hedef]
    ikili[("Python", "-")] = [sys.executable, os.path.join(
        py, "H07_deney_siralama.py")]
    return ikili


def olc(komut, deney, alg, girdi, n, tekrar):
    p = subprocess.run(komut + [deney, alg, str(girdi), str(n),
                                str(tekrar)],
                       capture_output=True, text=True,
                       env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    if p.returncode not in (0, 3):
        raise RuntimeError(f"{komut} {deney} {alg} {girdi} {n}: "
                           f"{p.returncode} {p.stderr}")
    s = p.stdout.strip().split(";")
    sonuc = {"deney": s[0], "algoritma": s[1], "girdi": s[2],
             "n": int(s[3]), "tekrar": int(s[4]), "dogru": s[8],
             "takas": s[9]}
    if p.returncode == 3:
        sonuc.update(ortanca_ms="", en_az_ms="", en_cok_ms="",
                     islemci_ortanca_ms="", islemci_en_az_ms="",
                     islemci_en_cok_ms="")
    else:
        sonuc.update(ortanca_ms=float(s[5]), en_az_ms=float(s[6]),
                     en_cok_ms=float(s[7]), islemci_ortanca_ms=float(s[10]),
                     islemci_en_az_ms=float(s[11]),
                     islemci_en_cok_ms=float(s[12]))
    return sonuc


def olc_tutarli(komut, deney, alg, girdi, n, tekrar):
    en_iyi, deneme = None, 0
    for deneme in range(1, 4):
        s = olc(komut, deney, alg, girdi, n, tekrar)
        if s["ortanca_ms"] == "":
            return dict(s, deneme=1)
        # tutarlılık işlemci zamanı üzerinden (duvar saati başka süreçlerin
        # yükünü de içerir)
        yayilim = s["islemci_en_cok_ms"] / max(s["islemci_en_az_ms"], 1e-3)
        if en_iyi is None or yayilim < en_iyi[0]:
            en_iyi = (yayilim, s)
        if yayilim <= 1.5 or s["islemci_ortanca_ms"] <= 2.0 or tekrar == 1:
            break
    return dict(en_iyi[1], deneme=deneme)


def tekrar_sec(dil, alg, n):
    """Tek çalıştırması ~1 s'yi aşabilecek büyüklüklerde 3 tekrar"""
    if dil == "Python":
        if alg in KARESEL:
            return 5 if n <= 3000 else 1
        return 5 if n <= 30000 or alg in ("kutuphane", "sayma") else 3
    if alg in KARESEL:
        return 5 if n <= 10000 else 3
    return 5 if n <= 1000000 else 3


def plan(hizli):
    """(dil, derleme, deney, alg, girdi, n, tur) listesi"""
    p = []
    izgara = [1000, 10000, 100000, 1000000]       # n log n ve doğrusal
    karesel = [1000, 3000, 10000, 30000]
    py_izgara, py_karesel = [1000, 10000, 100000], [1000, 3000]
    if hizli:
        izgara, karesel, py_izgara, py_karesel = [1000], [1000], [1000], []
    for dil, der in (("C", "-O2"), ("C++", "-O2")):
        for t in TURLER:
            for n in izgara:
                for alg in HIZLI:
                    p.append((dil, der, "karsilastir", alg, t, n, "olcum"))
            for n in karesel:
                for alg in KARESEL:
                    p.append((dil, der, "karsilastir", alg, t, n, "olcum"))
        if not hizli:
            p.append((dil, der, "karsilastir", "araya_ekleme", "rastgele",
                      100000, "dogrulama"))
    if not hizli:
        for alg in HIZLI:                        # yalnız C, rastgele, 10^7
            p.append(("C", "-O2", "karsilastir", alg, "rastgele", 10000000,
                      "olcum"))
        for alg in HIZLI:                        # C -O0 karşılaştırması
            p.append(("C", "-O0", "karsilastir", alg, "rastgele", 100000,
                      "olcum"))
        for alg in KARESEL:
            p.append(("C", "-O0", "karsilastir", alg, "rastgele", 10000,
                      "olcum"))
    for t in TURLER:
        for n in py_izgara:
            for alg in HIZLI:
                p.append(("Python", "-", "karsilastir", alg, t, n, "olcum"))
        for n in py_karesel:
            for alg in KARESEL:
                p.append(("Python", "-", "karsilastir", alg, t, n, "olcum"))
        if not hizli:
            p.append(("Python", "-", "karsilastir", "kutuphane", t, 1000000,
                      "olcum"))
    if not hizli:
        for alg in KARESEL:
            p.append(("Python", "-", "karsilastir", alg, "rastgele", 10000,
                      "dogrulama"))
    # 2) anahtar aralığı
    kler = [100, 10000, 1000000, 10000000, 100000000, 2 ** 32]
    for dil, der, n in (("C", "-O2", 1000000), ("C++", "-O2", 1000000),
                        ("Python", "-", 100000)):
        if hizli:
            n = 10000
        for k in kler:
            for alg in ("sayma", "taban", "taban_d", "kutuphane", "hizli"):
                p.append((dil, der, "aralik", alg, k, n, "olcum"))
    # 3) öbek kurma
    for dil, der, ust in (("C", "-O2", 10 ** 7), ("C++", "-O2", 10 ** 7),
                          ("Python", "-", 10 ** 6)):
        if hizli:
            ust = 10 ** 4
        n = 1000
        while n <= ust:
            for yontem in ("asagidan", "ekleyerek"):
                for t in ("rastgele", "artan"):
                    if (dil == "Python" and yontem == "ekleyerek"
                            and t == "artan" and n > 10 ** 5):
                        continue
                    p.append((dil, der, "kurma", yontem, t, n, "olcum"))
            n *= 10
    return p


def yuk():
    try:
        return " ".join(open("/proc/loadavg").read().split()[:3])
    except OSError:
        return "?"


def ortam_yaz(sure_sn, yuk_once, yuk_sonra, satirlar):
    def ilk(komut):
        try:
            return subprocess.run(komut, capture_output=True, text=True
                                  ).stdout.strip().splitlines()[0]
        except (OSError, IndexError):
            return "?"
    model = "?"
    for satir in subprocess.run(["lscpu"], capture_output=True, text=True
                                ).stdout.splitlines():
        if satir.startswith("Model name:"):
            model = satir.split(":", 1)[1].strip()
    metin = (
        "AP-2 Hafta 7 · Haftanın Deneyi — ölçüm ortamı\n"
        f"Tarih          : {datetime.date.today().isoformat()}\n"
        f"İşlemci        : {model}\n"
        f"Çekirdek sayısı: {os.cpu_count()} (sanal makine; ölçüm sırasında "
        "başka süreçler de çalışıyordu)\n"
        f"Yük ortalaması : önce {yuk_once} · sonra {yuk_sonra} "
        "(/proc/loadavg: 1, 5, 15 dk)\n"
        f"İşletim sistemi: {platform.system()} {platform.release()} "
        f"({platform.machine()})\n"
        f"C derleyicisi  : {ilk(['gcc', '--version'])}\n"
        f"C++ derleyicisi: {ilk(['g++', '--version'])}\n"
        f"Python         : {ilk([sys.executable, '--version'])}\n"
        "Bayraklar      : C/C++ -std=c17 / -std=c++17 -Wall -Wextra "
        "-pedantic -O2 (C ayrıca -O0)\n"
        "Yöntem         : 1 ısınma + 5 tekrar (büyük n'de 3; doğrulama "
        "ölçümlerinde 1), ortanca; işlemci zamanı en_cok/en_az > 1,5 ise "
        "en çok 2 kez yineleme\n"
        "Saat           : duvar saati C timespec_get, C++ steady_clock, "
        "Python time.perf_counter; işlemci zamanı C/C++ clock() (1 µs "
        "çözünürlük), Python time.process_time\n"
        "Veri türü      : 32 bitlik işaretsiz anahtarlar (C/C++ uint32_t)\n"
        f"Ölçüm sayısı   : {len(satirlar)} (ikinci oturumda yinelenen: "
        f"{sum(s.get('oturum_sayisi', 1) > 1 for s in satirlar)}; "
        f"CSV'ye ikinci oturumdan alınan: "
        f"{sum(s.get('oturum', 1) == 2 for s in satirlar)})\n"
        "Toplam süre    : işlemci zamanı toplamı (ısınma ve yinelemeler "
        f"dahil, CSV'deki ölçümler) {islemci_toplam(satirlar):.1f} s; "
        "ham kayıtlardan duvar saati toplamı "
        f"{oturum_duvar(1):.1f} s (1. oturum), {oturum_duvar(2):.1f} s "
        f"(2. oturum); bu çalıştırma {sure_sn:.1f} s\n")
    with open(os.path.join(KOK, "OLCUM_ORTAMI.txt"), "w",
              encoding="utf-8") as f:
        f.write(metin)
    print(metin)


def oturum_duvar(oturum):
    """h07_ham.jsonl'deki bir oturumun duvar saati toplamı (s)"""
    ham = os.path.join(SONUC, "h07_ham.jsonl")
    if not os.path.exists(ham):
        return 0.0
    toplam = 0.0
    for satir in open(ham, encoding="utf-8"):
        k = json.loads(satir)
        if k.get("oturum", 1) == oturum and k["ortanca_ms"] != "":
            toplam += (k["tekrar"] + 1) * k["deneme"] * k["ortanca_ms"]
    return toplam / 1000


def islemci_toplam(satirlar):
    return sum((s["tekrar"] + 1) * s["deneme"] * s["islemci_ortanca_ms"]
               for s in satirlar if s["islemci_ortanca_ms"] != "") / 1000


def csv_yaz(ad, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(ALANLAR) + "\n")
        for s in satirlar:
            f.write(";".join(f"{s[a]:.6f}" if isinstance(s[a], float)
                             else str(s[a]) for a in ALANLAR) + "\n")


def anahtar(dil, der, deney, alg, girdi, n, tur):
    return f"{dil}|{der}|{deney}|{alg}|{girdi}|{n}|{tur}"


def secilen(kayitlar):
    """Aynı ölçümün oturumlarından işlemci zamanı ortancası küçük olanı"""
    gecerli = [k for k in kayitlar if k["islemci_ortanca_ms"] != ""]
    if not gecerli:
        return kayitlar[-1]
    return min(gecerli, key=lambda k: k["islemci_ortanca_ms"])


def main():
    hizli = "--hizli" in sys.argv
    ikinci = sys.argv[sys.argv.index("--ikinci-oturum") + 1] \
        if "--ikinci-oturum" in sys.argv else None
    os.makedirs(SONUC, exist_ok=True)
    ham = os.path.join(SONUC, "h07_ham.jsonl")
    baslangic = datetime.datetime.now()
    yuk_once = yuk()
    onceki = {}                        # anahtar -> [oturum kayıtları]
    if ("--devam" in sys.argv or ikinci) and os.path.exists(ham):
        for satir in open(ham, encoding="utf-8"):
            s = json.loads(satir)
            s.setdefault("oturum", 1)
            onceki.setdefault(s["anahtar"], []).append(s)
            yuk_once = s.get("yuk_once", yuk_once)
    elif not hizli and os.path.exists(ham):
        os.remove(ham)
    satirlar = []
    with tempfile.TemporaryDirectory(prefix="h07x_") as gecici:
        ikili = derle(gecici)
        p = plan(hizli)
        for k, (dil, der, deney, alg, girdi, n, tur) in enumerate(p, 1):
            a = anahtar(dil, der, deney, alg, girdi, n, tur)
            eski = onceki.get(a, [])
            yinele = ikinci == dil and all(e["oturum"] == 1 for e in eski)
            if eski and not yinele:
                satirlar.append(dict(secilen(eski),
                                     oturum_sayisi=len(eski)))
                continue
            tekrar = tekrar_sec(dil, alg, n) if deney == "karsilastir" \
                else (3 if n >= 10 ** 7 or (dil == "Python" and n >= 10 ** 6)
                      else 5)
            if tur == "dogrulama":
                tekrar = 1
            s = olc_tutarli(ikili[(dil, der)], deney, alg, girdi, n, tekrar)
            s.update(dil=dil, derleme=der, tur=tur, anahtar=a,
                     yuk_once=yuk_once, oturum=2 if eski else 1)
            if not hizli:
                with open(ham, "a", encoding="utf-8") as f:
                    f.write(json.dumps(s, ensure_ascii=False) + "\n")
            satirlar.append(dict(secilen(eski + [s]),
                                 oturum_sayisi=len(eski) + 1))
            print(f"[{k}/{len(p)}] {dil:<6} {der:<3} {deney:<11} {alg:<13} "
                  f"{str(girdi):<10} n={n:>9} "
                  f"duvar={s['ortanca_ms']!s:>12} "
                  f"işlemci={s['islemci_ortanca_ms']!s:>12} "
                  f"deneme={s['deneme']} oturum={s['oturum']} {s['dogru']}",
                  flush=True)
    if hizli:
        return
    for deney, ad in (("karsilastir", "h07_deney_karsilastirma.csv"),
                      ("aralik", "h07_deney_anahtar_araligi.csv"),
                      ("kurma", "h07_deney_obek_kurma.csv")):
        csv_yaz(ad, [s for s in satirlar if s["deney"] == deney])
    ortam_yaz((datetime.datetime.now() - baslangic).total_seconds(),
              yuk_once, yuk(), satirlar)


if __name__ == "__main__":
    main()

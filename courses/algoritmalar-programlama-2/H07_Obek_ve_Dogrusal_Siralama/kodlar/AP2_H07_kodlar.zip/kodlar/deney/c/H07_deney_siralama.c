/* H07_deney_siralama.c — AP-2 Hafta 7 · Haftanın Deneyi (C)
 * Amaç    : Sıralama algoritmalarının süre ölçümü (sayaçsız sürümler;
 *           algoritmalar Örnek 12 ile aynıdır). Üç deney:
 *   karsilastir ALG TUR N TEKRAR  — 8 algoritma × 4 girdi türü × n
 *   aralik ALG K N TEKRAR         — sayma/taban: anahtar aralığı [0, K)
 *   kurma YONTEM TUR N TEKRAR     — öbek kurma: asagidan | ekleyerek
 *   ALG : secmeli araya_ekleme birlestirmeli hizli obek sayma taban
 *         taban_d (geçiş sayısı K'ya uyarlanır) kutuphane
 *   TUR : rastgele sirali ters tekrarli (kurma: rastgele artan)
 * Çıktı   : stdout'a tek CSV satırı (süreler ms; 1 ısınma + TEKRAR):
 *   deney;algoritma;girdi;n;tekrar;ortanca_ms;en_az_ms;en_cok_ms;dogru;
 *   takas;islemci_ortanca_ms;islemci_en_az_ms;islemci_en_cok_ms
 *   (duvar saati ve işlemci zamanı)
 *   Çıkış kodu 3: uygulanamaz (sayaç dizisi bellek sınırını aşar).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_deney_siralama.c \
 *           ortak_rastgele.c zamanlayici.c -o H07_deney_siralama
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

typedef uint32_t Anahtar;

#define SAYAC_SINIRI (1ULL << 28)      /* en çok 2^28 sayaç (1 GiB) */

/* ---------- Algoritmalar (Örnek 12 ile aynı adımlar, sayaçsız) -------- */
static void takas(Anahtar *x, Anahtar *y)
{
    Anahtar g = *x;
    *x = *y;
    *y = g;
}

static void secmeli_siralama(Anahtar *a, int n)
{
    for (int i = 0; i + 1 < n; i++) {
        int m = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[m]) {
                m = j;
            }
        }
        if (m != i) {
            takas(&a[i], &a[m]);
        }
    }
}

static void araya_ekleme_siralamasi(Anahtar *a, int n)
{
    for (int i = 1; i < n; i++) {
        Anahtar x = a[i];
        int j = i - 1;
        while (j >= 0 && x < a[j]) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}

static void birlestir(Anahtar *a, Anahtar *g, int lo, int orta, int hi)
{
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        g[k++] = a[j] < a[i] ? a[j++] : a[i++];
    }
    while (i < orta) {
        g[k++] = a[i++];
    }
    while (j < hi) {
        g[k++] = a[j++];
    }
    memcpy(a + lo, g + lo, (size_t)(hi - lo) * sizeof *a);
}

static void birlestirmeli_ozyineli(Anahtar *a, Anahtar *g, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli_ozyineli(a, g, lo, orta);
    birlestirmeli_ozyineli(a, g, orta, hi);
    birlestir(a, g, lo, orta, hi);
}

static Anahtar *gecici_dizi = NULL;    /* birleştirme ve taban için */

static void birlestirmeli_siralama(Anahtar *a, int n)
{
    birlestirmeli_ozyineli(a, gecici_dizi, 0, n);
}

static int bolumle(Anahtar *a, int lo, int hi)
{
    int orta = lo + (hi - lo) / 2;
    if (a[orta] < a[lo]) {
        takas(&a[orta], &a[lo]);
    }
    if (a[hi] < a[lo]) {
        takas(&a[hi], &a[lo]);
    }
    if (a[hi] < a[orta]) {
        takas(&a[hi], &a[orta]);
    }
    Anahtar pivot = a[orta];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {
            i++;
        } while (a[i] < pivot);
        do {
            j--;
        } while (pivot < a[j]);
        if (i >= j) {
            return j;
        }
        takas(&a[i], &a[j]);
    }
}

static void hizli_ozyineli(Anahtar *a, int lo, int hi)
{
    while (lo < hi) {
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            hizli_ozyineli(a, lo, p);
            lo = p + 1;
        } else {
            hizli_ozyineli(a, p + 1, hi);
            hi = p;
        }
    }
}

static void hizli_siralama(Anahtar *a, int n)
{
    hizli_ozyineli(a, 0, n - 1);
}

static long long asagi_suz(Anahtar *a, int n, int i)
{
    long long t = 0;
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c] < a[c + 1]) {
            c++;
        }
        if (!(a[i] < a[c])) {
            break;
        }
        takas(&a[i], &a[c]);
        t++;
        i = c;
    }
    return t;
}

static long long obek_kur(Anahtar *a, int n)       /* aşağıdan yukarıya */
{
    long long t = 0;
    for (int i = n / 2 - 1; i >= 0; i--) {
        t += asagi_suz(a, n, i);
    }
    return t;
}

static long long obek_kur_ekleyerek(Anahtar *a, int n)   /* yukarı süzme */
{
    long long t = 0;
    for (int i = 1; i < n; i++) {
        int j = i;
        while (j > 0 && a[(j - 1) / 2] < a[j]) {
            takas(&a[j], &a[(j - 1) / 2]);
            t++;
            j = (j - 1) / 2;
        }
    }
    return t;
}

static void obek_siralamasi(Anahtar *a, int n)
{
    obek_kur(a, n);
    for (int son = n - 1; son > 0; son--) {
        takas(&a[0], &a[son]);
        asagi_suz(a, son, 0);
    }
}

/* anahtarlar 0 .. k-1; sayaç dizisi k elemanlı */
static void sayma_siralamasi(Anahtar *a, int n, uint64_t k)
{
    uint32_t *sayac = calloc((size_t)k, sizeof *sayac);
    if (sayac == NULL) {
        exit(3);
    }
    for (int i = 0; i < n; i++) {
        sayac[a[i]]++;
    }
    int j = 0;
    for (uint64_t v = 0; v < k; v++) {
        for (uint32_t c = 0; c < sayac[v]; c++) {
            a[j++] = (Anahtar)v;
        }
    }
    free(sayac);
}

/* gecis_sayisi bayt geçişi (4: tam 32 bit; çift değilse sonuç kopyalanır) */
static void taban_siralamasi(Anahtar *a, int n, int gecis_sayisi)
{
    Anahtar *kaynak = a, *hedef = gecici_dizi;
    for (int d = 0; d < gecis_sayisi; d++) {
        int kaydir = 8 * d;
        int onek[256] = {0};
        for (int i = 0; i < n; i++) {
            onek[(kaynak[i] >> kaydir) & 0xFF]++;
        }
        for (int v = 1; v < 256; v++) {
            onek[v] += onek[v - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            hedef[--onek[(kaynak[i] >> kaydir) & 0xFF]] = kaynak[i];
        }
        Anahtar *g = kaynak;
        kaynak = hedef;
        hedef = g;
    }
    if (kaynak != a) {
        memcpy(a, kaynak, (size_t)n * sizeof *a);
    }
}

static int artan(const void *x, const void *y)
{
    Anahtar p = *(const Anahtar *)x, q = *(const Anahtar *)y;
    return (p > q) - (p < q);
}

static void kutuphane_siralamasi(Anahtar *a, int n)
{
    qsort(a, (size_t)n, sizeof *a, artan);
}

/* ---------- Girdiler ---------- */
static Anahtar rastgele_u32(void)
{
    uint32_t ust = rastgele_sayi() >> 15;
    uint32_t alt = rastgele_sayi() >> 15;
    return (ust << 16) | alt;
}

/* karsilastir: Örnek 12 ile aynı girdiler (anahtarlar 0..999999 / 0..9) */
static void girdi_uret(Anahtar *a, int n, const char *tur)
{
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        if (strcmp(tur, "rastgele") == 0) {
            a[i] = (Anahtar)rastgele_aralik(0, 999999);
        } else if (strcmp(tur, "sirali") == 0) {
            a[i] = (Anahtar)((long long)i * 1000000 / n);
        } else if (strcmp(tur, "ters") == 0) {
            a[i] = (Anahtar)((long long)(n - 1 - i) * 1000000 / n);
        } else {
            a[i] = (Anahtar)rastgele_aralik(0, 9);
        }
    }
}

static int gecis_icin(uint64_t k)      /* k - 1'i taşıyan bayt sayısı */
{
    int d = 1;
    while (d < 4 && (k - 1) >> (8 * d) != 0) {
        d++;
    }
    return d;
}

/* ---------- Ölçüm ---------- */
typedef struct {
    const char *alg;
    uint64_t k;
    const char *tur;
    long long takas;
} Is;

static void calistir(const Is *is, Anahtar *a, int n, long long *takas_say)
{
    const char *s = is->alg;
    if (strcmp(s, "secmeli") == 0) {
        secmeli_siralama(a, n);
    } else if (strcmp(s, "araya_ekleme") == 0) {
        araya_ekleme_siralamasi(a, n);
    } else if (strcmp(s, "birlestirmeli") == 0) {
        birlestirmeli_siralama(a, n);
    } else if (strcmp(s, "hizli") == 0) {
        hizli_siralama(a, n);
    } else if (strcmp(s, "obek") == 0) {
        obek_siralamasi(a, n);
    } else if (strcmp(s, "sayma") == 0) {
        sayma_siralamasi(a, n, is->k);
    } else if (strcmp(s, "taban") == 0) {
        taban_siralamasi(a, n, 4);
    } else if (strcmp(s, "taban_d") == 0) {
        taban_siralamasi(a, n, gecis_icin(is->k));
    } else if (strcmp(s, "kutuphane") == 0) {
        kutuphane_siralamasi(a, n);
    } else if (strcmp(s, "asagidan") == 0) {
        *takas_say = obek_kur(a, n);
    } else {
        *takas_say = obek_kur_ekleyerek(a, n);
    }
}

static bool obek_mi(const Anahtar *a, int n)
{
    for (int i = 1; i < n; i++) {
        if (a[(i - 1) / 2] < a[i]) {
            return false;
        }
    }
    return true;
}

static int kullanim(const char *ad)
{
    fprintf(stderr, "kullanım: %s karsilastir ALG TUR N TEKRAR | aralik "
            "ALG K N TEKRAR | kurma YONTEM TUR N TEKRAR\n", ad);
    return 2;
}

int main(int argc, char *argv[])
{
    if (argc != 6) {
        return kullanim(argv[0]);
    }
    const char *deney = argv[1];
    char *son;
    long n = strtol(argv[4], &son, 10);
    long tekrar = strtol(argv[5], &son, 10);
    if (n < 2 || n > 100000000 || tekrar < 1 || tekrar > 101) {
        return kullanim(argv[0]);
    }
    Is is = {argv[2], 0, argv[3], -1};
    Anahtar *g = malloc((size_t)n * sizeof *g);
    Anahtar *a = malloc((size_t)n * sizeof *a);
    Anahtar *k = malloc((size_t)n * sizeof *k);
    gecici_dizi = malloc((size_t)n * sizeof *gecici_dizi);
    if (g == NULL || a == NULL || k == NULL || gecici_dizi == NULL) {
        return 1;
    }
    if (strcmp(deney, "karsilastir") == 0) {
        girdi_uret(g, (int)n, is.tur);
        is.k = strcmp(is.tur, "tekrarli") == 0 ? 10 : 1000000;
    } else if (strcmp(deney, "aralik") == 0) {
        is.k = strtoull(argv[3], &son, 10);
        if (is.k < 2 || is.k > (1ULL << 32)) {
            return kullanim(argv[0]);
        }
        if (strcmp(is.alg, "sayma") == 0 && is.k > SAYAC_SINIRI) {
            printf("aralik;sayma;%s;%ld;0;;;;uygulanamaz;;;;\n", argv[3],
                   n);
            return 3;
        }
        rastgele_tohum(42);
        for (long i = 0; i < n; i++) {
            Anahtar x = rastgele_u32();
            g[i] = is.k == (1ULL << 32) ? x : (Anahtar)(x % is.k);
        }
    } else if (strcmp(deney, "kurma") == 0) {
        rastgele_tohum(42);
        for (long i = 0; i < n; i++) {
            g[i] = strcmp(is.tur, "artan") == 0 ? (Anahtar)i
                                                : (Anahtar)rastgele_sayi();
        }
    } else {
        return kullanim(argv[0]);
    }
    memcpy(k, g, (size_t)n * sizeof *g);
    if (strcmp(deney, "kurma") != 0) {
        kutuphane_siralamasi(k, (int)n);              /* kâhin */
    }
    double *t = malloc((size_t)tekrar * sizeof *t);
    double *c = malloc((size_t)tekrar * sizeof *c);
    if (t == NULL || c == NULL) {
        return 1;
    }
    for (int r = -1; r < tekrar; r++) {               /* r = -1: ısınma */
        memcpy(a, g, (size_t)n * sizeof *a);
        double c0 = islemci_sn();
        double t0 = zaman_sn();
        calistir(&is, a, (int)n, &is.takas);
        double t1 = zaman_sn();
        double c1 = islemci_sn();
        if (r >= 0) {
            t[r] = (t1 - t0) * 1000.0;
            c[r] = (c1 - c0) * 1000.0;
        }
    }
    bool dogru = strcmp(deney, "kurma") == 0
                     ? obek_mi(a, (int)n)
                     : memcmp(a, k, (size_t)n * sizeof *a) == 0;
    double en_az = t[0], en_cok = t[0];
    for (int r = 1; r < tekrar; r++) {
        en_az = t[r] < en_az ? t[r] : en_az;
        en_cok = t[r] > en_cok ? t[r] : en_cok;
    }
    double orta = ortanca(t, (int)tekrar);
    printf("%s;%s;%s;%ld;%ld;%.6f;%.6f;%.6f;%s;", deney, is.alg, argv[3], n,
           tekrar, orta, en_az, en_cok, dogru ? "evet" : "HAYIR");
    if (is.takas >= 0) {
        printf("%lld", is.takas);
    }
    double c_az = c[0], c_cok = c[0];
    for (int r = 1; r < tekrar; r++) {
        c_az = c[r] < c_az ? c[r] : c_az;
        c_cok = c[r] > c_cok ? c[r] : c_cok;
    }
    printf(";%.6f;%.6f;%.6f\n", ortanca(c, (int)tekrar), c_az, c_cok);
    free(c);
    free(g);
    free(a);
    free(k);
    free(t);
    free(gecici_dizi);
    return 0;
}

/* Kütüphane karşılığı: C — qsort (kâhin ve "kutuphane" satırı). */

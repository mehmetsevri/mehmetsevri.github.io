#!/usr/bin/env python3
"""h07_cozumle.py — AP-2 Hafta 7 · Haftanın Deneyi: çözümleme

Ham ölçümleri (sonuclar/h07_deney_*.csv) okur; ara proje ölçüm raporunun
tablolarını üretir. Hiçbir sayı elle yazılmaz: her oran, eğim ve kestirim
bu betikte hesaplanır.

Süre ölçütü: İŞLEMCİ ZAMANI ortancası (islemci_ortanca_ms). Ölçüm sırasında
makinede başka süreçler çalıştığından duvar saati, sürecin beklediği süreyi
de içerir (oranı ortam.csv'de). C/C++ clock() çözünürlüğü 1 µs olduğundan
0,05 ms altındaki değerler eğim hesabına alınmaz.

Üretilen dosyalar (sonuclar/):
  h07_ozet_tablo.csv     n = 10^4 ve 10^6 için algoritma × girdi süreleri
                         (C -O2; ölçülmeyen karesel hücreler kestirim)
  h07_ozet_egim.csv      log–log eğimleri (en küçük kareler) ve 10 kat oranı
  h07_ozet_oran.csv      diller ve derleme seçenekleri arası oranlar
  h07_ozet_kestirim.csv  kestirimler ve doğrulama ölçümleriyle sınaması
  h07_ozet_aralik.csv    anahtar aralığına duyarlılık
  h07_ozet_kurma.csv     öbek kurma: takas/n ve eleman başına süre
  h07_ozet_ortam.csv     duvar saati / işlemci zamanı (ortam yükü göstergesi)
Kullanım (deney/ klasöründe): python3 h07_cozumle.py
"""
import csv
import json
import math
import os
import statistics

KOK = os.path.dirname(os.path.abspath(__file__))
SONUC = os.path.join(KOK, "sonuclar")
ALGLAR = ["secmeli", "araya_ekleme", "birlestirmeli", "hizli", "obek",
          "sayma", "taban", "kutuphane"]
TURLER = ["rastgele", "sirali", "ters", "tekrarli"]
KARESEL = {"secmeli", "araya_ekleme"}
ESIK_MS = 0.05


def oku(ad):
    yol = os.path.join(SONUC, ad)
    satirlar = list(csv.DictReader(open(yol, encoding="utf-8"),
                                   delimiter=";"))
    for s in satirlar:
        s["n"] = int(s["n"])
        for a in ("ortanca_ms", "en_az_ms", "en_cok_ms",
                  "islemci_ortanca_ms", "islemci_en_az_ms",
                  "islemci_en_cok_ms"):
            s[a] = float(s[a]) if s[a] not in ("", None) else None
    return satirlar


def yaz(ad, alanlar, satirlar):
    with open(os.path.join(SONUC, ad), "w", encoding="utf-8") as f:
        f.write(";".join(alanlar) + "\n")
        for s in satirlar:
            f.write(";".join(f"{s[a]:.6g}" if isinstance(s[a], float)
                             else str(s[a]) for a in alanlar) + "\n")


def model(alg, girdi, n):
    """Kestirimin büyüme modeli f(n)"""
    if alg in KARESEL:
        return n if (alg == "araya_ekleme" and girdi == "sirali") else n * n
    if alg in ("sayma", "taban"):
        return n
    return n * math.log2(n)


def egim(noktalar):
    """log t = a + b log n en küçük kareler; (b, nokta sayısı)"""
    x = [math.log10(n) for n, t in noktalar]
    y = [math.log10(t) for n, t in noktalar]
    if len(x) < 2:
        return None
    xo, yo = statistics.mean(x), statistics.mean(y)
    pay = sum((a - xo) * (b - yo) for a, b in zip(x, y))
    payda = sum((a - xo) ** 2 for a in x)
    return pay / payda


def main():
    kar = oku("h07_deney_karsilastirma.csv")
    ara = oku("h07_deney_anahtar_araligi.csv")
    kur = oku("h07_deney_obek_kurma.csv")
    t = {}                                  # (dil, der, alg, girdi, n, tür)
    for s in kar:
        t[(s["dil"], s["derleme"], s["algoritma"], s["girdi"], s["n"],
           s["tur"])] = s["islemci_ortanca_ms"]
    dogru = sum(s["dogru"] == "evet" for s in kar + ara + kur
                if s["dogru"] != "uygulanamaz")
    ozet = {"olcum_sayisi": len(kar) + len(ara) + len(kur),
            "dogru_evet": dogru,
            "uygulanamaz": sum(s["dogru"] == "uygulanamaz" for s in ara),
            "yinelenen": sum(int(s["deneme"]) > 1 for s in kar + ara + kur)}

    def olculen(dil, der, alg, girdi, n):
        return t.get((dil, der, alg, girdi, n, "olcum"))

    def en_buyuk_n(dil, der, alg, girdi):
        ns = [k[4] for k in t if k[:4] == (dil, der, alg, girdi)
              and k[5] == "olcum"]
        return max(ns) if ns else None

    def kestir(dil, der, alg, girdi, n):
        n0 = en_buyuk_n(dil, der, alg, girdi)
        t0 = olculen(dil, der, alg, girdi, n0)
        if alg == "sayma":                  # t = α n + β (k sabit)
            ns = sorted(k[4] for k in t if k[:4] == (dil, der, alg, girdi)
                        and k[5] == "olcum")
            n1 = ns[-2]
            t1 = olculen(dil, der, alg, girdi, n1)
            alfa = (t0 - t1) / (n0 - n1)
            return t1 + alfa * (n - n1), n0
        return t0 * model(alg, girdi, n) / model(alg, girdi, n0), n0

    # 1) özet tablo: C -O2, n = 10^4 ve 10^6
    tablo = []
    for n in (10000, 1000000):
        for alg in ALGLAR:
            for g in TURLER:
                v = olculen("C", "-O2", alg, g, n)
                tur = "olcum"
                if v is None:
                    v, _ = kestir("C", "-O2", alg, g, n)
                    tur = "kestirim"
                tablo.append({"n": n, "algoritma": alg, "girdi": g,
                              "islemci_ms": v, "tur": tur})
    yaz("h07_ozet_tablo.csv", ["n", "algoritma", "girdi", "islemci_ms",
                               "tur"], tablo)

    # 2) log–log eğimleri ve on kat oranları (her dil, her girdi)
    egimler = []
    for dil, der in (("C", "-O2"), ("C++", "-O2"), ("Python", "-")):
        for alg in ALGLAR:
            for g in TURLER:
                nok = sorted((k[4], v) for k, v in t.items()
                             if k[:4] == (dil, der, alg, g)
                             and k[5] == "olcum" and v and v >= ESIK_MS)
                if len(nok) < 2:
                    continue
                b = egim(nok)
                son = nok[-1]
                onceki = [p for p in nok if p[0] * 10 == son[0]]
                on_kat = son[1] / onceki[0][1] if onceki else None
                egimler.append({"dil": dil, "derleme": der, "algoritma": alg,
                                "girdi": g, "n_min": nok[0][0],
                                "n_max": son[0], "nokta": len(nok),
                                "egim": b,
                                "on_kat_orani": on_kat if on_kat else "",
                                })
    yaz("h07_ozet_egim.csv", ["dil", "derleme", "algoritma", "girdi",
                              "n_min", "n_max", "nokta", "egim",
                              "on_kat_orani"], egimler)

    # 3) oranlar: C++/C, Python/C, C -O0 / C -O2 (rastgele girdi)
    oranlar = []
    for alg in ALGLAR:
        n = 3000 if alg in KARESEL else 100000
        c = olculen("C", "-O2", alg, "rastgele", n)
        cpp = olculen("C++", "-O2", alg, "rastgele", n)
        py = olculen("Python", "-", alg, "rastgele", n)
        n0 = 10000 if alg in KARESEL else 100000
        c2 = olculen("C", "-O2", alg, "rastgele", n0)
        c0 = olculen("C", "-O0", alg, "rastgele", n0)
        oranlar.append({"algoritma": alg, "n": n, "C_ms": c, "Cpp_ms": cpp,
                        "Python_ms": py, "Cpp_bolu_C": cpp / c,
                        "Python_bolu_C": py / c, "n_O0": n0,
                        "O0_bolu_O2": c0 / c2 if c0 and c2 else ""})
    yaz("h07_ozet_oran.csv", ["algoritma", "n", "C_ms", "Cpp_ms",
                              "Python_ms", "Cpp_bolu_C", "Python_bolu_C",
                              "n_O0", "O0_bolu_O2"], oranlar)

    # 4) kestirimler ve sınaması
    kest = []
    for dil, der in (("C", "-O2"), ("C++", "-O2"), ("Python", "-")):
        for alg in ALGLAR:
            for n in (10 ** 4, 10 ** 5, 10 ** 6, 10 ** 7):
                if olculen(dil, der, alg, "rastgele", n) is not None:
                    continue
                if n < en_buyuk_n(dil, der, alg, "rastgele") if \
                        en_buyuk_n(dil, der, alg, "rastgele") else True:
                    continue
                if en_buyuk_n(dil, der, alg, "rastgele") is None:
                    continue
                v, n0 = kestir(dil, der, alg, "rastgele", n)
                gercek = t.get((dil, der, alg, "rastgele", n, "dogrulama"))
                kest.append({"dil": dil, "derleme": der, "algoritma": alg,
                             "girdi": "rastgele", "n": n, "taban_n": n0,
                             "kestirim_ms": v,
                             "olculen_ms": gercek if gercek else "",
                             "hata_yuzde": (100 * (v - gercek) / gercek
                                            if gercek else ""),
                             "tur": "kestirim sınaması" if gercek
                             else "kestirim"})
    # n log n modelinin C'de 10^7 ile sınanması (ölçülmüş)
    for alg in ("birlestirmeli", "hizli", "obek", "sayma", "taban",
                "kutuphane"):
        t7 = olculen("C", "-O2", alg, "rastgele", 10 ** 7)
        t6 = olculen("C", "-O2", alg, "rastgele", 10 ** 6)
        if t7 and t6:
            if alg == "sayma":              # t = α n + β (10^5 ve 10^6)
                t5 = olculen("C", "-O2", alg, "rastgele", 10 ** 5)
                v = t6 + (t6 - t5) / (10 ** 6 - 10 ** 5) * (10 ** 7 - 10 ** 6)
            else:
                v = t6 * model(alg, "rastgele", 10 ** 7) / \
                    model(alg, "rastgele", 10 ** 6)
            kest.append({"dil": "C", "derleme": "-O2", "algoritma": alg,
                         "girdi": "rastgele", "n": 10 ** 7, "taban_n": 10 ** 6,
                         "kestirim_ms": v, "olculen_ms": t7,
                         "hata_yuzde": 100 * (v - t7) / t7,
                         "tur": "model sınaması (10^6 -> 10^7)"})
    yaz("h07_ozet_kestirim.csv", ["dil", "derleme", "algoritma", "girdi",
                                  "n", "taban_n", "kestirim_ms",
                                  "olculen_ms", "hata_yuzde", "tur"], kest)

    # 5) anahtar aralığı
    aralik = []
    for s in ara:
        k = int(s["girdi"])
        bellek = (4 * k if s["dil"] != "Python" else 8 * k) \
            if s["algoritma"] == "sayma" else ""
        aralik.append({"dil": s["dil"], "derleme": s["derleme"],
                       "n": s["n"], "K": k, "algoritma": s["algoritma"],
                       "islemci_ms": s["islemci_ortanca_ms"]
                       if s["islemci_ortanca_ms"] is not None else "",
                       "durum": s["dogru"], "sayac_bellek_bayt": bellek})
    yaz("h07_ozet_aralik.csv", ["dil", "derleme", "n", "K", "algoritma",
                                "islemci_ms", "durum", "sayac_bellek_bayt"],
        aralik)

    # 6) öbek kurma
    kurma = []
    for s in kur:
        kurma.append({"dil": s["dil"], "n": s["n"], "yontem": s["algoritma"],
                      "girdi": s["girdi"], "takas": int(s["takas"]),
                      "takas_bolu_n": int(s["takas"]) / s["n"],
                      "islemci_ms": s["islemci_ortanca_ms"],
                      "ns_bolu_eleman": 1e6 * s["islemci_ortanca_ms"]
                      / s["n"], "obek": s["dogru"]})
    yaz("h07_ozet_kurma.csv", ["dil", "n", "yontem", "girdi", "takas",
                               "takas_bolu_n", "islemci_ms",
                               "ns_bolu_eleman", "obek"], kurma)

    # 7) ortam: duvar / işlemci (CPU >= 10 ms ölçümler)
    ortam = []
    for dil in ("C", "C++", "Python"):
        r = [s["ortanca_ms"] / s["islemci_ortanca_ms"]
             for s in kar + ara + kur if s["dil"] == dil
             and s["islemci_ortanca_ms"] and s["islemci_ortanca_ms"] >= 10]
        ortam.append({"dil": dil, "olcum": len(r),
                      "duvar_bolu_islemci_ortanca": statistics.median(r),
                      "en_az": min(r), "en_cok": max(r)})
    yaz("h07_ozet_ortam.csv", ["dil", "olcum", "duvar_bolu_islemci_ortanca",
                               "en_az", "en_cok"], ortam)
    with open(os.path.join(SONUC, "h07_ozet_sayim.json"), "w",
              encoding="utf-8") as f:
        json.dump(ozet, f, ensure_ascii=False, indent=1)
    print(json.dumps(ozet, ensure_ascii=False))
    for s in ortam:
        print(s)


if __name__ == "__main__":
    main()

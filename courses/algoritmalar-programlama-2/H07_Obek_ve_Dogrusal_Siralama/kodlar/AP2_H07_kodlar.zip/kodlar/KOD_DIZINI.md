# Hafta 7 · Kod dizini (kodlar/)

Bu klasördeki her kod dosyası; türü, düzeyi, amacı, beklenen çıktısı ve materyalde geçtiği yerlerle aşağıdadır. **Ders notu** sütunu bölüm numarası (Ek A: dil karşılıkları), **Sunum** slayt numarası, **Web** sayfadaki bölümdür. Ortam: gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, Python 3.11.15 (örnekler 3.10 uyumludur).

Derleme: `gcc -std=c17 -Wall -Wextra -pedantic -O2 DOSYA.c [ortak_rastgele.c] [zamanlayici.c] -o program -lm` · `g++ -std=c++17 -Wall -Wextra -pedantic -O2 DOSYA.cpp -o program` · `python3 DOSYA.py`. `-lm` yalnızca `log2` kullanan örneklerde gerekir (Örnek 3, 4, 5, 6, 7, 10, 13).

Eşdeğerlik: `python3 esdeger_test.py .` → **13/13 GEÇTİ** (13 “=”: üç dilde bayt bayt aynı stdout), derleyici uyarısı 0, sütun aşımı 0; `--asan` (AddressSanitizer + UBSan) ile de 13/13 GEÇTİ.


## 1. Örnek merdiveni (c/, cpp/, python/)

| Kök | Düzey | Tür | Amiral | Başlık | Argüman | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|---|
| `H07_01_dizi_agac` | ★ | = | — | Dizi ↔ ağaç: ebeveyn (i − 1)/2, çocuklar 2i + 1 ve 2i + 2; öbeğin ağaç biçiminde yazdırılması | — | 1.1, 3.1, 3.2, 4.1, Ek A.1 | 18 | Dizideki ağaç, Ekleme ve çıkarma, Merdiven |
| `H07_02_obek_mi` | ★ | = | — | Öbek özelliği denetimi (is_heap): ilk ihlal, karşılaştırma sayısı; 1..n'nin kaç permütasyonu öbektir? | — | 1.1, 3.2, 5.1, Ek A.2 | 11 | Dizideki ağaç, Merdiven |
| `H07_03_ekle_cikar` | ★★ | = | evet | En büyük öbeğe ekleme (yukarı süzme) ve en büyüğü çıkarma (aşağı süzme); işlem başına ortalama takas | — | 1.1, 4.1, 4.3, 11.1, 11.5, 11.8, Ek A.3 | 18, 19 | Ekleme ve çıkarma, Öbek sıralaması, Merdiven |
| `H07_04_obek_kur` | ★★ | = | evet | Aşağıdan yukarıya öbek kurma ve takas sayısı (O(n) deneyi; Σ yükseklik = n − popcount(n)) | [n_ust=100000] | 1.1, 4.2, 11.2, Ek A.4 | — | Ekleme ve çıkarma, Öbek kurma, Merdiven, Alıştırmalar |
| `H07_05_obek_siralamasi` | ★★ | = | evet | Öbek sıralaması: yerinde, en kötü durumda O(n log n); kararsızlık gösterimi | [n_ust=10000] | 1.1, 2, 4.3, 11.4, Ek A.5 | 26 | Öbek sıralaması, Merdiven, Quiz, Alıştırmalar |
| `H07_06_ilk_k` | ★★ | = | — | Öncelik kuyruğuyla ilk-k en yüksek not: boyutu k olan en küçük öbek, O(n log k) | — | 1.1, 4.1, 5.2, 8, Ek A.6 | — | Öncelik kuyruğu, Merdiven, Vize bankası |
| `H07_07_k_yollu_birlestirme` | ★★★ | = | — | k sıralı listenin en küçük öbekle birleştirilmesi (çok yollu birleştirme, O(N log k)) | — | 1.1, 4.1, 5.3, Ek A.7 | 29 | Öncelik kuyruğu, Merdiven |
| `H07_08_sayma_siralamasi` | ★ | = | evet | Sayma sıralaması (0–100 notlar): değeri indis olarak kullanma; not dağılımı | — | 1.1, 4.4, Ek A.8, Ek A.12 | 34 | Sayma, Merdiven, Alıştırmalar |
| `H07_09_kararli_sayma` | ★★ | = | evet | Kararlı sayma sıralaması: kayıtlar, sıklık dizisi ve önek toplam; yerleştirme yönünün önemi | — | 1.1, 4.4, 11.3, Ek A.9 | — | Sayma, Merdiven, Quiz |
| `H07_10_taban_siralamasi` | ★★★ | = | evet | Taban sıralaması (LSD): 32 bitlik işaretsiz tamsayılar bayt bayt (256 tabanı, 4 geçiş) | — | 1.1, 4.5, 11.1, 11.2, Ek A.10 | 38 | Sayma, Taban, Merdiven, Vize bankası |
| `H07_11_kova_siralamasi` | ★★ | = | evet | Kova sıralaması: [0, 1) aralığındaki değerler; dağılım varsayımı | — | 4.6, Ek A.11 | — | Sayma, Kova, Merdiven |
| `H07_12_siralama_karsilastirma` | ★★★ | = | — | Sıralama karşılaştırma deneyi: sekiz algoritma × dört girdi türü × n (ara proje raporunun omurgası) | [olc [n] [tekrar]] | 1.1, 3.4, 5.4, 6, 10.4, Ek A.12 | 45 | Merdiven, Deney, Ara proje |
| `H07_13_akan_ortanca` | ★★★ | = | — | Akan veride ortanca: iki öbek (en büyük + en küçük) — merak | — | 4.1, 5, 13, Ek A.13 | 50 | Merdiven, Merak |

Her kök için üç dosya: `c/KÖK.c`, `cpp/KÖK.cpp`, `python/KÖK.py`; beklenen çıktı `ciktilar/KÖK.txt`. C++/Python'da C'den anlam olarak farklılaşan satırlar ve Dil Penceresi notu `ornekler.json` → `farklar`, `dil_notu`.

Ortak modüller (dersin ortak kod kopyası, değiştirilmedi): `c/ortak_rastgele.h/.c`, `c/zamanlayici.h/.c`, `cpp/ortak_rastgele.hpp`, `cpp/zamanlayici.hpp`, `python/ortak_rastgele.py`, `python/zamanlayici.py`; `esdeger_test.py`. Kullananlar: ortak_rastgele — Örnek 3–13; zamanlayici — Örnek 12 (`olc` kipi).


## 2. Kavram programları (kavram/)

Merdiven dışı küçük programlar: kütüphane karşılıkları, alt sınır tablosu, kararlılık sözleşmesi. Çıktılar `kavram/ciktilar/`.

| Dosya | Dil | Amaç | Ders notu | Sunum | Web |
|---|---|---|---|---|---|
| `kavram/H07_K01_priority_queue.cpp` | C++ | std::priority_queue varsayılan olarak EN BÜYÜK öbektir; en küçük öbek için std::greater karşılaştırıcısı verilir. İlk-k (boyutu k olan en küçük öbek) kütüphaneyle. | 8 | — | Dil Penceresi |
| `kavram/H07_K02_make_heap.cpp` | C++ | std::make_heap / push_heap / pop_heap / sort_heap ile bir vektör üzerinde öbek işlemleri ve std::is_heap denetimi (kütüphane karşılığı; Örnek 4 ve 5'te öbek elle yazılır) | 4.1, 4.2, 4.3 | — | Öbek kurma |
| `kavram/H07_K03_heapq.py` | Python | heapq, bir Python listesini EN KÜÇÜK öbek olarak kullanır (heap[0] en küçük). En büyük öbek için -x hilesi; eşit önceliklerde sıra numarası (öncelik, sıra, veri) demetleri. | 8 | — | Dil Penceresi |
| `kavram/H07_K04_alt_sinir.c` | C | Karşılaştırmalı sıralamanın alt sınırı: n elemanın n! permütasyonunun HER BİRİ araya ekleme ve birleştirmeli sıralamayla sıralanır; en kötü karşılaştırma sayısı ceil(log2 n!) ile karşılaştırılır (n = 1..8) | 2, 3.4 | 4 | Geçen haftadan, Alt sınır |
| `kavram/H07_K05_kararlilik.py` | Python | sorted ve list.sort KARARLIDIR (Timsort): eşit anahtarlı kayıtların girdi sırası korunur. Bu yüzden iki kararlı geçiş, çok anahtarlı sıralama verir — taban (LSD) sıralamasının fikri: önce İKİNCİL anahtara, sonra BİRİNCİL anahtara göre sırala. | 8 | — | Dil Penceresi |
| `kavram/H07_K06_stable_sort.cpp` | C++ | std::stable_sort kararlıdır; std::sort kararlılık güvencesi vermez. 200 kayıt (anahtar 0..4, sıra numarasıyla) iki yöntemle sıralanır ve eşit anahtarlıların sırası denetlenir. | 8 | — | Dil Penceresi |
| `kavram/H07_K07_oncelik_kuyrugu.c` | C | Öncelik kuyruğu SOYUT VERİ TÜRÜ: kullanıcı yalnızca işlemleri (ekle, en_buyuk, cikar, bos_mu) görür; içeride dizi tabanlı en büyük öbek vardır. Kapasite dolunca dizi iki katına büyütülür (realloc; dinamik diziler Hafta 8'in konusudur). | 3.2, 8, 13 | 49 | Dizideki ağaç, Dil Penceresi, Merak |

## 3. Hata Avcısı (hata_avcisi/)

Kasıtlı hatalı dosyaların başlığında “BU DOSYA KASITLI HATA İÇERİR” yazar; tümü uyarısız derlenir (hata mantıksaldır; HA4'ün C sürümü tanımsız davranıştır, açıkça işaretlidir). Bu makinede gözlenen belirtiler `hata_avcisi/ciktilar/` altındadır.

| Dosya | Dil | Tür | Hata / belirti | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `hata_avcisi/H07_HA1_bir_tabanli_indis.c` | C | kasıtlı hata | 0/1 tabanlı indis karışıklığı: çocuklar 2i, 2i + 1 → çıkarma sırası bozuk; yalnız ebeveyn i / 2 → 10 000 rastgele dizinin bir kısmında bozuk öbek | `ciktilar/H07_HA1_bir_tabanli_indis.txt` | 5.1, 7 | 47 | Hata Avcısı |
| `hata_avcisi/H07_HA1_bir_tabanli_indis_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H07_HA1_bir_tabanli_indis_duzeltilmis.txt` | 5.1, 7 | 47 | Hata Avcısı |
| `hata_avcisi/H07_HA2_ilk_cocuk.c` | C | kasıtlı hata | Aşağı süzmede büyük çocuk yerine ebeveynden büyük İLK çocuk: öbek kurulamıyor, sıralama yanlış | `ciktilar/H07_HA2_ilk_cocuk.txt` | 4.1, 7, 11.8 | 47 | Hata Avcısı, Ekleme ve çıkarma, Quiz |
| `hata_avcisi/H07_HA2_ilk_cocuk_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H07_HA2_ilk_cocuk_duzeltilmis.txt` | 4.1, 7, 11.8 | 47 | Hata Avcısı, Ekleme ve çıkarma, Quiz |
| `hata_avcisi/H07_HA3_bastan_kurma.cpp` | C++ | kasıtlı hata | Öbek kurmayı i = 0'dan başlatmak: kök 63, sıralama yanlış | `ciktilar/H07_HA3_bastan_kurma.txt` | 4.2, 7 | 47 | Hata Avcısı, Öbek kurma |
| `hata_avcisi/H07_HA3_bastan_kurma_duzeltilmis.cpp` | C++ | düzeltilmiş | — | `ciktilar/H07_HA3_bastan_kurma_duzeltilmis.txt` | 4.2, 7 | 47 | Hata Avcısı, Öbek kurma |
| `hata_avcisi/H07_HA4_aralik_disi_anahtar.c` | C | kasıtlı hata | Sayma sıralamasında aralık dışı anahtar (−1, 105): C'de TANIMSIZ DAVRANIŞ (bu çalıştırmada SIGABRT; ASan: heap-buffer-overflow); Python'da −1 sessizce 100 sayılır, 105 IndexError | `ciktilar/H07_HA4_aralik_disi_anahtar_c.txt` | 4.4, 7, 9 | 47 | Hata Avcısı, Vize bankası |
| `hata_avcisi/H07_HA4_aralik_disi_anahtar_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H07_HA4_aralik_disi_anahtar_duzeltilmis_c.txt` | 4.4, 7, 9 | 47 | Hata Avcısı, Vize bankası |
| `hata_avcisi/H07_HA4_aralik_disi_anahtar.py` | Python | kasıtlı hata | Sayma sıralamasında aralık dışı anahtar (−1, 105): C'de TANIMSIZ DAVRANIŞ (bu çalıştırmada SIGABRT; ASan: heap-buffer-overflow); Python'da −1 sessizce 100 sayılır, 105 IndexError | `ciktilar/H07_HA4_aralik_disi_anahtar_py.txt` | 4.4, 7, 9 | 47 | Hata Avcısı, Vize bankası |
| `hata_avcisi/H07_HA4_aralik_disi_anahtar_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H07_HA4_aralik_disi_anahtar_duzeltilmis_py.txt` | 4.4, 7, 9 | 47 | Hata Avcısı, Vize bankası |
| `hata_avcisi/H07_HA5_kararsiz_gecis.c` | C | kasıtlı hata | Taban sıralamasında kararsız geçiş (soldan sağa yerleştirme): 135 214 207 … — sıralı değil | `ciktilar/H07_HA5_kararsiz_gecis.txt` | 4.5, 7 | 47, 48 | Taban, Hata Avcısı, Quiz |
| `hata_avcisi/H07_HA5_kararsiz_gecis_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H07_HA5_kararsiz_gecis_duzeltilmis.txt` | 4.5, 7 | 47, 48 | Taban, Hata Avcısı, Quiz |
| `hata_avcisi/H07_HA6_heapq_en_kucuk.py` | Python | kasıtlı hata | Python heapq'nun en küçük öbek olduğunu unutmak: “en yüksek 3 not” yerine [45, 52, 63] | `ciktilar/H07_HA6_heapq_en_kucuk.txt` | 7 | 47 | Hata Avcısı |
| `hata_avcisi/H07_HA6_heapq_en_kucuk_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H07_HA6_heapq_en_kucuk_duzeltilmis.txt` | 7 | 47 | Hata Avcısı |
| `hata_avcisi/H07_HA7_isaretli_taban.c` | C | kasıtlı hata | İşaretli sayıları işaretsiz gibi taban sıralamasına sokmak: negatifler sona düşer | `ciktilar/H07_HA7_isaretli_taban_c.txt` | 4.5, 7, 8, Ek A.10 | 47 | Hata Avcısı, Dil Penceresi, Vize bankası, Quiz |
| `hata_avcisi/H07_HA7_isaretli_taban_duzeltilmis.c` | C | düzeltilmiş | — | `ciktilar/H07_HA7_isaretli_taban_duzeltilmis_c.txt` | 4.5, 7, 8, Ek A.10 | 47 | Hata Avcısı, Dil Penceresi, Vize bankası, Quiz |
| `hata_avcisi/H07_HA7_isaretli_taban.py` | Python | kasıtlı hata | İşaretli sayıları işaretsiz gibi taban sıralamasına sokmak: negatifler sona düşer | `ciktilar/H07_HA7_isaretli_taban_py.txt` | 4.5, 7, 8, Ek A.10 | 47 | Hata Avcısı, Dil Penceresi, Vize bankası, Quiz |
| `hata_avcisi/H07_HA7_isaretli_taban_duzeltilmis.py` | Python | düzeltilmiş | — | `ciktilar/H07_HA7_isaretli_taban_duzeltilmis_py.txt` | 4.5, 7, 8, Ek A.10 | 47 | Hata Avcısı, Dil Penceresi, Vize bankası, Quiz |

## 4. Alıştırmalar (alistirmalar/)

Ders notu Bölüm 11'deki kodlu alıştırmalar; önce çalıştırmadan tahmin edin. Hata bulma dosyaları kasıtlı hatalıdır; Parsons dosyası bu hâliyle derlenmez (tamamlanacak). Çözümler öğretim üyesindedir.

| Dosya | Alıştırma | Dil | Amaç | Çıktı dosyası | Ders notu | Sunum | Web |
|---|---|---|---|---|---|---|---|
| `alistirmalar/H07_A01_cikti_tahmini.c` | 7.1 | C | Çıktı tahmini — boş bir en büyük öbeğe altı değer sırayla eklenir (yukarı süzme). Çalıştırmadan önce son diziyi ve toplam takas sayısını kâğıt üzerinde bulun. | `ciktilar/H07_A01_cikti_tahmini.txt` | 11.1 | — | Alıştırmalar |
| `alistirmalar/H07_A02_hata_bul_obek_siralamasi.c` | 7.7 | C | BU DOSYA KASITLI HATA İÇERİR: Örnek 5'in girdisi sıralanmak isteniyor, ama çıktı sıralı değil. Hatalı satırı bulun ve düzeltin (Örnek 5 ile karşılaştırın). | `ciktilar/H07_A02_hata_bul_obek_siralamasi.txt` | 11.4 | — | Alıştırmalar |
| `alistirmalar/H07_A03_hata_bul_onek.c` | 7.8 | C | BU DOSYA KASITLI HATA İÇERİR: kararlı sayma sıralaması anahtarları 0..k olan kayıtları sıralamalı; çıktıda bazı kayıtlar kayboluyor, bazı konumlar boş kalıyor. Hatalı satırı bulun (Örnek 9 ile karşılaştırın). | `ciktilar/H07_A03_hata_bul_onek.txt` | 11.4 | — | Alıştırmalar |
| `alistirmalar/H07_A04_parsons_asagi_suz.c` | 7.9 | C | Tamamlanacak; bu hâliyle derlenmez: aşağıdaki satırlar en büyük öbekte aşağı süzme fonksiyonunun KARIŞTIRILMIŞ satırlarıdır (iki satır fazladır: kullanılmayacak). Doğru sıraya dizin, girintiyi düzeltin; Örnek 3'ün çıkarma adımlarıyla aynı takasları yapmalı. | — (derlenmez) | 11.5 | — | Alıştırmalar |
| `alistirmalar/H07_A05_heapq_okuma.py` | 7.13 | Python | Diller arası okuma — çalıştırmadan önce dört print satırının çıktısını yazın; heapq listesinin İÇ düzenine dikkat edin. | `ciktilar/H07_A05_heapq_okuma.txt` | 11.7 | — | Alıştırmalar |
| `alistirmalar/H07_A06_priority_queue_okuma.cpp` | 7.14 | C++ | Diller arası okuma — std::pair'ler (öncelik, geliş sırası) önce ilk alana, eşitse ikinci alana göre karşılaştırılır. Çalıştırmadan önce çıktıyı yazın. | `ciktilar/H07_A06_priority_queue_okuma.txt` | 11.7 | — | Alıştırmalar |

## 5. Quiz ve vize hazırlık soru bankası (quiz/)

Q01–Q02 haftalık quiz'in, Q11–Q47 web sayfasındaki vize hazırlık soru bankasının (H1–H7) kodlu sorularıdır; çıktılar `quiz/ciktilar/`. Adında `_bos` geçen dosyalar Parsons / kod tamamlama sorularının iskeletidir (seçeneklerden biri yerleştirilerek derlenir; çıktı dosyası yoktur).

| Dosya | Dil | Amaç | Çıktı | Web |
|---|---|---|---|---|
| `quiz/H07_Q01_obek_islemleri.c` | C | Haftalık quizin üç öbek sorusunu programla doğrular: (1) Örnek 1'in öbeğine 89 eklemek, (2) aynı öbekten en büyüğü çıkarmak, (3) artan 15 elemanı aşağıdan yukarıya öbek yapmak. | `ciktilar/H07_Q01_obek_islemleri.txt` | yanıt doğrulaması |
| `quiz/H07_Q02_kaydirma.c` | C | H07_Q02_kaydirma.py'nin C karşılığı: -5, 32 bitlik işaretsiz tamsayıya çevrilip (mod 2^32, tanımlı) en üst baytı alınır. | `ciktilar/H07_Q02_kaydirma_c.txt` | Quiz |
| `quiz/H07_Q02_kaydirma.py` | Python | Negatif bir tamsayıyı sağa kaydırmak Python'da ne verir? Aynı bayt çıkarma işlemi C'de uint32_t ile (H07_Q02_kaydirma.c). | `ciktilar/H07_Q02_kaydirma_py.txt` | Quiz |
| `quiz/H07_Q11_h1_oklid.c` | C | Öklid algoritmasının döngüsünü izleyin: ebob(252, 105) kaç yinelemede biter ve sonuç nedir? | `ciktilar/H07_Q11_h1_oklid.txt` | Vize bankası |
| `quiz/H07_Q12_h1_ikinci_en_buyuk.c` | C | İkinci en büyük elemanı bulan döngünün değişmezi. Program dört aday ifadeyi rastgele dizilerde her yinelemenin BAŞINDA sınar ve kaç kez yanlış olduklarını sayar. | `ciktilar/H07_Q12_h1_ikinci_en_buyuk.txt` | Vize bankası |
| `quiz/H07_Q13_h1_hatali_en_buyuk.c` | C | Başlangıç değeri hatalı "en büyük" fonksiyonu hangi girdide yanlış sonuç verir? Program dört aday girdiyi doğru sürümle karşılaştırır. | `ciktilar/H07_Q13_h1_hatali_en_buyuk.txt` | Vize bankası |
| `quiz/H07_Q14_h1_bolme.c` | C | H07_Q14_h1_bolme.py'nin C karşılığı: C99'dan beri tamsayı bölmesi sıfıra doğru keser; kalan bölünenin işaretini alır. | `ciktilar/H07_Q14_h1_bolme_c.txt` | Vize bankası |
| `quiz/H07_Q14_h1_bolme.py` | Python | Negatif sayılarda tamsayı bölmesi ve kalan: Python // aşağı yuvarlar; C karşılığı: H07_Q14_h1_bolme.c | `ciktilar/H07_Q14_h1_bolme_py.txt` | Vize bankası |
| `quiz/H07_Q15_h1_faktoriyel.c` | C | int (32 bit) ile faktöriyel hangi n'de ilk kez taşar? İşaretli taşma TANIMSIZ DAVRANIŞTIR; program taşmayı çarpmadan ÖNCE long long ile denetler (taşan çarpma hiç yapılmaz). | `ciktilar/H07_Q15_h1_faktoriyel.txt` | Vize bankası |
| `quiz/H07_Q16_h1_dogrusal_bos.c` | C | Tamamlanacak; bu hâliyle derlenmez: doğrusal arama x'in İLK konumunu, x yoksa -1 döndürmeli ("bulunamadı" sözleşmesi). İki boşluğu doldurun. | — | Vize bankası |
| `quiz/H07_Q17_h2_harmonik.c` | C | İç döngü adımı i olan iç içe döngünün işlem sayısı hangi sınıftadır? Program sayacı birkaç n için yazar ve n ln n ile oranlar; n iki katına çıkınca sayacın kaç katına çıktığını verir. | `ciktilar/H07_Q17_h2_harmonik.txt` | Vize bankası |
| `quiz/H07_Q18_h2_hizli_us.c` | C | Yinelemeli hızlı üs alma (sağdan sola ikili yöntem): us_mod (3, 13, 1000) sonucu ve çarpma sayısı; dört aday değişmezin her yinelemenin BAŞINDA doğru olup olmadığı sınanır. | `ciktilar/H07_Q18_h2_hizli_us.txt` | Vize bankası |
| `quiz/H07_Q19_h2_asal.c` | C | Deneme bölmesinde döngü koşulu d * d <= n olmalıdır. Hatalı koşulla (d * d < n) dört aday sayı sınanır. | `ciktilar/H07_Q19_h2_asal.txt` | Vize bankası |
| `quiz/H07_Q20_h2_tasma.c` | C | 64 bitlik işaretsiz tamsayıda 2^64: işaretsiz taşma 2^64 modunda TANIMLIDIR. Python karşılığı: H07_Q20_h2_tasma.py | `ciktilar/H07_Q20_h2_tasma_c.txt` | Vize bankası |
| `quiz/H07_Q20_h2_tasma.py` | Python | H07_Q20_h2_tasma.c'nin Python karşılığı: tamsayı sınırsızdır. | `ciktilar/H07_Q20_h2_tasma_py.txt` | Vize bankası |
| `quiz/H07_Q21_h2_kadane_bos.c` | C | Tamamlanacak; bu hâliyle derlenmez: Kadane algoritması en büyük toplamlı bitişik alt dizinin toplamını Θ(n)'de bulur. Boş satırı doldurun. | — | Vize bankası |
| `quiz/H07_Q22_h3_fib.c` | C | Özyinelemeli Fibonacci'de fib(6) değeri ve toplam çağrı sayısı (özyineleme ağacının düğüm sayısı). | `ciktilar/H07_Q22_h3_fib.txt` | Vize bankası |
| `quiz/H07_Q23_h3_hanoi.c` | C | T(n) = 2T(n - 1) + 1, T(0) = 0 bağıntısını hamle sayacıyla doğrulamak: n = 1..20 için sayaç 2^n - 1 mi? | `ciktilar/H07_Q23_h3_hanoi.txt` | Vize bankası |
| `quiz/H07_Q24_h3_permutasyon_bos.c` | C | Tamamlanacak; bu hâliyle derlenmez: kullanildi dizisiyle permütasyon üretimi (seç -> dene -> geri al). n = 3 için 6 permütasyon sözlük sırasında yazılmalı. Boş satırı doldurun. | — | Vize bankası |
| `quiz/H07_Q25_h3_kopya.py` | Python | Geri izlemede çözümü saklarken listenin KENDİSİNİ eklemek ile kopyasını eklemek arasındaki fark (başvuru semantiği). | `ciktilar/H07_Q25_h3_kopya.txt` | Vize bankası |
| `quiz/H07_Q26_h3_budama.c` | C | "toplam > hedef ise dur" budaması hangi girdide bir çözümü kaçırır? Dört aday girdide budamalı ve kaba kuvvet sürümlerin bulduğu çözüm sayıları karşılaştırılır. | `ciktilar/H07_Q26_h3_budama.txt` | Vize bankası |
| `quiz/H07_Q27_h4_ikili_arama.c` | C | Kapalı aralıkta ikili arama: (1) Hafta 4'ün 16 elemanlı dizisinde x = 61 için yoklanan değerler; (2) n = 10^6 elemanlı a[i] = 2i + 1 dizisinde başarısız aramaların en çok yoklaması. | `ciktilar/H07_Q27_h4_ikili_arama.txt` | Vize bankası |
| `quiz/H07_Q28_h4_lower_bound.c` | C | Yarı açık aralıkta [lo, hi) lower_bound döngüsünün değişmezi. Dört aday ifade rastgele sıralı dizilerde her yinelemenin başında sınanır; ihlal sayıları yazılır. | `ciktilar/H07_Q28_h4_lower_bound.txt` | Vize bankası |
| `quiz/H07_Q29_h4_sonsuz_dongu.c` | C | lo = mid yazılan ikili arama hangi x için sonsuz döngüye girer? Program her aday x'te yineleme sayısını 100 ile sınırlar. | `ciktilar/H07_Q29_h4_sonsuz_dongu.txt` | Vize bankası |
| `quiz/H07_Q30_h4_orta_nokta.c` | C | (lo + hi) / 2 işaretsiz 32 bitte sarar (2^32 modunda tanımlı): orta nokta aralığın DIŞINA düşer. Python: H07_Q30_h4_orta_nokta.py | `ciktilar/H07_Q30_h4_orta_nokta_c.txt` | Vize bankası |
| `quiz/H07_Q30_h4_orta_nokta.py` | Python | H07_Q30_h4_orta_nokta.c'nin Python karşılığı (tamsayı taşmaz). | `ciktilar/H07_Q30_h4_orta_nokta_py.txt` | Vize bankası |
| `quiz/H07_Q31_h5_iki_gecis.c` | C | Hafta 5'in dizisinde seçmeli, araya ekleme ve kabarcık sıralamasının İLK İKİ dış yinelemesinden sonraki durumları. | `ciktilar/H07_Q31_h5_iki_gecis.txt` | Vize bankası |
| `quiz/H07_Q32_h5_ters_cevrim.c` | C | Araya ekleme sıralamasının kaydırma sayısı dizinin ters çevrim sayısına eşittir. Hafta 5'in dizisinde ikisi de sayılır. | `ciktilar/H07_Q32_h5_ters_cevrim.txt` | yanıt doğrulaması |
| `quiz/H07_Q33_h5_degismez.c` | C | Seçmeli ve araya ekleme sıralamasının dış döngü değişmezleri. Dört aday ifade (A–D) iki algoritmada, rastgele dizilerde her dış yinelemenin BAŞINDA sınanır; ihlal sayıları yazılır. | `ciktilar/H07_Q33_h5_degismez.txt` | yanıt doğrulaması |
| `quiz/H07_Q34_h5_kabarcik_kararlilik.c` | C | Kabarcık sıralamasında hangi değişiklik KARARLILIĞI bozar? Dört değişiklik (A–D) eşit anahtarlı kayıtlarda denenir; her biri için "sıralı mı / kararlı mı" yazılır. | `ciktilar/H07_Q34_h5_kabarcik_kararlilik.txt` | Vize bankası |
| `quiz/H07_Q35_h5_sorted.py` | Python | sorted kararlıdır: eşit puanlı kayıtlar girdi sırasında kalır. | `ciktilar/H07_Q35_h5_sorted.txt` | Vize bankası |
| `quiz/H07_Q36_h5_k_sirali.c` | C | Her elemanı sıralı konumundan en çok 3 uzakta olan n = 2000 elemanlı dizide dört yöntemin karşılaştırma sayısı. | `ciktilar/H07_Q36_h5_k_sirali.txt` | yanıt doğrulaması |
| `quiz/H07_Q37_h5_araya_bos.c` | C | Tamamlanacak; bu hâliyle derlenmez: araya ekleme sıralamasının iç döngü koşulunu tamamlayın (artan, kararlı sıralama). | — | Vize bankası |
| `quiz/H07_Q38_h6_lomuto.c` | C | (1) Hafta 6'nın dizisinde Lomuto bölümlemesinin sonucu (pivot a[hi], a[j] < pivot); (2) sıralı n = 1000 girdide son eleman pivotlu hızlı sıralamanın karşılaştırma sayısı. | `ciktilar/H07_Q38_h6_lomuto.txt` | Vize bankası |
| `quiz/H07_Q39_h6_birlestirme.c` | C | İki sıralı dizinin birleştirilmesinde ana döngünün değişmezi. Dört aday ifade (A–D) rastgele girdilerde her yinelemenin BAŞINDA sınanır; ihlal sayıları yazılır. | `ciktilar/H07_Q39_h6_birlestirme.txt` | yanıt doğrulaması |
| `quiz/H07_Q40_h6_birlestirme_kararlilik.c` | C | Birleştirmeli sıralamada hangi değişiklik sonucu SIRALI bırakıp KARARLILIĞI bozar? Dört değişiklik (A–D) eşit anahtarlı kayıtlarda denenir. | `ciktilar/H07_Q40_h6_birlestirme_kararlilik.txt` | yanıt doğrulaması |
| `quiz/H07_Q41_h6_quickselect_bos.c` | C | Tamamlanacak; bu hâliyle derlenmez: quickselect, k. en küçüğü (0 tabanlı) bulur. bolumle Lomuto'dur: a[p] son yerine oturur. Boş satırı doldurun. | — | Vize bankası |
| `quiz/H07_Q42_h6_ozyineleme.c` | C | H07_Q42_h6_ozyineleme.py'nin C karşılığı: aynı algoritma sıralı 3000 elemanda ≈ 3000 derinliğe iner; C'de her çerçeve küçük olduğundan 8 MB'lık yığına sığar (bu derleyicide, -O2). | `ciktilar/H07_Q42_h6_ozyineleme_c.txt` | Vize bankası |
| `quiz/H07_Q42_h6_ozyineleme.py` | Python | Lomuto bölümlemeli, iki özyinelemeli çağrılı hızlı sıralama sıralı 3000 elemanda ne yapar? (Özyineleme derinliği ≈ n.) C karşılığı: H07_Q42_h6_ozyineleme.c | `ciktilar/H07_Q42_h6_ozyineleme_py.txt` | Vize bankası |
| `quiz/H07_Q43_h6_tekrarli.c` | C | Anahtarları yalnızca 0..9 olan n = 20000 elemanda Lomuto (a[j] < pivot) ile üç yollu bölümlemenin karşılaştırma sayısı. | `ciktilar/H07_Q43_h6_tekrarli.txt` | yanıt doğrulaması |
| `quiz/H07_Q44_h7_kurma.c` | C | Altı elemanlı bir diziyi aşağıdan yukarıya en büyük öbek yapmak: sonuç dizi ve takas sayısı. | `ciktilar/H07_Q44_h7_kurma.txt` | yanıt doğrulaması |
| `quiz/H07_Q45_h7_sayma_aralik.py` | Python | Anahtar denetimi yapmayan sayma sıralaması (anahtarlar 0..3 olmalı) dört aday girdide: hangisi HATA VERMEDEN yanlış sonuç üretir? | `ciktilar/H07_Q45_h7_sayma_aralik.txt` | Vize bankası |
| `quiz/H07_Q46_h7_yerlestirme_bos.c` | C | Tamamlanacak; bu hâliyle derlenmez: kararlı sayma sıralamasının yerleştirme döngüsü. onek[v], anahtarı <= v olan kayıt sayısıdır (v bloğunun BİTİŞİ). Boş satırı doldurun. | — | Vize bankası |
| `quiz/H07_Q47_h7_heapq.py` | Python | heapq ile std::priority_queue aynı sırayla doldurulunca ilk çıkan eleman. C++ karşılığı: H07_Q47_h7_priority_queue.cpp | `ciktilar/H07_Q47_h7_heapq.txt` | Vize bankası |
| `quiz/H07_Q47_h7_priority_queue.cpp` | C++ | H07_Q47_h7_heapq.py'nin C++ karşılığı: aynı ekleme sırası, std::priority_queue'nun top() değeri. | `ciktilar/H07_Q47_h7_priority_queue.txt` | Vize bankası |

## 6. Haftanın Deneyi (deney/)

| Dosya | Görev |
|---|---|
| `deney/c/H07_deney_siralama.c` | C ölçüm programı (sayaçsız algoritmalar; `karsilastir` · `aralik` · `kurma`) |
| `deney/cpp/H07_deney_siralama.cpp` | C++ eşi (kütüphane: `std::sort`) |
| `deney/python/H07_deney_siralama.py` | Python eşi (kütüphane: `list.sort`) |
| `deney/h07_olcum_calistir.py` | Sürücü: derler, ızgarayı çalıştırır, tutarsız ölçümü yineler; `--devam` ile kaldığı yerden sürer, `--hizli` küçük ızgara |
| `deney/h07_cozumle.py` | Çözümleme: eğim, oran, kestirim tabloları (`sonuclar/h07_ozet_*.csv`) |
| `deney/sonuclar/h07_deney_karsilastirma.csv` | Ham ölçüm: 8 algoritma × 4 girdi × n (C -O2, C++ -O2, C -O0, Python); web sayfasındaki karşılaştırma panosunun verisi ve öğrenci CSV'si için şablon biçim |
| `deney/sonuclar/h07_deney_anahtar_araligi.csv` | Ham ölçüm: anahtar aralığı K = 10² … 2³² |
| `deney/sonuclar/h07_deney_obek_kurma.csv` | Ham ölçüm: öbek kurma (aşağıdan yukarıya / tek tek ekleyerek) |
| `deney/OLCUM_ORTAMI.txt` | Makine, derleyici, yöntem, yük ortalaması |

Materyalde: ders notu Bölüm 6, sunum slayt 45 (Örnek 12 ve deney), web “Deney” bölümü (karşılaştırma panosu). Deney programları da ortak modüllerin kopyalarını kullanır (`deney/c`, `deney/cpp`, `deney/python`).


## 7. Arşiv

`AP2_H07_kodlar.zip` bu klasörün tamamıdır (derleme ürünleri ve önbellek dosyaları hariç). Açtıktan sonra `python3 esdeger_test.py .` 13/13 GEÇTİ vermelidir.


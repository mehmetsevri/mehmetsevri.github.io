/* H07_K01_priority_queue.cpp — AP-2 Hafta 7 · Kavram 1
 * Amaç    : std::priority_queue varsayılan olarak EN BÜYÜK öbektir;
 *           en küçük öbek için std::greater karşılaştırıcısı verilir.
 *           İlk-k (boyutu k olan en küçük öbek) kütüphaneyle.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_K01_priority_queue.cpp -o H07_K01_priority_queue
 * Çalıştır: ./H07_K01_priority_queue
 * Not     : Örnek 3, 6 ve 7'de öbek elle yazılır; bu dosya yalnızca
 *           kütüphane karşılığını gösterir (Dil Penceresi).
 */
#include <functional>
#include <iostream>
#include <queue>
#include <vector>

int main()
{
    const std::vector<int> notlar = {71, 84, 63, 95, 52, 90, 45, 88};

    std::priority_queue<int> en_buyuk;  // varsayılan: en büyük öbek
    for (int x : notlar) {
        en_buyuk.push(x);
    }
    std::cout << "en büyük öbek (top, pop):";
    while (!en_buyuk.empty()) {
        std::cout << ' ' << en_buyuk.top();
        en_buyuk.pop();
    }
    std::cout << '\n';

    std::priority_queue<int, std::vector<int>, std::greater<int>> en_kucuk;
    for (int x : notlar) {
        en_kucuk.push(x);
    }
    std::cout << "en küçük öbek (top, pop):";
    while (!en_kucuk.empty()) {
        std::cout << ' ' << en_kucuk.top();
        en_kucuk.pop();
    }
    std::cout << '\n';

    // İlk 3 not: boyutu 3 olan EN KÜÇÜK öbek; kökte listenin en kötüsü
    const std::size_t k = 3;
    std::priority_queue<int, std::vector<int>, std::greater<int>> ilk;
    for (int x : notlar) {
        if (ilk.size() < k) {
            ilk.push(x);
        } else if (x > ilk.top()) {
            ilk.pop();
            ilk.push(x);
        }
    }
    std::cout << "ilk 3 (küçükten büyüğe çıkar):";
    while (!ilk.empty()) {
        std::cout << ' ' << ilk.top();
        ilk.pop();
    }
    std::cout << '\n';
    return 0;
}

/* Kütüphane karşılığı: C — yok (öbek elle yazılır); C++ —
 * std::priority_queue<T> (en büyük), std::priority_queue<T,
 * std::vector<T>, std::greater<T>> (en küçük); Python — heapq (en küçük). */

/* H07_K02_make_heap.cpp — AP-2 Hafta 7 · Kavram 2
 * Amaç    : std::make_heap / push_heap / pop_heap / sort_heap ile bir
 *           vektör üzerinde öbek işlemleri ve std::is_heap denetimi
 *           (kütüphane karşılığı; Örnek 4 ve 5'te öbek elle yazılır)
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_K02_make_heap.cpp -o H07_K02_make_heap
 * Çalıştır: ./H07_K02_make_heap
 */
#include <algorithm>
#include <iostream>
#include <vector>

static void yaz(const char *baslik, const std::vector<int> &a)
{
    std::cout << baslik << " [";
    for (std::size_t i = 0; i < a.size(); i++) {
        std::cout << (i > 0 ? " " : "") << a[i];
    }
    std::cout << "]  öbek mi? "
              << (std::is_heap(a.begin(), a.end()) ? "evet" : "hayır")
              << '\n';
}

int main()
{
    // Örnek 4'ün artan girdisi; Örnek 4'teki elle kurmanın sonucu:
    // 95 92 88 90 79 84 63 45 71 52
    std::vector<int> a = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    std::make_heap(a.begin(), a.end());
    yaz("make_heap        :", a);

    a.push_back(97);                  // önce sona ekle,
    std::push_heap(a.begin(), a.end());  // sonra yukarı süz
    yaz("push_heap(97)    :", a);

    std::pop_heap(a.begin(), a.end());   // kökü sona taşır, öbeği onarır
    std::cout << "pop_heap -> " << a.back() << '\n';
    a.pop_back();
    yaz("pop_heap sonrası :", a);

    std::sort_heap(a.begin(), a.end());  // öbek sıralaması (artan)
    yaz("sort_heap        :", a);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::make_heap (en çok 3n
 * karşılaştırma), std::push_heap, std::pop_heap, std::sort_heap,
 * std::is_heap; Python — heapq.heapify, heappush, heappop (en küçük). */

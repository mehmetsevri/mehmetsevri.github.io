/* H07_K07_oncelik_kuyrugu.c — AP-2 Hafta 7 · Kavram 7
 * Amaç    : Öncelik kuyruğu SOYUT VERİ TÜRÜ: kullanıcı yalnızca işlemleri
 *           (ekle, en_buyuk, cikar, bos_mu) görür; içeride dizi tabanlı
 *           en büyük öbek vardır. Kapasite dolunca dizi iki katına
 *           büyütülür (realloc; dinamik diziler Hafta 8'in konusudur).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_K07_oncelik_kuyrugu.c -o H07_K07_oncelik_kuyrugu
 * Çalıştır: ./H07_K07_oncelik_kuyrugu
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *a;          /* a[0..n-1] en büyük öbek */
    int n;
    int kapasite;
} OncelikKuyrugu;

static bool ok_baslat(OncelikKuyrugu *q, int kapasite)
{
    q->a = malloc((size_t)kapasite * sizeof *q->a);
    q->n = 0;
    q->kapasite = q->a ? kapasite : 0;
    return q->a != NULL;
}

static void ok_birak(OncelikKuyrugu *q)
{
    free(q->a);
    q->a = NULL;
    q->n = q->kapasite = 0;
}

static bool ok_bos_mu(const OncelikKuyrugu *q) { return q->n == 0; }

static int ok_en_buyuk(const OncelikKuyrugu *q) { return q->a[0]; }

static bool ok_ekle(OncelikKuyrugu *q, int x)
{
    if (q->n == q->kapasite) {
        int yeni = 2 * q->kapasite;
        int *b = realloc(q->a, (size_t)yeni * sizeof *b);
        if (b == NULL) {
            return false;  /* eski öbek bozulmadan kalır */
        }
        q->a = b;
        q->kapasite = yeni;
    }
    int i = q->n++;
    while (i > 0 && q->a[(i - 1) / 2] < x) {   /* yukarı süzme (delik) */
        q->a[i] = q->a[(i - 1) / 2];
        i = (i - 1) / 2;
    }
    q->a[i] = x;
    return true;
}

static int ok_cikar(OncelikKuyrugu *q)        /* ön koşul: n > 0 */
{
    int en_buyuk = q->a[0];
    int x = q->a[--q->n];
    int i = 0;
    while (2 * i + 1 < q->n) {                  /* aşağı süzme (delik) */
        int c = 2 * i + 1;
        if (c + 1 < q->n && q->a[c + 1] > q->a[c]) {
            c++;
        }
        if (q->a[c] <= x) {
            break;
        }
        q->a[i] = q->a[c];
        i = c;
    }
    q->a[i] = x;
    return en_buyuk;
}

int main(void)
{
    OncelikKuyrugu q;
    if (!ok_baslat(&q, 2)) {
        return 1;
    }
    const int oncelikler[] = {3, 9, 1, 7, 9, 4, 2, 8};
    for (size_t i = 0; i < sizeof oncelikler / sizeof oncelikler[0]; i++) {
        if (!ok_ekle(&q, oncelikler[i])) {
            ok_birak(&q);
            return 1;
        }
    }
    printf("kapasite = %d, eleman = %d, en büyük = %d\n", q.kapasite, q.n,
           ok_en_buyuk(&q));
    printf("çıkarma sırası:");
    while (!ok_bos_mu(&q)) {
        printf(" %d", ok_cikar(&q));
    }
    printf("\n");
    ok_birak(&q);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::priority_queue<int> (push, top,
 * pop, empty); Python — heapq (en küçük öbek; en büyük için -x). */

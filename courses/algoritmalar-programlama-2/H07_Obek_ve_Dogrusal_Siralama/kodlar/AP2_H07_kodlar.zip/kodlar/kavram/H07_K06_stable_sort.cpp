/* H07_K06_stable_sort.cpp — AP-2 Hafta 7 · Kavram 6
 * Amaç    : std::stable_sort kararlıdır; std::sort kararlılık güvencesi
 *           vermez. 200 kayıt (anahtar 0..4, sıra numarasıyla) iki
 *           yöntemle sıralanır ve eşit anahtarlıların sırası denetlenir.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_K06_stable_sort.cpp -o H07_K06_stable_sort
 * Çalıştır: ./H07_K06_stable_sort
 */
#include <algorithm>
#include <iostream>
#include <vector>

#include "../cpp/ortak_rastgele.hpp"

struct Kayit {
    int anahtar;
    int sira;  // girdideki konum
};

static bool anahtar_once(const Kayit &x, const Kayit &y)
{
    return x.anahtar < y.anahtar;
}

static bool kararli_mi(const std::vector<Kayit> &a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (a[i - 1].anahtar == a[i].anahtar && a[i - 1].sira > a[i].sira) {
            return false;
        }
    }
    return true;
}

int main()
{
    rastgele_tohum(42);
    std::vector<Kayit> a;
    for (int i = 0; i < 200; i++) {
        a.push_back({rastgele_aralik(0, 4), i});
    }
    std::vector<Kayit> b = a;
    std::vector<Kayit> c = a;
    std::stable_sort(b.begin(), b.end(), anahtar_once);
    std::sort(c.begin(), c.end(), anahtar_once);
    std::cout << "std::stable_sort: sıralı, kararlı mı? "
              << (kararli_mi(b) ? "evet" : "HAYIR") << '\n';
    std::cout << "std::sort       : sıralı, kararlı mı? "
              << (kararli_mi(c) ? "evet" : "HAYIR")
              << "  (bu derleyicide, bu girdide)\n";
    return 0;
}

/* Kütüphane karşılığı: C — qsort (kararlılık güvencesi yok); C++ —
 * std::stable_sort (kararlı), std::sort (kararlı değil); Python — sorted
 * (kararlı). */

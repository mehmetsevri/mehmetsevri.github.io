/* H07_K04_alt_sinir.c — AP-2 Hafta 7 · Kavram 4
 * Amaç    : Karşılaştırmalı sıralamanın alt sınırı: n elemanın n!
 *           permütasyonunun HER BİRİ araya ekleme ve birleştirmeli
 *           sıralamayla sıralanır; en kötü karşılaştırma sayısı
 *           ceil(log2 n!) ile karşılaştırılır (n = 1..8)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_K04_alt_sinir.c \
 *           -o H07_K04_alt_sinir -lm
 * Çalıştır: ./H07_K04_alt_sinir
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#define NMAX 12

static long long karsilastirma = 0;

static bool kucuk_mu(int x, int y)
{
    karsilastirma++;
    return x < y;
}

static void araya_ekleme(int *a, int n)
{
    for (int i = 1; i < n; i++) {
        int x = a[i];
        int j = i - 1;
        while (j >= 0 && kucuk_mu(x, a[j])) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}

static void birlestirmeli(int *a, int *g, int lo, int hi)  /* [lo, hi) */
{
    if (hi - lo < 2) {
        return;
    }
    int mid = lo + (hi - lo) / 2;
    birlestirmeli(a, g, lo, mid);
    birlestirmeli(a, g, mid, hi);
    int i = lo, j = mid, k = lo;
    while (i < mid && j < hi) {
        g[k++] = kucuk_mu(a[j], a[i]) ? a[j++] : a[i++];
    }
    while (i < mid) {
        g[k++] = a[i++];
    }
    while (j < hi) {
        g[k++] = a[j++];
    }
    memcpy(a + lo, g + lo, (size_t)(hi - lo) * sizeof *a);
}

/* sözlük sırasında bir sonraki permütasyon; sonuncudaysa false */
static bool sonraki(int *p, int n)
{
    int i = n - 2;
    while (i >= 0 && p[i] >= p[i + 1]) {
        i--;
    }
    if (i < 0) {
        return false;
    }
    int j = n - 1;
    while (p[j] <= p[i]) {
        j--;
    }
    int t = p[i];
    p[i] = p[j];
    p[j] = t;
    for (int l = i + 1, r = n - 1; l < r; l++, r--) {
        t = p[l];
        p[l] = p[r];
        p[r] = t;
    }
    return true;
}

static int log2_fakt_tavan(int n)  /* ceil(log2 n!) */
{
    double s = 0.0;
    for (int k = 2; k <= n; k++) {
        s += log2((double)k);
    }
    return (int)ceil(s - 1e-9);
}

int main(void)
{
    int p[NMAX], a[NMAX], g[NMAX];
    printf("  n       n!  ceil(log2 n!)  araya/en kötü"
           "  birleştirmeli/en kötü  n log2 n\n");
    for (int n = 1; n <= 8; n++) {
        long long sayi = 0, en_kotu_a = 0, en_kotu_b = 0;
        for (int i = 0; i < n; i++) {
            p[i] = i;
        }
        do {
            sayi++;
            memcpy(a, p, (size_t)n * sizeof *a);
            karsilastirma = 0;
            araya_ekleme(a, n);
            if (karsilastirma > en_kotu_a) {
                en_kotu_a = karsilastirma;
            }
            memcpy(a, p, (size_t)n * sizeof *a);
            karsilastirma = 0;
            birlestirmeli(a, g, 0, n);
            if (karsilastirma > en_kotu_b) {
                en_kotu_b = karsilastirma;
            }
        } while (sonraki(p, n));
        printf("%3d %8lld %14d %14lld %22lld %9.2f\n", n, sayi,
               log2_fakt_tavan(n), en_kotu_a, en_kotu_b,
               n * log2((double)n));
    }
    printf("büyük n (yalnız formül):\n");
    for (int n = 10; n <= 1000000; n *= 100) {
        double lf = 0.0;
        for (int k = 2; k <= n; k++) {
            lf += log2((double)k);
        }
        printf("  n = %7d: log2 n! = %12.1f  n log2 n = %12.1f"
               "  oran = %.3f\n", n, lf, n * log2((double)n),
               lf / (n * log2((double)n)));
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (alt sınır bir kanıttır, algoritma değil);
 * C++ — std::next_permutation; Python — itertools.permutations,
 * math.lgamma(n + 1) / math.log(2) = log2 n!. */

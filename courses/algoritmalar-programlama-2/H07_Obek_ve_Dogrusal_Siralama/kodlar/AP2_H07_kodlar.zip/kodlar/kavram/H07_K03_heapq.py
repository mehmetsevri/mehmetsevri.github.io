"""H07_K03_heapq.py — AP-2 Hafta 7 · Kavram 3
Amaç    : heapq, bir Python listesini EN KÜÇÜK öbek olarak kullanır
          (heap[0] en küçük). En büyük öbek için -x hilesi; eşit
          önceliklerde sıra numarası (öncelik, sıra, veri) demetleri.
Çalıştır: python3 H07_K03_heapq.py
"""
import heapq


def main():
    notlar = [71, 84, 63, 95, 52, 90, 45, 88]

    h = notlar[:]
    heapq.heapify(h)                    # doğrusal zamanda en küçük öbek
    print("heapify      :", h)
    print("heappop x3   :", [heapq.heappop(h) for _ in range(3)])

    eb = []
    for x in notlar:
        heapq.heappush(eb, -x)          # -x hilesi: en büyük öbek
    print("en büyük x3  :", [-heapq.heappop(eb) for _ in range(3)])

    print("nlargest(3)  :", heapq.nlargest(3, notlar))

    gorevler = []
    for sira, (oncelik, ad) in enumerate([(2, "rapor"), (1, "sinav"),
                                          (2, "odev"), (1, "proje")]):
        heapq.heappush(gorevler, (oncelik, sira, ad))
    print("görev sırası :", [heapq.heappop(gorevler)[2]
                             for _ in range(len(gorevler))])


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (öbek elle yazılır); C++ —
# std::priority_queue (varsayılan en büyük öbek); Python — heapq
# (heapify, heappush, heappop, nlargest, nsmallest; en küçük öbek).

"""H07_K05_kararlilik.py — AP-2 Hafta 7 · Kavram 5
Amaç    : sorted ve list.sort KARARLIDIR (Timsort): eşit anahtarlı
          kayıtların girdi sırası korunur. Bu yüzden iki kararlı geçiş,
          çok anahtarlı sıralama verir — taban (LSD) sıralamasının fikri:
          önce İKİNCİL anahtara, sonra BİRİNCİL anahtara göre sırala.
Çalıştır: python3 H07_K05_kararlilik.py
"""


def main():
    kayitlar = [("Emre", 85), ("Ada", 70), ("Gül", 85), ("Cem", 70),
                ("Banu", 90), ("Filiz", 70), ("Defne", 85)]

    tek = sorted(kayitlar, key=lambda r: r[1])
    print("nota göre      :", " ".join(f"{a}/{n}" for a, n in tek))

    adla = sorted(kayitlar, key=lambda r: r[0])        # 1. geçiş: ikincil
    iki = sorted(adla, key=lambda r: r[1])             # 2. geçiş: birincil
    print("ad, sonra not  :", " ".join(f"{a}/{n}" for a, n in iki))

    demet = sorted(kayitlar, key=lambda r: (r[1], r[0]))
    print("(not, ad) anahtarı aynı mı?", "evet" if demet == iki else "HAYIR")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort (kararlılık GÜVENCESİ YOK); C++ —
# std::stable_sort (kararlı), std::sort (kararlı değil); Python — sorted,
# list.sort (kararlı).

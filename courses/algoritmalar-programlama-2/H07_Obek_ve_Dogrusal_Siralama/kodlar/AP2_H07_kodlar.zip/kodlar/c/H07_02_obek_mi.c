/* H07_02_obek_mi.c — AP-2 Hafta 7 · Örnek 2 (★)
 * Amaç    : Öbek özelliği denetimi (is_heap): her i > 0 için
 *           a[ebeveyn(i)] >= a[i]; ilk ihlalin yeri ve karşılaştırma sayısı;
 *           1..n'nin kaç permütasyonu öbektir?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_02_obek_mi.c \
 *           -o H07_02_obek_mi
 * Çalıştır: ./H07_02_obek_mi
 * Eşleri  : cpp/H07_02_obek_mi.cpp · python/H07_02_obek_mi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>

#define MAKS_N 12

static long long karsilastirma_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

/* İlk ihlal: a[ebeveyn(i)] < a[i] olan en küçük i; ihlal yoksa -1 */
static int ilk_ihlal(const int *a, int n)
{
    for (int i = 1; i < n; i++) {
        karsilastirma_sayisi++;
        if (a[ebeveyn(i)] < a[i]) {
            return i;
        }
    }
    return -1;
}

static bool obek_mi(const int *a, int n)
{
    return ilk_ihlal(a, n) == -1;
}

/* Aynı özellik çocuklardan bakarak: iç düğümler 0 .. n/2 - 1 (kâhin) */
static bool obek_mi_cocuklar(const int *a, int n)
{
    for (int i = 0; i < n / 2; i++) {
        int sol = 2 * i + 1, sag = 2 * i + 2;
        if (a[i] < a[sol] || (sag < n && a[i] < a[sag])) {
            return false;
        }
    }
    return true;
}

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

/* Sözlük sırasında sonraki permütasyon; son permütasyondaysa false */
static bool sonraki_permutasyon(int *p, int n)
{
    int i = n - 2;
    while (i >= 0 && p[i] >= p[i + 1]) {
        i--;
    }
    if (i < 0) {
        return false;
    }
    int j = n - 1;
    while (p[j] <= p[i]) {
        j--;
    }
    takas(&p[i], &p[j]);
    for (int s = i + 1, t = n - 1; s < t; s++, t--) {
        takas(&p[s], &p[t]);
    }
    return true;
}

static void denetle(const char *ad, const int *a, int n)
{
    karsilastirma_sayisi = 0;
    int i = ilk_ihlal(a, n);
    printf("%s (n = %d): ", ad, n);
    if (i == -1) {
        printf("öbek: evet");
    } else {
        printf("öbek: HAYIR (i = %d: a[%d] = %d < a[%d] = %d)", i,
               ebeveyn(i), a[ebeveyn(i)], i, a[i]);
    }
    printf(", karşılaştırma = %lld\n", karsilastirma_sayisi);
}

int main(void)
{
    const int obek[] = {95, 88, 92, 71, 84, 63, 90, 45, 52, 79};
    const int azalan[] = {95, 92, 90, 88, 84, 79, 71, 63, 52, 45};
    const int artan[] = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    const int derinde[] = {95, 88, 92, 71, 84, 63, 90, 45, 52, 85};
    const int esit[] = {7, 7, 7, 7, 7};
    const int tek[] = {42};

    printf("1) Öbek özelliği: her i > 0 için a[(i - 1) / 2] >= a[i]\n");
    denetle("Örnek 1'in öbeği", obek, 10);
    denetle("azalan sıralı", azalan, 10);
    denetle("artan sıralı", artan, 10);
    denetle("son yaprakta ihlal", derinde, 10);
    denetle("eşit elemanlar", esit, 5);
    denetle("tek eleman", tek, 1);
    denetle("boş dizi", tek, 0);

    printf("\n2) 1..n'nin permütasyonlarından kaçı en büyük öbektir?\n");
    printf("  n        n!    öbek    oran (%%)   ort. karş.  uyumsuz\n");
    for (int n = 1; n <= 8; n++) {
        int p[MAKS_N];
        long long toplam = 0, obek_sayisi = 0, uyumsuz = 0;
        for (int i = 0; i < n; i++) {
            p[i] = i + 1;
        }
        karsilastirma_sayisi = 0;
        do {
            toplam++;
            bool b1 = obek_mi(p, n);
            if (b1) {
                obek_sayisi++;
            }
            if (b1 != obek_mi_cocuklar(p, n)) {
                uyumsuz++;
            }
        } while (sonraki_permutasyon(p, n));
        printf("%3d %9lld %7lld %10.4f %12.3f %8lld\n", n, toplam,
               obek_sayisi, 100.0 * (double)obek_sayisi / (double)toplam,
               (double)karsilastirma_sayisi / (double)toplam, uyumsuz);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::is_heap,
 * std::is_heap_until (ilk ihlalin konumu); Python — yok (heapq'da
 * denetim fonksiyonu yoktur; en küçük öbek için elle yazılır). */

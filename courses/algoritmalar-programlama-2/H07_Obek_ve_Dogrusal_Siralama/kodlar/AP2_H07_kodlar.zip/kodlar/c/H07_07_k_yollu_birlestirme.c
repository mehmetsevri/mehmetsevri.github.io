/* H07_07_k_yollu_birlestirme.c — AP-2 Hafta 7 · Örnek 7 (★★★)
 * Amaç    : k sıralı listenin en küçük öbekle birleştirilmesi: öbekte her
 *           listenin sıradaki elemanı; çıktı başına O(log k) — toplam
 *           O(N log k); k başı doğrusal taramayla (O(N k)) karşılaştırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_07_k_yollu_birlestirme.c ortak_rastgele.c \
 *           -o H07_07_k_yollu_birlestirme -lm
 * Çalıştır: ./H07_07_k_yollu_birlestirme
 * Eşleri  : cpp/H07_07_k_yollu_birlestirme.cpp ·
 *           python/H07_07_k_yollu_birlestirme.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    int deger;
    int liste;                         /* hangi listeden */
    int konum;                         /* o listedeki indisi */
} Oge;

static long long karsilastirma_sayisi = 0;

/* x, y'den önce mi gelir? (küçük değer; eşitse küçük liste no) */
static bool once_mi(Oge x, Oge y)
{
    karsilastirma_sayisi++;
    return x.deger < y.deger || (x.deger == y.deger && x.liste < y.liste);
}

static void takas(Oge *x, Oge *y)
{
    Oge g = *x;
    *x = *y;
    *y = g;
}

static void yukari_suz(Oge *h, int i)
{
    while (i > 0 && once_mi(h[i], h[(i - 1) / 2])) {
        takas(&h[i], &h[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

static void asagi_suz(Oge *h, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && once_mi(h[c + 1], h[c])) {
            c++;
        }
        if (!once_mi(h[c], h[i])) {
            break;
        }
        takas(&h[i], &h[c]);
        i = c;
    }
}

static void obek_yaz(const Oge *h, int boyut)
{
    for (int j = 0; j < boyut; j++) {
        printf(" %d/%c", h[j].deger, 'A' + h[j].liste);
    }
    printf("\n");
}

/* Her listenin ilk elemanı öbeğe; sonra kökü çıktıya yaz ve yerine aynı
 * listenin sonraki elemanını koy (liste bittiyse son öğeyi köke taşı) */
static int k_yollu_birlestir(int *const *liste, const int *uzunluk, int k,
                             int *cikti, int izle)
{
    if (k < 1) {
        return 0;
    }
    Oge *h = malloc((size_t)k * sizeof *h);
    int boyut = 0, m = 0;
    if (h == NULL) {
        exit(1);
    }
    for (int j = 0; j < k; j++) {
        if (uzunluk[j] > 0) {
            h[boyut] = (Oge){liste[j][0], j, 0};
            boyut++;
            yukari_suz(h, boyut - 1);
        }
    }
    if (izle) {
        printf("  başlangıç öbeği:");
        obek_yaz(h, boyut);
    }
    while (boyut > 0) {
        Oge en = h[0];
        cikti[m++] = en.deger;
        if (en.konum + 1 < uzunluk[en.liste]) {
            int s = en.konum + 1;
            h[0] = (Oge){liste[en.liste][s], en.liste, s};
        } else {
            boyut--;
            h[0] = h[boyut];               /* liste bitti */
        }
        asagi_suz(h, boyut, 0);
        if (izle) {
            printf("  %2d. çıktı %d/%c  öbek:", m, en.deger, 'A' + en.liste);
            obek_yaz(h, boyut);
        }
    }
    free(h);
    return m;
}

/* Karşılaştırma için: her adımda k listenin başını tek tek tara */
static int dogrusal_birlestir(int *const *liste, const int *uzunluk, int k,
                              int *cikti)
{
    if (k < 1) {
        return 0;
    }
    int *konum = calloc((size_t)k, sizeof *konum);
    int m = 0;
    if (konum == NULL) {
        exit(1);
    }
    for (;;) {
        int en = -1;
        for (int j = 0; j < k; j++) {
            if (konum[j] < uzunluk[j]) {
                Oge aday = {liste[j][konum[j]], j, konum[j]};
                if (en == -1 ||
                    once_mi(aday, (Oge){liste[en][konum[en]], en, 0})) {
                    en = j;
                }
            }
        }
        if (en == -1) {
            break;
        }
        cikti[m++] = liste[en][konum[en]];
        konum[en]++;
    }
    free(konum);
    return m;
}

static bool sirali_mi(const int *a, int n)
{
    for (int i = 1; i < n; i++) {
        if (a[i - 1] > a[i]) {
            return false;
        }
    }
    return true;
}

int main(void)
{
    int sa[] = {45, 62, 78, 91}, sb[] = {50, 50, 83}, sc[] = {38, 70, 95};
    int se[] = {66};
    int *liste[] = {sa, sb, sc, NULL, se};
    int uzunluk[] = {4, 3, 3, 0, 1};
    int cikti[16];

    printf("1) 5 şubenin sıralı not listeleri (D şubesi boş), k = 5\n");
    for (int j = 0; j < 5; j++) {
        printf("  %c:", 'A' + j);
        for (int i = 0; i < uzunluk[j]; i++) {
            printf(" %d", liste[j][i]);
        }
        printf(uzunluk[j] == 0 ? " (boş)\n" : "\n");
    }
    karsilastirma_sayisi = 0;
    int m = k_yollu_birlestir(liste, uzunluk, 5, cikti, 1);
    printf("  birleşik:");
    for (int i = 0; i < m; i++) {
        printf(" %d", cikti[i]);
    }
    printf("\n  eleman = %d, karşılaştırma = %lld, sıralı mı? %s\n", m,
           karsilastirma_sayisi, sirali_mi(cikti, m) ? "evet" : "HAYIR");

    printf("\n2) N = 16384 eleman, k eşit uzunlukta sıralı liste\n");
    printf("     k  öbek karş.  öbek/N  log2 k  tarama karş.  tarama/N"
           "  aynı mı\n");
    const int n = 16384;
    int *veri = malloc((size_t)n * sizeof *veri);
    int *c1 = malloc((size_t)n * sizeof *c1);
    int *c2 = malloc((size_t)n * sizeof *c2);
    int **ls = malloc(64 * sizeof *ls);
    int *uz = malloc(64 * sizeof *uz);
    if (veri == NULL || c1 == NULL || c2 == NULL || ls == NULL ||
        uz == NULL) {
        return 1;
    }
    for (int k = 2; k <= 64; k *= 2) {
        rastgele_tohum(42);
        for (int j = 0; j < k; j++) {  /* artan adımlarla sıralı liste */
            ls[j] = veri + j * (n / k);
            uz[j] = n / k;
            int x = 0;
            for (int i = 0; i < n / k; i++) {
                x += rastgele_aralik(0, 9);
                ls[j][i] = x;
            }
        }
        karsilastirma_sayisi = 0;
        int m1 = k_yollu_birlestir(ls, uz, k, c1, 0);
        long long ko = karsilastirma_sayisi;
        karsilastirma_sayisi = 0;
        int m2 = dogrusal_birlestir(ls, uz, k, c2);
        long long kt = karsilastirma_sayisi;
        bool ayni = m1 == n && m2 == n && sirali_mi(c1, n);
        for (int i = 0; i < n; i++) {
            ayni = ayni && c1[i] == c2[i];
        }
        printf("%6d %11lld %7.3f %7.3f %13lld %9.3f  %s\n", k, ko,
               (double)ko / n, log2((double)k), kt, (double)kt / n,
               ayni ? "evet" : "HAYIR");
    }
    free(veri);
    free(c1);
    free(c2);
    free(ls);
    free(uz);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue +
 * std::greater (en küçük öbek), iki liste için std::merge; Python —
 * heapq.merge(*listeler) (yalnızca kâhin). */

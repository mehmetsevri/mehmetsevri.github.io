/* H07_09_kararli_sayma.c — AP-2 Hafta 7 · Örnek 9 (★★)
 * Amaç    : Kararlı sayma sıralaması: kayıtlar, sıklık dizisi, önek toplam
 *           ve sağdan sola yerleştirme; yön yanlış seçilirse kararlılık
 *           kaybolur
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_09_kararli_sayma.c \
 *           ortak_rastgele.c -o H07_09_kararli_sayma
 * Çalıştır: ./H07_09_kararli_sayma
 * Eşleri  : cpp/H07_09_kararli_sayma.cpp · python/H07_09_kararli_sayma.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    int no;
    int not_;                          /* anahtar: 0..k */
} Kayit;

static void dizi_yaz(const char *ad, const int *x, int n)
{
    printf("  %s:", ad);
    for (int i = 0; i < n; i++) {
        printf(" %d", x[i]);
    }
    printf("\n");
}

/* Yol 1: önek[v] = anahtarı <= v olan kayıt sayısı; sağdan sola yerleştir */
static void kararli_sayma(const Kayit *a, Kayit *b, int n, int k, int izle)
{
    int *onek = calloc((size_t)k + 1, sizeof *onek);
    if (onek == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        onek[a[i].not_]++;                 /* sıklık */
    }
    if (izle) {
        dizi_yaz("sayaç    ", onek, k + 1);
    }
    for (int v = 1; v <= k; v++) {
        onek[v] += onek[v - 1];            /* önek toplam */
    }
    if (izle) {
        dizi_yaz("önek top.", onek, k + 1);
    }
    for (int i = n - 1; i >= 0; i--) {     /* sağdan sola: kararlı */
        int v = a[i].not_;
        onek[v]--;
        b[onek[v]] = a[i];
        if (izle) {
            printf("  a[%d] = (%d, %d) -> b[%d]\n", i, a[i].no, v, onek[v]);
        }
    }
    free(onek);
}

/* Yol 2: başlangıç[v] = anahtarı < v olan kayıt sayısı; soldan sağa */
static void kararli_sayma_bas(const Kayit *a, Kayit *b, int n, int k)
{
    int *bas = calloc((size_t)k + 2, sizeof *bas);
    if (bas == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        bas[a[i].not_ + 1]++;
    }
    for (int v = 1; v <= k; v++) {
        bas[v] += bas[v - 1];
    }
    for (int i = 0; i < n; i++) {          /* soldan sağa, artırarak */
        b[bas[a[i].not_]++] = a[i];
    }
    free(bas);
}

/* Yol 3: Yol 1'in önek dizisi, ama soldan sağa: eşitler ters döner */
static void kararsiz_sayma(const Kayit *a, Kayit *b, int n, int k)
{
    int *onek = calloc((size_t)k + 1, sizeof *onek);
    if (onek == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        onek[a[i].not_]++;
    }
    for (int v = 1; v <= k; v++) {
        onek[v] += onek[v - 1];
    }
    for (int i = 0; i < n; i++) {          /* YANLIŞ yön */
        b[--onek[a[i].not_]] = a[i];
    }
    free(onek);
}

static void kayit_yaz(const char *ad, const Kayit *a, int n)
{
    printf("  %s:", ad);
    for (int i = 0; i < n; i++) {
        printf(" (%d, %d)", a[i].no, a[i].not_);
    }
    printf("\n");
}

/* Sıralı mı ve eşit anahtarlı kayıtlar girdi sırasını (no artan) korumuş
 * mu? Numaralar girdide artan verildiği için no karşılaştırması yeter. */
static void denetle(const char *ad, const Kayit *b, int n)
{
    bool sirali = true, kararli = true;
    for (int i = 1; i < n; i++) {
        if (b[i - 1].not_ > b[i].not_) {
            sirali = false;
        } else if (b[i - 1].not_ == b[i].not_ && b[i - 1].no > b[i].no) {
            kararli = false;
        }
    }
    printf("  %s: sıralı mı? %s, kararlı mı? %s\n", ad,
           sirali ? "evet" : "HAYIR", kararli ? "evet" : "HAYIR");
}

int main(void)
{
    Kayit a[] = {{1001, 3}, {1002, 1}, {1003, 3}, {1004, 0}, {1005, 2},
                 {1006, 1}, {1007, 3}, {1008, 2}};
    const int n = 8, k = 5;
    Kayit b[8];

    printf("1) Kayıtlar (no, not), anahtarlar 0..%d\n", k);
    kayit_yaz("girdi", a, n);
    kararli_sayma(a, b, n, k, 1);
    kayit_yaz("yol 1", b, n);
    denetle("yol 1 sağdan sola   ", b, n);
    kararli_sayma_bas(a, b, n, k);
    kayit_yaz("yol 2", b, n);
    denetle("yol 2 başlangıçlarla", b, n);
    kararsiz_sayma(a, b, n, k);
    kayit_yaz("yol 3", b, n);
    denetle("yol 3 yanlış yön    ", b, n);

    printf("\n2) 100000 kayıt, notlar 0..100 (tohum 42)\n");
    const int m = 100000;
    Kayit *x = malloc((size_t)m * sizeof *x);
    Kayit *y = malloc((size_t)m * sizeof *y);
    if (x == NULL || y == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    for (int i = 0; i < m; i++) {
        x[i].no = 2400001 + i;
        x[i].not_ = rastgele_aralik(0, 100);
    }
    kararli_sayma(x, y, m, 100, 0);
    denetle("yol 1 sağdan sola   ", y, m);
    kararli_sayma_bas(x, y, m, 100);
    denetle("yol 2 başlangıçlarla", y, m);
    kararsiz_sayma(x, y, m, 100);
    denetle("yol 3 yanlış yön    ", y, m);
    free(x);
    free(y);
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort kararlı olmak zorunda değildir);
 * C++ — std::stable_sort (karşılaştırmalı, kararlı); Python — sorted /
 * list.sort (kararlı, karşılaştırmalı; yalnızca kâhin). */

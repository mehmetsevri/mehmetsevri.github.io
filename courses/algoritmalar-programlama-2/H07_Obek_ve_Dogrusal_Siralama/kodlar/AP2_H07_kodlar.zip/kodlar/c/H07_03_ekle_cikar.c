/* H07_03_ekle_cikar.c — AP-2 Hafta 7 · Örnek 3 (★★)
 * Amaç    : En büyük öbeğe ekleme (yukarı süzme) ve en büyüğü çıkarma
 *           (aşağı süzme); adım adım izleme ve rastgele anahtarlarda
 *           işlem başına ortalama takas sayısı
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_03_ekle_cikar.c \
 *           ortak_rastgele.c -o H07_03_ekle_cikar -lm
 * Çalıştır: ./H07_03_ekle_cikar
 * Eşleri  : cpp/H07_03_ekle_cikar.cpp · python/H07_03_ekle_cikar.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma_sayisi = 0;
static long long takas_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

static bool buyuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x > y;
}

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
    takas_sayisi++;
}

/* a[i] ebeveyninden büyük oldukça yukarı taşınır; son konumu döndürür */
static int yukari_suz(int *a, int i)
{
    while (i > 0 && buyuk_mu(a[i], a[ebeveyn(i)])) {
        takas(&a[i], &a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
    return i;
}

/* a[i], büyük çocuğundan küçük oldukça aşağı taşınır (a[0..n-1]) */
static int asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;  /* sol çocuk */
        if (c + 1 < n && buyuk_mu(a[c + 1], a[c])) {
            c++;  /* sağ çocuk daha büyük */
        }
        if (!buyuk_mu(a[c], a[i])) {
            break;  /* öbek özelliği sağlandı */
        }
        takas(&a[i], &a[c]);
        i = c;
    }
    return i;
}

/* Yeni eleman ilk boş yaprağa konur, sonra yukarı süzülür */
static int obege_ekle(int *a, int *n, int x)
{
    a[*n] = x;
    (*n)++;
    return yukari_suz(a, *n - 1);
}

/* Kök çıkarılır; son eleman köke taşınıp aşağı süzülür (n > 0 olmalı) */
static int en_buyugu_cikar(int *a, int *n)
{
    int en_buyuk = a[0];
    (*n)--;
    a[0] = a[*n];
    asagi_suz(a, *n, 0);
    return en_buyuk;
}

static void dizi_yaz(const int *a, int n)
{
    printf("[");
    for (int i = 0; i < n; i++) {
        printf(i > 0 ? " %d" : "%d", a[i]);
    }
    printf("]\n");
}

static void sayaclari_sifirla(void)
{
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
}

/* n rastgele anahtar: ekleme, artan girdiyle ekleme ve tümünü çıkarma */
static void ortalama_satiri(int n)
{
    int *a = malloc((size_t)n * sizeof *a);
    int boyut = 0;
    if (a == NULL) {
        exit(1);
    }
    rastgele_tohum(42);
    sayaclari_sifirla();
    for (int k = 0; k < n; k++) {
        obege_ekle(a, &boyut, (int)rastgele_sayi());
    }
    double ekleme = (double)takas_sayisi / n;
    sayaclari_sifirla();
    while (boyut > 0) {
        en_buyugu_cikar(a, &boyut);
    }
    double cikar_t = (double)takas_sayisi / n;
    double cikar_k = (double)karsilastirma_sayisi / n;
    sayaclari_sifirla();
    for (int k = 0; k < n; k++) {
        obege_ekle(a, &boyut, k);      /* artan: her eleman köke çıkar */
    }
    double artan = (double)takas_sayisi / n;
    printf("%7d %10.3f %10.3f %8.3f %11.3f %11.3f\n", n, ekleme, artan,
           log2((double)n), cikar_t, cikar_k);
    free(a);
}

int main(void)
{
    const int sira[] = {45, 79, 63, 90, 84, 92, 95, 52, 71, 88};
    const int ornek1[] = {95, 88, 92, 71, 84, 63, 90, 45, 52, 79};
    int a[16];
    int n = 0;

    printf("1) Boş öbeğe sırayla ekleme (yukarı süzme)\n");
    for (int k = 0; k < 10; k++) {
        sayaclari_sifirla();
        int son = obege_ekle(a, &n, sira[k]);
        printf("  ekle %d: konum %d -> %d, takas = %lld  ", sira[k], n - 1,
               son, takas_sayisi);
        dizi_yaz(a, n);
    }
    bool ayni = true;
    for (int i = 0; i < n; i++) {
        ayni = ayni && a[i] == ornek1[i];
    }
    printf("  Örnek 1'in öbeğiyle aynı mı? %s\n", ayni ? "evet" : "HAYIR");

    printf("\n2) En kötü durum: yeni eleman köke kadar çıkar\n");
    sayaclari_sifirla();
    int son = obege_ekle(a, &n, 97);
    printf("  ekle 97: konum %d -> %d, takas = %lld (düzey sayısı - 1)  ",
           n - 1, son, takas_sayisi);
    dizi_yaz(a, n);

    printf("\n3) En büyüğü çıkarma (son eleman köke, aşağı süzme)\n");
    for (int k = 0; k < 3; k++) {
        int kok_adayi = a[n - 1];
        sayaclari_sifirla();
        int en_buyuk = en_buyugu_cikar(a, &n);
        printf("  çıkar -> %d (köke %d taşındı), karşılaştırma = %lld, "
               "takas = %lld\n    ", en_buyuk, kok_adayi,
               karsilastirma_sayisi, takas_sayisi);
        dizi_yaz(a, n);
    }
    printf("  kalanlar sırayla çıkarılınca:");
    while (n > 0) {
        printf(" %d", en_buyugu_cikar(a, &n));
    }
    printf("\n");

    printf("\n4) İşlem başına ortalama (rastgele anahtarlar, tohum 42)\n");
    printf("      n   ekle/takas  artan/takas   log2 n  çıkar/takas"
           "  çıkar/karş.\n");
    ortalama_satiri(1000);
    ortalama_satiri(10000);
    ortalama_satiri(100000);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue
 * (push/top/pop; varsayılan en büyük öbek), std::push_heap/std::pop_heap;
 * Python — heapq.heappush/heapq.heappop (en küçük öbek). */

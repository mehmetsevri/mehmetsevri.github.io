/* H07_13_akan_ortanca.c — AP-2 Hafta 7 · Örnek 13 (★★★, merak)
 * Amaç    : Akan veride ortanca: küçük yarı EN BÜYÜK öbekte, büyük yarı
 *           EN KÜÇÜK öbekte; boylar en çok 1 farklı; ekleme O(log n),
 *           ortanca O(1). Sıralı dizide araya eklemeyle (O(n)) karşılaştırma
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_13_akan_ortanca.c \
 *           ortak_rastgele.c -o H07_13_akan_ortanca -lm
 * Çalıştır: ./H07_13_akan_ortanca
 * Eşleri  : cpp/H07_13_akan_ortanca.cpp · python/H07_13_akan_ortanca.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    int *a;
    int n;
    bool en_buyuk;                     /* true: en büyük öbek */
} Obek;

static long long karsilastirma_sayisi = 0;

/* x, öbekte y'nin üstünde mi durmalı? */
static bool ustte_mi(const Obek *h, int x, int y)
{
    karsilastirma_sayisi++;
    return h->en_buyuk ? x > y : x < y;
}

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static void ekle(Obek *h, int x)
{
    int i = h->n++;
    h->a[i] = x;
    while (i > 0 && ustte_mi(h, h->a[i], h->a[(i - 1) / 2])) {
        takas(&h->a[i], &h->a[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

static int cikar(Obek *h)
{
    int tepe = h->a[0];
    h->a[0] = h->a[--h->n];
    int i = 0;
    while (2 * i + 1 < h->n) {
        int c = 2 * i + 1;
        if (c + 1 < h->n && ustte_mi(h, h->a[c + 1], h->a[c])) {
            c++;
        }
        if (!ustte_mi(h, h->a[c], h->a[i])) {
            break;
        }
        takas(&h->a[i], &h->a[c]);
        i = c;
    }
    return tepe;
}

/* Değişmez: alt'taki her değer <= ust'teki her değer ve
 * alt->n == ust->n ya da alt->n == ust->n + 1 */
static void ortancaya_ekle(Obek *alt, Obek *ust, int x)
{
    if (alt->n == 0 || !ustte_mi(alt, x, alt->a[0])) {
        ekle(alt, x);  /* x <= alt'ın tepesi */
    } else {
        ekle(ust, x);
    }
    if (alt->n > ust->n + 1) {  /* dengele */
        ekle(ust, cikar(alt));
    } else if (ust->n > alt->n) {
        ekle(alt, cikar(ust));
    }
}

static double ortanca(const Obek *alt, const Obek *ust)
{
    if (alt->n > ust->n) {
        return alt->a[0];
    }
    return (alt->a[0] + ust->a[0]) / 2.0;
}

static Obek obek_olustur(int kapasite, bool en_buyuk)
{
    Obek h = {malloc((size_t)kapasite * sizeof(int)), 0, en_buyuk};
    if (h.a == NULL) {
        exit(1);
    }
    return h;
}

static void obek_yaz(const char *ad, const Obek *h)
{
    printf("%s[", ad);
    for (int i = 0; i < h->n; i++) {
        printf(i > 0 ? " %d" : "%d", h->a[i]);
    }
    printf("]");
}

static int artan(const void *x, const void *y)            /* kâhin için */
{
    int p = *(const int *)x, q = *(const int *)y;
    return (p > q) - (p < q);
}

static double kahin_ortanca(const int *a, int n)
{
    int *b = malloc((size_t)n * sizeof *b);
    if (b == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        b[i] = a[i];
    }
    qsort(b, (size_t)n, sizeof *b, artan);
    double m = n % 2 ? b[n / 2] : (b[n / 2 - 1] + b[n / 2]) / 2.0;
    free(b);
    return m;
}

/* Karşılaştırma için: sıralı dizide araya ekleme; kaydırma sayısı */
static long long sirali_dizi_kaydirma(const int *a, int n)
{
    int *s = malloc((size_t)n * sizeof *s);
    long long kaydirma = 0;
    if (s == NULL) {
        exit(1);
    }
    for (int m = 0; m < n; m++) {
        int j = m - 1;
        while (j >= 0 && s[j] > a[m]) {
            s[j + 1] = s[j];
            kaydirma++;
            j--;
        }
        s[j + 1] = a[m];
    }
    free(s);
    return kaydirma;
}

int main(void)
{
    printf("1) 15 değerlik akış (0..99, tohum 42)\n");
    Obek alt = obek_olustur(16, true), ust = obek_olustur(16, false);
    rastgele_tohum(42);
    for (int k = 0; k < 15; k++) {
        int x = rastgele_aralik(0, 99);
        ortancaya_ekle(&alt, &ust, x);
        printf("  %2d. gelen %2d  ortanca = %5.1f  ", k + 1, x,
               ortanca(&alt, &ust));
        obek_yaz("alt (en büyük) ", &alt);
        obek_yaz("  üst (en küçük) ", &ust);
        printf("\n");
    }
    free(alt.a);
    free(ust.a);

    printf("\n2) 100000 değerlik akış (0..1000000): denetim noktaları\n");
    printf("        n    ortanca  kâhin  alt boy  üst boy  karş./n  "
           "log2 n\n");
    const int n = 100000;
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 0, 1000000);
    alt = obek_olustur(n, true);
    ust = obek_olustur(n, false);
    karsilastirma_sayisi = 0;
    int nokta = 10;
    for (int m = 1; m <= n; m++) {
        ortancaya_ekle(&alt, &ust, a[m - 1]);
        if (m == nokta) {
            double o = ortanca(&alt, &ust);
            printf("%9d %10.1f  %5s %8d %8d %8.3f %7.3f\n", m, o,
                   o == kahin_ortanca(a, m) ? "evet" : "HAYIR", alt.n,
                   ust.n, (double)karsilastirma_sayisi / m, log2((double)m));
            nokta *= 10;
        }
    }
    free(alt.a);
    free(ust.a);

    printf("\n3) İki öbek ve sıralı dizi: toplam iş\n");
    printf("        n  iki öbek karş.  sıralı dizi kaydırma\n");
    for (int m = 500; m <= 2000; m *= 2) {
        alt = obek_olustur(m, true);
        ust = obek_olustur(m, false);
        karsilastirma_sayisi = 0;
        for (int i = 0; i < m; i++) {
            ortancaya_ekle(&alt, &ust, a[i]);
        }
        printf("%9d %15lld %21lld\n", m, karsilastirma_sayisi,
               sirali_dizi_kaydirma(a, m));
        free(alt.a);
        free(ust.a);
    }
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — iki std::priority_queue
 * (biri std::greater ile); Python — iki heapq listesi (alt yarı için -x
 * hilesiyle en büyük öbek); statistics.median yalnızca kâhin. */

/* H07_01_dizi_agac.c — AP-2 Hafta 7 · Örnek 1 (★)
 * Amaç    : Tam ikili ağacın dizi gösterimi: ebeveyn (i-1)/2, çocuklar 2i+1
 *           ve 2i+2; öbeğin düzeyler ve ağaç biçiminde yazdırılması
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_01_dizi_agac.c \
 *           -o H07_01_dizi_agac
 * Çalıştır: ./H07_01_dizi_agac
 * Eşleri  : cpp/H07_01_dizi_agac.cpp · python/H07_01_dizi_agac.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdio.h>
#include <string.h>

#define HUCRE 4                    /* son düzeyde düğüm başına sütun */
#define MAKS_GENISLIK 128

/* 0 tabanlı indis formülleri */
static int ebeveyn(int i) { return (i - 1) / 2; }
static int sol_cocuk(int i) { return 2 * i + 1; }
static int sag_cocuk(int i) { return 2 * i + 2; }

/* i. düğümün düzeyi (kök 0): i + 1'in ikilik basamak sayısı - 1 */
static int duzey(int i)
{
    int d = 0;
    while (i > 0) {
        i = ebeveyn(i);
        d++;
    }
    return d;
}

static void tablo_yaz(const int *a, int n)
{
    printf("  i  a[i]  ebeveyn  sol  sağ  düzey\n");
    for (int i = 0; i < n; i++) {
        printf("%3d  %4d", i, a[i]);
        if (i == 0) {
            printf("  %7s", "-");
        } else {
            printf("  %7d", ebeveyn(i));
        }
        if (sol_cocuk(i) < n) {
            printf("  %3d", sol_cocuk(i));
        } else {
            printf("  %3s", "-");
        }
        if (sag_cocuk(i) < n) {
            printf("  %3d", sag_cocuk(i));
        } else {
            printf("  %3s", "-");
        }
        printf("  %5d\n", duzey(i));
    }
}

static void duzeyleri_yaz(const int *a, int n)
{
    int bas = 0, d = 0;
    while (bas < n) {
        int son = 2 * bas + 1;     /* sonraki düzeyin başı */
        if (son > n) {
            son = n;
        }
        printf("  düzey %d (a[%d..%d]):", d, bas, son - 1);
        for (int i = bas; i < son; i++) {
            printf(" %d", a[i]);
        }
        printf("\n");
        bas = 2 * bas + 1;
        d++;
    }
}

/* Satır sonundaki boşlukları silip yazdırır */
static void satir_bas(char *s)
{
    int u = (int)strlen(s);
    while (u > 0 && s[u - 1] == ' ') {
        u--;
    }
    s[u] = '\0';
    printf("%s\n", s);
}

/* Ortalanmış ağaç: d. düzeyde 2^d yuva, yuva genişliği G / 2^d */
static void agac_yaz(const int *a, int n)
{
    int yukseklik = duzey(n - 1);
    int g = HUCRE << yukseklik;    /* toplam genişlik */
    char satir[MAKS_GENISLIK + 1];
    for (int d = 0; d <= yukseklik; d++) {
        int bas = (1 << d) - 1;
        int yuva = g >> d;
        memset(satir, ' ', (size_t)g);
        satir[g] = '\0';
        for (int j = 0; j < (1 << d) && bas + j < n; j++) {
            char sayi[16];
            int u = snprintf(sayi, sizeof sayi, "%d", a[bas + j]);
            int hedef = yuva * j + (yuva - u) / 2;
            memcpy(satir + hedef, sayi, (size_t)u);
        }
        satir_bas(satir);
        if (d == yukseklik) {
            break;
        }
        memset(satir, ' ', (size_t)g);   /* bağlantı çizgileri */
        for (int j = 0; j < (1 << d) && bas + j < n; j++) {
            if (sol_cocuk(bas + j) < n) {
                satir[yuva * j + 3 * yuva / 8] = '/';
            }
            if (sag_cocuk(bas + j) < n) {
                satir[yuva * j + 5 * yuva / 8] = '\\';
            }
        }
        satir_bas(satir);
    }
}

/* Yan yatırılmış ağaç: önce sağ alt ağaç (üstte), sonra düğüm, sonra sol */
static void yan_agac(const int *a, int n, int i, int derinlik)
{
    if (i >= n) {
        return;
    }
    yan_agac(a, n, sag_cocuk(i), derinlik + 1);
    printf("%*s%d\n", 6 * derinlik, "", a[i]);
    yan_agac(a, n, sol_cocuk(i), derinlik + 1);
}

/* Formüllerin tutarlılığı: her i > 0 için i, ebeveyninin bir çocuğu mu?
 * Bit kaydırmalı biçimler aynı sonucu veriyor mu? */
static long long formul_denetimi(int n)
{
    long long hata = 0;
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            int e = ebeveyn(i);
            if (sol_cocuk(e) != i && sag_cocuk(e) != i) {
                hata++;
            }
            if (((i - 1) >> 1) != e) {
                hata++;
            }
        }
        if (((i << 1) | 1) != sol_cocuk(i)) {
            hata++;
        }
        if (((i + 1) << 1) != sag_cocuk(i)) {
            hata++;
        }
    }
    return hata;
}

int main(void)
{
    const int a[] = {95, 88, 92, 71, 84, 63, 90, 45, 52, 79};
    const int n = (int)(sizeof a / sizeof a[0]);

    printf("Öbek dizisi (n = %d):", n);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n\n1) İndis ilişkileri (0 tabanlı)\n");
    tablo_yaz(a, n);

    printf("\n2) Düzeyler: d. düzey a[2^d - 1 .. 2^(d+1) - 2]\n");
    duzeyleri_yaz(a, n);

    printf("\n3) Ağaç biçimi (dizi sırası = düzey düzey, soldan sağa)\n");
    agac_yaz(a, n);

    printf("\n4) Yan yatırılmış ağaç (sağ çocuk üstte)\n");
    yan_agac(a, n, 0, 0);

    printf("\n5) Bit kaydırmayla: sol = (i << 1) | 1, sağ = (i + 1) << 1,"
           " ebeveyn = (i - 1) >> 1\n");
    printf("   i = 3: sol = %d, sağ = %d, ebeveyn = %d\n",
           (3 << 1) | 1, (3 + 1) << 1, (3 - 1) >> 1);
    printf("   i = 0 .. 999999 için tutarsızlık sayısı: %lld\n",
           formul_denetimi(1000000));
    printf("   düzey sayısı (yükseklik + 1): n = 10 -> %d, "
           "n = 1000000 -> %d\n", duzey(9) + 1, duzey(999999) + 1);
    return 0;
}

/* Kütüphane karşılığı: C — yok (dizi + indis aritmetiği elle);
 * C++ — std::make_heap aynı 0 tabanlı yerleşimi kullanır; Python — heapq
 * aynı yerleşimi kullanır (heap[k] <= heap[2k+1], heap[2k+2]). */

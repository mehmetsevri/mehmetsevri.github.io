/* H07_10_taban_siralamasi.c — AP-2 Hafta 7 · Örnek 10 (★★★)
 * Amaç    : Taban sıralaması (LSD): en düşük basamaktan başlayarak her
 *           basamakta KARARLI sayma; 32 bitlik işaretsiz tamsayılar bayt
 *           bayt (256 tabanı, 4 geçiş); Θ(d(n + b)); taban seçimi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_10_taban_siralamasi.c ortak_rastgele.c \
 *           -o H07_10_taban_siralamasi -lm
 * Çalıştır: ./H07_10_taban_siralamasi
 * Eşleri  : cpp/H07_10_taban_siralamasi.cpp ·
 *           python/H07_10_taban_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long adim_sayisi = 0;

/* Ondalık gösterim (kart sıralayıcı benzetmesi): bolen = 1, 10, 100 */
static void ondalik_gecis(const int *a, int *b, int n, int bolen)
{
    int onek[10] = {0};
    for (int i = 0; i < n; i++) {
        onek[a[i] / bolen % 10]++;
    }
    for (int v = 1; v < 10; v++) {
        onek[v] += onek[v - 1];
    }
    /* sağdan sola: kararlı */
    for (int i = n - 1; i >= 0; i--) {
        b[--onek[a[i] / bolen % 10]] = a[i];
    }
}

/* Bir geçiş: (x >> kaydir) & maske basamağına göre kararlı sayma */
static void gecis(const uint32_t *a, uint32_t *b, int n, int kaydir,
                  uint32_t maske, int *onek)
{
    for (uint32_t v = 0; v <= maske; v++) {
        onek[v] = 0;
    }
    for (int i = 0; i < n; i++) {
        onek[(a[i] >> kaydir) & maske]++;
        adim_sayisi++;
    }
    for (uint32_t v = 1; v <= maske; v++) {
        onek[v] += onek[v - 1];
        adim_sayisi++;
    }
    for (int i = n - 1; i >= 0; i--) {
        uint32_t v = (a[i] >> kaydir) & maske;
        b[--onek[v]] = a[i];
        adim_sayisi++;
    }
}

/* bit: basamak genişliği (4, 8 ya da 16); 32 / bit geçiş (çift sayı:
 * sonuç yeniden a'da). izle: her geçişten sonra yazdır */
static void taban_siralamasi(uint32_t *a, int n, int bit, int izle)
{
    uint32_t maske = (1u << bit) - 1;
    uint32_t *b = malloc((size_t)n * sizeof *b);
    int *onek = malloc(((size_t)maske + 1) * sizeof *onek);
    if (b == NULL || onek == NULL) {
        exit(1);
    }
    uint32_t *kaynak = a, *hedef = b;
    for (int kaydir = 0; kaydir < 32; kaydir += bit) {
        gecis(kaynak, hedef, n, kaydir, maske, onek);
        uint32_t *g = kaynak;          /* rolleri değiştir */
        kaynak = hedef;
        hedef = g;
        if (izle) {
            printf("  bayt %d   :", kaydir / 8);
            for (int i = 0; i < n; i++) {
                printf(" %08X", (unsigned)kaynak[i]);
            }
            printf("\n");
        }
    }
    free(b);
    free(onek);
}

static uint32_t rastgele_u32(void)
{
    uint32_t ust = rastgele_sayi() >> 15;   /* 16 bit */
    uint32_t alt = rastgele_sayi() >> 15;   /* ayrı deyim: sıra belli */
    return (ust << 16) | alt;
}

static int artan_u32(const void *x, const void *y)        /* kâhin için */
{
    uint32_t p = *(const uint32_t *)x, q = *(const uint32_t *)y;
    return (p > q) - (p < q);
}

static void olcek_satiri(int n, int bit)
{
    uint32_t *a = malloc((size_t)n * sizeof *a);
    uint32_t *k = malloc((size_t)n * sizeof *k);
    if (a == NULL || k == NULL) {
        exit(1);
    }
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        a[i] = rastgele_u32();
        k[i] = a[i];
    }
    qsort(k, (size_t)n, sizeof *k, artan_u32);             /* kâhin */
    adim_sayisi = 0;
    taban_siralamasi(a, n, bit, 0);
    bool dogru = true;
    for (int i = 0; i < n; i++) {
        dogru = dogru && a[i] == k[i];
    }
    int d = 32 / bit, b = 1 << bit;
    printf("%8d %4d %6d %3d %10lld %10lld %8.3f %11.0f  %s\n", n, bit, b, d,
           adim_sayisi, (long long)d * (2LL * n + b - 1),
           (double)adim_sayisi / n, n * log2((double)n),
           dogru ? "evet" : "HAYIR");
    free(a);
    free(k);
}

int main(void)
{
    int o[] = {532, 418, 207, 351, 842, 135, 600, 214};
    int t[8];
    const char *ad[] = {"birler", "onlar ", "yüzler"};
    printf("1) Ondalık LSD: önce birler, sonra onlar, sonra yüzler\n");
    printf("  girdi        :");
    for (int i = 0; i < 8; i++) {
        printf(" %d", o[i]);
    }
    printf("\n");
    for (int d = 0, bolen = 1; d < 3; d++, bolen *= 10) {
        ondalik_gecis(o, t, 8, bolen);
        printf("  %d. geçiş %s:", d + 1, ad[d]);
        for (int i = 0; i < 8; i++) {
            o[i] = t[i];
            printf(" %d", o[i]);
        }
        printf("\n");
    }

    printf("\n2) 32 bit, 256 tabanı: bayt 0 (en düşük) -> bayt 3\n");
    uint32_t a[] = {0x2A00FF10u, 0x00C0FFEEu, 0x12345678u, 0xDEADBEEFu,
                    0x0000002Au, 0xFFFFFFFFu, 0x12340078u, 0x80000000u};
    printf("  girdi    :");
    for (int i = 0; i < 8; i++) {
        printf(" %08X", (unsigned)a[i]);
    }
    printf("\n");
    adim_sayisi = 0;
    taban_siralamasi(a, 8, 8, 1);
    printf("  onluk    :");
    for (int i = 0; i < 8; i++) {
        printf(" %u", (unsigned)a[i]);
    }
    printf("\n  adım = %lld = 4 (2n + b - 1), n = 8, b = 256\n",
           adim_sayisi);

    printf("\n3) Rastgele 32 bitlik sayılar: adım = d (2n + b - 1)\n");
    printf("       n  bit  taban   d       adım    formül   adım/n"
           "     n log2 n  kâhin\n");
    for (int n = 1000; n <= 100000; n *= 10) {
        olcek_satiri(n, 8);
    }
    printf("  taban seçimi (n = 100000): az geçiş <-> büyük sayaç dizisi\n");
    olcek_satiri(100000, 4);
    olcek_satiri(100000, 8);
    olcek_satiri(100000, 16);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::sort karşılaştırmalıdır);
 * Python — yok (sorted karşılaştırmalıdır; yalnızca kâhin). */

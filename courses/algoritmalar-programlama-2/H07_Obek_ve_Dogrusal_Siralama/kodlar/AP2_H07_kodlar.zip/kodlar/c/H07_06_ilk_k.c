/* H07_06_ilk_k.c — AP-2 Hafta 7 · Örnek 6 (★★)
 * Amaç    : Öncelik kuyruğuyla ilk-k en yüksek not: boyutu k olan EN KÜÇÜK
 *           öbek (kökte listenin en kötüsü); O(n log k) zaman, O(k) bellek
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_06_ilk_k.c \
 *           ortak_rastgele.c -o H07_06_ilk_k -lm
 * Çalıştır: ./H07_06_ilk_k
 * Eşleri  : cpp/H07_06_ilk_k.cpp · python/H07_06_ilk_k.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

typedef struct {
    int no;
    int not_;
} Ogrenci;

static long long karsilastirma_sayisi = 0;
static long long degisim_sayisi = 0;      /* köke yazılan yeni kayıt */

/* x, y'den daha mı kötü? (düşük not; eşit notta büyük numara) */
static bool kotu_mu(Ogrenci x, Ogrenci y)
{
    karsilastirma_sayisi++;
    return x.not_ < y.not_ || (x.not_ == y.not_ && x.no > y.no);
}

static void takas(Ogrenci *x, Ogrenci *y)
{
    Ogrenci g = *x;
    *x = *y;
    *y = g;
}

/* En küçük öbek: kökte en kötü kayıt */
static void yukari_suz(Ogrenci *h, int i)
{
    while (i > 0 && kotu_mu(h[i], h[(i - 1) / 2])) {
        takas(&h[i], &h[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

static void asagi_suz(Ogrenci *h, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && kotu_mu(h[c + 1], h[c])) {
            c++;                           /* daha kötü çocuk */
        }
        if (!kotu_mu(h[c], h[i])) {
            break;
        }
        takas(&h[i], &h[c]);
        i = c;
    }
}

/* Her kayıt için: öbek dolmadıysa ekle; doluysa ve kökten iyiyse kökü
 * değiştir. Sonunda öbek yerinde sıralanır: h[0] en iyi. Dönüş: boyut */
static int ilk_k(const Ogrenci *a, int n, int k, Ogrenci *h, int izle)
{
    int boyut = 0;
    for (int i = 0; i < n; i++) {
        const char *ne;
        if (boyut < k) {
            h[boyut++] = a[i];
            yukari_suz(h, boyut - 1);
            ne = "eklendi";
        } else if (kotu_mu(h[0], a[i])) {
            h[0] = a[i];                   /* en kötüyü at */
            asagi_suz(h, k, 0);
            degisim_sayisi++;
            ne = "köke yazıldı";
        } else {
            ne = "atlandı";
        }
        if (izle) {
            printf("  %d (%3d)  kök = %3d  öbek:", a[i].no, a[i].not_,
                   h[0].not_);
            for (int j = 0; j < boyut; j++) {
                printf(" %d", h[j].not_);
            }
            printf("  <- %s\n", ne);
        }
    }
    for (int son = boyut - 1; son > 0; son--) {   /* en kötü sona */
        takas(&h[0], &h[son]);
        asagi_suz(h, son, 0);
    }
    return boyut;
}

static int iyiden_kotuye(const void *x, const void *y)   /* kâhin için */
{
    const Ogrenci *p = x, *q = y;
    if (p->not_ != q->not_) {
        return q->not_ - p->not_;
    }
    return (p->no > q->no) - (p->no < q->no);
}

/* artan = 0: notlar rastgele 0..100; artan = 1: puan = i (en kötü durum:
 * her yeni kayıt kökten iyidir) */
static Ogrenci *ogrenciler(int n, int artan)
{
    Ogrenci *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        exit(1);
    }
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        a[i].no = 2400001 + i;
        a[i].not_ = artan ? i : rastgele_aralik(0, 100);
    }
    return a;
}

int main(void)
{
    printf("1) İlk 12 öğrenci, k = 3 (kökte listenin en kötüsü)\n");
    Ogrenci *a = ogrenciler(12, 0);
    Ogrenci h[1000];
    int b = ilk_k(a, 12, 3, h, 1);
    printf("  ilk 3:");
    for (int j = 0; j < b; j++) {
        printf(" %d (%d)", h[j].no, h[j].not_);
    }
    printf("\n");
    free(a);

    printf("\n2) 200 öğrenci, k = 5; eşit notta küçük numara önce\n");
    a = ogrenciler(200, 0);
    karsilastirma_sayisi = 0;
    b = ilk_k(a, 200, 5, h, 0);
    qsort(a, 200, sizeof *a, iyiden_kotuye);           /* kâhin */
    bool ayni = true;
    for (int j = 0; j < b; j++) {
        printf("  %d. %d  not = %d\n", j + 1, h[j].no, h[j].not_);
        ayni = ayni && h[j].no == a[j].no;
    }
    printf("  karşılaştırma = %lld; tam sıralamanın ilk 5'iyle aynı mı? "
           "%s\n", karsilastirma_sayisi, ayni ? "evet" : "HAYIR");
    free(a);

    printf("\n3) n = 100000: k büyüdükçe iş; r: rastgele notlar, a: artan "
           "puan (en kötü durum)\n");
    printf("     k  karş. r  karş./n r köke yazma r  karş./n a  2 log2 k"
           "  kâhin\n");
    const int n = 100000;
    const int kler[] = {1, 10, 100, 1000};
    a = ogrenciler(n, 0);
    Ogrenci *s = ogrenciler(n, 0);
    Ogrenci *e = ogrenciler(n, 1);
    qsort(s, (size_t)n, sizeof *s, iyiden_kotuye);     /* kâhin */
    for (int t = 0; t < 4; t++) {
        int k = kler[t];
        karsilastirma_sayisi = 0;
        degisim_sayisi = 0;
        b = ilk_k(a, n, k, h, 0);
        long long kr = karsilastirma_sayisi, dr = degisim_sayisi;
        ayni = true;
        for (int j = 0; j < b; j++) {
            ayni = ayni && h[j].no == s[j].no;
        }
        karsilastirma_sayisi = 0;
        b = ilk_k(e, n, k, h, 0);
        for (int j = 0; j < b; j++) {
            ayni = ayni && h[j].not_ == n - 1 - j;
        }
        printf("%6d %8lld %10.3f %12lld %10.3f %9.3f  %s\n", k, kr,
               (double)kr / n, dr, (double)karsilastirma_sayisi / n,
               2 * log2((double)k), ayni ? "evet" : "HAYIR");
    }
    printf("  tam sıralama ölçeği: n log2 n = %.0f\n", n * log2((double)n));
    free(a);
    free(s);
    free(e);
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue<T,
 * std::vector<T>, std::greater<T>> (en küçük öbek), std::partial_sort,
 * std::nth_element; Python — heapq.nlargest(k, a) (yalnızca kâhin). */

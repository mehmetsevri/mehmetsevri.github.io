/* H07_04_obek_kur.c — AP-2 Hafta 7 · Örnek 4 (★★)
 * Amaç    : Aşağıdan yukarıya öbek kurma (son iç düğümden köke aşağı
 *           süzme) ve takas sayısı: takas <= Σ yükseklik = n - popcount(n)
 *           < n, yani O(n); tek tek eklemeyle kurmanın O(n log n) en kötüsü
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_04_obek_kur.c \
 *           ortak_rastgele.c -o H07_04_obek_kur -lm
 * Çalıştır: ./H07_04_obek_kur [n_ust=100000]
 * Eşleri  : cpp/H07_04_obek_kur.cpp · python/H07_04_obek_kur.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma_sayisi = 0;
static long long takas_sayisi = 0;

static int ebeveyn(int i) { return (i - 1) / 2; }

static bool buyuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x > y;
}

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
    takas_sayisi++;
}

static void asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;  /* sol çocuk */
        if (c + 1 < n && buyuk_mu(a[c + 1], a[c])) {
            c++;  /* sağ çocuk daha büyük */
        }
        if (!buyuk_mu(a[c], a[i])) {
            break;
        }
        takas(&a[i], &a[c]);
        i = c;
    }
}

static void yukari_suz(int *a, int i)
{
    while (i > 0 && buyuk_mu(a[i], a[ebeveyn(i)])) {
        takas(&a[i], &a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
}

/* Aşağıdan yukarıya: yapraklar zaten öbektir; son iç düğümden köke */
static void obek_kur(int *a, int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
}

/* Yukarıdan aşağıya: a[0..i-1] öbeğine a[i]'yi ekler gibi yukarı süz */
static void obek_kur_ekleyerek(int *a, int n)
{
    for (int i = 1; i < n; i++) {
        yukari_suz(a, i);
    }
}

static bool obek_mi(const int *a, int n)
{
    for (int i = 1; i < n; i++) {
        if (a[ebeveyn(i)] < a[i]) {
            return false;
        }
    }
    return true;
}

/* i. düğümün yüksekliği: altındaki en uzun yol (en soldaki yol) */
static int yukseklik(int i, int n)
{
    int h = 0;
    while (2 * i + 1 < n) {
        i = 2 * i + 1;
        h++;
    }
    return h;
}

static long long yukseklik_toplami(int n)
{
    long long t = 0;
    for (int i = 0; i < n; i++) {
        t += yukseklik(i, n);
    }
    return t;
}

static int birler(int n)             /* ikilik gösterimdeki 1 sayısı */
{
    int b = 0;
    for (; n > 0; n >>= 1) {
        b += n & 1;
    }
    return b;
}

static void dizi_yaz(const int *a, int n)
{
    printf("[");
    for (int i = 0; i < n; i++) {
        printf(i > 0 ? " %d" : "%d", a[i]);
    }
    printf("]\n");
}

static void sayaclari_sifirla(void)
{
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
}

static void doldur(int *a, int n, int artan)
{
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        a[i] = artan ? i : (int)rastgele_sayi();
    }
}

static void izleme(void)
{
    int a[] = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    const int n = 10;
    printf("1) Aşağıdan yukarıya kurma, artan girdi (n = 10)\n   ");
    dizi_yaz(a, n);
    sayaclari_sifirla();
    for (int i = n / 2 - 1; i >= 0; i--) {
        long long once = takas_sayisi;
        asagi_suz(a, n, i);
        printf("  i = %d (a[i] süzüldü, takas = %lld)  ", i,
               takas_sayisi - once);
        dizi_yaz(a, n);
    }
    printf("  toplam: karşılaştırma = %lld, takas = %lld, öbek mi? %s\n",
           karsilastirma_sayisi, takas_sayisi,
           obek_mi(a, n) ? "evet" : "HAYIR");
    printf("  üst sınır Σ yükseklik = %lld (n - popcount(n) = %d)\n",
           yukseklik_toplami(n), n - birler(n));
    int b[] = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    sayaclari_sifirla();
    obek_kur_ekleyerek(b, n);
    printf("  aynı girdi tek tek eklemeyle: takas = %lld, öbek mi? %s  ",
           takas_sayisi, obek_mi(b, n) ? "evet" : "HAYIR");
    dizi_yaz(b, n);
}

/* Mükemmel ağaçta (n = 2^(H+1) - 1) düzeylere göre iş */
static void duzey_tablosu(int buyuk_h)
{
    int n = (1 << (buyuk_h + 1)) - 1;
    int *a = malloc((size_t)n * sizeof *a);
    int *r = malloc((size_t)n * sizeof *r);
    long long *ta = calloc((size_t)buyuk_h + 1, sizeof *ta);
    long long *tr = calloc((size_t)buyuk_h + 1, sizeof *tr);
    if (a == NULL || r == NULL || ta == NULL || tr == NULL) {
        exit(1);
    }
    doldur(a, n, 1);
    doldur(r, n, 0);
    for (int i = n / 2 - 1; i >= 0; i--) {
        int d = 0;
        for (int j = i; j > 0; j = ebeveyn(j)) {
            d++;
        }
        long long once = takas_sayisi;
        asagi_suz(a, n, i);
        ta[d] += takas_sayisi - once;
        once = takas_sayisi;
        asagi_suz(r, n, i);
        tr[d] += takas_sayisi - once;
    }
    printf("\n2) Düzeylere göre iş: mükemmel ağaç, n = %d\n", n);
    printf("  düzey  düğüm  yükseklik  üst sınır  artan girdi  rastgele\n");
    long long top_s = 0, top_a = 0, top_r = 0;
    for (int d = 0; d <= buyuk_h; d++) {
        long long dugum = 1LL << d, h = buyuk_h - d;
        printf("%7d %6lld %10lld %10lld %12lld %9lld\n", d, dugum, h,
               dugum * h, ta[d], tr[d]);
        top_s += dugum * h;
        top_a += ta[d];
        top_r += tr[d];
    }
    printf("  toplam %6d %10s %10lld %12lld %9lld\n", n, "", top_s, top_a,
           top_r);
    free(a);
    free(r);
    free(ta);
    free(tr);
}

static void asagidan_satiri(int n)
{
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        exit(1);
    }
    doldur(a, n, 0);
    sayaclari_sifirla();
    obek_kur(a, n);
    long long t_r = takas_sayisi, k_r = karsilastirma_sayisi;
    bool ok = obek_mi(a, n);
    doldur(a, n, 1);
    sayaclari_sifirla();
    obek_kur(a, n);
    long long t_a = takas_sayisi;
    ok = ok && obek_mi(a, n);
    long long s = yukseklik_toplami(n);
    printf("%9d %10lld %10lld %10lld %6s %7.3f %7.3f %7.3f %s\n", n, t_r,
           t_a, s, s == n - birler(n) ? "evet" : "HAYIR", (double)t_r / n,
           (double)t_a / n, (double)k_r / n, ok ? "evet" : "HAYIR");
    free(a);
}

static void ekleyerek_satiri(int n)
{
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        exit(1);
    }
    doldur(a, n, 0);
    sayaclari_sifirla();
    obek_kur_ekleyerek(a, n);
    long long e_r = takas_sayisi;
    doldur(a, n, 1);
    sayaclari_sifirla();
    obek_kur_ekleyerek(a, n);
    long long e_a = takas_sayisi;
    printf("%9d %10lld %10lld %7.3f %7.3f %7.3f\n", n, e_r, e_a,
           (double)e_r / n, (double)e_a / n, log2((double)n));
    free(a);
}

int main(int argc, char *argv[])
{
    long n_ust = 100000;
    if (argc > 1) {
        char *son;
        n_ust = strtol(argv[1], &son, 10);
        if (*son != '\0' || n_ust < 10 || n_ust > 100000000) {
            fprintf(stderr, "kullanım: %s [n_ust: 10..100000000]\n",
                    argv[0]);
            return 2;
        }
    }
    izleme();
    duzey_tablosu(9);
    printf("\n3) Aşağıdan yukarıya: takas / n sabit kalıyor mu?\n");
    printf("  r: rastgele, a: artan girdi; t: takas, k: karşılaştırma; "
           "n-pc?: Σ yüks. = n - popcount(n) mi?\n");
    printf("        n    takas r    takas a    Σ yüks.  n-pc?   t/n r"
           "   t/n a   k/n r öbek?\n");
    for (long n = 10; n <= n_ust; n *= 10) {
        asagidan_satiri((int)n);
    }
    printf("\n4) Tek tek ekleyerek kurma (yukarı süzme)\n");
    printf("        n    takas r    takas a   t/n r   t/n a  log2 n\n");
    for (long n = 10; n <= n_ust; n *= 10) {
        ekleyerek_satiri((int)n);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle); C++ — std::make_heap (doğrusal
 * zamanda kurar: en çok 3n karşılaştırma); Python — heapq.heapify(a)
 * (en küçük öbek, doğrusal zaman). */

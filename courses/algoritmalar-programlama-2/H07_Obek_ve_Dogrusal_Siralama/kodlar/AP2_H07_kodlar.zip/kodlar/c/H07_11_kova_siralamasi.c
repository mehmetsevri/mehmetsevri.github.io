/* H07_11_kova_siralamasi.c — AP-2 Hafta 7 · Örnek 11 (★★)
 * Amaç    : Kova sıralaması: [0, 1) aralığındaki n değer n kovaya
 *           dağıtılır (kova = ⌊x · n⌋), kova içleri araya eklemeyle
 *           sıralanır; düzgün dağılımda Θ(n), varsayım bozulursa Θ(n²)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_11_kova_siralamasi.c ortak_rastgele.c \
 *           -o H07_11_kova_siralamasi
 * Çalıştır: ./H07_11_kova_siralamasi
 * Eşleri  : cpp/H07_11_kova_siralamasi.cpp ·
 *           python/H07_11_kova_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma_sayisi = 0;
static int en_dolu = 0;                    /* en kalabalık kovanın boyu */
static int bos_kova = 0;

/* a[bas..son-1] dilimini araya eklemeyle sıralar */
static void araya_ekleme(double *a, int bas, int son)
{
    for (int i = bas + 1; i < son; i++) {
        double x = a[i];
        int j = i - 1;
        while (j >= bas) {
            karsilastirma_sayisi++;
            if (a[j] <= x) {
                break;
            }
            a[j + 1] = a[j];               /* kaydır */
            j--;
        }
        a[j + 1] = x;
    }
}

static int kova_no(double x, int n)
{
    int k = (int)(x * n);                  /* 0 <= x < 1 */
    return k < n ? k : n - 1;
}

/* Kovalar ayrı listeler yerine tek dizide ardışık dilimlerdir: kova
 * boyları sayılır, önek toplamla başlangıçlar bulunur (Örnek 9) */
static void kova_siralamasi(double *a, int n, int izle)
{
    int *bas = calloc((size_t)n + 1, sizeof *bas);
    int *yer = malloc((size_t)n * sizeof *yer);
    double *b = malloc((size_t)n * sizeof *b);
    if (bas == NULL || yer == NULL || b == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        bas[kova_no(a[i], n) + 1]++;       /* kova boyları */
    }
    for (int v = 1; v <= n; v++) {
        bas[v] += bas[v - 1];              /* kova v: b[bas[v]..bas[v+1]) */
    }
    for (int v = 0; v < n; v++) {
        yer[v] = bas[v];
    }
    for (int i = 0; i < n; i++) {          /* dağıt (kararlı) */
        b[yer[kova_no(a[i], n)]++] = a[i];
    }
    en_dolu = 0;
    bos_kova = 0;
    for (int v = 0; v < n; v++) {
        int boy = bas[v + 1] - bas[v];
        en_dolu = boy > en_dolu ? boy : en_dolu;
        bos_kova += boy == 0;
        if (izle) {
            printf("  kova %d [%.1f, %.1f):", v, (double)v / n,
                   (double)(v + 1) / n);
            for (int i = bas[v]; i < bas[v + 1]; i++) {
                printf(" %.4f", b[i]);
            }
            printf("\n");
        }
        araya_ekleme(b, bas[v], bas[v + 1]);
    }
    for (int i = 0; i < n; i++) {
        a[i] = b[i];
    }
    free(bas);
    free(yer);
    free(b);
}

static int artan(const void *x, const void *y)            /* kâhin için */
{
    double p = *(const double *)x, q = *(const double *)y;
    return (p > q) - (p < q);
}

/* dagilim: 0 düzgün (u), 1 çarpık (u^4), 2 tek kova (0.5 + u / 2n) */
static double *uret(int n, int dagilim)
{
    double *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        exit(1);
    }
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        double u = rastgele_kesir();
        if (dagilim == 0) {
            a[i] = u;
        } else if (dagilim == 1) {
            a[i] = u * u * u * u;
        } else {
            a[i] = 0.5 + u / (2.0 * n);
        }
    }
    return a;
}

static bool dogru_mu(const double *a, int n, int dagilim)
{
    double *k = uret(n, dagilim);
    qsort(k, (size_t)n, sizeof *k, artan);              /* kâhin */
    bool ayni = true;
    for (int i = 0; i < n; i++) {
        ayni = ayni && a[i] == k[i];
    }
    free(k);
    return ayni;
}

int main(void)
{
    printf("1) 10 değer, 10 kova (tohum 42)\n  girdi:");
    double *a = uret(10, 0);
    for (int i = 0; i < 10; i++) {
        printf(" %.4f", a[i]);
    }
    printf("\n");
    karsilastirma_sayisi = 0;
    kova_siralamasi(a, 10, 1);
    printf("  çıktı:");
    for (int i = 0; i < 10; i++) {
        printf(" %.4f", a[i]);
    }
    printf("\n  karşılaştırma = %lld, boş kova = %d, en dolu kova = %d\n",
           karsilastirma_sayisi, bos_kova, en_dolu);
    free(a);

    printf("\n2) Düzgün dağılım: kova başına ortalama 1 eleman\n");
    printf("        n  karşılaştırma  karş./n  en dolu  boş kova oranı"
           "  kâhin\n");
    for (int n = 1000; n <= 100000; n *= 10) {
        a = uret(n, 0);
        karsilastirma_sayisi = 0;
        kova_siralamasi(a, n, 0);
        printf("%9d %14lld %8.3f %8d %15.4f  %s\n", n, karsilastirma_sayisi,
               (double)karsilastirma_sayisi / n, en_dolu,
               (double)bos_kova / n, dogru_mu(a, n, 0) ? "evet" : "HAYIR");
        free(a);
    }

    printf("\n3) Dağılım varsayımı bozulursa (karş./n)\n");
    printf("        n    düzgün  çarpık u^4   tek kova  kâhin\n");
    for (int n = 1000; n <= 4000; n *= 2) {
        double oran[3];
        bool hepsi = true;
        for (int d = 0; d < 3; d++) {
            a = uret(n, d);
            karsilastirma_sayisi = 0;
            kova_siralamasi(a, n, 0);
            oran[d] = (double)karsilastirma_sayisi / n;
            hepsi = hepsi && dogru_mu(a, n, d);
            free(a);
        }
        printf("%9d %9.3f %11.3f %10.3f  %s\n", n, oran[0], oran[1], oran[2],
               hepsi ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok (std::sort karşılaştırmalıdır);
 * Python — yok (sorted yalnızca kâhin). */

/* H07_12_siralama_karsilastirma.c — AP-2 Hafta 7 · Örnek 12 (★★★)
 * Amaç    : Sıralama karşılaştırma deneyi: sekiz algoritma × dört girdi
 *           türü × n. Varsayılan: deterministik sayaçlar + kâhin denetimi
 *           + oran testi; "olc N [tekrar]": süre tablosu (stderr)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_12_siralama_karsilastirma.c ortak_rastgele.c zamanlayici.c \
 *           -o H07_12_siralama_karsilastirma
 * Çalıştır: ./H07_12_siralama_karsilastirma  |  ... olc 100000 5
 * Eşleri  : cpp/H07_12_siralama_karsilastirma.cpp ·
 *           python/H07_12_siralama_karsilastirma.py
 * Çıktı   : üç dilde aynı (=) — süreler stderr'e
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ortak_rastgele.h"
#include "zamanlayici.h"

#define ALG_SAYISI 8
#define TUR_SAYISI 4
#define ANAHTAR 1000000            /* rastgele/sıralı/ters: 0..999999 */

static long long karsilastirma_sayisi = 0;
static long long yazma_sayisi = 0;         /* diziye eleman yazma */
static long long sayac_islemi = 0;         /* sayaç dizisi adımları */

static bool kucuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x < y;
}

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
    yazma_sayisi += 2;
}

/* 1. Seçmeli: a[i..n-1]'in en küçüğünü i'ye getir */
static void secmeli_siralama(int *a, int n)
{
    for (int i = 0; i + 1 < n; i++) {
        int m = i;
        for (int j = i + 1; j < n; j++) {
            if (kucuk_mu(a[j], a[m])) {
                m = j;
            }
        }
        if (m != i) {
            takas(&a[i], &a[m]);
        }
    }
}

/* 2. Araya ekleme: a[i]'yi sıralı a[0..i-1] içine kaydırarak yerleştir */
static void araya_ekleme_siralamasi(int *a, int n)
{
    for (int i = 1; i < n; i++) {
        int x = a[i];
        int j = i - 1;
        while (j >= 0 && kucuk_mu(x, a[j])) {
            a[j + 1] = a[j];
            yazma_sayisi++;
            j--;
        }
        a[j + 1] = x;
        yazma_sayisi++;
    }
}

/* 3. Birleştirmeli: a[lo..orta) ve a[orta..hi) -> g -> a (kararlı) */
static void birlestir(int *a, int *g, int lo, int orta, int hi)
{
    int i = lo, j = orta, k = lo;
    while (i < orta && j < hi) {
        g[k++] = kucuk_mu(a[j], a[i]) ? a[j++] : a[i++];
    }
    while (i < orta) {
        g[k++] = a[i++];
    }
    while (j < hi) {
        g[k++] = a[j++];
    }
    for (k = lo; k < hi; k++) {
        a[k] = g[k];
    }
    yazma_sayisi += 2LL * (hi - lo);
}

static void birlestirmeli_ozyineli(int *a, int *g, int lo, int hi)
{
    if (hi - lo < 2) {
        return;
    }
    int orta = lo + (hi - lo) / 2;
    birlestirmeli_ozyineli(a, g, lo, orta);
    birlestirmeli_ozyineli(a, g, orta, hi);
    birlestir(a, g, lo, orta, hi);
}

static void birlestirmeli_siralama(int *a, int n)
{
    int *g = malloc((size_t)n * sizeof *g + 1);
    if (g == NULL) {
        exit(1);
    }
    birlestirmeli_ozyineli(a, g, 0, n);
    free(g);
}

/* 4. Hızlı: üçün ortancası pivot, Hoare bölümlemesi (a[lo..hi] kapalı) */
static int bolumle(int *a, int lo, int hi)
{
    int orta = lo + (hi - lo) / 2;
    if (kucuk_mu(a[orta], a[lo])) {
        takas(&a[orta], &a[lo]);
    }
    if (kucuk_mu(a[hi], a[lo])) {
        takas(&a[hi], &a[lo]);
    }
    if (kucuk_mu(a[hi], a[orta])) {
        takas(&a[hi], &a[orta]);
    }
    int pivot = a[orta];
    int i = lo - 1, j = hi + 1;
    for (;;) {
        do {
            i++;
        } while (kucuk_mu(a[i], pivot));
        do {
            j--;
        } while (kucuk_mu(pivot, a[j]));
        if (i >= j) {
            return j;              /* a[lo..j] <= pivot <= a[j+1..hi] */
        }
        takas(&a[i], &a[j]);
    }
}

/* Küçük parçada özyineleme, büyük parçada döngü: yığın derinliği O(log n) */
static void hizli_ozyineli(int *a, int lo, int hi)
{
    while (lo < hi) {
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            hizli_ozyineli(a, lo, p);
            lo = p + 1;
        } else {
            hizli_ozyineli(a, p + 1, hi);
            hi = p;
        }
    }
}

static void hizli_siralama(int *a, int n)
{
    hizli_ozyineli(a, 0, n - 1);
}

/* 5. Öbek (Örnek 5) */
static void asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && kucuk_mu(a[c], a[c + 1])) {
            c++;
        }
        if (!kucuk_mu(a[i], a[c])) {
            break;
        }
        takas(&a[i], &a[c]);
        i = c;
    }
}

static void obek_siralamasi(int *a, int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
    for (int son = n - 1; son > 0; son--) {
        takas(&a[0], &a[son]);
        asagi_suz(a, son, 0);
    }
}

/* 6. Sayma (Örnek 8): anahtarlar 0..k */
static void sayma_siralamasi(int *a, int n, int k)
{
    int *sayac = calloc((size_t)k + 1, sizeof *sayac);
    if (sayac == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        sayac[a[i]]++;
    }
    int j = 0;
    for (int v = 0; v <= k; v++) {
        for (int c = 0; c < sayac[v]; c++) {
            a[j++] = v;
        }
    }
    sayac_islemi += n + k + 1;
    yazma_sayisi += n;
    free(sayac);
}

/* 7. Taban (Örnek 10): 256 tabanı, 4 kararlı geçiş (anahtarlar >= 0) */
static void taban_siralamasi(int *a, int n)
{
    int *b = malloc((size_t)n * sizeof *b + 1);
    if (b == NULL) {
        exit(1);
    }
    int *kaynak = a, *hedef = b;
    for (int kaydir = 0; kaydir < 32; kaydir += 8) {
        int onek[256] = {0};
        for (int i = 0; i < n; i++) {
            onek[((uint32_t)kaynak[i] >> kaydir) & 0xFF]++;
        }
        for (int v = 1; v < 256; v++) {
            onek[v] += onek[v - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            hedef[--onek[((uint32_t)kaynak[i] >> kaydir) & 0xFF]] = kaynak[i];
        }
        int *g = kaynak;
        kaynak = hedef;
        hedef = g;
        sayac_islemi += n + 255;
        yazma_sayisi += n;
    }
    free(b);                       /* 4 geçiş: sonuç yeniden a'da */
}

/* 8. Kütüphane: qsort (algoritmasını standart belirtmez; sayaç yok) */
static int artan(const void *x, const void *y)
{
    int p = *(const int *)x, q = *(const int *)y;
    return (p > q) - (p < q);
}

static void kutuphane_siralamasi(int *a, int n)
{
    qsort(a, (size_t)n, sizeof *a, artan);
}

static const char *const ALG_AD[ALG_SAYISI] = {
    "seçmeli       ", "araya ekleme  ", "birleştirmeli ", "hızlı         ",
    "öbek          ", "sayma         ", "taban (LSD)   ", "kütüphane     "};

static int en_buyuk_anahtar(int tur)
{
    return tur == 3 ? 9 : ANAHTAR - 1;
}

/* tur: 0 rastgele 0..999999, 1 sıralı, 2 ters sıralı, 3 çok tekrarlı
 * 0..9 (sıralı ve ters: eşit aralıklı, aynı anahtar aralığı) */
static void girdi_uret(int *a, int n, int tur)
{
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = rastgele_aralik(0, ANAHTAR - 1);
        } else if (tur == 1) {
            a[i] = (int)((long long)i * ANAHTAR / n);
        } else if (tur == 2) {
            a[i] = (int)((long long)(n - 1 - i) * ANAHTAR / n);
        } else {
            a[i] = rastgele_aralik(0, 9);
        }
    }
}

static void calistir(int alg, int *a, int n, int tur)
{
    switch (alg) {
    case 0: secmeli_siralama(a, n); break;
    case 1: araya_ekleme_siralamasi(a, n); break;
    case 2: birlestirmeli_siralama(a, n); break;
    case 3: hizli_siralama(a, n); break;
    case 4: obek_siralamasi(a, n); break;
    case 5: sayma_siralamasi(a, n, en_buyuk_anahtar(tur)); break;
    case 6: taban_siralamasi(a, n); break;
    default: kutuphane_siralamasi(a, n); break;
    }
}

typedef struct {
    long long kar, yaz, say;
    bool dogru;
} Sonuc;

static Sonuc olcum_yap(int alg, int n, int tur)
{
    int *a = malloc((size_t)n * sizeof *a);
    int *k = malloc((size_t)n * sizeof *k);
    if (a == NULL || k == NULL) {
        exit(1);
    }
    girdi_uret(a, n, tur);
    memcpy(k, a, (size_t)n * sizeof *a);
    kutuphane_siralamasi(k, n);                        /* kâhin */
    karsilastirma_sayisi = yazma_sayisi = sayac_islemi = 0;
    calistir(alg, a, n, tur);
    Sonuc s = {karsilastirma_sayisi, yazma_sayisi, sayac_islemi,
               memcmp(a, k, (size_t)n * sizeof *a) == 0};
    free(a);
    free(k);
    return s;
}

static void sayac_tablolari(int n, Sonuc s[ALG_SAYISI][TUR_SAYISI])
{
    for (int alg = 0; alg < ALG_SAYISI; alg++) {
        for (int t = 0; t < TUR_SAYISI; t++) {
            s[alg][t] = olcum_yap(alg, n, t);
        }
    }
    const char *baslik = "  algoritma          rastgele      sıralı"
                         "  ters sıralı  çok tekrarlı\n";
    for (int tablo = 0; tablo < 3; tablo++) {
        static const char *const ad[] = {
            "karşılaştırma", "yazma (eleman)", "sayaç işlemi"};
        printf("  %s, n = %d\n%s", ad[tablo], n, baslik);
        for (int alg = 0; alg < ALG_SAYISI; alg++) {
            printf("  %s", ALG_AD[alg]);
            for (int t = 0; t < TUR_SAYISI; t++) {
                long long v = tablo == 0 ? s[alg][t].kar
                              : tablo == 1 ? s[alg][t].yaz : s[alg][t].say;
                if (alg == 7) {
                    printf(" %12s", "-");
                } else {
                    printf(" %12lld", v);
                }
            }
            printf("\n");
        }
    }
    printf("  kâhinle aynı mı (4 girdi türü):");
    int dogru = 0;
    for (int alg = 0; alg < ALG_SAYISI; alg++) {
        for (int t = 0; t < TUR_SAYISI; t++) {
            dogru += s[alg][t].dogru;
        }
    }
    printf(" %d / %d evet\n", dogru, ALG_SAYISI * TUR_SAYISI);
}

static void sure_tablosu(int n, int tekrar)
{
    int *a = malloc((size_t)n * sizeof *a);
    int *g = malloc((size_t)n * sizeof *g);
    double *t = malloc((size_t)tekrar * sizeof *t);
    if (a == NULL || g == NULL || t == NULL) {
        exit(1);
    }
    fprintf(stderr, "Süre (ms, ortanca; 1 ısınma + %d tekrar), n = %d; "
            "-: karesel, n > 50000 atlandı\n", tekrar, n);
    fprintf(stderr, "  algoritma          rastgele      sıralı"
                    "  ters sıralı  çok tekrarlı\n");
    for (int alg = 0; alg < ALG_SAYISI; alg++) {
        fprintf(stderr, "  %s", ALG_AD[alg]);
        for (int tur = 0; tur < TUR_SAYISI; tur++) {
            if (alg < 2 && n > 50000) {
                fprintf(stderr, " %12s", "-");
                continue;
            }
            girdi_uret(g, n, tur);
            for (int r = -1; r < tekrar; r++) {    /* r = -1: ısınma */
                memcpy(a, g, (size_t)n * sizeof *a);
                double t0 = zaman_sn();
                calistir(alg, a, n, tur);
                if (r >= 0) {
                    t[r] = (zaman_sn() - t0) * 1000.0;
                }
            }
            fprintf(stderr, " %12.3f", ortanca(t, tekrar));
        }
        fprintf(stderr, "\n");
    }
    free(a);
    free(g);
    free(t);
}

int main(int argc, char *argv[])
{
    if (argc > 1) {                        /* ölçüm kipi */
        char *son1 = NULL, *son2 = NULL;
        long n = argc > 2 ? strtol(argv[2], &son1, 10) : 100000;
        long tekrar = argc > 3 ? strtol(argv[3], &son2, 10) : 5;
        if (strcmp(argv[1], "olc") != 0 || (son1 && *son1 != '\0') ||
            (son2 && *son2 != '\0') || n < 10 || n > 10000000 ||
            tekrar < 1 || tekrar > 101) {
            fprintf(stderr, "kullanım: %s [olc [n=100000] [tekrar=5]]\n",
                    argv[0]);
            return 2;
        }
        Sonuc s[ALG_SAYISI][TUR_SAYISI];
        printf("Ölçüm kipi: sayaçlar stdout'a, süreler stderr'e\n");
        if (n <= 50000) {
            sayac_tablolari((int)n, s);
        }
        sure_tablosu((int)n, (int)tekrar);
        return 0;
    }
    printf("Sıralama karşılaştırma deneyi (sayaçlar; süre için: olc N)\n");
    printf("Girdi türleri: rastgele 0..999999 (tohum 42), sıralı ve ters "
           "sıralı (eşit aralıklı), çok tekrarlı 0..9\n\n");
    static Sonuc s1[ALG_SAYISI][TUR_SAYISI], s2[ALG_SAYISI][TUR_SAYISI];
    printf("1) n = 1000\n");
    sayac_tablolari(1000, s1);
    printf("\n2) n = 2000\n");
    sayac_tablolari(2000, s2);

    printf("\n3) Oran testi: iş(2000) / iş(1000), iş = karş. + yazma + "
           "sayaç işlemi\n");
    printf("   beklenen: karesel ~4, n log n ~2,2, doğrusal ~2; sayma "
           "(k = 10^6) ~1\n");
    printf("  algoritma          rastgele      sıralı  ters sıralı  "
           "çok tekrarlı\n");
    for (int alg = 0; alg < ALG_SAYISI - 1; alg++) {
        printf("  %s", ALG_AD[alg]);
        for (int t = 0; t < TUR_SAYISI; t++) {
            long long i1 = s1[alg][t].kar + s1[alg][t].yaz + s1[alg][t].say;
            long long i2 = s2[alg][t].kar + s2[alg][t].yaz + s2[alg][t].say;
            printf(" %12.3f", (double)i2 / (double)i1);
        }
        printf("\n");
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (algoritma ve kararlılık belirtilmez);
 * C++ — std::sort (introsort; en kötü O(n log n)), std::stable_sort;
 * Python — list.sort / sorted (Timsort; kararlı). */

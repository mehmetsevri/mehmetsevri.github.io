/* H07_05_obek_siralamasi.c — AP-2 Hafta 7 · Örnek 5 (★★)
 * Amaç    : Öbek sıralaması: öbek kur, kökü sona al, kalanı aşağı süz;
 *           yerinde ve en kötü durumda O(n log n); kararsızlık gösterimi
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_05_obek_siralamasi.c ortak_rastgele.c \
 *           -o H07_05_obek_siralamasi -lm
 * Çalıştır: ./H07_05_obek_siralamasi [n_ust=10000]
 * Eşleri  : cpp/H07_05_obek_siralamasi.cpp ·
 *           python/H07_05_obek_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long karsilastirma_sayisi = 0;
static long long takas_sayisi = 0;

static bool buyuk_mu(int x, int y)
{
    karsilastirma_sayisi++;
    return x > y;
}

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
    takas_sayisi++;
}

static void asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;  /* sol çocuk */
        if (c + 1 < n && buyuk_mu(a[c + 1], a[c])) {
            c++;  /* sağ çocuk daha büyük */
        }
        if (!buyuk_mu(a[c], a[i])) {
            break;
        }
        takas(&a[i], &a[c]);
        i = c;
    }
}

static void obek_kur(int *a, int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
}

/* a[son+1..n-1] sıralı ve en büyükler; a[0..son] en büyük öbek */
static void obek_siralamasi(int *a, int n)
{
    obek_kur(a, n);
    for (int son = n - 1; son > 0; son--) {
        takas(&a[0], &a[son]);  /* en büyük yerine */
        asagi_suz(a, son, 0);  /* kalan öbeği onar */
    }
}

/* --- Kararlılık gösterimi: aynı algoritma, kayıtlar (anahtar: not) --- */
typedef struct {
    int not_;
    const char *ad;
} Kayit;

static void kayit_suz(Kayit *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c + 1].not_ > a[c].not_) {
            c++;
        }
        if (a[c].not_ <= a[i].not_) {
            break;
        }
        Kayit g = a[i];
        a[i] = a[c];
        a[c] = g;
        i = c;
    }
}

static void kayit_siralamasi(Kayit *a, int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) {
        kayit_suz(a, n, i);
    }
    for (int son = n - 1; son > 0; son--) {
        Kayit g = a[0];
        a[0] = a[son];
        a[son] = g;
        kayit_suz(a, son, 0);
    }
}

static void kayitlari_yaz(const Kayit *a, int n)
{
    for (int i = 0; i < n; i++) {
        printf(" (%d %s)", a[i].not_, a[i].ad);
    }
    printf("\n");
}

static void dizi_yaz(const int *a, int n, int ayrac)
{
    printf("[");
    for (int i = 0; i < n; i++) {
        printf(i > 0 ? (i == ayrac ? " | %d" : " %d") : "%d", a[i]);
    }
    printf("]\n");
}

static int artan_karsilastir(const void *x, const void *y)
{
    int p = *(const int *)x, q = *(const int *)y;
    return (p > q) - (p < q);
}

/* tur: 0 rastgele, 1 sıralı, 2 ters sıralı, 3 çok tekrarlı (0..9) */
static void doldur(int *a, int n, int tur)
{
    rastgele_tohum(42);
    for (int i = 0; i < n; i++) {
        if (tur == 0) {
            a[i] = (int)rastgele_sayi();
        } else if (tur == 1) {
            a[i] = i;
        } else if (tur == 2) {
            a[i] = n - i;
        } else {
            a[i] = rastgele_aralik(0, 9);
        }
    }
}

static void sayac_satiri(int n, int tur)
{
    static const char *const ad[] = {"rastgele", "sıralı", "ters sıralı",
                                     "çok tekrarlı"};
    int *a = malloc((size_t)n * sizeof *a);
    int *k = malloc((size_t)n * sizeof *k);
    if (a == NULL || k == NULL) {
        exit(1);
    }
    doldur(a, n, tur);
    doldur(k, n, tur);
    qsort(k, (size_t)n, sizeof *k, artan_karsilastir);   /* kâhin */
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
    obek_siralamasi(a, n);
    bool dogru = true;
    for (int i = 0; i < n; i++) {
        dogru = dogru && a[i] == k[i];
    }
    double nlogn = n * log2((double)n);
    printf("%7d %10lld %10lld %8.3f %8.3f  %s  %s\n", n,
           karsilastirma_sayisi, takas_sayisi, karsilastirma_sayisi / nlogn,
           takas_sayisi / nlogn, dogru ? "evet" : "HAYIR", ad[tur]);
    free(a);
    free(k);
}

int main(int argc, char *argv[])
{
    long n_ust = 10000;
    if (argc > 1) {
        char *son;
        n_ust = strtol(argv[1], &son, 10);
        if (*son != '\0' || n_ust < 1000 || n_ust > 100000000) {
            fprintf(stderr, "kullanım: %s [n_ust: 1000..100000000]\n",
                    argv[0]);
            return 2;
        }
    }
    int a[] = {71, 84, 63, 95, 52, 90, 45, 88, 79, 92};
    const int n = 10;

    printf("1) Öbek sıralaması adım adım (| sağı: sıralı bölge)\n");
    printf("  girdi       : ");
    dizi_yaz(a, n, n);
    karsilastirma_sayisi = 0;
    takas_sayisi = 0;
    obek_kur(a, n);
    printf("  öbek kuruldu: ");
    dizi_yaz(a, n, n);
    for (int son = n - 1; son > 0; son--) {
        takas(&a[0], &a[son]);
        asagi_suz(a, son, 0);
        printf("  son = %d     : ", son);
        dizi_yaz(a, n, son);
    }
    printf("  karşılaştırma = %lld, takas = %lld (öbek kurma dahil)\n",
           karsilastirma_sayisi, takas_sayisi);

    printf("\n2) Kararlı mı? Eşit notlu kayıtların sırası korunuyor mu?\n");
    Kayit k[] = {{70, "Ada"}, {85, "Banu"}, {70, "Cem"}, {90, "Defne"},
                 {85, "Emre"}, {70, "Filiz"}, {85, "Gül"}};
    printf("  girdi :");
    kayitlari_yaz(k, 7);
    kayit_siralamasi(k, 7);
    printf("  çıktı :");
    kayitlari_yaz(k, 7);
    printf("  70'ler girdide Ada, Cem, Filiz sırasındaydı: öbek sıralaması "
           "kararsızdır\n");

    printf("\n3) Sayaçlar: girdi düzeninden neredeyse bağımsız "
           "(uyarlanabilir değil)\n");
    printf("      n karşılaştır.      takas  k/nlogn  t/nlogn  kâhin  "
           "girdi\n");
    for (int tur = 0; tur < 4; tur++) {
        for (long m = 1000; m <= n_ust; m *= 10) {
            sayac_satiri((int)m, tur);
        }
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort algoritmayı belirtmez; yalnızca
 * kâhin); C++ — std::make_heap + std::sort_heap, std::partial_sort;
 * Python — heapq ile (heapify + n kez heappop; yerinde değil). */

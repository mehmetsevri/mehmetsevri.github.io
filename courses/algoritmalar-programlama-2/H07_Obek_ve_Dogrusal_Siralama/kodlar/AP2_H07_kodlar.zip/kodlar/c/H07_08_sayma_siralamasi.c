/* H07_08_sayma_siralamasi.c — AP-2 Hafta 7 · Örnek 8 (★)
 * Amaç    : Sayma sıralaması (0–100 notlar): değeri indis olarak kullan,
 *           say, sayaçları sırayla geri yaz; Θ(n + k), anahtar
 *           karşılaştırması yok; not dağılımı (histogram)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_08_sayma_siralamasi.c ortak_rastgele.c \
 *           -o H07_08_sayma_siralamasi
 * Çalıştır: ./H07_08_sayma_siralamasi
 * Eşleri  : cpp/H07_08_sayma_siralamasi.cpp ·
 *           python/H07_08_sayma_siralamasi.py
 * Çıktı   : üç dilde aynı (=)
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "ortak_rastgele.h"

static long long adim_sayisi = 0;

/* a[0..n-1] içindeki anahtarlar 0..k aralığında olmalı (bkz. Hata Avcısı) */
static void sayma_siralamasi(int *a, int n, int k)
{
    /* calloc: sıfırlanmış bellek */
    int *sayac = calloc((size_t)k + 1, sizeof *sayac);
    if (sayac == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        sayac[a[i]]++;  /* değer = indis */
        adim_sayisi++;
    }
    int j = 0;
    /* sayaçları sırayla geri yaz */
    for (int v = 0; v <= k; v++) {
        adim_sayisi++;
        for (int c = 0; c < sayac[v]; c++) {
            a[j++] = v;
            adim_sayisi++;
        }
    }
    free(sayac);
}

static int artan(const void *x, const void *y)            /* kâhin için */
{
    int p = *(const int *)x, q = *(const int *)y;
    return (p > q) - (p < q);
}

static int *rastgele_notlar(int n, int k)
{
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        exit(1);
    }
    rastgele_tohum(42);
    rastgele_dizi(a, (size_t)n, 0, k);
    return a;
}

static void maliyet_satiri(int n, int k)
{
    int *a = rastgele_notlar(n, k);
    int *b = rastgele_notlar(n, k);
    qsort(b, (size_t)n, sizeof *b, artan);                /* kâhin */
    adim_sayisi = 0;
    sayma_siralamasi(a, n, k);
    bool dogru = true;
    for (int i = 0; i < n; i++) {
        dogru = dogru && a[i] == b[i];
    }
    printf("%9d %9d %12lld %12lld %9.3f %10lld  %s\n", n, k, adim_sayisi,
           2LL * n + k + 1, (double)adim_sayisi / n, 4LL * (k + 1),
           dogru ? "evet" : "HAYIR");
    free(a);
    free(b);
}

int main(void)
{
    int a[] = {85, 70, 100, 45, 70, 90, 85, 0, 55, 70, 100, 85, 62, 45, 90};
    const int n = (int)(sizeof a / sizeof a[0]);

    printf("1) %d not, anahtarlar 0..100\n  girdi :", n);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    int sayac[101] = {0};
    for (int i = 0; i < n; i++) {
        sayac[a[i]]++;
    }
    printf("\n  sıfır olmayan sayaçlar:");
    for (int v = 0; v <= 100; v++) {
        if (sayac[v] > 0) {
            printf(" [%d]=%d", v, sayac[v]);
        }
    }
    adim_sayisi = 0;
    sayma_siralamasi(a, n, 100);
    printf("\n  çıktı :");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n  adım = %lld = 2n + k + 1 = %d; anahtar karşılaştırması: 0\n",
           adim_sayisi, 2 * n + 100 + 1);

    printf("\n2) Not dağılımı: 1000 öğrenci (tohum 42), 10'luk aralıklar\n");
    int *b = rastgele_notlar(1000, 100);
    sayma_siralamasi(b, 1000, 100);
    int i = 0;
    for (int alt = 0; alt <= 90; alt += 10) {
        int ust = alt == 90 ? 100 : alt + 9;
        int adet = 0;
        while (i < 1000 && b[i] <= ust) {   /* sıralı: aralık ardışık */
            adet++;
            i++;
        }
        printf("  %3d-%3d %4d ", alt, ust, adet);
        for (int y = 0; y < adet / 5; y++) {
            printf("#");
        }
        printf("\n");
    }
    printf("  ortanca (500. ve 501. not): %d, %d\n", b[499], b[500]);
    free(b);

    printf("\n3) Maliyet: adım = 2n + k + 1 (sayma n, tarama k + 1, "
           "yazma n);\n   4(k+1) B: C'deki int sayaç dizisinin baytı\n");
    printf("        n         k         adım   2n + k + 1    adım/n"
           "   4(k+1) B  kâhin\n");
    for (int m = 1000; m <= 1000000; m *= 10) {
        maliyet_satiri(m, 100);
    }
    printf("  k büyürse (n = 1000): adım ve bellek k ile büyür\n");
    for (int k = 100; k <= 1000000; k *= 100) {
        maliyet_satiri(1000, k);
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort karşılaştırmalıdır; yalnızca
 * kâhin); C++ — yok (std::sort karşılaştırmalıdır); Python — yok
 * (sorted karşılaştırmalıdır; collections.Counter yalnızca sayar). */

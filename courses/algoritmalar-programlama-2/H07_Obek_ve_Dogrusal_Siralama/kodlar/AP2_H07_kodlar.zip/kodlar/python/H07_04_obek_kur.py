"""H07_04_obek_kur.py — AP-2 Hafta 7 · Örnek 4 (★★)
Amaç    : Aşağıdan yukarıya öbek kurma (son iç düğümden köke aşağı
          süzme) ve takas sayısı: takas <= Σ yükseklik = n - popcount(n)
          < n, yani O(n); tek tek eklemeyle kurmanın O(n log n) en kötüsü
Çalıştır: python3 H07_04_obek_kur.py [n_ust=100000]
Eşleri  : c/H07_04_obek_kur.c · cpp/H07_04_obek_kur.cpp
Çıktı   : üç dilde aynı (=)
"""
import math
import sys

from ortak_rastgele import rastgele_sayi, rastgele_tohum

karsilastirma_sayisi = 0
takas_sayisi = 0


def ebeveyn(i):
    return (i - 1) // 2


def buyuk_mu(x, y):
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return x > y


def takas(a, i, j):
    global takas_sayisi
    a[i], a[j] = a[j], a[i]
    takas_sayisi += 1


def asagi_suz(a, n, i):
    while 2 * i + 1 < n:
        c = 2 * i + 1  # sol çocuk
        if c + 1 < n and buyuk_mu(a[c + 1], a[c]):
            c += 1  # sağ çocuk daha büyük
        if not buyuk_mu(a[c], a[i]):
            break
        takas(a, i, c)
        i = c


def yukari_suz(a, i):
    while i > 0 and buyuk_mu(a[i], a[ebeveyn(i)]):
        takas(a, i, ebeveyn(i))
        i = ebeveyn(i)


# Aşağıdan yukarıya: yapraklar zaten öbektir; son iç düğümden köke
def obek_kur(a):
    n = len(a)
    for i in range(n // 2 - 1, -1, -1):
        asagi_suz(a, n, i)


# Yukarıdan aşağıya: a[0..i-1] öbeğine a[i]'yi ekler gibi yukarı süz
def obek_kur_ekleyerek(a):
    for i in range(1, len(a)):
        yukari_suz(a, i)


def obek_mi(a):
    for i in range(1, len(a)):
        if a[ebeveyn(i)] < a[i]:
            return False
    return True


def yukseklik(i, n):
    """i. düğümün yüksekliği: altındaki en uzun yol (en soldaki yol)"""
    h = 0
    while 2 * i + 1 < n:
        i = 2 * i + 1
        h += 1
    return h


def yukseklik_toplami(n):
    t = 0
    for i in range(n):
        t += yukseklik(i, n)
    return t


def birler(n):                       # ikilik gösterimdeki 1 sayısı
    b = 0
    while n > 0:
        b += n & 1
        n >>= 1
    return b


def dizi_yaz(a):
    print("[" + " ".join(str(x) for x in a) + "]")


def sayaclari_sifirla():
    global karsilastirma_sayisi, takas_sayisi
    karsilastirma_sayisi = 0
    takas_sayisi = 0


def doldur(n, artan):
    rastgele_tohum(42)
    a = [0] * n
    for i in range(n):
        a[i] = i if artan else rastgele_sayi()
    return a


def izleme():
    a = [45, 52, 63, 71, 79, 84, 88, 90, 92, 95]
    n = 10
    print("1) Aşağıdan yukarıya kurma, artan girdi (n = 10)\n   ", end="")
    dizi_yaz(a)
    sayaclari_sifirla()
    for i in range(n // 2 - 1, -1, -1):
        once = takas_sayisi
        asagi_suz(a, n, i)
        print(f"  i = {i} (a[i] süzüldü, takas = {takas_sayisi - once})  ",
              end="")
        dizi_yaz(a)
    print(f"  toplam: karşılaştırma = {karsilastirma_sayisi}, "
          f"takas = {takas_sayisi}, öbek mi? "
          + ("evet" if obek_mi(a) else "HAYIR"))
    print(f"  üst sınır Σ yükseklik = {yukseklik_toplami(n)} "
          f"(n - popcount(n) = {n - birler(n)})")
    b = [45, 52, 63, 71, 79, 84, 88, 90, 92, 95]
    sayaclari_sifirla()
    obek_kur_ekleyerek(b)
    print(f"  aynı girdi tek tek eklemeyle: takas = {takas_sayisi}, "
          "öbek mi? " + ("evet" if obek_mi(b) else "HAYIR") + "  ", end="")
    dizi_yaz(b)


def duzey_tablosu(buyuk_h):
    """Mükemmel ağaçta (n = 2^(H+1) - 1) düzeylere göre iş"""
    n = (1 << (buyuk_h + 1)) - 1
    a = doldur(n, True)
    r = doldur(n, False)
    ta = [0] * (buyuk_h + 1)
    tr = [0] * (buyuk_h + 1)
    for i in range(n // 2 - 1, -1, -1):
        d = 0
        j = i
        while j > 0:
            j = ebeveyn(j)
            d += 1
        once = takas_sayisi
        asagi_suz(a, n, i)
        ta[d] += takas_sayisi - once
        once = takas_sayisi
        asagi_suz(r, n, i)
        tr[d] += takas_sayisi - once
    print(f"\n2) Düzeylere göre iş: mükemmel ağaç, n = {n}")
    print("  düzey  düğüm  yükseklik  üst sınır  artan girdi  rastgele")
    top_s, top_a, top_r = 0, 0, 0
    for d in range(buyuk_h + 1):
        dugum, h = 1 << d, buyuk_h - d
        print(f"{d:7d} {dugum:6d} {h:10d} {dugum * h:10d} {ta[d]:12d} "
              f"{tr[d]:9d}")
        top_s += dugum * h
        top_a += ta[d]
        top_r += tr[d]
    print(f"  toplam {n:6d} {'':10s} {top_s:10d} {top_a:12d} {top_r:9d}")


def asagidan_satiri(n):
    a = doldur(n, False)
    sayaclari_sifirla()
    obek_kur(a)
    t_r, k_r = takas_sayisi, karsilastirma_sayisi
    ok = obek_mi(a)
    a = doldur(n, True)
    sayaclari_sifirla()
    obek_kur(a)
    t_a = takas_sayisi
    ok = ok and obek_mi(a)
    s = yukseklik_toplami(n)
    esit = "evet" if s == n - birler(n) else "HAYIR"
    print(f"{n:9d} {t_r:10d} {t_a:10d} {s:10d} {esit:>6s} {t_r / n:7.3f} "
          f"{t_a / n:7.3f} {k_r / n:7.3f} " + ("evet" if ok else "HAYIR"))


def ekleyerek_satiri(n):
    a = doldur(n, False)
    sayaclari_sifirla()
    obek_kur_ekleyerek(a)
    e_r = takas_sayisi
    a = doldur(n, True)
    sayaclari_sifirla()
    obek_kur_ekleyerek(a)
    e_a = takas_sayisi
    print(f"{n:9d} {e_r:10d} {e_a:10d} {e_r / n:7.3f} {e_a / n:7.3f} "
          f"{math.log2(n):7.3f}")


def main():
    n_ust = 100000
    if len(sys.argv) > 1:
        try:
            n_ust = int(sys.argv[1])
        except ValueError:
            n_ust = -1
        if n_ust < 10 or n_ust > 100000000:
            print(f"kullanım: {sys.argv[0]} [n_ust: 10..100000000]",
                  file=sys.stderr)
            sys.exit(2)
    izleme()
    duzey_tablosu(9)
    print("\n3) Aşağıdan yukarıya: takas / n sabit kalıyor mu?")
    print("  r: rastgele, a: artan girdi; t: takas, k: karşılaştırma; "
          "n-pc?: Σ yüks. = n - popcount(n) mi?")
    print("        n    takas r    takas a    Σ yüks.  n-pc?   t/n r"
          "   t/n a   k/n r öbek?")
    n = 10
    while n <= n_ust:
        asagidan_satiri(n)
        n *= 10
    print("\n4) Tek tek ekleyerek kurma (yukarı süzme)")
    print("        n    takas r    takas a   t/n r   t/n a  log2 n")
    n = 10
    while n <= n_ust:
        ekleyerek_satiri(n)
        n *= 10


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::make_heap (doğrusal
# zamanda kurar: en çok 3n karşılaştırma); Python — heapq.heapify(a)
# (en küçük öbek, doğrusal zaman).

"""H07_08_sayma_siralamasi.py — AP-2 Hafta 7 · Örnek 8 (★)
Amaç    : Sayma sıralaması (0–100 notlar): değeri indis olarak kullan,
          say, sayaçları sırayla geri yaz; Θ(n + k), anahtar
          karşılaştırması yok; not dağılımı (histogram)
Çalıştır: python3 H07_08_sayma_siralamasi.py
Eşleri  : c/H07_08_sayma_siralamasi.c · cpp/H07_08_sayma_siralamasi.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_dizi, rastgele_tohum

adim_sayisi = 0


def sayma_siralamasi(a, k):
    """a içindeki anahtarlar 0..k aralığında olmalı (bkz. Hata Avcısı)"""
    global adim_sayisi
    sayac = [0] * (k + 1)  # sıfırlı
    for x in a:
        sayac[x] += 1  # değer = indis
        adim_sayisi += 1
    j = 0
    # sayaçları sırayla geri yaz
    for v in range(k + 1):
        adim_sayisi += 1
        for _ in range(sayac[v]):
            a[j] = v
            j += 1
            adim_sayisi += 1


def rastgele_notlar(n, k):
    rastgele_tohum(42)
    return rastgele_dizi(n, 0, k)


def maliyet_satiri(n, k):
    global adim_sayisi
    a = rastgele_notlar(n, k)
    b = sorted(a)                                       # kâhin
    adim_sayisi = 0
    sayma_siralamasi(a, k)
    dogru = (a == b)
    print(f"{n:9d} {k:9d} {adim_sayisi:12d} {2 * n + k + 1:12d} "
          f"{adim_sayisi / n:9.3f} {4 * (k + 1):10d}  "
          + ("evet" if dogru else "HAYIR"))


def main():
    global adim_sayisi
    a = [85, 70, 100, 45, 70, 90, 85, 0, 55, 70, 100, 85, 62, 45, 90]
    n = len(a)

    print(f"1) {n} not, anahtarlar 0..100\n  girdi :"
          + "".join(f" {x}" for x in a))
    sayac = [0] * 101
    for x in a:
        sayac[x] += 1
    print("  sıfır olmayan sayaçlar:"
          + "".join(f" [{v}]={sayac[v]}" for v in range(101) if sayac[v]))
    adim_sayisi = 0
    sayma_siralamasi(a, 100)
    print("  çıktı :" + "".join(f" {x}" for x in a))
    print(f"  adım = {adim_sayisi} = 2n + k + 1 = {2 * n + 100 + 1}; "
          "anahtar karşılaştırması: 0")

    print("\n2) Not dağılımı: 1000 öğrenci (tohum 42), 10'luk aralıklar")
    b = rastgele_notlar(1000, 100)
    sayma_siralamasi(b, 100)
    i = 0
    for alt in range(0, 91, 10):
        ust = 100 if alt == 90 else alt + 9
        adet = 0
        while i < 1000 and b[i] <= ust:    # sıralı: aralık ardışık
            adet += 1
            i += 1
        print(f"  {alt:3d}-{ust:3d} {adet:4d} " + "#" * (adet // 5))
    print(f"  ortanca (500. ve 501. not): {b[499]}, {b[500]}")

    print("\n3) Maliyet: adım = 2n + k + 1 (sayma n, tarama k + 1, "
          "yazma n);\n   4(k+1) B: C'deki int sayaç dizisinin baytı")
    print("        n         k         adım   2n + k + 1    adım/n"
          "   4(k+1) B  kâhin")
    m = 1000
    while m <= 1000000:
        maliyet_satiri(m, 100)
        m *= 10
    print("  k büyürse (n = 1000): adım ve bellek k ile büyür")
    k = 100
    while k <= 1000000:
        maliyet_satiri(1000, k)
        k *= 100


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (qsort karşılaştırmalıdır; yalnızca
# kâhin); C++ — yok (std::sort karşılaştırmalıdır); Python — yok
# (sorted karşılaştırmalıdır; collections.Counter yalnızca sayar).

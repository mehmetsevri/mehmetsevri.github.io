"""H07_12_siralama_karsilastirma.py — AP-2 Hafta 7 · Örnek 12 (★★★)
Amaç    : Sıralama karşılaştırma deneyi: sekiz algoritma × dört girdi
          türü × n. Varsayılan: deterministik sayaçlar + kâhin denetimi
          + oran testi; "olc N [tekrar]": süre tablosu (stderr)
Çalıştır: python3 H07_12_siralama_karsilastirma.py  |  ... olc 10000 5
Eşleri  : c/H07_12_siralama_karsilastirma.c ·
          cpp/H07_12_siralama_karsilastirma.cpp
Çıktı   : üç dilde aynı (=) — süreler stderr'e
"""
import sys

from ortak_rastgele import rastgele_aralik, rastgele_tohum
from zamanlayici import ortanca, zaman_sn

ALG_SAYISI = 8
TUR_SAYISI = 4
ANAHTAR = 1000000                  # rastgele/sıralı/ters: 0..999999

karsilastirma_sayisi = 0
yazma_sayisi = 0                           # diziye eleman yazma
sayac_islemi = 0                           # sayaç dizisi adımları


def kucuk_mu(x, y):
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return x < y


def takas(a, i, j):
    global yazma_sayisi
    a[i], a[j] = a[j], a[i]
    yazma_sayisi += 2


def secmeli_siralama(a):
    """1. Seçmeli: a[i..n-1]'in en küçüğünü i'ye getir"""
    n = len(a)
    for i in range(n - 1):
        m = i
        for j in range(i + 1, n):
            if kucuk_mu(a[j], a[m]):
                m = j
        if m != i:
            takas(a, i, m)


def araya_ekleme_siralamasi(a):
    """2. Araya ekleme: a[i]'yi sıralı a[0..i-1] içine kaydırarak yerleştir"""
    global yazma_sayisi
    for i in range(1, len(a)):
        x = a[i]
        j = i - 1
        while j >= 0 and kucuk_mu(x, a[j]):
            a[j + 1] = a[j]
            yazma_sayisi += 1
            j -= 1
        a[j + 1] = x
        yazma_sayisi += 1


def birlestir(a, g, lo, orta, hi):
    """3. Birleştirmeli: a[lo..orta) ve a[orta..hi) -> g -> a (kararlı)"""
    global yazma_sayisi
    i, j, k = lo, orta, lo
    while i < orta and j < hi:
        if kucuk_mu(a[j], a[i]):
            g[k] = a[j]
            j += 1
        else:
            g[k] = a[i]
            i += 1
        k += 1
    while i < orta:
        g[k] = a[i]
        i, k = i + 1, k + 1
    while j < hi:
        g[k] = a[j]
        j, k = j + 1, k + 1
    a[lo:hi] = g[lo:hi]
    yazma_sayisi += 2 * (hi - lo)


def birlestirmeli_ozyineli(a, g, lo, hi):
    if hi - lo < 2:
        return
    orta = lo + (hi - lo) // 2
    birlestirmeli_ozyineli(a, g, lo, orta)
    birlestirmeli_ozyineli(a, g, orta, hi)
    birlestir(a, g, lo, orta, hi)


def birlestirmeli_siralama(a):
    g = [0] * len(a)
    birlestirmeli_ozyineli(a, g, 0, len(a))


def bolumle(a, lo, hi):
    """4. Hızlı: üçün ortancası pivot, Hoare bölümlemesi (a[lo..hi] kapalı)"""
    orta = lo + (hi - lo) // 2
    if kucuk_mu(a[orta], a[lo]):
        takas(a, orta, lo)
    if kucuk_mu(a[hi], a[lo]):
        takas(a, hi, lo)
    if kucuk_mu(a[hi], a[orta]):
        takas(a, hi, orta)
    pivot = a[orta]
    i, j = lo - 1, hi + 1
    while True:
        i += 1
        while kucuk_mu(a[i], pivot):
            i += 1
        j -= 1
        while kucuk_mu(pivot, a[j]):
            j -= 1
        if i >= j:
            return j               # a[lo..j] <= pivot <= a[j+1..hi]
        takas(a, i, j)


def hizli_ozyineli(a, lo, hi):
    """Küçük parçada özyineleme, büyük parçada döngü: yığın derinliği
    O(log n)"""
    while lo < hi:
        p = bolumle(a, lo, hi)
        if p - lo < hi - p:
            hizli_ozyineli(a, lo, p)
            lo = p + 1
        else:
            hizli_ozyineli(a, p + 1, hi)
            hi = p


def hizli_siralama(a):
    hizli_ozyineli(a, 0, len(a) - 1)


def asagi_suz(a, n, i):
    """5. Öbek (Örnek 5)"""
    while 2 * i + 1 < n:
        c = 2 * i + 1
        if c + 1 < n and kucuk_mu(a[c], a[c + 1]):
            c += 1
        if not kucuk_mu(a[i], a[c]):
            break
        takas(a, i, c)
        i = c


def obek_siralamasi(a):
    n = len(a)
    for i in range(n // 2 - 1, -1, -1):
        asagi_suz(a, n, i)
    for son in range(n - 1, 0, -1):
        takas(a, 0, son)
        asagi_suz(a, son, 0)


def sayma_siralamasi(a, k):
    """6. Sayma (Örnek 8): anahtarlar 0..k"""
    global sayac_islemi, yazma_sayisi
    n = len(a)
    sayac = [0] * (k + 1)
    for x in a:
        sayac[x] += 1
    j = 0
    for v in range(k + 1):
        for _ in range(sayac[v]):
            a[j] = v
            j += 1
    sayac_islemi += n + k + 1
    yazma_sayisi += n


def taban_siralamasi(a):
    """7. Taban (Örnek 10): 256 tabanı, 4 kararlı geçiş (anahtarlar >= 0)"""
    global sayac_islemi, yazma_sayisi
    n = len(a)
    kaynak, hedef = a, [0] * n
    for kaydir in range(0, 32, 8):
        onek = [0] * 256
        for x in kaynak:
            onek[(x >> kaydir) & 0xFF] += 1
        for v in range(1, 256):
            onek[v] += onek[v - 1]
        for i in range(n - 1, -1, -1):
            v = (kaynak[i] >> kaydir) & 0xFF
            onek[v] -= 1
            hedef[onek[v]] = kaynak[i]
        kaynak, hedef = hedef, kaynak
        sayac_islemi += n + 255
        yazma_sayisi += n
    # 4 geçiş: kaynak yeniden a nesnesidir (sonuç a'da)


def kutuphane_siralamasi(a):
    """8. Kütüphane: list.sort (Timsort; sayaç yok)"""
    a.sort()


ALG_AD = ["seçmeli       ", "araya ekleme  ", "birleştirmeli ",
          "hızlı         ", "öbek          ", "sayma         ",
          "taban (LSD)   ", "kütüphane     "]


def en_buyuk_anahtar(tur):
    return 9 if tur == 3 else ANAHTAR - 1


def girdi_uret(n, tur):
    """tur: 0 rastgele 0..999999, 1 sıralı, 2 ters sıralı, 3 çok tekrarlı
    0..9 (sıralı ve ters: eşit aralıklı, aynı anahtar aralığı)"""
    rastgele_tohum(42)
    a = [0] * n
    for i in range(n):
        if tur == 0:
            a[i] = rastgele_aralik(0, ANAHTAR - 1)
        elif tur == 1:
            a[i] = i * ANAHTAR // n
        elif tur == 2:
            a[i] = (n - 1 - i) * ANAHTAR // n
        else:
            a[i] = rastgele_aralik(0, 9)
    return a


def calistir(alg, a, tur):
    if alg == 0:
        secmeli_siralama(a)
    elif alg == 1:
        araya_ekleme_siralamasi(a)
    elif alg == 2:
        birlestirmeli_siralama(a)
    elif alg == 3:
        hizli_siralama(a)
    elif alg == 4:
        obek_siralamasi(a)
    elif alg == 5:
        sayma_siralamasi(a, en_buyuk_anahtar(tur))
    elif alg == 6:
        taban_siralamasi(a)
    else:
        kutuphane_siralamasi(a)


def olcum_yap(alg, n, tur):
    """Dönüş: (karşılaştırma, yazma, sayaç işlemi, doğru mu)"""
    global karsilastirma_sayisi, yazma_sayisi, sayac_islemi
    a = girdi_uret(n, tur)
    k = a[:]
    kutuphane_siralamasi(k)                            # kâhin
    karsilastirma_sayisi = yazma_sayisi = sayac_islemi = 0
    calistir(alg, a, tur)
    return (karsilastirma_sayisi, yazma_sayisi, sayac_islemi, a == k)


def sayac_tablolari(n):
    s = [[olcum_yap(alg, n, t) for t in range(TUR_SAYISI)]
         for alg in range(ALG_SAYISI)]
    baslik = ("  algoritma          rastgele      sıralı"
              "  ters sıralı  çok tekrarlı")
    ad = ["karşılaştırma", "yazma (eleman)", "sayaç işlemi"]
    for tablo in range(3):
        print(f"  {ad[tablo]}, n = {n}\n{baslik}")
        for alg in range(ALG_SAYISI):
            satir = "  " + ALG_AD[alg]
            for t in range(TUR_SAYISI):
                if alg == 7:
                    satir += f" {'-':>12}"
                else:
                    satir += f" {s[alg][t][tablo]:12d}"
            print(satir)
    dogru = sum(r[3] for satir in s for r in satir)
    print(f"  kâhinle aynı mı (4 girdi türü): {dogru} / "
          f"{ALG_SAYISI * TUR_SAYISI} evet")
    return s


def sure_tablosu(n, tekrar):
    print(f"Süre (ms, ortanca; 1 ısınma + {tekrar} tekrar), n = {n}; "
          "-: karesel, n > 50000 atlandı", file=sys.stderr)
    print("  algoritma          rastgele      sıralı"
          "  ters sıralı  çok tekrarlı", file=sys.stderr)
    for alg in range(ALG_SAYISI):
        satir = "  " + ALG_AD[alg]
        for tur in range(TUR_SAYISI):
            if alg < 2 and n > 50000:
                satir += f" {'-':>12}"
                continue
            g = girdi_uret(n, tur)
            t = []
            for r in range(-1, tekrar):    # r = -1: ısınma
                a = g[:]
                t0 = zaman_sn()
                calistir(alg, a, tur)
                if r >= 0:
                    t.append((zaman_sn() - t0) * 1000.0)
            satir += f" {ortanca(t):12.3f}"
        print(satir, file=sys.stderr)


def main():
    if len(sys.argv) > 1:              # ölçüm kipi
        try:
            n = int(sys.argv[2]) if len(sys.argv) > 2 else 100000
            tekrar = int(sys.argv[3]) if len(sys.argv) > 3 else 5
            ok = sys.argv[1] == "olc"
        except ValueError:
            ok = False
        if not ok or not 10 <= n <= 10000000 or not 1 <= tekrar <= 101:
            print(f"kullanım: {sys.argv[0]} [olc [n=100000] [tekrar=5]]",
                  file=sys.stderr)
            sys.exit(2)
        print("Ölçüm kipi: sayaçlar stdout'a, süreler stderr'e")
        if n <= 50000:
            sayac_tablolari(n)
        sure_tablosu(n, tekrar)
        return
    print("Sıralama karşılaştırma deneyi (sayaçlar; süre için: olc N)")
    print("Girdi türleri: rastgele 0..999999 (tohum 42), sıralı ve ters "
          "sıralı (eşit aralıklı), çok tekrarlı 0..9\n")
    print("1) n = 1000")
    s1 = sayac_tablolari(1000)
    print("\n2) n = 2000")
    s2 = sayac_tablolari(2000)

    print("\n3) Oran testi: iş(2000) / iş(1000), iş = karş. + yazma + "
          "sayaç işlemi")
    print("   beklenen: karesel ~4, n log n ~2,2, doğrusal ~2; sayma "
          "(k = 10^6) ~1")
    print("  algoritma          rastgele      sıralı  ters sıralı  "
          "çok tekrarlı")
    for alg in range(ALG_SAYISI - 1):
        satir = "  " + ALG_AD[alg]
        for t in range(TUR_SAYISI):
            i1 = s1[alg][t][0] + s1[alg][t][1] + s1[alg][t][2]
            i2 = s2[alg][t][0] + s2[alg][t][1] + s2[alg][t][2]
            satir += f" {i2 / i1:12.3f}"
        print(satir)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort (algoritma ve kararlılık belirtilmez);
# C++ — std::sort (introsort; en kötü O(n log n)), std::stable_sort;
# Python — list.sort / sorted (Timsort; kararlı).

"""H07_11_kova_siralamasi.py — AP-2 Hafta 7 · Örnek 11 (★★)
Amaç    : Kova sıralaması: [0, 1) aralığındaki n değer n kovaya
          dağıtılır (kova = ⌊x · n⌋), kova içleri araya eklemeyle
          sıralanır; düzgün dağılımda Θ(n), varsayım bozulursa Θ(n²)
Çalıştır: python3 H07_11_kova_siralamasi.py
Eşleri  : c/H07_11_kova_siralamasi.c · cpp/H07_11_kova_siralamasi.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_kesir, rastgele_tohum

karsilastirma_sayisi = 0
en_dolu = 0                                # en kalabalık kovanın boyu
bos_kova = 0


def araya_ekleme(a, bas, son):
    """a[bas..son-1] dilimini araya eklemeyle sıralar"""
    global karsilastirma_sayisi
    for i in range(bas + 1, son):
        x = a[i]
        j = i - 1
        while j >= bas:
            karsilastirma_sayisi += 1
            if a[j] <= x:
                break
            a[j + 1] = a[j]                # kaydır
            j -= 1
        a[j + 1] = x


def kova_no(x, n):
    k = int(x * n)                         # 0 <= x < 1
    return k if k < n else n - 1


def kova_siralamasi(a, izle):
    """Kovalar ayrı listeler yerine tek dizide ardışık dilimlerdir: kova
    boyları sayılır, önek toplamla başlangıçlar bulunur (Örnek 9)"""
    global en_dolu, bos_kova
    n = len(a)
    bas = [0] * (n + 1)
    b = [0.0] * n
    for x in a:
        bas[kova_no(x, n) + 1] += 1        # kova boyları
    for v in range(1, n + 1):
        bas[v] += bas[v - 1]               # kova v: b[bas[v]..bas[v+1])
    yer = bas[:n]
    for x in a:                            # dağıt (kararlı)
        k = kova_no(x, n)
        b[yer[k]] = x
        yer[k] += 1
    en_dolu = 0
    bos_kova = 0
    for v in range(n):
        boy = bas[v + 1] - bas[v]
        en_dolu = max(boy, en_dolu)
        bos_kova += boy == 0
        if izle:
            print(f"  kova {v} [{v / n:.1f}, {(v + 1) / n:.1f}):"
                  + "".join(f" {b[i]:.4f}" for i in range(bas[v],
                                                          bas[v + 1])))
        araya_ekleme(b, bas[v], bas[v + 1])
    a[:] = b


def uret(n, dagilim):
    """dagilim: 0 düzgün (u), 1 çarpık (u^4), 2 tek kova (0.5 + u / 2n)"""
    rastgele_tohum(42)
    a = [0.0] * n
    for i in range(n):
        u = rastgele_kesir()
        if dagilim == 0:
            a[i] = u
        elif dagilim == 1:
            a[i] = u * u * u * u
        else:
            a[i] = 0.5 + u / (2.0 * n)
    return a


def dogru_mu(a, dagilim):
    return a == sorted(uret(len(a), dagilim))           # kâhin


def main():
    global karsilastirma_sayisi
    print("1) 10 değer, 10 kova (tohum 42)\n  girdi:", end="")
    a = uret(10, 0)
    print("".join(f" {x:.4f}" for x in a))
    karsilastirma_sayisi = 0
    kova_siralamasi(a, True)
    print("  çıktı:" + "".join(f" {x:.4f}" for x in a))
    print(f"  karşılaştırma = {karsilastirma_sayisi}, boş kova = {bos_kova},"
          f" en dolu kova = {en_dolu}")

    print("\n2) Düzgün dağılım: kova başına ortalama 1 eleman")
    print("        n  karşılaştırma  karş./n  en dolu  boş kova oranı"
          "  kâhin")
    n = 1000
    while n <= 100000:
        a = uret(n, 0)
        karsilastirma_sayisi = 0
        kova_siralamasi(a, False)
        print(f"{n:9d} {karsilastirma_sayisi:14d} "
              f"{karsilastirma_sayisi / n:8.3f} {en_dolu:8d} "
              f"{bos_kova / n:15.4f}  "
              + ("evet" if dogru_mu(a, 0) else "HAYIR"))
        n *= 10

    print("\n3) Dağılım varsayımı bozulursa (karş./n)")
    print("        n    düzgün  çarpık u^4   tek kova  kâhin")
    n = 1000
    while n <= 4000:
        oran = [0.0] * 3
        hepsi = True
        for d in range(3):
            a = uret(n, d)
            karsilastirma_sayisi = 0
            kova_siralamasi(a, False)
            oran[d] = karsilastirma_sayisi / n
            hepsi = hepsi and dogru_mu(a, d)
        print(f"{n:9d} {oran[0]:9.3f} {oran[1]:11.3f} {oran[2]:10.3f}  "
              + ("evet" if hepsi else "HAYIR"))
        n *= 2


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (std::sort karşılaştırmalıdır);
# Python — yok (sorted yalnızca kâhin).

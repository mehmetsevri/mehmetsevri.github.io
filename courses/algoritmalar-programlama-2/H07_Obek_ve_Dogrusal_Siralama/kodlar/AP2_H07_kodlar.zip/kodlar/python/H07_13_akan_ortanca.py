"""H07_13_akan_ortanca.py — AP-2 Hafta 7 · Örnek 13 (★★★, merak)
Amaç    : Akan veride ortanca: küçük yarı EN BÜYÜK öbekte, büyük yarı
          EN KÜÇÜK öbekte; boylar en çok 1 farklı; ekleme O(log n),
          ortanca O(1). Sıralı dizide araya eklemeyle (O(n)) karşılaştırma
Çalıştır: python3 H07_13_akan_ortanca.py
Eşleri  : c/H07_13_akan_ortanca.c · cpp/H07_13_akan_ortanca.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_aralik, rastgele_dizi, rastgele_tohum


class Obek:
    def __init__(self, en_buyuk):
        self.a = []
        self.en_buyuk = en_buyuk       # True: en büyük öbek


karsilastirma_sayisi = 0


def ustte_mi(h, x, y):
    """x, öbekte y'nin üstünde mi durmalı?"""
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return x > y if h.en_buyuk else x < y


def ekle(h, x):
    h.a.append(x)
    i = len(h.a) - 1
    while i > 0 and ustte_mi(h, h.a[i], h.a[(i - 1) // 2]):
        h.a[i], h.a[(i - 1) // 2] = h.a[(i - 1) // 2], h.a[i]
        i = (i - 1) // 2


def cikar(h):
    tepe = h.a[0]
    h.a[0] = h.a[-1]
    h.a.pop()
    n = len(h.a)
    i = 0
    while 2 * i + 1 < n:
        c = 2 * i + 1
        if c + 1 < n and ustte_mi(h, h.a[c + 1], h.a[c]):
            c += 1
        if not ustte_mi(h, h.a[c], h.a[i]):
            break
        h.a[i], h.a[c] = h.a[c], h.a[i]
        i = c
    return tepe


def ortancaya_ekle(alt, ust, x):
    """Değişmez: alt'taki her değer <= ust'teki her değer ve
    len(alt.a) == len(ust.a) ya da len(alt.a) == len(ust.a) + 1"""
    if not alt.a or not ustte_mi(alt, x, alt.a[0]):
        ekle(alt, x)  # x <= alt'ın tepesi
    else:
        ekle(ust, x)
    if len(alt.a) > len(ust.a) + 1:  # dengele
        ekle(ust, cikar(alt))
    elif len(ust.a) > len(alt.a):
        ekle(alt, cikar(ust))


def ortanca(alt, ust):
    if len(alt.a) > len(ust.a):
        return float(alt.a[0])
    return (alt.a[0] + ust.a[0]) / 2.0


def obek_yaz(ad, h):
    return ad + "[" + " ".join(str(x) for x in h.a) + "]"


def kahin_ortanca(a, n):
    b = sorted(a[:n])
    return float(b[n // 2]) if n % 2 else (b[n // 2 - 1] + b[n // 2]) / 2.0


def sirali_dizi_kaydirma(a, n):
    """Karşılaştırma için: sıralı dizide araya ekleme; kaydırma sayısı"""
    s = [0] * n
    kaydirma = 0
    for m in range(n):
        j = m - 1
        while j >= 0 and s[j] > a[m]:
            s[j + 1] = s[j]
            kaydirma += 1
            j -= 1
        s[j + 1] = a[m]
    return kaydirma


def main():
    global karsilastirma_sayisi
    print("1) 15 değerlik akış (0..99, tohum 42)")
    alt, ust = Obek(True), Obek(False)
    rastgele_tohum(42)
    for k in range(15):
        x = rastgele_aralik(0, 99)
        ortancaya_ekle(alt, ust, x)
        print(f"  {k + 1:2d}. gelen {x:2d}  ortanca = {ortanca(alt, ust):5.1f}"
              "  " + obek_yaz("alt (en büyük) ", alt)
              + obek_yaz("  üst (en küçük) ", ust))

    print("\n2) 100000 değerlik akış (0..1000000): denetim noktaları")
    print("        n    ortanca  kâhin  alt boy  üst boy  karş./n  log2 n")
    n = 100000
    rastgele_tohum(42)
    a = rastgele_dizi(n, 0, 1000000)
    alt, ust = Obek(True), Obek(False)
    karsilastirma_sayisi = 0
    nokta = 10
    for m in range(1, n + 1):
        ortancaya_ekle(alt, ust, a[m - 1])
        if m == nokta:
            o = ortanca(alt, ust)
            esit = "evet" if o == kahin_ortanca(a, m) else "HAYIR"
            print(f"{m:9d} {o:10.1f}  {esit:>5s} {len(alt.a):8d} "
                  f"{len(ust.a):8d} {karsilastirma_sayisi / m:8.3f} "
                  f"{math.log2(m):7.3f}")
            nokta *= 10

    print("\n3) İki öbek ve sıralı dizi: toplam iş")
    print("        n  iki öbek karş.  sıralı dizi kaydırma")
    m = 500
    while m <= 2000:
        alt, ust = Obek(True), Obek(False)
        karsilastirma_sayisi = 0
        for i in range(m):
            ortancaya_ekle(alt, ust, a[i])
        print(f"{m:9d} {karsilastirma_sayisi:15d} "
              f"{sirali_dizi_kaydirma(a, m):21d}")
        m *= 2


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — iki std::priority_queue
# (biri std::greater ile); Python — iki heapq listesi (alt yarı için -x
# hilesiyle en büyük öbek); statistics.median yalnızca kâhin.

"""H07_02_obek_mi.py — AP-2 Hafta 7 · Örnek 2 (★)
Amaç    : Öbek özelliği denetimi (is_heap): her i > 0 için
          a[ebeveyn(i)] >= a[i]; ilk ihlalin yeri ve karşılaştırma sayısı;
          1..n'nin kaç permütasyonu öbektir?
Çalıştır: python3 H07_02_obek_mi.py
Eşleri  : c/H07_02_obek_mi.c · cpp/H07_02_obek_mi.cpp
Çıktı   : üç dilde aynı (=)
"""

karsilastirma_sayisi = 0


def ebeveyn(i):
    return (i - 1) // 2


def ilk_ihlal(a, n):
    """İlk ihlal: a[ebeveyn(i)] < a[i] olan en küçük i; ihlal yoksa -1"""
    global karsilastirma_sayisi
    for i in range(1, n):
        karsilastirma_sayisi += 1
        if a[ebeveyn(i)] < a[i]:
            return i
    return -1


def obek_mi(a, n):
    return ilk_ihlal(a, n) == -1


def obek_mi_cocuklar(a, n):
    """Aynı özellik çocuklardan bakarak: iç düğümler 0 .. n/2 - 1 (kâhin)"""
    for i in range(n // 2):
        sol, sag = 2 * i + 1, 2 * i + 2
        if a[i] < a[sol] or (sag < n and a[i] < a[sag]):
            return False
    return True


def sonraki_permutasyon(p, n):
    """Sözlük sırasında sonraki permütasyon; son permütasyondaysa False"""
    i = n - 2
    while i >= 0 and p[i] >= p[i + 1]:
        i -= 1
    if i < 0:
        return False
    j = n - 1
    while p[j] <= p[i]:
        j -= 1
    p[i], p[j] = p[j], p[i]
    s, t = i + 1, n - 1
    while s < t:
        p[s], p[t] = p[t], p[s]
        s, t = s + 1, t - 1
    return True


def denetle(ad, a, n):
    global karsilastirma_sayisi
    karsilastirma_sayisi = 0
    i = ilk_ihlal(a, n)
    s = f"{ad} (n = {n}): "
    if i == -1:
        s += "öbek: evet"
    else:
        s += (f"öbek: HAYIR (i = {i}: a[{ebeveyn(i)}] = {a[ebeveyn(i)]}"
              f" < a[{i}] = {a[i]})")
    print(s + f", karşılaştırma = {karsilastirma_sayisi}")


def main():
    global karsilastirma_sayisi
    obek = [95, 88, 92, 71, 84, 63, 90, 45, 52, 79]
    azalan = [95, 92, 90, 88, 84, 79, 71, 63, 52, 45]
    artan = [45, 52, 63, 71, 79, 84, 88, 90, 92, 95]
    derinde = [95, 88, 92, 71, 84, 63, 90, 45, 52, 85]
    esit = [7, 7, 7, 7, 7]
    tek = [42]

    print("1) Öbek özelliği: her i > 0 için a[(i - 1) / 2] >= a[i]")
    denetle("Örnek 1'in öbeği", obek, 10)
    denetle("azalan sıralı", azalan, 10)
    denetle("artan sıralı", artan, 10)
    denetle("son yaprakta ihlal", derinde, 10)
    denetle("eşit elemanlar", esit, 5)
    denetle("tek eleman", tek, 1)
    denetle("boş dizi", tek, 0)

    print("\n2) 1..n'nin permütasyonlarından kaçı en büyük öbektir?")
    print("  n        n!    öbek    oran (%)   ort. karş.  uyumsuz")
    for n in range(1, 9):
        p = [i + 1 for i in range(n)]
        toplam, obek_sayisi, uyumsuz = 0, 0, 0
        karsilastirma_sayisi = 0
        while True:
            toplam += 1
            b1 = obek_mi(p, n)
            if b1:
                obek_sayisi += 1
            if b1 != obek_mi_cocuklar(p, n):
                uyumsuz += 1
            if not sonraki_permutasyon(p, n):
                break
        print(f"{n:3d} {toplam:9d} {obek_sayisi:7d} "
              f"{100.0 * obek_sayisi / toplam:10.4f} "
              f"{karsilastirma_sayisi / toplam:12.3f} {uyumsuz:8d}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::is_heap,
# std::is_heap_until (ilk ihlalin konumu); Python — yok (heapq'da
# denetim fonksiyonu yoktur; en küçük öbek için elle yazılır).

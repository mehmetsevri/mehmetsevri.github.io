"""H07_10_taban_siralamasi.py — AP-2 Hafta 7 · Örnek 10 (★★★)
Amaç    : Taban sıralaması (LSD): en düşük basamaktan başlayarak her
          basamakta KARARLI sayma; 32 bitlik işaretsiz tamsayılar bayt
          bayt (256 tabanı, 4 geçiş); Θ(d(n + b)); taban seçimi
Çalıştır: python3 H07_10_taban_siralamasi.py
Eşleri  : c/H07_10_taban_siralamasi.c · cpp/H07_10_taban_siralamasi.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_sayi, rastgele_tohum

adim_sayisi = 0


def ondalik_gecis(a, b, bolen):
    """Ondalık gösterim (kart sıralayıcı benzetmesi): bolen = 1, 10, 100"""
    onek = [0] * 10
    for x in a:
        onek[x // bolen % 10] += 1
    for v in range(1, 10):
        onek[v] += onek[v - 1]
    # sağdan sola: kararlı
    for i in range(len(a) - 1, -1, -1):
        v = a[i] // bolen % 10
        onek[v] -= 1
        b[onek[v]] = a[i]


def gecis(a, b, kaydir, maske, onek):
    """Bir geçiş: (x >> kaydir) & maske basamağına göre kararlı sayma"""
    global adim_sayisi
    n = len(a)
    for v in range(maske + 1):
        onek[v] = 0
    for i in range(n):
        onek[(a[i] >> kaydir) & maske] += 1
        adim_sayisi += 1
    for v in range(1, maske + 1):
        onek[v] += onek[v - 1]
        adim_sayisi += 1
    for i in range(n - 1, -1, -1):
        v = (a[i] >> kaydir) & maske
        onek[v] -= 1
        b[onek[v]] = a[i]
        adim_sayisi += 1


def taban_siralamasi(a, bit, izle):
    """bit: basamak genişliği (4, 8 ya da 16); 32 / bit geçiş (çift sayı:
    sonuç yeniden a'da). izle: her geçişten sonra yazdır"""
    maske = (1 << bit) - 1
    b = [0] * len(a)
    onek = [0] * (maske + 1)
    kaynak, hedef = a, b
    for kaydir in range(0, 32, bit):
        gecis(kaynak, hedef, kaydir, maske, onek)
        kaynak, hedef = hedef, kaynak      # rolleri değiştir
        if izle:
            print(f"  bayt {kaydir // 8}   :"
                  + "".join(f" {x:08X}" for x in kaynak))


def rastgele_u32():
    ust = rastgele_sayi() >> 15             # 16 bit
    alt = rastgele_sayi() >> 15             # ayrı deyim: sıra belli
    return (ust << 16) | alt


def olcek_satiri(n, bit):
    global adim_sayisi
    rastgele_tohum(42)
    a = [rastgele_u32() for _ in range(n)]
    k = sorted(a)                                       # kâhin
    adim_sayisi = 0
    taban_siralamasi(a, bit, False)
    dogru = (a == k)
    d, b = 32 // bit, 1 << bit
    print(f"{n:8d} {bit:4d} {b:6d} {d:3d} {adim_sayisi:10d} "
          f"{d * (2 * n + b - 1):10d} {adim_sayisi / n:8.3f} "
          f"{n * math.log2(n):11.0f}  " + ("evet" if dogru else "HAYIR"))


def main():
    global adim_sayisi
    o = [532, 418, 207, 351, 842, 135, 600, 214]
    t = [0] * 8
    ad = ["birler", "onlar ", "yüzler"]
    print("1) Ondalık LSD: önce birler, sonra onlar, sonra yüzler")
    print("  girdi        :" + "".join(f" {x}" for x in o))
    bolen = 1
    for d in range(3):
        ondalik_gecis(o, t, bolen)
        o = t[:]
        print(f"  {d + 1}. geçiş {ad[d]}:" + "".join(f" {x}" for x in o))
        bolen *= 10

    print("\n2) 32 bit, 256 tabanı: bayt 0 (en düşük) -> bayt 3")
    a = [0x2A00FF10, 0x00C0FFEE, 0x12345678, 0xDEADBEEF, 0x0000002A,
         0xFFFFFFFF, 0x12340078, 0x80000000]
    print("  girdi    :" + "".join(f" {x:08X}" for x in a))
    adim_sayisi = 0
    taban_siralamasi(a, 8, True)
    print("  onluk    :" + "".join(f" {x}" for x in a))
    print(f"  adım = {adim_sayisi} = 4 (2n + b - 1), n = 8, b = 256")

    print("\n3) Rastgele 32 bitlik sayılar: adım = d (2n + b - 1)")
    print("       n  bit  taban   d       adım    formül   adım/n"
          "     n log2 n  kâhin")
    n = 1000
    while n <= 100000:
        olcek_satiri(n, 8)
        n *= 10
    print("  taban seçimi (n = 100000): az geçiş <-> büyük sayaç dizisi")
    olcek_satiri(100000, 4)
    olcek_satiri(100000, 8)
    olcek_satiri(100000, 16)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok; C++ — yok (std::sort karşılaştırmalıdır);
# Python — yok (sorted karşılaştırmalıdır; yalnızca kâhin).

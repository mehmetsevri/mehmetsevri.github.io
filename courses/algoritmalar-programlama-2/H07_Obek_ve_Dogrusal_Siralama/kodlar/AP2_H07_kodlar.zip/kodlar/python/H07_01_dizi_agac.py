"""H07_01_dizi_agac.py — AP-2 Hafta 7 · Örnek 1 (★)
Amaç    : Tam ikili ağacın dizi gösterimi: ebeveyn (i-1)/2, çocuklar 2i+1
          ve 2i+2; öbeğin düzeyler ve ağaç biçiminde yazdırılması
Çalıştır: python3 H07_01_dizi_agac.py
Eşleri  : c/H07_01_dizi_agac.c · cpp/H07_01_dizi_agac.cpp
Çıktı   : üç dilde aynı (=)
"""

HUCRE = 4                       # son düzeyde düğüm başına sütun


# 0 tabanlı indis formülleri (Python'da // aşağı yuvarlar: i > 0 için aynı)
def ebeveyn(i):
    return (i - 1) // 2


def sol_cocuk(i):
    return 2 * i + 1


def sag_cocuk(i):
    return 2 * i + 2


def duzey(i):
    """i. düğümün düzeyi (kök 0): i + 1'in ikilik basamak sayısı - 1"""
    d = 0
    while i > 0:
        i = ebeveyn(i)
        d += 1
    return d


def tablo_yaz(a):
    n = len(a)
    print("  i  a[i]  ebeveyn  sol  sağ  düzey")
    for i in range(n):
        s = f"{i:3d}  {a[i]:4d}"
        if i == 0:
            s += f"  {'-':>7}"
        else:
            s += f"  {ebeveyn(i):7d}"
        if sol_cocuk(i) < n:
            s += f"  {sol_cocuk(i):3d}"
        else:
            s += f"  {'-':>3}"
        if sag_cocuk(i) < n:
            s += f"  {sag_cocuk(i):3d}"
        else:
            s += f"  {'-':>3}"
        print(s + f"  {duzey(i):5d}")


def duzeyleri_yaz(a):
    n = len(a)
    bas, d = 0, 0
    while bas < n:
        son = min(2 * bas + 1, n)   # sonraki düzeyin başı
        print(f"  düzey {d} (a[{bas}..{son - 1}]):", end="")
        for i in range(bas, son):
            print(f" {a[i]}", end="")
        print()
        bas = 2 * bas + 1
        d += 1


def satir_bas(s):
    """Satır sonundaki boşlukları silip yazdırır"""
    print("".join(s).rstrip(" "))


def agac_yaz(a):
    """Ortalanmış ağaç: d. düzeyde 2^d yuva, yuva genişliği G / 2^d"""
    n = len(a)
    yukseklik = duzey(n - 1)
    g = HUCRE << yukseklik      # toplam genişlik
    for d in range(yukseklik + 1):
        bas = (1 << d) - 1
        yuva = g >> d
        satir = [" "] * g
        j = 0
        while j < (1 << d) and bas + j < n:
            sayi = str(a[bas + j])
            u = len(sayi)
            hedef = yuva * j + (yuva - u) // 2
            satir[hedef:hedef + u] = list(sayi)
            j += 1
        satir_bas(satir)
        if d == yukseklik:
            break
        satir = [" "] * g       # bağlantı çizgileri
        j = 0
        while j < (1 << d) and bas + j < n:
            if sol_cocuk(bas + j) < n:
                satir[yuva * j + 3 * yuva // 8] = "/"
            if sag_cocuk(bas + j) < n:
                satir[yuva * j + 5 * yuva // 8] = "\\"
            j += 1
        satir_bas(satir)


def yan_agac(a, i, derinlik):
    """Yan yatırılmış ağaç: önce sağ alt ağaç (üstte), düğüm, sonra sol"""
    if i >= len(a):
        return
    yan_agac(a, sag_cocuk(i), derinlik + 1)
    print(" " * (6 * derinlik) + str(a[i]))
    yan_agac(a, sol_cocuk(i), derinlik + 1)


def formul_denetimi(n):
    """Formüllerin tutarlılığı: her i > 0 için i, ebeveyninin bir çocuğu mu?
    Bit kaydırmalı biçimler aynı sonucu veriyor mu?"""
    hata = 0
    for i in range(n):
        if i > 0:
            e = ebeveyn(i)
            if sol_cocuk(e) != i and sag_cocuk(e) != i:
                hata += 1
            if ((i - 1) >> 1) != e:
                hata += 1
        if ((i << 1) | 1) != sol_cocuk(i):
            hata += 1
        if ((i + 1) << 1) != sag_cocuk(i):
            hata += 1
    return hata


def main():
    a = [95, 88, 92, 71, 84, 63, 90, 45, 52, 79]
    n = len(a)

    print(f"Öbek dizisi (n = {n}):", end="")
    for x in a:
        print(f" {x}", end="")
    print("\n\n1) İndis ilişkileri (0 tabanlı)")
    tablo_yaz(a)

    print("\n2) Düzeyler: d. düzey a[2^d - 1 .. 2^(d+1) - 2]")
    duzeyleri_yaz(a)

    print("\n3) Ağaç biçimi (dizi sırası = düzey düzey, soldan sağa)")
    agac_yaz(a)

    print("\n4) Yan yatırılmış ağaç (sağ çocuk üstte)")
    yan_agac(a, 0, 0)

    print("\n5) Bit kaydırmayla: sol = (i << 1) | 1, sağ = (i + 1) << 1,"
          " ebeveyn = (i - 1) >> 1")
    print(f"   i = 3: sol = {(3 << 1) | 1}, sağ = {(3 + 1) << 1}, "
          f"ebeveyn = {(3 - 1) >> 1}")
    print("   i = 0 .. 999999 için tutarsızlık sayısı: "
          f"{formul_denetimi(1000000)}")
    print(f"   düzey sayısı (yükseklik + 1): n = 10 -> {duzey(9) + 1}, "
          f"n = 1000000 -> {duzey(999999) + 1}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (dizi + indis aritmetiği elle);
# C++ — std::make_heap aynı 0 tabanlı yerleşimi kullanır; Python — heapq
# aynı yerleşimi kullanır (heap[k] <= heap[2k+1], heap[2k+2]).

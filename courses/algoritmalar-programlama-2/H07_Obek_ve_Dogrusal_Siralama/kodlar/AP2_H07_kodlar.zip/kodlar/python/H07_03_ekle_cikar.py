"""H07_03_ekle_cikar.py — AP-2 Hafta 7 · Örnek 3 (★★)
Amaç    : En büyük öbeğe ekleme (yukarı süzme) ve en büyüğü çıkarma
          (aşağı süzme); adım adım izleme ve rastgele anahtarlarda
          işlem başına ortalama takas sayısı
Çalıştır: python3 H07_03_ekle_cikar.py
Eşleri  : c/H07_03_ekle_cikar.c · cpp/H07_03_ekle_cikar.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_sayi, rastgele_tohum

karsilastirma_sayisi = 0
takas_sayisi = 0


def ebeveyn(i):
    return (i - 1) // 2


def buyuk_mu(x, y):
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return x > y


def takas(a, i, j):
    global takas_sayisi
    a[i], a[j] = a[j], a[i]
    takas_sayisi += 1


def yukari_suz(a, i):
    """a[i] ebeveyninden büyük oldukça yukarı taşınır; son konumu döndürür"""
    while i > 0 and buyuk_mu(a[i], a[ebeveyn(i)]):
        takas(a, i, ebeveyn(i))
        i = ebeveyn(i)
    return i


def asagi_suz(a, n, i):
    """a[i], büyük çocuğundan küçük oldukça aşağı taşınır (a[0..n-1])"""
    while 2 * i + 1 < n:
        c = 2 * i + 1  # sol çocuk
        if c + 1 < n and buyuk_mu(a[c + 1], a[c]):
            c += 1  # sağ çocuk daha büyük
        if not buyuk_mu(a[c], a[i]):
            break  # öbek özelliği sağlandı
        takas(a, i, c)
        i = c
    return i


def obege_ekle(a, x):
    """Yeni eleman ilk boş yaprağa konur, sonra yukarı süzülür"""
    a.append(x)
    return yukari_suz(a, len(a) - 1)


def en_buyugu_cikar(a):
    """Kök çıkarılır; son eleman köke taşınıp aşağı süzülür (a boş olmamalı)"""
    en_buyuk = a[0]
    a[0] = a[-1]
    a.pop()
    asagi_suz(a, len(a), 0)
    return en_buyuk


def dizi_yaz(a):
    print("[" + " ".join(str(x) for x in a) + "]")


def sayaclari_sifirla():
    global karsilastirma_sayisi, takas_sayisi
    karsilastirma_sayisi = 0
    takas_sayisi = 0


def ortalama_satiri(n):
    """n rastgele anahtar: ekleme, artan girdiyle ekleme ve tümünü çıkarma"""
    a = []
    rastgele_tohum(42)
    sayaclari_sifirla()
    for _ in range(n):
        obege_ekle(a, rastgele_sayi())
    ekleme = takas_sayisi / n
    sayaclari_sifirla()
    while a:
        en_buyugu_cikar(a)
    cikar_t = takas_sayisi / n
    cikar_k = karsilastirma_sayisi / n
    sayaclari_sifirla()
    for k in range(n):
        obege_ekle(a, k)               # artan: her eleman köke çıkar
    artan = takas_sayisi / n
    print(f"{n:7d} {ekleme:10.3f} {artan:10.3f} {math.log2(n):8.3f} "
          f"{cikar_t:11.3f} {cikar_k:11.3f}")


def main():
    sira = [45, 79, 63, 90, 84, 92, 95, 52, 71, 88]
    ornek1 = [95, 88, 92, 71, 84, 63, 90, 45, 52, 79]
    a = []

    print("1) Boş öbeğe sırayla ekleme (yukarı süzme)")
    for x in sira:
        sayaclari_sifirla()
        son = obege_ekle(a, x)
        print(f"  ekle {x}: konum {len(a) - 1} -> {son}, "
              f"takas = {takas_sayisi}  ", end="")
        dizi_yaz(a)
    ayni = (a == ornek1)
    print("  Örnek 1'in öbeğiyle aynı mı? " + ("evet" if ayni else "HAYIR"))

    print("\n2) En kötü durum: yeni eleman köke kadar çıkar")
    sayaclari_sifirla()
    son = obege_ekle(a, 97)
    print(f"  ekle 97: konum {len(a) - 1} -> {son}, takas = {takas_sayisi}"
          " (düzey sayısı - 1)  ", end="")
    dizi_yaz(a)

    print("\n3) En büyüğü çıkarma (son eleman köke, aşağı süzme)")
    for _ in range(3):
        kok_adayi = a[-1]
        sayaclari_sifirla()
        en_buyuk = en_buyugu_cikar(a)
        print(f"  çıkar -> {en_buyuk} (köke {kok_adayi} taşındı), "
              f"karşılaştırma = {karsilastirma_sayisi}, "
              f"takas = {takas_sayisi}\n    ", end="")
        dizi_yaz(a)
    print("  kalanlar sırayla çıkarılınca:", end="")
    while a:
        print(f" {en_buyugu_cikar(a)}", end="")
    print()

    print("\n4) İşlem başına ortalama (rastgele anahtarlar, tohum 42)")
    print("      n   ekle/takas  artan/takas   log2 n  çıkar/takas"
          "  çıkar/karş.")
    ortalama_satiri(1000)
    ortalama_satiri(10000)
    ortalama_satiri(100000)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue
# (push/top/pop; varsayılan en büyük öbek), std::push_heap/std::pop_heap;
# Python — heapq.heappush/heapq.heappop (en küçük öbek).

"""H07_06_ilk_k.py — AP-2 Hafta 7 · Örnek 6 (★★)
Amaç    : Öncelik kuyruğuyla ilk-k en yüksek not: boyutu k olan EN KÜÇÜK
          öbek (kökte listenin en kötüsü); O(n log k) zaman, O(k) bellek
Çalıştır: python3 H07_06_ilk_k.py
Eşleri  : c/H07_06_ilk_k.c · cpp/H07_06_ilk_k.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_aralik, rastgele_tohum

karsilastirma_sayisi = 0
degisim_sayisi = 0                        # köke yazılan yeni kayıt


def kotu_mu(x, y):
    """x, y'den daha mı kötü? (düşük not; eşit notta büyük numara)
    Kayıt: (no, not) demeti"""
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return x[1] < y[1] or (x[1] == y[1] and x[0] > y[0])


def yukari_suz(h, i):
    """En küçük öbek: kökte en kötü kayıt"""
    while i > 0 and kotu_mu(h[i], h[(i - 1) // 2]):
        h[i], h[(i - 1) // 2] = h[(i - 1) // 2], h[i]
        i = (i - 1) // 2


def asagi_suz(h, n, i):
    while 2 * i + 1 < n:
        c = 2 * i + 1
        if c + 1 < n and kotu_mu(h[c + 1], h[c]):
            c += 1                         # daha kötü çocuk
        if not kotu_mu(h[c], h[i]):
            break
        h[i], h[c] = h[c], h[i]
        i = c


def ilk_k(a, k, izle):
    """Her kayıt için: öbek dolmadıysa ekle; doluysa ve kökten iyiyse kökü
    değiştir. Sonunda öbek yerinde sıralanır: h[0] en iyi."""
    global degisim_sayisi
    h = []
    for x in a:
        if len(h) < k:
            h.append(x)
            yukari_suz(h, len(h) - 1)
            ne = "eklendi"
        elif kotu_mu(h[0], x):
            h[0] = x                       # en kötüyü at
            asagi_suz(h, k, 0)
            degisim_sayisi += 1
            ne = "köke yazıldı"
        else:
            ne = "atlandı"
        if izle:
            print(f"  {x[0]} ({x[1]:3d})  kök = {h[0][1]:3d}  öbek:"
                  + "".join(f" {y[1]}" for y in h) + f"  <- {ne}")
    for son in range(len(h) - 1, 0, -1):            # en kötü sona
        h[0], h[son] = h[son], h[0]
        asagi_suz(h, son, 0)
    return h


def ogrenciler(n, artan):
    """artan = False: notlar rastgele 0..100; artan = True: puan = i (en
    kötü durum: her yeni kayıt kökten iyidir)"""
    rastgele_tohum(42)
    a = []
    for i in range(n):
        a.append((2400001 + i, i if artan else rastgele_aralik(0, 100)))
    return a


def main():
    global karsilastirma_sayisi, degisim_sayisi
    print("1) İlk 12 öğrenci, k = 3 (kökte listenin en kötüsü)")
    a = ogrenciler(12, False)
    h = ilk_k(a, 3, True)
    print("  ilk 3:" + "".join(f" {y[0]} ({y[1]})" for y in h))

    print("\n2) 200 öğrenci, k = 5; eşit notta küçük numara önce")
    a = ogrenciler(200, False)
    karsilastirma_sayisi = 0
    h = ilk_k(a, 5, False)
    a = sorted(a, key=lambda r: (-r[1], r[0]))      # kâhin
    ayni = True
    for j, y in enumerate(h):
        print(f"  {j + 1}. {y[0]}  not = {y[1]}")
        ayni = ayni and y[0] == a[j][0]
    print(f"  karşılaştırma = {karsilastirma_sayisi}; tam sıralamanın ilk "
          "5'iyle aynı mı? " + ("evet" if ayni else "HAYIR"))

    print("\n3) n = 100000: k büyüdükçe iş; r: rastgele notlar, a: artan "
          "puan (en kötü durum)")
    print("     k  karş. r  karş./n r köke yazma r  karş./n a  2 log2 k"
          "  kâhin")
    n = 100000
    a = ogrenciler(n, False)
    s = sorted(a, key=lambda r: (-r[1], r[0]))      # kâhin
    e = ogrenciler(n, True)
    for k in [1, 10, 100, 1000]:
        karsilastirma_sayisi = 0
        degisim_sayisi = 0
        h = ilk_k(a, k, False)
        kr, dr = karsilastirma_sayisi, degisim_sayisi
        ayni = all(h[j][0] == s[j][0] for j in range(len(h)))
        karsilastirma_sayisi = 0
        h = ilk_k(e, k, False)
        ayni = ayni and all(h[j][1] == n - 1 - j for j in range(len(h)))
        print(f"{k:6d} {kr:8d} {kr / n:10.3f} {dr:12d} "
              f"{karsilastirma_sayisi / n:10.3f} {2 * math.log2(k):9.3f}  "
              + ("evet" if ayni else "HAYIR"))
    print(f"  tam sıralama ölçeği: n log2 n = {n * math.log2(n):.0f}")


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue<T,
# std::vector<T>, std::greater<T>> (en küçük öbek), std::partial_sort,
# std::nth_element; Python — heapq.nlargest(k, a) (yalnızca kâhin).

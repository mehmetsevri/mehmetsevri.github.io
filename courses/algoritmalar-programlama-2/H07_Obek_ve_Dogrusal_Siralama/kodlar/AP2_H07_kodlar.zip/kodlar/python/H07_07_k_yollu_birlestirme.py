"""H07_07_k_yollu_birlestirme.py — AP-2 Hafta 7 · Örnek 7 (★★★)
Amaç    : k sıralı listenin en küçük öbekle birleştirilmesi: öbekte her
          listenin sıradaki elemanı; çıktı başına O(log k) — toplam
          O(N log k); k başı doğrusal taramayla (O(N k)) karşılaştırma
Çalıştır: python3 H07_07_k_yollu_birlestirme.py
Eşleri  : c/H07_07_k_yollu_birlestirme.c ·
          cpp/H07_07_k_yollu_birlestirme.cpp
Çıktı   : üç dilde aynı (=)
"""
import math

from ortak_rastgele import rastgele_aralik, rastgele_tohum

karsilastirma_sayisi = 0


def once_mi(x, y):
    """x, y'den önce mi gelir? (küçük değer; eşitse küçük liste no)
    Öğe: (deger, liste, konum) demeti"""
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return x[0] < y[0] or (x[0] == y[0] and x[1] < y[1])


def yukari_suz(h, i):
    while i > 0 and once_mi(h[i], h[(i - 1) // 2]):
        h[i], h[(i - 1) // 2] = h[(i - 1) // 2], h[i]
        i = (i - 1) // 2


def asagi_suz(h, n, i):
    while 2 * i + 1 < n:
        c = 2 * i + 1
        if c + 1 < n and once_mi(h[c + 1], h[c]):
            c += 1
        if not once_mi(h[c], h[i]):
            break
        h[i], h[c] = h[c], h[i]
        i = c


def obek_yaz(h):
    print("".join(f" {d}/{chr(ord('A') + j)}" for d, j, _ in h))


def k_yollu_birlestir(liste, izle):
    """Her listenin ilk elemanı öbeğe; sonra kökü çıktıya yaz ve yerine aynı
    listenin sonraki elemanını koy (liste bittiyse son öğeyi köke taşı)"""
    h = []
    cikti = []
    for j, lis in enumerate(liste):
        if lis:
            h.append((lis[0], j, 0))
            yukari_suz(h, len(h) - 1)
    if izle:
        print("  başlangıç öbeği:", end="")
        obek_yaz(h)
    while h:
        en = h[0]
        cikti.append(en[0])
        lis = liste[en[1]]
        if en[2] + 1 < len(lis):
            s = en[2] + 1
            h[0] = (lis[s], en[1], s)
        else:
            h[0] = h[-1]                   # liste bitti
            h.pop()
        asagi_suz(h, len(h), 0)
        if izle:
            print(f"  {len(cikti):2d}. çıktı {en[0]}/{chr(ord('A') + en[1])}"
                  "  öbek:", end="")
            obek_yaz(h)
    return cikti


def dogrusal_birlestir(liste):
    """Karşılaştırma için: her adımda k listenin başını tek tek tara"""
    k = len(liste)
    konum = [0] * k
    cikti = []
    while True:
        en = -1
        for j in range(k):
            if konum[j] < len(liste[j]):
                aday = (liste[j][konum[j]], j, konum[j])
                if en == -1 or once_mi(aday, (liste[en][konum[en]], en, 0)):
                    en = j
        if en == -1:
            break
        cikti.append(liste[en][konum[en]])
        konum[en] += 1
    return cikti


def sirali_mi(a):
    for i in range(1, len(a)):
        if a[i - 1] > a[i]:
            return False
    return True


def main():
    global karsilastirma_sayisi
    liste = [[45, 62, 78, 91], [50, 50, 83], [38, 70, 95], [], [66]]

    print("1) 5 şubenin sıralı not listeleri (D şubesi boş), k = 5")
    for j in range(5):
        print(f"  {chr(ord('A') + j)}:"
              + "".join(f" {x}" for x in liste[j])
              + (" (boş)" if not liste[j] else ""))
    karsilastirma_sayisi = 0
    cikti = k_yollu_birlestir(liste, True)
    print("  birleşik:" + "".join(f" {x}" for x in cikti))
    print(f"  eleman = {len(cikti)}, karşılaştırma = {karsilastirma_sayisi},"
          " sıralı mı? " + ("evet" if sirali_mi(cikti) else "HAYIR"))

    print("\n2) N = 16384 eleman, k eşit uzunlukta sıralı liste")
    print("     k  öbek karş.  öbek/N  log2 k  tarama karş.  tarama/N"
          "  aynı mı")
    n = 16384
    k = 2
    while k <= 64:
        rastgele_tohum(42)
        ls = []
        for _ in range(k):             # artan adımlarla sıralı liste
            x = 0
            lis = [0] * (n // k)
            for i in range(n // k):
                x += rastgele_aralik(0, 9)
                lis[i] = x
            ls.append(lis)
        karsilastirma_sayisi = 0
        c1 = k_yollu_birlestir(ls, False)
        ko = karsilastirma_sayisi
        karsilastirma_sayisi = 0
        c2 = dogrusal_birlestir(ls)
        kt = karsilastirma_sayisi
        ayni = len(c1) == n and c1 == c2 and sirali_mi(c1)
        print(f"{k:6d} {ko:11d} {ko / n:7.3f} {math.log2(k):7.3f} "
              f"{kt:13d} {kt / n:9.3f}  " + ("evet" if ayni else "HAYIR"))
        k *= 2


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle); C++ — std::priority_queue +
# std::greater (en küçük öbek), iki liste için std::merge; Python —
# heapq.merge(*listeler) (yalnızca kâhin).

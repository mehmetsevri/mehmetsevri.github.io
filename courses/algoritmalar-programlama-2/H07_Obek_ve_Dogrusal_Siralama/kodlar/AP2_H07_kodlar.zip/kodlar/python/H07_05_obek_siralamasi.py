"""H07_05_obek_siralamasi.py — AP-2 Hafta 7 · Örnek 5 (★★)
Amaç    : Öbek sıralaması: öbek kur, kökü sona al, kalanı aşağı süz;
          yerinde ve en kötü durumda O(n log n); kararsızlık gösterimi
Çalıştır: python3 H07_05_obek_siralamasi.py [n_ust=10000]
Eşleri  : c/H07_05_obek_siralamasi.c · cpp/H07_05_obek_siralamasi.cpp
Çıktı   : üç dilde aynı (=)
"""
import math
import sys

from ortak_rastgele import rastgele_aralik, rastgele_sayi, rastgele_tohum

karsilastirma_sayisi = 0
takas_sayisi = 0


def buyuk_mu(x, y):
    global karsilastirma_sayisi
    karsilastirma_sayisi += 1
    return x > y


def takas(a, i, j):
    global takas_sayisi
    a[i], a[j] = a[j], a[i]
    takas_sayisi += 1


def asagi_suz(a, n, i):
    while 2 * i + 1 < n:
        c = 2 * i + 1  # sol çocuk
        if c + 1 < n and buyuk_mu(a[c + 1], a[c]):
            c += 1  # sağ çocuk daha büyük
        if not buyuk_mu(a[c], a[i]):
            break
        takas(a, i, c)
        i = c


def obek_kur(a, n):
    for i in range(n // 2 - 1, -1, -1):
        asagi_suz(a, n, i)


# a[son+1..n-1] sıralı ve en büyükler; a[0..son] en büyük öbek
def obek_siralamasi(a):
    n = len(a)
    obek_kur(a, n)
    for son in range(n - 1, 0, -1):
        takas(a, 0, son)  # en büyük yerine
        asagi_suz(a, son, 0)  # kalan öbeği onar


# --- Kararlılık gösterimi: aynı algoritma, kayıtlar (anahtar: not) ---
def kayit_suz(a, n, i):
    while 2 * i + 1 < n:
        c = 2 * i + 1
        if c + 1 < n and a[c + 1][0] > a[c][0]:
            c += 1
        if a[c][0] <= a[i][0]:
            break
        a[i], a[c] = a[c], a[i]
        i = c


def kayit_siralamasi(a):
    n = len(a)
    for i in range(n // 2 - 1, -1, -1):
        kayit_suz(a, n, i)
    for son in range(n - 1, 0, -1):
        a[0], a[son] = a[son], a[0]
        kayit_suz(a, son, 0)


def kayitlari_yaz(a):
    print("".join(f" ({not_} {ad})" for not_, ad in a))


def dizi_yaz(a, ayrac):
    s = "["
    for i, x in enumerate(a):
        if i > 0:
            s += " | " if i == ayrac else " "
        s += str(x)
    print(s + "]")


def doldur(n, tur):
    """tur: 0 rastgele, 1 sıralı, 2 ters sıralı, 3 çok tekrarlı (0..9)"""
    rastgele_tohum(42)
    a = [0] * n
    for i in range(n):
        if tur == 0:
            a[i] = rastgele_sayi()
        elif tur == 1:
            a[i] = i
        elif tur == 2:
            a[i] = n - i
        else:
            a[i] = rastgele_aralik(0, 9)
    return a


def sayac_satiri(n, tur):
    global karsilastirma_sayisi, takas_sayisi
    ad = ["rastgele", "sıralı", "ters sıralı", "çok tekrarlı"]
    a = doldur(n, tur)
    k = sorted(a)                                   # kâhin
    karsilastirma_sayisi = 0
    takas_sayisi = 0
    obek_siralamasi(a)
    dogru = (a == k)
    nlogn = n * math.log2(n)
    print(f"{n:7d} {karsilastirma_sayisi:10d} {takas_sayisi:10d} "
          f"{karsilastirma_sayisi / nlogn:8.3f} {takas_sayisi / nlogn:8.3f}"
          "  " + ("evet" if dogru else "HAYIR") + "  " + ad[tur])


def main():
    global karsilastirma_sayisi, takas_sayisi
    n_ust = 10000
    if len(sys.argv) > 1:
        try:
            n_ust = int(sys.argv[1])
        except ValueError:
            n_ust = -1
        if n_ust < 1000 or n_ust > 100000000:
            print(f"kullanım: {sys.argv[0]} [n_ust: 1000..100000000]",
                  file=sys.stderr)
            sys.exit(2)
    a = [71, 84, 63, 95, 52, 90, 45, 88, 79, 92]
    n = 10

    print("1) Öbek sıralaması adım adım (| sağı: sıralı bölge)")
    print("  girdi       : ", end="")
    dizi_yaz(a, n)
    karsilastirma_sayisi = 0
    takas_sayisi = 0
    obek_kur(a, n)
    print("  öbek kuruldu: ", end="")
    dizi_yaz(a, n)
    for son in range(n - 1, 0, -1):
        takas(a, 0, son)
        asagi_suz(a, son, 0)
        print(f"  son = {son}     : ", end="")
        dizi_yaz(a, son)
    print(f"  karşılaştırma = {karsilastirma_sayisi}, takas = {takas_sayisi}"
          " (öbek kurma dahil)")

    print("\n2) Kararlı mı? Eşit notlu kayıtların sırası korunuyor mu?")
    k = [(70, "Ada"), (85, "Banu"), (70, "Cem"), (90, "Defne"),
         (85, "Emre"), (70, "Filiz"), (85, "Gül")]
    print("  girdi :", end="")
    kayitlari_yaz(k)
    kayit_siralamasi(k)
    print("  çıktı :", end="")
    kayitlari_yaz(k)
    print("  70'ler girdide Ada, Cem, Filiz sırasındaydı: öbek sıralaması "
          "kararsızdır")

    print("\n3) Sayaçlar: girdi düzeninden neredeyse bağımsız "
          "(uyarlanabilir değil)")
    print("      n karşılaştır.      takas  k/nlogn  t/nlogn  kâhin  girdi")
    for tur in range(4):
        m = 1000
        while m <= n_ust:
            sayac_satiri(m, tur)
            m *= 10


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (qsort algoritmayı belirtmez; yalnızca
# kâhin); C++ — std::make_heap + std::sort_heap, std::partial_sort;
# Python — heapq ile (heapify + n kez heappop; yerinde değil).

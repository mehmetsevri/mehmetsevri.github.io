"""H07_09_kararli_sayma.py — AP-2 Hafta 7 · Örnek 9 (★★)
Amaç    : Kararlı sayma sıralaması: kayıtlar, sıklık dizisi, önek toplam
          ve sağdan sola yerleştirme; yön yanlış seçilirse kararlılık
          kaybolur
Çalıştır: python3 H07_09_kararli_sayma.py
Eşleri  : c/H07_09_kararli_sayma.c · cpp/H07_09_kararli_sayma.cpp
Çıktı   : üç dilde aynı (=)
"""
from ortak_rastgele import rastgele_aralik, rastgele_tohum


def dizi_yaz(ad, x):
    print(f"  {ad}:" + "".join(f" {v}" for v in x))


def kararli_sayma(a, k, izle):
    """Yol 1: önek[v] = anahtarı <= v olan kayıt sayısı; sağdan sola
    yerleştir. Kayıt: (no, not) demeti; anahtar not (0..k)"""
    n = len(a)
    b = [None] * n
    onek = [0] * (k + 1)
    for r in a:
        onek[r[1]] += 1                    # sıklık
    if izle:
        dizi_yaz("sayaç    ", onek)
    for v in range(1, k + 1):
        onek[v] += onek[v - 1]             # önek toplam
    if izle:
        dizi_yaz("önek top.", onek)
    for i in range(n - 1, -1, -1):         # sağdan sola: kararlı
        v = a[i][1]
        onek[v] -= 1
        b[onek[v]] = a[i]
        if izle:
            print(f"  a[{i}] = ({a[i][0]}, {v}) -> b[{onek[v]}]")
    return b


def kararli_sayma_bas(a, k):
    """Yol 2: başlangıç[v] = anahtarı < v olan kayıt sayısı; soldan sağa"""
    b = [None] * len(a)
    bas = [0] * (k + 2)
    for r in a:
        bas[r[1] + 1] += 1
    for v in range(1, k + 1):
        bas[v] += bas[v - 1]
    for r in a:                            # soldan sağa, artırarak
        b[bas[r[1]]] = r
        bas[r[1]] += 1
    return b


def kararsiz_sayma(a, k):
    """Yol 3: Yol 1'in önek dizisi, ama soldan sağa: eşitler ters döner"""
    b = [None] * len(a)
    onek = [0] * (k + 1)
    for r in a:
        onek[r[1]] += 1
    for v in range(1, k + 1):
        onek[v] += onek[v - 1]
    for r in a:                            # YANLIŞ yön
        onek[r[1]] -= 1
        b[onek[r[1]]] = r
    return b


def kayit_yaz(ad, a):
    print(f"  {ad}:" + "".join(f" ({no}, {not_})" for no, not_ in a))


def denetle(ad, b):
    """Sıralı mı ve eşit anahtarlı kayıtlar girdi sırasını (no artan)
    korumuş mu? Numaralar girdide artan verildiği için no karşılaştırması
    yeter."""
    sirali, kararli = True, True
    for i in range(1, len(b)):
        if b[i - 1][1] > b[i][1]:
            sirali = False
        elif b[i - 1][1] == b[i][1] and b[i - 1][0] > b[i][0]:
            kararli = False
    print(f"  {ad}: sıralı mı? " + ("evet" if sirali else "HAYIR")
          + ", kararlı mı? " + ("evet" if kararli else "HAYIR"))


def main():
    a = [(1001, 3), (1002, 1), (1003, 3), (1004, 0), (1005, 2), (1006, 1),
         (1007, 3), (1008, 2)]
    k = 5

    print(f"1) Kayıtlar (no, not), anahtarlar 0..{k}")
    kayit_yaz("girdi", a)
    b = kararli_sayma(a, k, True)
    kayit_yaz("yol 1", b)
    denetle("yol 1 sağdan sola   ", b)
    b = kararli_sayma_bas(a, k)
    kayit_yaz("yol 2", b)
    denetle("yol 2 başlangıçlarla", b)
    b = kararsiz_sayma(a, k)
    kayit_yaz("yol 3", b)
    denetle("yol 3 yanlış yön    ", b)

    print("\n2) 100000 kayıt, notlar 0..100 (tohum 42)")
    m = 100000
    rastgele_tohum(42)
    x = [(2400001 + i, rastgele_aralik(0, 100)) for i in range(m)]
    denetle("yol 1 sağdan sola   ", kararli_sayma(x, 100, False))
    denetle("yol 2 başlangıçlarla", kararli_sayma_bas(x, 100))
    denetle("yol 3 yanlış yön    ", kararsiz_sayma(x, 100))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (qsort kararlı olmak zorunda değildir);
# C++ — std::stable_sort (karşılaştırmalı, kararlı); Python — sorted /
# list.sort (kararlı, karşılaştırmalı; yalnızca kâhin).

/* H07_A04_parsons_asagi_suz.c — AP-2 Hafta 7 · Alıştırma 7.9 (★★) — Parsons
 * Tamamlanacak; bu hâliyle derlenmez: aşağıdaki satırlar en büyük öbekte
 * aşağı süzme fonksiyonunun KARIŞTIRILMIŞ satırlarıdır (iki satır fazladır:
 * kullanılmayacak). Doğru sıraya dizin, girintiyi düzeltin; Örnek 3'ün
 * çıkarma adımlarıyla aynı takasları yapmalı.
 */
        i = c;
    return i;
            break;
static int asagi_suz(int *a, int n, int i)
        if (c + 1 < n && a[c + 1] > a[c]) {
        int c = 2 * i;
    while (2 * i + 1 < n) {
        if (a[c] <= a[i]) {
        takas(&a[i], &a[c]);
            c++;
        }
        int c = 2 * i + 1;
        }
    }
{
    while (2 * i < n) {
}

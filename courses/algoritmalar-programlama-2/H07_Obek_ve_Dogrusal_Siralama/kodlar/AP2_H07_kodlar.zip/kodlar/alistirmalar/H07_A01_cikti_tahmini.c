/* H07_A01_cikti_tahmini.c — AP-2 Hafta 7 · Alıştırma 7.1
 * Amaç    : Çıktı tahmini — boş bir en büyük öbeğe altı değer sırayla
 *           eklenir (yukarı süzme). Çalıştırmadan önce son diziyi ve
 *           toplam takas sayısını kâğıt üzerinde bulun.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_A01_cikti_tahmini.c -o H07_A01_cikti_tahmini
 * Çalıştır: ./H07_A01_cikti_tahmini
 */
#include <stdio.h>

static int takas_sayisi = 0;

static void yukari_suz(int *a, int i)
{
    while (i > 0 && a[i] > a[(i - 1) / 2]) {
        int g = a[i];
        a[i] = a[(i - 1) / 2];
        a[(i - 1) / 2] = g;
        takas_sayisi++;
        i = (i - 1) / 2;
    }
}

int main(void)
{
    const int girdi[] = {30, 50, 20, 70, 40, 90};
    int a[6];
    int n = 0;
    for (int k = 0; k < 6; k++) {
        a[n] = girdi[k];
        n++;
        yukari_suz(a, n - 1);
    }
    printf("son dizi:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\ntakas = %d\n", takas_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::push_heap; Python —
 * heapq.heappush (en küçük öbek). */

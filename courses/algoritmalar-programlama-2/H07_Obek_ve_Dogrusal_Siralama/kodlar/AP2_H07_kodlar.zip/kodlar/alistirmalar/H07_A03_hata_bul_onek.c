/* H07_A03_hata_bul_onek.c — AP-2 Hafta 7 · Alıştırma 7.8 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: kararlı sayma sıralaması anahtarları
 * 0..k olan kayıtları sıralamalı; çıktıda bazı kayıtlar kayboluyor, bazı
 * konumlar boş kalıyor. Hatalı satırı bulun (Örnek 9 ile karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_A03_hata_bul_onek.c -o H07_A03_hata_bul_onek
 * Çalıştır: ./H07_A03_hata_bul_onek
 */
#include <stdio.h>

#define K 4  /* anahtarlar 0..K */

typedef struct {
    int no;
    int anahtar;
} Kayit;

static void kararli_sayma(const Kayit *a, Kayit *b, int n)
{
    int onek[K + 1] = {0};
    for (int i = 0; i < n; i++) {
        onek[a[i].anahtar]++;
    }
    for (int v = 1; v < K; v++) {
        onek[v] += onek[v - 1];
    }
    for (int i = n - 1; i >= 0; i--) {
        b[--onek[a[i].anahtar]] = a[i];
    }
}

int main(void)
{
    const Kayit a[] = {{101, 4}, {102, 1}, {103, 0}, {104, 4},
                       {105, 2}, {106, 1}, {107, 3}};
    const int n = (int)(sizeof a / sizeof a[0]);
    Kayit b[sizeof a / sizeof a[0]];
    for (int i = 0; i < n; i++) {
        b[i].no = 0;        /* boş konum */
        b[i].anahtar = -1;
    }
    kararli_sayma(a, b, n);
    printf("çıktı:");
    for (int i = 0; i < n; i++) {
        printf(" (%d, %d)", b[i].no, b[i].anahtar);
    }
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: C, C++, Python — yok (sayma sıralaması elle
 * yazılır); Python'da collections.Counter yalnızca sayar. */

/* H07_A02_hata_bul_obek_siralamasi.c — AP-2 Hafta 7 · Alıştırma 7.7 (★★)
 * BU DOSYA KASITLI HATA İÇERİR: Örnek 5'in girdisi sıralanmak isteniyor,
 * ama çıktı sıralı değil. Hatalı satırı bulun ve düzeltin (Örnek 5 ile
 * karşılaştırın).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_A02_hata_bul_obek_siralamasi.c -o H07_A02_hata_bul
 * Çalıştır: ./H07_A02_hata_bul
 */
#include <stdio.h>

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static void asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c + 1] > a[c]) {
            c++;
        }
        if (a[c] <= a[i]) {
            break;
        }
        takas(&a[i], &a[c]);
        i = c;
    }
}

static void obek_siralamasi(int *a, int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
    for (int son = n - 1; son > 0; son--) {
        takas(&a[0], &a[son]);
        asagi_suz(a, son + 1, 0);
    }
}

int main(void)
{
    int a[] = {71, 84, 63, 95, 52, 90, 45, 88, 79, 92};
    int n = (int)(sizeof a / sizeof a[0]);
    obek_siralamasi(a, n);
    printf("çıktı:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::make_heap + std::sort_heap;
 * Python — heapq ile (yerinde değil). */

"""H07_A05_heapq_okuma.py — AP-2 Hafta 7 · Alıştırma 7.13 (★★)
Amaç    : Diller arası okuma — çalıştırmadan önce dört print satırının
          çıktısını yazın; heapq listesinin İÇ düzenine dikkat edin.
Çalıştır: python3 H07_A05_heapq_okuma.py
"""
import heapq


def main():
    h = []
    for x in [7, 3, 9, 1, 5]:
        heapq.heappush(h, x)
    print(h)
    print(heapq.heappop(h), heapq.heappop(h))
    print(h[0], len(h))
    heapq.heappush(h, -10)
    print(h[0])


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — yok (elle öbek); C++ — std::priority_queue
# (varsayılan en büyük öbek); Python — heapq (en küçük öbek).

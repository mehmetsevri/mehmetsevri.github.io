/* H07_A06_priority_queue_okuma.cpp — AP-2 Hafta 7 · Alıştırma 7.14 (★★)
 * Amaç    : Diller arası okuma — std::pair'ler (öncelik, geliş sırası)
 *           önce ilk alana, eşitse ikinci alana göre karşılaştırılır.
 *           Çalıştırmadan önce çıktıyı yazın.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_A06_priority_queue_okuma.cpp -o H07_A06_pq_okuma
 * Çalıştır: ./H07_A06_pq_okuma
 */
#include <iostream>
#include <queue>
#include <utility>

int main()
{
    std::priority_queue<std::pair<int, int>> q;  // (öncelik, sıra)
    q.push({2, 0});
    q.push({5, 1});
    q.push({2, 2});
    q.push({5, 3});
    while (!q.empty()) {
        std::cout << q.top().first << '/' << q.top().second << ' ';
        q.pop();
    }
    std::cout << '\n';
    return 0;
}

/* Kütüphane karşılığı: C — yok (elle öbek + karşılaştırma fonksiyonu);
 * C++ — std::priority_queue; Python — heapq (en küçük öbek). */

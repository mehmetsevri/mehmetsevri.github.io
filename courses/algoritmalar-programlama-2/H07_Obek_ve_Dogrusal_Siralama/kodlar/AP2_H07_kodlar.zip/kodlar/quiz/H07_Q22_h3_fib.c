/* H07_Q22_h3_fib.c — AP-2 Hafta 7 · Vize hazırlık (H3) · İzleme
 * Amaç    : Özyinelemeli Fibonacci'de fib(6) değeri ve toplam çağrı sayısı
 *           (özyineleme ağacının düğüm sayısı).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q22_h3_fib.c \
 *           -o H07_Q22_h3_fib
 * Çalıştır: ./H07_Q22_h3_fib
 */
#include <stdio.h>

static long long cagri = 0;

static int fib(int n)
{
    cagri++;
    if (n < 2) {
        return n;
    }
    return fib(n - 1) + fib(n - 2);
}

int main(void)
{
    int f = fib(6);
    printf("fib(6) = %d, çağrı = %lld\n", f, cagri);
    return 0;
}

/* Kütüphane karşılığı: yok; ara sonuçları saklamak (memoization) çağrı
 * sayısını n + 1 farklı alt probleme indirir (Hafta 13). */

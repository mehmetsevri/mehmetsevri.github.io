"""H07_Q45_h7_sayma_aralik.py — AP-2 Hafta 7 · Vize hazırlık (H7) · Hata bulma
Amaç    : Anahtar denetimi yapmayan sayma sıralaması (anahtarlar 0..3
          olmalı) dört aday girdide: hangisi HATA VERMEDEN yanlış sonuç
          üretir?
Çalıştır: python3 H07_Q45_h7_sayma_aralik.py
"""


def sayma_siralamasi(a, k):
    sayac = [0] * (k + 1)
    for x in a:
        sayac[x] += 1
    b = []
    for v in range(k + 1):
        b.extend([v] * sayac[v])
    return b


def main():
    for a in ([0, 3, 2], [3, -1, 2], [4, 1, 0], [2, 2, 2]):
        try:
            b = sayma_siralamasi(a, 3)
            durum = "doğru" if b == sorted(a) else "YANLIŞ (hata iletisi yok)"
            print(a, "->", b, durum)
        except IndexError as e:
            print(a, "-> IndexError:", e)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok; collections.Counter yalnızca sayar. sorted(a)
# yalnızca kâhin olarak kullanıldı.

/* H07_Q02_kaydirma.c — AP-2 Hafta 7 · Quiz S8 (diller arası okuma)
 * Amaç    : H07_Q02_kaydirma.py'nin C karşılığı: -5, 32 bitlik işaretsiz
 *           tamsayıya çevrilip (mod 2^32, tanımlı) en üst baytı alınır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q02_kaydirma.c \
 *           -o H07_Q02_kaydirma
 * Çalıştır: ./H07_Q02_kaydirma
 */
#include <inttypes.h>
#include <stdio.h>

int main(void)
{
    uint32_t u = (uint32_t)-5;
    printf("%" PRIu32 " %" PRIu32 "\n", u >> 24, (u >> 24) & 0xFF);
    return 0;
}

/* Kütüphane karşılığı: yok (dil davranışı); C'de işaretli negatif sayıyı
 * sağa kaydırmanın sonucu gerçekleştirime bağlıdır: önce işaretsize çevirin. */

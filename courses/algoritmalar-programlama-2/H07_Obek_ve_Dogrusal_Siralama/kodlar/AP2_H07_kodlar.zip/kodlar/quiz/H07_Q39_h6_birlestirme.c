/* H07_Q39_h6_birlestirme.c — AP-2 Hafta 7 · Vize hazırlık (H6) · Değişmez
 * Amaç    : İki sıralı dizinin birleştirilmesinde ana döngünün değişmezi.
 *           Dört aday ifade (A–D) rastgele girdilerde her yinelemenin
 *           BAŞINDA sınanır; ihlal sayıları yazılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q39_h6_birlestirme.c ../c/ortak_rastgele.c \
 *           -o H07_Q39_h6_birlestirme
 * Çalıştır: ./H07_Q39_h6_birlestirme
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../c/ortak_rastgele.h"

static int artan(const void *x, const void *y)
{
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}

static bool sirali(const int *c, int k)
{
    for (int t = 1; t < k; t++) {
        if (c[t - 1] > c[t]) {
            return false;
        }
    }
    return true;
}

/* c[0..k-1], a[0..i-1] ile b[0..j-1]'in çoklu kümesi mi? */
static bool birlesim_mi(const int *c, int k, const int *a, int i,
                        const int *b, int j)
{
    int x[40], y[40];
    if (k != i + j) {
        return false;
    }
    memcpy(x, c, (size_t)k * sizeof *x);
    memcpy(y, a, (size_t)i * sizeof *y);
    memcpy(y + i, b, (size_t)j * sizeof *y);
    qsort(x, (size_t)k, sizeof *x, artan);
    qsort(y, (size_t)k, sizeof *y, artan);
    return memcmp(x, y, (size_t)k * sizeof *x) == 0;
}

int main(void)
{
    int a[20], b[20], c[40], ihlal[4] = {0}, sinama = 0;
    rastgele_tohum(42);
    for (int deneme = 0; deneme < 2000; deneme++) {
        int na = rastgele_aralik(1, 20), nb = rastgele_aralik(1, 20);
        rastgele_dizi(a, (size_t)na, 0, 30);
        rastgele_dizi(b, (size_t)nb, 0, 30);
        qsort(a, (size_t)na, sizeof *a, artan);
        qsort(b, (size_t)nb, sizeof *b, artan);
        int i = 0, j = 0, k = 0, son_a = 1;  /* son yazılan a'dan mı? */
        while (i < na && j < nb) {
            sinama++;
            bool s = sirali(c, k), u = birlesim_mi(c, k, a, i, b, j);
            ihlal[0] += !(s && u);                            /* A */
            ihlal[1] += !(s && k == i);                       /* B */
            ihlal[2] += !(u && k == na + nb);                 /* C */
            ihlal[3] += !(k == 0 || son_a);                   /* D */
            son_a = a[i] <= b[j];
            c[k++] = a[i] <= b[j] ? a[i++] : b[j++];
        }
    }
    printf("sınama = %d; ihlal: A = %d, B = %d, C = %d, D = %d\n", sinama,
           ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::merge; Python — heapq.merge
 * ya da sorted(a + b) (kâhin). */

/* H07_Q21_h2_kadane_bos.c — AP-2 Hafta 7 · Vize hazırlık (H2) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: Kadane algoritması en büyük toplamlı
 * bitişik alt dizinin toplamını Θ(n)'de bulur. Boş satırı doldurun.
 */
#include <stdio.h>

static int en_buyuk_alt_dizi(const int *a, int n)  /* ön koşul: n >= 1 */
{
    int simdiki = a[0], en_iyi = a[0];
    for (int i = 1; i < n; i++) {
        ____________________________________;
        if (simdiki > en_iyi) {
            en_iyi = simdiki;
        }
    }
    return en_iyi;
}

int main(void)
{
    const int a[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    printf("%d\n", en_buyuk_alt_dizi(a, 9));
    return 0;
}

/* Kütüphane karşılığı: yok (algoritma elle yazılır). */

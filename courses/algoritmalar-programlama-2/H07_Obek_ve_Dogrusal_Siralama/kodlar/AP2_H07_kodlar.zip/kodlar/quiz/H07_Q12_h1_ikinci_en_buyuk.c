/* H07_Q12_h1_ikinci_en_buyuk.c — AP-2 Hafta 7 · Vize hazırlık (H1) · Değişmez
 * Amaç    : İkinci en büyük elemanı bulan döngünün değişmezi. Program dört
 *           aday ifadeyi rastgele dizilerde her yinelemenin BAŞINDA sınar
 *           ve kaç kez yanlış olduklarını sayar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q12_h1_ikinci_en_buyuk.c ../c/ortak_rastgele.c \
 *           -o H07_Q12_h1_ikinci_en_buyuk
 * Çalıştır: ./H07_Q12_h1_ikinci_en_buyuk
 */
#include <stdio.h>

#include "../c/ortak_rastgele.h"

/* ön koşul: n >= 2; dönüş: ikinci en büyük (tekrarlar sayılır) */
static int ikinci_en_buyuk(const int *a, size_t n)
{
    int b1 = a[0] > a[1] ? a[0] : a[1];
    int b2 = a[0] > a[1] ? a[1] : a[0];
    for (size_t i = 2; i < n; i++) {
        if (a[i] > b1) {
            b2 = b1;
            b1 = a[i];
        } else if (a[i] > b2) {
            b2 = a[i];
        }
    }
    return b2;
}

/* a[0..i-1]'in sıralanmış hâlinde en büyük iki değer (tekrarlar sayılır) */
static void en_buyuk_iki(const int *a, size_t i, int *m1, int *m2)
{
    *m1 = a[0] > a[1] ? a[0] : a[1];
    *m2 = a[0] > a[1] ? a[1] : a[0];
    for (size_t k = 2; k < i; k++) {
        if (a[k] > *m1) {
            *m2 = *m1;
            *m1 = a[k];
        } else if (a[k] > *m2) {
            *m2 = a[k];
        }
    }
}

int main(void)
{
    long long ihlal[4] = {0, 0, 0, 0}, sinama = 0, dogru = 0;
    int a[12];
    rastgele_tohum(42);
    for (int deneme = 0; deneme < 2000; deneme++) {
        size_t n = (size_t)rastgele_aralik(2, 12);
        rastgele_dizi(a, n, 0, 9);  /* tekrarlar bilerek çok */
        int b1 = a[0] > a[1] ? a[0] : a[1];
        int b2 = a[0] > a[1] ? a[1] : a[0];
        for (size_t i = 2; i <= n; i++) {     /* i = n: son koşul */
            int m1, m2;
            en_buyuk_iki(a, i, &m1, &m2);
            sinama++;
            /* A: b1, b2 = a[0..i-1]'in en büyük iki değeri */
            ihlal[0] += !(b1 == m1 && b2 == m2);
            ihlal[1] += !(b2 < b1);               /* B: b2 < b1 */
            ihlal[2] += !(b1 == a[i - 1]);        /* C: b1 = a[i-1] */
            ihlal[3] += i < n && !(b1 >= a[i]);   /* D: b1 >= a[i] */
            if (i == n) {
                break;
            }
            if (a[i] > b1) {
                b2 = b1;
                b1 = a[i];
            } else if (a[i] > b2) {
                b2 = a[i];
            }
        }
        int m1, m2;
        en_buyuk_iki(a, n, &m1, &m2);
        dogru += ikinci_en_buyuk(a, n) == m2;
    }
    printf("sınama = %lld; ihlal: A = %lld, B = %lld, C = %lld, D = %lld\n",
           sinama, ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    printf("ikinci_en_buyuk doğru: %lld / 2000\n", dogru);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::nth_element ya da
 * std::partial_sort; Python — heapq.nlargest(2, a)[1]. */

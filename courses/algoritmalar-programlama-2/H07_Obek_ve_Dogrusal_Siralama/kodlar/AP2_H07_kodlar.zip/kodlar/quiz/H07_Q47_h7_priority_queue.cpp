/* H07_Q47_h7_priority_queue.cpp — AP-2 Hafta 7 · Vize (H7) · Diller arası
 * Amaç    : H07_Q47_h7_heapq.py'nin C++ karşılığı: aynı ekleme sırası,
 *           std::priority_queue'nun top() değeri.
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q47_h7_priority_queue.cpp -o H07_Q47_h7_pq
 * Çalıştır: ./H07_Q47_h7_pq
 */
#include <iostream>
#include <queue>

int main()
{
    std::priority_queue<int> q;
    for (int x : {5, 1, 8, 3}) {
        q.push(x);
    }
    std::cout << q.top() << '\n';
    return 0;
}

/* Kütüphane karşılığı: std::priority_queue (varsayılan en büyük öbek);
 * en küçük için std::greater<int>. */

/* H07_Q41_h6_quickselect_bos.c — AP-2 Hafta 7 · Vize (H6) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: quickselect, k. en küçüğü (0 tabanlı)
 * bulur. bolumle Lomuto'dur: a[p] son yerine oturur. Boş satırı doldurun.
 */
#include <stdio.h>

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static int bolumle(int *a, int lo, int hi)
{
    int pivot = a[hi], i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (a[j] < pivot) {
            takas(&a[++i], &a[j]);
        }
    }
    takas(&a[i + 1], &a[hi]);
    return i + 1;
}

static int quickselect(int *a, int n, int k)
{
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int p = bolumle(a, lo, hi);
        if (k == p) {
            return a[p];
        }
        __________________________________________;
    }
    return a[lo];
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4};
    printf("%d\n", quickselect(a, 8, 3));   /* 4. en küçük */
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::nth_element; Python —
 * heapq.nsmallest(k + 1, a)[-1] ya da sorted(a)[k]. */

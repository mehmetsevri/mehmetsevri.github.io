"""H07_Q47_h7_heapq.py — AP-2 Hafta 7 · Vize hazırlık (H7) · Diller arası
Amaç    : heapq ile std::priority_queue aynı sırayla doldurulunca ilk
          çıkan eleman. C++ karşılığı: H07_Q47_h7_priority_queue.cpp
Çalıştır: python3 H07_Q47_h7_heapq.py
"""
import heapq


def main():
    h = []
    for x in [5, 1, 8, 3]:
        heapq.heappush(h, x)
    print(heapq.heappop(h))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: heapq (en küçük öbek); C++ std::priority_queue
# (varsayılan en büyük öbek).

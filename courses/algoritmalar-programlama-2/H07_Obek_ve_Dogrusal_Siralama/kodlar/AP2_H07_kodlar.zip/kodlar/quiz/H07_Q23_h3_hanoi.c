/* H07_Q23_h3_hanoi.c — AP-2 Hafta 7 · Vize hazırlık (H3) · Karmaşıklık
 * Amaç    : T(n) = 2T(n - 1) + 1, T(0) = 0 bağıntısını hamle sayacıyla
 *           doğrulamak: n = 1..20 için sayaç 2^n - 1 mi?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q23_h3_hanoi.c \
 *           -o H07_Q23_h3_hanoi
 * Çalıştır: ./H07_Q23_h3_hanoi
 */
#include <stdio.h>

static long long hamle = 0;

static void hanoi(int n, char kaynak, char hedef, char ara)
{
    if (n == 0) {
        return;
    }
    hanoi(n - 1, kaynak, ara, hedef);
    hamle++;
    hanoi(n - 1, ara, hedef, kaynak);
}

int main(void)
{
    int uyumsuz = 0;
    for (int n = 1; n <= 20; n++) {
        hamle = 0;
        hanoi(n, 'A', 'C', 'B');
        uyumsuz += hamle != (1LL << n) - 1;
        if (n % 5 == 0) {
            printf("n = %2d: hamle = %lld\n", n, hamle);
        }
    }
    printf("2^n - 1 ile uyumsuz n sayısı: %d\n", uyumsuz);
    return 0;
}

/* Kütüphane karşılığı: yok. */

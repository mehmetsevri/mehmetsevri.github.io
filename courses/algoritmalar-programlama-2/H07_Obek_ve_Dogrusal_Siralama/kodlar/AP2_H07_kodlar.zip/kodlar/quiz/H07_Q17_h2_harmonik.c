/* H07_Q17_h2_harmonik.c — AP-2 Hafta 7 · Vize hazırlık (H2) · Karmaşıklık
 * Amaç    : İç döngü adımı i olan iç içe döngünün işlem sayısı hangi
 *           sınıftadır? Program sayacı birkaç n için yazar ve n ln n ile
 *           oranlar; n iki katına çıkınca sayacın kaç katına çıktığını verir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q17_h2_harmonik.c \
 *           -o H07_Q17_h2_harmonik -lm
 * Çalıştır: ./H07_Q17_h2_harmonik
 */
#include <math.h>
#include <stdio.h>

static long long say(int n)
{
    long long s = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j += i) {
            s++;
        }
    }
    return s;
}

int main(void)
{
    long long onceki = 0;
    for (int n = 1000; n <= 64000; n *= 2) {
        long long s = say(n);
        printf("n = %6d: s = %9lld  s/(n ln n) = %.3f", n, s,
               s / (n * log((double)n)));
        if (onceki) {
            printf("  s(n)/s(n/2) = %.3f", (double)s / onceki);
        }
        printf("\n");
        onceki = s;
    }
    return 0;
}

/* Kütüphane karşılığı: yok (sayma deneyi); toplam n·H_n ≈ n ln n
 * (harmonik seri). */

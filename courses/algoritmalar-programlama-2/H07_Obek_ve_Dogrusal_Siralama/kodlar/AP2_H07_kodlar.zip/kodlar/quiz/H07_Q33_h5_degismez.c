/* H07_Q33_h5_degismez.c — AP-2 Hafta 7 · Vize hazırlık (H5) · Değişmez
 * Amaç    : Seçmeli ve araya ekleme sıralamasının dış döngü değişmezleri.
 *           Dört aday ifade (A–D) iki algoritmada, rastgele dizilerde her
 *           dış yinelemenin BAŞINDA sınanır; ihlal sayıları yazılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q33_h5_degismez.c \
 *           ../c/ortak_rastgele.c -o H07_Q33_h5_degismez
 * Çalıştır: ./H07_Q33_h5_degismez
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../c/ortak_rastgele.h"

#define N 10

static int artan(const void *x, const void *y)
{
    int a = *(const int *)x, b = *(const int *)y;
    return (a > b) - (a < b);
}

static bool sirali(const int *a, int bas, int son)    /* a[bas..son-1] */
{
    for (int k = bas + 1; k < son; k++) {
        if (a[k - 1] > a[k]) {
            return false;
        }
    }
    return true;
}

static bool ayni_coklu_kume(const int *a, const int *b, int m)
{
    int x[N], y[N];
    memcpy(x, a, (size_t)m * sizeof *x);
    memcpy(y, b, (size_t)m * sizeof *y);
    qsort(x, (size_t)m, sizeof *x, artan);
    qsort(y, (size_t)m, sizeof *y, artan);
    return memcmp(x, y, (size_t)m * sizeof *x) == 0;
}

/* i. dış yinelemenin başında A–D */
static void sina(const int *a, const int *ilk, const int *sirali_ilk,
                 int i, int *ihlal)
{
    ihlal[0] += !sirali(a, 0, i);                                 /* A */
    ihlal[1] += memcmp(a, sirali_ilk, (size_t)i * sizeof *a) != 0;  /* B */
    ihlal[2] += !sirali(a, i, N);                                 /* C */
    ihlal[3] += !ayni_coklu_kume(a, ilk, i);                      /* D */
}

int main(void)
{
    int ihlal_s[4] = {0}, ihlal_a[4] = {0};
    int ilk[N], s[N], a[N];
    rastgele_tohum(42);
    for (int deneme = 0; deneme < 500; deneme++) {
        rastgele_dizi(ilk, N, 0, 99);
        memcpy(s, ilk, sizeof s);
        qsort(s, N, sizeof *s, artan);                 /* kâhin */
        memcpy(a, ilk, sizeof a);                      /* seçmeli */
        for (int i = 0; i < N - 1; i++) {
            sina(a, ilk, s, i, ihlal_s);
            int m = i;
            for (int j = i + 1; j < N; j++) {
                if (a[j] < a[m]) {
                    m = j;
                }
            }
            int g = a[i];
            a[i] = a[m];
            a[m] = g;
        }
        memcpy(a, ilk, sizeof a);                      /* araya ekleme */
        for (int i = 1; i < N; i++) {
            sina(a, ilk, s, i, ihlal_a);
            int x = a[i], j = i - 1;
            while (j >= 0 && a[j] > x) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = x;
        }
    }
    printf("seçmeli     ihlal: A = %d, B = %d, C = %d, D = %d\n", ihlal_s[0],
           ihlal_s[1], ihlal_s[2], ihlal_s[3]);
    printf("araya ekleme ihlal: A = %d, B = %d, C = %d, D = %d\n",
           ihlal_a[0], ihlal_a[1], ihlal_a[2], ihlal_a[3]);
    return 0;
}

/* Kütüphane karşılığı: C — qsort (yalnız kâhin); C++ — std::sort;
 * Python — sorted. */

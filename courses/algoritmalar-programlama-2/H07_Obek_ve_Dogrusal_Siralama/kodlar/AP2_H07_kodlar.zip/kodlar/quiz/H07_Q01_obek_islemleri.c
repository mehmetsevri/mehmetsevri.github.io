/* H07_Q01_obek_islemleri.c — AP-2 Hafta 7 · Quiz S1–S3 (denetim programı)
 * Amaç    : Haftalık quizin üç öbek sorusunu programla doğrular:
 *           (1) Örnek 1'in öbeğine 89 eklemek, (2) aynı öbekten en büyüğü
 *           çıkarmak, (3) artan 15 elemanı aşağıdan yukarıya öbek yapmak.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q01_obek_islemleri.c -o H07_Q01_obek_islemleri
 * Çalıştır: ./H07_Q01_obek_islemleri
 */
#include <stdio.h>

static int takas_sayisi = 0;

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
    takas_sayisi++;
}

static void yukari_suz(int *a, int i)
{
    while (i > 0 && a[i] > a[(i - 1) / 2]) {
        takas(&a[i], &a[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

static void asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c + 1] > a[c]) {
            c++;
        }
        if (a[c] <= a[i]) {
            break;
        }
        takas(&a[i], &a[c]);
        i = c;
    }
}

static void yaz(const char *baslik, const int *a, int n)
{
    printf("%s", baslik);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("  (takas = %d)\n", takas_sayisi);
}

int main(void)
{
    const int obek[] = {95, 88, 92, 71, 84, 63, 90, 45, 52, 79};
    int a[16];
    int n = 10;
    for (int i = 0; i < n; i++) {
        a[i] = obek[i];
    }
    takas_sayisi = 0;
    a[n++] = 89;
    yukari_suz(a, n - 1);
    yaz("S1 ekle 89 :", a, n);

    n = 10;
    for (int i = 0; i < n; i++) {
        a[i] = obek[i];
    }
    takas_sayisi = 0;
    int kok = a[0];
    a[0] = a[--n];
    asagi_suz(a, n, 0);
    printf("S2 çıkan = %d;", kok);
    yaz("", a, n);

    n = 15;
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }
    takas_sayisi = 0;
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
    int birler = 0;
    for (int x = n; x > 0; x >>= 1) {
        birler += x & 1;
    }
    printf("S3 artan 1..15 kurma: takas = %d, n - popcount(n) = %d\n",
           takas_sayisi, n - birler);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::push_heap, std::pop_heap,
 * std::make_heap; Python — heapq (en küçük öbek). */

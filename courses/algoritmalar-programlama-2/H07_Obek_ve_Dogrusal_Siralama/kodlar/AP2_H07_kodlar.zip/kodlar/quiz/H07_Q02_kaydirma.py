"""H07_Q02_kaydirma.py — AP-2 Hafta 7 · Quiz S8 (diller arası okuma)
Amaç    : Negatif bir tamsayıyı sağa kaydırmak Python'da ne verir?
          Aynı bayt çıkarma işlemi C'de uint32_t ile (H07_Q02_kaydirma.c).
Çalıştır: python3 H07_Q02_kaydirma.py
"""


def main():
    x = -5
    print(x >> 24, (x >> 24) & 0xFF)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (dil davranışı). Python'da tamsayı sınırsızdır;
# negatif sayının sağa kaydırılması işaret bitini sonsuza dek genişletir.

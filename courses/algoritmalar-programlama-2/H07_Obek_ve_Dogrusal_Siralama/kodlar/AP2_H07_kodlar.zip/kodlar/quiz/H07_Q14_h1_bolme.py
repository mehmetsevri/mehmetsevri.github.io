"""H07_Q14_h1_bolme.py — AP-2 Hafta 7 · Vize hazırlık (H1) · Diller arası
Amaç    : Negatif sayılarda tamsayı bölmesi ve kalan: Python // aşağı
          yuvarlar; C karşılığı: H07_Q14_h1_bolme.c
Çalıştır: python3 H07_Q14_h1_bolme.py
"""


def main():
    print(-9 // 4, -9 % 4)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: Python — divmod(-9, 4); C — div() (sıfıra doğru);
# C++ — std::div.

/* H07_Q13_h1_hatali_en_buyuk.c — AP-2 Hafta 7 · Vize hazırlık (H1) · Hata bulma
 * Amaç    : Başlangıç değeri hatalı "en büyük" fonksiyonu hangi girdide
 *           yanlış sonuç verir? Program dört aday girdiyi doğru sürümle
 *           karşılaştırır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q13_h1_hatali_en_buyuk.c -o H07_Q13_h1_hatali_en_buyuk
 * Çalıştır: ./H07_Q13_h1_hatali_en_buyuk
 */
#include <stdio.h>

static int en_buyuk(const int *a, size_t n)  /* ön koşul: n >= 1 */
{
    int m = 0;
    for (size_t i = 0; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

static int en_buyuk_dogru(const int *a, size_t n)
{
    int m = a[0];
    for (size_t i = 1; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }
    return m;
}

int main(void)
{
    const int g1[] = {3, 1, 2}, g2[] = {-5, -2, -9}, g3[] = {0, 0, 0},
              g4[] = {7};
    const int *g[] = {g1, g2, g3, g4};
    const size_t n[] = {3, 3, 3, 1};
    for (int k = 0; k < 4; k++) {
        int s = en_buyuk(g[k], n[k]), d = en_buyuk_dogru(g[k], n[k]);
        printf("girdi %d: hatalı = %d, doğru = %d -> %s\n", k + 1, s, d,
               s == d ? "aynı" : "FARKLI");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::max_element; Python — max(a). */

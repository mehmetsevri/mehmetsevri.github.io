/* H07_Q29_h4_sonsuz_dongu.c — AP-2 Hafta 7 · Vize hazırlık (H4) · Hata bulma
 * Amaç    : lo = mid yazılan ikili arama hangi x için sonsuz döngüye girer?
 *           Program her aday x'te yineleme sayısını 100 ile sınırlar.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q29_h4_sonsuz_dongu.c -o H07_Q29_h4_sonsuz_dongu
 * Çalıştır: ./H07_Q29_h4_sonsuz_dongu
 */
#include <stdio.h>

static int yineleme = 0;

static int ara(const int *a, int n, int x)
{
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < x) {
            lo = mid;
        } else {
            hi = mid;
        }
    }
    return a[lo] == x ? lo : -1;
}

/* aynı fonksiyon; yalnızca denetim için 100 yinelemede kesilir */
static int ara_sinirli(const int *a, int n, int x)
{
    int lo = 0, hi = n - 1;
    while (lo < hi && ++yineleme <= 100) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < x) {
            lo = mid;
        } else {
            hi = mid;
        }
    }
    return a[lo] == x ? lo : -1;
}

int main(void)
{
    const int a[] = {1, 3, 5, 7};
    const int aday[] = {-5, 0, 1, 5};
    for (int k = 0; k < 4; k++) {
        yineleme = 0;
        int s = ara_sinirli(a, 4, aday[k]);
        printf("x = %2d: %s (sonuç %d)\n", aday[k],
               yineleme > 100 ? "SONSUZ DÖNGÜ (100'de kesildi)" : "bitti", s);
    }
    printf("ara(a, 4, 1) = %d\n", ara(a, 4, 1));
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::lower_bound; Python —
 * bisect. Düzeltme: lo = mid + 1. */

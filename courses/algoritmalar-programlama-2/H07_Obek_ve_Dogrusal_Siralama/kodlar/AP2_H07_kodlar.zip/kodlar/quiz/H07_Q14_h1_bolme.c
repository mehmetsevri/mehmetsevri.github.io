/* H07_Q14_h1_bolme.c — AP-2 Hafta 7 · Vize hazırlık (H1) · Diller arası
 * Amaç    : H07_Q14_h1_bolme.py'nin C karşılığı: C99'dan beri tamsayı
 *           bölmesi sıfıra doğru keser; kalan bölünenin işaretini alır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q14_h1_bolme.c \
 *           -o H07_Q14_h1_bolme
 * Çalıştır: ./H07_Q14_h1_bolme
 */
#include <stdio.h>

int main(void)
{
    printf("%d %d\n", -9 / 4, -9 % 4);
    return 0;
}

/* Kütüphane karşılığı: C — div(); C++ — std::div; Python — divmod. */

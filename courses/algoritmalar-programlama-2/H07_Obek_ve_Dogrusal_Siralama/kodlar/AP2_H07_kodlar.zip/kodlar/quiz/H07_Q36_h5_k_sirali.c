/* H07_Q36_h5_k_sirali.c — AP-2 Hafta 7 · Vize hazırlık (H5) · Strateji seçimi
 * Amaç    : Her elemanı sıralı konumundan en çok 3 uzakta olan n = 2000
 *           elemanlı dizide dört yöntemin karşılaştırma sayısı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q36_h5_k_sirali.c \
 *           ../c/ortak_rastgele.c -o H07_Q36_h5_k_sirali
 * Çalıştır: ./H07_Q36_h5_k_sirali
 */
#include <stdio.h>
#include <string.h>

#include "../c/ortak_rastgele.h"

#define N 2000

static long long kars = 0;

static int kucuk(int x, int y)
{
    kars++;
    return x < y;
}

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static void secmeli(int *a, int n)
{
    for (int i = 0; i + 1 < n; i++) {
        int m = i;
        for (int j = i + 1; j < n; j++) {
            if (kucuk(a[j], a[m])) {
                m = j;
            }
        }
        takas(&a[i], &a[m]);
    }
}

static void araya_ekleme(int *a, int n)
{
    for (int i = 1; i < n; i++) {
        int x = a[i], j = i - 1;
        while (j >= 0 && kucuk(x, a[j])) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}

static void lomuto(int *a, int lo, int hi)   /* pivot: a[hi] */
{
    while (lo < hi) {
        int p = a[hi], i = lo - 1;
        for (int j = lo; j < hi; j++) {
            if (kucuk(a[j], p)) {
                takas(&a[++i], &a[j]);
            }
        }
        takas(&a[i + 1], &a[hi]);
        int m = i + 1;
        if (m - lo < hi - m) {        /* küçük parça özyineli: derinlik */
            lomuto(a, lo, m - 1);
            lo = m + 1;
        } else {
            lomuto(a, m + 1, hi);
            hi = m - 1;
        }
    }
}

static void kabarcik_erken_cikissiz(int *a, int n)
{
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (kucuk(a[j + 1], a[j])) {
                takas(&a[j], &a[j + 1]);
            }
        }
    }
}

int main(void)
{
    int g[N], a[N];
    for (int i = 0; i < N; i++) {
        g[i] = i;
    }
    rastgele_tohum(42);
    for (int b = 0; b + 3 < N; b += 4) {   /* 4'lük bloklar içinde karıştır */
        for (int i = 3; i > 0; i--) {
            int j = rastgele_aralik(0, i);
            takas(&g[b + i], &g[b + j]);
        }
    }
    const char *ad[] = {"seçmeli", "araya ekleme", "Lomuto (son eleman)",
                        "kabarcık (erken çıkışsız)"};
    for (int y = 0; y < 4; y++) {
        memcpy(a, g, sizeof a);
        kars = 0;
        if (y == 0) {
            secmeli(a, N);
        } else if (y == 1) {
            araya_ekleme(a, N);
        } else if (y == 2) {
            lomuto(a, 0, N - 1);
        } else {
            kabarcik_erken_cikissiz(a, N);
        }
        int ok = 1;
        for (int i = 0; i < N; i++) {
            ok = ok && a[i] == i;
        }
        printf("%s: karşılaştırma = %lld%s\n", ad[y], kars,
               ok ? "" : " (YANLIŞ)");
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — sorted
 * (Timsort neredeyse sıralı veride de hızlıdır). */

/* H07_Q20_h2_tasma.c — AP-2 Hafta 7 · Vize hazırlık (H2) · Diller arası
 * Amaç    : 64 bitlik işaretsiz tamsayıda 2^64: işaretsiz taşma 2^64
 *           modunda TANIMLIDIR. Python karşılığı: H07_Q20_h2_tasma.py
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q20_h2_tasma.c \
 *           -o H07_Q20_h2_tasma
 * Çalıştır: ./H07_Q20_h2_tasma
 */
#include <inttypes.h>
#include <stdio.h>

int main(void)
{
    uint64_t x = 1;
    for (int i = 0; i < 64; i++) {
        x *= 2;
    }
    printf("%" PRIu64 "\n", x);
    return 0;
}

/* Kütüphane karşılığı: yok (dil davranışı); Python tamsayısı sınırsızdır. */

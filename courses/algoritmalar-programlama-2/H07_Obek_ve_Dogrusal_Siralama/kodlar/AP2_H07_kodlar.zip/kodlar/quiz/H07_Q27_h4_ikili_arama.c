/* H07_Q27_h4_ikili_arama.c — AP-2 Hafta 7 · Vize (H4) · İzleme, Karmaşıklık
 * Amaç    : Kapalı aralıkta ikili arama: (1) Hafta 4'ün 16 elemanlı
 *           dizisinde x = 61 için yoklanan değerler; (2) n = 10^6 elemanlı
 *           a[i] = 2i + 1 dizisinde başarısız aramaların en çok yoklaması.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q27_h4_ikili_arama.c -o H07_Q27_h4_ikili_arama
 * Çalıştır: ./H07_Q27_h4_ikili_arama
 */
#include <stdio.h>
#include <stdlib.h>

static int yoklama = 0;
static int iz = 0;  /* 1: yoklanan değerleri yaz */

static int ikili_ara(const int *a, int n, int x)
{
    int lo = 0, hi = n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        yoklama++;
        if (iz) {
            printf(" %d", a[mid]);
        }
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return -1;
}

int main(void)
{
    const int d[] = {3, 8, 14, 19, 23, 31, 37, 42,
                     50, 56, 61, 67, 73, 80, 88, 95};
    printf("x = 61, yoklanan:");
    iz = 1;
    int k = ikili_ara(d, 16, 61);
    iz = 0;
    printf("  -> konum %d, yoklama = %d\n", k, yoklama);

    const int n = 1000000;
    int *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    for (int i = 0; i < n; i++) {
        a[i] = 2 * i + 1;
    }
    int en_cok = 0;
    for (int x = 0; x <= 2 * n; x += 2) {   /* hepsi başarısız */
        yoklama = 0;
        ikili_ara(a, n, x);
        if (yoklama > en_cok) {
            en_cok = yoklama;
        }
    }
    printf("n = %d, başarısız aramada en çok yoklama = %d\n", n, en_cok);
    free(a);
    return 0;
}

/* Kütüphane karşılığı: C — bsearch; C++ — std::binary_search,
 * std::lower_bound; Python — bisect.bisect_left. */

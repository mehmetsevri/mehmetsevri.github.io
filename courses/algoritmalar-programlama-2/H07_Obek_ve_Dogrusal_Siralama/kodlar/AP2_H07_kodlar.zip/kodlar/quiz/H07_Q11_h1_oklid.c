/* H07_Q11_h1_oklid.c — AP-2 Hafta 7 · Vize hazırlık (H1) · İzleme
 * Amaç    : Öklid algoritmasının döngüsünü izleyin: ebob(252, 105)
 *           kaç yinelemede biter ve sonuç nedir?
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q11_h1_oklid.c \
 *           -o H07_Q11_h1_oklid
 * Çalıştır: ./H07_Q11_h1_oklid
 */
#include <stdio.h>

static int adim = 0;

static int ebob(int a, int b)
{
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
        adim++;
    }
    return a;
}

int main(void)
{
    int g = ebob(252, 105);
    printf("ebob = %d, yineleme = %d\n", g, adim);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::gcd (<numeric>, C++17);
 * Python — math.gcd. */

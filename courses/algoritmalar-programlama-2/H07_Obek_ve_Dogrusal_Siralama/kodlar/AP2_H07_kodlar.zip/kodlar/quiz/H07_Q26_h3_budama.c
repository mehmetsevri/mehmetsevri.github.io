/* H07_Q26_h3_budama.c — AP-2 Hafta 7 · Vize hazırlık (H3) · Hata bulma
 * Amaç    : "toplam > hedef ise dur" budaması hangi girdide bir çözümü
 *           kaçırır? Dört aday girdide budamalı ve kaba kuvvet sürümlerin
 *           bulduğu çözüm sayıları karşılaştırılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q26_h3_budama.c \
 *           -o H07_Q26_h3_budama
 * Çalıştır: ./H07_Q26_h3_budama
 */
#include <stdio.h>

static const int *a;
static int n, hedef, cozum;

static void budamali(int i, int toplam)
{
    if (toplam > hedef) {
        return;  /* budama */
    }
    if (i == n) {
        cozum += toplam == hedef;
        return;
    }
    budamali(i + 1, toplam + a[i]);
    budamali(i + 1, toplam);
}

static void kaba_kuvvet(int i, int toplam)
{
    if (i == n) {
        cozum += toplam == hedef;
        return;
    }
    kaba_kuvvet(i + 1, toplam + a[i]);
    kaba_kuvvet(i + 1, toplam);
}

int main(void)
{
    static const int g1[] = {1, 2, 3}, g2[] = {4, -2, 3}, g3[] = {2, 2},
                     g4[] = {5, 1};
    const int *g[] = {g1, g2, g3, g4};
    const int gn[] = {3, 3, 2, 2}, gh[] = {3, 2, 4, 6};
    for (int k = 0; k < 4; k++) {
        a = g[k];
        n = gn[k];
        hedef = gh[k];
        cozum = 0;
        budamali(0, 0);
        int b = cozum;
        cozum = 0;
        kaba_kuvvet(0, 0);
        printf("girdi %d (hedef %d): budamalı = %d, kaba kuvvet = %d\n",
               k + 1, hedef, b, cozum);
    }
    return 0;
}

/* Kütüphane karşılığı: yok (geri izleme elle yazılır). */

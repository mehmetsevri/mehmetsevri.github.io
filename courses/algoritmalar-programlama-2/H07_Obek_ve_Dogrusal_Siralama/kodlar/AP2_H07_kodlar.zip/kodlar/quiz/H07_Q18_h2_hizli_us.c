/* H07_Q18_h2_hizli_us.c — AP-2 Hafta 7 · Vize hazırlık (H2) · İzleme, Değişmez
 * Amaç    : Yinelemeli hızlı üs alma (sağdan sola ikili yöntem): us_mod
 *           (3, 13, 1000) sonucu ve çarpma sayısı; dört aday değişmezin
 *           her yinelemenin BAŞINDA doğru olup olmadığı sınanır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q18_h2_hizli_us.c \
 *           -o H07_Q18_h2_hizli_us
 * Çalıştır: ./H07_Q18_h2_hizli_us
 */
#include <stdio.h>

static int carpma = 0;

static long long us_mod(long long b, long long e, long long m)
{
    long long r = 1;
    b %= m;
    while (e > 0) {
        if (e & 1) {
            r = r * b % m;
            carpma++;
        }
        b = b * b % m;
        carpma++;
        e >>= 1;
    }
    return r;
}

static long long yavas_us(long long b, long long e, long long m)
{
    long long r = 1;
    for (long long k = 0; k < e; k++) {
        r = r * b % m;
    }
    return r;
}

int main(void)
{
    long long sonuc = us_mod(3, 13, 1000);  /* önce çağır, sonra yazdır */
    printf("us_mod(3, 13, 1000) = %lld, çarpma = %d\n", sonuc, carpma);
    /* değişmez adayları: hedef = 3^13 mod 1000 */
    const long long m = 1000, hedef = yavas_us(3, 13, 1000);
    long long r = 1, b = 3, e = 13;
    int ihlal[4] = {0, 0, 0, 0}, adim = 0;
    while (1) {
        adim++;
        ihlal[0] += (r * yavas_us(b, e, m)) % m != hedef;  /* A */
        ihlal[1] += r != yavas_us(3, e, m);               /* B */
        ihlal[2] += b != (r * r) % m;                     /* C */
        ihlal[3] += (r * b) % m != hedef;                 /* D */
        if (e == 0) {
            break;
        }
        if (e & 1) {
            r = r * b % m;
        }
        b = b * b % m;
        e >>= 1;
    }
    printf("sınama = %d; ihlal: A = %d, B = %d, C = %d, D = %d\n", adim,
           ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — yok; Python — pow(b, e, m). */

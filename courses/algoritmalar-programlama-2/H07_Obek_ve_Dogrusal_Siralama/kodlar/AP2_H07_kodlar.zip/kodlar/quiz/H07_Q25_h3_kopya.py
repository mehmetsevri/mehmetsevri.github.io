"""H07_Q25_h3_kopya.py — AP-2 Hafta 7 · Vize hazırlık (H3) · Diller arası
Amaç    : Geri izlemede çözümü saklarken listenin KENDİSİNİ eklemek ile
          kopyasını eklemek arasındaki fark (başvuru semantiği).
Çalıştır: python3 H07_Q25_h3_kopya.py
"""


def alt_kumeler(i, yol, sonuc):
    if i == 2:
        sonuc.append(yol)
        return
    alt_kumeler(i + 1, yol, sonuc)
    yol.append(i)
    alt_kumeler(i + 1, yol, sonuc)
    yol.pop()


def main():
    sonuc = []
    alt_kumeler(0, [], sonuc)
    print(sonuc)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: itertools.combinations / itertools.product; kopya
# için sonuc.append(yol[:]) ya da list(yol).

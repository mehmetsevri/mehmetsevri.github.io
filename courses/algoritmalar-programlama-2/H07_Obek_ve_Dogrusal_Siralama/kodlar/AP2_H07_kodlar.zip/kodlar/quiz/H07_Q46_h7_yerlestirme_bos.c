/* H07_Q46_h7_yerlestirme_bos.c — AP-2 Hafta 7 · Vize (H7) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: kararlı sayma sıralamasının
 * yerleştirme döngüsü. onek[v], anahtarı <= v olan kayıt sayısıdır
 * (v bloğunun BİTİŞİ). Boş satırı doldurun.
 */
#include <stdio.h>

typedef struct {
    int no;
    int anahtar;
} Kayit;

static void yerlestir(const Kayit *a, Kayit *b, int n, int *onek)
{
    for (int i = n - 1; i >= 0; i--) {
        ________________________________;
    }
}

int main(void)
{
    const Kayit a[] = {{1, 2}, {2, 0}, {3, 2}, {4, 1}};
    int onek[3] = {1, 2, 4};   /* sayac = 1 1 2 -> önek toplam */
    Kayit b[4];
    yerlestir(a, b, 4, onek);
    for (int i = 0; i < 4; i++) {
        printf("(%d, %d) ", b[i].no, b[i].anahtar);
    }
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: yok (sayma sıralaması elle yazılır). */

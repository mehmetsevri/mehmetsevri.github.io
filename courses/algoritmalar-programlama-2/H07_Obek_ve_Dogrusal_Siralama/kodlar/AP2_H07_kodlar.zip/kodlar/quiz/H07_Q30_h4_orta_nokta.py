"""H07_Q30_h4_orta_nokta.py — AP-2 Hafta 7 · Vize hazırlık (H4) · Diller arası
Amaç    : H07_Q30_h4_orta_nokta.c'nin Python karşılığı (tamsayı taşmaz).
Çalıştır: python3 H07_Q30_h4_orta_nokta.py
"""


def main():
    lo, hi = 4000000000, 4100000000
    mid = (lo + hi) // 2
    print(mid)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (dil davranışı).

/* H07_Q34_h5_kabarcik_kararlilik.c — AP-2 Hafta 7 · Vize (H5) · Hata bulma
 * Amaç    : Kabarcık sıralamasında hangi değişiklik KARARLILIĞI bozar?
 *           Dört değişiklik (A–D) eşit anahtarlı kayıtlarda denenir;
 *           her biri için "sıralı mı / kararlı mı" yazılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q34_h5_kabarcik_kararlilik.c -o H07_Q34_h5_kabarcik
 * Çalıştır: ./H07_Q34_h5_kabarcik
 */
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    int anahtar;
    int sira;  /* girdideki konum */
} Kayit;

static void takas(Kayit *x, Kayit *y)
{
    Kayit g = *x;
    *x = *y;
    *y = g;
}

static void kabarcik(Kayit *a, int n)
{
    for (int i = 0; i < n - 1; i++) {
        bool takas_oldu = false;
        for (int j = 0; j < n - 1 - i; j++) {
            if (a[j].anahtar > a[j + 1].anahtar) {
                takas(&a[j], &a[j + 1]);
                takas_oldu = true;
            }
        }
        if (!takas_oldu) {
            break;
        }
    }
}

/* tur 'A': > yerine >=; 'B': dış döngü n kez; 'C': erken çıkış yok;
 * 'D': iç döngü sınırı n - 1 */
static void kabarcik_degisik(Kayit *a, int n, char tur)
{
    int dis = tur == 'B' ? n : n - 1;
    for (int i = 0; i < dis; i++) {
        bool takas_oldu = false;
        int son = tur == 'D' ? n - 1 : n - 1 - i;
        for (int j = 0; j < son; j++) {
            bool ters = tur == 'A' ? a[j].anahtar >= a[j + 1].anahtar
                                   : a[j].anahtar > a[j + 1].anahtar;
            if (ters) {
                takas(&a[j], &a[j + 1]);
                takas_oldu = true;
            }
        }
        if (!takas_oldu && tur != 'C') {
            break;
        }
    }
}

int main(void)
{
    const int anahtarlar[] = {3, 1, 2, 3, 1, 2, 3, 1};
    Kayit g[8], a[8];
    for (int i = 0; i < 8; i++) {
        g[i].anahtar = anahtarlar[i];
        g[i].sira = i;
    }
    memcpy(a, g, sizeof a);
    kabarcik(a, 8);
    printf("özgün: ");
    for (int i = 0; i < 8; i++) {
        printf("%d/%d ", a[i].anahtar, a[i].sira);
    }
    printf("\n");
    for (char tur = 'A'; tur <= 'D'; tur++) {
        memcpy(a, g, sizeof a);
        kabarcik_degisik(a, 8, tur);
        bool s = true, k = true;
        for (int i = 1; i < 8; i++) {
            s = s && a[i - 1].anahtar <= a[i].anahtar;
            k = k && !(a[i - 1].anahtar == a[i].anahtar &&
                       a[i - 1].sira > a[i].sira);
        }
        printf("değişiklik %c: sıralı mı? %s, kararlı mı? %s\n", tur,
               s ? "evet" : "HAYIR", k ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — qsort (kararlılık güvencesi yok); C++ —
 * std::stable_sort; Python — sorted (kararlı). */

/* H07_Q40_h6_birlestirme_kararlilik.c — AP-2 Hafta 7 · Vize (H6) · Hata bulma
 * Amaç    : Birleştirmeli sıralamada hangi değişiklik sonucu SIRALI bırakıp
 *           KARARLILIĞI bozar? Dört değişiklik (A–D) eşit anahtarlı
 *           kayıtlarda denenir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q40_h6_birlestirme_kararlilik.c -o H07_Q40_h6_birlestirme
 * Çalıştır: ./H07_Q40_h6_birlestirme
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int anahtar;
    int sira;
} Kayit;

static char tur = ' ';   /* ' ': özgün; 'A'–'D': değişiklik */
static Kayit gecici[64];

/* a[lo..mid] ve a[mid+1..hi] sıralı -> a[lo..hi] sıralı */
static void birlestir(Kayit *a, int lo, int mid, int hi)
{
    Kayit *g = gecici;
    if (tur == 'D') {
        g = malloc(sizeof gecici);       /* D: her çağrıda yeni tampon */
        if (g == NULL) {
            exit(1);
        }
    }
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        bool soldan = tur == 'A' ? a[i].anahtar < a[j].anahtar
                                 : a[i].anahtar <= a[j].anahtar;
        g[k++] = soldan ? a[i++] : a[j++];
    }
    if (tur != 'B') {                    /* B: kalanlar kopyalanmaz */
        while (i <= mid) {
            g[k++] = a[i++];
        }
        while (j <= hi) {
            g[k++] = a[j++];
        }
    }
    memcpy(a + lo, g + lo, (size_t)(k - lo) * sizeof *a);
    if (tur == 'D') {
        free(g);
    }
}

static void sirala(Kayit *a, int lo, int hi)
{
    if (lo >= hi) {
        return;
    }
    int mid = tur == 'C' ? (lo + hi) / 2 : lo + (hi - lo) / 2;
    sirala(a, lo, mid);
    sirala(a, mid + 1, hi);
    birlestir(a, lo, mid, hi);
}

int main(void)
{
    const int anahtarlar[] = {2, 1, 2, 1, 3, 1, 2, 3, 1, 2};
    Kayit g[10], a[10];
    for (int i = 0; i < 10; i++) {
        g[i].anahtar = anahtarlar[i];
        g[i].sira = i;
    }
    int beklenen[10], m = 0;             /* kâhin: anahtarların sıralısı */
    for (int v = 1; v <= 3; v++) {
        for (int i = 0; i < 10; i++) {
            if (anahtarlar[i] == v) {
                beklenen[m++] = v;
            }
        }
    }
    for (char t = 'A'; t <= 'D'; t++) {
        tur = t;
        memcpy(a, g, sizeof a);
        sirala(a, 0, 9);
        bool s = true, k = true;
        for (int i = 0; i < 10; i++) {
            s = s && a[i].anahtar == beklenen[i];
            k = k && !(i > 0 && a[i - 1].anahtar == a[i].anahtar &&
                       a[i - 1].sira > a[i].sira);
        }
        printf("değişiklik %c: doğru sıralı mı? %s, kararlı mı? %s\n", t,
               s ? "evet" : "HAYIR", s && k ? "evet" : "HAYIR");
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (qsort kararlılık güvencesi vermez); C++ —
 * std::stable_sort; Python — sorted. */

/* H07_Q31_h5_iki_gecis.c — AP-2 Hafta 7 · Vize hazırlık (H5) · İzleme
 * Amaç    : Hafta 5'in dizisinde seçmeli, araya ekleme ve kabarcık
 *           sıralamasının İLK İKİ dış yinelemesinden sonraki durumları.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q31_h5_iki_gecis.c \
 *           -o H07_Q31_h5_iki_gecis
 * Çalıştır: ./H07_Q31_h5_iki_gecis
 */
#include <stdio.h>
#include <string.h>

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

/* yalnızca ilk "gecis" dış yineleme */
static void secmeli(int *a, int n, int gecis)
{
    for (int i = 0; i < gecis && i + 1 < n; i++) {
        int en_kucuk = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[en_kucuk]) {
                en_kucuk = j;
            }
        }
        takas(&a[i], &a[en_kucuk]);
    }
}

static void araya_ekleme(int *a, int n, int gecis)
{
    for (int i = 1; i <= gecis && i < n; i++) {
        int x = a[i], j = i - 1;
        while (j >= 0 && a[j] > x) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}

static void kabarcik(int *a, int n, int gecis)
{
    for (int g = 0; g < gecis; g++) {
        for (int j = 0; j + 1 < n - g; j++) {
            if (a[j] > a[j + 1]) {
                takas(&a[j], &a[j + 1]);
            }
        }
    }
}

static void yaz(const char *ad, const int *a, int n)
{
    printf("%s:", ad);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

int main(void)
{
    const int g[] = {42, 17, 8, 31, 25, 4, 39, 12};
    int a[8];
    memcpy(a, g, sizeof a);
    secmeli(a, 8, 2);
    yaz("seçmeli     ", a, 8);
    memcpy(a, g, sizeof a);
    araya_ekleme(a, 8, 2);
    yaz("araya ekleme", a, 8);
    memcpy(a, g, sizeof a);
    kabarcik(a, 8, 2);
    yaz("kabarcık    ", a, 8);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — sorted
 * (yalnızca kâhin olarak). */

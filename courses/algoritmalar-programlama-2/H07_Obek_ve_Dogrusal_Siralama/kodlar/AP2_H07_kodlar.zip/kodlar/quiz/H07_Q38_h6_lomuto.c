/* H07_Q38_h6_lomuto.c — AP-2 Hafta 7 · Vize hazırlık (H6) · İzleme, Karmaşıklık
 * Amaç    : (1) Hafta 6'nın dizisinde Lomuto bölümlemesinin sonucu (pivot
 *           a[hi], a[j] < pivot); (2) sıralı n = 1000 girdide son eleman
 *           pivotlu hızlı sıralamanın karşılaştırma sayısı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q38_h6_lomuto.c \
 *           -o H07_Q38_h6_lomuto
 * Çalıştır: ./H07_Q38_h6_lomuto
 */
#include <stdio.h>

static long long kars = 0;

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static int bolumle(int *a, int lo, int hi)
{
    int pivot = a[hi];
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        kars++;
        if (a[j] < pivot) {
            i++;
            takas(&a[i], &a[j]);
        }
    }
    takas(&a[i + 1], &a[hi]);
    return i + 1;
}

static void hizli(int *a, int lo, int hi)
{
    while (lo < hi) {            /* büyük parça döngüyle: derinlik sınırlı */
        int p = bolumle(a, lo, hi);
        if (p - lo < hi - p) {
            hizli(a, lo, p - 1);
            lo = p + 1;
        } else {
            hizli(a, p + 1, hi);
            hi = p - 1;
        }
    }
}

int main(void)
{
    int a[] = {6, 3, 8, 1, 7, 2, 5, 4};
    int p = bolumle(a, 0, 7);
    printf("bölümleme: [");
    for (int i = 0; i < 8; i++) {
        printf(i ? " %d" : "%d", a[i]);
    }
    printf("], p = %d\n", p);

    static int b[1000];
    for (int i = 0; i < 1000; i++) {
        b[i] = i;
    }
    kars = 0;
    hizli(b, 0, 999);
    printf("sıralı n = 1000: karşılaştırma = %lld, n(n-1)/2 = %d\n", kars,
           1000 * 999 / 2);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (introsort); Python —
 * sorted (yalnızca kâhin). */

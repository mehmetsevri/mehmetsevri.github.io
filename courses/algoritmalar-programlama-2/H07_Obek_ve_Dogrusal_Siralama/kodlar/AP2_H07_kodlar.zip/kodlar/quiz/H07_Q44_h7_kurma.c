/* H07_Q44_h7_kurma.c — AP-2 Hafta 7 · Vize hazırlık (H7) · İzleme
 * Amaç    : Altı elemanlı bir diziyi aşağıdan yukarıya en büyük öbek
 *           yapmak: sonuç dizi ve takas sayısı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q44_h7_kurma.c \
 *           -o H07_Q44_h7_kurma
 * Çalıştır: ./H07_Q44_h7_kurma
 */
#include <stdio.h>

static int takas_sayisi = 0;

static void asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c + 1] > a[c]) {
            c++;
        }
        if (a[c] <= a[i]) {
            break;
        }
        int g = a[i];
        a[i] = a[c];
        a[c] = g;
        takas_sayisi++;
        i = c;
    }
}

int main(void)
{
    int a[] = {3, 9, 2, 1, 4, 5};
    int n = 6;
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
    printf("öbek:");
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("  (takas = %d)\n", takas_sayisi);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::make_heap; Python —
 * heapq.heapify (en küçük öbek). */

/* H07_Q43_h6_tekrarli.c — AP-2 Hafta 7 · Vize hazırlık (H6) · Strateji seçimi
 * Amaç    : Anahtarları yalnızca 0..9 olan n = 20000 elemanda Lomuto
 *           (a[j] < pivot) ile üç yollu bölümlemenin karşılaştırma sayısı.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q43_h6_tekrarli.c \
 *           ../c/ortak_rastgele.c -o H07_Q43_h6_tekrarli
 * Çalıştır: ./H07_Q43_h6_tekrarli
 */
#include <stdio.h>
#include <string.h>

#include "../c/ortak_rastgele.h"

#define N 20000

static long long kars = 0;

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static void lomuto(int *a, int lo, int hi)
{
    while (lo < hi) {
        int p = a[hi], i = lo - 1;
        for (int j = lo; j < hi; j++) {
            kars++;
            if (a[j] < p) {
                takas(&a[++i], &a[j]);
            }
        }
        takas(&a[i + 1], &a[hi]);
        int m = i + 1;
        if (m - lo < hi - m) {
            lomuto(a, lo, m - 1);
            lo = m + 1;
        } else {
            lomuto(a, m + 1, hi);
            hi = m - 1;
        }
    }
}

/* Dijkstra: a[lo..lt-1] < p, a[lt..gt] = p, a[gt+1..hi] > p */
static void uc_yollu(int *a, int lo, int hi)
{
    while (lo < hi) {
        int p = a[lo], lt = lo, gt = hi, i = lo + 1;
        while (i <= gt) {
            kars++;
            if (a[i] < p) {
                takas(&a[lt++], &a[i++]);
            } else if (a[i] > p) {
                takas(&a[i], &a[gt--]);
            } else {
                i++;
            }
        }
        if (lt - lo < hi - gt) {
            uc_yollu(a, lo, lt - 1);
            lo = gt + 1;
        } else {
            uc_yollu(a, gt + 1, hi);
            hi = lt - 1;
        }
    }
}

int main(void)
{
    static int g[N], a[N];
    rastgele_tohum(42);
    rastgele_dizi(g, N, 0, 9);
    memcpy(a, g, sizeof a);
    kars = 0;
    lomuto(a, 0, N - 1);
    printf("Lomuto   : karşılaştırma = %lld\n", kars);
    memcpy(a, g, sizeof a);
    kars = 0;
    uc_yollu(a, 0, N - 1);
    printf("üç yollu : karşılaştırma = %lld\n", kars);
    printf("n(n-1)/2 = %lld, n log2 n ≈ %d\n", (long long)N * (N - 1) / 2,
           N * 14);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — sorted. */

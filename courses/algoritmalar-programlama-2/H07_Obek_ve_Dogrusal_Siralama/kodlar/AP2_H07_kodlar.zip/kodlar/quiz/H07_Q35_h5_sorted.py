"""H07_Q35_h5_sorted.py — AP-2 Hafta 7 · Vize hazırlık (H5) · Diller arası
Amaç    : sorted kararlıdır: eşit puanlı kayıtlar girdi sırasında kalır.
Çalıştır: python3 H07_Q35_h5_sorted.py
"""


def main():
    kayitlar = [("Ece", 70), ("Can", 85), ("Ada", 70), ("Bora", 85)]
    s = sorted(kayitlar, key=lambda r: r[1])
    print(" ".join(ad for ad, _ in s))


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: C — qsort (kararlılık güvencesi yok); C++ —
# std::stable_sort; Python — sorted, list.sort (kararlı).

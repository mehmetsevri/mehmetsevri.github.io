/* H07_Q24_h3_permutasyon_bos.c — AP-2 Hafta 7 · Vize (H3) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: kullanildi dizisiyle permütasyon
 * üretimi (seç -> dene -> geri al). n = 3 için 6 permütasyon sözlük
 * sırasında yazılmalı. Boş satırı doldurun.
 */
#include <stdio.h>

#define N 3

static const int a[N] = {1, 2, 3};
static int yol[N], kullanildi[N];
static int sayi = 0;

static void permutasyon(int k)
{
    if (k == N) {
        printf("%d%d%d ", yol[0], yol[1], yol[2]);
        sayi++;
        return;
    }
    for (int i = 0; i < N; i++) {
        if (!kullanildi[i]) {
            kullanildi[i] = 1;
            yol[k] = a[i];
            permutasyon(k + 1);
            ______________;
        }
    }
}

int main(void)
{
    permutasyon(0);
    printf("\npermütasyon = %d\n", sayi);
    return 0;
}

/* Kütüphane karşılığı: C — yok; C++ — std::next_permutation; Python —
 * itertools.permutations. */

/* H07_Q16_h1_dogrusal_bos.c — AP-2 Hafta 7 · Vize hazırlık (H1) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: doğrusal arama x'in İLK konumunu,
 * x yoksa -1 döndürmeli ("bulunamadı" sözleşmesi). İki boşluğu doldurun.
 */
#include <stdio.h>

static int dogrusal_ara(const int *a, int n, int x)
{
    for (int i = 0; i < n; i++) {
        if (a[i] == x) {
            return ____;
        }
    }
    return ____;
}

int main(void)
{
    const int a[] = {5, 8, 3, 8};
    printf("%d %d\n", dogrusal_ara(a, 4, 8), dogrusal_ara(a, 4, 7));
    return 0;
}

/* Kütüphane karşılığı: C — yok (POSIX lfind); C++ — std::find;
 * Python — a.index(x) (yoksa ValueError). */

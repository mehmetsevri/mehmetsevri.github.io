/* H07_Q37_h5_araya_bos.c — AP-2 Hafta 7 · Vize hazırlık (H5) · Kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez: araya ekleme sıralamasının iç
 * döngü koşulunu tamamlayın (artan, kararlı sıralama).
 */
#include <stdio.h>

static void araya_ekleme(int *a, int n)
{
    for (int i = 1; i < n; i++) {
        int x = a[i];
        int j = i - 1;
        while (j >= 0 && ________) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 39, 12};
    araya_ekleme(a, 8);
    for (int i = 0; i < 8; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort; Python — sorted. */

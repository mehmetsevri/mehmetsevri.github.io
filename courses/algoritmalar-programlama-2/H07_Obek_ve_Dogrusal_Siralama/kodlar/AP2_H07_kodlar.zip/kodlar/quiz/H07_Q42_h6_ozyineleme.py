"""H07_Q42_h6_ozyineleme.py — AP-2 Hafta 7 · Vize hazırlık (H6) · Diller arası
Amaç    : Lomuto bölümlemeli, iki özyinelemeli çağrılı hızlı sıralama
          sıralı 3000 elemanda ne yapar? (Özyineleme derinliği ≈ n.)
          C karşılığı: H07_Q42_h6_ozyineleme.c
Çalıştır: python3 H07_Q42_h6_ozyineleme.py
"""


def bolumle(a, lo, hi):
    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        if a[j] < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


def hizli(a, lo, hi):
    if lo < hi:
        p = bolumle(a, lo, hi)
        hizli(a, lo, p - 1)
        hizli(a, p + 1, hi)


def main():
    a = list(range(3000))
    try:
        hizli(a, 0, len(a) - 1)
        print("sıralandı")
    except RecursionError as e:
        print("RecursionError:", e)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: sorted / list.sort (Timsort; özyinelemesiz).

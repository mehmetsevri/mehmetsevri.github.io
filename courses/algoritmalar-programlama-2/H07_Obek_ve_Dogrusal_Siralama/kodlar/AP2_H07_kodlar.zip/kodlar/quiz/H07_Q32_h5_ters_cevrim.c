/* H07_Q32_h5_ters_cevrim.c — AP-2 Hafta 7 · Vize hazırlık (H5) · Karmaşıklık
 * Amaç    : Araya ekleme sıralamasının kaydırma sayısı dizinin ters çevrim
 *           sayısına eşittir. Hafta 5'in dizisinde ikisi de sayılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q32_h5_ters_cevrim.c -o H07_Q32_h5_ters_cevrim
 * Çalıştır: ./H07_Q32_h5_ters_cevrim
 */
#include <stdio.h>

static int ters_cevrim(const int *a, int n)
{
    int t = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            t += a[i] > a[j];
        }
    }
    return t;
}

static int araya_ekleme(int *a, int n)  /* kaydırma sayısını döndürür */
{
    int kaydirma = 0;
    for (int i = 1; i < n; i++) {
        int x = a[i], j = i - 1;
        while (j >= 0 && a[j] > x) {
            a[j + 1] = a[j];
            j--;
            kaydirma++;
        }
        a[j + 1] = x;
    }
    return kaydirma;
}

int main(void)
{
    int a[] = {42, 17, 8, 31, 25, 4, 39, 12};
    int t = ters_cevrim(a, 8);
    printf("ters çevrim = %d, kaydırma = %d, n(n-1)/2 = %d\n", t,
           araya_ekleme(a, 8), 8 * 7 / 2);
    return 0;
}

/* Kütüphane karşılığı: yok; ters çevrim sayısı birleştirmeli sıralamayla
 * Θ(n log n)'de de sayılabilir (Hafta 6, Örnek 8). */

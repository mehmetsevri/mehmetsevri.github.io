/* H07_Q42_h6_ozyineleme.c — AP-2 Hafta 7 · Vize hazırlık (H6) · Diller arası
 * Amaç    : H07_Q42_h6_ozyineleme.py'nin C karşılığı: aynı algoritma sıralı
 *           3000 elemanda ≈ 3000 derinliğe iner; C'de her çerçeve küçük
 *           olduğundan 8 MB'lık yığına sığar (bu derleyicide, -O2).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q42_h6_ozyineleme.c -o H07_Q42_h6_ozyineleme
 * Çalıştır: ./H07_Q42_h6_ozyineleme
 */
#include <stdio.h>

static int derinlik = 0, en_derin = 0;

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static int bolumle(int *a, int lo, int hi)
{
    int pivot = a[hi], i = lo - 1;
    for (int j = lo; j < hi; j++) {
        if (a[j] < pivot) {
            takas(&a[++i], &a[j]);
        }
    }
    takas(&a[i + 1], &a[hi]);
    return i + 1;
}

static void hizli(int *a, int lo, int hi)
{
    if (++derinlik > en_derin) {
        en_derin = derinlik;
    }
    if (lo < hi) {
        int p = bolumle(a, lo, hi);
        hizli(a, lo, p - 1);
        hizli(a, p + 1, hi);
    }
    derinlik--;
}

int main(void)
{
    static int a[3000];
    for (int i = 0; i < 3000; i++) {
        a[i] = i;
    }
    hizli(a, 0, 2999);
    printf("sıralandı; en büyük özyineleme derinliği = %d\n", en_derin);
    return 0;
}

/* Kütüphane karşılığı: C — qsort; C++ — std::sort (derinlik sınırlı
 * introsort); Python — sorted. */

/* H07_Q19_h2_asal.c — AP-2 Hafta 7 · Vize hazırlık (H2) · Hata bulma
 * Amaç    : Deneme bölmesinde döngü koşulu d * d <= n olmalıdır. Hatalı
 *           koşulla (d * d < n) dört aday sayı sınanır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_Q19_h2_asal.c \
 *           -o H07_Q19_h2_asal
 * Çalıştır: ./H07_Q19_h2_asal
 */
#include <stdbool.h>
#include <stdio.h>

static bool asal_mi(int n)
{
    if (n < 2) {
        return false;
    }
    for (int d = 2; d * d < n; d++) {
        if (n % d == 0) {
            return false;
        }
    }
    return true;
}

static bool asal_mi_dogru(int n)
{
    if (n < 2) {
        return false;
    }
    for (int d = 2; d * d <= n; d++) {
        if (n % d == 0) {
            return false;
        }
    }
    return true;
}

int main(void)
{
    const int aday[] = {15, 21, 25, 27};
    for (int k = 0; k < 4; k++) {
        printf("%d: hatalı = %s, doğru = %s\n", aday[k],
               asal_mi(aday[k]) ? "asal" : "asal değil",
               asal_mi_dogru(aday[k]) ? "asal" : "asal değil");
    }
    return 0;
}

/* Kütüphane karşılığı: yok (standart kütüphanelerde asallık sınaması
 * yoktur); Θ(√n) deneme bölmesi. */

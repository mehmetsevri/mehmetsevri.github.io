"""H07_Q20_h2_tasma.py — AP-2 Hafta 7 · Vize hazırlık (H2) · Diller arası
Amaç    : H07_Q20_h2_tasma.c'nin Python karşılığı: tamsayı sınırsızdır.
Çalıştır: python3 H07_Q20_h2_tasma.py
"""


def main():
    x = 1
    for _ in range(64):
        x *= 2
    print(x)


if __name__ == "__main__":
    main()

# Kütüphane karşılığı: yok (dil davranışı); 2 ** 64 ya da 1 << 64.

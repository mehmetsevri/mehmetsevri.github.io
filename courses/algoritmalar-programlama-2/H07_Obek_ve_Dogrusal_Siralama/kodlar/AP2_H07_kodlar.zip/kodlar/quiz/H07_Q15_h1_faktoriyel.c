/* H07_Q15_h1_faktoriyel.c — AP-2 Hafta 7 · Vize hazırlık (H1) · Hata bulma
 * Amaç    : int (32 bit) ile faktöriyel hangi n'de ilk kez taşar? İşaretli
 *           taşma TANIMSIZ DAVRANIŞTIR; program taşmayı çarpmadan ÖNCE
 *           long long ile denetler (taşan çarpma hiç yapılmaz).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q15_h1_faktoriyel.c -o H07_Q15_h1_faktoriyel
 * Çalıştır: ./H07_Q15_h1_faktoriyel
 */
#include <limits.h>
#include <stdio.h>

static int faktoriyel(int n)
{
    int f = 1;
    for (int k = 2; k <= n; k++) {
        f *= k;
    }
    return f;
}

int main(void)
{
    long long f = 1;
    for (int n = 2; n <= 20; n++) {
        if (f * n > INT_MAX) {
            printf("ilk taşan n = %d: %d! = %lld > INT_MAX = %d\n", n, n,
                   f * n, INT_MAX);
            printf("son güvenli: %d! = %d\n", n - 1, faktoriyel(n - 1));
            break;
        }
        f *= n;
    }
    return 0;
}

/* Kütüphane karşılığı: C — yok (taşma denetimi elle ya da GCC'de
 * __builtin_mul_overflow); C++ — yok; Python — math.factorial (sınırsız). */

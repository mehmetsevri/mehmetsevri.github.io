/* H07_Q30_h4_orta_nokta.c — AP-2 Hafta 7 · Vize hazırlık (H4) · Diller arası
 * Amaç    : (lo + hi) / 2 işaretsiz 32 bitte sarar (2^32 modunda tanımlı):
 *           orta nokta aralığın DIŞINA düşer. Python: H07_Q30_h4_orta_nokta.py
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q30_h4_orta_nokta.c -o H07_Q30_h4_orta_nokta
 * Çalıştır: ./H07_Q30_h4_orta_nokta
 */
#include <inttypes.h>
#include <stdio.h>

int main(void)
{
    uint32_t lo = 4000000000u, hi = 4100000000u;
    uint32_t mid = (lo + hi) / 2;
    printf("%" PRIu32 "\n", mid);
    return 0;
}

/* Kütüphane karşılığı: yok; güvenli yazım lo + (hi - lo) / 2. */

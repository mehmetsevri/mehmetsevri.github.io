/* H07_Q28_h4_lower_bound.c — AP-2 Hafta 7 · Vize hazırlık (H4) · Değişmez
 * Amaç    : Yarı açık aralıkta [lo, hi) lower_bound döngüsünün değişmezi.
 *           Dört aday ifade rastgele sıralı dizilerde her yinelemenin
 *           başında sınanır; ihlal sayıları yazılır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_Q28_h4_lower_bound.c ../c/ortak_rastgele.c \
 *           -o H07_Q28_h4_lower_bound
 * Çalıştır: ./H07_Q28_h4_lower_bound
 */
#include <stdbool.h>
#include <stdio.h>

#include "../c/ortak_rastgele.h"

/* ilk a[i] >= x konumu; yoksa n */
static int alt_sinir(const int *a, int n, int x)
{
    int lo = 0, hi = n;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < x) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo;
}

static bool A(const int *a, int n, int lo, int hi, int x)
{
    for (int i = 0; i < lo; i++) {
        if (!(a[i] < x)) {
            return false;
        }
    }
    for (int i = hi; i < n; i++) {
        if (!(a[i] >= x)) {
            return false;
        }
    }
    return true;
}

int main(void)
{
    int a[20], ihlal[4] = {0, 0, 0, 0}, sinama = 0, dogru = 0;
    rastgele_tohum(42);
    for (int deneme = 0; deneme < 3000; deneme++) {
        int n = rastgele_aralik(1, 20);
        a[0] = rastgele_aralik(0, 3);
        for (int i = 1; i < n; i++) {
            a[i] = a[i - 1] + rastgele_aralik(0, 2);   /* sıralı, tekrarlı */
        }
        int x = rastgele_aralik(-1, a[n - 1] + 1);
        int lo = 0, hi = n;
        while (1) {
            sinama++;
            int mid = lo + (hi - lo) / 2;
            ihlal[0] += !A(a, n, lo, hi, x);
            ihlal[1] += !(hi < n && lo < n && a[lo] <= x && x <= a[hi]);
            ihlal[2] += !(lo < hi && a[mid] == x);
            ihlal[3] += !(lo < hi && a[lo] == x && a[hi - 1] == x);
            if (lo >= hi) {
                break;
            }
            if (a[mid] < x) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        int k = 0;
        while (k < n && a[k] < x) {
            k++;
        }
        dogru += alt_sinir(a, n, x) == k;
    }
    printf("sınama = %d; ihlal: A = %d, B = %d, C = %d, D = %d\n", sinama,
           ihlal[0], ihlal[1], ihlal[2], ihlal[3]);
    printf("alt_sinir doğru: %d / 3000\n", dogru);
    return 0;
}

/* Kütüphane karşılığı: C — yok (bsearch yalnız eşitliği bulur); C++ —
 * std::lower_bound; Python — bisect.bisect_left. */

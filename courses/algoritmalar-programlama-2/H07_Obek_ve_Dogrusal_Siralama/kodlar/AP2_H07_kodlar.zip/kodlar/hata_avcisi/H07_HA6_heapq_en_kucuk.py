"""H07_HA6_heapq_en_kucuk.py — AP-2 Hafta 7 · Hata Avcısı 6
BU DOSYA KASITLI HATA İÇERİR: Python'un heapq modülü EN KÜÇÜK öbektir
(heap[0] en küçük eleman). En yüksek 3 not istenirken heappop en düşük
notları verir. (C++'taki std::priority_queue ise varsayılan olarak en
büyük öbektir: iki kütüphane ters yönde varsayılan kullanır.)
Çalıştır: python3 H07_HA6_heapq_en_kucuk.py
Düzeltme: H07_HA6_heapq_en_kucuk_duzeltilmis.py
"""
import heapq


def main():
    notlar = [71, 84, 63, 95, 52, 90, 45, 88, 79, 92]
    obek = []
    for x in notlar:
        heapq.heappush(obek, x)
    print("öbek listesi:", obek)
    print("obek[0] =", obek[0], "(kök)")
    ilk3 = [heapq.heappop(obek) for _ in range(3)]   # HATA: en küçükler
    print("en yüksek 3 not (sanılan):", ilk3)


if __name__ == "__main__":
    main()

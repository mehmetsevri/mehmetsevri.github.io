/* H07_HA5_kararsiz_gecis_duzeltilmis.c — AP-2 Hafta 7 · Hata Avcısı 5
 * (düzeltilmiş): önek dizisi "<= v olanların sayısı" (bitiş konumu)
 * olduğundan yerleştirme SAĞDAN SOLA yapılır; eşit basamaklılar girdi
 * sırasını korur (kararlı geçiş) ve LSD taban sıralaması doğru çalışır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA5_kararsiz_gecis_duzeltilmis.c \
 *           -o H07_HA5_kararsiz_gecis_duzeltilmis
 */
#include <stdbool.h>
#include <stdio.h>

static void ondalik_gecis(const int *a, int *b, int n, int bolen)
{
    int onek[10] = {0};
    for (int i = 0; i < n; i++) {
        onek[a[i] / bolen % 10]++;
    }
    for (int v = 1; v < 10; v++) {
        onek[v] += onek[v - 1];
    }
    for (int i = n - 1; i >= 0; i--) { /* sağdan sola: kararlı */
        b[--onek[a[i] / bolen % 10]] = a[i];
    }
}

int main(void)
{
    int a[] = {532, 418, 207, 351, 842, 135, 600, 214};
    int b[8];
    const char *ad[] = {"birler", "onlar ", "yüzler"};
    printf("girdi          :");
    for (int i = 0; i < 8; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
    for (int d = 0, bolen = 1; d < 3; d++, bolen *= 10) {
        ondalik_gecis(a, b, 8, bolen);
        printf("%d. geçiş %s :", d + 1, ad[d]);
        for (int i = 0; i < 8; i++) {
            a[i] = b[i];
            printf(" %d", a[i]);
        }
        printf("\n");
    }
    bool sirali = true;
    for (int i = 1; i < 8; i++) {
        sirali = sirali && a[i - 1] <= a[i];
    }
    printf("sıralı mı? %s\n", sirali ? "evet" : "HAYIR");
    return 0;
}

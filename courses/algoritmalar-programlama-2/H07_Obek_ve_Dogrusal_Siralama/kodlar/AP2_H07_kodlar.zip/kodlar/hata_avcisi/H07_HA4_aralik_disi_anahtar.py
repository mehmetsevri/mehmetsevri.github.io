"""H07_HA4_aralik_disi_anahtar.py — AP-2 Hafta 7 · Hata Avcısı 4
BU DOSYA KASITLI HATA İÇERİR: notların 0..100 olduğu varsayılıyor; aralık
denetimi yok. Python'da sayac[-1] HATA VERMEZ: negatif indis sondan sayar,
-1 notu sessizce 100 olarak sayılır. sayac[105] ise IndexError verir.
Çalıştır: python3 H07_HA4_aralik_disi_anahtar.py
Düzeltme: H07_HA4_aralik_disi_anahtar_duzeltilmis.py
"""

K = 100                                # en büyük not (varsayım)


def sayma_siralamasi(a):
    sayac = [0] * (K + 1)
    for x in a:
        sayac[x] += 1                  # HATA: x < 0 ya da x > K
    j = 0
    for v in range(K + 1):
        for _ in range(sayac[v]):
            a[j] = v
            j += 1


def main():
    notlar = [85, 70, -1, 100, 45, 70, 90]
    print("1) girdi:", *notlar)
    sayma_siralamasi(notlar)
    print("   çıktı:", *notlar)
    notlar = [85, 70, 100, 45, 105, 70, 90]
    print("2) girdi:", *notlar)
    sayma_siralamasi(notlar)
    print("   çıktı:", *notlar)


if __name__ == "__main__":
    main()

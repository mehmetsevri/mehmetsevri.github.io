/* H07_HA4_aralik_disi_anahtar_duzeltilmis.c — AP-2 Hafta 7 · Hata
 * Avcısı 4 (düzeltilmiş): her anahtar sayaca girmeden önce aralık
 * denetiminden geçer; 0..k dışındakiler raporlanır ve sıralamaya alınmaz.
 * (Negatif anahtarlar gerçekten gerekiyorsa en küçük değer kadar kaydırma
 * yapılır: indis = x - en_kucuk, k = en_buyuk - en_kucuk.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA4_aralik_disi_anahtar_duzeltilmis.c \
 *           -o H07_HA4_aralik_disi_anahtar_duzeltilmis
 */
#include <stdio.h>
#include <stdlib.h>

#define K 100

/* Geçerli anahtarları sıralı olarak a[0..m-1]'e yazar; m'yi döndürür */
static int sayma_siralamasi(int *a, int n)
{
    int *sayac = calloc(K + 1, sizeof *sayac);
    if (sayac == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        if (a[i] < 0 || a[i] > K) {    /* aralık denetimi */
            printf("  geçersiz not: %d (konum %d) — sıralamaya alınmadı\n",
                   a[i], i);
            continue;
        }
        sayac[a[i]]++;
    }
    int j = 0;
    for (int v = 0; v <= K; v++) {
        for (int c = 0; c < sayac[v]; c++) {
            a[j++] = v;
        }
    }
    free(sayac);
    return j;
}

int main(void)
{
    int notlar[] = {85, 70, -1, 100, 45, 105, 70, 90};
    const int n = 8;
    printf("girdi:");
    for (int i = 0; i < n; i++) {
        printf(" %d", notlar[i]);
    }
    printf("\n");
    int m = sayma_siralamasi(notlar, n);
    printf("çıktı (%d geçerli not):", m);
    for (int i = 0; i < m; i++) {
        printf(" %d", notlar[i]);
    }
    printf("\n");
    return 0;
}

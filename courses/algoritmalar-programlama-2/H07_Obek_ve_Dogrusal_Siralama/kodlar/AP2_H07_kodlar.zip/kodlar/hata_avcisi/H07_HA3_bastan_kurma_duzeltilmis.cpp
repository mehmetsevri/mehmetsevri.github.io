/* H07_HA3_bastan_kurma_duzeltilmis.cpp — AP-2 Hafta 7 · Hata Avcısı 3
 * (düzeltilmiş): öbek kurma son iç düğümden (n/2 - 1) KÖKE doğru
 * ilerler; i süzülürken iki alt ağacı zaten öbektir (döngü değişmezi:
 * i + 1 .. n - 1 düğümlerinin her biri bir öbeğin köküdür).
 * Derleme : g++ -std=c++17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA3_bastan_kurma_duzeltilmis.cpp \
 *           -o H07_HA3_bastan_kurma_duzeltilmis
 */
#include <iostream>
#include <string>
#include <utility>
#include <vector>

static void asagi_suz(std::vector<int>& a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c + 1] > a[c]) {
            c++;
        }
        if (a[c] <= a[i]) {
            break;
        }
        std::swap(a[i], a[c]);
        i = c;
    }
}

static void obek_kur(std::vector<int>& a)
{
    int n = static_cast<int>(a.size());
    for (int i = n / 2 - 1; i >= 0; i--) {   // aşağıdan yukarıya
        asagi_suz(a, n, i);
    }
}

static bool obek_mi(const std::vector<int>& a)
{
    for (std::size_t i = 1; i < a.size(); i++) {
        if (a[(i - 1) / 2] < a[i]) {
            return false;
        }
    }
    return true;
}

static void yaz(const std::string& ad, const std::vector<int>& a)
{
    std::cout << ad << ":";
    for (int x : a) {
        std::cout << " " << x;
    }
    std::cout << "\n";
}

int main()
{
    std::vector<int> a = {45, 52, 63, 71, 79, 84, 88, 90, 92, 95};
    int n = static_cast<int>(a.size());
    yaz("girdi       ", a);
    obek_kur(a);
    yaz("öbek kuruldu", a);
    std::cout << "öbek mi? " << (obek_mi(a) ? "evet" : "HAYIR")
              << "; kök = " << a[0] << " (en büyük 95 olmalı)\n";
    for (int son = n - 1; son > 0; son--) {
        std::swap(a[0], a[son]);
        asagi_suz(a, son, 0);
    }
    yaz("sıralandı   ", a);
    return 0;
}

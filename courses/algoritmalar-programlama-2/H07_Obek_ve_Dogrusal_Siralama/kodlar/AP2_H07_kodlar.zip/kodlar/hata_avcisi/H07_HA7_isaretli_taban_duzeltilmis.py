"""H07_HA7_isaretli_taban_duzeltilmis.py — AP-2 Hafta 7 · Hata Avcısı 7
(düzeltilmiş): 32 bitlik işaretli aralık [−2**31, 2**31) için anahtar =
x + 2**31; böylece anahtarlar 0 .. 2**32 − 1 olur, negatif kaydırma
yapılmaz ve işaretsiz sıra işaretli sırayla aynıdır (C'deki işaret biti
çevirmenin karşılığı).
Çalıştır: python3 H07_HA7_isaretli_taban_duzeltilmis.py
"""


def anahtar(x):
    return x + 2**31                   # 0 .. 2**32 − 1


def taban_siralamasi(a):
    n = len(a)
    b = [0] * n
    for kaydir in range(0, 32, 8):
        onek = [0] * 256
        for x in a:
            onek[(anahtar(x) >> kaydir) & 0xFF] += 1
        for v in range(1, 256):
            onek[v] += onek[v - 1]
        for i in range(n - 1, -1, -1):
            v = (anahtar(a[i]) >> kaydir) & 0xFF
            onek[v] -= 1
            b[onek[v]] = a[i]
        a[:] = b


def main():
    a = [42, -5, 17, -1, 0, -2**31, 2**31 - 1, 3]
    taban_siralamasi(a)
    print("sıralandı:", *a)
    print("anahtar(-5) =", hex(anahtar(-5)), "; en yüksek bayt =",
          hex(anahtar(-5) >> 24))


if __name__ == "__main__":
    main()

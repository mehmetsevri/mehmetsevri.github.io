/* H07_HA4_aralik_disi_anahtar.c — AP-2 Hafta 7 · Hata Avcısı 4
 * BU DOSYA KASITLI HATA İÇERİR: notların 0..100 olduğu VARSAYILIYOR ama
 * girdide -1 ("sınava girmedi") ve 105 (yanlış giriş) var. sayac[-1] ve
 * sayac[105] dizinin DIŞINA yazar: TANIMSIZ DAVRANIŞ (sınır dışı erişim).
 * Sonuç derleyiciye ve çalıştırmaya bağlıdır; "her zaman çöker" denemez.
 * Güvenli gösterim: AddressSanitizer ile derleyin (bkz. ciktilar/).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA4_aralik_disi_anahtar.c -o H07_HA4_aralik_disi_anahtar
 * Düzeltme: H07_HA4_aralik_disi_anahtar_duzeltilmis.c
 */
#include <stdio.h>
#include <stdlib.h>

#define K 100                          /* en büyük not (varsayım) */

static void sayma_siralamasi(int *a, int n)
{
    int *sayac = calloc(K + 1, sizeof *sayac);
    if (sayac == NULL) {
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        sayac[a[i]]++;                 /* HATA: a[i] < 0 ya da a[i] > K */
    }
    int j = 0;
    for (int v = 0; v <= K; v++) {
        for (int c = 0; c < sayac[v]; c++) {
            a[j++] = v;
        }
    }
    free(sayac);
}

int main(void)
{
    int notlar[] = {85, 70, -1, 100, 45, 105, 70, 90};
    const int n = 8;
    printf("girdi:");
    for (int i = 0; i < n; i++) {
        printf(" %d", notlar[i]);
    }
    printf("\n");
    sayma_siralamasi(notlar, n);
    printf("çıktı:");
    for (int i = 0; i < n; i++) {
        printf(" %d", notlar[i]);
    }
    printf("\n");
    return 0;
}

/* H07_HA2_ilk_cocuk_duzeltilmis.c — AP-2 Hafta 7 · Hata Avcısı 2
 * (düzeltilmiş): önce iki çocuktan BÜYÜĞÜ bulunur, sonra yalnızca o
 * çocukla karşılaştırılır; böylece köke çıkan değer iki alt ağacın da
 * en büyüğüdür ve öbek özelliği korunur.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA2_ilk_cocuk_duzeltilmis.c -o H07_HA2_ilk_cocuk_duzeltilmis
 */
#include <stdbool.h>
#include <stdio.h>

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static void asagi_suz(int *a, int n, int i)
{
    while (2 * i + 1 < n) {
        int c = 2 * i + 1;
        if (c + 1 < n && a[c + 1] > a[c]) {
            c++;                       /* büyük çocuk */
        }
        if (a[c] <= a[i]) {
            break;
        }
        takas(&a[i], &a[c]);
        i = c;
    }
}

static bool obek_mi(const int *a, int n)
{
    for (int i = 1; i < n; i++) {
        if (a[(i - 1) / 2] < a[i]) {
            return false;
        }
    }
    return true;
}

static void yaz(const char *ad, const int *a, int n)
{
    printf("%s:", ad);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

int main(void)
{
    int a[] = {71, 84, 63, 95, 52, 90, 45, 88, 79, 92};
    const int n = 10;
    yaz("girdi       ", a, n);
    for (int i = n / 2 - 1; i >= 0; i--) {
        asagi_suz(a, n, i);
    }
    yaz("öbek kuruldu", a, n);
    printf("öbek mi? %s\n", obek_mi(a, n) ? "evet" : "HAYIR");
    for (int son = n - 1; son > 0; son--) {
        takas(&a[0], &a[son]);
        asagi_suz(a, son, 0);
    }
    yaz("sıralandı   ", a, n);
    bool sirali = true;
    for (int i = 1; i < n; i++) {
        sirali = sirali && a[i - 1] <= a[i];
    }
    printf("sıralı mı? %s\n", sirali ? "evet" : "HAYIR");
    return 0;
}

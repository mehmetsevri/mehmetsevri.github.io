/* H07_HA1_bir_tabanli_indis.c — AP-2 Hafta 7 · Hata Avcısı 1
 * BU DOSYA KASITLI HATA İÇERİR: 1 tabanlı kitaplardaki çocuk formülleri
 * (sol = 2i, sağ = 2i + 1) 0 tabanlı C dizisine taşınmış; ebeveyn ise
 * 0 tabanlı (i - 1) / 2. İkinci bölümde yalnızca ebeveyn i / 2 yazılmış.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA1_bir_tabanli_indis.c -o H07_HA1_bir_tabanli_indis
 * Beklenen: azalan sırada çıkış; rastgele denemede 0 bozuk öbek
 * Düzeltme: H07_HA1_bir_tabanli_indis_duzeltilmis.c
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

static int ebeveyn(int i) { return (i - 1) / 2; }
static int sol_cocuk(int i) { return 2 * i; }          /* HATA: 2i + 1 */
static int sag_cocuk(int i) { return 2 * i + 1; }      /* HATA: 2i + 2 */

static void takas(int *x, int *y)
{
    int g = *x;
    *x = *y;
    *y = g;
}

static void yukari_suz(int *a, int i)
{
    while (i > 0 && a[i] > a[ebeveyn(i)]) {
        takas(&a[i], &a[ebeveyn(i)]);
        i = ebeveyn(i);
    }
}

static void asagi_suz(int *a, int n, int i)
{
    while (sol_cocuk(i) < n) {
        int c = sol_cocuk(i);
        if (sag_cocuk(i) < n && a[sag_cocuk(i)] > a[c]) {
            c = sag_cocuk(i);
        }
        if (a[c] <= a[i]) {
            break;
        }
        takas(&a[i], &a[c]);
        i = c;
    }
}

/* İkinci bölüm: yalnızca ebeveyn 1 tabanlı yazılmış yukarı süzme */
static void yukari_suz_i2(int *a, int i)
{
    while (i > 0 && a[i] > a[i / 2]) {                 /* HATA: (i-1)/2 */
        takas(&a[i], &a[i / 2]);
        i = i / 2;
    }
}

static bool obek_mi(const int *a, int n)
{
    for (int i = 1; i < n; i++) {
        if (a[(i - 1) / 2] < a[i]) {
            return false;
        }
    }
    return true;
}

int main(void)
{
    const int sira[] = {45, 79, 63, 90, 84, 92, 95, 52, 71, 88};
    int a[10], n = 0;
    for (int k = 0; k < 10; k++) {
        a[n++] = sira[k];
        yukari_suz(a, n - 1);
    }
    printf("1) öbek:");
    for (int i = 0; i < 10; i++) {
        printf(" %d", a[i]);
    }
    printf("\n   sırayla çıkarılanlar:");
    int onceki = 1000;
    bool azalan = true;
    while (n > 0) {
        int en_buyuk = a[0];
        a[0] = a[--n];
        asagi_suz(a, n, 0);
        printf(" %d", en_buyuk);
        azalan = azalan && en_buyuk <= onceki;
        onceki = en_buyuk;
    }
    printf("\n   azalan mı? %s\n", azalan ? "evet" : "HAYIR");

    /* 2) Rastgele 10 elemanlı diziler (64 bitlik LCG, tohum 42) */
    uint64_t durum = 42;
    int bozuk = 0;
    for (int t = 0; t < 10000; t++) {
        int b[10];
        for (int m = 0; m < 10; m++) {
            durum = durum * 6364136223846793005u + 1442695040888963407u;
            b[m] = (int)((durum >> 33) % 1000);
            yukari_suz_i2(b, m);
        }
        bozuk += !obek_mi(b, 10);
    }
    printf("2) ebeveyn = i / 2 ile 10000 rastgele dizide bozuk öbek: %d\n",
           bozuk);
    return 0;
}

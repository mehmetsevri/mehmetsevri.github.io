"""H07_HA7_isaretli_taban.py — AP-2 Hafta 7 · Hata Avcısı 7
BU DOSYA KASITLI HATA İÇERİR: negatif sayılar taban sıralamasına doğrudan
sokuluyor. Python'da x >> s negatif x için işaret bitini SONSUZA dek
genişletir (−5 >> 24 == −1); & 0xFF ile bayt 0xFF olur ve negatifler
tüm pozitiflerden sonra gelir.
Çalıştır: python3 H07_HA7_isaretli_taban.py
Düzeltme: H07_HA7_isaretli_taban_duzeltilmis.py
"""


def anahtar(x):
    return x                           # HATA: 2**31 eklenmeli


def taban_siralamasi(a):
    n = len(a)
    b = [0] * n
    for kaydir in range(0, 32, 8):
        onek = [0] * 256
        for x in a:
            onek[(anahtar(x) >> kaydir) & 0xFF] += 1
        for v in range(1, 256):
            onek[v] += onek[v - 1]
        for i in range(n - 1, -1, -1):
            v = (anahtar(a[i]) >> kaydir) & 0xFF
            onek[v] -= 1
            b[onek[v]] = a[i]
        a[:] = b


def main():
    a = [42, -5, 17, -1, 0, -2**31, 2**31 - 1, 3]
    taban_siralamasi(a)
    print("sıralandı:", *a)
    print("-5 >> 24 =", -5 >> 24, "; (-5 >> 24) & 0xFF =", (-5 >> 24) & 0xFF)


if __name__ == "__main__":
    main()

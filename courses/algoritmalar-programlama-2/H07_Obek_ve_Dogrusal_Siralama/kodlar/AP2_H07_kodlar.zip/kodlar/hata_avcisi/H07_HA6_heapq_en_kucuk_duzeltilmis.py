"""H07_HA6_heapq_en_kucuk_duzeltilmis.py — AP-2 Hafta 7 · Hata Avcısı 6
(düzeltilmiş): en büyük öbek için anahtarlar −x olarak saklanır (−x
hilesi) ve çıkarılırken işaret geri çevrilir. Yalnızca ilk-k gerekiyorsa
heapq.nlargest(k, a) aynı sonucu verir (kâhin olarak denetlenir).
Çalıştır: python3 H07_HA6_heapq_en_kucuk_duzeltilmis.py
"""
import heapq


def main():
    notlar = [71, 84, 63, 95, 52, 90, 45, 88, 79, 92]
    obek = []
    for x in notlar:
        heapq.heappush(obek, -x)                     # −x hilesi
    print("öbek listesi (−x):", obek)
    print("-obek[0] =", -obek[0], "(kök: en büyük)")
    ilk3 = [-heapq.heappop(obek) for _ in range(3)]
    print("en yüksek 3 not:", ilk3)
    print("heapq.nlargest(3, notlar):", heapq.nlargest(3, notlar))


if __name__ == "__main__":
    main()

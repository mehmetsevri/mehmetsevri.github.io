"""H07_HA4_aralik_disi_anahtar_duzeltilmis.py — AP-2 Hafta 7 · Hata
Avcısı 4 (düzeltilmiş): her anahtar sayaca girmeden önce 0..K aralığında
mı diye denetlenir; Python'un negatif indis kuralına güvenilmez.
Çalıştır: python3 H07_HA4_aralik_disi_anahtar_duzeltilmis.py
"""

K = 100


def sayma_siralamasi(a):
    """Geçerli anahtarların sıralı listesini döndürür"""
    sayac = [0] * (K + 1)
    for i, x in enumerate(a):
        if x < 0 or x > K:             # aralık denetimi
            print(f"  geçersiz not: {x} (konum {i}) — sıralamaya alınmadı")
            continue
        sayac[x] += 1
    sonuc = []
    for v in range(K + 1):
        sonuc.extend([v] * sayac[v])
    return sonuc


def main():
    for no, notlar in ((1, [85, 70, -1, 100, 45, 70, 90]),
                       (2, [85, 70, 100, 45, 105, 70, 90])):
        print(f"{no}) girdi:", *notlar)
        s = sayma_siralamasi(notlar)
        print(f"   çıktı ({len(s)} geçerli not):", *s)


if __name__ == "__main__":
    main()

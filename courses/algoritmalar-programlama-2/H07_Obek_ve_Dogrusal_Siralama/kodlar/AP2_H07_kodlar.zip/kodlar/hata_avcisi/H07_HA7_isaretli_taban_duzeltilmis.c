/* H07_HA7_isaretli_taban_duzeltilmis.c — AP-2 Hafta 7 · Hata Avcısı 7
 * (düzeltilmiş): anahtar = (uint32_t)x ^ 0x80000000 — işaret biti
 * çevrilince INT32_MIN -> 0x00000000, -1 -> 0x7FFFFFFF, 0 -> 0x80000000,
 * INT32_MAX -> 0xFFFFFFFF olur; işaretsiz sıra işaretli sırayla aynıdır.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA7_isaretli_taban_duzeltilmis.c \
 *           -o H07_HA7_isaretli_taban_duzeltilmis
 */
#include <stdint.h>
#include <stdio.h>

static uint32_t anahtar(int x)
{
    return (uint32_t)x ^ 0x80000000u;  /* işaret bitini çevir */
}

static void taban_siralamasi(int *a, int *b, int n)
{
    for (int kaydir = 0; kaydir < 32; kaydir += 8) {
        int onek[256] = {0};
        for (int i = 0; i < n; i++) {
            onek[(anahtar(a[i]) >> kaydir) & 0xFF]++;
        }
        for (int v = 1; v < 256; v++) {
            onek[v] += onek[v - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            b[--onek[(anahtar(a[i]) >> kaydir) & 0xFF]] = a[i];
        }
        for (int i = 0; i < n; i++) {
            a[i] = b[i];
        }
    }
}

int main(void)
{
    int a[] = {42, -5, 17, -1, 0, INT32_MIN, INT32_MAX, 3};
    int b[8];
    taban_siralamasi(a, b, 8);
    printf("sıralandı:");
    for (int i = 0; i < 8; i++) {
        printf(" %d", a[i]);
    }
    printf("\n-5 için anahtar = 0x%08X (en yüksek bayt 0x%02X)\n",
           (unsigned)anahtar(-5), (unsigned)(anahtar(-5) >> 24));
    return 0;
}

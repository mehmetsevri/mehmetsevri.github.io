/* H07_HA7_isaretli_taban.c — AP-2 Hafta 7 · Hata Avcısı 7
 * BU DOSYA KASITLI HATA İÇERİR: işaretli int değerler, işaretsiz 32 bitlik
 * sayılar gibi taban sıralamasına sokuluyor. İkiye tümleyen gösterimde
 * negatif sayıların en yüksek baytı >= 0x80 olduğundan negatifler, tüm
 * pozitiflerden SONRA gelir. (int -> uint32_t dönüşümü tanımlıdır:
 * mod 2^32; hata mantıksaldır.)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -O2 \
 *           H07_HA7_isaretli_taban.c -o H07_HA7_isaretli_taban
 * Düzeltme: H07_HA7_isaretli_taban_duzeltilmis.c
 */
#include <stdint.h>
#include <stdio.h>

static uint32_t anahtar(int x)
{
    return (uint32_t)x;                /* HATA: işaret biti çevrilmeli */
}

static void taban_siralamasi(int *a, int *b, int n)
{
    for (int kaydir = 0; kaydir < 32; kaydir += 8) {
        int onek[256] = {0};
        for (int i = 0; i < n; i++) {
            onek[(anahtar(a[i]) >> kaydir) & 0xFF]++;
        }
        for (int v = 1; v < 256; v++) {
            onek[v] += onek[v - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            b[--onek[(anahtar(a[i]) >> kaydir) & 0xFF]] = a[i];
        }
        for (int i = 0; i < n; i++) {
            a[i] = b[i];
        }
    }
}

int main(void)
{
    int a[] = {42, -5, 17, -1, 0, INT32_MIN, INT32_MAX, 3};
    int b[8];
    taban_siralamasi(a, b, 8);
    printf("sıralandı:");
    for (int i = 0; i < 8; i++) {
        printf(" %d", a[i]);
    }
    printf("\n-5 için anahtar = 0x%08X (en yüksek bayt 0x%02X)\n",
           (unsigned)anahtar(-5), (unsigned)(anahtar(-5) >> 24));
    return 0;
}

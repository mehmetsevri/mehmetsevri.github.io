/* H14_K12_sayi_metin_ikili.c — Hafta 14 · Kavram programı: aynı sayı,
 * iki dosya
 * Amaç   : H03_K02_bayt_sirasi.c'deki 0x12345678 sayısını önce METİN
 *          (fprintf: onluk rakamların karakter kodları), sonra İKİLİ
 *          (fwrite: bellekteki dört bayt, küçük-uçlu sırayla) yazmak.
 *          Dosyaların onaltılı dökümü ciktilar/ altındadır
 *          (od -A x -t x1z; Windows'ta PowerShell Format-Hex).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K12_sayi_metin_ikili.c -o sayi_metin_ikili
 * Not    : fprintf yazdığı karakter sayısını, fwrite yazdığı öğe
 *          sayısını döndürür (burada öğe = 1 bayt). Windows'ta metin
 *          kipinde '\n' diske "\r\n" olarak gider (11 bayt).
 * Örnek  : -> sayi.txt: 10 karakter, sayi.bin: 4 bayt
 */
#include <stdio.h>

int main(void)
{
    int sayi = 0x12345678;                  /* H03_K02 ile aynı sayı */

    FILE *t = fopen("sayi.txt", "w");
    FILE *b = fopen("sayi.bin", "wb");
    if (t == NULL || b == NULL) {
        perror("fopen");
        return 1;
    }
    int nt = fprintf(t, "%d\n", sayi);      /* "305419896\n" */
    size_t nb = fwrite(&sayi, 1, sizeof sayi, b);   /* 78 56 34 12 */
    fclose(t);
    fclose(b);
    printf("sayi = %d (0x%08X)\n", sayi, (unsigned)sayi);
    printf("sayi.txt: %d karakter, sayi.bin: %zu bayt\n", nt, nb);
    return 0;
}

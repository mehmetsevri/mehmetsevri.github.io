/* H14_K02_atama_kopya.c — Hafta 14 · Kavram programı: ilk değer,
 * atama ve fonksiyondan yapı döndürme
 * Amaç   : (1) Üç ilk değer biçimi: sırayla, belirlenmiş (C99, .ad =),
 *          sıfırla ({0}: verilmeyen üyeler 0). (2) Yapı ATAMASI bütün
 *          üyeleri, DİZİ ÜYELER DAHİL, kopyalar: b = a'dan sonra b.ad
 *          ayrı bir dizidir. (Diziler ise birbirine atanamaz:
 *          H14_K03_dizi_atama_hatasi.c.) (3) Fonksiyon bir yapıyı
 *          DEĞER olarak döndürebilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K02_atama_kopya.c -o atama_kopya
 * Örnek  : -> a.ad = CAN, b.ad = XAN
 */
#include <stdio.h>

typedef struct {
    char ad[8];
    int puan;
} Oyuncu;

typedef struct {
    double x;
    double y;
} Nokta;

Nokta orta_nokta(Nokta p, Nokta q)      /* yapı DÖNDÜRÜR */
{
    Nokta m = {(p.x + q.x) / 2, (p.y + q.y) / 2};
    return m;
}

int main(void)
{
    Oyuncu a = {"CAN", 70};                 /* sırayla */
    Oyuncu c = {.puan = 95, .ad = "EMRE"};  /* belirlenmiş ilk değer */
    Oyuncu z = {0};                         /* bütün üyeler sıfır */

    Oyuncu b = a;               /* yapı ataması: ad[] de KOPYALANIR */
    b.ad[0] = 'X';
    b.puan = 10;
    printf("a.ad = %s, b.ad = %s\n", a.ad, b.ad);
    printf("a.puan = %d, b.puan = %d\n", a.puan, b.puan);
    printf("c = {%s, %d}, z = {\"%s\", %d}\n", c.ad, c.puan, z.ad, z.puan);

    Nokta p = {0, 0}, q = {4, 6};
    Nokta m = orta_nokta(p, q);             /* dönen yapı m'ye kopyalanır */
    printf("orta nokta = (%.1f, %.1f)\n", m.x, m.y);
    return 0;
}

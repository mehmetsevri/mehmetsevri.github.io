/* H14_K04_karsilastirma.c — Hafta 14 · Kavram programı: yapılar nasıl
 * karşılaştırılır?
 * Amaç   : C'de yapılar == ile karşılaştırılamaz (derleme hatası,
 *          Hata Avcısı 1); karşılaştırma ALAN ALAN yazılır. memcmp ile
 *          bayt bayt karşılaştırma ise DOLGU baytları yüzünden
 *          güvenilmezdir: alanları aynı iki yapının dolgusu farklı
 *          olabilir. Deneyde dolgular bilerek farklı doldurulur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K04_karsilastirma.c -o karsilastirma
 * Örnek  : -> alan alan: EŞİT, memcmp: FARKLI
 */
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct {
    char sube;          /* 1 bayt + 3 bayt dolgu */
    int no;
} Kayit;

bool kayit_esit(const Kayit *a, const Kayit *b)
{
    return a->sube == b->sube && a->no == b->no;
}

int main(void)
{
    Kayit a, b;
    memset(&a, 0x00, sizeof a);     /* dolgu baytları 00 */
    memset(&b, 0xFF, sizeof b);     /* dolgu baytları FF */
    a.sube = 'A';
    a.no = 1045;
    b.sube = 'A';
    b.no = 1045;

    printf("sizeof(Kayit) = %zu (üyeler %zu bayt)\n", sizeof(Kayit),
           sizeof(char) + sizeof(int));
    printf("alan alan: %s, memcmp: %s\n",
           kayit_esit(&a, &b) ? "EŞİT" : "FARKLI",
           memcmp(&a, &b, sizeof a) == 0 ? "EŞİT" : "FARKLI");
    const unsigned char *pa = (const unsigned char *)&a;
    const unsigned char *pb = (const unsigned char *)&b;
    printf("a: ");
    for (size_t i = 0; i < sizeof a; i++) {
        printf("%02X ", pa[i]);
    }
    printf("\nb: ");
    for (size_t i = 0; i < sizeof b; i++) {
        printf("%02X ", pb[i]);
    }
    printf("\n");
    return 0;
}

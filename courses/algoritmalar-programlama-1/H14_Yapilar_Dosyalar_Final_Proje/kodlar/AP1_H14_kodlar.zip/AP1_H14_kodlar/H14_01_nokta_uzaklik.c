/* H14_01_nokta_uzaklik.c — Hafta 14 · Örnek 1 (★): İlk yapımız
 * Amaç   : Birbirine ait iki değeri (x, y) TEK bir kayıtta toplamak:
 *          struct Nokta. Üyelere nokta (.) operatörüyle erişilir; yapı
 *          fonksiyona DEĞERLE aktarılır (bütün üyeler kopyalanır).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_01_nokta_uzaklik.c -o nokta_uzaklik -lm
 * Örnek  : -> |AB| = 5.00
 */
#include <stdio.h>
#include <math.h>

struct Nokta {                  /* yeni bir TİP: iki double'lık kayıt */
    double x;
    double y;
};

double uzaklik(struct Nokta p, struct Nokta q)
{
    double dx = q.x - p.x;
    double dy = q.y - p.y;
    return sqrt(dx * dx + dy * dy);
}

int main(void)
{
    struct Nokta a = {1.0, 2.0};            /* sırayla: x, y */
    struct Nokta b = {.y = 6.0, .x = 4.0};  /* belirlenmiş ilk değer */

    printf("A(%.1f, %.1f)  B(%.1f, %.1f)\n", a.x, a.y, b.x, b.y);
    printf("|AB| = %.2f\n", uzaklik(a, b));
    printf("sizeof(struct Nokta) = %zu bayt\n", sizeof(struct Nokta));
    return 0;
}

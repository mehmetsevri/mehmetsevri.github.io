/* H14_K01_paralel_struct.c — Hafta 14 · Kavram programı: paralel
 * dizilerden yapı dizisine
 * Amaç   : H10_K10_paralel_diziler.c'deki deneyin yapı dizisiyle
 *          tekrarı. Orada 1046'yı silerken yalnızca no[] kaydırılmış,
 *          vize[] ve final[] unutulmuş, kayıtlar KAYMIŞTI. Yapı
 *          dizisinde bir kayıt TEK eleman olduğundan kaydırma tek
 *          atamadır: bir öğrencinin verileri birbirinden ayrılamaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K01_paralel_struct.c -o paralel_struct
 * Örnek  : -> no 1047  vize 90  final 95
 */
#include <stdio.h>

#define N 4

typedef struct {
    int no;
    int vize;
    int final;
} Kayit;

int main(void)
{
    Kayit sinif[N] = {{1045, 70, 85}, {1046, 45, 48},
                      {1047, 90, 95}, {1048, 55, 60}};
    int n = N;

    /* 1046'yı (indis 1) sil: sonrakiler birer sola kayar (H10_12) */
    for (int i = 1; i < n - 1; i++) {
        sinif[i] = sinif[i + 1];        /* üç alan BİRLİKTE taşınır */
    }
    n--;
    printf("Silmeden sonra (yapı dizisi):\n");
    for (int i = 0; i < n; i++) {
        printf("  no %d  vize %d  final %d\n", sinif[i].no, sinif[i].vize,
               sinif[i].final);
    }
    return 0;
}

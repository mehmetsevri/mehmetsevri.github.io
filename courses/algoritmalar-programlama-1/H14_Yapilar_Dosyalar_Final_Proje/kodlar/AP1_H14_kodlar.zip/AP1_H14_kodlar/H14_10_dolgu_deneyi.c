/* H14_10_dolgu_deneyi.c — Hafta 14 · Örnek 10 (★★★): sizeof(struct)
 * ve dolgu deneyi
 * Amaç   : Aynı dört üye, iki farklı SIRA: sizeof neden farklı? Her
 *          tipin bir HİZALAMA gereksinimi vardır (_Alignof); derleyici
 *          üyeyi bu sayının katı olan bir adrese koymak için araya,
 *          dizide sonraki elemanın da hizalı olması için sona DOLGU
 *          (padding) baytları ekler. offsetof üyenin baştan uzaklığıdır.
 *          Bayt haritası: her harf bir üyenin baytı, '.' dolgu.
 * Not    : Değerler x86-64 Linux, GCC (LP64) içindir; hizalama kuralları
 *          ABI'ye bağlıdır, başka platformlarda değişebilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_10_dolgu_deneyi.c -o dolgu_deneyi
 * Örnek  : -> sizeof(struct Kotu) = 24, sizeof(struct Iyi) = 16
 */
#include <stdio.h>
#include <stddef.h>         /* offsetof, size_t */
#include <string.h>         /* memset */

struct Kotu {               /* küçük, büyük, küçük, orta */
    char harf;
    double ort;
    char sube;
    int no;
};

struct Iyi {                /* büyükten küçüğe */
    double ort;
    int no;
    char harf;
    char sube;
};

/* harita[bas .. bas+boyut-1] baytlarını harf ile işaretler */
static void isaretle(char *harita, size_t bas, size_t boyut, char harf)
{
    memset(harita + bas, harf, boyut);
}

int main(void)
{
    printf("_Alignof: char %zu, int %zu, double %zu\n",
           _Alignof(char), _Alignof(int), _Alignof(double));

    char h[sizeof(struct Kotu) + 1];
    memset(h, '.', sizeof h - 1);
    h[sizeof h - 1] = '\0';
    isaretle(h, offsetof(struct Kotu, harf), sizeof(char), 'H');
    isaretle(h, offsetof(struct Kotu, ort), sizeof(double), 'D');
    isaretle(h, offsetof(struct Kotu, sube), sizeof(char), 'S');
    isaretle(h, offsetof(struct Kotu, no), sizeof(int), 'N');
    printf("Kotu: harf %zu, ort %zu, sube %zu, no %zu  |%s|\n",
           offsetof(struct Kotu, harf), offsetof(struct Kotu, ort),
           offsetof(struct Kotu, sube), offsetof(struct Kotu, no), h);

    char g[sizeof(struct Iyi) + 1];
    memset(g, '.', sizeof g - 1);
    g[sizeof g - 1] = '\0';
    isaretle(g, offsetof(struct Iyi, ort), sizeof(double), 'D');
    isaretle(g, offsetof(struct Iyi, no), sizeof(int), 'N');
    isaretle(g, offsetof(struct Iyi, harf), sizeof(char), 'H');
    isaretle(g, offsetof(struct Iyi, sube), sizeof(char), 'S');
    printf("Iyi : ort %zu, no %zu, harf %zu, sube %zu  |%s|\n",
           offsetof(struct Iyi, ort), offsetof(struct Iyi, no),
           offsetof(struct Iyi, harf), offsetof(struct Iyi, sube), g);

    size_t uyeler = 2 * sizeof(char) + sizeof(int) + sizeof(double);
    printf("Üyelerin toplamı = %zu bayt\n", uyeler);
    printf("sizeof(struct Kotu) = %zu, sizeof(struct Iyi) = %zu\n",
           sizeof(struct Kotu), sizeof(struct Iyi));
    printf("Dolgu: Kotu %zu bayt, Iyi %zu bayt\n",
           sizeof(struct Kotu) - uyeler, sizeof(struct Iyi) - uyeler);
    printf("1000 kayıtlık dizi: %zu ve %zu bayt\n",
           sizeof(struct Kotu[1000]), sizeof(struct Iyi[1000]));
    return 0;
}

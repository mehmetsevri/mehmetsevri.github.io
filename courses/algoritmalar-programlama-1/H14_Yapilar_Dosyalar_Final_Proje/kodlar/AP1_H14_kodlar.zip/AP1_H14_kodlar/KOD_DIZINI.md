# Hafta 14 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` ve `.h` dosyası (112 `.c`, 4 `.h`); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (GCC 13.3, x86-64 Linux, glibc; Mini-OBS için `proje/Makefile`). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (derleme komutu, hazırlık komutları, `$ ./program` satırları, girdiler ve çıktılar). Kasıtlı hata içermeyen bütün örnek ve kavram programları ayrıca `-fsanitize=address,undefined` ile temiz çalıştı. `veri/` Örnek 8 ve 11’in girdi dosyalarını içerir.

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Ders notu ve sunumdaki kod kesitleri dosyanın **ardışık satırlarıdır** (başlıkta dosya adı ve satır aralığı). `proje/main.c`’nin `obs.h`, `metin.h` ve `dosya.h` ile birleşmiş hâli (başlıklar elle yapıştırılmış tek çeviri birimi) `H14_K13_obs_ceviri_birimi.c`’dedir; envanter aracı yalnızca `.c` dosyalarını taradığı için materyaldeki `obs.h` kesitleri bu dosyayla eşleşir; `proje/` kesitleri envanterde doğrudan kaynak dosyalarla eşleşir.

Envanter denetimi (ortak araç `kod_envanteri.js`, hafta 14): ders notu, sunum ve web’deki her kod parçası bu klasördeki bir dosyada bulundu → **EKSİK 0**.

**Final hazırlık soru bankası (`quiz/H14_F*`).** `quiz/H14_F*.c` dosyaları bölüm `h14-final-hazirlik`'teki final hazırlık soru bankasının (simülasyon `h14-final`, 42 soru, H1–H14) programlarıdır: kod içeren her soru için çalıştırılabilir tam program `H14_FNN_kisa_ad.c` (NN = soru no); kod tamamlama sorularında soruda gösterilen `_bosluklu.c`, Parsons sorularında `_karisik.c` (ikisi de bu hâliyle derlenmez), bazı hata bulma sorularında `_duzeltilmis.c`; S3–S4 sözde kodlarının C karşılıkları, S28'in doğrulama programı ve S22'nin çok dosyalı deneyi (`H14_F22_coklu_tanim.h` + iki `.c`). Kasıtlı hatalılar başlık yorumunda “BU DOSYA KASITLI HATA İÇERİR” diye işaretlidir; gerçek çıktılar `quiz/ciktilar/H14_F*.txt`.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H14_01_nokta_uzaklik.c` | Örnek 1 (★) | Örnek 1 (★): İlk yapımız | sıfır uyarı | 3.1 | 10 | h14-yapilar |
| `H14_02_ogrenci_typedef.c` | Örnek 2 (★) | Örnek 2 (★): typedef ve oku/yazdır fonksiyonları | sıfır uyarı | 3.2, 4.1 | — | h14-yapilar |
| `H14_03_enum_menu.c` | Örnek 3 (★) | Örnek 3 (★): enum ile okunabilir sabitler | sıfır uyarı | 3.4, 4.1 | 21 | h14-enum-union |
| `H14_04_metin_dosyasi.c` | Örnek 4 (★) | Örnek 4 (★): Metin dosyasına yazma ve okuma | sıfır uyarı | 4.1 | 31 | h14-dosya |
| `H14_05_ic_ice_tarih.c` | Örnek 5 (★★) | Örnek 5 (★★): İç içe yapı | sıfır uyarı | 4.1 | 14 (şekil) | h14-yapilar |
| `H14_06_en_yuksek_ortalama.c` | Örnek 6 (★★) | Örnek 6 (★★): Yapı dizisi | sıfır uyarı | 4.1 | 15 | h14-yapilar |
| `H14_07_isaretci_guncelleme.c` | Örnek 7 (★★) | Örnek 7 (★★): Yapı işaretçisi ve -> ile güncelleme | sıfır uyarı | 3.3 (şekil), 4.2 | 17 (şekil), 18, 19, 20 (şekil) | h14-isaretci |
| `H14_08_mini_wc.c` | Örnek 8 (★★) | Örnek 8 (★★): Dosyadaki satır, kelime ve karakter sayısı (mini wc) | sıfır uyarı | 4.3 | — | h14-metin |
| `H14_09_dosya_hatalari.c` | Örnek 9 (★★) | Örnek 9 (★★): Dosya hata yönetimi | sıfır uyarı | 4.3 | 30 | h14-dosya |
| `H14_10_dolgu_deneyi.c` | Örnek 10 (★★★) | Örnek 10 (★★★): sizeof(struct) ve dolgu deneyi | sıfır uyarı | 3.5 (şekil), 4.3 | 23 (şekil), 24 | h14-dolgu |
| `H14_11_csv_yukleme.c` | Örnek 11 (★★★) | Örnek 11 (★★★): CSV'den öğrenci listesinin yüklenmesi | sıfır uyarı | 4.4 | 37 | h14-csv |
| `H14_12_ikili_dosya.c` | Örnek 12 (★★★) | Örnek 12 (★★★): İkili dosyaya yapı dizisi yazma/okuma ve onaltılı inceleme | sıfır uyarı | 4.5 | 39, 40 (şekil) | h14-ikili |
| `H14_K01_paralel_struct.c` | Kavram programı | Kavram programı: paralel dizilerden yapı dizisine | sıfır uyarı | 3.1 (şekil, metin) | 9 (şekil) | h14-yapilar |
| `H14_K02_atama_kopya.c` | Kavram programı | Kavram programı: ilk değer, atama ve fonksiyondan yapı döndürme | sıfır uyarı | 3.2 (metin) | 11 | h14-yapilar |
| `H14_K03_dizi_atama_hatasi.c` | Kavram programı | Kavram programı: diziler atanamaz, yapılar atanır | kasıtlı derleme hatası | 3.2 (metin) | — | h14-yapilar |
| `H14_K04_karsilastirma.c` | Kavram programı | Kavram programı: yapılar nasıl karşılaştırılır? | sıfır uyarı | 3.2 (metin) | — | h14-yapilar |
| `H14_K05_kopya_maliyeti.c` | Kavram programı | Kavram programı: değerle aktarımın maliyeti | sıfır uyarı | 3.3 (metin), 4.2 (şekil) | 20 (şekil) | — |
| `H14_K06_union.c` | Kavram programı | Kavram programı (Merak Kutusu): union | sıfır uyarı | 3.4 (metin) | 22 | h14-enum-union |
| `H14_K07_dosya_kipleri.c` | Kavram programı | Kavram programı: fopen kipleri | sıfır uyarı | 3.6 (metin) | 28 (şekil) | h14-dosya |
| `H14_K08_akislar.c` | Kavram programı | Kavram programı: üç standart akış | sıfır uyarı | 3.6 (metin) | 27 (şekil) | h14-dosya |
| `H14_K09_tampon_gozlem.c` | Kavram programı | Kavram programı: tamponu gözlemek | sıfır uyarı | 3.7 (metin, şekil) | 32 (şekil) | h14-tampon |
| `H14_K10_fscanf_donus.c` | Kavram programı | Kavram programı: fscanf'in dönüş değeri | sıfır uyarı | 3.8 (metin) | — | h14-metin |
| `H14_K11_strtok_bos_alan.c` | Kavram programı | Kavram programı: strtok boş alanı yutar | sıfır uyarı | 3.9 (metin) | — | h14-csv |
| `H14_K12_sayi_metin_ikili.c` | Kavram programı | Kavram programı: aynı sayı, iki dosya | sıfır uyarı | 3.10 (metin) | — | h14-ikili |
| `H14_K13_obs_ceviri_birimi.c` | Kavram programı | Kavram programı: Mini-OBS v1.0 çeviri birimi | sıfır uyarı (-Iproje, proje/metin.c obs.c dosya.c ile) | — | — | — |
| `H14_K14_y2k_2038.c` | Kavram programı | Kavram programı: iki haneli yıl ve | sıfır uyarı | 1 (metin), 10 (metin) | — | h14-buyuk-soru |
| `H14_K15_dugum.c` | Kavram programı | Kavram programı (AP-2 Köprüsü): kendini gösteren yapı | sıfır uyarı | 10 | 53 | h14-ap2 |
| `H14_K16_obs_yerlesim.c` | Kavram programı | Kavram programı: Mini-OBS v1.0 veri modelinin bellek yerleşimi | sıfır uyarı (-Iproje) | 3.5 (metin) | 45 (şekil) | — |
| `alistirmalar/H14_A01_kopya_tahmin.c` | Alıştırma 14.1 | Alıştırma 14.1 (★, Çıktı tahmini) | sıfır uyarı | 8.1 (alıştırma) | — | h14-alistirmalar |
| `alistirmalar/H14_A02_dolgu_tahmin.c` | Alıştırma 14.2 | Alıştırma 14.2 (★★, Çıktı tahmini) | sıfır uyarı | 8.1 (alıştırma) | — | h14-alistirmalar |
| `alistirmalar/H14_A03_hata_bul_not_ekle.c` | Alıştırma 14.3 | Alıştırma 14.3 (★★, Hata bul) | sıfır uyarı; kasıtlı bellek/mantık hatası | 8.1 (alıştırma) | — | h14-alistirmalar |
| `alistirmalar/H14_A04_hata_bul_dosya.c` | Alıştırma 14.4 | Alıştırma 14.4 (★★, Hata bul) | sıfır uyarı; kasıtlı bellek/mantık hatası | 8.1 (alıştırma) | — | h14-alistirmalar |
| `alistirmalar/H14_A05_parsons_numarala.c` | Alıştırma 14.5 | Alıştırma 14.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8.1 (alıştırma) | — | h14-alistirmalar |
| `alistirmalar/H14_A06_kod_tamamla_ikili.c` | Alıştırma 14.6 | Alıştırma 14.6 (★★, Kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8.1 (alıştırma) | — | h14-alistirmalar |
| `hata_avcisi/H14_HA1_yapi_esitlik.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1: yapıları == ile karşılaştırmak | kasıtlı derleme hatası | — | 13 | h14-hata-avcisi |
| `hata_avcisi/H14_HA1_yapi_esitlik_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 (düzeltilmiş): alan alan karşılaştırma | sıfır uyarı | — | — | h14-hata-avcisi |
| `hata_avcisi/H14_HA2_nokta_ok.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2: . ile -> karışıklığı | kasıtlı derleme hatası | — | — | h14-hata-avcisi |
| `hata_avcisi/H14_HA2_nokta_ok_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 (düzeltilmiş): yapıyla nokta, işaretçiyle ok | sıfır uyarı | — | — | h14-hata-avcisi |
| `hata_avcisi/H14_HA3_fopen_denetimsiz.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3: fopen'ın dönüş değerini denetlememek | sıfır uyarı; kasıtlı çökme (SIGSEGV, 139) | — | — | h14-hata-avcisi |
| `hata_avcisi/H14_HA3_fopen_denetimsiz_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 (düzeltilmiş): her fopen sonucu denetlenir | sıfır uyarı | — | — | h14-hata-avcisi |
| `hata_avcisi/H14_HA4_fclose_unutma.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4: fclose'u unutmak ve tamponda kalan veri | sıfır uyarı; kasıtlı abort (134) | — | 33 | h14-tampon |
| `hata_avcisi/H14_HA4_fclose_unutma_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4 (düzeltilmiş): işi biten akış hemen kapatılır | sıfır uyarı; kasıtlı abort (134) | — | — | h14-tampon |
| `hata_avcisi/H14_HA5_feof_dongusu.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5: while (!feof(f)) | sıfır uyarı; kasıtlı bellek/mantık hatası | — | 35 (şekil) | h14-hata-avcisi |
| `hata_avcisi/H14_HA5_feof_dongusu_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 (düzeltilmiş): okuma fonksiyonunun DÖNÜŞÜ döngü koşuludur | sıfır uyarı | — | 35 (şekil) | h14-hata-avcisi |
| `hata_avcisi/H14_HA6_w_kipi.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6: "w" kipi mevcut dosyayı siler | sıfır uyarı; kasıtlı bellek/mantık hatası | — | — | h14-hata-avcisi |
| `hata_avcisi/H14_HA6_w_kipi_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 (düzeltilmiş): sona eklemek için "a" | sıfır uyarı | — | — | h14-hata-avcisi |
| `proje/dosya.c` | Mini-OBS v1.0 (Örnek 13) · modül | Mini-OBS v1.0 (AP-1 Hafta 14): kalıcı saklama (CSV ve ikili) | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 3.9 (şekil), 7 (şekil), 7.1 (şekil) | 36 (şekil), 44 (şekil), 46 (şekil), 47 (şekil) | h14-miniobs |
| `proje/dosya.h` | Mini-OBS v1.0 (Örnek 13) · başlık | Mini-OBS v1.0 (AP-1 Hafta 14): kalıcı saklama | başlık (içeren .c ile derlenir) | — | — | h14-miniobs |
| `proje/main.c` | Mini-OBS v1.0 (Örnek 13) · modül | Mini-OBS v1.0 (AP-1 Hafta 14): menü güdümlü, verisini dosyada | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 7 (şekil) | 44 (şekil) | — |
| `proje/metin.c` | Mini-OBS v1.0 (Örnek 13) · modül | Mini-OBS v1.0 (AP-1 Hafta 14): güvenli girdi ve metin işleme | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 7 (şekil) | 44 (şekil) | — |
| `proje/metin.h` | Mini-OBS v1.0 (Örnek 13) · başlık | Mini-OBS v1.0 (AP-1 Hafta 14): güvenli girdi ve metin işleme | başlık (içeren .c ile derlenir) | — | — | — |
| `proje/obs.c` | Mini-OBS v1.0 (Örnek 13) · modül | Mini-OBS v1.0 (AP-1 Hafta 14): kayıt tipleri üzerinde iş kuralları | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 7 (şekil) | 44 (şekil) | h14-miniobs |
| `proje/obs.h` | Mini-OBS v1.0 (Örnek 13) · başlık | Mini-OBS v1.0 (AP-1 Hafta 14): kayıt tipleri ve iş kuralları | başlık (içeren .c ile derlenir) | 7 | 45 (şekil) | h14-miniobs |
| `proje/test_obs.c` | Mini-OBS v1.0 (Örnek 13) · birim testleri | Mini-OBS v1.0 (AP-1 Hafta 14): birim testleri | sıfır uyarı (Makefile; ASan + Valgrind temiz) | — | — | h14-miniobs |
| `quiz/H14_F03_sozde_izleme.c` | Final hazırlık S3 (H2) · quiz | Sözde kodu izleme tablosuyla yürütme (sözde kodun C karşılığı) | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F04_esitlik_testi.c` | Final hazırlık S4 (H2) · quiz | Sınır durumu: eşitlik (sözde kodun C karşılığı) | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F05_printf_alan.c` | Final hazırlık S5 (H3) · quiz | printf alan genişliği ve hassasiyet | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F06_isaretsiz_sarma.c` | Final hazırlık S6 (H3) · quiz | İşaretsiz tamsayıda modüler sarma | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F07_bit_islemleri.c` | Final hazırlık S7 (H4) · quiz | Maske, kaydırma ve XOR | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F08_oncelik_birlesme.c` | Final hazırlık S8 (H4) · quiz | Operatör önceliği ve birleşme yönü | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F09_ucgen_turu.c` | Final hazırlık S9 (H5) · quiz | else-if merdiveninde ilk doğru dal | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F10_bos_if.c` | Final hazırlık S10 (H5) · quiz · kasıtlı hata | if sonrası noktalı virgül (boş deyim) | derlenir; kasıtlı uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F11_basamak_toplami.c` | Final hazırlık S11 (H6) · quiz | Basamak işleme deseninde döngü koşulu | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F11_basamak_toplami_bosluklu.c` | Final hazırlık S11 (H6) · quiz · kod tamamlama | Soruda gösterilen boşluklu sürüm | tamamlanacak (bu hâliyle derlenmez) | — | — | h14-final-hazirlik |
| `quiz/H14_F12_collatz_izleme.c` | Final hazırlık S12 (H6) · quiz | Döngüyü izleme: adım sayısı ve en büyük değer | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F13_ic_ice_tur.c` | Final hazırlık S13 (H7) · quiz | İç içe döngüde yineleme sayısı | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F14_asal_say.c` | Final hazırlık S14 (H7) · quiz | Asallık testinde √n sınırı | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F14_asal_say_bosluklu.c` | Final hazırlık S14 (H7) · quiz · kod tamamlama | Soruda gösterilen boşluklu sürüm | tamamlanacak (bu hâliyle derlenmez) | — | — | h14-final-hazirlik |
| `quiz/H14_F15_degerle_aktarim.c` | Final hazırlık S15 (H8) · quiz | Değerle aktarım ve fonksiyon bileşimi | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F16_eksik_return.c` | Final hazırlık S16 (H8) · quiz · kasıtlı hata | Değer döndüren fonksiyonda eksik return | derlenir; kasıtlı uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F17_harf_notu_izleme.c` | Final hazırlık S17 (H8) · quiz | Mini-OBS hesap fonksiyonlarını izleme | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F18_assert_testi.c` | Final hazırlık S18 (H8) · quiz · kasıtlı hata | assert ile birim testi | sıfır uyarı; kasıtlı bellek/mantık hatası | — | — | h14-final-hazirlik |
| `quiz/H14_F19_static_omur.c` | Final hazırlık S19 (H9) · quiz | static ve otomatik ömür | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F20_ozyineleme_izleme.c` | Final hazırlık S20 (H9) · quiz | Özyinelemeli çağrı zinciri | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F21_makro_yan_etki.c` | Final hazırlık S21 (H9) · quiz | Makroya yan etkili argüman | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F22_coklu_tanim_main.c` | Final hazırlık S22 (H9) · quiz · kasıtlı hata | Çok dosyalı deney: main.c (başlıkta tanım) | kasıtlı bağlayıcı hatası (multiple definition) | — | — | h14-final-hazirlik |
| `quiz/H14_F22_coklu_tanim_sayac.c` | Final hazırlık S22 (H9) · quiz · kasıtlı hata | Çok dosyalı deney: sayac.c (başlıkta tanım) | kasıtlı bağlayıcı hatası (multiple definition) | — | — | h14-final-hazirlik |
| `quiz/H14_F22_coklu_tanim.h` | Final hazırlık S22 (H9) · quiz · başlık | Çok dosyalı deney: sayac.h (başlıkta değişken TANIMI) | başlık (içeren .c ile derlenir); kasıtlı tanım | — | — | h14-final-hazirlik |
| `quiz/H14_F23_en_buyuk_takas.c` | Final hazırlık S23 (H10) · quiz | En büyüğün indisi ve takas | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F24_dizi_parametresi.c` | Final hazırlık S24 (H10) · quiz | Diziyi fonksiyona aktarma | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F25_sinir_asimi.c` | Final hazırlık S25 (H10) · quiz · kasıtlı hata | Dizi sınırı aşımı (i <= N) | sıfır uyarı; kasıtlı bellek/mantık hatası | — | — | h14-final-hazirlik |
| `quiz/H14_F26_araya_ekle.c` | Final hazırlık S26 (H10) · quiz | Diziye araya ekleme (kaydırma) | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F26_araya_ekle_karisik.c` | Final hazırlık S26 (H10) · quiz · Parsons | Soruda gösterilen karışık parçalar | tamamlanacak (bu hâliyle derlenmez) | — | — | h14-final-hazirlik |
| `quiz/H14_F27_kosegenler.c` | Final hazırlık S27 (H11) · quiz | Ana ve yan köşegen toplamı | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F28_satir_oncelikli.c` | Final hazırlık S28 (H11) · quiz | Satır öncelikli yerleşimde adres hesabı (doğrulama programı) | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F29_sifirlanmayan_sonuc.c` | Final hazırlık S29 (H11) · quiz · kasıtlı hata | Matris çarpımında sıfırlanmayan sonuç | sıfır uyarı; kasıtlı bellek/mantık hatası | — | — | h14-final-hazirlik |
| `quiz/H14_F29_sifirlanmayan_sonuc_duzeltilmis.c` | Final hazırlık S29 (H11) · quiz · düzeltilmiş | Matris çarpımında sıfırlanmayan sonuç (düzeltilmiş sürüm) | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F30_komsu_mayin.c` | Final hazırlık S30 (H11) · quiz | Izgarada sınır denetimi | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F30_komsu_mayin_bosluklu.c` | Final hazırlık S30 (H11) · quiz · kod tamamlama | Soruda gösterilen boşluklu sürüm | tamamlanacak (bu hâliyle derlenmez) | — | — | h14-final-hazirlik |
| `quiz/H14_F31_dondur_isaretci.c` | Final hazırlık S31 (H12) · quiz | İşaretçi parametrelerle kutu–ok izleme | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F32_isaretci_adim.c` | Final hazırlık S32 (H12) · quiz | İşaretçi aritmetiğiyle dolaşma | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F33_yerel_adres.c` | Final hazırlık S33 (H12) · quiz · kasıtlı hata | Yerel değişkenin adresini döndürmek | derlenir; kasıtlı uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F34_realloc_buyutme.c` | Final hazırlık S34 (H12) · quiz | realloc ile güvenli büyütme | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F34_realloc_buyutme_karisik.c` | Final hazırlık S34 (H12) · quiz · Parsons | Soruda gösterilen karışık parçalar | tamamlanacak (bu hâliyle derlenmez) | — | — | h14-final-hazirlik |
| `quiz/H14_F35_strlen_sizeof.c` | Final hazırlık S35 (H13) · quiz | strlen, sizeof ve UTF-8 | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F36_fgets_satir_sonu.c` | Final hazırlık S36 (H13) · quiz | fgets ve sondaki '\n' | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F37_sezar.c` | Final hazırlık S37 (H13) · quiz | Sezar şifreleme | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F38_strcpy_tasmasi.c` | Final hazırlık S38 (H13) · quiz · kasıtlı hata | strcpy ile tampon taşması | derlenir; kasıtlı uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F39_yapi_aktarimi.c` | Final hazırlık S39 (H14) · quiz | Yapı kopyalama, değerle ve işaretçiyle aktarım | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F40_yapi_dolgu.c` | Final hazırlık S40 (H14) · quiz | Yapıda hizalama ve dolgu | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F41_feof_dongusu.c` | Final hazırlık S41 (H14) · quiz · kasıtlı hata | while (!feof(f)) karşıt örüntüsü | sıfır uyarı; kasıtlı bellek/mantık hatası | — | — | h14-final-hazirlik |
| `quiz/H14_F41_feof_dongusu_duzeltilmis.c` | Final hazırlık S41 (H14) · quiz · düzeltilmiş | while (!feof(f)) karşıt örüntüsü (düzeltilmiş sürüm) | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F42_guvenli_kaydet.c` | Final hazırlık S42 (H14) · quiz | Mini-OBS güvenli kaydetme (geçici dosya + rename) | sıfır uyarı | — | — | h14-final-hazirlik |
| `quiz/H14_F42_guvenli_kaydet_karisik.c` | Final hazırlık S42 (H14) · quiz · Parsons | Soruda gösterilen karışık parçalar | tamamlanacak (bu hâliyle derlenmez) | — | — | h14-final-hazirlik |
| `quiz/H14_Q01_sonlandirici.c` | Geri çağırma S1 · quiz | Quiz 1 (geri çağırma, H13): '\0' ve "boyut + 1" Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \ H14_Q01_sonlandirici.c -o q01 | sıfır uyarı | 2 (metin) | 3 | h14-gecen-hafta |
| `quiz/H14_Q02_fgets_satir_sonu.c` | Geri çağırma S2 · quiz | Quiz 2 (geri çağırma, H13): fgets'in bıraktığı '\n' (girdi: Ali ve Enter) Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \ H14_Q02_fgets_satir_sonu.c -o q02 | sıfır uyarı | 2 (metin) | 4 | h14-gecen-hafta |
| `quiz/H14_Q03_strcmp.c` | Geri çağırma S3 · quiz | Quiz 3 (geri çağırma, H13): == ile strcmp Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \ H14_Q03_strcmp.c -o q03 | sıfır uyarı | 2 (metin) | 4 | h14-gecen-hafta |
| `quiz/H14_Q04_yapi_kopyasi.c` | Kendini sına · quiz | Quiz 4: yapı ataması kopyalar | sıfır uyarı | — | 12 | h14-quiz |
| `quiz/H14_Q05_deger_isaretci.c` | Kendini sına · quiz | Quiz 5: değerle ve işaretçiyle aktarım Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \ H14_Q05_deger_isaretci.c -o q05 | sıfır uyarı | — | — | h14-quiz |
| `quiz/H14_Q06_dolgu.c` | Kendini sına · quiz | Quiz 6: sizeof ve dolgu (x86-64 GCC) | sıfır uyarı | — | 25 | h14-quiz |
| `quiz/H14_Q07_enum.c` | Kendini sına · quiz | Quiz 7: enum sabitlerinin değerleri | sıfır uyarı | — | — | h14-quiz |
| `quiz/H14_Q08_kipler.c` | Kendini sına · quiz | Quiz 8: "w" ve "a" kipleri | sıfır uyarı | — | 29 | h14-quiz |
| `quiz/H14_Q09_feof_sayac.c` | Kendini sına · quiz | Quiz 9: while (!feof(f)) kaç tur döner? (dosya: 'A', 'B', '\n' — 3 bayt) Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \ H14_Q09_feof_sayac.c -o q09 | sıfır uyarı | — | 34 | h14-quiz |
| `quiz/H14_Q10_fscanf.c` | Kendini sına · quiz | Quiz 10: fscanf'in dönüş değeri | sıfır uyarı | — | — | h14-quiz |
| `quiz/H14_Q11_ikili_boyut.c` | Kendini sına · quiz | Quiz 11: ikili dosyanın boyutu | sıfır uyarı | — | 41 | h14-quiz |
| `quiz/H14_Q12_ok_operatoru.c` | Kendini sına · quiz | Quiz 12: p->x ve (*p).x | sıfır uyarı | — | — | h14-quiz |

**Diğer dosyalar**

- `proje/Makefile` — Mini-OBS v1.0 (`make`, `make test`, `make ornek`, `make asan`, `make valgrind`, `make clean`); `proje/` klasörü `91_Proje_MiniOBS/v1.0/`’ın kodlarının kopyasıdır (asıl yer orası; belge `mini_obs_v1_0.md` ve gerçek oturumlar `mini_obs_v1_0_ciktilar.txt` orada).
- `proje/testler/` — T1–T6b oturum girdileri ve `bozuk.csv`; `proje/ornek_veri/ogrenciler.csv` — sekiz öğrencilik örnek veri.
- `AP1_H14_kodlar.zip` — bu klasörün (`.c`, `.h`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H14_kodlar/` klasörü oluşur.

Materyalde doğrudan geçmeyen (envanter ya da arşiv amaçlı) dosyalar: `H14_K13_obs_ceviri_birimi.c`, `proje/metin.h`.

/* H14_07_isaretci_guncelleme.c — Hafta 14 · Örnek 7 (★★): Yapı
 * işaretçisi ve -> ile güncelleme
 * Amaç   : Kaydı DEĞİŞTİREN fonksiyon yapının ADRESİNİ alır (H12'nin
 *          takas'ı gibi); o->vize, (*o).vize demektir. Yalnızca OKUYAN
 *          fonksiyon const işaretçi alır: kopyalama yok, değiştirme yok.
 *          Değerle aktarılan yapı bir KOPYADIR: değişiklik kaybolur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_07_isaretci_guncelleme.c -o isaretci_guncelleme
 * Örnek  : -> Aktarılan: değerle 64 bayt, işaretçiyle 8 bayt
 */
#include <stdio.h>

typedef struct {
    long long no;
    char ad[32];
    double vize;
    double final;
    double ort;                     /* vize ve finalden TÜRETİLİR */
} Ogrenci;

/* DEĞERLE: o bir kopya; değişiklik çağırana yansımaz */
void guncelle_kopya(Ogrenci o, double vize, double final)
{
    o.vize = vize;
    o.final = final;
    o.ort = 0.4 * vize + 0.6 * final;
    printf("  (kopyada ort = %.2f)\n", o.ort);
}

/* İŞARETÇİYLE: o, kaydın KENDİSİNİ gösterir */
void guncelle(Ogrenci *o, double vize, double final)
{
    o->vize = vize;                 /* (*o).vize = vize; ile aynı */
    o->final = final;
    o->ort = 0.4 * vize + 0.6 * final;
}

/* const işaretçi: okur ama değiştiremez */
void yazdir(const Ogrenci *o)
{
    printf("%lld %-5s vize %5.1f final %5.1f ort %5.2f\n",
           o->no, o->ad, o->vize, o->final, o->ort);
}

int main(void)
{
    Ogrenci a = {2301010045, "AYSE", 70, 85, 79.0};
    yazdir(&a);
    guncelle_kopya(a, 100, 100);
    yazdir(&a);                             /* değişmedi */
    guncelle(&a, 80, 90);
    yazdir(&a);                             /* değişti */

    Ogrenci *p = &a;
    printf("p->ort = %.2f, (*p).ort = %.2f\n", p->ort, (*p).ort);
    printf("Aktarılan: değerle %zu bayt, işaretçiyle %zu bayt\n",
           sizeof a, sizeof p);
    return 0;
}

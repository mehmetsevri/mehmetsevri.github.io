/* H14_03_enum_menu.c — Hafta 14 · Örnek 3 (★): enum ile okunabilir
 * sabitler
 * Amaç   : Menü seçeneklerine ve harf notlarına AD vermek. enum
 *          sabitleri int'tir: MENU_HARF = 1'den başlayıp birer artar;
 *          HarfNotu ise 0'dan (AA = 0 ... FF = 8) başlar ve bir dizide
 *          indis olarak kullanılabilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_03_enum_menu.c -o enum_menu
 * Örnek  : -> 78 -> BB (enum değeri 2)
 */
#include <stdio.h>

typedef enum {
    MENU_HARF = 1,          /* 1: ortalamadan harf notu */
    MENU_TABLO,             /* 2: harf tablosu          */
    MENU_CIKIS              /* 3                        */
} MenuSecimi;

typedef enum { AA, BA, BB, CB, CC, DC, DD, FD, FF } HarfNotu;

static const char *const HARF_ADI[] = {
    "AA", "BA", "BB", "CB", "CC", "DC", "DD", "FD", "FF"
};
static const int ALT_SINIR[] = {90, 81, 73, 66, 60, 50, 40, 30, 0};

HarfNotu harf_bul(int ortalama)
{
    for (HarfNotu h = AA; h < FF; h++) {    /* enum da bir tamsayıdır */
        if (ortalama >= ALT_SINIR[h]) {
            return h;
        }
    }
    return FF;
}

int main(void)
{
    int secim;
    do {
        printf("1) Harf notu  2) Tablo  3) Çıkış\nSeçim: ");
        if (scanf("%d", &secim) != 1) {
            printf("\nGirdi sona erdi ya da sayı değil.\n");
            return 1;
        }
        switch ((MenuSecimi)secim) {
        case MENU_HARF: {
            int ort;
            printf("Ortalama: ");
            if (scanf("%d", &ort) == 1) {
                HarfNotu h = harf_bul(ort);
                printf("%d -> %s (enum değeri %d)\n", ort, HARF_ADI[h], h);
            }
            break;
        }
        case MENU_TABLO:
            for (HarfNotu h = AA; h <= FF; h++) {
                printf("%s=%d%s", HARF_ADI[h], h, h < FF ? " " : "\n");
            }
            break;
        case MENU_CIKIS:
            printf("Hoşça kalın.\n");
            break;
        default:
            printf("Geçersiz seçim: %d\n", secim);
        }
    } while (secim != MENU_CIKIS);
    return 0;
}

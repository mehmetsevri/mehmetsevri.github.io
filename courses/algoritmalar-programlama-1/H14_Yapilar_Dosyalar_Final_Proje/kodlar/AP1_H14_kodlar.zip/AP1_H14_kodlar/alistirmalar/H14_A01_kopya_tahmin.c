/* H14_A01_kopya_tahmin.c — Hafta 14 · Alıştırma 14.1 (★, Çıktı tahmini)
 * Görev  : Programı çalıştırmadan çıktısını tahmin edin. Her satırdan
 *          sonra a ve b'nin üyelerini bir tabloya yazın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_A01_kopya_tahmin.c -o a01
 */
#include <stdio.h>

typedef struct {
    char ad[8];
    int puan;
} Oyuncu;

void bonus(Oyuncu o)
{
    o.puan += 10;
}

void bonus_p(Oyuncu *o)
{
    o->puan += 10;
}

int main(void)
{
    Oyuncu a = {"ADA", 50};
    Oyuncu b = a;
    bonus(a);
    bonus_p(&b);
    b.ad[0] = 'O';
    Oyuncu *p = &a;
    p->puan *= 2;
    printf("%s %d / %s %d\n", a.ad, a.puan, b.ad, b.puan);
    return 0;
}

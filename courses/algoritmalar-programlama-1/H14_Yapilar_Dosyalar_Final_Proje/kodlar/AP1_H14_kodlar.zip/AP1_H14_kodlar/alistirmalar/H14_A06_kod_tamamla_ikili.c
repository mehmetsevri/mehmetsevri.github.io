/* H14_A06_kod_tamamla_ikili.c — Hafta 14 · Alıştırma 14.6 (★★, Kod tamamla)
 * Görev  : Beş boşluğu (____) doldurun: program iki Nokta'yı ikili
 *          dosyaya yazıp geri okumalı ve "2 kayıt: (1, 2) (3, 4)"
 *          yazmalıdır. Bu hâliyle derlenmez.
 */
#include <stdio.h>

typedef struct {
    int x;
    int y;
} Nokta;

int main(void)
{
    Nokta yaz[2] = {{1, 2}, {3, 4}};
    FILE *f = fopen("noktalar.dat", ____);              /* (1) kip */
    if (f == NULL) {
        return 1;
    }
    fwrite(yaz, ____, 2, f);                             /* (2) boyut */
    fclose(f);

    Nokta oku[2];
    f = fopen("noktalar.dat", ____);                     /* (3) kip */
    if (f == NULL) {
        return 1;
    }
    size_t n = fread(____, sizeof oku[0], 2, f);         /* (4) hedef */
    fclose(f);
    printf("%zu kayıt:", n);
    for (size_t i = 0; i < n; i++) {
        printf(" (%d, %d)", oku[i].x, ____);             /* (5) */
    }
    printf("\n");
    return 0;
}

/* H14_A02_dolgu_tahmin.c — Hafta 14 · Alıştırma 14.2 (★★, Çıktı tahmini)
 * Görev  : x86-64 Linux GCC için dört değeri tahmin edin; her yapının
 *          bayt haritasını (üye baytları ve dolgu) çizin. Sonra derleyip
 *          çalıştırarak doğrulayın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_A02_dolgu_tahmin.c -o a02
 */
#include <stdio.h>
#include <stddef.h>

struct A {
    char a;
    double b;
    char c;
};

struct B {
    double b;
    char a;
    char c;
};

struct C {
    char a;
    char c;
    int i;
};

int main(void)
{
    printf("%zu %zu %zu %zu\n", sizeof(struct A), sizeof(struct B),
           sizeof(struct C), offsetof(struct A, c));
    return 0;
}

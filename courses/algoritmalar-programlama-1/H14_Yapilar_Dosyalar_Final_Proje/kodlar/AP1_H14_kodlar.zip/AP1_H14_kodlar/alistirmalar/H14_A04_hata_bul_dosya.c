/* H14_A04_hata_bul_dosya.c — Hafta 14 · Alıştırma 14.4 (★★, Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR (alıştırma: hataları siz bulacaksınız).
 * Görev  : Program kayitlar.txt'ye bir satır EKLEYİP dosyadaki satırları
 *          saymalıydı. Bu kodda ÜÇ hata var (biri yalnızca belirli
 *          koşullarda ortaya çıkar). Hepsini bulun ve düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_A04_hata_bul_dosya.c -o a04
 */
#include <stdio.h>

int main(void)
{
    FILE *f = fopen("kayitlar.txt", "w");
    fprintf(f, "2301010048 CAN\n");
    fclose(f);

    f = fopen("kayitlar.txt", "r");
    char satir[64];
    int n = 0;
    while (!feof(f)) {
        fgets(satir, sizeof satir, f);
        n++;
    }
    fclose(f);
    printf("Dosyada %d satır var.\n", n);
    return 0;
}

/* H14_A05_parsons_numarala.c — Hafta 14 · Alıştırma 14.5 (★★, Parsons)
 * Satırlar karışık verilmiştir: tamamlanacak; bu hâliyle derlenmez.
 * Görev  : numarala(yol), dosyanın satırlarını "1: ..." biçiminde
 *          numaralayarak yazmalı ve satır sayısını döndürmelidir; dosya
 *          açılamazsa nedenini yazıp -1 döndürmelidir. Satırları doğru
 *          sıraya dizin ve girintileyin.
 */
    fclose(f);
int numarala(const char *yol)
        return -1;
    while (fgets(satir, sizeof satir, f) != NULL) {
{
        printf("%d: %s", ++n, satir);
    return n;
    FILE *f = fopen(yol, "r");
    }
    if (f == NULL) {
        perror(yol);
}
    char satir[256];
    int n = 0;
    }

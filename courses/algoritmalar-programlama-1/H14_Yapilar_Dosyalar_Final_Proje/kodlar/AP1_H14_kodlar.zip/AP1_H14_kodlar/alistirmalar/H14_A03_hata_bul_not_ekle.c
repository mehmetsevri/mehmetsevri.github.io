/* H14_A03_hata_bul_not_ekle.c — Hafta 14 · Alıştırma 14.3 (★★, Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR (alıştırma: hatayı siz bulacaksınız).
 * Görev  : Program üç not ekleyip ortalamayı yazmalıydı; oysa "Not
 *          sayısı: 0" yazıyor. Derleyici uyarı vermez. Hatayı bulun,
 *          nedenini yığın çerçeveleriyle açıklayın ve düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_A03_hata_bul_not_ekle.c -o a03
 */
#include <stdio.h>

#define AZAMI 10

typedef struct {
    double notlar[AZAMI];
    int n;
} Karne;

void not_ekle(Karne k, double puan)
{
    if (k.n < AZAMI) {
        k.notlar[k.n] = puan;
        k.n++;
    }
}

int main(void)
{
    Karne k = {{0}, 0};
    not_ekle(k, 70);
    not_ekle(k, 85);
    not_ekle(k, 90);
    printf("Not sayısı: %d\n", k.n);
    if (k.n > 0) {
        double toplam = 0;
        for (int i = 0; i < k.n; i++) {
            toplam += k.notlar[i];
        }
        printf("Ortalama: %.2f\n", toplam / k.n);
    }
    return 0;
}

/* test_obs.c — Mini-OBS v1.0 (AP-1 Hafta 14): birim testleri
 * Kurallar (v0.8'den 37 doğrulama, aynen) + metin işleme (v0.13'ten) +
 * yapılar (DersNotu, Ogrenci, Sinif: kopyalama, büyütme, silme, arama,
 * işaretçiyle güncelleme, doğrulama) + dosyalar (CSV ve ikili gidiş-dönüş,
 * bozuk satırların satır numarasıyla bildirilmesi, kesik/bozuk ikili
 * dosyalar, yükleme başarısızsa verinin DEĞİŞMEMESİ).
 * Derleme : make test       (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c metin.c obs.c dosya.c test_obs.c
 *           gcc metin.o obs.o dosya.o test_obs.o -o obs_test -lm && ./obs_test
 * Bellek  : make asan (ASan + LeakSanitizer) · make valgrind
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdbool.h>
#include "obs.h"
#include "metin.h"
#include "dosya.h"

static int sayac = 0;                /* geçen doğrulama sayısı (dosya kapsamı) */
static const double EPS = 1e-9;      /* kayan nokta toleransı */

/* v0.8'deki 37 kural testi (aynen) */
static void kural_testleri(void)
{
    /* hesapla_ortalama: kayan noktada == yerine tolerans */
    assert(hesapla_ortalama(70, 85) - 79.0 < EPS && 79.0 - hesapla_ortalama(70, 85) < EPS); sayac++;
    assert(hesapla_ortalama(0, 0) == 0.0); sayac++;
    assert(hesapla_ortalama(100, 100) - 100.0 < EPS && 100.0 - hesapla_ortalama(100, 100) < EPS); sayac++;

    /* yuvarla: .5 yukarı, altı aşağı */
    assert(yuvarla(59.5) == 60); sayac++;
    assert(yuvarla(59.4) == 59); sayac++;
    assert(yuvarla(0.0) == 0); sayac++;
    assert(yuvarla(100.0) == 100); sayac++;

    /* harf_notu: her kademenin iki sınırı ve baraj */
    assert(strcmp(harf_notu(100, 100), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(90, 90), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(89, 89), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(81, 81), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(80, 80), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(73, 73), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(72, 72), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(66, 66), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(65, 65), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(60, 60), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(59, 59), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(50, 50), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(49, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(40, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(39, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(30, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(29, 50), "FF") == 0); sayac++;
    assert(strcmp(harf_notu(95, 49.9), "FF") == 0); sayac++;   /* baraj */

    /* gecti_mi / sartli_mi */
    assert(gecti_mi(60, 50)); sayac++;
    assert(!gecti_mi(59, 80)); sayac++;
    assert(!gecti_mi(95, 49.9)); sayac++;
    assert(sartli_mi(50, 50)); sayac++;
    assert(sartli_mi(59, 60)); sayac++;
    assert(!sartli_mi(60, 60)); sayac++;
    assert(!sartli_mi(49, 60)); sayac++;
    assert(!sartli_mi(55, 45)); sayac++;

    /* durum_metni */
    assert(strcmp(durum_metni(79, 85), "BAŞARILI") == 0); sayac++;
    assert(strcmp(durum_metni(54, 70), "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)") == 0); sayac++;
    assert(strcmp(durum_metni(47, 48), "BAŞARISIZ (final barajı)") == 0); sayac++;
    assert(strcmp(durum_metni(45, 50), "BAŞARISIZ") == 0); sayac++;
}

/* Kayan nokta karşılaştırması: |x - y| < EPS */
static bool yakin(double x, double y)
{
    return x - y < EPS && y - x < EPS;
}

/* v0.13'ten: karakter dizileri ve metin işleme (metin.c) */
static void metin_testleri(void)
{
    char h[AD_BOYUT];
    /* boşluk temizleme + Türkçe büyük harf */
    assert(ad_normallestir("  ayşe   nur ", h, sizeof h) == 9
           && strcmp(h, "AYŞE NUR") == 0); sayac++;
    assert(ad_normallestir("ılgaz", h, sizeof h) == 5
           && strcmp(h, "ILGAZ") == 0); sayac++;           /* ı (2 bayt) → I (1) */
    assert(ad_normallestir("ismail", h, sizeof h) == 8
           && strcmp(h, "İSMAİL") == 0); sayac++;          /* i (1 bayt) → İ (2) */
    assert(ad_normallestir("çağrı gökşen üzüm", h, sizeof h) == 23
           && strcmp(h, "ÇAĞRI GÖKŞEN ÜZÜM") == 0); sayac++;
    assert(ad_normallestir("ÖZGÜR", h, sizeof h) == 7
           && strcmp(h, "ÖZGÜR") == 0); sayac++;           /* zaten büyük */
    assert(ad_normallestir(" \t ", h, sizeof h) == 0 && h[0] == '\0'); sayac++;
    /* taşma: 31 bayta sığmayan ad reddedilir, hedef boş kalır */
    assert(ad_normallestir("abcdefghjklmnopqrstuvwxyzabcdef", h, sizeof h) == 31);
    sayac++;                                               /* tam 31 bayt sığar */
    assert(ad_normallestir("abcdefghjklmnopqrstuvwxyzabcdefg", h, sizeof h) == -1
           && h[0] == '\0'); sayac++;                       /* 32 bayt sığmaz */
    char kucuk[4];
    assert(ad_normallestir("ali", kucuk, sizeof kucuk) == -1); sayac++;  /* "ALİ" 4 bayt */
    assert(ad_normallestir("ala", kucuk, sizeof kucuk) == 3
           && strcmp(kucuk, "ALA") == 0); sayac++;

    /* geçerlilik */
    assert(ad_gecerli_mi("AYŞE NUR") && ad_gecerli_mi("O'NEIL")
           && ad_gecerli_mi("ÖZ-TÜRK")); sayac++;
    assert(!ad_gecerli_mi("") && !ad_gecerli_mi("ALİ2")
           && !ad_gecerli_mi("ALİ;VELİ")); sayac++;
    assert(!ad_gecerli_mi("\xC3") && !ad_gecerli_mi("A\xFF" "B")); sayac++;  /* bozuk UTF-8 */

    /* bayt ≠ karakter */
    assert(strlen("ÇAY") == 4 && utf8_karakter_sayisi("ÇAY") == 3); sayac++;
    assert(strlen("ÇAĞLAR") == 8 && utf8_karakter_sayisi("ÇAĞLAR") == 6); sayac++;
    assert(utf8_karakter_sayisi("") == 0); sayac++;

    /* sayı çözümleme: satırın TAMAMI sayı olmalı */
    long long t = 0;
    double x = 0;
    assert(tamsayi_coz("2301010045", &t) && t == 2301010045LL); sayac++;
    assert(tamsayi_coz("  42  ", &t) && t == 42); sayac++;
    assert(!tamsayi_coz("12abc", &t) && !tamsayi_coz("", &t)
           && !tamsayi_coz("3 4", &t)); sayac++;
    assert(!tamsayi_coz("99999999999999999999", &t)); sayac++;   /* ERANGE */
    assert(ondalik_coz("85.5", &x) && yakin(x, 85.5)); sayac++;
    assert(!ondalik_coz("85,5", &x) && !ondalik_coz("nan", &x)
           && !ondalik_coz("inf", &x)); sayac++;
}

/* Yardımcı: bir öğrenci kaydı kurar ve DEĞER olarak döndürür (yapılar
 * dizilerden farklı olarak fonksiyondan döndürülebilir ve atanabilir). */
static Ogrenci ornek(long long no, const char *ad, const char *soyad,
                     const double notlar[2 * DERS_SAYISI])
{
    Ogrenci o = {0};
    o.no = no;
    ad_normallestir(ad, o.ad, sizeof o.ad);
    ad_normallestir(soyad, o.soyad, sizeof o.soyad);
    for (int d = 0; d < DERS_SAYISI; d++) {
        ders_notu_ata(&o.ders[d], notlar[2 * d], notlar[2 * d + 1]);
    }
    return o;
}

/* İki kayıt alan alan aynı mı? (Yapılar == ile karşılaştırılamaz; memcmp
 * de dolgu baytları yüzünden genelde güvenilmez: alanlar tek tek.) */
static bool ayni_kayit(const Ogrenci *a, const Ogrenci *b)
{
    if (a->no != b->no || strcmp(a->ad, b->ad) != 0
        || strcmp(a->soyad, b->soyad) != 0) {
        return false;
    }
    for (int d = 0; d < DERS_SAYISI; d++) {
        if (!yakin(a->ders[d].vize, b->ders[d].vize)
            || !yakin(a->ders[d].final, b->ders[d].final)
            || !yakin(a->ders[d].ort, b->ders[d].ort)) {
            return false;
        }
    }
    return true;
}

static bool ayni_sinif(const Sinif *a, const Sinif *b)
{
    if (a->n != b->n) {
        return false;
    }
    for (int i = 0; i < a->n; i++) {
        if (!ayni_kayit(&a->kayit[i], &b->kayit[i])) {
            return false;
        }
    }
    return true;
}

static const double N1[] = {70, 85, 90, 95, 40, 60};       /* BB AA DC */
static const double N2[] = {45, 48, 55, 62, 60, 70};       /* FF DC CB */
static const double N3[] = {88, 92, 60, 75, 30, 45};       /* AA BB FF */
static const double N4[] = {85.5, 90.25, 100, 100, 0, 50}; /* ondalıklı */

/* Örnek sınıf: 5 kayıt (iki YILMAZ). */
static void ornek_sinif(Sinif *s)
{
    sinif_baslat(s);
    Ogrenci o;
    o = ornek(2301010045, "ayşe nur", "yılmaz", N1); assert(sinif_ekle(s, &o));
    o = ornek(2301010046, "mehmet ali", "kaya", N2); assert(sinif_ekle(s, &o));
    o = ornek(2301010047, "ismail", "öztürk", N3);   assert(sinif_ekle(s, &o));
    o = ornek(2301010048, "can", "yılmaz", N4);      assert(sinif_ekle(s, &o));
    o = ornek(2301010049, "zeynep", "çelik", N1);    assert(sinif_ekle(s, &o));
}

/* Yeni (H14): yapılar, yapı dizisi ve işaretçiyle erişim */
static void yapi_testleri(void)
{
    DersNotu dn;
    ders_notu_ata(&dn, 70, 85);
    assert(yakin(dn.ort, 79.0) && ders_harfi(&dn) == 2); sayac++;      /* BB */
    ders_notu_ata(&dn, 100, 49);
    assert(ders_harfi(&dn) == 8); sayac++;                            /* baraj: FF */

    Ogrenci a = ornek(2301010045, "ayşe nur", "yılmaz", N1);
    assert(strcmp(a.ad, "AYŞE NUR") == 0 && strcmp(a.soyad, "YILMAZ") == 0);
    sayac++;
    assert(yakin(ogrenci_yano(&a), 2.91)); sayac++;   /* (6·3,0 + 6·4,0 + 5·1,5) / 17 */
    Ogrenci b = a;                                    /* yapı ataması: KOPYA */
    b.ad[0] = 'X';
    b.ders[0].vize = 0;
    assert(a.ad[0] == 'A' && yakin(a.ders[0].vize, 70)     /* a değişmedi, */
           && b.ad[0] == 'X' && yakin(b.ders[0].vize, 0)); sayac++;    /* b değişti */
    assert(sizeof a.ad == AD_BOYUT
           && sizeof(Ogrenci) >= sizeof(long long) + AD_BOYUT + SOYAD_BOYUT
                                 + DERS_SAYISI * sizeof(DersNotu)); sayac++;

    /* sınıf: 0 → 4 → 8 kapasite; kayıtlar KOPYALANIR */
    Sinif s;
    sinif_baslat(&s);
    assert(s.kayit == NULL && s.n == 0 && s.kapasite == 0); sayac++;
    for (int i = 0; i < 5; i++) {
        Ogrenci o = ornek(2301010100 + i, "öğrenci", "deneme", N2);
        assert(sinif_ekle(&s, &o));
        o.no = 0;                                 /* yerel kopya değişir... */
        assert(s.kayit[i].no == 2301010100 + i);  /* ...dizideki değişmez */
    }
    assert(s.n == 5 && s.kapasite == 8); sayac++;
    assert(sinif_numara_bul(&s, 2301010103) == 3
           && sinif_numara_bul(&s, 1) == -1); sayac++;
    /* işaretçiyle güncelleme: kaydın KENDİSİ değişir */
    Ogrenci *p = &s.kayit[2];
    ders_notu_ata(&p->ders[1], 100, 100);
    assert(yakin(s.kayit[2].ders[1].ort, 100)); sayac++;
    /* silme: sıra korunur */
    assert(sinif_sil(&s, 1) && s.n == 4 && s.kayit[1].no == 2301010102
           && s.kayit[3].no == 2301010104); sayac++;
    assert(!sinif_sil(&s, 4) && !sinif_sil(&s, -1) && s.n == 4); sayac++;
    while (s.n > 0) {
        assert(sinif_sil(&s, 0));
    }
    assert(s.n == 0 && s.kapasite == 8); sayac++;
    sinif_birak(&s);
    assert(s.kayit == NULL && s.n == 0 && s.kapasite == 0); sayac++;    /* sarkan yok */
    sinif_birak(&s);                                                    /* free(NULL) */

    /* isimle arama: bütün eşleşmeler */
    ornek_sinif(&s);
    assert(sinif_isim_bul(&s, "YILMAZ", 0) == 0 && sinif_isim_bul(&s, "YILMAZ", 1) == 3
           && sinif_isim_bul(&s, "YILMAZ", 4) == -1); sayac++;
    assert(sinif_isim_bul(&s, "MEHMET ALİ KAYA", 0) == 1
           && sinif_isim_bul(&s, "İSMAİL", 0) == 2); sayac++;

    /* istatistik: çıktı parametreleri */
    double o = 0, sp = 0;
    int enb = -1, enk = -1, bas = -1, sar = -1;
    assert(ders_istatistigi(&s, 0, &o, &sp, &enb, &enk, &bas, &sar)); sayac++;
    assert(enb == 2 && enk == 1); sayac++;                       /* 90.4 ve 46.8 */
    assert(bas == 4 && sar == 0); sayac++;                       /* FF baraj */
    int sayac_m[DERS_SAYISI][HARF_SAYISI];
    ders_harf_dagilimi(&s, sayac_m);
    assert(sayac_m[2][5] == 2 && sayac_m[2][8] == 1 && sayac_m[2][7] == 1
           && sayac_m[2][3] == 1); sayac++;            /* FIZ: DC DC FF FD CB */

    /* dosyadan gelen kayıt doğrulaması */
    Ogrenci k = a;
    assert(ogrenci_gecerli_mi(&k)); sayac++;
    k.no = 0;
    assert(!ogrenci_gecerli_mi(&k)); sayac++;
    k = a;
    memset(k.ad, 'A', sizeof k.ad);                  /* '\0' yok */
    assert(!ogrenci_gecerli_mi(&k)); sayac++;
    k = a;
    k.ders[2].final = 101;                           /* aralık dışı */
    assert(!ogrenci_gecerli_mi(&k)); sayac++;
    sinif_birak(&s);
}

/* Yeni (H14): dosyalar. Testler tmpfile() ile geçici bir akış kullanır;
 * fonksiyonlar FILE * aldığı için diskte ad vermeye gerek kalmaz. */
static void dosya_testleri(void)
{
    assert(dosya_turu("ogrenciler.csv") == DOSYA_CSV
           && dosya_turu("yedek.2026.dat") == DOSYA_IKILI
           && dosya_turu("notlar.txt") == DOSYA_BILINMIYOR
           && dosya_turu("csv") == DOSYA_BILINMIYOR); sayac++;

    Sinif s, t;
    ornek_sinif(&s);
    int hs = -1;

    /* CSV gidiş-dönüş */
    FILE *f = tmpfile();
    assert(f != NULL);
    assert(csv_yaz(f, &s) == DOSYA_TAMAM);
    rewind(f);
    char ilk[128];
    assert(fgets(ilk, sizeof ilk, f) != NULL
           && strcmp(ilk, "no;ad;soyad;ALG_vize;ALG_final;MAT_vize;MAT_final;"
                          "FIZ_vize;FIZ_final\n") == 0); sayac++;
    rewind(f);
    sinif_baslat(&t);
    assert(csv_oku(f, &t, &hs) == DOSYA_TAMAM && hs == 0); sayac++;
    assert(ayni_sinif(&s, &t)); sayac++;                 /* 85.5 ve 90.25 dahil */
    fclose(f);
    sinif_birak(&t);

    /* CSV: başlıksız, boş satırlı, CRLF, küçük harfli ad */
    f = tmpfile();
    fputs("\r\n2301010045;ayşe nur;yılmaz;70;85;90;95;40;60\r\n\r\n"
          "2301010046; mehmet  ali ;kaya;45;48;55;62;60;70\r\n", f);
    rewind(f);
    sinif_baslat(&t);
    assert(csv_oku(f, &t, &hs) == DOSYA_TAMAM && t.n == 2
           && strcmp(t.kayit[1].ad, "MEHMET ALİ") == 0
           && ayni_kayit(&t.kayit[0], &s.kayit[0])); sayac++;
    fclose(f);
    sinif_birak(&t);

    /* CSV: Excel "CSV UTF-8" dosya başı imzası (BOM) atlanır */
    f = tmpfile();
    fputs("\xEF\xBB\xBFno;ad;soyad;ALG_vize;ALG_final;MAT_vize;MAT_final;"
          "FIZ_vize;FIZ_final\n2301010045;AYŞE NUR;YILMAZ;70;85;90;95;40;60\n", f);
    rewind(f);
    sinif_baslat(&t);
    assert(csv_oku(f, &t, &hs) == DOSYA_TAMAM && t.n == 1
           && ayni_kayit(&t.kayit[0], &s.kayit[0])); sayac++;
    fclose(f);
    sinif_birak(&t);

    /* CSV: bozuk satırlar → okuma durur, satır numarası bildirilir */
    const char *bozuk[] = {
        "no;ad;soyad\n2301010045;AYŞE;YILMAZ;70;85;90;95;40\n",          /* 8 alan */
        "1;A;B;70;85;90;95;40;60\n2;C;D;70;85,5;90;95;40;60\n",           /* virgül */
        "1;A;B;70;85;90;95;40;60\n1;C;D;70;85;90;95;40;60\n",             /* mükerrer */
        "1;;B;70;85;90;95;40;60\n",                                       /* boş ad */
        "1;A;B;70;85;90;95;40;101\n",                                     /* aralık */
        "1;A;B;70;85;90;95;40;60;99\n",                                   /* fazla alan */
    };
    const int beklenen_satir[] = {2, 2, 2, 1, 1, 1};
    for (int i = 0; i < 6; i++) {
        f = tmpfile();
        fputs(bozuk[i], f);
        rewind(f);
        sinif_baslat(&t);
        assert(csv_oku(f, &t, &hs) == DOSYA_BICIM_HATASI && hs == beklenen_satir[i]);
        fclose(f);
        sinif_birak(&t);
    }
    sayac++;

    /* İkili gidiş-dönüş: 16 bayt başlık + n × sizeof(Ogrenci) */
    f = tmpfile();
    assert(ikili_yaz(f, &s) == DOSYA_TAMAM);
    assert(ftell(f) == 16 + (long)(s.n * sizeof(Ogrenci))); sayac++;
    rewind(f);
    sinif_baslat(&t);
    assert(ikili_oku(f, &t) == DOSYA_TAMAM && ayni_sinif(&s, &t)); sayac++;
    sinif_birak(&t);

    /* İkili: kesik dosya, bozuk imza, fazladan bayt */
    rewind(f);
    unsigned char tampon[16 + 5 * sizeof(Ogrenci) + 1];
    size_t boy = fread(tampon, 1, sizeof tampon, f);
    assert(boy == 16 + 5 * sizeof(Ogrenci));
    fclose(f);
    size_t kes[] = {boy - 1, 10};
    for (int i = 0; i < 2; i++) {
        f = tmpfile();
        fwrite(tampon, 1, kes[i], f);
        rewind(f);
        sinif_baslat(&t);
        assert(ikili_oku(f, &t) == DOSYA_BICIM_HATASI && t.n <= 4);
        fclose(f);
        sinif_birak(&t);
    }
    sayac++;
    tampon[0] = 'X';
    f = tmpfile();
    fwrite(tampon, 1, boy, f);
    rewind(f);
    sinif_baslat(&t);
    assert(ikili_oku(f, &t) == DOSYA_BICIM_HATASI && t.n == 0); sayac++;
    fclose(f);
    sinif_birak(&t);
    tampon[0] = 'M';
    tampon[boy] = 0;
    f = tmpfile();
    fwrite(tampon, 1, boy + 1, f);
    rewind(f);
    sinif_baslat(&t);
    assert(ikili_oku(f, &t) == DOSYA_BICIM_HATASI); sayac++;
    fclose(f);
    sinif_birak(&t);

    /* Dosya yolu ile: kaydet → yükle (iki biçim), olmayan dosya, bozuk dosya */
    const char *yollar[] = {"test_gecici.csv", "test_gecici.dat"};
    for (int i = 0; i < 2; i++) {
        assert(sinif_kaydet(yollar[i], &s) == DOSYA_TAMAM);
        sinif_baslat(&t);
        assert(sinif_yukle(yollar[i], &t, &hs) == DOSYA_TAMAM && ayni_sinif(&s, &t));
        sinif_birak(&t);
        remove(yollar[i]);
    }
    sayac++;
    ornek_sinif(&t);
    assert(sinif_yukle("olmayan_dosya.csv", &t, &hs) == DOSYA_YOK && t.n == 5); sayac++;
    f = fopen("test_bozuk.csv", "w");
    assert(f != NULL);
    fputs("1;A;B;70;85;90;95;40;60\nbozuk satır\n", f);
    fclose(f);
    assert(sinif_yukle("test_bozuk.csv", &t, &hs) == DOSYA_BICIM_HATASI
           && hs == 2 && t.n == 5); sayac++;          /* t DEĞİŞMEDİ */
    remove("test_bozuk.csv");
    assert(sinif_kaydet("notlar.txt", &t) == DOSYA_BICIM_HATASI); sayac++;
    sinif_birak(&t);
    sinif_birak(&s);
}

int main(void)
{
    kural_testleri();
    int kural = sayac;
    metin_testleri();
    int metin = sayac - kural;
    yapi_testleri();
    int yapi = sayac - kural - metin;
    dosya_testleri();
    printf("Tüm testler geçti (%d doğrulama: %d kural + %d metin + %d yapı"
           " + %d dosya).\n", sayac, kural, metin, yapi,
           sayac - kural - metin - yapi);
    return 0;
}

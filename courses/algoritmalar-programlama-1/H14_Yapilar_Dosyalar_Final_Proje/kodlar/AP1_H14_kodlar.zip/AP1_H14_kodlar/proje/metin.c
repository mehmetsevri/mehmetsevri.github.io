/* metin.c — Mini-OBS v1.0 (AP-1 Hafta 14): güvenli girdi ve metin işleme
 * v0.13'teki fonksiyonlar (satir_oku, tamsayi_coz, ondalik_coz,
 * ad_normallestir, ad_gecerli_mi, utf8_karakter_sayisi, hizali_yaz,
 * numara_oku, not_oku, ad_oku) AYNEN; yeni: secim_oku (menü ve ders seçimi
 * için genel aralık okuma) ve evet_mi_oku (silme onayı).
 * Kodlama : Kaynak dosya ve bütün metinler UTF-8'dir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g -c metin.c
 */
#include <stdio.h>
#include <stdlib.h>   /* strtoll, strtod */
#include <string.h>   /* strlen, strncmp, memcpy */
#include <ctype.h>    /* isspace, isalpha, toupper */
#include <errno.h>    /* errno, ERANGE */
#include <math.h>     /* isfinite */
#include "metin.h"

/* Türkçe küçük harfler ve büyük karşılıkları (UTF-8). Sıra önemlidir:
 * ASCII 'i' de tabloda, çünkü Türkçede büyüğü 'I' değil 'İ'dir. */
static const char *const KUCUK_HARF[] = { "ç", "ğ", "ı", "ö", "ş", "ü", "i" };
static const char *const BUYUK_HARF[] = { "Ç", "Ğ", "I", "Ö", "Ş", "Ü", "İ" };
static const int TR_HARF_SAYISI = 7;

/* Girdi tamponunda satırın kalanını (satır sonu dahil) atar.
 * static fonksiyon: yalnızca bu dosyadan çağrılabilir (obs.h'de yok). */
static void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }
}

/* Ön koşul : tampon en az boyut baytlık bir dizi; boyut >= 2.
 * Son koşul:  1 → bir satır okundu; sondaki '\n' (ve Windows'tan gelen '\r')
 *                 silindi, tampon '\0' ile biter;
 *             0 → satır tampona sığmadı; kalanı atıldı, tampon boş;
 *            -1 → hiçbir şey okunamadan girdi bitti (EOF).
 * fgets en çok boyut - 1 bayt okur ve sona her zaman '\0' koyar: taşmaz. */
int satir_oku(char *tampon, size_t boyut)
{
    if (fgets(tampon, (int)boyut, stdin) == NULL) {
        return -1;
    }
    size_t uzunluk = strlen(tampon);
    if (uzunluk > 0 && tampon[uzunluk - 1] == '\n') {
        tampon[--uzunluk] = '\0';                 /* fgets '\n'i de saklar */
    } else {
        int c = getchar();          /* satır tam sığdı mı, yoksa taştı mı? */
        if (c != '\n' && c != EOF) {
            satir_temizle();                      /* taşan kısmı at */
            tampon[0] = '\0';
            return 0;
        }
    }
    if (uzunluk > 0 && tampon[uzunluk - 1] == '\r') {
        tampon[--uzunluk] = '\0';                 /* CRLF satır sonu */
    }
    return 1;
}

/* Son koşul: metnin TAMAMI (baştaki/sondaki boşluklar hariç) onluk bir
 * tamsayıysa değeri *sonuc'a yazılır ve true döner; rakam yoksa, sayıdan
 * sonra başka karakter varsa ya da long long'a sığmıyorsa false. */
bool tamsayi_coz(const char *metin, long long *sonuc)
{
    char *son;
    errno = 0;
    long long deger = strtoll(metin, &son, 10);
    if (son == metin || errno == ERANGE) {
        return false;                    /* hiç rakam yok ya da taşma */
    }
    while (isspace((unsigned char)*son)) {
        son++;
    }
    if (*son != '\0') {
        return false;                    /* "12abc", "3 4" gibi artıklar */
    }
    *sonuc = deger;
    return true;
}

/* Son koşul: metnin TAMAMI sonlu bir ondalık sayıysa (ondalık ayırıcı
 * NOKTA: 85.5) değeri *sonuc'a yazılır ve true döner; aksi hâlde false
 * ("85,5", "nan", "inf", "1e999" reddedilir). */
bool ondalik_coz(const char *metin, double *sonuc)
{
    char *son;
    errno = 0;
    double deger = strtod(metin, &son);
    if (son == metin || errno == ERANGE || !isfinite(deger)) {
        return false;
    }
    while (isspace((unsigned char)*son)) {
        son++;
    }
    if (*son != '\0') {
        return false;
    }
    *sonuc = deger;
    return true;
}

/* s, Türkçe küçük harflerden biriyle başlıyorsa o harfin tablo indisini,
 * başlamıyorsa -1'i döndürür. */
static int turkce_kucuk_harf(const char *s)
{
    for (int k = 0; k < TR_HARF_SAYISI; k++) {
        if (strncmp(s, KUCUK_HARF[k], strlen(KUCUK_HARF[k])) == 0) {
            return k;
        }
    }
    return -1;
}

/* Ön koşul : kaynak '\0' ile biten UTF-8 metin; hedef en az boyut baytlık.
 * Son koşul: hedef = kaynağın normalleştirilmiş biçimi: baştaki ve sondaki
 *            boşluklar atılır, aradaki boşluk dizileri tek boşluğa iner,
 *            harfler Türkçe kurala göre büyütülür (i → İ, ı → I, ç → Ç, ...).
 *            Dönüş: hedefe yazılan bayt sayısı ('\0' hariç); sonuç boyut - 1
 *            bayta sığmazsa hedef boş bırakılır ve -1 döner.
 *            Hedefe hiçbir zaman boyut bayttan fazla yazılmaz; çok baytlı
 *            bir harf asla ortasından bölünmez. */
int ad_normallestir(const char *kaynak, char *hedef, size_t boyut)
{
    size_t i = 0;                 /* kaynakta okunacak bayt */
    size_t j = 0;                 /* hedefte yazılacak bayt */
    bool bosluk_bekliyor = false; /* kelimeler arasına tek boşluk koyulacak */
    if (boyut == 0) {
        return -1;
    }
    while (kaynak[i] != '\0') {
        if (isspace((unsigned char)kaynak[i])) {
            bosluk_bekliyor = (j > 0);   /* baştaki boşluklar hiç yazılmaz */
            i++;
            continue;
        }
        char tek[2] = { 0, 0 };
        const char *parca;
        int k = turkce_kucuk_harf(&kaynak[i]);
        if (k != -1) {
            parca = BUYUK_HARF[k];               /* 'ı' → "I": 2 bayt → 1 */
            i += strlen(KUCUK_HARF[k]);          /* 'i' → "İ": 1 bayt → 2 */
        } else {
            tek[0] = (char)toupper((unsigned char)kaynak[i]);
            parca = tek;                         /* ASCII harf ya da diğer bayt */
            i++;
        }
        size_t gerekli = strlen(parca) + (bosluk_bekliyor ? 1 : 0);
        if (j + gerekli >= boyut) {              /* '\0' için de yer kalmalı */
            hedef[0] = '\0';
            return -1;
        }
        if (bosluk_bekliyor) {
            hedef[j++] = ' ';
            bosluk_bekliyor = false;
        }
        memcpy(&hedef[j], parca, strlen(parca));
        j += strlen(parca);
    }
    hedef[j] = '\0';                  /* sondaki boşluklar hiç yazılmadı */
    return (int)j;
}

/* Son koşul: ad boş değilse ve yalnızca harf (ASCII harfler ve geçerli
 * çok baytlı UTF-8 karakterler), boşluk, kesme işareti (') ve kısa çizgi
 * (-) içeriyorsa true. Rakam, noktalama ve bozuk UTF-8 dizileri reddedilir. */
bool ad_gecerli_mi(const char *ad)
{
    if (ad[0] == '\0') {
        return false;
    }
    for (size_t i = 0; ad[i] != '\0'; ) {
        unsigned char c = (unsigned char)ad[i];
        int devam;                          /* beklenen devam baytı sayısı */
        if (c < 0x80) {                     /* ASCII: 0xxxxxxx */
            if (!isalpha(c) && c != ' ' && c != '\'' && c != '-') {
                return false;
            }
            i++;
            continue;
        } else if (c >= 0xC2 && c <= 0xDF) {    /* 110xxxxx: 2 baytlık */
            devam = 1;
        } else if ((c & 0xF0) == 0xE0) {        /* 1110xxxx: 3 baytlık */
            devam = 2;
        } else if (c >= 0xF0 && c <= 0xF4) {    /* 11110xxx: 4 baytlık */
            devam = 3;
        } else {
            return false;                       /* geçersiz başlangıç baytı */
        }
        for (int k = 1; k <= devam; k++) {
            if (((unsigned char)ad[i + k] & 0xC0) != 0x80) {
                return false;                   /* eksik devam baytı ('\0' dahil) */
            }
        }
        i += devam + 1;
    }
    return true;
}

/* Son koşul: s'deki KARAKTER sayısı. UTF-8'de devam baytları 10xxxxxx
 * biçimindedir; yalnızca devam baytı OLMAYAN baytlar sayılır.
 * strlen ise BAYT sayar: strlen("ÇAY") = 4, utf8_karakter_sayisi("ÇAY") = 3. */
size_t utf8_karakter_sayisi(const char *s)
{
    size_t sayi = 0;
    for (; *s != '\0'; s++) {
        if (((unsigned char)*s & 0xC0) != 0x80) {
            sayi++;
        }
    }
    return sayi;
}

/* s'yi yazar ve sağına, toplam genişlik KARAKTER olarak genislik olacak
 * kadar boşluk ekler (printf'in %-24s biçimi BAYT saydığı için Türkçe
 * harfli metinlerde sütunları kaydırır). */
void hizali_yaz(const char *s, int genislik)
{
    printf("%s", s);
    for (size_t k = utf8_karakter_sayisi(s); k < (size_t)genislik; k++) {
        putchar(' ');
    }
}

/* Son koşul: en_kucuk..en_buyuk aralığında bir tamsayı döndürür; geçersiz
 * girdide nedeni yazar ve yeniden sorar; girdi biterse -1. */
int secim_oku(const char *etiket, int en_kucuk, int en_buyuk)
{
    char satir[SATIR_BOYUT];
    long long secim;
    for (;;) {
        printf("%s", etiket);
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1;
        }
        if (durum == 1 && tamsayi_coz(satir, &secim)
            && secim >= en_kucuk && secim <= en_buyuk) {
            return (int)secim;
        }
        printf("  Geçersiz: %d-%d arası bir sayı girin.\n", en_kucuk, en_buyuk);
    }
}

/* Son koşul: pozitif bir öğrenci numarası döndürür; geçersiz girdide
 * yeniden sorar; girdi biterse -1 döndürür. */
long long numara_oku(const char *etiket)
{
    char satir[SATIR_BOYUT];
    long long numara;
    for (;;) {
        printf("%s", etiket);
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1;
        }
        if (durum == 1 && tamsayi_coz(satir, &numara) && numara > 0) {
            return numara;
        }
        printf("  Geçersiz: pozitif bir numara girin.\n");
    }
}
/* Ön koşul : etiket, ekrana yazılacak istem metnidir.
 * Son koşul: 0-100 aralığında bir not döndürür; geçersiz girdide yeniden
 *            sorar; girdi biterse -1.0 döndürür. NaN, !(0 <= x <= 100)
 *            sınamasıyla da reddedilir (NaN ile her karşılaştırma false). */
double not_oku(const char *etiket)
{
    char satir[SATIR_BOYUT];
    double deger;
    for (;;) {
        printf("%s", etiket);
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1.0;
        }
        if (durum == 1 && ondalik_coz(satir, &deger)
            && deger >= 0 && deger <= 100) {
            return deger;
        }
        printf("  Geçersiz: 0 ile 100 arasında bir sayı girin"
               " (ondalık ayırıcı nokta: 85.5).\n");
    }
}

/* Ön koşul : hedef en az boyut baytlık; boyut >= 2.
 * Son koşul: geçerli bir ad okunur, normalleştirilip hedefe yazılır ve 1
 *            döner; geçersizse nedeni yazılır ve yeniden sorulur; girdi
 *            biterse -1. */
int ad_oku(const char *etiket, char *hedef, size_t boyut)
{
    char satir[SATIR_BOYUT];
    for (;;) {
        printf("%s", etiket);
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1;
        }
        if (durum == 0) {
            printf("  Geçersiz: satır çok uzun.\n");
            continue;
        }
        int uzunluk = ad_normallestir(satir, hedef, boyut);
        if (uzunluk == -1) {
            printf("  Geçersiz: en çok %zu bayt (Türkçe harfler 2 bayt).\n",
                   boyut - 1);
        } else if (uzunluk == 0) {
            printf("  Geçersiz: boş bırakılamaz.\n");
        } else if (!ad_gecerli_mi(hedef)) {
            printf("  Geçersiz: yalnızca harf, boşluk, ' ve - kullanılabilir.\n");
        } else {
            return 1;
        }
    }
}

/* Son koşul: "E"/"EVET" (büyük-küçük harf ve baştaki/sondaki boşluklar
 * önemsiz) → 1, "H"/"HAYIR" → 0; başka yanıtta yeniden sorar; EOF → -1. */
int evet_mi_oku(const char *etiket)
{
    char satir[SATIR_BOYUT];
    char yanit[SATIR_BOYUT];
    for (;;) {
        printf("%s", etiket);
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1;
        }
        if (durum == 1 && ad_normallestir(satir, yanit, sizeof yanit) > 0) {
            if (strcmp(yanit, "E") == 0 || strcmp(yanit, "EVET") == 0) {
                return 1;
            }
            if (strcmp(yanit, "H") == 0 || strcmp(yanit, "HAYIR") == 0) {
                return 0;
            }
        }
        printf("  Geçersiz: E (evet) ya da H (hayır) girin.\n");
    }
}

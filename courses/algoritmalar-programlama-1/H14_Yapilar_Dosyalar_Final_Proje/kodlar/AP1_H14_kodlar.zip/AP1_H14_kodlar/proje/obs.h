/* obs.h — Mini-OBS v1.0 (AP-1 Hafta 14): kayıt tipleri ve iş kuralları
 * Yenilik : Altı paralel blok (no, ad, soyad, vize, final, ort) TEK bir
 *           kayıt tipinde toplandı:
 *               DersNotu  { vize, final, ort }            (bir ders)
 *               Ogrenci   { no, ad, soyad, ders[3] }       (iç içe yapı)
 *               Sinif     { kayit, n, kapasite }           (öbekte yapı dizisi)
 *           Aynı öğrencinin bütün verisi bellekte yan yana durur; büyütme
 *           tek realloc'tur (v0.13'te altı ayrı realloc gerekiyordu).
 *           Yapılar fonksiyonlara const işaretçiyle aktarılır (kopyalama
 *           yok, değiştirme yok); değiştiren fonksiyonlar const'suz alır.
 *           Menü seçenekleri enum MenuSecimi ile adlandırılır.
 * Kurallar: RTEÜ yönetmeliği (RG 14.12.2025, 33107; son değişiklik RG
 *           27.02.2026, 33181), md. 25/2, 26/2, 30, 31/2-a — obs.c başında.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>

#define DERS_SAYISI 3       /* her öğrencinin ders sayısı (örnek) */
#define HARF_SAYISI 9       /* AA, BA, BB, CB, CC, DC, DD, FD, FF */
#define AD_BOYUT 32         /* ad için en çok 31 bayt + '\0' */
#define SOYAD_BOYUT 32      /* soyad için en çok 31 bayt + '\0' */

typedef struct {
    double vize;
    double final;
    double ort;             /* %40 vize + %60 final; ders_notu_ata hesaplar */
} DersNotu;

typedef struct {
    long long no;
    char ad[AD_BOYUT];      /* normalleştirilmiş, '\0' ile biten UTF-8 */
    char soyad[SOYAD_BOYUT];
    DersNotu ders[DERS_SAYISI];
} Ogrenci;

typedef struct {
    Ogrenci *kayit;         /* öbekte, kapasite elemanlık yapı dizisi */
    int n;                  /* dolu kayıt sayısı */
    int kapasite;
} Sinif;

typedef enum {
    MENU_EKLE = 1,
    MENU_LISTELE,
    MENU_ARA,
    MENU_GUNCELLE,
    MENU_SIL,
    MENU_ISTATISTIK,
    MENU_TRANSKRIPT,
    MENU_HARF_TABLOSU,
    MENU_KAYDET,
    MENU_CIKIS              /* = 10 */
} MenuSecimi;

/* ---- hesap kuralları (v0.8'den, değişmedi) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
int harf_indeksi(int yuvarlanmis, double final);   /* AA=0 ... FF=8 */
const char *harf_adi(int indeks);
double harf_katsayisi(int indeks);                 /* AA 4,00 ... FF 0,00 */

/* ---- dersler (örnek değerler) ---- */
const char *ders_adi(int d);
const char *ders_kodu(int d);
int ders_kredisi(int d);

/* ---- 1B dizi desenleri (v0.10'dan) ---- */
double dizi_ortalama(const double a[], int n);
double standart_sapma(const double a[], int n);
void min_max_indis(const double a[], int n, int *enk, int *enb);

/* ---- tek kayıt ---- */
void ders_notu_ata(DersNotu *dn, double vize, double final);
int ders_harfi(const DersNotu *dn);                /* harf indisi */
double ogrenci_yano(const Ogrenci *o);
bool ogrenci_gecerli_mi(const Ogrenci *o);          /* dosyadan okunan kayıt için */

/* ---- sınıf (yapı dizisi) ---- */
void sinif_baslat(Sinif *s);
bool sinif_ekle(Sinif *s, const Ogrenci *o);       /* gerekirse büyütür */
bool sinif_sil(Sinif *s, int indis);               /* sırayı korur */
void sinif_birak(Sinif *s);
int sinif_numara_bul(const Sinif *s, long long no);
int sinif_isim_bul(const Sinif *s, const char *aranan, int baslangic);

/* ---- istatistik ---- */
bool ders_istatistigi(const Sinif *s, int d, double *ortalama, double *sapma,
                      int *enb, int *enk, int *basarili, int *sartli);
void ders_harf_dagilimi(const Sinif *s, int sayac[DERS_SAYISI][HARF_SAYISI]);

/* ---- ekran ---- */
void baslik_yaz(void);
void menu_goster(const char *dosya_yolu, int kayit_sayisi, bool degisti);
void ogrenci_ozeti_yaz(const Ogrenci *o);
void transkript_yaz(const Ogrenci *o);
void ders_istatistikleri_yaz(const Sinif *s);
void harf_tablosu_yaz(const Sinif *s);
void kayitlari_listele(const Sinif *s);
void arama_sonucu_yaz(const Sinif *s, const char *aranan);

#endif /* OBS_H */

/* metin.h — Mini-OBS v1.0 (AP-1 Hafta 14): güvenli girdi ve metin işleme
 * v0.13'te obs.c içinde olan girdi ve metin fonksiyonları kendi modülüne
 * taşındı: hiçbiri öğrenci kaydını bilmez, başka programlarda da
 * kullanılabilir (yüksek uyum, düşük bağlaşım).
 * Bütün girdiler satır satır fgets ile okunur; scanf kullanılmaz.
 * Metinler UTF-8'dir: Türkçe harfler 2 bayttır (bayt ≠ karakter).
 */
#ifndef METIN_H
#define METIN_H

#include <stdbool.h>
#include <stddef.h>   /* size_t */

#define SATIR_BOYUT 128     /* bir girdi satırı için tampon (+ '\n' + '\0') */

/* ---- satır okuma ve sayı çözümleme ---- */
int satir_oku(char *tampon, size_t boyut);         /* 1 tamam, 0 çok uzun, -1 EOF */
bool tamsayi_coz(const char *metin, long long *sonuc);
bool ondalik_coz(const char *metin, double *sonuc);

/* ---- ad işleme ---- */
int ad_normallestir(const char *kaynak, char *hedef, size_t boyut);
bool ad_gecerli_mi(const char *ad);
size_t utf8_karakter_sayisi(const char *s);
void hizali_yaz(const char *s, int genislik);

/* ---- etkileşimli girdi (istem yazar, geçersizde yeniden sorar) ---- */
int secim_oku(const char *etiket, int en_kucuk, int en_buyuk); /* EOF → -1 */
long long numara_oku(const char *etiket);                       /* EOF → -1 */
double not_oku(const char *etiket);                             /* EOF → -1.0 */
int ad_oku(const char *etiket, char *hedef, size_t boyut);      /* 1 / EOF → -1 */
int evet_mi_oku(const char *etiket);                            /* 1 E, 0 H, -1 EOF */

#endif /* METIN_H */

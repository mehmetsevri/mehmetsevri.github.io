/* main.c — Mini-OBS v1.0 (AP-1 Hafta 14): menü güdümlü, verisini dosyada
 * saklayan öğrenci not sistemi
 * Kullanım: ./mini_obs [veri_dosyasi.csv | veri_dosyasi.dat]
 *           (argüman verilmezse ogrenciler.csv; uzantı biçimi seçer)
 * Akış    : dosyadan yükle → menü döngüsü → (değişiklik varsa sorarak) kaydet.
 *           Dosya bozuksa program BAŞLAMAZ (çıkış kodu 1): yarım yüklenmiş
 *           veriyi kaydedip sağlam kayıtları silme riskine girilmez.
 * Çıkış kodları: 0 normal; 1 girdi yarıda bitti, dosya okunamadı ya da
 *           kaydedilemedi; 2 hatalı kullanım.
 * Her menü işlemi kendi static fonksiyonundadır; girdi biterse (EOF) false
 * döndürür. Bütün çıkışlar TEK temizlik yolundan geçer: sinif_birak.
 * Derleme : make            (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c metin.c obs.c dosya.c main.c
 *           gcc metin.o obs.o dosya.o main.o -o mini_obs -lm
 */
#include <stdio.h>
#include <stdbool.h>
#include "obs.h"
#include "metin.h"
#include "dosya.h"

static const char *const VARSAYILAN_DOSYA = "ogrenciler.csv";

/* Numara sorar ve kaydın indisini döndürür; kayıt yoksa iletisini yazıp
 * -2, girdi biterse -1 döndürür. */
static int kayit_sor(const Sinif *s)
{
    long long numara = numara_oku("Öğrenci numarası : ");
    if (numara == -1) {
        return -1;
    }
    int i = sinif_numara_bul(s, numara);
    if (i == -1) {
        printf("  Kayıt bulunamadı: %lld\n", numara);
        return -2;
    }
    return i;
}

static bool islem_ekle(Sinif *s, bool *degisti)
{
    Ogrenci o = {0};      /* bütün baytlar sıfır: dosyaya bellek artığı yazılmaz */
    printf("\n------------ ÖĞRENCİ %d ------------\n", s->n + 1);
    o.no = numara_oku("Öğrenci numarası : ");
    if (o.no == -1) {
        return false;
    }
    int bulunan = sinif_numara_bul(s, o.no);
    if (bulunan != -1) {
        printf("  Bu numara zaten kayıtlı (sıra %d).\n", bulunan + 1);
        return true;
    }
    if (ad_oku("Ad               : ", o.ad, sizeof o.ad) == -1
        || ad_oku("Soyad            : ", o.soyad, sizeof o.soyad) == -1) {
        return false;
    }
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("-- %s (%d kredi) --\n", ders_adi(d), ders_kredisi(d));
        double v = not_oku("Vize notu        : ");
        if (v < 0) {
            return false;
        }
        double f = not_oku("Final notu       : ");
        if (f < 0) {
            return false;
        }
        ders_notu_ata(&o.ders[d], v, f);
    }
    if (!sinif_ekle(s, &o)) {
        printf("  Bellek yetersiz: kayıt eklenemedi (%d öğrenci korunuyor).\n", s->n);
        return true;
    }
    *degisti = true;
    ogrenci_ozeti_yaz(&s->kayit[s->n - 1]);
    return true;
}

static bool islem_ara(const Sinif *s)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    char satir[SATIR_BOYUT];
    char aranan[AD_BOYUT + SOYAD_BOYUT];
    long long numara;
    printf("Numara ya da ad  : ");
    int durum = satir_oku(satir, sizeof satir);
    if (durum == -1) {
        return false;
    }
    if (durum == 1 && tamsayi_coz(satir, &numara)) {    /* sayıysa numara */
        int i = sinif_numara_bul(s, numara);
        if (i == -1) {
            printf("  Kayıt bulunamadı: %lld\n", numara);
        } else {
            ogrenci_ozeti_yaz(&s->kayit[i]);
        }
    } else if (durum == 1 && ad_normallestir(satir, aranan, sizeof aranan) > 0) {
        arama_sonucu_yaz(s, aranan);
    } else {
        printf("  Geçersiz: boş ya da çok uzun bir arama.\n");
    }
    return true;
}

static bool islem_guncelle(Sinif *s, bool *degisti)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    int i = kayit_sor(s);
    if (i < 0) {
        return i == -2;                    /* -2: kayıt yok, menüye dön */
    }
    Ogrenci *o = &s->kayit[i];             /* kaydın KENDİSİNİ değiştireceğiz */
    printf("%s %s — dersler:\n", o->ad, o->soyad);
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("  %d) %-20s  vize %6.2f  final %6.2f\n", d + 1, ders_adi(d),
               o->ders[d].vize, o->ders[d].final);
    }
    int d = secim_oku("Ders (1-3)       : ", 1, DERS_SAYISI);
    if (d == -1) {
        return false;
    }
    double v = not_oku("Yeni vize notu   : ");
    if (v < 0) {
        return false;
    }
    double f = not_oku("Yeni final notu  : ");
    if (f < 0) {
        return false;
    }
    ders_notu_ata(&o->ders[d - 1], v, f);  /* o->ders[...]: (*o).ders[...] */
    *degisti = true;
    printf("  Güncellendi.\n");
    ogrenci_ozeti_yaz(o);
    return true;
}

static bool islem_sil(Sinif *s, bool *degisti)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    int i = kayit_sor(s);
    if (i < 0) {
        return i == -2;
    }
    char istem[160];                       /* istem metni snprintf ile kurulur */
    snprintf(istem, sizeof istem, "%lld %s %s silinsin mi? (E/H) : ",
             s->kayit[i].no, s->kayit[i].ad, s->kayit[i].soyad);
    int yanit = evet_mi_oku(istem);
    if (yanit == -1) {
        return false;
    }
    if (yanit == 1 && sinif_sil(s, i)) {
        *degisti = true;
        printf("  Silindi. Kalan kayıt: %d\n", s->n);
    } else {
        printf("  Silme iptal edildi.\n");
    }
    return true;
}

static bool islem_transkript(const Sinif *s)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    int i = kayit_sor(s);
    if (i < 0) {
        return i == -2;
    }
    transkript_yaz(&s->kayit[i]);
    return true;
}

/* Kaydeder ve sonucu yazar; başarılıysa değişiklik bayrağını indirir. */
static bool kaydet(const char *yol, const Sinif *s, bool *degisti)
{
    DosyaDurumu d = sinif_kaydet(yol, s);
    if (d == DOSYA_TASIMA_HATASI) {
        fprintf(stderr, "  Hata: %s yerine konamadı; yeni veri %s.tmp dosyasında.\n",
                yol, yol);
        return false;
    }
    if (d != DOSYA_TAMAM) {
        fprintf(stderr, "  Hata: %s kaydedilemedi: %s\n", yol, dosya_durumu_metni(d));
        return false;
    }
    printf("  Kaydedildi: %d kayıt → %s\n", s->n, yol);
    *degisti = false;
    return true;
}

/* Veri dosyasını yükler ve sonucu yazar. Dosya yoksa boş sınıfla başlanır;
 * dosya bozuksa false döner ve program BAŞLAMAZ. */
static bool veriyi_yukle(const char *yol, Sinif *s)
{
    int hatali_satir = 0;
    DosyaDurumu d = sinif_yukle(yol, s, &hatali_satir);
    if (d == DOSYA_YOK) {
        printf("Yeni veri dosyası: %s (ilk kayıtta oluşturulacak)\n", yol);
        return true;
    }
    if (d != DOSYA_TAMAM) {
        fprintf(stderr, "Hata: %s okunamadı: %s", yol, dosya_durumu_metni(d));
        if (hatali_satir > 0) {
            fprintf(stderr, " (satır %d)", hatali_satir);
        }
        fprintf(stderr, "\n");
        return false;
    }
    printf("Yüklendi: %d kayıt (%s)\n", s->n, yol);
    return true;
}

/* Seçilen menü işlemini yapar. Girdi biterse (EOF) false döndürür.
 * *hata: son kaydetme denemesi başarısız olduysa true. */
static bool islem_yap(MenuSecimi secim, const char *yol, Sinif *s,
                      bool *degisti, bool *hata)
{
    switch (secim) {
    case MENU_EKLE:         return islem_ekle(s, degisti);
    case MENU_LISTELE:      kayitlari_listele(s);                  break;
    case MENU_ARA:          return islem_ara(s);
    case MENU_GUNCELLE:     return islem_guncelle(s, degisti);
    case MENU_SIL:          return islem_sil(s, degisti);
    case MENU_ISTATISTIK:   ders_istatistikleri_yaz(s);            break;
    case MENU_TRANSKRIPT:   return islem_transkript(s);
    case MENU_HARF_TABLOSU: harf_tablosu_yaz(s);                   break;
    case MENU_KAYDET:       *hata = !kaydet(yol, s, degisti);      break;
    case MENU_CIKIS:
        if (*degisti) {
            int yanit = evet_mi_oku("Değişiklikler kaydedilsin mi? (E/H) : ");
            if (yanit == -1) {
                return false;
            }
            if (yanit == 1) {
                *hata = !kaydet(yol, s, degisti);
            }
        }
        break;
    }
    return true;
}

int main(int argc, char *argv[])
{
    const char *yol = (argc > 1) ? argv[1] : VARSAYILAN_DOSYA;
    if (argc > 2 || dosya_turu(yol) == DOSYA_BILINMIYOR) {
        fprintf(stderr, "Kullanım: %s [veri_dosyasi.csv | veri_dosyasi.dat]\n", argv[0]);
        return 2;
    }

    Sinif sinif;
    sinif_baslat(&sinif);
    baslik_yaz();
    if (!veriyi_yukle(yol, &sinif)) {
        return 1;                       /* sinif boş: bırakılacak bellek yok */
    }

    bool degisti = false;
    bool devam = true;                  /* false: girdi bitti (EOF) */
    bool hata = false;                  /* son kaydetme başarısız oldu */
    int secim = 0;
    do {
        menu_goster(yol, sinif.n, degisti);
        secim = secim_oku("Seçiminiz (1-10) : ", MENU_EKLE, MENU_CIKIS);
        if (secim == -1) {
            devam = false;
        } else {
            devam = islem_yap((MenuSecimi)secim, yol, &sinif, &degisti, &hata);
        }
    } while (secim != MENU_CIKIS && devam);

    if (!devam) {
        printf("\nGirdi sona erdi.%s\n",
               degisti ? " Kaydedilmemiş değişiklikler kaydedilmedi." : "");
    } else {
        printf("Çıkış: %d öğrenci kaydı. Hoşça kalın.\n", sinif.n);
    }
    sinif_birak(&sinif);                /* TEK temizlik yolu */
    return (!devam || hata) ? 1 : 0;
}

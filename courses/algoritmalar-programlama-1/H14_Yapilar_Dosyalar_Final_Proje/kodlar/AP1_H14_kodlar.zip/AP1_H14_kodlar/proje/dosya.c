/* dosya.c — Mini-OBS v1.0 (AP-1 Hafta 14): kalıcı saklama (CSV ve ikili)
 * Okuma döngüleri DOĞRU örüntüyü kullanır: while (fgets(...) != NULL) ve
 * fread'in dönüş değeri. while (!feof(f)) KULLANILMAZ: feof ancak bir okuma
 * dosya sonuna çarptıktan SONRA doğru olur; döngü son kaydı iki kez işler.
 * Dosyadan gelen veri GÜVENİLMEZ girdidir: her alan, girdi fonksiyonlarıyla
 * aynı kurallarla denetlenir (tamsayi_coz, ondalik_coz, ad_gecerli_mi,
 * ogrenci_gecerli_mi); bozuk dosya hiçbir zaman yarım yüklenmez.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g -c dosya.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>   /* strlen, strchr, strrchr, strcmp, strncmp, memcmp */
#include <stdint.h>   /* int32_t: diskte boyutu sabit tamsayı */
#include <errno.h>    /* errno, ENOENT */
#include "dosya.h"
#include "metin.h"

#define CSV_SATIR_BOYUT 512
#define CSV_ALAN_SAYISI (3 + 2 * DERS_SAYISI)   /* no;ad;soyad + vize;final × 3 */

static const char UTF8_BOM[] = "\xEF\xBB\xBF";   /* dosya başı imzası */
static const char IKILI_IMZA[4] = { 'M', 'O', 'B', 'S' };
static const int32_t IKILI_SURUM = 1;

/* Son koşul: ".csv" → DOSYA_CSV, ".dat" → DOSYA_IKILI, aksi → BILINMIYOR.
 * strrchr SON noktayı bulur: "yedek.2026.csv" → ".csv". */
DosyaTuru dosya_turu(const char *yol)
{
    const char *nokta = strrchr(yol, '.');
    if (nokta == NULL) {
        return DOSYA_BILINMIYOR;
    }
    if (strcmp(nokta, ".csv") == 0) {
        return DOSYA_CSV;
    }
    if (strcmp(nokta, ".dat") == 0) {
        return DOSYA_IKILI;
    }
    return DOSYA_BILINMIYOR;
}

const char *dosya_durumu_metni(DosyaDurumu d)
{
    switch (d) {
    case DOSYA_TAMAM:           return "tamam";
    case DOSYA_YOK:             return "dosya bulunamadı";
    case DOSYA_ACILAMADI:       return "dosya açılamadı";
    case DOSYA_BICIM_HATASI:    return "dosya biçimi hatalı";
    case DOSYA_BELLEK_YETERSIZ: return "bellek yetersiz";
    case DOSYA_OKUMA_HATASI:    return "okuma hatası";
    case DOSYA_YAZMA_HATASI:    return "yazma hatası";
    case DOSYA_TASIMA_HATASI:   return "yeni dosya yerine konamadı";
    }
    return "bilinmeyen durum";
}

/* ---------------------------- CSV (metin) ---------------------------- */

/* Son koşul: başlık + her öğrenci için bir satır yazılır. Notlar %.15g ile
 * yazılır: en çok 15 anlamlı basamaklı (DBL_DIG) ondalık bir değer okuma–
 * yazma döngüsünde birebir korunur (85.5 → "85.5", 70 → "70"); daha uzun
 * değerler (ör. 0.1 + 0.2 = 0.30000000000000004) 15 basamağa yuvarlanır. */
DosyaDurumu csv_yaz(FILE *f, const Sinif *s)
{
    fprintf(f, "no;ad;soyad");
    for (int d = 0; d < DERS_SAYISI; d++) {
        fprintf(f, ";%s_vize;%s_final", ders_kodu(d), ders_kodu(d));
    }
    fprintf(f, "\n");
    for (int i = 0; i < s->n; i++) {
        const Ogrenci *o = &s->kayit[i];
        fprintf(f, "%lld;%s;%s", o->no, o->ad, o->soyad);
        for (int d = 0; d < DERS_SAYISI; d++) {
            fprintf(f, ";%.15g;%.15g", o->ders[d].vize, o->ders[d].final);
        }
        fprintf(f, "\n");
    }
    return ferror(f) ? DOSYA_YAZMA_HATASI : DOSYA_TAMAM;
}

/* satir'ı ';' noktalarında böler: her ';' yerine '\0' yazar ve alanların
 * başlangıç adreslerini alanlar[]'a koyar. Boş alanlar da sayılır ("a;;b" →
 * 3 alan); strtok ise ardışık ayırıcıları tek sayar ve boş alanı yutar.
 * Son koşul: alan sayısı; azami'den fazlaysa azami + 1. */
static int alanlara_bol(char *satir, char *alanlar[], int azami)
{
    int sayi = 0;
    char *p = satir;
    for (;;) {
        if (sayi == azami) {
            return azami + 1;                  /* fazladan alan var */
        }
        alanlar[sayi++] = p;
        char *ayrac = strchr(p, ';');
        if (ayrac == NULL) {
            return sayi;
        }
        *ayrac = '\0';
        p = ayrac + 1;
    }
}

/* Bir veri satırını Ogrenci'ye çevirir; herhangi bir alan geçersizse false. */
static bool csv_satiri_coz(char *satir, Ogrenci *o)
{
    char *alan[CSV_ALAN_SAYISI];
    if (alanlara_bol(satir, alan, CSV_ALAN_SAYISI) != CSV_ALAN_SAYISI) {
        return false;
    }
    if (!tamsayi_coz(alan[0], &o->no) || o->no <= 0) {
        return false;
    }
    if (ad_normallestir(alan[1], o->ad, sizeof o->ad) < 1
        || ad_normallestir(alan[2], o->soyad, sizeof o->soyad) < 1) {
        return false;                          /* boş ya da sığmayan ad */
    }
    for (int d = 0; d < DERS_SAYISI; d++) {
        double v, f;
        if (!ondalik_coz(alan[3 + 2 * d], &v) || !ondalik_coz(alan[4 + 2 * d], &f)) {
            return false;
        }
        ders_notu_ata(&o->ders[d], v, f);
    }
    return ogrenci_gecerli_mi(o);              /* ad karakterleri, not aralığı */
}

/* Son koşul: dosyadaki bütün kayıtlar s'ye eklenir ve DOSYA_TAMAM döner.
 *            İlk satır "no;" ile başlıyorsa başlıktır; boş satırlar atlanır.
 *            Bozuk ya da mükerrer numaralı satırda okuma DURUR,
 *            *hatali_satir o satırın numarasıdır (1'den başlar). */
DosyaDurumu csv_oku(FILE *f, Sinif *s, int *hatali_satir)
{
    char satir[CSV_SATIR_BOYUT];
    int satir_no = 0;
    *hatali_satir = 0;
    while (fgets(satir, sizeof satir, f) != NULL) {
        satir_no++;
        size_t uzunluk = strlen(satir);
        if (uzunluk > 0 && satir[uzunluk - 1] == '\n') {
            satir[--uzunluk] = '\0';
        } else if (!feof(f)) {                 /* satır tampona sığmadı */
            *hatali_satir = satir_no;
            return DOSYA_BICIM_HATASI;
        }
        if (uzunluk > 0 && satir[uzunluk - 1] == '\r') {
            satir[--uzunluk] = '\0';           /* Windows'ta yazılmış dosya */
        }
        char *veri = satir;
        if (satir_no == 1 && strncmp(veri, UTF8_BOM, 3) == 0) {
            veri += 3;                         /* Excel "CSV UTF-8" imzası */
        }
        if (veri[0] == '\0' || (satir_no == 1 && strncmp(veri, "no;", 3) == 0)) {
            continue;                          /* boş satır ya da başlık */
        }
        Ogrenci o = {0};
        if (!csv_satiri_coz(veri, &o) || sinif_numara_bul(s, o.no) != -1) {
            *hatali_satir = satir_no;
            return DOSYA_BICIM_HATASI;
        }
        if (!sinif_ekle(s, &o)) {
            return DOSYA_BELLEK_YETERSIZ;
        }
    }
    return ferror(f) ? DOSYA_OKUMA_HATASI : DOSYA_TAMAM;
}

/* ---------------------------- İkili ---------------------------- */

/* Son koşul: 16 baytlık başlık ve n tane Ogrenci yazılır. Kayıtlar yazılmadan
 * önce sıfırla başlatıldığı için (Ogrenci o = {0}) adların '\0'dan sonraki
 * baytları çöp değil sıfırdır: dosyaya bellekten artık veri sızmaz. */
DosyaDurumu ikili_yaz(FILE *f, const Sinif *s)
{
    int32_t boyut = (int32_t)sizeof(Ogrenci);
    int32_t sayi = s->n;
    if (fwrite(IKILI_IMZA, 1, sizeof IKILI_IMZA, f) != sizeof IKILI_IMZA
        || fwrite(&IKILI_SURUM, sizeof IKILI_SURUM, 1, f) != 1
        || fwrite(&boyut, sizeof boyut, 1, f) != 1
        || fwrite(&sayi, sizeof sayi, 1, f) != 1) {
        return DOSYA_YAZMA_HATASI;
    }
    if (s->n > 0 && fwrite(s->kayit, sizeof *s->kayit, (size_t)s->n, f) != (size_t)s->n) {
        return DOSYA_YAZMA_HATASI;
    }
    return DOSYA_TAMAM;
}

/* Son koşul: başlık denetlenir (imza, sürüm, bu derleyicideki sizeof(Ogrenci),
 *            sayı >= 0); kayıtlar TEK TEK okunur ve doğrulanır. Dosyadaki
 *            sayıya güvenip tek seferde dev bir blok ayrılmaz: kesik ya da
 *            kötü niyetli bir dosya bellek tüketemez. Kayıtlardan sonra
 *            fazladan bayt varsa da biçim hatasıdır. */
DosyaDurumu ikili_oku(FILE *f, Sinif *s)
{
    char imza[sizeof IKILI_IMZA];
    int32_t surum, boyut, sayi;
    if (fread(imza, 1, sizeof imza, f) != sizeof imza
        || memcmp(imza, IKILI_IMZA, sizeof imza) != 0
        || fread(&surum, sizeof surum, 1, f) != 1 || surum != IKILI_SURUM
        || fread(&boyut, sizeof boyut, 1, f) != 1
        || boyut != (int32_t)sizeof(Ogrenci)
        || fread(&sayi, sizeof sayi, 1, f) != 1 || sayi < 0) {
        return ferror(f) ? DOSYA_OKUMA_HATASI : DOSYA_BICIM_HATASI;
    }
    for (int32_t i = 0; i < sayi; i++) {
        Ogrenci o;
        if (fread(&o, sizeof o, 1, f) != 1) {
            return ferror(f) ? DOSYA_OKUMA_HATASI : DOSYA_BICIM_HATASI;
        }
        if (!ogrenci_gecerli_mi(&o) || sinif_numara_bul(s, o.no) != -1) {
            return DOSYA_BICIM_HATASI;
        }
        for (int d = 0; d < DERS_SAYISI; d++) {   /* ort'a güvenme: yeniden hesapla */
            ders_notu_ata(&o.ders[d], o.ders[d].vize, o.ders[d].final);
        }
        if (!sinif_ekle(s, &o)) {
            return DOSYA_BELLEK_YETERSIZ;
        }
    }
    if (fgetc(f) != EOF) {
        return DOSYA_BICIM_HATASI;              /* kayıtlardan sonra artık bayt */
    }
    return ferror(f) ? DOSYA_OKUMA_HATASI : DOSYA_TAMAM;
}

/* ---------------------------- Dosya yolu ile ---------------------------- */

/* Son koşul: DOSYA_TAMAM → s, dosyadaki kayıtlarla DEĞİŞTİRİLİR (eski içerik
 *            bırakılır); DOSYA_YOK → dosya yok (ilk çalıştırma), s değişmez;
 *            diğer durumlarda s DEĞİŞMEZ: kayıtlar önce geçici bir sınıfa
 *            okunur, yalnızca hepsi geçerliyse s'ye taşınır.
 * errno: fopen başarısız olunca nedeni errno'ya yazar (POSIX ve Windows
 * CRT; C standardı bunu zorunlu tutmaz). ENOENT: "böyle bir dosya yok". */
DosyaDurumu sinif_yukle(const char *yol, Sinif *s, int *hatali_satir)
{
    *hatali_satir = 0;
    DosyaTuru tur = dosya_turu(yol);
    if (tur == DOSYA_BILINMIYOR) {
        return DOSYA_BICIM_HATASI;
    }
    errno = 0;
    FILE *f = fopen(yol, tur == DOSYA_CSV ? "r" : "rb");
    if (f == NULL) {
        return (errno == ENOENT) ? DOSYA_YOK : DOSYA_ACILAMADI;
    }
    Sinif gecici;
    sinif_baslat(&gecici);
    DosyaDurumu d = (tur == DOSYA_CSV) ? csv_oku(f, &gecici, hatali_satir)
                                       : ikili_oku(f, &gecici);
    fclose(f);                                  /* yalnızca okuduk */
    if (d != DOSYA_TAMAM) {
        sinif_birak(&gecici);
        return d;
    }
    sinif_birak(s);
    *s = gecici;          /* yapı ataması: işaretçi, n ve kapasite birlikte */
    return DOSYA_TAMAM;
}

/* Son koşul: s, yol'a uzantısının biçiminde yazılır. Önce "<yol>.tmp"
 *            dosyasına yazılır; fclose da başarılıysa (tamponda kalan veri
 *            ancak fclose/fflush ile diske iner) eski dosyanın yerine geçer.
 *            Yazma hatasında eski dosya olduğu gibi kalır. Yeni dosya yerine
 *            konamazsa DOSYA_TASIMA_HATASI döner ve yeni veri "<yol>.tmp"
 *            dosyasında KORUNUR (hiçbir durumda iki kopya birden silinmez). */
DosyaDurumu sinif_kaydet(const char *yol, const Sinif *s)
{
    DosyaTuru tur = dosya_turu(yol);
    if (tur == DOSYA_BILINMIYOR) {
        return DOSYA_BICIM_HATASI;
    }
    char gecici[FILENAME_MAX];
    int uzunluk = snprintf(gecici, sizeof gecici, "%s.tmp", yol);
    if (uzunluk < 0 || (size_t)uzunluk >= sizeof gecici) {
        return DOSYA_ACILAMADI;                 /* yol çok uzun */
    }
    FILE *f = fopen(gecici, tur == DOSYA_CSV ? "w" : "wb");
    if (f == NULL) {
        return DOSYA_ACILAMADI;
    }
    DosyaDurumu d = (tur == DOSYA_CSV) ? csv_yaz(f, s) : ikili_yaz(f, s);
    if (fclose(f) != 0 && d == DOSYA_TAMAM) {
        d = DOSYA_YAZMA_HATASI;                 /* tampon diske yazılamadı */
    }
    if (d != DOSYA_TAMAM) {
        remove(gecici);
        return d;
    }
    if (rename(gecici, yol) != 0) {
        /* C standardında hedef varken rename'in davranışı uygulamaya
         * bağlıdır: POSIX'te hedefin yerine geçer, Windows'ta başarısız
         * olur. Bu durumda eski dosyayı silip yeniden deneriz. İkinci
         * deneme de başarısızsa .tmp SİLİNMEZ: yeni veri orada kalır. */
        remove(yol);
        if (rename(gecici, yol) != 0) {
            return DOSYA_TASIMA_HATASI;
        }
    }
    return DOSYA_TAMAM;
}

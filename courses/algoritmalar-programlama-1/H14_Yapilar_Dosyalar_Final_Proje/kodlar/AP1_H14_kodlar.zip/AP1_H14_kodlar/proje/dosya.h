/* dosya.h — Mini-OBS v1.0 (AP-1 Hafta 14): kalıcı saklama
 * İki biçim, dosya uzantısına göre seçilir:
 *   .csv → METİN: bir başlık satırı + öğrenci başına bir satır, alanlar ';'
 *          ile ayrılır (Türkçe Excel'in liste ayırıcısı; ondalık ayırıcı
 *          nokta). İnsan okuyabilir, Excel'de açılır, makineden makineye
 *          taşınır.
 *   .dat → İKİLİ: 16 baytlık başlık (imza "MOBS", sürüm, kayıt boyutu,
 *          kayıt sayısı) + Ogrenci yapıları bellekteki gibi (fwrite).
 *          Hızlı ve kayıpsız, ancak TAŞINABİLİR DEĞİL: dolgu, bayt sırası,
 *          double biçimi ve sizeof derleyiciye/makineye bağlıdır.
 * Kaydetme önce "<yol>.tmp" dosyasına yazar, başarılıysa adını değiştirir:
 * yazma yarıda kalırsa eski veri dosyası bozulmaz; yeni dosya yerine
 * konamazsa (DOSYA_TASIMA_HATASI) yeni veri "<yol>.tmp" dosyasında kalır.
 * CSV okuyucu, Excel'in "CSV UTF-8" biçimindeki dosya başı imzasını (BOM:
 * EF BB BF baytları) atlar.
 */
#ifndef DOSYA_H
#define DOSYA_H

#include <stdio.h>
#include "obs.h"

typedef enum {
    DOSYA_CSV,
    DOSYA_IKILI,
    DOSYA_BILINMIYOR
} DosyaTuru;

typedef enum {
    DOSYA_TAMAM = 0,
    DOSYA_YOK,              /* dosya bulunamadı (ilk çalıştırma) */
    DOSYA_ACILAMADI,        /* izin, klasör yok vb. */
    DOSYA_BICIM_HATASI,     /* bozuk satır, eksik alan, geçersiz kayıt */
    DOSYA_BELLEK_YETERSIZ,
    DOSYA_OKUMA_HATASI,
    DOSYA_YAZMA_HATASI,     /* disk dolu, fclose başarısız vb. */
    DOSYA_TASIMA_HATASI     /* yeni veri yazıldı ama yerine konamadı: <yol>.tmp */
} DosyaDurumu;

DosyaTuru dosya_turu(const char *yol);
const char *dosya_durumu_metni(DosyaDurumu d);

/* Açık bir akış üzerinde (testlerde tmpfile ile de kullanılır) */
DosyaDurumu csv_yaz(FILE *f, const Sinif *s);
DosyaDurumu csv_oku(FILE *f, Sinif *s, int *hatali_satir);
DosyaDurumu ikili_yaz(FILE *f, const Sinif *s);
DosyaDurumu ikili_oku(FILE *f, Sinif *s);

/* Dosya yolu ile: biçimi uzantı seçer */
DosyaDurumu sinif_yukle(const char *yol, Sinif *s, int *hatali_satir);
DosyaDurumu sinif_kaydet(const char *yol, const Sinif *s);

#endif /* DOSYA_H */

/* obs.c — Mini-OBS v1.0 (AP-1 Hafta 14): kayıt tipleri üzerinde iş kuralları
 * Yenilik : Paralel bloklar yerine yapı dizisi (Sinif → Ogrenci → DersNotu).
 *           Büyütme tek realloc (sinif_ekle), silme kaydırarak (sinif_sil),
 *           arama doğrusal (sinif_numara_bul, sinif_isim_bul), istatistik ve
 *           raporlar const Sinif * / const Ogrenci * alır.
 *           Hesap kuralları ve rapor biçimleri v0.13 ile AYNIDIR.
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107): Madde 25/2 ve 26/2: %40 ara sınav +
 *           %60 yarıyıl sonu sınavı; yarıyıl sonundan 50 alamayan FF.
 *           Madde 30/3: AA 90-100, BA 81-89, BB 73-80, CB 66-72, CC 60-65
 *           başarılı; DC 50-59 şartlı; DD 40-49, FD 30-39, FF 0-29
 *           başarısız. Katsayılar AA 4,0 · BA 3,5 · BB 3,0 · CB 2,5 ·
 *           CC 2,0 · DC 1,5 · DD 1,0 · FD 0,5 · FF 0,0. Madde 30/4-b: YANO
 *           en az 2,00 ise DC başarılı sayılır. Madde 31/2-a: not ortalaması
 *           = Σ(kredi × katsayı) / Σ kredi (kredi: dersin ulusal kredisi,
 *           Madde 4); YANO virgülden sonra iki haneye yuvarlanır (üçüncü
 *           hane >= 5 ise yukarı). Ders ortalaması: (int)(ort + 0.5). Ders
 *           adları ve kredileri ÖRNEKTİR (ders içi modelleme).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c   (bağlarken -lm)
 */
#include <stdio.h>
#include <stdlib.h>   /* malloc, realloc, free */
#include <string.h>   /* strcmp, memchr */
#include <limits.h>   /* INT_MAX */
#include <math.h>     /* sqrt */
#include "obs.h"
#include "metin.h"    /* ad_gecerli_mi, hizali_yaz */

/* ---- Kurallar: dosya kapsamında static const (yalnızca bu modül) ---- */
static const double VIZE_AGIRLIK = 0.40;
static const double FINAL_AGIRLIK = 0.60;
static const int GECME_ORTALAMA = 60;        /* CC ve üzeri: başarılı */
static const int SARTLI_ORTALAMA = 50;       /* DC: şartlı başarılı */
static const int FINAL_BARAJI = 50;          /* yarıyıl sonu sınavında en az 50 */

static const int BASLANGIC_KAPASITE = 4;    /* ilk ayırmada yer açılan kayıt */
static const int AD_SUTUNU = 24;            /* listelerde "Ad Soyad" sütunu (karakter) */

/* Ön koşul : 0 <= vize, final <= 100.  Son koşul: %40 + %60 ağırlıklı ortalama. */
double hesapla_ortalama(double vize, double final)
{
    return VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
}

/* Ön koşul : ortalama >= 0.  Son koşul: en yakın tamsayı (.5 yukarı). */
int yuvarla(double ortalama)
{
    return (int)(ortalama + 0.5);
}

/* Son koşul: RTEÜ tablosuna göre harf notu; final barajın altındaysa "FF". */
const char *harf_notu(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "FF";
    } else if (yuvarlanmis >= 90) {
        return "AA";
    } else if (yuvarlanmis >= 81) {
        return "BA";
    } else if (yuvarlanmis >= 73) {
        return "BB";
    } else if (yuvarlanmis >= 66) {
        return "CB";
    } else if (yuvarlanmis >= 60) {
        return "CC";
    } else if (yuvarlanmis >= 50) {
        return "DC";
    } else if (yuvarlanmis >= 40) {
        return "DD";
    } else if (yuvarlanmis >= 30) {
        return "FD";
    }
    return "FF";
}

/* Son koşul: CC ve üzeri ve final barajı aşıldıysa true. */
bool gecti_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= GECME_ORTALAMA;
}

/* Son koşul: DC (50-59) ve final barajı aşıldıysa true. */
bool sartli_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= SARTLI_ORTALAMA
           && yuvarlanmis < GECME_ORTALAMA;
}

/* Son koşul: rapordaki "Durum" satırının metni. */
const char *durum_metni(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "BAŞARISIZ (final barajı)";
    } else if (gecti_mi(yuvarlanmis, final)) {
        return "BAŞARILI";
    } else if (sartli_mi(yuvarlanmis, final)) {
        return "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)";
    }
    return "BAŞARISIZ";
}

/* Son koşul: harf notunun frekans dizisindeki indisi (AA=0 ... FF=8).
 * harf_notu() ile aynı merdiven; sayaç dizisinde "değer = indis". */
int harf_indeksi(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return 8;                                /* FF (baraj) */
    } else if (yuvarlanmis >= 90) {
        return 0;
    } else if (yuvarlanmis >= 81) {
        return 1;
    } else if (yuvarlanmis >= 73) {
        return 2;
    } else if (yuvarlanmis >= 66) {
        return 3;
    } else if (yuvarlanmis >= 60) {
        return 4;
    } else if (yuvarlanmis >= 50) {
        return 5;
    } else if (yuvarlanmis >= 40) {
        return 6;
    } else if (yuvarlanmis >= 30) {
        return 7;
    }
    return 8;
}

/* Ön koşul: 0 <= indeks < HARF_SAYISI.  Son koşul: harfin adı. */
const char *harf_adi(int indeks)
{
    switch (indeks) {
    case 0: return "AA";
    case 1: return "BA";
    case 2: return "BB";
    case 3: return "CB";
    case 4: return "CC";
    case 5: return "DC";
    case 6: return "DD";
    case 7: return "FD";
    default: return "FF";
    }
}

/* Ön koşul: 0 <= indeks < HARF_SAYISI.  Son koşul: harfin katsayısı
 * (AA=0 → 4,00; her kademe 0,50 azalır; FF=8 → 0,00). */
double harf_katsayisi(int indeks)
{
    return 4.0 - 0.5 * indeks;
}

/* Ders bilgileri (ÖRNEK değerler; gerçek ders planına göre değiştirilir). */
const char *ders_adi(int d)
{
    switch (d) {
    case 0: return "Algoritma ve Prog. I";
    case 1: return "Matematik I";
    default: return "Fizik I";
    }
}

const char *ders_kodu(int d)
{
    switch (d) {
    case 0: return "ALG";
    case 1: return "MAT";
    default: return "FIZ";
    }
}

int ders_kredisi(int d)
{
    switch (d) {
    case 0: return 6;
    case 1: return 6;
    default: return 5;
    }
}

/* Ön koşul: n >= 1.  Son koşul: a[0..n-1] ortalaması. */
double dizi_ortalama(const double a[], int n)
{
    double toplam = 0.0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
    }
    return toplam / n;
}

/* Ön koşul: n >= 1.  Son koşul: popülasyon standart sapması
 * sqrt( Σ (a[i] - μ)² / n ). İki geçiş: önce μ, sonra sapmalar. */
double standart_sapma(const double a[], int n)
{
    double mu = dizi_ortalama(a, n);
    double kare_toplam = 0.0;
    for (int i = 0; i < n; i++) {
        double fark = a[i] - mu;
        kare_toplam += fark * fark;
    }
    return sqrt(kare_toplam / n);
}

/* Ön koşul : n >= 1; enk ve enb geçerli adreslerdir.
 * Son koşul: *enk ve *enb, en küçük ve en büyük elemanın İLK indisleri
 *            (tek geçişte; en_kucuk_indis ve en_buyuk_indis ile aynı sonuç). */
void min_max_indis(const double a[], int n, int *enk, int *enb)
{
    *enk = 0;
    *enb = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] < a[*enk]) {
            *enk = i;
        }
        if (a[i] > a[*enb]) {
            *enb = i;
        }
    }
}

/* Ön koşul : 0 <= vize, final <= 100.
 * Son koşul: dersin notları atanır ve ortalaması yeniden hesaplanır.
 * ort, vize ve finalden TÜRETİLİR: notları tek bu fonksiyondan değiştirmek
 * üçünün tutarsız kalmasını önler. */
void ders_notu_ata(DersNotu *dn, double vize, double final)
{
    dn->vize = vize;
    dn->final = final;
    dn->ort = hesapla_ortalama(vize, final);
}

/* Son koşul: dersin harf notu indisi (AA=0 ... FF=8). */
int ders_harfi(const DersNotu *dn)
{
    return harf_indeksi(yuvarla(dn->ort), dn->final);
}

/* Son koşul: kredi ağırlıklı yarıyıl not ortalaması (YANO), Madde 31/2-a'ya
 * göre iki haneye yuvarlanmış (üçüncü hane >= 5 ise yukarı). Kayan nokta
 * hatası olmasın diye tamsayıyla: s = Σ kredi × (katsayı × 100), K = Σ kredi;
 * yuvarlanmış YANO × 100 = (2s + K) / (2K). */
double ogrenci_yano(const Ogrenci *o)
{
    int s = 0, toplam_kredi = 0;
    for (int d = 0; d < DERS_SAYISI; d++) {
        int katsayi100 = (int)(harf_katsayisi(ders_harfi(&o->ders[d])) * 100.0 + 0.5);
        s += ders_kredisi(d) * katsayi100;
        toplam_kredi += ders_kredisi(d);
    }
    int yano100 = (2 * s + toplam_kredi) / (2 * toplam_kredi);
    return yano100 / 100.0;
}

/* Son koşul: kayıt dosyadan okunmuş olsa bile güvenle kullanılabilirse
 * true: numara pozitif, ad ve soyad dizinin İÇİNDE '\0' ile bitiyor ve
 * geçerli, bütün notlar 0-100 aralığında (NaN da reddedilir). */
bool ogrenci_gecerli_mi(const Ogrenci *o)
{
    if (o->no <= 0) {
        return false;
    }
    if (memchr(o->ad, '\0', sizeof o->ad) == NULL
        || memchr(o->soyad, '\0', sizeof o->soyad) == NULL) {
        return false;                      /* sonlandırıcısız dizi: strlen taşar */
    }
    if (!ad_gecerli_mi(o->ad) || !ad_gecerli_mi(o->soyad)) {
        return false;
    }
    for (int d = 0; d < DERS_SAYISI; d++) {
        double v = o->ders[d].vize, f = o->ders[d].final;
        if (!(v >= 0 && v <= 100) || !(f >= 0 && f <= 100)) {
            return false;
        }
    }
    return true;
}

/* Son koşul: boş bir sınıf (henüz bellek ayrılmamış). */
void sinif_baslat(Sinif *s)
{
    s->kayit = NULL;
    s->n = 0;
    s->kapasite = 0;
}

/* Ön koşul : o geçerli bir kayıttır.
 * Son koşul: kayıt sona KOPYALANIR (yapı ataması) ve true döner; dizi
 *            doluysa önce tek bir realloc ile büyütülür (0 → 4 → 8 → 16 …).
 *            Bellek ayrılamazsa sınıf DEĞİŞMEDEN kalır ve false döner. */
bool sinif_ekle(Sinif *s, const Ogrenci *o)
{
    if (s->n == s->kapasite) {
        if (s->kapasite > INT_MAX / 2) {
            return false;                       /* 2 × kapasite taşar */
        }
        int yeni = (s->kapasite == 0) ? BASLANGIC_KAPASITE : 2 * s->kapasite;
        Ogrenci *g = realloc(s->kayit, (size_t)yeni * sizeof *g);
        if (g == NULL) {
            return false;                       /* eski dizi yerinde, geçerli */
        }
        s->kayit = g;
        s->kapasite = yeni;
    }
    s->kayit[s->n] = *o;        /* bütün üyeler (diziler dahil) kopyalanır */
    s->n++;
    return true;
}

/* Son koşul: indis geçerliyse kayıt silinir, sonrakiler birer sola
 * kaydırılır (sıra korunur; H10'daki silme deseni) ve true döner. */
bool sinif_sil(Sinif *s, int indis)
{
    if (indis < 0 || indis >= s->n) {
        return false;
    }
    for (int i = indis; i < s->n - 1; i++) {
        s->kayit[i] = s->kayit[i + 1];
    }
    s->n--;
    return true;
}

/* TEK temizlik yolu: yapı dizisini bırakır ve sınıfı boşaltır
 * (bırakılmış adresi tutan sarkan işaretçi kalmaz). */
void sinif_birak(Sinif *s)
{
    free(s->kayit);
    sinif_baslat(s);
}

/* Doğrusal tarama: numaranın indisi; yoksa -1. */
int sinif_numara_bul(const Sinif *s, long long no)
{
    for (int i = 0; i < s->n; i++) {
        if (s->kayit[i].no == no) {
            return i;
        }
    }
    return -1;
}

/* Ön koşul : aranan normalleştirilmiştir; 0 <= baslangic.
 * Son koşul: baslangic'tan itibaren adı, soyadı ya da "AD SOYAD" tam adı
 *            arananla AYNI olan ilk kaydın indisi; yoksa -1 (v0.13'teki
 *            isim_bul'un yapı dizisi sürümü). */
int sinif_isim_bul(const Sinif *s, const char *aranan, int baslangic)
{
    char tam_ad[AD_BOYUT + SOYAD_BOYUT];   /* 31 + ' ' + 31 + '\0' = 64 bayt */
    for (int i = baslangic; i < s->n; i++) {
        const Ogrenci *o = &s->kayit[i];
        snprintf(tam_ad, sizeof tam_ad, "%s %s", o->ad, o->soyad);
        if (strcmp(o->soyad, aranan) == 0 || strcmp(o->ad, aranan) == 0
            || strcmp(tam_ad, aranan) == 0) {
            return i;
        }
    }
    return -1;
}

/* Ön koşul : s->n >= 1; 0 <= d < DERS_SAYISI; çıktı işaretçileri geçerli.
 * Son koşul: d. dersin ortalaması, standart sapması, en yüksek ve en düşük
 *            ortalamalı öğrencinin İNDİSİ, başarılı ve şartlı öğrenci sayısı
 *            çıktı parametrelerine yazılır; true döner. Kayıt yoksa ya da
 *            geçici dizi için bellek ayrılamazsa false. */
bool ders_istatistigi(const Sinif *s, int d, double *ortalama, double *sapma,
                      int *enb, int *enk, int *basarili, int *sartli)
{
    if (s->n < 1) {
        return false;                           /* ön koşul: en az bir kayıt */
    }
    double *sutun = calloc((size_t)s->n, sizeof *sutun);   /* sıfırlanmış */
    if (sutun == NULL) {
        return false;
    }
    *basarili = 0;
    *sartli = 0;
    for (int i = 0; i < s->n; i++) {
        const DersNotu *dn = &s->kayit[i].ders[d];
        sutun[i] = dn->ort;
        int y = yuvarla(dn->ort);
        if (gecti_mi(y, dn->final)) {
            (*basarili)++;
        } else if (sartli_mi(y, dn->final)) {
            (*sartli)++;
        }
    }
    *ortalama = dizi_ortalama(sutun, s->n);
    *sapma = standart_sapma(sutun, s->n);
    min_max_indis(sutun, s->n, enk, enb);
    free(sutun);
    return true;
}

/* Son koşul: sayac[d][k] = d. derste k. harfi alan öğrenci sayısı. */
void ders_harf_dagilimi(const Sinif *s, int sayac[DERS_SAYISI][HARF_SAYISI])
{
    for (int d = 0; d < DERS_SAYISI; d++) {
        for (int k = 0; k < HARF_SAYISI; k++) {
            sayac[d][k] = 0;
        }
    }
    for (int i = 0; i < s->n; i++) {
        for (int d = 0; d < DERS_SAYISI; d++) {
            sayac[d][ders_harfi(&s->kayit[i].ders[d])]++;
        }
    }
}

/* Ekrana program başlığını yazar. */
void baslik_yaz(void)
{
    printf("==========================================\n");
    printf("  MİNİ-OBS v1.0 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");
}

/* Ana menüyü, dosya adını, kayıt sayısını ve kaydedilmemiş değişiklik
 * olup olmadığını yazar. */
void menu_goster(const char *dosya_yolu, int kayit_sayisi, bool degisti)
{
    printf("\n---------------- ANA MENÜ ----------------\n");
    printf("Dosya: %s · Kayıt: %d%s\n", dosya_yolu, kayit_sayisi,
           degisti ? " · kaydedilmemiş değişiklik var" : "");
    printf("   1) Öğrenci ekle\n");
    printf("   2) Kayıtları listele\n");
    printf("   3) Ara (numara ya da ad)\n");
    printf("   4) Not güncelle\n");
    printf("   5) Öğrenci sil\n");
    printf("   6) Ders istatistikleri tablosu\n");
    printf("   7) Transkript (numara ile)\n");
    printf("   8) Harf notu dağılımı (ders × harf)\n");
    printf("   9) Kaydet\n");
    printf("  10) Çıkış\n");
}

/* Bir öğrencinin ders ders kısa özeti ve YANO'su. */
void ogrenci_ozeti_yaz(const Ogrenci *o)
{
    printf("Öğrenci no  : %lld\n", o->no);
    printf("Ad Soyad    : %s %s\n", o->ad, o->soyad);
    for (int d = 0; d < DERS_SAYISI; d++) {
        const DersNotu *dn = &o->ders[d];
        int y = yuvarla(dn->ort);
        printf("%-20s  %6.2f  %s  %s\n", ders_adi(d), dn->ort,
               harf_notu(y, dn->final), durum_metni(y, dn->final));
    }
    printf("YANO        : %4.2f\n", ogrenci_yano(o));
}

/* Bir öğrencinin transkripti: ders, kredi, notlar, harf, katsayı, YANO. */
void transkript_yaz(const Ogrenci *o)
{
    bool dc_var = false;
    int toplam_kredi = 0;
    printf("\n----------------------- TRANSKRİPT -----------------------\n");
    printf("Öğrenci no : %lld\n", o->no);
    printf("Ad Soyad   : %s %s\n", o->ad, o->soyad);
    printf("Ders                  Kredi    Vize   Final    Ort.  Harf  Katsayı\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        const DersNotu *dn = &o->ders[d];
        int k = ders_harfi(dn);
        if (k == 5) {
            dc_var = true;
        }
        toplam_kredi += ders_kredisi(d);
        printf("%-20s  %5d  %6.2f  %6.2f  %6.2f    %s     %4.2f\n", ders_adi(d),
               ders_kredisi(d), dn->vize, dn->final, dn->ort, harf_adi(k),
               harf_katsayisi(k));
    }
    double yano = ogrenci_yano(o);
    printf("----------------------------------------------------------\n");
    printf("Toplam kredi : %d\n", toplam_kredi);
    printf("YANO         : %4.2f\n", yano);
    if (dc_var) {
        printf("DC notları   : %s\n", yano >= 2.0
               ? "YANO ≥ 2,00 → başarılı sayılır"
               : "YANO < 2,00 → başarısız sayılır");
    }
}

/* Her ders için ortalama, standart sapma, en yüksek, en düşük, başarılı ve
 * şartlı sayısı (biçim v0.11–v0.13 ile aynı). */
void ders_istatistikleri_yaz(const Sinif *s)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    printf("\n------------------------ DERS İSTATİSTİKLERİ ------------------------\n");
    printf("Ders                    Ort.  S.sapma  En yük.  En düş.  Başarılı  Şartlı\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        double ortalama, sapma;
        int enb, enk, basarili, sartli;
        if (!ders_istatistigi(s, d, &ortalama, &sapma, &enb, &enk,
                              &basarili, &sartli)) {
            printf("  Bellek yetersiz: %s hesaplanamadı.\n", ders_adi(d));
            continue;
        }
        printf("%-20s  %6.2f  %7.2f  %7.2f  %7.2f  %4d/%-3d  %3d/%-3d\n",
               ders_adi(d), ortalama, sapma, s->kayit[enb].ders[d].ort,
               s->kayit[enk].ders[d].ort, basarili, s->n, sartli, s->n);
    }
    printf("---------------------------------------------------------------------\n");
    printf("Öğrenci sayısı: %d\n", s->n);
}

/* Ders × harf frekans matrisini tablo olarak yazar. */
void harf_tablosu_yaz(const Sinif *s)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    int sayac[DERS_SAYISI][HARF_SAYISI];
    ders_harf_dagilimi(s, sayac);
    printf("\n-------------- HARF NOTU DAĞILIMI (ders × harf) --------------\n");
    printf("%-20s", "Ders");
    for (int k = 0; k < HARF_SAYISI; k++) {
        printf("  %s", harf_adi(k));
    }
    printf("\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("%-20s", ders_adi(d));
        for (int k = 0; k < HARF_SAYISI; k++) {
            printf("  %2d", sayac[d][k]);
        }
        printf("\n");
    }
    printf("--------------------------------------------------------------\n");
}

/* Liste ve arama sonuçlarının ortak başlığı ve tek satırı. */
static void liste_basligi_yaz(void)
{
    printf("Sıra  Öğrenci no  ");
    hizali_yaz("Ad Soyad", AD_SUTUNU);
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("  %9s", ders_kodu(d));
    }
    printf("   YANO\n");
}

static void liste_satiri_yaz(int sira, const Ogrenci *o)
{
    char tam_ad[AD_BOYUT + SOYAD_BOYUT];
    snprintf(tam_ad, sizeof tam_ad, "%s %s", o->ad, o->soyad);
    printf("%4d  %10lld  ", sira, o->no);
    hizali_yaz(tam_ad, AD_SUTUNU);
    for (int d = 0; d < DERS_SAYISI; d++) {
        const DersNotu *dn = &o->ders[d];
        printf("  %6.2f %s", dn->ort, harf_notu(yuvarla(dn->ort), dn->final));
    }
    printf("   %4.2f\n", ogrenci_yano(o));
}

/* Bütün öğrenciler: ad soyad, her dersin ortalaması ve harfi, YANO. */
void kayitlari_listele(const Sinif *s)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    printf("\n------------------------------------ KAYITLAR ------------------------------------\n");
    liste_basligi_yaz();
    for (int i = 0; i < s->n; i++) {
        liste_satiri_yaz(i + 1, &s->kayit[i]);
    }
    printf("----------------------------------------------------------------------------------\n");
}

/* Ön koşul : aranan normalleştirilmiştir.
 * Son koşul: eşleşen bütün kayıtlar ve eşleşme sayısı yazılır. */
void arama_sonucu_yaz(const Sinif *s, const char *aranan)
{
    int bulunan = 0;
    for (int i = sinif_isim_bul(s, aranan, 0); i != -1;
         i = sinif_isim_bul(s, aranan, i + 1)) {
        if (bulunan == 0) {
            printf("\n--------------------------------- ARAMA: %s\n", aranan);
            liste_basligi_yaz();
        }
        liste_satiri_yaz(i + 1, &s->kayit[i]);
        bulunan++;
    }
    if (bulunan == 0) {
        printf("  Eşleşen kayıt yok: %s\n", aranan);
    } else {
        printf("Eşleşen kayıt: %d\n", bulunan);
    }
}

/* H14_K08_akislar.c — Hafta 14 · Kavram programı: üç standart akış
 * Amaç   : Her C programı üç açık akışla başlar: stdin (klavye),
 *          stdout (normal çıktı), stderr (hata iletileri). printf,
 *          stdout'a; fprintf(stderr, ...) stderr'e yazar. Kabuk ikisini
 *          ayrı ayrı yönlendirebilir (> ve 2>). stdout uçbirimde SATIR
 *          tamponlu, dosyaya yönlendirilince TAM tamponludur; stderr
 *          tamponsuzdur: yönlendirilmiş çıktıda satırların sırası
 *          değişebilir (gerçek çalıştırmalar ciktilar/ altında).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K08_akislar.c -o akislar
 * Örnek  : -> 2. satır (stderr)
 */
#include <stdio.h>

int main(void)
{
    printf("1. satır (stdout)\n");
    fprintf(stderr, "2. satır (stderr)\n");
    fprintf(stdout, "3. satır (stdout)\n");     /* printf ile aynı */
    fputs("4. satır (stderr)\n", stderr);
    return 0;
}

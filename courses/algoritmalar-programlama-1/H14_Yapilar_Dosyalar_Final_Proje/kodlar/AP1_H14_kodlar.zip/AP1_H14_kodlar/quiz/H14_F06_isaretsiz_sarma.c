/* H14_F06_isaretsiz_sarma.c — Hafta 14 · Final hazırlık soru bankası, S6
 *          (H3 · ÖÇ 3.4 · çıktı tahmini): işaretsiz tamsayıda modüler sarma
 * Soru   : x86-64 Linux, GCC (unsigned int 32 bit, char 8 bit). Program ne
 *          yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F06_isaretsiz_sarma.c -o f06
 */
#include <stdio.h>

int main(void)
{
    unsigned int u = 0;
    unsigned char c = 250;
    u = u - 1;
    c = c + 10;
    printf("%u %d\n", u, c);
    return 0;
}

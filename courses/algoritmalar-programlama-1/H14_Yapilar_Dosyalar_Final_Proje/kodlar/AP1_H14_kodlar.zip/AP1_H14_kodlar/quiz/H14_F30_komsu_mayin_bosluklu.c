/* H14_F30_komsu_mayin_bosluklu.c — Hafta 14 · Final hazırlık soru bankası, S30
 *          (H11 · ÖÇ 11.4 · kod tamamlama): ızgarada sınır denetimi
 * Soru   : Program, mayın tarlasında (1, 0) hücresinin 8 komşusundaki
 *          mayınları ('*') saymalıdır. Boşluğa hangisi gelmelidir?
 * Kod tamamlama: TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. Boşluğa (_____) doğru
 *          seçenek yazılınca H14_F30_komsu_mayin.c elde edilir.
 */
#include <stdio.h>

#define SATIR 3
#define SUTUN 4

int main(void)
{
    char m[SATIR][SUTUN] = {
        {'*', '.', '.', '.'},
        {'.', '.', '*', '.'},
        {'*', '*', '.', '*'}
    };
    int r = 1;
    int c = 0;
    int sayi = 0;
    for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
            int nr = r + dr;
            int nc = c + dc;
            if ((dr != 0 || dc != 0)
                && _____
                && m[nr][nc] == '*') {
                sayi++;
            }
        }
    }
    printf("%d\n", sayi);
    return 0;
}

/* H14_F22_coklu_tanim_main.c — Hafta 14 · Final hazırlık soru bankası, S22
 *          (H9 · ÖÇ 9.5 · kavram): başlık dosyasında tanım: multiple
 *          definition
 * Soru   : Bir projede sayac.h (başlık koruyucusu ile) int kayit_sayisi = 0;
 *          satırını içeriyor ve bu başlık hem main.c hem sayac.c tarafından
 *          #include ediliyor. gcc main.c sayac.c -o prog ne üretir?
 * BU DOSYA KASITLI HATA İÇERİR: başlık dosyasında değişken TANIMI; iki .c
 *          dosyası da içerince bağlayıcı “multiple definition” hatası verir.
 * Kaynak: main.c'nin karşılığı.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F22_coklu_tanim_main.c H14_F22_coklu_tanim_sayac.c -o f22
 */
#include <stdio.h>
#include "H14_F22_coklu_tanim.h"

int main(void)
{
    kayit_ekle();
    printf("%d\n", kayit_sayisi);
    return 0;
}

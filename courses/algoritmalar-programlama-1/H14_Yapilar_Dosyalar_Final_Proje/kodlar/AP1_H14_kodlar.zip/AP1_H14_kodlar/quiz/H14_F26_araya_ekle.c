/* H14_F26_araya_ekle.c — Hafta 14 · Final hazırlık soru bankası, S26
 *          (H10 · ÖÇ 10.3 · Parsons): diziye araya ekleme (kaydırma)
 * Soru   : araya_ekle, dizi dolu değilse deger'i k konumuna ekleyip yeni
 *          eleman sayısını döndürmelidir ({10, 20, 30, 40, 50}, k = 2, 25 →
 *          {10, 20, 25, 30, 40, 50}). Fonksiyon gövdesinin parçaları karışık
 *          verilmiştir. Doğru sıra hangisidir?
 * Parsons sorusunun TAM (doğru sıralı) programı; soruda gösterilen karışık
 *          parçalar: H14_F26_araya_ekle_karisik.c
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F26_araya_ekle.c -o f26
 */
#include <stdio.h>

#define KAPASITE 6

int araya_ekle(int a[], int n, int k, int deger)
{
    if (n == KAPASITE) {
        return n;
    }
    for (int i = n; i > k; i--) {
        a[i] = a[i - 1];
    }
    a[k] = deger;
    return n + 1;
}

int main(void)
{
    int a[KAPASITE] = {10, 20, 30, 40, 50};
    int n = 5;
    n = araya_ekle(a, n, 2, 25);
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
    return 0;
}

/* H14_F09_ucgen_turu.c — Hafta 14 · Final hazırlık soru bankası, S9
 *          (H5 · ÖÇ 5.1 · çıktı tahmini): else-if merdiveninde ilk doğru dal
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F09_ucgen_turu.c -o f09
 */
#include <stdio.h>

int main(void)
{
    int a = 6;
    int b = 8;
    int c = 10;
    if (a + b <= c || a + c <= b || b + c <= a) {
        printf("geçersiz\n");
    } else if (a == b && b == c) {
        printf("eşkenar\n");
    } else if (a == b || b == c || a == c) {
        printf("ikizkenar\n");
    } else if (a * a + b * b == c * c) {
        printf("dik\n");
    } else {
        printf("çeşitkenar\n");
    }
    return 0;
}

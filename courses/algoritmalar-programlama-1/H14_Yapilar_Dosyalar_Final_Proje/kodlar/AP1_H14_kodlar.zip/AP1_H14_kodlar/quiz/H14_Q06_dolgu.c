/* H14_Q06_dolgu.c — Hafta 14 · Quiz 6: sizeof ve dolgu (x86-64 GCC)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q06_dolgu.c -o q06
 */
#include <stdio.h>

struct Kayit {
    char c;
    int i;
    char d;
};

int main(void)
{
    printf("%zu\n", sizeof(struct Kayit));
    return 0;
}

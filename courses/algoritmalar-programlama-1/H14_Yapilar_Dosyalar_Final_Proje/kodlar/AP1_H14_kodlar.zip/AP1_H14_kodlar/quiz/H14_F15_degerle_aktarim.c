/* H14_F15_degerle_aktarim.c — Hafta 14 · Final hazırlık soru bankası, S15
 *          (H8 · ÖÇ 8.2 · çıktı tahmini): değerle aktarım ve fonksiyon
 *          bileşimi
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F15_degerle_aktarim.c -o f15
 */
#include <stdio.h>

int karesi_arti_bir(int x)
{
    x = x * x;
    return x + 1;
}

int main(void)
{
    int a = 4;
    int b = karesi_arti_bir(a);
    int c = karesi_arti_bir(karesi_arti_bir(1));
    printf("%d %d %d\n", a, b, c);
    return 0;
}

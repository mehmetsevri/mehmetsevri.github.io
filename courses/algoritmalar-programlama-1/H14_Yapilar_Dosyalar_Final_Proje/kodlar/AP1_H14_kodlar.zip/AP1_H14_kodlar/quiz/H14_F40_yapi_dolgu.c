/* H14_F40_yapi_dolgu.c — Hafta 14 · Final hazırlık soru bankası, S40
 *          (H14 · ÖÇ 14.1 · çıktı tahmini): yapıda hizalama ve dolgu
 * Soru   : x86-64 Linux, GCC (int 4 bayt ve 4 bayta hizalı). Program ne
 *          yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F40_yapi_dolgu.c -o f40
 */
#include <stdio.h>

struct A {
    char c;
    int i;
    char d;
};

struct B {
    int i;
    char c;
    char d;
};

int main(void)
{
    printf("%zu %zu\n", sizeof(struct A), sizeof(struct B));
    return 0;
}

/* H14_F41_feof_dongusu_duzeltilmis.c
 *          Hafta 14 · Final hazırlık soru bankası, S41
 *          (H14 · ÖÇ 14.3 · hata bulma): while (!feof(f)) karşıt örüntüsü
 * Soru   : (düzeltilmiş sürüm) Program dosyaya üç sayı (10, 20, 30) yazıp
 *          geri okuyor, ama okuma = 4, toplam = 90 yazdırıyor. Hatanın nedeni
 *          nedir?
 * Düzeltilmiş sürüm: kasıtlı hatalı H14_F41_feof_dongusu.c dosyasının
 *          düzeltilmiş hâli.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F41_feof_dongusu_duzeltilmis.c -o f41d
 */
#include <stdio.h>

int main(void)
{
    FILE *f = fopen("sayilar.txt", "w");
    if (f == NULL) {
        perror("sayilar.txt");
        return 1;
    }
    fprintf(f, "10\n20\n30\n");
    fclose(f);

    f = fopen("sayilar.txt", "r");
    if (f == NULL) {
        perror("sayilar.txt");
        return 1;
    }
    int x = 0;
    int toplam = 0;
    int okuma = 0;
    while (fscanf(f, "%d", &x) == 1) {        /* DÜZELTME */
        toplam += x;
        okuma++;
    }
    fclose(f);
    printf("okuma = %d, toplam = %d\n", okuma, toplam);
    return 0;
}

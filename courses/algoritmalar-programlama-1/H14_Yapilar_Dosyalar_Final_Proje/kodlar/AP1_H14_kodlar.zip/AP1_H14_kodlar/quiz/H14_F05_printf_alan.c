/* H14_F05_printf_alan.c — Hafta 14 · Final hazırlık soru bankası, S5
 *          (H3 · ÖÇ 3.5 · çıktı tahmini): printf alan genişliği ve hassasiyet
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F05_printf_alan.c -o f05
 */
#include <stdio.h>

int main(void)
{
    double pi = 3.14159;
    int adet = 7;
    int no = 42;
    printf("[%6.2f][%-4d][%04d]\n", pi, adet, no);
    return 0;
}

/* H14_Q10_fscanf.c — Hafta 14 · Quiz 10: fscanf'in dönüş değeri
 * (dosya: "10 20 x 30")
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q10_fscanf.c -o q10
 */
#include <stdio.h>

int main(void)
{
    FILE *f = fopen("q10.txt", "w");
    if (f == NULL) {
        return 1;
    }
    fputs("10 20 x 30\n", f);
    fclose(f);
    f = fopen("q10.txt", "r");
    if (f == NULL) {
        return 1;
    }
    int x, toplam = 0;
    while (fscanf(f, "%d", &x) == 1) {
        toplam += x;
    }
    fclose(f);
    remove("q10.txt");
    printf("toplam = %d\n", toplam);
    return 0;
}

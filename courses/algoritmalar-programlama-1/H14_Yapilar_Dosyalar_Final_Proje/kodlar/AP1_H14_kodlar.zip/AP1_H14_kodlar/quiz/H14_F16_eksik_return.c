/* H14_F16_eksik_return.c — Hafta 14 · Final hazırlık soru bankası, S16
 *          (H8 · ÖÇ 8.1 · hata bulma): değer döndüren fonksiyonda eksik
 *          return
 * Soru   : gcc -std=c17 -Wall -Wextra -pedantic bu programı derlerken ne olur
 *          ve buyuk(5, 5) çağrısı için hangisi doğrudur?
 * BU DOSYA KASITLI HATA İÇERİR: a == b iken hiçbir return çalışmaz (tanımsız
 *          davranış). Derleyici iletisi ve çalıştırma:
 *          ciktilar/H14_F16_eksik_return.txt
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F16_eksik_return.c -o f16
 */
#include <stdio.h>

int buyuk(int a, int b)
{
    if (a > b) {
        return a;
    } else if (b > a) {
        return b;
    }
}

int main(void)
{
    printf("%d\n", buyuk(5, 5));
    return 0;
}

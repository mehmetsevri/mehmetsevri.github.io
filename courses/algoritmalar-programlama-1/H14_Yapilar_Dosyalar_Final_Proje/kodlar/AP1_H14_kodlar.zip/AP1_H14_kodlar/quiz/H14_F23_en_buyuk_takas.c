/* H14_F23_en_buyuk_takas.c — Hafta 14 · Final hazırlık soru bankası, S23
 *          (H10 · ÖÇ 10.3 · çıktı tahmini): en büyüğün indisi ve takas
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F23_en_buyuk_takas.c -o f23
 */
#include <stdio.h>

int main(void)
{
    int a[6] = {3, 8, 1, 9, 4, 7};
    int enb = 0;
    for (int i = 1; i < 6; i++) {
        if (a[i] > a[enb]) {
            enb = i;
        }
    }
    int gecici = a[0];
    a[0] = a[enb];
    a[enb] = gecici;
    for (int i = 0; i < 6; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
    return 0;
}

/* H14_Q03_strcmp.c — Hafta 14 · Quiz 3 (geri çağırma, H13): == ile
 * strcmp
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q03_strcmp.c -o q03
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char a[] = "elma";
    char b[] = "elma";
    const char *p = a;
    const char *q = b;
    printf("%d %d\n", p == q, strcmp(p, q) == 0);
    return 0;
}

/* H14_F36_fgets_satir_sonu.c — Hafta 14 · Final hazırlık soru bankası, S36
 *          (H13 · ÖÇ 13.2 · çıktı tahmini): fgets ve sondaki '\n'
 * Soru   : Kullanıcı Ali yazıp Enter'a basıyor. Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F36_fgets_satir_sonu.c -o f36
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char ad[16];
    if (fgets(ad, sizeof ad, stdin) == NULL) {
        return 1;
    }
    printf("[%s] %zu\n", ad, strlen(ad));
    return 0;
}

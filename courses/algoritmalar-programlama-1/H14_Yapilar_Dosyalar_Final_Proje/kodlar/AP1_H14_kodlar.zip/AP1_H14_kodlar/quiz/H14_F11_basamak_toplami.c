/* H14_F11_basamak_toplami.c — Hafta 14 · Final hazırlık soru bankası, S11
 *          (H6 · ÖÇ 6.3 · kod tamamlama): basamak işleme deseninde döngü
 *          koşulu
 * Soru   : Program 4057'nin basamaklarının toplamını yazdırmalıdır. Boşluğa
 *          hangisi gelmelidir?
 * Kod tamamlama sorusunun TAM (çözülmüş) programı; soruda gösterilen boşluklu
 *          sürüm: H14_F11_basamak_toplami_bosluklu.c
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F11_basamak_toplami.c -o f11
 */
#include <stdio.h>

int main(void)
{
    int n = 4057;
    int toplam = 0;
    while (n > 0) {
        toplam += n % 10;
        n /= 10;
    }
    printf("%d\n", toplam);
    return 0;
}

/* H14_F25_sinir_asimi.c — Hafta 14 · Final hazırlık soru bankası, S25
 *          (H10 · ÖÇ 10.5 · hata bulma): dizi sınırı aşımı (i <= N)
 * Soru   : Beş notun ortalamasını bulması gereken programın hatası nedir?
 * BU DOSYA KASITLI HATA İÇERİR: i <= N: notlar[5] okunur, sınır dışı erişim
 *          (tanımsız davranış). Derleyici iletisi ve çalıştırma:
 *          ciktilar/H14_F25_sinir_asimi.txt
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F25_sinir_asimi.c -o f25
 */
#include <stdio.h>

#define N 5

int main(void)
{
    int notlar[N] = {70, 85, 60, 90, 75};
    int toplam = 0;
    for (int i = 0; i <= N; i++) {
        toplam += notlar[i];
    }
    printf("Ortalama: %d\n", toplam / N);
    return 0;
}

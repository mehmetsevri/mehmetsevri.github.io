/* H14_F30_komsu_mayin.c — Hafta 14 · Final hazırlık soru bankası, S30
 *          (H11 · ÖÇ 11.4 · kod tamamlama): ızgarada sınır denetimi
 * Soru   : Program, mayın tarlasında (1, 0) hücresinin 8 komşusundaki
 *          mayınları ('*') saymalıdır. Boşluğa hangisi gelmelidir?
 * Kod tamamlama sorusunun TAM (çözülmüş) programı; soruda gösterilen boşluklu
 *          sürüm: H14_F30_komsu_mayin_bosluklu.c
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F30_komsu_mayin.c -o f30
 */
#include <stdio.h>

#define SATIR 3
#define SUTUN 4

int main(void)
{
    char m[SATIR][SUTUN] = {
        {'*', '.', '.', '.'},
        {'.', '.', '*', '.'},
        {'*', '*', '.', '*'}
    };
    int r = 1;
    int c = 0;
    int sayi = 0;
    for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
            int nr = r + dr;
            int nc = c + dc;
            if ((dr != 0 || dc != 0)
                && nr >= 0 && nr < SATIR && nc >= 0 && nc < SUTUN
                && m[nr][nc] == '*') {
                sayi++;
            }
        }
    }
    printf("%d\n", sayi);
    return 0;
}

/* H14_Q01_sonlandirici.c — Hafta 14 · Quiz 1 (geri çağırma, H13):
 * '\0' ve "boyut + 1"
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q01_sonlandirici.c -o q01
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char ad[] = "MERT";
    printf("%zu %zu\n", sizeof ad, strlen(ad));
    return 0;
}

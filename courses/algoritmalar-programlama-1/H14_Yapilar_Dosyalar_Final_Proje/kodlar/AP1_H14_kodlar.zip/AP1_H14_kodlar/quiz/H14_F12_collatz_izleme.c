/* H14_F12_collatz_izleme.c — Hafta 14 · Final hazırlık soru bankası, S12
 *          (H6 · ÖÇ 6.4 · izleme): döngüyü izleme: adım sayısı ve en büyük
 *          değer
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F12_collatz_izleme.c -o f12
 */
#include <stdio.h>

int main(void)
{
    int n = 6;
    int adim = 0;
    int en_buyuk = n;
    while (n != 1) {
        if (n % 2 == 0) {
            n = n / 2;
        } else {
            n = 3 * n + 1;
        }
        adim++;
        if (n > en_buyuk) {
            en_buyuk = n;
        }
    }
    printf("%d %d\n", adim, en_buyuk);
    return 0;
}

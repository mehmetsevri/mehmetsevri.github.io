/* H14_F29_sifirlanmayan_sonuc_duzeltilmis.c
 *          Hafta 14 · Final hazırlık soru bankası, S29
 *          (H11 · ÖÇ 11.3 · hata bulma): matris çarpımında sıfırlanmayan
 *          sonuç
 * Soru   : (düzeltilmiş sürüm) 2 × 3 ile 3 × 2 matrisin çarpımını hesaplayan
 *          programın hatası nedir?
 * Düzeltilmiş sürüm: kasıtlı hatalı H14_F29_sifirlanmayan_sonuc.c dosyasının
 *          düzeltilmiş hâli.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F29_sifirlanmayan_sonuc_duzeltilmis.c -o f29d
 */
#include <stdio.h>

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int b[3][2] = {{1, 0}, {0, 1}, {2, 2}};
    int c[2][2] = {{0}};               /* DÜZELTME: sonuç sıfırdan başlar */
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < 3; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    printf("%d %d\n%d %d\n", c[0][0], c[0][1], c[1][0], c[1][1]);
    return 0;
}

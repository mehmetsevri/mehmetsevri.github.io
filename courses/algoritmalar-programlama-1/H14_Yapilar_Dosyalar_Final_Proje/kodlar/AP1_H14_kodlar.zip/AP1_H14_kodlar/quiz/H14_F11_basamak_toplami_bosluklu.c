/* H14_F11_basamak_toplami_bosluklu.c
 *          Hafta 14 · Final hazırlık soru bankası, S11
 *          (H6 · ÖÇ 6.3 · kod tamamlama): basamak işleme deseninde döngü
 *          koşulu
 * Soru   : Program 4057'nin basamaklarının toplamını yazdırmalıdır. Boşluğa
 *          hangisi gelmelidir?
 * Kod tamamlama: TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. Boşluğa (_____) doğru
 *          seçenek yazılınca H14_F11_basamak_toplami.c elde edilir.
 */
#include <stdio.h>

int main(void)
{
    int n = 4057;
    int toplam = 0;
    while (_____) {
        toplam += n % 10;
        n /= 10;
    }
    printf("%d\n", toplam);
    return 0;
}

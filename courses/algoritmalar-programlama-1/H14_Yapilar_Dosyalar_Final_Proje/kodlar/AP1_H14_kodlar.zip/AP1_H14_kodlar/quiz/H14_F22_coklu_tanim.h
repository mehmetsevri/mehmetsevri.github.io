/* H14_F22_coklu_tanim.h — Hafta 14 · Final hazırlık soru bankası, S22
 *          (H9 · ÖÇ 9.5 · kavram): başlık dosyasında tanım: multiple
 *          definition
 * Soru   : Bir projede sayac.h (başlık koruyucusu ile) int kayit_sayisi = 0;
 *          satırını içeriyor ve bu başlık hem main.c hem sayac.c tarafından
 *          #include ediliyor. gcc main.c sayac.c -o prog ne üretir?
 * BU DOSYA KASITLI HATA İÇERİR: başlık dosyasında değişken TANIMI; iki .c
 *          dosyası da içerince bağlayıcı “multiple definition” hatası verir.
 * Başlık: sayac.h'nin karşılığı.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F22_coklu_tanim_main.c H14_F22_coklu_tanim_sayac.c -o f22
 */
#ifndef H14_F22_COKLU_TANIM_H
#define H14_F22_COKLU_TANIM_H

int kayit_sayisi = 0;           /* HATA: başlıkta tanım; doğrusu: extern int kayit_sayisi; */

void kayit_ekle(void);

#endif

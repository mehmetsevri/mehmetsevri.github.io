/* H14_F35_strlen_sizeof.c — Hafta 14 · Final hazırlık soru bankası, S35
 *          (H13 · ÖÇ 13.1 · çıktı tahmini): strlen, sizeof ve UTF-8
 * Soru   : Kaynak dosya UTF-8 olarak kaydedilmiştir (GCC'nin varsayılanı).
 *          Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F35_strlen_sizeof.c -o f35
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[] = "çay";
    char t[10] = "çay";
    printf("%zu %zu %zu\n", strlen(s), sizeof s, sizeof t);
    return 0;
}

/* H14_Q05_deger_isaretci.c — Hafta 14 · Quiz 5: değerle ve işaretçiyle
 * aktarım
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q05_deger_isaretci.c -o q05
 */
#include <stdio.h>

typedef struct {
    int deger;
} Sayac;

void arttir(Sayac *s)
{
    s->deger++;
}

void arttir_kopya(Sayac s)
{
    s.deger++;
}

int main(void)
{
    Sayac c = {0};
    arttir(&c);
    arttir_kopya(c);
    arttir(&c);
    printf("%d\n", c.deger);
    return 0;
}

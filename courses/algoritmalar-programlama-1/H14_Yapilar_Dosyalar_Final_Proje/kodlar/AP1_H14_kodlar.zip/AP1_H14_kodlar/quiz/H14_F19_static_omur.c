/* H14_F19_static_omur.c — Hafta 14 · Final hazırlık soru bankası, S19
 *          (H9 · ÖÇ 9.1 · çıktı tahmini): static ve otomatik ömür
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F19_static_omur.c -o f19
 */
#include <stdio.h>

int f(void)
{
    static int s = 0;
    int a = 0;
    s += 2;
    a += 2;
    return s * 10 + a;
}

int main(void)
{
    printf("%d ", f());
    printf("%d ", f());
    printf("%d\n", f());
    return 0;
}

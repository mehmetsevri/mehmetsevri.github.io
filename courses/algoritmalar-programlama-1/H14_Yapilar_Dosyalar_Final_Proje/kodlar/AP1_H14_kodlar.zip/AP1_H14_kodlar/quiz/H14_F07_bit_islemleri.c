/* H14_F07_bit_islemleri.c — Hafta 14 · Final hazırlık soru bankası, S7
 *          (H4 · ÖÇ 4.4 · çıktı tahmini): maske, kaydırma ve XOR
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F07_bit_islemleri.c -o f07
 */
#include <stdio.h>

int main(void)
{
    int x = 0x6B;               /* 0110 1011 */
    printf("%d %d %d\n", x & 0x0F, x >> 3, x ^ 0xFF);
    return 0;
}

/* H14_F38_strcpy_tasmasi.c — Hafta 14 · Final hazırlık soru bankası, S38
 *          (H13 · ÖÇ 13.5 · hata bulma): strcpy ile tampon taşması
 * Soru   : Bu programın hatası nedir?
 * BU DOSYA KASITLI HATA İÇERİR: 7 baytlık string 5 baytlık diziye
 *          kopyalanıyor: tampon taşması (tanımsız davranış). Derleyici
 *          iletisi ve çalıştırma: ciktilar/H14_F38_strcpy_tasmasi.txt
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F38_strcpy_tasmasi.c -o f38
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char ad[5];
    strcpy(ad, "Zeynep");
    printf("Merhaba, %s\n", ad);
    return 0;
}

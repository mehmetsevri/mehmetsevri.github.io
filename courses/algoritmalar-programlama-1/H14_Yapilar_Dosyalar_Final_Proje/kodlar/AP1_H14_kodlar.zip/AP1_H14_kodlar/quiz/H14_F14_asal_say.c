/* H14_F14_asal_say.c — Hafta 14 · Final hazırlık soru bankası, S14
 *          (H7 · ÖÇ 7.3 · kod tamamlama): asallık testinde √n sınırı
 * Soru   : Program 2–30 arasındaki asal sayıların sayısını bulmalıdır.
 *          Boşluğa hangisi gelirse test hem doğru hem verimli (√n sınırlı)
 *          olur?
 * Kod tamamlama sorusunun TAM (çözülmüş) programı; soruda gösterilen boşluklu
 *          sürüm: H14_F14_asal_say_bosluklu.c
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F14_asal_say.c -o f14
 */
#include <stdio.h>

int main(void)
{
    int asal_sayisi = 0;
    for (int n = 2; n <= 30; n++) {
        int asal = 1;
        for (int d = 2; d * d <= n; d++) {
            if (n % d == 0) {
                asal = 0;
                break;
            }
        }
        if (asal) {
            asal_sayisi++;
        }
    }
    printf("%d\n", asal_sayisi);
    return 0;
}

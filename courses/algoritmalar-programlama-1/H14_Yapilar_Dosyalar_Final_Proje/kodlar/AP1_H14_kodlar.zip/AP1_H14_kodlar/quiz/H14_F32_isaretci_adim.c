/* H14_F32_isaretci_adim.c — Hafta 14 · Final hazırlık soru bankası, S32
 *          (H12 · ÖÇ 12.3 · izleme): işaretçi aritmetiğiyle dolaşma
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F32_isaretci_adim.c -o f32
 */
#include <stdio.h>

int main(void)
{
    int a[6] = {5, 10, 15, 20, 25, 30};
    int toplam = 0;
    int adim = 0;
    for (int *p = a; p < a + 6; p += 2) {
        toplam += *p;
        adim++;
    }
    printf("%d %d\n", toplam, adim);
    return 0;
}

/* H14_F28_satir_oncelikli.c — Hafta 14 · Final hazırlık soru bankası, S28
 *          (H11 · ÖÇ 11.2 · kavram): satır öncelikli yerleşimde adres hesabı
 * Soru   : short s[5][8]; dizisinde (x86-64 Linux, GCC: sizeof(short) = 2)
 *          &s[0][0] adresi 0x2000 ise &s[3][5] adresi kaçtır?
 * Adres hesabını doğrulayan program (soruda kod gösterilmez).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F28_satir_oncelikli.c -o f28
 */
#include <stdio.h>

int main(void)
{
    short s[5][8];
    printf("%zu %td\n", sizeof s, (char *)&s[3][5] - (char *)&s[0][0]);
    return 0;
}

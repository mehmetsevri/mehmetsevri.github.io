/* H14_F42_guvenli_kaydet.c — Hafta 14 · Final hazırlık soru bankası, S42
 *          (H14 · ÖÇ 14.4 · Parsons): Mini-OBS güvenli kaydetme (geçici dosya
 *          + rename)
 * Soru   : Mini-OBS'nin güvenli kaydetme yaklaşımında veri önce <yol>.tmp
 *          dosyasına yazılır ve yalnızca her adım başarılıysa asıl dosyanın
 *          yerine geçer; böylece yazma yarıda kalırsa eski veri bozulmaz.
 *          Aşağıdaki kaydet bu yaklaşımın sadeleştirilmiş hâlidir; parçaları
 *          karışık verilmiştir. Doğru sıra hangisidir?
 * Parsons sorusunun TAM (doğru sıralı) programı; soruda gösterilen karışık
 *          parçalar: H14_F42_guvenli_kaydet_karisik.c
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F42_guvenli_kaydet.c -o f42
 */
#include <stdio.h>
#include <stdbool.h>

bool kaydet(const char *yol, const int notlar[], int n)
{
    char gecici[64];
    int uzunluk = snprintf(gecici, sizeof gecici, "%s.tmp", yol);
    if (uzunluk < 0 || (size_t)uzunluk >= sizeof gecici) {
        return false;
    }
    FILE *f = fopen(gecici, "w");
    if (f == NULL) {
        return false;
    }
    for (int i = 0; i < n; i++) {
        fprintf(f, "%d\n", notlar[i]);
    }
    if (fclose(f) != 0) {
        remove(gecici);
        return false;
    }
    return rename(gecici, yol) == 0;
}

int main(void)
{
    int notlar[3] = {72, 85, 64};
    if (!kaydet("notlar.txt", notlar, 3)) {
        printf("Kaydedilemedi\n");
        return 1;
    }
    FILE *f = fopen("notlar.txt", "r");
    if (f == NULL) {
        perror("notlar.txt");
        return 1;
    }
    char satir[16];
    while (fgets(satir, sizeof satir, f) != NULL) {
        printf("okundu: %s", satir);
    }
    fclose(f);
    return 0;
}

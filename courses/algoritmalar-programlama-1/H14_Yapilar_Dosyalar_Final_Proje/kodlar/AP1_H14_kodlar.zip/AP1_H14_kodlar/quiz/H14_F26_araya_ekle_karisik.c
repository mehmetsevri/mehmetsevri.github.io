/* H14_F26_araya_ekle_karisik.c — Hafta 14 · Final hazırlık soru bankası, S26
 *          (H10 · ÖÇ 10.3 · Parsons): diziye araya ekleme (kaydırma)
 * Soru   : araya_ekle, dizi dolu değilse deger'i k konumuna ekleyip yeni
 *          eleman sayısını döndürmelidir ({10, 20, 30, 40, 50}, k = 2, 25 →
 *          {10, 20, 25, 30, 40, 50}). Fonksiyon gövdesinin parçaları karışık
 *          verilmiştir. Doğru sıra hangisidir?
 * Parsons: parçalar karışık verilmiştir; TAMAMLANACAK; BU HÂLİYLE DERLENMEZ.
 *          [k] etiketleri parça numaralarıdır; doğru sıra
 *          H14_F26_araya_ekle.c dosyasındadır.
 */
a[k] = deger;                           /* [1] */
for (int i = n; i > k; i--) {           /* [2] */
    a[i] = a[i - 1];
}
if (n == KAPASITE) {                    /* [3] */
    return n;
}
return n + 1;                           /* [4] */

/* H14_F31_dondur_isaretci.c — Hafta 14 · Final hazırlık soru bankası, S31
 *          (H12 · ÖÇ 12.2 · izleme): işaretçi parametrelerle kutu–ok izleme
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F31_dondur_isaretci.c -o f31
 */
#include <stdio.h>

void dondur(int *x, int *y, int *z)
{
    int t = *x;
    *x = *y;
    *y = *z;
    *z = t;
}

int main(void)
{
    int a = 1;
    int b = 2;
    int c = 3;
    dondur(&c, &b, &a);
    printf("%d %d %d\n", a, b, c);
    return 0;
}

/* H14_F27_kosegenler.c — Hafta 14 · Final hazırlık soru bankası, S27
 *          (H11 · ÖÇ 11.3 · çıktı tahmini): ana ve yan köşegen toplamı
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F27_kosegenler.c -o f27
 */
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{2, 0, 1}, {3, 5, 4}, {6, 7, 8}};
    int ana = 0;
    int yan = 0;
    for (int i = 0; i < 3; i++) {
        ana += m[i][i];
        yan += m[i][2 - i];
    }
    printf("%d %d\n", ana, yan);
    return 0;
}

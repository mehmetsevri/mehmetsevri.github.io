/* H14_Q11_ikili_boyut.c — Hafta 14 · Quiz 11: ikili dosyanın boyutu
 * (x86-64 GCC)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q11_ikili_boyut.c -o q11
 */
#include <stdio.h>

typedef struct {
    int no;
    double ort;
} Kayit;

int main(void)
{
    Kayit k[3] = {{1, 79.0}, {2, 46.8}, {3, 90.4}};
    FILE *f = fopen("q11.dat", "wb");
    if (f == NULL) {
        return 1;
    }
    fwrite(k, sizeof k[0], 3, f);
    long boyut = ftell(f);
    fclose(f);
    remove("q11.dat");
    printf("%ld\n", boyut);
    return 0;
}

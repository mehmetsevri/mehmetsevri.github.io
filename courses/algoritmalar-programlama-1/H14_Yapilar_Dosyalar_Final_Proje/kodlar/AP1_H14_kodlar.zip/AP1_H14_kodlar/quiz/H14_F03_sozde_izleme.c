/* H14_F03_sozde_izleme.c — Hafta 14 · Final hazırlık soru bankası, S3
 *          (H2 · ÖÇ 2.5 · izleme): sözde kodu izleme tablosuyla yürütme
 * Soru   : Aşağıdaki algoritmayı izleme tablosuyla elle yürütün. Ne
 *          yazdırılır?
 * Sözde kodun C karşılığı (doğrulama için; soruda sözde kod gösterilir).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F03_sozde_izleme.c -o f03
 */
#include <stdio.h>

int main(void)
{
    int a = 1;
    int b = 1;
    int k = 0;
    while (b < 20) {
        int t = a + b;
        a = b;
        b = t;
        k = k + 1;
    }
    printf("%d %d\n", k, b);
    return 0;
}

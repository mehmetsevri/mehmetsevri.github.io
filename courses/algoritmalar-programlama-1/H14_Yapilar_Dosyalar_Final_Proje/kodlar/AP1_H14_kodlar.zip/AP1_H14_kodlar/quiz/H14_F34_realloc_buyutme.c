/* H14_F34_realloc_buyutme.c — Hafta 14 · Final hazırlık soru bankası, S34
 *          (H12 · ÖÇ 12.5 · Parsons): realloc ile güvenli büyütme
 * Soru   : Program 1, 4, 9, 16, 25 değerlerini, dolunca kapasitesini ikiye
 *          katlayan dinamik bir diziye eklemelidir. for gövdesinin parçaları
 *          karışık verilmiştir. Hem doğru hem güvenli sıra hangisidir?
 * Parsons sorusunun TAM (doğru sıralı) programı; soruda gösterilen karışık
 *          parçalar: H14_F34_realloc_buyutme_karisik.c
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F34_realloc_buyutme.c -o f34
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int kapasite = 2;
    int n = 0;
    int *dizi = malloc(kapasite * sizeof *dizi);
    if (dizi == NULL) {
        return 1;
    }
    for (int deger = 1; deger <= 5; deger++) {
        if (n == kapasite) {
            int *yeni = realloc(dizi, 2 * kapasite * sizeof *dizi);
            if (yeni == NULL) {
                free(dizi);
                return 1;
            }
            dizi = yeni;
            kapasite *= 2;
        }
        dizi[n] = deger * deger;
        n++;
    }
    printf("n = %d, kapasite = %d, son = %d\n", n, kapasite, dizi[n - 1]);
    free(dizi);
    return 0;
}

/* H14_F17_harf_notu_izleme.c — Hafta 14 · Final hazırlık soru bankası, S17
 *          (H8 · ÖÇ 8.3 · izleme): Mini-OBS hesap fonksiyonlarını izleme
 * Soru   : Mini-OBS'nin hesap fonksiyonları aşağıdadır (RTEÜ kuralları: %40
 *          vize + %60 final, final < 50 → FF). Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F17_harf_notu_izleme.c -o f17
 */
#include <stdio.h>

double hesapla_ortalama(double vize, double final)
{
    return 0.40 * vize + 0.60 * final;
}

int yuvarla(double ortalama)
{
    return (int)(ortalama + 0.5);
}

const char *harf_notu(int yuvarlanmis, double final)
{
    if (final < 50) {
        return "FF";
    } else if (yuvarlanmis >= 90) {
        return "AA";
    } else if (yuvarlanmis >= 81) {
        return "BA";
    } else if (yuvarlanmis >= 73) {
        return "BB";
    } else if (yuvarlanmis >= 66) {
        return "CB";
    } else if (yuvarlanmis >= 60) {
        return "CC";
    } else if (yuvarlanmis >= 50) {
        return "DC";
    } else if (yuvarlanmis >= 40) {
        return "DD";
    } else if (yuvarlanmis >= 30) {
        return "FD";
    }
    return "FF";
}

int main(void)
{
    int y1 = yuvarla(hesapla_ortalama(70, 50));
    int y2 = yuvarla(hesapla_ortalama(100, 45));
    int y3 = yuvarla(hesapla_ortalama(55, 64));
    printf("%s %s %s\n", harf_notu(y1, 50), harf_notu(y2, 45),
           harf_notu(y3, 64));
    return 0;
}

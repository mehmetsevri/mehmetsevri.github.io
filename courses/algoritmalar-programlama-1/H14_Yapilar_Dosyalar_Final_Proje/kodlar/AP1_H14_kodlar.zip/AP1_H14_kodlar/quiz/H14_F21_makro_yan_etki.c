/* H14_F21_makro_yan_etki.c — Hafta 14 · Final hazırlık soru bankası, S21
 *          (H9 · ÖÇ 9.5 · çıktı tahmini): makroya yan etkili argüman
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F21_makro_yan_etki.c -o f21
 */
#include <stdio.h>

#define MAX(a, b) ((a) > (b) ? (a) : (b))

int main(void)
{
    int i = 5;
    int m = MAX(i++, 3);
    printf("%d %d\n", m, i);
    return 0;
}

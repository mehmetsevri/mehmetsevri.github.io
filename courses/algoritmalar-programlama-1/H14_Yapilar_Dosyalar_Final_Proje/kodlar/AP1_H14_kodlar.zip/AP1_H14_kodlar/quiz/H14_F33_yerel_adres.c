/* H14_F33_yerel_adres.c — Hafta 14 · Final hazırlık soru bankası, S33
 *          (H12 · ÖÇ 12.4 · hata bulma): yerel değişkenin adresini döndürmek
 * Soru   : Bu programın hatası nedir?
 * BU DOSYA KASITLI HATA İÇERİR: yerel dizinin adresi döndürülüyor: sarkan
 *          işaretçi (tanımsız davranış). Derleyici iletisi ve çalıştırma:
 *          ciktilar/H14_F33_yerel_adres.txt
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F33_yerel_adres.c -o f33
 */
#include <stdio.h>

int *kopya_olustur(const int a[], int n)
{
    int b[10];
    for (int i = 0; i < n; i++) {
        b[i] = a[i];
    }
    return b;
}

int main(void)
{
    int a[3] = {1, 2, 3};
    int *k = kopya_olustur(a, 3);
    printf("%d\n", k[0]);
    return 0;
}

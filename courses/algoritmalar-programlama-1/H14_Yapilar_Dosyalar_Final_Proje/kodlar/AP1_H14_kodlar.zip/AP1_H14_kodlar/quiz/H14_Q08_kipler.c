/* H14_Q08_kipler.c — Hafta 14 · Quiz 8: "w" ve "a" kipleri
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q08_kipler.c -o q08
 */
#include <stdio.h>

static void yaz(const char *kip, const char *metin)
{
    FILE *f = fopen("q08.txt", kip);
    if (f != NULL) {
        fputs(metin, f);
        fclose(f);
    }
}

int main(void)
{
    yaz("w", "ABC");
    yaz("w", "X");
    yaz("a", "Y");
    FILE *f = fopen("q08.txt", "r");
    if (f == NULL) {
        return 1;
    }
    int c;
    while ((c = fgetc(f)) != EOF) {
        putchar(c);
    }
    putchar('\n');
    fclose(f);
    remove("q08.txt");
    return 0;
}

/* H14_F20_ozyineleme_izleme.c — Hafta 14 · Final hazırlık soru bankası, S20
 *          (H9 · ÖÇ 9.3 · izleme): özyinelemeli çağrı zinciri
 * Soru   : Program ne yazdırır? (cagri genel bir değişkendir.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F20_ozyineleme_izleme.c -o f20
 */
#include <stdio.h>

int cagri = 0;

int f(int n)
{
    cagri++;
    if (n <= 1) {
        return n;
    }
    return f(n / 2) + n % 2;
}

int main(void)
{
    int sonuc = f(13);
    printf("%d %d\n", sonuc, cagri);
    return 0;
}

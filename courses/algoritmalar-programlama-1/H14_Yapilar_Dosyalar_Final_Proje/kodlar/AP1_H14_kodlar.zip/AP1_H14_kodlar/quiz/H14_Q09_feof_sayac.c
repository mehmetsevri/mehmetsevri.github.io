/* H14_Q09_feof_sayac.c — Hafta 14 · Quiz 9: while (!feof(f)) kaç tur
 * döner? (dosya: 'A', 'B', '\n' — 3 bayt)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q09_feof_sayac.c -o q09
 */
#include <stdio.h>

int main(void)
{
    FILE *f = fopen("q09.txt", "w");
    if (f == NULL) {
        return 1;
    }
    fputs("AB\n", f);
    fclose(f);
    f = fopen("q09.txt", "r");
    if (f == NULL) {
        return 1;
    }
    int n = 0;
    while (!feof(f)) {
        fgetc(f);
        n++;
    }
    fclose(f);
    remove("q09.txt");
    printf("%d\n", n);
    return 0;
}

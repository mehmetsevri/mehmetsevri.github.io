/* H14_Q04_yapi_kopyasi.c — Hafta 14 · Quiz 4: yapı ataması kopyalar
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q04_yapi_kopyasi.c -o q04
 */
#include <stdio.h>

typedef struct {
    char ad[8];
    int puan;
} Oyuncu;

int main(void)
{
    Oyuncu a = {"CAN", 70};
    Oyuncu b = a;
    b.puan = 90;
    b.ad[0] = 'J';
    printf("%s %d / %s %d\n", a.ad, a.puan, b.ad, b.puan);
    return 0;
}

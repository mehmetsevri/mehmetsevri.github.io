/* H14_Q02_fgets_satir_sonu.c — Hafta 14 · Quiz 2 (geri çağırma, H13):
 * fgets'in bıraktığı '\n' (girdi: Ali ve Enter)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q02_fgets_satir_sonu.c -o q02
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char ad[16];
    if (fgets(ad, sizeof ad, stdin) == NULL) {
        return 1;
    }
    printf("%zu %s\n", strlen(ad), strcmp(ad, "Ali") == 0 ? "eşit" : "farklı");
    return 0;
}

/* H14_F37_sezar.c — Hafta 14 · Final hazırlık soru bankası, S37
 *          (H13 · ÖÇ 13.4 · çıktı tahmini): Sezar şifreleme
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F37_sezar.c -o f37
 */
#include <stdio.h>
#include <ctype.h>

void sezar(char *s, int k)
{
    for (int i = 0; s[i] != '\0'; i++) {
        if (isupper((unsigned char)s[i])) {
            s[i] = (char)('A' + (s[i] - 'A' + k) % 26);
        } else if (islower((unsigned char)s[i])) {
            s[i] = (char)('a' + (s[i] - 'a' + k) % 26);
        }
    }
}

int main(void)
{
    char metin[] = "Zebra 2026!";
    sezar(metin, 3);
    printf("%s\n", metin);
    return 0;
}

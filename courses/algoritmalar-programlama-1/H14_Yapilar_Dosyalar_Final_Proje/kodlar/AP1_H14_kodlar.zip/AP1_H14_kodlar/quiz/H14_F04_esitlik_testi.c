/* H14_F04_esitlik_testi.c — Hafta 14 · Final hazırlık soru bankası, S4
 *          (H2 · ÖÇ 2.1 · hata bulma): sınır durumu: eşitlik
 * Soru   : Üç sayının en büyüğünü bulması gereken algoritma aşağıdadır. Hangi
 *          test durumu algoritmanın hatalı olduğunu ortaya çıkarır?
 * Sözde kodun C karşılığı ve dört test durumu (doğrulama için).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F04_esitlik_testi.c -o f04
 */
#include <stdio.h>

int en_buyuk_bul(int a, int b, int c)
{
    int en_buyuk;
    if (a > b && a > c) {
        en_buyuk = a;
    } else if (b > a && b > c) {
        en_buyuk = b;
    } else {
        en_buyuk = c;
    }
    return en_buyuk;
}

int main(void)
{
    int test[4][4] = {
        {5, 5, 1, 5},           /* a, b, c, beklenen */
        {3, 2, 1, 3},
        {1, 2, 3, 3},
        {2, 9, 4, 9}
    };
    for (int i = 0; i < 4; i++) {
        int bulunan = en_buyuk_bul(test[i][0], test[i][1], test[i][2]);
        printf("(%d, %d, %d) -> %d, beklenen %d: %s\n",
               test[i][0], test[i][1], test[i][2], bulunan, test[i][3],
               bulunan == test[i][3] ? "TAMAM" : "HATA");
    }
    return 0;
}

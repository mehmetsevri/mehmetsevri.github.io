/* H14_Q12_ok_operatoru.c — Hafta 14 · Quiz 12: p->x ve (*p).x
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q12_ok_operatoru.c -o q12
 */
#include <stdio.h>

typedef struct {
    int x;
    int y;
} Nokta;

int main(void)
{
    Nokta n = {3, 4};
    Nokta *p = &n;
    p->x += 2;
    (*p).y *= 2;
    printf("%d %d\n", n.x, n.y);
    return 0;
}

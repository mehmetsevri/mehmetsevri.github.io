/* H14_F34_realloc_buyutme_karisik.c
 *          Hafta 14 · Final hazırlık soru bankası, S34
 *          (H12 · ÖÇ 12.5 · Parsons): realloc ile güvenli büyütme
 * Soru   : Program 1, 4, 9, 16, 25 değerlerini, dolunca kapasitesini ikiye
 *          katlayan dinamik bir diziye eklemelidir. for gövdesinin parçaları
 *          karışık verilmiştir. Hem doğru hem güvenli sıra hangisidir?
 * Parsons: parçalar karışık verilmiştir; TAMAMLANACAK; BU HÂLİYLE DERLENMEZ.
 *          [k] etiketleri parça numaralarıdır; doğru sıra
 *          H14_F34_realloc_buyutme.c dosyasındadır.
 */
dizi[n] = deger * deger;                /* [1] */
n++;
if (n == kapasite) {                    /* [2] */
int *yeni = realloc(dizi, 2 * kapasite * sizeof *dizi);  /* [3] */
if (yeni == NULL) {                     /* [4] */
    free(dizi);
    return 1;
}
dizi = yeni;                            /* [5] */
kapasite *= 2;
}                                       /* [6] */

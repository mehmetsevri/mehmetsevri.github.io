/* H14_F42_guvenli_kaydet_karisik.c
 *          Hafta 14 · Final hazırlık soru bankası, S42
 *          (H14 · ÖÇ 14.4 · Parsons): Mini-OBS güvenli kaydetme (geçici dosya
 *          + rename)
 * Soru   : Mini-OBS'nin güvenli kaydetme yaklaşımında veri önce <yol>.tmp
 *          dosyasına yazılır ve yalnızca her adım başarılıysa asıl dosyanın
 *          yerine geçer; böylece yazma yarıda kalırsa eski veri bozulmaz.
 *          Aşağıdaki kaydet bu yaklaşımın sadeleştirilmiş hâlidir; parçaları
 *          karışık verilmiştir. Doğru sıra hangisidir?
 * Parsons: parçalar karışık verilmiştir; TAMAMLANACAK; BU HÂLİYLE DERLENMEZ.
 *          [k] etiketleri parça numaralarıdır; doğru sıra
 *          H14_F42_guvenli_kaydet.c dosyasındadır.
 */
for (int i = 0; i < n; i++) {           /* [1] */
    fprintf(f, "%d\n", notlar[i]);
}
return rename(gecici, yol) == 0;        /* [2] */
FILE *f = fopen(gecici, "w");           /* [3] */
if (fclose(f) != 0) {                   /* [4] */
    remove(gecici);
    return false;
}
if (f == NULL) {                        /* [5] */
    return false;
}

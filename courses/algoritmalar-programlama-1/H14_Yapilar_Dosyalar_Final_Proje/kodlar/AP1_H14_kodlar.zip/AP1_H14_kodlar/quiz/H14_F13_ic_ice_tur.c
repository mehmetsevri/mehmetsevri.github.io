/* H14_F13_ic_ice_tur.c — Hafta 14 · Final hazırlık soru bankası, S13
 *          (H7 · ÖÇ 7.1 · izleme): iç içe döngüde yineleme sayısı
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F13_ic_ice_tur.c -o f13
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    int sayac = 0;
    for (int i = 1; i <= 4; i++) {
        for (int j = i; j <= 4; j++) {
            tur++;
            if ((i + j) % 2 == 0) {
                sayac++;
            }
        }
    }
    printf("%d %d\n", tur, sayac);
    return 0;
}

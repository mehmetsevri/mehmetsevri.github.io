/* H14_F10_bos_if.c — Hafta 14 · Final hazırlık soru bankası, S10
 *          (H5 · ÖÇ 5.1 · hata bulma): if sonrası noktalı virgül (boş deyim)
 * Soru   : Bakiye 100, çekilecek tutar 50 iken program Yetersiz bakiye ve
 *          Kalan: 100 yazdırıyor. Hatanın nedeni nedir?
 * BU DOSYA KASITLI HATA İÇERİR: if (...); boş deyim: blok koşuldan bağımsız
 *          her zaman çalışır. Derleyici iletisi ve çalıştırma:
 *          ciktilar/H14_F10_bos_if.txt
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F10_bos_if.c -o f10
 */
#include <stdio.h>

int main(void)
{
    int bakiye = 100;
    int cekilecek = 50;
    if (cekilecek > bakiye);
    {
        printf("Yetersiz bakiye\n");
        cekilecek = 0;
    }
    bakiye -= cekilecek;
    printf("Kalan: %d\n", bakiye);
    return 0;
}

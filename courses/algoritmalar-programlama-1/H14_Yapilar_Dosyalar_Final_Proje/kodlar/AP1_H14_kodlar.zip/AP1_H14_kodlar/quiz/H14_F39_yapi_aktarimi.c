/* H14_F39_yapi_aktarimi.c — Hafta 14 · Final hazırlık soru bankası, S39
 *          (H14 · ÖÇ 14.2 · çıktı tahmini): yapı kopyalama, değerle ve
 *          işaretçiyle aktarım
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F39_yapi_aktarimi.c -o f39
 */
#include <stdio.h>

typedef struct {
    char ad[8];
    int puan;
} Oyuncu;

void bonus_deger(Oyuncu o)
{
    o.puan += 10;
}

void bonus_isaretci(Oyuncu *o)
{
    o->puan += 10;
}

int main(void)
{
    Oyuncu a = {"Ece", 50};
    Oyuncu b = a;
    b.ad[0] = 'A';
    bonus_deger(a);
    bonus_isaretci(&b);
    printf("%s %d | %s %d\n", a.ad, a.puan, b.ad, b.puan);
    return 0;
}

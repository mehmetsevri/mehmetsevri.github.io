/* H14_Q07_enum.c — Hafta 14 · Quiz 7: enum sabitlerinin değerleri
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_Q07_enum.c -o q07
 */
#include <stdio.h>

enum Renk { KIRMIZI, YESIL = 5, MAVI };

int main(void)
{
    printf("%d %d %d\n", KIRMIZI, YESIL, MAVI);
    return 0;
}

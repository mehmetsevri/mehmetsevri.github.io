/* H14_F08_oncelik_birlesme.c — Hafta 14 · Final hazırlık soru bankası, S8
 *          (H4 · ÖÇ 4.2 · çıktı tahmini): operatör önceliği ve birleşme yönü
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F08_oncelik_birlesme.c -o f08
 */
#include <stdio.h>

int main(void)
{
    int a = 2 + 3 * 4 % 5;
    int b = 20 / 3 * 3;
    int c = 10 - 4 - 3;
    printf("%d %d %d\n", a, b, c);
    return 0;
}

/* H14_F18_assert_testi.c — Hafta 14 · Final hazırlık soru bankası, S18
 *          (H8 · ÖÇ 8.5 · hata bulma): assert ile birim testi
 * Soru   : asal_mi için üç birim testi yazılmıştır. Program (NDEBUG tanımlı
 *          değilken) derlenip çalıştırılınca ne olur?
 * BU DOSYA KASITLI HATA İÇERİR: asal_mi(1) true döndürür; üçüncü assert bu
 *          hatayı yakalar ve programı durdurur. Derleyici iletisi ve
 *          çalıştırma: ciktilar/H14_F18_assert_testi.txt
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F18_assert_testi.c -o f18
 */
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>

bool asal_mi(int n)
{
    for (int d = 2; d * d <= n; d++) {
        if (n % d == 0) {
            return false;
        }
    }
    return true;
}

int main(void)
{
    assert(asal_mi(7));
    assert(!asal_mi(9));
    assert(!asal_mi(1));
    printf("Tüm testler geçti\n");
    return 0;
}

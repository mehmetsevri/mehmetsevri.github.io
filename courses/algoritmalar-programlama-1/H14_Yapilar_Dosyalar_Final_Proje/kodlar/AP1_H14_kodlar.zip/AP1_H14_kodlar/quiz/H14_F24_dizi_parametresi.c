/* H14_F24_dizi_parametresi.c — Hafta 14 · Final hazırlık soru bankası, S24
 *          (H10 · ÖÇ 10.4 · çıktı tahmini): diziyi fonksiyona aktarma
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_F24_dizi_parametresi.c -o f24
 */
#include <stdio.h>

void ikiye_katla(int a[], int n)
{
    for (int i = 0; i < n; i++) {
        a[i] *= 2;
    }
    n = 0;
}

int main(void)
{
    int d[3] = {1, 2, 3};
    int n = 3;
    ikiye_katla(d, n);
    printf("%d %d %d | %d\n", d[0], d[1], d[2], n);
    return 0;
}

/* H14_K10_fscanf_donus.c — Hafta 14 · Kavram programı: fscanf'in dönüş
 * değeri
 * Amaç   : fscanf, BAŞARIYLA okunup atanan alan sayısını döndürür; hiçbir
 *          alan atanmadan girdi biterse EOF döndürür. Döngü koşulu
 *          "== 3" olmalıdır: döngü bitince EOF mu (normal son) yoksa
 *          bozuk bir satır mı (0, 1 ya da 2) olduğu ayırt edilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K10_fscanf_donus.c -o fscanf_donus
 * Örnek  : -> 2 kayıt okundu; 3. kayıtta fscanf 1 döndürdü: bozuk veri
 */
#include <stdio.h>

static int dosyayi_oku(const char *yol)
{
    FILE *f = fopen(yol, "r");
    if (f == NULL) {
        perror(yol);
        return -1;
    }
    long long no;
    double vize, final;
    int n = 0, r;
    while ((r = fscanf(f, "%lld %lf %lf", &no, &vize, &final)) == 3) {
        n++;
        printf("  %lld  ort %.2f\n", no, 0.4 * vize + 0.6 * final);
    }
    if (r == EOF) {
        printf("%s: %d kayıt okundu; dosya sonu (fscanf EOF döndürdü)\n",
               yol, n);
    } else {
        printf("%s: %d kayıt okundu; %d. kayıtta fscanf %d döndürdü: "
               "bozuk veri\n", yol, n, n + 1, r);
    }
    fclose(f);
    return n;
}

int main(void)
{
    FILE *f = fopen("saglam.txt", "w");
    if (f == NULL) {
        return 1;
    }
    fputs("2301010045 70 85\n2301010046 45 48\n", f);
    fclose(f);
    f = fopen("bozuk.txt", "w");
    if (f == NULL) {
        return 1;
    }
    fputs("2301010045 70 85\n2301010046 45 48\n2301010047 sekiz 92\n", f);
    fclose(f);

    dosyayi_oku("saglam.txt");
    dosyayi_oku("bozuk.txt");
    remove("saglam.txt");
    remove("bozuk.txt");
    return 0;
}

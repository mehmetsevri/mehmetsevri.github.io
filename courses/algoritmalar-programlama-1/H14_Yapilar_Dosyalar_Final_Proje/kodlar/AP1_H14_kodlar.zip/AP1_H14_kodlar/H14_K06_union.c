/* H14_K06_union.c — Hafta 14 · Kavram programı (Merak Kutusu): union
 * Amaç   : union'ın bütün üyeleri AYNI adresten başlar; boyutu en
 *          büyük üyeye yeter. Aynı anda en çok BİR üyenin değeri
 *          saklanır: taşınabilir program yalnızca SON YAZILAN üyeyi
 *          okur. Başka bir üye okunursa baytlar yeni tipte yeniden
 *          yorumlanır (sonuç uygulamaya bağlıdır; burada IEEE 754,
 *          H3). Yaygın kullanım: hangi üyenin geçerli olduğunu tutan
 *          bir enum etiketiyle birlikte ("etiketli union").
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K06_union.c -o union_deneyi
 * Örnek  : -> 1.0f'ın baytları int olarak: 0x3F800000
 */
#include <stdio.h>

typedef union {
    int i;
    float f;
    char c[8];
} Deger;

typedef enum { TAMSAYI, ONDALIK } Tur;

typedef struct {
    Tur tur;                        /* hangi üye geçerli? */
    union {
        int i;
        double d;
    } u;
} Sayi;

static void sayi_yaz(Sayi s)
{
    if (s.tur == TAMSAYI) {
        printf("tamsayı %d\n", s.u.i);
    } else {
        printf("ondalık %.2f\n", s.u.d);
    }
}

int main(void)
{
    Deger d;
    printf("sizeof(Deger) = %zu\n", sizeof(Deger));
    printf("&d.i = %p, &d.f = %p\n", (void *)&d.i, (void *)&d.f);
    d.f = 1.0f;                     /* son yazılan: f */
    printf("d.f = %.1f\n", d.f);
    printf("1.0f'ın baytları int olarak: 0x%08X\n", (unsigned)d.i);

    Sayi a = {TAMSAYI, {.i = 42}};
    Sayi b = {ONDALIK, {.d = 85.5}};
    sayi_yaz(a);
    sayi_yaz(b);
    return 0;
}

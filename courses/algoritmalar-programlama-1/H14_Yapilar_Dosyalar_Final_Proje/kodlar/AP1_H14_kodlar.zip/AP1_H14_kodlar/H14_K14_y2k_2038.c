/* H14_K14_y2k_2038.c — Hafta 14 · Kavram programı: iki haneli yıl ve
 * 2038 sınırı
 * Amaç   : (1) Yılı İKİ haneyle saklayan bir kayıt (Y2K): 1930
 *          doğumlu birinin yaşı 1999'da doğru, 2000'de ("00") negatif
 *          çıkar (GAO, 1997'deki örnek). Onarım yollarından "pencere"
 *          (pivot yıl): 00-29 → 20xx, 30-99 → 19xx. (2) 2038: zamanı
 *          1970'ten beri geçen saniye olarak İŞARETLİ 32 bitle tutan
 *          sistemlerin son anı. Bu sistemde time_t 64 bittir; 32 bitlik
 *          sınır değerleri gmtime ile tarihe çevrilir.
 * Not    : time_t'nin "1970'ten beri saniye" olması POSIX'in tanımıdır;
 *          C standardı time_t'nin gösterimini uygulamaya bırakır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K14_y2k_2038.c -o y2k_2038
 * Örnek  : -> 2147483647 s -> 2038-01-19 03:14:07 UTC
 */
#include <stdio.h>
#include <stdint.h>
#include <time.h>

typedef struct {
    char ad[16];
    int dogum_yy;                   /* İKİ hane: 30 = 1930 (!) */
} EskiKayit;

static int yas_iki_hane(EskiKayit k, int bugun_yy)
{
    return bugun_yy - k.dogum_yy;   /* yüzyıl bilgisi yok */
}

static int pencere(int yy)          /* pivot 30: 00-29 → 20xx */
{
    return (yy < 30) ? 2000 + yy : 1900 + yy;
}

static void tarih_yaz(long long saniye)
{
    time_t t = (time_t)saniye;
    struct tm *u = gmtime(&t);
    char metin[32];
    if (u != NULL && strftime(metin, sizeof metin, "%Y-%m-%d %H:%M:%S", u)) {
        printf("%11lld s -> %s UTC\n", saniye, metin);
    }
}

int main(void)
{
    EskiKayit k = {"EMEKLİ ADAY", 30};
    printf("1999'da yaş: %d\n", yas_iki_hane(k, 99));
    printf("2000'de yaş: %d   (\"00\" - \"30\")\n", yas_iki_hane(k, 0));
    printf("Pencereyle: 2000'de yaş %d\n", pencere(0) - pencere(k.dogum_yy));

    printf("sizeof(time_t) = %zu bayt\n", sizeof(time_t));
    tarih_yaz(INT32_MAX);                       /* 32 bitin son anı */
    tarih_yaz((long long)INT32_MAX + 1);        /* 64 bitte sorun yok */
    tarih_yaz(INT32_MIN);                       /* 32 bit taşınca */
    return 0;
}

/* H14_K11_strtok_bos_alan.c — Hafta 14 · Kavram programı: strtok boş
 * alanı yutar
 * Amaç   : strtok ardışık ayırıcıları TEK ayırıcı sayar; CSV'deki boş
 *          alan ("1;;B") kaybolur ve alanlar kayar. Mini-OBS v1.0'daki
 *          alanlara_bol (dosya.c) ise her ';' noktasında böler: boş
 *          alan da bir alandır. İkisi de satırı DEĞİŞTİRİR (';' → '\0').
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K11_strtok_bos_alan.c -o strtok_bos_alan
 * Örnek  : -> alanlara_bol: 4 alan: [1] [] [ÇELİK] [70]
 */
#include <stdio.h>
#include <string.h>

/* satir'ı ';' noktalarında böler: her ';' yerine '\0' yazar ve alanların
 * başlangıç adreslerini alanlar[]'a koyar. Boş alanlar da sayılır ("a;;b" →
 * 3 alan); strtok ise ardışık ayırıcıları tek sayar ve boş alanı yutar.
 * Son koşul: alan sayısı; azami'den fazlaysa azami + 1. */
static int alanlara_bol(char *satir, char *alanlar[], int azami)
{
    int sayi = 0;
    char *p = satir;
    for (;;) {
        if (sayi == azami) {
            return azami + 1;                  /* fazladan alan var */
        }
        alanlar[sayi++] = p;
        char *ayrac = strchr(p, ';');
        if (ayrac == NULL) {
            return sayi;
        }
        *ayrac = '\0';
        p = ayrac + 1;
    }
}

static void yaz(const char *etiket, char *alan[], int n)
{
    printf("%s: %d alan:", etiket, n);
    for (int i = 0; i < n; i++) {
        printf(" [%s]", alan[i]);
    }
    printf("\n");
}

int main(void)
{
    char s1[] = "1;;ÇELİK;70";          /* ad alanı BOŞ */
    char s2[] = "1;;ÇELİK;70";
    char *alan[8];
    int n = 0;
    for (char *p = strtok(s1, ";"); p != NULL; p = strtok(NULL, ";")) {
        alan[n++] = p;
    }
    yaz("strtok      ", alan, n);
    n = alanlara_bol(s2, alan, 8);
    yaz("alanlara_bol", alan, n);
    return 0;
}

/* H14_06_en_yuksek_ortalama.c — Hafta 14 · Örnek 6 (★★): Yapı dizisi
 * Amaç   : H10'daki paralel diziler (no[], vize[], final[]) yerine TEK
 *          bir yapı dizisi: sinif[i] bir öğrencinin BÜTÜN verisidir.
 *          H10'un "en büyüğün indisi" deseni aynen çalışır; indis bir
 *          kaydı (no, ad, notlar) birlikte seçer.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_06_en_yuksek_ortalama.c -o en_yuksek_ortalama
 * Örnek  : -> En yüksek ortalama: İSMAİL (2301010047) 90.40
 */
#include <stdio.h>

typedef struct {
    long long no;
    char ad[32];
    double vize;
    double final;
} Ogrenci;

double ortalama(Ogrenci o)
{
    return 0.4 * o.vize + 0.6 * o.final;
}

/* Ön koşul: n >= 1.  Son koşul: en yüksek ortalamanın İLK indisi. */
int en_yuksek_indis(const Ogrenci a[], int n)
{
    int enb = 0;
    for (int i = 1; i < n; i++) {
        if (ortalama(a[i]) > ortalama(a[enb])) {
            enb = i;
        }
    }
    return enb;
}

int main(void)
{
    Ogrenci sinif[] = {
        {2301010045, "AYŞE NUR", 70, 85},
        {2301010046, "MEHMET ALİ", 45, 48},
        {2301010047, "İSMAİL", 88, 92},
        {2301010048, "CAN", 85.5, 90.25},
    };
    int n = sizeof sinif / sizeof sinif[0];     /* 224 / 56 = 4 */

    for (int i = 0; i < n; i++) {
        printf("%d) %lld  %6.2f  %s\n", i + 1, sinif[i].no,
               ortalama(sinif[i]), sinif[i].ad);
    }
    int k = en_yuksek_indis(sinif, n);
    printf("En yüksek ortalama: %s (%lld) %.2f\n", sinif[k].ad,
           sinif[k].no, ortalama(sinif[k]));
    printf("sizeof sinif = %zu, sizeof sinif[0] = %zu\n",
           sizeof sinif, sizeof sinif[0]);
    return 0;
}

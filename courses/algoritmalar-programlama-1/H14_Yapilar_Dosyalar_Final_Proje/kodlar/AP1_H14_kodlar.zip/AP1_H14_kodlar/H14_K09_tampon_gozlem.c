/* H14_K09_tampon_gozlem.c — Hafta 14 · Kavram programı: tamponu
 * gözlemek
 * Amaç   : fprintf veriyi önce C kütüphanesinin TAMPONUNA yazar;
 *          işletim sistemine ancak tampon dolunca, fflush ya da fclose
 *          ile gider. Dosyanın işletim sistemindeki boyutunu ikinci bir
 *          akışla (fseek + ftell) ölçerek bunu görürüz; sonra tampon
 *          kendiliğinden boşalana dek karakter yazıp tampon boyutunu
 *          ölçeriz (uygulamaya bağlıdır; BUFSIZ yalnızca bir öneridir).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K09_tampon_gozlem.c -o tampon_gozlem
 * Örnek  : -> fflush sonrası işletim sisteminde: 17 bayt
 */
#include <stdio.h>

#define DOSYA "tampon.txt"

/* Dosyanın işletim sisteminin gördüğü boyutu (ayrı bir akışla) */
static long boyut(void)
{
    FILE *g = fopen(DOSYA, "rb");
    if (g == NULL) {
        return -1;
    }
    fseek(g, 0, SEEK_END);
    long n = ftell(g);
    fclose(g);
    return n;
}

int main(void)
{
    FILE *f = fopen(DOSYA, "w");
    if (f == NULL) {
        perror(DOSYA);
        return 1;
    }
    fprintf(f, "2301010045;70;85\n");              /* 17 bayt */
    printf("fprintf sonrası işletim sisteminde: %ld bayt\n", boyut());
    fflush(f);                                      /* tamponu boşalt */
    printf("fflush sonrası işletim sisteminde: %ld bayt\n", boyut());

    long yazilan = 0;
    long once = boyut();
    while (boyut() == once) {                       /* boşalana dek yaz */
        fputc('x', f);
        yazilan++;
    }
    printf("%ld karakter sonra tampon kendiliğinden boşaldı: %ld bayt\n",
           yazilan, boyut());
    fclose(f);                                      /* kalanı yazar */
    printf("fclose sonrası işletim sisteminde: %ld bayt\n", boyut());
    printf("BUFSIZ = %d\n", BUFSIZ);
    remove(DOSYA);
    return 0;
}

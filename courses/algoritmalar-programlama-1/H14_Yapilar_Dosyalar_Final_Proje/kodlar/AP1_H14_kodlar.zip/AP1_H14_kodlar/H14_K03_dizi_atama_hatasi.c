/* H14_K03_dizi_atama_hatasi.c — Hafta 14 · Kavram programı: diziler
 * atanamaz, yapılar atanır
 * BU DOSYA KASITLI HATA İÇERİR: iki DİZİ birbirine atanmaya çalışılıyor
 * (derleme hatası). Aynı dizi bir yapının üyesiyken yapı ataması onu
 * sorunsuz kopyalar (H14_K02_atama_kopya.c).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K03_dizi_atama_hatasi.c -o dizi_atama
 */
#include <stdio.h>

typedef struct {
    int notlar[3];
} Karne;

int main(void)
{
    int a[3] = {70, 85, 90};
    int b[3];
    b = a;                      /* HATA: dizi tipine atama yapılamaz */

    Karne k1 = {{70, 85, 90}};
    Karne k2;
    k2 = k1;                    /* geçerli: içindeki dizi kopyalanır */
    printf("%d %d\n", b[0], k2.notlar[2]);
    return 0;
}

/* H14_04_metin_dosyasi.c — Hafta 14 · Örnek 4 (★): Metin dosyasına
 * yazma ve okuma
 * Amaç   : Program kapandıktan sonra da duran veri: fopen ile bir
 *          AKIŞ (FILE *) açmak, fprintf/fputs ile yazmak, fclose ile
 *          kapatmak; aynı dosyayı yeniden açıp fgets ile satır satır
 *          okumak. Her fopen sonucu NULL'a karşı denetlenir.
 * Not    : Okuma döngüsü DOĞRU örüntüdür: while (fgets(...) != NULL).
 *          "w" kipi dosya varsa İÇERİĞİNİ SİLER (bkz. Hata Avcısı 6).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_04_metin_dosyasi.c -o metin_dosyasi
 * Örnek  : -> 3 satır okundu.
 */
#include <stdio.h>

#define DOSYA "notlar.txt"

int main(void)
{
    FILE *f = fopen(DOSYA, "w");            /* yazmak için; yoksa oluşur */
    if (f == NULL) {
        perror(DOSYA);
        return 1;
    }
    fprintf(f, "%lld %d %d\n", 2301010045LL, 70, 85);
    fprintf(f, "%lld %d %d\n", 2301010046LL, 45, 48);
    fputs("2301010047 88 92\n", f);
    if (fclose(f) != 0) {                   /* tampon yazılamadıysa */
        perror(DOSYA);
        return 1;
    }

    f = fopen(DOSYA, "r");                  /* okumak için */
    if (f == NULL) {
        perror(DOSYA);
        return 1;
    }
    char satir[128];
    int sayac = 0;
    while (fgets(satir, sizeof satir, f) != NULL) {
        sayac++;
        printf("%d: %s", sayac, satir);     /* satir '\n' içerir */
    }
    fclose(f);
    printf("%d satır okundu.\n", sayac);
    return 0;
}

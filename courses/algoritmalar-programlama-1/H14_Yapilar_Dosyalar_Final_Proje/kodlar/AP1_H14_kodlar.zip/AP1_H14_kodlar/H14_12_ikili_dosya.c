/* H14_12_ikili_dosya.c — Hafta 14 · Örnek 12 (★★★): İkili dosyaya yapı
 * dizisi yazma/okuma ve onaltılı inceleme
 * Amaç   : fwrite yapıları BELLEKTEKİ BAYTLARIYLA (dolgu dahil) yazar,
 *          fread aynı baytları geri okur: biçimlendirme yok, çözümleme
 *          yok. Her kayıt aynı boyutta olduğu için k. kayda fseek ile
 *          doğrudan gidilir; ftell konumu (bayt) verir. Aynı veri metin
 *          olarak da yazılıp boyutlar karşılaştırılır.
 * Not    : İkili dosya TAŞINABİLİR DEĞİLDİR: dolgu, bayt sırası
 *          (küçük-uçlu, H03_K02) ve sizeof derleyiciye/makineye bağlıdır.
 *          memset dolgu baytlarını da sıfırlar (dosyaya çöp sızmasın).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_12_ikili_dosya.c -o ikili_dosya
 * Örnek  : -> 3. kayıt (fseek 48): 3 ZEYNEP 52.00
 */
#include <stdio.h>
#include <string.h>

typedef struct {
    int no;                 /* 4 bayt, offset 0          */
    char ad[8];             /* 8 bayt, offset 4          */
    double ort;             /* 8 bayt, offset 16 (4 dolgu) */
} Kayit;

static Kayit kayit_yap(int no, const char *ad, double ort)
{
    Kayit k;
    memset(&k, 0, sizeof k);            /* dolgu dahil bütün baytlar 0 */
    k.no = no;
    snprintf(k.ad, sizeof k.ad, "%s", ad);
    k.ort = ort;
    return k;
}

int main(void)
{
    Kayit yaz[3] = { kayit_yap(1, "EMRE", 79.0),
                     kayit_yap(2, "CAN", 88.35),
                     kayit_yap(3, "ZEYNEP", 52.0) };
    FILE *f = fopen("kayitlar.dat", "wb");          /* b: ikili */
    if (f == NULL) {
        perror("kayitlar.dat");
        return 1;
    }
    size_t yazilan = fwrite(yaz, sizeof yaz[0], 3, f);
    if (fclose(f) != 0 || yazilan != 3) {
        fprintf(stderr, "Yazma hatası\n");
        return 1;
    }
    FILE *t = fopen("kayitlar.txt", "w");           /* aynı veri, metin */
    if (t == NULL) {
        perror("kayitlar.txt");
        return 1;
    }
    for (int i = 0; i < 3; i++) {
        fprintf(t, "%d;%s;%.2f\n", yaz[i].no, yaz[i].ad, yaz[i].ort);
    }
    fclose(t);

    f = fopen("kayitlar.dat", "rb");
    if (f == NULL) {
        perror("kayitlar.dat");
        return 1;
    }
    fseek(f, 0, SEEK_END);                          /* sona git */
    printf("sizeof(Kayit) = %zu, dosya = %ld bayt\n", sizeof(Kayit),
           ftell(f));
    rewind(f);                                      /* başa dön */
    Kayit oku[10];
    size_t n = fread(oku, sizeof oku[0], 10, f);    /* 10 istendi */
    printf("fread %zu kayıt döndürdü\n", n);
    for (size_t i = 0; i < n; i++) {
        printf("  %d %-6s %.2f\n", oku[i].no, oku[i].ad, oku[i].ort);
    }
    long konum = 2 * (long)sizeof(Kayit);           /* 3. kaydın başı */
    Kayit k;
    if (fseek(f, konum, SEEK_SET) == 0 && fread(&k, sizeof k, 1, f) == 1) {
        printf("3. kayıt (fseek %ld): %d %s %.2f\n", konum, k.no, k.ad,
               k.ort);
    }
    fclose(f);
    return 0;
}

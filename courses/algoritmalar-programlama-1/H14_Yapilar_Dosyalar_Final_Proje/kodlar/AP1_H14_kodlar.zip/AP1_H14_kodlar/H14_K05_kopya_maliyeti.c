/* H14_K05_kopya_maliyeti.c — Hafta 14 · Kavram programı: değerle
 * aktarımın maliyeti
 * Amaç   : Değerle aktarılan yapının BÜTÜN baytları her çağrıda
 *          kopyalanır; işaretçiyle yalnızca 8 baytlık adres gider.
 *          4 KiB'lık bir yapıyla bir milyon çağrı clock() ile ölçülür
 *          (H7'deki ölçüm kültürü). Süreler makineye ve derleme
 *          seçeneklerine bağlıdır: oranı yorumlayın, sayıyı değil.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K05_kopya_maliyeti.c -o kopya_maliyeti
 * Örnek  : -> sizeof(Buyuk) = 4096 bayt, sizeof(&b) = 8 bayt
 */
#include <stdio.h>
#include <time.h>

#define CAGRI 1000000

typedef struct {
    double veri[512];               /* 512 × 8 = 4096 bayt */
} Buyuk;

double ilk_deger(Buyuk b)           /* her çağrıda 4096 bayt kopya */
{
    return b.veri[0];
}

double ilk_isaretci(const Buyuk *b) /* her çağrıda 8 bayt adres */
{
    return b->veri[0];
}

int main(void)
{
    static Buyuk b = {{1.0}};       /* static: yığını şişirmesin */
    double toplam = 0;

    clock_t t0 = clock();
    for (int i = 0; i < CAGRI; i++) {
        toplam += ilk_deger(b);
    }
    clock_t t1 = clock();
    for (int i = 0; i < CAGRI; i++) {
        toplam += ilk_isaretci(&b);
    }
    clock_t t2 = clock();

    printf("sizeof(Buyuk) = %zu bayt, sizeof(&b) = %zu bayt\n",
           sizeof(Buyuk), sizeof(&b));
    printf("değerle   : %.3f s\n", (double)(t1 - t0) / CLOCKS_PER_SEC);
    printf("işaretçiyle: %.3f s\n", (double)(t2 - t1) / CLOCKS_PER_SEC);
    printf("(toplam = %.0f)\n", toplam);
    return 0;
}

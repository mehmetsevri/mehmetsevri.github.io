/* H14_K13_obs_ceviri_birimi.c — Hafta 14 · Kavram programı: Mini-OBS v1.0
 * çeviri birimi
 * Amaç   : Mini-OBS v1.0'daki main.c'nin önişlemciden sonraki hâlini ELLE
 *          göstermek: #include "obs.h", "metin.h" ve "dosya.h" yerine
 *          arayüzlerin metni yapıştırıldı (H09_K11 ve H12_K13 ile aynı yöntem).
 *          Yapı tipleri (DersNotu, Ogrenci, Sinif), enum MenuSecimi,
 *          DosyaTuru, DosyaDurumu ve bütün bildirimler burada görülür.
 *          dosya.h'nin içindeki #include "obs.h" satırı başlık koruması
 *          (OBS_H) sayesinde ikinci kez bir şey eklemez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -Iproje \
 *              H14_K13_obs_ceviri_birimi.c proje/metin.c proje/obs.c \
 *              proje/dosya.c -o obs_birim -lm
 */
#include <stdio.h>
#include <stdbool.h>
/* ---- #include "obs.h" satırının yerine başlığın metni ---- */
/* obs.h — Mini-OBS v1.0 (AP-1 Hafta 14): kayıt tipleri ve iş kuralları
 * Yenilik : Altı paralel blok (no, ad, soyad, vize, final, ort) TEK bir
 *           kayıt tipinde toplandı:
 *               DersNotu  { vize, final, ort }            (bir ders)
 *               Ogrenci   { no, ad, soyad, ders[3] }       (iç içe yapı)
 *               Sinif     { kayit, n, kapasite }           (öbekte yapı dizisi)
 *           Aynı öğrencinin bütün verisi bellekte yan yana durur; büyütme
 *           tek realloc'tur (v0.13'te altı ayrı realloc gerekiyordu).
 *           Yapılar fonksiyonlara const işaretçiyle aktarılır (kopyalama
 *           yok, değiştirme yok); değiştiren fonksiyonlar const'suz alır.
 *           Menü seçenekleri enum MenuSecimi ile adlandırılır.
 * Kurallar: RTEÜ yönetmeliği (RG 14.12.2025, 33107; son değişiklik RG
 *           27.02.2026, 33181), md. 25/2, 26/2, 30, 31/2-a — obs.c başında.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>

#define DERS_SAYISI 3       /* her öğrencinin ders sayısı (örnek) */
#define HARF_SAYISI 9       /* AA, BA, BB, CB, CC, DC, DD, FD, FF */
#define AD_BOYUT 32         /* ad için en çok 31 bayt + '\0' */
#define SOYAD_BOYUT 32      /* soyad için en çok 31 bayt + '\0' */

typedef struct {
    double vize;
    double final;
    double ort;             /* %40 vize + %60 final; ders_notu_ata hesaplar */
} DersNotu;

typedef struct {
    long long no;
    char ad[AD_BOYUT];      /* normalleştirilmiş, '\0' ile biten UTF-8 */
    char soyad[SOYAD_BOYUT];
    DersNotu ders[DERS_SAYISI];
} Ogrenci;

typedef struct {
    Ogrenci *kayit;         /* öbekte, kapasite elemanlık yapı dizisi */
    int n;                  /* dolu kayıt sayısı */
    int kapasite;
} Sinif;

typedef enum {
    MENU_EKLE = 1,
    MENU_LISTELE,
    MENU_ARA,
    MENU_GUNCELLE,
    MENU_SIL,
    MENU_ISTATISTIK,
    MENU_TRANSKRIPT,
    MENU_HARF_TABLOSU,
    MENU_KAYDET,
    MENU_CIKIS              /* = 10 */
} MenuSecimi;

/* ---- hesap kuralları (v0.8'den, değişmedi) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
int harf_indeksi(int yuvarlanmis, double final);   /* AA=0 ... FF=8 */
const char *harf_adi(int indeks);
double harf_katsayisi(int indeks);                 /* AA 4,00 ... FF 0,00 */

/* ---- dersler (örnek değerler) ---- */
const char *ders_adi(int d);
const char *ders_kodu(int d);
int ders_kredisi(int d);

/* ---- 1B dizi desenleri (v0.10'dan) ---- */
double dizi_ortalama(const double a[], int n);
double standart_sapma(const double a[], int n);
void min_max_indis(const double a[], int n, int *enk, int *enb);

/* ---- tek kayıt ---- */
void ders_notu_ata(DersNotu *dn, double vize, double final);
int ders_harfi(const DersNotu *dn);                /* harf indisi */
double ogrenci_yano(const Ogrenci *o);
bool ogrenci_gecerli_mi(const Ogrenci *o);          /* dosyadan okunan kayıt için */

/* ---- sınıf (yapı dizisi) ---- */
void sinif_baslat(Sinif *s);
bool sinif_ekle(Sinif *s, const Ogrenci *o);       /* gerekirse büyütür */
bool sinif_sil(Sinif *s, int indis);               /* sırayı korur */
void sinif_birak(Sinif *s);
int sinif_numara_bul(const Sinif *s, long long no);
int sinif_isim_bul(const Sinif *s, const char *aranan, int baslangic);

/* ---- istatistik ---- */
bool ders_istatistigi(const Sinif *s, int d, double *ortalama, double *sapma,
                      int *enb, int *enk, int *basarili, int *sartli);
void ders_harf_dagilimi(const Sinif *s, int sayac[DERS_SAYISI][HARF_SAYISI]);

/* ---- ekran ---- */
void baslik_yaz(void);
void menu_goster(const char *dosya_yolu, int kayit_sayisi, bool degisti);
void ogrenci_ozeti_yaz(const Ogrenci *o);
void transkript_yaz(const Ogrenci *o);
void ders_istatistikleri_yaz(const Sinif *s);
void harf_tablosu_yaz(const Sinif *s);
void kayitlari_listele(const Sinif *s);
void arama_sonucu_yaz(const Sinif *s, const char *aranan);

#endif /* OBS_H */
/* ---- başlığın sonu ---- */
/* ---- #include "metin.h" satırının yerine başlığın metni ---- */
/* metin.h — Mini-OBS v1.0 (AP-1 Hafta 14): güvenli girdi ve metin işleme
 * v0.13'te obs.c içinde olan girdi ve metin fonksiyonları kendi modülüne
 * taşındı: hiçbiri öğrenci kaydını bilmez, başka programlarda da
 * kullanılabilir (yüksek uyum, düşük bağlaşım).
 * Bütün girdiler satır satır fgets ile okunur; scanf kullanılmaz.
 * Metinler UTF-8'dir: Türkçe harfler 2 bayttır (bayt ≠ karakter).
 */
#ifndef METIN_H
#define METIN_H

#include <stdbool.h>
#include <stddef.h>   /* size_t */

#define SATIR_BOYUT 128     /* bir girdi satırı için tampon (+ '\n' + '\0') */

/* ---- satır okuma ve sayı çözümleme ---- */
int satir_oku(char *tampon, size_t boyut);         /* 1 tamam, 0 çok uzun, -1 EOF */
bool tamsayi_coz(const char *metin, long long *sonuc);
bool ondalik_coz(const char *metin, double *sonuc);

/* ---- ad işleme ---- */
int ad_normallestir(const char *kaynak, char *hedef, size_t boyut);
bool ad_gecerli_mi(const char *ad);
size_t utf8_karakter_sayisi(const char *s);
void hizali_yaz(const char *s, int genislik);

/* ---- etkileşimli girdi (istem yazar, geçersizde yeniden sorar) ---- */
int secim_oku(const char *etiket, int en_kucuk, int en_buyuk); /* EOF → -1 */
long long numara_oku(const char *etiket);                       /* EOF → -1 */
double not_oku(const char *etiket);                             /* EOF → -1.0 */
int ad_oku(const char *etiket, char *hedef, size_t boyut);      /* 1 / EOF → -1 */
int evet_mi_oku(const char *etiket);                            /* 1 E, 0 H, -1 EOF */

#endif /* METIN_H */
/* ---- başlığın sonu ---- */
/* ---- #include "dosya.h" satırının yerine başlığın metni ---- */
/* dosya.h — Mini-OBS v1.0 (AP-1 Hafta 14): kalıcı saklama
 * İki biçim, dosya uzantısına göre seçilir:
 *   .csv → METİN: bir başlık satırı + öğrenci başına bir satır, alanlar ';'
 *          ile ayrılır (Türkçe Excel'in liste ayırıcısı; ondalık ayırıcı
 *          nokta). İnsan okuyabilir, Excel'de açılır, makineden makineye
 *          taşınır.
 *   .dat → İKİLİ: 16 baytlık başlık (imza "MOBS", sürüm, kayıt boyutu,
 *          kayıt sayısı) + Ogrenci yapıları bellekteki gibi (fwrite).
 *          Hızlı ve kayıpsız, ancak TAŞINABİLİR DEĞİL: dolgu, bayt sırası,
 *          double biçimi ve sizeof derleyiciye/makineye bağlıdır.
 * Kaydetme önce "<yol>.tmp" dosyasına yazar, başarılıysa adını değiştirir:
 * yazma yarıda kalırsa eski veri dosyası bozulmaz; yeni dosya yerine
 * konamazsa (DOSYA_TASIMA_HATASI) yeni veri "<yol>.tmp" dosyasında kalır.
 * CSV okuyucu, Excel'in "CSV UTF-8" biçimindeki dosya başı imzasını (BOM:
 * EF BB BF baytları) atlar.
 */
#ifndef DOSYA_H
#define DOSYA_H

#include <stdio.h>
#include "obs.h"

typedef enum {
    DOSYA_CSV,
    DOSYA_IKILI,
    DOSYA_BILINMIYOR
} DosyaTuru;

typedef enum {
    DOSYA_TAMAM = 0,
    DOSYA_YOK,              /* dosya bulunamadı (ilk çalıştırma) */
    DOSYA_ACILAMADI,        /* izin, klasör yok vb. */
    DOSYA_BICIM_HATASI,     /* bozuk satır, eksik alan, geçersiz kayıt */
    DOSYA_BELLEK_YETERSIZ,
    DOSYA_OKUMA_HATASI,
    DOSYA_YAZMA_HATASI,     /* disk dolu, fclose başarısız vb. */
    DOSYA_TASIMA_HATASI     /* yeni veri yazıldı ama yerine konamadı: <yol>.tmp */
} DosyaDurumu;

DosyaTuru dosya_turu(const char *yol);
const char *dosya_durumu_metni(DosyaDurumu d);

/* Açık bir akış üzerinde (testlerde tmpfile ile de kullanılır) */
DosyaDurumu csv_yaz(FILE *f, const Sinif *s);
DosyaDurumu csv_oku(FILE *f, Sinif *s, int *hatali_satir);
DosyaDurumu ikili_yaz(FILE *f, const Sinif *s);
DosyaDurumu ikili_oku(FILE *f, Sinif *s);

/* Dosya yolu ile: biçimi uzantı seçer */
DosyaDurumu sinif_yukle(const char *yol, Sinif *s, int *hatali_satir);
DosyaDurumu sinif_kaydet(const char *yol, const Sinif *s);

#endif /* DOSYA_H */
/* ---- başlığın sonu ---- */

static const char *const VARSAYILAN_DOSYA = "ogrenciler.csv";

/* Numara sorar ve kaydın indisini döndürür; kayıt yoksa iletisini yazıp
 * -2, girdi biterse -1 döndürür. */
static int kayit_sor(const Sinif *s)
{
    long long numara = numara_oku("Öğrenci numarası : ");
    if (numara == -1) {
        return -1;
    }
    int i = sinif_numara_bul(s, numara);
    if (i == -1) {
        printf("  Kayıt bulunamadı: %lld\n", numara);
        return -2;
    }
    return i;
}

static bool islem_ekle(Sinif *s, bool *degisti)
{
    Ogrenci o = {0};      /* bütün baytlar sıfır: dosyaya bellek artığı yazılmaz */
    printf("\n------------ ÖĞRENCİ %d ------------\n", s->n + 1);
    o.no = numara_oku("Öğrenci numarası : ");
    if (o.no == -1) {
        return false;
    }
    int bulunan = sinif_numara_bul(s, o.no);
    if (bulunan != -1) {
        printf("  Bu numara zaten kayıtlı (sıra %d).\n", bulunan + 1);
        return true;
    }
    if (ad_oku("Ad               : ", o.ad, sizeof o.ad) == -1
        || ad_oku("Soyad            : ", o.soyad, sizeof o.soyad) == -1) {
        return false;
    }
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("-- %s (%d kredi) --\n", ders_adi(d), ders_kredisi(d));
        double v = not_oku("Vize notu        : ");
        if (v < 0) {
            return false;
        }
        double f = not_oku("Final notu       : ");
        if (f < 0) {
            return false;
        }
        ders_notu_ata(&o.ders[d], v, f);
    }
    if (!sinif_ekle(s, &o)) {
        printf("  Bellek yetersiz: kayıt eklenemedi (%d öğrenci korunuyor).\n", s->n);
        return true;
    }
    *degisti = true;
    ogrenci_ozeti_yaz(&s->kayit[s->n - 1]);
    return true;
}

static bool islem_ara(const Sinif *s)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    char satir[SATIR_BOYUT];
    char aranan[AD_BOYUT + SOYAD_BOYUT];
    long long numara;
    printf("Numara ya da ad  : ");
    int durum = satir_oku(satir, sizeof satir);
    if (durum == -1) {
        return false;
    }
    if (durum == 1 && tamsayi_coz(satir, &numara)) {    /* sayıysa numara */
        int i = sinif_numara_bul(s, numara);
        if (i == -1) {
            printf("  Kayıt bulunamadı: %lld\n", numara);
        } else {
            ogrenci_ozeti_yaz(&s->kayit[i]);
        }
    } else if (durum == 1 && ad_normallestir(satir, aranan, sizeof aranan) > 0) {
        arama_sonucu_yaz(s, aranan);
    } else {
        printf("  Geçersiz: boş ya da çok uzun bir arama.\n");
    }
    return true;
}

static bool islem_guncelle(Sinif *s, bool *degisti)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    int i = kayit_sor(s);
    if (i < 0) {
        return i == -2;                    /* -2: kayıt yok, menüye dön */
    }
    Ogrenci *o = &s->kayit[i];             /* kaydın KENDİSİNİ değiştireceğiz */
    printf("%s %s — dersler:\n", o->ad, o->soyad);
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("  %d) %-20s  vize %6.2f  final %6.2f\n", d + 1, ders_adi(d),
               o->ders[d].vize, o->ders[d].final);
    }
    int d = secim_oku("Ders (1-3)       : ", 1, DERS_SAYISI);
    if (d == -1) {
        return false;
    }
    double v = not_oku("Yeni vize notu   : ");
    if (v < 0) {
        return false;
    }
    double f = not_oku("Yeni final notu  : ");
    if (f < 0) {
        return false;
    }
    ders_notu_ata(&o->ders[d - 1], v, f);  /* o->ders[...]: (*o).ders[...] */
    *degisti = true;
    printf("  Güncellendi.\n");
    ogrenci_ozeti_yaz(o);
    return true;
}

static bool islem_sil(Sinif *s, bool *degisti)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    int i = kayit_sor(s);
    if (i < 0) {
        return i == -2;
    }
    char istem[160];                       /* istem metni snprintf ile kurulur */
    snprintf(istem, sizeof istem, "%lld %s %s silinsin mi? (E/H) : ",
             s->kayit[i].no, s->kayit[i].ad, s->kayit[i].soyad);
    int yanit = evet_mi_oku(istem);
    if (yanit == -1) {
        return false;
    }
    if (yanit == 1 && sinif_sil(s, i)) {
        *degisti = true;
        printf("  Silindi. Kalan kayıt: %d\n", s->n);
    } else {
        printf("  Silme iptal edildi.\n");
    }
    return true;
}

static bool islem_transkript(const Sinif *s)
{
    if (s->n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return true;
    }
    int i = kayit_sor(s);
    if (i < 0) {
        return i == -2;
    }
    transkript_yaz(&s->kayit[i]);
    return true;
}

/* Kaydeder ve sonucu yazar; başarılıysa değişiklik bayrağını indirir. */
static bool kaydet(const char *yol, const Sinif *s, bool *degisti)
{
    DosyaDurumu d = sinif_kaydet(yol, s);
    if (d == DOSYA_TASIMA_HATASI) {
        fprintf(stderr, "  Hata: %s yerine konamadı; yeni veri %s.tmp dosyasında.\n",
                yol, yol);
        return false;
    }
    if (d != DOSYA_TAMAM) {
        fprintf(stderr, "  Hata: %s kaydedilemedi: %s\n", yol, dosya_durumu_metni(d));
        return false;
    }
    printf("  Kaydedildi: %d kayıt → %s\n", s->n, yol);
    *degisti = false;
    return true;
}

/* Veri dosyasını yükler ve sonucu yazar. Dosya yoksa boş sınıfla başlanır;
 * dosya bozuksa false döner ve program BAŞLAMAZ. */
static bool veriyi_yukle(const char *yol, Sinif *s)
{
    int hatali_satir = 0;
    DosyaDurumu d = sinif_yukle(yol, s, &hatali_satir);
    if (d == DOSYA_YOK) {
        printf("Yeni veri dosyası: %s (ilk kayıtta oluşturulacak)\n", yol);
        return true;
    }
    if (d != DOSYA_TAMAM) {
        fprintf(stderr, "Hata: %s okunamadı: %s", yol, dosya_durumu_metni(d));
        if (hatali_satir > 0) {
            fprintf(stderr, " (satır %d)", hatali_satir);
        }
        fprintf(stderr, "\n");
        return false;
    }
    printf("Yüklendi: %d kayıt (%s)\n", s->n, yol);
    return true;
}

/* Seçilen menü işlemini yapar. Girdi biterse (EOF) false döndürür.
 * *hata: son kaydetme denemesi başarısız olduysa true. */
static bool islem_yap(MenuSecimi secim, const char *yol, Sinif *s,
                      bool *degisti, bool *hata)
{
    switch (secim) {
    case MENU_EKLE:         return islem_ekle(s, degisti);
    case MENU_LISTELE:      kayitlari_listele(s);                  break;
    case MENU_ARA:          return islem_ara(s);
    case MENU_GUNCELLE:     return islem_guncelle(s, degisti);
    case MENU_SIL:          return islem_sil(s, degisti);
    case MENU_ISTATISTIK:   ders_istatistikleri_yaz(s);            break;
    case MENU_TRANSKRIPT:   return islem_transkript(s);
    case MENU_HARF_TABLOSU: harf_tablosu_yaz(s);                   break;
    case MENU_KAYDET:       *hata = !kaydet(yol, s, degisti);      break;
    case MENU_CIKIS:
        if (*degisti) {
            int yanit = evet_mi_oku("Değişiklikler kaydedilsin mi? (E/H) : ");
            if (yanit == -1) {
                return false;
            }
            if (yanit == 1) {
                *hata = !kaydet(yol, s, degisti);
            }
        }
        break;
    }
    return true;
}

int main(int argc, char *argv[])
{
    const char *yol = (argc > 1) ? argv[1] : VARSAYILAN_DOSYA;
    if (argc > 2 || dosya_turu(yol) == DOSYA_BILINMIYOR) {
        fprintf(stderr, "Kullanım: %s [veri_dosyasi.csv | veri_dosyasi.dat]\n", argv[0]);
        return 2;
    }

    Sinif sinif;
    sinif_baslat(&sinif);
    baslik_yaz();
    if (!veriyi_yukle(yol, &sinif)) {
        return 1;                       /* sinif boş: bırakılacak bellek yok */
    }

    bool degisti = false;
    bool devam = true;                  /* false: girdi bitti (EOF) */
    bool hata = false;                  /* son kaydetme başarısız oldu */
    int secim = 0;
    do {
        menu_goster(yol, sinif.n, degisti);
        secim = secim_oku("Seçiminiz (1-10) : ", MENU_EKLE, MENU_CIKIS);
        if (secim == -1) {
            devam = false;
        } else {
            devam = islem_yap((MenuSecimi)secim, yol, &sinif, &degisti, &hata);
        }
    } while (secim != MENU_CIKIS && devam);

    if (!devam) {
        printf("\nGirdi sona erdi.%s\n",
               degisti ? " Kaydedilmemiş değişiklikler kaydedilmedi." : "");
    } else {
        printf("Çıkış: %d öğrenci kaydı. Hoşça kalın.\n", sinif.n);
    }
    sinif_birak(&sinif);                /* TEK temizlik yolu */
    return (!devam || hata) ? 1 : 0;
}

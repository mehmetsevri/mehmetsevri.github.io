/* H14_K16_obs_yerlesim.c — Hafta 14 · Kavram programı: Mini-OBS v1.0
 * veri modelinin bellek yerleşimi
 * Amaç   : obs.h'deki üç yapının (DersNotu, Ogrenci, Sinif) boyutlarını
 *          ve üye uzaklıklarını (offsetof) yazdırmak. Ogrenci'de hiç
 *          dolgu yoktur: 8 + 32 + 32 + 3 × 24 = 144. İkili dosyadaki
 *          her kayıt bu 144 baytın birebir kopyasıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -Iproje \
 *              H14_K16_obs_yerlesim.c -o obs_yerlesim
 * Örnek  : -> sizeof(Ogrenci) = 144 (dolgu 0 bayt)
 */
#include <stdio.h>
#include <stddef.h>
#include "obs.h"

int main(void)
{
    printf("sizeof(DersNotu) = %zu: vize %zu, final %zu, ort %zu\n",
           sizeof(DersNotu), offsetof(DersNotu, vize),
           offsetof(DersNotu, final), offsetof(DersNotu, ort));
    printf("Ogrenci: no %zu, ad %zu, soyad %zu, ders %zu\n",
           offsetof(Ogrenci, no), offsetof(Ogrenci, ad),
           offsetof(Ogrenci, soyad), offsetof(Ogrenci, ders));
    size_t uyeler = sizeof(long long) + AD_BOYUT + SOYAD_BOYUT
                    + DERS_SAYISI * sizeof(DersNotu);
    printf("sizeof(Ogrenci) = %zu (dolgu %zu bayt)\n", sizeof(Ogrenci),
           sizeof(Ogrenci) - uyeler);
    printf("Sinif: kayit %zu, n %zu, kapasite %zu; sizeof(Sinif) = %zu\n",
           offsetof(Sinif, kayit), offsetof(Sinif, n),
           offsetof(Sinif, kapasite), sizeof(Sinif));
    printf("8 kayıtlık ikili dosya: 16 + 8 × %zu = %zu bayt\n",
           sizeof(Ogrenci), 16 + 8 * sizeof(Ogrenci));
    return 0;
}

/* H14_08_mini_wc.c — Hafta 14 · Örnek 8 (★★): Dosyadaki satır, kelime
 * ve karakter sayısı (mini wc)
 * Amaç   : H13'ün kelime sayma durum makinesini (H13_13_kelime_sayma.c:
 *          kelime İÇİNDE / DIŞINDA) bir DOSYAYA uygulamak. Dosya adı
 *          komut satırından gelir (argc/argv); fgetc bir sonraki baytı
 *          ya da EOF'u (int) döndürür.
 * Not    : bayt ≠ karakter (H13): UTF-8'de Türkçe harfler 2 bayttır;
 *          devam baytları (10xxxxxx) sayılmazsa karakter sayısı bulunur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_08_mini_wc.c -o mini_wc
 * Örnek  : -> satır 6, kelime 40, karakter 275, bayt 296
 */
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Kullanım: %s dosya\n", argv[0]);
        return 2;
    }
    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        perror(argv[1]);
        return 1;
    }
    long satir = 0, kelime = 0, karakter = 0, bayt = 0;
    bool kelime_icinde = false;
    int c;                                  /* char DEĞİL: EOF da gelir */
    while ((c = fgetc(f)) != EOF) {
        bayt++;
        if ((c & 0xC0) != 0x80) {           /* UTF-8 devam baytı değil */
            karakter++;
        }
        if (c == '\n') {
            satir++;
        }
        if (isspace(c)) {
            kelime_icinde = false;
        } else if (!kelime_icinde) {        /* dışarıdan içeri geçiş */
            kelime_icinde = true;
            kelime++;
        }
    }
    if (ferror(f)) {
        perror(argv[1]);
        fclose(f);
        return 1;
    }
    fclose(f);
    printf("satır %ld, kelime %ld, karakter %ld, bayt %ld\n",
           satir, kelime, karakter, bayt);
    return 0;
}

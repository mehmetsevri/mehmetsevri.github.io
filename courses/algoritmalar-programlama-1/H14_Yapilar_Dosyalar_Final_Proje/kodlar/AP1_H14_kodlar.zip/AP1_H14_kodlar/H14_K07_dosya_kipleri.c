/* H14_K07_dosya_kipleri.c — Hafta 14 · Kavram programı: fopen kipleri
 * Amaç   : Aynı dosya üzerinde kipleri tek tek denemek: "r" dosya
 *          yoksa başarısız; "w" oluşturur ya da İÇERİĞİ SİLER; "a"
 *          sona ekler; "r+" silmeden baştan üzerine yazar; "w+" siler,
 *          okur ve yazar; "a+" okur, yazdığını hep sona ekler; "wx"
 *          (C11) dosya VARSA başarısız olur. Her adımdan sonra içerik
 *          yazdırılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K07_dosya_kipleri.c -o dosya_kipleri
 * Örnek  : -> "wx"  : açılamadı (File exists)
 */
#include <stdio.h>
#include <errno.h>
#include <string.h>

#define DOSYA "kip_deneyi.txt"

/* Dosyanın içeriğini tek satırda gösterir ('\n' → |) */
static void icerik(const char *etiket)
{
    FILE *f = fopen(DOSYA, "r");
    printf("%-6s: ", etiket);
    if (f == NULL) {
        printf("(dosya yok)\n");
        return;
    }
    int c;
    printf("\"");
    while ((c = fgetc(f)) != EOF) {
        putchar(c == '\n' ? '|' : c);
    }
    printf("\"\n");
    fclose(f);
}

/* kip ile açar, metni yazar (metin NULL ise yazmaz), kapatır */
static void dene(const char *kip, const char *metin)
{
    errno = 0;
    FILE *f = fopen(DOSYA, kip);
    char etiket[8];
    snprintf(etiket, sizeof etiket, "\"%s\"", kip);
    if (f == NULL) {
        printf("%-6s: açılamadı (%s)\n", etiket, strerror(errno));
        return;
    }
    if (metin != NULL) {
        fputs(metin, f);
    }
    fclose(f);
    icerik(etiket);
}

int main(void)
{
    remove(DOSYA);                  /* temiz başlangıç */
    dene("r", NULL);                /* yok: başarısız */
    dene("w", "ilk\n");             /* oluşturur */
    dene("a", "ek\n");              /* sona ekler */
    dene("r+", "XY");               /* baştan, silmeden üzerine */
    dene("w", "yeni\n");            /* eskisini siler! */
    dene("a+", "son\n");            /* sona ekler */
    dene("w+", NULL);               /* siler: boş dosya */
    dene("wx", "?");                /* var: başarısız (C11) */
    remove(DOSYA);
    dene("wx", "tek\n");            /* yok: oluşturur */
    remove(DOSYA);
    return 0;
}

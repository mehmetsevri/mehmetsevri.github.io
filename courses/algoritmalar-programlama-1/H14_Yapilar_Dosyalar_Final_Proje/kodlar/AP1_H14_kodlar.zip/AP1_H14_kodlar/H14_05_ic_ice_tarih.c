/* H14_05_ic_ice_tarih.c — Hafta 14 · Örnek 5 (★★): İç içe yapı
 * Amaç   : Bir yapının üyesi başka bir yapı olabilir: Ogrenci içinde
 *          iki Tarih. Erişim zincirlenir: o.dogum.yil. İlk değerde iç
 *          yapı kendi süslü parantezini alır. Yıl DÖRT hane tutulur
 *          (2000 Yılı Problemi'nin dersi; bkz. H14_K14_y2k_2038.c).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_05_ic_ice_tarih.c -o ic_ice_tarih
 * Örnek  : -> Kayıt anındaki yaşı: 17
 */
#include <stdio.h>

typedef struct {
    int gun;
    int ay;
    int yil;                        /* dört hane: 2006, "06" değil */
} Tarih;

typedef struct {
    long long no;
    char ad[32];
    Tarih dogum;                    /* yapı içinde yapı */
    Tarih kayit;
} Ogrenci;

/* a, b'den önceyse negatif, aynı günse 0, sonraysa pozitif */
int tarih_karsilastir(Tarih a, Tarih b)
{
    if (a.yil != b.yil) {
        return a.yil - b.yil;
    }
    if (a.ay != b.ay) {
        return a.ay - b.ay;
    }
    return a.gun - b.gun;
}

/* gun tarihindeki tam yaş */
int yas(Tarih dogum, Tarih gun)
{
    int y = gun.yil - dogum.yil;
    Tarih bu_yilki = {dogum.gun, dogum.ay, gun.yil};
    if (tarih_karsilastir(gun, bu_yilki) < 0) {
        y--;                        /* doğum günü henüz gelmedi */
    }
    return y;
}

int main(void)
{
    Ogrenci o = {2301010045, "AYŞE NUR", {14, 9, 2006}, {18, 9, 2023}};
    Tarih bugun = {.gun = 21, .ay = 12, .yil = 2026};   /* örnek tarih */

    printf("%s doğum: %02d.%02d.%d\n", o.ad,
           o.dogum.gun, o.dogum.ay, o.dogum.yil);
    printf("Kayıt anındaki yaşı: %d\n", yas(o.dogum, o.kayit));
    printf("%02d.%02d.%d itibarıyla yaşı: %d\n",
           bugun.gun, bugun.ay, bugun.yil, yas(o.dogum, bugun));
    printf("sizeof(Tarih) = %zu, sizeof(Ogrenci) = %zu\n",
           sizeof(Tarih), sizeof(Ogrenci));
    return 0;
}

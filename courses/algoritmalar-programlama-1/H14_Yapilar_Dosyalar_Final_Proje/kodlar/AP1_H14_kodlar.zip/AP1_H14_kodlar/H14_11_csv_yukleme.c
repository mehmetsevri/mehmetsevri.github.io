/* H14_11_csv_yukleme.c — Hafta 14 · Örnek 11 (★★★): CSV'den öğrenci
 * listesinin yüklenmesi
 * Amaç   : Her satırı ';' ile ayrılmış bir metin dosyasını (CSV) okuyup
 *          ÖBEKTE büyüyen bir yapı dizisine yüklemek: fgets ile satır,
 *          strtok ile alanlar, strtoll/strtod ile denetimli sayı
 *          çözümleme (H13), realloc ile ikiye katlama (H12_12). Bozuk
 *          satır, satır numarasıyla bildirilip ATLANIR.
 * Not    : strtok satırı DEĞİŞTİRİR (';' yerine '\0') ve ardışık
 *          ayırıcıları tek sayar: boş alanlı "1;;B" satırı 3 değil 2
 *          alan verir (bkz. H14_K11_strtok_bos_alan.c).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_11_csv_yukleme.c -o csv_yukleme
 * Örnek  : -> 7 öğrenci yüklendi (kapasite 8), 2 satır atlandı.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define ALAN_SAYISI 5               /* no;ad;soyad;vize;final */

typedef struct {
    long long no;
    char ad[32];
    char soyad[32];
    double vize;
    double final;
} Ogrenci;

/* metnin TAMAMI 0-100 aralığında bir sayıysa true */
static bool not_coz(const char *metin, double *deger)
{
    char *son;
    *deger = strtod(metin, &son);
    return son != metin && *son == '\0' && *deger >= 0 && *deger <= 100;
}

/* "2301010045;AYŞE NUR;YILMAZ;70;85" → *o; biçim hatalıysa false */
static bool satir_coz(char *satir, Ogrenci *o)
{
    char *alan[ALAN_SAYISI];
    int n = 0;
    for (char *p = strtok(satir, ";"); p != NULL; p = strtok(NULL, ";")) {
        if (n == ALAN_SAYISI) {
            return false;               /* fazla alan */
        }
        alan[n++] = p;
    }
    char *son;
    if (n != ALAN_SAYISI) {
        return false;                   /* eksik alan */
    }
    o->no = strtoll(alan[0], &son, 10);
    if (son == alan[0] || *son != '\0' || o->no <= 0) {
        return false;
    }
    if (strlen(alan[1]) >= sizeof o->ad
        || strlen(alan[2]) >= sizeof o->soyad) {
        return false;                   /* '\0' için yer kalmalı */
    }
    snprintf(o->ad, sizeof o->ad, "%s", alan[1]);
    snprintf(o->soyad, sizeof o->soyad, "%s", alan[2]);
    return not_coz(alan[3], &o->vize) && not_coz(alan[4], &o->final);
}

int main(int argc, char *argv[])
{
    const char *yol = (argc > 1) ? argv[1] : "sinif.csv";
    FILE *f = fopen(yol, "r");
    if (f == NULL) {
        perror(yol);
        return 1;
    }
    Ogrenci *dizi = NULL;
    int n = 0, kapasite = 0, satir_no = 0, atlanan = 0;
    char satir[256];
    while (fgets(satir, sizeof satir, f) != NULL) {
        satir_no++;
        satir[strcspn(satir, "\r\n")] = '\0';   /* '\n' ve '\r' sil */
        if (satir_no == 1 || satir[0] == '\0') {
            continue;                           /* başlık, boş satır */
        }
        Ogrenci o = {0};
        if (!satir_coz(satir, &o)) {
            fprintf(stderr, "Uyarı: %s satır %d biçim hatası, atlandı\n",
                    yol, satir_no);
            atlanan++;
            continue;
        }
        if (n == kapasite) {                    /* doluysa ikiye katla */
            int yeni = (kapasite == 0) ? 4 : 2 * kapasite;
            Ogrenci *g = realloc(dizi, (size_t)yeni * sizeof *g);
            if (g == NULL) {
                fprintf(stderr, "Bellek yetersiz.\n");
                break;
            }
            dizi = g;
            kapasite = yeni;
        }
        dizi[n++] = o;                          /* yapı ataması: kopya */
    }
    fclose(f);

    double toplam = 0;
    for (int i = 0; i < n; i++) {
        double ort = 0.4 * dizi[i].vize + 0.6 * dizi[i].final;
        toplam += ort;
        printf("%lld  %6.2f  %s %s\n", dizi[i].no, ort, dizi[i].ad,
               dizi[i].soyad);
    }
    printf("%d öğrenci yüklendi (kapasite %d), %d satır atlandı.\n",
           n, kapasite, atlanan);
    if (n > 0) {
        printf("Sınıf ortalaması: %.2f\n", toplam / n);
    }
    free(dizi);
    return 0;
}

/* H14_K15_dugum.c — Hafta 14 · Kavram programı (AP-2 Köprüsü): kendini
 * gösteren yapı
 * Amaç   : Bir yapı kendi tipinden bir İŞARETÇİ üyesi taşıyabilir
 *          (kendi tipinden bir ÜYE taşıyamaz: boyutu sonsuz olurdu).
 *          struct Dugum, AP-2'deki bağlı listenin, ağaçların ve diğer
 *          dinamik veri yapılarının kapısıdır. Burada yalnızca iki düğüm
 *          elle bağlanır ve -> zinciri izlenir; liste işlemleri AP-2'de.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_K15_dugum.c -o dugum
 * Örnek  : -> a.sonraki->veri = 20
 */
#include <stdio.h>

struct Dugum {
    int veri;
    struct Dugum *sonraki;          /* bir sonraki düğümün ADRESİ */
};

int main(void)
{
    struct Dugum b = {20, NULL};    /* NULL: zincirin sonu */
    struct Dugum a = {10, &b};

    printf("sizeof(struct Dugum) = %zu bayt\n", sizeof(struct Dugum));
    printf("a.veri = %d\n", a.veri);
    printf("a.sonraki->veri = %d\n", a.sonraki->veri);
    printf("a.sonraki->sonraki %s NULL\n",
           a.sonraki->sonraki == NULL ? "==" : "!=");
    return 0;
}

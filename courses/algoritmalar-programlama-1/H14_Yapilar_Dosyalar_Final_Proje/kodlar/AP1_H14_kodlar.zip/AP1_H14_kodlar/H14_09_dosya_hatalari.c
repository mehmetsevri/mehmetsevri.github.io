/* H14_09_dosya_hatalari.c — Hafta 14 · Örnek 9 (★★): Dosya hata
 * yönetimi
 * Amaç   : fopen başarısız olabilir: dosya yoktur, izin yoktur ya da
 *          ad bir klasördür. Dönüş değeri NULL'a karşı denetlenir;
 *          nedeni perror (stderr'e "ad: ileti") ve errno/strerror ile
 *          yazılır. Okuma hatası da (ferror) ayrıca denetlenir.
 * Not    : fopen'ın başarısızlıkta errno'yu ayarlaması POSIX'te ve
 *          Windows CRT'de güvencelidir; C standardı bunu zorunlu tutmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_09_dosya_hatalari.c -o dosya_hatalari
 * Örnek  : -> 4 dosyadan 3 tanesi okunamadı.
 */
#include <stdio.h>
#include <errno.h>
#include <string.h>

/* Dosyanın satırlarını sayar; açılamaz ya da okunamazsa -1. */
static int satir_say(const char *yol)
{
    errno = 0;
    FILE *f = fopen(yol, "r");
    if (f == NULL) {
        int hata = errno;               /* errno'yu HEMEN sakla */
        perror(yol);                    /* "yol: ileti" → stderr */
        fprintf(stderr, "  errno = %d (%s)\n", hata, strerror(hata));
        return -1;
    }
    int satir = 0, c;
    while ((c = fgetc(f)) != EOF) {
        if (c == '\n') {
            satir++;
        }
    }
    if (ferror(f)) {                    /* EOF mu, hata mı? */
        perror(yol);
        fclose(f);
        return -1;
    }
    fclose(f);
    printf("%s: %d satır\n", yol, satir);
    return satir;
}

int main(int argc, char *argv[])
{
    int hatali = 0;
    for (int i = 1; i < argc; i++) {
        if (satir_say(argv[i]) < 0) {
            hatali++;
        }
    }
    printf("%d dosyadan %d tanesi okunamadı.\n", argc - 1, hatali);
    return hatali > 0 ? 1 : 0;
}

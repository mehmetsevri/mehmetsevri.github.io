/* H14_02_ogrenci_typedef.c — Hafta 14 · Örnek 2 (★): typedef ve
 * oku/yazdır fonksiyonları
 * Amaç   : typedef ile yapıya kısa bir ad vermek (Ogrenci) ve yapıyı
 *          fonksiyonlar arasında DEĞER olarak taşımak: ogrenci_oku bir
 *          yapı DÖNDÜRÜR, ogrenci_yazdir bir yapının KOPYASINI alır.
 * Not    : "struct Ogrenci" (etiket) ile "Ogrenci" (typedef adı) aynı
 *          tiptir. Ad tek kelime okunur (%31s: en çok 31 bayt + '\0').
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_02_ogrenci_typedef.c -o ogrenci_typedef
 * Örnek  : -> 2301010045 Ayşe      vize  70.0 final  85.0 ort  79.0
 */
#include <stdio.h>

#define AD_BOYUT 32

typedef struct Ogrenci {
    long long no;
    char ad[AD_BOYUT];
    double vize;
    double final;
} Ogrenci;

/* stdin'den bir öğrenci okur ve DEĞER olarak döndürür; okuma
 * başarısızsa no = 0 olan bir kayıt döner. */
Ogrenci ogrenci_oku(void)
{
    Ogrenci o = {0};                    /* bütün üyeler sıfır */
    printf("No, ad, vize, final: ");
    if (scanf("%lld %31s %lf %lf", &o.no, o.ad, &o.vize, &o.final) != 4) {
        o.no = 0;                       /* geçersiz kayıt işareti */
    }
    return o;
}

void ogrenci_yazdir(Ogrenci o)          /* o, çağıranın KOPYASIDIR */
{
    double ort = 0.4 * o.vize + 0.6 * o.final;
    printf("%lld %-10s vize %5.1f final %5.1f ort %5.1f\n",
           o.no, o.ad, o.vize, o.final, ort);
}

int main(void)
{
    Ogrenci a = ogrenci_oku();
    if (a.no == 0) {
        printf("\nGeçersiz girdi.\n");
        return 1;
    }
    ogrenci_yazdir(a);
    printf("sizeof(Ogrenci) = %zu bayt\n", sizeof(Ogrenci));
    return 0;
}

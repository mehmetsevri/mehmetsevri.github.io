/* H14_HA3_fopen_denetimsiz.c — Hafta 14 · Hata Avcısı 3: fopen'ın dönüş
 * değerini denetlememek
 * BU DOSYA KASITLI HATA İÇERİR: "raporlar" klasörü yoksa fopen NULL
 * döndürür; NULL bir akışa fprintf ile yazmak TANIMSIZ DAVRANIŞTIR. Bu
 * sistemde (glibc) program "Segmentation fault" ile çöktü; başka bir
 * sistemde başka bir şey olabilir. Derleyici uyarı vermez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA3_fopen_denetimsiz.c -o ha3
 */
#include <stdio.h>

int main(void)
{
    FILE *f = fopen("raporlar/donem_sonu.txt", "w");
    fprintf(f, "Dönem sonu raporu\n");  /* HATA: f NULL olabilir */
    fclose(f);
    printf("Rapor yazıldı.\n");
    return 0;
}

/* H14_HA1_yapi_esitlik_duzeltilmis.c — Hafta 14 · Hata Avcısı 1
 * (düzeltilmiş): alan alan karşılaştırma
 * Not    : Kayan noktalı alanlar için çoğu zaman == yerine bir tolerans
 *          (|a - b| < EPS) gerekir (H4); burada değerler tam olarak
 *          gösterilebilir (1.0, 2.0) olduğu için == yeterlidir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA1_yapi_esitlik_duzeltilmis.c -o ha1d
 */
#include <stdio.h>
#include <stdbool.h>

typedef struct {
    double x;
    double y;
} Nokta;

bool nokta_esit(Nokta a, Nokta b)
{
    return a.x == b.x && a.y == b.y;
}

int main(void)
{
    Nokta a = {1.0, 2.0};
    Nokta b = {1.0, 2.0};
    if (nokta_esit(a, b)) {
        printf("Aynı nokta\n");
    }
    return 0;
}

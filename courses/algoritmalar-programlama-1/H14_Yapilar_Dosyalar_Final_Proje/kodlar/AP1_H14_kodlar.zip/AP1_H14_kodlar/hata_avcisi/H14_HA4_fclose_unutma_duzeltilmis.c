/* H14_HA4_fclose_unutma_duzeltilmis.c — Hafta 14 · Hata Avcısı 4
 * (düzeltilmiş): işi biten akış hemen kapatılır
 * Not    : fclose tamponu boşaltır ve dönüşüyle sonucu bildirir. Akış
 *          açık kalacaksa önemli yazımlardan sonra fflush(f) çağrılır.
 *          Aynı çökme şimdi veriyi götürmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA4_fclose_unutma_duzeltilmis.c -o ha4d
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f = fopen("gunluk.txt", "w");
    if (f == NULL) {
        perror("gunluk.txt");
        return 1;
    }
    fprintf(f, "2301010045 notu girildi\n");
    fprintf(f, "2301010046 notu girildi\n");
    fprintf(f, "2301010047 notu girildi\n");
    if (fclose(f) != 0) {               /* tampon diske gider */
        perror("gunluk.txt");
        return 1;
    }
    printf("Üç kayıt yazıldı.\n");
    fflush(stdout);
    abort();                            /* aynı çökme */
}

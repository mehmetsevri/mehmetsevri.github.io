/* H14_HA2_nokta_ok_duzeltilmis.c — Hafta 14 · Hata Avcısı 2
 * (düzeltilmiş): yapıyla nokta, işaretçiyle ok
 * Kural  : Solda YAPI varsa  o.ort ; solda İŞARETÇİ varsa  p->ort
 *          (p->ort ≡ (*p).ort; parantez şarttır).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA2_nokta_ok_duzeltilmis.c -o ha2d
 */
#include <stdio.h>

typedef struct {
    long long no;
    double ort;
} Ogrenci;

void yukselt(Ogrenci *p)
{
    p->ort = p->ort + 5;
}

int main(void)
{
    Ogrenci o = {2301010045, 79.0};
    Ogrenci *p = &o;
    yukselt(p);
    printf("%.1f\n", o.ort);
    printf("%.1f\n", (*p).ort);
    return 0;
}

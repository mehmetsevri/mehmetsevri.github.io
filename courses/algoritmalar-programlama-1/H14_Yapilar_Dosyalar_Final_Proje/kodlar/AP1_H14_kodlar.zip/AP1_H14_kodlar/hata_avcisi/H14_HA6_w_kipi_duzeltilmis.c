/* H14_HA6_w_kipi_duzeltilmis.c — Hafta 14 · Hata Avcısı 6
 * (düzeltilmiş): sona eklemek için "a"
 * Not    : "a" dosya yoksa oluşturur, varsa her yazımı SONA ekler.
 *          Yanlışlıkla üzerine yazmayı önlemenin bir yolu da C11'in
 *          "wx" kipidir: dosya varsa açma başarısız olur (H14_K07).
 *          Windows: metin kipinde '\n' diske "\r\n" olarak yazılır;
 *          ikili veri için "ab"/"wb" (b) kullanılmalıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA6_w_kipi_duzeltilmis.c -o ha6d
 */
#include <stdio.h>

int main(void)
{
    FILE *f = fopen("ogrenciler.txt", "a");     /* sona ekle */
    if (f == NULL) {
        perror("ogrenciler.txt");
        return 1;
    }
    fprintf(f, "2301010048 CAN YILMAZ\n");
    if (fclose(f) != 0) {
        perror("ogrenciler.txt");
        return 1;
    }
    printf("Yeni kayıt eklendi.\n");
    return 0;
}

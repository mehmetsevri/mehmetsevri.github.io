/* H14_HA2_nokta_ok.c — Hafta 14 · Hata Avcısı 2: . ile -> karışıklığı
 * BU DOSYA KASITLI HATA İÇERİR: p bir İŞARETÇİ, o bir YAPI. İşaretçiyle
 * nokta (.), yapıyla ok (->) kullanılmış; *p.ort ise öncelik tuzağıdır:
 * . operatörü *'dan önce bağlanır, ifade *(p.ort) olarak okunur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA2_nokta_ok.c -o ha2
 */
#include <stdio.h>

typedef struct {
    long long no;
    double ort;
} Ogrenci;

void yukselt(Ogrenci *p)
{
    p.ort = p.ort + 5;                  /* HATA: p bir işaretçi */
}

int main(void)
{
    Ogrenci o = {2301010045, 79.0};
    Ogrenci *p = &o;
    yukselt(p);
    printf("%.1f\n", o->ort);           /* HATA: o bir yapı */
    printf("%.1f\n", *p.ort);           /* HATA: *(p.ort) */
    return 0;
}

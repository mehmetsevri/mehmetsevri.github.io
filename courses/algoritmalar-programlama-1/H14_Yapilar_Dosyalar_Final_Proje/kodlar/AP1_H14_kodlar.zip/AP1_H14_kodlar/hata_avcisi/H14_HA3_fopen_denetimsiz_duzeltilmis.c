/* H14_HA3_fopen_denetimsiz_duzeltilmis.c — Hafta 14 · Hata Avcısı 3
 * (düzeltilmiş): her fopen sonucu denetlenir
 * Not    : perror nedeni stderr'e yazar; program anlamlı bir çıkış
 *          koduyla (1) biter. fclose'un dönüşü de denetlenir: tamponda
 *          kalan veri ancak fclose sırasında yazılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA3_fopen_denetimsiz_duzeltilmis.c -o ha3d
 */
#include <stdio.h>

int main(void)
{
    const char *yol = "raporlar/donem_sonu.txt";
    FILE *f = fopen(yol, "w");
    if (f == NULL) {
        perror(yol);
        return 1;
    }
    fprintf(f, "Dönem sonu raporu\n");
    if (fclose(f) != 0) {
        perror(yol);
        return 1;
    }
    printf("Rapor yazıldı.\n");
    return 0;
}

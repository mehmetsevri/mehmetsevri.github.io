/* H14_HA5_feof_dongusu_duzeltilmis.c — Hafta 14 · Hata Avcısı 5
 * (düzeltilmiş): okuma fonksiyonunun DÖNÜŞÜ döngü koşuludur
 * Not    : fgets → NULL, fscanf → beklenen sayı, fread → istenen öğe
 *          sayısı, fgetc → EOF. Döngüden sonra feof/ferror "neden
 *          bitti?" sorusunu yanıtlar (dosya sonu mu, okuma hatası mı).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA5_feof_dongusu_duzeltilmis.c -o ha5d
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f = fopen("puanlar.txt", "w");
    if (f == NULL) {
        return 1;
    }
    fputs("70\n85\n90\n", f);
    fclose(f);

    f = fopen("puanlar.txt", "r");
    if (f == NULL) {
        return 1;
    }
    char satir[32];
    int n = 0, toplam = 0;
    while (fgets(satir, sizeof satir, f) != NULL) {
        n++;
        toplam += atoi(satir);
        printf("%d. okuma: %s", n, satir);
    }
    if (ferror(f)) {
        perror("puanlar.txt");
    }
    fclose(f);
    printf("%d kayıt, toplam %d\n", n, toplam);
    return 0;
}

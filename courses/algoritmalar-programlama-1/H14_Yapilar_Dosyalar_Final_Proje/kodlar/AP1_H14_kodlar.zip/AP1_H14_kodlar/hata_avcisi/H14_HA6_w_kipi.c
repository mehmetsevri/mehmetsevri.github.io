/* H14_HA6_w_kipi.c — Hafta 14 · Hata Avcısı 6: "w" kipi mevcut dosyayı
 * siler
 * BU DOSYA KASITLI HATA İÇERİR: amaç ogrenciler.txt'nin SONUNA yeni bir
 * kayıt eklemek; ama "w" kipi dosya varsa uzunluğunu SIFIRA indirir
 * (ISO C 7.21.5.3): eski kayıtların hepsi gider. Derleyici ve çalışma
 * zamanı hiçbir uyarı vermez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA6_w_kipi.c -o ha6
 */
#include <stdio.h>

int main(void)
{
    FILE *f = fopen("ogrenciler.txt", "w");     /* HATA: "a" olmalıydı */
    if (f == NULL) {
        perror("ogrenciler.txt");
        return 1;
    }
    fprintf(f, "2301010048 CAN YILMAZ\n");
    if (fclose(f) != 0) {
        perror("ogrenciler.txt");
        return 1;
    }
    printf("Yeni kayıt eklendi.\n");
    return 0;
}

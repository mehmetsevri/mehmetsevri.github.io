/* H14_HA5_feof_dongusu.c — Hafta 14 · Hata Avcısı 5: while (!feof(f))
 * BU DOSYA KASITLI HATA İÇERİR: feof, dosya sonunu ÖNCEDEN haber vermez;
 * yalnızca bir okuma dosya sonuna ÇARPTIKTAN SONRA doğru olur. Son
 * satır okunduğunda feof hâlâ false'tur; döngü bir tur daha döner,
 * fgets NULL döndürür ama dönüşü denetlenmediği için tamponda kalan SON
 * SATIR ikinci kez işlenir: 3 kayıt 4 sayılır, toplam yanlış çıkar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA5_feof_dongusu.c -o ha5
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f = fopen("puanlar.txt", "w");
    if (f == NULL) {
        return 1;
    }
    fputs("70\n85\n90\n", f);           /* 3 kayıt, toplam 245 */
    fclose(f);

    f = fopen("puanlar.txt", "r");
    if (f == NULL) {
        return 1;
    }
    char satir[32];
    int n = 0, toplam = 0;
    while (!feof(f)) {                  /* HATA: karşıt örüntü */
        fgets(satir, sizeof satir, f);  /* dönüş değeri denetlenmiyor */
        n++;
        toplam += atoi(satir);
        printf("%d. okuma: %s", n, satir);
    }
    fclose(f);
    printf("%d kayıt, toplam %d\n", n, toplam);
    return 0;
}

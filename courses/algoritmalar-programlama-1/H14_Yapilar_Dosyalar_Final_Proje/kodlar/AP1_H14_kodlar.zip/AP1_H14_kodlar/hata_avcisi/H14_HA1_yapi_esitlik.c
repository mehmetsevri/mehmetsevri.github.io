/* H14_HA1_yapi_esitlik.c — Hafta 14 · Hata Avcısı 1: yapıları == ile
 * karşılaştırmak
 * BU DOSYA KASITLI HATA İÇERİR: C'de == yalnızca aritmetik tiplerde ve
 * işaretçilerde tanımlıdır; iki yapı == ile karşılaştırılamaz (derleme
 * hatası). Çözüm: alan alan karşılaştıran bir fonksiyon.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA1_yapi_esitlik.c -o ha1
 */
#include <stdio.h>

typedef struct {
    double x;
    double y;
} Nokta;

int main(void)
{
    Nokta a = {1.0, 2.0};
    Nokta b = {1.0, 2.0};
    if (a == b) {                       /* HATA: yapılar için == yok */
        printf("Aynı nokta\n");
    }
    return 0;
}

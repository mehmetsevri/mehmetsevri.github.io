/* H14_HA4_fclose_unutma.c — Hafta 14 · Hata Avcısı 4: fclose'u unutmak
 * ve tamponda kalan veri
 * BU DOSYA KASITLI HATA İÇERİR: üç kayıt fprintf ile yazılır ama akış
 * kapatılmaz; ardından program bir hata nedeniyle ANORMAL sonlanır
 * (burada abort() ile canlandırılır). Kayıtlar C kütüphanesinin
 * tamponundaydı: bu sistemde dosya 0 bayt kaldı. (main'den normal
 * dönüşte ya da exit'te açık akışlar boşaltılır; abort'ta bu
 * uygulamaya bağlıdır.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H14_HA4_fclose_unutma.c -o ha4
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f = fopen("gunluk.txt", "w");
    if (f == NULL) {
        perror("gunluk.txt");
        return 1;
    }
    fprintf(f, "2301010045 notu girildi\n");
    fprintf(f, "2301010046 notu girildi\n");
    fprintf(f, "2301010047 notu girildi\n");
    /* HATA: fclose(f) (ya da fflush(f)) yok */
    printf("Üç kayıt yazıldı (sanıyoruz).\n");
    fflush(stdout);
    abort();                            /* beklenmedik bir çökme */
}

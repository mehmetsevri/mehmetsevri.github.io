/* H05_10_ay_gun.c — AP-1 Hafta 5, Örnek 10 (★★)
 * Amaç   : Ayın gün sayısı: switch'te art arda case etiketleri (bilinçli düşüş)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_10_ay_gun.c -o ay_gun
 * Örnek çıktı: 2. ay (2024) 29 gün çeker.  (girdi: 2 2024) */

#include <stdio.h>

int main(void)
{
    int ay = 0;
    int yil = 0;

    printf("Ay ve yıl girin (ör. 2 2024): ");
    scanf("%d %d", &ay, &yil);

    int gun = 0;
    switch (ay) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
        gun = 31;            /* yedi etiket, tek gövde */
        break;
    case 4:
    case 6:
    case 9:
    case 11:
        gun = 30;
        break;
    case 2:
        if ((yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0) {
            gun = 29;
        } else {
            gun = 28;
        }
        break;
    default:
        printf("Hata: %d geçerli bir ay değil (1-12).\n", ay);
        return 1;
    }
    printf("%d. ay (%d) %d gün çeker.\n", ay, yil, gun);
    return 0;
}

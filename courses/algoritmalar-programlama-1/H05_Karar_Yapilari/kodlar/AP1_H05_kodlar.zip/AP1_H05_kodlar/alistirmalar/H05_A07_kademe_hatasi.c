/* H05_A07_kademe_hatasi.c — AP-1 Hafta 5, Alıştırma 5.9 (★★★, Hata bul + sınır testi)
 * Öğrenciye verilen kod; çözümü 92_Degerlendirme'dedir.
 * BU DOSYA KASITLI HATA İÇERİR (bulup düzeltmeniz beklenir). */

#include <stdio.h>

int main(void)
{
    int tuketim = 0;
    scanf("%d", &tuketim);

    double bedel = 0.0;
    if (tuketim <= 150) {
        bedel = tuketim * 2.00;
    } else if (tuketim <= 300) {
        bedel = tuketim * 3.00;
    } else {
        bedel = tuketim * 4.50;
    }
    printf("%d kWh -> %.2f TL\n", tuketim, bedel);
    return 0;
}

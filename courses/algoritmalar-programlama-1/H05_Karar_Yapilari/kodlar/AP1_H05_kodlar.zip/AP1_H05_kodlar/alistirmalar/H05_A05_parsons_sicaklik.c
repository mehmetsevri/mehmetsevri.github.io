/* H05_A05_parsons_sicaklik.c — AP-1 Hafta 5, Alıştırma 5.5 (★★, Parsons)
 * Öğrenciye verilen kod; çözümü 92_Degerlendirme'dedir.
 * NOT: tamamlanacak; bu hâliyle derlenmez. */

#include <stdio.h>

int main(void)
{
    /* Satırları doğru sıraya dizin; biri fazladır (çeldirici). */
    } else if (derece < 25.0) {
        printf("Soğuk\n");
    if (derece < 0.0) {
    scanf("%lf", &derece);
        printf("Sıcak\n");
    } else if (derece < 15.0) {
    } else if (derece > 25.0) {
    double derece = 0.0;
        printf("Ilık\n");
    } else {
        printf("Dondurucu\n");
    printf("Sıcaklık (°C): ");
    }
    return 0;
}

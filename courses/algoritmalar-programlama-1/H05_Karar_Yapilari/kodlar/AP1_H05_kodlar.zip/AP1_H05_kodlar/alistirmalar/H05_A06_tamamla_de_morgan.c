/* H05_A06_tamamla_de_morgan.c — AP-1 Hafta 5, Alıştırma 5.6 (★★, Kod tamamla)
 * Öğrenciye verilen kod; çözümü 92_Degerlendirme'dedir.
 * NOT: tamamlanacak; bu hâliyle derlenmez. */

#include <stdio.h>

int main(void)
{
    int saat = 0;
    printf("Saat (0-23): ");
    scanf("%d", &saat);

    /* Mesai 9:00'da başlar, 17:00'de biter (9 dahil, 17 hariç). */
    int mesaide = (saat >= 9 ____ saat < 17);

    /* Mesai DIŞI koşulu: ! kullanmadan, De Morgan ile yazın. */
    if (saat ____ 9 ____ saat ____ 17) {
        printf("Mesai dışı: kapıyı kartınızla açın.\n");
    }
    printf("mesaide = %d\n", mesaide);
    return 0;
}

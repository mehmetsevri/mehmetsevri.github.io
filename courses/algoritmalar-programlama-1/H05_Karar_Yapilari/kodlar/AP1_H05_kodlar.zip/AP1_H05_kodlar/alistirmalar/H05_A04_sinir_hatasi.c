/* H05_A04_sinir_hatasi.c — AP-1 Hafta 5, Alıştırma 5.4 (★★, Hata bul + test tasarla)
 * Öğrenciye verilen kod; çözümü 92_Degerlendirme'dedir.
 * BU DOSYA KASITLI HATA İÇERİR (bulup düzeltmeniz beklenir). */

#include <stdio.h>

int main(void)
{
    int final_notu = 0;
    scanf("%d", &final_notu);

    if (final_notu < 0 || final_notu > 100) {
        printf("GEÇERSİZ\n");
        return 1;
    }
    if (final_notu > 50) {
        printf("baraj geçildi\n");
    } else {
        printf("FF (final barajı)\n");
    }
    return 0;
}

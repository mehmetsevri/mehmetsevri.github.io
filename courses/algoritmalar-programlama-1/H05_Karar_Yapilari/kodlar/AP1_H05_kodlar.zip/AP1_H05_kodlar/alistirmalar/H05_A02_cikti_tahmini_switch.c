/* H05_A02_cikti_tahmini_switch.c — AP-1 Hafta 5, Alıştırma 5.2 (★★, Çıktı tahmini)
 * Öğrenciye verilen kod; çözümü 92_Degerlendirme'dedir. */

#include <stdio.h>

int main(void)
{
    int kod = 2;
    int puan = 0;

    switch (kod) {
    case 1:
        puan = puan + 10;
        /* fall through */
    case 2:
        puan = puan + 20;
        /* fall through */
    case 3:
        puan = puan + 30;
        break;
    case 4:
        puan = puan + 40;
        break;
    default:
        puan = -1;
        break;
    }
    printf("puan = %d\n", puan);
    return 0;
}

/* H05_A01_cikti_tahmini_ic_ice.c — AP-1 Hafta 5, Alıştırma 5.1 (★, Çıktı tahmini)
 * Öğrenciye verilen kod; çözümü 92_Degerlendirme'dedir. */

#include <stdio.h>

int main(void)
{
    int x = 7;
    int y = 12;

    if (x > y) {
        printf("A\n");
    } else if (x + 5 >= y) {
        printf("B\n");
        if (x % 2 == 0) {
            printf("C\n");
        } else {
            printf("D\n");
        }
    } else {
        printf("E\n");
    }
    printf("F\n");
    return 0;
}

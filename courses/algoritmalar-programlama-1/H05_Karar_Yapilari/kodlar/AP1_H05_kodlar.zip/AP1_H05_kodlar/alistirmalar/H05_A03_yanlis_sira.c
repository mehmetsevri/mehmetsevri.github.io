/* H05_A03_yanlis_sira.c — AP-1 Hafta 5, Alıştırma 5.3 (★★, Hata bul)
 * Öğrenciye verilen kod; çözümü 92_Degerlendirme'dedir.
 * BU DOSYA KASITLI HATA İÇERİR (bulup düzeltmeniz beklenir). */

#include <stdio.h>

int main(void)
{
    int puan = 0;

    printf("Puan: ");
    scanf("%d", &puan);

    if (puan >= 50) {
        printf("şartlı başarılı\n");
    } else if (puan >= 60) {
        printf("başarılı\n");
    } else {
        printf("başarısız\n");
    }
    return 0;
}

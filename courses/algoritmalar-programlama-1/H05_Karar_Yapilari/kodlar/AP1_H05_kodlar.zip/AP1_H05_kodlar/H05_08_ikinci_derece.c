/* H05_08_ikinci_derece.c — AP-1 Hafta 5, Örnek 8 (★★)
 * Amaç   : İkinci dereceden denklemin kökleri: Δ > 0, Δ = 0, Δ < 0 dalları
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_08_ikinci_derece.c -o denklem -lm
 * Örnek çıktı: İki farklı gerçel kök: x1 = 2.0000, x2 = 1.0000  (girdi: 1 -3 2) */

#include <stdio.h>
#include <math.h>

int main(void)
{
    int a = 0;
    int b = 0;
    int c = 0;

    printf("a, b, c katsayıları (tamsayı): ");
    scanf("%d %d %d", &a, &b, &c);

    if (a == 0) {
        printf("a = 0: denklem ikinci dereceden değil.\n");
        return 1;
    }

    int delta = b * b - 4 * a * c;      /* tamsayı: == 0 güvenle sınanır */
    printf("Delta = %d\n", delta);

    if (delta > 0) {
        double x1 = (-b + sqrt(delta)) / (2.0 * a);
        double x2 = (-b - sqrt(delta)) / (2.0 * a);
        printf("İki farklı gerçel kök: x1 = %.4f, x2 = %.4f\n", x1, x2);
    } else if (delta == 0) {
        double x = -b / (2.0 * a);
        printf("Çakışık (çift) kök: x = %.4f\n", x);
    } else {
        double gercel = -b / (2.0 * a);
        double sanal = sqrt(-delta) / fabs(2.0 * a);
        printf("Gerçel kök yok; karmaşık kökler: %.4f ± %.4fi\n",
               gercel, sanal);
    }
    return 0;
}

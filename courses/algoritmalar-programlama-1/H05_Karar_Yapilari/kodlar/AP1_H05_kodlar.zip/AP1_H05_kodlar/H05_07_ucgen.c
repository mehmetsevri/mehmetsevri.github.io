/* H05_07_ucgen.c — AP-1 Hafta 5, Örnek 7 (★★)
 * Amaç   : Üçgen geçerliliği ve türü: çok koşullu mantık
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_07_ucgen.c -o ucgen
 * Örnek çıktı: Ayrıca dik üçgendir.  (girdi: 3 4 5) */

#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;
    int c = 0;

    printf("Üç kenar girin (tamsayı): ");
    scanf("%d %d %d", &a, &b, &c);

    /* 1) Geçerlilik: pozitif kenarlar ve üçgen eşitsizliği */
    if (a <= 0 || b <= 0 || c <= 0) {
        printf("Geçersiz: kenarlar pozitif olmalı.\n");
        return 1;
    }
    if (a + b <= c || a + c <= b || b + c <= a) {
        printf("Geçersiz: üçgen eşitsizliği sağlanmıyor.\n");
        return 1;
    }

    /* 2) Kenarlara göre tür */
    if (a == b && b == c) {
        printf("Eşkenar üçgen\n");
    } else if (a == b || b == c || a == c) {
        printf("İkizkenar üçgen\n");
    } else {
        printf("Çeşitkenar üçgen\n");
    }

    /* 3) Açıya göre: dik mi? (Pisagor; tamsayılarla tam sonuç) */
    if (a * a + b * b == c * c || a * a + c * c == b * b
        || b * b + c * c == a * a) {
        printf("Ayrıca dik üçgendir.\n");
    }
    return 0;
}

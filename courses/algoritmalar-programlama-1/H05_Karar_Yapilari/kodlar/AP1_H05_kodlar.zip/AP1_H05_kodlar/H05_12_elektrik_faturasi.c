/* H05_12_elektrik_faturasi.c — AP-1 Hafta 5, Örnek 12 (★★★)
 * Amaç   : Kademeli elektrik faturası: aralıklı hesaplama ve sınır değerler
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_12_elektrik_faturasi.c -o fatura
 * Örnek çıktı: Tüketim: 120 kWh | Kademe: 1 | Bedel: 240.00 TL  (girdi: 120) */

#include <stdio.h>

int main(void)
{
    const int KADEME1_UST = 150;        /* kWh; örnek tarife */
    const int KADEME2_UST = 300;
    const double FIYAT1 = 2.00;         /* TL/kWh */
    const double FIYAT2 = 3.00;
    const double FIYAT3 = 4.50;

    int tuketim = 0;
    printf("Aylık tüketim (kWh): ");
    scanf("%d", &tuketim);

    if (tuketim < 0) {
        printf("Hata: tüketim negatif olamaz.\n");
        return 1;
    }

    double bedel = 0.0;
    int kademe = 0;
    if (tuketim <= KADEME1_UST) {
        kademe = 1;
        bedel = tuketim * FIYAT1;
    } else if (tuketim <= KADEME2_UST) {
        kademe = 2;
        bedel = KADEME1_UST * FIYAT1 + (tuketim - KADEME1_UST) * FIYAT2;
    } else {
        kademe = 3;
        bedel = KADEME1_UST * FIYAT1 + (KADEME2_UST - KADEME1_UST) * FIYAT2
                + (tuketim - KADEME2_UST) * FIYAT3;
    }
    printf("Tüketim: %d kWh | Kademe: %d | Bedel: %.2f TL\n",
           tuketim, kademe, bedel);
    return 0;
}

/* H05_03_iki_sayi_buyuk.c — AP-1 Hafta 5, Örnek 3 (★)
 * Amaç   : İki sayının büyüğü: if-else ve koşul operatörü ?:
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_03_iki_sayi_buyuk.c -o buyuk
 * Örnek çıktı: if-else ile : 12  (girdi: 12 9) */

#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;

    printf("İki tamsayı girin: ");
    scanf("%d %d", &a, &b);

    /* 1. yol: if-else (H2 Örnek 3'teki akış diyagramı) */
    int buyuk = 0;
    if (a > b) {
        buyuk = a;
    } else {
        buyuk = b;
    }
    printf("if-else ile : %d\n", buyuk);

    /* 2. yol: koşul operatörü ?: */
    int buyuk2 = (a > b) ? a : b;
    printf("?: ile      : %d\n", buyuk2);

    if (a == b) {
        printf("Not: iki sayı eşit.\n");
    }
    return 0;
}

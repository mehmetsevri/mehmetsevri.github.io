/* H05_K04_mantiksal_kosullar.c — AP-1 Hafta 5, Kavram programı K04
 * Amaç   : && ve || ile aralık denetimi, De Morgan ve kısa devre
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K04_mantiksal_kosullar.c -o mantiksal
 * Örnek çıktı: ic = 0, dis1 = 1, dis2 = 1 */

#include <stdio.h>

int main(void)
{
    int puan = 105;

    /* Aralığın İÇİNDE mi? İki koşul birlikte: && */
    if (puan >= 0 && puan <= 100) {
        printf("%d geçerli bir puan.\n", puan);
    }

    /* Aralığın DIŞINDA mı? Biri yeter: || */
    if (puan < 0 || puan > 100) {
        printf("%d geçersiz bir puan.\n", puan);
    }

    /* De Morgan: !(A && B) ile (!A || !B) aynı sonucu verir */
    int ic = (puan >= 0 && puan <= 100);
    int dis1 = !(puan >= 0 && puan <= 100);
    int dis2 = (puan < 0 || puan > 100);
    printf("ic = %d, dis1 = %d, dis2 = %d\n", ic, dis1, dis2);

    /* Kısa devre: sol taraf yanlışsa sağ taraf hiç hesaplanmaz */
    int toplam = 50;
    int adet = 0;
    if (adet != 0 && toplam / adet > 10) {
        printf("Ortalama 10'dan büyük.\n");
    } else {
        printf("Ortalama hesaplanmadı (adet = 0).\n");
    }
    return 0;
}

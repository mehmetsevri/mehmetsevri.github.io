/* H05_K10_kaput_if.c — AP-1 Hafta 5, Kavram programı K10
 * Amaç   : Kaputun Altında: if → cmp + koşullu atlama (gcc -S)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K10_kaput_if.c -o kaput_if
 * Örnek çıktı: Baraj geçildi  (girdi: 50) */

#include <stdio.h>

int main(void)
{
    int final_notu = 0;
    if (scanf("%d", &final_notu) != 1) {
        return 1;
    }
    if (final_notu >= 50) {
        printf("Baraj geçildi\n");
    } else {
        printf("FF\n");
    }
    return 0;
}

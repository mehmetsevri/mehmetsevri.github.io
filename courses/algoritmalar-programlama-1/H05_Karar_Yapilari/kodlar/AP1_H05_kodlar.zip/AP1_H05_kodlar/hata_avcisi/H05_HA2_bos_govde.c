/* H05_HA2_bos_govde.c — AP-1 Hafta 5, Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: if (kosul); — boş deyim tuzağı
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA2_bos_govde.txt */

#include <stdio.h>

int main(void)
{
    int puan = 40;

    if (puan >= 60);                  /* satır sonundaki ; boş deyimdir */
    {
        printf("Tebrikler, geçtiniz!\n");
    }
    return 0;
}

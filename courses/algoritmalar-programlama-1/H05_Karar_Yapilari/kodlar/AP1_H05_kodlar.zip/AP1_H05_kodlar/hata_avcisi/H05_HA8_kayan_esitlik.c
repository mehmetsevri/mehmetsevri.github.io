/* H05_HA8_kayan_esitlik.c — AP-1 Hafta 5, Hata Avcısı 8 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: Kayan noktalı değerlerin == ile karşılaştırılması
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA8_kayan_esitlik.txt */

#include <stdio.h>

int main(void)
{
    double toplam = 0.1 + 0.2;

    if (toplam == 0.3) {
        printf("Eşit.\n");
    } else {
        printf("Eşit değil! toplam - 0.3 = %.3e\n", toplam - 0.3);
    }
    return 0;
}

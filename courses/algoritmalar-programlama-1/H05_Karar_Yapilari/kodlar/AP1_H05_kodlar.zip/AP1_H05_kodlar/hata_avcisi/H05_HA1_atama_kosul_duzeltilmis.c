/* H05_HA1_atama_kosul_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 1 (düzeltilmiş sürüm)
 * Konu: if (x = 5): atama ile karşılaştırmanın karıştırılması
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA1_atama_kosul_duzeltilmis.c -o ha1d */

#include <stdio.h>

int main(void)
{
    int kalan_hak = 0;                /* deneme hakkı bitti */

    if (kalan_hak == 3) {             /* karşılaştırma: == */
        printf("Tam hakkınız var: %d\n", kalan_hak);
    } else {
        printf("Hakkınız kalmadı.\n");
    }
    return 0;
}

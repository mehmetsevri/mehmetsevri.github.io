/* H05_HA7_break_unutma.c — AP-1 Hafta 5, Hata Avcısı 7 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: switch'te break unutulması
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA7_break_unutma.txt */

#include <stdio.h>

int main(void)
{
    int secim = 1;

    switch (secim) {
    case 1:
        printf("Not girişi açıldı.\n");
    case 2:
        printf("Not SİLME açıldı!\n");
        break;
    default:
        printf("Geçersiz seçim.\n");
        break;
    }
    return 0;
}

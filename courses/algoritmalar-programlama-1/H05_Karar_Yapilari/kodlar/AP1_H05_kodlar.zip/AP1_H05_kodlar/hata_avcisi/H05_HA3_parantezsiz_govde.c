/* H05_HA3_parantezsiz_govde.c — AP-1 Hafta 5, Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: Süslü parantezsiz çok satırlı gövde
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA3_parantezsiz_govde.txt */

#include <stdio.h>

int main(void)
{
    int final_notu = 70;
    int uyari_sayisi = 0;

    if (final_notu < 50)
        printf("Final barajının altında!\n");
        uyari_sayisi = uyari_sayisi + 1;     /* if'e ait DEĞİL */

    printf("Uyarı sayısı: %d\n", uyari_sayisi);
    return 0;
}

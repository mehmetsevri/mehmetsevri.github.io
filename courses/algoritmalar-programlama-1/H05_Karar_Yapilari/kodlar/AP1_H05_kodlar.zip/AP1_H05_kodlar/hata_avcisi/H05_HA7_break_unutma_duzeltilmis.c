/* H05_HA7_break_unutma_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 7 (düzeltilmiş sürüm)
 * Konu: switch'te break unutulması
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA7_break_unutma_duzeltilmis.c -o ha7d */

#include <stdio.h>

int main(void)
{
    int secim = 1;

    switch (secim) {
    case 1:
        printf("Not girişi açıldı.\n");
        break;
    case 2:
        printf("Not SİLME açıldı!\n");
        break;
    default:
        printf("Geçersiz seçim.\n");
        break;
    }
    return 0;
}

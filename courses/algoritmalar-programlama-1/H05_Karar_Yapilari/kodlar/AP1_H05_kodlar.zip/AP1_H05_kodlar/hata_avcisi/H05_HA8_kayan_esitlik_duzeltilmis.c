/* H05_HA8_kayan_esitlik_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 8 (düzeltilmiş sürüm)
 * Konu: Kayan noktalı değerlerin == ile karşılaştırılması
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA8_kayan_esitlik_duzeltilmis.c -o ha8d -lm */

#include <stdio.h>
#include <math.h>

int main(void)
{
    const double TOLERANS = 1e-9;
    double toplam = 0.1 + 0.2;

    if (fabs(toplam - 0.3) < TOLERANS) {
        printf("Eşit sayılır (fark < %g).\n", TOLERANS);
    } else {
        printf("Eşit değil! toplam - 0.3 = %.3e\n", toplam - 0.3);
    }
    return 0;
}

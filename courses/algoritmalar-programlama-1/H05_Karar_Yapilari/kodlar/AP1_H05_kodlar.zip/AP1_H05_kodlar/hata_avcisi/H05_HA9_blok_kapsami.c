/* H05_HA9_blok_kapsami.c — AP-1 Hafta 5, Hata Avcısı 9 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: Blok dışında blok içi değişkene erişim
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA9_blok_kapsami.txt */

#include <stdio.h>

int main(void)
{
    int sicaklik = 34;

    if (sicaklik > 30) {
        int fark = sicaklik - 30;      /* bloğun içinde doğar */
        printf("Eşik aşıldı.\n");
    }
    printf("Fark: %d\n", fark);        /* blok bitti, fark yok! */
    return 0;
}

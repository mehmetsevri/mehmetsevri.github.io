/* H05_HA5_sallanan_else.c — AP-1 Hafta 5, Hata Avcısı 5 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: İç içe if ve sallanan else
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA5_sallanan_else.txt */

#include <stdio.h>

int main(void)
{
    int yas = 16;
    int ehliyet = 0;

    if (yas >= 18)
        if (ehliyet == 1)
            printf("Araç kullanabilir.\n");
    else                               /* girinti yalan söylüyor */
        printf("18 yaşından küçük.\n");

    printf("Denetim bitti.\n");
    return 0;
}

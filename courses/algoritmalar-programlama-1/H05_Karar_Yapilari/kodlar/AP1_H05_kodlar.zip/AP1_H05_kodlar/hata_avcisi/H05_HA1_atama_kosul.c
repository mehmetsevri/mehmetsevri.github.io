/* H05_HA1_atama_kosul.c — AP-1 Hafta 5, Hata Avcısı 1 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: if (x = 5): atama ile karşılaştırmanın karıştırılması
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA1_atama_kosul.txt */

#include <stdio.h>

int main(void)
{
    int kalan_hak = 0;                /* deneme hakkı bitti */

    if (kalan_hak = 3) {              /* niyet: kalan_hak == 3 mü? */
        printf("Tam hakkınız var: %d\n", kalan_hak);
    } else {
        printf("Hakkınız kalmadı.\n");
    }
    return 0;
}

/* H05_HA4_goto_fail_yeniden_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 4 (düzeltilmiş sürüm)
 * Konu: goto fail: parantezsiz if ve yinelenen satır (eğitsel yeniden kurgu)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA4_goto_fail_yeniden_duzeltilmis.c -o ha4d */

#include <stdio.h>

int main(void)
{
    int hata = 0;              /* 0: başarı, 0 dışı: hata kodu */
    int ozet_hatasi = 0;       /* 1. adım: özet (hash) hesabı sorunsuz */
    int imza_gecerli = 0;      /* 2. adım: saldırganın SAHTE imzası */

    printf("1. adım: el sıkışma verisinin özeti hesaplanıyor\n");
    if ((hata = ozet_hatasi) != 0) {
        goto fail;
        goto fail;             /* aynı kopyalama hatası artık zararsız */
    }

    printf("2. adım: sunucunun imzası doğrulanıyor\n");
    if (imza_gecerli == 0) {
        hata = -1;
    }

fail:
    if (hata == 0) {
        printf("Sonuç: doğrulama BAŞARILI, bağlantı güvenli sayıldı\n");
    } else {
        printf("Sonuç: doğrulama BAŞARISIZ, bağlantı reddedildi\n");
    }
    return 0;
}

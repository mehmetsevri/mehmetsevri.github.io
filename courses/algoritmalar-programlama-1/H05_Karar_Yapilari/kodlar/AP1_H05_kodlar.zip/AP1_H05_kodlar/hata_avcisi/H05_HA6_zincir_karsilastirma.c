/* H05_HA6_zincir_karsilastirma.c — AP-1 Hafta 5, Hata Avcısı 6 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: 0 < x < 10 yazımının C'deki anlamı
 * Derleyici iletisi: hata_avcisi/ciktilar/H05_HA6_zincir_karsilastirma.txt */

#include <stdio.h>

int main(void)
{
    int x = 25;

    if (0 < x < 10) {                  /* matematikte: 0 < x ve x < 10 */
        printf("%d, (0, 10) aralığında.\n", x);
    } else {
        printf("%d, aralığın dışında.\n", x);
    }
    return 0;
}

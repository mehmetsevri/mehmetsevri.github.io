/* H05_HA5_sallanan_else_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 5 (düzeltilmiş sürüm)
 * Konu: İç içe if ve sallanan else
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA5_sallanan_else_duzeltilmis.c -o ha5d */

#include <stdio.h>

int main(void)
{
    int yas = 16;
    int ehliyet = 0;

    if (yas >= 18) {
        if (ehliyet == 1) {
            printf("Araç kullanabilir.\n");
        }
    } else {
        printf("18 yaşından küçük.\n");
    }

    printf("Denetim bitti.\n");
    return 0;
}

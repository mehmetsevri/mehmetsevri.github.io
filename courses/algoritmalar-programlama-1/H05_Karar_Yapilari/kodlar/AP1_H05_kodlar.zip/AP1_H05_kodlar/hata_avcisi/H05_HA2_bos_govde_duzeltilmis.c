/* H05_HA2_bos_govde_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 2 (düzeltilmiş sürüm)
 * Konu: if (kosul); — boş deyim tuzağı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA2_bos_govde_duzeltilmis.c -o ha2d */

#include <stdio.h>

int main(void)
{
    int puan = 40;

    if (puan >= 60) {
        printf("Tebrikler, geçtiniz!\n");
    }
    return 0;
}

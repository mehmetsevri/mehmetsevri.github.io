/* H05_HA9_blok_kapsami_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 9 (düzeltilmiş sürüm)
 * Konu: Blok dışında blok içi değişkene erişim
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA9_blok_kapsami_duzeltilmis.c -o ha9d */

#include <stdio.h>

int main(void)
{
    int sicaklik = 34;
    int fark = 0;                      /* dış kapsamda bildir */

    if (sicaklik > 30) {
        fark = sicaklik - 30;
        printf("Eşik aşıldı.\n");
    }
    printf("Fark: %d\n", fark);
    return 0;
}

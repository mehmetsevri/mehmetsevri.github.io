/* H05_HA6_zincir_karsilastirma_duzeltilmis.c — AP-1 Hafta 5, Hata Avcısı 6 (düzeltilmiş sürüm)
 * Konu: 0 < x < 10 yazımının C'deki anlamı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_HA6_zincir_karsilastirma_duzeltilmis.c -o ha6d */

#include <stdio.h>

int main(void)
{
    int x = 25;

    if (0 < x && x < 10) {
        printf("%d, (0, 10) aralığında.\n", x);
    } else {
        printf("%d, aralığın dışında.\n", x);
    }
    return 0;
}

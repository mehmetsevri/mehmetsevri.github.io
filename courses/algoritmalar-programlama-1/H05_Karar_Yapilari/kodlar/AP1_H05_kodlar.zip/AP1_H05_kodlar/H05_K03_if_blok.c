/* H05_K03_if_blok.c — AP-1 Hafta 5, Kavram programı K03
 * Amaç   : Tek dallı if, if-else ve bloğun kapsam oluşturması
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K03_if_blok.c -o if_blok
 * Örnek çıktı: Sıcak bir gün: bol su için. */

#include <stdio.h>

int main(void)
{
    int sicaklik = 34;

    /* Tek dallı if: koşul yanlışsa hiçbir şey yapılmaz */
    if (sicaklik > 30) {
        printf("Sıcak bir gün: bol su için.\n");
    }

    /* if-else: iki yoldan tam olarak biri */
    if (sicaklik >= 20) {
        printf("Mont gerekmez.\n");
    } else {
        printf("Mont alın.\n");
    }

    /* Blok bir kapsam (scope) oluşturur */
    if (sicaklik > 30) {
        int fark = sicaklik - 30;        /* yalnızca bu blokta yaşar */
        printf("Eşik %d derece aşıldı.\n", fark);
    }
    return 0;
}

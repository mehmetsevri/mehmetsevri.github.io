/* H05_K02_dogruluk_degeri.c — AP-1 Hafta 5, Kavram programı K02
 * Amaç   : C'de doğruluk: 0 yanlış, sıfırdan farklı doğru; 0/1 sonuçlar; stdbool.h
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K02_dogruluk_degeri.c -o dogruluk
 * Örnek çıktı: (10 > 3) = 1, (10 < 3) = 0 */

#include <stdio.h>
#include <stdbool.h>

int main(void)
{
    int sayac = 3;
    if (sayac) {                        /* sayac != 0 ile aynı anlam */
        printf("sayac = %d  -> doğru sayıldı\n", sayac);
    }

    int eksi = -7;
    if (eksi) {
        printf("eksi = %d  -> doğru (sıfırdan farklı)\n", eksi);
    }

    int sifir = 0;
    if (!sifir) {
        printf("sifir = 0  -> yanlış; !sifir = %d\n", !sifir);
    }

    int sonuc = (10 > 3);
    printf("(10 > 3) = %d, (10 < 3) = %d\n", sonuc, 10 < 3);

    bool gecti = true;
    bool devamsiz = false;
    printf("gecti = %d, devamsiz = %d, sizeof(bool) = %zu\n",
           gecti, devamsiz, sizeof(bool));
    return 0;
}

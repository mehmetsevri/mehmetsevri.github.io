/* H05_01_isaret.c — AP-1 Hafta 5, Örnek 1 (★)
 * Amaç   : Pozitif / negatif / sıfır: if – else if – else
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_01_isaret.c -o isaret
 * Örnek çıktı: 7 pozitiftir.  (girdi: 7) */

#include <stdio.h>

int main(void)
{
    int sayi = 0;

    printf("Bir tamsayı girin: ");
    scanf("%d", &sayi);

    if (sayi > 0) {
        printf("%d pozitiftir.\n", sayi);
    } else if (sayi < 0) {
        printf("%d negatiftir.\n", sayi);
    } else {
        printf("Sayı sıfırdır.\n");
    }
    return 0;
}

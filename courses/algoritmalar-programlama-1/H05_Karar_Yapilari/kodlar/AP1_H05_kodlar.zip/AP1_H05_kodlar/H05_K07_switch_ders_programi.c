/* H05_K07_switch_ders_programi.c — AP-1 Hafta 5, Kavram programı K07
 * Amaç   : switch-case temel yapısı: case, break, default (atlama tablosu örneği)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K07_switch_ders_programi.c -o ders_programi
 * Örnek çıktı: Pazartesi: Algoritma dersi  (girdi: 1) */

#include <stdio.h>

int main(void)
{
    int gun = 0;

    printf("Gün (1-7): ");
    if (scanf("%d", &gun) != 1) {
        return 1;
    }
    switch (gun) {
    case 1:
        printf("Pazartesi: Algoritma dersi\n");
        break;
    case 2:
        printf("Salı: Fizik laboratuvarı\n");
        break;
    case 3:
        printf("Çarşamba: Matematik\n");
        break;
    case 4:
        printf("Perşembe: Algoritma uygulaması\n");
        break;
    case 5:
        printf("Cuma: Kimya\n");
        break;
    case 6:
    case 7:
        printf("Hafta sonu: ders yok\n");
        break;
    default:
        printf("Geçersiz gün: %d\n", gun);
        break;
    }
    return 0;
}

/* H05_13_harf_notu_test.c — AP-1 Hafta 5, Örnek 13 (★★★)
 * Amaç   : Harf notu için sınır değer test tablosu (her sınıra üç test)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_13_harf_notu_test.c -o harf_test
 * Örnek çıktı: DC şartlı başarılı  (girdi: 59) */

#include <stdio.h>

int main(void)
{
    int puan = 0;
    scanf("%d", &puan);          /* test için: istem yazdırılmaz */

    if (puan < 0 || puan > 100) {
        printf("GEÇERSİZ\n");
        return 1;
    }
    if (puan >= 90) {
        printf("AA");
    } else if (puan >= 81) {
        printf("BA");
    } else if (puan >= 73) {
        printf("BB");
    } else if (puan >= 66) {
        printf("CB");
    } else if (puan >= 60) {
        printf("CC");
    } else if (puan >= 50) {
        printf("DC");
    } else if (puan >= 40) {
        printf("DD");
    } else if (puan >= 30) {
        printf("FD");
    } else {
        printf("FF");
    }
    if (puan >= 60) {            /* CC ve üzeri: başarılı */
        printf(" başarılı\n");
    } else if (puan >= 50) {     /* DC: YANO >= 2,00 ise başarılı */
        printf(" şartlı başarılı\n");
    } else {
        printf(" başarısız\n");
    }
    return 0;
}

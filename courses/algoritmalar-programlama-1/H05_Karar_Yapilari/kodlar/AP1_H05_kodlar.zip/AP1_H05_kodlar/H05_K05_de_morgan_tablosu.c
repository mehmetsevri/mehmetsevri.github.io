/* H05_K05_de_morgan_tablosu.c — AP-1 Hafta 5, Kavram programı K05
 * Amaç   : &&, ||, ! doğruluk tablosu ve De Morgan eşdeğerlikleri
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K05_de_morgan_tablosu.c -o de_morgan
 * Örnek çıktı: A B | A&&B A||B | !(A&&B) !A||!B | !(A||B) !A&&!B */

#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;

    printf("A B | A&&B A||B | !(A&&B) !A||!B | !(A||B) !A&&!B\n");
    a = 0;
    b = 0;
    printf("%d %d |  %d    %d   |    %d       %d    |    %d       %d\n",
           a, b, a && b, a || b, !(a && b), !a || !b, !(a || b), !a && !b);
    a = 0;
    b = 1;
    printf("%d %d |  %d    %d   |    %d       %d    |    %d       %d\n",
           a, b, a && b, a || b, !(a && b), !a || !b, !(a || b), !a && !b);
    a = 1;
    b = 0;
    printf("%d %d |  %d    %d   |    %d       %d    |    %d       %d\n",
           a, b, a && b, a || b, !(a && b), !a || !b, !(a || b), !a && !b);
    a = 1;
    b = 1;
    printf("%d %d |  %d    %d   |    %d       %d    |    %d       %d\n",
           a, b, a && b, a || b, !(a && b), !a || !b, !(a || b), !a && !b);
    return 0;
}

/* H05_02_tek_cift.c — AP-1 Hafta 5, Örnek 2 (★)
 * Amaç   : Sayının tek/çift olması: if-else ve % (negatif kalan dahil)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_02_tek_cift.c -o tek_cift
 * Örnek çıktı: 14 çifttir.  (girdi: 14) */

#include <stdio.h>

int main(void)
{
    int sayi = 0;

    printf("Bir tamsayı girin: ");
    scanf("%d", &sayi);

    if (sayi % 2 == 0) {
        printf("%d çifttir.\n", sayi);
    } else {
        printf("%d tektir.\n", sayi);
    }
    printf("(%d %% 2 = %d)\n", sayi, sayi % 2);
    return 0;
}

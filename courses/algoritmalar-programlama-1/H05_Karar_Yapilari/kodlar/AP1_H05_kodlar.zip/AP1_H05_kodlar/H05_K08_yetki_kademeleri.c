/* H05_K08_yetki_kademeleri.c — AP-1 Hafta 5, Kavram programı K08
 * Amaç   : Gövdeli bilinçli düşüş ve fall through yorumu
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K08_yetki_kademeleri.c -o yetki
 * Örnek çıktı: - Not görüntüleme  (girdi: 3) */

#include <stdio.h>

int main(void)
{
    int seviye = 0;

    printf("Yetki seviyesi (1-3): ");
    scanf("%d", &seviye);

    printf("Açılan menüler:\n");
    switch (seviye) {
    case 3:
        printf("  - Kullanıcı yönetimi\n");
        /* fall through */
    case 2:
        printf("  - Not girişi\n");
        /* fall through */
    case 1:
        printf("  - Not görüntüleme\n");
        break;
    default:
        printf("  (hiçbiri: geçersiz seviye)\n");
        break;
    }
    return 0;
}

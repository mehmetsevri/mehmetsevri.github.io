/* H05_05_artik_yil.c — AP-1 Hafta 5, Örnek 5 (★★)
 * Amaç   : Artık yıl: if zinciri ve tek bileşik ifade; stdbool.h
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_05_artik_yil.c -o artik_yil
 * Örnek çıktı: if zinciri : artık yıl  (girdi: 2024) */

#include <stdio.h>
#include <stdbool.h>

int main(void)
{
    int yil = 0;

    printf("Yıl girin: ");
    scanf("%d", &yil);

    /* 1. yol: if zinciri — en özel kuraldan en genele */
    bool artik1 = false;
    if (yil % 400 == 0) {
        artik1 = true;
    } else if (yil % 100 == 0) {
        artik1 = false;
    } else if (yil % 4 == 0) {
        artik1 = true;
    } else {
        artik1 = false;
    }

    /* 2. yol: tek bileşik ifade (H4 Örnek 8) */
    bool artik2 = (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;

    printf("if zinciri : %s\n", artik1 ? "artık yıl" : "artık yıl değil");
    printf("tek ifade  : %s\n", artik2 ? "artık yıl" : "artık yıl değil");
    return 0;
}

/* H05_K01_geri_cagirma.c — AP-1 Hafta 5, Kavram programı K01
 * Amaç   : Geçen haftadan (H4) üç geri çağırma sorusunun kodu
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K01_geri_cagirma.c -o geri_cagirma
 * Örnek çıktı: 1 0 0 */

#include <stdio.h>

int main(void)
{
    /* S1: tamsayı bölmesi, kalan ve cast */
    int a = 7;
    int b = 2;
    printf("%d %d %.1f\n", a / b, a % b, (double)a / b);

    /* S2: ilişkisel ve mantıksal ifadeler 0 ya da 1 üretir */
    int x = 5;
    printf("%d %d %d\n", x > 3, x > 3 && x > 8, !x);

    /* S3: artık yıl ifadesi (H4 Örnek 8) */
    int yil = 1900;
    int artik = (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;
    printf("%d\n", artik);
    return 0;
}

/* H05_K12_kaput_kosul_operatoru.c — AP-1 Hafta 5, Kavram programı K12
 * Amaç   : Kaputun Altında: ?: → koşullu taşıma (cmov)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K12_kaput_kosul_operatoru.c -o kosul_cmov
 * Örnek çıktı: Büyük olan: 12  (girdi: 12 9) */

#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;
    if (scanf("%d %d", &a, &b) != 2) {
        return 1;
    }
    int buyuk = (a > b) ? a : b;
    printf("Büyük olan: %d\n", buyuk);
    return 0;
}

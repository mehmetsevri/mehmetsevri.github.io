/* H05_K11_kaput_seyrek_switch.c — AP-1 Hafta 5, Kavram programı K11
 * Amaç   : Kaputun Altında: seyrek case değerleri → karşılaştırma ağacı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K11_kaput_seyrek_switch.c -o seyrek
 * Örnek çıktı: bin  (girdi: 1000) */

#include <stdio.h>

int main(void)
{
    int kod = 0;
    if (scanf("%d", &kod) != 1) {
        return 1;
    }
    switch (kod) {
    case 1:
        printf("bir\n");
        break;
    case 100:
        printf("yüz\n");
        break;
    case 1000:
        printf("bin\n");
        break;
    case 10000:
        printf("on bin\n");
        break;
    case 100000:
        printf("yüz bin\n");
        break;
    default:
        printf("diğer\n");
        break;
    }
    return 0;
}

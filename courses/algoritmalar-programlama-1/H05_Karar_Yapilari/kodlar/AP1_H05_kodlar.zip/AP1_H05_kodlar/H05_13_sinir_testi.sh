#!/bin/bash
# H05_13_sinir_testi.sh — AP-1 Hafta 5, Örnek 13: harf notu için sınır değer testleri
# Kullanım: gcc -std=c17 -Wall -Wextra -pedantic -g H05_13_harf_notu_test.c -o harf_test
#           bash H05_13_sinir_testi.sh ./harf_test
# Her satır: girdi|beklenen. Beklenenler harf notu tablosundan (RTEÜ Ön Lisans ve Lisans
# Eğitim-Öğretim ve Sınav Yönetmeliği, Madde 30) ELLE yazılmıştır
# (programdan kopyalanmaz!); her sınır için bir altı, kendisi ve bir üstü denenir.
PROG=${1:-./harf_test}
gecen=0
kalan=0
while IFS='|' read -r girdi beklenen; do
    gercek=$(echo "$girdi" | "$PROG")
    if [ "$gercek" = "$beklenen" ]; then
        sonuc="✓"; gecen=$((gecen + 1))
    else
        sonuc="✗"; kalan=$((kalan + 1))
    fi
    echo "$girdi | beklenen: $beklenen | gerçek: $gercek | $sonuc"
done <<'TABLO'
-1|GEÇERSİZ
0|FF başarısız
1|FF başarısız
29|FF başarısız
30|FD başarısız
31|FD başarısız
39|FD başarısız
40|DD başarısız
41|DD başarısız
49|DD başarısız
50|DC şartlı başarılı
51|DC şartlı başarılı
59|DC şartlı başarılı
60|CC başarılı
61|CC başarılı
65|CC başarılı
66|CB başarılı
67|CB başarılı
72|CB başarılı
73|BB başarılı
74|BB başarılı
80|BB başarılı
81|BA başarılı
82|BA başarılı
89|BA başarılı
90|AA başarılı
91|AA başarılı
99|AA başarılı
100|AA başarılı
101|GEÇERSİZ
TABLO
echo "Toplam: $((gecen + kalan)) test, geçen: $gecen, kalan: $kalan"

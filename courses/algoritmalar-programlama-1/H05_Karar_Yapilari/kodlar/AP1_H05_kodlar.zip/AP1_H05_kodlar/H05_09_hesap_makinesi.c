/* H05_09_hesap_makinesi.c — AP-1 Hafta 5, Örnek 9 (★★)
 * Amaç   : Dört işlem hesap makinesi: switch ve sıfıra bölme denetimi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_09_hesap_makinesi.c -o hesap
 * Örnek çıktı: 12 / 4 = 3.00  (girdi: 12 / 4) */

#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;
    char islem = ' ';

    printf("İşlem girin (ör. 12 / 4): ");
    scanf("%d %c %d", &a, &islem, &b);

    switch (islem) {
    case '+':
        printf("%d + %d = %d\n", a, b, a + b);
        break;
    case '-':
        printf("%d - %d = %d\n", a, b, a - b);
        break;
    case '*':
        printf("%d * %d = %d\n", a, b, a * b);
        break;
    case '/':
        if (b == 0) {                        /* sıfıra bölme denetimi */
            printf("Hata: sıfıra bölme tanımsızdır.\n");
        } else {
            printf("%d / %d = %.2f\n", a, b, (double)a / b);
        }
        break;
    default:
        printf("Bilinmeyen işlem: '%c'\n", islem);
        break;
    }
    return 0;
}

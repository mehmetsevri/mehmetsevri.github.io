/* H05_06_harf_notu.c — AP-1 Hafta 5, Örnek 6 (★★)
 * Amaç   : Puandan harf notu: else-if merdiveni ve aralık sıralaması
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_06_harf_notu.c -o harf_notu
 * Örnek çıktı: Harf notu: BA  (girdi: 81) */

#include <stdio.h>

int main(void)
{
    int puan = 0;

    printf("Puanı girin (0-100): ");
    scanf("%d", &puan);

    if (puan < 0 || puan > 100) {                /* girdi doğrulama */
        printf("Hata: %d geçersiz; puan 0-100 olmalı.\n", puan);
        return 1;
    }

    printf("Harf notu: ");
    if (puan >= 90) {
        printf("AA\n");
    } else if (puan >= 81) {
        printf("BA\n");
    } else if (puan >= 73) {
        printf("BB\n");
    } else if (puan >= 66) {
        printf("CB\n");
    } else if (puan >= 60) {
        printf("CC\n");
    } else if (puan >= 50) {
        printf("DC\n");
    } else if (puan >= 40) {
        printf("DD\n");
    } else if (puan >= 30) {
        printf("FD\n");
    } else {
        printf("FF\n");
    }
    return 0;
}

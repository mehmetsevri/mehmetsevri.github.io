	.file	"H05_K07_switch_ders_programi.c"
	.text
	.section	.rodata
.LC0:
	.string	"G\303\274n (1-7): "
.LC1:
	.string	"%d"
.LC2:
	.string	"Pazartesi: Algoritma dersi"
.LC3:
	.string	"Sal\304\261: Fizik laboratuvar\304\261"
.LC4:
	.string	"\303\207ar\305\237amba: Matematik"
	.align 8
.LC5:
	.string	"Per\305\237embe: Algoritma uygulamas\304\261"
.LC6:
	.string	"Cuma: Kimya"
.LC7:
	.string	"Hafta sonu: ders yok"
.LC8:
	.string	"Ge\303\247ersiz g\303\274n: %d\n"
	.text
	.globl	main
	.type	main, @function
main:
	pushq	%rbp
	movq	%rsp, %rbp
	subq	$16, %rsp
	movl	$0, -4(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	leaq	-4(%rbp), %rax
	movq	%rax, %rsi
	leaq	.LC1(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	__isoc99_scanf@PLT
	cmpl	$1, %eax
	je	.L2
	movl	$1, %eax
	jmp	.L13
.L2:
	movl	-4(%rbp), %eax
	cmpl	$7, %eax
	ja	.L4
	movl	%eax, %eax
	leaq	0(,%rax,4), %rdx
	leaq	.L6(%rip), %rax
	movl	(%rdx,%rax), %eax
	cltq
	leaq	.L6(%rip), %rdx
	addq	%rdx, %rax
	jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L6:
	.long	.L4-.L6
	.long	.L11-.L6
	.long	.L10-.L6
	.long	.L9-.L6
	.long	.L8-.L6
	.long	.L7-.L6
	.long	.L5-.L6
	.long	.L5-.L6
	.text
.L11:
	leaq	.LC2(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	jmp	.L12
.L10:
	leaq	.LC3(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	jmp	.L12
.L9:
	leaq	.LC4(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	jmp	.L12
.L8:
	leaq	.LC5(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	jmp	.L12
.L7:
	leaq	.LC6(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	jmp	.L12
.L5:
	leaq	.LC7(%rip), %rax
	movq	%rax, %rdi
	call	puts@PLT
	jmp	.L12
.L4:
	movl	-4(%rbp), %eax
	movl	%eax, %esi
	leaq	.LC8(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	nop
.L12:
	movl	$0, %eax
.L13:
	leave
	ret
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits

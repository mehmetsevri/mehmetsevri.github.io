	.file	"H05_K12_kaput_kosul_operatoru.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"%d %d"
.LC1:
	.string	"B\303\274y\303\274k olan: %d\n"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
	subq	$24, %rsp
	leaq	.LC0(%rip), %rdi
	xorl	%eax, %eax
	leaq	12(%rsp), %rdx
	leaq	8(%rsp), %rsi
	movl	$0, 8(%rsp)
	movl	$0, 12(%rsp)
	call	__isoc99_scanf@PLT
	movl	%eax, %edx
	movl	$1, %eax
	cmpl	$2, %edx
	je	.L7
.L1:
	addq	$24, %rsp
	ret
.L7:
	movl	8(%rsp), %eax
	movl	12(%rsp), %esi
	leaq	.LC1(%rip), %rdi
	cmpl	%eax, %esi
	cmovl	%eax, %esi
	xorl	%eax, %eax
	call	printf@PLT
	xorl	%eax, %eax
	jmp	.L1
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits

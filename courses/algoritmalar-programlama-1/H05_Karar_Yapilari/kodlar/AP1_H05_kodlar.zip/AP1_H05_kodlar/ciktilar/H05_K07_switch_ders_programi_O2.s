	.file	"H05_K07_switch_ders_programi.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"G\303\274n (1-7): "
.LC1:
	.string	"%d"
.LC2:
	.string	"Pazartesi: Algoritma dersi"
.LC3:
	.string	"Sal\304\261: Fizik laboratuvar\304\261"
.LC4:
	.string	"\303\207ar\305\237amba: Matematik"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC5:
	.string	"Per\305\237embe: Algoritma uygulamas\304\261"
	.section	.rodata.str1.1
.LC6:
	.string	"Cuma: Kimya"
.LC7:
	.string	"Hafta sonu: ders yok"
.LC8:
	.string	"Ge\303\247ersiz g\303\274n: %d\n"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
	subq	$24, %rsp
	leaq	.LC0(%rip), %rdi
	xorl	%eax, %eax
	movl	$0, 12(%rsp)
	call	printf@PLT
	leaq	12(%rsp), %rsi
	leaq	.LC1(%rip), %rdi
	xorl	%eax, %eax
	call	__isoc99_scanf@PLT
	movl	%eax, %edx
	movl	$1, %eax
	cmpl	$1, %edx
	jne	.L1
	movl	12(%rsp), %esi
	leal	-1(%rsi), %eax
	cmpl	$6, %eax
	ja	.L3
	leaq	.L5(%rip), %rdx
	movslq	(%rdx,%rax,4), %rax
	addq	%rdx, %rax
	jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L5:
	.long	.L10-.L5
	.long	.L9-.L5
	.long	.L8-.L5
	.long	.L7-.L5
	.long	.L6-.L5
	.long	.L4-.L5
	.long	.L4-.L5
	.section	.text.startup
.L10:
	leaq	.LC2(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
.L1:
	addq	$24, %rsp
	ret
.L4:
	leaq	.LC7(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L9:
	leaq	.LC3(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L8:
	leaq	.LC4(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L7:
	leaq	.LC5(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L6:
	leaq	.LC6(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L3:
	leaq	.LC8(%rip), %rdi
	xorl	%eax, %eax
	call	printf@PLT
	xorl	%eax, %eax
	jmp	.L1
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits

	.file	"H05_K11_kaput_seyrek_switch.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"%d"
.LC1:
	.string	"bir"
.LC2:
	.string	"y\303\274z"
.LC3:
	.string	"bin"
.LC4:
	.string	"on bin"
.LC5:
	.string	"y\303\274z bin"
.LC6:
	.string	"di\304\237er"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
	subq	$24, %rsp
	leaq	.LC0(%rip), %rdi
	xorl	%eax, %eax
	leaq	12(%rsp), %rsi
	movl	$0, 12(%rsp)
	call	__isoc99_scanf@PLT
	movl	%eax, %edx
	movl	$1, %eax
	cmpl	$1, %edx
	jne	.L1
	movl	12(%rsp), %eax
	cmpl	$1000, %eax
	je	.L3
	jg	.L4
	cmpl	$1, %eax
	je	.L5
	cmpl	$100, %eax
	jne	.L7
	leaq	.LC2(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
.L1:
	addq	$24, %rsp
	ret
.L4:
	cmpl	$10000, %eax
	je	.L8
	cmpl	$100000, %eax
	jne	.L7
	leaq	.LC5(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L8:
	leaq	.LC4(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L3:
	leaq	.LC3(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L5:
	leaq	.LC1(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
.L7:
	leaq	.LC6(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits

	.file	"H05_K10_kaput_if.c"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"%d"
.LC1:
	.string	"Baraj ge\303\247ildi"
.LC2:
	.string	"FF"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
	subq	$24, %rsp
	leaq	.LC0(%rip), %rdi
	xorl	%eax, %eax
	leaq	12(%rsp), %rsi
	movl	$0, 12(%rsp)
	call	__isoc99_scanf@PLT
	movl	%eax, %edx
	movl	$1, %eax
	cmpl	$1, %edx
	jne	.L1
	cmpl	$49, 12(%rsp)
	jle	.L3
	leaq	.LC1(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
.L1:
	addq	$24, %rsp
	ret
.L3:
	leaq	.LC2(%rip), %rdi
	call	puts@PLT
	xorl	%eax, %eax
	jmp	.L1
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits

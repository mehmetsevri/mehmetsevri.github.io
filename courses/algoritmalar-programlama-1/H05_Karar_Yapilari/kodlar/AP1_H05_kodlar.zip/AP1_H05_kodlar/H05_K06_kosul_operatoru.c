/* H05_K06_kosul_operatoru.c — AP-1 Hafta 5, Kavram programı K06
 * Amaç   : Koşul operatörü ?: ile değer seçimi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K06_kosul_operatoru.c -o kosul_op
 * Örnek çıktı: |-7| = 7 */

#include <stdio.h>

int main(void)
{
    int n = -7;

    /* koşul ? doğruysa_değer : yanlışsa_değer */
    int mutlak = (n < 0) ? -n : n;
    printf("|%d| = %d\n", n, mutlak);

    printf("%d bir %s sayıdır.\n", n, (n % 2 == 0) ? "çift" : "tek");

    int final_notu = 45;
    printf("Final barajı: %s\n", (final_notu >= 50) ? "geçildi" : "FF");
    return 0;
}

/* H05_04_uc_sayi_en_buyuk.c — AP-1 Hafta 5, Örnek 4 (★★)
 * Amaç   : Üç sayının en büyüğü: iç içe if, && ve ardışık güncelleme
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_04_uc_sayi_en_buyuk.c -o uc_sayi
 * Örnek çıktı: Ardışık güncelleme : 9  (girdi: 4 9 7) */

#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;
    int c = 0;

    printf("Üç tamsayı girin: ");
    scanf("%d %d %d", &a, &b, &c);

    /* Çözüm 1: iç içe if (H2 Örnek 5, strateji 1) */
    int eb1 = 0;
    if (a >= b) {
        if (a >= c) {
            eb1 = a;
        } else {
            eb1 = c;
        }
    } else {
        if (b >= c) {
            eb1 = b;
        } else {
            eb1 = c;
        }
    }

    /* Çözüm 2: && ile bileşik koşullar */
    int eb2 = 0;
    if (a >= b && a >= c) {
        eb2 = a;
    } else if (b >= a && b >= c) {
        eb2 = b;
    } else {
        eb2 = c;
    }

    /* Çözüm 3: ardışık güncelleme (H2 Örnek 5, strateji 2) */
    int eb3 = a;
    if (b > eb3) {
        eb3 = b;
    }
    if (c > eb3) {
        eb3 = c;
    }

    printf("İç içe if          : %d\n", eb1);
    printf("&& ile koşullar    : %d\n", eb2);
    printf("Ardışık güncelleme : %d\n", eb3);
    return 0;
}

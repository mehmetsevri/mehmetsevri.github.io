/* H05_Q01_sifir_disi_dogru.c — AP-1 Hafta 5, Quiz sorusu 1
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_Q01_sifir_disi_dogru.c -o q01 */

#include <stdio.h>

int main(void)
{
    int x = -2;
    if (x) {
        printf("A\n");
    } else {
        printf("B\n");
    }
    return 0;
}

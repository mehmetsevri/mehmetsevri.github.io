/* H05_Q04_kisa_devre.c — AP-1 Hafta 5, Quiz sorusu 4
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_Q04_kisa_devre.c -o q04 */

#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 10;
    if (a != 0 && b / a > 2) {
        printf("X\n");
    } else {
        printf("Y\n");
    }
    return 0;
}

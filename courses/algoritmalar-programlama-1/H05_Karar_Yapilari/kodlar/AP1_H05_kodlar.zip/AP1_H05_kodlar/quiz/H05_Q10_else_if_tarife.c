/* H05_Q10_else_if_tarife.c — AP-1 Hafta 5, Quiz sorusu 10
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_Q10_else_if_tarife.c -o q10 */

#include <stdio.h>

int main(void)
{
    int yas = 20;
    int ogrenci = 0;
    if (yas < 18) {
        printf("Çocuk tarifesi\n");
    } else if (ogrenci) {
        printf("Öğrenci tarifesi\n");
    } else {
        printf("Tam tarife\n");
    }
    return 0;
}

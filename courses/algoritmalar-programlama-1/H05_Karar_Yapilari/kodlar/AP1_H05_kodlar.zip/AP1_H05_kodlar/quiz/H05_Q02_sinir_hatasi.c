/* H05_Q02_sinir_hatasi.c — AP-1 Hafta 5, Quiz sorusu 2
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_Q02_sinir_hatasi.c -o q02 */

#include <stdio.h>

int main(void)
{
    int puan = 81;
    if (puan >= 90) {
        printf("AA\n");
    } else if (puan > 81) {
        printf("BA\n");
    } else if (puan >= 73) {
        printf("BB\n");
    } else {
        printf("CB\n");
    }
    return 0;
}

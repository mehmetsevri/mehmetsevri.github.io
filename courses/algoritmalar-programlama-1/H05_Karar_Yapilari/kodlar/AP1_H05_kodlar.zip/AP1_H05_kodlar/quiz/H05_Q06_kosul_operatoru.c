/* H05_Q06_kosul_operatoru.c — AP-1 Hafta 5, Quiz sorusu 6
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_Q06_kosul_operatoru.c -o q06 */

#include <stdio.h>

int main(void)
{
    int a = 4;
    int b = 9;
    int k = (a > b) ? a - b : b - a;
    printf("%d\n", k);
    return 0;
}

/* H05_Q03_bilincli_dusus.c — AP-1 Hafta 5, Quiz sorusu 3
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_Q03_bilincli_dusus.c -o q03 */

#include <stdio.h>

int main(void)
{
    int n = 2;
    switch (n) {
    case 1:
        printf("bir ");
        /* fall through */
    case 2:
        printf("iki ");
        /* fall through */
    case 3:
        printf("üç ");
        break;
    default:
        printf("çok ");
        break;
    }
    printf("\n");
    return 0;
}

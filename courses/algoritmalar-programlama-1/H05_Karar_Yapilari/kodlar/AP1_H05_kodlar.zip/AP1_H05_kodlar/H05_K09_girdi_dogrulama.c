/* H05_K09_girdi_dogrulama.c — AP-1 Hafta 5, Kavram programı K09
 * Amaç   : Girdi doğrulama: scanf dönüş değeri ve aralık denetimi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_K09_girdi_dogrulama.c -o dogrulama
 * Örnek çıktı: Kabul edildi: 75  (girdi: 75) */

#include <stdio.h>

int main(void)
{
    int puan = 0;

    printf("Puan (0-100): ");
    if (scanf("%d", &puan) != 1) {           /* 1) Sayı mı? */
        printf("Hata: bir tamsayı girmelisiniz.\n");
        return 1;
    }
    if (puan < 0 || puan > 100) {            /* 2) Aralıkta mı? */
        printf("Hata: %d aralık dışında (0-100).\n", puan);
        return 1;
    }
    printf("Kabul edildi: %d\n", puan);       /* 3) Artık güvenle kullan */
    return 0;
}

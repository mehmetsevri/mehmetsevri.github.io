/* H05_11_pin_yetki.c — AP-1 Hafta 5, Örnek 11 (★★)
 * Amaç   : PIN doğrulama ve kullanıcı yetkisi: mantıksal operatörler, güvenlik bakışı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H05_11_pin_yetki.c -o pin
 * Örnek çıktı: Giriş başarılı.  (girdi: 1001 4826) */

#include <stdio.h>
#include <stdbool.h>

int main(void)
{
    /* YALNIZCA EĞİTSEL: gerçek sistemlerde kimlik bilgisi koda yazılmaz;
       PIN'in özeti (hash) saklanır ve deneme sayısı sınırlanır (H6). */
    const int OGRENCI_NO = 1001;
    const int OGRENCI_PIN = 4826;
    const int HOCA_NO = 2001;
    const int HOCA_PIN = 7391;

    int kullanici = 0;
    int pin = 0;
    printf("Kullanıcı no: ");
    scanf("%d", &kullanici);
    printf("PIN         : ");
    scanf("%d", &pin);

    bool ogrenci_mi = (kullanici == OGRENCI_NO && pin == OGRENCI_PIN);
    bool hoca_mi = (kullanici == HOCA_NO && pin == HOCA_PIN);

    if (!ogrenci_mi && !hoca_mi) {   /* De Morgan: !(ogrenci_mi || hoca_mi) */
        printf("Erişim reddedildi: kullanıcı no veya PIN hatalı.\n");
        return 1;
    }
    printf("Giriş başarılı.\n");
    if (hoca_mi) {
        printf("Yetki: not girme ve düzeltme\n");
    } else {
        printf("Yetki: yalnızca kendi notlarını görme\n");
    }
    return 0;
}

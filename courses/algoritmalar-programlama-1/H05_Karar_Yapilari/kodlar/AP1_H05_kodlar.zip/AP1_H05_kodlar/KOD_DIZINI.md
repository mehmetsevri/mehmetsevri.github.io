# Hafta 5 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` dosyası; türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (Örnek 8 ve HA8’de ayrıca `-lm`). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır; kullanıcı girdileri istemin sonunda, `[çıkış kodu: N]` satırı programın dönüş değeridir. Bütün örnek ve kavram programları ayrıca AddressSanitizer + UBSan ile temiz çalıştı.

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyadan üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = dosyaya metinde atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Web’deki kodlar dosyanın **tamamıdır** (satır numaraları dosyayla aynı); simülasyonların (`h05-hangi-dal`, `h05-asm`, `h05-karar-agaci`) gösterdiği kodlar da bu dosyalardan birebir alınır.

Envanter denetimi: `node shared/kod_envanteri.js 5` → **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H05_01_isaret.c` | Örnek 1 (★) | Pozitif / negatif / sıfır: if – else if – else | sıfır uyarı | 3.3 (şekil) | 13 (şekil), 34 | h05-merdiven |
| `H05_02_tek_cift.c` | Örnek 2 (★) | Sayının tek/çift olması: if-else ve % (negatif kalan dahil) | sıfır uyarı | 4.2 | 34 | h05-merdiven |
| `H05_03_iki_sayi_buyuk.c` | Örnek 3 (★) | İki sayının büyüğü: if-else ve koşul operatörü ?: | sıfır uyarı | 4.3 | 34 | h05-merdiven |
| `H05_04_uc_sayi_en_buyuk.c` | Örnek 4 (★★) | Üç sayının en büyüğü: iç içe if, && ve ardışık güncelleme | sıfır uyarı | 4.4 | 35 | h05-merdiven |
| `H05_05_artik_yil.c` | Örnek 5 (★★) | Artık yıl: if zinciri ve tek bileşik ifade; stdbool.h | sıfır uyarı | 4.5 | 36 | h05-merdiven |
| `H05_06_harf_notu.c` | Örnek 6 (★★) | Puandan harf notu: else-if merdiveni ve aralık sıralaması | sıfır uyarı | 3.3 (şekil), 4.6 | 37, 38 | h05-merdiven, h05-else-if |
| `H05_07_ucgen.c` | Örnek 7 (★★) | Üçgen geçerliliği ve türü: çok koşullu mantık | sıfır uyarı | 4.7 | 39 (şekil) | h05-merdiven |
| `H05_08_ikinci_derece.c` | Örnek 8 (★★) | İkinci dereceden denklemin kökleri: Δ > 0, Δ = 0, Δ < 0 dalları | sıfır uyarı | 4.8 | 40 | h05-merdiven |
| `H05_09_hesap_makinesi.c` | Örnek 9 (★★) | Dört işlem hesap makinesi: switch ve sıfıra bölme denetimi | sıfır uyarı | 4.9 | 25 (şekil), 41 | h05-merdiven |
| `H05_10_ay_gun.c` | Örnek 10 (★★) | Ayın gün sayısı: switch'te art arda case etiketleri (bilinçli düşüş) | sıfır uyarı | 4.10 | 42 | h05-merdiven |
| `H05_11_pin_yetki.c` | Örnek 11 (★★) | PIN doğrulama ve kullanıcı yetkisi: mantıksal operatörler, güvenlik bakışı | sıfır uyarı | 4.11 | 43 | h05-merdiven |
| `H05_12_elektrik_faturasi.c` | Örnek 12 (★★★) | Kademeli elektrik faturası: aralıklı hesaplama ve sınır değerler | sıfır uyarı | 4.12 | 44, 45 (şekil) | h05-merdiven |
| `H05_13_harf_notu_test.c` | Örnek 13 (★★★) | Harf notu için sınır değer test tablosu (her sınıra üç test) | sıfır uyarı | 3.9 (şekil), 4.13 | 15 | h05-merdiven |
| `H05_K01_geri_cagirma.c` | Kavram programı | Geçen haftadan (H4) üç geri çağırma sorusunun kodu | sıfır uyarı | 2 | 3 | h05-buyuk-soru |
| `H05_K02_dogruluk_degeri.c` | Kavram programı | C'de doğruluk: 0 yanlış, sıfırdan farklı doğru; 0/1 sonuçlar; stdbool.h | sıfır uyarı | 3.1 | 9 | h05-dogruluk |
| `H05_K03_if_blok.c` | Kavram programı | Tek dallı if, if-else ve bloğun kapsam oluşturması | sıfır uyarı | 3.2 | 1 (şekil), 10 (şekil), 11 (şekil), 12 | h05-if |
| `H05_K04_mantiksal_kosullar.c` | Kavram programı | && ve \|\| ile aralık denetimi, De Morgan ve kısa devre | sıfır uyarı | 3.5 | 19, 22 (şekil) | h05-bilesik |
| `H05_K05_de_morgan_tablosu.c` | Kavram programı | &&, \|\|, ! doğruluk tablosu ve De Morgan eşdeğerlikleri | sıfır uyarı | 3.5 (metin, şekil) | 20 (şekil) | h05-bilesik |
| `H05_K06_kosul_operatoru.c` | Kavram programı | Koşul operatörü ?: ile değer seçimi | sıfır uyarı | 3.6 | 24 | h05-kosul-op |
| `H05_K07_switch_ders_programi.c` | Kavram programı | switch-case temel yapısı: case, break, default (atlama tablosu örneği) | sıfır uyarı | 3.7 (metin), 3.10 (şekil) | 31 (şekil) | h05-switch, h05-kaput |
| `H05_K08_yetki_kademeleri.c` | Kavram programı | Gövdeli bilinçli düşüş ve fall through yorumu | sıfır uyarı | 3.7 | 26 (şekil) | h05-switch |
| `H05_K09_girdi_dogrulama.c` | Kavram programı | Girdi doğrulama: scanf dönüş değeri ve aralık denetimi | sıfır uyarı | 3.8 | 28 | h05-dogrulama |
| `H05_K10_kaput_if.c` | Kavram programı | Kaputun Altında: if → cmp + koşullu atlama (gcc -S) | sıfır uyarı | 3.10 (şekil) | 30 (şekil) | h05-kaput |
| `H05_K11_kaput_seyrek_switch.c` | Kavram programı | Kaputun Altında: seyrek case değerleri → karşılaştırma ağacı | sıfır uyarı | — | — | h05-kaput |
| `H05_K12_kaput_kosul_operatoru.c` | Kavram programı | Kaputun Altında: ?: → koşullu taşıma (cmov) | sıfır uyarı | — | 32 (şekil) | h05-kaput |
| `hata_avcisi/H05_HA1_atama_kosul.c` | Hata Avcısı (kasıtlı hata) | if (x = 5): atama ile karşılaştırmanın karıştırılması | derlenir; kasıtlı uyarı | — | 47 | h05-hata-avcisi, h05-tahmin |
| `hata_avcisi/H05_HA1_atama_kosul_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | if (x = 5): atama ile karşılaştırmanın karıştırılması | sıfır uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA2_bos_govde.c` | Hata Avcısı (kasıtlı hata) | if (kosul); — boş deyim tuzağı | derlenir; kasıtlı uyarı | — | — | h05-hata-avcisi, h05-tahmin |
| `hata_avcisi/H05_HA2_bos_govde_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | if (kosul); — boş deyim tuzağı | sıfır uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA3_parantezsiz_govde.c` | Hata Avcısı (kasıtlı hata) | Süslü parantezsiz çok satırlı gövde | derlenir; kasıtlı uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA3_parantezsiz_govde_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | Süslü parantezsiz çok satırlı gövde | sıfır uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA4_goto_fail_yeniden.c` | Hata Avcısı (kasıtlı hata) | goto fail: parantezsiz if ve yinelenen satır (eğitsel yeniden kurgu) | derlenir; kasıtlı uyarı | 5.1 | 5 | h05-buyuk-soru |
| `hata_avcisi/H05_HA4_goto_fail_yeniden_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | goto fail: parantezsiz if ve yinelenen satır (eğitsel yeniden kurgu) | sıfır uyarı | 5.1 (metin) | 49 | — |
| `hata_avcisi/H05_HA5_sallanan_else.c` | Hata Avcısı (kasıtlı hata) | İç içe if ve sallanan else | derlenir; kasıtlı uyarı | 3.4 (şekil) | 17 (şekil) | h05-ic-ice, h05-hata-avcisi, h05-tahmin |
| `hata_avcisi/H05_HA5_sallanan_else_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | İç içe if ve sallanan else | sıfır uyarı | — | 16 (şekil) | h05-hata-avcisi |
| `hata_avcisi/H05_HA6_zincir_karsilastirma.c` | Hata Avcısı (kasıtlı hata) | 0 < x < 10 yazımının C'deki anlamı | derlenir; kasıtlı uyarı | — | 47 | h05-hata-avcisi, h05-tahmin |
| `hata_avcisi/H05_HA6_zincir_karsilastirma_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | 0 < x < 10 yazımının C'deki anlamı | sıfır uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA7_break_unutma.c` | Hata Avcısı (kasıtlı hata) | switch'te break unutulması | derlenir; kasıtlı uyarı | — | — | h05-hata-avcisi, h05-tahmin |
| `hata_avcisi/H05_HA7_break_unutma_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | switch'te break unutulması | sıfır uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA8_kayan_esitlik.c` | Hata Avcısı (kasıtlı hata) | Kayan noktalı değerlerin == ile karşılaştırılması | derlenir; kasıtlı uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA8_kayan_esitlik_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | Kayan noktalı değerlerin == ile karşılaştırılması | sıfır uyarı | — | — | h05-hata-avcisi |
| `hata_avcisi/H05_HA9_blok_kapsami.c` | Hata Avcısı (kasıtlı hata) | Blok dışında blok içi değişkene erişim | derlenmez (kasıtlı hata) | — | 12 | h05-hata-avcisi |
| `hata_avcisi/H05_HA9_blok_kapsami_duzeltilmis.c` | Hata Avcısı (düzeltilmiş) | Blok dışında blok içi değişkene erişim | sıfır uyarı | — | — | h05-hata-avcisi |
| `alistirmalar/H05_A01_cikti_tahmini_ic_ice.c` | Alıştırma 5.1 | Alıştırma 5.1 (★, Çıktı tahmini) | sıfır uyarı | 8.2 (alıştırma) | — | h05-alistirmalar |
| `alistirmalar/H05_A02_cikti_tahmini_switch.c` | Alıştırma 5.2 | Alıştırma 5.2 (★★, Çıktı tahmini) | sıfır uyarı | 8.2 (alıştırma) | — | h05-alistirmalar |
| `alistirmalar/H05_A03_yanlis_sira.c` | Alıştırma 5.3 | Alıştırma 5.3 (★★, Hata bul) | sıfır uyarı | 8.2 (alıştırma) | 15 | h05-else-if, h05-alistirmalar |
| `alistirmalar/H05_A04_sinir_hatasi.c` | Alıştırma 5.4 | Alıştırma 5.4 (★★, Hata bul + test tasarla) | sıfır uyarı | 8.2 (alıştırma) | — | h05-alistirmalar |
| `alistirmalar/H05_A05_parsons_sicaklik.c` | Alıştırma 5.5 | Alıştırma 5.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8.2 (alıştırma) | — | h05-alistirmalar |
| `alistirmalar/H05_A06_tamamla_de_morgan.c` | Alıştırma 5.6 | Alıştırma 5.6 (★★, Kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8.2 (alıştırma) | — | h05-alistirmalar |
| `alistirmalar/H05_A07_kademe_hatasi.c` | Alıştırma 5.9 | Alıştırma 5.9 (★★★, Hata bul + sınır testi) | sıfır uyarı | 8.2 (alıştırma) | 45 (şekil) | h05-alistirmalar |
| `quiz/H05_Q01_sifir_disi_dogru.c` | Quiz 1 | Quiz sorusu 1 | sıfır uyarı | — | — | h05-quiz |
| `quiz/H05_Q02_sinir_hatasi.c` | Quiz 2 | Quiz sorusu 2 | sıfır uyarı | — | — | h05-quiz |
| `quiz/H05_Q03_bilincli_dusus.c` | Quiz 3 | Quiz sorusu 3 | sıfır uyarı | — | 27 | h05-quiz, h05-tahmin |
| `quiz/H05_Q04_kisa_devre.c` | Quiz 4 | Quiz sorusu 4 | sıfır uyarı | — | 23 | h05-quiz |
| `quiz/H05_Q06_kosul_operatoru.c` | Quiz 6 | Quiz sorusu 6 | sıfır uyarı | — | — | h05-quiz |
| `quiz/H05_Q10_else_if_tarife.c` | Quiz 10 | Quiz sorusu 10 | sıfır uyarı | — | — | h05-quiz, h05-tahmin |

**Diğer dosyalar**

- `H05_13_sinir_testi.sh` — Örnek 13’ün 30 sınır testini çalıştıran betik (beklenenler tablodan elle yazılmıştır): `bash H05_13_sinir_testi.sh ./harf_test`; çıktısı `ciktilar/H05_13_harf_notu_test.txt` içindedir (Toplam: 30 test, geçen: 30, kalan: 0). Ders notu 4.13, sunum “Örnek 13” slaytı, web `#h05-ornek-13`.
- `ciktilar/*.s` — Kaputun Altında için gerçek `gcc -S` çıktıları (9 dosya): `H05_K07_switch_ders_programi_O0.s`, `H05_K07_switch_ders_programi_O2.s`, `H05_K10_kaput_if_O0.s`, `H05_K10_kaput_if_O0_ubuntu_varsayilan.s`, `H05_K10_kaput_if_O2.s`, `H05_K10_kaput_if_O2_ubuntu_varsayilan.s`, `H05_K11_kaput_seyrek_switch_O2.s`, `H05_K12_kaput_kosul_operatoru_O0.s`, `H05_K12_kaput_kosul_operatoru_O2.s`. Sade görünüm bayrakları: `-fno-asynchronous-unwind-tables -fno-stack-protector -fcf-protection=none -U_FORTIFY_SOURCE`; `*_ubuntu_varsayilan.s` Ubuntu’nun varsayılan bayraklarıyla üretilmiştir. K07, K10, K11 ve K12’nin `ciktilar/*.txt` dosyalarının sonunda ayrıca `gcc -S` bölümleri vardır.
- `AP1_H05_kodlar.zip` — bu klasörün (`.c`, `.sh`, `ciktilar/` dahil) tamamı; arşiv açıldığında her şey tek bir `AP1_H05_kodlar/` kök klasörüne çıkar.

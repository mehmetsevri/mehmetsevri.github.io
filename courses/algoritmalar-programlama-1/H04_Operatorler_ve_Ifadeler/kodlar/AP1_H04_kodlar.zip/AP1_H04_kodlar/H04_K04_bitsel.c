/* H04_K04_bitsel.c — AP-1 Hafta 4, Kavram programı K04 (★★)
 * Amaç   : Bit düzeyi operatörler: &, |, ^, ~, <<, >>
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K04_bitsel.c -o bitsel
 * Örnek çıktı: a & b     = 0x48 */

#include <stdio.h>

int main(void)
{
    unsigned int a = 0xCA;          /* 1100 1010 */
    unsigned int b = 0x5C;          /* 0101 1100 */

    printf("a         = 0x%02X\n", a);
    printf("b         = 0x%02X\n", b);
    printf("a & b     = 0x%02X\n", a & b);
    printf("a | b     = 0x%02X\n", a | b);
    printf("a ^ b     = 0x%02X\n", a ^ b);
    printf("~a        = 0x%08X\n", ~a);
    printf("~a & 0xFF = 0x%02X\n", ~a & 0xFF);
    printf("a << 1    = 0x%03X\n", a << 1);
    printf("a >> 2    = 0x%02X\n", a >> 2);
    return 0;
}

/* H04_K13_tahmin_kartlari.c — AP-1 Hafta 4, Kavram programı K13 (★★★)
 * Amaç   : Tip dönüşümü tahmin kartlarının yanıtlarını _Generic ile doğrulama
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K13_tahmin_kartlari.c -o kartlar
 * Örnek çıktı: 7 / 2|int|3 */

#include <stdio.h>

/* _Generic (C11): ifadenin tipine göre bir ad seçer; burada yalnızca
   tahmin kartlarının yanıtlarını derleyiciye doğrulatmak için kullanılır */
#define TIP(x) _Generic((x), char: "char", int: "int", \
    unsigned int: "unsigned int", long: "long", float: "float", \
    double: "double", default: "başka")

int main(void)
{
    printf("7 / 2|%s|%d\n", TIP(7 / 2), 7 / 2);
    printf("7.0 / 2|%s|%.1f\n", TIP(7.0 / 2), 7.0 / 2);
    printf("(double)7 / 2|%s|%.1f\n", TIP((double)7 / 2), (double)7 / 2);
    printf("(double)(7 / 2)|%s|%.1f\n", TIP((double)(7 / 2)),
           (double)(7 / 2));
    printf("'A' + 1|%s|%d\n", TIP('A' + 1), 'A' + 1);
    printf("5 / 2 * 2.0|%s|%.1f\n", TIP(5 / 2 * 2.0), 5 / 2 * 2.0);
    printf("5 * 2.0 / 2|%s|%.1f\n", TIP(5 * 2.0 / 2), 5 * 2.0 / 2);
    printf("1 / 2 + 1 / 2.0|%s|%.1f\n", TIP(1 / 2 + 1 / 2.0),
           1 / 2 + 1 / 2.0);
    printf("10 / 4 * 4|%s|%d\n", TIP(10 / 4 * 4), 10 / 4 * 4);
    printf("-7 / 2|%s|%d\n", TIP(-7 / 2), -7 / 2);
    printf("-7 %% 2|%s|%d\n", TIP(-7 % 2), -7 % 2);
    printf("(int)3.99|%s|%d\n", TIP((int)3.99), (int)3.99);
    printf("(int)-3.99|%s|%d\n", TIP((int)-3.99), (int)-3.99);
    printf("'a' - 'A'|%s|%d\n", TIP('a' - 'A'), 'a' - 'A');
    printf("3.0f * 2|%s|%.1f\n", TIP(3.0f * 2), 3.0f * 2);
    printf("2.5f + 1.0|%s|%.1f\n", TIP(2.5f + 1.0), 2.5f + 1.0);
    printf("1 + 2L|%s|%ld\n", TIP(1 + 2L), 1 + 2L);
    printf("7u / 2|%s|%u\n", TIP(7u / 2), 7u / 2);
    printf("(char)('A' + 1)|%s|%c\n", TIP((char)('A' + 1)),
           (char)('A' + 1));
    printf("3 > 2|%s|%d\n", TIP(3 > 2), 3 > 2);
    printf("7 %% 3 * 1.5|%s|%.1f\n", TIP(7 % 3 * 1.5), 7 % 3 * 1.5);
    printf("9 / 2 + 0.5|%s|%.1f\n", TIP(9 / 2 + 0.5), 9 / 2 + 0.5);
    return 0;
}

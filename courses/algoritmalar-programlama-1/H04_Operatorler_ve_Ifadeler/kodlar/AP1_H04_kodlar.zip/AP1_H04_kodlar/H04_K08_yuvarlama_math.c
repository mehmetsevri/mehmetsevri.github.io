/* H04_K08_yuvarlama_math.c — AP-1 Hafta 4, Kavram programı K08 (★★)
 * Amaç   : math.h: round, floor, ceil, fabs, sqrt, pow; %.0f ve +0.5 tuzağı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K08_yuvarlama_math.c -o yuvarlama -lm
 * Örnek çıktı: round(2.5)  = 3.0 */

#include <stdio.h>
#include <math.h>

int main(void)
{
    printf("round(2.5)  = %.1f\n", round(2.5));
    printf("round(-2.5) = %.1f\n", round(-2.5));
    printf("printf %%.0f ile 2.5 -> %.0f\n", 2.5);
    printf("printf %%.0f ile 3.5 -> %.0f\n", 3.5);
    printf("floor(-2.7) = %.1f, ceil(-2.7) = %.1f\n", floor(-2.7),
           ceil(-2.7));
    printf("fabs(-2.7)  = %.1f\n", fabs(-2.7));

    double x = -2.7;
    printf("(int)x          = %d\n", (int)x);
    printf("(int)(x + 0.5)  = %d   (yanlış: -3 olmalı)\n", (int)(x + 0.5));
    printf("(int)round(x)   = %d\n", (int)round(x));
    printf("sqrt(2.0) = %.6f, pow(2.0, 10) = %.1f\n", sqrt(2.0),
           pow(2.0, 10));
    return 0;
}

/* H04_01_dort_islem.c — AP-1 Hafta 4, Örnek 1 (★)
 * Amaç   : Dört işlem ve kalan operatörü: tamsayı bölmesi ve %
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_01_dort_islem.c -o dort_islem
 * Örnek çıktı: a / b = 3   (tamsayı bölmesi: kesir atılır)  (girdi: 17 5) */

#include <stdio.h>

int main(void)
{
    int a = 0, b = 0;

    printf("İki tamsayı girin (a b): ");
    scanf("%d %d", &a, &b);

    printf("a + b = %d\n", a + b);
    printf("a - b = %d\n", a - b);
    printf("a * b = %d\n", a * b);
    printf("a / b = %d   (tamsayı bölmesi: kesir atılır)\n", a / b);
    printf("a %% b = %d   (kalan)\n", a % b);
    printf("(a / b) * b + a %% b = %d   (a ile aynı olmalı)\n",
           (a / b) * b + a % b);
    return 0;
}

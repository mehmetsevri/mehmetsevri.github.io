/* H04_05_artirma_azaltma.c — AP-1 Hafta 4, Örnek 5 (★★)
 * Amaç   : i++ ve ++i: önek ve sonek (önce tahmin et, sonra çalıştır)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_05_artirma_azaltma.c -o artirma
 * Örnek çıktı: a = i++  ->  a = 5, i = 6 */

#include <stdio.h>

int main(void)
{
    int i = 5;

    int a = i++;    /* sonek: önce değeri kullan (5), sonra artır */
    printf("a = i++  ->  a = %d, i = %d\n", a, i);

    int b = ++i;    /* önek: önce artır (7), sonra değeri kullan */
    printf("b = ++i  ->  b = %d, i = %d\n", b, i);

    int c = i--;
    printf("c = i--  ->  c = %d, i = %d\n", c, i);

    int d = --i;
    printf("d = --i  ->  d = %d, i = %d\n", d, i);

    i++;            /* tek başına deyim: önek ya da sonek fark etmez */
    ++i;
    printf("son      ->  i = %d\n", i);
    return 0;
}

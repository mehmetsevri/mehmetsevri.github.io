/* H04_K02_iliskisel_mantiksal.c — AP-1 Hafta 4, Kavram programı K02 (★)
 * Amaç   : İlişkisel ve mantıksal operatörler: sonuç her zaman 0 ya da 1
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K02_iliskisel_mantiksal.c -o iliskisel
 * Örnek çıktı: x > 5  : 1 */

#include <stdio.h>

int main(void)
{
    int x = 7;

    printf("x > 5  : %d\n", x > 5);
    printf("x == 5 : %d\n", x == 5);
    printf("x != 5 : %d\n", x != 5);
    printf("!x     : %d\n", !x);
    printf("!!x    : %d\n", !!x);

    printf("0 && 0 = %d, 0 && 1 = %d, 1 && 0 = %d, 1 && 1 = %d\n",
           0 && 0, 0 && 1, 1 && 0, 1 && 1);
    printf("0 || 0 = %d, 0 || 1 = %d, 1 || 0 = %d, 1 || 1 = %d\n",
           0 || 0, 0 || 1, 1 || 0, 1 || 1);

    int aralikta = 0 <= x && x <= 10;
    printf("0 <= x && x <= 10 : %d\n", aralikta);
    printf("(x > 5) + (x > 6) + (x > 7) = %d\n", (x > 5) + (x > 6) + (x > 7));
    return 0;
}

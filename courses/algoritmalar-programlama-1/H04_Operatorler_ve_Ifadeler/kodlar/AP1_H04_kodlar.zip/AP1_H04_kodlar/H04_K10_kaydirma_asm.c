/* H04_K10_kaydirma_asm.c — AP-1 Hafta 4, Kavram programı K10 (★★★)
 * Amaç   : Kaputun altında: x * 8, x / 8 ve x & 1 için derleyicinin ürettiği kod
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K10_kaydirma_asm.c -o asm
 * Örnek çıktı: 40 5 -2 1 */

#include <stdio.h>

unsigned int carp8(unsigned int x)
{
    return x * 8;
}

unsigned int bol8(unsigned int x)
{
    return x / 8;
}

int bol8_isaretli(int x)
{
    return x / 8;
}

unsigned int tek_mi(unsigned int x)
{
    return x & 1;
}

int main(void)
{
    printf("%u %u %d %u\n", carp8(5), bol8(40), bol8_isaretli(-17),
           tek_mi(7));
    return 0;
}

/* H04_09_tek_cift.c — AP-1 Hafta 4, Örnek 9 (★★)
 * Amaç   : Tek/çift: n % 2 ve n & 1 (en düşük anlamlı bit)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_09_tek_cift.c -o tek_cift
 * Örnek çıktı: n % 2         = 0  (girdi: 14) */

#include <stdio.h>

int main(void)
{
    int n = 0;

    printf("Bir tamsayı: ");
    scanf("%d", &n);

    printf("n %% 2         = %d\n", n % 2);
    printf("n & 1         = %d\n", n & 1);
    printf("n %% 2 != 0    = %d   (tek mi?)\n", n % 2 != 0);
    printf("(n & 1) == 1  = %d   (tek mi?)\n", (n & 1) == 1);
    printf("n %% 2 == 1    = %d   (dikkat: negatif tek sayıda 0)\n",
           n % 2 == 1);
    return 0;
}

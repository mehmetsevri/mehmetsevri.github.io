/* H04_K05_isaretli_kaydirma.c — AP-1 Hafta 4, Kavram programı K05 (★★★)
 * Amaç   : Negatif sayıda >> (uygulama tanımlı) ve / farkı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K05_isaretli_kaydirma.c -o kaydir_isaret
 * Örnek çıktı: n >> 2   = -5   (gcc: aritmetik kaydırma) */

#include <stdio.h>

int main(void)
{
    int n = -17;
    unsigned int u = (unsigned int)n;   /* aynı bitler: 0xFFFFFFEF */

    printf("n / 4    = %d   (bölme sıfıra doğru keser)\n", n / 4);
    printf("n >> 2   = %d   (gcc: aritmetik kaydırma)\n", n >> 2);
    printf("-16 >> 2 = %d\n", -16 >> 2);
    printf("n >> 2   = 0x%08X  (soldan işaret biti 1 girer)\n",
           (unsigned int)(n >> 2));
    printf("u >> 2   = 0x%08X  (işaretsiz: soldan 0 girer)\n", u >> 2);
    return 0;
}

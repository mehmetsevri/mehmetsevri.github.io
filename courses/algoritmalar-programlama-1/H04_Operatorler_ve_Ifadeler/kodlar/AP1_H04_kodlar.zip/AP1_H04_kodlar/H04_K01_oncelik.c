/* H04_K01_oncelik.c — AP-1 Hafta 4, Kavram programı K01 (★★)
 * Amaç   : Öncelik ve birleşme yönü; a + b * c - d / e
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K01_oncelik.c -o oncelik
 * Örnek çıktı: a + b * c - d / e = 12 */

#include <stdio.h>

int main(void)
{
    int a = 2, b = 3, c = 4, d = 10, e = 5;

    printf("2 + 3 * 4         = %d\n", 2 + 3 * 4);
    printf("(2 + 3) * 4       = %d\n", (2 + 3) * 4);
    printf("10 - 4 - 3        = %d\n", 10 - 4 - 3);     /* soldan sağa */
    printf("100 / 10 / 5      = %d\n", 100 / 10 / 5);
    printf("a + b * c - d / e = %d\n", a + b * c - d / e);

    int x = 0, y = 0, z = 0;
    x = y = z = 7;                                      /* sağdan sola */
    printf("x = y = z = 7     -> %d %d %d\n", x, y, z);
    printf("-2 * -3 = %d, !0 + 1 = %d\n", -2 * -3, !0 + 1);
    return 0;
}

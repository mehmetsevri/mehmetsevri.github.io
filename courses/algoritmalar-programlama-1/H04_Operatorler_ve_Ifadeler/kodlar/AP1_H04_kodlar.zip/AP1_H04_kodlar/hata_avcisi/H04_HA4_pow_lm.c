/* H04_HA4_pow_lm.c — AP-1 Hafta 4, Hata Avcısı 4 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR — Konu: pow sonucunun int'e atanması ve -lm bayrağı
 * Derleyici iletisi ve çalışma çıktısı: ciktilar/H04_HA4_pow_lm.txt */

#include <stdio.h>
#include <math.h>

int main(void)
{
    double anapara = 0.0, faiz = 0.0;
    int yil = 0;

    printf("Anapara, yıllık faiz (ör. 0.05), yıl: ");
    scanf("%lf %lf %d", &anapara, &faiz, &yil);

    int tutar = anapara * pow(1 + faiz, yil);   /* HATA: kuruşlar kesilir */
    printf("%d yıl sonra: %d TL\n", yil, tutar);
    return 0;
}

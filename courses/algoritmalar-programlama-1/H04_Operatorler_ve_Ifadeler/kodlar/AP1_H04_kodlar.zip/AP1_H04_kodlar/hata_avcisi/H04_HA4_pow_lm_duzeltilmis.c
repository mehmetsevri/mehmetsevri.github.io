/* H04_HA4_pow_lm_duzeltilmis.c — AP-1 Hafta 4, Hata Avcısı 4 (düzeltilmiş sürüm)
 * Konu: pow sonucunun int'e atanması ve -lm bayrağı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_HA4_pow_lm_duzeltilmis.c -o ha4d -lm */

#include <stdio.h>
#include <math.h>

int main(void)
{
    double anapara = 0.0, faiz = 0.0;
    int yil = 0;

    printf("Anapara, yıllık faiz (ör. 0.05), yıl: ");
    scanf("%lf %lf %d", &anapara, &faiz, &yil);

    double tutar = anapara * pow(1 + faiz, yil);  /* double'da kalır */
    printf("%d yıl sonra: %.2f TL\n", yil, tutar);
    return 0;
}

/* H04_HA3_bitsel_mantiksal.c — AP-1 Hafta 4, Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR — Konu: & ile && ve | ile || karışıklığı
 * Derleyici iletisi ve çalışma çıktısı: ciktilar/H04_HA3_bitsel_mantiksal.txt */

#include <stdio.h>

int main(void)
{
    int kitap = 2, dergi = 1;         /* ödünç alınan adetler */

    int ikisi_de = kitap & dergi;     /* HATA: & bit düzeyinde VE */
    printf("İkisinden de var mı? %d\n", ikisi_de);

    int x = 0;
    int sonuc = (x == 0) | printf("sağ taraf da çalıştı\n"); /* HATA: | */
    printf("sonuc = %d\n", sonuc);
    return 0;
}

/* H04_HA1_oncelik_ortalama.c — AP-1 Hafta 4, Hata Avcısı 1 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR — Konu: Öncelik hatası: ortalama = a + b / 2
 * Derleyici iletisi ve çalışma çıktısı: ciktilar/H04_HA1_oncelik_ortalama.txt */

#include <stdio.h>

int main(void)
{
    int vize = 70, final = 90;

    double ortalama = vize + final / 2;     /* HATA: önce final / 2 */
    printf("Ortalama: %.2f\n", ortalama);
    return 0;
}

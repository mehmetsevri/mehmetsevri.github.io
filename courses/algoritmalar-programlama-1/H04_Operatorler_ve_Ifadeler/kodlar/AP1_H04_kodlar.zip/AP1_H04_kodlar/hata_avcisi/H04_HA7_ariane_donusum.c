/* H04_HA7_ariane_donusum.c — AP-1 Hafta 4, Hata Avcısı 7 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR — Konu: Aralık dışı kayan nokta → tamsayı dönüşümü (Ariane 5)
 * Derleyici iletisi ve çalışma çıktısı: ciktilar/H04_HA7_ariane_donusum.txt */

#include <stdio.h>

int main(void)
{
    double yatay_hiz = 40000.0;       /* varsayımsal değer: 16 bite sığmaz */

    short bh = (short)yatay_hiz;      /* HATA: aralık dışı dönüşüm */
    printf("double %.1f -> short %d\n", yatay_hiz, bh);
    return 0;
}

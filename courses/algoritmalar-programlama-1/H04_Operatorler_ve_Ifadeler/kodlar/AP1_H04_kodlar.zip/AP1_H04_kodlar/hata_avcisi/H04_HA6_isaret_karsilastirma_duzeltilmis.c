/* H04_HA6_isaret_karsilastirma_duzeltilmis.c — AP-1 Hafta 4, Hata Avcısı 6 (düzeltilmiş sürüm)
 * Konu: İşaretli–işaretsiz karşılaştırma: -1 < 1u
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_HA6_isaret_karsilastirma_duzeltilmis.c -o ha6d */

#include <stdio.h>

int main(void)
{
    int sicaklik = -5;
    int esik = 10;                    /* iki işlenen de işaretli */

    int soguk_mu = sicaklik < esik;
    printf("-5 < 10 mu? %d\n", soguk_mu);
    printf("-1 < 1 mi?  %d\n", -1 < 1);
    return 0;
}

/* H04_HA5_sirasiz_yan_etki_duzeltilmis.c — AP-1 Hafta 4, Hata Avcısı 5 (düzeltilmiş sürüm)
 * Konu: Aynı ifadede bir değişkeni birden çok kez değiştirmek
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_HA5_sirasiz_yan_etki_duzeltilmis.c -o ha5d */

#include <stdio.h>

int main(void)
{
    int i = 5;
    int once = i++;         /* her yan etki ayrı deyimde: once = 5, i = 6 */
    int sonra = ++i;        /* sonra = 7, i = 7 */
    i = once + sonra;       /* amaç açıkça yazıldı */
    printf("i = %d\n", i);

    int n = 5;
    ++n;                    /* n = 6 */
    int k = n;
    ++n;                    /* n = 7 */
    k = k + n;              /* 6 + 7 */
    printf("k = %d\n", k);
    return 0;
}

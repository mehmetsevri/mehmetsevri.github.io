/* H04_HA2_atama_esitlik.c — AP-1 Hafta 4, Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR — Konu: = ile == karışıklığı
 * Derleyici iletisi ve çalışma çıktısı: ciktilar/H04_HA2_atama_esitlik.txt */

#include <stdio.h>

int main(void)
{
    int puan = 85;

    int tam_puan = (puan = 100);    /* HATA: == yerine = (atama!) */
    printf("puan = %d, tam puan mı? %d\n", puan, tam_puan);
    return 0;
}

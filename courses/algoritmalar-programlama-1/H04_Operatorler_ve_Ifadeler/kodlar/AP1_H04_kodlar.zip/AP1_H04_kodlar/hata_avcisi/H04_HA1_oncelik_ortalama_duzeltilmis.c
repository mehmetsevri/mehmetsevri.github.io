/* H04_HA1_oncelik_ortalama_duzeltilmis.c — AP-1 Hafta 4, Hata Avcısı 1 (düzeltilmiş sürüm)
 * Konu: Öncelik hatası: ortalama = a + b / 2
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_HA1_oncelik_ortalama_duzeltilmis.c -o ha1d */

#include <stdio.h>

int main(void)
{
    int vize = 70, final = 90;

    double ortalama = (vize + final) / 2.0; /* parantez + kayan bölme */
    printf("Ortalama: %.2f\n", ortalama);
    return 0;
}

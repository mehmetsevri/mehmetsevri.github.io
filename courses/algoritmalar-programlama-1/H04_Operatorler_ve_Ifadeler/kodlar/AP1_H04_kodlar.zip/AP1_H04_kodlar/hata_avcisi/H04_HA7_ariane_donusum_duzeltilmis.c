/* H04_HA7_ariane_donusum_duzeltilmis.c — AP-1 Hafta 4, Hata Avcısı 7 (düzeltilmiş sürüm)
 * Konu: Aralık dışı kayan nokta → tamsayı dönüşümü (Ariane 5)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_HA7_ariane_donusum_duzeltilmis.c -o ha7d -lm */

#include <stdio.h>
#include <limits.h>
#include <math.h>

int main(void)
{
    double yatay_hiz = 40000.0;

    int sigar = yatay_hiz >= SHRT_MIN && yatay_hiz <= SHRT_MAX;  /* 0/1 */
    double sinirli = fmax(SHRT_MIN, fmin(SHRT_MAX, yatay_hiz)); /* doyurma */
    short bh = (short)sinirli;        /* artık her zaman aralık içinde */
    printf("short'a sığar mı? %d\n", sigar);
    printf("double %.1f -> short %d (doyurmalı)\n", yatay_hiz, bh);
    return 0;
}

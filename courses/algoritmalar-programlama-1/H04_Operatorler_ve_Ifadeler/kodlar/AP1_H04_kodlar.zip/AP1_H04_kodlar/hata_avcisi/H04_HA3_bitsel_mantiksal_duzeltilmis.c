/* H04_HA3_bitsel_mantiksal_duzeltilmis.c — AP-1 Hafta 4, Hata Avcısı 3 (düzeltilmiş sürüm)
 * Konu: & ile && ve | ile || karışıklığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_HA3_bitsel_mantiksal_duzeltilmis.c -o ha3d */

#include <stdio.h>

int main(void)
{
    int kitap = 2, dergi = 1;         /* ödünç alınan adetler */

    int ikisi_de = kitap && dergi;    /* mantıksal VE: 0 ya da 1 */
    printf("İkisinden de var mı? %d\n", ikisi_de);

    int x = 0;
    int sonuc = (x == 0) || printf("sağ taraf da çalıştı\n"); /* kısa devre */
    printf("sonuc = %d\n", sonuc);
    return 0;
}

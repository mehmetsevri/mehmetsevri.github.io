/* H04_HA2_atama_esitlik_duzeltilmis.c — AP-1 Hafta 4, Hata Avcısı 2 (düzeltilmiş sürüm)
 * Konu: = ile == karışıklığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_HA2_atama_esitlik_duzeltilmis.c -o ha2d */

#include <stdio.h>

int main(void)
{
    int puan = 85;

    int tam_puan = (puan == 100);   /* karşılaştırma: 0 ya da 1 */
    printf("puan = %d, tam puan mı? %d\n", puan, tam_puan);
    return 0;
}

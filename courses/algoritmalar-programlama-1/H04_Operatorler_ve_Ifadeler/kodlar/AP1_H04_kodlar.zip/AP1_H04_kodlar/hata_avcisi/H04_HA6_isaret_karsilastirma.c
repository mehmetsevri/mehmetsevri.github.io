/* H04_HA6_isaret_karsilastirma.c — AP-1 Hafta 4, Hata Avcısı 6 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR — Konu: İşaretli–işaretsiz karşılaştırma: -1 < 1u
 * Derleyici iletisi ve çalışma çıktısı: ciktilar/H04_HA6_isaret_karsilastirma.txt */

#include <stdio.h>

int main(void)
{
    int sicaklik = -5;
    unsigned int esik = 10;

    int soguk_mu = sicaklik < esik;   /* HATA: -5 işaretsize dönüşür */
    printf("-5 < 10 mu? %d\n", soguk_mu);
    printf("-1 < 1u mu? %d\n", -1 < 1u);
    return 0;
}

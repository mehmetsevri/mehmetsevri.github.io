/* H04_HA5_sirasiz_yan_etki.c — AP-1 Hafta 4, Hata Avcısı 5 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR — Konu: Aynı ifadede bir değişkeni birden çok kez değiştirmek
 * Derleyici iletisi ve çalışma çıktısı: ciktilar/H04_HA5_sirasiz_yan_etki.txt */

#include <stdio.h>

int main(void)
{
    int i = 5;
    i = i++ + ++i;          /* HATA: i aynı ifadede birden çok kez değişir */
    printf("i = %d\n", i);

    int n = 5;
    int k = ++n + ++n;      /* HATA: n iki kez değişir; sıra belirsiz */
    printf("k = %d\n", k);
    return 0;
}

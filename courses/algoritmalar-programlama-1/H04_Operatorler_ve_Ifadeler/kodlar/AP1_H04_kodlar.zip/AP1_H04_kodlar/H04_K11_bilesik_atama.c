/* H04_K11_bilesik_atama.c — AP-1 Hafta 4, Kavram programı K11 (★)
 * Amaç   : Bileşik atama operatörleri: +=, -=, *=, /=, %=
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K11_bilesik_atama.c -o bilesik
 * Örnek çıktı: x *= 2 + 1 -> 6 */

#include <stdio.h>

int main(void)
{
    int x = 20;

    x += 5;         /* x = x + 5 */
    printf("x += 5     -> %d\n", x);
    x -= 3;
    printf("x -= 3     -> %d\n", x);
    x *= 2;
    printf("x *= 2     -> %d\n", x);
    x /= 5;         /* tamsayı bölmesi */
    printf("x /= 5     -> %d\n", x);
    x %= 3;
    printf("x %%= 3     -> %d\n", x);
    x *= 2 + 1;     /* x = x * (2 + 1): önce sağ taraf */
    printf("x *= 2 + 1 -> %d\n", x);
    return 0;
}

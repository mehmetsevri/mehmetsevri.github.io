/* H04_K07_genisletme_daraltma.c — AP-1 Hafta 4, Kavram programı K07 (★★★)
 * Amaç   : Genişletme (işaret/sıfır) ve daraltma (kesme) dönüşümleri
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K07_genisletme_daraltma.c -o daraltma
 * Örnek çıktı: signed char   -> int:  -56  0xFFFFFFC8 */

#include <stdio.h>

int main(void)
{
    signed char sc = -56;           /* bitler: 1100 1000 (0xC8) */
    unsigned char uc = 200;         /* bitler: 1100 1000 (0xC8) */
    int i1 = sc;                    /* işaret genişletme */
    int i2 = uc;                    /* sıfırla genişletme */
    printf("signed char   -> int: %4d  0x%08X\n", i1, (unsigned int)i1);
    printf("unsigned char -> int: %4d  0x%08X\n", i2, (unsigned int)i2);

    int buyuk = 300;                /* 0x0000012C */
    unsigned char kesik = (unsigned char)buyuk;    /* yalnızca alt 8 bit */
    printf("(unsigned char)300 = %d   (300 - 256)\n", kesik);
    int cok_buyuk = 70000;          /* 0x00011170 */
    short kisa = (short)cok_buyuk;  /* sonuç derleyiciye bağlı */
    printf("(short)70000       = %d  (gcc: alt 16 bit)\n", kisa);

    double x = 3.99;
    printf("(int)3.99 = %d, (int)-3.99 = %d   (sıfıra doğru)\n",
           (int)x, (int)-x);
    return 0;
}

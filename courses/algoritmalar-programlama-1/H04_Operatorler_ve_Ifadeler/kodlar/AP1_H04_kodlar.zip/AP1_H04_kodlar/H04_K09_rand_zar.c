/* H04_K09_rand_zar.c — AP-1 Hafta 4, Kavram programı K09 (★)
 * Amaç   : rand/srand'a ilk bakış: zar atma (sabit tohum)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K09_rand_zar.c -o zar
 * Örnek çıktı: Zarlar    : 1 1 6 */

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    srand(42);                    /* sabit tohum: her çalıştırmada aynı dizi */
    int zar1 = rand() % 6 + 1;    /* 0..5 aralığını 1..6 aralığına kaydır */
    int zar2 = rand() % 6 + 1;
    int zar3 = rand() % 6 + 1;
    printf("Zarlar    : %d %d %d\n", zar1, zar2, zar3);
    printf("RAND_MAX  : %d\n", RAND_MAX);

    srand(42);                    /* aynı tohum: aynı üç sayı yeniden */
    printf("Tek printf: %d %d %d  (argüman sırası belirtilmemiştir)\n",
           rand() % 6 + 1, rand() % 6 + 1, rand() % 6 + 1);
    return 0;
}

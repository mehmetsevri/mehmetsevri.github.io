/* H04_K12_geri_cagirma.c — AP-1 Hafta 4, Kavram programı K12 (★)
 * Amaç   : Geçen haftadan (H3): üç geri çağırma sorusunun programı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K12_geri_cagirma.c -o geri
 * Örnek çıktı: 0 */

#include <stdio.h>
#include <limits.h>

int main(void)
{
    unsigned int u = UINT_MAX;
    u = u + 1;
    printf("%u\n", u);

    printf("%d\n", 0.1 + 0.2 == 0.3);

    printf("[%6.2f]\n", 3.14159);
    return 0;
}

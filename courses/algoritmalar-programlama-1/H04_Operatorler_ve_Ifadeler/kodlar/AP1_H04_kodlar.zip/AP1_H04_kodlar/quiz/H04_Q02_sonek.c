/* H04_Q02_sonek.c — AP-1 Hafta 4, web "Kendini sına" sorusu 2
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q02_sonek.c -o q02 */

#include <stdio.h>

int main(void)
{
    int i = 3;
    int j = i++ + 2;
    printf("i = %d, j = %d\n", i, j);
    return 0;
}

/* H04_Q04_bit_test.c — AP-1 Hafta 4, web "Kendini sına" sorusu 4
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q04_bit_test.c -o q04 */

#include <stdio.h>

int main(void)
{
    unsigned int x = 0x2C;
    printf("%u\n", (x >> 2) & 1u);
    return 0;
}

/* H04_Q10_sekizlik.c — AP-1 Hafta 4, web "Kendini sına" sorusu 10
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q10_sekizlik.c -o q10 */

#include <stdio.h>

int main(void)
{
    printf("%o %d\n", 0755, 0755);
    return 0;
}

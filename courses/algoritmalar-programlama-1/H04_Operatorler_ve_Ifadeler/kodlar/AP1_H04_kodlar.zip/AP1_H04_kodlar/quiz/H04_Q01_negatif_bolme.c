/* H04_Q01_negatif_bolme.c — AP-1 Hafta 4, web "Kendini sına" sorusu 1
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q01_negatif_bolme.c -o q01 */

#include <stdio.h>

int main(void)
{
    printf("%d %d\n", -7 / 2, -7 % 2);
    return 0;
}

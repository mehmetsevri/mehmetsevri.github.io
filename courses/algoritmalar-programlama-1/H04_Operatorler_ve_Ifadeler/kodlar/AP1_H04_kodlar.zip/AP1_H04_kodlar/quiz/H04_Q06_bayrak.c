/* H04_Q06_bayrak.c — AP-1 Hafta 4, web "Kendini sına" sorusu 6
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q06_bayrak.c -o q06 */

#include <stdio.h>

int main(void)
{
    unsigned int bayraklar = 0x5Au;     /* 0101 1010 */
    printf("%d\n", (bayraklar & (1u << 3)) != 0);
    printf("%d\n", (bayraklar & (1u << 2)) != 0);
    return 0;
}

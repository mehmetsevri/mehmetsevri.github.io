/* H04_Q08_kisa_devre.c — AP-1 Hafta 4, web "Kendini sına" sorusu 8
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q08_kisa_devre.c -o q08 */

#include <stdio.h>

int main(void)
{
    int x = 0;
    int r = (x != 0) && (10 / x > 1);
    printf("r = %d\n", r);
    return 0;
}

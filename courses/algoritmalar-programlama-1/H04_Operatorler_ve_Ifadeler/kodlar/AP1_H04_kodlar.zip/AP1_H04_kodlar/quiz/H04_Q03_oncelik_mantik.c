/* H04_Q03_oncelik_mantik.c — AP-1 Hafta 4, web "Kendini sına" sorusu 3
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q03_oncelik_mantik.c -o q03 */

#include <stdio.h>

int main(void)
{
    printf("%d\n", 2 + 3 * 4 > 10 && 5 % 3 == 2);
    return 0;
}

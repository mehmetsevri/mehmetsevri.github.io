/* H04_Q09_yuvarlama.c — AP-1 Hafta 4, web "Kendini sına" sorusu 9
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q09_yuvarlama.c -o q09 -lm */

#include <stdio.h>
#include <math.h>

int main(void)
{
    printf("%.0f %.0f\n", round(2.5), 2.5);
    return 0;
}

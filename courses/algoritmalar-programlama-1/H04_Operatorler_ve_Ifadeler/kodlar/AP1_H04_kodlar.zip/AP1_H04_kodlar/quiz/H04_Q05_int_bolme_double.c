/* H04_Q05_int_bolme_double.c — AP-1 Hafta 4, web "Kendini sına" sorusu 5
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_Q05_int_bolme_double.c -o q05 */

#include <stdio.h>

int main(void)
{
    double d = 7 / 2;
    printf("%.1f\n", d);
    return 0;
}

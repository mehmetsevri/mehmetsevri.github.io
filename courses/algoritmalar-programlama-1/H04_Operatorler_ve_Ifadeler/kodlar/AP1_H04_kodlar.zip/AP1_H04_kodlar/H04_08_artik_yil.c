/* H04_08_artik_yil.c — AP-1 Hafta 4, Örnek 8 (★★)
 * Amaç   : Artık yıl koşulu tek bir mantıksal ifade olarak (sonuç 0/1)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_08_artik_yil.c -o artik_yil
 * Örnek çıktı: Artık yıl mı? (1 evet, 0 hayır): 1  (girdi: 2024) */

#include <stdio.h>

int main(void)
{
    int yil = 0;

    printf("Yıl: ");
    scanf("%d", &yil);

    int artik = (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;

    printf("%d %% 4   == 0 : %d\n", yil, yil % 4 == 0);
    printf("%d %% 100 != 0 : %d\n", yil, yil % 100 != 0);
    printf("%d %% 400 == 0 : %d\n", yil, yil % 400 == 0);
    printf("Artık yıl mı? (1 evet, 0 hayır): %d\n", artik);
    printf("Şubat bu yıl %d gün çeker.\n", 28 + artik);
    return 0;
}

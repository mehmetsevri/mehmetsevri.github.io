/* H04_A07_parsons_ters_cevir.c — AP-1 Hafta 4, Alıştırma 4.7 (Parsons)
 * Parsons problemi: satırlar karışık sırada; tamamlanacak (doğru sıraya dizilecek); bu hâliyle derlenmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A07_parsons_ters_cevir.c -o a07 */

#include <stdio.h>

int main(void)
{
    printf("Tersi: %d\n", ters);
    int yuzler = sayi / 100;
    scanf("%d", &sayi);
    int ters = birler * 100 + onlar * 10 + yuzler;
    int birler = sayi % 10;
    int sayi = 0;
    int onlar = (sayi / 10) % 10;
    printf("Üç basamaklı bir sayı: ");
    return 0;
}

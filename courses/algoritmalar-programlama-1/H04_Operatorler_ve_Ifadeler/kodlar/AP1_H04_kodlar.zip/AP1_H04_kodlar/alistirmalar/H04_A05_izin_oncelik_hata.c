/* H04_A05_izin_oncelik_hata.c — AP-1 Hafta 4, Alıştırma 4.5 (Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR — hatayı bulup düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A05_izin_oncelik_hata.c -o a05 */

#include <stdio.h>

int main(void)
{
    unsigned int izin = 0644;

    int sahip_yazabilir = izin & 0200 == 0200;
    printf("Sahip yazabilir mi? %d\n", sahip_yazabilir);
    return 0;
}

/* H04_A03_donusum_tahmini.c — AP-1 Hafta 4, Alıştırma 4.3 (Çıktı tahmini)
 * Önce çıktıyı kâğıt üzerinde tahmin edin, sonra derleyip çalıştırın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A03_donusum_tahmini.c -o a03 */

#include <stdio.h>

int main(void)
{
    printf("%.2f\n", 9 / 4 * 1.0);
    printf("%.2f\n", 9 * 1.0 / 4);
    printf("%d\n", (int)9.99 + (int)-9.99);
    printf("%d\n", 'a' - 'A');
    printf("%d\n", 3 > 2 && 2 > 1);
    printf("%u\n", 0x0Fu << 4 | 0x03u);
    return 0;
}

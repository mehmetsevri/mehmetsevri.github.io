/* H04_A08_led_tamamla.c — AP-1 Hafta 4, Alıştırma 4.8 (Kod tamamla)
 * Tamamlanacak; bu hâliyle derlenmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A08_led_tamamla.c -o a08 */

#include <stdio.h>

int main(void)
{
    unsigned int led = 0x00;                /* 8 LED, hepsi sönük */

    led = led ___ (1u << 3);                /* (a) 3. LED'i yak */
    led = led ___ (1u << 7);                /* (b) 7. LED'i yak */
    led = led ___ (1u << 3);                /* (c) 3. LED'i tersine çevir */
    int yanik7 = (led ___ (1u << 7)) != 0;  /* (d) 7. LED yanıyor mu? */
    printf("led = 0x%02X, 7. LED: %d\n", led, yanik7);
    return 0;
}

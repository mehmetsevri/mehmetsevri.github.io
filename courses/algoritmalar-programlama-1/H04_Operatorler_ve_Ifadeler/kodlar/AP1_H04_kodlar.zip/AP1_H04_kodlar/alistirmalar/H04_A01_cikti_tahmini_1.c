/* H04_A01_cikti_tahmini_1.c — AP-1 Hafta 4, Alıştırma 4.1 (Çıktı tahmini)
 * Önce çıktıyı kâğıt üzerinde tahmin edin, sonra derleyip çalıştırın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A01_cikti_tahmini_1.c -o a01 */

#include <stdio.h>

int main(void)
{
    printf("%d %d %d\n", 17 / 5, 17 % 5, -17 / 5);
    printf("%d %d\n", -17 % 5, 17 % -5);
    printf("%d\n", 2 + 3 * 4 % 5);
    printf("%d\n", (2 + 3) * 4 % 5);
    return 0;
}

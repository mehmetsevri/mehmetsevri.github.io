/* H04_A06_aralik_zinciri_hata.c — AP-1 Hafta 4, Alıştırma 4.6 (Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR — hatayı bulup düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A06_aralik_zinciri_hata.c -o a06 */

#include <stdio.h>

int main(void)
{
    int puan = 150;

    int gecerli = 0 <= puan <= 100;
    printf("Puan geçerli mi? %d\n", gecerli);
    return 0;
}

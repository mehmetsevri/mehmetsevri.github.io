/* H04_A04_fahrenheit_hata.c — AP-1 Hafta 4, Alıştırma 4.4 (Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR — hatayı bulup düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A04_fahrenheit_hata.c -o a04 */

#include <stdio.h>

int main(void)
{
    double f = 0.0;

    printf("Fahrenheit: ");
    scanf("%lf", &f);

    double c = 5 / 9 * (f - 32);
    printf("Celsius: %.1f\n", c);
    return 0;
}

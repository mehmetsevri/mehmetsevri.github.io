/* H04_A02_cikti_tahmini_2.c — AP-1 Hafta 4, Alıştırma 4.2 (Çıktı tahmini)
 * Önce çıktıyı kâğıt üzerinde tahmin edin, sonra derleyip çalıştırın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_A02_cikti_tahmini_2.c -o a02 */

#include <stdio.h>

int main(void)
{
    int x = 10;
    int y = x++ * 2;
    int z = --x + y;
    x *= 3 - 1;
    printf("x = %d, y = %d, z = %d\n", x, y, z);
    return 0;
}

/* H04_03_basamaklar.c — AP-1 Hafta 4, Örnek 3 (★★)
 * Amaç   : Üç basamaklı sayının basamakları ve basamak toplamı (%10, /10)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_03_basamaklar.c -o basamak
 * Örnek çıktı: Basamak toplamı: 13  (girdi: 472) */

#include <stdio.h>

int main(void)
{
    int sayi = 0;

    printf("Üç basamaklı bir sayı: ");
    scanf("%d", &sayi);

    /* % 10 son basamağı verir, / 10 son basamağı atar */
    int birler = sayi % 10;
    int onlar = (sayi / 10) % 10;
    int yuzler = sayi / 100;
    int toplam = yuzler + onlar + birler;

    printf("Yüzler: %d  Onlar: %d  Birler: %d\n", yuzler, onlar, birler);
    printf("Basamak toplamı: %d\n", toplam);
    return 0;
}

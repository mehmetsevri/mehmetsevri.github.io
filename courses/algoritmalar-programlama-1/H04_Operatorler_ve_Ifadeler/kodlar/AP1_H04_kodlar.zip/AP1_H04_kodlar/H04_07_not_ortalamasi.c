/* H04_07_not_ortalamasi.c — AP-1 Hafta 4, Örnek 7 (★★)
 * Amaç   : Not ortalamasında cast ve yuvarlama (round, %.0f, +0.5)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_07_not_ortalamasi.c -o not_ort -lm
 * Örnek çıktı: round(ortalama)      : 86  (girdi: 85 90 78 92) */

#include <stdio.h>
#include <math.h>

int main(void)
{
    int q1 = 0, q2 = 0, q3 = 0, q4 = 0;

    printf("Dört quiz notu: ");
    scanf("%d %d %d %d", &q1, &q2, &q3, &q4);

    int toplam = q1 + q2 + q3 + q4;
    int tamsayi_ort = toplam / 4;             /* kesir atılır */
    double ortalama = (double)toplam / 4;     /* cast: kesirli bölme */

    printf("Toplam               : %d\n", toplam);
    printf("toplam / 4           : %d\n", tamsayi_ort);
    printf("(double)toplam / 4   : %.2f\n", ortalama);
    printf("round(ortalama)      : %.0f\n", round(ortalama));
    printf("(int)(ortalama + 0.5): %d\n", (int)(ortalama + 0.5));
    printf("printf ile %%.0f      : %.0f\n", ortalama);
    return 0;
}

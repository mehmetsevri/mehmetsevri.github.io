/* H04_K14_yuvarlama_tablosu.c — AP-1 Hafta 4, Kavram programı K14 (★★)
 * Amaç   : Yuvarlama yollarının karşılaştırma tablosu (Şekil 4.x verisi)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K14_yuvarlama_tablosu.c -o yuv_tablo -lm
 * Örnek çıktı: 2.5  |      2     2    3     3             3    2 */

#include <stdio.h>
#include <math.h>

int main(void)
{
    printf("x    | (int)x floor ceil round (int)(x+0.5) %%.0f\n");
    printf("2.5  | %6d %5.0f %4.0f %5.0f %13d %4.0f\n",
           (int)2.5, floor(2.5), ceil(2.5), round(2.5), (int)(2.5 + 0.5), 2.5);
    printf("-2.5 | %6d %5.0f %4.0f %5.0f %13d %4.0f\n",
           (int)-2.5, floor(-2.5), ceil(-2.5), round(-2.5), (int)(-2.5 + 0.5),
           -2.5);
    printf("2.7  | %6d %5.0f %4.0f %5.0f %13d %4.0f\n",
           (int)2.7, floor(2.7), ceil(2.7), round(2.7), (int)(2.7 + 0.5), 2.7);
    printf("-2.7 | %6d %5.0f %4.0f %5.0f %13d %4.0f\n",
           (int)-2.7, floor(-2.7), ceil(-2.7), round(-2.7), (int)(-2.7 + 0.5),
           -2.7);
    return 0;
}

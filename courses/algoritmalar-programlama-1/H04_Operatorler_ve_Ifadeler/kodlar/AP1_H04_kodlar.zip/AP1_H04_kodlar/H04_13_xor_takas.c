/* H04_13_xor_takas.c — AP-1 Hafta 4, Örnek 13 (★★★)
 * Amaç   : XOR ile takas (Merak Kutusu): ^ operatörü ve sınırları
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_13_xor_takas.c -o xor_takas
 * Örnek çıktı: XOR takası : a = 25, b = 12 */

#include <stdio.h>

int main(void)
{
    int a = 12, b = 25;               /* ikili: 01100 ve 11001 */

    printf("Başta      : a = %d, b = %d\n", a, b);
    a ^= b;                           /* a = a ^ b */
    b ^= a;                           /* b = b ^ (a ^ b) = eski a */
    a ^= b;                           /* a = (a ^ b) ^ eski a = eski b */
    printf("XOR takası : a = %d, b = %d\n", a, b);

    int gecici = a;                   /* H3'teki üçüncü bardak */
    a = b;
    b = gecici;
    printf("Geri takas : a = %d, b = %d\n", a, b);

    int c = 7;                        /* bir nesneyi kendisiyle "takas" */
    c ^= c;                           /* x ^ x == 0: değer kaybolur */
    c ^= c;
    c ^= c;
    printf("c kendisiyle: c = %d (7 kalmalıydı)\n", c);
    return 0;
}

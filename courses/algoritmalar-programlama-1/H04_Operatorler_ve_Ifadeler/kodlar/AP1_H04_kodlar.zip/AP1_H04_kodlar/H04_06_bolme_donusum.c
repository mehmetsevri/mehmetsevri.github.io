/* H04_06_bolme_donusum.c — AP-1 Hafta 4, Örnek 6 (★★)
 * Amaç   : 7/2, 7.0/2 ve (double)7/2: örtük ve açık tip dönüşümü
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_06_bolme_donusum.c -o bolme
 * Örnek çıktı: (double)7 / 2   = 3.500000 */

#include <stdio.h>

int main(void)
{
    printf("7 / 2           = %d\n", 7 / 2);
    printf("7.0 / 2         = %f\n", 7.0 / 2);
    printf("7 / 2.0         = %f\n", 7 / 2.0);
    printf("(double)7 / 2   = %f\n", (double)7 / 2);
    printf("(double)(7 / 2) = %f\n", (double)(7 / 2));
    printf("5 / 2 * 2.0     = %f\n", 5 / 2 * 2.0);
    printf("5 * 2.0 / 2     = %f\n", 5 * 2.0 / 2);
    printf("(int)3.99       = %d\n", (int)3.99);
    printf("(int)-3.99      = %d\n", (int)-3.99);

    int toplam = 7, adet = 2;
    double yanlis = toplam / adet;          /* önce int bölmesi: 3 */
    double dogru = (double)toplam / adet;   /* önce dönüşüm: 3.5 */
    printf("yanlis = %.2f, dogru = %.2f\n", yanlis, dogru);
    return 0;
}

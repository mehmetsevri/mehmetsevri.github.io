/* H04_11_ikinci_derece.c — AP-1 Hafta 4, Örnek 11 (★★)
 * Amaç   : İkinci dereceden denklem: diskriminant, sqrt, pow ve -lm
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_11_ikinci_derece.c -o kokler -lm
 * Örnek çıktı: x1 = 2.0000  (girdi: 1 -3 2) */

#include <stdio.h>
#include <math.h>

int main(void)
{
    double a = 0.0, b = 0.0, c = 0.0;

    printf("a, b, c katsayıları: ");
    scanf("%lf %lf %lf", &a, &b, &c);

    double delta = pow(b, 2) - 4 * a * c;          /* Δ = b² - 4ac */
    double kok1 = (-b + sqrt(delta)) / (2 * a);
    double kok2 = (-b - sqrt(delta)) / (2 * a);

    printf("Δ  = %.2f\n", delta);
    printf("x1 = %.4f\n", kok1);
    printf("x2 = %.4f\n", kok2);
    return 0;
}

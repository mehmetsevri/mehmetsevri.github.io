/* H04_K15_bolme_isaretleri.c — AP-1 Hafta 4, Kavram programı K15 (★★)
 * Amaç   : İşaret kombinasyonlarında / ve %: kalanın işareti bölünenle aynı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K15_bolme_isaretleri.c -o bolme_isaret
 * Örnek çıktı: -7 /  2 = -3   -7 %  2 = -1 */

#include <stdio.h>

int main(void)
{
    printf(" 7 /  2 = %2d    7 %%  2 = %2d\n", 7 / 2, 7 % 2);
    printf("-7 /  2 = %2d   -7 %%  2 = %2d\n", -7 / 2, -7 % 2);
    printf(" 7 / -2 = %2d    7 %% -2 = %2d\n", 7 / -2, 7 % -2);
    printf("-7 / -2 = %2d   -7 %% -2 = %2d\n", -7 / -2, -7 % -2);
    return 0;
}

/* H04_K03_kisa_devre.c — AP-1 Hafta 4, Kavram programı K03 (★★)
 * Amaç   : Kısa devre değerlendirme: && ve || sağ tarafı atlayabilir
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K03_kisa_devre.c -o kisa_devre
 * Örnek çıktı: 4) (b != 0) && (10 / b > 1) = 0 */

#include <stdio.h>

int main(void)
{
    int x = 0;

    printf("1) (x != 0) && printf(...)\n");
    int s1 = (x != 0) && printf("   sağ taraf çalıştı\n");
    printf("   sonuç = %d\n", s1);

    printf("2) (x == 0) && printf(...)\n");
    int s2 = (x == 0) && printf("   sağ taraf çalıştı\n");
    printf("   sonuç = %d\n", s2);

    printf("3) (x == 0) || printf(...)\n");
    int s3 = (x == 0) || printf("   sağ taraf çalıştı\n");
    printf("   sonuç = %d\n", s3);

    int b = 0;
    int guvenli = (b != 0) && (10 / b > 1);   /* 10 / b hiç hesaplanmaz */
    printf("4) (b != 0) && (10 / b > 1) = %d\n", guvenli);
    return 0;
}

/* H04_10_kaydirma.c — AP-1 Hafta 4, Örnek 10 (★★)
 * Amaç   : 2'nin kuvvetleri: << ve >> ile çarpma/bölme karşılığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_10_kaydirma.c -o kaydirma
 * Örnek çıktı: x << 3   =  40  (0x28)  x * 8 */

#include <stdio.h>

int main(void)
{
    unsigned int x = 5u;                  /* ikili: 0000 0101 */

    printf("x        = %3u  (0x%02X)\n", x, x);
    printf("x << 1   = %3u  (0x%02X)  x * 2\n", x << 1, x << 1);
    printf("x << 3   = %3u  (0x%02X)  x * 8\n", x << 3, x << 3);
    printf("x >> 1   = %3u  (0x%02X)  x / 2 (kesir atılır)\n", x >> 1,
           x >> 1);
    printf("40u >> 3 = %3u  (0x%02X)  40 / 8\n", 40u >> 3, 40u >> 3);

    unsigned int bayrak = 1u << 4;        /* yalnızca 4. bit 1 */
    printf("1u << 4  = %3u  (0x%02X)\n", bayrak, bayrak);
    printf("1u << 10 = %u (2 üzeri 10)\n", 1u << 10);
    printf("1u << 31 = %u\n", 1u << 31);
    return 0;
}

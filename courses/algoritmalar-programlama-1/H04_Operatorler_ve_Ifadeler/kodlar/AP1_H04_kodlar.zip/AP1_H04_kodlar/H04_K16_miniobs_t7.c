/* H04_K16_miniobs_t7.c — AP-1 Hafta 4, Kavram programı K16 (★★)
 * Amaç   : Mini-OBS v0.4’ün üç ifadesi T7 girdisiyle: 59.5 neden 59 oldu?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K16_miniobs_t7.c -o t7
 * Örnek çıktı: Ortalama (%.17g) : 59.499999999999993 */

#include <stdio.h>

int main(void)
{
    const double VIZE_AGIRLIK = 0.40;
    const double FINAL_AGIRLIK = 0.60;
    const int GECME_ORTALAMA = 60;
    const int FINAL_BARAJI = 50;

    double vize = 1.0, final = 98.5;   /* T7: matematikte ortalama tam 59.5 */

    double ortalama = VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
    int yuvarlanmis = (int)(ortalama + 0.5);   /* not >= 0: yarım yukarı */
    int gecti = (yuvarlanmis >= GECME_ORTALAMA) && (final >= FINAL_BARAJI);

    printf("Ortalama (%%.2f)  : %.2f\n", ortalama);
    printf("Ortalama (%%.17g) : %.17g\n", ortalama);
    printf("Yuvarlanmış      : %d\n", yuvarlanmis);
    printf("Geçme durumu (1=geçti, 0=kaldı): %d\n", gecti);
    return 0;
}

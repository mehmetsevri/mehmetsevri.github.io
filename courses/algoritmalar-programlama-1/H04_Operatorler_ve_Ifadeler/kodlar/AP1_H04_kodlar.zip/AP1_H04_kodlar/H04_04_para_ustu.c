/* H04_04_para_ustu.c — AP-1 Hafta 4, Örnek 4 (★★)
 * Amaç   : Para üstü: en az parça (ardışık bölme-kalan, %=; açgözlü yaklaşım)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_04_para_ustu.c -o para_ustu
 * Örnek çıktı: Toplam parça: 8  (girdi: 387) */

#include <stdio.h>

int main(void)
{
    int tutar = 0;

    printf("Para üstü (TL, tamsayı): ");
    scanf("%d", &tutar);
    printf("%d TL için en az sayıda banknot/madeni para:\n", tutar);

    int adet200 = tutar / 200;   /* önce en büyük değer */
    tutar %= 200;                /* tutar = tutar % 200 */
    int adet100 = tutar / 100;
    tutar %= 100;
    int adet50 = tutar / 50;
    tutar %= 50;
    int adet20 = tutar / 20;
    tutar %= 20;
    int adet10 = tutar / 10;
    tutar %= 10;
    int adet5 = tutar / 5;
    tutar %= 5;
    int adet1 = tutar;           /* kalan: 1 TL'ler */

    printf("200 TL x %d\n", adet200);
    printf("100 TL x %d\n", adet100);
    printf(" 50 TL x %d\n", adet50);
    printf(" 20 TL x %d\n", adet20);
    printf(" 10 TL x %d\n", adet10);
    printf("  5 TL x %d\n", adet5);
    printf("  1 TL x %d\n", adet1);
    printf("Toplam parça: %d\n",
           adet200 + adet100 + adet50 + adet20 + adet10 + adet5 + adet1);
    return 0;
}

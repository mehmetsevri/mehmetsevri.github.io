/* H04_K06_yukseltme.c — AP-1 Hafta 4, Kavram programı K06 (★★)
 * Amaç   : Tamsayı yükseltmeleri ve olağan aritmetik dönüşümler
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_K06_yukseltme.c -o yukseltme
 * Örnek çıktı: sizeof(c1 + c2) = 4 */

#include <stdio.h>

int main(void)
{
    char c1 = 100, c2 = 100;
    int toplam = c1 + c2;           /* char'lar önce int'e yükseltilir */
    printf("c1 + c2         = %d\n", toplam);
    printf("sizeof(c1)      = %zu\n", sizeof(c1));
    printf("sizeof(c1 + c2) = %zu\n", sizeof(c1 + c2));
    printf("sizeof('A')     = %zu   (C'de karakter sabiti int'tir)\n",
           sizeof('A'));

    unsigned char u = 255;
    printf("u + 1           = %d\n", u + 1);   /* int olarak: 256 */
    u = u + 1;                                  /* geri yazılınca: 0 */
    printf("u = u + 1 sonra = %d\n", u);

    int i = 5;
    long l = 3;
    float f = 1.5f;
    double d = 2.0;
    printf("sizeof(i + l)   = %zu   (int  -> long)\n", sizeof(i + l));
    printf("sizeof(l + f)   = %zu   (long -> float)\n", sizeof(l + f));
    printf("sizeof(f * d)   = %zu   (float -> double)\n", sizeof(f * d));
    printf("i / 2 = %d, i / d = %.1f\n", i / 2, i / d);
    return 0;
}

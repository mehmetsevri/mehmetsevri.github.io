/* H04_02_saniye_donustur.c — AP-1 Hafta 4, Örnek 2 (★)
 * Amaç   : Saniyeyi saat:dakika:saniye biçimine çevirme (/ ve %)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_02_saniye_donustur.c -o saniye
 * Örnek çıktı: 3725 saniye = 01:02:05  (girdi: 3725) */

#include <stdio.h>

int main(void)
{
    int toplam_saniye = 0;

    printf("Süre (saniye): ");
    scanf("%d", &toplam_saniye);

    /* / tam birim sayısını, % geriye kalanı verir */
    int saat = toplam_saniye / 3600;
    int kalan = toplam_saniye % 3600;
    int dakika = kalan / 60;
    int saniye = kalan % 60;

    printf("%d saniye = %02d:%02d:%02d\n", toplam_saniye, saat, dakika,
           saniye);
    return 0;
}

/* H04_12_dosya_izinleri.c — AP-1 Hafta 4, Örnek 12 (★★★)
 * Amaç   : Dosya izin bitleri: set, clear, toggle, test (maskeler)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H04_12_dosya_izinleri.c -o izinler
 * Örnek çıktı: Başlangıç            : 755 */

#include <stdio.h>

int main(void)
{
    /* r = 4, w = 2, x = 1: her sekizlik basamak bir grubun üç biti */
    const unsigned int SAHIP_R = 0400, SAHIP_W = 0200, SAHIP_X = 0100;
    const unsigned int GRUP_R = 0040, GRUP_W = 0020, GRUP_X = 0010;
    const unsigned int DIGER_R = 0004, DIGER_W = 0002, DIGER_X = 0001;

    unsigned int izin = 0755;             /* baştaki 0: sekizlik taban! */
    printf("Başlangıç            : %03o\n", izin);
    printf("Grup yazabilir mi?   : %d\n", (izin & GRUP_W) != 0);  /* test */

    izin |= GRUP_W;                       /* set: biti 1 yap */
    printf("izin |= GRUP_W       : %03o\n", izin);
    izin &= ~(DIGER_R | DIGER_X);         /* clear: bitleri 0 yap */
    printf("izin &= ~(R|X diğer) : %03o\n", izin);
    izin ^= SAHIP_X;                      /* toggle: tersine çevir */
    printf("izin ^= SAHIP_X      : %03o\n", izin);
    izin ^= SAHIP_X;                      /* bir kez daha: eski hâli */
    printf("izin ^= SAHIP_X      : %03o\n", izin);

    printf("Sahip/grup/diğer     : %o %o %o\n",
           (izin >> 6) & 7, (izin >> 3) & 7, izin & 7);
    printf("Diğerleri okuyabilir mi? %d\n", (izin & DIGER_R) != 0);

    unsigned int rw_r_r = SAHIP_R | SAHIP_W | GRUP_R | DIGER_R;
    unsigned int hepsi = rw_r_r | SAHIP_X | GRUP_W | GRUP_X | DIGER_W
                         | DIGER_X;
    printf("rw-r--r-- = %03o, rwxrwxrwx = %03o\n", rw_r_r, hepsi);
    printf("0755 onlu tabanda %u; 755 ise %u\n", 0755u, 755u);
    return 0;
}

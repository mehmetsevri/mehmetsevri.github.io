# Hafta 10 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` ve `.h` dosyası (59 `.c`, 1 `.h`); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (GCC 13.3, x86-64 Linux; özel komutlar dosya başlıklarında: `H10_09_zar_histogram.c` kayıtlı çıktı için `-DSABIT_TOHUM=2026` ile, Mini-OBS `-lm` ile). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (her dosyanın başında derleme komutu, sonra `$ ./program` satırları ve girdileriyle birlikte çıktı). Örnek ve kavram programları ayrıca AddressSanitizer + UBSan ile temiz çalıştı (“ASan+UBSan temiz”); bilerek hatalı `H10_13_sinir_disi.c` hiçbir uyarı vermez (`-O2` dahil), ASan altında “stack-buffer-overflow” raporu verir (`ciktilar/H10_13_sinir_disi_asan_tam.txt`).

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Ders notu ve sunumdaki kod kesitleri dosyanın **ardışık satırlarıdır** (başlıkta dosya adı ve satır aralığı); web’deki kod blokları dosyanın tamamı ya da ardışık bir kesitidir (`data-start` ile satır numarası). Web simülasyonlarındaki kod satırları da bu dosyalardan birebir alınır.

Envanter denetimi (ders materyalindeki her kod bloğu bu klasördeki bir dosyayla eşleşir): **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H10_01_dizi_oku_yaz.c` | Örnek 1 (★) | Örnek 1 (★): 5 elemanlı dizi oku-yazdır | sıfır uyarı; ASan+UBSan temiz | 3.4 | 16 | h10-merdiven |
| `H10_02_toplam_ortalama.c` | Örnek 2 (★) | Örnek 2 (★): toplam ve ortalama | sıfır uyarı; ASan+UBSan temiz | 4.1 | 26 | h10-merdiven |
| `H10_03_ortalama_ustu.c` | Örnek 3 (★) | Örnek 3 (★): ortalamanın üstündekiler | sıfır uyarı; ASan+UBSan temiz | 4.1 | 27 (üst başlık, şekil) | h10-merdiven |
| `H10_04_deger_sayma.c` | Örnek 4 (★) | Örnek 4 (★): bir değer kaç kez geçiyor? | sıfır uyarı; ASan+UBSan temiz | 4.1 | 28 (üst başlık) | h10-merdiven |
| `H10_05_en_buyuk_indis.c` | Örnek 5 (★★) | Örnek 5 (★★): en büyük ve indisi | sıfır uyarı; ASan+UBSan temiz | 4.2 | 28 | h10-merdiven |
| `H10_06_dogrusal_tarama.c` | Örnek 6 (★★) | Örnek 6 (★★): değer var mı, nerede? | sıfır uyarı; ASan+UBSan temiz | 4.3 | 29 (üst başlık, şekil) | h10-merdiven |
| `H10_07_ters_cevir.c` | Örnek 7 (★★) | Örnek 7 (★★): diziyi yerinde ters çevirme | sıfır uyarı; ASan+UBSan temiz | 4.4 | 30, 31 (şekil) | h10-merdiven |
| `H10_08_sola_dondur.c` | Örnek 8 (★★) | Örnek 8 (★★): bir konum sola döndürme | sıfır uyarı; ASan+UBSan temiz | 4.4 | 33 (üst başlık, şekil) | h10-merdiven |
| `H10_09_zar_histogram.c` | Örnek 9 (★★) | Örnek 9 (★★): 6000 zar atışı ve histogram | sıfır uyarı; ASan+UBSan temiz | 4.5, 8 (metin) | 34, 35 (şekil) | h10-merdiven |
| `H10_10_harf_dagilimi.c` | Örnek 10 (★★) | Örnek 10 (★★): harf notu dağılımı | sıfır uyarı; ASan+UBSan temiz | 4.5, 8 (metin) | 36 (üst başlık, şekil) | h10-merdiven |
| `H10_11_dizi_fonksiyonlari.c` | Örnek 11 (★★) | Örnek 11 (★★): dizi fonksiyonları | sıfır uyarı; ASan+UBSan temiz | 4.5 | 37 | h10-merdiven |
| `H10_12_ekle_sil.c` | Örnek 12 (★★★) | Örnek 12 (★★★): araya ekleme ve silme | sıfır uyarı; ASan+UBSan temiz | 4.6 | 38, 39 (şekil), 48 | h10-merdiven |
| `H10_13_sinir_disi.c` | Örnek 13 (★★★) | Örnek 13 (★★★): sınır dışı yazma deneyi | sıfır uyarı; kasıtlı sınır dışı yazma (tanımsız davranış) | 4.7, 8 (alıştırma) | 40, 41 (şekil) | h10-merdiven |
| `H10_14_eratosthenes.c` | Örnek 14 (★★★) | Örnek 14 (★★★, meydan okuma): Eratosthenes Kalburu | sıfır uyarı; ASan+UBSan temiz | 4.8 | 43, 44 (şekil) | h10-merdiven |
| `H10_K01_ayri_degiskenler.c` | Kavram programı | Kavram programı: neden dizi? | sıfır uyarı; ASan+UBSan temiz | 3.1 (metin) | 10 | h10-neden-dizi |
| `H10_K02_bildirim_ilk_deger.c` | Kavram programı | Kavram programı: bildirim ve | sıfır uyarı; ASan+UBSan temiz | 3.2 | 12 | h10-bildirim |
| `H10_K03_adresler.c` | Kavram programı | Kavram programı: bitişik bellek | sıfır uyarı; ASan+UBSan temiz | 3.1 (şekil), 3.3 (metin, şekil) | 11 (not, şekil), 14 (üst başlık, şekil), 15 (not, üst başlık) | h10-adres |
| `H10_K04_sizeof.c` | Kavram programı | Kavram programı: sizeof ile eleman sayısı | sıfır uyarı; ASan+UBSan temiz | 3.4 | 17 | h10-dolasma |
| `H10_K05_vla.c` | Kavram programı | Kavram programı: değişken uzunluklu dizi (VLA) | sıfır uyarı; ASan+UBSan temiz | 3.5 | 18 | h10-dolasma |
| `H10_K06_dizi_adresi.c` | Kavram programı | Kavram programı: fonksiyona dizinin | sıfır uyarı; ASan+UBSan temiz | 3.6 | 19 (üst başlık, şekil) | h10-fonksiyon |
| `H10_K07_ikili_dizi.c` | Kavram programı | Kavram programı: tersten yazdırma | sıfır uyarı; ASan+UBSan temiz | 4.1 | — | h10-merdiven |
| `H10_K08_kaydirma_yonu.c` | Kavram programı | Kavram programı: kaydırma yönü | sıfır uyarı; ASan+UBSan temiz | 4.6 (metin, şekil) | 39 (üst başlık, şekil) | h10-merdiven |
| `H10_K09_kopyala_karsilastir.c` | Kavram programı | Kavram programı: dizi kopyalama, karşılaştırma ve birleştirme | sıfır uyarı; ASan+UBSan temiz | 3.7 | 20 | h10-kopyalama |
| `H10_K10_paralel_diziler.c` | Kavram programı | Kavram programı: paralel diziler | sıfır uyarı; ASan+UBSan temiz | 3.8 (metin) | 21 (not) | h10-kopyalama |
| `H10_K11_heartbeat_benzetimi.c` | Kavram programı | Kavram programı: "uzunluğa | sıfır uyarı; ASan+UBSan temiz | 3.9 | 7 (üst başlık, şekil) | h10-kaput |
| `H10_K12_const_ihlali.c` | Kavram programı | Kavram programı: const dizi parametresi | kasıtlı derleme hatası | 3.3 (metin), 3.6 (metin) | 15 (not), 37 (not) | h10-fonksiyon |
| `H10_K13_ters_cevir_test.c` | Kavram programı | Kavram programı: ters çevirmenin | sıfır uyarı; ASan+UBSan temiz | 4.4 (metin) | — | h10-merdiven |
| `H10_K14_obs_ceviri_birimi.c` | Kavram programı | kavram: Mini-OBS v0.10 arayüzü tek çeviri biriminde | sıfır uyarı; ASan+UBSan temiz | — | — | h10-miniobs |
| `H10_K15_fazla_ilk_deger.c` | Kavram programı | kavram: boyuttan fazla ilk değer | derlenir; kasıtlı uyarı | 3.2 (metin) | — | h10-bildirim |
| `alistirmalar/H10_A01_cikti_tahmini.c` | Alıştırma 10.1 | Alıştırma 10.1 (★): çıktı tahmini | sıfır uyarı; ASan+UBSan temiz | 8 (alıştırma) | — | h10-alistirmalar |
| `alistirmalar/H10_A02_cikti_tahmini_kaydirma.c` | Alıştırma 10.2 | Alıştırma 10.2 (★★): çıktı tahmini | sıfır uyarı; ASan+UBSan temiz | 8 (alıştırma) | — | h10-alistirmalar |
| `alistirmalar/H10_A03_hata_bul_ortalama.c` | Alıştırma 10.3 | Alıştırma 10.3 (★★): hata bul | sıfır uyarı; kasıtlı mantık hatası | 8 (alıştırma) | — | h10-alistirmalar |
| `alistirmalar/H10_A04_hata_bul_ekleme.c` | Alıştırma 10.4 | Alıştırma 10.4 (★★): hata bul | sıfır uyarı; kasıtlı mantık hatası | 8 (alıştırma) | — | h10-alistirmalar |
| `alistirmalar/H10_A05_parsons_sirali_mi.c` | Alıştırma 10.5 | Alıştırma 10.5 (★★): Parsons problemi | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h10-alistirmalar |
| `alistirmalar/H10_A06_kod_tamamla_frekans.c` | Alıştırma 10.6 | Alıştırma 10.6 (★★): kod tamamlama | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h10-alistirmalar |
| `hata_avcisi/H10_HA1_bir_fark.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1: a[n] erişimi (bir-fark hatası) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | 46 (not) | h10-hata-avcisi |
| `hata_avcisi/H10_HA1_bir_fark_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 (düzeltilmiş) | sıfır uyarı; ASan+UBSan temiz | — | — | h10-hata-avcisi |
| `hata_avcisi/H10_HA2_ilk_deger_yok.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2: ilk değeri olmayan dizi | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | 46 (not) | h10-hata-avcisi |
| `hata_avcisi/H10_HA2_ilk_deger_yok_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 (düzeltilmiş) | sıfır uyarı; ASan+UBSan temiz | — | — | h10-hata-avcisi |
| `hata_avcisi/H10_HA3_sizeof_parametre.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3: fonksiyon içinde sizeof | derlenir; kasıtlı uyarı | 5 (metin) | 47 (not) | h10-hata-avcisi |
| `hata_avcisi/H10_HA3_sizeof_parametre_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 (düzeltilmiş) | sıfır uyarı; ASan+UBSan temiz | — | — | h10-hata-avcisi |
| `hata_avcisi/H10_HA4_dizi_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4 (düzeltilmiş) | sıfır uyarı; ASan+UBSan temiz | 5 (metin) | — | h10-hata-avcisi |
| `hata_avcisi/H10_HA4_dizi_esitlik.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4b: dizi == ile karşılaştırılmaz | derlenir; kasıtlı uyarı | 5 (metin) | 47 (not) | h10-hata-avcisi |
| `hata_avcisi/H10_HA4_dizi_kopyalama.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4a: dizi = ile kopyalanmaz | kasıtlı derleme hatası | 5 (metin) | 47 (not) | h10-hata-avcisi |
| `hata_avcisi/H10_HA5_scanf_adres.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5: scanf'te & unutulması | derlenir; kasıtlı uyarı | 5 (metin) | 47 (not) | h10-hata-avcisi |
| `hata_avcisi/H10_HA5_scanf_adres_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 (düzeltilmiş) | sıfır uyarı; ASan+UBSan temiz | — | — | h10-hata-avcisi |
| `proje/main.c` | Mini-OBS v0.10 · main.c | Mini-OBS v0.10 (AP-1 Hafta 10): menü döngüsü + paralel diziler | sıfır uyarı (Makefile, -lm) | 7 (metin) | 21 (şekil), 49 (not, şekil) | h10-miniobs |
| `proje/obs.c` | Mini-OBS v0.10 · obs.c | Mini-OBS v0.10 (AP-1 Hafta 10): modülün GERÇEKLEMESİ | sıfır uyarı (Makefile, -lm) | 7 (metin) | 49 (not, şekil) | h10-miniobs |
| `proje/obs.h` | Mini-OBS v0.10 · başlık | Mini-OBS v0.10 (AP-1 Hafta 10): modülün ARAYÜZÜ | başlık (içeren .c ile derlenir) | — | 49 (şekil) | h10-miniobs |
| `proje/test_obs.c` | Mini-OBS v0.10 · test_obs.c | Mini-OBS v0.10 (AP-1 Hafta 10): birim testleri | sıfır uyarı (Makefile, -lm) | — | 49 (şekil) | — |
| `quiz/H10_Q01_static_sayac.c` | Geri çağırma S1 | Geçen haftadan S1 (H9: static yerel) | sıfır uyarı; ASan+UBSan temiz | 2 (metin) | 3 | h10-gecen-hafta |
| `quiz/H10_Q02_cagri_yigini.c` | Geri çağırma S2 | Geçen haftadan S2 (H9: çağrı yığını) | sıfır uyarı; ASan+UBSan temiz | 2 (metin) | 3 | h10-gecen-hafta |
| `quiz/H10_Q03_basamak_toplami.c` | Geri çağırma S3 | Geçen haftadan S3 (H9: özyineleme) | sıfır uyarı; ASan+UBSan temiz | 2 (metin) | — | h10-gecen-hafta |
| `quiz/H10_Q11_kismi_ilk_deger.c` | Quiz S1 | Quiz S1 (kısmi ilk değer) | sıfır uyarı; ASan+UBSan temiz | — | 13 | h10-quiz |
| `quiz/H10_Q13_sizeof_fonksiyon.c` | Quiz S3 | Quiz S3 (fonksiyonda sizeof) | derlenir; kasıtlı uyarı | — | — | h10-quiz |
| `quiz/H10_Q14_son_eslesme.c` | Quiz S4 | Quiz S4 (tarama, erken çıkış yok) | sıfır uyarı; ASan+UBSan temiz | — | — | h10-quiz |
| `quiz/H10_Q15_iki_kez_ters.c` | Quiz S5 | Quiz S5 (ters çevirme koşulu) | sıfır uyarı; ASan+UBSan temiz | — | 32 | h10-quiz |
| `quiz/H10_Q16_frekans.c` | Quiz S6 | Quiz S6 (frekans dizisi) | sıfır uyarı; ASan+UBSan temiz | — | — | h10-quiz |
| `quiz/H10_Q17_kaydirma.c` | Quiz S7 | Quiz S7 (kaydırma yönü) | sıfır uyarı; ASan+UBSan temiz | — | — | h10-quiz |
| `quiz/H10_Q18_dizi_atama.c` | Quiz S8 | Quiz S8 (dizi ataması) | kasıtlı derleme hatası | — | — | h10-quiz |

**Diğer dosyalar**

- `proje/Makefile` ve `proje/testler/` — Mini-OBS v0.10 (`make`, `make test`, `make clean`); `proje/` klasörü `91_Proje_MiniOBS/v0.10/`’un kopyasıdır (asıl yer orası; belge `mini_obs_v0_10.md` ve gerçek oturum `mini_obs_v0_10_ciktilar.txt` orada).
- `ciktilar/H10_13_sinir_disi_cerceve_asm.txt` — `main`’in yığın çerçevesi (`gcc -S -O0 -masm=intel`, değişkenlerin rbp’ye göre konumları); `ciktilar/H10_13_sinir_disi_tum_indisler.txt` — −6…12 arasındaki **her** indise 77 yazan gerçek çalıştırmalar (web’deki “Sınırı aşarsam ne olur?” simülasyonunun verisi); `…_asan_tam.txt` — tam ASan raporları.
- `AP1_H10_kodlar.zip` — bu klasörün (`.c`, `.h`, `ciktilar/`, `proje/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H10_kodlar/` klasörü oluşur.

Materyalde geçmeyen dosya yoktur.

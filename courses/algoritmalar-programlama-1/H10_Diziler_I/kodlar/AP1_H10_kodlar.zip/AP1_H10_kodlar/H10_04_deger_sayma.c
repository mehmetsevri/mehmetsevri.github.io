/* H10_04_deger_sayma.c — Hafta 10 · Örnek 4 (★): bir değer kaç kez geçiyor?
 * Amaç   : Sayma deseni: dizinin TAMAMI dolaşılır, koşulu sağlayan her
 *          eleman için sayaç bir artar (erken çıkış yok).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_04_deger_sayma.c -o deger_sayma
 * Örnek  : girdi "6" -> 6 değeri 12 atışta 5 kez geçti.
 */
#include <stdio.h>

int main(void)
{
    int atislar[] = {3, 6, 1, 6, 2, 6, 4, 5, 6, 1, 3, 6};   /* 12 zar atışı */
    int n = (int)(sizeof(atislar) / sizeof(atislar[0]));

    int aranan;
    printf("Hangi değer sayılsın (1-6)? ");
    if (scanf("%d", &aranan) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int sayac = 0;
    for (int i = 0; i < n; i++) {
        if (atislar[i] == aranan) {     /* koşul: eşit mi? */
            sayac++;
        }
    }
    printf("%d değeri %d atışta %d kez geçti.\n", aranan, n, sayac);
    return 0;
}

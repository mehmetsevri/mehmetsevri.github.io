/* H10_K06_dizi_adresi.c — Hafta 10 · Kavram programı: fonksiyona dizinin
 *          ADRESİ gider
 * Amaç   : H8'de takas(a, b) çalışmamıştı (H08_10_takas_denemesi.c):
 *          fonksiyona değerlerin kopyaları gidiyordu. Dizide ise kopyalanan
 *          şey dizinin İLK ELEMANININ ADRESİDİR: fonksiyon çağıranın
 *          dizisinin kendisiyle çalışır ve elemanlarını değiştirebilir.
 *          Aynı adres main'de ve fonksiyonda görünür. (Tam açıklama H12.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K06_dizi_adresi.c -o dizi_adresi
 * Örnek  : -> sonra: a = {9, 7, 0}, s = 7
 */
#include <stdio.h>

void eleman_takas(int dizi[], int i, int j);
void sifirla(int x);

int main(void)
{
    int a[3] = {7, 9, 4};
    int s = 7;
    printf("main  : &a[0] = %p   &s = %p\n", (void *)&a[0], (void *)&s);
    eleman_takas(a, 0, 1);              /* a[0] ile a[1] yer değiştirir */
    a[2] = 0;
    sifirla(s);                         /* s'nin KOPYASI gider */
    printf("sonra: a = {%d, %d, %d}, s = %d\n", a[0], a[1], a[2], s);
    return 0;
}

/* dizi[i] ile dizi[j]'yi değiş tokuş eder: ÇAĞIRANIN dizisi değişir. */
void eleman_takas(int dizi[], int i, int j)
{
    printf("takas: dizi  = %p   (main'deki &a[0] ile aynı)\n", (void *)dizi);
    int gecici = dizi[i];
    dizi[i] = dizi[j];
    dizi[j] = gecici;
}

/* Yalnızca kendi kopyasını sıfırlar: çağıranın değişkeni değişmez. */
void sifirla(int x)
{
    printf("sifirla: &x  = %p   (main'deki &s'den farklı)\n", (void *)&x);
    x = 0;
}

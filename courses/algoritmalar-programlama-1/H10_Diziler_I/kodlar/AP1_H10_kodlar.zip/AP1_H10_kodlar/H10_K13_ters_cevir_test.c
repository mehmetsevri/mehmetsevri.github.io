/* H10_K13_ters_cevir_test.c — Hafta 10 · Kavram programı: ters çevirmenin
 *          sınır testleri
 * Amaç   : Örnek 7'deki iki uç algoritmasını fonksiyona taşıyıp farklı
 *          boyutlarda dener: n = 0 (boş), 1, 2, tek ve çift eleman sayısı.
 *          Her durumda kaç takas yapıldığı da yazılır (n / 2).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K13_ters_cevir_test.c -o ters_cevir_test
 * Örnek  : -> n = 6: [1 2 3 4 5 6] -> [6 5 4 3 2 1]  (3 takas)
 */
#include <stdio.h>

/* a[0..n-1]'i yerinde ters çevirir; yapılan takas sayısını döndürür. */
int ters_cevir(int a[], int n)
{
    int takas = 0;
    int i = 0;
    int j = n - 1;
    while (i < j) {
        int gecici = a[i];
        a[i] = a[j];
        a[j] = gecici;
        i++;
        j--;
        takas++;
    }
    return takas;
}

int main(void)
{
    int boyutlar[] = {0, 1, 2, 5, 6};
    for (int t = 0; t < 5; t++) {
        int n = boyutlar[t];
        int a[6];
        for (int k = 0; k < n; k++) {
            a[k] = k + 1;               /* 1, 2, ..., n */
        }
        printf("n = %d: [", n);
        for (int k = 0; k < n; k++) {
            printf(k ? " %d" : "%d", a[k]);
        }
        int takas = ters_cevir(a, n);
        printf("] -> [");
        for (int k = 0; k < n; k++) {
            printf(k ? " %d" : "%d", a[k]);
        }
        printf("]  (%d takas)\n", takas);
    }
    return 0;
}

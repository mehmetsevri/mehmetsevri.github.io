/* H10_09_zar_histogram.c — Hafta 10 · Örnek 9 (★★): 6000 zar atışı ve histogram
 * Amaç   : Frekans dizisi: zarın DEĞERİ, sayacın İNDİSİ olur
 *          (frekans[zar]++). H8'deki altı ayrı sayaç ve switch
 *          (H08_11_zar_frekans.c) tek satıra iner. Her * = 20 atış.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_09_zar_histogram.c -o zar_histogram
 *          Kayıtlı çıktı yeniden üretilebilir olsun diye sabit tohumla:
 *          gcc ... -DSABIT_TOHUM=2026 H10_09_zar_histogram.c -o zar_histogram
 * Örnek  : -> Toplam: 6000 atış
 */
#include <stdio.h>
#include <stdlib.h>                     /* rand, srand */
#include <time.h>                       /* time */

#define ATIS 6000
#define YILDIZ_BASINA 20                /* bir * kaç atış */

int main(void)
{
#ifdef SABIT_TOHUM
    srand(SABIT_TOHUM);                 /* aynı tohum -> aynı atışlar */
#else
    srand((unsigned)time(NULL));        /* her çalıştırmada farklı */
#endif
    int frekans[7] = {0};               /* [1]..[6] kullanılır, [0] boş */

    for (int atis = 0; atis < ATIS; atis++) {
        int zar = rand() % 6 + 1;       /* 1..6 */
        frekans[zar]++;                 /* DEĞER = İNDİS */
    }

    printf("Yüz  Adet  Histogram (* = %d atış)\n", YILDIZ_BASINA);
    int toplam = 0;
    for (int yuz = 1; yuz <= 6; yuz++) {
        printf("%3d %5d  ", yuz, frekans[yuz]);
        for (int k = 0; k < frekans[yuz] / YILDIZ_BASINA; k++) {
            putchar('*');
        }
        putchar('\n');
        toplam += frekans[yuz];
    }
    printf("Toplam: %d atış (beklenen her yüz için %d)\n", toplam, ATIS / 6);
    return 0;
}

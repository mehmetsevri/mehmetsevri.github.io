/* H10_10_harf_dagilimi.c — Hafta 10 · Örnek 10 (★★): harf notu dağılımı
 * Amaç   : Frekans + karar: her öğrencinin harf notunun İNDİSİ (AA=0 ...
 *          FF=8) bulunur, sayac[indis]++ yapılır. Kurallar Mini-OBS ile
 *          aynı (RTEÜ tablosu): %40 vize + %60 final, (int)(ort + 0.5);
 *          final < 50 -> FF (baraj). Harf sınırları da bir dizidedir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_10_harf_dagilimi.c -o harf_dagilimi
 * Örnek  : -> Toplam: 15 öğrenci
 */
#include <stdio.h>

#define HARF 9

int main(void)
{
    /* paralel diziler: vize[i] ile final[i] aynı öğrenciye aittir */
    double vize[]  = {70, 45, 90, 55, 62, 88, 30, 75,
                      66, 95, 50, 80, 58, 78, 40};
    double final[] = {85, 48, 95, 60, 70, 92, 55, 68,
                      64, 98, 52, 45, 66, 84, 62};
    int n = (int)(sizeof(vize) / sizeof(vize[0]));

    int alt_sinir[HARF] = {90, 81, 73, 66, 60, 50, 40, 30, 0};
    char ilk[HARF]    = {'A', 'B', 'B', 'C', 'C', 'D', 'D', 'F', 'F'};
    char ikinci[HARF] = {'A', 'A', 'B', 'B', 'C', 'C', 'D', 'D', 'F'};
    int sayac[HARF] = {0};

    for (int i = 0; i < n; i++) {
        int y = (int)(0.40 * vize[i] + 0.60 * final[i] + 0.5);
        int k = HARF - 1;               /* final barajı: FF */
        if (final[i] >= 50) {
            k = 0;
            while (y < alt_sinir[k]) {  /* ilk uygun sınırı bul */
                k++;
            }
        }
        sayac[k]++;                     /* harf indisinin sayacı */
    }

    for (int k = 0; k < HARF; k++) {
        printf("%c%c | ", ilk[k], ikinci[k]);
        for (int j = 0; j < sayac[k]; j++) {
            putchar('*');
        }
        printf(" %d\n", sayac[k]);
    }
    printf("Toplam: %d öğrenci\n", n);
    return 0;
}

/* H10_13_sinir_disi.c — Hafta 10 · Örnek 13 (★★★): sınır dışı yazma deneyi
 * BU DOSYA KASITLI HATA İÇERİR: a[k] = deger satırında sınır denetimi yok.
 * Amaç   : İndis kullanıcıdan gelir ve DENETLENMEZ. 0 <= k < N değilse
 *          yazma TANIMSIZ DAVRANIŞTIR: ne olacağını standart söylemez.
 *          Bu derleyicide/ayarda gözlenen: bazen hiçbir şey görünmez,
 *          bazen komşu değişken bozulur, bazen program durdurulur.
 *          Bellek yerleşimi derleyiciye ve seçeneklere bağlıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_13_sinir_disi.c -o sinir_disi        (uyarı YOK!)
 *          gcc -std=c17 -g -fsanitize=address \
 *              H10_13_sinir_disi.c -o sinir_disi_asan   (yakalar)
 * Örnek  : girdi "2 77" -> a = {10, 20, 77, 40}  once = 111  sonra = 222
 */
#include <stdio.h>

#define N 4

int main(void)
{
    int once = 111;                     /* dizinin komşuları */
    int a[N] = {10, 20, 30, 40};
    int sonra = 222;

    printf("&once  = %p\n", (void *)&once);
    printf("&sonra = %p\n", (void *)&sonra);
    printf("&a[0]  = %p\n", (void *)&a[0]);
    printf("&a[%d]  = %p (dizinin hemen sonrası)\n", N, (void *)&a[N]);

    int k, deger;
    printf("İndis ve değer: ");
    if (scanf("%d %d", &k, &deger) != 2) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    a[k] = deger;                       /* SINIR DENETİMİ YOK */

    printf("a = {%d, %d, %d, %d}  once = %d  sonra = %d\n",
           a[0], a[1], a[2], a[3], once, sonra);
    return 0;
}

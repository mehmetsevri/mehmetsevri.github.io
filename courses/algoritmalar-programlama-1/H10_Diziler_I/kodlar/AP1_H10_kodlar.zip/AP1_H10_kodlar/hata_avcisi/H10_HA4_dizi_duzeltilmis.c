/* H10_HA4_dizi_duzeltilmis.c — Hafta 10 · Hata Avcısı 4 (düzeltilmiş)
 * Düzeltme: kopyalama ve karşılaştırma ELEMAN ELEMAN, döngüyle.
 *          (Kütüphane karşılıkları memcpy/memcmp: H10_K09.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA4_dizi_duzeltilmis.c -o ha4d
 * Örnek  : -> a ve b eşit
 */
#include <stdio.h>
#include <stdbool.h>

#define N 4

int main(void)
{
    int notlar[N] = {72, 85, 64, 90};
    int yedek[N];
    for (int i = 0; i < N; i++) {       /* kopyalama */
        yedek[i] = notlar[i];
    }
    printf("yedek[0] = %d\n", yedek[0]);

    int a[3] = {1, 2, 3};
    int b[3] = {1, 2, 3};
    bool esit = true;
    for (int i = 0; i < 3; i++) {       /* karşılaştırma */
        if (a[i] != b[i]) {
            esit = false;
            break;
        }
    }
    printf("a ve b %s\n", esit ? "eşit" : "farklı");
    return 0;
}

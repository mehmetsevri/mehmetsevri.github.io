/* H10_HA4_dizi_kopyalama.c — Hafta 10 · Hata Avcısı 4a: dizi = ile kopyalanmaz
 * BU DOSYA KASITLI HATA İÇERİR: yedek = notlar; derlenmez. Dizinin adı
 *          değiştirilebilir bir değer (lvalue) değildir: C'de dizi
 *          türündeki bir ifadeye atama yapılamaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA4_dizi_kopyalama.c -o ha4a      (derleme hatası)
 */
#include <stdio.h>

#define N 4

int main(void)
{
    int notlar[N] = {72, 85, 64, 90};
    int yedek[N];
    yedek = notlar;                     /* HATA: diziye atama yok */
    printf("yedek[0] = %d\n", yedek[0]);
    return 0;
}

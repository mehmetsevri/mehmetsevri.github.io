/* H10_HA2_ilk_deger_yok_duzeltilmis.c — Hafta 10 · Hata Avcısı 2 (düzeltilmiş)
 * Düzeltme: int frekans[7] = {0}; (kısmi ilk değer listesi: kalanlar 0).
 *          Sayaç, toplayıcı ve frekans dizilerine her zaman ilk değer verin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA2_ilk_deger_yok_duzeltilmis.c -o ha2d
 * Örnek  : -> yüz 6: 3 kez
 */
#include <stdio.h>

void onceki_is(void);
void zar_say(void);

int main(void)
{
    onceki_is();
    zar_say();
    return 0;
}

/* Yığında "eski değerler" bırakan bir iş. */
void onceki_is(void)
{
    int gecici[8];
    for (int i = 0; i < 8; i++) {
        gecici[i] = 1000 + i;
    }
    printf("önceki iş bitti (son değer %d)\n", gecici[7]);
}

/* 6 atışın frekansı: 3, 6, 1, 6, 2, 6 */
void zar_say(void)
{
    int frekans[7] = {0};               /* DOĞRU: hepsi 0'dan başlar */
    int atislar[] = {3, 6, 1, 6, 2, 6};
    for (int i = 0; i < 6; i++) {
        frekans[atislar[i]]++;
    }
    for (int yuz = 1; yuz <= 6; yuz++) {
        printf("yüz %d: %d kez\n", yuz, frekans[yuz]);
    }
}

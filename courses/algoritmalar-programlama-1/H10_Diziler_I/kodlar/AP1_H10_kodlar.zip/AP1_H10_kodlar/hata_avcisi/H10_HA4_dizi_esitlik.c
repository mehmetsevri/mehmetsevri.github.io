/* H10_HA4_dizi_esitlik.c — Hafta 10 · Hata Avcısı 4b: dizi == ile karşılaştırılmaz
 * BU DOSYA KASITLI HATA İÇERİR: a == b içerikleri değil ADRESLERİ
 *          karşılaştırır (iki dizinin adı ilk elemanlarının adresine
 *          dönüşür). İki ayrı dizinin adresi hiçbir zaman eşit olmadığından
 *          içerikler aynı olsa da sonuç "farklı" çıkar. GCC 13 -Wall ile
 *          -Warray-compare uyarısı verir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA4_dizi_esitlik.c -o ha4b
 */
#include <stdio.h>

int main(void)
{
    int a[3] = {1, 2, 3};
    int b[3] = {1, 2, 3};
    if (a == b) {                       /* HATA: adres karşılaştırması */
        printf("a ve b eşit\n");
    } else {
        printf("a ve b farklı (içerikleri aynı olduğu hâlde!)\n");
    }
    return 0;
}

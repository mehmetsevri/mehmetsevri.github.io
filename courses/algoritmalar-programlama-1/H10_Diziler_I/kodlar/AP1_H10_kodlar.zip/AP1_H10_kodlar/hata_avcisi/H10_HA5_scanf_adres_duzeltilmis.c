/* H10_HA5_scanf_adres_duzeltilmis.c — Hafta 10 · Hata Avcısı 5 (düzeltilmiş)
 * Düzeltme: scanf("%d", &a[i]) — i. elemanın ADRESİ. Ayrıca scanf'in
 *          dönüş değeri denetlenir (H6'dan beri kural).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA5_scanf_adres_duzeltilmis.c -o ha5d
 * Örnek  : girdi "5 6 7" -> Toplam = 18
 */
#include <stdio.h>

#define N 3

int main(void)
{
    int a[N] = {0};
    printf("%d sayı: ", N);
    for (int i = 0; i < N; i++) {
        if (scanf("%d", &a[i]) != 1) {  /* DOĞRU: adres + denetim */
            printf("Geçersiz girdi.\n");
            return 1;
        }
    }
    printf("Toplam = %d\n", a[0] + a[1] + a[2]);
    return 0;
}

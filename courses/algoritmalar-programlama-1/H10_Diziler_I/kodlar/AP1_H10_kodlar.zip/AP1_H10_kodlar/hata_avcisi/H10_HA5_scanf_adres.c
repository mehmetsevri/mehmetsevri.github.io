/* H10_HA5_scanf_adres.c — Hafta 10 · Hata Avcısı 5: scanf'te & unutulması
 * BU DOSYA KASITLI HATA İÇERİR: scanf("%d", a[i]) elemanın ADRESİNİ
 *          değil DEĞERİNİ (0) verir; scanf o değeri adres sanıp oraya
 *          yazmaya çalışır. GCC -Wall ile -Wformat uyarısı verir;
 *          çalıştırınca bu sistemde program çöktü (Segmentation fault).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA5_scanf_adres.c -o ha5
 */
#include <stdio.h>

#define N 3

int main(void)
{
    int a[N] = {0};
    printf("%d sayı: ", N);
    for (int i = 0; i < N; i++) {
        scanf("%d", a[i]);              /* HATA: &a[i] olmalı */
    }
    printf("Toplam = %d\n", a[0] + a[1] + a[2]);
    return 0;
}

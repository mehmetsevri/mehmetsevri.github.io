/* H10_HA1_bir_fark.c — Hafta 10 · Hata Avcısı 1: a[n] erişimi (bir-fark hatası)
 * BU DOSYA KASITLI HATA İÇERİR: döngü koşulu i <= N; son turda notlar[N]
 *          okunur. N elemanlı dizinin son indisi N - 1'dir. Sınır dışı
 *          okuma TANIMSIZ DAVRANIŞTIR: toplam "çöp" bir değer içerebilir.
 *          -O0 ile derleyici UYARMAZ; -O2 ile bazı durumları yakalar;
 *          AddressSanitizer her çalıştırmada yakalar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA1_bir_fark.c -o ha1
 */
#include <stdio.h>

#define N 5

int main(void)
{
    int notlar[N] = {72, 85, 64, 90, 58};
    int toplam = 0;
    for (int i = 0; i <= N; i++) {      /* HATA: i = N için notlar[N] yok */
        toplam += notlar[i];
    }
    printf("Toplam = %d (beklenen 369)\n", toplam);
    return 0;
}

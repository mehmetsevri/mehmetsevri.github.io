/* H10_HA3_sizeof_parametre.c — Hafta 10 · Hata Avcısı 3: fonksiyon içinde sizeof
 * BU DOSYA KASITLI HATA İÇERİR: ortalama() eleman sayısını sizeof ile
 *          bulmaya çalışıyor. Parametre olarak yazılan "int dizi[]" aslında
 *          bir İŞARETÇİDİR (int *): sizeof(dizi) dizinin değil işaretçinin
 *          boyutudur (x86-64 Linux'ta 8 bayt). 8 / 4 = 2 eleman sanılır.
 *          GCC bunu -Wsizeof-array-argument ile uyarır (-Wall içinde).
 *          Ayrıntılı açıklama H12'de (işaretçiler).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA3_sizeof_parametre.c -o ha3
 */
#include <stdio.h>

double ortalama(int dizi[]);

int main(void)
{
    int notlar[] = {72, 85, 64, 90, 58, 77};
    printf("main     : sizeof(notlar) = %zu bayt -> %zu eleman\n",
           sizeof(notlar), sizeof(notlar) / sizeof(notlar[0]));
    printf("Ortalama = %.2f (beklenen 74.33)\n", ortalama(notlar));
    return 0;
}

double ortalama(int dizi[])
{
    int n = (int)(sizeof(dizi) / sizeof(dizi[0]));   /* HATA */
    printf("ortalama : sizeof(dizi) = %zu bayt -> n = %d\n", sizeof(dizi), n);
    int toplam = 0;
    for (int i = 0; i < n; i++) {
        toplam += dizi[i];
    }
    return (double)toplam / n;
}

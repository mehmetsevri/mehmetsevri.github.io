/* H10_HA1_bir_fark_duzeltilmis.c — Hafta 10 · Hata Avcısı 1 (düzeltilmiş)
 * Düzeltme: koşul i < N. Kural: N elemanlı dizide geçerli indisler
 *          0 .. N-1; "i = 0; i < N" kalıbı tam N tur döner.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA1_bir_fark_duzeltilmis.c -o ha1d
 * Örnek  : -> Toplam = 369 (beklenen 369)
 */
#include <stdio.h>

#define N 5

int main(void)
{
    int notlar[N] = {72, 85, 64, 90, 58};
    int toplam = 0;
    for (int i = 0; i < N; i++) {       /* DOĞRU: i = 0 .. N-1 */
        toplam += notlar[i];
    }
    printf("Toplam = %d (beklenen 369)\n", toplam);
    return 0;
}

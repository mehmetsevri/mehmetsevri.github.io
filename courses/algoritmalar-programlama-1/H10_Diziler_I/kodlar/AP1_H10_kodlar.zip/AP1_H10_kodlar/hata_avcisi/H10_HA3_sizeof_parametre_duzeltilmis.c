/* H10_HA3_sizeof_parametre_duzeltilmis.c — Hafta 10 · Hata Avcısı 3 (düzeltilmiş)
 * Düzeltme: eleman sayısı dizinin BİLDİRİLDİĞİ yerde (main) sizeof ile
 *          hesaplanır ve fonksiyona AYRI bir parametre olarak verilir.
 *          Diziyi değiştirmeyen fonksiyonda parametre const'tur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA3_sizeof_parametre_duzeltilmis.c -o ha3d
 * Örnek  : -> Ortalama = 74.33 (beklenen 74.33)
 */
#include <stdio.h>

double ortalama(const int dizi[], int n);

int main(void)
{
    int notlar[] = {72, 85, 64, 90, 58, 77};
    int n = (int)(sizeof(notlar) / sizeof(notlar[0]));   /* burada doğru */
    printf("Ortalama = %.2f (beklenen 74.33)\n", ortalama(notlar, n));
    return 0;
}

/* Ön koşul: n >= 1.  Son koşul: dizi[0..n-1] ortalaması. */
double ortalama(const int dizi[], int n)
{
    int toplam = 0;
    for (int i = 0; i < n; i++) {
        toplam += dizi[i];
    }
    return (double)toplam / n;
}

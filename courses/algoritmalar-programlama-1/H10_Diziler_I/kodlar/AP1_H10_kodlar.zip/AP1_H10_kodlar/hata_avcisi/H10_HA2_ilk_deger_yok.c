/* H10_HA2_ilk_deger_yok.c — Hafta 10 · Hata Avcısı 2: ilk değeri olmayan dizi
 * BU DOSYA KASITLI HATA İÇERİR: frekans dizisinin ilk değeri yok.
 *          Fonksiyon içindeki (otomatik) dizi sıfırla BAŞLAMAZ: elemanlar
 *          belirsizdir (indeterminate); yığında o adreste ne kaldıysa o
 *          görünebilir. Burada önce çağrılan onceki_is() yığına 1000,
 *          1001, ... bırakır; zar_say()'ın çerçevesi aynı bölgeye
 *          kurulursa sayaçlar o değerlerden başlar (gözlenen sonuç
 *          derleyiciye ve seçeneklere bağlıdır).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_HA2_ilk_deger_yok.c -o ha2
 */
#include <stdio.h>

void onceki_is(void);
void zar_say(void);

int main(void)
{
    onceki_is();
    zar_say();
    return 0;
}

/* Yığında "eski değerler" bırakan bir iş. */
void onceki_is(void)
{
    int gecici[8];
    for (int i = 0; i < 8; i++) {
        gecici[i] = 1000 + i;
    }
    printf("önceki iş bitti (son değer %d)\n", gecici[7]);
}

/* 6 atışın frekansı: 3, 6, 1, 6, 2, 6 */
void zar_say(void)
{
    int frekans[7];                     /* HATA: = {0} unutuldu */
    int atislar[] = {3, 6, 1, 6, 2, 6};
    for (int i = 0; i < 6; i++) {
        frekans[atislar[i]]++;
    }
    for (int yuz = 1; yuz <= 6; yuz++) {
        printf("yüz %d: %d kez\n", yuz, frekans[yuz]);
    }
}

/* H10_K10_paralel_diziler.c — Hafta 10 · Kavram programı: paralel diziler
 * Amaç   : Bir öğrencinin bilgileri AYNI İNDİSTEKİ elemanlardadır:
 *          no[i], vize[i], final[i]. En yüksek finalin indisi bulunur ve
 *          o indisle diğer diziler okunur. Sınırlılık: bir kaydı silmek,
 *          taşımak ya da sıralamak ÜÇ diziye AYNI işlemi uygulamayı
 *          gerektirir; biri unutulursa kayıtlar KAYAR (aşağıdaki deney).
 *          Çözüm H14'te: struct Ogrenci.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K10_paralel_diziler.c -o paralel_diziler
 * Örnek  : -> En yüksek final: 95 (no 1047, vize 90)
 */
#include <stdio.h>

#define N 4

int main(void)
{
    int no[N]    = {1045, 1046, 1047, 1048};
    int vize[N]  = {70, 45, 90, 55};
    int final[N] = {85, 48, 95, 60};

    int enb = 0;
    for (int i = 1; i < N; i++) {
        if (final[i] > final[enb]) {
            enb = i;
        }
    }
    printf("En yüksek final: %d (no %d, vize %d)\n", final[enb], no[enb],
           vize[enb]);

    /* Deney: 1046'yı yalnızca no[] dizisinden silelim (sola kaydırma) */
    for (int i = 1; i < N - 1; i++) {
        no[i] = no[i + 1];
    }
    printf("Silmeden sonra (vize[] ve final[] unutuldu):\n");
    for (int i = 0; i < N - 1; i++) {
        printf("  no %d  vize %d  final %d\n", no[i], vize[i], final[i]);
    }
    return 0;
}

/* H10_K04_sizeof.c — Hafta 10 · Kavram programı: sizeof ile eleman sayısı
 * Amaç   : sizeof(dizi) dizinin TOPLAM bayt sayısı, sizeof(dizi[0]) bir
 *          elemanın bayt sayısıdır; bölümleri eleman sayısını verir. Bu
 *          yalnızca dizinin BİLDİRİLDİĞİ yerde çalışır (fonksiyon
 *          parametresinde değil: Hata Avcısı 3). Hesap derleme zamanında
 *          yapılır. H9'daki makro tekniğiyle tek satıra indirilebilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K04_sizeof.c -o sizeof_ornek
 * Örnek  : -> double b[10]: sizeof(b) = 80, sizeof(b[0]) = 8, eleman = 10
 */
#include <stdio.h>

#define ELEMAN_SAYISI(d) (sizeof(d) / sizeof((d)[0]))   /* parantezler! */

int main(void)
{
    int    a[10] = {0};
    double b[10] = {0};
    char   c[10] = {0};

    printf("int    a[10]: sizeof(a) = %zu, sizeof(a[0]) = %zu, eleman = %zu\n",
           sizeof(a), sizeof(a[0]), sizeof(a) / sizeof(a[0]));
    printf("double b[10]: sizeof(b) = %zu, sizeof(b[0]) = %zu, eleman = %zu\n",
           sizeof(b), sizeof(b[0]), sizeof(b) / sizeof(b[0]));
    printf("char   c[10]: sizeof(c) = %zu, sizeof(c[0]) = %zu, eleman = %zu\n",
           sizeof(c), sizeof(c[0]), ELEMAN_SAYISI(c));
    return 0;
}

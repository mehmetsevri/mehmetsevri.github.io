/* H10_K12_const_ihlali.c — Hafta 10 · Kavram programı: const dizi parametresi
 * BU DOSYA KASITLI HATA İÇERİR: derlenmez.
 * Amaç   : const int a[] "bu fonksiyon diziyi yalnızca OKUR" sözüdür.
 *          Fonksiyon içinde bir elemana yazılırsa derleyici HATA verir:
 *          yanlışlıkla bozma derleme zamanında yakalanır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K12_const_ihlali.c -o const_ihlali    (derleme hatası)
 */
#include <stdio.h>

int dizi_toplam(const int a[], int n)
{
    int toplam = 0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
        a[i] = 0;                       /* HATA: const dizi değiştirilemez */
    }
    return toplam;
}

int main(void)
{
    int sayilar[3] = {4, 5, 6};
    printf("%d\n", dizi_toplam(sayilar, 3));
    return 0;
}

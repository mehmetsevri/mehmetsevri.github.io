/* H10_14_eratosthenes.c — Hafta 10 · Örnek 14 (★★★, meydan okuma):
 *          Eratosthenes Kalburu
 * Amaç   : bool dizisiyle işaretleme: asal[i] "i asal mı?" sorusunun yanıtı.
 *          Hepsi doğru başlar; her asal p için p*p, p*p+p, ... katları
 *          yanlışa çevrilir (daha küçük katları zaten işaretlendi).
 *          p <= ust / p olduğu sürece (p*p taşmasın). Bölme YOK: yalnızca
 *          toplama ve dizi yazma. İşaretleme sayısı sayılır (H7'deki
 *          √n yöntemindeki bölme sayısıyla karşılaştırmak için).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_14_eratosthenes.c -o eratosthenes
 * Örnek  : girdi "1000" -> 2..1000 arasında 168 asal
 */
#include <stdio.h>
#include <stdbool.h>

#define AZAMI 100000

int main(void)
{
    bool asal[AZAMI + 1];               /* asal[0] .. asal[AZAMI] */
    int ust;

    printf("Üst sınır (2-%d): ", AZAMI);
    if (scanf("%d", &ust) != 1 || ust < 2 || ust > AZAMI) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    asal[0] = false;
    asal[1] = false;
    for (int i = 2; i <= ust; i++) {
        asal[i] = true;                 /* başta herkes aday */
    }

    long isaretleme = 0;
    for (int p = 2; p <= ust / p; p++) {        /* p * p <= ust */
        if (asal[p]) {
            for (int kat = p * p; kat <= ust; kat += p) {
                asal[kat] = false;      /* p'nin katı: asal değil */
                isaretleme++;
            }
        }
    }

    int adet = 0;
    for (int i = 2; i <= ust; i++) {
        if (asal[i]) {
            adet++;
            if (i <= 100) {             /* yalnızca 100'e kadarını yaz */
                printf("%4d%s", i, adet % 10 == 0 ? "\n" : "");
            }
        }
    }
    printf("\n2..%d arasında %d asal (%ld işaretleme)\n", ust, adet,
           isaretleme);
    return 0;
}

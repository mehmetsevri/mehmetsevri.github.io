/* H10_K01_ayri_degiskenler.c — Hafta 10 · Kavram programı: neden dizi?
 * Amaç   : Aynı iş iki kez: beş AYRI değişkenle (her öğrenci için ayrı ad,
 *          ayrı satır, ayrı if) ve tek bir DİZİYLE (tek ad, bir döngü).
 *          Öğrenci sayısı 100 olsa ilk yöntemde 100 değişken ve 100 if
 *          gerekirdi; ikincisinde yalnızca N değişir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K01_ayri_degiskenler.c -o ayri_degiskenler
 * Örnek  : -> Diziyle          : ortalama 73.80, üstündekiler: 85 90
 */
#include <stdio.h>

#define N 5

int main(void)
{
    /* 1) Ayrı değişkenlerle */
    int not1 = 72, not2 = 85, not3 = 64, not4 = 90, not5 = 58;
    double ort = (not1 + not2 + not3 + not4 + not5) / 5.0;
    printf("Ayrı değişkenler : ortalama %.2f, üstündekiler:", ort);
    if (not1 > ort) { printf(" %d", not1); }
    if (not2 > ort) { printf(" %d", not2); }
    if (not3 > ort) { printf(" %d", not3); }
    if (not4 > ort) { printf(" %d", not4); }
    if (not5 > ort) { printf(" %d", not5); }
    printf("\n");

    /* 2) Diziyle */
    int notlar[N] = {72, 85, 64, 90, 58};
    int toplam = 0;
    for (int i = 0; i < N; i++) {
        toplam += notlar[i];
    }
    double ortalama = (double)toplam / N;
    printf("Diziyle          : ortalama %.2f, üstündekiler:", ortalama);
    for (int i = 0; i < N; i++) {
        if (notlar[i] > ortalama) {
            printf(" %d", notlar[i]);
        }
    }
    printf("\n");
    return 0;
}

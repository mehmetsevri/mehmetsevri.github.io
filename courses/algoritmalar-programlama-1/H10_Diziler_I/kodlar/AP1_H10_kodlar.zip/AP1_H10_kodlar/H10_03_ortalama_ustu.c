/* H10_03_ortalama_ustu.c — Hafta 10 · Örnek 3 (★): ortalamanın üstündekiler
 * Amaç   : Neden dizi gerekli? Ortalamanın üstündeki notları yazmak için
 *          İKİ GEÇİŞ gerekir: önce ortalama (hepsi okunmalı), sonra
 *          karşılaştırma. Değerler birinci geçişte SAKLANMALI.
 *          Kapasite (KAPASITE) ile dolu eleman sayısı (n) ayrıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_03_ortalama_ustu.c -o ortalama_ustu
 * Örnek  : girdi "6  72 85 64 90 58 77" -> Ortalamanın üstünde: 3 not
 */
#include <stdio.h>

#define KAPASITE 100                    /* en çok 100 öğrenci */

int main(void)
{
    int notlar[KAPASITE];
    int n;

    printf("Öğrenci sayısı (1-%d): ", KAPASITE);
    if (scanf("%d", &n) != 1 || n < 1 || n > KAPASITE) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("%d not: ", n);
    int toplam = 0;
    for (int i = 0; i < n; i++) {       /* 1. geçiş: oku, sakla, topla */
        if (scanf("%d", &notlar[i]) != 1) {
            printf("Geçersiz girdi.\n");
            return 1;
        }
        toplam += notlar[i];
    }
    double ortalama = (double)toplam / n;
    printf("Ortalama: %.2f\n", ortalama);

    int adet = 0;
    for (int i = 0; i < n; i++) {       /* 2. geçiş: saklananları karşılaştır */
        if (notlar[i] > ortalama) {
            printf("  %d. öğrenci: %d\n", i + 1, notlar[i]);
            adet++;
        }
    }
    printf("Ortalamanın üstünde: %d not\n", adet);
    return 0;
}

/* H10_K14_obs_ceviri_birimi.c — Hafta 10 · kavram: Mini-OBS v0.10 arayüzü tek çeviri biriminde
 * Amaç   : #include "obs.h" satırının önişlemcide yaptığı işi elle yapmak: obs.h'nin
 *          METNİ aşağıya birebir yapıştırıldı (H9: #include metin yapıştırmaktır).
 *          Prototipler bildirimdir; tanımları proje/obs.c'dedir ve burada çağrılmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_K14_obs_ceviri_birimi.c -o obs_ceviri_birimi
 * Örnek  : -> AZAMI_OGRENCI = 100, HARF_SAYISI = 9
 */
#include <stdio.h>

/* ---- obs.h'nin metni (değiştirilmeden) ---- */
/* obs.h — Mini-OBS v0.10 (AP-1 Hafta 10): modülün ARAYÜZÜ
 * Yenilik : Kayıtlar artık SAKLANIYOR: main.c'deki paralel diziler
 *           no[], vize[], final[], ort[] (aynı indis = aynı öğrenci).
 *           Akış hâlindeki static istatistik değişkenleri (v0.9) kalktı;
 *           istatistikler her istendiğinde dizilerden yeniden hesaplanır.
 *           Diziler fonksiyonlara boyut (n) ile birlikte ve salt okunur
 *           olacaksa const ile aktarılır.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>

#define AZAMI_OGRENCI 100   /* dizilerin kapasitesi (derleme zamanı sabiti) */
#define HARF_SAYISI 9       /* AA, BA, BB, CB, CC, DC, DD, FD, FF */

/* ---- ekran ve girdi ---- */
void baslik_yaz(void);
void menu_goster(void);
int menu_secimi_oku(void);
long long numara_oku(void);
double not_oku(const char *etiket);

/* ---- hesap kuralları (yan etkisiz, test edilebilir; v0.8'den) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
void ogrenci_raporu_yaz(long long numara, double vize, double final,
                        double ortalama, int yuvarlanmis);

/* ---- harf notu indisi: frekans dizisinde "değer = indis" ---- */
int harf_indeksi(int yuvarlanmis, double final);   /* AA=0 ... FF=8 */
const char *harf_adi(int indeks);

/* ---- dizi desenleri (H10) ---- */
int numara_bul(const long long no[], int n, long long aranan);   /* indis ya da -1 */
double dizi_ortalama(const double a[], int n);
double standart_sapma(const double a[], int n);                 /* popülasyon: n'ye böl */
int en_buyuk_indis(const double a[], int n);
int en_kucuk_indis(const double a[], int n);
int esik_ustu_say(const double a[], int n, double esik);
void harf_dagilimi(const double ort[], const double final[], int n,
                   int sayac[HARF_SAYISI]);

/* ---- raporlar ---- */
void istatistik_yaz(const long long no[], const double final[],
                    const double ort[], int n);
void kayitlari_listele(const long long no[], const double vize[],
                       const double final[], const double ort[], int n);
void histogram_yaz(const double ort[], const double final[], int n);

#endif /* OBS_H */
/* ---- obs.h'nin sonu ---- */

int main(void)
{
    printf("AZAMI_OGRENCI = %d, HARF_SAYISI = %d\n", AZAMI_OGRENCI, HARF_SAYISI);
    return 0;
}

/* H10_K02_bildirim_ilk_deger.c — Hafta 10 · Kavram programı: bildirim ve
 *          ilk değer listeleri
 * Amaç   : Tam liste, kısmi liste (kalanlar 0), {0}, boyutu listeden
 *          alan bildirim ve C99'un belirlenmiş ilk değerleri ([indis] =).
 *          Dosya kapsamındaki (global) dizi kendiliğinden sıfırla başlar;
 *          fonksiyon içindeki ilk değersiz dizi BAŞLAMAZ (Hata Avcısı 2).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K02_bildirim_ilk_deger.c -o bildirim_ilk_deger
 * Örnek  : -> b (kısmi)      : 1 2 0 0 0
 */
#include <stdio.h>

int g[5];                               /* global: hepsi 0 */

int main(void)
{
    int a[5] = {1, 2, 3, 4, 5};         /* tam liste */
    int b[5] = {1, 2};                  /* kısmi: kalanlar 0 */
    int c[5] = {0};                     /* hepsi 0 */
    int d[] = {4, 8, 15, 16, 23, 42};   /* boyut listeden: 6 */
    int e[6] = {[2] = 7, [5] = 9};      /* C99: belirlenmiş ilk değer */

    printf("a (tam liste)  :");
    for (int i = 0; i < 5; i++) { printf(" %d", a[i]); }
    printf("\nb (kısmi)      :");
    for (int i = 0; i < 5; i++) { printf(" %d", b[i]); }
    printf("\nc ({0})        :");
    for (int i = 0; i < 5; i++) { printf(" %d", c[i]); }
    printf("\nd (boyut: %zu)   :", sizeof(d) / sizeof(d[0]));
    for (int i = 0; i < 6; i++) { printf(" %d", d[i]); }
    printf("\ne ([2], [5])   :");
    for (int i = 0; i < 6; i++) { printf(" %d", e[i]); }
    printf("\ng (global)     :");
    for (int i = 0; i < 5; i++) { printf(" %d", g[i]); }
    printf("\n");
    return 0;
}

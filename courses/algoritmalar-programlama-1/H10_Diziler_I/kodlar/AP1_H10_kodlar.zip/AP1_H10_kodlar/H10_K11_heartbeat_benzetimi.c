/* H10_K11_heartbeat_benzetimi.c — Hafta 10 · Kavram programı: "uzunluğa
 *          güvenen kopyalama" benzetimi (Heartbleed'in özü)
 * Amaç   : EĞİTSEL BENZETİM; ağ kodu değildir. Sunucu belleğini temsil
 *          eden TEK bir dizide önce istemcinin gönderdiği yük ("KUS", 3
 *          bayt), hemen ardından başka verilerin durduğunu varsayalım.
 *          Hatalı yanıt fonksiyonu istemcinin BİLDİRDİĞİ uzunluk kadar
 *          kopyalar; uzunluk yalan söylerse yükün ötesindeki veriler de
 *          yanıta girer. Düzeltilmiş sürüm bildirilen uzunluk gerçek yükü
 *          aşıyorsa isteği yanıtlamaz. Benzetim kendi dizisinin dışına
 *          ÇIKMAZ: bildirilen uzunluk sizeof(bellek) ile sınırlanır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K11_heartbeat_benzetimi.c -o heartbeat
 * Örnek  : -> düzeltilmiş: istek atıldı (0 bayt)
 */
#include <stdio.h>

#define YANIT_KAPASITE 64

int yanit_hatali(const char bellek[], int bildirilen, char yanit[]);
int yanit_duzeltilmis(const char bellek[], int gercek, int bildirilen,
                      char yanit[]);
void yaz(const char *etiket, const char yanit[], int uzunluk);

int main(void)
{
    /* yük (3 bayt) + bitişik bellekteki başka veriler */
    const char bellek[] = "KUS|oturum=7f3a91|parola=Rize53|";
    const int gercek = 3;               /* istemcinin gerçekten gönderdiği */
    const int istekler[] = {3, 31};     /* istemcinin BİLDİRDİĞİ uzunluklar */
    char yanit[YANIT_KAPASITE];

    for (int k = 0; k < 2; k++) {
        int bildirilen = istekler[k];
        if (bildirilen > (int)sizeof(bellek) - 1) {   /* benzetimin sınırı */
            bildirilen = (int)sizeof(bellek) - 1;
        }
        printf("İstek: yük \"KUS\" (%d bayt), bildirilen uzunluk %d\n",
               gercek, bildirilen);
        yaz("  hatalı     ", yanit, yanit_hatali(bellek, bildirilen, yanit));
        yaz("  düzeltilmiş", yanit,
            yanit_duzeltilmis(bellek, gercek, bildirilen, yanit));
    }
    return 0;
}

/* HATALI: istemcinin bildirdiği uzunluğa GÜVENİR (denetim yok). */
int yanit_hatali(const char bellek[], int bildirilen, char yanit[])
{
    for (int i = 0; i < bildirilen; i++) {
        yanit[i] = bellek[i];
    }
    return bildirilen;
}

/* DÜZELTİLMİŞ: bildirilen > gercek ise isteği yanıtlamadan at (0). */
int yanit_duzeltilmis(const char bellek[], int gercek, int bildirilen,
                      char yanit[])
{
    if (bildirilen > gercek) {          /* eksik olan SINIR DENETİMİ */
        return 0;
    }
    for (int i = 0; i < bildirilen; i++) {
        yanit[i] = bellek[i];
    }
    return bildirilen;
}

/* Yanıtı karakter karakter yazar (uzunluk 0 ise isteğin atıldığını). */
void yaz(const char *etiket, const char yanit[], int uzunluk)
{
    if (uzunluk == 0) {
        printf("%s: istek atıldı (0 bayt)\n", etiket);
        return;
    }
    printf("%s: \"", etiket);
    for (int i = 0; i < uzunluk; i++) {
        putchar(yanit[i]);
    }
    printf("\" (%d bayt)\n", uzunluk);
}

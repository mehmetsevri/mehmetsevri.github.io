/* H10_08_sola_dondur.c — Hafta 10 · Örnek 8 (★★): bir konum sola döndürme
 * Amaç   : Kaydırma + geçici değişken: ilk eleman kenara alınır, diğerleri
 *          bir sola kaydırılır (SOLDAN SAĞA: a[i] = a[i + 1]), kenara
 *          alınan değer sona konur. Döngü n - 1 kez döner (a[n] YOK).
 *          Üç kez art arda döndürülür.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_08_sola_dondur.c -o sola_dondur
 * Örnek  : -> 3. dönüş: 4 5 6 1 2 3
 */
#include <stdio.h>

#define N 6

int main(void)
{
    int a[N] = {1, 2, 3, 4, 5, 6};

    printf("Başta   :");
    for (int k = 0; k < N; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");

    for (int tur = 1; tur <= 3; tur++) {
        int ilk = a[0];                 /* 1) ilk elemanı kenara al */
        for (int i = 0; i < N - 1; i++) {
            a[i] = a[i + 1];            /* 2) soldan sağa: bir sola kaydır */
        }
        a[N - 1] = ilk;                 /* 3) kenardakini sona koy */

        printf("%d. dönüş:", tur);
        for (int k = 0; k < N; k++) {
            printf(" %d", a[k]);
        }
        printf("\n");
    }
    return 0;
}

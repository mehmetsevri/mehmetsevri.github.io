/* H10_K09_kopyala_karsilastir.c — Hafta 10 · Kavram programı: dizi kopyalama,
 *          karşılaştırma ve birleştirme
 * Amaç   : C'de diziler = ile kopyalanmaz, == ile karşılaştırılmaz
 *          (Hata Avcısı 4). Üçü de eleman eleman bir döngüyle yapılır.
 *          Standart kütüphane karşılıkları: memcpy ve memcmp (<string.h>);
 *          boyut BAYT cinsinden verilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K09_kopyala_karsilastir.c -o kopyala_karsilastir
 * Örnek  : -> birleşik : 3 1 4 1 5 9 2 6
 */
#include <stdio.h>
#include <stdbool.h>
#include <string.h>                     /* memcpy, memcmp */

#define N 4

int main(void)
{
    int a[N] = {3, 1, 4, 1};
    int b[N];
    int c[N] = {5, 9, 2, 6};

    for (int i = 0; i < N; i++) {       /* kopyalama: eleman eleman */
        b[i] = a[i];
    }

    bool esit = true;                   /* karşılaştırma: ilk farkta dur */
    for (int i = 0; i < N; i++) {
        if (a[i] != b[i]) {
            esit = false;
            break;
        }
    }
    printf("a ile b %s\n", esit ? "eşit" : "farklı");

    int birlesik[2 * N];                /* birleştirme: a, ardından c */
    for (int i = 0; i < N; i++) {
        birlesik[i] = a[i];
        birlesik[N + i] = c[i];
    }
    printf("birleşik :");
    for (int i = 0; i < 2 * N; i++) { printf(" %d", birlesik[i]); }
    printf("\n");

    int d[N];
    memcpy(d, c, sizeof(c));            /* kütüphaneyle kopya (bayt) */
    printf("memcmp(c, d) = %d (0: aynı)\n", memcmp(c, d, sizeof(c)));
    return 0;
}

/* H10_Q01_static_sayac.c — Hafta 10 · Geçen haftadan S1 (H9: static yerel)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q01_static_sayac.c -o q01
 */
#include <stdio.h>

int say(void)
{
    static int n = 0;
    n++;
    return n;
}

int main(void)
{
    say();
    say();
    printf("%d\n", say());
    return 0;
}

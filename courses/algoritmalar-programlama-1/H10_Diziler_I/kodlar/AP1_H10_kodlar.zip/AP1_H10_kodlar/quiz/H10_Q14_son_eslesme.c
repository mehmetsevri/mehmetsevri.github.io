/* H10_Q14_son_eslesme.c — Hafta 10 · Quiz S4 (tarama, erken çıkış yok)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q14_son_eslesme.c -o q14
 */
#include <stdio.h>

int main(void)
{
    int a[] = {7, 3, 7, 1, 7};
    int k = -1;
    for (int i = 0; i < 5; i++) {
        if (a[i] == 7) {
            k = i;
        }
    }
    printf("%d\n", k);
    return 0;
}

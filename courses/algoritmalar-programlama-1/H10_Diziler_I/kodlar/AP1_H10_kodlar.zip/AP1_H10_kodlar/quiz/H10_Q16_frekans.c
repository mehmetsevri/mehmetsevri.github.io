/* H10_Q16_frekans.c — Hafta 10 · Quiz S6 (frekans dizisi)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q16_frekans.c -o q16
 */
#include <stdio.h>

int main(void)
{
    int v[] = {1, 3, 1, 2, 1};
    int f[4] = {0};
    for (int i = 0; i < 5; i++) {
        f[v[i]]++;
    }
    printf("%d%d%d%d\n", f[0], f[1], f[2], f[3]);
    return 0;
}

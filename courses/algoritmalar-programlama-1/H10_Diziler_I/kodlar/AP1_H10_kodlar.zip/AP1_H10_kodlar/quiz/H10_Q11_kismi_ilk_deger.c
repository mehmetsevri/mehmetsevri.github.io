/* H10_Q11_kismi_ilk_deger.c — Hafta 10 · Quiz S1 (kısmi ilk değer)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q11_kismi_ilk_deger.c -o q11
 */
#include <stdio.h>

int main(void)
{
    int a[5] = {3};
    printf("%d %d\n", a[0], a[4]);
    return 0;
}

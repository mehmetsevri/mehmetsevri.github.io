/* H10_Q02_cagri_yigini.c — Hafta 10 · Geçen haftadan S2 (H9: çağrı yığını)
 * Soru   : Program ne yazdırır? Yığında aynı anda en çok kaç çerçeve olur?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q02_cagri_yigini.c -o q02
 */
#include <stdio.h>

void b(void)
{
    printf("b ");
}

void a(void)
{
    printf("a1 ");
    b();
    printf("a2 ");
}

int main(void)
{
    printf("m1 ");
    a();
    printf("m2\n");
    return 0;
}

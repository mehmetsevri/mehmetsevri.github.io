/* H10_Q18_dizi_atama.c — Hafta 10 · Quiz S8 (dizi ataması)
 * BU DOSYA KASITLI HATA İÇERİR: b = a; derlenmez.
 * Soru   : Bu program için hangisi doğrudur?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q18_dizi_atama.c -o q18
 */
#include <stdio.h>

int main(void)
{
    int a[3] = {1, 2, 3};
    int b[3];
    b = a;
    printf("%d\n", b[0]);
    return 0;
}

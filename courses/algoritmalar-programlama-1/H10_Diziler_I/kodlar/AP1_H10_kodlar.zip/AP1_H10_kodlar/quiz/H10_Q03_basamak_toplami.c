/* H10_Q03_basamak_toplami.c — Hafta 10 · Geçen haftadan S3 (H9: özyineleme)
 * Soru   : Program ne yazdırır? Temel durum hangisi?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q03_basamak_toplami.c -o q03
 */
#include <stdio.h>

int topla(int n)
{
    if (n == 0) {
        return 0;
    }
    return n % 10 + topla(n / 10);
}

int main(void)
{
    printf("%d\n", topla(2026));
    return 0;
}

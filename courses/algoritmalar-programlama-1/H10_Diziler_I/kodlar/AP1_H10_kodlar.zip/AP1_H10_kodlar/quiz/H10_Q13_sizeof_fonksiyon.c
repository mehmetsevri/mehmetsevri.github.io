/* H10_Q13_sizeof_fonksiyon.c — Hafta 10 · Quiz S3 (fonksiyonda sizeof)
 * BU DOSYA KASITLI HATA İÇERİR: parametredeki dizi bir işaretçidir
 *          (derleyici -Wsizeof-array-argument ile uyarır).
 * Soru   : x86-64 Linux'ta (int 4, işaretçi 8 bayt) program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q13_sizeof_fonksiyon.c -o q13
 */
#include <stdio.h>

void f(int d[])
{
    printf("%zu\n", sizeof(d) / sizeof(d[0]));
}

int main(void)
{
    int x[10] = {0};
    f(x);
    return 0;
}

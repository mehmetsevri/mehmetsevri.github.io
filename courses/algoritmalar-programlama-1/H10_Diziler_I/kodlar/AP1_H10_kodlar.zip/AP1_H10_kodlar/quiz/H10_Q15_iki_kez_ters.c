/* H10_Q15_iki_kez_ters.c — Hafta 10 · Quiz S5 (ters çevirme koşulu)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q15_iki_kez_ters.c -o q15
 */
#include <stdio.h>

int main(void)
{
    int a[4] = {1, 2, 3, 4};
    for (int i = 0; i < 4; i++) {       /* i < j değil, i < n! */
        int j = 3 - i;
        int g = a[i];
        a[i] = a[j];
        a[j] = g;
    }
    printf("%d %d %d %d\n", a[0], a[1], a[2], a[3]);
    return 0;
}

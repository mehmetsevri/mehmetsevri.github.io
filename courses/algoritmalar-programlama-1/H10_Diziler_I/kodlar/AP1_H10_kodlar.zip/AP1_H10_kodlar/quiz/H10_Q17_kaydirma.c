/* H10_Q17_kaydirma.c — Hafta 10 · Quiz S7 (kaydırma yönü)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_Q17_kaydirma.c -o q17
 */
#include <stdio.h>

int main(void)
{
    int a[5] = {1, 2, 3, 4};
    for (int i = 1; i <= 4; i++) {
        a[i] = a[i - 1];
    }
    a[0] = 9;
    printf("%d %d %d %d %d\n", a[0], a[1], a[2], a[3], a[4]);
    return 0;
}

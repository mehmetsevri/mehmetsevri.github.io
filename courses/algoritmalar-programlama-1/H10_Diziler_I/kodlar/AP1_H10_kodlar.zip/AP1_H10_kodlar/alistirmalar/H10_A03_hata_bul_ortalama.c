/* H10_A03_hata_bul_ortalama.c — Hafta 10 · Alıştırma 10.3 (★★): hata bul
 * BU DOSYA KASITLI HATA İÇERİR (iki mantık hatası; uyarısız derlenir).
 * Soru   : Üç notun ortalaması 80.00 olmalıyken program 56.00 yazıyor.
 *          İki hatayı bulun ve düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_A03_hata_bul_ortalama.c -o a03
 */
#include <stdio.h>

#define KAPASITE 10

int main(void)
{
    int notlar[KAPASITE] = {70, 80, 90};    /* kalanlar 0 */
    int n = 3;                              /* dolu eleman sayısı */
    int toplam = 0;
    for (int i = 1; i <= n; i++) {
        toplam += notlar[i];
    }
    double ortalama = toplam / n;
    printf("Ortalama: %.2f\n", ortalama);
    return 0;
}

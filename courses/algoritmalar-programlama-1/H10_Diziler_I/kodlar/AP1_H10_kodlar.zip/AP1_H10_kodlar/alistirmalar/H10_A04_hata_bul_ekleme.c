/* H10_A04_hata_bul_ekleme.c — Hafta 10 · Alıştırma 10.4 (★★): hata bul
 * BU DOSYA KASITLI HATA İÇERİR (mantık hatası; uyarısız derlenir).
 * Soru   : basa_ekle(a, 4, 0) çağrısından sonra dizi 0 10 20 30 40 olmalı;
 *          program 0 10 10 10 10 yazıyor. Hata nerede? Düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_A04_hata_bul_ekleme.c -o a04
 */
#include <stdio.h>

/* Ön koşul: dizide en az n + 1 yer var.  Son koşul: yeni n. */
int basa_ekle(int a[], int n, int deger)
{
    for (int i = 1; i <= n; i++) {
        a[i] = a[i - 1];
    }
    a[0] = deger;
    return n + 1;
}

int main(void)
{
    int a[5] = {10, 20, 30, 40};
    int n = basa_ekle(a, 4, 0);
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
    return 0;
}

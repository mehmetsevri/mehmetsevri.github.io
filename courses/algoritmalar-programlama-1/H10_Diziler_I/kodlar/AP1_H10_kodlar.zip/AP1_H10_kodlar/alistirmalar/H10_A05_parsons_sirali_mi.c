/* H10_A05_parsons_sirali_mi.c — Hafta 10 · Alıştırma 10.5 (★★): Parsons problemi
 * Tamamlanacak; bu hâliyle derlenmez.
 * Soru   : sirali_mi() fonksiyonunun satırları karıştırıldı ve araya FAZLADAN
 *          bir satır (çeldirici) eklendi. Fonksiyon dizi küçükten büyüğe
 *          (azalmayan) sıralıysa true, değilse false döndürmeli. Satırları
 *          doğru sıraya dizin, çeldiriciyi atın ve girintiyi düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_A05_parsons_sirali_mi.c -o a05
 */
#include <stdio.h>
#include <stdbool.h>

/* ---- karışık satırlar (birini kullanmayacaksınız) ---- */
        return false;
    return true;
bool sirali_mi(const int a[], int n)
    for (int i = 0; i < n; i++) {
}
        if (a[i] > a[i + 1]) {
{
    for (int i = 0; i < n - 1; i++) {
        }
    }
/* ---- karışık satırların sonu ---- */

int main(void)
{
    int a[] = {3, 5, 5, 8, 13};
    int b[] = {3, 8, 5};
    printf("%d %d\n", sirali_mi(a, 5), sirali_mi(b, 3));   /* 1 0 */
    return 0;
}

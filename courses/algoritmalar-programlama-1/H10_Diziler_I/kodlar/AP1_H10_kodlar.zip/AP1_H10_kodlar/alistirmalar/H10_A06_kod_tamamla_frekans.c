/* H10_A06_kod_tamamla_frekans.c — Hafta 10 · Alıştırma 10.6 (★★): kod tamamlama
 * Tamamlanacak; bu hâliyle derlenmez.
 * Soru   : 0-10 arası puanların frekansını sayıp yalnızca en az bir kez
 *          geçen puanları yazdıran programdaki dört boşluğu (____) doldurun.
 *          Beklenen çıktı: " 3: 1", " 5: 1", " 7: 3", " 8: 1", "10: 2"
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_A06_kod_tamamla_frekans.c -o a06
 */
#include <stdio.h>

int main(void)
{
    int puanlar[] = {7, 10, 3, 7, 8, 10, 7, 5};
    int n = (int)(sizeof(puanlar) / sizeof(puanlar[0]));
    int frekans[____] = {____};
    for (int i = 0; i < n; i++) {
        frekans[____]++;
    }
    for (int puan = 0; puan <= 10; puan++) {
        if (frekans[puan] > 0) {
            printf("%2d: %d\n", puan, ____);
        }
    }
    return 0;
}

/* H10_A02_cikti_tahmini_kaydirma.c — Hafta 10 · Alıştırma 10.2 (★★): çıktı tahmini
 * Soru   : Programın iki satırlık çıktısını tahmin edin. Birinci bölüm
 *          diziye ne yapıyor? İkinci bölümdeki say[] dizisi neyi sayıyor?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_A02_cikti_tahmini_kaydirma.c -o a02
 */
#include <stdio.h>

int main(void)
{
    int a[5] = {1, 2, 3, 4, 5};
    int son = a[4];
    for (int i = 4; i > 0; i--) {
        a[i] = a[i - 1];
    }
    a[0] = son;
    for (int i = 0; i < 5; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    int veri[] = {2, 0, 2, 1, 2, 0};
    int say[3] = {0};
    for (int i = 0; i < 6; i++) {
        say[veri[i]]++;
    }
    printf("%d %d %d\n", say[0], say[1], say[2]);
    return 0;
}

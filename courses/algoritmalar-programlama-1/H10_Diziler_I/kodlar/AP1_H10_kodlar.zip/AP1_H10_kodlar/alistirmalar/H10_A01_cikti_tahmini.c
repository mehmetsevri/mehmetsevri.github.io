/* H10_A01_cikti_tahmini.c — Hafta 10 · Alıştırma 10.1 (★): çıktı tahmini
 * Soru   : Programı çalıştırmadan çıktısını tahmin edin; sonra derleyip
 *          karşılaştırın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_A01_cikti_tahmini.c -o a01
 */
#include <stdio.h>

int main(void)
{
    int a[6];
    for (int i = 0; i < 6; i++) {
        a[i] = i * i;
    }
    printf("%d %d %d\n", a[2], a[a[2]], a[5] - a[4]);

    int b[5] = {4};
    int n = (int)(sizeof(b) / sizeof(b[0]));
    printf("%d %d\n", b[0] + b[4], n);
    return 0;
}

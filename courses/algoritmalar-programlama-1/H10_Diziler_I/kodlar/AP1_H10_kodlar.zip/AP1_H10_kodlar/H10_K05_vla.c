/* H10_K05_vla.c — Hafta 10 · Kavram programı: değişken uzunluklu dizi (VLA)
 * Amaç   : Boyutu ÇALIŞMA ZAMANINDA belirlenen dizi: int kareler[n];
 *          C99'da zorunlu, C11/C17'de İSTEĞE BAĞLI bir özelliktir:
 *          desteklemeyen derleyici __STDC_NO_VLA__ makrosunu 1 tanımlar
 *          (MSVC böyledir). GCC destekler. Sorun: n büyükse yığın taşar ve
 *          bunu denetlemenin taşınabilir yolu yoktur; derste sabit
 *          kapasiteli diziler (#define) kullanıyoruz, dinamik bellek H12.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K05_vla.c -o vla
 *          (-Wvla eklenirse VLA kullanımı uyarı olarak gösterilir)
 * Örnek  : girdi "6" -> sizeof(kareler) = 24 bayt (çalışma zamanında)
 */
#include <stdio.h>

int main(void)
{
#ifdef __STDC_NO_VLA__
    printf("Bu derleyici VLA desteklemiyor (__STDC_NO_VLA__ tanımlı).\n");
#else
    int n;
    printf("Kaç eleman (1-1000)? ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 1000) {   /* sınırı denetle! */
        printf("Geçersiz girdi.\n");
        return 1;
    }
    int kareler[n];                     /* VLA: boyut n, çalışma zamanında */
    for (int i = 0; i < n; i++) {
        kareler[i] = i * i;
    }
    printf("kareler[%d] = %d\n", n - 1, kareler[n - 1]);
    printf("sizeof(kareler) = %zu bayt (çalışma zamanında)\n", sizeof(kareler));
#endif
    return 0;
}

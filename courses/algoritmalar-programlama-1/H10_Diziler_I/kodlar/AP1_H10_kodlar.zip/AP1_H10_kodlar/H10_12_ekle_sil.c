/* H10_12_ekle_sil.c — Hafta 10 · Örnek 12 (★★★): araya ekleme ve silme
 * Amaç   : Eleman kaydırma ve KAYDIRMA YÖNÜ. Ekleme: konumdan sonrası bir
 *          SAĞA kayar; döngü SONDAN BAŞA gider (yoksa elemanlar ezilir).
 *          Silme: konumdan sonrası bir SOLA kayar; döngü BAŞTAN SONA gider.
 *          Fonksiyon n'yi değiştiremez (değerle aktarım): yeni n'yi
 *          döndürür. Hatalı konumda ya da dolu dizide -1 döndürür.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_12_ekle_sil.c -o ekle_sil
 * Örnek  : -> sil(0)        : [20, 25, 30, 40, 50]  n = 5
 */
#include <stdio.h>

#define KAPASITE 6

void yazdir(const char *etiket, const int a[], int n);
int ekle(int a[], int n, int kapasite, int konum, int deger);
int sil(int a[], int n, int konum);

int main(void)
{
    int a[KAPASITE] = {10, 20, 30, 40, 50};
    int n = 5;                          /* dolu eleman sayısı */

    yazdir("başta         ", a, n);
    n = ekle(a, n, KAPASITE, 2, 25);
    yazdir("ekle(2, 25)   ", a, n);
    n = sil(a, n, 0);
    yazdir("sil(0)        ", a, n);
    n = ekle(a, n, KAPASITE, n, 60);    /* konum = n: sona ekleme */
    yazdir("ekle(n, 60)   ", a, n);
    int r = ekle(a, n, KAPASITE, 0, 5); /* dizi dolu */
    printf("ekle(0, 5)    : %d (dizi dolu)\n", r);
    r = sil(a, n, 7);                   /* geçersiz konum */
    printf("sil(7)        : %d (geçersiz konum)\n", r);
    return 0;
}

/* Ön koşul: n < kapasite, 0 <= konum <= n.  Son koşul: yeni n; aksi -1. */
int ekle(int a[], int n, int kapasite, int konum, int deger)
{
    if (n >= kapasite || konum < 0 || konum > n) {
        return -1;
    }
    for (int i = n; i > konum; i--) {   /* SONDAN BAŞA: sağa kaydır */
        a[i] = a[i - 1];
    }
    a[konum] = deger;
    return n + 1;
}

/* Ön koşul: 0 <= konum < n.  Son koşul: yeni n; aksi -1. */
int sil(int a[], int n, int konum)
{
    if (konum < 0 || konum >= n) {
        return -1;
    }
    for (int i = konum; i < n - 1; i++) {   /* BAŞTAN SONA: sola kaydır */
        a[i] = a[i + 1];
    }
    return n - 1;
}

/* etiket : [a0, a1, ...]  n = ... */
void yazdir(const char *etiket, const int a[], int n)
{
    printf("%s: [", etiket);
    for (int i = 0; i < n; i++) {
        printf("%s%d", i > 0 ? ", " : "", a[i]);
    }
    printf("]  n = %d\n", n);
}

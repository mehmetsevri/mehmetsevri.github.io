/* H10_K03_adresler.c — Hafta 10 · Kavram programı: bitişik bellek
 * Amaç   : &a[0], &a[1], ... adresleri ELEMAN BOYUTU kadar artar:
 *          int'te 4, double'da 8, char'da 1 bayt (x86-64 Linux, LP64).
 *          adres(a[i]) = taban + i * sizeof(eleman). Dizinin adı (a)
 *          ifadelerde &a[0] olarak kullanılır; a[i] ile *(a + i) aynıdır
 *          (ilk bakış; ayrıntısı H12). Adresler her çalıştırmada
 *          değişir (ASLR), ARALARINDAKİ FARK değişmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K03_adresler.c -o adresler
 * Örnek  : -> a[2] = 30, *(a + 2) = 30
 */
#include <stdio.h>

int main(void)
{
    int    a[4] = {10, 20, 30, 40};
    double d[4] = {1.5, 2.5, 3.5, 4.5};
    char   c[4] = {'A', 'B', 'C', 'D'};

    printf("sizeof: int %zu, double %zu, char %zu bayt\n",
           sizeof(a[0]), sizeof(d[0]), sizeof(c[0]));
    for (int i = 0; i < 4; i++) {
        printf("i=%d  &a[i]=%p  &d[i]=%p  &c[i]=%p\n", i,
               (void *)&a[i], (void *)&d[i], (void *)&c[i]);
    }
    printf("a = %p (dizinin adı = &a[0])\n", (void *)a);
    printf("a[2] = %d, *(a + 2) = %d\n", a[2], *(a + 2));
    return 0;
}

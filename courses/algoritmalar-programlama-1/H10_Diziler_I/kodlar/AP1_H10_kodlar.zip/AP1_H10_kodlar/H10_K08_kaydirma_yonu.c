/* H10_K08_kaydirma_yonu.c — Hafta 10 · Kavram programı: kaydırma yönü
 * Amaç   : Başa (konum 0) 9 eklemek için herkes bir SAĞA kaymalı. Döngü
 *          baştan sona giderse her eleman bir sonrakinin üstüne yazılır
 *          ve ilk değer bütün diziye yayılır. Sondan başa giderse her
 *          eleman ezilmeden önce taşınmış olur. (Silmede tersi: sola
 *          kaydırma baştan sona.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K08_kaydirma_yonu.c -o kaydirma_yonu
 * Örnek  : -> Doğru yön (sondan başa) : 9 1 2 3 4 5
 */
#include <stdio.h>

int main(void)
{
    int yanlis[6] = {1, 2, 3, 4, 5};    /* 5 dolu eleman, 1 boş yer */
    int dogru[6]  = {1, 2, 3, 4, 5};

    for (int i = 1; i <= 5; i++) {      /* YANLIŞ: baştan sona */
        yanlis[i] = yanlis[i - 1];
    }
    yanlis[0] = 9;

    for (int i = 5; i >= 1; i--) {      /* DOĞRU: sondan başa */
        dogru[i] = dogru[i - 1];
    }
    dogru[0] = 9;

    printf("Yanlış yön (baştan sona): ");
    for (int i = 0; i < 6; i++) { printf("%d ", yanlis[i]); }
    printf("\nDoğru yön (sondan başa) : ");
    for (int i = 0; i < 6; i++) { printf("%d ", dogru[i]); }
    printf("\n");
    return 0;
}

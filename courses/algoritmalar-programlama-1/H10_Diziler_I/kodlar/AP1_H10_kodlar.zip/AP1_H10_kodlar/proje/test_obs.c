/* test_obs.c — Mini-OBS v0.10 (AP-1 Hafta 10): birim testleri
 * v0.8'deki 37 kural doğrulaması (aynen) + dizi fonksiyonları için yeni
 * testler (numara_bul, dizi_ortalama, standart_sapma, en büyük/küçük
 * indis, eşik üstü sayma, harf_indeksi, harf_dagilimi).
 * Derleme : make test       (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c test_obs.c
 *           gcc obs.o test_obs.o -o obs_test -lm && ./obs_test
 */
#include <stdio.h>
#include <assert.h>
#include <string.h>   /* strcmp: metin karşılaştırmak için */
#include <stdbool.h>
#include "obs.h"

static int sayac = 0;                /* geçen doğrulama sayısı (dosya kapsamı) */
static const double EPS = 1e-9;      /* kayan nokta toleransı */

/* v0.8'deki 37 kural testi (aynen) */
static void kural_testleri(void)
{
    /* hesapla_ortalama: kayan noktada == yerine tolerans */
    assert(hesapla_ortalama(70, 85) - 79.0 < EPS && 79.0 - hesapla_ortalama(70, 85) < EPS); sayac++;
    assert(hesapla_ortalama(0, 0) == 0.0); sayac++;
    assert(hesapla_ortalama(100, 100) - 100.0 < EPS && 100.0 - hesapla_ortalama(100, 100) < EPS); sayac++;

    /* yuvarla: .5 yukarı, altı aşağı */
    assert(yuvarla(59.5) == 60); sayac++;
    assert(yuvarla(59.4) == 59); sayac++;
    assert(yuvarla(0.0) == 0); sayac++;
    assert(yuvarla(100.0) == 100); sayac++;

    /* harf_notu: her kademenin iki sınırı ve baraj */
    assert(strcmp(harf_notu(100, 100), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(90, 90), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(89, 89), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(81, 81), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(80, 80), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(73, 73), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(72, 72), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(66, 66), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(65, 65), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(60, 60), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(59, 59), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(50, 50), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(49, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(40, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(39, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(30, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(29, 50), "FF") == 0); sayac++;
    assert(strcmp(harf_notu(95, 49.9), "FF") == 0); sayac++;   /* baraj */

    /* gecti_mi / sartli_mi */
    assert(gecti_mi(60, 50)); sayac++;
    assert(!gecti_mi(59, 80)); sayac++;
    assert(!gecti_mi(95, 49.9)); sayac++;
    assert(sartli_mi(50, 50)); sayac++;
    assert(sartli_mi(59, 60)); sayac++;
    assert(!sartli_mi(60, 60)); sayac++;
    assert(!sartli_mi(49, 60)); sayac++;
    assert(!sartli_mi(55, 45)); sayac++;

    /* durum_metni */
    assert(strcmp(durum_metni(79, 85), "BAŞARILI") == 0); sayac++;
    assert(strcmp(durum_metni(54, 70), "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)") == 0); sayac++;
    assert(strcmp(durum_metni(47, 48), "BAŞARISIZ (final barajı)") == 0); sayac++;
    assert(strcmp(durum_metni(45, 50), "BAŞARISIZ") == 0); sayac++;
}

/* Kayan nokta karşılaştırması: |x - y| < EPS */
static bool yakin(double x, double y)
{
    return x - y < EPS && y - x < EPS;
}

/* Yeni (H10): dizi fonksiyonları */
static void dizi_testleri(void)
{
    const long long no[] = {2301010045, 2301010046, 2301010047};
    assert(numara_bul(no, 3, 2301010046) == 1); sayac++;
    assert(numara_bul(no, 3, 2301010099) == -1); sayac++;
    assert(numara_bul(no, 0, 2301010045) == -1); sayac++;   /* boş dizi */

    const double a[] = {2, 4, 4, 4, 5, 5, 7, 9};             /* μ = 5, σ = 2 */
    int n = (int)(sizeof a / sizeof a[0]);
    assert(yakin(dizi_ortalama(a, n), 5.0)); sayac++;
    assert(yakin(standart_sapma(a, n), 2.0)); sayac++;
    assert(en_buyuk_indis(a, n) == 7); sayac++;
    assert(en_kucuk_indis(a, n) == 0); sayac++;
    assert(esik_ustu_say(a, n, 5.0) == 2); sayac++;          /* yalnız 7 ve 9 */

    const double esit[] = {3, 8, 8, 1};                      /* eşitlikte İLK indis */
    assert(en_buyuk_indis(esit, 4) == 1); sayac++;
    assert(yakin(standart_sapma(esit, 1), 0.0)); sayac++;    /* tek eleman */

    assert(harf_indeksi(90, 90) == 0 && strcmp(harf_adi(0), "AA") == 0); sayac++;
    assert(harf_indeksi(59, 60) == 5 && strcmp(harf_adi(5), "DC") == 0); sayac++;
    assert(harf_indeksi(95, 49.9) == 8 && strcmp(harf_adi(8), "FF") == 0); sayac++;
    for (int y = 0; y <= 100; y++) {                          /* iki merdiven aynı */
        assert(strcmp(harf_adi(harf_indeksi(y, 60)), harf_notu(y, 60)) == 0);
    }
    sayac++;

    const double ort[] = {79.0, 46.8, 93.0, 54.0, 59.6};
    const double fin[] = {85, 48, 95, 70, 58};
    int sayaclar[HARF_SAYISI];
    harf_dagilimi(ort, fin, 5, sayaclar);
    int toplam = 0;
    for (int k = 0; k < HARF_SAYISI; k++) {
        toplam += sayaclar[k];
    }
    assert(toplam == 5); sayac++;                             /* her öğrenci bir kez */
    assert(sayaclar[0] == 1 && sayaclar[2] == 1 && sayaclar[4] == 1
           && sayaclar[5] == 1 && sayaclar[8] == 1); sayac++;
}

int main(void)
{
    kural_testleri();
    int kural = sayac;
    dizi_testleri();
    printf("Tüm testler geçti (%d doğrulama: %d kural + %d dizi).\n",
           sayac, kural, sayac - kural);
    return 0;
}

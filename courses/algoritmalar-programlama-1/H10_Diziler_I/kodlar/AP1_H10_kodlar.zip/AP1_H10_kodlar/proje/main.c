/* main.c — Mini-OBS v0.10 (AP-1 Hafta 10): menü döngüsü + paralel diziler
 * Kayıtlar dört paralel dizide tutulur: aynı indis aynı öğrenciye aittir
 * (no[i], vize[i], final[i], ort[i]); n dolu eleman sayısıdır.
 * Paralel dizilerin sınırlılığı (dört ayrı diziyi aynı tutma yükü) H14'te
 * struct Ogrenci ile çözülecek.
 * Derleme : make            (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c main.c
 *           gcc obs.o main.o -o mini_obs -lm
 */
#include <stdio.h>
#include "obs.h"

int main(void)
{
    long long no[AZAMI_OGRENCI];          /* paralel diziler */
    double vize[AZAMI_OGRENCI];
    double final[AZAMI_OGRENCI];
    double ort[AZAMI_OGRENCI];
    int n = 0;                            /* dolu eleman sayısı */
    int secim = 0;

    baslik_yaz();
    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }

        switch (secim) {
        case 1: {
            if (n == AZAMI_OGRENCI) {     /* sınırı aşmadan önce denetle */
                printf("  Kapasite dolu (%d öğrenci).\n", AZAMI_OGRENCI);
                break;
            }
            printf("\n------------ ÖĞRENCİ %d ------------\n", n + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            int bulunan = numara_bul(no, n, numara);
            if (bulunan != -1) {
                printf("  Bu numara zaten kayıtlı (sıra %d).\n", bulunan + 1);
                break;
            }
            double v = not_oku("Vize notu        : ");
            if (v < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            double f = not_oku("Final notu       : ");
            if (f < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }

            double o = hesapla_ortalama(v, f);
            ogrenci_raporu_yaz(numara, v, f, o, yuvarla(o));
            no[n] = numara;               /* dizilerin n. elemanına yaz */
            vize[n] = v;
            final[n] = f;
            ort[n] = o;
            n++;
            break;
        }
        case 2:
            istatistik_yaz(no, final, ort, n);
            break;
        case 3:
            kayitlari_listele(no, vize, final, ort, n);
            break;
        case 4:
            histogram_yaz(ort, final, n);
            break;
        case 5:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n", n);
            break;
        default:
            printf("  Geçersiz seçim: 1-5 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 5);

    return 0;
}

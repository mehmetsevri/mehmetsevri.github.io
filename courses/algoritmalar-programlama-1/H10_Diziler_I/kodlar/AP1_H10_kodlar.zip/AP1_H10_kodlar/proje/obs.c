/* obs.c — Mini-OBS v0.10 (AP-1 Hafta 10): modülün GERÇEKLEMESİ
 * Yenilik : Kayıtlar main.c'deki paralel dizilerde saklanır; bu modül
 *           dizileri boyutlarıyla (n) birlikte parametre olarak alır.
 *           v0.9'daki akış hâlindeki static istatistik değişkenleri
 *           kaldırıldı: veriler saklandığı için ortalama, standart sapma,
 *           en yüksek/en düşük, ortalama üstü sayısı ve harf dağılımı her
 *           istendiğinde dizilerden yeniden hesaplanır (iki geçiş).
 *           Menü: 1) Not girişi 2) İstatistikler 3) Listele 4) Histogram 5) Çıkış
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107), Madde 30: %40 vize + %60 final;
 *           final < 50 → FF; AA 90-100, BA 81-89, BB 73-80, CB 66-72,
 *           CC 60-65 başarılı; DC 50-59 şartlı (YANO ≥ 2,00 ise);
 *           DD 40-49, FD 30-39, FF 0-29 başarısız. Yuvarlama: (int)(ort + 0.5)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           (standart_sapma sqrt kullanır: bağlarken -lm)
 */
#include <stdio.h>
#include <math.h>     /* sqrt */
#include "obs.h"

/* ---- Kurallar: dosya kapsamında static const (yalnızca bu modül) ---- */
static const double VIZE_AGIRLIK = 0.40;
static const double FINAL_AGIRLIK = 0.60;
static const int GECME_ORTALAMA = 60;        /* CC ve üzeri: başarılı */
static const int SARTLI_ORTALAMA = 50;       /* DC: şartlı başarılı */
static const int FINAL_BARAJI = 50;          /* yarıyıl sonu sınavında en az 50 */

static const int SECENEK_SAYISI = 5;        /* menüdeki seçenek sayısı */

/* Girdi tamponunda satırın kalanını (satır sonu dahil) atar.
 * static fonksiyon: yalnızca bu dosyadan çağrılabilir (obs.h'de yok). */
static void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }
}

/* Ekrana program başlığını yazar. */
void baslik_yaz(void)
{
    printf("==========================================\n");
    printf("  MİNİ-OBS v0.10 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");
}

/* Ana menüyü ve seçim istemini yazar. */
void menu_goster(void)
{
    printf("\n---------------- ANA MENÜ ----------------\n");
    printf("  1) Not girişi (bir öğrenci)\n");
    printf("  2) Sınıf istatistikleri\n");
    printf("  3) Kayıtları listele\n");
    printf("  4) Harf notu dağılımı (histogram)\n");
    printf("  5) Çıkış\n");
    printf("Seçiminiz (1-5)  : ");
}

/* Son koşul: 1-SECENEK_SAYISI arası bir sayı girildiyse onu; sayı değilse ya da
 * aralık dışıysa 0'ı (geçersiz); girdi bittiyse -1'i döndürür. */
int menu_secimi_oku(void)
{
    int secim = 0;
    int okunan = scanf("%d", &secim);
    if (okunan == EOF) {
        return -1;
    }
    if (okunan == 0) {
        satir_temizle();
        return 0;
    }
    if (secim < 1 || secim > SECENEK_SAYISI) {
        return 0;
    }
    return secim;
}

/* Son koşul: pozitif bir öğrenci numarası döndürür; geçersiz girdide
 * yeniden sorar; girdi biterse -1 döndürür. */
long long numara_oku(void)
{
    long long numara = 0;
    int okunan;
    do {
        printf("Öğrenci numarası : ");
        okunan = scanf("%lld", &numara);
        if (okunan == EOF) {
            return -1;
        }
        if (okunan == 0) {
            satir_temizle();
            numara = 0;
        }
        if (numara <= 0) {
            printf("  Geçersiz: pozitif bir numara girin.\n");
        }
    } while (numara <= 0);
    return numara;
}

/* Ön koşul : etiket, ekrana yazılacak istem metnidir.
 * Son koşul: 0-100 aralığında bir not döndürür; geçersiz girdide yeniden
 *            sorar; girdi biterse -1.0 döndürür. (v0.7'de üç kez yazılan
 *            doğrulama bloğunun tek kopyası.) */
double not_oku(const char *etiket)
{
    double deger = -1.0;
    int okunan;
    do {
        printf("%s", etiket);
        okunan = scanf("%lf", &deger);
        if (okunan == EOF) {
            return -1.0;
        }
        if (okunan == 0) {
            satir_temizle();
            deger = -1.0;
        }
        if (deger < 0 || deger > 100) {
            printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
        }
    } while (deger < 0 || deger > 100);
    return deger;
}

/* Ön koşul : 0 <= vize, final <= 100.  Son koşul: %40 + %60 ağırlıklı ortalama. */
double hesapla_ortalama(double vize, double final)
{
    return VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
}

/* Ön koşul : ortalama >= 0.  Son koşul: en yakın tamsayı (.5 yukarı). */
int yuvarla(double ortalama)
{
    return (int)(ortalama + 0.5);
}

/* Son koşul: RTEÜ tablosuna göre harf notu; final barajın altındaysa "FF". */
const char *harf_notu(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "FF";
    } else if (yuvarlanmis >= 90) {
        return "AA";
    } else if (yuvarlanmis >= 81) {
        return "BA";
    } else if (yuvarlanmis >= 73) {
        return "BB";
    } else if (yuvarlanmis >= 66) {
        return "CB";
    } else if (yuvarlanmis >= 60) {
        return "CC";
    } else if (yuvarlanmis >= 50) {
        return "DC";
    } else if (yuvarlanmis >= 40) {
        return "DD";
    } else if (yuvarlanmis >= 30) {
        return "FD";
    }
    return "FF";
}

/* Son koşul: CC ve üzeri ve final barajı aşıldıysa true. */
bool gecti_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= GECME_ORTALAMA;
}

/* Son koşul: DC (50-59) ve final barajı aşıldıysa true. */
bool sartli_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= SARTLI_ORTALAMA
           && yuvarlanmis < GECME_ORTALAMA;
}

/* Son koşul: rapordaki "Durum" satırının metni. */
const char *durum_metni(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "BAŞARISIZ (final barajı)";
    } else if (gecti_mi(yuvarlanmis, final)) {
        return "BAŞARILI";
    } else if (sartli_mi(yuvarlanmis, final)) {
        return "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)";
    }
    return "BAŞARISIZ";
}

/* Bir öğrencinin raporunu v0.5 etiketleriyle yazar. */
void ogrenci_raporu_yaz(long long numara, double vize, double final,
                        double ortalama, int yuvarlanmis)
{
    printf("Öğrenci no  : %lld\n", numara);
    printf("Vize  (%%40) : %6.2f\n", vize);
    printf("Final (%%60) : %6.2f\n", final);
    printf("Ortalama    : %6.2f\n", ortalama);
    printf("Yuvarlanmış : %3d\n", yuvarlanmis);
    printf("Harf notu   : %s\n", harf_notu(yuvarlanmis, final));
    printf("Durum       : %s\n", durum_metni(yuvarlanmis, final));
}

/* Son koşul: harf notunun frekans dizisindeki indisi (AA=0 ... FF=8).
 * harf_notu() ile aynı merdiven; sayaç dizisinde "değer = indis". */
int harf_indeksi(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return 8;                                /* FF (baraj) */
    } else if (yuvarlanmis >= 90) {
        return 0;
    } else if (yuvarlanmis >= 81) {
        return 1;
    } else if (yuvarlanmis >= 73) {
        return 2;
    } else if (yuvarlanmis >= 66) {
        return 3;
    } else if (yuvarlanmis >= 60) {
        return 4;
    } else if (yuvarlanmis >= 50) {
        return 5;
    } else if (yuvarlanmis >= 40) {
        return 6;
    } else if (yuvarlanmis >= 30) {
        return 7;
    }
    return 8;
}

/* Ön koşul: 0 <= indeks < HARF_SAYISI.  Son koşul: harfin adı. */
const char *harf_adi(int indeks)
{
    switch (indeks) {
    case 0: return "AA";
    case 1: return "BA";
    case 2: return "BB";
    case 3: return "CB";
    case 4: return "CC";
    case 5: return "DC";
    case 6: return "DD";
    case 7: return "FD";
    default: return "FF";
    }
}

/* Doğrusal tarama: aranan numaranın ilk indisi; yoksa -1 (erken çıkış). */
int numara_bul(const long long no[], int n, long long aranan)
{
    for (int i = 0; i < n; i++) {
        if (no[i] == aranan) {
            return i;
        }
    }
    return -1;
}

/* Ön koşul: n >= 1.  Son koşul: a[0..n-1] ortalaması. */
double dizi_ortalama(const double a[], int n)
{
    double toplam = 0.0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
    }
    return toplam / n;
}

/* Ön koşul: n >= 1.  Son koşul: popülasyon standart sapması
 * sqrt( Σ (a[i] - μ)² / n ). İki geçiş: önce μ, sonra sapmalar. */
double standart_sapma(const double a[], int n)
{
    double mu = dizi_ortalama(a, n);
    double kare_toplam = 0.0;
    for (int i = 0; i < n; i++) {
        double fark = a[i] - mu;
        kare_toplam += fark * fark;
    }
    return sqrt(kare_toplam / n);
}

/* Ön koşul: n >= 1.  Son koşul: en büyük elemanın İLK indisi. */
int en_buyuk_indis(const double a[], int n)
{
    int enb = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] > a[enb]) {
            enb = i;
        }
    }
    return enb;
}

/* Ön koşul: n >= 1.  Son koşul: en küçük elemanın İLK indisi. */
int en_kucuk_indis(const double a[], int n)
{
    int enk = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] < a[enk]) {
            enk = i;
        }
    }
    return enk;
}

/* Son koşul: eşikten KESİN büyük eleman sayısı. */
int esik_ustu_say(const double a[], int n, double esik)
{
    int sayi = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] > esik) {
            sayi++;
        }
    }
    return sayi;
}

/* Son koşul: sayac[k] = k. harf notunu alan öğrenci sayısı (frekans dizisi).
 * sayac dizisi çağıranındır; fonksiyon onu doldurur (dizi adresle gider). */
void harf_dagilimi(const double ort[], const double final[], int n,
                   int sayac[HARF_SAYISI])
{
    for (int k = 0; k < HARF_SAYISI; k++) {
        sayac[k] = 0;
    }
    for (int i = 0; i < n; i++) {
        sayac[harf_indeksi(yuvarla(ort[i]), final[i])]++;
    }
}

/* Sınıf özetini yazar (v0.9 satırları + standart sapma + ortalama üstü). */
void istatistik_yaz(const long long no[], const double final[],
                    const double ort[], int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Not girişi.\n");
        return;
    }
    int basarili = 0, sartli = 0;
    for (int i = 0; i < n; i++) {
        int y = yuvarla(ort[i]);
        if (gecti_mi(y, final[i])) {
            basarili++;
        } else if (sartli_mi(y, final[i])) {
            sartli++;
        }
    }
    double ortalama = dizi_ortalama(ort, n);
    int enb = en_buyuk_indis(ort, n);
    int enk = en_kucuk_indis(ort, n);
    printf("\n--------------- SINIF ÖZETİ ---------------\n");
    printf("Öğrenci sayısı   : %d\n", n);
    printf("Sınıf ortalaması : %6.2f\n", ortalama);
    printf("Standart sapma   : %6.2f\n", standart_sapma(ort, n));
    printf("En yüksek        : %6.2f (%lld)\n", ort[enb], no[enb]);
    printf("En düşük         : %6.2f (%lld)\n", ort[enk], no[enk]);
    printf("Ortalama üstü    : %d / %d\n", esik_ustu_say(ort, n, ortalama), n);
    printf("Başarılı (CC+)   : %d / %d\n", basarili, n);
    printf("Şartlı (DC)      : %d / %d\n", sartli, n);
    printf("-------------------------------------------\n");
}

/* Bütün kayıtları tablo olarak yazar (paralel diziler: aynı i). */
void kayitlari_listele(const long long no[], const double vize[],
                       const double final[], const double ort[], int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Not girişi.\n");
        return;
    }
    printf("\n------------------- KAYITLAR -------------------\n");
    printf("Sıra  Öğrenci no    Vize   Final  Ortalama  Harf\n");
    for (int i = 0; i < n; i++) {
        printf("%4d  %10lld  %6.2f  %6.2f  %8.2f  %4s\n", i + 1, no[i],
               vize[i], final[i], ort[i], harf_notu(yuvarla(ort[i]), final[i]));
    }
    printf("------------------------------------------------\n");
}

/* Harf notu dağılımını yıldızlı histogram olarak yazar. */
void histogram_yaz(const double ort[], const double final[], int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Not girişi.\n");
        return;
    }
    int sayac[HARF_SAYISI];
    harf_dagilimi(ort, final, n, sayac);
    printf("\n----------- HARF NOTU DAĞILIMI -----------\n");
    for (int k = 0; k < HARF_SAYISI; k++) {
        printf("%s | ", harf_adi(k));
        for (int j = 0; j < sayac[k]; j++) {
            putchar('*');
        }
        printf("%s%d\n", sayac[k] > 0 ? " " : "", sayac[k]);
    }
    printf("------------------------------------------\n");
}

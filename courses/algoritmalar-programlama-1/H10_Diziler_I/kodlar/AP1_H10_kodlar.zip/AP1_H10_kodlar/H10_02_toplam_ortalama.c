/* H10_02_toplam_ortalama.c — Hafta 10 · Örnek 2 (★): toplam ve ortalama
 * Amaç   : İlk değer listesiyle bildirim; eleman sayısını derleyiciye
 *          hesaplatmak: sizeof(dizi) / sizeof(dizi[0]). H6'daki toplayıcı
 *          deseni artık bir dizinin elemanları üzerinde çalışır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_02_toplam_ortalama.c -o toplam_ortalama
 * Örnek  : -> Ortalama : 75.29
 */
#include <stdio.h>

int main(void)
{
    int notlar[] = {72, 85, 64, 90, 58, 77, 81};   /* boyut listeden: 7 */
    int n = (int)(sizeof(notlar) / sizeof(notlar[0]));

    int toplam = 0;                     /* toplayıcı: 0'dan başlar */
    for (int i = 0; i < n; i++) {
        toplam += notlar[i];
    }
    double ortalama = (double)toplam / n;           /* tamsayı bölmesi değil */

    printf("Dizinin boyutu: %zu bayt, eleman: %d\n", sizeof(notlar), n);
    printf("Toplam   : %d\n", toplam);
    printf("Ortalama : %.2f\n", ortalama);
    return 0;
}

/* H10_K15_fazla_ilk_deger.c — Hafta 10 · kavram: boyuttan fazla ilk değer
 * BU DOSYA KASITLI HATA İÇERİR: 3 elemanlı diziye 4 ilk değer verilmiştir.
 * Amaç   : Standart bunu bir kısıt ihlali sayar: derleyici bir TANI vermek
 *          zorundadır. GCC 13.3 (ve Clang 18) yalnızca UYARI verir, fazla
 *          değeri atar ve programı derler; -pedantic-errors ile aynı tanı
 *          HATA olur. Uyarıyı hata gibi ele alın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H10_K15_fazla_ilk_deger.c -o fazla_ilk_deger
 * Örnek  : -> sizeof(f) = 12 bayt (3 eleman): 1 2 3
 */
#include <stdio.h>

int main(void)
{
    int f[3] = {1, 2, 3, 4};            /* 4. değer fazla: atılır */
    printf("sizeof(f) = %zu bayt (%zu eleman): %d %d %d\n", sizeof(f),
           sizeof(f) / sizeof(f[0]), f[0], f[1], f[2]);
    return 0;
}

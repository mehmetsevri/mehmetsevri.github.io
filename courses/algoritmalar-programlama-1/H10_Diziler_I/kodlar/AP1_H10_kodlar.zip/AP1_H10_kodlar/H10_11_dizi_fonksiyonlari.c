/* H10_11_dizi_fonksiyonlari.c — Hafta 10 · Örnek 11 (★★): dizi fonksiyonları
 * Amaç   : Diziyi fonksiyona aktarmak: fonksiyona dizinin ADRESİ gider,
 *          boyut AYRI bir parametredir (int n). Diziyi yalnızca okuyan
 *          fonksiyonlar const ile işaretlenir: yanlışlıkla yazılırsa
 *          derleyici hata verir. dizi_oku ise diziyi doldurur (const yok).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_11_dizi_fonksiyonlari.c -o dizi_fonksiyonlari
 * Örnek  : girdi "6  12 7 25 3 25 9" -> Toplam = 81, en büyük = 25
 */
#include <stdio.h>
#include <stdbool.h>

#define KAPASITE 50

bool dizi_oku(int a[], int n);
void dizi_yazdir(const int a[], int n);
int dizi_toplam(const int a[], int n);
int dizi_max(const int a[], int n);

int main(void)
{
    int sayilar[KAPASITE];
    int n;

    printf("Kaç sayı (1-%d)? ", KAPASITE);
    if (scanf("%d", &n) != 1 || n < 1 || n > KAPASITE) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("%d sayı: ", n);
    if (!dizi_oku(sayilar, n)) {        /* dizinin adı = ilk elemanın adresi */
        printf("Geçersiz girdi.\n");
        return 1;
    }
    dizi_yazdir(sayilar, n);
    printf("Toplam = %d, en büyük = %d\n", dizi_toplam(sayilar, n),
           dizi_max(sayilar, n));
    return 0;
}

/* a[0..n-1]'e n tamsayı okur; hepsi okunduysa true döndürür. */
bool dizi_oku(int a[], int n)
{
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &a[i]) != 1) {
            return false;
        }
    }
    return true;
}

/* a[0..n-1]'i köşeli parantez içinde yazar; diziyi değiştirmez. */
void dizi_yazdir(const int a[], int n)
{
    printf("[");
    for (int i = 0; i < n; i++) {
        printf("%s%d", i > 0 ? ", " : "", a[i]);
    }
    printf("]\n");
}

/* Son koşul: a[0..n-1] elemanlarının toplamı (n = 0 için 0). */
int dizi_toplam(const int a[], int n)
{
    int toplam = 0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
    }
    return toplam;
}

/* Ön koşul: n >= 1.  Son koşul: en büyük elemanın DEĞERİ. */
int dizi_max(const int a[], int n)
{
    int enb = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] > enb) {
            enb = a[i];
        }
    }
    return enb;
}

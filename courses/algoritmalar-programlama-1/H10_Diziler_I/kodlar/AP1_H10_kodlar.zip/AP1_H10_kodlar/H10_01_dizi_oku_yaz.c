/* H10_01_dizi_oku_yaz.c — Hafta 10 · Örnek 1 (★): 5 elemanlı dizi oku-yazdır
 * Amaç   : İlk dizi: bildirim (int notlar[N]), indisle erişim (notlar[i])
 *          ve for döngüsüyle dolaşma. İndisler 0'dan N-1'e kadardır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_01_dizi_oku_yaz.c -o dizi_oku_yaz
 * Örnek  : girdi "72 85 64 90 58" -> notlar[4] =    58
 */
#include <stdio.h>

#define N 5                             /* eleman sayısı: tek yerde */

int main(void)
{
    int notlar[N];                      /* 5 int: notlar[0] .. notlar[4] */

    printf("%d not girin: ", N);
    for (int i = 0; i < N; i++) {
        if (scanf("%d", &notlar[i]) != 1) {   /* &: i. elemanın adresi */
            printf("Geçersiz girdi.\n");
            return 1;
        }
    }

    printf("Okunan dizi:\n");
    for (int i = 0; i < N; i++) {       /* i = 0, 1, 2, 3, 4 */
        printf("notlar[%d] = %5d\n", i, notlar[i]);
    }
    return 0;
}

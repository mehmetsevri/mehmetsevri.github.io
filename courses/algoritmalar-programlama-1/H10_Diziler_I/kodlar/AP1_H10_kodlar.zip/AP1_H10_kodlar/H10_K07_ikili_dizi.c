/* H10_K07_ikili_dizi.c — Hafta 10 · Kavram programı: tersten yazdırma
 *          sorununun DİZİLİ çözümü
 * Amaç   : H7'de (H07_10_onluk_ikili.c) ardışık 2'ye bölmenin kalanları
 *          ters sırada çıkıyordu; H9'da özyinelemeyle çözdük
 *          (H09_09_ikili_yazdir.c). Dizide çözüm: kalanları SAKLA, sonra
 *          diziyi sondan başa yazdır. int'in 32 bitine 32 elemanlık dizi
 *          yeter (negatif olmayan int en çok 31 bit).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_K07_ikili_dizi.c -o ikili_dizi
 * Örnek  : girdi "13" -> 13 (onluk) = 1101 (ikili), 4 bit
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Negatif olmayan bir tamsayı: ");
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int bitler[32];                     /* kalanların deposu */
    int adet = 0;
    int sayi = n;
    do {                                /* n = 0 için de bir bit: 0 */
        bitler[adet] = sayi % 2;        /* en sağdaki bit ilk gelir */
        adet++;
        sayi /= 2;
    } while (sayi > 0);

    printf("%d (onluk) = ", n);
    for (int i = adet - 1; i >= 0; i--) {   /* SONDAN BAŞA yazdır */
        printf("%d", bitler[i]);
    }
    printf(" (ikili), %d bit\n", adet);
    return 0;
}

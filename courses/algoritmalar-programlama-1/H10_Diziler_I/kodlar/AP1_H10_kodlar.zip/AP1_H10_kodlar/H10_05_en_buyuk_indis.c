/* H10_05_en_buyuk_indis.c — Hafta 10 · Örnek 5 (★★): en büyük ve indisi
 * Amaç   : Konum takibi: yalnızca değeri değil, İNDİSİ de saklamak.
 *          Başlangıç: ilk eleman (indis 0); ">" kullanıldığı için eşitlikte
 *          İLK indis kalır. En küçük için aynı desen "<" ile.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_05_en_buyuk_indis.c -o en_buyuk_indis
 * Örnek  : -> En büyük: 91 (indis 1, 2. sırada)
 */
#include <stdio.h>

int main(void)
{
    int puanlar[] = {64, 91, 77, 91, 58, 85};
    int n = (int)(sizeof(puanlar) / sizeof(puanlar[0]));

    int enb = 0;                        /* en büyüğün İNDİSİ */
    int enk = 0;                        /* en küçüğün İNDİSİ */
    for (int i = 1; i < n; i++) {       /* 0. eleman zaten aday */
        if (puanlar[i] > puanlar[enb]) {
            enb = i;
        }
        if (puanlar[i] < puanlar[enk]) {
            enk = i;
        }
    }
    printf("En büyük: %d (indis %d, %d. sırada)\n", puanlar[enb], enb, enb + 1);
    printf("En küçük: %d (indis %d, %d. sırada)\n", puanlar[enk], enk, enk + 1);
    return 0;
}

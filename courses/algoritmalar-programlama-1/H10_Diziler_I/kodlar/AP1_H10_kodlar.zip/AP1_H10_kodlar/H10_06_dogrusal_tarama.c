/* H10_06_dogrusal_tarama.c — Hafta 10 · Örnek 6 (★★): değer var mı, nerede?
 * Amaç   : Doğrusal tarama (linear search) deseni: baştan sona sırayla
 *          bak; İLK eşleşmede dur (erken çıkış, break). Bulunamazsa konum
 *          -1 kalır (geçerli indis olamayacak bir değer). Kaç
 *          karşılaştırma yapıldığı da sayılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_06_dogrusal_tarama.c -o dogrusal_tarama
 * Örnek  : girdi "1012" -> 1012 bulundu: indis 1 (2 karşılaştırma)
 */
#include <stdio.h>

int main(void)
{
    int numaralar[] = {1045, 1012, 1078, 1033, 1012, 1090};
    int n = (int)(sizeof(numaralar) / sizeof(numaralar[0]));

    int aranan;
    printf("Aranan numara: ");
    if (scanf("%d", &aranan) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int konum = -1;                     /* "bulunamadı" anlamında */
    int karsilastirma = 0;
    for (int i = 0; i < n; i++) {
        karsilastirma++;
        if (numaralar[i] == aranan) {
            konum = i;
            break;                      /* erken çıkış: ilk eşleşme yeter */
        }
    }

    if (konum != -1) {
        printf("%d bulundu: indis %d (%d karşılaştırma)\n", aranan, konum,
               karsilastirma);
    } else {
        printf("%d yok: konum = -1 (%d karşılaştırma)\n", aranan,
               karsilastirma);
    }
    return 0;
}

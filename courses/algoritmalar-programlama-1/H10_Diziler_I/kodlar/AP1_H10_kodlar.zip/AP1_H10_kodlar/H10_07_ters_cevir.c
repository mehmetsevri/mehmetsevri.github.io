/* H10_07_ters_cevir.c — Hafta 10 · Örnek 7 (★★): diziyi yerinde ters çevirme
 * Amaç   : İki uç tekniği: i baştan, j sondan başlar; a[i] ile a[j] takas
 *          edilir (gecici ile üç atama, H3), sonra i ileri, j geri gider;
 *          i < j olduğu sürece. Ek dizi gerekmez ("yerinde"). Tek eleman
 *          sayısında ortadaki eleman yerinde kalır. (H12'de işaretçilerle.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H10_07_ters_cevir.c -o ters_cevir
 * Örnek  : -> Sonra : 70 60 50 40 30 20 10
 */
#include <stdio.h>

int main(void)
{
    int a[] = {10, 20, 30, 40, 50, 60, 70};
    int n = (int)(sizeof(a) / sizeof(a[0]));

    printf("Önce  :");
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");

    int i = 0;                          /* sol uç */
    int j = n - 1;                      /* sağ uç */
    while (i < j) {                     /* uçlar ortada buluşana kadar */
        printf("  takas: a[%d]=%d <-> a[%d]=%d\n", i, a[i], j, a[j]);
        int gecici = a[i];              /* üç atamalı takas */
        a[i] = a[j];
        a[j] = gecici;
        i++;
        j--;
    }

    printf("Sonra :");
    for (int k = 0; k < n; k++) {
        printf(" %d", a[k]);
    }
    printf("\n");
    return 0;
}

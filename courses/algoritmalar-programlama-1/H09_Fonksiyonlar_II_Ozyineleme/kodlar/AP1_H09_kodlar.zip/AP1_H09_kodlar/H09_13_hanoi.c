/* H09_13_hanoi.c — Hafta 9 · Örnek 13 (★★★): Hanoi Kuleleri
 * Amaç   : n diski taşımayı n - 1 diski taşımaya indirgemek; hamleleri
 *          saymak ve en az hamle sayısının 2^n - 1 olduğunu doğrulamak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_13_hanoi.c -o hanoi
 * Örnek  : -> Toplam 7 hamle
 */
#include <stdio.h>

static long long hamle = 0;         /* yapılan hamle sayısı */

void hanoi(int n, char kaynak, char hedef, char yardimci, int yaz)
{
    if (n == 0) {                   /* temel durum: taşınacak disk yok */
        return;
    }
    hanoi(n - 1, kaynak, yardimci, hedef, yaz);   /* 1) üstteki n-1 disk */
    hamle++;                                      /* 2) en büyük disk */
    if (yaz) {
        printf("%2lld. hamle: disk %d  %c -> %c\n", hamle, n, kaynak, hedef);
    }
    hanoi(n - 1, yardimci, hedef, kaynak, yaz);   /* 3) n-1 disk üstüne */
}

int main(void)
{
    printf("3 disk, A -> C (yardımcı çubuk B):\n");
    hanoi(3, 'A', 'C', 'B', 1);
    printf("Toplam %lld hamle\n\n", hamle);
    printf(" n  sayılan hamle    2^n - 1\n");
    for (int n = 1; n <= 20; n++) {
        if (n > 10 && n % 5 != 0) {
            continue;               /* tabloyu kısa tut: 1..10, 15, 20 */
        }
        hamle = 0;
        hanoi(n, 'A', 'C', 'B', 0);
        printf("%2d %14lld %10lld\n", n, hamle, (1LL << n) - 1);
    }
    return 0;
}

/* H09_09_ikili_yazdir.c — Hafta 9 · Örnek 9 (★★): Onluktan ikiliye (özyinelemeli)
 * Amaç   : H07_10'daki "bitler ters sırada çıkıyor" sorununu dönüşte iş
 *          yaparak çözmek: önce üst bitleri yazdır, dönüşte kendi bitini yaz
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_09_ikili_yazdir.c -o ikili_yazdir
 * Örnek  : -> 13 = 1101 (ikili)
 */
#include <stdio.h>

void kalanlari_yaz(unsigned int n)  /* H07_10'un yöntemi: ardışık bölme */
{
    do {
        printf("%u", n % 2);        /* en düşük bit ÖNCE çıkar */
        n /= 2;
    } while (n > 0);
}

void ikili_yaz(unsigned int n)      /* özyinelemeli çözüm */
{
    if (n >= 2) {
        ikili_yaz(n / 2);           /* önce üst bitler */
    }
    printf("%u", n % 2);            /* dönüşte bu çerçevenin biti */
}

int main(void)
{
    unsigned int n = 13;
    printf("Kalanlar üretildikleri sırayla (H07_10): ");
    kalanlari_yaz(n);
    printf("  <- ters!\n");
    printf("%u = ", n);
    ikili_yaz(n);
    printf(" (ikili)\n");
    for (unsigned int k = 0; k <= 5; k++) {
        printf("%4u = ", k);
        ikili_yaz(k);
        printf("\n");
    }
    printf("%4u = ", 2026u);
    ikili_yaz(2026u);
    printf("\n");
    return 0;
}

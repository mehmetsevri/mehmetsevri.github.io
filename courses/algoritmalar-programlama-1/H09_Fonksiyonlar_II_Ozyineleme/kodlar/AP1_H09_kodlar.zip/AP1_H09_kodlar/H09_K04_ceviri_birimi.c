/* H09_K04_ceviri_birimi.c — Hafta 9 · Kavram programı: çeviri birimi
 * Amaç   : Önişlemcinin #include ile yaptığını ELLE göstermek: main.c'deki
 *          #include "matematik_util.h" satırının yerine başlığın metni
 *          yapıştırılmıştır. Derleyici main.c'yi tam olarak böyle görür.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K04_ceviri_birimi.c H09_04_cok_dosyali/matematik_util.c \
 *              -o ceviri_birimi
 * Örnek  : -> Modül fonksiyonları 3 kez çağrıldı.
 */
#include <stdio.h>
/* ---- #include "matematik_util.h" satırının yerine başlığın metni ---- */
/* matematik_util.h — Hafta 9 · Örnek 4 (★★): modülün ARAYÜZÜ
 * Yalnızca bildirimler: prototipler ve extern değişken bildirimi.
 * Tanımlar (gövdeler, bellek ayıran değişkenler) matematik_util.c'dedir.
 */
#ifndef MATEMATIK_UTIL_H            /* başlık koruyucusu (include guard) */
#define MATEMATIK_UTIL_H

extern const double PI_YAKLASIK;    /* bildirim: tanımı başka dosyada */

long long faktoriyel(int n);
int ebob(int a, int b);
double daire_alani(double r);
int cagri_sayisi(void);

#endif /* MATEMATIK_UTIL_H */
/* ---- başlığın sonu ---- */

int main(void)
{
    printf("10! = %lld\n", faktoriyel(10));
    printf("EBOB(84, 36) = %d\n", ebob(84, 36));
    printf("Yarıçapı 2 olan dairenin alanı = %.4f\n", daire_alani(2.0));
    printf("PI_YAKLASIK = %.5f (extern ile)\n", PI_YAKLASIK);
    printf("Modül fonksiyonları %d kez çağrıldı.\n", cagri_sayisi());
    /* cagri = 0;  → derlenmez: cagri, matematik_util.c'de static */
    return 0;
}

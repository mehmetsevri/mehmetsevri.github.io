/* H09_HA1_temel_durum_yok_duzeltilmis.c — Hafta 9 · Hata Avcısı 1 (düzeltilmiş)
 * Düzeltme: n <= 1 temel durumu eklendi; her çağrı n'yi 1 azalttığı için
 * temel duruma mutlaka ulaşılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA1_temel_durum_yok_duzeltilmis.c -o ha1d
 * Örnek  : -> 5! = 120
 */
#include <stdio.h>

long long faktoriyel(int n)
{
    if (n <= 1) {                   /* temel durum */
        return 1;
    }
    return n * faktoriyel(n - 1);
}

int main(void)
{
    printf("5! = %lld\n", faktoriyel(5));
    return 0;
}

/* H09_HA6_makro_yan_etki.c — Hafta 9 · Hata Avcısı 6 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: parantezli KARE makrosuna yan etkili bir
 * argüman (i++) veriliyor. Açılım ((i++) * (i++)) olur: aynı ifadede i iki
 * kez, aralarında sıralama olmadan değiştirilir → TANIMSIZ DAVRANIŞ.
 * Parantez bu sorunu ÇÖZMEZ. Bu dosya bilerek çalıştırılmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA6_makro_yan_etki.c -o ha6
 */
#include <stdio.h>

#define KARE(x) ((x) * (x))

int main(void)
{
    int i = 3;
    int sonuc = KARE(i++);          /* ((i++) * (i++)) */
    printf("sonuc = %d, i = %d\n", sonuc, i);
    return 0;
}

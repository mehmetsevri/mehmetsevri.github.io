/* H09_HA2_atlanan_temel_durum.c — Hafta 9 · Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: temel durum VAR ama tek sayılarda hiç
 * ulaşılmıyor: n = 7 → 5 → 3 → 1 → -1 → -3 ... (0 atlanır). Derleyici
 * uyarmaz; program yığın taşmasıyla çöker.
 * Amaç   : azalan_toplam(n) = n + (n - 2) + (n - 4) + ... (pozitif terimler)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA2_atlanan_temel_durum.c -o ha2
 */
#include <stdio.h>

int azalan_toplam(int n)
{
    if (n == 0) {                   /* yalnızca çift n bu duruma iner */
        return 0;
    }
    return n + azalan_toplam(n - 2);
}

int main(void)
{
    printf("azalan_toplam(10) = %d\n", azalan_toplam(10));
    printf("azalan_toplam(7)  = %d\n", azalan_toplam(7));
    return 0;
}

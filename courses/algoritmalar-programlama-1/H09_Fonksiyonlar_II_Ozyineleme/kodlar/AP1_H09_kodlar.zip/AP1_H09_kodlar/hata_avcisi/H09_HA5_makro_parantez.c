/* H09_HA5_makro_parantez.c — Hafta 9 · Hata Avcısı 5 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: FARK makrosunda ne argümanlar ne de bütün
 * ifade parantez içinde. Derleyici uyarmaz; sonuçlar sessizce yanlış.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA5_makro_parantez.c -o ha5
 */
#include <stdio.h>

#define FARK(a, b) a - b

int main(void)
{
    printf("FARK(10, 3 - 1) = %d  (beklenen 8)\n", FARK(10, 3 - 1));
    printf("2 * FARK(10, 4) = %d  (beklenen 12)\n", 2 * FARK(10, 4));
    return 0;
}

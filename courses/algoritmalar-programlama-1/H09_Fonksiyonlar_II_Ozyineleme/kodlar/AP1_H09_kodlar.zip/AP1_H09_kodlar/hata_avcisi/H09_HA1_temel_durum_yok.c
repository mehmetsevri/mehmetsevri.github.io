/* H09_HA1_temel_durum_yok.c — Hafta 9 · Hata Avcısı 1 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: özyinelemeli fonksiyonda temel durum yok;
 * her çağrı yeni bir çağrı yapar, yığın dolar ve program çöker.
 * GCC 12'den beri -Wall içindeki -Winfinite-recursion bunu uyarır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA1_temel_durum_yok.c -o ha1
 */
#include <stdio.h>

long long faktoriyel(int n)
{
    return n * faktoriyel(n - 1);   /* temel durum unutuldu! */
}

int main(void)
{
    printf("5! = %lld\n", faktoriyel(5));
    return 0;
}

/* H09_HA2_atlanan_temel_durum_duzeltilmis.c — Hafta 9 · Hata Avcısı 2 (düzeltilmiş)
 * Düzeltme: temel durum "n == 0" yerine "n <= 0": n her adımda 2 azaldığı
 * için er ya da geç 0 ya da -1 olur ve bu koşul mutlaka sağlanır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA2_atlanan_temel_durum_duzeltilmis.c -o ha2d
 * Örnek  : -> azalan_toplam(7)  = 16
 */
#include <stdio.h>

int azalan_toplam(int n)
{
    if (n <= 0) {                   /* hem çift hem tek n buraya iner */
        return 0;
    }
    return n + azalan_toplam(n - 2);
}

int main(void)
{
    printf("azalan_toplam(10) = %d\n", azalan_toplam(10));
    printf("azalan_toplam(7)  = %d\n", azalan_toplam(7));
    return 0;
}

/* sayac.h — Hafta 9 · Hata Avcısı 4 (düzeltilmiş)
 * Başlıkta yalnızca BİLDİRİM (extern); tanım tek bir .c dosyasında.
 */
#ifndef SAYAC_H
#define SAYAC_H

extern int toplam_cagri;            /* bildirim: bellek ayırmaz */

void say(void);

#endif /* SAYAC_H */

/* sayac.c — Hafta 9 · Hata Avcısı 4 (düzeltilmiş): modül
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -c sayac.c
 */
#include "sayac.h"

int toplam_cagri = 0;               /* TEK tanım: yalnızca burada */

void say(void)
{
    toplam_cagri++;
}

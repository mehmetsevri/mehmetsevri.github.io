/* main.c — Hafta 9 · Hata Avcısı 4 (düzeltilmiş): kullanan program
 * Değişiklik yok: düzeltme yalnızca sayac.h ve sayac.c'dedir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -c sayac.c
 *          gcc -std=c17 -Wall -Wextra -pedantic -g -c main.c
 *          gcc sayac.o main.o -o sayac
 * Örnek  : -> say() 2 kez çağrıldı.
 */
#include <stdio.h>
#include "sayac.h"

int main(void)
{
    say();
    say();
    printf("say() %d kez çağrıldı.\n", toplam_cagri);
    return 0;
}

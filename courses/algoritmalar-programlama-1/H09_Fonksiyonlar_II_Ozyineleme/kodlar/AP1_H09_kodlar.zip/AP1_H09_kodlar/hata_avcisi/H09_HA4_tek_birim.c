/* H09_HA4_tek_birim.c — Hafta 9 · Hata Avcısı 4: hatalı başlık, tek çeviri biriminde
 * sayac.h, sayac.c ve main.c TEK bir çeviri biriminde birleştirildi (her
 * #include "sayac.h" yerine başlığın metni). Tek birimde değişkenin yalnızca
 * bir tanımı olduğu için bu dosya sorunsuz derlenir ve çalışır: sorun,
 * aynı tanımı içeren İKİ nesne dosyasının bağlanmasındadır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA4_tek_birim.c -o tek_birim
 * Örnek  : -> say() 2 kez çağrıldı.
 */
#include <stdio.h>
/* ---- sayac.h ---- */
/* sayac.h — Hafta 9 · Hata Avcısı 4 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: başlık dosyasında bir değişken TANIMI var.
 * İki .c dosyası bu başlığı içerince her nesne dosyasında birer tanım olur.
 */
#ifndef SAYAC_H
#define SAYAC_H

int toplam_cagri = 0;               /* HATA: tanım başlıkta! */

void say(void);

#endif /* SAYAC_H */
/* ---- sayac.c ---- */
void say(void)
{
    toplam_cagri++;
}

/* ---- main.c ---- */
int main(void)
{
    say();
    say();
    printf("say() %d kez çağrıldı.\n", toplam_cagri);
    return 0;
}

/* H09_HA4_tek_birim_duzeltilmis.c — Hafta 9 · Hata Avcısı 4: düzeltilmiş başlık, tek çeviri biriminde
 * sayac.h, sayac.c ve main.c TEK bir çeviri biriminde birleştirildi (her
 * #include "sayac.h" yerine başlığın metni). Tek birimde değişkenin yalnızca
 * bir tanımı olduğu için bu dosya sorunsuz derlenir ve çalışır: sorun,
 * aynı tanımı içeren İKİ nesne dosyasının bağlanmasındadır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA4_tek_birim_duzeltilmis.c -o tek_birim
 * Örnek  : -> say() 2 kez çağrıldı.
 */
#include <stdio.h>
/* ---- sayac.h ---- */
/* sayac.h — Hafta 9 · Hata Avcısı 4 (düzeltilmiş)
 * Başlıkta yalnızca BİLDİRİM (extern); tanım tek bir .c dosyasında.
 */
#ifndef SAYAC_H
#define SAYAC_H

extern int toplam_cagri;            /* bildirim: bellek ayırmaz */

void say(void);

#endif /* SAYAC_H */
/* ---- sayac.c ---- */
int toplam_cagri = 0;               /* TEK tanım: yalnızca burada */

void say(void)
{
    toplam_cagri++;
}

/* ---- main.c ---- */
int main(void)
{
    say();
    say();
    printf("say() %d kez çağrıldı.\n", toplam_cagri);
    return 0;
}

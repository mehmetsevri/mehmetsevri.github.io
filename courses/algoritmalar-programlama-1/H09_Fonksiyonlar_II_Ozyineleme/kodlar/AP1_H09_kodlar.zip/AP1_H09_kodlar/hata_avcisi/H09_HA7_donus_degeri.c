/* H09_HA7_donus_degeri.c — Hafta 9 · Hata Avcısı 7 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: özyinelemeli çağrının sonucu kullanılmıyor
 * ve return unutulmuş. Fonksiyon değer döndürmeden sona erer; çağıranın bu
 * değeri kullanması TANIMSIZ DAVRANIŞTIR (sonuç derleyiciye göre değişir).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA7_donus_degeri.c -o ha7
 */
#include <stdio.h>

int basamak_toplami(int n)
{
    if (n < 10) {
        return n;
    }
    n % 10 + basamak_toplami(n / 10);   /* sonuç atılıyor, return yok! */
}

int ebob(int a, int b)
{
    if (b == 0) {
        return a;
    }
    ebob(b, a % b);                 /* return unutuldu! */
}

int main(void)
{
    printf("basamak_toplami(2026) = %d  (beklenen 10)\n", basamak_toplami(2026));
    printf("ebob(48, 18) = %d  (beklenen 6)\n", ebob(48, 18));
    return 0;
}

/* H09_HA3_global_sayac_duzeltilmis.c — Hafta 9 · Hata Avcısı 3 (düzeltilmiş)
 * Düzeltme: her döngü kendi yerel sayacını bildirir; bir fonksiyon
 * ötekinin değişkenine dokunamaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA3_global_sayac_duzeltilmis.c -o ha3d
 * Örnek  : -> Öğrenci 3
 */
#include <stdio.h>

void cizgi_ciz(void)
{
    for (int i = 0; i < 20; i++) {  /* yerel i: yalnızca bu döngüde */
        printf("-");
    }
    printf("\n");
}

int main(void)
{
    for (int i = 1; i <= 3; i++) {  /* main'in kendi i'si */
        printf("Öğrenci %d\n", i);
        cizgi_ciz();
    }
    return 0;
}

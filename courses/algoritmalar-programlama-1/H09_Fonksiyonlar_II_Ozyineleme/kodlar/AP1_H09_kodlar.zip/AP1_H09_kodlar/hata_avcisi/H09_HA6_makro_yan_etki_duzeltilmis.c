/* H09_HA6_makro_yan_etki_duzeltilmis.c — Hafta 9 · Hata Avcısı 6 (düzeltilmiş)
 * Düzeltme: yan etkili ifadeyi makroya vermeyin; artırmayı ayrı bir deyimde
 * yapın ya da argümanı bir kez hesaplayan bir FONKSİYON kullanın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA6_makro_yan_etki_duzeltilmis.c -o ha6d
 * Örnek  : -> kare(j++) = 9, j = 4
 */
#include <stdio.h>

#define KARE(x) ((x) * (x))

int kare(int x)                     /* argüman çağrıdan ÖNCE bir kez hesaplanır */
{
    return x * x;
}

int main(void)
{
    int i = 3;
    int sonuc = KARE(i);            /* önce kare al */
    i++;                            /* sonra ayrı deyimde artır */
    printf("KARE(i) = %d, i = %d\n", sonuc, i);
    int j = 3;
    int k = kare(j++);              /* fonksiyona j++ vermek güvenli */
    printf("kare(j++) = %d, j = %d\n", k, j);
    return 0;
}

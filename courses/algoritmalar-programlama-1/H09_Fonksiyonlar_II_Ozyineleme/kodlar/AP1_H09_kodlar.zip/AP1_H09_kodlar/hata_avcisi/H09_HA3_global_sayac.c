/* H09_HA3_global_sayac.c — Hafta 9 · Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: iki fonksiyon aynı GLOBAL döngü sayacını
 * paylaşıyor. cizgi_ciz() i'yi 20'ye çıkarınca main'deki döngü erken biter.
 * Beklenen: 3 öğrenci satırı. Derleyici uyarmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA3_global_sayac.c -o ha3
 */
#include <stdio.h>

int i;                              /* global sayaç: herkes değiştirebilir */

void cizgi_ciz(void)
{
    for (i = 0; i < 20; i++) {
        printf("-");
    }
    printf("\n");
}

int main(void)
{
    for (i = 1; i <= 3; i++) {
        printf("Öğrenci %d\n", i);
        cizgi_ciz();
    }
    return 0;
}

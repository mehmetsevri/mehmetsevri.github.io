/* H09_HA7_donus_degeri_duzeltilmis.c — Hafta 9 · Hata Avcısı 7 (düzeltilmiş)
 * Düzeltme: özyinelemeli çağrının sonucu return ile yukarı taşınır;
 * her çerçeve kendi payını ekleyip bir üst çerçeveye teslim eder.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA7_donus_degeri_duzeltilmis.c -o ha7d
 * Örnek  : -> ebob(48, 18) = 6  (beklenen 6)
 */
#include <stdio.h>

int basamak_toplami(int n)
{
    if (n < 10) {
        return n;
    }
    return n % 10 + basamak_toplami(n / 10);
}

int ebob(int a, int b)
{
    if (b == 0) {
        return a;
    }
    return ebob(b, a % b);
}

int main(void)
{
    printf("basamak_toplami(2026) = %d  (beklenen 10)\n", basamak_toplami(2026));
    printf("ebob(48, 18) = %d  (beklenen 6)\n", ebob(48, 18));
    return 0;
}

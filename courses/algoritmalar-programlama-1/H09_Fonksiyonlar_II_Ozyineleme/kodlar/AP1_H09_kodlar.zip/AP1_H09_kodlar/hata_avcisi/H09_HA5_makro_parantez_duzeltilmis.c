/* H09_HA5_makro_parantez_duzeltilmis.c — Hafta 9 · Hata Avcısı 5 (düzeltilmiş)
 * Düzeltme: her argüman ve bütün ifade parantez içinde.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_HA5_makro_parantez_duzeltilmis.c -o ha5d
 * Örnek  : -> 2 * FARK(10, 4) = 12  (beklenen 12)
 */
#include <stdio.h>

#define FARK(a, b) ((a) - (b))

int main(void)
{
    printf("FARK(10, 3 - 1) = %d  (beklenen 8)\n", FARK(10, 3 - 1));
    printf("2 * FARK(10, 4) = %d  (beklenen 12)\n", 2 * FARK(10, 4));
    return 0;
}

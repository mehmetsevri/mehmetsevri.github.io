/* main.c — Hafta 9 · Hata Avcısı 4 (hatalı sürüm): kullanan program
 * BU KLASÖR KASITLI HATA İÇERİR: iki dosya ayrı ayrı derlenir, bağlama
 * aşamasında "multiple definition" hatası çıkar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -c sayac.c
 *          gcc -std=c17 -Wall -Wextra -pedantic -g -c main.c
 *          gcc sayac.o main.o -o sayac
 */
#include <stdio.h>
#include "sayac.h"

int main(void)
{
    say();
    say();
    printf("say() %d kez çağrıldı.\n", toplam_cagri);
    return 0;
}

/* sayac.h — Hafta 9 · Hata Avcısı 4 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: başlık dosyasında bir değişken TANIMI var.
 * İki .c dosyası bu başlığı içerince her nesne dosyasında birer tanım olur.
 */
#ifndef SAYAC_H
#define SAYAC_H

int toplam_cagri = 0;               /* HATA: tanım başlıkta! */

void say(void);

#endif /* SAYAC_H */

/* sayac.c — Hafta 9 · Hata Avcısı 4 (hatalı sürüm): modül
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -c sayac.c
 */
#include "sayac.h"

void say(void)
{
    toplam_cagri++;
}

/* H09_K08_kuyruk_ozyineleme.c — Hafta 9 · Kavram programı: kuyruk özyinelemesi
 * Amaç   : Özyinelemeli çağrının fonksiyondaki SON iş olduğu (kuyruk) ve
 *          olmadığı iki faktöriyeli karşılaştırmak; gcc -O0 ve -O2'nin
 *          ürettiği makine kodunda call komutunu aramak
 * Assembly: gcc -std=c17 -O0 -S -masm=intel H09_K08_kuyruk_ozyineleme.c
 *           gcc -std=c17 -O2 -S -masm=intel H09_K08_kuyruk_ozyineleme.c
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K08_kuyruk_ozyineleme.c -o kuyruk
 * Örnek  : -> 20! = 2432902008176640000 = 2432902008176640000
 */
#include <stdio.h>

long long faktoriyel(int n)         /* kuyruk DEĞİL: çağrıdan sonra çarpma var */
{
    if (n <= 1) {
        return 1;
    }
    return n * faktoriyel(n - 1);
}

long long faktoriyel_kuyruk(int n, long long birikim)   /* kuyruk özyinelemesi */
{
    if (n <= 1) {
        return birikim;
    }
    return faktoriyel_kuyruk(n - 1, birikim * n);   /* son iş: çağrının kendisi */
}

int main(void)
{
    printf("20! = %lld = %lld\n", faktoriyel(20), faktoriyel_kuyruk(20, 1));
    return 0;
}

/* H09_07_toplam_us.c — Hafta 9 · Örnek 7 (★★): 1..N toplamı ve üs alma
 * Amaç   : Problemi kendisinin bir küçük örneğine indirgemek:
 *          toplam(n) = n + toplam(n - 1),  us_al(t, u) = t * us_al(t, u - 1)
 * Kısıt  : n >= 0, us >= 0
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_07_toplam_us.c -o toplam_us
 * Örnek  : -> toplam(100) = 5050  (formül: 5050)
 */
#include <stdio.h>

long long toplam(int n)
{
    if (n == 0) {                   /* temel durum: boş toplam */
        return 0;
    }
    return n + toplam(n - 1);       /* n + (1..n-1 toplamı) */
}

long long us_al(long long taban, int us)
{
    if (us == 0) {                  /* temel durum: x^0 = 1 */
        return 1;
    }
    return taban * us_al(taban, us - 1);
}

int main(void)
{
    for (int n = 0; n <= 4; n++) {
        printf("toplam(%d) = %lld\n", n, toplam(n));
    }
    printf("toplam(100) = %lld  (formül: %d)\n", toplam(100), 100 * 101 / 2);
    printf("us_al(2, 10) = %lld\n", us_al(2, 10));
    printf("us_al(3, 4)  = %lld\n", us_al(3, 4));
    printf("us_al(-2, 5) = %lld\n", us_al(-2, 5));
    printf("us_al(7, 0)  = %lld\n", us_al(7, 0));
    return 0;
}

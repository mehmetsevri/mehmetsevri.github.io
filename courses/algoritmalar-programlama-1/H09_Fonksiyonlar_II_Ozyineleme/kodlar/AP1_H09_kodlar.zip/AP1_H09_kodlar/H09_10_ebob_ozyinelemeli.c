/* H09_10_ebob_ozyinelemeli.c — Hafta 9 · Örnek 10 (★★): Özyinelemeli EBOB
 * Amaç   : Öklid algoritmasını tanımına en yakın biçimde yazmak:
 *          ebob(a, 0) = a,  ebob(a, b) = ebob(b, a % b)
 * Kısıt  : a >= 0, b >= 0, ikisi birden 0 değil
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_10_ebob_ozyinelemeli.c -o ebob_ozyinelemeli
 * Örnek  : -> EBOB(1071, 462) = 21
 */
#include <stdio.h>

int ebob(int a, int b)
{
    printf("  ebob(%d, %d)\n", a, b);  /* her çağrıyı göster */
    if (b == 0) {                   /* temel durum */
        return a;
    }
    return ebob(b, a % b);          /* özyinelemeli adım: b kesin küçülür */
}

int main(void)
{
    int sonuc = ebob(48, 18);
    printf("EBOB(48, 18) = %d\n", sonuc);
    sonuc = ebob(1071, 462);
    printf("EBOB(1071, 462) = %d\n", sonuc);
    sonuc = ebob(18, 48);
    printf("EBOB(18, 48) = %d\n", sonuc);
    return 0;
}

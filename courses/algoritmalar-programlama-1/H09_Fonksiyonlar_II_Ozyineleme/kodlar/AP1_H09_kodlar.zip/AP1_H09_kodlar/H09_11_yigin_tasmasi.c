/* H09_11_yigin_tasmasi.c — Hafta 9 · Örnek 11 (★★): Yığın taşması gözlemi
 * Amaç   : Temel duruma hiç ulaşılmazsa her çağrının yığında açtığı
 *          çerçevelerin yığını doldurduğunu ve programın çöktüğünü görmek
 * UYARI  : Hedef -1 girilirse program BİLEREK çöker (Segmentation fault).
 *          -O0 ile derleyin (varsayılan); -O2 özyinelemeyi döngüye çevirebilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_11_yigin_tasmasi.c -o yigin_tasmasi
 *          (daha sık ilerleme raporu için: -DARALIK=1000)
 * Örnek  : girdi "50000" -> Temel duruma ulaşıldı: 50000 çağrı
 */
#include <stdio.h>

#ifndef ARALIK
#define ARALIK 10000                /* kaç çağrıda bir rapor yazılsın */
#endif

long dal(long derinlik, long hedef)
{
    if (derinlik == hedef) {        /* temel durum: hedef derinlik */
        return derinlik;
    }
    if (derinlik % ARALIK == 0) {
        printf("derinlik %ld\n", derinlik);
        fflush(stdout);             /* çökmeden önce çıktı kaybolmasın */
    }
    return dal(derinlik + 1, hedef);
}

int main(void)
{
    long hedef;
    printf("Hedef derinlik (-1: hiç ulaşılamaz): ");
    if (scanf("%ld", &hedef) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("\n");
    long ulasilan = dal(1, hedef);
    printf("Temel duruma ulaşıldı: %ld çağrı\n", ulasilan);
    return 0;
}

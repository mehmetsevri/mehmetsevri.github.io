/* H09_K10_hanoi_64.c — Hafta 9 · Kavram programı: 64 diskin bedeli
 * Amaç   : Efsanedeki 64 disk için en az hamle sayısını hesaplamak (Örnek 13'te
 *          sayarak doğruladığımız kural: bir disk eklemek hamleyi 2 katına
 *          çıkarıp 1 ekler) ve saniyede bir hamleyle gereken süreyi bulmak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K10_hanoi_64.c -o hanoi_64
 * Örnek  : -> 64 disk için en az hamle: 18446744073709551615
 */
#include <stdio.h>

int main(void)
{
    unsigned long long hamle = 0;   /* 0 disk: 0 hamle */
    for (int n = 1; n <= 64; n++) {
        hamle = 2 * hamle + 1;      /* n-1 disk + 1 hamle + n-1 disk */
    }
    printf("64 disk için en az hamle: %llu\n", hamle);

    double yil_saniye = 365.25 * 24 * 60 * 60;   /* Jülyen yılı: 31 557 600 s */
    double yil = (double)hamle / yil_saniye;
    printf("Saniyede 1 hamleyle süre: %.4e yıl\n", yil);

    double evren_yasi = 13.8e9;     /* evrenin yaşı ≈ 13,8 milyar yıl */
    printf("Evrenin yaşının yaklaşık %.1f katı\n", yil / evren_yasi);
    return 0;
}

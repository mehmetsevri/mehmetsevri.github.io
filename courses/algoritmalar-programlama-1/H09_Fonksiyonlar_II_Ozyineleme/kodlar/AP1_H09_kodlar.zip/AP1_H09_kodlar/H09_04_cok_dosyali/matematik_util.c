/* matematik_util.c — Hafta 9 · Örnek 4 (★★): modülün GERÇEKLEMESİ
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -c matematik_util.c
 */
#include "matematik_util.h"         /* kendi başlığı: bildirim–tanım uyumu */

const double PI_YAKLASIK = 3.14159265358979;  /* extern'in tanımı */

static int cagri = 0;               /* dosya kapsamı + static: iç bağlantı */

long long faktoriyel(int n)
{
    cagri++;
    long long sonuc = 1;
    for (int i = 2; i <= n; i++) {
        sonuc *= i;
    }
    return sonuc;
}

int ebob(int a, int b)
{
    cagri++;
    while (b != 0) {
        int kalan = a % b;
        a = b;
        b = kalan;
    }
    return a;
}

double daire_alani(double r)
{
    cagri++;
    return PI_YAKLASIK * r * r;
}

int cagri_sayisi(void)              /* cagri'ya dışarıdan tek erişim yolu */
{
    return cagri;
}

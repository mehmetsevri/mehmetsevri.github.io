/* main.c — Hafta 9 · Örnek 4 (★★): modülü KULLANAN program
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -c matematik_util.c
 *          gcc -std=c17 -Wall -Wextra -pedantic -g -c main.c
 *          gcc matematik_util.o main.o -o hesap
 * Örnek  : -> Modül fonksiyonları 3 kez çağrıldı.
 */
#include <stdio.h>
#include "matematik_util.h"

int main(void)
{
    printf("10! = %lld\n", faktoriyel(10));
    printf("EBOB(84, 36) = %d\n", ebob(84, 36));
    printf("Yarıçapı 2 olan dairenin alanı = %.4f\n", daire_alani(2.0));
    printf("PI_YAKLASIK = %.5f (extern ile)\n", PI_YAKLASIK);
    printf("Modül fonksiyonları %d kez çağrıldı.\n", cagri_sayisi());
    /* cagri = 0;  → derlenmez: cagri, matematik_util.c'de static */
    return 0;
}

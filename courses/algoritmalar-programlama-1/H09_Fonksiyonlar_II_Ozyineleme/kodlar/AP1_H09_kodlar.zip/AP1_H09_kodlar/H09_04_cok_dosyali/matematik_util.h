/* matematik_util.h — Hafta 9 · Örnek 4 (★★): modülün ARAYÜZÜ
 * Yalnızca bildirimler: prototipler ve extern değişken bildirimi.
 * Tanımlar (gövdeler, bellek ayıran değişkenler) matematik_util.c'dedir.
 */
#ifndef MATEMATIK_UTIL_H            /* başlık koruyucusu (include guard) */
#define MATEMATIK_UTIL_H

extern const double PI_YAKLASIK;    /* bildirim: tanımı başka dosyada */

long long faktoriyel(int n);
int ebob(int a, int b);
double daire_alani(double r);
int cagri_sayisi(void);

#endif /* MATEMATIK_UTIL_H */

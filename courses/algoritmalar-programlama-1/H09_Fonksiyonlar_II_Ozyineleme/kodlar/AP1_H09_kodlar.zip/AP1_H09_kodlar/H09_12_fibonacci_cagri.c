/* H09_12_fibonacci_cagri.c — Hafta 9 · Örnek 12 (★★★): Fibonacci'nin bedeli
 * Amaç   : Özyinelemeli fib(n)'nin kaç kez çağrıldığını static sayaçla
 *          ölçmek; süresini clock() ile yinelemeli sürümle karşılaştırmak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_12_fibonacci_cagri.c -o fibonacci_cagri
 * Not    : Süreler makineye ve ana göre değişir; çağrı sayıları değişmez.
 * Örnek  : -> 35    9227465       29860703
 */
#include <stdio.h>
#include <time.h>

static long long cagri = 0;         /* fib kaç kez çağrıldı? */

long long fib(int n)                /* özyinelemeli: tanımın birebir kopyası */
{
    cagri++;
    if (n < 2) {                    /* iki temel durum: fib(0) = 0, fib(1) = 1 */
        return n;
    }
    return fib(n - 1) + fib(n - 2);
}

long long fib_dongu(int n)          /* yinelemeli: her değeri bir kez hesaplar */
{
    long long onceki = 0, simdiki = 1;
    for (int i = 0; i < n; i++) {
        long long sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
    }
    return onceki;
}

void olc(int n)
{
    cagri = 0;
    clock_t t0 = clock();
    long long f = fib(n);
    double ms = 1000.0 * (double)(clock() - t0) / CLOCKS_PER_SEC;
    t0 = clock();
    long long g = fib_dongu(n);
    double ms2 = 1000.0 * (double)(clock() - t0) / CLOCKS_PER_SEC;
    printf("%3d %10lld %14lld %10.1f ms %8.3f ms  %s\n", n, f, cagri, ms, ms2,
           f == g ? "aynı" : "FARKLI!");
}

int main(void)
{
    printf("  n     fib(n)   çağrı sayısı  özyinelemeli       döngü  sonuç\n");
    olc(5);
    olc(10);
    olc(20);
    olc(30);
    olc(35);
    olc(40);
    return 0;
}

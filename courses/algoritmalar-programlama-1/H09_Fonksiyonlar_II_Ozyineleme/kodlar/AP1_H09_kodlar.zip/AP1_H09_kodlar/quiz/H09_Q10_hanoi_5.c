/* H09_Q10_hanoi_5.c — Hafta 9 · Quiz 7 (Hanoi hamle sayısı)
 * Soru   : 5 diskli Hanoi Kuleleri en az kaç hamlede çözülür?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q10_hanoi_5.c -o q10
 */
#include <stdio.h>

long long hamle_sayisi(int n)
{
    if (n == 0) {
        return 0;
    }
    return 2 * hamle_sayisi(n - 1) + 1;
}

int main(void)
{
    printf("5 disk: %lld hamle\n", hamle_sayisi(5));
    return 0;
}

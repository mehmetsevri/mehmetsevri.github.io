/* H09_Q01_prototip.c — Hafta 9 · Geçen haftadan S1 (H8: prototip)
 * Soru   : Program ne yazdırır? Prototip satırı silinirse ne olur?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q01_prototip.c -o q01
 */
#include <stdio.h>

int kup(int x);                     /* prototip (bildirim) */

int main(void)
{
    printf("kup(3) = %d\n", kup(3));
    return 0;
}

int kup(int x)                      /* tanım main'den SONRA */
{
    return x * x * x;
}

/* H09_Q09_sonlanma.c — Hafta 9 · Quiz 6 (temel duruma yaklaşma)
 * Soru   : g(n) hangi n değerleri için sonlanır? (programda g(7) çağrılıyor)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q09_sonlanma.c -o q09
 */
#include <stdio.h>

int g(int n)
{
    if (n == 1) {
        return 1;
    }
    return g(n - 2) + 1;
}

int main(void)
{
    printf("g(7) = %d\n", g(7));
    return 0;
}

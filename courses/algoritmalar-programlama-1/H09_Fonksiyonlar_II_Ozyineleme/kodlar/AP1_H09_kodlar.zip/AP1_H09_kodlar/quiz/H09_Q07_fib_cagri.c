/* H09_Q07_fib_cagri.c — Hafta 9 · Quiz 4 (özyineleme ağacı)
 * Soru   : fib(5) hesaplanırken fib fonksiyonu toplam kaç kez çağrılır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q07_fib_cagri.c -o q07
 */
#include <stdio.h>

int cagri = 0;

int fib(int n)
{
    cagri++;
    if (n < 2) {
        return n;
    }
    return fib(n - 1) + fib(n - 2);
}

int main(void)
{
    int sonuc = fib(5);
    printf("fib(5) = %d, çağrı = %d\n", sonuc, cagri);
    return 0;
}

/* H09_Q03_assert.c — Hafta 9 · Geçen haftadan S3 (H8: assert)
 * Soru   : Program ne yazdırır? Hangi satırda durur?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q03_assert.c -o q03
 */
#include <assert.h>
#include <stdio.h>

int mutlak(int x)
{
    if (x < 0) {
        return -x;
    }
    return x;
}

int main(void)
{
    assert(mutlak(-5) == 5);
    assert(mutlak(0) == 0);
    assert(mutlak(7) == -7);
    printf("Tüm testler geçti.\n");
    return 0;
}

/* H09_Q02_takas.c — Hafta 9 · Geçen haftadan S2 (H8: değerle aktarım)
 * Soru   : Program ne yazdırır? Neden?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q02_takas.c -o q02
 */
#include <stdio.h>

void takas(int a, int b)
{
    int gecici = a;
    a = b;
    b = gecici;
}

int main(void)
{
    int x = 1, y = 2;
    takas(x, y);
    printf("x = %d, y = %d\n", x, y);
    return 0;
}

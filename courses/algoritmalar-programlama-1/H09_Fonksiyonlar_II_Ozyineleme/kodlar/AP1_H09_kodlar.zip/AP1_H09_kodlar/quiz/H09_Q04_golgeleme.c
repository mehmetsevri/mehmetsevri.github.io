/* H09_Q04_golgeleme.c — Hafta 9 · Quiz 1 (kapsam ve gölgeleme)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q04_golgeleme.c -o q04
 */
#include <stdio.h>

int a = 5;

int main(void)
{
    int a = 1;
    {
        int a = 2;
        a = a + 10;
    }
    a = a + 100;
    printf("%d\n", a);
    return 0;
}

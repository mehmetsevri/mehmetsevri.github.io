/* H09_Q08_iki_kati.c — Hafta 9 · Quiz 5 (makro açılımı)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q08_iki_kati.c -o q08
 */
#include <stdio.h>

#define IKI_KATI(x) x + x

int main(void)
{
    printf("%d\n", 3 * IKI_KATI(2));
    return 0;
}

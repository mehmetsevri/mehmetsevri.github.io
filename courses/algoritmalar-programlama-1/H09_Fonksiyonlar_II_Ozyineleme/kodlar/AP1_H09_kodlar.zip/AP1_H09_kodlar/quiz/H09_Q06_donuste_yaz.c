/* H09_Q06_donuste_yaz.c — Hafta 9 · Quiz 3 (dönüşte iş yapma)
 * Soru   : f(3) ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q06_donuste_yaz.c -o q06
 */
#include <stdio.h>

void f(int n)
{
    if (n == 0) {
        return;
    }
    f(n - 1);
    printf("%d ", n);
}

int main(void)
{
    f(3);
    printf("\n");
    return 0;
}

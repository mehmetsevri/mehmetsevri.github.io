/* H09_Q05_static_cagri.c — Hafta 9 · Quiz 2 (static yerel değişken)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_Q05_static_cagri.c -o q05
 */
#include <stdio.h>

int sonraki(void)
{
    static int n = 10;
    int k = 0;
    n = n + 5;
    k = k + 1;
    return n + k;
}

int main(void)
{
    sonraki();
    sonraki();
    printf("%d\n", sonraki());
    return 0;
}

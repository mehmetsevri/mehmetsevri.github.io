/* H09_K07_faktoriyel_saf.c — Hafta 9 · Kavram programı: iki faktöriyel
 * Amaç   : Aynı işin yinelemeli (H08_05) ve özyinelemeli yazılışı; özyinelemeli
 *          sürümün makine kodunda kendini çağırdığını (call) görmek
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K07_faktoriyel_saf.c -o faktoriyel_saf
 * Assembly: gcc -std=c17 -O0 -S -masm=intel H09_K07_faktoriyel_saf.c
 * Örnek  : -> 10! = 3628800 = 3628800
 */
#include <stdio.h>

long long faktoriyel_dongu(int n)   /* yinelemeli: döngü + biriktirici */
{
    long long sonuc = 1;
    for (int i = 2; i <= n; i++) {
        sonuc *= i;
    }
    return sonuc;
}

long long faktoriyel(int n)         /* özyinelemeli: tanımın kendisi */
{
    if (n <= 1) {                   /* temel durum: 0! = 1! = 1 */
        return 1;
    }
    return n * faktoriyel(n - 1);   /* n! = n · (n-1)! */
}

int main(void)
{
    for (int n = 0; n <= 20; n += 5) {
        printf("%2d! = %lld = %lld\n", n, faktoriyel_dongu(n), faktoriyel(n));
    }
    return 0;
}

/* H09_K02_bellek_duzeni.c — Hafta 9 · Kavram programı: süreç bellek düzeni
 * Amaç   : Kod (text), ilk değerli veri (data), ilk değersiz veri (bss),
 *          öbek (heap; malloc ayrıntısı H12) ve yığın (stack) bölgelerindeki
 *          nesnelerin adreslerini %p ile yazdırmak
 * Not    : Fonksiyon adresini void * türüne dönüştürmeyi ISO C GARANTİ ETMEZ
 *          (-pedantic uyarır); POSIX sistemlerde (Linux, macOS) çalışır. Bu
 *          yüzden o tek satır için uyarı bilinçli olarak kapatıldı.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K02_bellek_duzeni.c -o bellek_duzeni
 */
#include <stdio.h>
#include <stdlib.h>

int ilk_degerli = 42;               /* data: ilk değeri dosyada saklanır */
int ilk_degersiz;                   /* bss: program başında 0 yapılır */

void fonksiyon(void)                /* text: makine kodu */
{
}

int main(void)
{
    static int statik_yerel = 7;    /* data: static ömür */
    int yerel = 1;                  /* stack: otomatik ömür */
    int *obek = malloc(sizeof *obek);   /* heap: önizleme (H12) */
    if (obek == NULL) {
        return 1;
    }
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
    printf("text  fonksiyon     %p\n", (void *)fonksiyon);
#pragma GCC diagnostic pop
    printf("data  ilk_degerli   %p\n", (void *)&ilk_degerli);
    printf("data  statik_yerel  %p\n", (void *)&statik_yerel);
    printf("bss   ilk_degersiz  %p\n", (void *)&ilk_degersiz);
    printf("heap  *obek         %p\n", (void *)obek);
    printf("stack yerel         %p\n", (void *)&yerel);
    free(obek);
    return 0;
}

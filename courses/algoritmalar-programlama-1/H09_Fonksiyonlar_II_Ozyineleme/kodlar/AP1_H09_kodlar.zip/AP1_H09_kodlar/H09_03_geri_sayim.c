/* H09_03_geri_sayim.c — Hafta 9 · Örnek 3 (★): Özyinelemeli geri sayım
 * Amaç   : Kendini çağıran ilk fonksiyon: temel durum (n == 0) ve
 *          problemi küçülten özyinelemeli adım (geri_say(n - 1))
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_03_geri_sayim.c -o geri_sayim
 * Örnek  : -> Ateşle!
 */
#include <stdio.h>

void geri_say(int n)
{
    if (n == 0) {                   /* temel durum: artık çağrı yok */
        printf("Ateşle!\n");
        return;
    }
    printf("%d...\n", n);
    geri_say(n - 1);                /* özyinelemeli adım: n küçülüyor */
}

int main(void)
{
    geri_say(5);
    return 0;
}

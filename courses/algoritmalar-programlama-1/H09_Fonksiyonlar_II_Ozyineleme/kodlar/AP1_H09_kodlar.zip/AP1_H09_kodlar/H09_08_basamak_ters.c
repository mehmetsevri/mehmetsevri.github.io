/* H09_08_basamak_ters.c — Hafta 9 · Örnek 8 (★★): Basamaklar ve dönüşte iş
 * Amaç   : Basamak toplamını özyinelemeyle hesaplamak; bir sayıyı "önce yaz,
 *          sonra çağır" ile ters, "önce çağır, dönüşte yaz" ile düz yazdırmak
 * Kısıt  : n >= 0
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_08_basamak_ters.c -o basamak_ters
 * Örnek  : -> ters_yaz(2026): 6202
 */
#include <stdio.h>

int basamak_toplami(int n)
{
    if (n < 10) {                   /* temel durum: tek basamak */
        return n;
    }
    return n % 10 + basamak_toplami(n / 10);
}

void ters_yaz(int n)                /* İŞ ÖNCE: son basamak önce yazılır */
{
    printf("%d", n % 10);
    if (n >= 10) {
        ters_yaz(n / 10);
    }
}

void duz_yaz(int n)                 /* İŞ DÖNÜŞTE: ilk basamak önce yazılır */
{
    if (n >= 10) {
        duz_yaz(n / 10);
    }
    printf("%d", n % 10);
}

int main(void)
{
    int n = 2026;
    printf("basamak_toplami(%d) = %d\n", n, basamak_toplami(n));
    printf("ters_yaz(%d): ", n);
    ters_yaz(n);
    printf("\nduz_yaz(%d):  ", n);
    duz_yaz(n);
    printf("\nters_yaz(1230): ");
    ters_yaz(1230);
    printf("\n");
    return 0;
}

/* H09_A01_cikti_tahmini.c — Hafta 9 · Alıştırma 9.1 (★, çıktı tahmini)
 * Soru   : yaz(3) ne yazdırır? Önce çağrı yığınını çizin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_A01_cikti_tahmini.c -o a01
 */
#include <stdio.h>

void yaz(int n)
{
    if (n == 0) {
        printf("| ");
        return;
    }
    printf("%d ", n);
    yaz(n - 1);
    printf("%d ", n);
}

int main(void)
{
    yaz(3);
    printf("\n");
    return 0;
}

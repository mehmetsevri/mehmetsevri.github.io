/* H09_A05_parsons_bir_sayisi.c — Hafta 9 · Alıştırma 9.5 (★★, Parsons)
 * Görev  : Satırları, bir sayının ikili gösterimindeki 1 bitlerini sayan
 *          özyinelemeli fonksiyona dönüşecek biçimde sıralayın ve girintileyin.
 *          Bir satır fazladır. bir_sayisi(13) = 3 olmalı (13 = 1101).
 * tamamlanacak; bu hâliyle derlenmez
 */
#include <stdio.h>

    return (n % 2) + bir_sayisi(n / 2);
}
        return 0;
unsigned int bir_sayisi(unsigned int n)
    }
    return 1;
    if (n == 0) {
{

int main(void)
{
    printf("bir_sayisi(13) = %u\n", bir_sayisi(13));
    return 0;
}

/* H09_A06_kod_tamamla_basamaklar.c — Hafta 9 · Alıştırma 9.6 (★★, kod tamamla)
 * Görev  : Boşlukları doldurun: basamaklar aralarında boşlukla, soldan sağa
 *          yazılsın. Beklenen: 2026 -> "2 0 2 6", 7 -> "7".
 * tamamlanacak; bu hâliyle derlenmez
 */
#include <stdio.h>

void basamaklari_yaz(int n)
{
    if (n < ____) {
        printf("%d", n);
        return;
    }
    basamaklari_yaz(____);
    printf(" %d", ____);
}

int main(void)
{
    basamaklari_yaz(2026);
    printf("\n");
    basamaklari_yaz(7);
    printf("\n");
    return 0;
}

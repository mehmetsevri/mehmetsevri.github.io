/* H09_A02_static_kapsam.c — Hafta 9 · Alıştırma 9.2 (★★, çıktı tahmini)
 * Soru   : Program ne yazdırır? Her sayac'ın kapsamını ve ömrünü yazın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_A02_static_kapsam.c -o a02
 */
#include <stdio.h>

int sayac = 10;

int artir(void)
{
    static int sayac = 0;
    sayac += 5;
    return sayac;
}

int main(void)
{
    int a = artir();
    int b = artir();
    {
        int sayac = 1;
        printf("%d ", sayac);
    }
    printf("%d %d %d\n", a, b, sayac);
    return 0;
}

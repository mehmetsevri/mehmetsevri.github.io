/* H09_A04_hata_bul_basamak.c — Hafta 9 · Alıştırma 9.4 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: basamak sayısını özyinelemeyle bulan
 * fonksiyon 2026 için 4, -305 için 3 yazıyor ama bir sınır değerde yanlış.
 * Hangisi? Düzeltin. Derleyici uyarmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_A04_hata_bul_basamak.c -o a04
 */
#include <stdio.h>

int basamak_sayisi(int n)
{
    if (n == 0) {
        return 0;
    }
    return 1 + basamak_sayisi(n / 10);
}

int main(void)
{
    printf("2026 -> %d\n", basamak_sayisi(2026));
    printf("-305 -> %d\n", basamak_sayisi(-305));
    printf("7    -> %d\n", basamak_sayisi(7));
    printf("0    -> %d\n", basamak_sayisi(0));
    return 0;
}

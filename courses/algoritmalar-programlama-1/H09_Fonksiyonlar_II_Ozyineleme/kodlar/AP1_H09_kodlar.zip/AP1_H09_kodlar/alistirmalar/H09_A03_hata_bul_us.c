/* H09_A03_hata_bul_us.c — Hafta 9 · Alıştırma 9.3 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: us_al(2, 10) doğru çalışıyor ama
 * us_al(7, 0) programı çökertiyor. Neden? Düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H09_A03_hata_bul_us.c -o a03
 */
#include <stdio.h>

long long us_al(long long taban, int us)
{
    if (us == 1) {
        return taban;
    }
    return taban * us_al(taban, us - 1);
}

int main(void)
{
    long long taban;
    int us;
    printf("Taban ve üs: ");
    if (scanf("%lld %d", &taban, &us) != 2 || us < 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("%lld^%d = %lld\n", taban, us, us_al(taban, us));
    return 0;
}

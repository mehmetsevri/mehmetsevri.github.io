/* H09_K03_yigin_adresleri.c — Hafta 9 · Kavram programı: yığın aşağı büyür
 * Amaç   : Özyineleme derinleştikçe her çerçevedeki n parametresinin
 *          adresinin AZALDIĞINI görmek ve çerçeve başına bayt farkını ölçmek
 * Not    : Adresi tamsayıya çevirmek (uintptr_t) yalnızca farkı hesaplamak
 *          içindir; adreslerle aritmetik H12'nin konusudur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K03_yigin_adresleri.c -o yigin_adresleri
 */
#include <stdio.h>
#include <stdint.h>

static uintptr_t onceki = 0;        /* bir önceki çerçevedeki &n */

long long faktoriyel(int n)
{
    uintptr_t adres = (uintptr_t)&n;
    if (onceki == 0) {
        printf("faktoriyel(%d): &n = %p\n", n, (void *)&n);
    } else {
        printf("faktoriyel(%d): &n = %p  (%lu bayt aşağıda)\n", n,
               (void *)&n, (unsigned long)(onceki - adres));
    }
    onceki = adres;
    if (n <= 1) {
        return 1;
    }
    long long sonuc = n * faktoriyel(n - 1);
    return sonuc;
}

int main(void)
{
    int yerel = 0;
    printf("main          : &yerel = %p\n", (void *)&yerel);
    printf("4! = %lld\n", faktoriyel(4));
    return 0;
}

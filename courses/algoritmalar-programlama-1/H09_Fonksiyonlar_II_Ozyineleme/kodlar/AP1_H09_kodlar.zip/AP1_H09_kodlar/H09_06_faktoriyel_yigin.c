/* H09_06_faktoriyel_yigin.c — Hafta 9 · Örnek 6 (★★): Özyinelemeli faktöriyel
 * Amaç   : Çağrı yığınının push/pop sürecini ekranda izlemek: her çağrı
 *          girişte bir çerçeve açar (push), dönüşte kapatır (pop)
 * Kısıt  : 0 <= n <= 20 (20! long long'a sığan son değer)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_06_faktoriyel_yigin.c -o faktoriyel_yigin
 * Örnek  : -> 4! = 24
 */
#include <stdio.h>

static int derinlik = 0;            /* izleme için: açık çerçeve sayısı */

long long faktoriyel(int n)
{
    derinlik++;                     /* PUSH: yeni çerçeve */
    printf("%*s→ faktoriyel(%d) çağrıldı   [derinlik %d]\n",
           2 * derinlik, "", n, derinlik);
    long long sonuc;
    if (n <= 1) {
        sonuc = 1;                  /* temel durum */
    } else {
        sonuc = n * faktoriyel(n - 1);  /* özyinelemeli adım */
    }
    printf("%*s← faktoriyel(%d) = %lld döndü\n", 2 * derinlik, "", n, sonuc);
    derinlik--;                     /* POP: çerçeve kapanır */
    return sonuc;
}

int main(void)
{
    long long f = faktoriyel(4);
    printf("4! = %lld\n", f);
    return 0;
}

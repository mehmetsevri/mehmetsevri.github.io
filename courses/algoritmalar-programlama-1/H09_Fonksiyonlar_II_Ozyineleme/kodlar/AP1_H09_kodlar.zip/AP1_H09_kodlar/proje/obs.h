/* obs.h — Mini-OBS v0.9 (AP-1 Hafta 9): modülün ARAYÜZÜ
 * Yalnızca dışarıya açık fonksiyonların prototipleri. Kural sabitleri,
 * istatistik değişkenleri ve satir_temizle() obs.c içinde static'tir:
 * bu başlığı içeren hiçbir dosya onları göremez ve değiştiremez.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>

/* ---- ekran ve girdi ---- */
void baslik_yaz(void);
void menu_goster(void);
int menu_secimi_oku(void);
long long numara_oku(void);
double not_oku(const char *etiket);

/* ---- hesap kuralları (yan etkisiz, test edilebilir) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
void ogrenci_raporu_yaz(long long numara, double vize, double final,
                        double ortalama, int yuvarlanmis);

/* ---- istatistik modülü (durum obs.c'de static değişkenlerde) ---- */
void istatistik_sifirla(void);
void istatistik_ekle(long long numara, double ortalama, int yuvarlanmis,
                     double final);
void istatistik_yaz(void);
int kayit_sayisi(void);
int basarili_sayisi(void);
int sartli_sayisi(void);
double sinif_ortalamasi(void);

#endif /* OBS_H */

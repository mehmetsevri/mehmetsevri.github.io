/* test_obs.c — Mini-OBS v0.9 (AP-1 Hafta 9): birim testleri
 * v0.8'deki 37 assert doğrulaması + istatistik modülü için yeni testler.
 * v0.8'de testler -DOBS_TEST ile main'in yerine geçiyordu; artık ayrı bir
 * programdır ve obs.o ile bağlanır (main.c'ye hiç dokunmaz).
 * Derleme : make test       (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c test_obs.c
 *           gcc obs.o test_obs.o -o obs_test && ./obs_test
 */
#include <stdio.h>
#include <assert.h>
#include <string.h>   /* strcmp: metin karşılaştırmak için */
#include "obs.h"

static int sayac = 0;                /* geçen doğrulama sayısı (dosya kapsamı) */
static const double EPS = 1e-9;      /* kayan nokta toleransı */

/* v0.8'deki 37 kural testi (aynen) */
static void kural_testleri(void)
{
    /* hesapla_ortalama: kayan noktada == yerine tolerans */
    assert(hesapla_ortalama(70, 85) - 79.0 < EPS && 79.0 - hesapla_ortalama(70, 85) < EPS); sayac++;
    assert(hesapla_ortalama(0, 0) == 0.0); sayac++;
    assert(hesapla_ortalama(100, 100) - 100.0 < EPS && 100.0 - hesapla_ortalama(100, 100) < EPS); sayac++;

    /* yuvarla: .5 yukarı, altı aşağı */
    assert(yuvarla(59.5) == 60); sayac++;
    assert(yuvarla(59.4) == 59); sayac++;
    assert(yuvarla(0.0) == 0); sayac++;
    assert(yuvarla(100.0) == 100); sayac++;

    /* harf_notu: her kademenin iki sınırı ve baraj */
    assert(strcmp(harf_notu(100, 100), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(90, 90), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(89, 89), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(81, 81), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(80, 80), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(73, 73), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(72, 72), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(66, 66), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(65, 65), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(60, 60), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(59, 59), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(50, 50), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(49, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(40, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(39, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(30, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(29, 50), "FF") == 0); sayac++;
    assert(strcmp(harf_notu(95, 49.9), "FF") == 0); sayac++;   /* baraj */

    /* gecti_mi / sartli_mi */
    assert(gecti_mi(60, 50)); sayac++;
    assert(!gecti_mi(59, 80)); sayac++;
    assert(!gecti_mi(95, 49.9)); sayac++;
    assert(sartli_mi(50, 50)); sayac++;
    assert(sartli_mi(59, 60)); sayac++;
    assert(!sartli_mi(60, 60)); sayac++;
    assert(!sartli_mi(49, 60)); sayac++;
    assert(!sartli_mi(55, 45)); sayac++;

    /* durum_metni */
    assert(strcmp(durum_metni(79, 85), "BAŞARILI") == 0); sayac++;
    assert(strcmp(durum_metni(54, 70), "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)") == 0); sayac++;
    assert(strcmp(durum_metni(47, 48), "BAŞARISIZ (final barajı)") == 0); sayac++;
    assert(strcmp(durum_metni(45, 50), "BAŞARISIZ") == 0); sayac++;
}

/* Yeni: istatistik modülü (static durum) testleri */
static void istatistik_testleri(void)
{
    istatistik_sifirla();
    assert(kayit_sayisi() == 0); sayac++;
    assert(sinif_ortalamasi() == 0.0); sayac++;

    istatistik_ekle(2301010045, 79.0, 79, 85);   /* BB: başarılı */
    istatistik_ekle(2301010046, 46.8, 47, 48);   /* FF: final barajı */
    istatistik_ekle(2301010047, 54.0, 54, 60);   /* DC: şartlı */
    assert(kayit_sayisi() == 3); sayac++;
    assert(basarili_sayisi() == 1); sayac++;
    assert(sartli_sayisi() == 1); sayac++;
    double beklenen = (79.0 + 46.8 + 54.0) / 3;
    assert(sinif_ortalamasi() - beklenen < EPS && beklenen - sinif_ortalamasi() < EPS); sayac++;

    istatistik_sifirla();
    assert(kayit_sayisi() == 0); sayac++;
}

int main(void)
{
    kural_testleri();
    int kural = sayac;
    istatistik_testleri();
    printf("Tüm testler geçti (%d doğrulama: %d kural + %d istatistik).\n",
           sayac, kural, sayac - kural);
    return 0;
}

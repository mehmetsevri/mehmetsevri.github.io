/* obs.c — Mini-OBS v0.9 (AP-1 Hafta 9): modülün GERÇEKLEMESİ
 * Yenilik : v0.8'in davranışı AYNEN korunarak program üç dosyaya bölündü:
 *           obs.h (arayüz), obs.c (kurallar, girdi/rapor, istatistik),
 *           main.c (yalnızca menü döngüsü). Testler test_obs.c'dedir.
 *           Kural sabitleri ve istatistik değişkenleri dosya kapsamında
 *           static'tir (iç bağlantı): yalnızca bu modül görür. Böylece
 *           v0.8'deki sekiz parametreli istatistik_yaz(...) parametresiz
 *           istatistik_yaz(void) oldu; "static kayıt sayacı" kayit'tir.
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107), Madde 30: %40 vize + %60 final;
 *           final < 50 → FF; AA 90-100, BA 81-89, BB 73-80, CB 66-72,
 *           CC 60-65 başarılı; DC 50-59 şartlı (YANO ≥ 2,00 ise);
 *           DD 40-49, FD 30-39, FF 0-29 başarısız. Yuvarlama: (int)(ort + 0.5)
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 */
#include <stdio.h>
#include "obs.h"

/* ---- Kurallar: dosya kapsamında static const (yalnızca bu modül) ---- */
static const double VIZE_AGIRLIK = 0.40;
static const double FINAL_AGIRLIK = 0.60;
static const int GECME_ORTALAMA = 60;        /* CC ve üzeri: başarılı */
static const int SARTLI_ORTALAMA = 50;       /* DC: şartlı başarılı */
static const int FINAL_BARAJI = 50;          /* yarıyıl sonu sınavında en az 50 */

/* ---- İstatistik durumu: static ömür, iç bağlantı ---- */
static int kayit = 0;                        /* static kayıt sayacı */
static double toplam_ortalama = 0.0;
static int basarili = 0, sartli = 0;
static double en_yuksek = 0.0, en_dusuk = 0.0;
static long long en_yuksek_no = 0, en_dusuk_no = 0;

/* Girdi tamponunda satırın kalanını (satır sonu dahil) atar.
 * static fonksiyon: yalnızca bu dosyadan çağrılabilir (obs.h'de yok). */
static void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }
}

/* Ekrana program başlığını yazar. */
void baslik_yaz(void)
{
    printf("==========================================\n");
    printf("  MİNİ-OBS v0.9 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");
}

/* Ana menüyü ve seçim istemini yazar. */
void menu_goster(void)
{
    printf("\n---------------- ANA MENÜ ----------------\n");
    printf("  1) Not girişi (bir öğrenci)\n");
    printf("  2) Sınıf istatistikleri\n");
    printf("  3) Çıkış\n");
    printf("Seçiminiz (1-3)  : ");
}

/* Son koşul: 1-3 arası bir sayı girildiyse onu; sayı değilse ya da
 * aralık dışıysa 0'ı (geçersiz); girdi bittiyse -1'i döndürür. */
int menu_secimi_oku(void)
{
    int secim = 0;
    int okunan = scanf("%d", &secim);
    if (okunan == EOF) {
        return -1;
    }
    if (okunan == 0) {
        satir_temizle();
        return 0;
    }
    if (secim < 1 || secim > 3) {
        return 0;
    }
    return secim;
}

/* Son koşul: pozitif bir öğrenci numarası döndürür; geçersiz girdide
 * yeniden sorar; girdi biterse -1 döndürür. */
long long numara_oku(void)
{
    long long numara = 0;
    int okunan;
    do {
        printf("Öğrenci numarası : ");
        okunan = scanf("%lld", &numara);
        if (okunan == EOF) {
            return -1;
        }
        if (okunan == 0) {
            satir_temizle();
            numara = 0;
        }
        if (numara <= 0) {
            printf("  Geçersiz: pozitif bir numara girin.\n");
        }
    } while (numara <= 0);
    return numara;
}

/* Ön koşul : etiket, ekrana yazılacak istem metnidir.
 * Son koşul: 0-100 aralığında bir not döndürür; geçersiz girdide yeniden
 *            sorar; girdi biterse -1.0 döndürür. (v0.7'de üç kez yazılan
 *            doğrulama bloğunun tek kopyası.) */
double not_oku(const char *etiket)
{
    double deger = -1.0;
    int okunan;
    do {
        printf("%s", etiket);
        okunan = scanf("%lf", &deger);
        if (okunan == EOF) {
            return -1.0;
        }
        if (okunan == 0) {
            satir_temizle();
            deger = -1.0;
        }
        if (deger < 0 || deger > 100) {
            printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
        }
    } while (deger < 0 || deger > 100);
    return deger;
}

/* Ön koşul : 0 <= vize, final <= 100.  Son koşul: %40 + %60 ağırlıklı ortalama. */
double hesapla_ortalama(double vize, double final)
{
    return VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
}

/* Ön koşul : ortalama >= 0.  Son koşul: en yakın tamsayı (.5 yukarı). */
int yuvarla(double ortalama)
{
    return (int)(ortalama + 0.5);
}

/* Son koşul: RTEÜ tablosuna göre harf notu; final barajın altındaysa "FF". */
const char *harf_notu(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "FF";
    } else if (yuvarlanmis >= 90) {
        return "AA";
    } else if (yuvarlanmis >= 81) {
        return "BA";
    } else if (yuvarlanmis >= 73) {
        return "BB";
    } else if (yuvarlanmis >= 66) {
        return "CB";
    } else if (yuvarlanmis >= 60) {
        return "CC";
    } else if (yuvarlanmis >= 50) {
        return "DC";
    } else if (yuvarlanmis >= 40) {
        return "DD";
    } else if (yuvarlanmis >= 30) {
        return "FD";
    }
    return "FF";
}

/* Son koşul: CC ve üzeri ve final barajı aşıldıysa true. */
bool gecti_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= GECME_ORTALAMA;
}

/* Son koşul: DC (50-59) ve final barajı aşıldıysa true. */
bool sartli_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= SARTLI_ORTALAMA
           && yuvarlanmis < GECME_ORTALAMA;
}

/* Son koşul: rapordaki "Durum" satırının metni. */
const char *durum_metni(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "BAŞARISIZ (final barajı)";
    } else if (gecti_mi(yuvarlanmis, final)) {
        return "BAŞARILI";
    } else if (sartli_mi(yuvarlanmis, final)) {
        return "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)";
    }
    return "BAŞARISIZ";
}

/* Bir öğrencinin raporunu v0.5 etiketleriyle yazar. */
void ogrenci_raporu_yaz(long long numara, double vize, double final,
                        double ortalama, int yuvarlanmis)
{
    printf("Öğrenci no  : %lld\n", numara);
    printf("Vize  (%%40) : %6.2f\n", vize);
    printf("Final (%%60) : %6.2f\n", final);
    printf("Ortalama    : %6.2f\n", ortalama);
    printf("Yuvarlanmış : %3d\n", yuvarlanmis);
    printf("Harf notu   : %s\n", harf_notu(yuvarlanmis, final));
    printf("Durum       : %s\n", durum_metni(yuvarlanmis, final));
}

/* İstatistikleri başlangıç durumuna getirir (testler için). */
void istatistik_sifirla(void)
{
    kayit = 0;
    toplam_ortalama = 0.0;
    basarili = 0;
    sartli = 0;
    en_yuksek = 0.0;
    en_dusuk = 0.0;
    en_yuksek_no = 0;
    en_dusuk_no = 0;
}

/* Bir öğrencinin sonucunu akış hâlindeki istatistiklere ekler
 * (v0.8'de main içindeydi). */
void istatistik_ekle(long long numara, double ortalama, int yuvarlanmis,
                     double final)
{
    if (gecti_mi(yuvarlanmis, final)) {
        basarili++;
    } else if (sartli_mi(yuvarlanmis, final)) {
        sartli++;
    }
    kayit++;
    toplam_ortalama += ortalama;
    if (kayit == 1 || ortalama > en_yuksek) {
        en_yuksek = ortalama;
        en_yuksek_no = numara;
    }
    if (kayit == 1 || ortalama < en_dusuk) {
        en_dusuk = ortalama;
        en_dusuk_no = numara;
    }
}

/* Sınıf özetini yazar; kayıt yoksa uyarır. v0.8'deki sekiz parametre
 * gitti: veriler bu modülün static değişkenlerinde. */
void istatistik_yaz(void)
{
    if (kayit == 0) {
        printf("  Henüz kayıt yok: önce 1) Not girişi.\n");
        return;
    }
    printf("\n--------------- SINIF ÖZETİ ---------------\n");
    printf("Öğrenci sayısı   : %d\n", kayit);
    printf("Sınıf ortalaması : %6.2f\n", toplam_ortalama / kayit);
    printf("En yüksek        : %6.2f (%lld)\n", en_yuksek, en_yuksek_no);
    printf("En düşük         : %6.2f (%lld)\n", en_dusuk, en_dusuk_no);
    printf("Başarılı (CC+)   : %d / %d\n", basarili, kayit);
    printf("Şartlı (DC)      : %d / %d\n", sartli, kayit);
    printf("-------------------------------------------\n");
}

/* Erişim fonksiyonları: static verilere dışarıdan YALNIZCA okuma yolu. */
int kayit_sayisi(void)
{
    return kayit;
}

int basarili_sayisi(void)
{
    return basarili;
}

int sartli_sayisi(void)
{
    return sartli;
}

double sinif_ortalamasi(void)
{
    if (kayit == 0) {
        return 0.0;
    }
    return toplam_ortalama / kayit;
}

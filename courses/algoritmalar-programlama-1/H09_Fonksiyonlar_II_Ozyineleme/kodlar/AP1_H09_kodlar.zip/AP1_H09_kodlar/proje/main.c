/* main.c — Mini-OBS v0.9 (AP-1 Hafta 9): yalnızca menü döngüsü
 * Bütün kurallar, girdi/rapor fonksiyonları ve istatistikler obs.c'de;
 * main.c onlara yalnızca obs.h'deki arayüz üzerinden ulaşır.
 * Derleme : make            (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c main.c
 *           gcc obs.o main.o -o mini_obs
 */
#include <stdio.h>
#include "obs.h"

int main(void)
{
    int secim = 0;

    baslik_yaz();
    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }

        switch (secim) {
        case 1: {
            printf("\n------------ ÖĞRENCİ %d ------------\n", kayit_sayisi() + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            double vize = not_oku("Vize notu        : ");
            if (vize < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            double final = not_oku("Final notu       : ");
            if (final < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }

            double ortalama = hesapla_ortalama(vize, final);
            int yuvarlanmis = yuvarla(ortalama);
            ogrenci_raporu_yaz(numara, vize, final, ortalama, yuvarlanmis);
            istatistik_ekle(numara, ortalama, yuvarlanmis, final);
            break;
        }
        case 2:
            istatistik_yaz();
            break;
        case 3:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n",
                   kayit_sayisi());
            break;
        default:
            printf("  Geçersiz seçim: 1, 2 ya da 3 girin.\n");
            break;
        }
    } while (secim != 3);

    return 0;
}

/* H09_K05_cift_icerme.c — Hafta 9 · Kavram programı: başlık koruyucusu
 * Amaç   : Aynı başlık iki kez içerildiğinde koruyucunun ikinci kopyayı
 *          boşalttığını önişlemci çıktısında saymak (gcc -E)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -I H09_04_cok_dosyali \
 *              H09_K05_cift_icerme.c -o cift_icerme
 * İnceleme: gcc -E -I H09_04_cok_dosyali H09_K05_cift_icerme.c \
 *               | grep -c "faktoriyel(int n);"
 */
#include <stdio.h>
#include "matematik_util.h"
#include "matematik_util.h"         /* bilerek ikinci kez (dolaylı içermeyi taklit eder) */

int main(void)
{
    printf("Başlık iki kez içerildi; program yine derlendi.\n");
    return 0;
}

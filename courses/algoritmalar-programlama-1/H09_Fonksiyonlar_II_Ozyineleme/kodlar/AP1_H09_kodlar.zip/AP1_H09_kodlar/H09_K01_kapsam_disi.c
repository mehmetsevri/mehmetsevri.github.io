/* H09_K01_kapsam_disi.c — Hafta 9 · Kavram programı: kapsam dışı erişim
 * BU DOSYA KASITLI HATA İÇERİR: for başlığında bildirilen i ile iç blokta
 * bildirilen ara, kapsamları bittikten sonra kullanılıyor. Derlenmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K01_kapsam_disi.c -o kapsam_disi
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;
    for (int i = 1; i <= 3; i++) {
        toplam += i;
    }
    {
        int ara = toplam * 2;
        printf("ara = %d\n", ara);
    }
    printf("i = %d\n", i);          /* HATA: i'nin kapsamı for ile bitti */
    printf("ara = %d\n", ara);      /* HATA: ara'nın kapsamı blokla bitti */
    return 0;
}

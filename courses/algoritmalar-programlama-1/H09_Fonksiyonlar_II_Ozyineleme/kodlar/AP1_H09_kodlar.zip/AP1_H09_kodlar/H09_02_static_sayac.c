/* H09_02_static_sayac.c — Hafta 9 · Örnek 2 (★): static sayaç
 * Amaç   : Otomatik ömürlü yerel değişken ile static yerel değişkeni
 *          karşılaştırmak: fonksiyon kaç kez çağrıldı?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_02_static_sayac.c -o static_sayac
 * Örnek  : -> 4. çağrı: otomatik = 1, statik = 4
 */
#include <stdio.h>

void ziyaret(void)
{
    int otomatik = 0;               /* her çağrıda yeniden oluşur ve 0 olur */
    static int statik = 0;          /* program başında bir kez 0 olur */
    otomatik++;
    statik++;                       /* değeri çağrılar arasında korunur */
    printf("%d. çağrı: otomatik = %d, statik = %d\n", statik, otomatik, statik);
}

int main(void)
{
    for (int i = 0; i < 4; i++) {
        ziyaret();
    }
    /* statik = 0;  → derlenmez: statik yalnızca ziyaret() içinde görünür */
    return 0;
}

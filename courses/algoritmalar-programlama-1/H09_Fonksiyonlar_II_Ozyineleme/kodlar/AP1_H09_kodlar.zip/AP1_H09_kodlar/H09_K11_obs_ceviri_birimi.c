/* H09_K11_obs_ceviri_birimi.c — Hafta 9 · Kavram programı: Mini-OBS çeviri birimi
 * Amaç   : Mini-OBS v0.9'daki main.c'nin önişlemciden sonraki hâlini ELLE
 *          göstermek: #include "obs.h" yerine arayüzün metni yapıştırıldı.
 *          main.c obs.c'deki static değişkenleri yine GÖREMEZ: arayüzde yoklar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K11_obs_ceviri_birimi.c proje/obs.c -o obs_birim
 */
#include <stdio.h>
/* ---- #include "obs.h" satırının yerine başlığın metni ---- */
/* obs.h — Mini-OBS v0.9 (AP-1 Hafta 9): modülün ARAYÜZÜ
 * Yalnızca dışarıya açık fonksiyonların prototipleri. Kural sabitleri,
 * istatistik değişkenleri ve satir_temizle() obs.c içinde static'tir:
 * bu başlığı içeren hiçbir dosya onları göremez ve değiştiremez.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>

/* ---- ekran ve girdi ---- */
void baslik_yaz(void);
void menu_goster(void);
int menu_secimi_oku(void);
long long numara_oku(void);
double not_oku(const char *etiket);

/* ---- hesap kuralları (yan etkisiz, test edilebilir) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
void ogrenci_raporu_yaz(long long numara, double vize, double final,
                        double ortalama, int yuvarlanmis);

/* ---- istatistik modülü (durum obs.c'de static değişkenlerde) ---- */
void istatistik_sifirla(void);
void istatistik_ekle(long long numara, double ortalama, int yuvarlanmis,
                     double final);
void istatistik_yaz(void);
int kayit_sayisi(void);
int basarili_sayisi(void);
int sartli_sayisi(void);
double sinif_ortalamasi(void);

#endif /* OBS_H */
/* ---- başlığın sonu ---- */

int main(void)
{
    int secim = 0;

    baslik_yaz();
    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }

        switch (secim) {
        case 1: {
            printf("\n------------ ÖĞRENCİ %d ------------\n", kayit_sayisi() + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            double vize = not_oku("Vize notu        : ");
            if (vize < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            double final = not_oku("Final notu       : ");
            if (final < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }

            double ortalama = hesapla_ortalama(vize, final);
            int yuvarlanmis = yuvarla(ortalama);
            ogrenci_raporu_yaz(numara, vize, final, ortalama, yuvarlanmis);
            istatistik_ekle(numara, ortalama, yuvarlanmis, final);
            break;
        }
        case 2:
            istatistik_yaz();
            break;
        case 3:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n",
                   kayit_sayisi());
            break;
        default:
            printf("  Geçersiz seçim: 1, 2 ya da 3 girin.\n");
            break;
        }
    } while (secim != 3);

    return 0;
}

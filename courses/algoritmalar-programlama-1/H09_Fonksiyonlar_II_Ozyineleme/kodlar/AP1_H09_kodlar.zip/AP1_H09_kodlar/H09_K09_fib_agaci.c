/* H09_K09_fib_agaci.c — Hafta 9 · Kavram programı: fib(5) özyineleme ağacı
 * Amaç   : Her çağrıyı derinliği kadar girintiyle yazdırarak özyineleme
 *          ağacını metin olarak çizmek; aynı alt problemin kaç kez yeniden
 *          hesaplandığını saymak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_K09_fib_agaci.c -o fib_agaci
 * Örnek  : -> Toplam 15 çağrı; fib(2) 3 kez hesaplandı.
 */
#include <stdio.h>

static int cagri = 0;               /* toplam çağrı */
static int fib2_sayisi = 0;         /* fib(2) kaç kez hesaplandı? */

int fib(int n, int derinlik)
{
    cagri++;
    if (n == 2) {
        fib2_sayisi++;
    }
    printf("%*sfib(%d)\n", 4 * derinlik, "", n);
    if (n < 2) {
        return n;
    }
    return fib(n - 1, derinlik + 1) + fib(n - 2, derinlik + 1);
}

int main(void)
{
    int sonuc = fib(5, 0);
    printf("fib(5) = %d\n", sonuc);
    printf("Toplam %d çağrı; fib(2) %d kez hesaplandı.\n", cagri, fib2_sayisi);
    return 0;
}

/* H09_05_kare_makro.c — Hafta 9 · Örnek 5 (★★): KARE(x) makro tuzağı
 * Amaç   : Önişlemcinin makroyu METİN olarak yerine koyduğunu göstermek;
 *          parantezli makroyu ve fonksiyon alternatifini karşılaştırmak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_05_kare_makro.c -o kare_makro
 * İnceleme: gcc -E H09_05_kare_makro.c | tail -n 12   (önişlemci çıktısı)
 * Örnek  : -> KARE_YANLIS(1 + 2) = 5
 */
#include <stdio.h>

#define KARE_YANLIS(x) x * x        /* parantezsiz: tuzak! */
#define KARE(x) ((x) * (x))         /* her argüman ve bütün ifade parantezli */

int kare(int x)                     /* fonksiyon: argüman bir kez hesaplanır */
{
    return x * x;
}

int main(void)
{
    printf("KARE_YANLIS(1 + 2) = %d\n", KARE_YANLIS(1 + 2));
    printf("KARE(1 + 2)        = %d\n", KARE(1 + 2));
    printf("kare(1 + 2)        = %d\n", kare(1 + 2));
    printf("100 / KARE_YANLIS(5) = %d\n", 100 / KARE_YANLIS(5));
    printf("100 / KARE(5)        = %d\n", 100 / KARE(5));
    printf("KARE(2.5)          = %.2f\n", KARE(2.5));
    return 0;
}

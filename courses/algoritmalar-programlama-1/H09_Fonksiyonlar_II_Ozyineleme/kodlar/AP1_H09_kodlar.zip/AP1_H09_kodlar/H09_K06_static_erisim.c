/* H09_K06_static_erisim.c — Hafta 9 · Kavram programı: static = iç bağlantı
 * BU DOSYA KASITLI HATA İÇERİR: matematik_util.c'deki static cagri
 * değişkenine extern ile ulaşmaya çalışır. Derleyici bu dosyayı derler,
 * BAĞLAYICI (linker) "undefined reference" hatası verir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -c H09_K06_static_erisim.c
 *          gcc H09_K06_static_erisim.o matematik_util.o -o static_erisim
 */
#include <stdio.h>

extern int cagri;                   /* "cagri başka bir dosyada tanımlı" iddiası */

int main(void)
{
    cagri = 0;                      /* static olduğu için dışarıdan görünmez */
    printf("cagri = %d\n", cagri);
    return 0;
}

/* H09_01_kapsam_golgeleme.c — Hafta 9 · Örnek 1 (★): Kapsam deneyleri
 * Amaç   : Aynı adı taşıyan üç değişkenle dosya, fonksiyon ve blok
 *          kapsamını; iç bloğun dıştaki adı gölgelemesini göstermek
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H09_01_kapsam_golgeleme.c -o kapsam
 * Ek     : -Wshadow eklenirse derleyici gölgelemeleri uyarı olarak bildirir
 * Örnek  : -> iç blok sonu  : x = 30
 */
#include <stdio.h>

int x = 1;                          /* dosya kapsamı (global) */

void goster(void)
{
    printf("goster()      : x = %d (global)\n", x);
}

int main(void)
{
    printf("main başı     : x = %d (global)\n", x);
    int x = 2;                      /* main'in x'i: globali gölgeler */
    printf("main          : x = %d\n", x);
    {
        int x = 3;                  /* iç blok: main'in x'ini gölgeler */
        printf("iç blok       : x = %d\n", x);
        x = x * 10;                 /* yalnızca iç x değişir */
        printf("iç blok sonu  : x = %d\n", x);
    }                               /* iç x'in kapsamı ve ömrü biter */
    printf("bloktan sonra : x = %d\n", x);
    for (int i = 0; i < 2; i++) {
        int y = 10 * (i + 1);       /* her turda yeniden oluşur */
        printf("for turu %d    : y = %d\n", i, y);
    }
    goster();                       /* goster() main'in x'ini görmez */
    return 0;
}

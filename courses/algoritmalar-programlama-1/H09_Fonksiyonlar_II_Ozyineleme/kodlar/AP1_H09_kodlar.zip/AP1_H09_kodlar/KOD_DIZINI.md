# Hafta 9 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` ve `.h` dosyası (62 `.c`, 4 `.h`); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (GCC 13.3, x86-64 Linux; çok dosyalı örneklerin komutları dosya başlıklarındadır). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (her dosyanın başında derleme komutu, sonra `$ ./program` satırları ve girdileriyle birlikte çıktı). Örnek ve kavram programları ayrıca AddressSanitizer + UBSan ile temiz çalıştı; bilerek çöken `H09_11_yigin_tasmasi.c` (hedef -1) ASan altında “stack-overflow” raporu verir, süre ölçen `H09_12_fibonacci_cagri.c` ayrı bir denetimde ASan + UBSan altında da temiz çalıştı (bu kipte süreler farklıdır, çağrı sayıları aynıdır).

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Ders notu ve sunumdaki kod kesitleri dosyanın **ardışık satırlarıdır** (başlıkta dosya adı ve satır aralığı); web’deki kod blokları dosyanın tamamı ya da `#include`’dan başlayan kesitidir. Başlık dosyalarının (`.h`) içeriği, envanter denetimi için `#include` satırı yerine metni elle yapıştırılmış tek çeviri birimi dosyalarında da bulunur: `H09_K04_ceviri_birimi.c` (matematik_util.h), `H09_K11_obs_ceviri_birimi.c` (proje/obs.h), `hata_avcisi/H09_HA4_tek_birim.c` ve `…_tek_birim_duzeltilmis.c` (sayac.h).

Envanter denetimi: `node shared/kod_envanteri.js 9` → **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H09_01_kapsam_golgeleme.c` | Örnek 1 (★) | Örnek 1 (★): Kapsam deneyleri | sıfır uyarı | 3.1 | 10 (şekil) | h09-kapsam |
| `H09_02_static_sayac.c` | Örnek 2 (★) | Örnek 2 (★): static sayaç | sıfır uyarı | 3.3 | 13 | h09-omur |
| `H09_03_geri_sayim.c` | Örnek 3 (★) | Örnek 3 (★): Özyinelemeli geri sayım | sıfır uyarı | 3.7 (şekil) | 21 (şekil) | h09-ozyineleme |
| `H09_04_cok_dosyali/main.c` | Örnek 4 (★★) · kullanan program | Örnek 4 (★★): modülü KULLANAN program | sıfır uyarı | 3.4 (şekil), 4.2 | 15 (şekil), 30 | h09-cok-dosya |
| `H09_04_cok_dosyali/matematik_util.c` | Örnek 4 (★★) · modül | Örnek 4 (★★): modülün GERÇEKLEMESİ | sıfır uyarı | 3.4, 4.2 (çıktı, metin) | 14, 15 (şekil), 30 (not) | h09-cok-dosya |
| `H09_04_cok_dosyali/matematik_util.h` | Örnek 4 (★★) · başlık | Örnek 4 (★★): modülün ARAYÜZÜ | başlık (içeren .c ile derlenir) | 3.4 | 14, 15 (şekil) | h09-cok-dosya |
| `H09_05_kare_makro.c` | Örnek 5 (★★) | Örnek 5 (★★): KARE(x) makro tuzağı | sıfır uyarı | 3.5 | 16 (şekil) | h09-makro |
| `H09_06_faktoriyel_yigin.c` | Örnek 6 (★★) | Örnek 6 (★★): Özyinelemeli faktöriyel | sıfır uyarı | 4.4 | 22 (şekil), 23 (şekil), 32 | h09-merdiven |
| `H09_07_toplam_us.c` | Örnek 7 (★★) | Örnek 7 (★★): 1..N toplamı ve üs alma | sıfır uyarı | 4.5 | 35 | h09-merdiven |
| `H09_08_basamak_ters.c` | Örnek 8 (★★) | Örnek 8 (★★): Basamaklar ve dönüşte iş | sıfır uyarı | 4.6 | 36 (şekil) | h09-merdiven |
| `H09_09_ikili_yazdir.c` | Örnek 9 (★★) | Örnek 9 (★★): Onluktan ikiliye (özyinelemeli) | sıfır uyarı | 4.7 | 37 | h09-merdiven |
| `H09_10_ebob_ozyinelemeli.c` | Örnek 10 (★★) | Örnek 10 (★★): Özyinelemeli EBOB | sıfır uyarı | 4.8 | 38 | h09-merdiven |
| `H09_11_yigin_tasmasi.c` | Örnek 11 (★★) | Örnek 11 (★★): Yığın taşması gözlemi | sıfır uyarı | 4.9 | 27 (şekil), 39 | h09-agac-tasma |
| `H09_12_fibonacci_cagri.c` | Örnek 12 (★★★) | Örnek 12 (★★★): Fibonacci'nin bedeli | sıfır uyarı | 4.10 | 40 | h09-merdiven |
| `H09_13_hanoi.c` | Örnek 13 (★★★) | Örnek 13 (★★★): Hanoi Kuleleri | sıfır uyarı | 4.11 | 41, 42 (şekil) | h09-merdiven |
| `H09_K01_kapsam_disi.c` | Kavram programı | Kavram programı: kapsam dışı erişim | kasıtlı derleme hatası | 3.1 (metin) | — | h09-kapsam |
| `H09_K02_bellek_duzeni.c` | Kavram programı | Kavram programı: süreç bellek düzeni | sıfır uyarı | 3.6 (metin, şekil) | 18 (şekil) | h09-yigin |
| `H09_K03_yigin_adresleri.c` | Kavram programı | Kavram programı: yığın aşağı büyür | sıfır uyarı | 3.6 (metin) | 20 (şekil) | h09-yigin |
| `H09_K04_ceviri_birimi.c` | Kavram programı | Kavram programı: çeviri birimi | sıfır uyarı | 3.4 (metin) | — | — |
| `H09_K05_cift_icerme.c` | Kavram programı | Kavram programı: başlık koruyucusu | sıfır uyarı | 3.4 (metin) | — | — |
| `H09_K06_static_erisim.c` | Kavram programı | Kavram programı: static = iç bağlantı | derlenir; kasıtlı bağlama hatası | 3.4 (metin) | — | h09-cok-dosya |
| `H09_K07_faktoriyel_saf.c` | Kavram programı | Kavram programı: iki faktöriyel | sıfır uyarı | 3.8, 4.4 (metin) | 28 | h09-donusum |
| `H09_K08_kuyruk_ozyineleme.c` | Kavram programı | Kavram programı: kuyruk özyinelemesi | sıfır uyarı | 3.8 (metin) | 48 (şekil) | h09-donusum |
| `H09_K09_fib_agaci.c` | Kavram programı | Kavram programı: fib(5) özyineleme ağacı | sıfır uyarı | 3.7 (metin, şekil) | 25 (şekil) | h09-agac-tasma |
| `H09_K10_hanoi_64.c` | Kavram programı | Kavram programı: 64 diskin bedeli | sıfır uyarı | 1 (metin), 4.11 (metin) | 6 (not) | h09-buyuk-soru |
| `H09_K11_obs_ceviri_birimi.c` | Kavram programı | Kavram programı: Mini-OBS çeviri birimi | sıfır uyarı | — | — | — |
| `alistirmalar/H09_A01_cikti_tahmini.c` | Alıştırma 9.1 | Alıştırma 9.1 (★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h09-alistirmalar |
| `alistirmalar/H09_A02_static_kapsam.c` | Alıştırma 9.2 | Alıştırma 9.2 (★★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h09-alistirmalar |
| `alistirmalar/H09_A03_hata_bul_us.c` | Alıştırma 9.3 | Alıştırma 9.3 (★★, hata bul) | sıfır uyarı; kasıtlı mantık hatası | 8 (alıştırma) | — | h09-alistirmalar |
| `alistirmalar/H09_A04_hata_bul_basamak.c` | Alıştırma 9.4 | Alıştırma 9.4 (★★, hata bul) | sıfır uyarı; kasıtlı mantık hatası | 8 (alıştırma) | — | h09-alistirmalar |
| `alistirmalar/H09_A05_parsons_bir_sayisi.c` | Alıştırma 9.5 | Alıştırma 9.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h09-alistirmalar |
| `alistirmalar/H09_A06_kod_tamamla_basamaklar.c` | Alıştırma 9.6 | Alıştırma 9.6 (★★, kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h09-alistirmalar |
| `hata_avcisi/H09_HA1_temel_durum_yok.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA1_temel_durum_yok_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 (düzeltilmiş) | sıfır uyarı | — | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA2_atlanan_temel_durum.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 | 43 | h09-hata-avcisi |
| `hata_avcisi/H09_HA2_atlanan_temel_durum_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 (düzeltilmiş) | sıfır uyarı | — | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA3_global_sayac.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 | 44 (şekil) | h09-hata-avcisi |
| `hata_avcisi/H09_HA3_global_sayac_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 (düzeltilmiş) | sıfır uyarı | — | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA4_cok_tanim/main.c` | Hata Avcısı 4 · kasıtlı hata · main.c | Hata Avcısı 4 (hatalı sürüm): kullanan program | derlenir; bağlamada multiple definition (kasıtlı) | — | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA4_cok_tanim/sayac.c` | Hata Avcısı 4 · kasıtlı hata · sayac.c | Hata Avcısı 4 (hatalı sürüm): modül | derlenir; bağlamada multiple definition (kasıtlı) | — | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA4_cok_tanim/sayac.h` | Hata Avcısı 4 · kasıtlı hata · sayac.h | Hata Avcısı 4 (hatalı sürüm) | başlık (içeren .c ile derlenir) | 5 | 45 | h09-hata-avcisi |
| `hata_avcisi/H09_HA4_cok_tanim_duzeltilmis/main.c` | Hata Avcısı 4 · düzeltilmiş · main.c | Hata Avcısı 4 (düzeltilmiş): kullanan program | sıfır uyarı | — | — | — |
| `hata_avcisi/H09_HA4_cok_tanim_duzeltilmis/sayac.c` | Hata Avcısı 4 · düzeltilmiş · sayac.c | Hata Avcısı 4 (düzeltilmiş): modül | sıfır uyarı | — | — | — |
| `hata_avcisi/H09_HA4_cok_tanim_duzeltilmis/sayac.h` | Hata Avcısı 4 · düzeltilmiş · sayac.h | Hata Avcısı 4 (düzeltilmiş) | başlık (içeren .c ile derlenir) | 5 (şekil) | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA4_tek_birim.c` | Hata Avcısı 4 (tek çeviri birimi) | Hata Avcısı 4: hatalı başlık, tek çeviri biriminde | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | — | — |
| `hata_avcisi/H09_HA4_tek_birim_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4: düzeltilmiş başlık, tek çeviri biriminde | sıfır uyarı | — | — | — |
| `hata_avcisi/H09_HA5_makro_parantez.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA5_makro_parantez_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 (düzeltilmiş) | sıfır uyarı | — | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA6_makro_yan_etki.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA6_makro_yan_etki_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 (düzeltilmiş) | sıfır uyarı | — | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA7_donus_degeri.c` | Hata Avcısı 7 (kasıtlı hata) | Hata Avcısı 7 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 | — | h09-hata-avcisi |
| `hata_avcisi/H09_HA7_donus_degeri_duzeltilmis.c` | Hata Avcısı 7 (düzeltilmiş) | Hata Avcısı 7 (düzeltilmiş) | sıfır uyarı | — | — | h09-hata-avcisi |
| `proje/main.c` | Mini-OBS v0.9 · main.c | Mini-OBS v0.9 (AP-1 Hafta 9): yalnızca menü döngüsü | sıfır uyarı (Makefile) | 7 (şekil) | 49 (şekil) | — |
| `proje/obs.c` | Mini-OBS v0.9 · obs.c | Mini-OBS v0.9 (AP-1 Hafta 9): modülün GERÇEKLEMESİ | sıfır uyarı (Makefile) | 7 | 49 (not, şekil), 50 (not) | — |
| `proje/obs.h` | Mini-OBS v0.9 · başlık | Mini-OBS v0.9 (AP-1 Hafta 9): modülün ARAYÜZÜ | başlık (içeren .c ile derlenir) | 7 | 49 (not, şekil), 50 (not) | h09-miniobs |
| `proje/test_obs.c` | Mini-OBS v0.9 · test_obs.c | Mini-OBS v0.9 (AP-1 Hafta 9): birim testleri | sıfır uyarı (Makefile) | 7 (metin, şekil) | 49 (not, şekil) | — |
| `quiz/H09_Q01_prototip.c` | Geri çağırma S1 · quiz | Geçen haftadan S1 (H8: prototip) | sıfır uyarı | 2 (metin) | 3 | h09-gecen-hafta, h09-quiz |
| `quiz/H09_Q02_takas.c` | Geri çağırma S2 · quiz | Geçen haftadan S2 (H8: değerle aktarım) | sıfır uyarı | 2 (metin) | 4 | h09-gecen-hafta, h09-quiz |
| `quiz/H09_Q03_assert.c` | Geri çağırma S3 · quiz | Geçen haftadan S3 (H8: assert) | sıfır uyarı | 2 (metin) | 4 | h09-gecen-hafta, h09-quiz |
| `quiz/H09_Q04_golgeleme.c` | Quiz S4 | Quiz 1 (kapsam ve gölgeleme) | sıfır uyarı | — | 12 | h09-quiz |
| `quiz/H09_Q05_static_cagri.c` | Quiz S5 | Quiz 2 (static yerel değişken) | sıfır uyarı | — | — | h09-quiz |
| `quiz/H09_Q06_donuste_yaz.c` | Quiz S6 | Quiz 3 (dönüşte iş yapma) | sıfır uyarı | — | 24 | h09-quiz |
| `quiz/H09_Q07_fib_cagri.c` | Quiz S7 | Quiz 4 (özyineleme ağacı) | sıfır uyarı | — | 26 | h09-quiz |
| `quiz/H09_Q08_iki_kati.c` | Quiz S8 | Quiz 5 (makro açılımı) | sıfır uyarı | — | — | h09-quiz |
| `quiz/H09_Q09_sonlanma.c` | Quiz S9 | Quiz 6 (temel duruma yaklaşma) | sıfır uyarı | — | — | h09-quiz |
| `quiz/H09_Q10_hanoi_5.c` | Quiz S10 | Quiz 7 (Hanoi hamle sayısı) | sıfır uyarı | — | — | h09-quiz |

**Diğer dosyalar**

- `proje/Makefile` — Mini-OBS v0.9 (`make`, `make test`, `make clean`); `proje/` klasörü `91_Proje_MiniOBS/v0.9/`’un kopyasıdır (asıl yer orası; testler ve gerçek oturum `mini_obs_v0_9_ciktilar.txt` orada).
- `ciktilar/H09_K07_*_asm.txt`, `ciktilar/H09_K08_*_asm.txt` — `gcc -O0` ve `gcc -O2` ile üretilmiş gerçek assembly (`-S -masm=intel`); Merak Kutusu (kuyruk özyinelemesi) için.
- `ciktilar/H09_04_cok_dosyali.txt` — Örnek 4’ün ayrı derleme, bağlama, `nm`, eksik bağlama ve derleme hatası oturumu.
- `AP1_H09_kodlar.zip` — bu klasörün (`.c`, `.h`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H09_kodlar/` klasörü oluşur.

Materyalde doğrudan geçmeyen (envanter ya da arşiv amaçlı) dosyalar: `H09_K11_obs_ceviri_birimi.c`, `hata_avcisi/H09_HA4_cok_tanim_duzeltilmis/main.c`, `hata_avcisi/H09_HA4_cok_tanim_duzeltilmis/sayac.c`, `hata_avcisi/H09_HA4_tek_birim_duzeltilmis.c`.

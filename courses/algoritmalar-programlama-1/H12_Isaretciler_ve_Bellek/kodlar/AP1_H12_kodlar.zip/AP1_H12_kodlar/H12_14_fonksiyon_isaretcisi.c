/* H12_14_fonksiyon_isaretcisi.c — Hafta 12 · Örnek 14 (★★★, meydan okuma)
 * Amaç   : Fonksiyonlar da bellekte (text bölgesinde) durur; adresleri bir
 *          FONKSİYON İŞARETÇİSİNDE saklanabilir, dizide tutulabilir ve başka
 *          fonksiyona argüman olarak verilebilir. switch yerine bir İŞLEM
 *          TABLOSU: davranış veri gibi seçilir. (AP-2: qsort'un
 *          karşılaştırma fonksiyonu bu fikirle çalışır.)
 * Not    : double (*islem)(double, double) → "iki double alıp double
 *          döndüren bir fonksiyonu gösteren işaretçi" (içten dışa okuyun).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_14_fonksiyon_isaretcisi.c -o islem_tablosu
 * Örnek  : -> 7 * 6 = 42.00
 */
#include <stdio.h>

double topla(double a, double b)
{
    return a + b;
}

double cikar(double a, double b)
{
    return a - b;
}

double carp(double a, double b)
{
    return a * b;
}

double bol(double a, double b)
{
    return a / b;
}

/* Davranışı PARAMETRE olarak alan fonksiyon */
double uygula(double (*islem)(double, double), double a, double b)
{
    return islem(a, b);
}

int main(void)
{
    double (*islemler[])(double, double) = {topla, cikar, carp, bol};
    const char isaretler[] = {'+', '-', '*', '/'};
    int adet = (int)(sizeof islemler / sizeof islemler[0]);

    for (int i = 0; i < adet; i++) {            /* tabloyu dolaş */
        printf("12 %c 4 = %.2f\n", isaretler[i], islemler[i](12, 4));
    }

    double x, y;
    char isaret;
    printf("İşlem (örn. 7 * 6): ");
    if (scanf("%lf %c %lf", &x, &isaret, &y) != 3) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    for (int i = 0; i < adet; i++) {            /* işarete göre seç */
        if (isaretler[i] == isaret) {
            if (isaret == '/' && y == 0) {
                printf("Sıfıra bölme.\n");
            } else {
                printf("%g %c %g = %.2f\n", x, isaret, y,
                       uygula(islemler[i], x, y));
            }
            return 0;
        }
    }
    printf("Bilinmeyen işlem: %c\n", isaret);
    return 0;
}

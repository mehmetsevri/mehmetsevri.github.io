/* H12_05_min_max.c — Hafta 12 · Örnek 5 (★★): Dizi + çıktı parametreleri
 * Amaç   : Dizinin en küçük ve en büyük elemanını TEK geçişte bulup iki
 *          çıktı parametresiyle döndürmek. Dizi parametresi const: fonksiyon
 *          diziyi yalnızca okur (salt okunur erişim sözleşmesi, Örnek 9).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_05_min_max.c -o min_max
 * Örnek  : -> 6 not: en küçük 38, en büyük 90, aralık 52
 */
#include <stdio.h>

/* Ön koşul : n >= 1; min ve max geçerli adreslerdir.
 * Son koşul: *min ve *max, dizi[0..n-1]'in en küçük ve en büyük elemanı. */
void dizi_min_max(const int dizi[], int n, int *min, int *max)
{
    *min = dizi[0];
    *max = dizi[0];
    for (int i = 1; i < n; i++) {
        if (dizi[i] < *min) {
            *min = dizi[i];
        }
        if (dizi[i] > *max) {
            *max = dizi[i];
        }
    }
}

int main(void)
{
    int notlar[] = {72, 45, 90, 61, 38, 85};
    int n = (int)(sizeof notlar / sizeof notlar[0]);
    int en_kucuk, en_buyuk;

    dizi_min_max(notlar, n, &en_kucuk, &en_buyuk);
    printf("%d not: en küçük %d, en büyük %d, aralık %d\n",
           n, en_kucuk, en_buyuk, en_buyuk - en_kucuk);

    int tek[] = {50};                       /* sınır durumu: tek eleman */
    dizi_min_max(tek, 1, &en_kucuk, &en_buyuk);
    printf("1 not: en küçük %d, en büyük %d\n", en_kucuk, en_buyuk);
    return 0;
}

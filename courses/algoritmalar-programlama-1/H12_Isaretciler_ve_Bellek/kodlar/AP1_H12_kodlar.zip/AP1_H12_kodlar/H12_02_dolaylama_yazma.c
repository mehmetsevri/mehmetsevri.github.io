/* H12_02_dolaylama_yazma.c — Hafta 12 · Örnek 2 (★): Dolaylama ile yazma
 * Amaç   : *p = ... ile p'nin gösterdiği kutuya YAZMAK; aynı işaretçiyi
 *          başka bir kutuya yöneltmek (p = &y). Her satırdan sonra
 *          kutu–ok diyagramını güncelleyin.
 * Not    : (*p)++ ile *p++ farklıdır: sonek ++, *'dan önce bağlanır;
 *          *p++ işaretçiyi ilerletir (Örnek 6).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_02_dolaylama_yazma.c -o dolaylama_yazma
 * Örnek  : -> 3) p = &y; *p = *p * 2; -> x = 101, y = 40
 */
#include <stdio.h>

int main(void)
{
    int x = 10;
    int y = 20;
    int *p = &x;

    *p = 100;                           /* x'e p üzerinden yazma */
    printf("1) *p = 100;            -> x = %d, y = %d\n", x, y);
    (*p)++;                             /* x'i bir artır (parantez şart) */
    printf("2) (*p)++;              -> x = %d, y = %d\n", x, y);
    p = &y;                             /* p artık y'yi gösteriyor */
    *p = *p * 2;
    printf("3) p = &y; *p = *p * 2; -> x = %d, y = %d\n", x, y);
    return 0;
}

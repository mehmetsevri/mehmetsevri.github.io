/* H12_K01_sizeof_isaretci.c — Hafta 12 · Kavram programı: işaretçinin boyutu
 * Amaç   : Gösterdiği tip ne olursa olsun, bir işaretçi bir ADRES taşır;
 *          64 bitlik sistemde (x86-64 Linux, LP64) adres 8 bayttır.
 *          Tip, işaretçinin boyutunu değil, gösterdiği nesnenin nasıl
 *          okunacağını ve p + 1'in kaç bayt ilerleyeceğini belirler.
 * Not    : 64 bit Windows'ta da işaretçi 8 bayttır (orada long 4 bayttır).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K01_sizeof_isaretci.c -o sizeof_isaretci
 * Örnek  : -> sizeof(int)    =  4   sizeof(int *)    = 8
 */
#include <stdio.h>

int main(void)
{
    printf("sizeof(char)   = %2zu   sizeof(char *)   = %zu\n",
           sizeof(char), sizeof(char *));
    printf("sizeof(int)    = %2zu   sizeof(int *)    = %zu\n",
           sizeof(int), sizeof(int *));
    printf("sizeof(double) = %2zu   sizeof(double *) = %zu\n",
           sizeof(double), sizeof(double *));
    printf("sizeof(void *) = %zu\n", sizeof(void *));
    return 0;
}

/* H12_HA4_null_dolaylama.c — Hafta 12 · Hata Avcısı 4: NULL'ı dolaylama
 * BU DOSYA KASITLI HATA İÇERİR: bul() "bulunamadı" durumunu NULL ile
 * bildirir, ama çağıran dönüş değerini denetlemeden dolaylıyor. Hoare'un
 * "milyar dolarlık hatası"nın en kısa C örneği.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA4_null_dolaylama.c -o ha4
 */
#include <stdio.h>

/* aranan bulunursa elemanın ADRESİNİ, bulunamazsa NULL'ı döndürür */
int *bul(int *a, int n, int aranan)
{
    for (int i = 0; i < n; i++) {
        if (a[i] == aranan) {
            return &a[i];
        }
    }
    return NULL;
}

int main(void)
{
    int a[] = {5, 8, 13};
    int *p = bul(a, 3, 99);     /* 99 yok: p = NULL */
    *p = 0;                     /* HATA: denetimsiz dolaylama */
    printf("a[0] = %d\n", a[0]);
    return 0;
}

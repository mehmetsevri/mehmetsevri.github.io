/* H12_HA4_null_dolaylama_duzeltilmis.c — Hafta 12 · Hata Avcısı 4
 * (düzeltilmiş): NULL dönebilen her işaretçi dolaylanmadan önce denetlenir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA4_null_dolaylama_duzeltilmis.c -o ha4d
 * Örnek  : -> 99 bulunamadı; dizi değişmedi.
 */
#include <stdio.h>

/* aranan bulunursa elemanın ADRESİNİ, bulunamazsa NULL'ı döndürür */
int *bul(int *a, int n, int aranan)
{
    for (int i = 0; i < n; i++) {
        if (a[i] == aranan) {
            return &a[i];
        }
    }
    return NULL;
}

int main(void)
{
    int a[] = {5, 8, 13};
    int *p = bul(a, 3, 99);
    if (p != NULL) {            /* DOĞRU: önce denetle */
        *p = 0;
    } else {
        printf("99 bulunamadı; dizi değişmedi.\n");
    }
    printf("a[0] = %d\n", a[0]);
    return 0;
}

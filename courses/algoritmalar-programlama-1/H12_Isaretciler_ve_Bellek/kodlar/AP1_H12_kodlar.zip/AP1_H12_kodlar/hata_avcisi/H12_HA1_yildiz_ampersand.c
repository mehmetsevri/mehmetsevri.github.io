/* H12_HA1_yildiz_ampersand.c — Hafta 12 · Hata Avcısı 1: * ile & karıştırma
 * BU DOSYA KASITLI HATA İÇERİR: iki satırda * ile & yer değiştirmiştir.
 * GCC 13 iki satırı da -Wint-conversion UYARISIYLA geçirir (GCC 14'ten
 * itibaren bu tanı varsayılan olarak hatadır); program çalışınca çöker.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA1_yildiz_ampersand.c -o ha1
 */
#include <stdio.h>

int main(void)
{
    int x = 5;
    int *p = &x;
    int y = p;                  /* HATA: * unutuldu → y'ye ADRES gider */
    printf("y = %d\n", y);
    p = x;                      /* HATA: & unutuldu → p'ye 5 yazılır */
    printf("p = %p\n", (void *)p);
    printf("*p = %d\n", *p);    /* 0x5 adresini okumaya çalışır */
    return 0;
}

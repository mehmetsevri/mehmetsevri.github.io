/* H12_HA7_malloc_sizeof.c — Hafta 12 · Hata Avcısı 7: malloc ve sizeof
 * BU DOSYA KASITLI HATA İÇERİR: (1) sizeof(kaynak) İŞARETÇİNİN boyutudur
 * (8 bayt), n elemanlık dizinin değil; (2) malloc'un dönüşü NULL'a karşı
 * denetlenmiyor. 5 int (20 bayt) 8 baytlık bloğa yazılır: öbek taşması.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA7_malloc_sizeof.c -o ha7
 */
#include <stdio.h>
#include <stdlib.h>

int *kopyala(const int *kaynak, int n)
{
    int *yeni = malloc(sizeof(kaynak));     /* HATA 1: 8 bayt */
    for (int i = 0; i < n; i++) {           /* HATA 2: NULL denetimi yok */
        yeni[i] = kaynak[i];
    }
    return yeni;
}

int main(void)
{
    int notlar[] = {70, 85, 90, 55, 62};
    int *kopya = kopyala(notlar, 5);
    printf("kopya[4] = %d\n", kopya[4]);
    free(kopya);
    return 0;
}

/* H12_HA6_cifte_free.c — Hafta 12 · Hata Avcısı 6: çifte free
 * BU DOSYA KASITLI HATA İÇERİR: a ve b AYNI bloğu gösterir; blok önce a
 * üzerinden, sonra b üzerinden ikinci kez bırakılıyor (double free).
 * Kök neden: bloğun "sahibi" belli değil.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_HA6_cifte_free.c -o ha6
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(4 * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    int *b = a;                 /* iki işaretçi, TEK blok */
    a[0] = 1;
    free(a);
    free(b);                    /* HATA: aynı blok ikinci kez */
    printf("bitti\n");
    return 0;
}

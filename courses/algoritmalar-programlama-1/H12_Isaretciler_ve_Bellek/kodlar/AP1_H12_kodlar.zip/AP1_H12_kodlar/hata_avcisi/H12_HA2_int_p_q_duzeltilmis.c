/* H12_HA2_int_p_q_duzeltilmis.c — Hafta 12 · Hata Avcısı 2 (düzeltilmiş):
 * her işaretçi adının önüne * yazılır; en güvenlisi her bildirimi ayrı
 * satıra ve ilk değeriyle yazmaktır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA2_int_p_q_duzeltilmis.c -o ha2d
 * Örnek  : -> *p = 1, *q = 2
 */
#include <stdio.h>

int main(void)
{
    int x = 1, y = 2;
    int *p = &x;                /* bir satır, bir işaretçi */
    int *q = &y;
    printf("sizeof p = %zu, sizeof q = %zu\n", sizeof p, sizeof q);
    printf("*p = %d, *q = %d\n", *p, *q);
    return 0;
}

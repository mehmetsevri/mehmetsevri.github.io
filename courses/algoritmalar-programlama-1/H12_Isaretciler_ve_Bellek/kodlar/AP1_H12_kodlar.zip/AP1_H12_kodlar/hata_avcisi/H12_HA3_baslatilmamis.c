/* H12_HA3_baslatilmamis.c — Hafta 12 · Hata Avcısı 3: başlatılmamış işaretçi
 * BU DOSYA KASITLI HATA İÇERİR: p'ye ilk değer verilmeden *p'ye yazılıyor.
 * p'nin içinde, o yığın hücresinde daha önce ne kaldıysa o vardır: rastgele
 * bir adres. Sonuç tanımsız davranıştır (çökme ya da sessiz bozulma).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA3_baslatilmamis.c -o ha3
 */
#include <stdio.h>

int main(void)
{
    int *p;                     /* HATA: ilk değer yok */
    *p = 10;                    /* bilinmeyen bir adrese yazma */
    printf("*p = %d\n", *p);
    return 0;
}

/* H12_HA8_yerel_adres.c — Hafta 12 · Hata Avcısı 8: yerel adres döndürme
 * BU DOSYA KASITLI HATA İÇERİR: sonuc, kare_dizisi'nin YIĞIN ÇERÇEVESİNDE
 * yaşar; fonksiyon dönünce çerçeve yok olur ve adres sarkar (H9: ömür).
 * GCC bunu -Wreturn-local-addr ile uyarır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA8_yerel_adres.c -o ha8
 */
#include <stdio.h>

int *kare_dizisi(int n)
{
    int sonuc[10];                  /* yerel: çerçeveyle birlikte ölür */
    for (int i = 0; i < n; i++) {
        sonuc[i] = i * i;
    }
    return sonuc;                   /* HATA: yerel dizinin adresi */
}

int main(void)
{
    int *k = kare_dizisi(5);
    printf("k = %p\n", (void *)k);
    printf("k[2] = %d\n", k[2]);
    return 0;
}

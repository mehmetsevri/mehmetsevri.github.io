/* H12_HA3_baslatilmamis_duzeltilmis.c — Hafta 12 · Hata Avcısı 3
 * (düzeltilmiş): işaretçi ya geçerli bir nesnenin adresiyle ya da NULL ile
 * başlatılır; dolaylamadan önce gerçek bir kutuyu gösterdiğinden emin olunur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA3_baslatilmamis_duzeltilmis.c -o ha3d
 * Örnek  : -> *p = 10
 */
#include <stdio.h>

int main(void)
{
    int x = 0;
    int *p = NULL;              /* güvenli ilk değer */
    p = &x;                     /* artık gerçek bir kutuyu gösteriyor */
    *p = 10;
    printf("*p = %d\n", *p);
    return 0;
}

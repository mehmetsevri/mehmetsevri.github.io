/* H12_HA8_yerel_adres_duzeltilmis.c — Hafta 12 · Hata Avcısı 8
 * (düzeltilmiş): sonuç ÖBEKTE ayrılır; blok fonksiyondan sonra da yaşar.
 * Bloğu bırakma sorumluluğu çağırana geçer (free). (Başka bir çözüm:
 * diziyi çağıran tanımlar, fonksiyon yalnızca doldurur.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA8_yerel_adres_duzeltilmis.c -o ha8d
 * Örnek  : -> k[2] = 4
 */
#include <stdio.h>
#include <stdlib.h>

int *kare_dizisi(int n)
{
    int *sonuc = malloc(n * sizeof *sonuc);     /* öbekte: yaşamaya devam */
    if (sonuc == NULL) {
        return NULL;
    }
    for (int i = 0; i < n; i++) {
        sonuc[i] = i * i;
    }
    return sonuc;
}

int main(void)
{
    int *k = kare_dizisi(5);
    if (k == NULL) {
        return 1;
    }
    printf("k[2] = %d\n", k[2]);
    free(k);                                    /* çağıranın sorumluluğu */
    return 0;
}

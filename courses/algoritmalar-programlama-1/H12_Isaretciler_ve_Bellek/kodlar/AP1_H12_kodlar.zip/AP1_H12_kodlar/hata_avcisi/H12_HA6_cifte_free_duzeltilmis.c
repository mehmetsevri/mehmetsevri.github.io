/* H12_HA6_cifte_free_duzeltilmis.c — Hafta 12 · Hata Avcısı 6
 * (düzeltilmiş): bloğun tek SAHİBİ (a) onu bir kez bırakır; bloğu gösteren
 * bütün işaretçiler NULL yapılır. free(NULL) etkisiz olduğundan yanlışlıkla
 * tekrarlanan bir free artık zararsızdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA6_cifte_free_duzeltilmis.c -o ha6d
 * Örnek  : -> bitti
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *a = malloc(4 * sizeof *a);
    if (a == NULL) {
        return 1;
    }
    int *b = a;                 /* b yalnızca ödünç alır */
    a[0] = 1;
    printf("b[0] = %d\n", b[0]);
    free(a);                    /* sahibi bir kez bırakır */
    a = NULL;
    b = NULL;
    free(b);                    /* free(NULL): etkisiz */
    printf("bitti\n");
    return 0;
}

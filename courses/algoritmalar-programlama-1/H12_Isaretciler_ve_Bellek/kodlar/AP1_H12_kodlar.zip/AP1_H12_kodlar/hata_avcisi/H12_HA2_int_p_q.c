/* H12_HA2_int_p_q.c — Hafta 12 · Hata Avcısı 2: int *p, q;
 * BU DOSYA KASITLI HATA İÇERİR: * bildirimde TİPE değil, her bir ADA
 * bağlanır. int *p, q; satırında yalnızca p işaretçidir; q düz bir int'tir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_HA2_int_p_q.c -o ha2
 */
#include <stdio.h>

int main(void)
{
    int x = 1, y = 2;
    int *p, q;                  /* HATA: yalnız p işaretçi, q bir int */
    p = &x;
    q = &y;                     /* uyarı: adres bir int'e sıkıştırılıyor */
    printf("sizeof p = %zu, sizeof q = %zu\n", sizeof p, sizeof q);
    printf("*p = %d, q = %d\n", *p, q);
    return 0;
}

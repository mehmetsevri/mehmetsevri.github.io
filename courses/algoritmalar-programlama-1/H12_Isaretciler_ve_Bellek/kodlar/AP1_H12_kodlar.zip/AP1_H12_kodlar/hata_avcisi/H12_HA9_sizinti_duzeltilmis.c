/* H12_HA9_sizinti_duzeltilmis.c — Hafta 12 · Hata Avcısı 9 (düzeltilmiş):
 * sonuç hesaplanıp bir değişkende saklanır, blok bırakılır, sonra döner.
 * Kural: her malloc'un tam olarak bir free'si olmalıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA9_sizinti_duzeltilmis.c -o ha9d
 * Örnek  : -> sonuç: 1498.5
 */
#include <stdio.h>
#include <stdlib.h>

double ortalama_hesapla(int n)
{
    int *gecici = malloc(n * sizeof *gecici);
    if (gecici == NULL) {
        return 0.0;
    }
    long toplam = 0;
    for (int i = 0; i < n; i++) {
        gecici[i] = i;
        toplam += gecici[i];
    }
    double ortalama = (double)toplam / n;
    free(gecici);                   /* DOĞRU: dönmeden önce bırak */
    return ortalama;
}

int main(void)
{
    double s = 0.0;
    for (int k = 0; k < 3; k++) {
        s += ortalama_hesapla(1000);
    }
    printf("sonuç: %.1f\n", s);
    return 0;
}

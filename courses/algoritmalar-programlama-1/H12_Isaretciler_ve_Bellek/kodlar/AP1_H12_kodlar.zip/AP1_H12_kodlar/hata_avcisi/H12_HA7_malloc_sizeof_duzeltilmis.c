/* H12_HA7_malloc_sizeof_duzeltilmis.c — Hafta 12 · Hata Avcısı 7
 * (düzeltilmiş): boyut n * sizeof *yeni (eleman sayısı × bir ELEMANIN
 * boyutu); dönüş NULL'a karşı denetlenir ve çağıran da denetler.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA7_malloc_sizeof_duzeltilmis.c -o ha7d
 * Örnek  : -> kopya[4] = 62
 */
#include <stdio.h>
#include <stdlib.h>

int *kopyala(const int *kaynak, int n)
{
    int *yeni = malloc(n * sizeof *yeni);   /* 5 × 4 = 20 bayt */
    if (yeni == NULL) {
        return NULL;
    }
    for (int i = 0; i < n; i++) {
        yeni[i] = kaynak[i];
    }
    return yeni;
}

int main(void)
{
    int notlar[] = {70, 85, 90, 55, 62};
    int *kopya = kopyala(notlar, 5);
    if (kopya == NULL) {
        printf("Bellek yetersiz.\n");
        return 1;
    }
    printf("kopya[4] = %d\n", kopya[4]);
    free(kopya);
    return 0;
}

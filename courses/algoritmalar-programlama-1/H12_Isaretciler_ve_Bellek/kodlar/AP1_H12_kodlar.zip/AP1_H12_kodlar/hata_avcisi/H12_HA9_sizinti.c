/* H12_HA9_sizinti.c — Hafta 12 · Hata Avcısı 9: bellek sızıntısı
 * BU DOSYA KASITLI HATA İÇERİR: her çağrı 1000 int'lik bir blok ayırır ama
 * bırakmaz; dönüşte blokun tek adresi (gecici) yok olur ve blok SAHİPSİZ
 * kalır. Program doğru sonucu yazar: sızıntı ancak araçla görülür
 * (LeakSanitizer, Valgrind). Uzun süre çalışan programlarda bellek tükenir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_HA9_sizinti.c -o ha9
 */
#include <stdio.h>
#include <stdlib.h>

double ortalama_hesapla(int n)
{
    int *gecici = malloc(n * sizeof *gecici);
    if (gecici == NULL) {
        return 0.0;
    }
    long toplam = 0;
    for (int i = 0; i < n; i++) {
        gecici[i] = i;
        toplam += gecici[i];
    }
    return (double)toplam / n;      /* HATA: free(gecici) unutuldu */
}

int main(void)
{
    double s = 0.0;
    for (int k = 0; k < 3; k++) {
        s += ortalama_hesapla(1000);
    }
    printf("sonuç: %.1f\n", s);
    return 0;
}

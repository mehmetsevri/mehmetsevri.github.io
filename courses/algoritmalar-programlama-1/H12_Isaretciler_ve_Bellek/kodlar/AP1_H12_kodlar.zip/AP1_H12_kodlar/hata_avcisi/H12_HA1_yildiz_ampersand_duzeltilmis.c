/* H12_HA1_yildiz_ampersand_duzeltilmis.c — Hafta 12 · Hata Avcısı 1
 * (düzeltilmiş): değeri okumak için *p, adresi almak için &x.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA1_yildiz_ampersand_duzeltilmis.c -o ha1d
 * Örnek  : -> *p = 5
 */
#include <stdio.h>

int main(void)
{
    int x = 5;
    int *p = &x;
    int y = *p;                 /* DOĞRU: gösterilen DEĞER */
    printf("y = %d\n", y);
    p = &x;                     /* DOĞRU: x'in ADRESİ */
    printf("p = %p\n", (void *)p);
    printf("*p = %d\n", *p);
    return 0;
}

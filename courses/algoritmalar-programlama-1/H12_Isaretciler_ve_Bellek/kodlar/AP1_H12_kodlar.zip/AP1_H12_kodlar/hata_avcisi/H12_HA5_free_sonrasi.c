/* H12_HA5_free_sonrasi.c — Hafta 12 · Hata Avcısı 5: free sonrası kullanım
 * BU DOSYA KASITLI HATA İÇERİR: blok free edildikten sonra okunuyor
 * (heap-use-after-free). notlar artık SARKAN bir işaretçidir: bir zamanlar
 * geçerli olan, artık ayrılmamış bir bölgeyi gösterir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA5_free_sonrasi.c -o ha5
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    double *notlar = malloc(3 * sizeof *notlar);
    if (notlar == NULL) {
        return 1;
    }
    notlar[0] = 70;
    notlar[1] = 85;
    notlar[2] = 90;
    free(notlar);
    printf("ilk not: %.1f\n", notlar[0]);   /* HATA: free sonrası okuma */
    return 0;
}

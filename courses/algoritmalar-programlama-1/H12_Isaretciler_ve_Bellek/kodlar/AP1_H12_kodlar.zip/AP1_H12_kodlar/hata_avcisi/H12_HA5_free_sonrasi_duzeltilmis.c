/* H12_HA5_free_sonrasi_duzeltilmis.c — Hafta 12 · Hata Avcısı 5
 * (düzeltilmiş): blok, son kullanımdan SONRA bırakılır ve işaretçi hemen
 * NULL yapılır; yanlışlıkla yeniden kullanılırsa sessiz bozulma yerine
 * hemen fark edilen bir NULL hatası olur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_HA5_free_sonrasi_duzeltilmis.c -o ha5d
 * Örnek  : -> ilk not: 70.0
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    double *notlar = malloc(3 * sizeof *notlar);
    if (notlar == NULL) {
        return 1;
    }
    notlar[0] = 70;
    notlar[1] = 85;
    notlar[2] = 90;
    printf("ilk not: %.1f\n", notlar[0]);   /* önce kullan */
    free(notlar);                           /* sonra bırak */
    notlar = NULL;
    return 0;
}

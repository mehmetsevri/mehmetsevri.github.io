/* H12_Q03_komsuluk.c — Hafta 12 · Geri çağırma 3 (H11): komşuluk ve sınır
 * Soru   : Bütün hücreleri 1 olan 3 × 3 ızgarada köşe, kenar ve orta hücre
 *          için 8-komşu toplamı kaçtır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_Q03_komsuluk.c -o q03
 */
#include <stdio.h>

#define N 3

int komsu_say(int g[N][N], int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            int a = i + di, b = j + dj;
            if ((di != 0 || dj != 0) && a >= 0 && a < N && b >= 0 && b < N) {
                sayi += g[a][b];
            }
        }
    }
    return sayi;
}

int main(void)
{
    int g[N][N] = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}};
    printf("köşe %d, kenar %d, orta %d\n",
           komsu_say(g, 0, 0), komsu_say(g, 0, 1), komsu_say(g, 1, 1));
    return 0;
}

/* H12_Q11_fonksiyon_isaretcisi.c — Hafta 12 · Quiz 11: fonksiyon işaretçisi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_Q11_fonksiyon_isaretcisi.c -o q11
 */
#include <stdio.h>

int kare(int x)
{
    return x * x;
}

int main(void)
{
    int (*f)(int) = kare;
    printf("%d\n", f(f(3)));
    return 0;
}

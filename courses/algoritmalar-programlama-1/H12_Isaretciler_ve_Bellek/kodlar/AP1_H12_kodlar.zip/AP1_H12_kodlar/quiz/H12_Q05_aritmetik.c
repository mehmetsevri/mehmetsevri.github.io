/* H12_Q05_aritmetik.c — Hafta 12 · Quiz 5: işaretçi aritmetiği
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_Q05_aritmetik.c -o q05
 */
#include <stdio.h>

int main(void)
{
    int a[] = {10, 20, 30, 40};
    int *p = a + 1;
    printf("%d %d\n", *p + 1, *(p + 1));
    return 0;
}

/* H12_Q02_2b_parametre.c — Hafta 12 · Geri çağırma 2 (H11): 2B dizi parametresi
 * Soru   : Program ne yazdırır? Parametrede SUTUN neden zorunludur?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_Q02_2b_parametre.c -o q02
 */
#include <stdio.h>

#define SUTUN 3

int satir_toplami(int m[][SUTUN], int i)
{
    int t = 0;
    for (int j = 0; j < SUTUN; j++) {
        t += m[i][j];
    }
    return t;
}

int main(void)
{
    int m[2][SUTUN] = {{1, 2, 3}, {4, 5, 6}};
    printf("%d %d\n", satir_toplami(m, 0), satir_toplami(m, 1));
    return 0;
}

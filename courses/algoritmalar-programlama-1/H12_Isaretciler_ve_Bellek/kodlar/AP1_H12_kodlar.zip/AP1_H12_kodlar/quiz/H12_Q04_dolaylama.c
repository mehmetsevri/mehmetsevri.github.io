/* H12_Q04_dolaylama.c — Hafta 12 · Quiz 4: dolaylama ile yazma
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_Q04_dolaylama.c -o q04
 */
#include <stdio.h>

int main(void)
{
    int x = 5;
    int *p = &x;
    *p += 3;
    int *q = p;
    *q = *q * 2;
    printf("x = %d\n", x);
    return 0;
}

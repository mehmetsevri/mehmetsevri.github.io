/* H12_Q08_char_adim.c — Hafta 12 · Quiz 8: ölçekleme
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_Q08_char_adim.c -o q08
 */
#include <stdio.h>

int main(void)
{
    int a[3] = {0};
    int *i = a;
    char *c = (char *)a;
    printf("%td %td\n", (char *)(i + 2) - c, (c + 2) - c);
    return 0;
}

/* H12_Q09_const.c — Hafta 12 · Quiz 9: const ve işaretçiler
 * Soru   : Bu programa hangi satır eklenirse program DERLENMEZ?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_Q09_const.c -o q09
 */
#include <stdio.h>

int main(void)
{
    int x = 1, y = 2;
    const int *p = &x;
    int *const q = &y;
    p = &y;
    *q = 5;
    printf("%d %d\n", *p, *q);
    return 0;
}

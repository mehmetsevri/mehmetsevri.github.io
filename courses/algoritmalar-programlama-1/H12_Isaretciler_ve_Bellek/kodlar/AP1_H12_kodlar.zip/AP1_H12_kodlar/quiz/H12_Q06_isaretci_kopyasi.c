/* H12_Q06_isaretci_kopyasi.c — Hafta 12 · Quiz 6: işaretçi de değerle gider
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_Q06_isaretci_kopyasi.c -o q06
 */
#include <stdio.h>

void yonlendir(int *p, int *yeni)
{
    p = yeni;                   /* yalnızca yerel kopya değişir */
    *p = 99;
}

int main(void)
{
    int x = 1, y = 2;
    yonlendir(&x, &y);
    printf("x = %d, y = %d\n", x, y);
    return 0;
}

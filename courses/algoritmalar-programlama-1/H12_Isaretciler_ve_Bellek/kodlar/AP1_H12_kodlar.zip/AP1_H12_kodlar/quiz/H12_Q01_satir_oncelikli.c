/* H12_Q01_satir_oncelikli.c — Hafta 12 · Geri çağırma 1 (H11): satır öncelikli
 * Soru   : m[2][1], m[0][0]'dan kaç bayt ileridedir? (int 4 bayt)
 * Not    : Adres farkını hesaplamak için adresler tamsayıya (uintptr_t)
 *          çevrilir (H09_K03'teki gibi); bu hafta aynı farkı işaretçi
 *          aritmetiğiyle de bulacağız.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_Q01_satir_oncelikli.c -o q01
 */
#include <stdio.h>
#include <stdint.h>

int main(void)
{
    int m[3][4] = {{0}};
    uintptr_t taban = (uintptr_t)&m[0][0];   /* adres → tamsayı */
    uintptr_t adres = (uintptr_t)&m[2][1];
    printf("m[2][1], m[0][0]'dan %lu bayt ileride\n",
           (unsigned long)(adres - taban));
    return 0;
}

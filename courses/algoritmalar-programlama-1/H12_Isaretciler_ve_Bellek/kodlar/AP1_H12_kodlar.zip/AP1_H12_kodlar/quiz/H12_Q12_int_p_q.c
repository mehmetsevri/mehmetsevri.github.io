/* H12_Q12_int_p_q.c — Hafta 12 · Quiz 12: bildirimde * neye bağlanır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_Q12_int_p_q.c -o q12
 */
#include <stdio.h>

int main(void)
{
    int *p, q;
    printf("%zu %zu\n", sizeof p, sizeof q);
    return 0;
}

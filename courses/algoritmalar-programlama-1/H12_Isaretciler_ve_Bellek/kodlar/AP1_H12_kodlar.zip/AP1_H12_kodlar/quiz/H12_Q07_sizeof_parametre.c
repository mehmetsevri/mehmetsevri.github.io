/* H12_Q07_sizeof_parametre.c — Hafta 12 · Quiz 7: dizi ve işaretçi boyutu
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_Q07_sizeof_parametre.c -o q07
 */
#include <stdio.h>

void yaz(int *p)
{
    printf("%zu\n", sizeof p);
}

int main(void)
{
    int a[6] = {0};
    printf("%zu ", sizeof a);
    yaz(a);
    return 0;
}

/* H12_Q10_malloc_sizeof.c — Hafta 12 · Quiz 10: sizeof d ile sizeof *d
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_Q10_malloc_sizeof.c -o q10
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    double *d = malloc(4 * sizeof *d);
    if (d == NULL) {
        return 1;
    }
    printf("%zu %zu\n", sizeof d, 4 * sizeof *d);
    free(d);
    return 0;
}

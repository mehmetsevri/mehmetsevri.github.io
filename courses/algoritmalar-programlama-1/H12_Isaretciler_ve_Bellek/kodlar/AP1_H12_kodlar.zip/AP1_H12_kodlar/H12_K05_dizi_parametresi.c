/* H12_K05_dizi_parametresi.c — Hafta 12 · Kavram programı: dizi parametresi
 * BU DOSYA KASITLI HATA İÇERİR: sizeof bir dizi parametresine uygulanmıştır
 * (H10'daki "fonksiyon içinde sizeof" tuzağı). GCC -Wsizeof-array-argument
 * uyarısı verir; uyarının gerçek metni ciktilar/ altındadır.
 * Amaç   : int dizi[] biçiminde yazılan parametre aslında int *dizi'dir:
 *          çağrıda dizi, ilk elemanın adresine dönüşür. Fonksiyona yalnızca
 *          bir ADRES (8 bayt) gider; dizinin boyutu gitmez. Bu yüzden boyut
 *          ayrı bir parametre olarak verilir (H10).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K05_dizi_parametresi.c -o dizi_parametresi
 */
#include <stdio.h>

void boyut_yaz(int dizi[])              /* derleyici için: int *dizi */
{
    printf("fonksiyonda sizeof dizi  = %zu  (int * boyutu)\n", sizeof dizi);
}

int main(void)
{
    int notlar[10] = {0};
    printf("main'de     sizeof notlar = %zu (10 x 4 bayt)\n", sizeof notlar);
    boyut_yaz(notlar);                  /* giden: &notlar[0] */
    return 0;
}

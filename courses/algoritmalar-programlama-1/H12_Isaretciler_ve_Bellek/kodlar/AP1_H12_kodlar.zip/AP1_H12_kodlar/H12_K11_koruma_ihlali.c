/* H12_K11_koruma_ihlali.c — Hafta 12 · Kavram programı: segmentation fault
 * BU DOSYA KASITLI HATA İÇERİR: iki seçenek de bilerek bellek koruma
 * ihlali yapar ve program SIGSEGV sinyaliyle sonlanır.
 * Amaç   : "Segmentation fault" iletisinin anlamını görmek: süreç, sanal
 *          adres alanında (1) hiç eşlenmemiş bir sayfaya (NULL'ın bulunduğu
 *          sıfır sayfası) ya da (2) eşlenmiş ama YAZMA izni olmayan bir
 *          sayfaya (salt okunur veri) erişmeye çalışır. Donanım (MMU) bunu
 *          yakalar, işletim sistemi süreci sonlandırır; kabuk çıkış
 *          durumunu 128 + 11 = 139 olarak bildirir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K11_koruma_ihlali.c -o koruma_ihlali
 */
#include <stdio.h>

static const int SABIT = 7;             /* salt okunur bölgede durur */

int main(void)
{
    int secim = 0;
    printf("1) NULL'dan oku  2) salt okunur sayfaya yaz: ");
    if (scanf("%d", &secim) != 1) {
        return 1;
    }
    printf("\n");
    if (secim == 1) {
        int *p = NULL;
        printf("%d\n", *p);             /* sıfır sayfası eşlenmemiş */
    } else if (secim == 2) {
        int *p = (int *)&SABIT;         /* const'u zorla atmak */
        *p = 8;                         /* sayfada yazma izni yok */
    }
    printf("Buraya ulaşılmaz.\n");
    return 0;
}

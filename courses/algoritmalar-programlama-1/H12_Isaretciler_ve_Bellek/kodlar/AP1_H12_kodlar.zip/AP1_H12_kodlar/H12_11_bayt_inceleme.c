/* H12_11_bayt_inceleme.c — Hafta 12 · Örnek 11 (★★★): Baytlara bakmak
 * Amaç   : H3'te gdb ile gördüğümüz bayt sırasını (H03_K02_bayt_sirasi.c,
 *          aynı sayı) C'nin İÇİNDEN okumak: bir int'in adresini karakter
 *          tipinden bir işaretçiye dönüştürüp baytları tek tek dolaşmak.
 *          b + 1 bir BAYT ilerler (unsigned char'ın boyutu 1).
 * Not    : Bir nesnenin baytlarına karakter tipi (char, unsigned char)
 *          işaretçisiyle erişmek C'de izinlidir. unsigned char, 0x80 ve
 *          üzerindeki baytların negatif görünmesini önler.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_11_bayt_inceleme.c -o bayt_inceleme
 * Örnek  : -> İlk bayt 0x78: bu makine küçük-uçlu.
 */
#include <stdio.h>

int main(void)
{
    int sayi = 0x12345678;                      /* H03_K02 ile aynı sayı */
    unsigned char *b = (unsigned char *)&sayi;  /* bayt bayt bakar */

    printf("sayi = 0x%08X, sizeof sayi = %zu\n", (unsigned)sayi, sizeof sayi);
    for (size_t i = 0; i < sizeof sayi; i++) {
        printf("  b + %zu = %p : %02X\n", i, (void *)(b + i), b[i]);
    }
    printf("İlk bayt 0x%02X: bu makine %s-uçlu.\n",
           b[0], b[0] == 0x78 ? "küçük" : "büyük");

    b[3] = 0x7F;                                /* en anlamlı bayt */
    printf("b[3] = 0x7F sonrası sayi = 0x%08X\n", (unsigned)sayi);
    return 0;
}

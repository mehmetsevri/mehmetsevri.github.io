/* H12_A06_kod_tamamla_ayir.c — Hafta 12 · Alıştırma 12.6 (★★, kod tamamla)
 * Boşluklu kod: tamamlanacak; bu hâliyle derlenmez.
 * Görev  : ayir(x, &tam, &kesir), x'in tam ve kesirli kısmını iki çıktı
 *          parametresiyle döndürmelidir. Dört boşluğu (___) doldurun.
 * Beklenen çıktı: tam = 3, kesir = 0.75
 */
#include <stdio.h>

void ayir(double x, int *tam, double *kesir)
{
    ___ = (int)x;
    ___ = x - (int)x;
}

int main(void)
{
    int t;
    double k;
    ayir(3.75, ___, ___);
    printf("tam = %d, kesir = %.2f\n", t, k);
    return 0;
}

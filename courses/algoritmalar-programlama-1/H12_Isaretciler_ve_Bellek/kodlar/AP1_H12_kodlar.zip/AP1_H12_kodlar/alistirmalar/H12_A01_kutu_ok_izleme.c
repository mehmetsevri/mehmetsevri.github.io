/* H12_A01_kutu_ok_izleme.c — Hafta 12 · Alıştırma 12.1 (★, çıktı tahmini)
 * Görev  : Her satırdan sonra kutu–ok diyagramını çizerek çıktıyı tahmin
 *          edin; sonra derleyip doğrulayın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_A01_kutu_ok_izleme.c -o a01
 */
#include <stdio.h>

int main(void)
{
    int a = 3, b = 8;
    int *p = &a;
    int *q = &b;
    *p = *q + 1;
    p = q;
    *p = *p * 2;
    printf("a = %d, b = %d, *p = %d, *q = %d\n", a, b, *p, *q);
    return 0;
}

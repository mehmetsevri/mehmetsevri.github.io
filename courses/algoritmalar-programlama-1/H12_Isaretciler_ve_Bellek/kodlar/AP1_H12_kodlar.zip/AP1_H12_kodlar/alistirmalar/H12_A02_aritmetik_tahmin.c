/* H12_A02_aritmetik_tahmin.c — Hafta 12 · Alıştırma 12.2 (★★, çıktı tahmini)
 * Görev  : Dizi şeridini çizip p'nin her adımda hangi kutuyu gösterdiğini
 *          işaretleyerek çıktıyı tahmin edin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_A02_aritmetik_tahmin.c -o a02
 */
#include <stdio.h>

int main(void)
{
    int a[] = {4, 7, 1, 9, 2};
    int *p = a + 1;
    printf("%d ", *p);
    printf("%d ", *(p + 2));
    printf("%d ", p[-1]);
    p += 3;
    printf("%d ", *p);
    printf("%td\n", p - a);
    return 0;
}

/* H12_A05_parsons_dizi_toplam.c — Hafta 12 · Alıştırma 12.5 (★★, Parsons)
 * Satırlar karışık verilmiştir: tamamlanacak; bu hâliyle derlenmez.
 * Görev  : dizi_toplam(bas, son), [bas, son) aralığındaki int'lerin
 *          toplamını bir işaretçiyle dolaşarak döndürmelidir. Satırları
 *          doğru sıraya dizin ve girintileyin.
 */
    return toplam;
int dizi_toplam(const int *bas, const int *son)
    for (const int *p = bas; p < son; p++) {
{
    int toplam = 0;
        toplam += *p;
}
    }

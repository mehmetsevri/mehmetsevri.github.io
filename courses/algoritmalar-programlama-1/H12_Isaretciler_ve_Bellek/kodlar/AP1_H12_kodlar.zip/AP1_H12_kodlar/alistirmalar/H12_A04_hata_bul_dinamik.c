/* H12_A04_hata_bul_dinamik.c — Hafta 12 · Alıştırma 12.4 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: üç bellek hatası var.
 * Görev  : Programı -fsanitize=address ile derleyip çalıştırın, raporu
 *          okuyun; üç hatayı da bulup düzeltin (beklenen toplam: 55).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -fsanitize=address \
 *              H12_A04_hata_bul_dinamik.c -o a04
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n = 5;
    int *kareler = malloc(n * sizeof *kareler);
    for (int i = 1; i <= n; i++) {
        kareler[i] = i * i;
    }
    int toplam = 0;
    for (int i = 1; i <= n; i++) {
        toplam += kareler[i];
    }
    printf("toplam = %d\n", toplam);
    return 0;
}

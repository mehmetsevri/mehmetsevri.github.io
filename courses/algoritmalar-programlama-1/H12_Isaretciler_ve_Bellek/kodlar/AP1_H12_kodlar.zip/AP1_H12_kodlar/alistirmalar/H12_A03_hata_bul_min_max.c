/* H12_A03_hata_bul_min_max.c — Hafta 12 · Alıştırma 12.3 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: program "en küçük 0, en büyük 0" yazar.
 * Görev  : Derleyicinin -Wextra uyarısını okuyun, hatayı kutu–ok
 *          diyagramıyla açıklayın ve düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_A03_hata_bul_min_max.c -o a03
 */
#include <stdio.h>

void min_max(const int a[], int n, int *min, int *max)
{
    int enk = a[0], enb = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] < enk) {
            enk = a[i];
        }
        if (a[i] > enb) {
            enb = a[i];
        }
    }
    min = &enk;
    max = &enb;
}

int main(void)
{
    int notlar[] = {72, 45, 90, 61, 38};
    int en_kucuk = 0, en_buyuk = 0;
    min_max(notlar, 5, &en_kucuk, &en_buyuk);
    printf("en küçük %d, en büyük %d\n", en_kucuk, en_buyuk);
    return 0;
}

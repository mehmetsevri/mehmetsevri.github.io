/* H12_K07_null_guvenli.c — Hafta 12 · Kavram programı: NULL ile güvenli kod
 * Amaç   : NULL, "hiçbir nesneyi göstermiyor" anlamına gelen işaretçi
 *          değeridir. Üç alışkanlık: (1) işaretçiye ilk değer olarak NULL
 *          ver, (2) "bulunamadı" gibi durumları NULL ile bildir ve
 *          dolaylamadan ÖNCE denetle, (3) free'den sonra işaretçiyi NULL yap.
 *          free(NULL) hiçbir şey yapmaz (C standardı); güvenlidir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K07_null_guvenli.c -o null_guvenli
 * Örnek  : -> 99 yok (NULL döndü)
 */
#include <stdio.h>
#include <stdlib.h>

/* aranan bulunursa elemanın ADRESİNİ, bulunamazsa NULL'ı döndürür */
int *bul(int *a, int n, int aranan)
{
    for (int i = 0; i < n; i++) {
        if (a[i] == aranan) {
            return &a[i];
        }
    }
    return NULL;
}

int main(void)
{
    int *p = NULL;                      /* güvenli ilk değer */
    int a[] = {5, 8, 13};

    p = bul(a, 3, 8);
    if (p != NULL) {                    /* dolaylamadan ÖNCE denetle */
        *p = 80;
    }
    printf("a[1] = %d\n", a[1]);
    p = bul(a, 3, 99);
    printf("99 %s\n", p != NULL ? "bulundu" : "yok (NULL döndü)");

    int *blok = malloc(3 * sizeof *blok);
    free(blok);                         /* blok NULL olsa bile güvenli */
    blok = NULL;                        /* sarkan işaretçi kalmasın */
    free(blok);                         /* free(NULL): hiçbir şey yapmaz */
    printf("free(NULL) sorunsuz.\n");
    return 0;
}

/* H12_K14_takas_testleri.c — Hafta 12 · Kavram programı: takas'ın testleri
 * Amaç   : Örnek 3'teki takas(int *a, int *b) fonksiyonunu normal, eşit
 *          değerli, negatif ve AYNI değişkenin iki kez verildiği (a == b,
 *          "takma ad") durumlarda assert ile sınamak (H8'deki test deseni).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K14_takas_testleri.c -o takas_testleri
 * Örnek  : -> takas: 4 test geçti.
 */
#include <stdio.h>
#include <assert.h>

void takas(int *a, int *b)
{
    int gecici = *a;
    *a = *b;
    *b = gecici;
}

int main(void)
{
    int x = 3, y = 7;
    takas(&x, &y);
    assert(x == 7 && y == 3);           /* normal */
    int e = 5, f = 5;
    takas(&e, &f);
    assert(e == 5 && f == 5);           /* eşit değerler */
    int n = -2, m = 40;
    takas(&n, &m);
    assert(n == 40 && m == -2);         /* negatif */
    int t = 9;
    takas(&t, &t);
    assert(t == 9);                     /* aynı değişken: a == b */
    printf("takas: 4 test geçti.\n");
    return 0;
}

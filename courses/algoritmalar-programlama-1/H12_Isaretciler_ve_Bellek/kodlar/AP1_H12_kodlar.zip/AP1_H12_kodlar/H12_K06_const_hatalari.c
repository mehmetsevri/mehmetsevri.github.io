/* H12_K06_const_hatalari.c — Hafta 12 · Kavram programı: const ihlalleri
 * BU DOSYA KASITLI HATA İÇERİR: üç satır const sözleşmesini çiğner ve
 * derlenmez. Gerçek derleyici iletileri ciktilar/ altındadır.
 * Amaç   : Örnek 9'daki (H12_09_const_isaretci.c) yasak satırların
 *          derleyicide nasıl yakalandığını görmek.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K06_const_hatalari.c -o const_hatalari   (derlenmez)
 */
#include <stdio.h>

int toplam(const int *a, int n)
{
    int t = 0;
    for (int i = 0; i < n; i++) {
        t += a[i];
        a[i] = 0;                       /* HATA 1: salt okunur erişim */
    }
    return t;
}

int main(void)
{
    int x = 1, y = 2;
    const int *p = &x;
    *p = 5;                             /* HATA 2: gösterilen salt okunur */
    int *const q = &x;
    q = &y;                             /* HATA 3: q'nun kendisi sabit */
    printf("%d %d %d\n", toplam(&x, 1), *p, *q);
    return 0;
}

/* H12_12_realloc_dinamik_dizi.c — Hafta 12 · Örnek 12 (★★★): Büyüyen dizi
 * Amaç   : Kaç eleman geleceği bilinmediğinde kapasite dolunca realloc ile
 *          İKİYE KATLAMAK (dinamik dizi). realloc bloğu yerinde
 *          büyütebilir ya da yeni yere TAŞIYIP içeriği kopyalayabilir.
 * Not    : Sonuç önce GEÇİCİ işaretçiye alınır: realloc başarısız olursa
 *          NULL döner ve eski blok yerinde, geçerli kalır. "dizi =
 *          realloc(dizi, ...)" yazılsaydı eski blok kaybolurdu (sızıntı).
 *          Taşınıp taşınmadığını anlamak için eski adres realloc'tan ÖNCE
 *          tamsayı (uintptr_t) olarak saklanır: başarılı realloc'tan sonra
 *          eski işaretçinin değeri kullanılamaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_12_realloc_dinamik_dizi.c -o realloc_dizi
 * Örnek  : -> 20 eleman, kapasite 32
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(void)
{
    int kapasite = 1, n = 0, tasinma = 0;
    int *dizi = malloc(kapasite * sizeof *dizi);
    if (dizi == NULL) {
        return 1;
    }

    for (int deger = 1; deger <= 20; deger++) {
        if (n == kapasite) {                    /* dolu: ikiye katla */
            uintptr_t eski = (uintptr_t)dizi;   /* adresi ÖNCE sakla */
            int *gecici = realloc(dizi, 2 * kapasite * sizeof *dizi);
            if (gecici == NULL) {               /* dizi hâlâ geçerli */
                printf("Bellek yetersiz: %d elemanda kaldı.\n", n);
                break;
            }
            dizi = gecici;
            kapasite *= 2;
            int tasindi = (uintptr_t)dizi != eski;
            tasinma += tasindi;
            printf("n = %2d: kapasite %2d -> %2d  %s\n", n, kapasite / 2,
                   kapasite, tasindi ? "(blok taşındı)" : "(yerinde büyüdü)");
        }
        dizi[n] = deger * deger;
        n++;
    }
    printf("%d eleman, kapasite %d, %d taşınma; son eleman %d\n",
           n, kapasite, tasinma, dizi[n - 1]);
    free(dizi);
    return 0;
}

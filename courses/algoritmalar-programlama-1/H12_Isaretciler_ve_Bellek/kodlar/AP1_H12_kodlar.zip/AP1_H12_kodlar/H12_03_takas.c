/* H12_03_takas.c — Hafta 12 · Örnek 3 (★★): Referansla aktarım ile takas
 * Amaç   : H8'deki başarısız takas (H08_10_takas_denemesi.c) ile işaretçili
 *          takası YAN YANA çalıştırmak. takas_deger DEĞERLERİN kopyasını,
 *          takas ise ADRESLERİN kopyasını alır: *a ve *b, main'deki x ve
 *          y'nin kendisidir. Böylece H8'in sorusu yanıtlanır.
 * Not    : Adresler her çalıştırmada değişir (ASLR).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H12_03_takas.c -o takas
 * Örnek  : -> takas'tan sonra : x = 7, y = 3   <- değişti
 */
#include <stdio.h>

/* H8'deki sürüm: a ve b, x ile y'nin KOPYALARIDIR */
void takas_deger(int a, int b)
{
    printf("  takas_deger: &a = %p, &b = %p\n", (void *)&a, (void *)&b);
    int gecici = a;
    a = b;
    b = gecici;
}

/* H12: a ve b ADRES taşır; *a ve *b main'deki kutulardır */
void takas(int *a, int *b)
{
    printf("  takas      :  a = %p,  b = %p\n", (void *)a, (void *)b);
    int gecici = *a;
    *a = *b;
    *b = gecici;
}

int main(void)
{
    int x = 3, y = 7;
    printf("  main       : &x = %p, &y = %p\n", (void *)&x, (void *)&y);
    takas_deger(x, y);
    printf("takas_deger'den : x = %d, y = %d   <- değişmedi\n", x, y);
    takas(&x, &y);
    printf("takas'tan sonra : x = %d, y = %d   <- değişti\n", x, y);
    return 0;
}

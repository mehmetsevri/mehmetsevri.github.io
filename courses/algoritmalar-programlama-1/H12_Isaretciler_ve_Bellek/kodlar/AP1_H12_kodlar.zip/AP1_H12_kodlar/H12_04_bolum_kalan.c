/* H12_04_bolum_kalan.c — Hafta 12 · Örnek 4 (★★): Birden çok sonuç döndürme
 * Amaç   : Bir fonksiyon return ile tek değer döndürür. Bölümü VE kalanı
 *          birlikte döndürmek için çağıran, sonuçların yazılacağı kutuların
 *          ADRESLERİNİ verir (çıktı parametreleri). Dönüş değeri başarıyı
 *          bildirir. scanf'in & istemesinin nedeni de budur (H3'ün yanıtı).
 * Not    : C17'de tamsayı bölmesi sıfıra doğru keser: -17 / 5 = -3,
 *          -17 % 5 = -2 ve her zaman a == b * (a / b) + a % b.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_04_bolum_kalan.c -o bolum_kalan
 * Örnek  : -> 17 = 5 * 3 + 2
 */
#include <stdio.h>
#include <stdbool.h>

/* Ön koşul : bolum ve kalan geçerli adreslerdir.
 * Son koşul: b != 0 ise *bolum = a / b, *kalan = a % b ve true döner;
 *            b == 0 ise çıktılara dokunmaz ve false döner. */
bool bolum_kalan(int a, int b, int *bolum, int *kalan)
{
    if (b == 0) {
        return false;
    }
    *bolum = a / b;
    *kalan = a % b;
    return true;
}

int main(void)
{
    int a, b;
    printf("Bölünen ve bölen: ");
    if (scanf("%d %d", &a, &b) != 2) {      /* &a: "a'nın adresine yaz" */
        printf("Geçersiz girdi.\n");
        return 1;
    }
    int bolum, kalan;
    if (bolum_kalan(a, b, &bolum, &kalan)) {
        printf("%d = %d * %d + %d\n", a, b, bolum, kalan);
    } else {
        printf("Sıfıra bölme: bölüm ve kalan tanımsız.\n");
    }
    return 0;
}

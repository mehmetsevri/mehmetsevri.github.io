/* H12_K03_olcekleme.c — Hafta 12 · Kavram programı: tip ve ölçekleme
 * Amaç   : p + k, adrese k × sizeof(*p) BAYT ekler: char * 1'er, int *
 *          4'er, double * 8'er bayt ilerler. İşaretçinin tipi bu yüzden
 *          önemlidir: derleyici ölçeklemeyi tipten bilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K03_olcekleme.c -o olcekleme
 * Örnek  : -> +1 adımı: char * 1 bayt, int * 4 bayt, double * 8 bayt
 */
#include <stdio.h>

int main(void)
{
    char c[3] = {0};
    int i[3] = {0};
    double d[3] = {0};
    char *pc = c;
    int *pi = i;
    double *pd = d;

    for (int k = 0; k < 3; k++) {
        printf("k = %d:  pc + k = %p  pi + k = %p  pd + k = %p\n", k,
               (void *)(pc + k), (void *)(pi + k), (void *)(pd + k));
    }
    printf("+1 adımı: char * %td bayt, int * %td bayt, double * %td bayt\n",
           (char *)(pc + 1) - (char *)pc, (char *)(pi + 1) - (char *)pi,
           (char *)(pd + 1) - (char *)pd);
    return 0;
}

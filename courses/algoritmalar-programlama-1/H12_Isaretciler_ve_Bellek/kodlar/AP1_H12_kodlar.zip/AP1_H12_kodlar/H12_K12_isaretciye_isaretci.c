/* H12_K12_isaretciye_isaretci.c — Hafta 12 · Kavram programı (merak kutusu)
 * Amaç   : İşaretçi de bir değişkendir; onun da adresi vardır. int ** bir
 *          int *'ı gösterir. Kullanım yeri: çağıranın İŞARETÇİSİNİ bir
 *          fonksiyonda değiştirmek (takas'ta int'i değiştirmek için int *
 *          verdik; burada int *'ı değiştirmek için int ** veriyoruz).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K12_isaretciye_isaretci.c -o isaretciye_isaretci
 * Örnek  : -> x = 7, *p = 7, **pp = 7
 */
#include <stdio.h>
#include <stdlib.h>

/* Başarıda *hedef yeni bloğu gösterir ve 1 döner; başarısızlıkta 0. */
int dizi_ayir(int **hedef, int n)
{
    int *yeni = malloc(n * sizeof *yeni);
    if (yeni == NULL) {
        return 0;
    }
    for (int i = 0; i < n; i++) {
        yeni[i] = i * 10;
    }
    *hedef = yeni;                      /* çağıranın işaretçisi değişir */
    return 1;
}

int main(void)
{
    int x = 5;
    int *p = &x;
    int **pp = &p;                      /* pp → p → x */
    **pp = 7;
    printf("x = %d, *p = %d, **pp = %d\n", x, *p, **pp);

    int *dizi = NULL;
    if (dizi_ayir(&dizi, 4)) {          /* dizi'nin ADRESİ gider */
        printf("dizi[3] = %d\n", dizi[3]);
        free(dizi);
    }
    return 0;
}

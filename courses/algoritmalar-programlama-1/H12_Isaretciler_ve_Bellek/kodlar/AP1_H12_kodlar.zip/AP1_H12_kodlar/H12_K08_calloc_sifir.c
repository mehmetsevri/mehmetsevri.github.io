/* H12_K08_calloc_sifir.c — Hafta 12 · Kavram programı: calloc
 * Amaç   : calloc(adet, boyut) adet × boyut baytlık bir blok ayırır ve
 *          bütün baytları SIFIRLAR; malloc'un bloğunun içeriği ise
 *          belirsizdir (okumadan önce yazılmalıdır). Sayaç dizileri için
 *          calloc doğal seçimdir (H10'daki frekans dizisi, öbekte).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K08_calloc_sifir.c -o calloc_sifir
 * Örnek  : -> 3 değeri 3 kez
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int aralik = 7;                             /* 0..6 değerleri */
    int *sayac = calloc(aralik, sizeof *sayac); /* hepsi 0 */
    if (sayac == NULL) {
        return 1;
    }
    int zarlar[] = {3, 1, 6, 3, 4, 3, 1, 6};
    int n = (int)(sizeof zarlar / sizeof zarlar[0]);

    for (int i = 0; i < n; i++) {
        sayac[zarlar[i]]++;                     /* değer = indis */
    }
    for (int k = 1; k < aralik; k++) {
        printf("%d değeri %d kez\n", k, sayac[k]);
    }
    free(sayac);
    return 0;
}

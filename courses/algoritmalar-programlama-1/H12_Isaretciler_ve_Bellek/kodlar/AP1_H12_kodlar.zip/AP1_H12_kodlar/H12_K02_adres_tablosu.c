/* H12_K02_adres_tablosu.c — Hafta 12 · Kavram programı: adres tablosu
 * Amaç   : Bellek dev bir bayt dizisidir; adres bu dizideki İNDİSTİR.
 *          Dört değişkenin adresini, boyutunu ve içeriğini bir tablo olarak
 *          yazdırmak: p'nin İÇERİĞİ, x'in ADRESİDİR (kutu–ok modelindeki ok).
 * Not    : Yerel değişkenlerin yığındaki sırasını derleyici seçer.
 *          Adresler her çalıştırmada değişir (ASLR); setarch x86_64 -R ile
 *          tek bir çalıştırma için kapatılabilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K02_adres_tablosu.c -o adres_tablosu
 */
#include <stdio.h>

int main(void)
{
    int x = 42;
    char c = 'A';
    double d = 2.5;
    int *p = &x;

    printf("ad  adres           boyut  içerik\n");
    printf("x   %p  %5zu  %d\n", (void *)&x, sizeof x, x);
    printf("c   %p  %5zu  '%c'\n", (void *)&c, sizeof c, c);
    printf("d   %p  %5zu  %.1f\n", (void *)&d, sizeof d, d);
    printf("p   %p  %5zu  %p (x'in adresi)\n", (void *)&p, sizeof p, (void *)p);
    return 0;
}

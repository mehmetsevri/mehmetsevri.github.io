/* H12_K13_obs_ceviri_birimi.c — Hafta 12 · Kavram programı: Mini-OBS v0.12 çeviri birimi
 * Amaç   : Mini-OBS v0.12'deki main.c'nin önişlemciden sonraki hâlini ELLE
 *          göstermek: #include "obs.h" yerine arayüzün metni yapıştırıldı
 *          (H09_K11 ile aynı yöntem). Arayüzdeki yeni bildirimler (kapasite_oku,
 *          min_max_indis, ders_istatistigi, yeni_kapasite, buyut,
 *          kayitlari_birak)
 *          ve satır işaretçisi tipleri burada görülür.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K13_obs_ceviri_birimi.c proje/obs.c -o obs_birim -lm
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
/* ---- #include "obs.h" satırının yerine başlığın metni ---- */
/* obs.h — Mini-OBS v0.12 (AP-1 Hafta 12): modülün ARAYÜZÜ
 * Yenilik : Sabit kapasite (AZAMI_OGRENCI) kalktı. Kayıtlar ÖBEKTE (heap)
 *           dinamik dizilerde tutulur; başlangıç kapasitesi çalışma
 *           zamanında sorulur, dolunca realloc ile ikiye katlanır.
 *           Not matrisleri "satır işaretçisi" tipindedir:
 *               double (*vize)[DERS_SAYISI] = malloc(kapasite * sizeof *vize);
 *           vize, DERS_SAYISI double'lık SATIRLARI gösterir; vize[i][d]
 *           ve v0.11'in double m[][DERS_SAYISI] parametreli fonksiyonları
 *           DEĞİŞMEDEN çalışır (parametredeki m[][DERS_SAYISI] zaten
 *           double (*m)[DERS_SAYISI] demektir).
 *           İstatistik sonuçları işaretçi (çıktı) parametreleriyle döner:
 *           min_max_indis, ders_istatistigi. Tek temizlik yolu:
 *           kayitlari_birak.
 * Not     : 2B dizi parametrelerinde const KULLANILMADI: C17'de
 *           double (*)[3] → const double (*)[3] dönüşümü uyumsuz sayılır
 *           (-pedantic uyarı verir; C23'te düzeltildi). Salt okunurluk
 *           yorumla belgelendi.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>
#include <stddef.h>   /* size_t */

#define DERS_SAYISI 3       /* sütun sayısı: satır tipinin parçası */
#define HARF_SAYISI 9       /* AA, BA, BB, CB, CC, DC, DD, FD, FF */

/* ---- ekran ve girdi ---- */
void baslik_yaz(void);
void menu_goster(void);
int menu_secimi_oku(void);
int kapasite_oku(void);                            /* yeni: >= 1; EOF → -1 */
long long numara_oku(void);
double not_oku(const char *etiket);

/* ---- hesap kuralları (v0.8'den) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
int harf_indeksi(int yuvarlanmis, double final);   /* AA=0 ... FF=8 */
const char *harf_adi(int indeks);
double harf_katsayisi(int indeks);                 /* AA 4,00 ... FF 0,00 */

/* ---- dersler ---- */
const char *ders_adi(int d);
const char *ders_kodu(int d);
int ders_kredisi(int d);                           /* örnek kredi değerleri */

/* ---- 1B dizi desenleri (v0.10'dan; bir SATIR ya da kopyalanmış SÜTUN) ---- */
int numara_bul(const long long no[], int n, long long aranan);
double dizi_ortalama(const double a[], int n);
double standart_sapma(const double a[], int n);
int en_buyuk_indis(const double a[], int n);
int en_kucuk_indis(const double a[], int n);
int esik_ustu_say(const double a[], int n, double esik);
void min_max_indis(const double a[], int n, int *enk, int *enb);   /* yeni */

/* ---- 2B dizi işlemleri (H11) ---- */
void sutun_kopyala(double m[][DERS_SAYISI], int n, int d, double hedef[]);
double yano_hesapla(const double ort_satiri[], const double final_satiri[]);
void ders_harf_dagilimi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                        int n, int sayac[DERS_SAYISI][HARF_SAYISI]);
bool ders_istatistigi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n, int d, double *ortalama, double *sapma,
                      int *enb, int *enk, int *basarili, int *sartli);

/* ---- dinamik bellek (H12) ---- */
int yeni_kapasite(int kapasite);
void *buyut(void *blok, int kapasite, size_t eleman_boyutu);
void kayitlari_birak(long long no[], double vize[][DERS_SAYISI],
                     double final[][DERS_SAYISI], double ort[][DERS_SAYISI]);

/* ---- raporlar ---- */
void ogrenci_ozeti_yaz(long long numara, const double ort_satiri[],
                       const double final_satiri[]);
void ders_istatistikleri_yaz(double ort[][DERS_SAYISI],
                             double final[][DERS_SAYISI], int n);
void transkript_yaz(long long numara, const double vize_satiri[],
                    const double final_satiri[], const double ort_satiri[]);
void harf_tablosu_yaz(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n);
void kayitlari_listele(const long long no[], double ort[][DERS_SAYISI],
                       double final[][DERS_SAYISI], int n);

#endif /* OBS_H */
/* ---- başlığın sonu ---- */

int main(void)
{
    int n = 0;                                    /* dolu satır sayısı */
    int secim = 0;
    bool girdi_bitti = false;

    baslik_yaz();
    int kapasite = kapasite_oku();
    if (kapasite == -1) {
        printf("\nGirdi sona erdi.\n");
        return 1;                                 /* henüz blok yok */
    }
    long long *no = malloc(kapasite * sizeof *no);
    double (*vize)[DERS_SAYISI] = malloc(kapasite * sizeof *vize);
    double (*final)[DERS_SAYISI] = malloc(kapasite * sizeof *final);
    double (*ort)[DERS_SAYISI] = malloc(kapasite * sizeof *ort);
    if (no == NULL || vize == NULL || final == NULL || ort == NULL) {
        printf("Bellek yetersiz: %d öğrencilik yer ayrılamadı.\n", kapasite);
        kayitlari_birak(no, vize, final, ort);    /* free(NULL) güvenli */
        return 1;
    }

    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            girdi_bitti = true;
            break;
        }

        switch (secim) {
        case 1: {
            if (n == kapasite) {              /* dolu: dört blok 2 katına */
                int yeni = yeni_kapasite(kapasite);   /* taşmada -1 */
                bool tamam = (yeni != -1);
                void *g;          /* realloc sonucu ÖNCE geçici işaretçiye */
                /* Biri başarısız olursa kapasite ARTIRILMAZ. Önceden büyümüş
                 * bloklar yine geçerlidir ve eski kayıtları taşır; yalnızca
                 * fazladan yer kaplarlar (zararsız, bir sonraki denemede
                 * realloc onları yeniden kullanır). */
                g = tamam ? buyut(no, yeni, sizeof *no) : NULL;
                if (g != NULL) { no = g; } else { tamam = false; }
                g = tamam ? buyut(vize, yeni, sizeof *vize) : NULL;
                if (g != NULL) { vize = g; } else { tamam = false; }
                g = tamam ? buyut(final, yeni, sizeof *final) : NULL;
                if (g != NULL) { final = g; } else { tamam = false; }
                g = tamam ? buyut(ort, yeni, sizeof *ort) : NULL;
                if (g != NULL) { ort = g; } else { tamam = false; }
                if (!tamam) {
                    printf("  Bellek yetersiz: kapasite artırılamadı (%d"
                           " öğrenci korunuyor).\n", n);
                    break;
                }
                kapasite = yeni;
            }
            printf("\n------------ ÖĞRENCİ %d ------------\n", n + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                girdi_bitti = true;
                break;
            }
            int bulunan = numara_bul(no, n, numara);
            if (bulunan != -1) {
                printf("  Bu numara zaten kayıtlı (sıra %d).\n", bulunan + 1);
                break;
            }
            for (int d = 0; d < DERS_SAYISI; d++) {      /* satırı doldur */
                printf("-- %s (%d kredi) --\n", ders_adi(d), ders_kredisi(d));
                double v = not_oku("Vize notu        : ");
                if (v < 0) {
                    girdi_bitti = true;
                    break;
                }
                double f = not_oku("Final notu       : ");
                if (f < 0) {
                    girdi_bitti = true;
                    break;
                }
                vize[n][d] = v;
                final[n][d] = f;
                ort[n][d] = hesapla_ortalama(v, f);
            }
            if (girdi_bitti) {
                break;
            }
            no[n] = numara;
            ogrenci_ozeti_yaz(numara, ort[n], final[n]);  /* satırlar 1B dizi */
            n++;
            break;
        }
        case 2:
            ders_istatistikleri_yaz(ort, final, n);
            break;
        case 3: {
            if (n == 0) {
                printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
                break;
            }
            long long numara = numara_oku();
            if (numara == -1) {
                girdi_bitti = true;
                break;
            }
            int i = numara_bul(no, n, numara);
            if (i == -1) {
                printf("  Kayıt bulunamadı: %lld\n", numara);
                break;
            }
            transkript_yaz(no[i], vize[i], final[i], ort[i]);
            break;
        }
        case 4:
            harf_tablosu_yaz(ort, final, n);
            break;
        case 5:
            kayitlari_listele(no, ort, final, n);
            break;
        case 6:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n", n);
            break;
        default:
            printf("  Geçersiz seçim: 1-6 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 6 && !girdi_bitti);

    if (girdi_bitti) {
        printf("\nGirdi sona erdi.\n");
    }
    kayitlari_birak(no, vize, final, ort);        /* TEK temizlik yolu */
    return girdi_bitti ? 1 : 0;
}

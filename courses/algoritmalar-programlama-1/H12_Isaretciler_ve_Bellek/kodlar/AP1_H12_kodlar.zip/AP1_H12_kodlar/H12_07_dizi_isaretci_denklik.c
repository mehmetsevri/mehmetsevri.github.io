/* H12_07_dizi_isaretci_denklik.c — Hafta 12 · Örnek 7 (★★): a[i] ≡ *(a + i)
 * Amaç   : Dizi adının çoğu ifadede ilk elemanın adresine dönüştüğünü ve
 *          a[i]'nin TANIMININ *(a + i) olduğunu görmek. Toplama değişmeli
 *          olduğu için i[a] = *(i + a) da aynı kutudur (yalnızca merak;
 *          gerçek kodda yazmayın).
 * Not    : sizeof a dizinin tamamını (4 × 4 = 16 bayt), sizeof p ise
 *          işaretçiyi (8 bayt) ölçer: dizi işaretçi DEĞİLDİR, işaretçiye
 *          dönüşür.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_07_dizi_isaretci_denklik.c -o dizi_isaretci_denklik
 * Örnek  : -> a == &a[0] ? evet
 */
#include <stdio.h>

int main(void)
{
    int a[4] = {10, 20, 30, 40};
    int *p = a;                         /* a, &a[0]'a dönüşür */

    printf(" i  a[i]  *(a + i)  p[i]  *(p + i)  i[a]\n");
    for (int i = 0; i < 4; i++) {
        printf("%2d  %4d  %8d  %4d  %8d  %4d\n",
               i, a[i], *(a + i), p[i], *(p + i), i[a]);
    }
    printf("a == &a[0] ? %s\n", a == &a[0] ? "evet" : "hayır");
    printf("sizeof a = %zu bayt, sizeof p = %zu bayt\n", sizeof a, sizeof p);
    return 0;
}

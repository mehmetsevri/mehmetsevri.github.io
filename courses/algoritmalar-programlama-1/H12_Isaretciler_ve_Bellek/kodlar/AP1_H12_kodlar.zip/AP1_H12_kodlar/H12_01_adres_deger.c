/* H12_01_adres_deger.c — Hafta 12 · Örnek 1 (★): Adres ve değer
 * Amaç   : & (adres) ve * (dolaylama) operatörleri; kutu–ok modeli.
 *          p bir işaretçidir: İÇİNDE x'in adresi durur. *p, "p'nin
 *          gösterdiği kutu", yani x'in kendisidir.
 * Not    : Adresler her çalıştırmada değişir (ASLR, H3); aralarındaki
 *          farklar sabittir. %p bir void * beklediği için (void *) yazılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_01_adres_deger.c -o adres_deger
 * Örnek  : -> *p (gösterdiği değer)   : 42
 */
#include <stdio.h>

int main(void)
{
    int x = 42;
    int *p = &x;                        /* p, x'in adresini tutar */

    printf("x  (değer)              : %d\n", x);
    printf("&x (x'in adresi)        : %p\n", (void *)&x);
    printf("p  (içindeki adres)     : %p\n", (void *)p);
    printf("*p (gösterdiği değer)   : %d\n", *p);
    printf("&p (p'nin kendi adresi) : %p\n", (void *)&p);
    printf("sizeof x = %zu bayt, sizeof p = %zu bayt\n", sizeof x, sizeof p);
    return 0;
}

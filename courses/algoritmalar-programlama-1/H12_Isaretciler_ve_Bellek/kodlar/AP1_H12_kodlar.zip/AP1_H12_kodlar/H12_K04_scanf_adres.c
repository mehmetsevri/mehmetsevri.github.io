/* H12_K04_scanf_adres.c — Hafta 12 · Kavram programı: scanf ve &
 * Amaç   : H3'ün sorusunun yanıtı: scanf okuduğu değeri bir yere YAZMALIDIR;
 *          C'de argümanlar değerle aktarıldığı için yazılacak kutunun
 *          ADRESİ verilir. p zaten bir adres taşıdığından scanf("%d", p)
 *          yazılır: & yoktur, ama yine x'e yazılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K04_scanf_adres.c -o scanf_adres
 * Örnek  : -> x = 9
 */
#include <stdio.h>

int main(void)
{
    int x = 0;
    int *p = &x;

    printf("Bir sayı      : ");
    if (scanf("%d", &x) != 1) {         /* &x: x'in ADRESİ */
        return 1;
    }
    printf("Bir sayı daha : ");
    if (scanf("%d", p) != 1) {          /* p zaten adres: & YOK */
        return 1;
    }
    printf("x = %d\n", x);              /* ikinci okuma da x'e yazdı */
    return 0;
}

# Hafta 12 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` ve `.h` dosyası (68 `.c`, 1 `.h`); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (GCC 13.3, x86-64 Linux, glibc; Mini-OBS için `proje/Makefile`). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (derleme komutu, `$ ./program` satırları, girdiler ve çıktılar; ASLR kapalı `setarch x86_64 -R` çalıştırmaları, AddressSanitizer/LeakSanitizer ve Valgrind raporlarının **tamamı**). Kasıtlı hata içermeyen bütün örnek ve kavram programları ayrıca `-fsanitize=address,undefined` ile temiz çalıştı. Adresler her çalıştırmada değişir (ASLR); ders notu ve şekillerdeki kararlı adresler ASLR kapalı çalıştırmalardandır.

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Ders notu ve sunumdaki kod kesitleri dosyanın **ardışık satırlarıdır** (başlıkta dosya adı ve satır aralığı). `proje/obs.h`’nin içeriği, envanter denetimi için `#include` satırı yerine metni elle yapıştırılmış tek çeviri birimi `H12_K13_obs_ceviri_birimi.c`’de de bulunur.

Envanter denetimi (ortak araç `kod_envanteri.js`, hafta 12): ders notu, sunum ve web’deki her kod parçası bu klasördeki bir dosyada bulundu → **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H12_01_adres_deger.c` | Örnek 1 (★) | Örnek 1 (★): Adres ve değer | sıfır uyarı | 3.2 | 10, 11 (şekil) | h12-adres |
| `H12_02_dolaylama_yazma.c` | Örnek 2 (★) | Örnek 2 (★): Dolaylama ile yazma | sıfır uyarı | 3.3 (metin, şekil) | 12 (şekil) | h12-dolaylama |
| `H12_03_takas.c` | Örnek 3 (★★) | Örnek 3 (★★): Referansla aktarım ile takas | sıfır uyarı | 3.5 (şekil), 4.1 | 16 (şekil), 17 | h12-referans |
| `H12_04_bolum_kalan.c` | Örnek 4 (★★) | Örnek 4 (★★): Birden çok sonuç döndürme | sıfır uyarı | 4.2 | 20 (şekil), 21 | h12-referans |
| `H12_05_min_max.c` | Örnek 5 (★★) | Örnek 5 (★★): Dizi + çıktı parametreleri | sıfır uyarı | 4.2 | 22 | h12-referans |
| `H12_06_isaretci_aritmetigi.c` | Örnek 6 (★★) | Örnek 6 (★★): p++ ile dolaşma | sıfır uyarı | 3.6 (şekil), 4.2 | 27 | h12-aritmetik |
| `H12_07_dizi_isaretci_denklik.c` | Örnek 7 (★★) | Örnek 7 (★★): a[i] ≡ *(a + i) | sıfır uyarı | 3.6 (metin) | 26 (şekil) | h12-aritmetik |
| `H12_08_ters_cevir_isaretci.c` | Örnek 8 (★★) | Örnek 8 (★★): İki işaretçiyle ters çevirme | sıfır uyarı | 4.3 | 29 | h12-aritmetik |
| `H12_09_const_isaretci.c` | Örnek 9 (★★) | Örnek 9 (★★): const ve işaretçiler | sıfır uyarı | 3.7 (şekil), 4.3 (metin) | 30 (şekil) | h12-aritmetik |
| `H12_10_malloc_not_dizisi.c` | Örnek 10 (★★) | Örnek 10 (★★): malloc ve free | sıfır uyarı | 4.3 | 34 (şekil), 35 | h12-dinamik |
| `H12_11_bayt_inceleme.c` | Örnek 11 (★★★) | Örnek 11 (★★★): Baytlara bakmak | sıfır uyarı | 4.3 | 39 (şekil) | h12-dinamik |
| `H12_12_realloc_dinamik_dizi.c` | Örnek 12 (★★★) | Örnek 12 (★★★): Büyüyen dizi | sıfır uyarı | 4.4 | 37, 38 (şekil) | h12-dinamik |
| `H12_13_asan_hatalari.c` | Örnek 13 (★★★) | Örnek 13 (★★★): Hata avı (ASan) | derlenir; kasıtlı bellek hataları (ASan/ASan’sız karşılaştırma) | 4.5 (metin), 8 (metin) | 43 (not) | h12-hatalar |
| `H12_14_fonksiyon_isaretcisi.c` | Örnek 14 (★★★) | Örnek 14 (★★★, meydan okuma) | sıfır uyarı | 4.5 | 48 | h12-fonksiyon-isaretcisi |
| `H12_K01_sizeof_isaretci.c` | Kavram programı | Kavram programı: işaretçinin boyutu | sıfır uyarı | 3.2 (metin) | — | h12-adres |
| `H12_K02_adres_tablosu.c` | Kavram programı | Kavram programı: adres tablosu | sıfır uyarı | 3.1 (metin, şekil) | 9 (şekil) | h12-adres |
| `H12_K03_olcekleme.c` | Kavram programı | Kavram programı: tip ve ölçekleme | sıfır uyarı | 3.6 (şekil) | 24 (şekil) | h12-aritmetik |
| `H12_K04_scanf_adres.c` | Kavram programı | Kavram programı: scanf ve & | sıfır uyarı | 3.5 (metin) | 20 (şekil) | h12-referans |
| `H12_K05_dizi_parametresi.c` | Kavram programı | Kavram programı: dizi parametresi | derlenir; kasıtlı uyarı | 3.6 (metin) | 28 | h12-aritmetik |
| `H12_K06_const_hatalari.c` | Kavram programı | Kavram programı: const ihlalleri | kasıtlı derleme hatası | 3.6 (metin), 3.7 (metin, şekil) | 30 (şekil) | h12-aritmetik |
| `H12_K07_null_guvenli.c` | Kavram programı | Kavram programı: NULL ile güvenli kod | sıfır uyarı | 3.4 (metin) | 14, 34 (şekil) | h12-dolaylama |
| `H12_K08_calloc_sifir.c` | Kavram programı | Kavram programı: calloc | sıfır uyarı | 3.9 (metin) | — | h12-dinamik |
| `H12_K09_bellek_yetersiz.c` | Kavram programı | Kavram programı: NULL dönüşü | sıfır uyarı | 3.9 (metin) | — | h12-dinamik |
| `H12_K10_bellek_haritasi.c` | Kavram programı | Kavram programı: H9 haritasının tamamlanması: yığın, öbek ve sanal bellek bölgeleri | sıfır uyarı | 3.8 (metin, şekil) | 32 (şekil) | h12-kaput |
| `H12_K11_koruma_ihlali.c` | Kavram programı | Kavram programı: segmentation fault | sıfır uyarı; kasıtlı çökme (SIGSEGV, 139) | 3.8 (metin) | 33 (şekil) | h12-kaput |
| `H12_K12_isaretciye_isaretci.c` | Kavram programı | Kavram programı (merak kutusu) | sıfır uyarı | 10 (metin) | 50 (şekil) | h12-fonksiyon-isaretcisi |
| `H12_K13_obs_ceviri_birimi.c` | Kavram programı | Kavram programı: Mini-OBS v0.12 çeviri birimi | sıfır uyarı | — | — | — |
| `H12_K14_takas_testleri.c` | Kavram programı | Kavram programı: takas'ın testleri | sıfır uyarı | 4.1 (metin) | — | h12-referans |
| `alistirmalar/H12_A01_kutu_ok_izleme.c` | Alıştırma 12.1 | Alıştırma 12.1 (★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h12-alistirmalar |
| `alistirmalar/H12_A02_aritmetik_tahmin.c` | Alıştırma 12.2 | Alıştırma 12.2 (★★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h12-alistirmalar |
| `alistirmalar/H12_A03_hata_bul_min_max.c` | Alıştırma 12.3 | Alıştırma 12.3 (★★, hata bul) | derlenir; kasıtlı uyarı | 8 (alıştırma) | — | h12-alistirmalar |
| `alistirmalar/H12_A04_hata_bul_dinamik.c` | Alıştırma 12.4 | Alıştırma 12.4 (★★, hata bul) | sıfır uyarı; kasıtlı bellek/mantık hatası | 8 (alıştırma) | — | h12-alistirmalar |
| `alistirmalar/H12_A05_parsons_dizi_toplam.c` | Alıştırma 12.5 | Alıştırma 12.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h12-alistirmalar |
| `alistirmalar/H12_A06_kod_tamamla_ayir.c` | Alıştırma 12.6 | Alıştırma 12.6 (★★, kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h12-alistirmalar |
| `hata_avcisi/H12_HA1_yildiz_ampersand.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1: * ile & karıştırma | derlenir; kasıtlı uyarı | — | 44 | h12-hata-avcisi |
| `hata_avcisi/H12_HA1_yildiz_ampersand_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 (düzeltilmiş): değeri okumak için *p, adresi almak için &x. | sıfır uyarı | — | 44 | h12-hata-avcisi |
| `hata_avcisi/H12_HA2_int_p_q.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2: int *p, q; | derlenir; kasıtlı uyarı | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA2_int_p_q_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 (düzeltilmiş): her işaretçi adının önüne * yazılır; en güvenlisi her bildirimi ayrı satıra ve ilk değeriyle yazmaktır. | sıfır uyarı | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA3_baslatilmamis.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3: başlatılmamış işaretçi | derlenir; kasıtlı uyarı | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA3_baslatilmamis_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 (düzeltilmiş): işaretçi ya geçerli bir nesnenin adresiyle ya da NULL ile başlatılır; dolaylamadan önce gerçek bir kutuyu gösterdiğinden emin olunur. | sıfır uyarı | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA4_null_dolaylama.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4: NULL'ı dolaylama | sıfır uyarı; kasıtlı bellek/mantık hatası | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA4_null_dolaylama_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4 (düzeltilmiş): NULL dönebilen her işaretçi dolaylanmadan önce denetlenir. | sıfır uyarı | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA5_free_sonrasi.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5: free sonrası kullanım | derlenir; kasıtlı uyarı | 5 (şekil) | 42 (not, şekil) | h12-hata-avcisi |
| `hata_avcisi/H12_HA5_free_sonrasi_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 (düzeltilmiş): blok, son kullanımdan SONRA bırakılır ve işaretçi hemen NULL yapılır; yanlışlıkla yeniden kullanılırsa sessiz bozulma yerine hemen fark edilen bir NULL hatası olur. | sıfır uyarı | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA6_cifte_free.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6: çifte free | derlenir; kasıtlı uyarı | 3.10 (şekil) | 41 (şekil) | h12-hata-avcisi |
| `hata_avcisi/H12_HA6_cifte_free_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 (düzeltilmiş): bloğun tek SAHİBİ (a) onu bir kez bırakır; bloğu gösteren bütün işaretçiler NULL yapılır. free(NULL) etkisiz olduğundan yanlışlıkla tekrarlanan bir free artık zararsızdır. | sıfır uyarı | — | — | h12-hata-avcisi |
| `hata_avcisi/H12_HA7_malloc_sizeof.c` | Hata Avcısı 7 (kasıtlı hata) | Hata Avcısı 7: malloc ve sizeof | sıfır uyarı; kasıtlı bellek/mantık hatası | — | 45 | h12-hata-avcisi |
| `hata_avcisi/H12_HA7_malloc_sizeof_duzeltilmis.c` | Hata Avcısı 7 (düzeltilmiş) | Hata Avcısı 7 (düzeltilmiş): boyut n * sizeof *yeni (eleman sayısı × bir ELEMANIN boyutu); dönüş NULL'a karşı denetlenir ve çağıran da denetler. | sıfır uyarı | — | 45 | h12-hata-avcisi |
| `hata_avcisi/H12_HA8_yerel_adres.c` | Hata Avcısı 8 (kasıtlı hata) | Hata Avcısı 8: yerel adres döndürme | derlenir; kasıtlı uyarı | — | 46 | h12-hata-avcisi |
| `hata_avcisi/H12_HA8_yerel_adres_duzeltilmis.c` | Hata Avcısı 8 (düzeltilmiş) | Hata Avcısı 8 (düzeltilmiş): sonuç ÖBEKTE ayrılır; blok fonksiyondan sonra da yaşar. | sıfır uyarı | — | 46 | h12-hata-avcisi |
| `hata_avcisi/H12_HA9_sizinti.c` | Hata Avcısı 9 (kasıtlı hata) | Hata Avcısı 9: bellek sızıntısı | sıfır uyarı; kasıtlı bellek/mantık hatası | 3.10 (şekil) | 41 (şekil), 47 | h12-hata-avcisi |
| `hata_avcisi/H12_HA9_sizinti_duzeltilmis.c` | Hata Avcısı 9 (düzeltilmiş) | Hata Avcısı 9 (düzeltilmiş): sonuç hesaplanıp bir değişkende saklanır, blok bırakılır, sonra döner. | sıfır uyarı | — | 47 | h12-hata-avcisi |
| `proje/main.c` | Mini-OBS v0.12 · main.c | Mini-OBS v0.12 (AP-1 Hafta 12): menü döngüsü + dinamik kayıtlar | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 7 | 51 (şekil) | h12-miniobs |
| `proje/obs.c` | Mini-OBS v0.12 · obs.c | Mini-OBS v0.12 (AP-1 Hafta 12): modülün GERÇEKLEMESİ | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 7 (metin, şekil) | 51 (şekil) | h12-miniobs |
| `proje/obs.h` | Mini-OBS v0.12 · başlık | Mini-OBS v0.12 (AP-1 Hafta 12): modülün ARAYÜZÜ | başlık (içeren .c ile derlenir) | 7 (şekil) | 51 (şekil) | — |
| `proje/sizinti_deneyi/main_sizinti.c` | Mini-OBS v0.12 · bilinçli sızıntı kopyası (make sizinti) | Mini-OBS v0.12 · BİLİNÇLİ SIZINTI DENEYİ | sıfır uyarı; kasıtlı sızıntı (LSan/Valgrind kanıtı) | 7 (metin) | — | — |
| `proje/test_obs.c` | Mini-OBS v0.12 · test_obs.c | Mini-OBS v0.12 (AP-1 Hafta 12): birim testleri | sıfır uyarı (Makefile; ASan + Valgrind temiz) | — | — | — |
| `quiz/H12_Q01_satir_oncelikli.c` | Geri çağırma S1 · quiz | Geri çağırma 1 (H11): satır öncelikli | sıfır uyarı | 2 (metin) | 3 | h12-gecen-hafta |
| `quiz/H12_Q02_2b_parametre.c` | Geri çağırma S2 · quiz | Geri çağırma 2 (H11): 2B dizi parametresi | sıfır uyarı | 2 (metin) | 4 | h12-gecen-hafta |
| `quiz/H12_Q03_komsuluk.c` | Geri çağırma S3 · quiz | Geri çağırma 3 (H11): komşuluk ve sınır | sıfır uyarı | 2 (metin) | — | h12-gecen-hafta |
| `quiz/H12_Q04_dolaylama.c` | Kendini sına · quiz | Quiz 4: dolaylama ile yazma | sıfır uyarı | — | 13 | h12-quiz |
| `quiz/H12_Q05_aritmetik.c` | Kendini sına · quiz | Quiz 5: işaretçi aritmetiği | sıfır uyarı | — | 25 | h12-quiz |
| `quiz/H12_Q06_isaretci_kopyasi.c` | Kendini sına · quiz | Quiz 6: işaretçi de değerle gider | sıfır uyarı | — | 19 | h12-quiz |
| `quiz/H12_Q07_sizeof_parametre.c` | Kendini sına · quiz | Quiz 7: dizi ve işaretçi boyutu | sıfır uyarı | — | — | h12-quiz |
| `quiz/H12_Q08_char_adim.c` | Kendini sına · quiz | Quiz 8: ölçekleme | sıfır uyarı | — | — | h12-quiz |
| `quiz/H12_Q09_const.c` | Kendini sına · quiz | Quiz 9: const ve işaretçiler | sıfır uyarı | — | — | h12-quiz |
| `quiz/H12_Q10_malloc_sizeof.c` | Kendini sına · quiz | Quiz 10: sizeof d ile sizeof *d | sıfır uyarı | — | 36 | h12-quiz |
| `quiz/H12_Q11_fonksiyon_isaretcisi.c` | Kendini sına · quiz | Quiz 11: fonksiyon işaretçisi | sıfır uyarı | — | — | h12-quiz |
| `quiz/H12_Q12_int_p_q.c` | Kendini sına · quiz | Quiz 12: bildirimde * neye bağlanır? | sıfır uyarı | — | — | h12-quiz |

**Diğer dosyalar**

- `proje/Makefile` — Mini-OBS v0.12 (`make`, `make test`, `make asan`, `make valgrind`, `make bellek_siniri`, `make sizinti`, `make clean`); `proje/` klasörü `91_Proje_MiniOBS/v0.12/`’nin kodlarının kopyasıdır (asıl yer orası; belge, testler ve gerçek oturum `mini_obs_v0_12_ciktilar.txt` orada).
- `proje/testler/` — T1–T6 test girdileri (`v0_11_girdileri/`: aynı girdilerin v0.11 sürümü, kapasite yanıtı atılmış).
- `AP1_H12_kodlar.zip` — bu klasörün (`.c`, `.h`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H12_kodlar/` klasörü oluşur.

Materyalde doğrudan geçmeyen (envanter ya da arşiv amaçlı) dosyalar: `H12_K13_obs_ceviri_birimi.c`, `proje/test_obs.c`.

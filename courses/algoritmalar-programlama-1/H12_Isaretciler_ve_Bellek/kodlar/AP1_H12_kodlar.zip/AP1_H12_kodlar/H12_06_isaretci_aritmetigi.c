/* H12_06_isaretci_aritmetigi.c — Hafta 12 · Örnek 6 (★★): p++ ile dolaşma
 * Amaç   : Diziyi indis yerine bir işaretçiyle dolaşmak. p + 1, "bir sonraki
 *          bayt" değil "bir sonraki int" demektir: adres sizeof(int) = 4
 *          bayt ilerler. p - a, iki işaretçi arasındaki ELEMAN sayısıdır.
 * Not    : a + 5 dizinin BİR ötesini gösterir: karşılaştırmada kullanmak
 *          serbest, dolaylamak (*(a + 5)) tanımsız davranıştır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_06_isaretci_aritmetigi.c -o isaretci_aritmetigi
 * Örnek  : -> toplam = 150
 */
#include <stdio.h>

int main(void)
{
    int a[5] = {10, 20, 30, 40, 50};
    int *son = a + 5;                   /* son elemanın BİR ötesi */
    int toplam = 0;

    for (int *p = a; p < son; p++) {    /* p++ : bir sonraki int */
        printf("p = %p   *p = %d   p - a = %td\n", (void *)p, *p, p - a);
        toplam += *p;
    }
    printf("toplam = %d\n", toplam);
    printf("a + 1, a'dan %td bayt ileride\n", (char *)(a + 1) - (char *)a);
    return 0;
}

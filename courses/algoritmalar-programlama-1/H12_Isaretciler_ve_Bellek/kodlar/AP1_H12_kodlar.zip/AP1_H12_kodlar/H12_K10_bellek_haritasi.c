/* H12_K10_bellek_haritasi.c — Hafta 12 · Kavram programı: H9 haritasının
 * tamamlanması: yığın, öbek ve sanal bellek bölgeleri
 * Amaç   : Her bölgeden (text, data, bss, heap = öbek, stack = yığın) bir
 *          nesnenin adresini yazdırıp Linux'un bu süreç için tuttuğu SANAL
 *          BELLEK HARİTASINDA (/proc/self/maps) hangi bölgeye ve hangi
 *          izinlere (r okuma, w yazma, x çalıştırma) düştüğünü göstermek.
 *          Küçük malloc blokları [heap] bölgesinden, büyük bloklar (glibc'de
 *          varsayılan eşik 128 KiB) ayrı bir mmap bölgesinden gelir.
 * Not    : Dosya okuma (fopen, fgets) H14'ün, sscanf H13'ün konusudur; burada
 *          yalnızca araç olarak kullanılır. Fonksiyon adresini void *'a
 *          dönüştürmeyi ISO C garanti etmez (H09_K02 ile aynı not).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K10_bellek_haritasi.c -o bellek_haritasi
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int ilk_degerli = 42;                   /* data */
int ilk_degersiz;                       /* bss */

/* adres'i içeren bölgenin satırını /proc/self/maps'ten bulup yazdırır */
void bolge_yaz(const char *etiket, const void *adres)
{
    FILE *f = fopen("/proc/self/maps", "r");
    char satir[256];
    unsigned long bas, son;
    char izin[5];
    while (f != NULL && fgets(satir, sizeof satir, f) != NULL) {
        if (sscanf(satir, "%lx-%lx %4s", &bas, &son, izin) == 3
            && (uintptr_t)adres >= bas && (uintptr_t)adres < son) {
            printf("%-5s %14p  bölge %lx-%lx  izin %s\n",
                   etiket, adres, bas, son, izin);
        }
    }
    if (f != NULL) {
        fclose(f);
    }
}

int main(void)
{
    int yerel = 1;
    int *kucuk = malloc(16 * sizeof *kucuk);    /* 64 bayt */
    char *buyuk = malloc(1024 * 1024);          /* 1 MiB */
    if (kucuk == NULL || buyuk == NULL) {
        free(kucuk);
        free(buyuk);
        return 1;
    }
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
    bolge_yaz("text", (const void *)bolge_yaz);
#pragma GCC diagnostic pop
    bolge_yaz("data", &ilk_degerli);
    bolge_yaz("bss", &ilk_degersiz);
    bolge_yaz("heap", kucuk);
    bolge_yaz("mmap", buyuk);
    bolge_yaz("stack", &yerel);
    free(kucuk);
    free(buyuk);
    return 0;
}

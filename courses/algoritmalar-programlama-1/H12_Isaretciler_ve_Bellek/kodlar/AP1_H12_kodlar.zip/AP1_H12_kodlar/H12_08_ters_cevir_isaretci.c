/* H12_08_ters_cevir_isaretci.c — Hafta 12 · Örnek 8 (★★): İki işaretçiyle
 * ters çevirme
 * Amaç   : H10'daki iki uç algoritmasını (H10_07_ters_cevir.c: i baştan,
 *          j sondan) İKİ İŞARETÇİYLE yazmak: bas ve son kutuları gösterir,
 *          takas(bas, son) ile değiş tokuş edilir, işaretçiler birbirine
 *          yaklaşır. Aynı fonksiyon bir alt diziye de uygulanabilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_08_ters_cevir_isaretci.c -o ters_cevir
 * Örnek  : -> sonra   : 7 6 5 4 3 2 1
 */
#include <stdio.h>

/* Örnek 3'teki takas */
void takas(int *a, int *b)
{
    int gecici = *a;
    *a = *b;
    *b = gecici;
}

/* H10'daki indisli sürüm: i ve j İNDİS */
void ters_cevir_indis(int a[], int n)
{
    for (int i = 0, j = n - 1; i < j; i++, j--) {
        takas(&a[i], &a[j]);
    }
}

/* İşaretçili sürüm: bas ve son ADRES; [bas, son] aralığını ters çevirir */
void ters_cevir(int *bas, int *son)
{
    while (bas < son) {
        printf("  takas: *bas = %d, *son = %d\n", *bas, *son);
        takas(bas, son);
        bas++;
        son--;
    }
}

void yazdir(const char *etiket, const int *a, int n)
{
    printf("%s:", etiket);
    for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
    }
    printf("\n");
}

int main(void)
{
    int a[] = {1, 2, 3, 4, 5, 6, 7};
    int n = (int)(sizeof a / sizeof a[0]);

    yazdir("önce    ", a, n);
    ters_cevir(a, a + n - 1);               /* son eleman: a + n - 1 */
    yazdir("sonra   ", a, n);
    ters_cevir_indis(a, n);                 /* indisli sürüm geri çevirir */
    yazdir("indisle ", a, n);
    ters_cevir(a + 1, a + n - 2);           /* yalnızca ortadaki 5 eleman */
    yazdir("ortası  ", a, n);
    return 0;
}

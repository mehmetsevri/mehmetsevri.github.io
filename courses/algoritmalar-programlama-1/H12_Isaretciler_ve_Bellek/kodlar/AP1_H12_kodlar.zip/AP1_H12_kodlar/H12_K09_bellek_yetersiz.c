/* H12_K09_bellek_yetersiz.c — Hafta 12 · Kavram programı: NULL dönüşü
 * Amaç   : malloc ve realloc istek karşılanamazsa NULL döndürür. Karşılanması
 *          olanaksız bir boyut isteyerek bu dalı GERÇEKTEN çalıştırmak ve
 *          realloc başarısız olduğunda eski bloğun yerinde ve geçerli
 *          kaldığını görmek (geçici işaretçi kalıbı).
 * Not    : İstenen boyut (SIZE_MAX / 2, yaklaşık 8 eksabayt) hiçbir
 *          sistemde karşılanamaz. AddressSanitizer altında çalıştırılacaksa
 *          ASAN_OPTIONS=allocator_may_return_null=1 verilmelidir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_K09_bellek_yetersiz.c -o bellek_yetersiz
 * Örnek  : -> realloc başarısız; eski blok yerinde: 10 20 30
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(void)
{
    size_t dev = SIZE_MAX / 2;
    double *p = malloc(dev);
    printf("malloc(%zu) -> %s\n", dev, p == NULL ? "NULL" : "bir adres");
    free(p);                                    /* NULL ise etkisiz */

    int *dizi = malloc(3 * sizeof *dizi);
    if (dizi == NULL) {
        return 1;
    }
    dizi[0] = 10;
    dizi[1] = 20;
    dizi[2] = 30;
    int *gecici = realloc(dizi, dev);           /* büyütme isteği */
    if (gecici == NULL) {                       /* dizi hâlâ geçerli */
        printf("realloc başarısız; eski blok yerinde: %d %d %d\n",
               dizi[0], dizi[1], dizi[2]);
    } else {
        dizi = gecici;
    }
    free(dizi);
    return 0;
}

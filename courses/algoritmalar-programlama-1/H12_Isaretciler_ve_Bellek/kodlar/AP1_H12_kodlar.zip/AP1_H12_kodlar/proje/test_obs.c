/* test_obs.c — Mini-OBS v0.12 (AP-1 Hafta 12): birim testleri
 * v0.11'in bütün testleri (37 kural + 14 dizi + 10 matris doğrulaması, aynen)
 * + işaretçi (çıktı) parametreli fonksiyonlar (min_max_indis,
 * ders_istatistigi) + dinamik bellek: kapasite büyütme (2 → 4 → 8; veriler
 * korunur), taşma koruması (yeni_kapasite), buyut'un sınır durumları,
 * kayitlari_birak(NULL...) ve büyük kapasitede "realloc başarısız olsa da
 * kayıtlar ve kapasite tutarlı kalır" değişmezi.
 * Derleme : make test       (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c test_obs.c
 *           gcc obs.o test_obs.o -o obs_test -lm && ./obs_test
 * Bellek  : make asan (ASan + LeakSanitizer) · make valgrind ·
 *           make bellek_siniri (ASan ile 1 MiB ayırma sınırı: büyük
 *           kapasite testinde realloc'u GERÇEKTEN başarısız kılar)
 */
#include <stdio.h>
#include <stdlib.h>   /* malloc, free */
#include <limits.h>   /* INT_MAX */
#include <assert.h>
#include <string.h>   /* strcmp: metin karşılaştırmak için */
#include <stdbool.h>
#include "obs.h"

static int sayac = 0;                /* geçen doğrulama sayısı (dosya kapsamı) */
static const double EPS = 1e-9;      /* kayan nokta toleransı */

/* v0.8'deki 37 kural testi (aynen) */
static void kural_testleri(void)
{
    /* hesapla_ortalama: kayan noktada == yerine tolerans */
    assert(hesapla_ortalama(70, 85) - 79.0 < EPS && 79.0 - hesapla_ortalama(70, 85) < EPS); sayac++;
    assert(hesapla_ortalama(0, 0) == 0.0); sayac++;
    assert(hesapla_ortalama(100, 100) - 100.0 < EPS && 100.0 - hesapla_ortalama(100, 100) < EPS); sayac++;

    /* yuvarla: .5 yukarı, altı aşağı */
    assert(yuvarla(59.5) == 60); sayac++;
    assert(yuvarla(59.4) == 59); sayac++;
    assert(yuvarla(0.0) == 0); sayac++;
    assert(yuvarla(100.0) == 100); sayac++;

    /* harf_notu: her kademenin iki sınırı ve baraj */
    assert(strcmp(harf_notu(100, 100), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(90, 90), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(89, 89), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(81, 81), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(80, 80), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(73, 73), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(72, 72), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(66, 66), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(65, 65), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(60, 60), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(59, 59), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(50, 50), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(49, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(40, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(39, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(30, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(29, 50), "FF") == 0); sayac++;
    assert(strcmp(harf_notu(95, 49.9), "FF") == 0); sayac++;   /* baraj */

    /* gecti_mi / sartli_mi */
    assert(gecti_mi(60, 50)); sayac++;
    assert(!gecti_mi(59, 80)); sayac++;
    assert(!gecti_mi(95, 49.9)); sayac++;
    assert(sartli_mi(50, 50)); sayac++;
    assert(sartli_mi(59, 60)); sayac++;
    assert(!sartli_mi(60, 60)); sayac++;
    assert(!sartli_mi(49, 60)); sayac++;
    assert(!sartli_mi(55, 45)); sayac++;

    /* durum_metni */
    assert(strcmp(durum_metni(79, 85), "BAŞARILI") == 0); sayac++;
    assert(strcmp(durum_metni(54, 70), "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)") == 0); sayac++;
    assert(strcmp(durum_metni(47, 48), "BAŞARISIZ (final barajı)") == 0); sayac++;
    assert(strcmp(durum_metni(45, 50), "BAŞARISIZ") == 0); sayac++;
}

/* Kayan nokta karşılaştırması: |x - y| < EPS */
static bool yakin(double x, double y)
{
    return x - y < EPS && y - x < EPS;
}

/* Yeni (H10): dizi fonksiyonları */
static void dizi_testleri(void)
{
    const long long no[] = {2301010045, 2301010046, 2301010047};
    assert(numara_bul(no, 3, 2301010046) == 1); sayac++;
    assert(numara_bul(no, 3, 2301010099) == -1); sayac++;
    assert(numara_bul(no, 0, 2301010045) == -1); sayac++;   /* boş dizi */

    const double a[] = {2, 4, 4, 4, 5, 5, 7, 9};             /* μ = 5, σ = 2 */
    int n = (int)(sizeof a / sizeof a[0]);
    assert(yakin(dizi_ortalama(a, n), 5.0)); sayac++;
    assert(yakin(standart_sapma(a, n), 2.0)); sayac++;
    assert(en_buyuk_indis(a, n) == 7); sayac++;
    assert(en_kucuk_indis(a, n) == 0); sayac++;
    assert(esik_ustu_say(a, n, 5.0) == 2); sayac++;          /* yalnız 7 ve 9 */

    const double esit[] = {3, 8, 8, 1};                      /* eşitlikte İLK indis */
    assert(en_buyuk_indis(esit, 4) == 1); sayac++;
    assert(yakin(standart_sapma(esit, 1), 0.0)); sayac++;    /* tek eleman */

    assert(harf_indeksi(90, 90) == 0 && strcmp(harf_adi(0), "AA") == 0); sayac++;
    assert(harf_indeksi(59, 60) == 5 && strcmp(harf_adi(5), "DC") == 0); sayac++;
    assert(harf_indeksi(95, 49.9) == 8 && strcmp(harf_adi(8), "FF") == 0); sayac++;
    for (int y = 0; y <= 100; y++) {                          /* iki merdiven aynı */
        assert(strcmp(harf_adi(harf_indeksi(y, 60)), harf_notu(y, 60)) == 0);
    }
    sayac++;

}

/* Yeni (H11): 2B dizi testleri */
static void matris_testleri(void)
{
    for (int k = 0; k < HARF_SAYISI; k++) {                   /* 4,00 → 0,00 */
        assert(yakin(harf_katsayisi(k), 4.0 - 0.5 * k));
    }
    sayac++;

    double ort[2][DERS_SAYISI] = {{79.0, 93.0, 54.0}, {46.8, 59.6, 66.0}};
    double fin[2][DERS_SAYISI] = {{85, 95, 70}, {48, 58, 70}};
    double sutun[2];
    sutun_kopyala(ort, 2, 1, sutun);                          /* 2. ders sütunu */
    assert(yakin(sutun[0], 93.0) && yakin(sutun[1], 59.6)); sayac++;

    /* 1. öğrenci: BB (3,00 × 6) + AA (4,00 × 6) + DC (1,50 × 5) = 49,5 / 17
     * = 2,9118 → iki haneye yuvarlanır (Madde 31/2-a): 2,91 */
    assert(yakin(yano_hesapla(ort[0], fin[0]), 2.91)); sayac++;
    /* 2. öğrenci: FF (baraj) + CC (2,00 × 6) + CB (2,50 × 5) = 24,5 / 17
     * = 1,4412 → 1,44 */
    assert(yakin(yano_hesapla(ort[1], fin[1]), 1.44)); sayac++;
    /* Yuvarlama sınırı: üçüncü hane >= 5 ise YUKARI (kesme değil):
     * FF, FF, FD (0,50 × 5) = 2,5 / 17 = 0,14706 → 0,15 (kesilse 0,14) */
    double o3[DERS_SAYISI] = {20, 20, 37}, f3[DERS_SAYISI] = {20, 20, 50};
    assert(yakin(yano_hesapla(o3, f3), 0.15)); sayac++;
    /* Tam değerler: hepsi AA → 4,00; hepsi FF → 0,00 */
    double o4[DERS_SAYISI] = {95, 95, 95}, f4[DERS_SAYISI] = {95, 95, 95};
    assert(yakin(yano_hesapla(o4, f4), 4.00) && yakin(yano_hesapla(o3, o3), 0.00)); sayac++;

    int sayaclar[DERS_SAYISI][HARF_SAYISI];
    ders_harf_dagilimi(ort, fin, 2, sayaclar);
    for (int d = 0; d < DERS_SAYISI; d++) {                   /* her sütun 2 */
        int toplam = 0;
        for (int k = 0; k < HARF_SAYISI; k++) {
            toplam += sayaclar[d][k];
        }
        assert(toplam == 2);
    }
    sayac++;
    assert(sayaclar[0][2] == 1 && sayaclar[0][8] == 1); sayac++;   /* BB, FF */
    assert(sayaclar[1][0] == 1 && sayaclar[1][4] == 1); sayac++;   /* AA, CC */
    assert(sayaclar[2][5] == 1 && sayaclar[2][3] == 1); sayac++;   /* DC, CB */
}

/* Yeni (H12): işaretçi (çıktı) parametreli fonksiyonlar */
static void isaretci_testleri(void)
{
    const double a[] = {2, 4, 4, 4, 5, 5, 7, 9};
    int enk = -1, enb = -1;
    min_max_indis(a, 8, &enk, &enb);
    assert(enk == 0 && enb == 7); sayac++;
    const double esit[] = {3, 8, 8, 1, 1};                   /* eşitlikte İLK */
    min_max_indis(esit, 5, &enk, &enb);
    assert(enb == 1 && enk == 3); sayac++;
    min_max_indis(esit, 1, &enk, &enb);                      /* tek eleman */
    assert(enk == 0 && enb == 0); sayac++;

    double ort[2][DERS_SAYISI] = {{79.0, 93.0, 54.0}, {46.8, 59.6, 66.0}};
    double fin[2][DERS_SAYISI] = {{85, 95, 70}, {48, 58, 70}};
    double o = 0, s = 0;
    int b = -1, k = -1, bas = -1, sar = -1;
    assert(ders_istatistigi(ort, fin, 2, 0, &o, &s, &b, &k, &bas, &sar));
    sayac++;
    assert(yakin(o, (79.0 + 46.8) / 2) && b == 0 && k == 1); sayac++;
    assert(yakin(s, (79.0 - 46.8) / 2)); sayac++;            /* iki eleman */
    assert(bas == 1 && sar == 0); sayac++;                   /* BB; FF baraj */
    assert(ders_istatistigi(ort, fin, 2, 2, &o, &s, &b, &k, &bas, &sar));
    sayac++;
    assert(bas == 1 && sar == 1 && b == 1 && k == 0); sayac++;   /* CB; DC */
}

/* Yeni (H12): dinamik bellek — kapasite büyütme ve temizlik. Büyütme
 * main.c'deki desenle yapılır: buyut'un sonucu ÖNCE geçici işaretçiye
 * alınır, yalnızca başarıda asıl işaretçiye bağlanır. */
static void bellek_testleri(void)
{
    int kapasite = 2, n = 0, adim[2] = {0, 0}, a = 0;
    long long *no = malloc(kapasite * sizeof *no);
    double (*vize)[DERS_SAYISI] = malloc(kapasite * sizeof *vize);
    double (*final)[DERS_SAYISI] = malloc(kapasite * sizeof *final);
    double (*ort)[DERS_SAYISI] = malloc(kapasite * sizeof *ort);
    assert(no != NULL && vize != NULL && final != NULL && ort != NULL);
    sayac++;

    /* Taşma koruması: 2 × kapasite int'e sığmıyorsa -1 */
    assert(yeni_kapasite(2) == 4 && yeni_kapasite(INT_MAX / 2) == INT_MAX - 1);
    sayac++;
    assert(yeni_kapasite(INT_MAX / 2 + 1) == -1); sayac++;

    for (int i = 0; i < 5; i++) {                  /* 5 kayıt: 2 → 4 → 8 */
        if (n == kapasite) {
            int yeni = yeni_kapasite(kapasite);
            void *g = buyut(no, yeni, sizeof *no);
            assert(g != NULL);
            no = g;
            g = buyut(vize, yeni, sizeof *vize);
            assert(g != NULL);
            vize = g;
            g = buyut(final, yeni, sizeof *final);
            assert(g != NULL);
            final = g;
            g = buyut(ort, yeni, sizeof *ort);
            assert(g != NULL);
            ort = g;
            kapasite = yeni;
            adim[a++] = kapasite;
        }
        no[n] = 2301010045 + i;
        for (int d = 0; d < DERS_SAYISI; d++) {
            vize[n][d] = 10 * i + d;
            final[n][d] = 50 + i;
            ort[n][d] = hesapla_ortalama(vize[n][d], final[n][d]);
        }
        n++;
    }
    assert(a == 2 && adim[0] == 4 && adim[1] == 8 && kapasite == 8); sayac++;
    bool korundu = true;                           /* taşınan bloklarda veri */
    for (int i = 0; i < n; i++) {
        korundu = korundu && no[i] == 2301010045 + i
                  && yakin(vize[i][2], 10 * i + 2)
                  && yakin(final[i][0], 50 + i);
    }
    assert(korundu); sayac++;
    assert(numara_bul(no, n, 2301010049) == 4); sayac++;
    kayitlari_birak(no, vize, final, ort);

    /* buyut(NULL, ...) malloc gibi çalışır; kapasite < 1 ise NULL döner ve
     * eski blok yerinde kalır */
    int *p = buyut(NULL, 4, sizeof *p);
    assert(p != NULL);
    p[3] = 7;
    assert(buyut(p, 0, sizeof *p) == NULL && p[3] == 7); sayac++;
    free(p);
    kayitlari_birak(NULL, NULL, NULL, NULL); sayac++;        /* free(NULL) */

    /* Büyük kapasite: büyütme başarılı da olsa başarısız da olsa kayıtlar ve
     * kapasite TUTARLI olmalı (make bellek_siniri: no büyür, vize'nin
     * 1,44 MB'lık yeni bloğu 1 MiB sınırını aşar ve realloc NULL döner) */
    int kap = 30000;
    long long *no2 = malloc(kap * sizeof *no2);
    double (*v2)[DERS_SAYISI] = malloc(kap * sizeof *v2);
    double (*f2)[DERS_SAYISI] = malloc(kap * sizeof *f2);
    double (*o2)[DERS_SAYISI] = malloc(kap * sizeof *o2);
    assert(no2 != NULL && v2 != NULL && f2 != NULL && o2 != NULL);
    for (int i = 0; i < kap; i++) {
        no2[i] = i;
        v2[i][0] = i;
        f2[i][1] = i;
        o2[i][2] = i;
    }
    int yeni = yeni_kapasite(kap);
    bool tamam = (yeni != -1);
    void *g;
    g = tamam ? buyut(no2, yeni, sizeof *no2) : NULL;
    if (g != NULL) { no2 = g; } else { tamam = false; }
    g = tamam ? buyut(v2, yeni, sizeof *v2) : NULL;
    if (g != NULL) { v2 = g; } else { tamam = false; }
    g = tamam ? buyut(f2, yeni, sizeof *f2) : NULL;
    if (g != NULL) { f2 = g; } else { tamam = false; }
    g = tamam ? buyut(o2, yeni, sizeof *o2) : NULL;
    if (g != NULL) { o2 = g; } else { tamam = false; }
    if (tamam) {
        kap = yeni;
    }
    assert(kap == (tamam ? 60000 : 30000));
    for (int i = 0; i < 30000; i++) {
        assert(no2[i] == i && v2[i][0] == i && f2[i][1] == i && o2[i][2] == i);
    }
    sayac++;
    printf("Büyük kapasite: 30000 -> %s\n", tamam ? "60000 (realloc başarılı)"
           : "30000 (realloc NULL döndü; kayıtlar korundu)");
    kayitlari_birak(no2, v2, f2, o2);
}

int main(void)
{
    kural_testleri();
    int kural = sayac;
    dizi_testleri();
    int dizi = sayac - kural;
    matris_testleri();
    int matris = sayac - kural - dizi;
    isaretci_testleri();
    int isaretci = sayac - kural - dizi - matris;
    bellek_testleri();
    printf("Tüm testler geçti (%d doğrulama: %d kural + %d dizi + %d matris"
           " + %d işaretçi + %d bellek).\n", sayac, kural, dizi, matris,
           isaretci, sayac - kural - dizi - matris - isaretci);
    return 0;
}

/* main_sizinti.c — Mini-OBS v0.12 · BİLİNÇLİ SIZINTI DENEYİ
 * BU DOSYA KASITLI HATA İÇERİR: main.c'nin birebir kopyasıdır; YALNIZCA
 * çıkıştaki kayitlari_birak(...) satırı silinmiştir. Program aynı çıktıyı
 * verir; dört öbek bloğu sahipsiz kalır. Amaç, LeakSanitizer ve Valgrind
 * sızıntı raporlarının nasıl göründüğünü görmek (make sizinti).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g \
 *               -fsanitize=address,undefined -I. obs.c \
 *               sizinti_deneyi/main_sizinti.c -o mini_obs_sizinti -lm
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "obs.h"

int main(void)
{
    int n = 0;                                    /* dolu satır sayısı */
    int secim = 0;
    bool girdi_bitti = false;

    baslik_yaz();
    int kapasite = kapasite_oku();
    if (kapasite == -1) {
        printf("\nGirdi sona erdi.\n");
        return 1;                                 /* henüz blok yok */
    }
    long long *no = malloc(kapasite * sizeof *no);
    double (*vize)[DERS_SAYISI] = malloc(kapasite * sizeof *vize);
    double (*final)[DERS_SAYISI] = malloc(kapasite * sizeof *final);
    double (*ort)[DERS_SAYISI] = malloc(kapasite * sizeof *ort);
    if (no == NULL || vize == NULL || final == NULL || ort == NULL) {
        printf("Bellek yetersiz: %d öğrencilik yer ayrılamadı.\n", kapasite);
        kayitlari_birak(no, vize, final, ort);    /* free(NULL) güvenli */
        return 1;
    }

    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            girdi_bitti = true;
            break;
        }

        switch (secim) {
        case 1: {
            if (n == kapasite) {              /* dolu: dört blok 2 katına */
                int yeni = yeni_kapasite(kapasite);   /* taşmada -1 */
                bool tamam = (yeni != -1);
                void *g;          /* realloc sonucu ÖNCE geçici işaretçiye */
                /* Biri başarısız olursa kapasite ARTIRILMAZ. Önceden büyümüş
                 * bloklar yine geçerlidir ve eski kayıtları taşır; yalnızca
                 * fazladan yer kaplarlar (zararsız, bir sonraki denemede
                 * realloc onları yeniden kullanır). */
                g = tamam ? buyut(no, yeni, sizeof *no) : NULL;
                if (g != NULL) { no = g; } else { tamam = false; }
                g = tamam ? buyut(vize, yeni, sizeof *vize) : NULL;
                if (g != NULL) { vize = g; } else { tamam = false; }
                g = tamam ? buyut(final, yeni, sizeof *final) : NULL;
                if (g != NULL) { final = g; } else { tamam = false; }
                g = tamam ? buyut(ort, yeni, sizeof *ort) : NULL;
                if (g != NULL) { ort = g; } else { tamam = false; }
                if (!tamam) {
                    printf("  Bellek yetersiz: kapasite artırılamadı (%d"
                           " öğrenci korunuyor).\n", n);
                    break;
                }
                kapasite = yeni;
            }
            printf("\n------------ ÖĞRENCİ %d ------------\n", n + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                girdi_bitti = true;
                break;
            }
            int bulunan = numara_bul(no, n, numara);
            if (bulunan != -1) {
                printf("  Bu numara zaten kayıtlı (sıra %d).\n", bulunan + 1);
                break;
            }
            for (int d = 0; d < DERS_SAYISI; d++) {      /* satırı doldur */
                printf("-- %s (%d kredi) --\n", ders_adi(d), ders_kredisi(d));
                double v = not_oku("Vize notu        : ");
                if (v < 0) {
                    girdi_bitti = true;
                    break;
                }
                double f = not_oku("Final notu       : ");
                if (f < 0) {
                    girdi_bitti = true;
                    break;
                }
                vize[n][d] = v;
                final[n][d] = f;
                ort[n][d] = hesapla_ortalama(v, f);
            }
            if (girdi_bitti) {
                break;
            }
            no[n] = numara;
            ogrenci_ozeti_yaz(numara, ort[n], final[n]);  /* satırlar 1B dizi */
            n++;
            break;
        }
        case 2:
            ders_istatistikleri_yaz(ort, final, n);
            break;
        case 3: {
            if (n == 0) {
                printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
                break;
            }
            long long numara = numara_oku();
            if (numara == -1) {
                girdi_bitti = true;
                break;
            }
            int i = numara_bul(no, n, numara);
            if (i == -1) {
                printf("  Kayıt bulunamadı: %lld\n", numara);
                break;
            }
            transkript_yaz(no[i], vize[i], final[i], ort[i]);
            break;
        }
        case 4:
            harf_tablosu_yaz(ort, final, n);
            break;
        case 5:
            kayitlari_listele(no, ort, final, n);
            break;
        case 6:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n", n);
            break;
        default:
            printf("  Geçersiz seçim: 1-6 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 6 && !girdi_bitti);

    if (girdi_bitti) {
        printf("\nGirdi sona erdi.\n");
    }
    /* SİLİNDİ: kayitlari_birak(no, vize, final, ort); */
    return girdi_bitti ? 1 : 0;
}

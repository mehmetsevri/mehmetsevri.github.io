/* obs.c — Mini-OBS v0.12 (AP-1 Hafta 12): modülün GERÇEKLEMESİ
 * Yenilik : Kayıtlar ÖBEKTE (heap): kapasite_oku (başlangıç kapasitesi),
 *           yeni_kapasite + buyut (realloc ile ikiye katlama; main geçici
 *           işaretçiyle bağlar), kayitlari_birak (tek temizlik yolu).
 *           İstatistik sonuçları işaretçi (çıktı) parametreleriyle döner:
 *           min_max_indis, ders_istatistigi. Sabit boyutlu yığın tamponu
 *           (double sutun[AZAMI_OGRENCI]) yerine sütun, öbekte n elemanlık
 *           geçici bir diziye kopyalanır ve iş bitince bırakılır.
 *           Hesap kuralları, menü ve rapor biçimleri v0.11 ile AYNIDIR.
 *           Menü: 1) Ekle 2) Ders ist. 3) Transkript 4) Harf tablosu
 *                 5) Listele 6) Çıkış
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107): Madde 25/2 ve 26/2: %40 ara sınav +
 *           %60 yarıyıl sonu sınavı; yarıyıl sonundan 50 alamayan FF.
 *           Madde 30/3: AA 90-100, BA 81-89, BB 73-80, CB 66-72, CC 60-65
 *           başarılı; DC 50-59 şartlı; DD 40-49, FD 30-39, FF 0-29
 *           başarısız. Katsayılar AA 4,0 · BA 3,5 · BB 3,0 · CB 2,5 ·
 *           CC 2,0 · DC 1,5 · DD 1,0 · FD 0,5 · FF 0,0. Madde 30/4-b: YANO
 *           en az 2,00 ise DC başarılı sayılır. Madde 31/2-a: not ortalaması
 *           = Σ(kredi × katsayı) / Σ kredi (kredi: dersin ulusal kredisi,
 *           Madde 4); YANO virgülden sonra iki haneye yuvarlanır (üçüncü
 *           hane >= 5 ise yukarı). Ders ortalaması: (int)(ort + 0.5). Ders
 *           adları ve kredileri ÖRNEKTİR (ders içi modelleme).
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c   (bağlarken -lm)
 */
#include <stdio.h>
#include <stdlib.h>   /* malloc, realloc, free */
#include <limits.h>   /* INT_MAX */
#include <math.h>     /* sqrt */
#include "obs.h"

/* ---- Kurallar: dosya kapsamında static const (yalnızca bu modül) ---- */
static const double VIZE_AGIRLIK = 0.40;
static const double FINAL_AGIRLIK = 0.60;
static const int GECME_ORTALAMA = 60;        /* CC ve üzeri: başarılı */
static const int SARTLI_ORTALAMA = 50;       /* DC: şartlı başarılı */
static const int FINAL_BARAJI = 50;          /* yarıyıl sonu sınavında en az 50 */

static const int SECENEK_SAYISI = 6;        /* menüdeki seçenek sayısı */

/* Girdi tamponunda satırın kalanını (satır sonu dahil) atar.
 * static fonksiyon: yalnızca bu dosyadan çağrılabilir (obs.h'de yok). */
static void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }
}

/* Ekrana program başlığını yazar. */
void baslik_yaz(void)
{
    printf("==========================================\n");
    printf("  MİNİ-OBS v0.12 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");
}

/* Ana menüyü ve seçim istemini yazar. */
void menu_goster(void)
{
    printf("\n---------------- ANA MENÜ ----------------\n");
    printf("  1) Öğrenci ekle (tüm dersler)\n");
    printf("  2) Ders istatistikleri tablosu\n");
    printf("  3) Transkript (numara ile)\n");
    printf("  4) Harf notu dağılımı (ders × harf)\n");
    printf("  5) Kayıtları listele\n");
    printf("  6) Çıkış\n");
    printf("Seçiminiz (1-6)  : ");
}

/* Son koşul: 1-SECENEK_SAYISI arası bir sayı girildiyse onu; sayı değilse ya da
 * aralık dışıysa 0'ı (geçersiz); girdi bittiyse -1'i döndürür. */
int menu_secimi_oku(void)
{
    int secim = 0;
    int okunan = scanf("%d", &secim);
    if (okunan == EOF) {
        return -1;
    }
    if (okunan == 0) {
        satir_temizle();
        return 0;
    }
    if (secim < 1 || secim > SECENEK_SAYISI) {
        return 0;
    }
    return secim;
}

/* Son koşul: 1 ya da daha büyük bir başlangıç kapasitesi (beklenen öğrenci
 * sayısı) döndürür; geçersiz girdide yeniden sorar; girdi biterse -1. */
int kapasite_oku(void)
{
    int kapasite = 0;
    int okunan;
    do {
        printf("Beklenen öğrenci sayısı : ");
        okunan = scanf("%d", &kapasite);
        if (okunan == EOF) {
            return -1;
        }
        if (okunan == 0) {
            satir_temizle();
            kapasite = 0;
        }
        if (kapasite < 1) {
            printf("  Geçersiz: 1 ya da daha büyük bir tamsayı girin.\n");
        }
    } while (kapasite < 1);
    return kapasite;
}

/* Son koşul: pozitif bir öğrenci numarası döndürür; geçersiz girdide
 * yeniden sorar; girdi biterse -1 döndürür. */
long long numara_oku(void)
{
    long long numara = 0;
    int okunan;
    do {
        printf("Öğrenci numarası : ");
        okunan = scanf("%lld", &numara);
        if (okunan == EOF) {
            return -1;
        }
        if (okunan == 0) {
            satir_temizle();
            numara = 0;
        }
        if (numara <= 0) {
            printf("  Geçersiz: pozitif bir numara girin.\n");
        }
    } while (numara <= 0);
    return numara;
}

/* Ön koşul : etiket, ekrana yazılacak istem metnidir.
 * Son koşul: 0-100 aralığında bir not döndürür; geçersiz girdide yeniden
 *            sorar; girdi biterse -1.0 döndürür. (v0.7'de üç kez yazılan
 *            doğrulama bloğunun tek kopyası.) */
double not_oku(const char *etiket)
{
    double deger = -1.0;
    int okunan;
    do {
        printf("%s", etiket);
        okunan = scanf("%lf", &deger);
        if (okunan == EOF) {
            return -1.0;
        }
        if (okunan == 0) {
            satir_temizle();
            deger = -1.0;
        }
        if (deger < 0 || deger > 100) {
            printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
        }
    } while (deger < 0 || deger > 100);
    return deger;
}

/* Ön koşul : 0 <= vize, final <= 100.  Son koşul: %40 + %60 ağırlıklı ortalama. */
double hesapla_ortalama(double vize, double final)
{
    return VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
}

/* Ön koşul : ortalama >= 0.  Son koşul: en yakın tamsayı (.5 yukarı). */
int yuvarla(double ortalama)
{
    return (int)(ortalama + 0.5);
}

/* Son koşul: RTEÜ tablosuna göre harf notu; final barajın altındaysa "FF". */
const char *harf_notu(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "FF";
    } else if (yuvarlanmis >= 90) {
        return "AA";
    } else if (yuvarlanmis >= 81) {
        return "BA";
    } else if (yuvarlanmis >= 73) {
        return "BB";
    } else if (yuvarlanmis >= 66) {
        return "CB";
    } else if (yuvarlanmis >= 60) {
        return "CC";
    } else if (yuvarlanmis >= 50) {
        return "DC";
    } else if (yuvarlanmis >= 40) {
        return "DD";
    } else if (yuvarlanmis >= 30) {
        return "FD";
    }
    return "FF";
}

/* Son koşul: CC ve üzeri ve final barajı aşıldıysa true. */
bool gecti_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= GECME_ORTALAMA;
}

/* Son koşul: DC (50-59) ve final barajı aşıldıysa true. */
bool sartli_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= SARTLI_ORTALAMA
           && yuvarlanmis < GECME_ORTALAMA;
}

/* Son koşul: rapordaki "Durum" satırının metni. */
const char *durum_metni(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "BAŞARISIZ (final barajı)";
    } else if (gecti_mi(yuvarlanmis, final)) {
        return "BAŞARILI";
    } else if (sartli_mi(yuvarlanmis, final)) {
        return "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)";
    }
    return "BAŞARISIZ";
}

/* Son koşul: harf notunun frekans dizisindeki indisi (AA=0 ... FF=8).
 * harf_notu() ile aynı merdiven; sayaç dizisinde "değer = indis". */
int harf_indeksi(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return 8;                                /* FF (baraj) */
    } else if (yuvarlanmis >= 90) {
        return 0;
    } else if (yuvarlanmis >= 81) {
        return 1;
    } else if (yuvarlanmis >= 73) {
        return 2;
    } else if (yuvarlanmis >= 66) {
        return 3;
    } else if (yuvarlanmis >= 60) {
        return 4;
    } else if (yuvarlanmis >= 50) {
        return 5;
    } else if (yuvarlanmis >= 40) {
        return 6;
    } else if (yuvarlanmis >= 30) {
        return 7;
    }
    return 8;
}

/* Ön koşul: 0 <= indeks < HARF_SAYISI.  Son koşul: harfin adı. */
const char *harf_adi(int indeks)
{
    switch (indeks) {
    case 0: return "AA";
    case 1: return "BA";
    case 2: return "BB";
    case 3: return "CB";
    case 4: return "CC";
    case 5: return "DC";
    case 6: return "DD";
    case 7: return "FD";
    default: return "FF";
    }
}

/* Ön koşul: 0 <= indeks < HARF_SAYISI.  Son koşul: harfin katsayısı
 * (AA=0 → 4,00; her kademe 0,50 azalır; FF=8 → 0,00). */
double harf_katsayisi(int indeks)
{
    return 4.0 - 0.5 * indeks;
}

/* Ders bilgileri (ÖRNEK değerler; gerçek ders planına göre değiştirilir). */
const char *ders_adi(int d)
{
    switch (d) {
    case 0: return "Algoritma ve Prog. I";
    case 1: return "Matematik I";
    default: return "Fizik I";
    }
}

const char *ders_kodu(int d)
{
    switch (d) {
    case 0: return "ALG";
    case 1: return "MAT";
    default: return "FIZ";
    }
}

int ders_kredisi(int d)
{
    switch (d) {
    case 0: return 6;
    case 1: return 6;
    default: return 5;
    }
}

/* Doğrusal tarama: aranan numaranın ilk indisi; yoksa -1 (erken çıkış). */
int numara_bul(const long long no[], int n, long long aranan)
{
    for (int i = 0; i < n; i++) {
        if (no[i] == aranan) {
            return i;
        }
    }
    return -1;
}

/* Ön koşul: n >= 1.  Son koşul: a[0..n-1] ortalaması. */
double dizi_ortalama(const double a[], int n)
{
    double toplam = 0.0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
    }
    return toplam / n;
}

/* Ön koşul: n >= 1.  Son koşul: popülasyon standart sapması
 * sqrt( Σ (a[i] - μ)² / n ). İki geçiş: önce μ, sonra sapmalar. */
double standart_sapma(const double a[], int n)
{
    double mu = dizi_ortalama(a, n);
    double kare_toplam = 0.0;
    for (int i = 0; i < n; i++) {
        double fark = a[i] - mu;
        kare_toplam += fark * fark;
    }
    return sqrt(kare_toplam / n);
}

/* Ön koşul: n >= 1.  Son koşul: en büyük elemanın İLK indisi. */
int en_buyuk_indis(const double a[], int n)
{
    int enb = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] > a[enb]) {
            enb = i;
        }
    }
    return enb;
}

/* Ön koşul: n >= 1.  Son koşul: en küçük elemanın İLK indisi. */
int en_kucuk_indis(const double a[], int n)
{
    int enk = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] < a[enk]) {
            enk = i;
        }
    }
    return enk;
}

/* Son koşul: eşikten KESİN büyük eleman sayısı. */
int esik_ustu_say(const double a[], int n, double esik)
{
    int sayi = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] > esik) {
            sayi++;
        }
    }
    return sayi;
}

/* Ön koşul : n >= 1; enk ve enb geçerli adreslerdir.
 * Son koşul: *enk ve *enb, en küçük ve en büyük elemanın İLK indisleri
 *            (tek geçişte; en_kucuk_indis ve en_buyuk_indis ile aynı sonuç). */
void min_max_indis(const double a[], int n, int *enk, int *enb)
{
    *enk = 0;
    *enb = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] < a[*enk]) {
            *enk = i;
        }
        if (a[i] > a[*enb]) {
            *enb = i;
        }
    }
}

/* d. sütunu (bir dersin bütün öğrencileri) 1B diziye kopyalar.
 * Sütun elemanları bellekte bitişik DEĞİLDİR: m[i][d] adresleri arasında
 * DERS_SAYISI * sizeof(double) bayt vardır (satır öncelikli yerleşim). */
void sutun_kopyala(double m[][DERS_SAYISI], int n, int d, double hedef[])
{
    for (int i = 0; i < n; i++) {
        hedef[i] = m[i][d];
    }
}

/* Son koşul: kredi ağırlıklı yarıyıl not ortalaması (YANO), Madde 31/2-a'ya
 * göre iki haneye yuvarlanmış (üçüncü hane >= 5 ise yukarı). Kayan nokta
 * hatası olmasın diye tamsayıyla: s = Σ kredi × (katsayı × 100), K = Σ kredi;
 * yuvarlanmış YANO × 100 = (2s + K) / (2K). Parametreler bir öğrencinin
 * SATIRLARIDIR (ort[i], final[i]). */
double yano_hesapla(const double ort_satiri[], const double final_satiri[])
{
    int s = 0, toplam_kredi = 0;
    for (int d = 0; d < DERS_SAYISI; d++) {
        int k = harf_indeksi(yuvarla(ort_satiri[d]), final_satiri[d]);
        int katsayi100 = (int)(harf_katsayisi(k) * 100.0 + 0.5);  /* 400 … 0 */
        s += ders_kredisi(d) * katsayi100;
        toplam_kredi += ders_kredisi(d);
    }
    int yano100 = (2 * s + toplam_kredi) / (2 * toplam_kredi);
    return yano100 / 100.0;
}

/* Son koşul: sayac[d][k] = d. derste k. harfi alan öğrenci sayısı
 * (2B frekans matrisi). */
void ders_harf_dagilimi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                        int n, int sayac[DERS_SAYISI][HARF_SAYISI])
{
    for (int d = 0; d < DERS_SAYISI; d++) {
        for (int k = 0; k < HARF_SAYISI; k++) {
            sayac[d][k] = 0;
        }
    }
    for (int i = 0; i < n; i++) {
        for (int d = 0; d < DERS_SAYISI; d++) {
            sayac[d][harf_indeksi(yuvarla(ort[i][d]), final[i][d])]++;
        }
    }
}

/* Ön koşul : n >= 1; 0 <= d < DERS_SAYISI; çıktı işaretçileri geçerli.
 * Son koşul: d. dersin (sütunun) ortalaması, standart sapması, en yüksek ve
 *            en düşük ortalamalı öğrencinin İNDİSİ, başarılı ve şartlı
 *            öğrenci sayısı çıktı parametrelerine yazılır; true döner.
 *            Geçici sütun dizisi için bellek ayrılamazsa false döner.
 * Sütun bellekte bitişik olmadığından öbekte n elemanlık geçici bir diziye
 * kopyalanır, v0.10'un 1B fonksiyonlarına verilir ve bırakılır. */
bool ders_istatistigi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n, int d, double *ortalama, double *sapma,
                      int *enb, int *enk, int *basarili, int *sartli)
{
    double *sutun = malloc(n * sizeof *sutun);
    if (sutun == NULL) {
        return false;
    }
    sutun_kopyala(ort, n, d, sutun);
    *ortalama = dizi_ortalama(sutun, n);
    *sapma = standart_sapma(sutun, n);
    min_max_indis(sutun, n, enk, enb);
    *basarili = 0;
    *sartli = 0;
    for (int i = 0; i < n; i++) {
        int y = yuvarla(ort[i][d]);
        if (gecti_mi(y, final[i][d])) {
            (*basarili)++;
        } else if (sartli_mi(y, final[i][d])) {
            (*sartli)++;
        }
    }
    free(sutun);
    return true;
}

/* Ön koşul : kapasite >= 1.
 * Son koşul: kapasitenin iki katı; sonuç int'e sığmıyorsa -1. */
int yeni_kapasite(int kapasite)
{
    if (kapasite > INT_MAX / 2) {
        return -1;                              /* 2 × kapasite taşar */
    }
    return 2 * kapasite;
}

/* Ön koşul : blok NULL ya da malloc/realloc'tan gelmiş bir blok;
 *            eleman_boyutu bir elemanın (satır dizilerinde bir SATIRIN)
 *            bayt sayısı.
 * Son koşul: kapasite elemanlık (yeni yerdeki olabilir) bloğun adresi;
 *            eski içerik korunur. Ayrılamazsa (ya da kapasite < 1 ise)
 *            NULL döner ve eski blok YERİNDE ve geçerlidir: çağıran
 *            sonucu önce GEÇİCİ işaretçiye almalıdır. */
void *buyut(void *blok, int kapasite, size_t eleman_boyutu)
{
    if (kapasite < 1) {
        return NULL;                  /* realloc(p, 0) uygulamaya bağlı */
    }
    return realloc(blok, (size_t)kapasite * eleman_boyutu);
}

/* TEK temizlik yolu: dört bloğu da bırakır. free(NULL) etkisiz olduğundan
 * kısmen başarısız bir ayırmadan sonra da güvenle çağrılabilir. */
void kayitlari_birak(long long no[], double vize[][DERS_SAYISI],
                     double final[][DERS_SAYISI], double ort[][DERS_SAYISI])
{
    free(no);
    free(vize);
    free(final);
    free(ort);
}

/* Eklenen öğrencinin ders ders kısa özeti ve YANO'su. */
void ogrenci_ozeti_yaz(long long numara, const double ort_satiri[],
                       const double final_satiri[])
{
    printf("Öğrenci no  : %lld\n", numara);
    for (int d = 0; d < DERS_SAYISI; d++) {
        int y = yuvarla(ort_satiri[d]);
        printf("%-20s  %6.2f  %s  %s\n", ders_adi(d), ort_satiri[d],
               harf_notu(y, final_satiri[d]), durum_metni(y, final_satiri[d]));
    }
    printf("YANO        : %4.2f\n", yano_hesapla(ort_satiri, final_satiri));
}

/* Her ders (sütun) için ortalama, standart sapma, en yüksek, en düşük,
 * başarılı ve şartlı sayısı. Değerler ders_istatistigi'nin ÇIKTI
 * PARAMETRELERİNDEN gelir; rapor biçimi v0.11 ile aynıdır. */
void ders_istatistikleri_yaz(double ort[][DERS_SAYISI],
                             double final[][DERS_SAYISI], int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    printf("\n------------------------ DERS İSTATİSTİKLERİ ------------------------\n");
    printf("Ders                    Ort.  S.sapma  En yük.  En düş.  Başarılı  Şartlı\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        double ortalama, sapma;
        int enb, enk, basarili, sartli;
        if (!ders_istatistigi(ort, final, n, d, &ortalama, &sapma,
                              &enb, &enk, &basarili, &sartli)) {
            printf("  Bellek yetersiz: %s hesaplanamadı.\n", ders_adi(d));
            continue;
        }
        printf("%-20s  %6.2f  %7.2f  %7.2f  %7.2f  %4d/%-3d  %3d/%-3d\n",
               ders_adi(d), ortalama, sapma, ort[enb][d], ort[enk][d],
               basarili, n, sartli, n);
    }
    printf("---------------------------------------------------------------------\n");
    printf("Öğrenci sayısı: %d\n", n);
}

/* Bir öğrencinin transkripti: ders, kredi, notlar, harf, katsayı, YANO. */
void transkript_yaz(long long numara, const double vize_satiri[],
                    const double final_satiri[], const double ort_satiri[])
{
    bool dc_var = false;
    int toplam_kredi = 0;
    printf("\n----------------------- TRANSKRİPT -----------------------\n");
    printf("Öğrenci no : %lld\n", numara);
    printf("Ders                  Kredi    Vize   Final    Ort.  Harf  Katsayı\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        int y = yuvarla(ort_satiri[d]);
        int k = harf_indeksi(y, final_satiri[d]);
        if (k == 5) {
            dc_var = true;
        }
        toplam_kredi += ders_kredisi(d);
        printf("%-20s  %5d  %6.2f  %6.2f  %6.2f    %s     %4.2f\n", ders_adi(d),
               ders_kredisi(d), vize_satiri[d], final_satiri[d], ort_satiri[d],
               harf_adi(k), harf_katsayisi(k));
    }
    double yano = yano_hesapla(ort_satiri, final_satiri);
    printf("----------------------------------------------------------\n");
    printf("Toplam kredi : %d\n", toplam_kredi);
    printf("YANO         : %4.2f\n", yano);
    if (dc_var) {
        printf("DC notları   : %s\n", yano >= 2.0
               ? "YANO ≥ 2,00 → başarılı sayılır"
               : "YANO < 2,00 → başarısız sayılır");
    }
}

/* Ders × harf frekans matrisini tablo olarak yazar. */
void harf_tablosu_yaz(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    int sayac[DERS_SAYISI][HARF_SAYISI];
    ders_harf_dagilimi(ort, final, n, sayac);
    printf("\n-------------- HARF NOTU DAĞILIMI (ders × harf) --------------\n");
    printf("%-20s", "Ders");
    for (int k = 0; k < HARF_SAYISI; k++) {
        printf("  %s", harf_adi(k));
    }
    printf("\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("%-20s", ders_adi(d));
        for (int k = 0; k < HARF_SAYISI; k++) {
            printf("  %2d", sayac[d][k]);
        }
        printf("\n");
    }
    printf("--------------------------------------------------------------\n");
}

/* Bütün öğrenciler: her dersin ortalaması ve harfi, YANO. */
void kayitlari_listele(const long long no[], double ort[][DERS_SAYISI],
                       double final[][DERS_SAYISI], int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    printf("\n---------------------------- KAYITLAR ----------------------------\n");
    printf("Sıra  Öğrenci no");
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("  %9s", ders_kodu(d));
    }
    printf("   YANO\n");
    for (int i = 0; i < n; i++) {
        printf("%4d  %10lld", i + 1, no[i]);
        for (int d = 0; d < DERS_SAYISI; d++) {
            printf("  %6.2f %s", ort[i][d], harf_notu(yuvarla(ort[i][d]), final[i][d]));
        }
        printf("   %4.2f\n", yano_hesapla(ort[i], final[i]));
    }
    printf("------------------------------------------------------------------\n");
}

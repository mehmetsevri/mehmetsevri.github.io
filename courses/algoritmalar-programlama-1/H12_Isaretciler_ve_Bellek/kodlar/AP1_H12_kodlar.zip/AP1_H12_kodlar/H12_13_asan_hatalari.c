/* H12_13_asan_hatalari.c — Hafta 12 · Örnek 13 (★★★): Hata avı (ASan)
 * BU DOSYA KASITLI HATA İÇERİR: her seçenek bilerek bir bellek hatası yapar.
 * Amaç   : Beş klasik işaretçi hatasını AddressSanitizer (ASan) ile
 *          yakalamak ve raporlarını okumak. ASan'sız derlenen program bu
 *          hataların çoğunda SESSİZCE "çalışır": tehlike de buradadır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              -fsanitize=address H12_13_asan_hatalari.c -o asan_hatalari
 * Çalıştırma: echo 2 | ./asan_hatalari     (seçim 1–5)
 */
#include <stdio.h>
#include <stdlib.h>

static void sinir_disi(void)            /* 1: bloğun ötesine yazma */
{
    int *a = malloc(4 * sizeof *a);
    if (a == NULL) {
        return;
    }
    a[4] = 99;                          /* geçerli indisler 0..3 */
    free(a);
}

static void free_sonrasi(void)          /* 2: bırakılmış bloğu okuma */
{
    int *p = malloc(sizeof *p);
    if (p == NULL) {
        return;
    }
    *p = 7;
    free(p);
    printf("*p = %d\n", *p);            /* p artık SARKAN işaretçi */
}

static void cifte_free(void)            /* 3: aynı bloğu iki kez bırakma */
{
    int *p = malloc(sizeof *p);
    free(p);
    free(p);
}

static void sizinti(void)               /* 4: free unutulmuş blok */
{
    int *p = malloc(100 * sizeof *p);
    if (p != NULL) {
        p[0] = 1;
    }
    p = NULL;                           /* blok sahipsiz kaldı */
}

static void null_dolaylama(void)        /* 5: NULL'ı dolaylama */
{
    int *p = NULL;
    *p = 1;
}

int main(void)
{
    int secim = 0;
    printf("Hata türü (1 sınır dışı, 2 free sonrası, 3 çifte free, "
           "4 sızıntı, 5 NULL): ");
    if (scanf("%d", &secim) != 1) {
        return 1;
    }
    printf("\n");
    switch (secim) {
    case 1: sinir_disi(); break;
    case 2: free_sonrasi(); break;
    case 3: cifte_free(); break;
    case 4: sizinti(); break;
    case 5: null_dolaylama(); break;
    default: printf("Geçersiz seçim.\n"); break;
    }
    printf("Program sona erdi (seçim %d).\n", secim);
    return 0;
}

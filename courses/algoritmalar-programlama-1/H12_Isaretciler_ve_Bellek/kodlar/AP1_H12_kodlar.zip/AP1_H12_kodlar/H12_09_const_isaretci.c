/* H12_09_const_isaretci.c — Hafta 12 · Örnek 9 (★★): const ve işaretçiler
 * Amaç   : const'un YERİ neyin kilitlendiğini belirler (sağdan sola okuyun):
 *            const int *p      → p'nin gösterdiği int salt okunur; p serbest
 *            int *const q      → q'nun kendisi sabit; gösterdiği int serbest
 *            const int *const r → ikisi de kilitli
 *          Fonksiyon parametresindeki const int * "diziyi değiştirmem"
 *          sözüdür. Yasak satırların gerçek derleyici iletileri:
 *          H12_K06_const_hatalari.c.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_09_const_isaretci.c -o const_isaretci
 * Örnek  : -> toplam = 108
 */
#include <stdio.h>

/* const int *: bu fonksiyon dizinin elemanlarını YALNIZCA OKUR */
int toplam(const int *a, int n)
{
    int t = 0;
    for (int i = 0; i < n; i++) {
        t += a[i];                      /* a[i] = 0; yazılamaz */
    }
    return t;
}

int main(void)
{
    int x = 1, y = 2;

    const int *p = &x;                  /* gösterilen salt okunur */
    p = &y;                             /* geçerli: p yön değiştirebilir */

    int *const q = &x;                  /* q sabit, gösterilen serbest */
    *q = 10;                            /* geçerli: x değişir */

    const int *const r = &y;            /* ikisi de kilitli */

    int dizi[] = {4, 8, 15, 16, 23, 42};
    printf("*p = %d, x = %d, *r = %d\n", *p, x, *r);
    printf("toplam = %d\n", toplam(dizi, 6));
    return 0;
}

/* H12_10_malloc_not_dizisi.c — Hafta 12 · Örnek 10 (★★): malloc ve free
 * Amaç   : Öğrenci sayısı ÇALIŞMA ZAMANINDA öğrenilir; dizi öbekten (heap)
 *          malloc ile istenir, dönüş değeri NULL'a karşı denetlenir, iş
 *          bitince free ile geri verilir ve işaretçi NULL yapılır.
 *          Yaşam döngüsü: ayır → denetle → kullan → bırak → NULL.
 * Not    : C'de malloc'un void * dönüşü dönüştürme (cast) gerektirmez.
 *          sizeof *notlar = bir elemanın boyutu (8); tip değişse de doğru.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H12_10_malloc_not_dizisi.c -o malloc_not
 * Örnek  : -> Ortalama: 75.00
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    printf("Kaç öğrenci? ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Geçersiz sayı.\n");
        return 1;
    }
    double *notlar = malloc(n * sizeof *notlar);    /* öbekten n double */
    if (notlar == NULL) {                           /* her zaman denetle */
        printf("Bellek yetersiz.\n");
        return 1;
    }

    double toplam = 0.0;
    for (int i = 0; i < n; i++) {
        printf("%d. not: ", i + 1);
        if (scanf("%lf", &notlar[i]) != 1) {
            printf("Geçersiz not.\n");
            free(notlar);                           /* erken çıkışta da */
            return 1;
        }
        toplam += notlar[i];
    }
    double ortalama = toplam / n;
    printf("Ortalama: %.2f\nOrtalamanın üstü:", ortalama);
    for (int i = 0; i < n; i++) {
        if (notlar[i] > ortalama) {
            printf(" %.1f", notlar[i]);
        }
    }
    printf("\nnotlar (yığında) %p -> blok (öbekte) %p\n",
           (void *)&notlar, (void *)notlar);

    free(notlar);                                   /* bloğu geri ver */
    notlar = NULL;                                  /* sarkmasın */
    return 0;
}

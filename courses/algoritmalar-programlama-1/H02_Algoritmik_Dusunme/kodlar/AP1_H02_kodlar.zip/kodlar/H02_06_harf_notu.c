/* H02_06_harf_notu.c — Hafta 2 · Örnek 6: sınav puanından harf notu
 * Amaç   : çok dallı karar; aralıkları büyükten küçüğe sıralayarak sınamak
 * Not    : basitleştirilmiş örnek ölçek (yönetmelikteki ölçek farklı olabilir)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H02_06_harf_notu.c -o harf_notu
 * Örnek  : girdi "85"  ->  Harf notu: BB
 */
#include <stdio.h>

int main(void)
{
    int puan;
    printf("Puanı girin (0-100):\n");
    scanf("%d", &puan);

    if (puan < 0 || puan > 100) {
        printf("Geçersiz puan: %d\n", puan);
    } else if (puan >= 90) {
        printf("Harf notu: AA\n");
    } else if (puan >= 80) {
        printf("Harf notu: BB\n");
    } else if (puan >= 70) {
        printf("Harf notu: CC\n");
    } else if (puan >= 60) {
        printf("Harf notu: DD\n");
    } else {
        printf("Harf notu: FF\n");
    }
    return 0;
}

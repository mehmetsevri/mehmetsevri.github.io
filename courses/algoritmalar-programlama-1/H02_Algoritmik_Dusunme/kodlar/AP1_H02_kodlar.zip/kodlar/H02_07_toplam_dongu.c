/* H02_07_toplam_dongu.c — Hafta 2 · Örnek 7: 1'den N'e kadar toplam
 * Amaç   : tekrar yapısı; sayaç (i) ve toplayıcı (toplam) değişkenleri
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_07_toplam_dongu.c -o toplam_dongu
 * Örnek  : girdi "5"  ->  Toplam (1..5) = 15
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("N değerini girin:\n");
    scanf("%d", &n);

    int toplam = 0;            /* toplam ← 0            */
    int i = 1;                 /* i ← 1                 */
    while (i <= n) {           /* İKEN i ≤ n YAP        */
        toplam = toplam + i;   /*   toplam ← toplam + i */
        i = i + 1;             /*   i ← i + 1           */
    }                          /* SON                   */

    printf("Toplam (1..%d) = %d\n", n, toplam);
    return 0;
}

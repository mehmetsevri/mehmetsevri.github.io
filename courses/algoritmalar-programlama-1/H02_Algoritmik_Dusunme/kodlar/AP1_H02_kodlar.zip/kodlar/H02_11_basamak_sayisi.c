/* H02_11_basamak_sayisi.c — Hafta 2 · Örnek 11: bir sayının basamak sayısı
 * Amaç   : tekrarlı bölme; sonlanma koşulunun gerekçelendirilmesi
 * Kısıt  : n ≥ 0 (negatif girdi kısıt dışıdır; bkz. test tablosu)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_11_basamak_sayisi.c -o basamak_sayisi
 * Örnek  : girdi "2026"  ->  2026 sayısı 4 basamaklıdır
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Negatif olmayan bir tamsayı girin:\n");
    scanf("%d", &n);

    int sayi = n;           /* girdinin kopyası */
    int basamak = 1;        /* 0'ın da 1 basamağı var */
    while (sayi >= 10) {    /* İKEN sayi ≥ 10 YAP */
        sayi = sayi / 10;   /* sayi ← sayi DIV 10 */
        basamak = basamak + 1;
    }

    printf("%d sayısı %d basamaklıdır\n", n, basamak);
    return 0;
}

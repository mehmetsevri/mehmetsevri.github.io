/* H02_09_n_sayi_en_buyuk.c — Hafta 2 · Örnek 9: N sayının en büyüğü
 * Amaç   : tekrar + seçim birlikteliği; "şimdiye kadarki en iyi" deseni
 * Kısıt  : N ≥ 1
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_09_n_sayi_en_buyuk.c -o n_sayi_en_buyuk
 * Örnek  : girdi "5" ve "34 12 58 7 41"  ->  En büyük: 58
 */
#include <stdio.h>

int main(void)
{
    int n, x;
    printf("Kaç sayı girilecek?\n");
    scanf("%d", &n);
    printf("%d sayı girin:\n", n);

    scanf("%d", &x);
    int en_buyuk = x;   /* ilk sayı: en iyi aday */
    int i = 2;
    while (i <= n) {
        scanf("%d", &x);
        if (x > en_buyuk) {   /* daha büyükse güncelle */
            en_buyuk = x;
        }
        i = i + 1;
    }

    printf("En büyük: %d\n", en_buyuk);
    return 0;
}

/* H02_12_oklid_ebob.c — Hafta 2 · Örnek 12: Öklid algoritması ile EBOB
 * Amaç   : klasik bir algoritma; izleme tablosu ve sonlanmanın gerekçesi
 * Kısıt  : a ≥ 0, b ≥ 0 ve ikisi birden 0 değil
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_12_oklid_ebob.c -o oklid_ebob
 * Örnek  : girdi "48 18"  ->  EBOB(48, 18) = 6
 */
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Negatif olmayan iki tamsayı girin:\n");
    scanf("%d %d", &a, &b);

    int x = a, y = b;           /* girdilerin kopyaları */
    while (y != 0) {            /* İKEN y ≠ 0 YAP  */
        int r = x % y;          /*   r ← x MOD y   */
        x = y;                  /*   x ← y         */
        y = r;                  /*   y ← r         */
    }                           /* SON             */

    printf("EBOB(%d, %d) = %d\n", a, b, x);
    return 0;
}

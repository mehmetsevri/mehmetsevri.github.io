/* H02_02_toplam_ortalama.c — Hafta 2 · Örnek 2: iki sayının toplamı ve ortalaması
 * Amaç   : IPO modeli ve sıralı yapı; sözde kodun C karşılığına ilk bakış
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_02_toplam_ortalama.c -o toplam_ortalama
 * Örnek  : girdi "7 4"  ->  Toplam = 11, Ortalama = 5.50
 */
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("İki tamsayı girin:\n");
    scanf("%d %d", &a, &b);          /* OKU a, b              */

    int toplam = a + b;              /* toplam ← a + b        */
    double ortalama = toplam / 2.0;  /* ortalama ← toplam / 2 */

    printf("Toplam   = %d\n", toplam);       /* YAZ toplam   */
    printf("Ortalama = %.2f\n", ortalama);   /* YAZ ortalama */
    return 0;
}

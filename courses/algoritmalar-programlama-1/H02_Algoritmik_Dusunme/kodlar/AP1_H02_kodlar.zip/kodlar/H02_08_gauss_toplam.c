/* H02_08_gauss_toplam.c — Hafta 2 · Örnek 8: aynı toplamın iki algoritması
 * Amaç   : döngü ile Gauss formülünü sonuç ve adım sayısı yönünden karşılaştırmak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_08_gauss_toplam.c -o gauss_toplam
 * Örnek  : girdi "100"  ->  iki algoritma da 5050; döngü 100 kez döner
 * Sınır  : N ≤ 10000 (daha büyük N'de n * (n + 1) int sınırını aşar; bkz. H3)
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("N değerini girin:\n");
    scanf("%d", &n);

    /* Algoritma A: döngüyle topla, tekrarları say */
    int toplam = 0, i = 1, tekrar = 0;
    while (i <= n) {
        toplam = toplam + i;
        i = i + 1;
        tekrar = tekrar + 1;
    }

    /* Algoritma B: Gauss formülü, tekrar yok */
    int gauss = n * (n + 1) / 2;

    printf("A (döngü): toplam = %d, %d tur\n", toplam, tekrar);
    printf("B (Gauss): toplam = %d, tur yok\n", gauss);
    return 0;
}

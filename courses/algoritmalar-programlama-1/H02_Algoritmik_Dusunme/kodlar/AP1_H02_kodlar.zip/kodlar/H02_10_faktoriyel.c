/* H02_10_faktoriyel.c — Hafta 2 · Örnek 10: faktöriyel (n!)
 * Amaç   : çarpım biriktirme; başlangıç değerinin (carpim ← 1) önemi
 * Kısıt  : 0 ≤ n ≤ 12 (13! int sınırını aşar; bkz. H3)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_10_faktoriyel.c -o faktoriyel
 * Örnek  : girdi "5"  ->  5! = 120
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("n değerini girin (0-12):\n");
    scanf("%d", &n);

    int carpim = 1;           /* carpim ← 1 */
    /* İÇİN i ← 1'DEN n'YE YAP */
    for (int i = 1; i <= n; i = i + 1) {
        carpim = carpim * i;  /* carpim ← carpim × i */
    }                         /* SON */

    printf("%d! = %d\n", n, carpim);
    return 0;
}

/* H02_03_iki_sayi_buyuk.c — Hafta 2 · Örnek 3: iki sayının büyüğü
 * Amaç   : seçim yapısı; akış diyagramındaki karar (◇) sembolünün karşılığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_03_iki_sayi_buyuk.c -o iki_sayi_buyuk
 * Örnek  : girdi "12 9"  ->  Büyük olan: 12
 */
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("İki tamsayı girin:\n");
    scanf("%d %d", &a, &b);

    if (a > b) {                  /* EĞER a > b İSE */
        printf("Büyük olan: %d\n", a);
    } else {                      /* DEĞİLSE */
        printf("Büyük olan: %d\n", b);
    }                             /* SON */
    return 0;
}

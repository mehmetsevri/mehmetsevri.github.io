/* H02_04_tek_cift.c — Hafta 2 · Örnek 4: sayının tek ya da çift olması
 * Amaç   : kalan (MOD) işlemi ve koşul; C'de MOD işlecinin karşılığı %
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H02_04_tek_cift.c -o tek_cift
 * Örnek  : girdi "7"  ->  7 tek sayıdır
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Bir tamsayı girin:\n");
    scanf("%d", &n);

    if (n % 2 == 0) {     /* EĞER n MOD 2 = 0 İSE */
        printf("%d çift sayıdır\n", n);
    } else {
        printf("%d tek sayıdır\n", n);
    }
    return 0;
}

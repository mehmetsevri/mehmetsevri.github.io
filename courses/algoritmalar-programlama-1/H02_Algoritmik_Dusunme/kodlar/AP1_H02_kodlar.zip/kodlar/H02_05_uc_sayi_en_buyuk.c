/* H02_05_uc_sayi_en_buyuk.c — Hafta 2 · Örnek 5: üç sayının en büyüğü
 * Amaç   : iç içe karar ile ardışık güncelleme stratejilerini karşılaştırmak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H02_05_uc_sayi_en_buyuk.c -o uc_sayi_en_buyuk
 * Örnek  : girdi "4 9 7"  ->  iki strateji de 9 bulur
 */
#include <stdio.h>

int main(void)
{
    int a, b, c;
    printf("Üç tamsayı girin:\n");
    scanf("%d %d %d", &a, &b, &c);

    /* Strateji 1: iç içe karar */
    int eb1;
    if (a >= b) {
        if (a >= c) {
            eb1 = a;
        } else {
            eb1 = c;
        }
    } else {
        if (b >= c) {
            eb1 = b;
        } else {
            eb1 = c;
        }
    }

    /* Strateji 2: ardışık güncelleme */
    int eb2 = a;
    if (b > eb2) {
        eb2 = b;
    }
    if (c > eb2) {
        eb2 = c;
    }

    printf("İç içe karar       : %d\n", eb1);
    printf("Ardışık güncelleme : %d\n", eb2);
    return 0;
}

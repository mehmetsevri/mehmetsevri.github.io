/* H02_K01_sozlesme_c.c — Hafta 2 · Kavram: sözde kod sözleşmesinin C karşılıkları (önizleme)
 * Amaç   : Sözde kod sözleşmesi tablosunun "C karşılığı" sütunundaki parçaların ve
 *          "aynı algoritmanın dört ifade biçimi" şeklindeki C panelinin çalışan hâli.
 *          Tablodaki … işareti "gövde buraya gelir" demektir; burada gövdeler kısa printf'lerdir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H02_K01_sozlesme_c.c -o sozlesme_c
 * Örnek  : girdi "7 4"
 */
#include <stdio.h>

int main(void) {
    int x, y;
    int ifade = 9, k = 1, k2 = 0, n = 3;
    int a = 17, b = 5;

    printf("İki tamsayı girin:\n");          /* OKU x, y */
    scanf("%d %d", &x, &y);
    printf("%d\n", x);                       /* YAZ x */
    x = ifade;                               /* x ← ifade */
    printf("%d\n", x);

    /* karşılaştırma ==, !=, <, <=, >, >= : sonuç 1 (doğru) ya da 0 (yanlış) */
    printf("%d %d %d %d %d %d\n", x == y, x != y, x < y, x <= y, x > y, x >= y);
    /* mantıksal bağlaçlar &&, ||, ! (VE, VEYA, DEĞİL) */
    printf("%d %d %d\n", k && k2, k || k2, !k);
    /* aritmetik +, -, *, / */
    printf("%d %d %d %d\n", a + b, a - b, a * b, a / b);
    /* tamsayılarda a DIV b ve a MOD b */
    printf("%d %d\n", a / b, a % b);

    if (k) { printf("k doğru\n"); } else if (k2) { printf("k2 doğru\n"); } else { printf("hiçbiri\n"); }
    while (k) { k = 0; }
    for (int i = 1; i <= n; i = i + 1) { printf("%d ", i); }
    printf("\n");

    /* açıklama */

    /* "dört ifade biçimi" şeklindeki C paneli: iki sayının büyüğü */
    a = x;
    b = y;
    if (a > b) {
        printf("%d\n", a);
    } else {
        printf("%d\n", b);
    }
    return 0;
}

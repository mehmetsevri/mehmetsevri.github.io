# AP-1 · Hafta 2 · Kod dizini

**Algoritmik ve Hesaplamalı Düşünme: Problemden Algoritmaya** — bu klasördeki 14 `.c` dosyasının türü, materyalde (ders notu, sunum, web sayfası) geçtiği yerler ve derleme durumu. Ders notunda, sunumda ve web sayfasında gösterilen her C kod parçası bu dosyalardan birinde harfi harfine bulunur (denetim: `node shared/kod_envanteri.js 2` → EKSİK 0).

## Nasıl derlenir ve çalıştırılır?

- **Linux / macOS (gcc):** `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program && ./program`
- **Windows (MinGW-w64, komut istemi):** `chcp 65001 && gcc -std=c17 -Wall -Wextra -pedantic DOSYA.c -o program.exe && program.exe`
- **Code::Blocks:** *Settings › Compiler › Compiler settings › Other compiler options* alanına `-std=c17 -Wall -Wextra -pedantic` yazın; dosyayı açıp *Build › Build and run* (F9).
- **Girdi vermek:** programı çalıştırıp sayıları klavyeden yazın ya da `echo "7 4" | ./program` (Windows: `echo 7 4 | program.exe`).

Notlar: `ciktilar/` klasörlerindeki her dosya bu ortamda alınmış **gerçek** derleme ve çalıştırma çıktısıdır (GCC 13.3.0, Ubuntu 24.04, x86-64, LP64). macOS'ta `gcc` komutu aslında Clang'i çalıştırdığı için ileti metinleri farklıdır; Windows'ta (MinGW-w64) `long` 4 bayttır ve bazı iletiler farklı olabilir.

`hata_avcisi/` klasöründeki iki dosya başlık yorumunda “BU DOSYA KASITLI HATA İÇERİR” diye işaretlidir: sözdizimi değil **mantık** hatası içerirler; standart komutla (`-O0`) derleyici uyarı vermez, HA1 için `-O2` ile alınan `-Wuninitialized` uyarısı `hata_avcisi/H02_HA1_derleyici_iletisi.txt` dosyasındadır.

Örnek 1 (çay demleme) yalnızca akış diyagramı/sözde koddur; bu yüzden merdiven dosyaları `H02_02`'den başlar. Sözde kod parçaları (ör. `x ← 3`) C kodu olmadığından dosyalanmaz. Sözde kod sözleşmesi tablosunun “C karşılığı” sütunundaki parçalar ve “dört ifade biçimi” şeklindeki C paneli `H02_K01_sozlesme_c.c` kavram programında çalışır hâliyle bulunur (tablodaki … işareti “gövde buraya gelir” demektir).

## Özet

| Tür | Dosya sayısı |
|---|---|
| merdiven örneği | 11 |
| kavram programı | 1 |
| hata avcısı | 2 |
| **Toplam** | **14** |

## Dosyalar

| Dosya | Tür | Açıklama | Materyalde geçtiği yerler | Derleme durumu | Gerçek çıktı |
|---|---|---|---|---|---|
| `H02_02_toplam_ortalama.c` | merdiven örneği | Örnek 2 ★ — iki sayının toplamı ve ortalaması: IPO ve sıralı yapı | **Ders notu:** §4.2 Örnek 2 (kesit)<br>**Sunum:** slayt 28<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 2 | sıfır uyarı | `ciktilar/H02_02_toplam_ortalama.txt` |
| `H02_03_iki_sayi_buyuk.c` | merdiven örneği | Örnek 3 ★ — iki sayının büyüğü: seçim yapısı | **Ders notu:** §4.3 Örnek 3 (kesit)<br>**Sunum:** slayt 29<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 3 | sıfır uyarı | `ciktilar/H02_03_iki_sayi_buyuk.txt` |
| `H02_04_tek_cift.c` | merdiven örneği | Örnek 4 ★ — tek mi çift mi: kalan (MOD, `%`) | **Ders notu:** §4.4 Örnek 4 (kesit)<br>**Sunum:** slayt 30<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 4 | sıfır uyarı | `ciktilar/H02_04_tek_cift.txt` |
| `H02_05_uc_sayi_en_buyuk.c` | merdiven örneği | Örnek 5 ★★ — üç sayının en büyüğü: iç içe karar ve ardışık güncelleme | **Ders notu:** §4.5 Örnek 5 (kesit)<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 5 | sıfır uyarı | `ciktilar/H02_05_uc_sayi_en_buyuk.txt` |
| `H02_06_harf_notu.c` | merdiven örneği | Örnek 6 ★★ — puandan harf notu: çok dallı karar, sınır değer testleri | **Ders notu:** §4.6 Örnek 6 (kesit)<br>**Sunum:** slayt 33<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 6 | sıfır uyarı | `ciktilar/H02_06_harf_notu.txt` |
| `H02_07_toplam_dongu.c` | merdiven örneği | Örnek 7 ★★ (amiral) — 1'den N'e toplam: sayaç ve toplayıcı, İKEN döngüsü | **Ders notu:** §4.7 Örnek 7 (kesit)<br>**Sunum:** slayt 34, 46, 47<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 7 | sıfır uyarı | `ciktilar/H02_07_toplam_dongu.txt`<br>`ciktilar/H02_07_toplam_dongu_asm.txt` |
| `H02_08_gauss_toplam.c` | merdiven örneği | Örnek 8 ★★ — aynı toplam Gauss formülüyle; tur sayısı karşılaştırması | **Ders notu:** §4.8 Örnek 8 (kesit)<br>**Sunum:** slayt 37<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 8 | sıfır uyarı | `ciktilar/H02_08_gauss_toplam.txt`<br>`ciktilar/H02_08_gauss_toplam_asm.txt` |
| `H02_09_n_sayi_en_buyuk.c` | merdiven örneği | Örnek 9 ★★ (amiral) — N sayının en büyüğü: “şimdiye kadarki en iyi” deseni | **Ders notu:** §4.9 Örnek 9 (kesit)<br>**Sunum:** slayt 40<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 9 | sıfır uyarı | `ciktilar/H02_09_n_sayi_en_buyuk.txt` |
| `H02_10_faktoriyel.c` | merdiven örneği | Örnek 10 ★★ — faktöriyel: çarpım biriktirme, başlangıç değeri 1 | **Ders notu:** §4.10 Örnek 10 (kesit)<br>**Sunum:** slayt 41<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 10 | sıfır uyarı | `ciktilar/H02_10_faktoriyel.txt` |
| `H02_11_basamak_sayisi.c` | merdiven örneği | Örnek 11 ★★★ — basamak sayısı: koşulla biten döngü, sonlanma | **Ders notu:** §4.11 Örnek 11 (kesit)<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 11 | sıfır uyarı | `ciktilar/H02_11_basamak_sayisi.txt` |
| `H02_12_oklid_ebob.c` | merdiven örneği | Örnek 12 ★★★ (amiral) — Öklid algoritmasıyla EBOB | **Ders notu:** §4.12 Örnek 12 (kesit)<br>**Sunum:** slayt 45<br>**Web:** Örnek merdiveni: 12 basamak (#h02-ornekler) › Örnek 12 | sıfır uyarı | `ciktilar/H02_12_oklid_ebob.txt` |
| `H02_K01_sozlesme_c.c` | kavram programı | Sözde kod sözleşmesinin C karşılıkları: `scanf`, `printf`, atama, karşılaştırma/mantıksal/aritmetik işleçler, `if … else if … else`, `while`, `for`, açıklama; “dört ifade biçimi” şeklindeki iki sayının büyüğü paneli | **Ders notu:** §3.6 Tablo 2.4 (“C karşılığı” sütunu)<br>**Sunum:** slayt 16 (dört ifade biçimi şekli), slayt 17 (sözleşme tablosu)<br>**Web:** Problemden algoritmaya: temel kavramlar (#h02-kavramlar) › sözde kod sözleşmesi tablosu ve dört ifade biçimi şekli | sıfır uyarı | `ciktilar/H02_K01_sozlesme_c.txt` |
| `hata_avcisi/H02_HA1_ilk_deger_yok.c` | hata avcısı | HA1 — toplayıcıya başlangıç değeri verilmemiş (BU DOSYA KASITLI HATA İÇERİR: mantık hatası) | **Sunum:** slayt 46<br>**Web:** Hata avcısı: derleyicinin yakalayamadıkları (#h02-hata-avcisi) › 1. Başlangıç değeri unutulmuş toplayıcı<br>_Not:_ ders notu §5 Hata Avcısı tablosunda (1. satır); `-O0`'da uyarı yok, `-O2`'de `-Wuninitialized` uyarısı | sıfır uyarı — kasıtlı **mantık** hatası (derleyici yakalamaz) | `hata_avcisi/H02_HA1_derleyici_iletisi.txt` |
| `hata_avcisi/H02_HA2_bir_fark.c` | hata avcısı | HA2 — bir-fark hatası: `<=` yerine `<` (BU DOSYA KASITLI HATA İÇERİR: mantık hatası) | **Sunum:** slayt 47<br>**Web:** Hata avcısı: derleyicinin yakalayamadıkları (#h02-hata-avcisi) › 2. Bir-fark hatası (off-by-one)<br>_Not:_ ders notu §5 Hata Avcısı tablosunda (3. satır) | sıfır uyarı — kasıtlı **mantık** hatası (derleyici yakalamaz) | `hata_avcisi/H02_HA2_derleyici_iletisi.txt` |

Kısaltmalar: *§* ders notu bölümü; *(tam)* dosyanın tamamı, *(kesit)* dosyadan ardışık satırlar gösterilir; web bağlantıları bölüm kimliğidir (`#…`).

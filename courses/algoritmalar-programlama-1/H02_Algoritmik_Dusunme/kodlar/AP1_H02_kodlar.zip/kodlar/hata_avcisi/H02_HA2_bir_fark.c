/* H02_HA2_bir_fark.c — Hafta 2 · Hata Avcısı 2 · BU DOSYA KASITLI HATA İÇERİR (mantık hatası)
 * Hata   : bir-fark hatası (off-by-one): koşulda <= yerine < yazılmış
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H02_HA2_bir_fark.c -o bir_fark
 *          -> uyarı YOK, ama sonuç yanlış: 15 yerine 10
 */
#include <stdio.h>

int main(void)
{
    int n = 5;
    int toplam = 0;
    int i = 1;
    while (i < n) {             /* HATA: i ≤ n olmalıydı; n hiç eklenmez */
        toplam = toplam + i;
        i = i + 1;
    }
    printf("Toplam (1..%d) = %d\n", n, toplam);
    return 0;
}

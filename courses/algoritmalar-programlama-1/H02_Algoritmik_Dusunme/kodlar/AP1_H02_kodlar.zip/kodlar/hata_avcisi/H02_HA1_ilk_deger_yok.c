/* H02_HA1_ilk_deger_yok.c — Hafta 2 · Hata Avcısı 1 · BU DOSYA KASITLI HATA İÇERİR (mantık hatası)
 * Hata   : toplayıcıya başlangıç değeri verilmemiş (toplam ← 0 unutulmuş)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H02_HA1_ilk_deger_yok.c
 *          -> -O0 ile uyarı YOK; -O2 eklenince uyarı gelir (bkz. ileti dosyası)
 *          Sonuç tanımsızdır; bu program ÇALIŞTIRILMAMALIDIR.
 */
#include <stdio.h>

int main(void)
{
    int n = 5;
    int toplam;                 /* HATA: toplam ← 0 yok */
    int i = 1;
    while (i <= n) {
        toplam = toplam + i;
        i = i + 1;
    }
    printf("Toplam (1..%d) = %d\n", n, toplam);
    return 0;
}

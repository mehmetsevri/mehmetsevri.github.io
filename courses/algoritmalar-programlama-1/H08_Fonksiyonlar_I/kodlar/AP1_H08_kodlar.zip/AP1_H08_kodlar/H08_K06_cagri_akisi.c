/* H08_K06_cagri_akisi.c — Hafta 8 · Kavram programı: çağrı akışı
 * Amaç   : main → f → g → f → main yolculuğu. Her fonksiyon çağrıldığı
 *          yere döner; dönüş değeri çağıran ifadenin yerini alır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K06_cagri_akisi.c -o cagri_akisi
 */
#include <stdio.h>

int f(int x);
int g(int z);

int main(void)
{
    printf("1. main: f(3) çağrılıyor\n");
    int r = f(3);
    printf("5. main: r = %d, program bitiyor\n", r);
    return 0;
}

int f(int x)
{
    printf("2.   f : x = %d, g(%d) çağrılıyor\n", x, x + 1);
    int y = g(x + 1);
    printf("4.   f : g'den %d geldi, %d döndürülüyor\n", y, y * 2);
    return y * 2;
}

int g(int z)
{
    printf("3.     g : z = %d, %d döndürülüyor\n", z, z * z);
    return z * z;
}

/* H08_11_zar_frekans.c — Hafta 8 · Örnek 11 (★★): zar simülasyonu ve frekans
 * Amaç   : zar_at() ile n zar atışı; altı yüz için ALTI AYRI sayaç (dizi yok,
 *          bkz. H10). Atış sayısı arttıkça her yüzün oranı 1/6'ya yaklaşır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_11_zar_frekans.c -o zar
 *          Kayıtlı çıktılar yeniden üretilebilir olsun diye sabit tohumla:
 *          gcc ... -DSABIT_TOHUM=2026 H08_11_zar_frekans.c -o zar
 * Örnek  : -> Beklenen oran: her yüz için %16.67 (1/6)
 */
#include <stdio.h>
#include <stdlib.h>                     /* rand, srand */
#include <time.h>                       /* time */

int zar_at(void);
double yuzde(int sayac, int toplam);
void satir_yaz(int yuz, int sayac, int toplam);

int main(void)
{
#ifdef SABIT_TOHUM
    srand(SABIT_TOHUM);                 /* aynı tohum -> aynı atışlar */
#else
    srand((unsigned)time(NULL));        /* her çalıştırmada farklı */
#endif
    int n;
    printf("Kaç kez zar atılsın? ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int s1 = 0, s2 = 0, s3 = 0, s4 = 0, s5 = 0, s6 = 0;   /* altı sayaç */
    for (int i = 0; i < n; i++) {
        switch (zar_at()) {
        case 1:
            s1++;
            break;
        case 2:
            s2++;
            break;
        case 3:
            s3++;
            break;
        case 4:
            s4++;
            break;
        case 5:
            s5++;
            break;
        default:
            s6++;
            break;
        }
    }
    printf("Yüz   Adet     Oran  (* = %%1)\n");
    satir_yaz(1, s1, n);
    satir_yaz(2, s2, n);
    satir_yaz(3, s3, n);
    satir_yaz(4, s4, n);
    satir_yaz(5, s5, n);
    satir_yaz(6, s6, n);
    printf("Beklenen oran: her yüz için %%16.67 (1/6)\n");
    return 0;
}

/* Son koşul: 1..6 arası bir tamsayı (rand() % 6 + 1). */
int zar_at(void)
{
    return rand() % 6 + 1;
}

/* Ön koşul : toplam > 0.  Son koşul: sayac'ın toplama oranı, yüzde olarak. */
double yuzde(int sayac, int toplam)
{
    return 100.0 * sayac / toplam;
}

/* Bir yüzün satırını yazar: adet, yüzde ve her %1 için bir yıldız. */
void satir_yaz(int yuz, int sayac, int toplam)
{
    double y = yuzde(sayac, toplam);
    printf("%3d %7d  %%%6.2f  ", yuz, sayac, y);
    for (int k = 0; k < (int)(y + 0.5); k++) {
        printf("*");
    }
    printf("\n");
}

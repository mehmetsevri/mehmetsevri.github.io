/* H08_Q12_bilesim.c — Hafta 8 · Web quiz: fonksiyon bileşimi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q12_bilesim.c -o q12
 */
#include <stdio.h>

int kare(int x);
int max2(int a, int b);

int main(void)
{
    printf("%d\n", kare(max2(-5, 3)) + max2(kare(-5), 3));
    return 0;
}

int kare(int x)
{
    return x * x;
}

int max2(int a, int b)
{
    if (a >= b) {
        return a;
    }
    return b;
}

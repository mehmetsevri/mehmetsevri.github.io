/* H08_Q14_void_deger.c — Hafta 8 · Web quiz: void fonksiyonun "değeri"
 * BU DOSYA KASITLI HATA İÇERİR: void fonksiyon değer döndürmez; sonucunu
 * bir değişkene atamaya çalışmak derleme hatasıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q14_void_deger.c -o q14
 */
#include <stdio.h>

void yaz(int n);

int main(void)
{
    int x = yaz(3);
    printf("%d\n", x);
    return 0;
}

void yaz(int n)
{
    printf("%d\n", n);
}

/* H08_Q11_deger_aktarim.c — Hafta 8 · Web quiz: değerle aktarım
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q11_deger_aktarim.c -o q11
 */
#include <stdio.h>

void ikiye_katla(int x);

int main(void)
{
    int n = 5;
    ikiye_katla(n);
    printf("%d\n", n);
    return 0;
}

void ikiye_katla(int x)
{
    x = x * 2;
}

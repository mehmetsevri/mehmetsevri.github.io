/* H08_Q20_kutuphane.c — Hafta 8 · Web quiz: abs ve floor
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q20_kutuphane.c -o q20 -lm
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
    printf("%d\n", abs(-7) + (int)floor(-2.5));
    return 0;
}

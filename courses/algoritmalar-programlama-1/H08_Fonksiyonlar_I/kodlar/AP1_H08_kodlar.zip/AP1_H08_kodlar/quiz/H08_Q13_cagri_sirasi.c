/* H08_Q13_cagri_sirasi.c — Hafta 8 · Web quiz: çağrı sırası
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q13_cagri_sirasi.c -o q13
 */
#include <stdio.h>

int a(int n);
int b(int n);

int main(void)
{
    int r = b(a(1));
    printf(" %d\n", r);
    return 0;
}

int a(int n)
{
    printf("a");
    return n + 1;
}

int b(int n)
{
    printf("b");
    return a(n) * 2;
}

/* H08_Q19_ayni_ad.c — Hafta 8 · Web quiz: aynı adlı parametre ve değişken
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q19_ayni_ad.c -o q19
 */
#include <stdio.h>

int kare(int a);

int main(void)
{
    int a = 3;
    int b = kare(a);
    printf("%d %d\n", a, b);
    return 0;
}

int kare(int a)
{
    a = a * a;
    return a;
}

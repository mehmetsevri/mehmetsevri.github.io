/* H08_Q16_toupper.c — Hafta 8 · Web quiz: toupper'ın dönüş değeri
 * BU DOSYA KASITLI HATA İÇERİR: ilk toupper çağrısının sonucu atılıyor
 * (GCC/glibc "statement with no effect" uyarısı verir).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q16_toupper.c -o q16
 */
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char h = 'k';
    toupper(h);
    printf("%c", h);
    h = toupper(h);
    printf("%c\n", h);
    return 0;
}

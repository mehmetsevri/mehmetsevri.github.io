/* H08_Q01_ic_ice_sayac.c — Hafta 8 · Geçen haftadan (H7): iç içe döngü
 * Soru: İç döngü toplam kaç kez çalışır? Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q01_ic_ice_sayac.c -o q01
 */
#include <stdio.h>

int main(void)
{
    int sayac = 0;
    for (int i = 1; i <= 4; i++) {
        for (int j = i; j <= 4; j++) {
            sayac++;
        }
    }
    printf("%d\n", sayac);
    return 0;
}

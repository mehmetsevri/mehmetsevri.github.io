/* H08_Q18_ndebug.c — Hafta 8 · Web quiz: assert ve NDEBUG
 * Soru: Program -DNDEBUG ile derlenip çalıştırılırsa ne olur?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -DNDEBUG \
 *              H08_Q18_ndebug.c -o q18
 */
#include <stdio.h>
#include <assert.h>

int main(void)
{
    int bakiye = -50;
    assert(bakiye >= 0);
    printf("bakiye = %d\n", bakiye);
    return 0;
}

/* H08_Q15_tamsayi_bolme.c — Hafta 8 · Web quiz: dönüş tipi ile bölme
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q15_tamsayi_bolme.c -o q15
 */
#include <stdio.h>

double ortalama(int a, int b);

int main(void)
{
    printf("%.2f\n", ortalama(3, 4));
    return 0;
}

double ortalama(int a, int b)
{
    return (a + b) / 2;
}

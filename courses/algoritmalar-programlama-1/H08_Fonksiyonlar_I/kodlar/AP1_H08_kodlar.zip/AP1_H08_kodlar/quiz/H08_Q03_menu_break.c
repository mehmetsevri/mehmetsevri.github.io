/* H08_Q03_menu_break.c — Hafta 8 · Geçen haftadan (H7): menü döngüsü
 * Soru: Girdi "1 2 1 3" ise program ne yazdırır? switch içindeki break
 *       neden döngüyü bitirmez?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q03_menu_break.c -o q03
 */
#include <stdio.h>

int main(void)
{
    int secim;
    do {
        if (scanf("%d", &secim) != 1) {
            return 1;
        }
        switch (secim) {
        case 1:
            printf("A");
            break;
        case 2:
            printf("B");
            break;
        default:
            break;
        }
    } while (secim != 3);
    printf(" bitti\n");
    return 0;
}

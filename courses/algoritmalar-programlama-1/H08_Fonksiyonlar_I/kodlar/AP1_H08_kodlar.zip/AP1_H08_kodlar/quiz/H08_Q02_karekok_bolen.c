/* H08_Q02_karekok_bolen.c — Hafta 8 · Geçen haftadan (H7): √n asallık
 * Soru: n = 97 için iyileştirilmiş test (yalnızca tek bölenler, d * d <= n)
 *       kaç bölen dener? Naif test (2..n-1) kaç bölen denerdi?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q02_karekok_bolen.c -o q02
 */
#include <stdio.h>

int main(void)
{
    int n = 97, denenen = 0, asal = 1;
    for (int d = 3; d <= n / d; d += 2) {
        denenen++;
        if (n % d == 0) {
            asal = 0;
            break;
        }
    }
    printf("denenen bölen: %d, asal mı: %d\n", denenen, asal);
    return 0;
}

/* H08_Q17_artik_yil.c — Hafta 8 · Web quiz: bool döndüren fonksiyon
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_Q17_artik_yil.c -o q17
 */
#include <stdio.h>
#include <stdbool.h>

bool is_leap_year(int yil);

int main(void)
{
    printf("%d %d %d\n", is_leap_year(1900), is_leap_year(2000),
           is_leap_year(2026));
    return 0;
}

bool is_leap_year(int yil)
{
    return (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;
}

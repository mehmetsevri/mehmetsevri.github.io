/* H08_K07_asm_cagri.c — Hafta 8 · Kavram programı: çağrı makine düzeyinde
 * Amaç   : gcc -O0 -S ile call/ret ve çerçeve kurulumunu (push rbp /
 *          mov rbp, rsp) görmek; tamsayı argümanların edi/esi, kayan noktalı
 *          argümanların xmm0/xmm1 yazmaçlarıyla gittiğini gözlemek (x86-64
 *          System V ABI); gdb ile dönüş adresini yığında bulmak.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K07_asm_cagri.c -o asm_cagri
 * Assembly: gcc -std=c17 -O0 -S -masm=intel H08_K07_asm_cagri.c
 */
#include <stdio.h>

int topla(int a, int b);
double ortalama2(double x, double y);

int main(void)
{
    int t = topla(3, 4);
    double o = ortalama2(70.0, 85.0);
    printf("topla(3, 4) = %d\n", t);
    printf("ortalama2(70.0, 85.0) = %.1f\n", o);
    return 0;
}

int topla(int a, int b)
{
    return a + b;
}

double ortalama2(double x, double y)
{
    return (x + y) / 2.0;
}

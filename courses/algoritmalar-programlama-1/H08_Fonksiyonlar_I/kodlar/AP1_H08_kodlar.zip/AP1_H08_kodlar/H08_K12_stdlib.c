/* H08_K12_stdlib.c — Hafta 8 · Kavram programı: <stdlib.h>: abs ve exit
 * Amaç   : abs ile mutlak değer; exit ile programı bir alt fonksiyonun
 *          içinden sonlandırmak. EXIT_SUCCESS ve EXIT_FAILURE, işletim
 *          sistemine giden çıkış kodlarının taşınabilir adlarıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K12_stdlib.c -o stdlib_ornek
 */
#include <stdio.h>
#include <stdlib.h>

int bol(int a, int b);

int main(void)
{
    printf("abs(-7) = %d, abs(7) = %d\n", abs(-7), abs(7));
    int a, b;
    printf("İki tamsayı: ");
    if (scanf("%d %d", &a, &b) != 2) {
        return EXIT_FAILURE;
    }
    printf("%d / %d = %d\n", a, b, bol(a, b));
    printf("Program olağan biçimde bitti.\n");
    return EXIT_SUCCESS;
}

/* Ön koşul: b != 0. İhlal edilirse programı EXIT_FAILURE ile bitirir. */
int bol(int a, int b)
{
    if (b == 0) {
        printf("Hata: sıfıra bölme! Program sonlandırılıyor.\n");
        exit(EXIT_FAILURE);             /* main'e dönmeden biter */
    }
    return a / b;
}

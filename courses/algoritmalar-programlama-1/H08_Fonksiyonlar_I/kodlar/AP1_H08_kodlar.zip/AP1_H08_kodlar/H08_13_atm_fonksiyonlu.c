/* H08_13_atm_fonksiyonlu.c — Hafta 8 · Örnek 13 (★★★): yukarıdan aşağıya
 *          tasarım
 * Amaç   : H07_14_atm_menu.c (ara proje) fonksiyonlarla yeniden yapılandırıldı.
 *          Davranış ve çıktı AYNIDIR (aynı girdilerle diff ile doğrulandı).
 *          main yalnızca "ne yapılacağını" söyler; "nasıl"ı alt fonksiyonlar.
 *          Bakiye fonksiyonlara DEĞERLE gider; yeni bakiye return ile döner
 *          (işaretçi yok: H12). H7'de dört kez yazılan scanf + tampon temizleme
 *          bloğu tek bir tamsayi_oku() fonksiyonu oldu.
 * Kurallar: PIN 1234 (eğitsel örnek; gerçek sistemlerde PIN asla kodda
 *          tutulmaz). Başlangıç bakiyesi 1000 TL. Para çekme 10 TL'nin katı
 *          olmalı ve bakiyeyi aşmamalı; para yatırma 1–10000 TL.
 *          3 hatalı PIN → kart bloke, program çıkış kodu 2 ile biter.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_13_atm_fonksiyonlu.c -o atm_f
 * Örnek  : printf '1111\n1234\n1\n3\n250\n2\n100\n4\n' | ./atm_f
 *          -> İyi günler dileriz.
 */
#include <stdio.h>
#include <stdlib.h>                     /* exit, EXIT_FAILURE */
#include <stdbool.h>

/* Kurallar: dosya kapsamındaki sabitler (tüm fonksiyonlar görür; H9) */
const int DOGRU_PIN = 1234;
const int AZAMI_DENEME = 3;
const int YATIRMA_SINIRI = 10000;

void satir_temizle(void);
int tamsayi_oku(int gecersiz);
bool pin_dogrula(void);
void menu_goster(void);
void bakiye_goster(int bakiye);
int para_yatir(int bakiye);
int cekilecek_tutar_oku(int bakiye);
int para_cek(int bakiye);

int main(void)
{
    int bakiye = 1000;                  /* TL, tamsayı: kuruş yok */

    printf("===== AP-1 BANKASI ATM =====\n");
    if (!pin_dogrula()) {
        printf("Kartınız bloke edildi. Lütfen şubenize başvurun.\n");
        return 2;
    }

    int secim;
    do {
        menu_goster();
        secim = tamsayi_oku(0);         /* sayı değilse 0: geçersiz seçim */
        switch (secim) {
        case 1:
            bakiye_goster(bakiye);
            break;
        case 2:
            bakiye = para_yatir(bakiye);    /* kopya gider, yenisi döner */
            break;
        case 3:
            bakiye = para_cek(bakiye);
            break;
        case 4:
            printf("İyi günler dileriz.\n");
            break;
        default:
            printf("  Geçersiz seçim: 1-4 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 4);

    return 0;
}

/* Girdi tamponunda satırın kalanını (satır sonu dahil) atar. */
void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }
}

/* Son koşul: okunan tamsayıyı döndürür. Sayı değilse satırın kalanını atar
 * ve 'gecersiz' değerini döndürür. Girdi biterse programı çıkış kodu 1 ile
 * bitirir (H7'deki "return 1" ile aynı sonuç). */
int tamsayi_oku(int gecersiz)
{
    int deger;
    int okunan = scanf("%d", &deger);
    if (okunan == EOF) {
        printf("\nGirdi sona erdi.\n");
        exit(EXIT_FAILURE);             /* EXIT_FAILURE = 1 */
    }
    if (okunan == 0) {
        satir_temizle();
        return gecersiz;
    }
    return deger;
}

/* Son koşul: AZAMI_DENEME hak içinde doğru PIN girildiyse true. */
bool pin_dogrula(void)
{
    for (int deneme = 1; deneme <= AZAMI_DENEME; deneme++) {
        printf("PIN (%d/%d)           : ", deneme, AZAMI_DENEME);
        if (tamsayi_oku(-1) == DOGRU_PIN) {
            return true;
        }
        printf("  Hatalı PIN.\n");
    }
    return false;
}

void menu_goster(void)
{
    printf("\n1) Bakiye  2) Para yatır  3) Para çek  4) Çıkış\n");
    printf("Seçiminiz           : ");
}

void bakiye_goster(int bakiye)
{
    printf("Bakiyeniz           : %d TL\n", bakiye);
}

/* Son koşul: geçerli tutar (1..YATIRMA_SINIRI) eklenmiş yeni bakiye. */
int para_yatir(int bakiye)
{
    int tutar;
    do {
        printf("Yatırılacak tutar   : ");
        tutar = tamsayi_oku(0);
        if (tutar < 1 || tutar > YATIRMA_SINIRI) {
            printf("  Geçersiz: 1 ile %d TL arasında girin.\n", YATIRMA_SINIRI);
        }
    } while (tutar < 1 || tutar > YATIRMA_SINIRI);
    bakiye += tutar;
    printf("Yatırıldı. Bakiye   : %d TL\n", bakiye);
    return bakiye;
}

/* Ön koşul : bakiye >= 10.
 * Son koşul: 0 (iptal) ya da 10'un katı olan, bakiyeyi aşmayan tutar. */
int cekilecek_tutar_oku(int bakiye)
{
    while (true) {
        printf("Çekilecek (0=iptal) : ");
        int tutar = tamsayi_oku(-1);
        if (tutar == 0) {
            return 0;                   /* vazgeçti */
        } else if (tutar < 0 || tutar % 10 != 0) {
            printf("  Geçersiz: 10 TL'nin katı, pozitif bir tutar girin.\n");
        } else if (tutar > bakiye) {
            printf("  Yetersiz bakiye (bakiye: %d TL).\n", bakiye);
        } else {
            return tutar;
        }
    }
}

/* Son koşul: çekilen tutar düşülmüş yeni bakiye (iptalde aynı bakiye). */
int para_cek(int bakiye)
{
    if (bakiye < 10) {
        printf("  Çekilebilir tutar yok (bakiye: %d TL).\n", bakiye);
        return bakiye;
    }
    int tutar = cekilecek_tutar_oku(bakiye);
    if (tutar == 0) {
        printf("İşlem iptal edildi.\n");
    } else {
        bakiye -= tutar;
        printf("Paranızı alınız. Bakiye: %d TL\n", bakiye);
    }
    return bakiye;
}

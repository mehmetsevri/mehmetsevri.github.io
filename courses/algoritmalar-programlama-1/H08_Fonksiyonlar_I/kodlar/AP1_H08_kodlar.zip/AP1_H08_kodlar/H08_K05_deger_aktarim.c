/* H08_K05_deger_aktarim.c — Hafta 8 · Kavram programı: değerle aktarım
 * Amaç   : artir(sayi) çağrısında parametre x, sayi'nin bir KOPYASIYLA
 *          başlar; x'i değiştirmek sayi'yi değiştirmez. Argüman bir ifade
 *          olabilir: önce değeri hesaplanır, sonra kopyalanır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K05_deger_aktarim.c -o deger_aktarim
 */
#include <stdio.h>

void artir(int x);

int main(void)
{
    int sayi = 5;
    printf("main : önce  sayi = %d\n", sayi);
    artir(sayi);
    printf("main : sonra sayi = %d   (değişmedi)\n", sayi);
    artir(sayi + 10);                   /* önce 15 hesaplanır */
    return 0;
}

void artir(int x)
{
    printf("artir: gelen x = %d\n", x);
    x = x + 1;
    printf("artir: x = %d   (yalnızca kopya değişti)\n", x);
}

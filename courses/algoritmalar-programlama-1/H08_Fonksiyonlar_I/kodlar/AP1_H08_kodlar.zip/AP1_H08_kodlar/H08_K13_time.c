/* H08_K13_time.c — Hafta 8 · Kavram programı: <time.h>: time
 * Amaç   : time(NULL) şu anki takvim zamanını döndürür; Linux'ta (POSIX)
 *          1 Ocak 1970 00:00 UTC'den bu yana geçen saniye sayısıdır.
 *          srand((unsigned)time(NULL)) tohumu buradan gelir (H6).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K13_time.c -o time_ornek
 */
#include <stdio.h>
#include <time.h>

int main(void)
{
    time_t simdi = time(NULL);
    printf("time(NULL) = %lld saniye\n", (long long)simdi);
    printf("           = %lld gün (1 Ocak 1970'ten beri)\n",
           (long long)simdi / (24 * 60 * 60));
    return 0;
}

/* H08_09_basamak_palindrom.c — Hafta 8 · Örnek 9 (★★): küçük fonksiyonlardan
 *          büyük çözüm
 * Amaç   : H06_09 ve H06_10'daki döngüler üç fonksiyona ayrıldı;
 *          is_palindrome kendi döngüsünü yazmaz, ters_cevir'i çağırır.
 * Kısıt  : n >= 0
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_09_basamak_palindrom.c -o basamak_palindrom
 * Örnek  : girdi "12321" -> Palindrom mu?   : evet
 */
#include <stdio.h>
#include <stdbool.h>

int basamak_toplami(int n);
long long ters_cevir(int n);
bool is_palindrome(int n);

int main(void)
{
    int n;
    printf("Negatif olmayan bir tamsayı girin: ");
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("Basamak toplamı : %d\n", basamak_toplami(n));
    printf("Tersi           : %lld\n", ters_cevir(n));
    printf("Palindrom mu?   : %s\n", is_palindrome(n) ? "evet" : "hayır");
    return 0;
}

/* Ön koşul : n >= 0.  Son koşul: basamakların toplamı (0 için 0). */
int basamak_toplami(int n)
{
    int toplam = 0;
    do {
        toplam += n % 10;               /* son basamağı al */
        n /= 10;                        /* son basamağı at */
    } while (n != 0);
    return toplam;
}

/* Ön koşul : n >= 0.  Son koşul: basamakları ters sırada (1230 -> 321).
 * long long: 1999999999'un tersi int'e sığmaz. */
long long ters_cevir(int n)
{
    long long ters = 0;
    while (n > 0) {
        ters = ters * 10 + n % 10;
        n /= 10;
    }
    return ters;
}

/* Ön koşul : n >= 0.  Son koşul: tersi kendisine eşitse true. */
bool is_palindrome(int n)
{
    return ters_cevir(n) == n;
}

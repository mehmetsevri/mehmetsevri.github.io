/* H08_K03_void_ornekleri.c — Hafta 8 · Kavram programı: void'in iki anlamı
 * Amaç   : Dönüş tipindeki void "değer döndürmez"; parametre listesindeki
 *          (void) "parametre almaz" demektir. void fonksiyonda yalın return;
 *          fonksiyondan erken çıkmak için kullanılabilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K03_void_ornekleri.c -o void_ornekleri
 */
#include <stdio.h>

void cizgi(int uzunluk);                /* değer döndürmez, parametre alır */
int hafta_no(void);                     /* parametre almaz, değer döndürür */

int main(void)
{
    cizgi(20);
    printf("AP-1 · Hafta %d\n", hafta_no());
    cizgi(20);
    cizgi(0);                           /* hiçbir şey çizmez */
    return 0;
}

/* uzunluk kadar '-' ve bir satır sonu yazar; uzunluk <= 0 ise hiçbir şey. */
void cizgi(int uzunluk)
{
    if (uzunluk <= 0) {
        return;                         /* değer yok: yalın return */
    }
    for (int i = 0; i < uzunluk; i++) {
        printf("-");
    }
    printf("\n");
}

int hafta_no(void)
{
    return 8;
}

/* H08_HA3_nodiscard_gosterim.c — Hafta 8 · Hata Avcısı 3 (gösterim, C23)
 * BU DOSYA KASITLI HATA İÇERİR: C23'teki [[nodiscard]] özniteliği,
 * dönüş değeri atılan çağrılar için derleyiciden uyarı ister.
 * C17'de yoktur; -std=c2x (GCC 13'te C23'ün adı) ile derleyin.
 * Derleme: gcc -std=c2x -Wall -Wextra -pedantic -g \
 *              H08_HA3_nodiscard_gosterim.c -o ha3n
 */
#include <stdio.h>

[[nodiscard]] long long us_al(int taban, int us);

int main(void)
{
    us_al(2, 10);                       /* derleyici artık uyarır */
    printf("Bitti.\n");
    return 0;
}

long long us_al(int taban, int us)
{
    long long sonuc = 1;
    for (int i = 1; i <= us; i++) {
        sonuc *= taban;
    }
    return sonuc;
}

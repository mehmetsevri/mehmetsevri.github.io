/* H08_HA4_parametre_tipi_duzeltilmis.c — Hafta 8 · Hata Avcısı 4b
 *          (düzeltilmiş sürüm): kesirli kenar için double parametre
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA4_parametre_tipi_duzeltilmis.c -o ha4bd
 */
#include <stdio.h>

double kare_d(double x);

int main(void)
{
    double kenar = 2.5;
    printf("kare_d(%.1f) = %.2f\n", kenar, kare_d(kenar));
    return 0;
}

double kare_d(double x)
{
    return x * x;
}

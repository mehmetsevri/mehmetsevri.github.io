/* H08_HA5_noktali_virgul_duzeltilmis.c — Hafta 8 · Hata Avcısı 5
 *          (düzeltilmiş sürüm): tanım başlığında ; yok
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA5_noktali_virgul_duzeltilmis.c -o ha5d
 */
#include <stdio.h>

int kare(int x)
{
    return x * x;
}

int main(void)
{
    printf("%d\n", kare(4));
    return 0;
}

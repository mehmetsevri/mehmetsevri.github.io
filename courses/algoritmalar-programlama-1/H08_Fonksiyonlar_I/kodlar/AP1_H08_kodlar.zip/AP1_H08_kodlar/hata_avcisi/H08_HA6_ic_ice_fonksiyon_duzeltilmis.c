/* H08_HA6_ic_ice_fonksiyon_duzeltilmis.c — Hafta 8 · Hata Avcısı 6
 *          (düzeltilmiş sürüm): her fonksiyon dosya düzeyinde, yan yana
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA6_ic_ice_fonksiyon_duzeltilmis.c -o ha6d
 */
#include <stdio.h>

int kare(int x);

int main(void)
{
    printf("kare(5) = %d\n", kare(5));
    return 0;
}

int kare(int x)
{
    return x * x;
}

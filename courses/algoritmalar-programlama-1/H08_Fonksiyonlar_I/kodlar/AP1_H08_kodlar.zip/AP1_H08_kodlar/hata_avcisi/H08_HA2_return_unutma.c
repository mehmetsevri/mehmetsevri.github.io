/* H08_HA2_return_unutma.c — Hafta 8 · Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: a <= b olduğunda max2 hiçbir return'e
 * ulaşmadan biter. Çağıran bu dönüş değerini kullandığı için davranış
 * TANIMSIZDIR: derleyiciye ve optimizasyon düzeyine göre farklı sonuçlar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA2_return_unutma.c -o ha2
 */
#include <stdio.h>

int max2(int a, int b);

int main(void)
{
    printf("max2(9, 4) = %d\n", max2(9, 4));
    printf("max2(4, 9) = %d\n", max2(4, 9));
    return 0;
}

int max2(int a, int b)
{
    if (a > b) {
        return a;
    }
}

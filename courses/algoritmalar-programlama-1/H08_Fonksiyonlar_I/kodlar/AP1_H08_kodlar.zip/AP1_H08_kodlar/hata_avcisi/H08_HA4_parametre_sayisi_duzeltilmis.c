/* H08_HA4_parametre_sayisi_duzeltilmis.c — Hafta 8 · Hata Avcısı 4a
 *          (düzeltilmiş sürüm): argüman sayısı parametre sayısına eşit
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA4_parametre_sayisi_duzeltilmis.c -o ha4d
 */
#include <stdio.h>

int max2(int a, int b);

int main(void)
{
    printf("%d\n", max2(5, 8));
    return 0;
}

int max2(int a, int b)
{
    if (a >= b) {
        return a;
    }
    return b;
}

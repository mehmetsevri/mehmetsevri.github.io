/* H08_HA1_prototip_eksik_duzeltilmis.c — Hafta 8 · Hata Avcısı 1
 *          (düzeltilmiş sürüm): main'den önce prototip
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA1_prototip_eksik_duzeltilmis.c -o ha1d
 */
#include <stdio.h>

int kup(int x);                         /* prototip: çağrıdan ÖNCE */

int main(void)
{
    printf("kup(3) = %d\n", kup(3));
    return 0;
}

int kup(int x)
{
    return x * x * x;
}

/* H08_HA2_return_unutma_duzeltilmis.c — Hafta 8 · Hata Avcısı 2
 *          (düzeltilmiş sürüm): her yol bir return'e ulaşır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA2_return_unutma_duzeltilmis.c -o ha2d
 */
#include <stdio.h>

int max2(int a, int b);

int main(void)
{
    printf("max2(9, 4) = %d\n", max2(9, 4));
    printf("max2(4, 9) = %d\n", max2(4, 9));
    return 0;
}

int max2(int a, int b)
{
    if (a > b) {
        return a;
    }
    return b;
}

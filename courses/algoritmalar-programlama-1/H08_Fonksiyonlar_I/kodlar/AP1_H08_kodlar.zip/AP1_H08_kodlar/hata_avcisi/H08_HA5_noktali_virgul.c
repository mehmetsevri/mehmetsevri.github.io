/* H08_HA5_noktali_virgul.c — Hafta 8 · Hata Avcısı 5 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: tanım başlığının sonuna ; konmuş. Başlık
 * bir prototipe dönüşür; arkasından gelen { } bloğu hiçbir fonksiyona
 * ait değildir ve dosya kapsamında blok olamaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA5_noktali_virgul.c -o ha5
 */
#include <stdio.h>

int kare(int x);
{
    return x * x;
}

int main(void)
{
    printf("%d\n", kare(4));
    return 0;
}

/* H08_HA3_donus_kullanilmiyor_duzeltilmis.c — Hafta 8 · Hata Avcısı 3
 *          (düzeltilmiş sürüm): dönüş değerleri atanıyor
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA3_donus_kullanilmiyor_duzeltilmis.c -o ha3d
 */
#include <stdio.h>
#include <ctype.h>

long long us_al(int taban, int us);

int main(void)
{
    char harf = 'k';
    harf = toupper(harf);               /* dönüş değeri saklanıyor */
    printf("Büyük harf: %c\n", harf);

    long long sonuc = us_al(2, 10);
    printf("2^10 = %lld\n", sonuc);
    return 0;
}

long long us_al(int taban, int us)
{
    long long sonuc = 1;
    for (int i = 1; i <= us; i++) {
        sonuc *= taban;
    }
    return sonuc;
}

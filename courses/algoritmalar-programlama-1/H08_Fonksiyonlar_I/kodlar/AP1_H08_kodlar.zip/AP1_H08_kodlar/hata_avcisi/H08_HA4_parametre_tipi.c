/* H08_HA4_parametre_tipi.c — Hafta 8 · Hata Avcısı 4b (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: kare int bekler; 2.5 argümanı prototipteki
 * tipe SESSİZCE dönüştürülür (kesirli kısım atılır: 2). -Wall -Wextra
 * uyarmaz; -Wconversion ile uyarı alınır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA4_parametre_tipi.c -o ha4b
 */
#include <stdio.h>

int kare(int x);

int main(void)
{
    double kenar = 2.5;
    printf("kare(%.1f) = %d\n", kenar, kare(kenar));
    return 0;
}

int kare(int x)
{
    return x * x;
}

/* H08_HA3_donus_kullanilmiyor.c — Hafta 8 · Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: toupper ve us_al değişkeni DEĞİŞTİRMEZ,
 * yeni bir değer DÖNDÜRÜR. Dönüş değeri bir yere atanmazsa kaybolur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA3_donus_kullanilmiyor.c -o ha3
 */
#include <stdio.h>
#include <ctype.h>

long long us_al(int taban, int us);

int main(void)
{
    char harf = 'k';
    toupper(harf);                      /* sonuç kayboldu */
    printf("Büyük harf: %c\n", harf);

    long long sonuc = 1;
    us_al(2, 10);                       /* sonuç kayboldu */
    printf("2^10 = %lld\n", sonuc);
    return 0;
}

long long us_al(int taban, int us)
{
    long long sonuc = 1;
    for (int i = 1; i <= us; i++) {
        sonuc *= taban;
    }
    return sonuc;
}

/* H08_HA4_parametre_sayisi.c — Hafta 8 · Hata Avcısı 4a (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: max2 iki parametre bekler, tek argümanla
 * çağrılıyor. Prototip olduğu için derleyici bunu HATA olarak yakalar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA4_parametre_sayisi.c -o ha4
 */
#include <stdio.h>

int max2(int a, int b);

int main(void)
{
    printf("%d\n", max2(5));
    return 0;
}

int max2(int a, int b)
{
    if (a >= b) {
        return a;
    }
    return b;
}

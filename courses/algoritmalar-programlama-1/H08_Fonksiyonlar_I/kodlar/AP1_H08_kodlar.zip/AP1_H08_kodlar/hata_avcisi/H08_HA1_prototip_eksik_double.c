/* H08_HA1_prototip_eksik_double.c — Hafta 8 · Hata Avcısı 1 (gösterim)
 * BU DOSYA KASITLI HATA İÇERİR: prototipsiz çağrıda derleyici, eski C
 * kuralıyla fonksiyonun int döndürdüğünü VARSAYAR. Tanım double döndürünce
 * varsayım çelişir: "conflicting types" HATASI. (Uyarıyı yok saymak,
 * int döndüren fonksiyonlarda yalnızca şans eseri işe yarar.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA1_prototip_eksik_double.c -o ha1b
 */
#include <stdio.h>

int main(void)
{
    printf("ortalama = %.2f\n", ortalama(70, 85));
    return 0;
}

double ortalama(int a, int b)
{
    return (a + b) / 2.0;
}

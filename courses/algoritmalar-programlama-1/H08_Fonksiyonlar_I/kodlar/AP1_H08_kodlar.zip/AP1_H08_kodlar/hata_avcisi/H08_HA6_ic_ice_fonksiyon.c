/* H08_HA6_ic_ice_fonksiyon.c — Hafta 8 · Hata Avcısı 6 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: kare, main'in İÇİNDE tanımlanmış. ISO C'de
 * fonksiyon içinde fonksiyon tanımlanamaz. GCC bunu bir uzantı (nested
 * functions) olarak kabul eder; -pedantic uyarır, -pedantic-errors ve
 * Clang derlemez. Taşınabilir kod için kare'yi main'in dışına taşıyın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA6_ic_ice_fonksiyon.c -o ha6
 */
#include <stdio.h>

int main(void)
{
    int kare(int x)
    {
        return x * x;
    }

    printf("kare(5) = %d\n", kare(5));
    return 0;
}

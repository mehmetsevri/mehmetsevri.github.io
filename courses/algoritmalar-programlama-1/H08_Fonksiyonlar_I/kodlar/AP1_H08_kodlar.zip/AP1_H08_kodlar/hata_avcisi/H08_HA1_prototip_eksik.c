/* H08_HA1_prototip_eksik.c — Hafta 8 · Hata Avcısı 1 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: kup, main'den SONRA tanımlanmış ve önünde
 * prototip yok. Derleyici çağrıyı gördüğünde kup hakkında hiçbir şey
 * bilmez. GCC 13 (-std=c17) "implicit declaration" UYARISI verip derler;
 * Clang 16+ ve GCC 14+ bunu varsayılan olarak HATA sayar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_HA1_prototip_eksik.c -o ha1
 */
#include <stdio.h>

int main(void)
{
    printf("kup(3) = %d\n", kup(3));
    return 0;
}

int kup(int x)
{
    return x * x * x;
}

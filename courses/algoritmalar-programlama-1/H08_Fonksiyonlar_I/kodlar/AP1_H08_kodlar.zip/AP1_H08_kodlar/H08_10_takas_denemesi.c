/* H08_10_takas_denemesi.c — Hafta 8 · Örnek 10 (★★): "Neden çalışmıyor?"
 * Amaç   : takas(a, b) kendi içinde değerleri değiş tokuş eder, ama main'deki
 *          a ve b DEĞİŞMEZ: fonksiyona değerlerin KOPYALARI gider (değerle
 *          aktarım). Adresler (%p) iki ayrı bellek kutusu olduğunu gösterir.
 *          Çözüm H12'de (işaretçiler): bilinçli olarak açık bırakılan soru.
 * Not    : Adresler her çalıştırmada değişir (ASLR, H3).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_10_takas_denemesi.c -o takas
 * Örnek  : -> main  (sonra): a = 3, b = 7
 */
#include <stdio.h>

void takas(int a, int b);

int main(void)
{
    int a = 3, b = 7;
    printf("main  (önce) : a = %d, b = %d   &a = %p\n", a, b, (void *)&a);
    takas(a, b);
    printf("main  (sonra): a = %d, b = %d   <- değişmedi!\n", a, b);
    return 0;
}

/* AMAÇ: a ile b'yi değiş tokuş etmek. Neden işe yaramıyor? */
void takas(int a, int b)
{
    printf("takas (giriş): a = %d, b = %d   &a = %p\n", a, b, (void *)&a);
    int gecici = a;                     /* H3'teki geçici değişkenli takas */
    a = b;
    b = gecici;
    printf("takas (çıkış): a = %d, b = %d\n", a, b);
}

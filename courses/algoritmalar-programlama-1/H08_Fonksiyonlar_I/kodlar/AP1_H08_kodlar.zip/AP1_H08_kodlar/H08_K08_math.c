/* H08_K08_math.c — Hafta 8 · Kavram programı: <math.h>
 * Amaç   : sqrt, pow, fabs, floor ve ceil'i belgelerindeki imzalarıyla
 *          kullanmak; kütüphane fonksiyonu üzerine kendi fonksiyonumuzu
 *          kurmak (hipotenus). Negatif sayıda floor/ceil ve sqrt'e dikkat.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K08_math.c -o math -lm
 *          (-lm: matematik kitaplığını bağla; Linux/glibc'de gerekir)
 */
#include <stdio.h>
#include <math.h>

double hipotenus(double a, double b);

int main(void)
{
    double x;
    printf("Bir sayı girin: ");
    if (scanf("%lf", &x) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("sqrt(%.2f)   = %.4f\n", x, sqrt(x));
    printf("pow(%.2f, 3) = %.4f\n", x, pow(x, 3));
    printf("fabs(%.2f)   = %.4f\n", x, fabs(x));
    printf("floor(%.2f)  = %.4f\n", x, floor(x));
    printf("ceil(%.2f)   = %.4f\n", x, ceil(x));
    printf("hipotenus(3, 4) = %.4f\n", hipotenus(3, 4));
    return 0;
}

/* Son koşul: dik kenarları a ve b olan üçgenin hipotenüsü. */
double hipotenus(double a, double b)
{
    return sqrt(a * a + b * b);
}

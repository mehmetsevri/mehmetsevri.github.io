/* H08_K04_bos_parantez.c — Hafta 8 · Kavram programı: () ile (void) farkı
 * BU DOSYA KASITLI HATA İÇERİR: int bugun() bildirimi C17'de bir PROTOTİP
 * değildir ("parametreleri belirtilmemiş" demektir). Bu yüzden bugun(1, 2)
 * çağrısı -std=c17 -Wall -Wextra -pedantic ile bile UYARISIZ derlenir.
 * int bugun(void) yazılsaydı derleyici "too many arguments" hatası verirdi.
 * C23'te () ile (void) aynı anlama gelir (gcc -std=c2x ile hata).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K04_bos_parantez.c -o bos_parantez
 */
#include <stdio.h>

int bugun();                            /* () : parametre bilgisi YOK */

int main(void)
{
    printf("bugun(1, 2) = %d\n", bugun(1, 2));  /* yanlış, ama sessiz */
    return 0;
}

int bugun()
{
    return 8;
}

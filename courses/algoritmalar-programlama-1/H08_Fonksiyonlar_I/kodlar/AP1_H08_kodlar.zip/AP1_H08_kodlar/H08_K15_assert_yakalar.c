/* H08_K15_assert_yakalar.c — Hafta 8 · Kavram programı: assert hata yakalar
 * BU DOSYA KASITLI HATA İÇERİR: is_leap_year yalnızca 4'e bölünebilmeye
 * bakıyor (100/400 kuralı eksik). İkinci assert bunu yakalar: ileti
 * stderr'e yazılır ve abort() çağrılır (kabukta çıkış kodu 134).
 * -DNDEBUG ile derlenirse assert'ler kaldırılır ve hata GÖRÜNMEZ.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K15_assert_yakalar.c -o assert_yakalar
 */
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>

bool is_leap_year(int yil);

int main(void)
{
    assert(is_leap_year(2024));
    printf("1. test geçti: 2024 artık yıl\n");
    assert(!is_leap_year(1900));
    printf("2. test geçti: 1900 artık yıl değil\n");
    printf("Tüm testler geçti.\n");
    return 0;
}

/* HATALI gerçekleştirim: 100 ve 400 kuralı unutulmuş. */
bool is_leap_year(int yil)
{
    return yil % 4 == 0;
}

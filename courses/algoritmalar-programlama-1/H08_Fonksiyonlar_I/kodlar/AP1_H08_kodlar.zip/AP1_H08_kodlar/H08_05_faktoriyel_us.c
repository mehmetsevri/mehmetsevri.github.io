/* H08_05_faktoriyel_us.c — Hafta 8 · Örnek 5 (★★): H6 kodunu fonksiyona taşımak
 * Amaç   : H06_05 (faktöriyel) ve H06_06 (üs alma) döngüleri, sözleşmesi
 *          yazılmış iki fonksiyona dönüştü; artık her yerden çağrılabilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_05_faktoriyel_us.c -o faktoriyel_us
 * Örnek  : -> C(5, 2) = 5! / (2! * 3!) = 10
 */
#include <stdio.h>

unsigned long long faktoriyel(int n);
long long us_al(int taban, int us);

int main(void)
{
    printf("0!  = %llu\n", faktoriyel(0));
    printf("5!  = %llu\n", faktoriyel(5));
    printf("20! = %llu\n", faktoriyel(20));
    printf("2^10   = %lld\n", us_al(2, 10));
    printf("(-3)^3 = %lld\n", us_al(-3, 3));
    printf("7^0    = %lld\n", us_al(7, 0));
    /* yeniden kullanım: aynı fonksiyon bir ifadede üç kez */
    printf("C(5, 2) = 5! / (2! * 3!) = %llu\n",
           faktoriyel(5) / (faktoriyel(2) * faktoriyel(3)));
    return 0;
}

/* Ön koşul : 0 <= n <= 20 (21! 64 bite sığmaz; bkz. H06_05).
 * Son koşul: n! değerini döndürür (0! = 1). */
unsigned long long faktoriyel(int n)
{
    unsigned long long carpim = 1;      /* çarpım biriktirici (H6) */
    for (int i = 2; i <= n; i++) {
        carpim *= i;
    }
    return carpim;
}

/* Ön koşul : us >= 0 ve sonuç long long'a sığmalı.
 * Son koşul: taban^us değerini döndürür (x^0 = 1). */
long long us_al(int taban, int us)
{
    long long sonuc = 1;
    for (int i = 1; i <= us; i++) {
        sonuc *= taban;
    }
    return sonuc;
}

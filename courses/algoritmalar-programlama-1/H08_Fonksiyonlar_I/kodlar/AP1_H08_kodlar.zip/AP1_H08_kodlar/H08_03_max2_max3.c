/* H08_03_max2_max3.c — Hafta 8 · Örnek 3 (★): fonksiyon bileşimi
 * Amaç   : max3, işi max2'ye devreder: max3 = max2(max2(a, b), c).
 *          H05_04'teki iç içe if'lerin yerini iki küçük fonksiyon alır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_03_max2_max3.c -o max2_max3
 * Örnek  : -> max3(4, 9, 2)   = 9
 */
#include <stdio.h>

int max2(int a, int b);
int max3(int a, int b, int c);

int main(void)
{
    printf("max2(4, 9)      = %d\n", max2(4, 9));
    printf("max2(-3, -8)    = %d\n", max2(-3, -8));
    printf("max3(4, 9, 2)   = %d\n", max3(4, 9, 2));
    printf("max3(7, 7, 7)   = %d\n", max3(7, 7, 7));
    printf("max3(-1, -5, 0) = %d\n", max3(-1, -5, 0));
    return 0;
}

/* a ile b'nin büyüğünü döndürür (eşitse a). */
int max2(int a, int b)
{
    if (a >= b) {
        return a;
    }
    return b;
}

/* Bileşim: önce a ile b'nin büyüğü, sonra onunla c'nin büyüğü. */
int max3(int a, int b, int c)
{
    return max2(max2(a, b), c);
}

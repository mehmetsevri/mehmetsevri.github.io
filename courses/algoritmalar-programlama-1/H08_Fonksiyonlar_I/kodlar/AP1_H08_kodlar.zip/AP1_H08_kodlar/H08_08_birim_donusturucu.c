/* H08_08_birim_donusturucu.c — Hafta 8 · Örnek 8 (★★): menü + fonksiyonlar
 * Amaç   : H7'deki menü döngüsü iskeleti (do-while + switch) korunur; her
 *          dönüşüm ve her girdi okuma işi kendi fonksiyonuna verilir.
 *          Girdi biterse (EOF) okuma fonksiyonu exit ile programı bitirir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_08_birim_donusturucu.c -o birim
 * Örnek  : girdi "1 100 0" -> 100.00 °C = 212.00 °F
 */
#include <stdio.h>
#include <stdlib.h>                     /* exit, EXIT_FAILURE */

void menu_goster(void);
int secim_oku(void);
double deger_oku(void);
void satir_temizle(void);
double c_to_f(double c);
double f_to_c(double f);
double km_to_mil(double km);
double mil_to_km(double mil);

int main(void)
{
    int secim;
    do {
        menu_goster();
        secim = secim_oku();
        double x;
        switch (secim) {
        case 1:
            x = deger_oku();
            printf("%.2f °C = %.2f °F\n", x, c_to_f(x));
            break;
        case 2:
            x = deger_oku();
            printf("%.2f °F = %.2f °C\n", x, f_to_c(x));
            break;
        case 3:
            x = deger_oku();
            printf("%.2f km = %.2f mil\n", x, km_to_mil(x));
            break;
        case 4:
            x = deger_oku();
            printf("%.2f mil = %.2f km\n", x, mil_to_km(x));
            break;
        case 0:
            printf("Güle güle.\n");
            break;
        default:
            printf("  Geçersiz seçim: 0-4 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 0);
    return 0;
}

void menu_goster(void)
{
    printf("\n1) °C->°F  2) °F->°C  3) km->mil  4) mil->km  0) Çıkış\n");
    printf("Seçim: ");
}

/* Satırın kalanını (satır sonu dahil) girdi tamponundan atar. */
void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* at */
    }
}

/* Son koşul: okunan sayıyı döndürür; sayı değilse -1 (geçersiz seçim). */
int secim_oku(void)
{
    int s;
    int okunan = scanf("%d", &s);
    if (okunan == EOF) {
        printf("\nGirdi sona erdi.\n");
        exit(EXIT_FAILURE);             /* programı buradan bitir */
    }
    if (okunan == 0) {
        satir_temizle();
        return -1;
    }
    return s;
}

/* Son koşul: geçerli bir sayı okunana kadar sorar ve onu döndürür. */
double deger_oku(void)
{
    double d;
    int okunan;
    printf("Değer: ");
    while ((okunan = scanf("%lf", &d)) != 1) {
        if (okunan == EOF) {
            printf("\nGirdi sona erdi.\n");
            exit(EXIT_FAILURE);
        }
        satir_temizle();
        printf("  Sayı girin: ");
    }
    return d;
}

double c_to_f(double c)
{
    return c * 9.0 / 5.0 + 32.0;
}

double f_to_c(double f)
{
    return (f - 32.0) * 5.0 / 9.0;
}

double km_to_mil(double km)
{
    const double KM_BIR_MIL = 1.609344;     /* 1 mil = 1,609344 km (tanım) */
    return km / KM_BIR_MIL;
}

double mil_to_km(double mil)
{
    const double KM_BIR_MIL = 1.609344;
    return mil * KM_BIR_MIL;
}

/* H08_K10_lm_degisken.c — Hafta 8 · Kavram programı: -lm gerçekten gerekir
 * Amaç   : Argüman çalışma zamanında belli olunca (scanf) derleyici sqrt'i
 *          önceden hesaplayamaz; koda "call sqrt" girer ve -lm olmadan
 *          bağlayıcı "undefined reference to `sqrt'" hatası verir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K10_lm_degisken.c -o lm_degisken -lm
 */
#include <stdio.h>
#include <math.h>

int main(void)
{
    double x;
    printf("x: ");
    if (scanf("%lf", &x) != 1) {
        return 1;
    }
    printf("sqrt(x) = %f\n", sqrt(x));
    return 0;
}

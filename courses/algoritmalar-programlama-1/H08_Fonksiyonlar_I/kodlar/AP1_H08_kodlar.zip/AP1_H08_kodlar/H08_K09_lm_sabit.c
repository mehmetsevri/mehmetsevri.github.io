/* H08_K09_lm_sabit.c — Hafta 8 · Kavram programı: -lm olmadan da derlenir mi?
 * Amaç   : Argümanlar SABİT olduğunda GCC sqrt(2.0) ve pow(2.0, 10.0)
 *          değerlerini derleme sırasında hesaplar; çağrı koda girmez ve
 *          bağlayıcı libm'i aramaz. Bu, -lm unutulmasını GİZLER (bkz. K10).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K09_lm_sabit.c -o lm_sabit
 */
#include <stdio.h>
#include <math.h>

int main(void)
{
    printf("sqrt(2.0)       = %f\n", sqrt(2.0));
    printf("pow(2.0, 10.0)  = %f\n", pow(2.0, 10.0));
    return 0;
}

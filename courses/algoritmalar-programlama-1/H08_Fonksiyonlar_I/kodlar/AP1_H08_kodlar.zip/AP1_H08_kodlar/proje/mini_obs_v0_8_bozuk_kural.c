/*
 * mini_obs_v0_8_bozuk_kural.c — Mini-OBS v0.8, BİLİNÇLİ BOZULMUŞ kopya
 * BU DOSYA KASITLI HATA İÇERİR: harf_notu'nda BA sınırı "> 81" yazıldı
 * (doğrusu ">= 81"). Tek fark budur; -DOBS_TEST ile derlenince assert
 * tabanlı testler hatayı yakalar (bkz. mini_obs_v0_8_ciktilar.txt).
 *
 * Yenilik : v0.7'nin davranışı AYNEN korunarak program fonksiyonlara
 *           bölündü (yukarıdan aşağıya tasarım). Üç kez yazılan doğrulama
 *           bloğu tek bir not_oku() fonksiyonuna dönüştü. Hesap kuralları
 *           (ortalama, yuvarlama, harf notu, durum) yan etkisiz, test
 *           edilebilir fonksiyonlardır; -DOBS_TEST ile derlenince main menü
 *           yerine assert tabanlı birim testlerini çalıştırır.
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107), Madde 30: %40 vize + %60 final;
 *           final < 50 → FF; AA 90-100, BA 81-89, BB 73-80, CB 66-72,
 *           CC 60-65 başarılı; DC 50-59 şartlı (YANO ≥ 2,00 ise);
 *           DD 40-49, FD 30-39, FF 0-29 başarısız. Yuvarlama: (int)(ort + 0.5)
 * Kavramlar: prototip, tanım, çağrı; değerle aktarım; bool döndüren
 *           doğrulama fonksiyonları; fonksiyon sözleşmesi (ön/son koşul);
 *           assert ile birim testi; yapı şeması (main → alt görevler)
 * Not     : const char * — değişmez bir metnin (ör. "AA") adresi. Şimdilik
 *           yalnızca printf("%s", ...) ile yazdırıyoruz; ayrıntısı H12–H13.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g mini_obs_v0_8.c -o mini_obs
 * Test    : gcc -std=c17 -Wall -Wextra -pedantic -g -DOBS_TEST mini_obs_v0_8.c -o obs_test && ./obs_test
 */

#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>   /* strcmp: yalnızca testlerde metin karşılaştırmak için */

/* ---- Kurallar: dosya kapsamındaki sabitler (tüm fonksiyonlar görür) ---- */
const double VIZE_AGIRLIK = 0.40;
const double FINAL_AGIRLIK = 0.60;
const int GECME_ORTALAMA = 60;       /* CC ve üzeri: başarılı */
const int SARTLI_ORTALAMA = 50;      /* DC: şartlı başarılı */
const int FINAL_BARAJI = 50;         /* yarıyıl sonu sınavında en az 50 */

/* ---- Prototipler (bildirimler): derleyiciye "bu fonksiyonlar var" ---- */
void baslik_yaz(void);
void menu_goster(void);
void satir_temizle(void);
int menu_secimi_oku(void);
long long numara_oku(void);
double not_oku(const char *etiket);
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
void ogrenci_raporu_yaz(long long numara, double vize, double final,
                        double ortalama, int yuvarlanmis);
void istatistik_yaz(int kayit, double toplam_ortalama,
                    double en_yuksek, long long en_yuksek_no,
                    double en_dusuk, long long en_dusuk_no,
                    int basarili, int sartli);
void testleri_calistir(void);

int main(void)
{
#ifdef OBS_TEST
    testleri_calistir();
    return 0;
#endif
    int kayit = 0;                                  /* akış hâlinde istatistik */
    double toplam_ortalama = 0.0;
    int basarili = 0, sartli = 0;
    double en_yuksek = 0.0, en_dusuk = 0.0;
    long long en_yuksek_no = 0, en_dusuk_no = 0;
    int secim = 0;

    baslik_yaz();
    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }

        switch (secim) {
        case 1: {
            printf("\n------------ ÖĞRENCİ %d ------------\n", kayit + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            double vize = not_oku("Vize notu        : ");
            if (vize < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            double final = not_oku("Final notu       : ");
            if (final < 0) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }

            double ortalama = hesapla_ortalama(vize, final);
            int yuvarlanmis = yuvarla(ortalama);
            ogrenci_raporu_yaz(numara, vize, final, ortalama, yuvarlanmis);

            if (gecti_mi(yuvarlanmis, final)) {
                basarili++;
            } else if (sartli_mi(yuvarlanmis, final)) {
                sartli++;
            }
            kayit++;
            toplam_ortalama += ortalama;
            if (kayit == 1 || ortalama > en_yuksek) {
                en_yuksek = ortalama;
                en_yuksek_no = numara;
            }
            if (kayit == 1 || ortalama < en_dusuk) {
                en_dusuk = ortalama;
                en_dusuk_no = numara;
            }
            break;
        }
        case 2:
            istatistik_yaz(kayit, toplam_ortalama, en_yuksek, en_yuksek_no,
                           en_dusuk, en_dusuk_no, basarili, sartli);
            break;
        case 3:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n", kayit);
            break;
        default:
            printf("  Geçersiz seçim: 1, 2 ya da 3 girin.\n");
            break;
        }
    } while (secim != 3);

    return 0;
}

/* Ekrana program başlığını yazar. */
void baslik_yaz(void)
{
    printf("==========================================\n");
    printf("  MİNİ-OBS v0.8 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");
}

/* Ana menüyü ve seçim istemini yazar. */
void menu_goster(void)
{
    printf("\n---------------- ANA MENÜ ----------------\n");
    printf("  1) Not girişi (bir öğrenci)\n");
    printf("  2) Sınıf istatistikleri\n");
    printf("  3) Çıkış\n");
    printf("Seçiminiz (1-3)  : ");
}

/* Girdi tamponunda satırın kalanını (satır sonu dahil) atar. */
void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }
}

/* Son koşul: 1-3 arası bir sayı girildiyse onu; sayı değilse ya da
 * aralık dışıysa 0'ı (geçersiz); girdi bittiyse -1'i döndürür. */
int menu_secimi_oku(void)
{
    int secim = 0;
    int okunan = scanf("%d", &secim);
    if (okunan == EOF) {
        return -1;
    }
    if (okunan == 0) {
        satir_temizle();
        return 0;
    }
    if (secim < 1 || secim > 3) {
        return 0;
    }
    return secim;
}

/* Son koşul: pozitif bir öğrenci numarası döndürür; geçersiz girdide
 * yeniden sorar; girdi biterse -1 döndürür. */
long long numara_oku(void)
{
    long long numara = 0;
    int okunan;
    do {
        printf("Öğrenci numarası : ");
        okunan = scanf("%lld", &numara);
        if (okunan == EOF) {
            return -1;
        }
        if (okunan == 0) {
            satir_temizle();
            numara = 0;
        }
        if (numara <= 0) {
            printf("  Geçersiz: pozitif bir numara girin.\n");
        }
    } while (numara <= 0);
    return numara;
}

/* Ön koşul : etiket, ekrana yazılacak istem metnidir.
 * Son koşul: 0-100 aralığında bir not döndürür; geçersiz girdide yeniden
 *            sorar; girdi biterse -1.0 döndürür. (v0.7'de üç kez yazılan
 *            doğrulama bloğunun tek kopyası.) */
double not_oku(const char *etiket)
{
    double deger = -1.0;
    int okunan;
    do {
        printf("%s", etiket);
        okunan = scanf("%lf", &deger);
        if (okunan == EOF) {
            return -1.0;
        }
        if (okunan == 0) {
            satir_temizle();
            deger = -1.0;
        }
        if (deger < 0 || deger > 100) {
            printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
        }
    } while (deger < 0 || deger > 100);
    return deger;
}

/* Ön koşul : 0 <= vize, final <= 100.  Son koşul: %40 + %60 ağırlıklı ortalama. */
double hesapla_ortalama(double vize, double final)
{
    return VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
}

/* Ön koşul : ortalama >= 0.  Son koşul: en yakın tamsayı (.5 yukarı). */
int yuvarla(double ortalama)
{
    return (int)(ortalama + 0.5);
}

/* Son koşul: RTEÜ tablosuna göre harf notu; final barajın altındaysa "FF". */
const char *harf_notu(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "FF";
    } else if (yuvarlanmis >= 90) {
        return "AA";
    } else if (yuvarlanmis > 81) {      /* HATA: >= olmalı */
        return "BA";
    } else if (yuvarlanmis >= 73) {
        return "BB";
    } else if (yuvarlanmis >= 66) {
        return "CB";
    } else if (yuvarlanmis >= 60) {
        return "CC";
    } else if (yuvarlanmis >= 50) {
        return "DC";
    } else if (yuvarlanmis >= 40) {
        return "DD";
    } else if (yuvarlanmis >= 30) {
        return "FD";
    }
    return "FF";
}

/* Son koşul: CC ve üzeri ve final barajı aşıldıysa true. */
bool gecti_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= GECME_ORTALAMA;
}

/* Son koşul: DC (50-59) ve final barajı aşıldıysa true. */
bool sartli_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= SARTLI_ORTALAMA
           && yuvarlanmis < GECME_ORTALAMA;
}

/* Son koşul: rapordaki "Durum" satırının metni. */
const char *durum_metni(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "BAŞARISIZ (final barajı)";
    } else if (gecti_mi(yuvarlanmis, final)) {
        return "BAŞARILI";
    } else if (sartli_mi(yuvarlanmis, final)) {
        return "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)";
    }
    return "BAŞARISIZ";
}

/* Bir öğrencinin raporunu v0.5 etiketleriyle yazar. */
void ogrenci_raporu_yaz(long long numara, double vize, double final,
                        double ortalama, int yuvarlanmis)
{
    printf("Öğrenci no  : %lld\n", numara);
    printf("Vize  (%%40) : %6.2f\n", vize);
    printf("Final (%%60) : %6.2f\n", final);
    printf("Ortalama    : %6.2f\n", ortalama);
    printf("Yuvarlanmış : %3d\n", yuvarlanmis);
    printf("Harf notu   : %s\n", harf_notu(yuvarlanmis, final));
    printf("Durum       : %s\n", durum_metni(yuvarlanmis, final));
}

/* Sınıf özetini yazar; kayıt yoksa uyarır. Sekiz parametre: H9'da bu
 * durum, modül içinde saklanan (static) istatistiklerle sadeleşecek. */
void istatistik_yaz(int kayit, double toplam_ortalama,
                    double en_yuksek, long long en_yuksek_no,
                    double en_dusuk, long long en_dusuk_no,
                    int basarili, int sartli)
{
    if (kayit == 0) {
        printf("  Henüz kayıt yok: önce 1) Not girişi.\n");
        return;
    }
    printf("\n--------------- SINIF ÖZETİ ---------------\n");
    printf("Öğrenci sayısı   : %d\n", kayit);
    printf("Sınıf ortalaması : %6.2f\n", toplam_ortalama / kayit);
    printf("En yüksek        : %6.2f (%lld)\n", en_yuksek, en_yuksek_no);
    printf("En düşük         : %6.2f (%lld)\n", en_dusuk, en_dusuk_no);
    printf("Başarılı (CC+)   : %d / %d\n", basarili, kayit);
    printf("Şartlı (DC)      : %d / %d\n", sartli, kayit);
    printf("-------------------------------------------\n");
}

/* assert tabanlı birim testleri: her biri normal, sınır ve baraj durumları. */
void testleri_calistir(void)
{
    int sayac = 0;
    const double EPS = 1e-9;                        /* kayan nokta toleransı */

    /* hesapla_ortalama: kayan noktada == yerine tolerans */
    assert(hesapla_ortalama(70, 85) - 79.0 < EPS && 79.0 - hesapla_ortalama(70, 85) < EPS); sayac++;
    assert(hesapla_ortalama(0, 0) == 0.0); sayac++;
    assert(hesapla_ortalama(100, 100) - 100.0 < EPS && 100.0 - hesapla_ortalama(100, 100) < EPS); sayac++;

    /* yuvarla: .5 yukarı, altı aşağı */
    assert(yuvarla(59.5) == 60); sayac++;
    assert(yuvarla(59.4) == 59); sayac++;
    assert(yuvarla(0.0) == 0); sayac++;
    assert(yuvarla(100.0) == 100); sayac++;

    /* harf_notu: her kademenin iki sınırı ve baraj */
    assert(strcmp(harf_notu(100, 100), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(90, 90), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(89, 89), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(81, 81), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(80, 80), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(73, 73), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(72, 72), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(66, 66), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(65, 65), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(60, 60), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(59, 59), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(50, 50), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(49, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(40, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(39, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(30, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(29, 50), "FF") == 0); sayac++;
    assert(strcmp(harf_notu(95, 49.9), "FF") == 0); sayac++;   /* baraj */

    /* gecti_mi / sartli_mi */
    assert(gecti_mi(60, 50)); sayac++;
    assert(!gecti_mi(59, 80)); sayac++;
    assert(!gecti_mi(95, 49.9)); sayac++;
    assert(sartli_mi(50, 50)); sayac++;
    assert(sartli_mi(59, 60)); sayac++;
    assert(!sartli_mi(60, 60)); sayac++;
    assert(!sartli_mi(49, 60)); sayac++;
    assert(!sartli_mi(55, 45)); sayac++;

    /* durum_metni */
    assert(strcmp(durum_metni(79, 85), "BAŞARILI") == 0); sayac++;
    assert(strcmp(durum_metni(54, 70), "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)") == 0); sayac++;
    assert(strcmp(durum_metni(47, 48), "BAŞARISIZ (final barajı)") == 0); sayac++;
    assert(strcmp(durum_metni(45, 50), "BAŞARISIZ") == 0); sayac++;

    printf("Tüm testler geçti (%d doğrulama).\n", sayac);
}

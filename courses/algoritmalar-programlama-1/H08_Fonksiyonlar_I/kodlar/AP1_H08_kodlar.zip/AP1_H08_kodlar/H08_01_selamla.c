/* H08_01_selamla.c — Hafta 8 · Örnek 1 (★): parametresiz void fonksiyon
 * Amaç   : İlk fonksiyonumuz: prototip (bildirim), tanım ve çağrı.
 *          selamla() parametre almaz (void) ve değer döndürmez (void).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_01_selamla.c -o selamla
 * Örnek  : -> Merhaba! AP-1'e hoş geldiniz.
 */
#include <stdio.h>

void selamla(void);                     /* prototip: "böyle bir fonksiyon" */

int main(void)
{
    printf("main başladı.\n");
    selamla();                          /* çağrı: akış selamla'ya gider... */
    selamla();                          /* ...ve her seferinde buraya döner */
    printf("main bitti.\n");
    return 0;
}

/* Ekrana iki satırlık bir karşılama iletisi yazar. */
void selamla(void)                      /* tanım: başlık + gövde */
{
    printf("  Merhaba! AP-1'e hoş geldiniz.\n");
    printf("  Bu hafta: Fonksiyonlar I\n");
}

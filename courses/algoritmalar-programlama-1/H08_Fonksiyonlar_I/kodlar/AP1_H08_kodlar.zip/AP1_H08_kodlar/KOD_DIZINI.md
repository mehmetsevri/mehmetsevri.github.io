# Hafta 8 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` dosyası (82 dosya); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (`math.h` kullananlar için sonuna `-lm`). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (her dosyanın başında derleme komutu, sonra `$ ./program` satırları ve kullanıcı girdileriyle birlikte çıktı). Bütün örnek ve kavram programları ayrıca AddressSanitizer + UBSan ile temiz çalıştı; `H08_K18_karekok_tasma.c` bilerek UBSan iletisi üretir. Rastgele sayı kullanan programların kayıtları `-DSABIT_TOHUM=2026` ile alındı (tekrarlanabilir).

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Web’deki kod blokları dosyanın **tamamıdır** (satır numaraları dosyayla aynı; quiz kodları `#include`’dan başlar); simülasyonların (`h08-cagri`, `h08-tamamla`, `h08-kutuphane`, `h08-yapi`) gösterdiği kodlar da bu dosyalardan birebir alınır.

Envanter denetimi: `node shared/kod_envanteri.js 8` → **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H08_01_selamla.c` | Örnek 1 (★) | Örnek 1 (★): parametresiz void fonksiyon | sıfır uyarı | 3.2 | 13 | h08-anatomi |
| `H08_02_kare.c` | Örnek 2 (★) | Örnek 2 (★): parametre ve dönüş değeri | sıfır uyarı | 3.1 (şekil), 3.2 (şekil), 3.10 (metin) | 1 (şekil), 11 (şekil), 12 (şekil), 14, 32 (not) | h08-anatomi, h08-anatomi (h08-cagri) |
| `H08_03_max2_max3.c` | Örnek 3 (★) | Örnek 3 (★): fonksiyon bileşimi | sıfır uyarı | 3.1 (şekil), 4.1 | 1 (şekil), 11 (şekil), 21 | h08-sozlesme |
| `H08_04_cift_artik_yil.c` | Örnek 4 (★) | Örnek 4 (★): bool döndüren fonksiyonlar | sıfır uyarı | 4.1 | 21 | h08-sozlesme, h08-kutuphane (h08-kutuphane) |
| `H08_05_faktoriyel_us.c` | Örnek 5 (★★) | Örnek 5 (★★): H6 kodunu fonksiyona taşımak | sıfır uyarı | 4.2 | 34 | h08-merdiven |
| `H08_06_is_prime.c` | Örnek 6 (★★) | Örnek 6 (★★): H7 kodunun yeniden düzenlenmesi | sıfır uyarı | 3.1 (şekil), 4.3 | 1 (şekil), 11 (şekil), 36, 37 | h08-merdiven |
| `H08_07_ebob_ekok.c` | Örnek 7 (★★) | Örnek 7 (★★): bir fonksiyon diğerini kullanır | sıfır uyarı | 4.4 | 34 | h08-merdiven |
| `H08_08_birim_donusturucu.c` | Örnek 8 (★★) | Örnek 8 (★★): menü + fonksiyonlar | sıfır uyarı | 4.4 (metin) | 39 | h08-merdiven |
| `H08_09_basamak_palindrom.c` | Örnek 9 (★★) | Örnek 9 (★★): küçük fonksiyonlardan | sıfır uyarı | 4.4 (metin) | 39 | h08-merdiven |
| `H08_10_takas_denemesi.c` | Örnek 10 (★★) | Örnek 10 (★★): "Neden çalışmıyor?" | sıfır uyarı | 3.10 (metin), 4.5 | 32 (not), 40, 41 (şekil) | h08-merdiven, h08-anatomi (h08-cagri) |
| `H08_11_zar_frekans.c` | Örnek 11 (★★) | Örnek 11 (★★): zar simülasyonu ve frekans | sıfır uyarı | 4.5 (metin, şekil) | 42 (not, şekil) | h08-merdiven |
| `H08_12_assert_testleri.c` | Örnek 12 (★★★) | Örnek 12 (★★★): assert ile birim testi | sıfır uyarı | 4.6 | 43 | h08-merdiven |
| `H08_13_atm_fonksiyonlu.c` | Örnek 13 (★★★) | Örnek 13 (★★★): yukarıdan aşağıya | sıfır uyarı | 3.8 (şekil), 4.7 | 26 (şekil), 27 (şekil), 44, 45 | h08-merdiven, h08-tasarim (h08-yapi) |
| `H08_K01_tekrar_fonksiyon.c` | Kavram programı | Kavram programı: neden fonksiyon? | sıfır uyarı | 3.1 (metin) | 10 | h08-neden |
| `H08_K02_kara_kutu.c` | Kavram programı | Kavram programı: kara kutu ve sözleşme | sıfır uyarı | 3.6 | 20 | h08-sozlesme |
| `H08_K03_void_ornekleri.c` | Kavram programı | Kavram programı: void'in iki anlamı | sıfır uyarı | 3.4 | 15 (not) | h08-anatomi |
| `H08_K04_bos_parantez.c` | Kavram programı | Kavram programı: () ile (void) farkı | sıfır uyarı; kasıtlı mantık hatası | 3.4 (metin) | 15 | h08-anatomi |
| `H08_K05_deger_aktarim.c` | Kavram programı | Kavram programı: değerle aktarım | sıfır uyarı | 3.5 | 18 (not, şekil) | h08-deger-aktarim |
| `H08_K06_cagri_akisi.c` | Kavram programı | Kavram programı: çağrı akışı | sıfır uyarı | 3.2 (metin, şekil), 11 (metin) | 16 (not, şekil) | h08-anatomi, h08-anatomi (h08-cagri) |
| `H08_K07_asm_cagri.c` | Kavram programı | Kavram programı: çağrı makine düzeyinde | sıfır uyarı | 3.10 (metin, çıktı, şekil) | 30 (not), 31 (şekil), 32 (şekil) | h08-kaput |
| `H08_K08_math.c` | Kavram programı | Kavram programı: <math.h> | sıfır uyarı | 3.7 (metin) | 23 | h08-kutuphane, h08-kutuphane (h08-kutuphane) |
| `H08_K09_lm_sabit.c` | Kavram programı | Kavram programı: -lm olmadan da derlenir mi? | sıfır uyarı | 3.7 (metin) | — | h08-kutuphane |
| `H08_K10_lm_degisken.c` | Kavram programı | Kavram programı: -lm gerçekten gerekir | sıfır uyarı | 3.7 (metin) | — | h08-kutuphane |
| `H08_K11_ctype.c` | Kavram programı | Kavram programı: <ctype.h> | sıfır uyarı | 3.7 (metin) | 24 | h08-kutuphane, h08-kutuphane (h08-kutuphane) |
| `H08_K12_stdlib.c` | Kavram programı | Kavram programı: <stdlib.h>: abs ve exit | sıfır uyarı | 3.7 (metin) | 25 | h08-kutuphane, h08-kutuphane (h08-kutuphane) |
| `H08_K13_time.c` | Kavram programı | Kavram programı: <time.h>: time | sıfır uyarı | 3.7 (metin) | — | h08-kutuphane, h08-kutuphane (h08-kutuphane) |
| `H08_K14_rand_aralik.c` | Kavram programı | Kavram programı: kütüphane | sıfır uyarı | 3.7 (metin) | 25 | h08-kutuphane, h08-kutuphane (h08-kutuphane) |
| `H08_K15_assert_yakalar.c` | Kavram programı | Kavram programı: assert hata yakalar | sıfır uyarı; kasıtlı mantık hatası | 3.9 (metin) | 28 (şekil), 29 | h08-test, h08-kutuphane (h08-kutuphane) |
| `H08_K16_kayan_tolerans.c` | Kavram programı | Kavram programı: kayan noktada eşitlik | sıfır uyarı | 3.9 (metin) | — | h08-test, h08-kutuphane (h08-kutuphane) |
| `H08_K17_iskelet_atm.c` | Kavram programı | Kavram programı: adım adım iyileştirme | sıfır uyarı | 3.8 (metin) | 26 (not, şekil) | h08-tasarim |
| `H08_K18_karekok_tasma.c` | Kavram programı | Kavram programı: d * d <= n neden riskli? | sıfır uyarı; kasıtlı tanımsız davranış (UBSan ile yakalanır) | 4.3 (metin) | 38 (not) | h08-merdiven |
| `alistirmalar/H08_A01_cikti_tahmini.c` | Alıştırma 8.1 | Alıştırma 8.1 (★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h08-alistirmalar |
| `alistirmalar/H08_A02_cagri_sirasi.c` | Alıştırma 8.2 | Alıştırma 8.2 (★★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h08-alistirmalar |
| `alistirmalar/H08_A03_hata_bul_ortalama.c` | Alıştırma 8.3 | Alıştırma 8.3 (★★, hata bul) | derlenmez (kasıtlı derleme hatası; ileti ciktilar/ altında) | 8 (alıştırma) | — | h08-alistirmalar |
| `alistirmalar/H08_A04_hata_bul_harf.c` | Alıştırma 8.4 | Alıştırma 8.4 (★★, hata bul) | derlenir; kasıtlı uyarı | 8 (alıştırma) | — | h08-alistirmalar |
| `alistirmalar/H08_A05_parsons_us.c` | Alıştırma 8.5 | Alıştırma 8.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h08-alistirmalar |
| `alistirmalar/H08_A06_kod_tamamla_basamak.c` | Alıştırma 8.6 | Alıştırma 8.6 (★★, kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h08-alistirmalar |
| `alistirmalar/H08_T01_kup.c` | “Fonksiyonu tamamla” 1 (tamamlanmış) | "Fonksiyonu tamamla" 1 (tamamlanmış sürüm) | sıfır uyarı | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T01_kup_bosluklu.c` | “Fonksiyonu tamamla” 1 (boşluklu) | "Fonksiyonu tamamla" 1 (boşluklu sürüm) | tamamlanacak (bu hâliyle derlenmez) | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T02_cift_mi.c` | “Fonksiyonu tamamla” 2 (tamamlanmış) | "Fonksiyonu tamamla" 2 (tamamlanmış sürüm) | sıfır uyarı | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T02_cift_mi_bosluklu.c` | “Fonksiyonu tamamla” 2 (boşluklu) | "Fonksiyonu tamamla" 2 (boşluklu sürüm) | tamamlanacak (bu hâliyle derlenmez) | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T03_ortalama_tipi.c` | “Fonksiyonu tamamla” 3 (tamamlanmış) | "Fonksiyonu tamamla" 3 (tamamlanmış) | sıfır uyarı | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T03_ortalama_tipi_bosluklu.c` | “Fonksiyonu tamamla” 3 (boşluklu) | "Fonksiyonu tamamla" 3 (boşluklu sürüm) | tamamlanacak (bu hâliyle derlenmez) | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T04_mutlak.c` | “Fonksiyonu tamamla” 4 (tamamlanmış) | "Fonksiyonu tamamla" 4 (tamamlanmış sürüm) | sıfır uyarı | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T04_mutlak_bosluklu.c` | “Fonksiyonu tamamla” 4 (boşluklu) | "Fonksiyonu tamamla" 4 (boşluklu sürüm) | tamamlanacak (bu hâliyle derlenmez) | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T05_selamla_prototip.c` | “Fonksiyonu tamamla” 5 (tamamlanmış) | "Fonksiyonu tamamla" 5 (tamamlanmış) | sıfır uyarı | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T05_selamla_prototip_bosluklu.c` | “Fonksiyonu tamamla” 5 (boşluklu) | "Fonksiyonu tamamla" 5 (boşluklu sürüm) | tamamlanacak (bu hâliyle derlenmez) | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T06_ekok.c` | “Fonksiyonu tamamla” 6 (tamamlanmış) | "Fonksiyonu tamamla" 6 (tamamlanmış sürüm) | sıfır uyarı | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T06_ekok_bosluklu.c` | “Fonksiyonu tamamla” 6 (boşluklu) | "Fonksiyonu tamamla" 6 (boşluklu sürüm) | tamamlanacak (bu hâliyle derlenmez) | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T07_faktoriyel.c` | “Fonksiyonu tamamla” 7 (tamamlanmış) | "Fonksiyonu tamamla" 7 (tamamlanmış) | sıfır uyarı | — | — | h08-alistirmalar (h08-tamamla) |
| `alistirmalar/H08_T07_faktoriyel_bosluklu.c` | “Fonksiyonu tamamla” 7 (boşluklu) | "Fonksiyonu tamamla" 7 (boşluklu sürüm) | tamamlanacak (bu hâliyle derlenmez) | — | — | h08-alistirmalar (h08-tamamla) |
| `hata_avcisi/H08_HA1_prototip_eksik.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 (çıktı, metin) | 48 | h08-hata-avcisi |
| `hata_avcisi/H08_HA1_prototip_eksik_double.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1 (gösterim) | derlenmez (kasıtlı derleme hatası; ileti ciktilar/ altında) | 5 (metin) | 48 (not) | h08-hata-avcisi |
| `hata_avcisi/H08_HA1_prototip_eksik_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 | sıfır uyarı | — | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA2_return_unutma.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 | 48 | h08-hata-avcisi |
| `hata_avcisi/H08_HA2_return_unutma_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 | sıfır uyarı | — | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA3_donus_kullanilmiyor.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 (metin) | 49 | h08-hata-avcisi |
| `hata_avcisi/H08_HA3_donus_kullanilmiyor_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 | sıfır uyarı | — | 49 | h08-hata-avcisi |
| `hata_avcisi/H08_HA3_nodiscard_gosterim.c` | Hata Avcısı 3 (C23 gösterimi) | Hata Avcısı 3 (gösterim, C23) | derlenir; kasıtlı uyarı | 5 (metin) | 49 (not) | h08-hata-avcisi |
| `hata_avcisi/H08_HA4_parametre_sayisi.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4a (hatalı sürüm) | derlenmez (kasıtlı derleme hatası; ileti ciktilar/ altında) | — | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA4_parametre_sayisi_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4a | sıfır uyarı | — | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA4_parametre_tipi.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4b (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | — | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA4_parametre_tipi_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4b | sıfır uyarı | — | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA5_noktali_virgul.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5 (hatalı sürüm) | derlenmez (kasıtlı derleme hatası; ileti ciktilar/ altında) | 5 (metin) | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA5_noktali_virgul_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 | sıfır uyarı | — | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA6_ic_ice_fonksiyon.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 (metin) | — | h08-hata-avcisi |
| `hata_avcisi/H08_HA6_ic_ice_fonksiyon_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 | sıfır uyarı | — | — | h08-hata-avcisi |
| `proje/mini_obs_v0_8.c` | Mini-OBS v0.8 | Mini-OBS v0.8 (AP-1 Hafta 8) | sıfır uyarı | 7 (şekil) | 51 (şekil) | h08-mini-obs |
| `proje/mini_obs_v0_8_bozuk_kural.c` | Mini-OBS v0.8 (bilinçli bozulmuş kopya) | Mini-OBS v0.8, BİLİNÇLİ BOZULMUŞ kopya | sıfır uyarı; kasıtlı mantık hatası | 7 (metin) | — | h08-mini-obs |
| `quiz/H08_Q01_ic_ice_sayac.c` | Geri çağırma S1 | Geçen haftadan (H7): iç içe döngü | sıfır uyarı | 2 (metin) | 3 | h08-gecen-hafta |
| `quiz/H08_Q02_karekok_bolen.c` | Geri çağırma S2 | Geçen haftadan (H7): √n asallık | sıfır uyarı | 2 (metin) | 4 | h08-gecen-hafta |
| `quiz/H08_Q03_menu_break.c` | Geri çağırma S3 | Geçen haftadan (H7): menü döngüsü | sıfır uyarı | 2 (metin) | 4 | h08-gecen-hafta |
| `quiz/H08_Q11_deger_aktarim.c` | Web quiz sorusu | Web quiz: değerle aktarım | sıfır uyarı | — | 17 | h08-quiz |
| `quiz/H08_Q12_bilesim.c` | Web quiz sorusu | Web quiz: fonksiyon bileşimi | sıfır uyarı | — | — | h08-quiz |
| `quiz/H08_Q13_cagri_sirasi.c` | Web quiz sorusu | Web quiz: çağrı sırası | sıfır uyarı | — | — | h08-quiz |
| `quiz/H08_Q14_void_deger.c` | Web quiz sorusu | Web quiz: void fonksiyonun "değeri" | derlenmez (kasıtlı derleme hatası; ileti ciktilar/ altında) | 3.4 (metin) | — | h08-quiz |
| `quiz/H08_Q15_tamsayi_bolme.c` | Web quiz sorusu | Web quiz: dönüş tipi ile bölme | sıfır uyarı | — | — | h08-quiz |
| `quiz/H08_Q16_toupper.c` | Web quiz sorusu | Web quiz: toupper'ın dönüş değeri | derlenir; kasıtlı uyarı | — | — | h08-quiz |
| `quiz/H08_Q17_artik_yil.c` | Web quiz sorusu | Web quiz: bool döndüren fonksiyon | sıfır uyarı | — | — | h08-quiz |
| `quiz/H08_Q18_ndebug.c` | Web quiz sorusu | Web quiz: assert ve NDEBUG | sıfır uyarı | — | — | h08-quiz |
| `quiz/H08_Q19_ayni_ad.c` | Web quiz sorusu | Web quiz: aynı adlı parametre ve değişken | sıfır uyarı | — | — | h08-quiz |
| `quiz/H08_Q20_kutuphane.c` | Web quiz sorusu | Web quiz: abs ve floor | sıfır uyarı | — | — | h08-quiz |

**Diğer dosyalar**

- `ciktilar/H08_K07_asm_cagri_O0_asm.txt`, `…_O0_ms_asm.txt`, `…_O2_asm.txt` — Kaputun Altında için gerçek assembly çıktıları (gcc 13.3, `-S -masm=intel -fno-asynchronous-unwind-tables -fno-pie`; `_ms`: `-mabi=ms`, yalnızca Windows x64 çağrı kuralını göstermek için).
- `ciktilar/H08_K07_asm_cagri_gdb.txt`, `…_objdump.txt` — `topla`’ya girildiği anda gdb oturumu (yazmaçlar, dönüş adresi, parametre adresleri) ve `objdump -d -M intel` kesiti.
- `proje/mini_obs_v0_8.c` — Mini-OBS v0.8’in kopyası (asıl yer: `91_Proje_MiniOBS/v0.8/`; testler ve gerçek çıktılar orada). `proje/mini_obs_v0_8_bozuk_kural.c` — BA sınırı bilinçli olarak bozulmuş kopya (assert’in yakaladığını göstermek için).
- `AP1_H08_kodlar.zip` — bu klasörün (`.c`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H08_kodlar/` klasörü oluşur.

Materyalde geçmeyen dosya yoktur.

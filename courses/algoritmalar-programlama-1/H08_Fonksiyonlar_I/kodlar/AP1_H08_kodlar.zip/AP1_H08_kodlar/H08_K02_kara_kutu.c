/* H08_K02_kara_kutu.c — Hafta 8 · Kavram programı: kara kutu ve sözleşme
 * Amaç   : Aynı sözleşmeyi (ön koşul + son koşul) iki farklı gerçekleştirim
 *          karşılar: döngüyle ve Gauss formülüyle. Çağıran yalnızca sözleşmeye
 *          güvenir; kutunun içi değişse de main'in tek satırı değişmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K02_kara_kutu.c -o kara_kutu
 */
#include <stdio.h>

long long toplam_dongu(int n);
long long toplam_formul(int n);

int main(void)
{
    printf("      n   toplam_dongu  toplam_formul\n");
    printf("%7d %14lld %14lld\n", 0, toplam_dongu(0), toplam_formul(0));
    printf("%7d %14lld %14lld\n", 10, toplam_dongu(10), toplam_formul(10));
    printf("%7d %14lld %14lld\n", 100, toplam_dongu(100), toplam_formul(100));
    printf("%7d %14lld %14lld\n", 100000, toplam_dongu(100000),
           toplam_formul(100000));
    return 0;
}

/* SÖZLEŞME (iki gerçekleştirim için de aynı)
 * Ön koşul : 0 <= n <= 100000
 * Son koşul: 1 + 2 + ... + n toplamını döndürür (n = 0 için 0).
 * Kara kutu 1: n tur süren döngü (H6, Örnek 2). */
long long toplam_dongu(int n)
{
    long long toplam = 0;
    for (int i = 1; i <= n; i++) {
        toplam += i;
    }
    return toplam;
}

/* Kara kutu 2: sabit sayıda işlem, n(n+1)/2 (H2, Gauss). */
long long toplam_formul(int n)
{
    return (long long)n * (n + 1) / 2;
}

/* H08_07_ebob_ekok.c — Hafta 8 · Örnek 7 (★★): bir fonksiyon diğerini kullanır
 * Amaç   : ebob (Öklid, H06_11) ve ekok; ekok işini ebob'a dayandırır.
 *          ebob parametrelerini değiştirir ama main'deki a ve b değişmez.
 * Kısıt  : a > 0, b > 0
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_07_ebob_ekok.c -o ebob_ekok
 * Örnek  : girdi "48 18" -> EKOK(48, 18) = 144
 */
#include <stdio.h>

int ebob(int a, int b);
long long ekok(int a, int b);

int main(void)
{
    int a, b;
    printf("Pozitif iki tamsayı girin: ");
    if (scanf("%d %d", &a, &b) != 2 || a <= 0 || b <= 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("EBOB(%d, %d) = %d\n", a, b, ebob(a, b));
    printf("EKOK(%d, %d) = %lld\n", a, b, ekok(a, b));
    return 0;
}

/* Ön koşul : a > 0, b > 0.
 * Son koşul: a ile b'nin en büyük ortak böleni (Öklid algoritması). */
int ebob(int a, int b)
{
    while (b != 0) {
        int r = a % b;
        a = b;                          /* a ve b yerel kopyalardır: */
        b = r;                          /* main'dekiler değişmez */
    }
    return a;
}

/* Ön koşul : a > 0, b > 0.
 * Son koşul: a ile b'nin en küçük ortak katı.
 * ebob'u KULLANIR; önce böl, sonra çarp: ara sonuç küçük kalır. */
long long ekok(int a, int b)
{
    return (long long)a / ebob(a, b) * b;
}

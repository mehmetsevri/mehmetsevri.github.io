/* H08_K14_rand_aralik.c — Hafta 8 · Kavram programı: kütüphane
 *          üzerine kendi fonksiyonumuz
 * Amaç   : rastgele(alt, ust): rand()'ı [alt, ust] aralığına taşıyan kendi
 *          fonksiyonumuz. Zar, 1-100 tahmin, rastgele not... tek fonksiyon.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K14_rand_aralik.c -o rand_aralik
 *          Yeniden üretilebilir çıktı için: gcc ... -DSABIT_TOHUM=2026 ...
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int rastgele(int alt, int ust);

int main(void)
{
#ifdef SABIT_TOHUM
    srand(SABIT_TOHUM);
#else
    srand((unsigned)time(NULL));
#endif
    printf("Zar      :");
    for (int i = 0; i < 10; i++) {
        printf(" %d", rastgele(1, 6));
    }
    printf("\nNot 0-100:");
    for (int i = 0; i < 5; i++) {
        printf(" %d", rastgele(0, 100));
    }
    printf("\n");
    return 0;
}

/* Ön koşul : alt <= ust ve ust - alt < RAND_MAX.
 * Son koşul: [alt, ust] aralığında bir tamsayı döndürür. */
int rastgele(int alt, int ust)
{
    return alt + rand() % (ust - alt + 1);
}

/* H08_12_assert_testleri.c — Hafta 8 · Örnek 12 (★★★): assert ile birim testi
 * Amaç   : is_prime (Örnek 6), ebob/ekok (Örnek 7) ve ortalama için normal,
 *          sınır ve hatalı/beklenmedik girdi testleri. Her test fonksiyonu
 *          tek bir fonksiyonu sınar; bir assert yanlışsa program durur.
 *          Kayan noktada == yerine tolerans (yakin) kullanılır.
 * Not    : Fonksiyonlar buraya kopyalandı; H9'da çok dosyalı yapıyla
 *          (asal.h / asal.c) kopyalamadan test edeceğiz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_12_assert_testleri.c -o assert_testleri -lm
 * Örnek  : -> Tüm testler geçti (24 doğrulama).
 */
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <math.h>                       /* fabs */

bool is_prime(int n);
int ebob(int a, int b);
long long ekok(int a, int b);
double ortalama(double a, double b);
bool yakin(double x, double y);
int test_is_prime(void);
int test_ebob_ekok(void);
int test_ortalama(void);

int main(void)
{
    int toplam = 0;
    toplam += test_is_prime();
    toplam += test_ebob_ekok();
    toplam += test_ortalama();
    printf("Tüm testler geçti (%d doğrulama).\n", toplam);
    return 0;
}

int test_is_prime(void)
{
    assert(is_prime(7));                /* normal */
    assert(is_prime(97));
    assert(!is_prime(91));              /* 7 * 13: asal "görünümlü" */
    assert(!is_prime(0));               /* sınır */
    assert(!is_prime(1));
    assert(is_prime(2));
    assert(is_prime(3));
    assert(!is_prime(4));
    assert(is_prime(2147483647));       /* INT_MAX: taşma olmamalı */
    assert(!is_prime(-7));              /* beklenmedik: negatif */
    printf("is_prime   : 10 test geçti\n");
    return 10;
}

int test_ebob_ekok(void)
{
    assert(ebob(48, 18) == 6);          /* normal */
    assert(ebob(18, 48) == 6);          /* sıra değişince */
    assert(ebob(17, 5) == 1);           /* aralarında asal */
    assert(ebob(7, 7) == 7);            /* sınır: eşit */
    assert(ebob(1, 1000000) == 1);      /* sınır: 1 */
    assert(ekok(48, 18) == 144);
    assert(ekok(4, 6) == 12);
    assert(ekok(2147483647, 2) == 4294967294LL);   /* int'e sığmaz */
    printf("ebob/ekok  : 8 test geçti\n");
    return 8;
}

int test_ortalama(void)
{
    assert(ortalama(70, 85) == 77.5);   /* tam temsil edilebilir */
    assert(yakin(ortalama(0.1, 0.2), 0.15));        /* == olmaz! */
    assert(!(ortalama(0.1, 0.2) == 0.15));          /* gerçekten olmaz */
    assert(yakin(ortalama(-1.5, 1.5), 0.0));
    assert(yakin(ortalama(1e9, 1e9), 1e9));
    assert(!yakin(ortalama(1, 2), 1.4));
    printf("ortalama   : 6 test geçti\n");
    return 6;
}

/* Son koşul: |x - y| < 1e-9 ise true (kayan nokta için "eşit sayılır"). */
bool yakin(double x, double y)
{
    const double EPS = 1e-9;
    return fabs(x - y) < EPS;
}

double ortalama(double a, double b)
{
    return (a + b) / 2.0;
}

/* Örnek 6'daki is_prime'ın aynısı. */
bool is_prime(int n)
{
    if (n < 2) {
        return false;
    }
    if (n == 2) {
        return true;
    }
    if (n % 2 == 0) {
        return false;
    }
    for (int d = 3; d <= n / d; d += 2) {
        if (n % d == 0) {
            return false;
        }
    }
    return true;
}

/* Örnek 7'deki ebob ve ekok'un aynısı. */
int ebob(int a, int b)
{
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

long long ekok(int a, int b)
{
    return (long long)a / ebob(a, b) * b;
}

/* H08_T05_selamla_prototip_bosluklu.c — Hafta 8
 *          "Fonksiyonu tamamla" 5 (boşluklu sürüm)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ: ____ yerine doğru ögeyi seçin
 * (web: "Fonksiyonu tamamla" simülasyonu;
 *          tamamlanmış hâli H08_T05_selamla_prototip.c)
 */
#include <stdio.h>

____ selamla(____);

int main(void)
{
    selamla();
    return 0;
}

____ selamla(____)
{
    printf("Merhaba!\n");
}

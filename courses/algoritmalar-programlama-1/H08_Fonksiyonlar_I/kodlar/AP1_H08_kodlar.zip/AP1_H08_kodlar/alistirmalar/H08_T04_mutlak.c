/* H08_T04_mutlak.c — Hafta 8 · "Fonksiyonu tamamla" 4 (tamamlanmış sürüm)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_T04_mutlak.c -o t04
 */
#include <stdio.h>

int mutlak(int x);

int main(void)
{
    printf("mutlak(-9) = %d, mutlak(4) = %d\n", mutlak(-9), mutlak(4));
    return 0;
}

int mutlak(int x)
{
    if (x < 0) {
        x = -x;
    }
    return x;
}

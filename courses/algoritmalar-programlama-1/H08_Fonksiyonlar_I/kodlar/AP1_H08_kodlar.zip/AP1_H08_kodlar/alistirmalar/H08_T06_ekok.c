/* H08_T06_ekok.c — Hafta 8 · "Fonksiyonu tamamla" 6 (tamamlanmış sürüm)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_T06_ekok.c -o t06
 */
#include <stdio.h>

int ebob(int a, int b);
long long ekok(int a, int b);

int main(void)
{
    printf("ekok(4, 6) = %lld\n", ekok(4, 6));
    return 0;
}

int ebob(int a, int b)
{
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

long long ekok(int a, int b)
{
    return (long long)a / ebob(a, b) * b;
}

/* H08_A04_hata_bul_harf.c — Hafta 8 · Alıştırma 8.4 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR. Amaç: her harfi büyütüp ünlü olup olmadığını
 * yazmak. Beklenen: "E: ünlü" ve "K: ünlü değil". İKİ hata var.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_A04_hata_bul_harf.c -o a04
 */
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>

bool unlu_mu(char h);
void incele(char h);

int main(void)
{
    incele('e');
    incele('k');
    return 0;
}

void incele(char h)
{
    toupper(h);
    if (unlu_mu(h)) {
        printf("%c: ünlü\n", h);
    } else {
        printf("%c: ünlü değil\n", h);
    }
}

/* Son koşul: h büyük ünlü harf (A, E, I, O, U) ise true. */
bool unlu_mu(char h)
{
    return h == 'A' || 'E' || 'I' || 'O' || 'U';
}

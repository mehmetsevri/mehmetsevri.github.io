/* H08_T04_mutlak_bosluklu.c — Hafta 8
 *          "Fonksiyonu tamamla" 4 (boşluklu sürüm)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ: ____ yerine doğru ögeyi seçin
 * (web: "Fonksiyonu tamamla" simülasyonu;
 *          tamamlanmış hâli H08_T04_mutlak.c)
 */
#include <stdio.h>

int mutlak(int x);

int main(void)
{
    printf("mutlak(-9) = %d, mutlak(4) = %d\n", mutlak(-9), mutlak(4));
    return 0;
}

int mutlak(int x)
{
    if (x < 0) {
        ____;
    }
    return x;
}

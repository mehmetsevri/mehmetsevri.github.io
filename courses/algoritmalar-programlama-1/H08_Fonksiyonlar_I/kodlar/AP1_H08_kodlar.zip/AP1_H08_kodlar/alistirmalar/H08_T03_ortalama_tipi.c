/* H08_T03_ortalama_tipi.c — Hafta 8 · "Fonksiyonu tamamla" 3 (tamamlanmış)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_T03_ortalama_tipi.c -o t03
 */
#include <stdio.h>

double ortalama(int a, int b);

int main(void)
{
    printf("ortalama(3, 4) = %.2f\n", ortalama(3, 4));
    return 0;
}

double ortalama(int a, int b)
{
    return (a + b) / 2.0;
}

/* H08_T02_cift_mi_bosluklu.c — Hafta 8
 *          "Fonksiyonu tamamla" 2 (boşluklu sürüm)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ: ____ yerine doğru ögeyi seçin
 * (web: "Fonksiyonu tamamla" simülasyonu;
 *          tamamlanmış hâli H08_T02_cift_mi.c)
 */
#include <stdio.h>
#include <stdbool.h>

bool is_even(int n);

int main(void)
{
    printf("%d %d %d\n", is_even(8), is_even(7), is_even(0));
    return 0;
}

bool is_even(int n)
{
    return n % 2 ____ 0;
}

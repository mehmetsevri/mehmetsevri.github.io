/* H08_T03_ortalama_tipi_bosluklu.c — Hafta 8
 *          "Fonksiyonu tamamla" 3 (boşluklu sürüm)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ: ____ yerine doğru ögeyi seçin
 * (web: "Fonksiyonu tamamla" simülasyonu;
 *          tamamlanmış hâli H08_T03_ortalama_tipi.c)
 */
#include <stdio.h>

____ ortalama(int a, int b);

int main(void)
{
    printf("ortalama(3, 4) = %.2f\n", ortalama(3, 4));
    return 0;
}

____ ortalama(int a, int b)
{
    return (a + b) / 2.0;
}

/* H08_T07_faktoriyel_bosluklu.c — Hafta 8
 *          "Fonksiyonu tamamla" 7 (boşluklu sürüm)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ: ____ yerine doğru ögeyi seçin
 * (web: "Fonksiyonu tamamla" simülasyonu;
 *          tamamlanmış hâli H08_T07_faktoriyel.c)
 */
#include <stdio.h>

unsigned long long faktoriyel(int n);

int main(void)
{
    printf("5! = %llu, 0! = %llu\n", faktoriyel(5), faktoriyel(0));
    return 0;
}

unsigned long long faktoriyel(int n)
{
    unsigned long long carpim = ____;
    for (int i = 2; i <= n; i++) {
        carpim *= i;
    }
    return carpim;
}

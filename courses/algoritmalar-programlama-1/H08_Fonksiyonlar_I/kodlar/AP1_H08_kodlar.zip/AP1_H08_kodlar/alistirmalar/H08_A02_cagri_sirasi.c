/* H08_A02_cagri_sirasi.c — Hafta 8 · Alıştırma 8.2 (★★, çıktı tahmini)
 * Çağrılar hangi sırayla çalışır? Önce hangi çağrının argümanı hesaplanır?
 * Not: Tanımlar main'den ÖNCE geldiği için ayrı prototip gerekmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_A02_cagri_sirasi.c -o a02
 */
#include <stdio.h>

int g(int n)
{
    printf("g(%d) ", n);
    return n + 1;
}

int f(int n)
{
    printf("f(%d) ", n);
    return g(n * 2);
}

int main(void)
{
    int r = f(g(1));
    printf("\nsonuç: %d\n", r);
    return 0;
}

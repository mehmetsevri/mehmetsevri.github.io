/* H08_A01_cikti_tahmini.c — Hafta 8 · Alıştırma 8.1 (★, çıktı tahmini)
 * Programın çıktısını çalıştırmadan tahmin edin: a hangi değeri yazar?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_A01_cikti_tahmini.c -o a01
 */
#include <stdio.h>

int f(int x);

int main(void)
{
    int a = 5;
    int b = f(a);
    printf("%d %d\n", a, b);
    printf("%d\n", f(f(a)));
    printf("%d\n", f(a) + f(a));
    return 0;
}

int f(int x)
{
    x = x * 2;
    return x + 1;
}

/* H08_T01_kup.c — Hafta 8 · "Fonksiyonu tamamla" 1 (tamamlanmış sürüm)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_T01_kup.c -o t01
 */
#include <stdio.h>

int kup(int x);

int main(void)
{
    printf("kup(3) = %d, kup(-2) = %d\n", kup(3), kup(-2));
    return 0;
}

int kup(int x)
{
    return x * x * x;
}

/* H08_T05_selamla_prototip.c — Hafta 8 · "Fonksiyonu tamamla" 5 (tamamlanmış)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_T05_selamla_prototip.c -o t05
 */
#include <stdio.h>

void selamla(void);

int main(void)
{
    selamla();
    return 0;
}

void selamla(void)
{
    printf("Merhaba!\n");
}

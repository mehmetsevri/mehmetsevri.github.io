/* H08_A03_hata_bul_ortalama.c — Hafta 8 · Alıştırma 8.3 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR. Amaç: vize 72, final 85 için ağırlıklı
 * ortalamayı (%40 + %60: 79.80) ve harf notunu (B) yazdırmak. ÜÇ hata var.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_A03_hata_bul_ortalama.c -o a03
 */
#include <stdio.h>

int main(void)
{
    int vize = 72, final = 85;
    printf("Ortalama: %.2f\n", ortalama(vize, final));
    printf("Harf    : %c\n", harf(ortalama(vize, final)));
    return 0;
}

double ortalama(int vize, int final)
{
    return (vize * 40 + final * 60) / 100;
}

char harf(double ort)
{
    if (ort >= 85) {
        return 'A';
    } else if (ort >= 70) {
        return 'B';
    } else if (ort >= 50) {
        return 'C';
    }
}

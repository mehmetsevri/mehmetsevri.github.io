/* H08_T07_faktoriyel.c — Hafta 8 · "Fonksiyonu tamamla" 7 (tamamlanmış)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_T07_faktoriyel.c -o t07
 */
#include <stdio.h>

unsigned long long faktoriyel(int n);

int main(void)
{
    printf("5! = %llu, 0! = %llu\n", faktoriyel(5), faktoriyel(0));
    return 0;
}

unsigned long long faktoriyel(int n)
{
    unsigned long long carpim = 1;
    for (int i = 2; i <= n; i++) {
        carpim *= i;
    }
    return carpim;
}

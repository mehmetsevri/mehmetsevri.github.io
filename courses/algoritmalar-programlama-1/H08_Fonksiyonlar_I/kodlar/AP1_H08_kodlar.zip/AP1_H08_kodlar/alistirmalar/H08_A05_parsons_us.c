/* H08_A05_parsons_us.c — Hafta 8 · Alıştırma 8.5 (★★, Parsons)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. Aşağıdaki satırları, us_al
 * fonksiyonunu tanımlayan ve 3^4 = 81 yazdıran bir programa dönüştürecek
 * biçimde sıralayın ve girintileyin. Satırlardan BİRİ fazladır (çeldirici).
 */
#include <stdio.h>

    return sonuc;
long long us_al(int taban, int us);
int main(void)
}
    long long sonuc = 0;
{
        sonuc *= taban;
    printf("3^4 = %lld\n", us_al(3, 4));
long long us_al(int taban, int us)
    return 0;
    for (int i = 1; i <= us; i++) {
}
    long long sonuc = 1;
    }
{

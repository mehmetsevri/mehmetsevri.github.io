/* H08_A06_kod_tamamla_basamak.c — Hafta 8 · Alıştırma 8.6 (★★, kod tamamla)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. Boşlukları (____) doldurun.
 * Beklenen çıktı: "38783: 5 basamak, en büyük basamak 8" ve "0: 1 basamak,
 * en büyük basamak 0".
 */
#include <stdio.h>

int basamak_sayisi(int n);
int en_buyuk_basamak(int n);

int main(void)
{
    printf("%d: %d basamak, en büyük basamak %d\n", 38783,
           basamak_sayisi(38783), en_buyuk_basamak(38783));
    printf("%d: %d basamak, en büyük basamak %d\n", 0,
           basamak_sayisi(0), en_buyuk_basamak(0));
    return 0;
}

/* Ön koşul: n >= 0.  Son koşul: n'nin basamak sayısı (0 için 1). */
int basamak_sayisi(int n)
{
    int sayac = 0;
    ____ {
        sayac++;
        n /= 10;
    } while (n != 0);
    return ____;
}

/* Ön koşul: n >= 0.  Son koşul: n'nin en büyük basamağı. */
____ en_buyuk_basamak(int n)
{
    int enb = n % 10;
    while (n > 0) {
        if (n % 10 > enb) {
            enb = ____;
        }
        n /= 10;
    }
    return enb;
}

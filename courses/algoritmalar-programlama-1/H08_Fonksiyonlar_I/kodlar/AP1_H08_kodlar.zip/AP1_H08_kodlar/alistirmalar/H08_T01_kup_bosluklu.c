/* H08_T01_kup_bosluklu.c — Hafta 8
 *          "Fonksiyonu tamamla" 1 (boşluklu sürüm)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ: ____ yerine doğru ögeyi seçin
 * (web: "Fonksiyonu tamamla" simülasyonu;
 *          tamamlanmış hâli H08_T01_kup.c)
 */
#include <stdio.h>

int kup(int x);

int main(void)
{
    printf("kup(3) = %d, kup(-2) = %d\n", kup(3), kup(-2));
    return 0;
}

int kup(int x)
{
    return ____;
}

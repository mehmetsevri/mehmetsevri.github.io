/* H08_T02_cift_mi.c — Hafta 8 · "Fonksiyonu tamamla" 2 (tamamlanmış sürüm)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_T02_cift_mi.c -o t02
 */
#include <stdio.h>
#include <stdbool.h>

bool is_even(int n);

int main(void)
{
    printf("%d %d %d\n", is_even(8), is_even(7), is_even(0));
    return 0;
}

bool is_even(int n)
{
    return n % 2 == 0;
}

/* H08_T06_ekok_bosluklu.c — Hafta 8
 *          "Fonksiyonu tamamla" 6 (boşluklu sürüm)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ: ____ yerine doğru ögeyi seçin
 * (web: "Fonksiyonu tamamla" simülasyonu;
 *          tamamlanmış hâli H08_T06_ekok.c)
 */
#include <stdio.h>

int ebob(int a, int b);
long long ekok(int a, int b);

int main(void)
{
    printf("ekok(4, 6) = %lld\n", ekok(4, 6));
    return 0;
}

int ebob(int a, int b)
{
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

long long ekok(int a, int b)
{
    return (long long)a / ____ * b;
}

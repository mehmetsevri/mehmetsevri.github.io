/* H08_K17_iskelet_atm.c — Hafta 8 · Kavram programı: adım adım iyileştirme
 * Amaç   : Yukarıdan aşağıya tasarımın 1. adımı: main yalnızca alt görevlerin
 *          ADLARIYLA yazılır; alt görevler şimdilik "koçan" (stub)
 *          fonksiyonlardır: adlarını yazar, sabit bir değer döndürür.
 *          Program derlenir ve çalışır; ayrıntılar sonraki adımlarda dolar
 *          (son hâli: H08_13_atm_fonksiyonlu.c).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K17_iskelet_atm.c -o iskelet_atm
 */
#include <stdio.h>
#include <stdbool.h>

bool pin_dogrula(void);
int menu_secimi(void);
int islem_yap(int secim, int bakiye);

int main(void)
{
    int bakiye = 1000;
    if (!pin_dogrula()) {
        printf("Kart bloke.\n");
        return 2;
    }
    int secim;
    do {
        secim = menu_secimi();
        bakiye = islem_yap(secim, bakiye);
    } while (secim != 4);
    printf("Son bakiye: %d TL\n", bakiye);
    return 0;
}

bool pin_dogrula(void)
{
    printf("[koçan] pin_dogrula: PIN doğru sayıldı\n");
    return true;
}

int menu_secimi(void)
{
    printf("[koçan] menu_secimi: 4 (çıkış) seçildi\n");
    return 4;
}

int islem_yap(int secim, int bakiye)
{
    printf("[koçan] islem_yap(%d, %d): işlem yok\n", secim, bakiye);
    return bakiye;
}

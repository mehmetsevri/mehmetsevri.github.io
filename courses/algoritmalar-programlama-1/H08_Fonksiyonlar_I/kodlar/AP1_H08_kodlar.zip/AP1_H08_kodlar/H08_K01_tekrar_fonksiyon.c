/* H08_K01_tekrar_fonksiyon.c — Hafta 8 · Kavram programı: neden fonksiyon?
 * Amaç   : Aynı formülü üç kez yazmak (kopyala-yapıştır) ile bir kez yazıp
 *          üç kez çağırmak aynı çıktıyı verir. Ama formül değişirse ilkinde
 *          üç yer, ikincisinde tek yer düzeltilir (DRY, H6).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K01_tekrar_fonksiyon.c -o tekrar_fonksiyon
 */
#include <stdio.h>

double agirlikli_ortalama(double vize, double final);

int main(void)
{
    /* 1) Fonksiyonsuz: aynı formül üç kez */
    printf("Ali  : %.2f\n", 0.40 * 70 + 0.60 * 85);
    printf("Ayşe : %.2f\n", 0.40 * 90 + 0.60 * 95);
    printf("Can  : %.2f\n", 0.40 * 45 + 0.60 * 48);

    /* 2) Fonksiyonlu: formül TEK yerde, adıyla çağrılır */
    printf("Ali  : %.2f\n", agirlikli_ortalama(70, 85));
    printf("Ayşe : %.2f\n", agirlikli_ortalama(90, 95));
    printf("Can  : %.2f\n", agirlikli_ortalama(45, 48));
    return 0;
}

/* %40 vize + %60 final (Mini-OBS kuralı). */
double agirlikli_ortalama(double vize, double final)
{
    return 0.40 * vize + 0.60 * final;
}

/* H08_06_is_prime.c — Hafta 8 · Örnek 6 (★★): H7 kodunun yeniden düzenlenmesi
 * Amaç   : H07_11'deki iyileştirilmiş asallık testi (yalnızca tek bölenler,
 *          karekök sınırı) bool döndüren bir fonksiyona taşındı (refactoring).
 *          Bölen bulununca "return false" döngüyü ve fonksiyonu birlikte
 *          bitirir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_06_is_prime.c -o is_prime
 * Örnek  : -> is_prime(2147483647) = 1
 */
#include <stdio.h>
#include <stdbool.h>

bool is_prime(int n);

int main(void)
{
    int adet = 0;
    printf("50'ye kadar asallar:");
    for (int n = 1; n <= 50; n++) {
        if (is_prime(n)) {              /* koşul bir cümle gibi okunur */
            printf(" %d", n);
            adet++;
        }
    }
    printf("\n(%d asal)\n", adet);
    printf("is_prime(97)         = %d\n", is_prime(97));
    printf("is_prime(91)         = %d\n", is_prime(91));
    printf("is_prime(-7)         = %d\n", is_prime(-7));
    printf("is_prime(2147483647) = %d\n", is_prime(2147483647));
    return 0;
}

/* Ön koşul : yok (her int için tanımlı).
 * Son koşul: n asalsa true, değilse false döndürür.
 * Yöntem   : 2 dışındaki çiftleri ele; 3'ten başlayıp yalnızca tek
 *            bölenleri dene; d <= n / d (d * d <= n yerine: taşma yok). */
bool is_prime(int n)
{
    if (n < 2) {
        return false;                   /* 0, 1 ve negatifler asal değil */
    }
    if (n == 2) {
        return true;                    /* tek çift asal */
    }
    if (n % 2 == 0) {
        return false;                   /* diğer bütün çiftler */
    }
    for (int d = 3; d <= n / d; d += 2) {
        if (n % d == 0) {
            return false;               /* bölen bulundu: hemen dön */
        }
    }
    return true;                        /* hiçbir tek bölen yok */
}

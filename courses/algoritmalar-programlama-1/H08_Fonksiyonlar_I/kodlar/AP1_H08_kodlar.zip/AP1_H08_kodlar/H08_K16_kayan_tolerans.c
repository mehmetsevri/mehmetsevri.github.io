/* H08_K16_kayan_tolerans.c — Hafta 8 · Kavram programı: kayan noktada eşitlik
 * Amaç   : 0.1 + 0.2 ikili tabanda tam temsil edilemez (H3, IEEE 754);
 *          == ile karşılaştırma yanlış çıkar. Testlerde "yeterince yakın mı?"
 *          sorusunu soran yakin() fonksiyonu kullanılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K16_kayan_tolerans.c -o kayan_tolerans -lm
 */
#include <stdio.h>
#include <stdbool.h>
#include <math.h>                       /* fabs */

bool yakin(double x, double y);

int main(void)
{
    double a = 0.1 + 0.2;
    printf("0.1 + 0.2     = %.17f\n", a);
    printf("a == 0.3      : %d\n", a == 0.3);
    printf("yakin(a, 0.3) : %d\n", yakin(a, 0.3));
    return 0;
}

/* Son koşul: |x - y| < 1e-9 ise true. */
bool yakin(double x, double y)
{
    const double EPS = 1e-9;
    return fabs(x - y) < EPS;
}

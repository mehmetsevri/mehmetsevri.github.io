/* H08_K11_ctype.c — Hafta 8 · Kavram programı: <ctype.h>
 * Amaç   : isdigit, isalpha, isspace ve toupper ile bir satırı karakter
 *          karakter işlemek. ctype fonksiyonlarının argümanı unsigned char
 *          aralığında ya da EOF olmalıdır: getchar() bunu zaten sağlar;
 *          char değişkenle çağırırken (unsigned char)'a dönüştürün.
 *          isdigit "doğru" için 1 değil, SIFIRDAN FARKLI bir int döndürür.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_K11_ctype.c -o ctype_ornek
 */
#include <stdio.h>
#include <ctype.h>

int rakam_mi(char ch);

int main(void)
{
    printf("isdigit('7') = %d, isdigit('x') = %d\n",
           isdigit('7'), isdigit('x'));
    printf("rakam_mi('5') = %d\n", rakam_mi('5'));

    int c, rakam = 0, harf = 0, bosluk = 0;
    printf("Bir satır yazın: ");
    while ((c = getchar()) != '\n' && c != EOF) {
        if (isdigit(c)) {
            rakam++;
        } else if (isalpha(c)) {
            harf++;
        } else if (isspace(c)) {
            bosluk++;
        }
        putchar(toupper(c));            /* harf değilse aynen döner */
    }
    printf("\nrakam: %d, harf: %d, boşluk: %d\n", rakam, harf, bosluk);
    return 0;
}

/* char ile çağırırken önce unsigned char'a dönüştür (negatif değer UB). */
int rakam_mi(char ch)
{
    return isdigit((unsigned char)ch) != 0;
}

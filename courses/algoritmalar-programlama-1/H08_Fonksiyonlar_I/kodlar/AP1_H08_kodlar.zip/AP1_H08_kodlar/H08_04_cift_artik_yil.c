/* H08_04_cift_artik_yil.c — Hafta 8 · Örnek 4 (★): bool döndüren fonksiyonlar
 * Amaç   : Doğrulama fonksiyonları "evet/hayır" sorusunu yanıtlar ve
 *          koşulları okunur kılar: if (is_leap_year(yil)) ...
 *          H05_05'teki artık yıl ifadesi tek bir fonksiyona taşındı.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_04_cift_artik_yil.c -o cift_artik_yil
 * Örnek  : -> 1900: artık yıl değil (365 gün)
 */
#include <stdio.h>
#include <stdbool.h>                    /* bool, true, false (C99) */

bool is_even(int n);
bool is_leap_year(int yil);
void yil_raporu(int yil);

int main(void)
{
    printf("is_even(10) = %d\n", is_even(10));  /* bool -> int: 1 */
    printf("is_even(7)  = %d\n", is_even(7));   /* 0 */
    printf("is_even(-4) = %d\n", is_even(-4));
    yil_raporu(1900);
    yil_raporu(2000);
    yil_raporu(2024);
    yil_raporu(2026);
    yil_raporu(2100);
    return 0;
}

/* n çiftse true döndürür (negatifler için de doğru). */
bool is_even(int n)
{
    return n % 2 == 0;
}

/* Gregoryen kural: 4'e bölünen yıllar artıktır; ama 100'e bölünenler
 * değildir; ancak 400'e bölünenler yine artıktır. */
bool is_leap_year(int yil)
{
    return (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;
}

/* Bir yılın artık olup olmadığını ve gün sayısını yazar. */
void yil_raporu(int yil)
{
    if (is_leap_year(yil)) {
        printf("%d: artık yıl (366 gün)\n", yil);
    } else {
        printf("%d: artık yıl değil (365 gün)\n", yil);
    }
}

/* H08_02_kare.c — Hafta 8 · Örnek 2 (★): parametre ve dönüş değeri
 * Amaç   : kare(x): bir int alır (parametre), bir int döndürür (return).
 *          Argüman sabit, değişken, ifade ya da başka bir çağrı olabilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H08_02_kare.c -o kare
 * Örnek  : -> kare(kare(3)) = 81
 */
#include <stdio.h>

int kare(int x);                        /* prototip: int alır, int döndürür */

int main(void)
{
    int a = 7;
    int sonuc = kare(a);                /* argüman: a'nın DEĞERİ (7) */
    printf("kare(%d) = %d\n", a, sonuc);
    printf("kare(5) = %d\n", kare(5));
    printf("kare(a + 1) = %d\n", kare(a + 1));      /* önce a + 1 = 8 */
    printf("kare(kare(3)) = %d\n", kare(kare(3)));  /* içteki önce */
    return 0;
}

/* x'in karesini döndürür. */
int kare(int x)
{
    return x * x;
}

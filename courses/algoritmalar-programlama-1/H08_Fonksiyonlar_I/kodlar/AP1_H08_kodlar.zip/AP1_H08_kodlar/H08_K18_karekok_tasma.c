/* H08_K18_karekok_tasma.c — Hafta 8 · Kavram programı: d * d <= n neden riskli?
 * BU DOSYA KASITLI HATA İÇERİR: is_prime_dd, döngü koşulunda d * d <= n
 * kullanır. n = 2147483647 (INT_MAX) için d = 46341 olduğunda d * d int'e
 * sığmaz: işaretli tamsayı taşması TANIMSIZ DAVRANIŞTIR (H3-H4).
 * UndefinedBehaviorSanitizer bunu çalışma zamanında yakalar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -fsanitize=undefined \
 *              H08_K18_karekok_tasma.c -o karekok_tasma
 */
#include <stdio.h>
#include <stdbool.h>

bool is_prime_dd(int n);

int main(void)
{
    printf("is_prime_dd(97) = %d\n", is_prime_dd(97));
    printf("is_prime_dd(2147483647) = %d\n", is_prime_dd(2147483647));
    return 0;
}

bool is_prime_dd(int n)
{
    if (n < 2) {
        return false;
    }
    if (n == 2) {
        return true;
    }
    if (n % 2 == 0) {
        return false;
    }
    for (int d = 3; d * d <= n; d += 2) {   /* d * d taşabilir! */
        if (n % d == 0) {
            return false;
        }
    }
    return true;
}

/* H03_Q01_tamsayi_bolme.c — AP-1 Hafta 3, Quiz sorusu 1 (web “Kendini sına”)
 * Materyalde: web “Kendini sına” 1. soru; aynı parça sunumun çıkış biletinde
 *          (1. soru) metin içinde geçer. Soru: kod ne yazdırır?
 * Not    : x / 4 iki int'in bölmesidir (2); sonuç double'a atanınca 2.0 olur;
 *          satır sonunu ayrı bir printf yazar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_Q01_tamsayi_bolme.c -o q01
 * Çıktı  : ciktilar/H03_Q01_tamsayi_bolme.txt */

#include <stdio.h>

int main(void)
{
    int x = 10;
    double y = x / 4;
    printf("%.2f", y);
    printf("\n");
    return 0;
}

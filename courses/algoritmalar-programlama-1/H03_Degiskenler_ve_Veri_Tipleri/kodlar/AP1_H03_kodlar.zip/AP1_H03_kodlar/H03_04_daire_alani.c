/* H03_04_daire_alani.c — AP-1 Hafta 3, Örnek 4 (★)
 * Amaç   : Dairenin alanı: double, #define ve const, %.2f
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_04_daire_alani.c -o daire
 * Çıktı  : Alan = 78.54 cm²  (girdi: 5) */
#include <stdio.h>
#define PI 3.14159265358979        /* makro: önişlemci metni yerine koyar */

int main(void)
{
    const double CM2_M2 = 0.0001;  /* const: tipli, değiştirilemez sabit */
    double yaricap;

    printf("Yarıçap (cm): ");
    scanf("%lf", &yaricap);        /* double okumak için %lf */

    double alan = PI * yaricap * yaricap;
    printf("Alan = %f cm² (varsayılan 6 basamak)\n", alan);
    printf("Alan = %.2f cm²\n", alan);
    printf("Alan = %.4f m²\n", alan * CM2_M2);
    return 0;
}

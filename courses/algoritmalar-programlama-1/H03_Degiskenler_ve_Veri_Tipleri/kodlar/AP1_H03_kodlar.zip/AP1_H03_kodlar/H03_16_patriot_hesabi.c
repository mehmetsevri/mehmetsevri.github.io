/* H03_16_patriot_hesabi.c — AP-1 Hafta 3, Ek örnek 16 (★★★)
 * Amaç   : Ek örnek (Merak): Patriot saatindeki birikimli hata
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_16_patriot_hesabi.c -o patriot
 * Çıktı  : 100 saat sonra  : 0.3433 s */
#include <stdio.h>

int main(void)
{
    /* 0.1 = 0.000110011001100... (ikili, sonsuz). Yazmaçta
       ikili noktadan sonra 23 bitte kesilirse: 838860 / 2^23 */
    const double KESILMIS = 838860.0 / 8388608.0;
    double tik_hatasi = 0.1 - KESILMIS;   /* her 0,1 s'lik tıkta */

    printf("Kesilmiş 0.1    : %.12f\n", KESILMIS);
    printf("Tık başına hata : %.3e s\n", tik_hatasi);
    printf("  1 saat sonra  : %.4f s\n", tik_hatasi * 1 * 3600 * 10);
    printf("  8 saat sonra  : %.4f s\n", tik_hatasi * 8 * 3600 * 10);
    printf(" 20 saat sonra  : %.4f s\n", tik_hatasi * 20 * 3600 * 10);
    printf(" 48 saat sonra  : %.4f s\n", tik_hatasi * 48 * 3600 * 10);
    printf(" 72 saat sonra  : %.4f s\n", tik_hatasi * 72 * 3600 * 10);
    printf("100 saat sonra  : %.4f s\n", tik_hatasi * 100 * 3600 * 10);
    return 0;
}

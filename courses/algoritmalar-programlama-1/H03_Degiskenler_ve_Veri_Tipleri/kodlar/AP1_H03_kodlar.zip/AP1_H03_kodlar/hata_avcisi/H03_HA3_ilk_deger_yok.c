/* H03_HA3_ilk_deger_yok.c — AP-1 Hafta 3, Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR. Konu: İlk değer atanmamış değişken */

#include <stdio.h>

int main(void)
{
    int toplam;                  /* HATA: ilk değer verilmedi */
    int sayi = 10;

    toplam = toplam + sayi;
    printf("Toplam: %d\n", toplam);
    return 0;
}

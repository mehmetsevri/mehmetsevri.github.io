/* H03_HA4_bolme_ve_esitlik.c — AP-1 Hafta 3, Hata Avcısı 4 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR. Konu: Tamsayı bölmesi ve kayan noktada == */

#include <stdio.h>

int main(void)
{
    int a = 5;
    int b = 2;
    double ortalama = (a + b) / 2;         /* HATA: 7 / 2 → 3 */
    double oran = 0.1 * 3;

    printf("ortalama = %f\n", ortalama);
    printf("a / b    = %d\n", a / b);
    printf("oran == 0.3 mü? %d\n", oran == 0.3);   /* HATA: == */
    return 0;
}

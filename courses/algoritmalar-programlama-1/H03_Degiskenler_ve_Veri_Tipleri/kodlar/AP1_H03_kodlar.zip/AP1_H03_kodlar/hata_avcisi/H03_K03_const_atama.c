/* H03_K03_const_atama.c — AP-1 Hafta 3, Kavram: const değiştirilebilir mi?
 * BU DOSYA KASITLI HATA İÇERİR — derlenmez (salt okunur değişkene atama).
 * Materyalde: sunum slayt 31 “Sabitler: #define mi, const mı?” (12–18.
 *          satırlar ve gerçek GCC iletisi; hatalı satır 15) ve ders notu
 *          4.4 Örnek 4 “Değiştir (a)” (CM2_M2 = 1.0; eklenince alınan hata).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_K03_const_atama.c -o const_atama
 * Gerçek derleyici iletisi: ciktilar/H03_K03_const_atama.txt */

#include <stdio.h>

int main(void)
{
    const double CM2_M2 = 0.0001;
    CM2_M2 = 1.0;
    printf("%f\n", CM2_M2);
    return 0;
}

/* H03_HA2_bicim_uyumsuzlugu_duzeltilmis.c — Hata Avcısı 2, düzeltilmiş sürüm
 * AP-1 Hafta 3 · Konu: Biçim belirteci–tip uyuşmazlığı */

#include <stdio.h>

int main(void)
{
    double ortalama = 77.5;
    int not_sayisi = 2;

    printf("Ortalama  : %.2f\n", ortalama);   /* DOĞRU: double için %f */
    printf("Not sayısı: %d\n", not_sayisi);   /* DOĞRU: int için %d */
    return 0;
}

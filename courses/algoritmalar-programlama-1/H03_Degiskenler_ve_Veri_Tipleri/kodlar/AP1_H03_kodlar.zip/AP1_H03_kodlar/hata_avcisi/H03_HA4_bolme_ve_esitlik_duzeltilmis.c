/* H03_HA4_bolme_ve_esitlik_duzeltilmis.c — Hata Avcısı 4, düzeltilmiş sürüm
 * AP-1 Hafta 3 · Konu: Tamsayı bölmesi ve == ile kayan nokta karşılaştırma */

#include <stdio.h>

int main(void)
{
    int a = 5;
    int b = 2;
    double ortalama = (a + b) / 2.0;       /* DOĞRU: 7 / 2.0 → 3.5 */
    double oran = 0.1 * 3;
    double fark = oran - 0.3;              /* == yerine farka bak */

    printf("ortalama = %f\n", ortalama);
    printf("a / b    = %d (tamsayı bölmesi kesirli kısmı atar)\n", a / b);
    printf("oran - 0.3 = %e (sıfır değil, çok küçük)\n", fark);
    return 0;
}

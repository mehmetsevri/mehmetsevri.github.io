/* H03_HA2_bicim_uyumsuzlugu.c — AP-1 Hafta 3, Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR. Konu: Biçim belirteci–tip uyuşmazlığı */

#include <stdio.h>

int main(void)
{
    double ortalama = 77.5;
    int not_sayisi = 2;

    printf("Ortalama  : %d\n", ortalama);     /* HATA: double için %d */
    printf("Not sayısı: %f\n", not_sayisi);   /* HATA: int için %f */
    return 0;
}

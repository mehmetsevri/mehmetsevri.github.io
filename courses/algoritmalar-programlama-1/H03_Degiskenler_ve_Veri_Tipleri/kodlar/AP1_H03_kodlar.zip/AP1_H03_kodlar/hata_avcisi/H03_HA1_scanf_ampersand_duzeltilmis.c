/* H03_HA1_scanf_ampersand_duzeltilmis.c — Hata Avcısı 1, düzeltilmiş sürüm
 * AP-1 Hafta 3 · Konu: scanf'te & unutulması */

#include <stdio.h>

int main(void)
{
    int yas = 0;

    printf("Yaşınız: ");
    scanf("%d", &yas);           /* DOĞRU: yas'ın adresi verilir */
    printf("Yaş: %d\n", yas);
    return 0;
}

/* H03_HA1_scanf_ampersand.c — AP-1 Hafta 3, Hata Avcısı 1 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR. Konu: scanf'te & unutulması */

#include <stdio.h>

int main(void)
{
    int yas = 0;

    printf("Yaşınız: ");
    scanf("%d", yas);            /* HATA: & unutuldu */
    printf("Yaş: %d\n", yas);
    return 0;
}

/* H03_HA3_ilk_deger_yok_duzeltilmis.c — Hata Avcısı 3, düzeltilmiş sürüm
 * AP-1 Hafta 3 · Konu: İlk değer atanmamış değişken */

#include <stdio.h>

int main(void)
{
    int toplam = 0;              /* DOĞRU: toplayıcı sıfırla başlar */
    int sayi = 10;

    toplam = toplam + sayi;
    printf("Toplam: %d\n", toplam);
    return 0;
}

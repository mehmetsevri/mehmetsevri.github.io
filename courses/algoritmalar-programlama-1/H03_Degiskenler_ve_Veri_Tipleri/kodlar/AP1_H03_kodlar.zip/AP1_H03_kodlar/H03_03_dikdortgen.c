/* H03_03_dikdortgen.c — AP-1 Hafta 3, Örnek 3 (★)
 * Amaç   : Dikdörtgenin alanı ve çevresi: formülün koda aktarılması
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_03_dikdortgen.c -o dikdortgen
 * Çıktı  : Alan  : 28 m²  (girdi: 7, 4) */
#include <stdio.h>

int main(void)
{
    int en;
    int boy;

    printf("Dikdörtgenin eni (m) : ");
    scanf("%d", &en);
    printf("Dikdörtgenin boyu (m): ");
    scanf("%d", &boy);

    int alan = en * boy;           /* A = en × boy       */
    int cevre = 2 * (en + boy);    /* Ç = 2 × (en + boy) */

    printf("Alan  : %d m²\n", alan);
    printf("Çevre : %d m\n", cevre);
    return 0;
}

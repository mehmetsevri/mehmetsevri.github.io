/* H03_08_takas.c — AP-1 Hafta 3, Örnek 8 (★★)
 * Amaç   : İki değişkenin değerlerini geçici değişkenle takas etme
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_08_takas.c -o takas
 * Çıktı  : Sonra: a = 9, b = 5 */
#include <stdio.h>

int main(void)
{
    int a = 5;
    int b = 9;
    printf("Önce : a = %d, b = %d\n", a, b);

    int gecici = a;    /* 1. adım: a'yı boş bardağa dök */
    a = b;             /* 2. adım: b'yi a'ya dök        */
    b = gecici;        /* 3. adım: boş bardaktakini b'ye dök */

    printf("Sonra: a = %d, b = %d\n", a, b);
    return 0;
}

/* H03_11_tasma_deneyi.c — AP-1 Hafta 3, Örnek 11 (★★★)
 * Amaç   : Tamsayı taşması: unsigned sarması (tanımlı), int taşması (tanımsız)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_11_tasma_deneyi.c -o tasma
 * Çıktı  : INT_MAX + 1           : -2147483648  (girdi: 1) */
#include <stdio.h>
#include <limits.h>

int main(void)
{
    unsigned int sayac = UINT_MAX;          /* 2^32 - 1 */
    printf("unsigned int en büyük : %u\n", sayac);
    sayac = sayac + 1;                      /* TANIMLI: mod 2^32 → 0 */
    printf("bir fazlası           : %u\n", sayac);

    int adim = 0;
    printf("INT_MAX'a kaç ekleyelim? ");
    scanf("%d", &adim);                     /* değer çalışma zamanında */

    int x = INT_MAX;                        /* 2^31 - 1 */
    printf("int en büyük          : %d\n", x);
    x = x + adim;                           /* taşarsa TANIMSIZ DAVRANIŞ */
    printf("INT_MAX + %d           : %d\n", adim, x);
    return 0;
}

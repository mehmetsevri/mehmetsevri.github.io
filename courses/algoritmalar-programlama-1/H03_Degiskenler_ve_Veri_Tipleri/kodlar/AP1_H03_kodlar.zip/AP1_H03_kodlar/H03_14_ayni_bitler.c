/* H03_14_ayni_bitler.c — AP-1 Hafta 3, Ek örnek 14 (★★)
 * Amaç   : Ek örnek: aynı bit örüntüsü, farklı tip, farklı yorum
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_14_ayni_bitler.c -o bitler
 * Çıktı  : unsigned olarak  : 4294967295 */
#include <stdio.h>

int main(void)
{
    int i = -1;
    unsigned int u = i;            /* aynı 32 bit, işaretsiz yorum */

    printf("int olarak       : %d\n", i);
    printf("unsigned olarak  : %u\n", u);
    printf("onaltılı (%%x)    : %x\n", u);

    signed char sc = -56;
    unsigned char uc = sc;         /* aynı 8 bit: 1100 1000 */
    printf("signed char      : %d\n", sc);
    printf("unsigned char    : %d\n", uc);
    return 0;
}

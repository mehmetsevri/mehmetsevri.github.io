/* H03_K01_bildirim_atama.c — AP-1 Hafta 3, Kavram programı
 * Amaç   : bildirim, ilk değer atama, atama; yas = yas + 1 (oku, sonra yaz)
 * Materyalde: sunum slayt 13 (int yas = 19;) ve slayt 14 (int ogrenci_sayisi;
 *          ogrenci_sayisi = 85; int yas = 19; yas = yas + 1;); aynı satırlar
 *          Örnek 1'de de geçer (H03_01_degisken_yazdir.c).
 * Dikkat : ogrenci_sayisi bildirimden hemen sonra belirsiz (“çöp”) değer
 *          taşır; atamadan ÖNCE okunmaz (bkz. hata_avcisi/H03_HA3_*.c).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_K01_bildirim_atama.c -o bildirim
 * Çıktı  : ciktilar/H03_K01_bildirim_atama.txt */

#include <stdio.h>

int main(void)
{
    int ogrenci_sayisi;
    ogrenci_sayisi = 85;
    int yas = 19;

    printf("ogrenci_sayisi = %d\n", ogrenci_sayisi);
    printf("yas            = %d\n", yas);

    yas = yas + 1;
    printf("yas = yas + 1 sonrası: %d\n", yas);
    return 0;
}

/* H03_05_celsius_fahrenheit.c — AP-1 Hafta 3, Örnek 5 (★★)
 * Amaç   : Celsius → Fahrenheit; 9 / 5 tamsayı bölmesi tuzağı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_05_celsius_fahrenheit.c -o celsius
 * Çıktı  : Doğru formül : 97.9 °F  (girdi: 36.6) */
#include <stdio.h>

int main(void)
{
    double celsius = 0.0;          /* okuma başarısız olursa 0 kalır */

    printf("Sıcaklık (°C): ");
    scanf("%lf", &celsius);

    double f_hatali = celsius * (9 / 5) + 32;     /* 9 / 5 → 1 (!) */
    double f_dogru = celsius * 9.0 / 5.0 + 32;    /* 9.0 / 5.0 → 1.8 */

    printf("Hatalı formül: %.1f °F\n", f_hatali);
    printf("Doğru formül : %.1f °F\n", f_dogru);
    return 0;
}

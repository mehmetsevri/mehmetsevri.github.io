/* H03_07_karakter_ascii.c — AP-1 Hafta 3, Örnek 7 (★★)
 * Amaç   : char'ın sayısal doğası: karakter ↔ ASCII kodu
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_07_karakter_ascii.c -o ascii
 * Çıktı  : 'A' + 1 = 'B' (kod 66) */
#include <stdio.h>

int main(void)
{
    char harf = 'A';
    char sonraki = harf + 1;       /* 65 + 1 = 66 → 'B' */

    printf("'%c' karakterinin kodu: %d\n", harf, harf);
    printf("'%c' + 1 = '%c' (kod %d)\n", harf, sonraki, sonraki);
    printf("'a' = %d, 'A' = %d, fark = %d\n", 'a', 'A', 'a' - 'A');
    printf("'7' karakterinin kodu %d, 7 sayısı ise %d\n", '7', 7);
    printf("'7' - '0' = %d (rakam karakterinden sayıya)\n", '7' - '0');
    printf("'g' büyük harfe: '%c'\n", 'g' - ('a' - 'A'));
    printf("sizeof(char) = %zu, sizeof('A') = %zu\n",
           sizeof(char), sizeof('A'));
    return 0;
}

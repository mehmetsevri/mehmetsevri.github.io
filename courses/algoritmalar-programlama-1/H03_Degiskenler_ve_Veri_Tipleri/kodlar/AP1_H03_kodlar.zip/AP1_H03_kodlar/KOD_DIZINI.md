# AP-1 · Hafta 3 · Kod dizini

**C’nin Yapı Taşları: Değişkenler, Veri Tipleri, Bellekte Temsil ve Temel Giriş/Çıkış** — bu klasördeki 33 `.c` dosyasının türü, materyalde (ders notu, sunum, web sayfası) geçtiği yerler ve derleme durumu. Ders notunda, sunumda ve web sayfasında gösterilen her C kod parçası bu dosyalardan birinde harfi harfine bulunur (denetim: `node shared/kod_envanteri.js 3` → EKSİK 0).

## Nasıl derlenir ve çalıştırılır?

- **Linux / macOS (gcc):** `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program && ./program`
- **Windows (MinGW-w64, komut istemi):** `chcp 65001 && gcc -std=c17 -Wall -Wextra -pedantic DOSYA.c -o program.exe && program.exe`
- **Code::Blocks:** *Settings › Compiler › Compiler settings › Other compiler options* alanına `-std=c17 -Wall -Wextra -pedantic` yazın; dosyayı açıp *Build › Build and run* (F9).
- **Girdi vermek:** etkileşimli programlar istemden sonra klavyeden girdi bekler; `ciktilar/` dosyalarında girilen değerler uçbirimdeki gibi görünür.

Notlar: `ciktilar/` klasörlerindeki her dosya bu ortamda alınmış **gerçek** derleme ve çalıştırma çıktısıdır (GCC 13.3.0, Ubuntu 24.04, x86-64, LP64). macOS'ta `gcc` komutu aslında Clang'i çalıştırdığı için ileti metinleri farklıdır; Windows'ta (MinGW-w64) `long` 4 bayttır ve bazı iletiler farklı olabilir.

**Kasıtlı hatalı dosyalar** — başlık yorumunda “BU DOSYA KASITLI HATA İÇERİR” yazan dosyalar (`hata_avcisi/` altındaki dört “hatalı sürüm”, `H03_K03_const_atama.c` ve `alistirmalar/H03_A02_hata_bul.c`) — ve başlığında “TAMAMLANACAK” yazan alıştırma dosyalarının derlenmemesi ya da uyarı vermesi beklenen durumdur; gerçek derleyici iletileri her klasörün `ciktilar/` alt klasöründedir. Başlık yorumları en çok 80 sütundur; satır numaraları materyaldeki başvurularla aynıdır.

## Özet

| Tür | Dosya sayısı |
|---|---|
| merdiven örneği | 12 |
| ek örnek (kavram) | 5 |
| kavram | 2 |
| kavram · hata gösterimi | 1 |
| hata avcısı | 4 |
| hata avcısı (düzeltilmiş) | 4 |
| alıştırma | 4 |
| quiz | 1 |
| **Toplam** | **33** |

## Dosyalar

| Dosya | Tür | Açıklama | Materyalde geçtiği yerler | Derleme durumu | Gerçek çıktı |
|---|---|---|---|---|---|
| `H03_01_degisken_yazdir.c` | merdiven örneği | Örnek 1 ★ — bildirim, ilk değer atama, atama ve `printf %d` | **Ders notu:** §4.1 Örnek 1 (kesit)<br>**Sunum:** slayt 16<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_01_degisken_yazdir.txt` |
| `H03_02_iki_sayi_toplam.c` | merdiven örneği | Örnek 2 ★ — `scanf` ve `&` ile iki tamsayı okuma | **Ders notu:** §4.2 Örnek 2 (kesit)<br>**Sunum:** slayt 35<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_02_iki_sayi_toplam.txt` |
| `H03_03_dikdortgen.c` | merdiven örneği | Örnek 3 ★ — dikdörtgenin alanı ve çevresi | **Ders notu:** §4.3 Örnek 3 (kesit)<br>**Sunum:** slayt 12<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_03_dikdortgen.txt` |
| `H03_04_daire_alani.c` | merdiven örneği | Örnek 4 ★ — dairenin alanı: `double`, `#define`, `const`, `%.2f` | **Ders notu:** §4.4 Örnek 4 (kesit)<br>**Sunum:** slayt 12<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_04_daire_alani.txt` |
| `H03_05_celsius_fahrenheit.c` | merdiven örneği | Örnek 5 ★★ (amiral) — Celsius → Fahrenheit; `9 / 5` tamsayı bölmesi tuzağı | **Ders notu:** §4.5 Örnek 5 (başlık yorumu dışında tam, 6–21)<br>**Sunum:** slayt 40 (kesit 8–21)<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_05_celsius_fahrenheit.txt` |
| `H03_06_tip_boyutlari.c` | merdiven örneği | Örnek 6 ★★ — `sizeof`, `limits.h`, `float.h` ile tip boyutları ve aralıkları | **Ders notu:** §4.6 Örnek 6 (kesit)<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_06_tip_boyutlari.txt` |
| `H03_07_karakter_ascii.c` | merdiven örneği | Örnek 7 ★★ — karakter ↔ ASCII kodu | **Ders notu:** §4.7 Örnek 7 (kesit)<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_07_karakter_ascii.txt` |
| `H03_08_takas.c` | merdiven örneği | Örnek 8 ★★ — geçici değişkenle takas | **Ders notu:** §4.8 Örnek 8 (kesit)<br>**Sunum:** slayt 42<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_08_takas.txt` |
| `H03_09_adresler.c` | merdiven örneği | Örnek 9 ★★ — değişkenlerin adresleri (`&`, `%p`); gdb bellek dökümü | **Ders notu:** §4.9 Örnek 9 (kesit)<br>**Sunum:** slayt 43<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven)<br>_Not:_ gdb dökümü sunum slayt 23'te (bayt sırası) | sıfır uyarı | `ciktilar/H03_09_adresler.txt`<br>`ciktilar/H03_09_adresler_gdb.txt` |
| `H03_10_vki.c` | merdiven örneği | Örnek 10 ★★ (amiral) — vücut kitle indeksi | **Ders notu:** §4.10 Örnek 10 (başlık yorumu dışında tam, 6–30)<br>**Sunum:** slayt 44 (kesit 18–28)<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_10_vki.txt` |
| `H03_11_tasma_deneyi.c` | merdiven örneği | Örnek 11 ★★★ — `UINT_MAX + 1` (tanımlı) ve `INT_MAX + 1` (tanımsız); `-fsanitize=undefined` | **Ders notu:** §4.11 Örnek 11 (başlık yorumu dışında tam, 6–25)<br>**Sunum:** slayt 22 (kesit 11–23)<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_11_tasma_deneyi.txt` |
| `H03_12_kayan_nokta.c` | merdiven örneği | Örnek 12 ★★★ — `0.1 + 0.2` ve `%.20f` | **Ders notu:** §4.12 Örnek 12 (kesit)<br>**Sunum:** slayt 28 (kesit 10–20)<br>**Web:** Örnek merdiveni: 12 derlenebilir örnek (#h03-merdiven) | sıfır uyarı | `ciktilar/H03_12_kayan_nokta.txt` |
| `H03_13_scanf_donus.c` | ek örnek (kavram) | Ek örnek 13 — `scanf`'in dönüş değeri (okunan öge sayısı, EOF) | **Sunum:** slayt 36<br>**Web:** scanf ile klavyeden okuma (#h03-scanf) › scanf ne döndürür?<br>_Not:_ web quiz 5'in dayanağı | sıfır uyarı | `ciktilar/H03_13_scanf_donus.txt` |
| `H03_14_ayni_bitler.c` | ek örnek (kavram) | Ek örnek 14 — aynı bit örüntüsü, farklı tip, farklı yorum | **Sunum:** slayt 24<br>**Web:** Kaputun altında: tamsayılar bitlerde (#h03-tamsayi) › Aynı bitler, farklı yorum | sıfır uyarı | `ciktilar/H03_14_ayni_bitler.txt` |
| `H03_15_karakter_tampon.c` | ek örnek (kavram) | Ek örnek 15 — tamponda kalan `'\n'` ve `" %c"` çözümü (Hata Avcısı 5) | **Ders notu:** §3.10 › Giriş tamponu ve karakter okuma tuzağı (kesit)<br>**Web:** scanf ile klavyeden okuma (#h03-scanf) › Giriş tamponu ve " %c" çözümü<br>_Not:_ ders notu §5 tablosunda HA5; web quiz 10'un dayanağı | sıfır uyarı | `ciktilar/H03_15_karakter_tampon.txt` |
| `H03_16_patriot_hesabi.c` | ek örnek (kavram) | Ek örnek 16 (Merak) — Patriot saatindeki birikimli hata | **Web:** Sonlu bitlerle sonsuz sayılar (#h03-buyuk-soru)<br>_Not:_ ders notu §6.2 | sıfır uyarı | `ciktilar/H03_16_patriot_hesabi.txt` |
| `H03_17_tasma_varsayimi.c` | ek örnek (kavram) | Ek örnek 17 (Merak) — derleyici işaretli taşmanın olmadığını varsayar | **Sunum:** slayt 49<br>**Web:** AP-2 köprüsü ve Merak Kutusu (#h03-ap2) | sıfır uyarı | `ciktilar/H03_17_tasma_varsayimi.txt` |
| `H03_K01_bildirim_atama.c` | kavram | Bildirim, atama, ilk değer atama ve `yas = yas + 1;` (slayttaki tek satırlar) | **Sunum:** slayt 13 (18. satır), 14 (16, 17, 18 ve 23. satırlar; panellerde dosya adı ve satır no) | sıfır uyarı | `ciktilar/H03_K01_bildirim_atama.txt` |
| `H03_K02_bayt_sirasi.c` | kavram | `int sayi = 0x12345678;` — küçük-uçlu bayt sırası (gdb dökümü: `78 56 34 12`) | **Sunum:** slayt 23 (14. satır; panelde dosya adı ve satır no) | sıfır uyarı | `ciktilar/H03_K02_bayt_sirasi.txt`<br>`ciktilar/H03_K02_bayt_sirasi_gdb.txt` |
| `hata_avcisi/H03_K03_const_atama.c` | kavram · hata gösterimi | `const` değişkene atama: `assignment of read-only variable` (KASITLI HATALI) | **Sunum:** slayt 31 (12–18. satırlar ve gerçek GCC iletisi)<br>**Web:** char, ASCII ve sabitler (#h03-karakter) › Sabitler (gerçek ileti)<br>_Not:_ ders notu §4.4 Örnek 4 “Değiştir (a)” metninde | kasıtlı hata — derlenmez (derleyici hatası) | `hata_avcisi/ciktilar/H03_K03_const_atama.txt` |
| `hata_avcisi/H03_HA1_scanf_ampersand.c` | hata avcısı | HA1 — `scanf`'te `&` yok: `-Wformat` uyarısı + Segmentation fault (KASITLI HATALI) | **Ders notu:** §5 HA1 (kesit)<br>**Sunum:** slayt 45<br>**Web:** Hata Avcısı (#h03-hata-avcisi) › 1 · scanf’te & unutmak | kasıtlı hata — uyarı verir, program oluşur | `hata_avcisi/ciktilar/H03_HA1_scanf_ampersand.txt` |
| `hata_avcisi/H03_HA1_scanf_ampersand_duzeltilmis.c` | hata avcısı (düzeltilmiş) | HA1'in düzeltilmiş sürümü | **Sunum:** slayt 45<br>**Web:** Hata Avcısı (#h03-hata-avcisi) › 1 · scanf’te & unutmak | sıfır uyarı | `hata_avcisi/ciktilar/H03_HA1_scanf_ampersand_duzeltilmis.txt` |
| `hata_avcisi/H03_HA2_bicim_uyumsuzlugu.c` | hata avcısı | HA2 — biçim belirteci–tip uyuşmazlığı: iki `-Wformat` uyarısı (KASITLI HATALI) | **Sunum:** slayt 46<br>**Web:** Hata Avcısı (#h03-hata-avcisi) › 2 · Belirteç–tip uyuşmazlığı | kasıtlı hata — uyarı verir, program oluşur | `hata_avcisi/ciktilar/H03_HA2_bicim_uyumsuzlugu.txt` |
| `hata_avcisi/H03_HA2_bicim_uyumsuzlugu_duzeltilmis.c` | hata avcısı (düzeltilmiş) | HA2'nin düzeltilmiş sürümü | **Web:** Hata Avcısı (#h03-hata-avcisi) › 2 · Belirteç–tip uyuşmazlığı | sıfır uyarı | `hata_avcisi/ciktilar/H03_HA2_bicim_uyumsuzlugu_duzeltilmis.txt` |
| `hata_avcisi/H03_HA3_ilk_deger_yok.c` | hata avcısı | HA3 — ilk değeri olmayan değişken: `-Wuninitialized` uyarısı, çöp değer (KASITLI HATALI) | **Sunum:** slayt 15<br>**Web:** Değişken: ad, tip, değer ve adres (#h03-degisken) › Bildirim, ilk değer atama ve atama<br>_Not:_ ders notu §3.3 ve §5 metninde çıktısıyla anılır | kasıtlı hata — uyarı verir, program oluşur | `hata_avcisi/ciktilar/H03_HA3_ilk_deger_yok.txt` |
| `hata_avcisi/H03_HA3_ilk_deger_yok_duzeltilmis.c` | hata avcısı (düzeltilmiş) | HA3'ün düzeltilmiş sürümü (`int toplam = 0;`) | _Not:_ kod bloğu olarak gösterilmez; düzeltme ders notu §5 tablosunda (`int toplam = 0;`) | sıfır uyarı | `hata_avcisi/ciktilar/H03_HA3_ilk_deger_yok_duzeltilmis.txt` |
| `hata_avcisi/H03_HA4_bolme_ve_esitlik.c` | hata avcısı | HA4 — tamsayı bölmesi ve kayan noktada `==`: uyarı YOK, mantık hatası (KASITLI HATALI) | **Web:** Hata Avcısı (#h03-hata-avcisi) › 4 · Tamsayı bölmesi ve == ile kayan nokta<br>_Not:_ ders notu §5 metninde çıktısıyla anılır | sıfır uyarı — kasıtlı **mantık** hatası (derleyici yakalamaz) | `hata_avcisi/ciktilar/H03_HA4_bolme_ve_esitlik.txt` |
| `hata_avcisi/H03_HA4_bolme_ve_esitlik_duzeltilmis.c` | hata avcısı (düzeltilmiş) | HA4'ün düzeltilmiş sürümü (`/ 2.0`, farkın mutlak değeri < ε) | **Web:** Hata Avcısı (#h03-hata-avcisi) › 4 · Tamsayı bölmesi ve == ile kayan nokta | sıfır uyarı | `hata_avcisi/ciktilar/H03_HA4_bolme_ve_esitlik_duzeltilmis.txt` |
| `alistirmalar/H03_A01_cikti_tahmini.c` | alıştırma | Alıştırma 3.1 ★★ Çıktı tahmini — tamsayı bölmesi, alan genişliği, `unsigned char` sarması | **Ders notu:** §8.2 Alıştırma 3.1 (kesit)<br>**Web:** Alıştırmalar ve atölye (#h03-alistirmalar), 4. madde | sıfır uyarı | `alistirmalar/ciktilar/H03_A01_cikti_tahmini.txt` |
| `alistirmalar/H03_A02_hata_bul.c` | alıştırma | Alıştırma 3.2 ★★ Hata bul — `&` yok, `/ 2` + `%d`, tamponda `'\n'` (KASITLI HATALI) | **Ders notu:** §8.2 Alıştırma 3.2 (kesit)<br>**Web:** Alıştırmalar ve atölye (#h03-alistirmalar), 5. madde | kasıtlı hata — uyarı verir, program oluşur | `alistirmalar/ciktilar/H03_A02_hata_bul.txt` |
| `alistirmalar/H03_A03_parsons.c` | alıştırma | Alıştırma 3.3 ★★ Parsons — karışık satırlar + bir çeldirici (TAMAMLANACAK) | **Ders notu:** §8.2 Alıştırma 3.3 (kesit)<br>**Web:** Alıştırmalar ve atölye (#h03-alistirmalar), 6. madde | tamamlanacak — bu hâliyle derlenmez | `alistirmalar/ciktilar/H03_A03_parsons.txt` |
| `alistirmalar/H03_A04_belirtec_tamamla.c` | alıştırma | Alıştırma 3.4 ★★ Kod tamamla — `___` yerine `%lld`, `%u`, `%c`, `%.1f%%`, `%x` (TAMAMLANACAK) | **Ders notu:** §8.2 Alıştırma 3.4 (kesit)<br>**Web:** Alıştırmalar ve atölye (#h03-alistirmalar), 7. madde | tamamlanacak — boşluklu hâli uyarı verir, istenen çıktıyı vermez | `alistirmalar/ciktilar/H03_A04_belirtec_tamamla.txt` |
| `quiz/H03_Q01_tamsayi_bolme.c` | quiz | Web quiz 1 — `double y = x / 4;` → `2.00` | **Web:** Kendini sına (#h03-quiz), 1. soru<br>_Not:_ aynı parça sunumun çıkış biletinde (1. soru) metin içinde | sıfır uyarı | `quiz/ciktilar/H03_Q01_tamsayi_bolme.txt` |

Kısaltmalar: *§* ders notu bölümü; *(tam)* dosyanın tamamı, *(kesit)* dosyadan ardışık satırlar gösterilir; web bağlantıları bölüm kimliğidir (`#…`).

/* H03_17_tasma_varsayimi.c — AP-1 Hafta 3, Ek örnek 17 (★★★)
 * Amaç   : Ek örnek (Merak): derleyici işaretli taşmanın olmadığını varsayar
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_17_tasma_varsayimi.c -o varsayim
 * Çıktı  : x + adim > x mi? = 1 (1 evet, 0 hayır)  (girdi: 1) */
#include <stdio.h>
#include <limits.h>

int main(void)
{
    int x = INT_MAX;
    int adim = 0;

    printf("INT_MAX'a kaç ekleyelim? ");
    scanf("%d", &adim);

    int sonuc = x + adim;                /* taşma: tanımsız davranış */
    printf("x + adim         = %d\n", sonuc);
    printf("x + adim > x mi? = %d (1 evet, 0 hayır)\n", x + adim > x);
    return 0;
}

/* H03_13_scanf_donus.c — AP-1 Hafta 3, Ek örnek 13 (★★)
 * Amaç   : Ek örnek: scanf'in dönüş değeri (okunan öge sayısı, EOF)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_13_scanf_donus.c -o scanf_donus
 * Çıktı  : scanf'in dönüş değeri: 2  (girdi: 12 30) */
#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;

    printf("İki tamsayı girin: ");
    int okunan = scanf("%d %d", &a, &b);   /* başarıyla okunan öge sayısı */

    printf("scanf'in dönüş değeri: %d\n", okunan);
    printf("a = %d, b = %d\n", a, b);
    return 0;
}

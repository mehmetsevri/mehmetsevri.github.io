/* H03_A01_cikti_tahmini.c — AP-1 Hafta 3, Alıştırma 3.1 (A · Çıktı tahmini, ★★)
 * Materyal: ders notu 8.2 Alıştırma 3.1; web “Alıştırmalar ve atölye” 4. madde
 * Görev  : Çıktıyı tahmin edin; (c) C'de tanımlı mı? Sonra derleyip çalıştırın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_A01_cikti_tahmini.c -o a01
 * Çıktı  : ciktilar/H03_A01_cikti_tahmini.txt (tahmin etmeden açmayın) */

#include <stdio.h>

int main(void)
{
    /* (a) */ int a = 7; int b = 2;
    printf("%d %d\n", a / b, b / a);
    printf("%.2f\n", a / 2.0);
    /* (b) */ printf("[%6.2f][%-4d][%03d]\n", 2.5, 7, 7);
    /* (c) */ unsigned char u = 250;
    u = u + 10;
    printf("%d\n", u);
    return 0;
}

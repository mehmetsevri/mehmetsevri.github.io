/* H03_A02_hata_bul.c — AP-1 Hafta 3, Alıştırma 3.2 (B · Hata bul, ★/★★)
 * BU DOSYA KASITLI HATA İÇERİR — iki -Wformat uyarısı verir, çalışınca çöker.
 * Materyal: ders notu 8.2 Alıştırma 3.2; web “Alıştırmalar ve atölye” 5. madde
 * Görev  : (a) Program derlenir ama çalışınca çöker. (b) Ortalama 72.5
 *          olmalıyken anlamsız bir sayı görünüyor; iki hatayı bulun.
 *          (c) Yaş girilince program cinsiyet harfini sormadan geçiyor;
 *          tek karakterlik düzeltmeyi yapın. İpucu: önce (a)'yı düzeltin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_A02_hata_bul.c -o a02
 * Gerçek derleyici iletisi ve çalışma: ciktilar/H03_A02_hata_bul.txt */

#include <stdio.h>

int main(void)
{
    /* (a) */ int yas = 0;
    scanf("%d", yas);
    /* (b) */ int vize = 70; int final = 75;
    double ortalama = (vize + final) / 2;
    printf("Ortalama: %d\n", ortalama);
    /* (c) */ scanf("%d", &yas);
    char cinsiyet = '?';
    scanf("%c", &cinsiyet);
    printf("yas = %d, cinsiyet = %c\n", yas, cinsiyet);
    return 0;
}

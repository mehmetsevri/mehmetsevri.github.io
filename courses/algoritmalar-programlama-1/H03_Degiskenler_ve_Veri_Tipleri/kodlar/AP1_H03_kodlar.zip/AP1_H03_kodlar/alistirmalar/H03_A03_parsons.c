/* H03_A03_parsons.c — AP-1 Hafta 3, Alıştırma 3.3 (C · Parsons, ★★)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ — satırlar karışık sırayla verilmiştir.
 * Materyal: ders notu 8.2 Alıştırma 3.3; web “Alıştırmalar ve atölye” 6. madde
 * Görev  : main gövdesindeki satırları, iki tamsayı okuyup ortalamalarını
 *          2 ondalık basamakla yazan bir gövde oluşturacak biçimde sıralayın.
 *          Bir satır ÇELDİRİCİDİR; onu silin. Sonra sıfır uyarıyla derleyin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H03_A03_parsons.c -o a03
 * Karışık hâlin gerçek derleyici iletisi: ciktilar/H03_A03_parsons.txt */

#include <stdio.h>

int main(void)
{
    printf("Ortalama: %.2f\n", ortalama);
    int a = 0;
    double ortalama = (a + b) / 2;
    scanf("%d %d", &a, &b);
    int b = 0;
    double ortalama = (a + b) / 2.0;
    printf("İki tamsayı: ");
    return 0;
}

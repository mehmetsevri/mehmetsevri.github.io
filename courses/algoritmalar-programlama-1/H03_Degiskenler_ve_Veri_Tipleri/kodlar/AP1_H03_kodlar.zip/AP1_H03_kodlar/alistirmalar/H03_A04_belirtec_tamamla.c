/* H03_A04_belirtec_tamamla.c — AP-1 Hafta 3, Alıştırma 3.4 (D · Kod tamamla)
 * TAMAMLANACAK: boşluklar (___) doğru biçim belirteçleriyle doldurulacak.
 * Materyal: ders notu 8.2 Alıştırma 3.4; web “Alıştırmalar ve atölye” 7. madde
 * Görev  : Çıktı sırasıyla 8100000000, 4000000000, A, 45.7% ve ff olmalıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_A04_belirtec_tamamla.c -o a04
 * Boşluklu hâli uyarı verir: ciktilar/H03_A04_belirtec_tamamla.txt */

#include <stdio.h>

int main(void)
{
    long long nufus = 8100000000LL;
    unsigned int buyuk = 4000000000u;
    double oran = 45.678;
    printf("Nüfus: ___\n", nufus);
    printf("Büyük: ___\n", buyuk);
    printf("Harf : ___\n", 'A');
    printf("Oran : ______\n", oran);
    printf("Onaltılı: ___\n", 255);
    return 0;
}

/* H03_12_kayan_nokta.c — AP-1 Hafta 3, Örnek 12 (★★★)
 * Amaç   : 0.1 + 0.2 deneyi: %.20f ile kayan nokta hassasiyeti
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_12_kayan_nokta.c -o kayan
 * Çıktı  : toplam (%.20f)   : 0.30000000000000004441 */
#include <stdio.h>

int main(void)
{
    double a = 0.1;
    double b = 0.2;
    double toplam = a + b;

    printf("toplam (%%f)      : %f\n", toplam);
    printf("toplam (%%.20f)   : %.20f\n", toplam);
    printf("0.3 (%%.20f)      : %.20f\n", 0.3);
    printf("0.1 (%%.20f)      : %.20f\n", a);
    printf("toplam - 0.3     : %e\n", toplam - 0.3);
    printf("0.3'e eşit mi?   : %d (1 evet, 0 hayır)\n", toplam == 0.3);
    printf("0.1 (%%a)         : %a\n", a);

    float f = 0.1f;
    printf("float 0.1 (%%.20f): %.20f\n", f);
    return 0;
}

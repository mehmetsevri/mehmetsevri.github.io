/* H03_09_adresler.c — AP-1 Hafta 3, Örnek 9 (★★)
 * Amaç   : Değişkenlerin adresleri: & ve %p (her çalıştırmada değişir)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_09_adresler.c -o adresler
 * Çıktı  : x: değer   42   adres 0x7ffce59f5608   boyut 4 */
#include <stdio.h>

int main(void)
{
    int x = 42;
    int y = 7;
    double d = 3.5;
    char c = 'Z';

    printf("x: değer %4d   adres %p   boyut %zu\n", x, (void *)&x, sizeof(x));
    printf("y: değer %4d   adres %p   boyut %zu\n", y, (void *)&y, sizeof(y));
    printf("d: değer %4.1f   adres %p   boyut %zu\n", d, (void *)&d, sizeof(d));
    printf("c: değer %4c   adres %p   boyut %zu\n", c, (void *)&c, sizeof(c));
    return 0;
}

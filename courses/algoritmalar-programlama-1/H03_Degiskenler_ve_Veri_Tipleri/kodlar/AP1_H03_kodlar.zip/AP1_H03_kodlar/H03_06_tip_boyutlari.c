/* H03_06_tip_boyutlari.c — AP-1 Hafta 3, Örnek 6 (★★)
 * Amaç   : Veri tipi boyutları ve aralıkları: sizeof, limits.h, float.h
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_06_tip_boyutlari.c -o tipler
 * Çıktı  : unsigned int     4                     0            4294967295 */
#include <stdio.h>
#include <limits.h>
#include <float.h>

int main(void)
{
    printf("Tip           Bayt        En küçük değer        En büyük değer\n");
    printf("char          %4zu  %20d  %20d\n",
           sizeof(char), CHAR_MIN, CHAR_MAX);
    printf("short         %4zu  %20d  %20d\n",
           sizeof(short), SHRT_MIN, SHRT_MAX);
    printf("int           %4zu  %20d  %20d\n",
           sizeof(int), INT_MIN, INT_MAX);
    printf("unsigned int  %4zu  %20u  %20u\n",
           sizeof(unsigned int), 0u, UINT_MAX);
    printf("long          %4zu  %20ld  %20ld\n",
           sizeof(long), LONG_MIN, LONG_MAX);
    printf("long long     %4zu  %20lld  %20lld\n",
           sizeof(long long), LLONG_MIN, LLONG_MAX);

    printf("\nfloat  : %zu bayt, en büyük %e, %d anlamlı basamak\n",
           sizeof(float), FLT_MAX, FLT_DIG);
    printf("double : %zu bayt, en büyük %e, %d anlamlı basamak\n",
           sizeof(double), DBL_MAX, DBL_DIG);
    printf("DBL_EPSILON (1.0 ile sonraki double farkı): %e\n",
           DBL_EPSILON);
    printf("Bir bayttaki bit sayısı (CHAR_BIT): %d\n", CHAR_BIT);
    return 0;
}

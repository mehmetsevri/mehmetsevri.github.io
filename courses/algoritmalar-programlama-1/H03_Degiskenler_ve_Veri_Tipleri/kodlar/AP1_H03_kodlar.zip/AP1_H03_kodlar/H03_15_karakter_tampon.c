/* H03_15_karakter_tampon.c — AP-1 Hafta 3, Ek örnek 15 (★★)
 * Amaç   : Ek örnek: tamponda kalan '\n' ve " %c" çözümü
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_15_karakter_tampon.c -o tampon
 * Çıktı  : harf2 = 'B'  (girdi: 19, B) */
#include <stdio.h>

int main(void)
{
    int yas = 0;
    char harf1 = '?';
    char harf2 = '?';

    printf("Yaşınız: ");
    scanf("%d", &yas);             /* 19 okunur, '\n' tamponda kalır */
    printf("Bir harf (1. deneme): ");
    scanf("%c", &harf1);           /* bekleyen '\n' hemen okunur! */
    printf("Bir harf (2. deneme): ");
    scanf(" %c", &harf2);          /* boşluk: beyaz karakterleri atla */

    printf("\nyas = %d\n", yas);
    printf("harf1 kodu = %d (10, '\\n' karakterinin kodudur)\n", harf1);
    printf("harf2 = '%c'\n", harf2);
    return 0;
}

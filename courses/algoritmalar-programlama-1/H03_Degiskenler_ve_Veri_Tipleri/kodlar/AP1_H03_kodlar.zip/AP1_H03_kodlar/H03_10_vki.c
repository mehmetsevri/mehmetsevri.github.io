/* H03_10_vki.c — AP-1 Hafta 3, Örnek 10 (★★)
 * Amaç   : Vücut kitle indeksi: giriş, işlem ve biçimli çıktı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_10_vki.c -o vki
 * Çıktı  : Boy              :    1.75 m  (girdi: 70, 175) */
#include <stdio.h>

int main(void)
{
    double kilo = 0.0;
    double boy_cm = 0.0;

    printf("Kilonuz (kg): ");
    scanf("%lf", &kilo);
    printf("Boyunuz (cm): ");
    scanf("%lf", &boy_cm);

    double boy_m = boy_cm / 100.0;          /* cm → m */
    double vki = kilo / (boy_m * boy_m);    /* VKİ = kg / m² */

    printf("\n=========== VKİ RAPORU ===========\n");
    printf("Kilo             : %7.1f kg\n", kilo);
    printf("Boy              : %7.2f m\n", boy_m);
    printf("Vücut kitle ind. : %7.2f kg/m²\n", vki);
    printf("----------------------------------\n");
    printf("Başvuru (DSÖ, yetişkin):\n");
    printf("  18,5 altı zayıf  | 18,5–24,9 normal\n");
    printf("  25–29,9 fazla kilolu | 30 ve üstü obez\n");
    return 0;
}

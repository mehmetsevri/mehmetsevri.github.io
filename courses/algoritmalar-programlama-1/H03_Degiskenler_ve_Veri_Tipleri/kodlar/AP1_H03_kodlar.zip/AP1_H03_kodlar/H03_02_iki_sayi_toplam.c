/* H03_02_iki_sayi_toplam.c — AP-1 Hafta 3, Örnek 2 (★)
 * Amaç   : Klavyeden iki tamsayı okuma: scanf ve & (adres)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_02_iki_sayi_toplam.c -o toplam
 * Çıktı  : 12 + 30 = 42  (girdi: 12, 30) */
#include <stdio.h>

int main(void)
{
    int a;
    int b;

    printf("Birinci sayı: ");
    scanf("%d", &a);           /* &a: "a'nın adresine yaz" */
    printf("İkinci sayı : ");
    scanf("%d", &b);

    int toplam = a + b;
    printf("%d + %d = %d\n", a, b, toplam);
    return 0;
}

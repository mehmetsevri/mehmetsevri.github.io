/* H03_01_degisken_yazdir.c — AP-1 Hafta 3, Örnek 1 (★)
 * Amaç   : Bildirim, ilk değer atama, atama ve printf %d
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_01_degisken_yazdir.c -o degisken
 * Çıktı  : Bir yıl sonra yaş: 20 */
#include <stdio.h>

int main(void)
{
    int yas = 19;              /* bildirim + ilk değer atama */
    int ogrenci_sayisi;        /* yalnızca bildirim */

    ogrenci_sayisi = 85;       /* atama: kutuya değer yazılır */
    printf("Yaş: %d\n", yas);
    printf("Sınıftaki öğrenci sayısı: %d\n", ogrenci_sayisi);

    yas = yas + 1;             /* sağ taraf okunur, sonuç sola yazılır */
    printf("Bir yıl sonra yaş: %d\n", yas);
    return 0;
}

/* H03_K02_bayt_sirasi.c — AP-1 Hafta 3, Kavram programı (Kaputun altında)
 * Amaç   : 4 baytlık bir int'in bellekteki bayt sırası (x86-64: küçük-uçlu)
 * Materyalde: sunum slayt 23 (bayt sırası): int sayi = 0x12345678;
 * Not    : Baytlara C içinden erişmek işaretçi gerektirir (H12); bu hafta gdb:
 *          bellekte 78 56 34 12 (ciktilar/H03_K02_bayt_sirasi_gdb.txt).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g
 *          H03_K02_bayt_sirasi.c -o bayt_sirasi
 * Çıktı  : ciktilar/H03_K02_bayt_sirasi.txt */

#include <stdio.h>

int main(void)
{
    int sayi = 0x12345678;

    printf("sayi (onluk)    : %d\n", sayi);
    printf("sayi (onaltılı) : 0x%08X\n", sayi);
    printf("sizeof sayi     : %zu bayt\n", sizeof sayi);
    return 0;
}

/* H06_14_collatz.c — Hafta 6 · Örnek 14 (★★★): Collatz dizisi
 * Amaç   : n çiftse n/2, tekse 3n+1; n = 1 olunca dur. Adım sayısı ve
 *          dizinin tepe değeri. Bu döngünün HER başlangıç değeri için
 *          sona erdiği kanıtlanmamıştır (Collatz sanısı; Merak Kutusu)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_14_collatz.c -o collatz
 * Örnek  : girdi "27" -> 111 adımda 1'e ulaşıldı; en büyük değer: 9232
 */
#include <stdio.h>
#include <limits.h>

int main(void)
{
    long long n;
    printf("Başlangıç değeri (n >= 1): ");
    if (scanf("%lld", &n) != 1 || n < 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    long long tepe = n;
    int adim = 0;
    printf("%lld", n);
    while (n != 1) {                    /* biteceği kanıtlanmış değil! */
        if (n % 2 == 0) {
            n = n / 2;
        } else if (n <= (LLONG_MAX - 1) / 3) {
            n = 3 * n + 1;
        } else {                        /* 3n + 1 long long'a sığmaz */
            printf("\nTaşma riski: durduruldu.\n");
            return 1;
        }
        adim++;
        if (n > tepe) {
            tepe = n;
        }
        if (adim % 10 == 0) {           /* her 10 değerde bir alt satır */
            printf("\n");
        }
        printf(" %lld", n);
    }
    printf("\n%d adımda 1'e ulaşıldı; en büyük değer: %lld\n", adim, tepe);
    return 0;
}

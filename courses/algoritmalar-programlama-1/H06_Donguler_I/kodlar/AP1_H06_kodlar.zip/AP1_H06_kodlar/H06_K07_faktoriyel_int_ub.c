/* H06_K07_faktoriyel_int_ub.c — Hafta 6 · Kavram programı: int taşması
 * BU DOSYA KASITLI olarak TANIMSIZ DAVRANIŞ içerir: 13! = 6227020800
 * değeri int'e (en çok 2147483647) sığmaz; işaretli tamsayı taşması C'de
 * tanımsızdır. Derleyici uyarı vermez (değerler çalışma anında oluşur);
 * sorunu -fsanitize=undefined ile çalışma anında yakalarız.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -fsanitize=undefined \
 *              H06_K07_faktoriyel_int_ub.c -o faktoriyel_int_ub
 */
#include <stdio.h>

int main(void)
{
    int carpim = 1;
    for (int n = 1; n <= 13; n++) {
        carpim *= n;                    /* n = 13'te taşar: tanımsız davranış */
        printf("%2d! = %d\n", n, carpim);
    }
    return 0;
}

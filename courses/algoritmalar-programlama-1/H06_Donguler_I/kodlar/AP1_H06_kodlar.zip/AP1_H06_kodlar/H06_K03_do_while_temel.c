/* H06_K03_do_while_temel.c — Hafta 6 · Kavram programı: do-while
 * Amaç   : koşul baştan yanlışken while gövdesi hiç çalışmaz, do-while
 *          gövdesi ise bir kez çalışır (koşul gövdeden SONRA sınanır)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K03_do_while_temel.c -o do_while_temel
 */
#include <stdio.h>

int main(void)
{
    int i = 10;
    while (i < 5) {
        printf("while gövdesi: i = %d\n", i);
        i++;
    }

    int j = 10;
    do {
        printf("do-while gövdesi: j = %d\n", j);
        j++;
    } while (j < 5);                    /* sondaki ; zorunlu */

    printf("Son değerler: i = %d, j = %d\n", i, j);
    return 0;
}

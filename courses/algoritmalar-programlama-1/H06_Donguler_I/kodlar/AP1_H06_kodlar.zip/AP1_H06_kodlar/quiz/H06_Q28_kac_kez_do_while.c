/* H06_Q28_kac_kez_do_while.c — Hafta 6 · Kaç kez? (do-while)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q28_kac_kez_do_while.c -o q28
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    int i = 10;
    do {
        i++;
        tur++;
    } while (i < 5);
    printf("%d\n", tur);
    return 0;
}

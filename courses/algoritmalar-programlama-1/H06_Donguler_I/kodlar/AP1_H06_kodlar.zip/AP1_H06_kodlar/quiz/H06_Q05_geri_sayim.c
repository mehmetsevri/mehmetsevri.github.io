/* H06_Q05_geri_sayim.c — Hafta 6 · Web quiz: 3'er geri sayım
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q05_geri_sayim.c -o q05
 */
#include <stdio.h>

int main(void)
{
    for (int i = 10; i > 0; i -= 3) {
        printf("%d ", i);
    }
    printf("\n");
    return 0;
}

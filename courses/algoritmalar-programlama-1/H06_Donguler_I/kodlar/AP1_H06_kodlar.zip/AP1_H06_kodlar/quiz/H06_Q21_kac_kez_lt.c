/* H06_Q21_kac_kez_lt.c — Hafta 6 · Kaç kez? (< ile 0'dan 10'a)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q21_kac_kez_lt.c -o q21
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    for (int i = 0; i < 10; i++) {
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

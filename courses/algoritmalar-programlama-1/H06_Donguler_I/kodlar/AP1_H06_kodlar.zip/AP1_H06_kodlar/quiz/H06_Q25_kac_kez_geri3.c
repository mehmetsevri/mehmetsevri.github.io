/* H06_Q25_kac_kez_geri3.c — Hafta 6 · Kaç kez? (3'er geri sayım)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q25_kac_kez_geri3.c -o q25
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    for (int i = 10; i >= 0; i -= 3) {
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

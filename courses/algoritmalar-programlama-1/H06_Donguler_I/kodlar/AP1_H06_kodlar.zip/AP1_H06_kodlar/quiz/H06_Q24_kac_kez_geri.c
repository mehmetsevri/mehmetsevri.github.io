/* H06_Q24_kac_kez_geri.c — Hafta 6 · Kaç kez? (geri sayım)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q24_kac_kez_geri.c -o q24
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    for (int i = 10; i > 0; i--) {
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

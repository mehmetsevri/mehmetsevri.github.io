/* H06_Q02_de_morgan.c — Hafta 6 · Geçen haftadan S2 (H5: bileşik koşul)
 * Soru   : Çıktı nedir? Koşulu ! kullanmadan (De Morgan ile) yazın.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q02_de_morgan.c -o q02
 */
#include <stdio.h>

int main(void)
{
    int puan = 105;
    if (!(puan >= 0 && puan <= 100)) {
        printf("Geçersiz puan: %d\n", puan);
    } else {
        printf("Geçerli puan: %d\n", puan);
    }
    return 0;
}

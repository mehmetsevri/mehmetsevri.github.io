/* H06_Q03_tek_sans.c — Hafta 6 · Geçen haftadan S3 (H5: girdi doğrulama)
 * Soru   : Kullanıcı 150 girerse ne olur? Kullanıcıya yeniden sorabilmek
 *          için hangi yapıya ihtiyaç var?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q03_tek_sans.c -o q03
 */
#include <stdio.h>

int main(void)
{
    int puan;
    printf("Puan (0-100): ");
    if (scanf("%d", &puan) != 1 || puan < 0 || puan > 100) {
        printf("Geçersiz puan; program sonlanıyor.\n");
        return 1;
    }
    printf("Puan kabul edildi: %d\n", puan);
    return 0;
}

/* H06_Q30_kac_kez_break.c — Hafta 6 · Kaç kez? (break)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q30_kac_kez_break.c -o q30
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    for (int i = 0; i < 10; i++) {
        tur++;
        if (i == 4) {
            break;
        }
    }
    printf("%d\n", tur);
    return 0;
}

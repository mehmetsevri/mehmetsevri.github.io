/* H06_Q23_kac_kez_adim2.c — Hafta 6 · Kaç kez? (adım 2)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q23_kac_kez_adim2.c -o q23
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    for (int i = 1; i < 10; i += 2) {
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

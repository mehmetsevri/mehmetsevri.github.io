/* H06_Q06_break_continue.c — Hafta 6 · Web quiz: break ve continue
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q06_break_continue.c -o q06
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 6; i++) {
        if (i == 2) {
            continue;
        }
        if (i == 5) {
            break;
        }
        printf("%d", i);
    }
    printf("\n");
    return 0;
}

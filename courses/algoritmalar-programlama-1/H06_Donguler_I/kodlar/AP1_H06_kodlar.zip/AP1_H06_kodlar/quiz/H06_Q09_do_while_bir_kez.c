/* H06_Q09_do_while_bir_kez.c — Hafta 6 · Web quiz: do-while en az bir kez
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q09_do_while_bir_kez.c -o q09
 */
#include <stdio.h>

int main(void)
{
    int x = 50;
    do {
        printf("x = %d\n", x);
        x *= 2;
    } while (x < 10);
    printf("son x = %d\n", x);
    return 0;
}

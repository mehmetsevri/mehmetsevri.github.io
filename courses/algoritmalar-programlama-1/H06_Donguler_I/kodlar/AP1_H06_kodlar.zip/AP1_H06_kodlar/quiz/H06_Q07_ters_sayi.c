/* H06_Q07_ters_sayi.c — Hafta 6 · Web quiz: basamaklardan sayı inşası
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q07_ters_sayi.c -o q07
 */
#include <stdio.h>

int main(void)
{
    int n = 507, t = 0;
    while (n > 0) {
        t = t * 10 + n % 10;
        n /= 10;
    }
    printf("%d\n", t);
    return 0;
}

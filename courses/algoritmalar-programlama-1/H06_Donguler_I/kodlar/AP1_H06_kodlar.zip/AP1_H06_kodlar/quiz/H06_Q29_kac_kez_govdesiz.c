/* H06_Q29_kac_kez_govdesiz.c — Hafta 6 · Kaç kez? (for ve süslü parantez)
 * BU DOSYA KASITLI HATA İÇERİR (derleyici uyarısı: ciktilar/).
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q29_kac_kez_govdesiz.c -o q29
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    for (int i = 0; i < 5; i++);
    {
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

/* H06_Q01_switch_duser.c — Hafta 6 · Geçen haftadan S1 (H5: switch)
 * Soru   : Program ne yazdırır? (break'i olmayan case'lere dikkat)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q01_switch_duser.c -o q01
 */
#include <stdio.h>

int main(void)
{
    int secim = 2;
    switch (secim) {
    case 1:
        printf("Bir ");
        break;
    case 2:
        printf("İki ");
        /* fall through - break yok: aşağıya düşer */
    case 3:
        printf("Üç ");
        break;
    default:
        printf("Diğer ");
    }
    printf("\n");
    return 0;
}

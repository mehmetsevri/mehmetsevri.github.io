/* H06_Q31_kac_kez_basamak.c — Hafta 6 · Kaç kez? (basamak döngüsü)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q31_kac_kez_basamak.c -o q31
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    int n = 1000;
    while (n > 0) {
        n /= 10;
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

/* H06_Q04_while_cikis.c — Hafta 6 · Web quiz: while sonrası sayaç
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q04_while_cikis.c -o q04
 */
#include <stdio.h>

int main(void)
{
    int i = 0;
    while (i < 3) {
        printf("%d", i);
        i++;
    }
    printf(" %d\n", i);
    return 0;
}

/* H06_Q27_kac_kez_ikiye_kat.c — Hafta 6 · Kaç kez? (ikiye katlama)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q27_kac_kez_ikiye_kat.c -o q27
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    int i = 1;
    while (i <= 100) {
        i *= 2;
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

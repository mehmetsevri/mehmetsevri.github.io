/* H06_Q32_kac_kez_kayan.c — Hafta 6 · Kaç kez? (kayan noktalı koşul)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q32_kac_kez_kayan.c -o q32
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    double x = 0.0;
    while (x < 1.0) {
        x += 0.1;
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

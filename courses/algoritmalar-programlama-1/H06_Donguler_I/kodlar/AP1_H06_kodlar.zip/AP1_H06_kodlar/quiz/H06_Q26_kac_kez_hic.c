/* H06_Q26_kac_kez_hic.c — Hafta 6 · Kaç kez? (for, başlangıç 5)
 * Yanıt  : yazdırılan sayı = tur++ satırının kaç kez çalıştığı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q26_kac_kez_hic.c -o q26
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;
    for (int i = 5; i < 5; i++) {
        tur++;
    }
    printf("%d\n", tur);
    return 0;
}

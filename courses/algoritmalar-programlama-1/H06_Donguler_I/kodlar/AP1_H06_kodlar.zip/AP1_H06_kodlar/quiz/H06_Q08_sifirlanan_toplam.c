/* H06_Q08_sifirlanan_toplam.c — Hafta 6 · Web quiz: toplam döngüsü
 * BU DOSYA KASITLI HATA İÇERİR.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_Q08_sifirlanan_toplam.c -o q08
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;
    for (int i = 1; i <= 4; i++) {
        toplam = 0;
        toplam += i;
    }
    printf("%d\n", toplam);
    return 0;
}

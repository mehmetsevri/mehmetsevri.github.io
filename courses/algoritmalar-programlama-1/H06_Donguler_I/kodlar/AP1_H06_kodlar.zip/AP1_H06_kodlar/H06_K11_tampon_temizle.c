/* H06_K11_tampon_temizle.c — Hafta 6 · Kavram programı: giriş tamponu
 * Amaç   : scanf("%d") sayı olmayan bir karakterle karşılaşınca 0 döndürür
 *          ve o karakterleri tamponda BIRAKIR; getchar döngüsü satırın
 *          kalanını okuyup atar (burada atılanları da gösteriyoruz)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K11_tampon_temizle.c -o tampon_temizle
 */
#include <stdio.h>

int main(void)
{
    int x = 0;
    printf("Bir sayı girin: ");
    int r = scanf("%d", &x);
    printf("scanf dönüşü: %d, x = %d\n", r, x);

    printf("Satırda kalanlar:");
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        printf(" '%c'", c);             /* atılan karakteri göster */
    }
    printf("  (temizlendi)\n");
    return 0;
}

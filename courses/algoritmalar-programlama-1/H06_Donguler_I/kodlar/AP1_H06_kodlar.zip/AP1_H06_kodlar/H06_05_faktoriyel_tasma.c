/* H06_05_faktoriyel_tasma.c — Hafta 6 · Örnek 5 (★★): faktöriyel ve taşma
 * Amaç   : çarpım biriktirici (başlangıç değeri 1); n! değerinin int ve
 *          unsigned long long sınırlarıyla karşılaştırılması; taşmayı
 *          çarpmadan ÖNCE sezmek
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_05_faktoriyel_tasma.c -o faktoriyel_tasma
 * Örnek  : -> 20  2432902008176640000    hayır
 */
#include <stdio.h>
#include <limits.h>

int main(void)
{
    unsigned long long carpim = 1;      /* çarpım biriktirici: 1 ile başlar */

    printf(" n  %-22s %s\n", "n! (unsigned long long)", "int'e sığar mı?");
    for (int n = 1; n <= 21; n++) {
        /* Taşma denetimi çarpmadan ÖNCE: carpim * n, ULLONG_MAX'ı aşar mı? */
        int tasacak = carpim > ULLONG_MAX / (unsigned long long)n;
        carpim *= n;                    /* işaretsiz: 2^64 modunda sarar */
        printf("%2d  %-22llu %s%s\n", n, carpim,
               carpim <= INT_MAX ? "evet" : "hayır",
               tasacak ? "   <- 64 bite sığmadı: sarmış değer!" : "");
    }
    return 0;
}

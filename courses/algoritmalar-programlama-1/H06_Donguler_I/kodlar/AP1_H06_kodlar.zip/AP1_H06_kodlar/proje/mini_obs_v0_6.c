/*
 * mini_obs_v0_6.c — Mini-OBS v0.6 (AP-1 Hafta 6)
 * Yenilik : N öğrenci için döngüyle not girişi; geçersiz girdi yeniden
 *           sorulur; her öğrenci için v0.5 biçiminde kısa rapor; döngü
 *           bitince sınıf özeti (sınıf ortalaması, en yüksek/en düşük
 *           ortalama, başarılı ve şartlı başarılı sayısı). Dizi yok: her
 *           öğrenci okunur, işlenir ve "unutulur"; yalnızca toplayıcı,
 *           sayaçlar ve en iyi adaylar saklanır (akış hâlinde istatistik).
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107), Madde 30: %40 vize + %60 final;
 *           final < 50 → FF; AA 90-100, BA 81-89, BB 73-80, CB 66-72,
 *           CC 60-65 başarılı; DC 50-59 şartlı (YANO ≥ 2,00 ise);
 *           DD 40-49, FD 30-39, FF 0-29 başarısız. Yuvarlama: (int)(ort + 0.5)
 * Kavramlar: for (sayaç kontrollü), do-while + scanf dönüş değeri + tampon
 *           temizleme (girdi doğrulama), toplayıcı, sayaç, en büyük/küçük
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g mini_obs_v0_6.c -o mini_obs
 */

#include <stdio.h>

int main(void)
{
    const double VIZE_AGIRLIK = 0.40;
    const double FINAL_AGIRLIK = 0.60;
    const int GECME_ORTALAMA = 60;       /* CC ve üzeri: başarılı */
    const int SARTLI_ORTALAMA = 50;      /* DC: şartlı başarılı */
    const int FINAL_BARAJI = 50;         /* yarıyıl sonu sınavında en az 50 */

    printf("==========================================\n");
    printf("  MİNİ-OBS v0.6 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");

    /* 1) Öğrenci sayısı: geçerli olana kadar yeniden sor */
    int n = 0, okunan, c;
    do {
        printf("Öğrenci sayısı   : ");
        okunan = scanf("%d", &n);
        if (okunan == EOF) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }
        if (okunan == 0) {                          /* sayı değil */
            while ((c = getchar()) != '\n' && c != EOF) {
                /* satırın kalanını at */
            }
            n = 0;
        }
        if (n < 1) {
            printf("  Geçersiz: en az 1 öğrenci olmalı.\n");
        }
    } while (n < 1);

    double toplam_ortalama = 0.0;                   /* toplayıcı */
    int basarili = 0, sartli = 0;                   /* sayaçlar */
    double en_yuksek = 0.0, en_dusuk = 0.0;         /* en iyi adaylar */
    long long en_yuksek_no = 0, en_dusuk_no = 0;

    for (int i = 1; i <= n; i++) {
        long long numara = 0;
        double vize = -1.0, final = -1.0;
        printf("\n------------ ÖĞRENCİ %d / %d ------------\n", i, n);

        /* 2) Numara: pozitif bir tamsayı olana kadar */
        do {
            printf("Öğrenci numarası : ");
            okunan = scanf("%lld", &numara);
            if (okunan == EOF) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            if (okunan == 0) {
                while ((c = getchar()) != '\n' && c != EOF) {
                    /* satırın kalanını at */
                }
                numara = 0;
            }
            if (numara <= 0) {
                printf("  Geçersiz: pozitif bir numara girin.\n");
            }
        } while (numara <= 0);

        /* 3) Vize: 0-100 aralığında bir sayı olana kadar */
        do {
            printf("Vize notu        : ");
            okunan = scanf("%lf", &vize);
            if (okunan == EOF) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            if (okunan == 0) {
                while ((c = getchar()) != '\n' && c != EOF) {
                    /* satırın kalanını at */
                }
                vize = -1.0;
            }
            if (vize < 0 || vize > 100) {
                printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
            }
        } while (vize < 0 || vize > 100);

        /* 4) Final: aynı doğrulama (H8'de bu tekrar fonksiyona dönüşecek) */
        do {
            printf("Final notu       : ");
            okunan = scanf("%lf", &final);
            if (okunan == EOF) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            if (okunan == 0) {
                while ((c = getchar()) != '\n' && c != EOF) {
                    /* satırın kalanını at */
                }
                final = -1.0;
            }
            if (final < 0 || final > 100) {
                printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
            }
        } while (final < 0 || final > 100);

        /* 5) Hesap (v0.4) ve rapor (v0.5 etiketleri) */
        double ortalama = VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
        int yuvarlanmis = (int)(ortalama + 0.5);
        printf("Öğrenci no  : %lld\n", numara);
        printf("Vize  (%%40) : %6.2f\n", vize);
        printf("Final (%%60) : %6.2f\n", final);
        printf("Ortalama    : %6.2f\n", ortalama);
        printf("Yuvarlanmış : %3d\n", yuvarlanmis);

        /* 6) Harf notu ve durum (v0.5, RTEÜ tablosu; ilk basamak baraj) */
        printf("Harf notu   : ");
        if (final < FINAL_BARAJI) {
            printf("FF\n");
        } else if (yuvarlanmis >= 90) {
            printf("AA\n");
        } else if (yuvarlanmis >= 81) {
            printf("BA\n");
        } else if (yuvarlanmis >= 73) {
            printf("BB\n");
        } else if (yuvarlanmis >= 66) {
            printf("CB\n");
        } else if (yuvarlanmis >= 60) {
            printf("CC\n");
        } else if (yuvarlanmis >= 50) {
            printf("DC\n");
        } else if (yuvarlanmis >= 40) {
            printf("DD\n");
        } else if (yuvarlanmis >= 30) {
            printf("FD\n");
        } else {
            printf("FF\n");
        }
        printf("Durum       : ");
        if (final < FINAL_BARAJI) {
            printf("BAŞARISIZ (final barajı)\n");
        } else if (yuvarlanmis >= GECME_ORTALAMA) {
            printf("BAŞARILI\n");
            basarili++;                             /* sayaç */
        } else if (yuvarlanmis >= SARTLI_ORTALAMA) {
            printf("ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)\n");
            sartli++;                               /* sayaç */
        } else {
            printf("BAŞARISIZ\n");
        }

        /* 7) Akış hâlinde istatistik: toplayıcı ve "en iyi aday" */
        toplam_ortalama += ortalama;
        if (i == 1 || ortalama > en_yuksek) {
            en_yuksek = ortalama;
            en_yuksek_no = numara;
        }
        if (i == 1 || ortalama < en_dusuk) {
            en_dusuk = ortalama;
            en_dusuk_no = numara;
        }
    }

    /* 8) Sınıf özeti */
    printf("\n--------------- SINIF ÖZETİ ---------------\n");
    printf("Öğrenci sayısı   : %d\n", n);
    printf("Sınıf ortalaması : %6.2f\n", toplam_ortalama / n);
    printf("En yüksek        : %6.2f (%lld)\n", en_yuksek, en_yuksek_no);
    printf("En düşük         : %6.2f (%lld)\n", en_dusuk, en_dusuk_no);
    printf("Başarılı (CC+)   : %d / %d\n", basarili, n);
    printf("Şartlı (DC)      : %d / %d\n", sartli, n);
    printf("-------------------------------------------\n");
    return 0;
}

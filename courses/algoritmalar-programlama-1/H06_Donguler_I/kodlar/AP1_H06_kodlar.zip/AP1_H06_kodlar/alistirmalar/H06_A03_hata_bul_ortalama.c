/* H06_A03_hata_bul_ortalama.c — Hafta 6 · Alıştırma 6.3 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR. Amaç: N sayının ortalaması.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_A03_hata_bul_ortalama.c -o a03
 */
#include <stdio.h>

int main(void)
{
    int n, x;
    printf("Kaç sayı? ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        return 1;
    }

    int toplam = 0;
    for (int i = 0; i <= n; i++) {
        printf("%d. sayı: ", i + 1);
        if (scanf("%d", &x) != 1) {
            return 1;
        }
        toplam = x;
    }
    printf("Ortalama: %.2f\n", toplam / n);
    return 0;
}

/* H06_A01_cikti_tahmini.c — Hafta 6 · Alıştırma 6.1 (★, çıktı tahmini)
 * Soru   : Çalıştırmadan önce çıktıyı tahmin edin; sonra derleyip
 *          karşılaştırın. İpucu: her döngü için izleme tablosu çizin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_A01_cikti_tahmini.c -o a01
 */
#include <stdio.h>

int main(void)
{
    int i = 20;
    while (i > 0) {
        printf("%d ", i);
        i -= 6;
    }
    printf("| i = %d\n", i);

    int j = 5;
    do {
        printf("[%d]", j);
        j += 5;
    } while (j < 5);
    printf(" j = %d\n", j);
    return 0;
}

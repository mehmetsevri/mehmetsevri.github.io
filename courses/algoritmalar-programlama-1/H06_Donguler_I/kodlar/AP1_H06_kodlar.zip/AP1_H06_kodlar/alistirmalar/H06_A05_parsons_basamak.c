/* H06_A05_parsons_basamak.c — Hafta 6 · Alıştırma 6.5 (★★, Parsons)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. Aşağıdaki satırları, 4071'in
 * basamaklarını sondan başa yazdırıp basamak sayısını bulan bir programa
 * dönüştürecek biçimde sıralayın ve girintileyin. Satırlardan BİRİ
 * fazladır (çeldirici). Beklenen çıktı: "1704" ve "4 basamak".
 */
#include <stdio.h>

int main(void)
{
    } while (sayi != 0);
    printf("\n%d basamak\n", basamak);
    sayi /= 10;
    int sayi = 4071;
    sayi %= 10;
    do {
    printf("%d", sayi % 10);
    int basamak = 0;
    basamak++;
    return 0;
}

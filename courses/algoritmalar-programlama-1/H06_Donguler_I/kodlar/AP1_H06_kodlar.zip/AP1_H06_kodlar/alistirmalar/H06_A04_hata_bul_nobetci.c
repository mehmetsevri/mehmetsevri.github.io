/* H06_A04_hata_bul_nobetci.c — Hafta 6 · Alıştırma 6.4 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_A04_hata_bul_nobetci.c -o a04
 */
#include <stdio.h>

int main(void)
{
    int not_degeri = 0, toplam = 0, sayac = 0;
    while (not_degeri != -1) {
        printf("Not (-1 bitirir): ");
        if (scanf("%d", &not_degeri) != 1) {
            break;
        }
        toplam += not_degeri;
        sayac++;
    }
    printf("%d not, ortalama %.2f\n", sayac, (double)toplam / sayac);
    return 0;
}

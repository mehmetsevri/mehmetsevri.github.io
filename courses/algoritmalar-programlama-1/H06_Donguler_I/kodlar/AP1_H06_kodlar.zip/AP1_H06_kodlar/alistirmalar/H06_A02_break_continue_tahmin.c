/* H06_A02_break_continue_tahmin.c — Hafta 6 · Alıştırma 6.2
 *          (★★, çıktı tahmini: break ve continue)
 * Soru   : Program hangi satırları yazdırır? toplam son olarak kaçtır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_A02_break_continue_tahmin.c -o a02
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;
    for (int i = 1; i <= 10; i++) {
        if (i % 2 == 0) {
            continue;
        }
        if (toplam > 10) {
            break;
        }
        toplam += i;
        printf("i = %d, toplam = %d\n", i, toplam);
    }
    printf("son: %d\n", toplam);
    return 0;
}

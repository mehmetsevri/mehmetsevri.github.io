/* H06_A06_kod_tamamla_katlar.c — Hafta 6 · Alıştırma 6.6 (★★, kod tamamla)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. ____ yerlerini doldurun: 1..N
 * arasında 3'ün YA DA 5'in katı olan sayıların toplamı ve adedi.
 * N = 20 için beklenen: "adet = 9, toplam = 98".
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("N: ");
    if (scanf("%d", &n) != 1) {
        return 1;
    }
    int toplam = ____, adet = ____;
    for (int i = 1; ____; i++) {
        if (____) {
            toplam += i;
            ____;
        }
    }
    printf("adet = %d, toplam = %d\n", adet, toplam);
    return 0;
}

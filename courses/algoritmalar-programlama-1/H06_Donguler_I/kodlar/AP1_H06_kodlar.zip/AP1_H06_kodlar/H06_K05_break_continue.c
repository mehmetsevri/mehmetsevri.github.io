/* H06_K05_break_continue.c — Hafta 6 · Kavram programı: break ve continue
 * Amaç   : break döngüyü hemen bitirir; continue yalnızca o turun
 *          kalanını atlar ve bir sonraki tura (for'da güncellemeye) geçer;
 *          üçüncü döngü ikisini birlikte kullanır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K05_break_continue.c -o break_continue
 */
#include <stdio.h>

int main(void)
{
    /* break: 50'den başlayarak 7'ye bölünen İLK sayıyı bul */
    for (int i = 50; i <= 100; i++) {
        if (i % 7 == 0) {
            printf("50'den sonraki ilk 7 katı: %d\n", i);
            break;                      /* aramayı sürdürmeye gerek yok */
        }
    }

    /* continue: 1..10 arasında 3'ün katlarını atla */
    for (int i = 1; i <= 10; i++) {
        if (i % 3 == 0) {
            continue;                   /* printf atlanır, i++ çalışır */
        }
        printf("%d ", i);
    }
    printf("\n");

    /* birlikte: 3'ün katlarını atla, 8'e gelince dur */
    for (int i = 1; i <= 10; i++) {
        if (i % 3 == 0) {
            continue;
        }
        if (i == 8) {
            break;
        }
        printf("%d ", i);
    }
    printf("\n");
    return 0;
}

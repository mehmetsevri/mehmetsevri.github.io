/* H06_HA5_kayan_sayac.c — Hafta 6 · Hata Avcısı 5 (hatalı, SAF sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: kayan noktalı sayaç 0.1 adımlarla hiçbir
 * zaman TAM 1.0 olmaz (0.1 ikili tabanda sonlu yazılamaz; H3), x != 1.0
 * koşulu hep doğru kalır -> sonsuz döngü. Derslikte Ctrl+C ile durdurun;
 * kayıtlı çıktı "timeout 2" ile alınmıştır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA5_kayan_sayac.c -o ha5
 */
#include <stdio.h>

int main(void)
{
    for (double x = 0.0; x != 1.0; x += 0.1) {
        printf("x = %.17f\n", x);
    }
    printf("Döngü bitti.\n");
    return 0;
}

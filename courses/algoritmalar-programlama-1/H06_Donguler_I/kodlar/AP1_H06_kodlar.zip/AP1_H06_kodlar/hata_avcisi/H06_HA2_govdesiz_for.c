/* H06_HA2_govdesiz_for.c — Hafta 6 · Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: for başlığının sonundaki ; döngünün
 * (boş) gövdesidir; alttaki blok döngüden SONRA yalnızca bir kez çalışır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA2_govdesiz_for.c -o ha2
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;
    int i;
    for (i = 1; i <= 5; i++);
    {
        toplam += i;
    }
    printf("1..5 toplamı: %d\n", toplam);
    return 0;
}

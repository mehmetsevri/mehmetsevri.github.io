/* H06_HA7_zune_dongusu_duzeltilmis.c — Hafta 6 · Hata Avcısı 7
 *          (düzeltilmiş sürüm): her turda ya gün en az 365 azalır ya da
 *          break ile çıkılır; döngünün bitmesi GÜVENCE altındadır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA7_zune_dongusu_duzeltilmis.c -o ha7d
 */
#include <stdio.h>

int main(void)
{
    int gun, yil = 1980;
    printf("1.1.1980'den beri geçen gün (1 = 1.1.1980): ");
    if (scanf("%d", &gun) != 1 || gun < 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    while (1) {
        int artik = (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;
        int yil_uzunlugu = artik ? 366 : 365;
        if (gun <= yil_uzunlugu) {
            break;                      /* gün bu yılın içinde: dur */
        }
        gun -= yil_uzunlugu;            /* ilerleme: gun en az 365 azalır */
        yil++;
    }
    printf("Yıl %d, yılın %d. günü\n", yil, gun);
    return 0;
}

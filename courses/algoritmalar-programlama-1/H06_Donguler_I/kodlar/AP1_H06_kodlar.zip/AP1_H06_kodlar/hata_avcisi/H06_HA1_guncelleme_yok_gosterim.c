/* H06_HA1_guncelleme_yok_gosterim.c — Hafta 6 · Hata Avcısı 1 (GÖSTERİM)
 * BU DOSYA KASITLI HATA İÇERİR (güncellemesi unutulmuş döngü); ancak
 * kayıtlı çıktının sonsuza dek sürmemesi için GÖSTERİM amaçlı bir tur
 * sınırı eklenmiştir. Sınır, hatanın parçası DEĞİLDİR.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA1_guncelleme_yok_gosterim.c -o ha1_gosterim
 */
#include <stdio.h>

int main(void)
{
    int i = 1;
    int tur = 0;                        /* GÖSTERİM: tur sayacı */
    printf("1'den 5'e kadar:\n");
    while (i <= 5) {
        printf("%d ", i);
        /* i++ unutuldu: koşul hep doğru kalır */
        tur++;                          /* GÖSTERİM */
        if (tur == 20) {                /* GÖSTERİM: güvenlik sınırı */
            printf("\n20 tur geçti, i hâlâ %d: döngü bitmedi"
                   " -> sonsuz döngü!\n", i);
            break;
        }
    }
    printf("\nBitti.\n");
    return 0;
}

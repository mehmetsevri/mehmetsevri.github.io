/* H06_HA5_kayan_sayac_gosterim.c — Hafta 6 · Hata Avcısı 5 (GÖSTERİM)
 * BU DOSYA KASITLI HATA İÇERİR (x != 1.0 ile biten kayan noktalı sayaç);
 * kayıtlı çıktının sonsuz sürmemesi için GÖSTERİM amaçlı tur sınırı
 * eklenmiştir. Sınır, hatanın parçası DEĞİLDİR.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA5_kayan_sayac_gosterim.c -o ha5_gosterim
 */
#include <stdio.h>

int main(void)
{
    int tur = 0;                        /* GÖSTERİM: tur sayacı */
    for (double x = 0.0; x != 1.0; x += 0.1) {
        printf("x = %.17f\n", x);
        tur++;                          /* GÖSTERİM */
        if (tur == 14) {                /* GÖSTERİM: güvenlik sınırı */
            printf("14 tur geçti, x 1.0'ı atladı: döngü bitmedi"
                   " -> sonsuz döngü!\n");
            break;
        }
    }
    printf("Döngü bitti.\n");
    return 0;
}

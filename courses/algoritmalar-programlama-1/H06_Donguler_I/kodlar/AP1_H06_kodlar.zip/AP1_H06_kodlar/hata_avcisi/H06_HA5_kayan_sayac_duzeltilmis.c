/* H06_HA5_kayan_sayac_duzeltilmis.c — Hafta 6 · Hata Avcısı 5
 *          (düzeltilmiş sürüm): sayaç tamsayı, kesirli değer her turda
 *          sayaçtan YENİDEN hesaplanır (hata birikmez)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA5_kayan_sayac_duzeltilmis.c -o ha5d
 */
#include <stdio.h>

int main(void)
{
    for (int i = 0; i <= 10; i++) {     /* tam 11 tur: 0.0, 0.1, ..., 1.0 */
        double x = i / 10.0;
        printf("x = %.17f\n", x);
    }
    printf("Döngü bitti.\n");
    return 0;
}

/* H06_HA2_govdesiz_for_duzeltilmis.c — Hafta 6 · Hata Avcısı 2
 *          (düzeltilmiş sürüm): başlıktan sonra ; yok, gövde { } içinde
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA2_govdesiz_for_duzeltilmis.c -o ha2d
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;
    for (int i = 1; i <= 5; i++) {
        toplam += i;
    }
    printf("1..5 toplamı: %d\n", toplam);
    return 0;
}

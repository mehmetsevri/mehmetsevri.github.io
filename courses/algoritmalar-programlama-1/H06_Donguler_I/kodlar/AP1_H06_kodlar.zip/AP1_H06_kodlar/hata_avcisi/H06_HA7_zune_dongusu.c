/* H06_HA7_zune_dongusu.c — Hafta 6 · Hata Avcısı 7 / Gerçek Dünyadan
 *          (hatalı, SAF sürüm)
 * BU DOSYA KASITLI HATA İÇERİR. Zune 30 saat sürücüsündeki gün -> yıl
 * döngüsünün kısaltılmış, eğitsel yeniden kurgusudur (özgün kod değildir;
 * yapısı için bkz. Hayes, 2009). 1 Ocak 1980 = 1. gün kabul edilir.
 * gun = 10593 (31 Aralık 2008, artık yılın 366. günü) için koşul
 * (gun > 365) hep doğru kalır ve hiçbir değişken değişmez: sonsuz döngü.
 * Kayıtlı çıktı "timeout 2" ile alınmıştır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA7_zune_dongusu.c -o ha7
 */
#include <stdio.h>

int main(void)
{
    int gun = 10593;                    /* 1.1.1980'den beri: 31.12.2008 */
    int yil = 1980;

    printf("Gün %d için yıl hesaplanıyor...\n", gun);
    while (gun > 365) {
        int artik = (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;
        if (artik) {
            if (gun > 366) {
                gun -= 366;
                yil += 1;
            }
            /* gun == 366 ise hiçbir şey değişmez! */
        } else {
            gun -= 365;
            yil += 1;
        }
    }
    printf("Yıl %d, yılın %d. günü\n", yil, gun);
    return 0;
}

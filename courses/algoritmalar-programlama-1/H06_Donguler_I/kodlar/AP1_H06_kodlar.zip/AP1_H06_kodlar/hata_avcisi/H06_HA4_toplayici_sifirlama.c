/* H06_HA4_toplayici_sifirlama.c — Hafta 6 · Hata Avcısı 4 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: toplayıcı döngünün İÇİNDE sıfırlanıyor;
 * her tur önceki toplamı siler, sonunda yalnızca son not kalır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA4_toplayici_sifirlama.c -o ha4
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;
    for (int i = 1; i <= 4; i++) {
        toplam = 0;                     /* her turda sıfırlanıyor! */
        int not_degeri;
        printf("%d. not: ", i);
        if (scanf("%d", &not_degeri) != 1) {
            return 1;
        }
        toplam += not_degeri;
    }
    printf("Toplam: %d, ortalama: %.2f\n", toplam, toplam / 4.0);
    return 0;
}

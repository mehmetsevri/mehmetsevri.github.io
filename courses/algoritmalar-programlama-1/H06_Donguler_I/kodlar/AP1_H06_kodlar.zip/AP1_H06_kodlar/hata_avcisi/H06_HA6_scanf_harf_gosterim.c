/* H06_HA6_scanf_harf_gosterim.c — Hafta 6 · Hata Avcısı 6 (GÖSTERİM)
 * BU DOSYA KASITLI HATA İÇERİR (scanf dönüş değeri denetlenmiyor); her
 * turda scanf'in döndürdüğü değer yazdırılır ve kayıtlı çıktının sonsuz
 * sürmemesi için GÖSTERİM amaçlı tur sınırı eklenmiştir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA6_scanf_harf_gosterim.c -o ha6_gosterim
 */
#include <stdio.h>

int main(void)
{
    int puan = -1;
    int tur = 0;                        /* GÖSTERİM: tur sayacı */
    do {
        printf("Puan (0-100): ");
        int r = scanf("%d", &puan);     /* GÖSTERİM: dönüş değerini gör */
        printf("[scanf %d döndürdü, puan = %d]\n", r, puan);
        tur++;                          /* GÖSTERİM */
        if (tur == 5) {                 /* GÖSTERİM: güvenlik sınırı */
            printf("5 tur geçti: 'abc' hâlâ tamponda"
                   " -> sonsuz döngü!\n");
            break;
        }
    } while (puan < 0 || puan > 100);
    printf("Puan: %d\n", puan);
    return 0;
}

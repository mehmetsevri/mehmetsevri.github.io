/* H06_HA1_guncelleme_yok.c — Hafta 6 · Hata Avcısı 1 (hatalı, SAF sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: sayaç hiç güncellenmiyor -> sonsuz döngü.
 * Derslikte çalıştırın ve Ctrl+C ile durdurun. Kayıtlı çıktı "timeout 2"
 * ile alınmıştır: işletim sistemi programı 2 saniye sonra durdurur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA1_guncelleme_yok.c -o ha1
 */
#include <stdio.h>

int main(void)
{
    int i = 1;
    printf("1'den 5'e kadar:\n");
    while (i <= 5) {
        printf("%d ", i);
        /* i++ unutuldu: koşul hep doğru kalır */
    }
    printf("\nBitti.\n");
    return 0;
}

/* H06_HA3_bir_fark.c — Hafta 6 · Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: bir-fark (off-by-one) hatası; < ile <=
 * karıştırıldığı için döngü bir tur eksik çalışır. Derleyici uyarmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA3_bir_fark.c -o ha3
 */
#include <stdio.h>

int main(void)
{
    const int N = 10;
    int toplam = 0, tur = 0;
    for (int i = 1; i < N; i++) {       /* N dahil edilmiyor! */
        toplam += i;
        tur++;
    }
    printf("1..%d toplamı: %d (%d tur)\n", N, toplam, tur);
    return 0;
}

/* H06_HA6_scanf_harf_duzeltilmis.c — Hafta 6 · Hata Avcısı 6
 *          (düzeltilmiş sürüm): dönüş değeri denetlenir; sayı değilse
 *          satırın kalanı getchar ile atılır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA6_scanf_harf_duzeltilmis.c -o ha6d
 */
#include <stdio.h>

int main(void)
{
    int puan = -1;
    do {
        printf("Puan (0-100): ");
        int r = scanf("%d", &puan);
        if (r == EOF) {
            return 1;                   /* girdi bitti */
        }
        if (r == 0) {                   /* sayı değil: tamponu temizle */
            int c;
            while ((c = getchar()) != '\n' && c != EOF) {
                /* satırın kalanını at */
            }
            puan = -1;
        }
    } while (puan < 0 || puan > 100);
    printf("Puan: %d\n", puan);
    return 0;
}

/* H06_HA7_zune_dongusu_gosterim.c — Hafta 6 · Hata Avcısı 7 (GÖSTERİM)
 * BU DOSYA KASITLI HATA İÇERİR (Zune döngüsünün eğitsel yeniden kurgusu).
 * Gün sayısı klavyeden okunur; son yılların turları yazdırılır ve kayıtlı
 * çıktının sonsuz sürmemesi için GÖSTERİM amaçlı 40 turluk sınır vardır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA7_zune_dongusu_gosterim.c -o ha7_gosterim
 */
#include <stdio.h>

int main(void)
{
    int gun, yil = 1980;
    printf("1.1.1980'den beri geçen gün (1 = 1.1.1980): ");
    if (scanf("%d", &gun) != 1 || gun < 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int tur = 0;                        /* GÖSTERİM: tur sayacı */
    while (gun > 365) {
        int artik = (yil % 4 == 0 && yil % 100 != 0) || yil % 400 == 0;
        if (artik) {
            if (gun > 366) {
                gun -= 366;
                yil += 1;
            }
        } else {
            gun -= 365;
            yil += 1;
        }
        tur++;                          /* GÖSTERİM */
        if (yil >= 2007) {              /* GÖSTERİM: yalnızca son yıllar */
            printf("tur %2d: yil = %d, gun = %d\n", tur, yil, gun);
        }
        if (tur == 40) {                /* GÖSTERİM: güvenlik sınırı */
            printf("40 tur geçti, gun hâlâ %d: döngü bitmedi"
                   " -> sonsuz döngü!\n", gun);
            return 1;
        }
    }
    printf("Yıl %d, yılın %d. günü\n", yil, gun);
    return 0;
}

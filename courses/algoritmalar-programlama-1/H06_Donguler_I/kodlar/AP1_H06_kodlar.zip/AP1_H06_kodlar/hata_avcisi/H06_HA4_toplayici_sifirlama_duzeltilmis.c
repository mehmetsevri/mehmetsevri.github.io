/* H06_HA4_toplayici_sifirlama_duzeltilmis.c — Hafta 6 · Hata Avcısı 4
 *          (düzeltilmiş sürüm): toplayıcı döngüden ÖNCE bir kez sıfırlanır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA4_toplayici_sifirlama_duzeltilmis.c -o ha4d
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;                     /* yalnızca bir kez, döngüden önce */
    for (int i = 1; i <= 4; i++) {
        int not_degeri;
        printf("%d. not: ", i);
        if (scanf("%d", &not_degeri) != 1) {
            return 1;
        }
        toplam += not_degeri;
    }
    printf("Toplam: %d, ortalama: %.2f\n", toplam, toplam / 4.0);
    return 0;
}

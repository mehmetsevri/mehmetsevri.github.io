/* H06_HA6_scanf_harf.c — Hafta 6 · Hata Avcısı 6 (hatalı, SAF sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: scanf'in dönüş değeri denetlenmiyor.
 * "abc" girilince scanf 0 döndürür, harfler tamponda kalır, puan hiç
 * değişmez; her turda aynı harflerle karşılaşan scanf yine 0 döndürür
 * -> sonsuz döngü. Kayıtlı çıktı "timeout 2" ile alınmıştır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA6_scanf_harf.c -o ha6
 */
#include <stdio.h>

int main(void)
{
    int puan = -1;
    do {
        printf("Puan (0-100): ");
        scanf("%d", &puan);             /* dönüş değeri yok sayılıyor! */
    } while (puan < 0 || puan > 100);
    printf("Puan: %d\n", puan);
    return 0;
}

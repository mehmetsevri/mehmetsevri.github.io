/* H06_HA3_bir_fark_duzeltilmis.c — Hafta 6 · Hata Avcısı 3
 *          (düzeltilmiş sürüm): 1'den N'e (N dahil) -> i <= N
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA3_bir_fark_duzeltilmis.c -o ha3d
 */
#include <stdio.h>

int main(void)
{
    const int N = 10;
    int toplam = 0, tur = 0;
    for (int i = 1; i <= N; i++) {      /* N dahil: N tur */
        toplam += i;
        tur++;
    }
    printf("1..%d toplamı: %d (%d tur)\n", N, toplam, tur);
    return 0;
}

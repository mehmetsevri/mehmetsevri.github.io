/* H06_HA1_guncelleme_yok_duzeltilmis.c — Hafta 6 · Hata Avcısı 1
 *          (düzeltilmiş sürüm): her tur i'yi sona doğru yaklaştırır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_HA1_guncelleme_yok_duzeltilmis.c -o ha1d
 */
#include <stdio.h>

int main(void)
{
    int i = 1;
    printf("1'den 5'e kadar:\n");
    while (i <= 5) {
        printf("%d ", i);
        i++;                            /* ilerleme: i her turda 1 artar */
    }
    printf("\nBitti.\n");
    return 0;
}

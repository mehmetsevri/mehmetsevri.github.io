/* H06_K04_for_while_donusum.c — Hafta 6 · Kavram programı: for ↔ while
 * Amaç   : for döngüsünün while karşılığı; for başlığında bildirilen
 *          sayacın kapsamı (döngü bitince yok olur)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K04_for_while_donusum.c -o for_while_donusum
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 3; i++) {
        printf("for   turu %d\n", i);
    }
    /* burada i yoktur: kapsamı for döngüsüyle sınırlı */

    int k = 1;                          /* başlatma döngüden önceye */
    while (k <= 3) {                    /* koşul aynen              */
        printf("while turu %d\n", k);
        k++;                            /* güncelleme gövdenin sonuna */
    }
    printf("while bitti: k = %d\n", k); /* k hâlâ erişilebilir */
    return 0;
}

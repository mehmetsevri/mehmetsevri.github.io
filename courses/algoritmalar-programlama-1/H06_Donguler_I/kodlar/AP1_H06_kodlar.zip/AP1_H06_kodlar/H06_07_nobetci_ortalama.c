/* H06_07_nobetci_ortalama.c — Hafta 6 · Örnek 7 (★★): bilinmeyen sayıda
 *          notun ortalaması
 * Amaç   : nöbetçi değer (-1) kontrollü döngü; öncül okuma; toplayıcı ve
 *          sayaç desenlerinin birlikte kullanılması; sıfıra bölme denetimi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_07_nobetci_ortalama.c -o nobetci_ortalama
 * Örnek  : girdi "70 85 90 -1" -> 3 not, toplam = 245, ortalama = 81.67
 */
#include <stdio.h>

int main(void)
{
    const int NOBETCI = -1;             /* "girdi bitti" işareti */
    int not_degeri;
    int toplam = 0;                     /* toplayıcı */
    int sayac = 0;                      /* sayaç     */

    /* öncül okuma: ilk değer döngüden ÖNCE istenir */
    printf("Not 1 (bitirmek için %d): ", NOBETCI);
    while (scanf("%d", &not_degeri) == 1 && not_degeri != NOBETCI) {
        toplam += not_degeri;
        sayac++;
        printf("Not %d (bitirmek için %d): ", sayac + 1, NOBETCI);
    }

    if (sayac == 0) {
        printf("Hiç not girilmedi; ortalama hesaplanamaz.\n");
    } else {
        double ortalama = (double)toplam / sayac;
        printf("%d not, toplam = %d, ortalama = %.2f\n",
               sayac, toplam, ortalama);
    }
    return 0;
}

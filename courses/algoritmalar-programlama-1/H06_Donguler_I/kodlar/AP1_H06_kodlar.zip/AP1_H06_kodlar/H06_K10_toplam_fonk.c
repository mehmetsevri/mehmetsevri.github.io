/* H06_K10_toplam_fonk.c — Hafta 6 · Kavram programı: döngünün makine kodu
 * Amaç   : Kaputun Altında için 1..n toplam döngüsünü küçük bir
 *          fonksiyona koyduk (fonksiyonlar H8'de); böylece derleyicinin
 *          ürettiği assembly'de yalnızca döngüyü görürüz
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K10_toplam_fonk.c -o toplam_fonk
 * Assembly: gcc -O0 / -O2 ve clang -O2 ile -S -masm=intel (ciktilar/)
 */
#include <stdio.h>

int toplam_dongu(int n)
{
    int toplam = 0;
    for (int i = 1; i <= n; i++) {
        toplam += i;
    }
    return toplam;
}

int main(void)
{
    int n;
    printf("N: ");
    if (scanf("%d", &n) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    printf("Toplam (1..%d) = %d\n", n, toplam_dongu(n));
    return 0;
}

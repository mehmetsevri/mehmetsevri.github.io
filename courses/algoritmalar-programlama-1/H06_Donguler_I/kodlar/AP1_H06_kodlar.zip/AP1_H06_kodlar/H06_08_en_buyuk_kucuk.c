/* H06_08_en_buyuk_kucuk.c — Hafta 6 · Örnek 8 (★★): en büyük ve en küçük
 * Amaç   : "şimdiye kadarki en iyi" deseni; adayları ilk sayıyla
 *          başlatmak; en iyinin kaçıncı sırada geldiğini de izlemek
 *          (H02_09'daki algoritmanın for ile ve iki yönlü sürümü)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_08_en_buyuk_kucuk.c -o en_buyuk_kucuk
 * Örnek  : girdi "5" ve "34 12 58 7 41" -> En büyük: 58 (3. sayı)
 */
#include <stdio.h>

int main(void)
{
    int n, x;
    printf("Kaç sayı girilecek? ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Geçersiz girdi: en az 1 sayı gerekir.\n");
        return 1;
    }

    printf("1. sayı: ");
    if (scanf("%d", &x) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    int en_buyuk = x, buyuk_sira = 1;   /* ilk sayı: şimdiye kadarki en iyi */
    int en_kucuk = x, kucuk_sira = 1;

    for (int i = 2; i <= n; i++) {
        printf("%d. sayı: ", i);
        if (scanf("%d", &x) != 1) {
            printf("Geçersiz girdi.\n");
            return 1;
        }
        if (x > en_buyuk) {             /* daha iyisi geldi: güncelle */
            en_buyuk = x;
            buyuk_sira = i;
        }
        if (x < en_kucuk) {
            en_kucuk = x;
            kucuk_sira = i;
        }
    }

    printf("En büyük: %d (%d. sayı)\n", en_buyuk, buyuk_sira);
    printf("En küçük: %d (%d. sayı)\n", en_kucuk, kucuk_sira);
    return 0;
}

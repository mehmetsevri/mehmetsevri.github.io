/* H06_10_ters_palindrom.c — Hafta 6 · Örnek 10 (★★): sayıyı ters çevirme
 *          ve palindrom sayı
 * Amaç   : basamaklardan yeni bir sayı inşa etmek: ters = ters * 10 + son
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_10_ters_palindrom.c -o ters_palindrom
 * Örnek  : girdi "12321" -> 12321 bir palindrom sayıdır.
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Negatif olmayan bir tamsayı girin: ");
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int sayi = n;
    long long ters = 0;                 /* 1999999999'un tersi int'e sığmaz */
    while (sayi > 0) {
        int son = sayi % 10;            /* 1) son basamağı al        */
        ters = ters * 10 + son;         /* 2) tersin sağına ekle     */
        sayi /= 10;                     /* 3) son basamağı at        */
    }

    printf("Ters: %lld\n", ters);
    if (ters == n) {
        printf("%d bir palindrom sayıdır.\n", n);
    } else {
        printf("%d palindrom değildir.\n", n);
    }
    return 0;
}

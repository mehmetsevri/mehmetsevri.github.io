/* H06_02_toplam_n.c — Hafta 6 · Örnek 2 (★): 1'den N'e kadar toplam
 * Amaç   : toplayıcı deseni; for döngüsü (H02_07'nin while sürümüyle
 *          karşılaştırın); scanf dönüş değerinin denetlenmesi
 * Kısıt  : N ≤ 65535 program içinde denetlenir (65536 için toplam int'e
 *          sığmaz; işaretli taşma tanımsız davranıştır). N ≤ 0: boş toplam 0
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_02_toplam_n.c -o toplam_n
 * Örnek  : girdi "5" -> Toplam (1..5) = 15
 */
#include <stdio.h>

int main(void)
{
    const int EN_BUYUK_N = 65535;       /* 65536 için toplam int'e sığmaz */
    int n;
    printf("N değerini girin: ");
    if (scanf("%d", &n) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    if (n > EN_BUYUK_N) {               /* taşmayı işlemden ÖNCE önle */
        printf("N en fazla %d olabilir.\n", EN_BUYUK_N);
        return 1;
    }

    int toplam = 0;                 /* toplayıcı: etkisiz eleman 0 */
    for (int i = 1; i <= n; i++) {
        toplam += i;                /* toplam = toplam + i */
    }

    printf("Toplam (1..%d) = %d\n", n, toplam);
    return 0;
}

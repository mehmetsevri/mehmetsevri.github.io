/* H06_03_cift_toplam.c — Hafta 6 · Örnek 3 (★): çift sayıların toplamı
 * Amaç   : aynı sonuca iki yol: (A) her sayıyı dolaşıp if ile süzmek,
 *          (B) adım 2 ile yalnızca çiftleri üretmek; tur sayılarını
 *          karşılaştırmak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_03_cift_toplam.c -o cift_toplam
 * Örnek  : girdi "10" -> Yol B (adım 2)      : toplam = 30, 5 tur
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("N değerini girin: ");
    if (scanf("%d", &n) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    /* Yol A: 1..N arasındaki her sayıyı dolaş, çift olanları süz */
    int toplam_a = 0, tur_a = 0;
    for (int i = 1; i <= n; i++) {
        tur_a++;
        if (i % 2 == 0) {
            toplam_a += i;
        }
    }

    /* Yol B: yalnızca çiftleri üret (2, 4, 6, ...) */
    int toplam_b = 0, tur_b = 0;
    for (int i = 2; i <= n; i += 2) {
        tur_b++;
        toplam_b += i;
    }

    printf("Yol A (if ile süzme): toplam = %d, %d tur\n", toplam_a, tur_a);
    printf("Yol B (adım 2)      : toplam = %d, %d tur\n", toplam_b, tur_b);
    return 0;
}

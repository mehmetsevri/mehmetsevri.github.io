/* H06_K02_while_temel.c — Hafta 6 · Kavram programı: while döngüsü
 * Amaç   : döngünün dört parçası (başlatma, koşul, gövde, güncelleme);
 *          koşul baştan yanlışsa while gövdesinin hiç çalışmaması
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K02_while_temel.c -o while_temel
 */
#include <stdio.h>

int main(void)
{
    int sayac = 3;                      /* 1) başlatma   */
    while (sayac > 0) {                 /* 2) koşul      */
        printf("%d...\n", sayac);       /* 3) gövde      */
        sayac--;                        /* 4) güncelleme */
    }
    printf("Kalkış! (sayac = %d)\n", sayac);

    int kalan = 0;
    while (kalan > 0) {                 /* koşul baştan yanlış */
        printf("Bu satır hiç yazılmaz.\n");
        kalan--;
    }
    printf("İkinci döngü 0 kez çalıştı.\n");
    return 0;
}

/* H06_K09_milyar_tur.c — Hafta 6 · Kavram programı: milyar turluk döngü
 * Amaç   : "Bilgisayar yorulmaz" iddiasını ölçmek: 1 + 2 + ... + N
 *          toplamını N = 1 000 000 000 için farklı derleyici ve
 *          optimizasyon düzeylerinde çalıştırıp süreyi karşılaştırmak
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -O0 \
 *              H06_K09_milyar_tur.c -o milyar_O0
 *          (ayrıca: gcc -O2, clang -O2; ölçüm: time)
 */
#include <stdio.h>

int main(void)
{
    unsigned long long n;
    printf("N: ");
    if (scanf("%llu", &n) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    unsigned long long toplam = 0;
    for (unsigned long long i = 1; i <= n; i++) {
        toplam += i;
    }
    printf("1 + 2 + ... + %llu = %llu\n", n, toplam);
    return 0;
}

/* H06_K20_izle_toplam.c — Hafta 6 · İzleme programı: 1..n toplamı
 * Amaç   : izleme tablosu ve web "Döngü izleyici" simülasyonu için sade
 *          sürüm (girdi yok; n'yi değiştirip yeniden derleyin)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K20_izle_toplam.c -o izle_toplam
 */
#include <stdio.h>

int main(void)
{
    int n = 5;
    int toplam = 0;
    for (int i = 1; i <= n; i++) {
        toplam += i;
    }
    printf("toplam = %d\n", toplam);
    return 0;
}

/* H06_K23_izle_oklid.c — Hafta 6 · İzleme programı: Öklid ile EBOB
 * Amaç   : kalanla küçülen döngünün izlenmesi (web "Döngü izleyici")
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K23_izle_oklid.c -o izle_oklid
 */
#include <stdio.h>

int main(void)
{
    int x = 48, y = 18;
    while (y != 0) {
        int r = x % y;
        x = y;
        y = r;
    }
    printf("EBOB = %d\n", x);
    return 0;
}

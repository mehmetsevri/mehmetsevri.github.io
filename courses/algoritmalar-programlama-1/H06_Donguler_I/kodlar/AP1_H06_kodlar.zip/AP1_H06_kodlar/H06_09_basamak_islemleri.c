/* H06_09_basamak_islemleri.c — Hafta 6 · Örnek 9 (★★): basamak sayısı
 *          ve basamak toplamı
 * Amaç   : %10 (son basamağı al) ve /10 (son basamağı at) döngüsü;
 *          0'ın da 1 basamaklı sayılması için do-while
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_09_basamak_islemleri.c -o basamak_islemleri
 * Örnek  : girdi "2026" -> 2026: 4 basamak, basamak toplamı 10
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Bir tamsayı girin: ");
    if (scanf("%d", &n) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    long long sayi = n;                 /* long long: -INT_MIN de sığar */
    if (sayi < 0) {
        sayi = -sayi;                   /* işareti at: basamaklar aynı kalır */
    }

    int basamak_sayisi = 0, basamak_toplami = 0;
    do {                                /* en az bir tur: 0 -> 1 basamak */
        basamak_toplami += sayi % 10;   /* son basamağı al */
        basamak_sayisi++;
        sayi /= 10;                     /* son basamağı at */
    } while (sayi != 0);

    printf("%d: %d basamak, basamak toplamı %d\n",
           n, basamak_sayisi, basamak_toplami);
    return 0;
}

/* H06_01_bir_den_ona.c — Hafta 6 · Örnek 1 (★): 1'den 10'a üç döngüyle
 * Amaç   : while, do-while ve for döngülerinin denkliği; başlatma,
 *          koşul, gövde ve güncelleme parçalarının üç yazılışı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_01_bir_den_ona.c -o bir_den_ona
 * Örnek  : -> for     : 1 2 3 4 5 6 7 8 9 10
 */
#include <stdio.h>

int main(void)
{
    /* 1) while: koşul ÖNCE sınanır */
    printf("while   : ");
    int i = 1;                  /* başlatma   */
    while (i <= 10) {           /* koşul      */
        printf("%d ", i);       /* gövde      */
        i++;                    /* güncelleme */
    }
    printf("\n");

    /* 2) do-while: gövde önce çalışır, koşul SONRA sınanır */
    printf("do-while: ");
    int j = 1;
    do {
        printf("%d ", j);
        j++;
    } while (j <= 10);
    printf("\n");

    /* 3) for: başlatma; koşul; güncelleme tek satırda */
    printf("for     : ");
    for (int k = 1; k <= 10; k++) {
        printf("%d ", k);
    }
    printf("\n");

    return 0;
}

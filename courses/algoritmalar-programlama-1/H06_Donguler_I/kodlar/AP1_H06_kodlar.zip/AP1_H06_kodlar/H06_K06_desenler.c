/* H06_K06_desenler.c — Hafta 6 · Kavram programı: altı döngü deseni
 * Amaç   : toplayıcı, sayaç, çarpım biriktirici, bayrak, en büyük ve
 *          basamak ayrıştırma desenlerinin en yalın biçimleri (desen
 *          kartlarındaki kodlar bu dosyadandır)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K06_desenler.c -o desenler
 */
#include <stdio.h>

int main(void)
{
    const int N = 6;

    /* 1) TOPLAYICI: 1 + 2 + ... + N */
    int toplam = 0;
    for (int i = 1; i <= N; i++) {
        toplam += i;
    }

    /* 2) SAYAÇ: 1..N arasında 3'e bölünenlerin sayısı */
    int sayac = 0;
    for (int i = 1; i <= N; i++) {
        if (i % 3 == 0) {
            sayac++;
        }
    }

    /* 3) ÇARPIM BİRİKTİRİCİ: N! */
    long long carpim = 1;
    for (int i = 1; i <= N; i++) {
        carpim *= i;
    }

    /* 4) BAYRAK: 2026'nın basamakları arasında 0 var mı? */
    int sayi = 2026, sifir_var = 0;
    while (sayi > 0) {
        if (sayi % 10 == 0) {
            sifir_var = 1;
        }
        sayi /= 10;
    }

    /* 5) EN BÜYÜK: x = (7 * i) % 10 akışının en büyüğü (7 4 1 8 5 2) */
    int en_buyuk = (7 * 1) % 10;
    for (int i = 2; i <= N; i++) {
        int x = (7 * i) % 10;
        if (x > en_buyuk) {
            en_buyuk = x;
        }
    }

    /* 6) BASAMAK AYRIŞTIRMA: 2026'nın basamakları sağdan sola */
    int m = 2026;
    printf("2026'nın basamakları (sağdan sola):");
    while (m > 0) {
        printf(" %d", m % 10);
        m /= 10;
    }
    printf("\n");

    printf("toplam = %d, sayac = %d, carpim = %lld\n", toplam, sayac, carpim);
    printf("sifir_var = %d, en_buyuk = %d\n", sifir_var, en_buyuk);
    return 0;
}

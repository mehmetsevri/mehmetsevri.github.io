# Hafta 6 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` dosyası (76 dosya); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program`. Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (her dosyanın başında derleme komutu, sonra `$ ./program` satırları ve kullanıcı girdileriyle birlikte çıktı). Bütün örnek, kavram ve izleme programları ayrıca AddressSanitizer + UBSan ile temiz çalıştı; `H06_K07_faktoriyel_int_ub.c` bilerek UBSan iletisi üretir.

Sonsuz döngü içeren **saf** Hata Avcısı dosyaları (HA1, HA5, HA6, HA7) kayıtlarda `timeout 2` ile iki saniyede durduruldu (çıkış kodu 124); kayıtlı oturumlar `hata_avcisi/ciktilar/` içindedir. Her birinin tur sınırlı `_gosterim.c` sürümü de vardır.

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Web’deki kod blokları dosyanın **tamamıdır** (satır numaraları dosyayla aynı; quiz kodları `#include`’dan başlar); simülasyonların (`h06-izleyici`, `h06-kac-kez`, `h06-tahmin`, `h06-collatz`) gösterdiği kodlar da bu dosyalardan birebir alınır.

Envanter denetimi: `node /home/claude/ap1/shared/kod_envanteri.js 6` → **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H06_01_bir_den_ona.c` | Örnek 1 (★) | Örnek 1 (★): 1'den 10'a üç döngüyle | sıfır uyarı | 3.2 | 1 (şekil), 13 (şekil) | h06-uc-dongu |
| `H06_02_toplam_n.c` | Örnek 2 (★) | Örnek 2 (★): 1'den N'e kadar toplam | sıfır uyarı | 3.1 (şekil), 4.1 | 11 (şekil), 30 | h06-merdiven |
| `H06_03_cift_toplam.c` | Örnek 3 (★) | Örnek 3 (★): çift sayıların toplamı | sıfır uyarı | 4.1 (metin) | — | h06-merdiven |
| `H06_04_carpim_tablosu.c` | Örnek 4 (★) | Örnek 4 (★): çarpım tablosu | sıfır uyarı | 4.1 | — | h06-merdiven |
| `H06_05_faktoriyel_tasma.c` | Örnek 5 (★★) | Örnek 5 (★★): faktöriyel ve taşma | sıfır uyarı | 4.2 | 31 | h06-merdiven |
| `H06_06_us_alma.c` | Örnek 6 (★★) | Örnek 6 (★★): tekrarlı çarpma ile üs alma | sıfır uyarı | 4.2 (metin) | — | h06-merdiven |
| `H06_07_nobetci_ortalama.c` | Örnek 7 (★★) | Örnek 7 (★★): bilinmeyen sayıda | sıfır uyarı | 4.3 | 18 (şekil), 34, 35 | h06-merdiven |
| `H06_08_en_buyuk_kucuk.c` | Örnek 8 (★★) | Örnek 8 (★★): en büyük ve en küçük | sıfır uyarı | 4.4 | — | h06-merdiven |
| `H06_09_basamak_islemleri.c` | Örnek 9 (★★) | Örnek 9 (★★): basamak sayısı | sıfır uyarı | 4.4 | — | h06-merdiven |
| `H06_10_ters_palindrom.c` | Örnek 10 (★★) | Örnek 10 (★★): sayıyı ters çevirme | sıfır uyarı | 4.5 | 36 (şekil), 37 | h06-merdiven |
| `H06_11_ebob_ekok.c` | Örnek 11 (★★) | Örnek 11 (★★): Öklid ile EBOB ve EKOK | sıfır uyarı | 4.6 | 38 | h06-merdiven |
| `H06_12_gecerli_girdi.c` | Örnek 12 (★★) | Örnek 12 (★★): geçerli girdi | sıfır uyarı | 4.6 | 39 | h06-merdiven |
| `H06_13_sayi_tahmin.c` | Örnek 13 (★★) | Örnek 13 (★★): sayı tahmin oyunu | sıfır uyarı | 4.6 | 40 (şekil), 41 | h06-merdiven, h06-merdiven (h06-tahmin) |
| `H06_14_collatz.c` | Örnek 14 (★★★) | Örnek 14 (★★★): Collatz dizisi | sıfır uyarı | 4.7 | — | h06-merdiven, h06-ap2 (h06-collatz) |
| `H06_K01_dry_tekrar.c` | Kavram programı | Kavram programı: neden döngü? (DRY) | sıfır uyarı | 3.1 | 10 | h06-neden-dongu |
| `H06_K02_while_temel.c` | Kavram programı | Kavram programı: while döngüsü | sıfır uyarı | 3.2 (metin) | 12 | h06-uc-dongu |
| `H06_K03_do_while_temel.c` | Kavram programı | Kavram programı: do-while | sıfır uyarı | 3.2 (metin) | 12 | h06-uc-dongu |
| `H06_K04_for_while_donusum.c` | Kavram programı | Kavram programı: for ↔ while | sıfır uyarı | 3.2 (metin) | 14 | h06-uc-dongu |
| `H06_K05_break_continue.c` | Kavram programı | Kavram programı: break ve continue | sıfır uyarı | 3.3 | 19 | h06-denetim |
| `H06_K06_desenler.c` | Kavram programı | Kavram programı: altı döngü deseni | sıfır uyarı | 3.4 (şekil, metin) | 20, 21 | h06-desenler |
| `H06_K07_faktoriyel_int_ub.c` | Kavram programı | Kavram programı: int taşması | sıfır uyarı | 4.2 (metin) | 32 | h06-merdiven |
| `H06_K08_degismez.c` | Kavram programı | Kavram programı: döngü değişmezi | sıfır uyarı | 3.5 (metin) | 23 (şekil) | h06-izleme |
| `H06_K09_milyar_tur.c` | Kavram programı | Kavram programı: milyar turluk döngü | sıfır uyarı | 3.7 (metin) | — | h06-kaput |
| `H06_K10_toplam_fonk.c` | Kavram programı | Kavram programı: döngünün makine kodu | sıfır uyarı | 3.7 (metin, şekil) | 25 (not, şekil), 26 (şekil) | h06-kaput |
| `H06_K11_tampon_temizle.c` | Kavram programı | Kavram programı: giriş tamponu | sıfır uyarı | — | — | h06-girdi-rastgele |
| `H06_K12_rand_srand.c` | Kavram programı | Kavram programı: rand ve srand | sıfır uyarı | 3.6 (metin) | — | h06-girdi-rastgele |
| `H06_K20_izle_toplam.c` | İzleme programı | İzleme programı: 1..n toplamı | sıfır uyarı | 3.5 (metin) | 22 | h06-izleme, h06-izleme (h06-izleyici) |
| `H06_K21_izle_faktoriyel.c` | İzleme programı | İzleme programı: n! | sıfır uyarı | — | — | h06-izleme (h06-izleyici) |
| `H06_K22_izle_basamak.c` | İzleme programı | İzleme programı: basamak toplamı | sıfır uyarı | — | — | h06-izleme (h06-izleyici) |
| `H06_K23_izle_oklid.c` | İzleme programı | İzleme programı: Öklid ile EBOB | sıfır uyarı | — | — | h06-izleme (h06-izleyici) |
| `alistirmalar/H06_A01_cikti_tahmini.c` | Alıştırma 6.1 | Alıştırma 6.1 (★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h06-alistirmalar |
| `alistirmalar/H06_A02_break_continue_tahmin.c` | Alıştırma 6.2 | Alıştırma 6.2 | sıfır uyarı | 8 (alıştırma) | — | h06-alistirmalar |
| `alistirmalar/H06_A03_hata_bul_ortalama.c` | Alıştırma 6.3 | Alıştırma 6.3 (★★, hata bul) | derlenir; kasıtlı uyarı | 8 (alıştırma) | — | h06-alistirmalar |
| `alistirmalar/H06_A04_hata_bul_nobetci.c` | Alıştırma 6.4 | Alıştırma 6.4 (★★, hata bul) | sıfır uyarı; kasıtlı mantık hatası | 8 (alıştırma) | — | h06-alistirmalar |
| `alistirmalar/H06_A05_parsons_basamak.c` | Alıştırma 6.5 | Alıştırma 6.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h06-alistirmalar |
| `alistirmalar/H06_A06_kod_tamamla_katlar.c` | Alıştırma 6.6 | Alıştırma 6.6 (★★, kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h06-alistirmalar |
| `hata_avcisi/H06_HA1_guncelleme_yok.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1 (hatalı, SAF sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 | 44 | h06-hata-avcisi |
| `hata_avcisi/H06_HA1_guncelleme_yok_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 | sıfır uyarı | — | 44 | h06-hata-avcisi |
| `hata_avcisi/H06_HA1_guncelleme_yok_gosterim.c` | Hata Avcısı 1 (tur sınırlı gösterim) | Hata Avcısı 1 (GÖSTERİM) | sıfır uyarı; kasıtlı mantık hatası | — | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA2_govdesiz_for.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 | 45 | h06-hata-avcisi |
| `hata_avcisi/H06_HA2_govdesiz_for_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 | sıfır uyarı | — | 45 | h06-hata-avcisi |
| `hata_avcisi/H06_HA3_bir_fark.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA3_bir_fark_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 | sıfır uyarı | — | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA4_toplayici_sifirlama.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA4_toplayici_sifirlama_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4 | sıfır uyarı | — | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA5_kayan_sayac.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5 (hatalı, SAF sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA5_kayan_sayac_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 | sıfır uyarı | — | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA5_kayan_sayac_gosterim.c` | Hata Avcısı 5 (tur sınırlı gösterim) | Hata Avcısı 5 (GÖSTERİM) | sıfır uyarı; kasıtlı mantık hatası | — | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA6_scanf_harf.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6 (hatalı, SAF sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 | 47 | h06-hata-avcisi |
| `hata_avcisi/H06_HA6_scanf_harf_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 | sıfır uyarı | — | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA6_scanf_harf_gosterim.c` | Hata Avcısı 6 (tur sınırlı gösterim) | Hata Avcısı 6 (GÖSTERİM) | sıfır uyarı; kasıtlı mantık hatası | — | — | h06-hata-avcisi |
| `hata_avcisi/H06_HA7_zune_dongusu.c` | Hata Avcısı 7 (kasıtlı hata) | Hata Avcısı 7 / Gerçek Dünyadan | sıfır uyarı; kasıtlı mantık hatası | 1 | 48 | h06-hata-avcisi |
| `hata_avcisi/H06_HA7_zune_dongusu_duzeltilmis.c` | Hata Avcısı 7 (düzeltilmiş) | Hata Avcısı 7 | sıfır uyarı | 5 (metin) | 49 | h06-hata-avcisi |
| `hata_avcisi/H06_HA7_zune_dongusu_gosterim.c` | Hata Avcısı 7 (tur sınırlı gösterim) | Hata Avcısı 7 (GÖSTERİM) | sıfır uyarı; kasıtlı mantık hatası | — | — | h06-hata-avcisi |
| `proje/mini_obs_v0_6.c` | Mini-OBS v0.6 | /* | sıfır uyarı | 7 | 51 | h06-mini-obs |
| `quiz/H06_Q01_switch_duser.c` | Geri çağırma S1 | Geçen haftadan S1 (H5: switch) | sıfır uyarı | 2 (metin) | 3 | h06-gecen-hafta |
| `quiz/H06_Q02_de_morgan.c` | Geri çağırma S2 | Geçen haftadan S2 (H5: bileşik koşul) | sıfır uyarı | — | 4 | h06-gecen-hafta |
| `quiz/H06_Q03_tek_sans.c` | Geri çağırma S3 | Geçen haftadan S3 (H5: girdi doğrulama) | sıfır uyarı | 2 (metin) | 4 | h06-gecen-hafta |
| `quiz/H06_Q04_while_cikis.c` | Web quiz sorusu | Web quiz: while sonrası sayaç | sıfır uyarı | — | — | h06-quiz |
| `quiz/H06_Q05_geri_sayim.c` | Web quiz sorusu | Web quiz: 3'er geri sayım | sıfır uyarı | — | — | h06-quiz |
| `quiz/H06_Q06_break_continue.c` | Web quiz sorusu | Web quiz: break ve continue | sıfır uyarı | — | — | h06-quiz |
| `quiz/H06_Q07_ters_sayi.c` | Web quiz sorusu | Web quiz: basamaklardan sayı inşası | sıfır uyarı | — | — | h06-quiz |
| `quiz/H06_Q08_sifirlanan_toplam.c` | Web quiz sorusu | Web quiz: toplam döngüsü | sıfır uyarı; kasıtlı mantık hatası | — | — | h06-quiz |
| `quiz/H06_Q09_do_while_bir_kez.c` | Web quiz sorusu | Web quiz: do-while en az bir kez | sıfır uyarı | — | — | h06-quiz |
| `quiz/H06_Q21_kac_kez_lt.c` | “Kaç kez?” serisi | Kaç kez? (< ile 0'dan 10'a) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q22_kac_kez_le.c` | “Kaç kez?” serisi | Kaç kez? (<= ile 0'dan 10'a) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q23_kac_kez_adim2.c` | “Kaç kez?” serisi | Kaç kez? (adım 2) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q24_kac_kez_geri.c` | “Kaç kez?” serisi | Kaç kez? (geri sayım) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q25_kac_kez_geri3.c` | “Kaç kez?” serisi | Kaç kez? (3'er geri sayım) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q26_kac_kez_hic.c` | “Kaç kez?” serisi | Kaç kez? (for, başlangıç 5) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q27_kac_kez_ikiye_kat.c` | “Kaç kez?” serisi | Kaç kez? (ikiye katlama) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q28_kac_kez_do_while.c` | “Kaç kez?” serisi | Kaç kez? (do-while) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q29_kac_kez_govdesiz.c` | “Kaç kez?” serisi | Kaç kez? (for ve süslü parantez) | derlenir; kasıtlı uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q30_kac_kez_break.c` | “Kaç kez?” serisi | Kaç kez? (break) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q31_kac_kez_basamak.c` | “Kaç kez?” serisi | Kaç kez? (basamak döngüsü) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |
| `quiz/H06_Q32_kac_kez_kayan.c` | “Kaç kez?” serisi | Kaç kez? (kayan noktalı koşul) | sıfır uyarı | — | — | h06-kac-kez (h06-kac-kez) |

**Diğer dosyalar**

- `ciktilar/H06_K10_toplam_fonk_gcc_O0_asm.txt`, `…_gcc_O2_asm.txt`, `…_clang_O2_asm.txt` — Kaputun Altında için gerçek assembly çıktıları (`gcc 13.3` / `clang 18.1`, `-S -masm=intel -fno-asynchronous-unwind-tables -fno-pie`).
- `ciktilar/H06_K10_toplam_fonk_gcc_O0_att_asm.txt` — aynı -O0 derlemesi AT&T sözdizimiyle (GCC’nin varsayılanı, `-masm=intel` olmadan); H5’teki gösterimle karşılaştırma için (Kaputun Altında notu).
- `ciktilar/H06_K09_milyar_tur.txt` — N = 10⁹ için `time` ölçümleri (gcc -O0, gcc -O2, clang -O2).
- `proje/mini_obs_v0_6.c` — Mini-OBS v0.6’nın kopyası (asıl yer: `91_Proje_MiniOBS/v0.6/`, testler ve gerçek çıktılar orada).
- `AP1_H06_kodlar.zip` — bu klasörün (`.c`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H06_kodlar/` klasörü oluşur.

Materyalde geçmeyen dosya yoktur.

/* H06_K22_izle_basamak.c — Hafta 6 · İzleme programı: basamak toplamı
 * Amaç   : %10 ve /10 döngüsünün izlenmesi (web "Döngü izleyici")
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K22_izle_basamak.c -o izle_basamak
 */
#include <stdio.h>

int main(void)
{
    int sayi = 2026;
    int toplam = 0;
    while (sayi > 0) {
        toplam += sayi % 10;
        sayi /= 10;
    }
    printf("basamak toplamı = %d\n", toplam);
    return 0;
}

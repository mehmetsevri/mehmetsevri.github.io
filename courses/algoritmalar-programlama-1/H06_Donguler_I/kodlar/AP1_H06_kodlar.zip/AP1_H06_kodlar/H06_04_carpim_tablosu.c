/* H06_04_carpim_tablosu.c — Hafta 6 · Örnek 4 (★): çarpım tablosu
 * Amaç   : sayaç kontrollü döngü (tur sayısı baştan bellidir: 10);
 *          printf alan genişliğiyle hizalı çıktı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_04_carpim_tablosu.c -o carpim_tablosu
 * Örnek  : girdi "7" ->  7 x 10 =   70
 */
#include <stdio.h>

int main(void)
{
    int sayi;
    printf("Hangi sayının çarpım tablosu? ");
    if (scanf("%d", &sayi) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    printf("--- %d için çarpım tablosu ---\n", sayi);
    for (int i = 1; i <= 10; i++) {          /* sayaç kontrollü: tam 10 tur */
        printf("%2d x %2d = %4d\n", sayi, i, sayi * i);
    }
    return 0;
}

/* H06_K08_degismez.c — Hafta 6 · Kavram programı: döngü değişmezi
 * Amaç   : "her turun BAŞINDA toplam = 1 + 2 + ... + (i-1)" önermesini
 *          her turda denetlemek; döngü bitince (i = n+1) önerme
 *          toplam = 1 + ... + n sonucunu verir
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K08_degismez.c -o degismez
 */
#include <stdio.h>

int main(void)
{
    const int N = 5;
    int toplam = 0;

    printf(" i  toplam  (i-1)*i/2  değişmez\n");
    for (int i = 1; i <= N; i++) {
        /* DEĞİŞMEZ: toplam == 1 + 2 + ... + (i-1) == (i-1)*i/2 */
        int beklenen = (i - 1) * i / 2;
        printf("%2d  %6d  %9d  %s\n", i, toplam, beklenen,
               toplam == beklenen ? "korunuyor" : "BOZULDU");
        toplam += i;
    }
    printf("Çıkışta i = %d: toplam = %d = N(N+1)/2 = %d\n",
           N + 1, toplam, N * (N + 1) / 2);
    return 0;
}

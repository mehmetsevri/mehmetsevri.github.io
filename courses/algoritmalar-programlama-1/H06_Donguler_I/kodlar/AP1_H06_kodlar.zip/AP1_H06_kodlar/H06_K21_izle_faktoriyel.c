/* H06_K21_izle_faktoriyel.c — Hafta 6 · İzleme programı: n!
 * Amaç   : çarpım biriktirici deseninin izlenmesi (web "Döngü izleyici")
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K21_izle_faktoriyel.c -o izle_faktoriyel
 */
#include <stdio.h>

int main(void)
{
    int n = 5;
    unsigned long long carpim = 1;
    int i = 2;
    while (i <= n) {
        carpim *= i;
        i++;
    }
    printf("%d! = %llu\n", n, carpim);
    return 0;
}

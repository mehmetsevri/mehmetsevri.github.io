/* H06_11_ebob_ekok.c — Hafta 6 · Örnek 11 (★★): Öklid ile EBOB ve EKOK
 * Amaç   : H02_12'deki algoritmanın adımlarını yazdırmak; EKOK'u
 *          EBOB'dan taşmaya dikkat ederek hesaplamak
 * Kısıt  : a > 0, b > 0
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_11_ebob_ekok.c -o ebob_ekok
 * Örnek  : girdi "48 18" -> EKOK(48, 18) = 144
 */
#include <stdio.h>

int main(void)
{
    int a, b;
    printf("Pozitif iki tamsayı girin: ");
    if (scanf("%d %d", &a, &b) != 2 || a <= 0 || b <= 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int x = a, y = b, adim = 0;
    printf("adım      x      y  x %% y\n");
    while (y != 0) {                    /* her turda y kesin olarak küçülür */
        int r = x % y;
        adim++;
        printf("%4d %6d %6d %6d\n", adim, x, y, r);
        x = y;
        y = r;
    }

    int ebob = x;
    /* önce böl, sonra çarp: ara sonuç küçük kalsın */
    long long ekok = (long long)a / ebob * b;
    printf("EBOB(%d, %d) = %d\n", a, b, ebob);
    printf("EKOK(%d, %d) = %lld\n", a, b, ekok);
    return 0;
}

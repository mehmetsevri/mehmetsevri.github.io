/* H06_K12_rand_srand.c — Hafta 6 · Kavram programı: rand ve srand
 * Amaç   : RAND_MAX değerini görmek; rand() % 100 + 1 ile 1..100 aralığı;
 *          aynı tohumun (srand) aynı diziyi ürettiğini göstermek
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K12_rand_srand.c -o rand_srand
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    printf("RAND_MAX = %d\n", RAND_MAX);

    srand(2026);                        /* sabit tohum */
    printf("srand(2026):");
    for (int i = 1; i <= 5; i++) {
        printf(" %d", rand() % 100 + 1);
    }
    printf("\n");

    srand(2026);                        /* aynı tohum -> aynı dizi */
    printf("srand(2026):");
    for (int i = 1; i <= 5; i++) {
        printf(" %d", rand() % 100 + 1);
    }
    printf("\n");

    srand((unsigned)time(NULL));        /* saate bağlı: her seferinde farklı */
    printf("srand(time): %d\n", rand() % 100 + 1);
    return 0;
}

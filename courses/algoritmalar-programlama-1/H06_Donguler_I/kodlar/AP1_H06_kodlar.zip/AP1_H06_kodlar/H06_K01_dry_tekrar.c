/* H06_K01_dry_tekrar.c — Hafta 6 · Kavram programı: neden döngü? (DRY)
 * Amaç   : aynı kalıbın kopyala-yapıştırla beş kez yazılması ile tek bir
 *          döngüyle yazılmasının karşılaştırılması (Don't Repeat Yourself)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_K01_dry_tekrar.c -o dry_tekrar
 */
#include <stdio.h>

int main(void)
{
    /* Döngüsüz: aynı kalıp beş kez; 500 kayıt olsaydı? */
    printf("%d. öğrenci kaydı işlendi\n", 1);
    printf("%d. öğrenci kaydı işlendi\n", 2);
    printf("%d. öğrenci kaydı işlendi\n", 3);
    printf("%d. öğrenci kaydı işlendi\n", 4);
    printf("%d. öğrenci kaydı işlendi\n", 5);

    printf("---\n");

    /* Döngüyle: kalıp bir kez yazılır, değişen kısım i olur */
    for (int i = 1; i <= 5; i++) {
        printf("%d. öğrenci kaydı işlendi\n", i);
    }
    return 0;
}

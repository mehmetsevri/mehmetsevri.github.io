/* H06_13_sayi_tahmin.c — Hafta 6 · Örnek 13 (★★): sayı tahmin oyunu
 * Amaç   : rand/srand ile 1-100 arası gizli sayı; deneme sayacı, bayrak,
 *          break (bulununca çık) ve continue (geçersiz girdide hak yakma)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_13_sayi_tahmin.c -o sayi_tahmin
 *          Kayıtlı çıktılar yeniden üretilebilir olsun diye sabit tohumla:
 *          gcc ... -DSABIT_TOHUM=2026 H06_13_sayi_tahmin.c -o sayi_tahmin
 * Örnek  : tohum 2026 -> Tebrikler! 6 denemede bildiniz.
 */
#include <stdio.h>
#include <stdlib.h>                     /* rand, srand */
#include <time.h>                       /* time */

int main(void)
{
    const int EN_FAZLA_DENEME = 7;

#ifdef SABIT_TOHUM
    srand(SABIT_TOHUM);                 /* aynı tohum -> aynı gizli sayı */
#else
    srand((unsigned)time(NULL));        /* her çalıştırmada farklı tohum */
#endif
    int gizli = rand() % 100 + 1;       /* 1..100 */

    printf("1-100 arasında bir sayı tuttum. %d hakkınız var.\n",
           EN_FAZLA_DENEME);
    int deneme = 0, bildi = 0;          /* sayaç ve bayrak */
    while (deneme < EN_FAZLA_DENEME) {
        int tahmin;
        printf("Tahmin %d: ", deneme + 1);
        if (scanf("%d", &tahmin) != 1) {
            int c;
            while ((c = getchar()) != '\n' && c != EOF) {
                /* geçersiz satırı at */
            }
            if (c == EOF) {
                break;                  /* girdi bitti: oyunu bitir */
            }
            printf("  Lütfen bir sayı girin.\n");
            continue;                   /* hak düşmeden yeniden sor */
        }
        deneme++;
        if (tahmin == gizli) {
            bildi = 1;
            break;                      /* bulundu: döngüden hemen çık */
        } else if (tahmin < gizli) {
            printf("  Daha BÜYÜK bir sayı deneyin.\n");
        } else {
            printf("  Daha KÜÇÜK bir sayı deneyin.\n");
        }
    }

    if (bildi) {
        printf("Tebrikler! %d denemede bildiniz.\n", deneme);
    } else {
        printf("Oyun bitti. Tuttuğum sayı %d idi.\n", gizli);
    }
    return 0;
}

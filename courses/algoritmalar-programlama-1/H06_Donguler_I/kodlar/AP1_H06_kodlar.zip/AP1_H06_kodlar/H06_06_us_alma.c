/* H06_06_us_alma.c — Hafta 6 · Örnek 6 (★★): tekrarlı çarpma ile üs alma
 * Amaç   : taban^üs değerini döngüyle hesaplamak; üs 0 iken döngü hiç
 *          çalışmaz ve sonuç 1 kalır (x^0 = 1)
 * Kısıt  : üs ≥ 0; sonuç long long aralığında olmalı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_06_us_alma.c -o us_alma
 * Örnek  : girdi "2 10" -> 2^10 = 1024 (10 çarpma)
 */
#include <stdio.h>

int main(void)
{
    int taban, us;
    printf("Taban ve üs (üs >= 0): ");
    if (scanf("%d %d", &taban, &us) != 2 || us < 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    long long sonuc = 1;                /* x^0 = 1: çarpmanın etkisiz elemanı */
    for (int i = 1; i <= us; i++) {
        sonuc *= taban;                 /* her turda bir kez daha çarp */
    }

    printf("%d^%d = %lld (%d çarpma)\n", taban, us, sonuc, us);
    return 0;
}

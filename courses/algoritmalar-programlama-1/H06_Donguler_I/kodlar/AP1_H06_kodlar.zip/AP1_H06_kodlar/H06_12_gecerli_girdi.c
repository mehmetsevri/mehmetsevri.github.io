/* H06_12_gecerli_girdi.c — Hafta 6 · Örnek 12 (★★): geçerli girdi
 *          alınana kadar tekrar
 * Amaç   : do-while ile girdi doğrulama; scanf dönüş değeri (1, 0, EOF);
 *          sayı olmayan girdinin tampondan getchar ile temizlenmesi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H06_12_gecerli_girdi.c -o gecerli_girdi
 * Örnek  : girdi "abc", "150", "-5", "85" -> Kabul edilen puan: 85
 */
#include <stdio.h>

int main(void)
{
    int puan = -1;
    int okunan;                         /* scanf'in dönüş değeri */

    do {
        printf("Puan girin (0-100): ");
        okunan = scanf("%d", &puan);

        if (okunan == EOF) {            /* girdi akışı kapandı */
            printf("\nGirdi sona erdi.\n");
            return 1;
        }
        if (okunan == 0) {              /* sayı değil: karakterler tamponda */
            printf("  Sayı bekleniyordu.\n");
            int c;
            while ((c = getchar()) != '\n' && c != EOF) {
                /* bilinçli boş gövde: satırın kalanını at */
            }
            puan = -1;                  /* geçersiz say: döngü sürsün */
        } else if (puan < 0 || puan > 100) {
            printf("  %d aralık dışında.\n", puan);
        }
    } while (puan < 0 || puan > 100);

    printf("Kabul edilen puan: %d\n", puan);
    return 0;
}

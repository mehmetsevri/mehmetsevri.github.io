/* H07_13_pisagor_ucluleri.c — Hafta 7 · Örnek 13 (★★★): Pisagor üçlüleri
 * Amaç   : kaba kuvvet ve arama uzayı: a² + b² = c² sağlayan tüm
 *          a <= b <= c <= N üçlüleri iç içe ÜÇ döngüyle aranır; ardından
 *          sınırlar daraltılır (c > b; c² hedefi aşınca ve a² + b² > N²
 *          olunca erken çıkış). İki yolun deneme sayıları sayaçla ölçülür.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_13_pisagor_ucluleri.c -o pisagor
 * Örnek  : girdi "30" -> 11 üçlü
 */
#include <stdio.h>

int main(void)
{
    int ust;
    printf("Üst sınır N (1-500): ");
    if (scanf("%d", &ust) != 1 || ust < 1 || ust > 500) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    /* 1) Kaba kuvvet: a <= b <= c <= N olan her üçlüyü dene */
    long long deneme = 0;
    int bulunan = 0;
    for (int a = 1; a <= ust; a++) {
        for (int b = a; b <= ust; b++) {
            for (int c = b; c <= ust; c++) {
                deneme++;
                if (a * a + b * b == c * c) {
                    bulunan++;
                    if (ust <= 30) {  /* küçük N'de listele */
                        printf("(%d, %d, %d) ", a, b, c);
                    }
                }
            }
        }
    }
    printf("\nKaba kuvvet  : %d üçlü, %lld deneme\n", bulunan, deneme);

    /* 2) Daraltılmış arama uzayı */
    long long deneme2 = 0;
    int bulunan2 = 0;
    for (int a = 1; a <= ust; a++) {
        for (int b = a; b <= ust; b++) {
            int hedef = a * a + b * b;
            if (hedef > ust * ust) {
                break;  /* daha büyük b'ler de aşar */
            }
            for (int c = b + 1; c * c <= hedef; c++) {
                deneme2++;
                if (c * c == hedef) {
                    bulunan2++;
                }
            }
        }
    }
    printf("Daraltılmış  : %d üçlü, %lld deneme\n", bulunan2, deneme2);
    return 0;
}

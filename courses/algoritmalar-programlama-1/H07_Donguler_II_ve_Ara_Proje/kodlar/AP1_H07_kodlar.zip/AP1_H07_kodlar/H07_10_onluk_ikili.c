/* H07_10_onluk_ikili.c — Hafta 7 · Örnek 10 (★★): onluk -> ikili dönüşüm
 * Amaç   : ardışık 2'ye bölme: kalanlar en az anlamlı bitten (en sağdan)
 *          başlayarak üretilir, bu yüzden yazıldıkları sıra TERSTİR
 *          ("tersten yazdırma sorunu"; doğal çözümleri H9 özyineleme ve
 *          H10 dizi). Dizisiz geçici çözüm: n'yi aşmayan en büyük 2
 *          kuvvetinden başlayıp aşağı inmek.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_10_onluk_ikili.c -o onluk_ikili
 * Örnek  : girdi "13" -> 13 (onluk) = 1101 (ikili)
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Negatif olmayan bir tamsayı: ");
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    /* 1) Ardışık 2'ye bölme: kalanlar EN SAĞDAKİ bitten başlayarak çıkar */
    printf("Kalanlar (üretildikleri sırayla): ");
    int sayi = n;
    do {  /* n = 0 için de bir kez: "0" */
        printf("%d", sayi % 2);
        sayi /= 2;
    } while (sayi > 0);
    printf("   <- bitler TERS sırada!\n");

    /* 2) Dizisiz geçici çözüm: en büyük 2 kuvvetinden aşağı doğru */
    int kuvvet = 1;
    while (kuvvet <= n / 2) {  /* n'yi aşmayan en büyük 2^k */
        kuvvet *= 2;
    }
    printf("%d (onluk) = ", n);
    sayi = n;
    while (kuvvet > 0) {
        if (sayi >= kuvvet) {
            printf("1");
            sayi -= kuvvet;
        } else {
            printf("0");
        }
        kuvvet /= 2;
    }
    printf(" (ikili)\n");
    return 0;
}

/* H07_K05_clock_temel.c — Hafta 7 · Kavram programı: clock() ile süre ölçümü
 * Amaç   : clock() programın o ana kadar kullandığı İŞLEMCİ zamanını
 *          "saat tıkı" (clock_t) olarak döndürür; iki ölçümün farkı
 *          CLOCKS_PER_SEC'e bölünerek saniyeye çevrilir. Sonuç yazdırılır
 *          ki derleyici ölçülen döngüyü silemesin (H07_K07).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K05_clock_temel.c -o clock_temel
 * Örnek  : -> CLOCKS_PER_SEC = 1000000
 */
#include <stdio.h>
#include <time.h>  /* clock, clock_t, CLOCKS_PER_SEC */

int main(void)
{
    printf("CLOCKS_PER_SEC = %ld\n", (long)CLOCKS_PER_SEC);

    clock_t bas = clock();  /* başlangıç tıkı */
    long long toplam = 0;
    for (int i = 1; i <= 100000000; i++) {
        toplam += i % 7;
    }
    clock_t son = clock();  /* bitiş tıkı */

    double sure = (double)(son - bas) / CLOCKS_PER_SEC;
    printf("toplam = %lld\n", toplam);
    printf("geçen işlemci zamanı = %.3f s (%ld tık)\n",
           sure, (long)(son - bas));
    return 0;
}

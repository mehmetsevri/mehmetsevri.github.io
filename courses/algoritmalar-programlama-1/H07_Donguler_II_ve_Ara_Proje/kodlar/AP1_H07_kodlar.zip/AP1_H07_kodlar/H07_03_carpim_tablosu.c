/* H07_03_carpim_tablosu.c — Hafta 7 · Örnek 3 (★): 10 × 10 çarpım tablosu
 * Amaç   : iç içe döngüyle iki boyutlu, hizalı tablo: başlık satırı,
 *          ayırıcı çizgi ve her hücrede i * j (%4d alan genişliği)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_03_carpim_tablosu.c -o carpim_tablosu
 * Örnek  : son satır ->   10 |  10  20  30  40  50  60  70  80  90 100
 */
#include <stdio.h>

int main(void)
{
    const int N = 10;

    printf("   x |");  /* başlık satırı: sütun no'ları */
    for (int j = 1; j <= N; j++) {
        printf("%4d", j);
    }
    printf("\n-----+");  /* ayırıcı çizgi */
    for (int j = 1; j <= N; j++) {
        printf("----");
    }
    printf("\n");

    for (int i = 1; i <= N; i++) {  /* dış döngü: satır (i) */
        printf("%4d |", i);
        for (int j = 1; j <= N; j++) {  /* iç döngü: sütun (j) */
            printf("%4d", i * j);
        }
        printf("\n");
    }
    return 0;
}

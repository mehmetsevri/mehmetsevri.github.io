/* H07_K02_yineleme_sayilari.c — Hafta 7 · Kavram programı: kaç yineleme?
 * Amaç   : iç döngü sınırına göre toplam yineleme sayısını SAYAÇLA ölçüp
 *          formülle karşılaştırmak (N = 10, 100, 1000):
 *          A) j <= N : N·N   B) j <= i : N(N+1)/2   C) j < i : N(N-1)/2
 *          D) üç katlı 1 <= a <= b <= c <= N : N(N+1)(N+2)/6
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K02_yineleme_sayilari.c -o yineleme_sayilari
 * Örnek  : -> 167167000
 */
#include <stdio.h>

int main(void)
{
    printf("   N    A(j<=N)    B(j<=i)     C(j<i)  D(a<=b<=c)\n");
    for (int n = 10; n <= 1000; n *= 10) {
        long long a = 0, b = 0, c = 0, d = 0;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {  /* A) dikdörtgen */
                a++;
            }
            for (int j = 1; j <= i; j++) {  /* B) üçgen, köşegen dahil */
                b++;
            }
            for (int j = 1; j < i; j++) {  /* C) üçgen, köşegen hariç */
                c++;
            }
            for (int j = i; j <= n; j++) {  /* D) üç katlı: a=i, b=j */
                for (int k = j; k <= n; k++) {
                    d++;
                }
            }
        }
        printf("%4d %10lld %10lld %10lld %11lld\n", n, a, b, c, d);
        printf("formül %8lld %10lld %10lld %11lld\n",
               (long long)n * n, (long long)n * (n + 1) / 2,
               (long long)n * (n - 1) / 2,
               (long long)n * (n + 1) * (n + 2) / 6);
    }
    return 0;
}

/* H07_11_asal_karekok_sure.c — Hafta 7 · Örnek 11 (★★★): iyileştirilmiş
 *          asallık testi (√n sınırı, yalnızca tek bölenler) ve süre ölçümü
 * Amaç   : 0..N arasındaki asalları iki yöntemle sayar ve karşılaştırır:
 *          naif (Örnek 6: d = 2 .. n-1) ve iyileştirilmiş (n < 2 değil,
 *          2 asal, çiftler değil; sonra yalnızca tek d, d <= n / d).
 *          Bölme (yineleme) sayısı sayaçla, süre clock() ile ölçülür.
 *          d * d <= n yerine d <= n / d: büyük n'de d * d taşmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_11_asal_karekok_sure.c -o asal_karekok_sure
 * Örnek  : girdi "100000" -> 9592
 */
#include <stdio.h>
#include <time.h>  /* clock, clock_t, CLOCKS_PER_SEC */

int main(void)
{
    int ust;
    printf("Üst sınır N (2-200000): ");
    if (scanf("%d", &ust) != 1 || ust < 2 || ust > 200000) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    /* ---- 1) Naif yöntem (Örnek 6) ---- */
    long long naif_bolme = 0;
    int naif_adet = 0;
    clock_t bas = clock();
    for (int n = 0; n <= ust; n++) {
        int asal = 1;
        if (n < 2) {
            asal = 0;
        } else {
            for (int d = 2; d < n; d++) {
                naif_bolme++;
                if (n % d == 0) {
                    asal = 0;
                    break;
                }
            }
        }
        naif_adet += asal;
    }
    double naif_sn = (double)(clock() - bas) / CLOCKS_PER_SEC;

    /* ---- 2) İyileştirilmiş: √n sınırı ve yalnızca tek bölenler ---- */
    long long iyi_bolme = 0;
    int iyi_adet = 0;
    bas = clock();
    for (int n = 0; n <= ust; n++) {
        int asal = 1;
        if (n < 2) {
            asal = 0;  /* 0 ve 1 asal değil */
        } else if (n == 2) {
            asal = 1;  /* tek çift asal */
        } else if (n % 2 == 0) {
            asal = 0;  /* 2'den büyük çiftler */
        } else {
            for (int d = 3; d <= n / d; d += 2) {  /* d <= √n, d tek */
                iyi_bolme++;
                if (n % d == 0) {
                    asal = 0;
                    break;
                }
            }
        }
        iyi_adet += asal;
    }
    double iyi_sn = (double)(clock() - bas) / CLOCKS_PER_SEC;

    printf("  asal          bölme   süre (s)  yöntem\n");
    printf("%6d %14lld %10.4f  naif (d < n)\n",
           naif_adet, naif_bolme, naif_sn);
    printf("%6d %14lld %10.4f  √n + yalnızca tek bölenler\n",
           iyi_adet, iyi_bolme, iyi_sn);
    printf("Bölme oranı: %.0f kat daha az yineleme\n",
           (double)naif_bolme / iyi_bolme);
    return 0;
}

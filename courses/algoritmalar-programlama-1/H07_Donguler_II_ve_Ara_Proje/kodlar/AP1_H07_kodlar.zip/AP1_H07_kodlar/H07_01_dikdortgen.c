/* H07_01_dikdortgen.c — Hafta 7 · Örnek 1 (★): n × m yıldız dikdörtgeni
 * Amaç   : iç içe döngünün temel yapısı: dış döngü SATIRLARI, iç döngü
 *          bir satırdaki SÜTUNLARI dolaşır; iç gövde satir × sutun kez çalışır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_01_dikdortgen.c -o dikdortgen
 * Örnek  : girdi "3 5" -> Toplam yineleme: 15 (3 x 5)
 */
#include <stdio.h>

int main(void)
{
    int satir, sutun;
    printf("Satır ve sütun sayısı: ");
    if (scanf("%d %d", &satir, &sutun) != 2 || satir < 1 || sutun < 1) {
        printf("Geçersiz girdi: iki pozitif tamsayı girin.\n");
        return 1;
    }

    int yineleme = 0;                       /* iç gövdenin kaç kez çalıştığı */
    for (int i = 1; i <= satir; i++) {      /* dış döngü: her tur bir SATIR */
        for (int j = 1; j <= sutun; j++) {  /* iç döngü: her tur bir SÜTUN */
            printf("*");
            yineleme++;
        }
        printf("\n");  /* satır bitti: alt satıra geç */
    }
    printf("Toplam yineleme: %d (%d x %d)\n", yineleme, satir, sutun);
    return 0;
}

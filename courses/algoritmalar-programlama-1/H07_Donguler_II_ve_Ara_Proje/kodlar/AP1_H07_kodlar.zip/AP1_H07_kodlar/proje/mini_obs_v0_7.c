/*
 * mini_obs_v0_7.c — Mini-OBS v0.7 (AP-1 Hafta 7 · ara proje)
 * Yenilik : Menü güdümlü ana döngü (do-while + switch):
 *             1) Not girişi (bir öğrenci)  2) Sınıf istatistikleri  3) Çıkış
 *           Menü seçimi de doğrulanır (sayı olmayan ya da 1-3 dışı seçim).
 *           Program artık bir kez çalışıp bitmez; kullanıcı çıkış seçene
 *           kadar öğrenci eklenebilir ve istatistikler istenildiği an görülür.
 *           Dizi yok: istatistikler v0.6'daki gibi akış hâlinde tutulur.
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107), Madde 30: %40 vize + %60 final;
 *           final < 50 → FF; AA 90-100, BA 81-89, BB 73-80, CB 66-72,
 *           CC 60-65 başarılı; DC 50-59 şartlı (YANO ≥ 2,00 ise);
 *           DD 40-49, FD 30-39, FF 0-29 başarısız. Yuvarlama: (int)(ort + 0.5)
 * Kavramlar: menü döngüsü (do-while + switch), iç içe döngü (menü döngüsünün
 *           içinde doğrulama döngüleri), switch içindeki break ile döngüden
 *           çıkış farkı, bayrak (devam), akış hâlinde istatistik
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g mini_obs_v0_7.c -o mini_obs
 */

#include <stdio.h>

int main(void)
{
    const double VIZE_AGIRLIK = 0.40;
    const double FINAL_AGIRLIK = 0.60;
    const int GECME_ORTALAMA = 60;       /* CC ve üzeri: başarılı */
    const int SARTLI_ORTALAMA = 50;      /* DC: şartlı başarılı */
    const int FINAL_BARAJI = 50;         /* yarıyıl sonu sınavında en az 50 */

    /* Akış hâlinde istatistik (v0.6): sayaç, toplayıcı, en iyi adaylar */
    int kayit = 0;                                  /* girilen öğrenci sayısı */
    double toplam_ortalama = 0.0;
    int basarili = 0, sartli = 0;
    double en_yuksek = 0.0, en_dusuk = 0.0;
    long long en_yuksek_no = 0, en_dusuk_no = 0;

    int secim = 0, okunan, c;

    printf("==========================================\n");
    printf("  MİNİ-OBS v0.7 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");

    do {                                            /* ANA MENÜ DÖNGÜSÜ */
        printf("\n---------------- ANA MENÜ ----------------\n");
        printf("  1) Not girişi (bir öğrenci)\n");
        printf("  2) Sınıf istatistikleri\n");
        printf("  3) Çıkış\n");
        printf("Seçiminiz (1-3)  : ");
        okunan = scanf("%d", &secim);
        if (okunan == EOF) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }
        if (okunan == 0) {                          /* sayı değil */
            while ((c = getchar()) != '\n' && c != EOF) {
                /* satırın kalanını at */
            }
            secim = 0;                              /* geçersiz seçim */
        }

        switch (secim) {
        case 1: {                                   /* ---- NOT GİRİŞİ ---- */
            long long numara = 0;
            double vize = -1.0, final = -1.0;
            printf("\n------------ ÖĞRENCİ %d ------------\n", kayit + 1);

            do {                                    /* iç döngü: numara */
                printf("Öğrenci numarası : ");
                okunan = scanf("%lld", &numara);
                if (okunan == EOF) {
                    printf("\nGirdi sona erdi.\n");
                    return 1;
                }
                if (okunan == 0) {
                    while ((c = getchar()) != '\n' && c != EOF) {
                        /* satırın kalanını at */
                    }
                    numara = 0;
                }
                if (numara <= 0) {
                    printf("  Geçersiz: pozitif bir numara girin.\n");
                }
            } while (numara <= 0);

            do {                                    /* iç döngü: vize */
                printf("Vize notu        : ");
                okunan = scanf("%lf", &vize);
                if (okunan == EOF) {
                    printf("\nGirdi sona erdi.\n");
                    return 1;
                }
                if (okunan == 0) {
                    while ((c = getchar()) != '\n' && c != EOF) {
                        /* satırın kalanını at */
                    }
                    vize = -1.0;
                }
                if (vize < 0 || vize > 100) {
                    printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
                }
            } while (vize < 0 || vize > 100);

            do {                                    /* iç döngü: final */
                printf("Final notu       : ");
                okunan = scanf("%lf", &final);
                if (okunan == EOF) {
                    printf("\nGirdi sona erdi.\n");
                    return 1;
                }
                if (okunan == 0) {
                    while ((c = getchar()) != '\n' && c != EOF) {
                        /* satırın kalanını at */
                    }
                    final = -1.0;
                }
                if (final < 0 || final > 100) {
                    printf("  Geçersiz: 0 ile 100 arasında bir sayı girin.\n");
                }
            } while (final < 0 || final > 100);

            double ortalama = VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
            int yuvarlanmis = (int)(ortalama + 0.5);
            printf("Öğrenci no  : %lld\n", numara);
            printf("Vize  (%%40) : %6.2f\n", vize);
            printf("Final (%%60) : %6.2f\n", final);
            printf("Ortalama    : %6.2f\n", ortalama);
            printf("Yuvarlanmış : %3d\n", yuvarlanmis);

            printf("Harf notu   : ");
            if (final < FINAL_BARAJI) {
                printf("FF\n");
            } else if (yuvarlanmis >= 90) {
                printf("AA\n");
            } else if (yuvarlanmis >= 81) {
                printf("BA\n");
            } else if (yuvarlanmis >= 73) {
                printf("BB\n");
            } else if (yuvarlanmis >= 66) {
                printf("CB\n");
            } else if (yuvarlanmis >= 60) {
                printf("CC\n");
            } else if (yuvarlanmis >= 50) {
                printf("DC\n");
            } else if (yuvarlanmis >= 40) {
                printf("DD\n");
            } else if (yuvarlanmis >= 30) {
                printf("FD\n");
            } else {
                printf("FF\n");
            }
            printf("Durum       : ");
            if (final < FINAL_BARAJI) {
                printf("BAŞARISIZ (final barajı)\n");
            } else if (yuvarlanmis >= GECME_ORTALAMA) {
                printf("BAŞARILI\n");
                basarili++;
            } else if (yuvarlanmis >= SARTLI_ORTALAMA) {
                printf("ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)\n");
                sartli++;
            } else {
                printf("BAŞARISIZ\n");
            }

            kayit++;                                /* akış hâlinde istatistik */
            toplam_ortalama += ortalama;
            if (kayit == 1 || ortalama > en_yuksek) {
                en_yuksek = ortalama;
                en_yuksek_no = numara;
            }
            if (kayit == 1 || ortalama < en_dusuk) {
                en_dusuk = ortalama;
                en_dusuk_no = numara;
            }
            break;                                  /* switch'ten çıkar, döngüden değil */
        }
        case 2:                                     /* ---- İSTATİSTİKLER ---- */
            if (kayit == 0) {
                printf("  Henüz kayıt yok: önce 1) Not girişi.\n");
                break;
            }
            printf("\n--------------- SINIF ÖZETİ ---------------\n");
            printf("Öğrenci sayısı   : %d\n", kayit);
            printf("Sınıf ortalaması : %6.2f\n", toplam_ortalama / kayit);
            printf("En yüksek        : %6.2f (%lld)\n", en_yuksek, en_yuksek_no);
            printf("En düşük         : %6.2f (%lld)\n", en_dusuk, en_dusuk_no);
            printf("Başarılı (CC+)   : %d / %d\n", basarili, kayit);
            printf("Şartlı (DC)      : %d / %d\n", sartli, kayit);
            printf("-------------------------------------------\n");
            break;
        case 3:                                     /* ---- ÇIKIŞ ---- */
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n", kayit);
            break;
        default:
            printf("  Geçersiz seçim: 1, 2 ya da 3 girin.\n");
            break;
        }
    } while (secim != 3);                           /* nöbetçi: 3 = çıkış */

    return 0;
}

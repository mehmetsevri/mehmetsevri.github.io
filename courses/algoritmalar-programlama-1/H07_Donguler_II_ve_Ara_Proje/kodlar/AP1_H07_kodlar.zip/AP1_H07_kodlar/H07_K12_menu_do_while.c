/* H07_K12_menu_do_while.c — Hafta 7 · Kavram programı: menü döngüsü (do-while)
 * Amaç   : menü en az bir kez gösterilir (do-while); seçim switch ile
 *          dağıtılır. case içindeki break yalnızca SWITCH'ten çıkar; menüyü
 *          bitiren, döngü koşulundaki nöbetçi seçimdir (0).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K12_menu_do_while.c -o menu_do_while
 * Örnek  : girdi "1 1 3 7 2 3 0" -> sayac = 1
 */
#include <stdio.h>

int main(void)
{
    int sayac = 0;
    int secim;
    do {
        printf("[1] Artır [2] Azalt [3] Göster [0] Çıkış > ");
        if (scanf("%d", &secim) != 1) {
            printf("Girdi okunamadı.\n");
            return 1;
        }
        switch (secim) {
        case 1:
            sayac++;
            break;  /* yalnızca switch'ten çıkar */
        case 2:
            sayac--;
            break;
        case 3:
            printf("sayac = %d\n", sayac);
            break;
        case 0:
            printf("Güle güle.\n");
            break;
        default:
            printf("Geçersiz seçim: %d\n", secim);
            break;
        }
    } while (secim != 0);  /* menüyü bitiren: döngü koşulu */
    return 0;
}

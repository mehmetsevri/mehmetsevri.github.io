/* H07_08_mukemmel_armstrong.c — Hafta 7 · Örnek 8 (★★): mükemmel sayılar ve
 *          Armstrong sayıları
 * Amaç   : (1) bölen toplamı: kendisi hariç bölenlerinin toplamı kendisine
 *          eşit olan sayılar; (2) basamak üsleri: k basamaklı bir sayının
 *          basamaklarının k. kuvvetleri toplamı kendisine eşit olan sayılar
 *          (üç katmanlı iç içe döngü: aday -> basamak -> kuvvet)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_08_mukemmel_armstrong.c -o mukemmel_armstrong
 * Örnek  : -> 28 = 1 + 2 + 4 + 7 + 14
 */
#include <stdio.h>

int main(void)
{
    const int UST = 10000;
    const int ARM_UST = 99999;

    /* 1) Mükemmel sayılar */
    printf("%d'e kadar mükemmel sayılar:\n", UST);
    for (int n = 2; n <= UST; n++) {
        int toplam = 0;                     /* her aday için SIFIRDAN */
        for (int d = 1; d <= n / 2; d++) {  /* n/2'den büyük öz bölen yok */
            if (n % d == 0) {
                toplam += d;
            }
        }
        if (toplam == n) {
            printf("%d = 1", n);
            for (int d = 2; d <= n / 2; d++) {  /* bölenleri yeniden yaz */
                if (n % d == 0) {
                    printf(" + %d", d);
                }
            }
            printf("\n");
        }
    }

    /* 2) Armstrong sayıları */
    printf("1-%d arasındaki Armstrong sayıları:\n", ARM_UST);
    for (int n = 1; n <= ARM_UST; n++) {
        int k = 0;  /* basamak sayısı */
        for (int s = n; s > 0; s /= 10) {
            k++;
        }
        int toplam = 0;
        for (int s = n; s > 0; s /= 10) {  /* her basamak için */
            int basamak = s % 10;
            int kuvvet = 1;
            for (int e = 1; e <= k; e++) {  /* basamak^k: tekrarlı çarpma */
                kuvvet *= basamak;
            }
            toplam += kuvvet;
        }
        if (toplam == n) {
            printf(" %d", n);
        }
    }
    printf("\n");
    return 0;
}

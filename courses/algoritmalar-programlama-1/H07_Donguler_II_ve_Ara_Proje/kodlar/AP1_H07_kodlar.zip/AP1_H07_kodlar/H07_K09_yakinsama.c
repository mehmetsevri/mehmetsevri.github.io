/* H07_K09_yakinsama.c — Hafta 7 · Kavram programı: yakınsama verisi
 * Amaç   : ilk n terimle e (Σ 1/k!) ve π (Leibniz) yaklaşımlarının mutlak
 *          hatası; n = 1..10 ve 16, 32, ..., 1048576 için yazılır
 *          (yakınsama grafiği bu çıktıdan çizilir)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K09_yakinsama.c -o yakinsama
 * Örnek  : -> 1048576
 */
#include <stdio.h>

int main(void)
{
    const double E_GERCEK = 2.718281828459045;
    const double PI_GERCEK = 3.141592653589793;
    const int SON = 1048576;  /* 2^20 terim */

    double e = 0.0, terim = 1.0;  /* terim = 1/k! */
    double pi = 0.0, isaret = 1.0;
    int yazim = 16;  /* 10'dan sonra 16, 32, 64, ... */

    printf("  terim     e hatası     π hatası\n");
    for (int n = 1; n <= SON; n++) {  /* n = toplanan terim sayısı */
        int k = n - 1;                /* bu turda eklenen terimin sırası */
        e += terim;
        terim /= n;  /* 1/k! -> 1/(k+1)! */
        pi += isaret * 4.0 / (2 * k + 1);
        isaret = -isaret;
        if (n <= 10 || n == yazim) {
            double he = e - E_GERCEK;
            double hp = pi - PI_GERCEK;
            if (he < 0) {
                he = -he;
            }
            if (hp < 0) {
                hp = -hp;
            }
            printf("%7d  %11.3e  %11.3e\n", n, he, hp);
            if (n == yazim) {
                yazim *= 2;
            }
        }
    }
    return 0;
}

/* H07_K01_izgara_sayac.c — Hafta 7 · Kavram programı: ızgara modeli
 * Amaç   : iç içe döngünün çalışma sırası: dış döngünün HER turunda iç
 *          döngü baştan sona çalışır; her (i, j) çifti ızgarada bir hücre,
 *          yani iç gövdenin bir yinelemesidir (3 x 4 = 12 hücre)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K01_izgara_sayac.c -o izgara_sayac
 * Örnek  : -> İç gövde 12 kez çalıştı = 3 x 4
 */
#include <stdio.h>

int main(void)
{
    const int SATIR = 3;
    const int SUTUN = 4;
    int adim = 0;

    for (int i = 0; i < SATIR; i++) {      /* dış: yavaş değişir */
        for (int j = 0; j < SUTUN; j++) {  /* iç: hızlı değişir */
            adim++;
            printf("(%d,%d) ", i, j);
        }
        printf("<- i = %d satırı bitti\n", i);
    }
    printf("İç gövde %d kez çalıştı = %d x %d\n", adim, SATIR, SUTUN);
    return 0;
}

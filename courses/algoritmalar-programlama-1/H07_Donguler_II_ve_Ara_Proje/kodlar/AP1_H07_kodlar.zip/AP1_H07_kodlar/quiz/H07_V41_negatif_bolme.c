/* H07_V41_negatif_bolme.c — Hafta 7 · Vize hazırlık soru bankası (H4: tamsayı bölmesi ve kalan)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V41_negatif_bolme.c -o v41
 */
#include <stdio.h>

int main(void)
{
    printf("%d %d\n", -7 / 2, -7 % 2);
    return 0;
}

/* H07_Q17_fibonacci_pencere.c — Hafta 7 · Kendini sına S7
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q17_fibonacci_pencere.c -o q17
 */
#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 1;
    for (int i = 0; i < 5; i++) {
        int c = a + b;
        a = b;
        b = c;
    }
    printf("%d %d\n", a, b);
    return 0;
}

/* H07_V74_break_kosegen.c — Hafta 7 · Vize hazırlık soru bankası (H7: iç içe döngüde break)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V74_break_kosegen.c -o v74
 */
#include <stdio.h>

int main(void)
{
    int t = 0;
    for (int i = 1; i <= 3; i++) {
        for (int j = 1; j <= 3; j++) {
            if (i == j) {
                break;
            }
            t += 10 * i + j;
        }
    }
    printf("%d\n", t);
    return 0;
}

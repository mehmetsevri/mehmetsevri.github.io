/* H07_Q01_dongu_turleri.c — Hafta 7 · Geçen haftadan S1 (H6: üç döngü)
 * Soru   : Program ne yazdırır? (her döngünün gövdesi kaç kez çalışır?)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q01_dongu_turleri.c -o q01
 */
#include <stdio.h>

int main(void)
{
    int a = 5;
    int b = 5;
    while (a < 3) {
        printf("W");
        a++;
    }
    do {
        printf("D");
        b++;
    } while (b < 3);
    for (int c = 0; c < 3; c += 2) {
        printf("F");
    }
    printf(" %d %d\n", a, b);
    return 0;
}

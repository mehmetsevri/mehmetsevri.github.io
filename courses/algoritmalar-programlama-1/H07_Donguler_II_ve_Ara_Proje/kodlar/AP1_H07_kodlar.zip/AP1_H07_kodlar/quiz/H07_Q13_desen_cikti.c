/* H07_Q13_desen_cikti.c — Hafta 7 · Kendini sına S3
 * Soru   : Program hangi deseni yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q13_desen_cikti.c -o q13
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 3; i++) {
        for (int j = i; j <= 3; j++) {
            printf("%d", j);
        }
        printf("\n");
    }
    return 0;
}

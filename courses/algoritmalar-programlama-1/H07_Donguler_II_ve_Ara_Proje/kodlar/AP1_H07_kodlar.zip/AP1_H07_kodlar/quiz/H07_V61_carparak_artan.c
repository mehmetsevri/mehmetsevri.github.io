/* H07_V61_carparak_artan.c — Hafta 7 · Vize hazırlık soru bankası (H6: for döngüsünde güncelleme)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V61_carparak_artan.c -o v61
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i < 20; i *= 3) {
        printf("%d ", i);
    }
    printf("\n");
    return 0;
}

/* H07_Q19_menu_switch_break.c — Hafta 7 · Kendini sına S9
 * Soru   : Girdi "1 4 2 0" için program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q19_menu_switch_break.c -o q19
 */
#include <stdio.h>

int main(void)
{
    int secim;
    int tur = 0;
    do {
        tur++;
        if (scanf("%d", &secim) != 1) {
            break;
        }
        switch (secim) {
        case 1:
            printf("A");
            break;
        case 2:
            printf("B");
            break;
        default:
            printf("?");
            break;
        }
    } while (secim != 0);
    printf(" tur = %d\n", tur);
    return 0;
}

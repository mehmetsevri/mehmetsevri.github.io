/* H07_V71_ic_ice_j_kucuk_i.c — Hafta 7 · Vize hazırlık soru bankası (H7: iç içe döngüde yineleme sayısı)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V71_ic_ice_j_kucuk_i.c -o v71
 */
#include <stdio.h>

int main(void)
{
    int sayac = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < i; j++) {
            sayac++;
        }
    }
    printf("%d\n", sayac);
    return 0;
}

/* H07_Q12_ucgen_sayac.c — Hafta 7 · Kendini sına S2
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q12_ucgen_sayac.c -o q12
 */
#include <stdio.h>

int main(void)
{
    int sayac = 0;
    for (int i = 1; i <= 6; i++) {
        for (int j = i; j <= 6; j++) {
            sayac++;
        }
    }
    printf("%d\n", sayac);
    return 0;
}

/* H07_V62_break_continue.c — Hafta 7 · Vize hazırlık soru bankası (H6: break ve continue)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V62_break_continue.c -o v62
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 6; i++) {
        if (i % 2 == 0) {
            continue;
        }
        if (i == 5) {
            break;
        }
        printf("%d", i);
    }
    printf("\n");
    return 0;
}

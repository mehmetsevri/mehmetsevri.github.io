/* H07_Q02_nobetci_toplam.c — Hafta 7 · Geçen haftadan S2 (H6: nöbetçi değer)
 * Soru   : Girdi "4 7 -1 9" için program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q02_nobetci_toplam.c -o q02
 */
#include <stdio.h>

int main(void)
{
    int x;
    int toplam = 0;
    int adet = 0;
    printf("Sayılar (-1 ile bitir): ");
    while (scanf("%d", &x) == 1 && x != -1) {
        toplam += x;  /* toplayıcı */
        adet++;       /* sayaç */
    }
    printf("adet = %d, toplam = %d\n", adet, toplam);
    return 0;
}

/* H07_V11_kacis_dizileri.c — Hafta 7 · Vize hazırlık soru bankası (H1: kaçış dizileri)
 * Soru   : Program kaç satır yazdırır, ikinci satır nedir?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V11_kacis_dizileri.c -o v11
 */
#include <stdio.h>

int main(void)
{
    printf("1\t2\n3\\n4\n");
    return 0;
}

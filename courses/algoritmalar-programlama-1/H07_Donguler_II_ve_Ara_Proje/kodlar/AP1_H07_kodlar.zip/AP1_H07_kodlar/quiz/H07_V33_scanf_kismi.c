/* H07_V33_scanf_kismi.c — Hafta 7 · Vize hazırlık soru bankası (H3: scanf dönüş değeri)
 * Soru   : Girdi "5 x" için ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V33_scanf_kismi.c -o v33
 */
#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 0;
    int r = scanf("%d %d", &a, &b);
    printf("r = %d, a = %d, b = %d\n", r, a, b);
    return 0;
}

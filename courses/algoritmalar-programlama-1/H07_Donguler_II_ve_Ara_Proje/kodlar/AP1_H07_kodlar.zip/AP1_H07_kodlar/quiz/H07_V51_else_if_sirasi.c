/* H07_V51_else_if_sirasi.c — Hafta 7 · Vize hazırlık soru bankası (H5: else-if zincirinde sıra)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V51_else_if_sirasi.c -o v51
 */
#include <stdio.h>

int main(void)
{
    int puan = 85;
    if (puan >= 60) {
        printf("CC+\n");
    } else if (puan >= 80) {
        printf("BA+\n");
    } else {
        printf("Diğer\n");
    }
    return 0;
}

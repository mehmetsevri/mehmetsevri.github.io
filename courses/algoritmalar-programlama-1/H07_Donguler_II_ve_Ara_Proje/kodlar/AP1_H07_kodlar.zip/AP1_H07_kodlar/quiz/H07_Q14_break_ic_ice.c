/* H07_Q14_break_ic_ice.c — Hafta 7 · Kendini sına S4
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q14_break_ic_ice.c -o q14
 */
#include <stdio.h>

int main(void)
{
    int sayac = 0;
    for (int i = 1; i <= 3; i++) {
        for (int j = 1; j <= 3; j++) {
            if (j == 2) {
                break;
            }
            sayac++;
        }
    }
    printf("%d\n", sayac);
    return 0;
}

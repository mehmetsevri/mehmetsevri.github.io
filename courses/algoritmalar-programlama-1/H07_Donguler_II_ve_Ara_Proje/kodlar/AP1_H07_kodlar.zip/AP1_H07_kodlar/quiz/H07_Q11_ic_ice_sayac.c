/* H07_Q11_ic_ice_sayac.c — Hafta 7 · Kendini sına S1
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q11_ic_ice_sayac.c -o q11
 */
#include <stdio.h>

int main(void)
{
    int sayac = 0;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 6; j++) {
            sayac++;
        }
    }
    printf("%d\n", sayac);
    return 0;
}

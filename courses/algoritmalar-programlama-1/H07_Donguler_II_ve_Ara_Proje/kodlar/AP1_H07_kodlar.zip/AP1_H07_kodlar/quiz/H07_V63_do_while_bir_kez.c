/* H07_V63_do_while_bir_kez.c — Hafta 7 · Vize hazırlık soru bankası (H6: do-while)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V63_do_while_bir_kez.c -o v63
 */
#include <stdio.h>

int main(void)
{
    int k = 10;
    do {
        printf("%d ", k);
        k++;
    } while (k < 5);
    printf("| k = %d\n", k);
    return 0;
}

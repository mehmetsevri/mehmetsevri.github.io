/* H07_Q16_tam_bolme_seri.c — Hafta 7 · Kendini sına S6
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q16_tam_bolme_seri.c -o q16
 */
#include <stdio.h>

int main(void)
{
    double toplam = 0.0;
    for (int k = 1; k <= 4; k++) {
        toplam += 1 / k;
    }
    printf("%.2f\n", toplam);
    return 0;
}

/* H07_V42_sonek_artirma.c — Hafta 7 · Vize hazırlık soru bankası (H4: sonek ++)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V42_sonek_artirma.c -o v42
 */
#include <stdio.h>

int main(void)
{
    int i = 3;
    int j = i++ * 2;
    printf("%d %d\n", i, j);
    return 0;
}

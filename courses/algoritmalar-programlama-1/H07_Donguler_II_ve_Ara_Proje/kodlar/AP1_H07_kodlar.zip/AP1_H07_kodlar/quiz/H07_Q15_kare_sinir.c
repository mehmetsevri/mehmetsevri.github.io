/* H07_Q15_kare_sinir.c — Hafta 7 · Kendini sına S5
 * Soru   : Program ne yazdırır? (koşuldaki < işaretine dikkat)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q15_kare_sinir.c -o q15
 */
#include <stdio.h>

int main(void)
{
    for (int n = 1; n <= 9; n += 4) {
        int asal = (n >= 2);
        for (int d = 2; d * d < n; d++) {
            if (n % d == 0) {
                asal = 0;
                break;
            }
        }
        printf("%d:%d ", n, asal);
    }
    printf("\n");
    return 0;
}

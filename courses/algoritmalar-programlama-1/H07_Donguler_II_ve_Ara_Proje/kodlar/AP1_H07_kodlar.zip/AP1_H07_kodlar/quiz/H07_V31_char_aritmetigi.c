/* H07_V31_char_aritmetigi.c — Hafta 7 · Vize hazırlık soru bankası (H3: char bir tamsayıdır)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V31_char_aritmetigi.c -o v31
 */
#include <stdio.h>

int main(void)
{
    char c = 'A' + 2;
    printf("%c %d\n", c, c);
    return 0;
}

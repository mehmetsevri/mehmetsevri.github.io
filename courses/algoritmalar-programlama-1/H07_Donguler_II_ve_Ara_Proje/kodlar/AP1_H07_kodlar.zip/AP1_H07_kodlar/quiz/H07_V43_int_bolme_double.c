/* H07_V43_int_bolme_double.c — Hafta 7 · Vize hazırlık soru bankası (H4: tamsayı bölmesi ve tip dönüşümü)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V43_int_bolme_double.c -o v43
 */
#include <stdio.h>

int main(void)
{
    double x = 7 / 2;
    double y = (double)7 / 2;
    printf("%.1f %.1f\n", x, y);
    return 0;
}

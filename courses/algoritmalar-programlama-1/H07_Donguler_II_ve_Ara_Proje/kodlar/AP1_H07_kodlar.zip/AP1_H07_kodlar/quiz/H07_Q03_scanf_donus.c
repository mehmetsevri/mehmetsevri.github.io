/* H07_Q03_scanf_donus.c — Hafta 7 · Geçen haftadan S3 (H6: scanf dönüş değeri)
 * Soru   : Kullanıcı "abc" yazarsa ne yazdırılır? Ctrl+D (dosya sonu) basılırsa?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q03_scanf_donus.c -o q03
 */
#include <stdio.h>

int main(void)
{
    int n = 7;
    printf("Bir sayı: ");
    int r = scanf("%d", &n);
    printf("r = %d, n = %d\n", r, n);
    return 0;
}

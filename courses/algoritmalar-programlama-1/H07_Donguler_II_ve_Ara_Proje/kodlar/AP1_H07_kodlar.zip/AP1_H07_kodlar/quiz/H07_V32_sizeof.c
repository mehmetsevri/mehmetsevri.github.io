/* H07_V32_sizeof.c — Hafta 7 · Vize hazırlık soru bankası (H3: veri tiplerinin boyutu)
 * Soru   : Bu makinede (x86-64 Linux, gcc) ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V32_sizeof.c -o v32
 */
#include <stdio.h>

int main(void)
{
    printf("%zu %zu %zu\n", sizeof(char), sizeof(int), sizeof(double));
    return 0;
}

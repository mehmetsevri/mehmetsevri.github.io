/* H07_V22_oklid_tur.c — Hafta 7 · Vize hazırlık soru bankası (H2: Öklid algoritması ve izleme)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V22_oklid_tur.c -o v22
 */
#include <stdio.h>

int main(void)
{
    int a = 48;
    int b = 18;
    int tur = 0;
    while (b != 0) {
        int k = a % b;
        a = b;
        b = k;
        tur++;
    }
    printf("%d %d\n", a, tur);
    return 0;
}

/* H07_V44_kisa_devre.c — Hafta 7 · Vize hazırlık soru bankası (H4: kısa devre değerlendirme)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V44_kisa_devre.c -o v44
 */
#include <stdio.h>

int main(void)
{
    int a = 0;
    int b = 5;
    if (a != 0 && b / a > 1) {
        printf("X\n");
    } else {
        printf("Y\n");
    }
    return 0;
}

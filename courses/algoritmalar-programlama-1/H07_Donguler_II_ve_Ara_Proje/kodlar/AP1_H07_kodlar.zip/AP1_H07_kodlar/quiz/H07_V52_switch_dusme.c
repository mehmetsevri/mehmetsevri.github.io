/* H07_V52_switch_dusme.c — Hafta 7 · Vize hazırlık soru bankası (H5: switch ve düşme)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_V52_switch_dusme.c -o v52
 */
#include <stdio.h>

int main(void)
{
    int g = 3;
    switch (g) {
    case 3:
        printf("Ç");
        /* fall through - bilinçli düşme */
    case 4:
        printf("P");
        break;
    default:
        printf("X");
        break;
    }
    printf("\n");
    return 0;
}

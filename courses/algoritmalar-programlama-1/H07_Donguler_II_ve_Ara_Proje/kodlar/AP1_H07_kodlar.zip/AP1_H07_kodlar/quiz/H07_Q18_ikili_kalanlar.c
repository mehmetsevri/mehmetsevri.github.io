/* H07_Q18_ikili_kalanlar.c — Hafta 7 · Kendini sına S8
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_Q18_ikili_kalanlar.c -o q18
 */
#include <stdio.h>

int main(void)
{
    int n = 6;
    while (n > 0) {
        printf("%d", n % 2);
        n /= 2;
    }
    printf("\n");
    return 0;
}

/* H07_K10_sin_taylor.c — Hafta 7 · Kavram programı: sin x (Taylor serisi)
 * Amaç   : sin x = x - x³/3! + x⁵/5! - ...  ; her terim bir öncekinden
 *          t(k+1) = -t(k) · x² / ((2k+2)(2k+3)) ile elde edilir; |terim| < ε
 *          olunca döngü biter. Sonuç math.h'deki sin() ile karşılaştırılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K10_sin_taylor.c -o sin_taylor -lm
 * Örnek  : girdi "1" -> 7 terim
 */
#include <stdio.h>
#include <math.h>  /* sin, fabs (bağlama: -lm) */

int main(void)
{
    const double EPS = 1e-12;
    double x;
    printf("x (radyan): ");
    if (scanf("%lf", &x) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    double terim = x;  /* ilk terim: x */
    double toplam = 0.0;
    int k = 0;  /* eklenen terim sayısı */
    while (fabs(terim) >= EPS) {
        toplam += terim;
        terim = -terim * x * x / ((2 * k + 2) * (2 * k + 3));
        k++;
    }
    printf("Taylor : sin(%g) ≈ %.12f  (%d terim)\n", x, toplam, k);
    printf("math.h : sin(%g) = %.12f  (fark %.1e)\n",
           x, sin(x), fabs(toplam - sin(x)));
    return 0;
}

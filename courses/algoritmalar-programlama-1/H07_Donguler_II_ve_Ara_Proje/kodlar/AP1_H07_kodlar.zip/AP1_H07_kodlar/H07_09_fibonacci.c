/* H07_09_fibonacci.c — Hafta 7 · Örnek 9 (★★): Fibonacci dizisi (yinelemeli)
 * Amaç   : kayan değişkenler: yalnızca son iki terim (onceki, simdiki)
 *          tutulur; her turda pencere bir adım kayar. Toplamadan ÖNCE
 *          sınır denetimiyle int'in ve unsigned long long'un yettiği son
 *          terim bulunur (işaretli taşma tanımsız davranıştır).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_09_fibonacci.c -o fibonacci
 * Örnek  : -> int'e sığan son terim : F(46) = 1836311903
 */
#include <stdio.h>
#include <limits.h>  /* INT_MAX, ULLONG_MAX */

int main(void)
{
    /* 1) F(0)..F(15): pencere [onceki, simdiki] */
    int onceki = 0;   /* F(0) */
    int simdiki = 1;  /* F(1) */
    printf("F(0..15): %d %d", onceki, simdiki);
    for (int i = 2; i <= 15; i++) {
        int sonraki = onceki + simdiki;
        onceki = simdiki;  /* pencere bir adım kayar */
        simdiki = sonraki;
        printf(" %d", simdiki);
    }
    printf("\n");

    /* 2) int ile nereye kadar? onceki + simdiki taşmadan önce dur */
    onceki = 0;
    simdiki = 1;
    int k = 1;  /* simdiki = F(k) */
    while (simdiki <= INT_MAX - onceki) {
        int sonraki = onceki + simdiki;
        onceki = simdiki;
        simdiki = sonraki;
        k++;
    }
    printf("int'e sığan son terim : F(%d) = %d\n", k, simdiki);
    printf("F(%d) = %llu > INT_MAX = %d\n",
           k + 1, (unsigned long long)onceki + simdiki, INT_MAX);

    /* 3) unsigned long long (64 bit) ile aynı denetim */
    unsigned long long a = 0;
    unsigned long long b = 1;
    int m = 1;  /* b = F(m) */
    while (b <= ULLONG_MAX - a) {
        unsigned long long c = a + b;
        a = b;
        b = c;
        m++;
    }
    printf("unsigned long long'a sığan son terim: F(%d) = %llu\n", m, b);
    printf("F(%d) sığmaz; işaretsiz toplam 2^64 modunda sarar: %llu\n",
           m + 1, a + b);
    return 0;
}

/* H07_12_e_pi_seri.c — Hafta 7 · Örnek 12 (★★★): e ve π yaklaşımı
 * Amaç   : ε eşiğiyle sonlanan seri döngüleri: kaç terim gerektiği önceden
 *          bilinmez; terim eşiğin altına inince döngü biter.
 *          e = 1/0! + 1/1! + 1/2! + ...  (çok hızlı yakınsar)
 *          π = 4 (1 - 1/3 + 1/5 - 1/7 + ...)  (Leibniz; çok yavaş yakınsar)
 *          Bir sonraki terim öncekinden kesirli (double) bölmeyle elde edilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_12_e_pi_seri.c -o e_pi_seri
 * Örnek  : -> 18 terim, hata 4.4e-16
 */
#include <stdio.h>

int main(void)
{
    /* ---- e: terim = 1/k!, her turda terim /= k ---- */
    const double EPS_E = 1e-15;
    const double E_GERCEK = 2.718281828459045;  /* karşılaştırma için */
    double e = 0.0;
    double terim = 1.0;  /* 1/0! */
    int k = 0;
    while (terim >= EPS_E) {
        e += terim;
        k++;
        terim /= k;  /* 1/k! = (1/(k-1)!) / k */
    }
    double hata_e = e - E_GERCEK;
    if (hata_e < 0) {
        hata_e = -hata_e;
    }
    printf("e ≈ %.15f   %8d terim, hata %.1e\n", e, k, hata_e);

    /* ---- π: Leibniz serisi, terim 4/(2t+1) eşiğin altına inene dek ---- */
    const double EPS_PI = 1e-6;
    const double PI_GERCEK = 3.141592653589793;
    double pi = 0.0;
    double isaret = 1.0;
    double buyukluk = 4.0;  /* 4/(2t+1), t = 0 */
    int t = 0;
    while (buyukluk >= EPS_PI) {
        pi += isaret * buyukluk;
        isaret = -isaret;  /* + - + - ... */
        t++;
        buyukluk = 4.0 / (2 * t + 1);
    }
    double hata_pi = pi - PI_GERCEK;
    if (hata_pi < 0) {
        hata_pi = -hata_pi;
    }
    printf("π ≈ %.15f   %8d terim, hata %.1e\n", pi, t, hata_pi);
    return 0;
}

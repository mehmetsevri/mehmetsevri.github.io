/* H07_K14_oyun_agaci.c — Hafta 7 · Kavram programı: kaba kuvvetin sınırı
 * Amaç   : Shannon'ın (1950) kaba kestirimiyle bir hamle çiftinde (beyaz +
 *          siyah) yaklaşık 1000 olasılık varsa, d hamle çifti ileriye
 *          bakmak 1000^d konum demektir. Deep Blue'nun 1997 maçında ölçülen
 *          ortalama hızıyla (saniyede 126 milyon konum; Campbell vd., 2002)
 *          bu konumların TÜMÜNÜ tek tek değerlendirmek ne kadar sürerdi?
 *          (Gerçekte Deep Blue budama ve seçici arama kullanıyordu.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K14_oyun_agaci.c -o oyun_agaci
 * Örnek  : -> 1.0e+18
 */
#include <stdio.h>

int main(void)
{
    const double CIFT_BASINA = 1000.0;  /* hamle çifti başına olasılık */
    const double HIZ = 126e6;           /* konum / saniye */

    printf("çift  konum sayısı      saniye         gün        yıl\n");
    double konum = 1.0;
    for (int d = 1; d <= 6; d++) {
        konum *= CIFT_BASINA;  /* çarpım biriktirici (H6) */
        double saniye = konum / HIZ;
        printf("%4d  %12.1e  %10.3g  %10.3g  %9.3g\n", d, konum,
               saniye, saniye / 86400.0, saniye / (365.25 * 86400.0));
    }
    return 0;
}

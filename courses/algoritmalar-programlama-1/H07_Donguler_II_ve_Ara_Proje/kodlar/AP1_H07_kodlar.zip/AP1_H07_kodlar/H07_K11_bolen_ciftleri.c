/* H07_K11_bolen_ciftleri.c — Hafta 7 · Kavram programı: neden √n yeter?
 * Amaç   : n'nin her böleni bir çift oluşturur: d x (n / d). Çiftin küçük
 *          elemanı en çok √n'dir; bu yüzden d <= n / d (yani d² <= n)
 *          koşuluna kadar aramak tüm çiftleri bulur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K11_bolen_ciftleri.c -o bolen_ciftleri
 * Örnek  : girdi "36" -> 6 x 6
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Pozitif bir tamsayı: ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int d;
    int cift = 0;
    for (d = 1; d <= n / d; d++) {  /* d² <= n, taşmasız yazımı */
        if (n % d == 0) {
            printf("  %d x %d\n", d, n / d);
            cift++;
        }
    }
    printf("%d bölen çifti; döngü d = %d iken durdu (%d x %d > %d)\n",
           cift, d, d, d, n);
    return 0;
}

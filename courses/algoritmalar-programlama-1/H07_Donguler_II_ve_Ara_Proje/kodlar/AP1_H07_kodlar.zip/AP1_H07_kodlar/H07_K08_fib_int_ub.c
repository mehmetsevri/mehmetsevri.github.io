/* H07_K08_fib_int_ub.c — Hafta 7 · Kavram programı: int ile Fibonacci taşması
 * BU DOSYA KASITLI TANIMSIZ DAVRANIŞ İÇERİR: F(47) = 2971215073, int'in
 * en büyük değerini (2147483647) aşar; işaretli tamsayı taşması tanımsız
 * davranıştır. Sorun çalışma anında -fsanitize=undefined ile yakalanır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g -fsanitize=undefined \
 *              H07_K08_fib_int_ub.c -o fib_int_ub
 */
#include <stdio.h>

int main(void)
{
    int onceki = 0;
    int simdiki = 1;  /* F(1) */
    for (int k = 2; k <= 47; k++) {
        int sonraki = onceki + simdiki; /* k = 47'de taşar! */
        onceki = simdiki;
        simdiki = sonraki;
        if (k >= 45) {
            printf("F(%d) = %d\n", k, simdiki);
        }
    }
    return 0;
}

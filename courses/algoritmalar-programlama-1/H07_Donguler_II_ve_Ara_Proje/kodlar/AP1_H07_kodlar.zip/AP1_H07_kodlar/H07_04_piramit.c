/* H07_04_piramit.c — Hafta 7 · Örnek 4 (★★): piramit (boşluk + yıldız)
 * Amaç   : satır başına formül çıkarma: n yükseklikli piramidin i. satırı
 *          n - i boşluk ve 2i - 1 yıldızdır; dış döngünün içinde ARDIŞIK
 *          iki iç döngü
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_04_piramit.c -o piramit
 * Örnek  : girdi "5" -> Toplam 25 yıldız (n² = 25)
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Piramidin yüksekliği n (1-30): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 30) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int toplam = 0;
    for (int i = 1; i <= n; i++) {
        for (int b = 1; b <= n - i; b++) {  /* önce n - i boşluk */
            printf(" ");
        }
        for (int y = 1; y <= 2 * i - 1; y++) {  /* sonra 2i - 1 yıldız */
            printf("*");
            toplam++;
        }
        printf("\n");
    }
    printf("Toplam %d yıldız (n² = %d)\n", toplam, n * n);
    return 0;
}

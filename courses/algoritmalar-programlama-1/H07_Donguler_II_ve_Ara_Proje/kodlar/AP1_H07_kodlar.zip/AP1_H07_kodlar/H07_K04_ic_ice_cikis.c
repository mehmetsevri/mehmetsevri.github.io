/* H07_K04_ic_ice_cikis.c — Hafta 7 · Kavram programı: iç içe döngüden çıkış
 * Amaç   : i² + j² = 325 sağlayan İLK (i, j) çiftini (i <= j <= 20) arıyoruz.
 *          325'in üç gösterimi vardır; ilki bulununca arama bitmeli.
 *          1) yalnız break: yalnızca İÇ döngüden çıkar, arama sürer
 *          2) bayrak: dış döngünün koşulu da bayrağı denetler
 *          3) goto: iki döngüden birden tek atlamayla çıkar
 *          (H8'de 4. yol: aramayı fonksiyona koyup return etmek)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K04_ic_ice_cikis.c -o ic_ice_cikis
 * Örnek  : -> 2) bayrak : 1^2 + 18^2, 18 deneme
 */
#include <stdio.h>

int main(void)
{
    const int HEDEF = 325;
    const int UST = 20;

    /* 1) Yalnızca break */
    int deneme = 0;
    for (int i = 1; i <= UST; i++) {
        for (int j = i; j <= UST; j++) {
            deneme++;
            if (i * i + j * j == HEDEF) {
                printf("   bulundu: %d^2 + %d^2\n", i, j);
                break;  /* yalnızca j döngüsü biter! */
            }
        }
    }
    printf("1) yalnız break: %d deneme\n", deneme);

    /* 2) Bayrak */
    int bulundu = 0;
    int bi = 0;
    int bj = 0;
    deneme = 0;
    for (int i = 1; i <= UST && !bulundu; i++) {  /* bayrağa da bak */
        for (int j = i; j <= UST; j++) {
            deneme++;
            if (i * i + j * j == HEDEF) {
                bulundu = 1;
                bi = i;
                bj = j;
                break;
            }
        }
    }
    printf("2) bayrak : %d^2 + %d^2, %d deneme\n", bi, bj, deneme);

    /* 3) goto: iki döngüden birden çıkış */
    bi = 0;
    bj = 0;
    deneme = 0;
    for (int i = 1; i <= UST; i++) {
        for (int j = i; j <= UST; j++) {
            deneme++;
            if (i * i + j * j == HEDEF) {
                bi = i;
                bj = j;
                goto arama_bitti;  /* iki döngüden çık */
            }
        }
    }
arama_bitti:
    if (bi > 0) {
        printf("3) goto   : %d^2 + %d^2, %d deneme\n", bi, bj, deneme);
    } else {
        printf("3) goto   : bulunamadı, %d deneme\n", deneme);
    }
    return 0;
}

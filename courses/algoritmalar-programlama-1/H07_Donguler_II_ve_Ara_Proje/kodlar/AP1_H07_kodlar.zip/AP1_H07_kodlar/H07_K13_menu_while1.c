/* H07_K13_menu_while1.c — Hafta 7 · Kavram programı: menü döngüsü (while (1))
 * Amaç   : "sonsuz" döngü + açık çıkış: çıkış denetimi switch'ten ÖNCE
 *          yapılır; çünkü switch'in içindeki break döngüyü bitirmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K13_menu_while1.c -o menu_while1
 * Örnek  : girdi "1 1 3 0" -> Çıkış: sayac = 2
 */
#include <stdio.h>

int main(void)
{
    int sayac = 0;
    int secim;
    while (1) {
        printf("[1] Artır [2] Azalt [3] Göster [0] Çıkış > ");
        if (scanf("%d", &secim) != 1 || secim == 0) {
            break;  /* while'dan çık: switch'in DIŞINDA */
        }
        switch (secim) {
        case 1:
            sayac++;
            break;
        case 2:
            sayac--;
            break;
        case 3:
            printf("sayac = %d\n", sayac);
            break;
        default:
            printf("Geçersiz seçim: %d\n", secim);
            break;
        }
    }
    printf("Çıkış: sayac = %d\n", sayac);
    return 0;
}

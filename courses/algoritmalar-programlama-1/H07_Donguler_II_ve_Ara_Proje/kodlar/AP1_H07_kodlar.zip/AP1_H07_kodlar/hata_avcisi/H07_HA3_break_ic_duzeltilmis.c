/* H07_HA3_break_ic_duzeltilmis.c — Hafta 7 · Hata Avcısı 3 (düzeltilmiş)
 * Düzeltme: bulundu bayrağı dış döngünün koşuluna da eklenir; iç döngüdeki
 *           break ile birlikte iki döngü de ilk çözümde durur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA3_break_ic_duzeltilmis.c -o ha3d
 * Örnek  : -> İlk çözüm: 1^2 + 18^2 = 325
 */
#include <stdio.h>

int main(void)
{
    const int HEDEF = 325;
    int bi = 0;
    int bj = 0;
    int bulundu = 0;
    for (int i = 1; i <= 20 && !bulundu; i++) {
        for (int j = i; j <= 20; j++) {
            if (i * i + j * j == HEDEF) {
                bi = i;
                bj = j;
                bulundu = 1;  /* dış döngüye de haber ver */
                break;
            }
        }
    }
    printf("İlk çözüm: %d^2 + %d^2 = %d\n", bi, bj, HEDEF);
    return 0;
}

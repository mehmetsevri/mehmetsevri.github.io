/* H07_HA2_ayni_sayac.c — Hafta 7 · Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: 3 x 5'lik dikdörtgen isteniyor, ama iç
 * döngü de dış döngünün sayacı i'yi kullanıyor. İç döngü i'yi 6'ya
 * çıkarır; dış döngünün koşulu (i <= 3) yanlış olur: tek satır çıkar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA2_ayni_sayac.c -o ha2
 */
#include <stdio.h>

int main(void)
{
    int i;
    for (i = 1; i <= 3; i++) {
        for (i = 1; i <= 5; i++) {  /* HATA: aynı sayaç! */
            printf("*");
        }
        printf("\n");
    }
    printf("Döngüler bitti: i = %d\n", i);
    return 0;
}

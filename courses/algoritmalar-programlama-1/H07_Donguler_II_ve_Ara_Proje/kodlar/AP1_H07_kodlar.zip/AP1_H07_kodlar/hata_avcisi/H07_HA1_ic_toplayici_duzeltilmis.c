/* H07_HA1_ic_toplayici_duzeltilmis.c — Hafta 7 · Hata Avcısı 1 (düzeltilmiş)
 * Düzeltme: satır toplayıcısı dış döngünün İÇİNDE, iç döngüden hemen önce
 *           bildirilir ve sıfırlanır: her satır kendi toplamıyla başlar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA1_ic_toplayici_duzeltilmis.c -o ha1d
 * Örnek  : -> 4. satırın toplamı: 60
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 4; i++) {
        int satir_toplami = 0;  /* her dış turda yeniden 0 */
        for (int j = 1; j <= 5; j++) {
            satir_toplami += i * j;
        }
        printf("%d. satırın toplamı: %d\n", i, satir_toplami);
    }
    return 0;
}

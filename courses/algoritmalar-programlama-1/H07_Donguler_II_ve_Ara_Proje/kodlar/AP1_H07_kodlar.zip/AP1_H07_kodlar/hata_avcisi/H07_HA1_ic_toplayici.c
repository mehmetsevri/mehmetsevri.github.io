/* H07_HA1_ic_toplayici.c — Hafta 7 · Hata Avcısı 1 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: her satırın toplamı isteniyor, ama satır
 * toplayıcısı dış döngüden ÖNCE bir kez sıfırlanıyor; her dış turda
 * yeniden sıfırlanmadığı için toplamlar birikir (15, 45, 90, 150).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA1_ic_toplayici.c -o ha1
 */
#include <stdio.h>

int main(void)
{
    int satir_toplami = 0;  /* yalnızca BİR KEZ sıfırlanıyor! */
    for (int i = 1; i <= 4; i++) {
        for (int j = 1; j <= 5; j++) {
            satir_toplami += i * j;
        }
        printf("%d. satırın toplamı: %d\n", i, satir_toplami);
    }
    return 0;
}

/* H07_HA2_ayni_sayac_duzeltilmis.c — Hafta 7 · Hata Avcısı 2 (düzeltilmiş)
 * Düzeltme: her döngünün kendi sayacı vardır ve sayaçlar for başlığında
 *           bildirilir (kapsamları kendi döngüleriyle sınırlı, H9).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA2_ayni_sayac_duzeltilmis.c -o ha2d
 * Örnek  : -> *****
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 3; i++) {
        for (int j = 1; j <= 5; j++) {  /* iç döngünün KENDİ sayacı */
            printf("*");
        }
        printf("\n");
    }
    return 0;
}

/* H07_HA3_break_ic.c — Hafta 7 · Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: i² + j² = 325 sağlayan İLK çift isteniyor.
 * break yalnızca İÇ döngüden çıkar; dış döngü sürer, sonraki çözümler
 * bi ve bj'nin üzerine yazılır: ekrana ilk değil SON çözüm çıkar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA3_break_ic.c -o ha3
 */
#include <stdio.h>

int main(void)
{
    const int HEDEF = 325;
    int bi = 0;
    int bj = 0;
    for (int i = 1; i <= 20; i++) {
        for (int j = i; j <= 20; j++) {
            if (i * i + j * j == HEDEF) {
                bi = i;
                bj = j;
                break;  /* "aramayı bitirir" sanılıyor */
            }
        }
    }
    printf("İlk çözüm: %d^2 + %d^2 = %d\n", bi, bj, HEDEF);
    return 0;
}

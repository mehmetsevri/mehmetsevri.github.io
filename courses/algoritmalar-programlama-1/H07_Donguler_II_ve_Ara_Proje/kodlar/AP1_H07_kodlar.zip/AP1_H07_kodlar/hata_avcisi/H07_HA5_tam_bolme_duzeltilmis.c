/* H07_HA5_tam_bolme_duzeltilmis.c — Hafta 7 · Hata Avcısı 5 (düzeltilmiş)
 * Düzeltme: pay 1.0 (double) yazılır; bölme kesirli yapılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA5_tam_bolme_duzeltilmis.c -o ha5d
 * Örnek  : -> e ≈ 2.7182818284
 */
#include <stdio.h>

int main(void)
{
    double e = 0.0;
    long long faktoriyel = 1;
    for (int k = 0; k <= 15; k++) {
        if (k > 0) {
            faktoriyel *= k;  /* k! */
        }
        e += 1.0 / faktoriyel;  /* double / long long -> double */
    }
    printf("e ≈ %.15f\n", e);
    return 0;
}

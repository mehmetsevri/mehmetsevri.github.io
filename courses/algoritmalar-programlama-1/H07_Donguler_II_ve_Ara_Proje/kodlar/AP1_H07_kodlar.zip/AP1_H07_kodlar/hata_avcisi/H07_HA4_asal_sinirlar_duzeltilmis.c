/* H07_HA4_asal_sinirlar_duzeltilmis.c — Hafta 7 · Hata Avcısı 4 (düzeltilmiş)
 * Düzeltme: sınır durumları döngüden ÖNCE ve doğru sırayla ele alınır:
 *           n < 2 asal değil; n == 2 asal; diğer çiftler asal değil;
 *           ancak sonra tek bölenler denenir (Örnek 11'in biçimi).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA4_asal_sinirlar_duzeltilmis.c -o ha4d
 * Örnek  : -> 2 3 5 7 11 13 17 19 23 29
 */
#include <stdio.h>

int main(void)
{
    printf("-3..30 arasında \"asal\" bulunanlar:");
    for (int n = -3; n <= 30; n++) {
        int asal = 1;
        if (n < 2) {
            asal = 0;
        } else if (n == 2) {
            asal = 1;
        } else if (n % 2 == 0) {
            asal = 0;
        } else {
            for (int d = 3; d <= n / d; d += 2) {
                if (n % d == 0) {
                    asal = 0;
                    break;
                }
            }
        }
        if (asal) {
            printf(" %d", n);
        }
    }
    printf("\n");
    return 0;
}

/* H07_HA6_karekok_tasma.c — Hafta 7 · Hata Avcısı 6 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: koşul d * d <= n büyük n'de taşar.
 * n = 2147483647 (INT_MAX, asaldır) için d = 46341'de 46341 * 46341 int'e
 * sığmaz: işaretli taşma TANIMSIZ DAVRANIŞTIR. Sanitizer bunu yakalar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA6_karekok_tasma.c -o ha6
 *          gcc ... -fsanitize=undefined H07_HA6_karekok_tasma.c -o ha6_ub
 */
#include <stdio.h>

int main(void)
{
    const int n = 2147483647;  /* INT_MAX = 2^31 - 1, bir asal */
    int asal = 1;
    int bolen = 0;
    long long bolme = 0;
    for (int d = 3; d * d <= n; d += 2) {  /* HATA: d * d taşabilir */
        bolme++;
        if (n % d == 0) {
            asal = 0;
            bolen = d;
            break;
        }
    }
    printf("%d: asal = %d, bölen = %d, %lld bölme\n", n, asal, bolen, bolme);
    return 0;
}

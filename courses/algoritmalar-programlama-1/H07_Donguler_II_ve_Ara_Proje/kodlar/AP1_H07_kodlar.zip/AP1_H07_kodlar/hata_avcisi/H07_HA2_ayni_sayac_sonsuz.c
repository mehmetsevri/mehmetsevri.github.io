/* H07_HA2_ayni_sayac_sonsuz.c — Hafta 7 · Hata Avcısı 2 (ikinci belirti)
 * BU DOSYA KASITLI HATA İÇERİR: aynı sayaç hatası, ama bu kez iç sınır (3)
 * dış sınırdan (5) küçük. İç döngü her seferinde i'yi 4'e getirir, dış
 * güncelleme 5 yapar, 5 <= 5 doğrudur, iç döngü i'yi yeniden 1'den
 * başlatır: döngü HİÇ bitmez. (timeout ile durdurulur.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA2_ayni_sayac_sonsuz.c -o ha2_sonsuz
 */
#include <stdio.h>

int main(void)
{
    int i;
    for (i = 1; i <= 5; i++) {
        for (i = 1; i <= 3; i++) {  /* HATA: aynı sayaç! */
            printf("*");
        }
        printf("\n");
    }
    return 0;
}

/* H07_HA5_tam_bolme.c — Hafta 7 · Hata Avcısı 5 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: e = Σ 1/k! hesabında 1 / faktoriyel
 * TAMSAYI bölmesidir (H4): k >= 2 için her terim 0 olur, sonuç 2 çıkar.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA5_tam_bolme.c -o ha5
 */
#include <stdio.h>

int main(void)
{
    double e = 0.0;
    long long faktoriyel = 1;
    for (int k = 0; k <= 15; k++) {
        if (k > 0) {
            faktoriyel *= k;  /* k! */
        }
        e += 1 / faktoriyel;  /* HATA: int / long long */
    }
    printf("e ≈ %.15f\n", e);
    return 0;
}

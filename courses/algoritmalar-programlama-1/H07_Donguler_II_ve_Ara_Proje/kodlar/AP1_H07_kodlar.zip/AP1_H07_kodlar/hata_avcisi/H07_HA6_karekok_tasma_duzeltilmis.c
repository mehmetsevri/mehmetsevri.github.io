/* H07_HA6_karekok_tasma_duzeltilmis.c — Hafta 7 · Hata Avcısı 6 (düzeltilmiş)
 * Düzeltme: d * d <= n yerine d <= n / d. Bölme taşmaz; d tam √n'yi
 *           aşınca n / d < d olur ve döngü doğru yerde biter.
 *           (Diğer yol: long long dd = (long long)d * d; dd <= n.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA6_karekok_tasma_duzeltilmis.c -o ha6d
 * Örnek  : -> 2147483647: asal = 1, bölen = 0, 23169 bölme
 */
#include <stdio.h>

int main(void)
{
    const int n = 2147483647;
    int asal = 1;
    int bolen = 0;
    long long bolme = 0;
    for (int d = 3; d <= n / d; d += 2) {  /* taşmasız √n sınırı */
        bolme++;
        if (n % d == 0) {
            asal = 0;
            bolen = d;
            break;
        }
    }
    printf("%d: asal = %d, bölen = %d, %lld bölme\n", n, asal, bolen, bolme);
    return 0;
}

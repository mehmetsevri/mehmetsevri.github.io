/* H07_HA4_asal_sinirlar.c — Hafta 7 · Hata Avcısı 4 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: "iyileştirilmiş" asallık testi sınır
 * durumlarını atlıyor: n < 2 denetimi yok (1 ve negatif tekler "asal"
 * çıkar) ve "çift sayılar asal değildir" kuralı 2'yi de eler.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_HA4_asal_sinirlar.c -o ha4
 */
#include <stdio.h>

int main(void)
{
    printf("-3..30 arasında \"asal\" bulunanlar:");
    for (int n = -3; n <= 30; n++) {
        int asal = 1;
        if (n % 2 == 0) {
            asal = 0;  /* çiftler asal değil... 2 de mi? */
        } else {
            for (int d = 3; d <= n / d; d += 2) {
                if (n % d == 0) {
                    asal = 0;
                    break;
                }
            }
        }
        if (asal) {
            printf(" %d", n);
        }
    }
    printf("\n");
    return 0;
}

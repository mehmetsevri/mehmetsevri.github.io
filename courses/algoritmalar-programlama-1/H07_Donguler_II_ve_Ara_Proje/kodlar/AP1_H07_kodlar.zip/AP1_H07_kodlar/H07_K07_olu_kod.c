/* H07_K07_olu_kod.c — Hafta 7 · Kavram programı: ölçülen kod silinebilir!
 * Amaç   : Aynı naif asal sayımı üç biçimde ölçülür:
 *          A) sonuç hiç kullanılmaz  B) sonuç yazdırılır
 *          C) toplayıcı volatile tanımlanır (her erişim belleğe gider)
 *          -O2 ile derlendiğinde derleyici A'daki hesabı tümüyle silebilir:
 *          "çok hızlı" ölçüm, aslında hiç çalışmayan koddur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -O0 H07_K07_olu_kod.c -o olu_O0
 *          gcc -std=c17 -Wall -Wextra -pedantic -O2 H07_K07_olu_kod.c -o olu_O2
 */
#include <stdio.h>
#include <time.h>

int main(void)
{
    const int UST = 30000;

    /* A) Sonuç kullanılmıyor */
    clock_t bas = clock();
    int sayac_a = 0;
    for (int n = 2; n <= UST; n++) {
        int asal = 1;
        for (int d = 2; d < n; d++) {
            if (n % d == 0) {
                asal = 0;
                break;
            }
        }
        sayac_a += asal;
    }
    (void)sayac_a;  /* uyarıyı susturur; sonuç yine kullanılmaz */
    double sure_a = (double)(clock() - bas) / CLOCKS_PER_SEC;

    /* B) Sonuç yazdırılıyor */
    bas = clock();
    int sayac_b = 0;
    for (int n = 2; n <= UST; n++) {
        int asal = 1;
        for (int d = 2; d < n; d++) {
            if (n % d == 0) {
                asal = 0;
                break;
            }
        }
        sayac_b += asal;
    }
    double sure_b = (double)(clock() - bas) / CLOCKS_PER_SEC;

    /* C) volatile toplayıcı: derleyici her ekleme işlemini yapmak zorunda */
    bas = clock();
    volatile int sayac_c = 0;
    for (int n = 2; n <= UST; n++) {
        int asal = 1;
        for (int d = 2; d < n; d++) {
            if (n % d == 0) {
                asal = 0;
                break;
            }
        }
        sayac_c += asal;
    }
    double sure_c = (double)(clock() - bas) / CLOCKS_PER_SEC;

    printf("A) sonuç kullanılmadı : %.6f s\n", sure_a);
    printf("B) sonuç yazdırıldı   : %.6f s (asal sayısı %d)\n", sure_b, sayac_b);
    printf("C) volatile toplayıcı : %.6f s (asal sayısı %d)\n", sure_c, sayac_c);
    return 0;
}

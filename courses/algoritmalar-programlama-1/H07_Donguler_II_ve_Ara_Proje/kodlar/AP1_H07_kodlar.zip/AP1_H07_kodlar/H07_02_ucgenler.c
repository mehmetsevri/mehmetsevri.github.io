/* H07_02_ucgenler.c — Hafta 7 · Örnek 2 (★): dik üçgen ve ters üçgen
 * Amaç   : iç döngünün sınırını dış döngü değişkenine bağlamak:
 *          i. satırda dik üçgende i, ters üçgende n - i + 1 yıldız
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_02_ucgenler.c -o ucgenler
 * Örnek  : girdi "5" -> (15 yıldız = n(n+1)/2 = 15)
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Satır sayısı n (1-40): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 40) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    printf("Dik üçgen:\n");
    int yildiz = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {  /* iç sınır = i */
            printf("*");
            yildiz++;
        }
        printf("\n");
    }
    printf("(%d yıldız = n(n+1)/2 = %d)\n", yildiz, n * (n + 1) / 2);

    printf("Ters üçgen:\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n - i + 1; j++) {  /* iç sınır = n - i + 1 */
            printf("*");
        }
        printf("\n");
    }
    return 0;
}

/* H07_A04_hata_bul_asal_listesi.c — Hafta 7 · Alıştırma 7.4 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR. 2-20 arasındaki asalların (2 3 5 7 11 13
 * 17 19) yazılması bekleniyor; program yalnızca "2 3" yazıyor. Neden?
 * Hangi satır nereye taşınmalı?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_A04_hata_bul_asal_listesi.c -o a04
 */
#include <stdio.h>

int main(void)
{
    int asal = 1;
    for (int n = 2; n <= 20; n++) {
        for (int d = 2; d < n; d++) {
            if (n % d == 0) {
                asal = 0;
                break;
            }
        }
        if (asal) {
            printf("%d ", n);
        }
    }
    printf("\n");
    return 0;
}

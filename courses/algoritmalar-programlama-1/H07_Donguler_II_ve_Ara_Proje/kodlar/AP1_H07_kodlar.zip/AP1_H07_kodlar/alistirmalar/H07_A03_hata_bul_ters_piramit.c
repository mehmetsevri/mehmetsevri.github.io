/* H07_A03_hata_bul_ters_piramit.c — Hafta 7 · Alıştırma 7.3 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR. n = 3 için aşağıdaki TERS piramit
 * isteniyor; program ise başka bir desen çiziyor. Satır-boşluk-yıldız
 * tablosu kurarak iki formül hatasını bulun ve düzeltin.
 *     *****
 *      ***
 *       *
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_A03_hata_bul_ters_piramit.c -o a03
 */
#include <stdio.h>

int main(void)
{
    const int n = 3;
    for (int i = 1; i <= n; i++) {
        for (int b = 1; b <= n - i; b++) {
            printf(" ");
        }
        for (int y = 1; y <= 2 * i + 1; y++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}

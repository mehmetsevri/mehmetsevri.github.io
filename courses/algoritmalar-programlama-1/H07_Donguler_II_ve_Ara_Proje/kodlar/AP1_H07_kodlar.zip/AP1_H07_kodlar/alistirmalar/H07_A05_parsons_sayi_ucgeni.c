/* H07_A05_parsons_sayi_ucgeni.c — Hafta 7 · Alıştırma 7.5 (★★, Parsons)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. Aşağıdaki satırları sıralayıp
 * girintileyerek şu çıktıyı üreten programı kurun. Satırlardan BİRİ
 * fazladır (çeldirici).
 *     1
 *     2 2
 *     3 3 3
 *     4 4 4 4
 */
#include <stdio.h>

int main(void)
{
        printf("\n");
    for (int i = 1; i <= 4; i++) {
            printf("%d ", j);
        for (int j = 1; j <= i; j++) {
    }
            printf("%d ", i);
        }
    return 0;
}

/* H07_A01_cikti_tahmini_x.c — Hafta 7 · Alıştırma 7.1 (★, çıktı tahmini)
 * Soru   : Programın çıktısını çalıştırmadan tahmin edin. Hangi (i, j)
 *          hücrelerine X yazılır? Izgarayı kâğıtta çizin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_A01_cikti_tahmini_x.c -o a01
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 4; i++) {
        for (int j = 1; j <= 4; j++) {
            if (i == j || i + j == 5) {
                printf("X");
            } else {
                printf(".");
            }
        }
        printf("\n");
    }
    return 0;
}

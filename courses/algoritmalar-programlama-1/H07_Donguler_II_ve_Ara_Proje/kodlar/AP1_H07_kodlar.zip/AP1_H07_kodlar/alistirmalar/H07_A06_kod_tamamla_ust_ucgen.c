/* H07_A06_kod_tamamla_ust_ucgen.c — Hafta 7 · Alıştırma 7.6 (★★, kod tamamla)
 * TAMAMLANACAK; BU HÂLİYLE DERLENMEZ. ____ yerlerini doldurun: 5 x 5
 * çarpım tablosunun yalnızca köşegen ve üstünü (j >= i) yazdırın; diğer
 * hücreler 4 boşluk olsun. Beklenen ilk iki satır:
 *        1   2   3   4   5
 *            4   6   8  10
 */
#include <stdio.h>

int main(void)
{
    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= ____; j++) {
            if (____) {
                printf("%4d", ____);
            } else {
                printf("____");
            }
        }
        ____;
    }
    return 0;
}

/* H07_A02_break_continue_ic_ice.c — Hafta 7 · Alıştırma 7.2 (★★, çıktı tahmini)
 * Soru   : toplam son olarak kaçtır? break ve continue hangi döngüyü etkiler?
 *          Her (i, j) için "eklendi / atlandı / döngü bitti" izleme tablosu
 *          kurun.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_A02_break_continue_ic_ice.c -o a02
 */
#include <stdio.h>

int main(void)
{
    int toplam = 0;
    for (int i = 1; i <= 4; i++) {
        for (int j = 1; j <= 4; j++) {
            if (j > i) {
                break;
            }
            if ((i + j) % 2 == 1) {
                continue;
            }
            toplam += i * j;
        }
    }
    printf("toplam = %d\n", toplam);
    return 0;
}

/* H07_K06_olcum_deneyi.c — Hafta 7 · Kavram programı: ölçüm deneyi
 * Amaç   : 0..N arasındaki asalları seçilen yöntemle (1 = naif, 2 = √n ve
 *          tek bölenler) TEKRAR kez sayar; her tekrarın süresini clock()
 *          ile ölçer, en kısa süreyi ve ortalamayı (H6'nın en küçük ve
 *          toplayıcı desenleri) yazar. Bölme sayısı her tekrarda aynıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K06_olcum_deneyi.c -o olcum_deneyi
 *          (ölçümler -O0 ve -O2 ile ayrı ayrı derlenip alındı)
 * Örnek  : girdi "2 100000 3" -> asal sayısı = 9592
 */
#include <stdio.h>
#include <time.h>  /* clock, clock_t, CLOCKS_PER_SEC */

int main(void)
{
    int yontem, ust, tekrar;
    printf("Yöntem (1 naif, 2 iyileştirilmiş), N, tekrar: ");
    if (scanf("%d %d %d", &yontem, &ust, &tekrar) != 3 ||
        yontem < 1 || yontem > 2 || ust < 0 || tekrar < 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    double en_kisa = 0.0, toplam_sure = 0.0;
    for (int t = 1; t <= tekrar; t++) {
        long long bolme = 0;  /* yineleme (bölme) sayacı */
        int asal_sayisi = 0;
        clock_t bas = clock();
        for (int n = 0; n <= ust; n++) {
            int asal = 1;
            if (n < 2) {
                asal = 0;
            } else if (yontem == 1) {  /* naif: d = 2 .. n-1 */
                for (int d = 2; d < n; d++) {
                    bolme++;
                    if (n % d == 0) {
                        asal = 0;
                        break;
                    }
                }
            } else if (n == 2) {
                asal = 1;
            } else if (n % 2 == 0) {
                asal = 0;
            } else {  /* yalnızca tek d, d <= n / d */
                for (int d = 3; d <= n / d; d += 2) {
                    bolme++;
                    if (n % d == 0) {
                        asal = 0;
                        break;
                    }
                }
            }
            asal_sayisi += asal;
        }
        clock_t son = clock();
        double sure = (double)(son - bas) / CLOCKS_PER_SEC;
        printf("tekrar %d: asal sayısı = %d, bölme = %lld, süre = %.6f s\n",
               t, asal_sayisi, bolme, sure);
        toplam_sure += sure;
        if (t == 1 || sure < en_kisa) {
            en_kisa = sure;
        }
    }
    printf("en kısa = %.6f s, ortalama = %.6f s\n",
           en_kisa, toplam_sure / tekrar);
    return 0;
}

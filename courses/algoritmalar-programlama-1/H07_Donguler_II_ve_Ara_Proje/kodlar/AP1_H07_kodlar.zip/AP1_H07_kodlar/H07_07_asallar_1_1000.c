/* H07_07_asallar_1_1000.c — Hafta 7 · Örnek 7 (★★): 1-1000 arasındaki asallar
 * Amaç   : iç içe döngü ile listeleme: dış döngü adayları (2..1000), iç
 *          döngü Örnek 6'nın naif testini dolaşır; asallar 10'arlı satırlar
 *          hâlinde yazılır; iç döngünün toplam tur sayısı sayılır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_07_asallar_1_1000.c -o asallar
 * Örnek  : -> Toplam 168 asal
 */
#include <stdio.h>

int main(void)
{
    const int UST = 1000;
    int adet = 0;         /* bulunan asal sayısı */
    long long bolme = 0;  /* iç döngünün toplam tur sayısı */

    printf("1-%d arasındaki asal sayılar:\n", UST);
    for (int n = 2; n <= UST; n++) {  /* dış döngü: adaylar */
        int asal = 1;
        for (int d = 2; d < n; d++) {  /* iç döngü: Örnek 6'nın testi */
            bolme++;
            if (n % d == 0) {
                asal = 0;
                break;
            }
        }
        if (asal) {
            printf("%4d", n);
            adet++;
            if (adet % 10 == 0) {  /* her 10 asalda bir alt satır */
                printf("\n");
            }
        }
    }
    printf("\nToplam %d asal; iç döngü %lld kez döndü.\n", adet, bolme);
    return 0;
}

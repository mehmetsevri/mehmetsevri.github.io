/* H07_06_asal_naif.c — Hafta 7 · Örnek 6 (★★): naif asallık testi
 * Amaç   : bölen arama + bayrak: n < 2 asal değildir; 2 .. n-1 arasındaki
 *          her d denenir; n % d == 0 olan ilk d bulununca bayrak indirilir
 *          ve break ile arama biter. Deneme (bölme) sayısı sayaçla tutulur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_06_asal_naif.c -o asal_naif
 * Örnek  : girdi "97" -> 97 asaldır (95 bölme denendi).
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Bir tamsayı: ");
    if (scanf("%d", &n) != 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int asal = 1;   /* bayrak: aksi kanıtlanana dek asal */
    int bolme = 0;  /* kaç bölme denendi */
    int bolen = 0;  /* bulunan ilk bölen */
    if (n < 2) {
        asal = 0;  /* 0, 1 ve negatifler asal değildir */
    } else {
        for (int d = 2; d < n; d++) {
            bolme++;
            if (n % d == 0) {
                asal = 0;
                bolen = d;
                break;  /* bir bölen yeter: aramayı bitir */
            }
        }
    }

    if (asal) {
        printf("%d asaldır (%d bölme denendi).\n", n, bolme);
    } else if (n < 2) {
        printf("%d asal değildir: asallar 2'den başlar.\n", n);
    } else {
        printf("%d asal değildir: %d x %d (%d bölme denendi).\n",
               n, bolen, n / bolen, bolme);
    }
    return 0;
}

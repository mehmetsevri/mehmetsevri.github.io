/* H07_05_floyd_ucgeni.c — Hafta 7 · Örnek 5 (★★): Floyd üçgeni ve sayı üçgeni
 * Amaç   : desen içinde sayaç sürdürme: Floyd üçgeninde sayı satırlar
 *          boyunca HİÇ sıfırlanmaz; sayı üçgeninde ise iç döngü değişkeni j
 *          her satırda yeniden 1'den başlar
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_05_floyd_ucgeni.c -o floyd_ucgeni
 * Örnek  : girdi "5" -> Son sayı: 15 = n(n+1)/2
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Satır sayısı n (1-13): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 13) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    printf("Floyd üçgeni:\n");
    int sayi = 1;  /* satırlar boyunca süren sayaç */
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%4d", sayi);
            sayi++;
        }
        printf("\n");
    }
    printf("Son sayı: %d = n(n+1)/2\n", sayi - 1);

    printf("Sayı üçgeni (j her satırda yeniden 1'den başlar):\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%4d", j);
        }
        printf("\n");
    }
    return 0;
}

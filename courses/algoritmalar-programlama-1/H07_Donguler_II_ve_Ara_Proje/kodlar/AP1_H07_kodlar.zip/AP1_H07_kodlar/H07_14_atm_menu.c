/*
 * H07_14_atm_menu.c — Menü güdümlü ATM simülasyonu (AP-1 Hafta 7 · ara proje)
 * Amaç    : H5–H7'nin bütünleştirilmesi: sayaç kontrollü PIN döngüsü (en çok
 *           3 deneme), menü döngüsü (do-while + switch), girdi doğrulama
 *           döngüleri (scanf dönüş değeri + tampon temizleme) ve bayrak.
 * Kurallar: PIN 1234 (eğitsel örnek; gerçek sistemlerde PIN asla kodda
 *           tutulmaz). Başlangıç bakiyesi 1000 TL. Para çekme 10 TL'nin katı
 *           olmalı ve bakiyeyi aşmamalı; para yatırma 1–10000 TL.
 *           3 hatalı PIN → kart bloke, program çıkış kodu 2 ile biter.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g H07_14_atm_menu.c -o atm
 * Örnek   : printf '1111\n1234\n1\n3\n250\n2\n100\n4\n' | ./atm
 */

#include <stdio.h>

int main(void)
{
    const int DOGRU_PIN = 1234;
    const int AZAMI_DENEME = 3;
    const int YATIRMA_SINIRI = 10000;

    int bakiye = 1000;                      /* TL, tamsayı: kuruş yok */
    int pin = 0, okunan, c;
    int giris_basarili = 0;                 /* bayrak */

    printf("===== AP-1 BANKASI ATM =====\n");

    /* 1) PIN doğrulama: sayaç kontrollü döngü + bayrak */
    for (int deneme = 1; deneme <= AZAMI_DENEME; deneme++) {
        printf("PIN (%d/%d)           : ", deneme, AZAMI_DENEME);
        okunan = scanf("%d", &pin);
        if (okunan == EOF) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }
        if (okunan == 0) {
            while ((c = getchar()) != '\n' && c != EOF) {
                /* satırın kalanını at */
            }
            pin = -1;
        }
        if (pin == DOGRU_PIN) {
            giris_basarili = 1;
            break;                          /* for döngüsünden çık */
        }
        printf("  Hatalı PIN.\n");
    }
    if (!giris_basarili) {
        printf("Kartınız bloke edildi. Lütfen şubenize başvurun.\n");
        return 2;
    }

    /* 2) Menü döngüsü */
    int secim = 0;
    do {
        printf("\n1) Bakiye  2) Para yatır  3) Para çek  4) Çıkış\n");
        printf("Seçiminiz           : ");
        okunan = scanf("%d", &secim);
        if (okunan == EOF) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }
        if (okunan == 0) {
            while ((c = getchar()) != '\n' && c != EOF) {
                /* satırın kalanını at */
            }
            secim = 0;
        }

        switch (secim) {
        case 1:
            printf("Bakiyeniz           : %d TL\n", bakiye);
            break;
        case 2: {
            int tutar = 0;
            do {                            /* iç döngü: geçerli tutar */
                printf("Yatırılacak tutar   : ");
                okunan = scanf("%d", &tutar);
                if (okunan == EOF) {
                    printf("\nGirdi sona erdi.\n");
                    return 1;
                }
                if (okunan == 0) {
                    while ((c = getchar()) != '\n' && c != EOF) {
                        /* satırın kalanını at */
                    }
                    tutar = 0;
                }
                if (tutar < 1 || tutar > YATIRMA_SINIRI) {
                    printf("  Geçersiz: 1 ile %d TL arasında girin.\n", YATIRMA_SINIRI);
                }
            } while (tutar < 1 || tutar > YATIRMA_SINIRI);
            bakiye += tutar;
            printf("Yatırıldı. Bakiye   : %d TL\n", bakiye);
            break;
        }
        case 3: {
            int tutar = -1, gecerli = 0;
            if (bakiye < 10) {
                printf("  Çekilebilir tutar yok (bakiye: %d TL).\n", bakiye);
                break;
            }
            do {                            /* iç döngü: geçerli tutar */
                printf("Çekilecek (0=iptal) : ");
                okunan = scanf("%d", &tutar);
                if (okunan == EOF) {
                    printf("\nGirdi sona erdi.\n");
                    return 1;
                }
                if (okunan == 0) {
                    while ((c = getchar()) != '\n' && c != EOF) {
                        /* satırın kalanını at */
                    }
                    tutar = -1;
                }
                if (tutar == 0) {
                    gecerli = 1;            /* vazgeçti */
                } else if (tutar < 0 || tutar % 10 != 0) {
                    printf("  Geçersiz: 10 TL'nin katı, pozitif bir tutar girin.\n");
                } else if (tutar > bakiye) {
                    printf("  Yetersiz bakiye (bakiye: %d TL).\n", bakiye);
                } else {
                    gecerli = 1;
                }
            } while (!gecerli);
            if (tutar == 0) {
                printf("İşlem iptal edildi.\n");
            } else {
                bakiye -= tutar;
                printf("Paranızı alınız. Bakiye: %d TL\n", bakiye);
            }
            break;
        }
        case 4:
            printf("İyi günler dileriz.\n");
            break;
        default:
            printf("  Geçersiz seçim: 1-4 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 4);

    return 0;
}

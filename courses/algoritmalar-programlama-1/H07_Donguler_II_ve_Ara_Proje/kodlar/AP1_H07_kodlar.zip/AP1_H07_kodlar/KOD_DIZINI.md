# Hafta 7 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` dosyası (76 dosya); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (`math.h` kullanan `H07_K10_sin_taylor.c` için sona `-lm`). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (her dosyanın başında derleme komutu, sonra `$ ./program` satırları ve kullanıcı girdileriyle birlikte çıktı). Bütün örnek ve kavram programları ayrıca AddressSanitizer + UBSan ile temiz çalıştı; `H07_K08_fib_int_ub.c` ve `hata_avcisi/H07_HA6_karekok_tasma.c` bilerek UBSan iletisi üretir.

Sonsuz döngü içeren `hata_avcisi/H07_HA2_ayni_sayac_sonsuz.c` kayıtta `timeout 1` ile bir saniyede durduruldu (çıkış kodu 124; yalnızca satır sayısı ve ilk satırlar kaydedildi). Süre ölçümleri (`H07_K05`, `H07_K06`, `H07_K07`, `H07_11`) 2 çekirdekli paylaşımlı bir sanal makinede yapıldı; süreler çalıştırmadan çalıştırmaya değişir, bölme sayıları değişmez. `ciktilar/H07_K06_olcum_deneyi.txt` dosyasının sonunda ölçüm deneyinin tam günlüğü (ortam, -O0 ve -O2, her satırda 5 tekrar) vardır.

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _tablo_ = tablo başlığında ya da satırlarında atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Web’deki kod blokları dosyanın **tamamıdır** ya da satır numarası dosyayla aynı olan kesitlerdir (quiz ve vize kodları `#include`’dan başlar); simülasyonların (`h07-desen`, `h07-izgara`, `h07-sure`, `h07-vize`) gösterdiği kodlar da bu dosyalardan birebir alınır.

Envanter denetimi: `node shared/kod_envanteri.js 7` → **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H07_01_dikdortgen.c` | Örnek 1 (★) | Örnek 1 (★): n × m yıldız dikdörtgeni | sıfır uyarı | 4.1 | 33 (tablo) | h07-merdiven, h07-desenler (h07-desen), h07-izgara (h07-izgara) |
| `H07_02_ucgenler.c` | Örnek 2 (★) | Örnek 2 (★): dik üçgen ve ters üçgen | sıfır uyarı | 3.3 (şekil) | 33 (tablo) | h07-merdiven, h07-desenler (h07-desen), h07-izgara (h07-izgara) |
| `H07_03_carpim_tablosu.c` | Örnek 3 (★) | Örnek 3 (★): 10 × 10 çarpım tablosu | sıfır uyarı | 4.1 (metin) | 33 (tablo), 34 | h07-merdiven |
| `H07_04_piramit.c` | Örnek 4 (★★) | Örnek 4 (★★): piramit (boşluk + yıldız) | sıfır uyarı | 3.3 (şekil), 4.2 | 1 (şekil), 16, 33 (tablo) | h07-desenler, h07-desenler (h07-desen) |
| `H07_05_floyd_ucgeni.c` | Örnek 5 (★★) | Örnek 5 (★★): Floyd üçgeni ve sayı üçgeni | sıfır uyarı | 4.3 | 33 (tablo), 35 | h07-merdiven |
| `H07_06_asal_naif.c` | Örnek 6 (★★) | Örnek 6 (★★): naif asallık testi | sıfır uyarı | 3.5 (şekil), 4.4 | 19, 20 (şekil), 33 (tablo) | h07-asallik |
| `H07_07_asallar_1_1000.c` | Örnek 7 (★★) | Örnek 7 (★★): 1-1000 arasındaki asallar | sıfır uyarı | 4.4 (metin) | 33 (tablo) | h07-merdiven |
| `H07_08_mukemmel_armstrong.c` | Örnek 8 (★★) | Örnek 8 (★★): mükemmel sayılar ve Armstrong sayıları | sıfır uyarı | 4.5 | 33 (tablo), 36 | h07-merdiven |
| `H07_09_fibonacci.c` | Örnek 9 (★★) | Örnek 9 (★★): Fibonacci dizisi (yinelemeli) | sıfır uyarı | 4.6 | 33 (tablo), 37 (şekil) | h07-merdiven |
| `H07_10_onluk_ikili.c` | Örnek 10 (★★) | Örnek 10 (★★): onluk -> ikili dönüşüm | sıfır uyarı | 4.6 | 33 (tablo), 38 (şekil) | h07-merdiven |
| `H07_11_asal_karekok_sure.c` | Örnek 11 (★★★) | Örnek 11 (★★★): iyileştirilmiş asallık testi (√n sınırı, yalnızca tek bölenler) ve süre ölçümü | sıfır uyarı | 4.7 | 21, 33 (tablo), 39 | h07-asallik |
| `H07_12_e_pi_seri.c` | Örnek 12 (★★★) | Örnek 12 (★★★): e ve π yaklaşımı | sıfır uyarı | 3.6 (şekil), 4.8 (metin) | 22, 23 (şekil), 33 (tablo) | h07-seriler |
| `H07_13_pisagor_ucluleri.c` | Örnek 13 (★★★) | Örnek 13 (★★★): Pisagor üçlüleri | sıfır uyarı | 4.8 | 33 (tablo), 40 (şekil) | h07-merdiven |
| `H07_14_atm_menu.c` | Örnek 14 (★★★) | Menü güdümlü ATM simülasyonu (AP-1 Hafta 7 · ara proje) | sıfır uyarı | 4.9 | 33 (tablo), 41 (şekil), 42 | h07-merdiven |
| `H07_K01_izgara_sayac.c` | Kavram programı | Kavram programı: ızgara modeli | sıfır uyarı | 3.1 | 11, 12 (şekil) | h07-izgara |
| `H07_K02_yineleme_sayilari.c` | Kavram programı | Kavram programı: kaç yineleme? | sıfır uyarı | 3.2 (tablo) | 14 (not) | h07-izgara, h07-izgara (h07-izgara) |
| `H07_K03_elmas.c` | Kavram programı | Kavram programı: elmas deseni | sıfır uyarı | 3.3 (metin), 4.2 (metin) | 17 | h07-desenler, h07-desenler (h07-desen) |
| `H07_K04_ic_ice_cikis.c` | Kavram programı | Kavram programı: iç içe döngüden çıkış | sıfır uyarı | 3.7 | 24 (not, şekil), 25 | h07-cikis |
| `H07_K05_clock_temel.c` | Kavram programı | Kavram programı: clock() ile süre ölçümü | sıfır uyarı | 3.9 | 28 | h07-kaput |
| `H07_K06_olcum_deneyi.c` | Kavram programı | Kavram programı: ölçüm deneyi | sıfır uyarı | 3.9 (metin, şekil), 4.7 (metin), 8 (metin) | 31 (not), 32 (şekil) | h07-kaput, h07-kaput (h07-sure) |
| `H07_K07_olu_kod.c` | Kavram programı | Kavram programı: ölçülen kod silinebilir! | sıfır uyarı | 3.9 (metin) | 30 (not, şekil) | h07-kaput |
| `H07_K08_fib_int_ub.c` | Kavram programı | Kavram programı: int ile Fibonacci taşması | sıfır uyarı; kasıtlı tanımsız davranış (UBSan ile yakalanır) | 4.6 (metin) | 37 (şekil) | h07-merdiven |
| `H07_K09_yakinsama.c` | Kavram programı | Kavram programı: yakınsama verisi | sıfır uyarı | 3.6 (metin, şekil) | 23 (not, şekil) | h07-seriler |
| `H07_K10_sin_taylor.c` | Kavram programı | Kavram programı: sin x (Taylor serisi) | sıfır uyarı | 3.6 (metin) | 22 (not) | h07-seriler |
| `H07_K11_bolen_ciftleri.c` | Kavram programı | Kavram programı: neden √n yeter? | sıfır uyarı | 3.5 | 20 (şekil) | h07-asallik |
| `H07_K12_menu_do_while.c` | Kavram programı | Kavram programı: menü döngüsü (do-while) | sıfır uyarı | 3.8 | 26 | h07-menu |
| `H07_K13_menu_while1.c` | Kavram programı | Kavram programı: menü döngüsü (while (1)) | sıfır uyarı | 3.8 (metin) | 26 (not) | h07-menu |
| `H07_K14_oyun_agaci.c` | Kavram programı | Kavram programı: kaba kuvvetin sınırı | sıfır uyarı | 4.8 (metin) | 7 (not, şekil) | h07-buyuk-soru |
| `alistirmalar/H07_A01_cikti_tahmini_x.c` | Alıştırma 7.1 | Alıştırma 7.1 (★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h07-alistirmalar |
| `alistirmalar/H07_A02_break_continue_ic_ice.c` | Alıştırma 7.2 | Alıştırma 7.2 (★★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h07-alistirmalar |
| `alistirmalar/H07_A03_hata_bul_ters_piramit.c` | Alıştırma 7.3 | Alıştırma 7.3 (★★, hata bul) | sıfır uyarı; kasıtlı mantık hatası | 8 (alıştırma) | — | h07-alistirmalar |
| `alistirmalar/H07_A04_hata_bul_asal_listesi.c` | Alıştırma 7.4 | Alıştırma 7.4 (★★, hata bul) | sıfır uyarı; kasıtlı mantık hatası | 8 (alıştırma) | — | h07-alistirmalar |
| `alistirmalar/H07_A05_parsons_sayi_ucgeni.c` | Alıştırma 7.5 | Alıştırma 7.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h07-alistirmalar |
| `alistirmalar/H07_A06_kod_tamamla_ust_ucgen.c` | Alıştırma 7.6 | Alıştırma 7.6 (★★, kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h07-alistirmalar |
| `hata_avcisi/H07_HA1_ic_toplayici.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | 44 | h07-hata-avcisi |
| `hata_avcisi/H07_HA1_ic_toplayici_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 (düzeltilmiş) | sıfır uyarı | — | 44 | h07-hata-avcisi |
| `hata_avcisi/H07_HA2_ayni_sayac.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 | 45 | h07-hata-avcisi |
| `hata_avcisi/H07_HA2_ayni_sayac_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 (düzeltilmiş) | sıfır uyarı | — | — | h07-hata-avcisi |
| `hata_avcisi/H07_HA2_ayni_sayac_sonsuz.c` | Hata Avcısı 2 (kasıtlı hata, sonsuz döngü) | Hata Avcısı 2 (ikinci belirti) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | — | h07-hata-avcisi |
| `hata_avcisi/H07_HA3_break_ic.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | 45 | h07-hata-avcisi |
| `hata_avcisi/H07_HA3_break_ic_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 (düzeltilmiş) | sıfır uyarı | — | — | h07-hata-avcisi |
| `hata_avcisi/H07_HA4_asal_sinirlar.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | 46 | h07-hata-avcisi |
| `hata_avcisi/H07_HA4_asal_sinirlar_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4 (düzeltilmiş) | sıfır uyarı | — | — | h07-hata-avcisi |
| `hata_avcisi/H07_HA5_tam_bolme.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 (metin) | 46 | h07-hata-avcisi |
| `hata_avcisi/H07_HA5_tam_bolme_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 (düzeltilmiş) | sıfır uyarı | — | — | h07-hata-avcisi |
| `hata_avcisi/H07_HA6_karekok_tasma.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık hatası | 5 | 47 | h07-hata-avcisi |
| `hata_avcisi/H07_HA6_karekok_tasma_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 (düzeltilmiş) | sıfır uyarı | — | 47 | h07-hata-avcisi |
| `proje/mini_obs_v0_7.c` | Mini-OBS v0.7 | Mini-OBS v0.7 (AP-1 Hafta 7 · ara proje) | sıfır uyarı | 7.1 (şekil) | 48 (şekil) | h07-mini-obs |
| `quiz/H07_Q01_dongu_turleri.c` | Geri çağırma S1 | Geçen haftadan S1 (H6: üç döngü) | sıfır uyarı | 2 (metin) | 3 | h07-gecen-hafta |
| `quiz/H07_Q02_nobetci_toplam.c` | Geri çağırma S2 | Geçen haftadan S2 (H6: nöbetçi değer) | sıfır uyarı | 2 (metin) | 4 | h07-gecen-hafta |
| `quiz/H07_Q03_scanf_donus.c` | Geri çağırma S3 | Geçen haftadan S3 (H6: scanf dönüş değeri) | sıfır uyarı | 2 (metin) | 4 | h07-gecen-hafta |
| `quiz/H07_Q11_ic_ice_sayac.c` | Web quiz sorusu | Kendini sına S1 | sıfır uyarı | — | 13 | h07-quiz |
| `quiz/H07_Q12_ucgen_sayac.c` | Web quiz sorusu | Kendini sına S2 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_Q13_desen_cikti.c` | Web quiz sorusu | Kendini sına S3 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_Q14_break_ic_ice.c` | Web quiz sorusu | Kendini sına S4 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_Q15_kare_sinir.c` | Web quiz sorusu | Kendini sına S5 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_Q16_tam_bolme_seri.c` | Web quiz sorusu | Kendini sına S6 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_Q17_fibonacci_pencere.c` | Web quiz sorusu | Kendini sına S7 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_Q18_ikili_kalanlar.c` | Web quiz sorusu | Kendini sına S8 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_Q19_menu_switch_break.c` | Web quiz sorusu | Kendini sına S9 | sıfır uyarı | — | — | h07-quiz |
| `quiz/H07_V11_kacis_dizileri.c` | Vize bankası (H1) | Vize hazırlık soru bankası (H1: kaçış dizileri) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V22_oklid_tur.c` | Vize bankası (H2) | Vize hazırlık soru bankası (H2: Öklid algoritması ve izleme) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V31_char_aritmetigi.c` | Vize bankası (H3) | Vize hazırlık soru bankası (H3: char bir tamsayıdır) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V32_sizeof.c` | Vize bankası (H3) | Vize hazırlık soru bankası (H3: veri tiplerinin boyutu) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V33_scanf_kismi.c` | Vize bankası (H3) | Vize hazırlık soru bankası (H3: scanf dönüş değeri) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V41_negatif_bolme.c` | Vize bankası (H4) | Vize hazırlık soru bankası (H4: tamsayı bölmesi ve kalan) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V42_sonek_artirma.c` | Vize bankası (H4) | Vize hazırlık soru bankası (H4: sonek ++) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V43_int_bolme_double.c` | Vize bankası (H4) | Vize hazırlık soru bankası (H4: tamsayı bölmesi ve tip dönüşümü) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V44_kisa_devre.c` | Vize bankası (H4) | Vize hazırlık soru bankası (H4: kısa devre değerlendirme) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V51_else_if_sirasi.c` | Vize bankası (H5) | Vize hazırlık soru bankası (H5: else-if zincirinde sıra) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V52_switch_dusme.c` | Vize bankası (H5) | Vize hazırlık soru bankası (H5: switch ve düşme) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V61_carparak_artan.c` | Vize bankası (H6) | Vize hazırlık soru bankası (H6: for döngüsünde güncelleme) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V62_break_continue.c` | Vize bankası (H6) | Vize hazırlık soru bankası (H6: break ve continue) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V63_do_while_bir_kez.c` | Vize bankası (H6) | Vize hazırlık soru bankası (H6: do-while) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V71_ic_ice_j_kucuk_i.c` | Vize bankası (H7) | Vize hazırlık soru bankası (H7: iç içe döngüde yineleme sayısı) | sıfır uyarı | — | — | h07-vize |
| `quiz/H07_V74_break_kosegen.c` | Vize bankası (H7) | Vize hazırlık soru bankası (H7: iç içe döngüde break) | sıfır uyarı | — | — | h07-vize |

**Diğer dosyalar**

- `proje/mini_obs_v0_7.c` — Mini-OBS v0.7’nin kopyası (asıl yer: `91_Proje_MiniOBS/v0.7/`; testler ve gerçek çıktılar orada).
- Alıştırma çözümleri bu klasörde **yoktur**: `92_Degerlendirme/cozum_kodlari/H07/` (öğretim üyesi için).
- `AP1_H07_kodlar.zip` — bu klasörün (`.c`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H07_kodlar/` klasörü oluşur.

Materyalde geçmeyen dosya yoktur.

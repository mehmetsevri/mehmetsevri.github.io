/* H07_K03_elmas.c — Hafta 7 · Kavram programı: elmas deseni
 * Amaç   : satır-sütun düşüncesi: elmas = piramit (i = 1..n) + ters piramit
 *          (i = n-1..1); her iki yarıda da i. satır n - i boşluk ve 2i - 1
 *          yıldızdır. Aynı formül, dış döngünün yönü değişince ters çalışır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H07_K03_elmas.c -o elmas
 * Örnek  : girdi "4" -> Toplam 25 yıldız
 */
#include <stdio.h>

int main(void)
{
    int n;
    printf("Elmasın yarı yüksekliği n (1-20): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > 20) {
        printf("Geçersiz girdi.\n");
        return 1;
    }

    int toplam = 0;
    for (int i = 1; i <= n; i++) {  /* üst yarı: genişleyen */
        for (int b = 1; b <= n - i; b++) {
            printf(" ");
        }
        for (int y = 1; y <= 2 * i - 1; y++) {
            printf("*");
            toplam++;
        }
        printf("\n");
    }
    for (int i = n - 1; i >= 1; i--) {  /* alt yarı: daralan */
        for (int b = 1; b <= n - i; b++) {
            printf(" ");
        }
        for (int y = 1; y <= 2 * i - 1; y++) {
            printf("*");
            toplam++;
        }
        printf("\n");
    }
    printf("Toplam %d yıldız\n", toplam);
    return 0;
}

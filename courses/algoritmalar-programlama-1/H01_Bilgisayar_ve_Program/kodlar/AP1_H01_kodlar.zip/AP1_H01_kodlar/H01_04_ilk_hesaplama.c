/* H01_04_ilk_hesaplama.c · Hafta 1 · Örnek 4: %d belirtecine ilk bakış
 * Derle: gcc -std=c17 -Wall -Wextra -pedantic H01_04_ilk_hesaplama.c -o hesap
 * Çıktı: ciktilar/H01_04_ilk_hesaplama.txt */
#include <stdio.h>

int main(void)
{
    printf("3 + 4\n");                 /* metin: olduğu gibi yazılır */
    printf("%d\n", 3 + 4);             /* ifade: önce hesaplanır     */
    printf("%d + %d = %d\n", 12, 30, 12 + 30);
    printf("Bir günde %d saniye var.\n", 24 * 60 * 60);
    return 0;
}

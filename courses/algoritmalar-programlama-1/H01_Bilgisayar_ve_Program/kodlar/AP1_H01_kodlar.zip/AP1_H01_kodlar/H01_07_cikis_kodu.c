/* H01_07_cikis_kodu.c · Hafta 1 · Örnek 7: Çıkış kodu (echo $?)
 * Derle: gcc -std=c17 -Wall -Wextra -pedantic H01_07_cikis_kodu.c -o cikis
 * Çıktı: ekrana ileti; çıkış kodu 3 */
#include <stdio.h>

int main(void)
{
    printf("Program çalıştı; işletim sistemine 3 döndürüyor.\n");
    return 3;   /* 0: başarılı, 0 dışı: bir sorun oldu */
}

/* H01_Q06_kacis_ters_egik.c · Hafta 1 · Quiz sorusu 6 (web “Kendini sına”)
 * Materyalde: web “Kendini sına” 6. soru; aynı satır sunumun çıkış biletinde
 *          (3. soru) metin içinde geçer.
 * Soru   : printf("A\tB\\n"); ne yazdırır?  (Doğru yanıt: D)
 * Not    : \\ tek bir ters eğik çizgi yazar, ardından gelen n sıradan harftir;
 *          satır sonu YOKTUR. Baytları görmek için:  ./q06 | od -c
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_Q06_kacis_ters_egik.c -o q06
 * Çıktı  : ciktilar/H01_Q06_kacis_ters_egik.txt */
#include <stdio.h>

int main(void)
{
    printf("A\tB\\n");
    return 0;
}

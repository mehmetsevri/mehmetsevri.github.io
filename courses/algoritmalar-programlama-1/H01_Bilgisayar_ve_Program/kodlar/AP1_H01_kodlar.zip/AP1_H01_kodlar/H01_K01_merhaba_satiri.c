/* H01_K01_merhaba_satiri.c · Hafta 1 · Kavram programı: Büyük Sorunun tek satırı
 * Materyalde: sunum slayt 1 (kapak) ve slayt 4 (“Bir satır koddan ekrandaki
 *             piksellere”, etikette merhaba.c) — printf("Merhaba"); satırı
 * Not    : "Merhaba" sonunda \n olmadığı için satır sonunu ayrı bir printf yazar;
 *          böylece kabuğun istemi (prompt) yeni satırda başlar.
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_K01_merhaba_satiri.c -o merhaba_satiri
 * Çıktı  : ciktilar/H01_K01_merhaba_satiri.txt */
#include <stdio.h>

int main(void)
{
    printf("Merhaba");
    printf("\n");
    return 0;
}

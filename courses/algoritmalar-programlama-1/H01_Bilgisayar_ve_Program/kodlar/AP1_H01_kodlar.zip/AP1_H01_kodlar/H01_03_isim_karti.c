/* H01_03_isim_karti.c · Hafta 1 · Örnek 3: ASCII sanatıyla isim kartı
 * Derle: gcc -std=c17 -Wall -Wextra -pedantic H01_03_isim_karti.c -o kart
 * Çıktı: ciktilar/H01_03_isim_karti.txt */
#include <stdio.h>

int main(void)
{
    printf("+==========================================+\n");
    printf("|   ____                                   |\n");
    printf("|  / ___|   Algoritma ve Programlama - I   |\n");
    printf("| | |       Hafta 1 · İlk C programım      |\n");
    printf("| | |___                                   |\n");
    printf("|  \\____|   Öğrenci : Ada Yılmaz           |\n");
    printf("|           Bölüm   : Bilgisayar Müh.      |\n");
    printf("+==========================================+\n");
    return 0;
}

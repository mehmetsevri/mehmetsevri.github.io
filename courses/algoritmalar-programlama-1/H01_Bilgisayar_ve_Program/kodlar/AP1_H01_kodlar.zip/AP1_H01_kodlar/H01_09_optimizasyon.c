/* H01_09_optimizasyon.c · Hafta 1 · Örnek 9 (Merak): -O0 / -O2 karşılaştırması
 * Derle: gcc -std=c17 -Wall -Wextra -pedantic -S -O0 \
 *        H01_09_optimizasyon.c
 * Çıktı: Toplam: 7 */
#include <stdio.h>

int main(void)
{
    int a = 3;
    int b = 4;
    int toplam = a + b;
    printf("Toplam: %d\n", toplam);
    return 0;
}

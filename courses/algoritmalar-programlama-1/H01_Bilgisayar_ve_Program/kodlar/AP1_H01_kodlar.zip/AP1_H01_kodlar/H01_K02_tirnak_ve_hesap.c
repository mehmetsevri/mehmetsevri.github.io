/* H01_K02_tirnak_ve_hesap.c · Hafta 1 · Kavram programı: tırnak içi metin mi, hesaplanan ifade mi?
 * Materyalde: sunum slayt 39 (soru slaytı: printf("%d\n", 2 * 60 * 60); ne yazdırır?)
 * Fikir  : Tırnak içindeki 2 * 60 * 60 yalnızca metindir; %d ile verilen ifade ise
 *          derleme/çalışma sırasında hesaplanır (7200).
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_K02_tirnak_ve_hesap.c -o tirnak_hesap
 * Çıktı  : ciktilar/H01_K02_tirnak_ve_hesap.txt */
#include <stdio.h>

int main(void)
{
    printf("2 * 60 * 60\n");
    printf("%d\n", 2 * 60 * 60);
    return 0;
}

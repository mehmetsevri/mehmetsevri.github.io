/* H01_01_merhaba_dunya.c · Hafta 1 · Örnek 1: İlk C programı
 * Derle: gcc -std=c17 -Wall -Wextra -pedantic H01_01_merhaba_dunya.c -o merhaba
 * Çıktı: Merhaba, Dünya! */
#include <stdio.h>

int main(void)
{
    printf("Merhaba, Dünya!\n");
    return 0;
}

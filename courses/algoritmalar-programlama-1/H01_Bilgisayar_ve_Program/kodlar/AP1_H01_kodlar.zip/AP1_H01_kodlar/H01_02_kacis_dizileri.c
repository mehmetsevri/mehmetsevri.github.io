/* H01_02_kacis_dizileri.c · Hafta 1 · Örnek 2: Kaçış dizileri ve %%
 * Derle: gcc -std=c17 -Wall -Wextra -pedantic H01_02_kacis_dizileri.c -o kacis
 * Çıktı: ciktilar/H01_02_kacis_dizileri.txt */
#include <stdio.h>

int main(void)
{
    printf("Hafta\tKonu\n");               /* \t : sekme        */
    printf("1\tBilgisayar ve program\n");
    printf("2\tAlgoritmik düşünme\n\n");   /* \n\n : boş satır  */
    printf("Tırnak: \"C dili\"\n");        /* \" : çift tırnak  */
    printf("Yol   : C:\\kodlar\\h01\n");   /* \\ : ters çizgi   */
    printf("Oran  : %%100\n");             /* %% : printf kuralı */
    return 0;
}

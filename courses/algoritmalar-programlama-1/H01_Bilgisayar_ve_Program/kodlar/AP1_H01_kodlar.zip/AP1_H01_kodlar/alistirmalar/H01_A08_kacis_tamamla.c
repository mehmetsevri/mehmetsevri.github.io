/* H01_A08_kacis_tamamla.c · Hafta 1 · Alıştırma 1.8 (★, Kod tamamla)
 * TAMAMLANACAK: iki printf satırındaki boşluklar (__) doldurulacak.
 *          Bu hâliyle derlenir (__ sıradan karakterdir) ama istenen çıktıyı vermez.
 * Materyalde: ders notu Bölüm 8, Alıştırma 1.8 · web “Alıştırmalar” 8
 * Görev  : Ekranda “Ad:” ile “"Ada"” arasında bir sekme, ikinci satırda C:\temp
 *          görünmeli. Her __ yerine uygun kaçış dizisini yazın.
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_A08_kacis_tamamla.c -o a08
 * Çıktı  : ciktilar/H01_A08_kacis_tamamla.txt (boşluklu hâlin gerçek çıktısı) */
#include <stdio.h>

int main(void)
{
    printf("Ad:__\"Ada__\n");
    printf("Klasör: C:__temp\n");
    return 0;
}

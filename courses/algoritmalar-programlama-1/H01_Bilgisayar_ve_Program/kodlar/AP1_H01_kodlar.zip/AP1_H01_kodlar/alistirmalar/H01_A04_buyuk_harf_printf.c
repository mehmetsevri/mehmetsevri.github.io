/* H01_A04_buyuk_harf_printf.c · Hafta 1 · Alıştırma 1.4 (★★, Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR — çalıştırılabilir dosya oluşmaz.
 * Materyalde: ders notu Bölüm 8, Alıştırma 1.4 · web “Alıştırmalar” 4
 *          (materyalde yalnızca main gövdesindeki iki satır gösterilir)
 * Görev  : GCC 13 ile hangi aşamada, hangi iletiyle başarısız olur?
 *          GCC 14'te ne değişir?
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_A04_buyuk_harf_printf.c -o a04
 * Gerçek derleyici/bağlayıcı iletisi (GCC 13.3): ciktilar/H01_A04_buyuk_harf_printf.txt
 */
#include <stdio.h>

int main(void)
{
    Printf("Sonuç: %d\n", 6 * 7);
    return 0;
}

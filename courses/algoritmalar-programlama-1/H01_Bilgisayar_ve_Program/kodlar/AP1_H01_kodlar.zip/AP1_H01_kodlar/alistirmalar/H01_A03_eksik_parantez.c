/* H01_A03_eksik_parantez.c · Hafta 1 · Alıştırma 1.3 (★, Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR — derlenmez.
 * Materyalde: ders notu Bölüm 8, Alıştırma 1.3 · web “Alıştırmalar” 3
 * Görev  : Program neden derlenmez? Kaç ileti göreceğinizi ve ilk iletinin hangi
 *          satırı göstereceğini tahmin edin.
 * Not    : Ders notu ve web bu dosyanın satırlarını (11–17) numaralarıyla
 *          gösterir; printf satırı 15. satırdır.
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_A03_eksik_parantez.c -o a03
 * Gerçek derleyici iletisi: ciktilar/H01_A03_eksik_parantez.txt
 */
#include <stdio.h>

int main(void)
{
    printf("Merhaba\n";
    return 0;
}

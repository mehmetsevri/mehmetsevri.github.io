/* H01_A05_ileti_okuma.c · Hafta 1 · Alıştırma 1.5 (★★, Hata bul: ileti okuma)
 * BU DOSYA KASITLI HATA İÇERİR — derlenmez.
 * Materyalde: ders notu Bölüm 8, Alıştırma 1.5 · web “Alıştırmalar” 5
 * Görev  : İleti 5. satırı gösterdiği hâlde neden sonraki satırdaki printf'ten
 *          söz ediyor? Nasıl düzeltilir?
 * Not    : Ders notu ve web bu dosyanın satırlarını (12–19) numaralarıyla ve
 *          gerçek iletisini gösterir: H01_A05_ileti_okuma.c:16:30: error:
 *          expected ';' before 'printf'.
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_A05_ileti_okuma.c -o a05
 * Gerçek derleyici iletisi: ciktilar/H01_A05_ileti_okuma.txt
 */
#include <stdio.h>

int main(void)
{
    printf("Birinci satır\n")
    printf("İkinci satır\n");
    return 0;
}

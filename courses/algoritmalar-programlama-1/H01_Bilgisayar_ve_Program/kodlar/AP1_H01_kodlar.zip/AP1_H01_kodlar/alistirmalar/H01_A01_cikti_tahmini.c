/* H01_A01_cikti_tahmini.c · Hafta 1 · Alıştırma 1.1 (★, Çıktı tahmini)
 * Materyalde: ders notu Bölüm 8, Alıştırma 1.1 · web “Alıştırmalar” 1
 * Görev  : main içindeki dört printf satırının ekran çıktısını, boşluk ve satır
 *          sonlarıyla birlikte ÖNCE kâğıt üzerinde tahmin edin; sonra derleyip
 *          çalıştırarak denetleyin.
 * Derle  : gcc -std=c17 -Wall -Wextra -pedantic H01_A01_cikti_tahmini.c -o a01
 * Çıktı  : ciktilar/H01_A01_cikti_tahmini.txt (tahmininizi yapmadan açmayın) */
#include <stdio.h>

int main(void)
{
    printf("Bir\tİki\n");
    printf("Üç\\n\n");
    printf("%d\n", 5 + 5);
    printf("5 + 5\n");
    return 0;
}

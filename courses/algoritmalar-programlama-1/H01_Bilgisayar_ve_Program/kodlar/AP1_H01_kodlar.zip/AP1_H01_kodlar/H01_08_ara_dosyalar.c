/* H01_08_ara_dosyalar.c · Hafta 1 · Örnek 8: .i, .s ve .o ara dosyaları
 * Derle: gcc -std=c17 -Wall -Wextra -pedantic -save-temps -c \
 *        H01_08_ara_dosyalar.c
 * Çıktı: Merhaba, Dünya! */
#include <stdio.h>

#define MESAJ "Merhaba, Dünya!\n"  /* önişlemci MESAJ'ı metinle değiştirir */

int main(void)
{
    printf(MESAJ);
    return 0;
}

# AP-1 · Hafta 1 · Kod dizini

**Bilgisayar Nasıl Çalışır? Programın Yaşam Döngüsü ve İlk C Programı** — bu klasördeki 20 `.c` dosyasının türü, materyalde (ders notu, sunum, web sayfası) geçtiği yerler ve derleme durumu. Ders notunda, sunumda ve web sayfasında gösterilen her C kod parçası bu dosyalardan birinde harfi harfine bulunur (denetim: `node shared/kod_envanteri.js 1` → EKSİK 0).

## Nasıl derlenir ve çalıştırılır?

- **Linux / macOS (gcc):** `gcc -std=c17 -Wall -Wextra -pedantic DOSYA.c -o program && ./program`
- **Windows (MinGW-w64, komut istemi):** `chcp 65001 && gcc -std=c17 -Wall -Wextra -pedantic DOSYA.c -o program.exe && program.exe`
- **Code::Blocks:** *Settings › Compiler › Compiler settings › Other compiler options* alanına `-std=c17 -Wall -Wextra -pedantic` yazın; dosyayı açıp *Build › Build and run* (F9).

Notlar: `ciktilar/` klasörlerindeki her dosya bu ortamda alınmış **gerçek** derleme ve çalıştırma çıktısıdır (GCC 13.3.0, Ubuntu 24.04, x86-64, LP64). macOS'ta `gcc` komutu aslında Clang'i çalıştırdığı için ileti metinleri farklıdır; Windows'ta (MinGW-w64) `long` 4 bayttır ve bazı iletiler farklı olabilir.

**Kasıtlı hatalı dosyalar** — `hatali/` klasöründeki **Hata Avcısı dosyaları** (Örnek 5–6) ve `alistirmalar/` altında “BU DOSYA KASITLI HATA İÇERİR” işaretini taşıyanlar — ile başlığında “TAMAMLANACAK” yazan alıştırma dosyasının derlenmemesi ya da istenen çıktıyı vermemesi beklenen durumdur; gerçek derleyici iletileri `ciktilar/` klasörlerindedir.

**`hatali/` = Hata Avcısı dosyaları.** Her dosya “BU DOSYA KASITLI HATA İÇERİR” diye işaretlidir; derleyici iletilerindeki satır numaraları değişmesin diye bu işaret yorumu dosyanın başında değil **sonundadır** (bkz. `hatali/BENIOKU.txt`). Ders notu ve sunum bu dosyaların kod satırlarını (`· satır 1–7`), web sayfası dosyanın tamamını gösterir; iletileri `ciktilar/` altındadır.

## Özet

| Tür | Dosya sayısı |
|---|---|
| merdiven örneği | 7 |
| merdiven örneği · hata avcısı | 4 |
| hata avcısı | 1 |
| kavram | 2 |
| alıştırma | 5 |
| quiz | 1 |
| **Toplam** | **20** |

## Dosyalar

| Dosya | Tür | Açıklama | Materyalde geçtiği yerler | Derleme durumu | Gerçek çıktı |
|---|---|---|---|---|---|
| `H01_01_merhaba_dunya.c` | merdiven örneği | Örnek 1 ★ — ilk C programı: `#include`, `main`, `printf`, `return 0` | **Ders notu:** §4.1 Örnek 1 (tam)<br>**Sunum:** slayt 34, 40<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 1 | sıfır uyarı | `ciktilar/H01_01_merhaba_dunya.txt` |
| `H01_02_kacis_dizileri.c` | merdiven örneği | Örnek 2 ★ — kaçış dizileri (`\n`, `\t`, `\"`, `\\`) ve `%%` | **Ders notu:** §4.2 Örnek 2 (kesit)<br>**Sunum:** slayt 35<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 2 | sıfır uyarı | `ciktilar/H01_02_kacis_dizileri.txt` |
| `H01_03_isim_karti.c` | merdiven örneği | Örnek 3 ★ — ASCII sanatıyla isim kartı; ekranda hizalama | **Ders notu:** §4.3 Örnek 3 (kesit)<br>**Sunum:** slayt 36<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 3<br>_Not:_ Alıştırma 1.7 ve 1.13'te `kart.c` adıyla kullanılır | sıfır uyarı | `ciktilar/H01_03_isim_karti.txt` |
| `H01_04_ilk_hesaplama.c` | merdiven örneği | Örnek 4 ★ — `%d` belirteciyle ilk hesaplama | **Ders notu:** §4.4 Örnek 4 (kesit)<br>**Sunum:** slayt 38<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 4 | sıfır uyarı | `ciktilar/H01_04_ilk_hesaplama.txt` |
| `hatali/H01_05_noktali_virgul.c` | merdiven örneği · hata avcısı | Örnek 5 ★ — `printf` satırında `;` eksik (BU DOSYA KASITLI HATA İÇERİR; işaret yorumu dosyanın SONUNDA) | **Ders notu:** §4.5 Örnek 5 (kesit)<br>**Sunum:** slayt 40<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 5<br>_Not:_ Hata Avcısı dosyası; ders notu §5 Hata Avcısı tablosu | kasıtlı hata — derlenmez (derleyici hatası) | `ciktilar/H01_05_noktali_virgul.txt` |
| `hatali/H01_05b_suslu_parantez.c` | hata avcısı | Örnek 5'in eşi — kapanış `}` eksik (BU DOSYA KASITLI HATA İÇERİR; işaret yorumu dosyanın SONUNDA) | _Not:_ kod bloğu olarak gösterilmez; ders notu §4.6 hata tablosunda adıyla, web Örnek 5 metninde iletisiyle anılır | kasıtlı hata — derlenmez (derleyici hatası) | `ciktilar/H01_05b_suslu_parantez.txt` |
| `hatali/H01_06a_prinft.c` | merdiven örneği · hata avcısı | Örnek 6 ★★ (amiral) — `prinft`: derleyici uyarısı + bağlayıcı hatası (BU DOSYA KASITLI HATA İÇERİR; işaret yorumu dosyanın SONUNDA) | **Ders notu:** §4.6 Örnek 6 (kesit)<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 6<br>_Not:_ ders notu §4.6 tablosu | kasıtlı hata — bağlayıcı hatası, program oluşmaz | `ciktilar/H01_06a_prinft.txt` |
| `hatali/H01_06b_main_buyuk_harf.c` | merdiven örneği · hata avcısı | Örnek 6 ★★ — `Main`: `undefined reference to main` (BU DOSYA KASITLI HATA İÇERİR; işaret yorumu dosyanın SONUNDA) | **Web:** Örnek merdiveni (#h01-ornekler) › Örnek 6<br>_Not:_ ders notu §4.6 tablosunda adıyla | kasıtlı hata — bağlayıcı hatası, program oluşmaz | `ciktilar/H01_06b_main_buyuk_harf.txt` |
| `hatali/H01_06c_include_eksik.c` | merdiven örneği · hata avcısı | Örnek 6 ★★ — `#include <stdio.h>` yok: yalnızca uyarı, program yine oluşur (BU DOSYA KASITLI HATA İÇERİR; işaret yorumu dosyanın SONUNDA) | **Web:** Örnek merdiveni (#h01-ornekler) › Örnek 6<br>_Not:_ ders notu §4.6 tablosunda adıyla | kasıtlı hata — uyarı verir, program oluşur | `ciktilar/H01_06c_include_eksik.txt` |
| `H01_07_cikis_kodu.c` | merdiven örneği | Örnek 7 ★★ — `return 3;` ve çıkış kodu (`echo $?`) | **Ders notu:** §4.7 Örnek 7 (kesit)<br>**Sunum:** slayt 43<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 7 | sıfır uyarı | `ciktilar/H01_07_cikis_kodu.txt` |
| `H01_08_ara_dosyalar.c` | merdiven örneği | Örnek 8 ★★ (amiral) — `gcc -save-temps -c` ile `.i`, `.s`, `.o` ara dosyaları | **Ders notu:** §4.8 Örnek 8 (kesit)<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 8 | sıfır uyarı | `ciktilar/H01_08_ara_dosyalar.txt` |
| `H01_09_optimizasyon.c` | merdiven örneği | Örnek 9 ★★★ (Merak) — `-O0` / `-O2` assembly karşılaştırması | **Ders notu:** §4.9 Örnek 9 (kesit)<br>**Sunum:** slayt 46<br>**Web:** Örnek merdiveni (#h01-ornekler) › Örnek 9 | sıfır uyarı | `ciktilar/H01_09_optimizasyon.txt` |
| `H01_K01_merhaba_satiri.c` | kavram | Haftanın Büyük Sorusundaki tek satır: `printf("Merhaba");` | **Sunum:** slayt 1, 4<br>_Not:_ kapak (slayt 1) ve slayt 4'teki kod panelinde `H01_K01_merhaba_satiri.c · satır 12` etiketiyle | sıfır uyarı | `ciktilar/H01_K01_merhaba_satiri.txt` |
| `H01_K02_tirnak_ve_hesap.c` | kavram | Tırnak içindeki `2 * 60 * 60` metin, `%d` ile verilen ifade hesaplanır (7200) | **Sunum:** slayt 39<br>_Not:_ sunumdaki soru slaytı (`· satır 11–12`, yanıt: B) | sıfır uyarı | `ciktilar/H01_K02_tirnak_ve_hesap.txt` |
| `alistirmalar/H01_A01_cikti_tahmini.c` | alıştırma | Alıştırma 1.1 ★ Çıktı tahmini — `\t`, `\\n`, `%d`, tırnak içi ifade | **Ders notu:** §8 Alıştırma 1.1 (kesit)<br>**Web:** Alıştırmalar (#h01-alistirmalar), 1. madde | sıfır uyarı | `alistirmalar/ciktilar/H01_A01_cikti_tahmini.txt` |
| `alistirmalar/H01_A03_eksik_parantez.c` | alıştırma | Alıştırma 1.3 ★ Hata bul — `printf("Merhaba\n";` kapanış `)` eksik (KASITLI HATALI) | **Ders notu:** §8 Alıştırma 1.3 (kesit)<br>**Web:** Alıştırmalar (#h01-alistirmalar), 3. madde<br>_Not:_ materyalde dosyanın 13–17. satırları numaralarıyla gösterilir | kasıtlı hata — derlenmez (derleyici hatası) | `alistirmalar/ciktilar/H01_A03_eksik_parantez.txt` |
| `alistirmalar/H01_A04_buyuk_harf_printf.c` | alıştırma | Alıştırma 1.4 ★★ Hata bul — `Printf`: GCC 13'te uyarı + bağlayıcı hatası (KASITLI HATALI) | **Ders notu:** §8 Alıştırma 1.4 (kesit)<br>**Web:** Alıştırmalar (#h01-alistirmalar), 4. madde<br>_Not:_ materyalde dosyanın 12–16. satırları numaralarıyla gösterilir | kasıtlı hata — bağlayıcı hatası, program oluşmaz | `alistirmalar/ciktilar/H01_A04_buyuk_harf_printf.txt` |
| `alistirmalar/H01_A05_ileti_okuma.c` | alıştırma | Alıştırma 1.5 ★★ İleti okuma — `;` eksik, ileti sonraki satırdaki `printf`'ten söz eder (KASITLI HATALI) | **Ders notu:** §8 Alıştırma 1.5 (kesit)<br>**Web:** Alıştırmalar (#h01-alistirmalar), 5. madde<br>_Not:_ materyalde dosyanın 14–19. satırları ve gerçek iletisi (`H01_A05_ileti_okuma.c:16:30`) gösterilir | kasıtlı hata — derlenmez (derleyici hatası) | `alistirmalar/ciktilar/H01_A05_ileti_okuma.txt` |
| `alistirmalar/H01_A08_kacis_tamamla.c` | alıştırma | Alıştırma 1.8 ★ Kod tamamla — `__` boşluklarına kaçış dizileri (TAMAMLANACAK) | **Ders notu:** §8 Alıştırma 1.8 (kesit)<br>**Web:** Alıştırmalar (#h01-alistirmalar), 8. madde | tamamlanacak — boşluklu hâli derlenir (uyarısız) ama istenen çıktıyı vermez | `alistirmalar/ciktilar/H01_A08_kacis_tamamla.txt` |
| `quiz/H01_Q06_kacis_ters_egik.c` | quiz | Web quiz 6 — `printf("A\tB\\n");` ne yazdırır? (`od -c` ile bayt dökümü) | **Web:** Kendini sına (#h01-quiz), 6. soru<br>_Not:_ aynı satır sunumun çıkış biletinde (3. soru) metin içinde | sıfır uyarı | `quiz/ciktilar/H01_Q06_kacis_ters_egik.txt` |

Kısaltmalar: *§* ders notu bölümü; *(tam)* dosyanın tamamı, *(kesit)* dosyadan ardışık satırlar gösterilir; web bağlantıları bölüm kimliğidir (`#…`).

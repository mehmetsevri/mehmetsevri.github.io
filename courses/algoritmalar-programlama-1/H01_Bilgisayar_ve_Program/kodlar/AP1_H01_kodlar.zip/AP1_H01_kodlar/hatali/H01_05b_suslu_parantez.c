#include <stdio.h>

int main(void)
{
    printf("Merhaba, Dünya!\n");
    return 0;

/* BU DOSYA KASITLI HATA İÇERİR.
 * Hata Avcısı (Örnek 5'in eşi): kapanış } eksik. */

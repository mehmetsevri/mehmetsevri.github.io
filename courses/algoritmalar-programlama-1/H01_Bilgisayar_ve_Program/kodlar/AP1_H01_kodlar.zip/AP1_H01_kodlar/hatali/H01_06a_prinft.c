#include <stdio.h>

int main(void)
{
    prinft("Merhaba, Dünya!\n");
    return 0;
}

/* BU DOSYA KASITLI HATA İÇERİR.
 * Hata Avcısı (Örnek 6): printf yerine prinft. */

#include <stdio.h>

int Main(void)
{
    printf("Merhaba, Dünya!\n");
    return 0;
}

/* BU DOSYA KASITLI HATA İÇERİR.
 * Hata Avcısı (Örnek 6): main yerine Main. */

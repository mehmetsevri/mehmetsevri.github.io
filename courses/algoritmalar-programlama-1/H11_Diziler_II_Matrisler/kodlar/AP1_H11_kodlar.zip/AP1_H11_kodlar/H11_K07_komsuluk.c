/* H11_K07_komsuluk.c — Hafta 11 · Kavram programı: 4 ve 8 komşuluk
 * Amaç   : Komşu konumları iki uzaklık dizisinde (di, dj) tutulur; ilk 4'ü
 *          4-komşuluk (yukarı, aşağı, sol, sağ), 8'i birlikte 8-komşuluk.
 *          5 × 5 ızgarada köşe, kenar ve iç hücrenin geçerli komşu sayısı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K07_komsuluk.c -o komsuluk
 * Örnek  : -> iç    (2,2): 4-komşu 4, 8-komşu 8
 */
#include <stdio.h>

#define SATIR 5
#define SUTUN 5

const int di[8] = {-1, 1, 0, 0, -1, -1, 1, 1};   /* ilk 4: dik yönler */
const int dj[8] = {0, 0, -1, 1, -1, 1, -1, 1};   /* son 4: çaprazlar */

int gecerli_komsu(int i, int j, int yon_sayisi)
{
    int sayi = 0;
    for (int k = 0; k < yon_sayisi; k++) {
        int ni = i + di[k], nj = j + dj[k];
        if (ni >= 0 && ni < SATIR && nj >= 0 && nj < SUTUN) {
            sayi++;                           /* ızgaranın içinde */
        }
    }
    return sayi;
}

int main(void)
{
    printf("köşe  (0,0): 4-komşu %d, 8-komşu %d\n",
           gecerli_komsu(0, 0, 4), gecerli_komsu(0, 0, 8));
    printf("kenar (0,2): 4-komşu %d, 8-komşu %d\n",
           gecerli_komsu(0, 2, 4), gecerli_komsu(0, 2, 8));
    printf("iç    (2,2): 4-komşu %d, 8-komşu %d\n",
           gecerli_komsu(2, 2, 4), gecerli_komsu(2, 2, 8));
    return 0;
}

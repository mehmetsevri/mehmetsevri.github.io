/* H11_K04_const_parametre.c — Hafta 11 · Kavram programı (Merak Kutusu): const 2B parametre
 * Amaç   : iz() matrisi yalnızca OKUR; parametreyi const yapmak doğaldır.
 *          const DİZİ ile çağrı C17'de sorunsuzdur. Ama const OLMAYAN bir
 *          dizi verilirse double (*)[N] → const double (*)[N] dönüşümü
 *          C17'de uyumsuz sayılır ve -pedantic uyarı verir (C23'te
 *          düzeltildi). Gerçek uyarı: ciktilar/H11_K04_const_parametre.txt
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K04_const_parametre.c -o const_parametre
 * Örnek  : -> iz = 3.0
 */
#include <stdio.h>

#define N 3

/* köşegen toplamı (iz, trace): yalnızca okur */
double iz(const double m[][N])
{
    double toplam = 0.0;
    for (int i = 0; i < N; i++) {
        toplam += m[i][i];
    }
    return toplam;
}

int main(void)
{
    const double birim[N][N] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    printf("iz = %.1f\n", iz(birim));         /* salt okunur parametre */
    return 0;
}

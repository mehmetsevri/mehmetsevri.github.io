/* H11_08_matris_carpim.c — Hafta 11 · Örnek 8 (★★★): Matris çarpımı
 * Amaç   : c[i][j] = Σ a[i][k] * b[k][j]: i. satır ile j. sütunun iç
 *          çarpımı. Üçlü iç içe döngü; c[i][j] her hücrede ÖNCE sıfırlanır.
 *          (n × m) · (m × p) çarpımı n·m·p çarpma yapar; sayaçla doğrulanır.
 *          Kare matriste bu n³'tür: n iki katına çıkınca iş 8 katına çıkar
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_08_matris_carpim.c -o matris_carpim
 * Örnek  : ->  160     4096000     4096000
 */
#include <stdio.h>

#define AZAMI 160

long long carp(int n, int m, int p, int a[][AZAMI], int b[][AZAMI],
               int c[][AZAMI])
{
    long long carpma = 0;                     /* yapılan çarpma sayısı */
    for (int i = 0; i < n; i++) {             /* a'nın satırı */
        for (int j = 0; j < p; j++) {         /* b'nin sütunu */
            c[i][j] = 0;                      /* ÖNCE sıfırla */
            for (int k = 0; k < m; k++) {
                c[i][j] += a[i][k] * b[k][j];
                carpma++;
            }
        }
    }
    return carpma;
}

int main(void)
{
    static int a[AZAMI][AZAMI] = {{1, 2, 3}, {4, 5, 6}};          /* 2 × 3 */
    static int b[AZAMI][AZAMI] = {{7, 8}, {9, 10}, {11, 12}};     /* 3 × 2 */
    static int c[AZAMI][AZAMI];

    long long sayi = carp(2, 3, 2, a, b, c);
    printf("(2 × 3) · (3 × 2) = 2 × 2:\n");
    for (int i = 0; i < 2; i++) {
        printf("%6d%6d\n", c[i][0], c[i][1]);
    }
    printf("çarpma sayısı: %lld (2 · 3 · 2)\n\n", sayi);

    printf("    n     çarpma          n³\n");
    for (int n = 10; n <= AZAMI; n *= 2) {    /* kare matrisler */
        long long n3 = (long long)n * n * n;
        printf("%5d %11lld %11lld\n", n, carp(n, n, n, a, b, c), n3);
    }
    return 0;
}

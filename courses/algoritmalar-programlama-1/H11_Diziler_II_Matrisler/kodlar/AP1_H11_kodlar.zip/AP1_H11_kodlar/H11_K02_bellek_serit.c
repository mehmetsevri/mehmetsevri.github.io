/* H11_K02_bellek_serit.c — Hafta 11 · Kavram programı: 2B dizi bellekte tek şerit
 * Amaç   : int m[3][4]'ün 12 elemanının gerçek adreslerini (%p) ve
 *          &m[0][0]'dan bayt uzaklığını yazdırır; uzaklık
 *          (i * SUTUN + j) * sizeof(int) formülüyle karşılaştırılır.
 *          Satır sonu ile sonraki satırın başı bitişiktir. Uzaklıklar
 *          (char *) işaretçilerle ölçülür: tek nesne m'nin baytları
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K02_bellek_serit.c -o bellek_serit
 * Örnek  : -> &m[1][0] - &m[0][3] = 4 bayt (1 eleman)
 */
#include <stdio.h>
#include <stddef.h>   /* ptrdiff_t */

#define SATIR 3
#define SUTUN 4

int main(void)
{
    int m[SATIR][SUTUN];
    char *taban = (char *)&m[0][0];

    printf("eleman   adres            uzaklık  (i*SUTUN+j)*4\n");
    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            m[i][j] = 10 * i + j;
            ptrdiff_t uzaklik = (char *)&m[i][j] - taban;
            printf("m[%d][%d]  %p  %4td  %8zu\n", i, j, (void *)&m[i][j],
                   uzaklik, (size_t)(i * SUTUN + j) * sizeof(int));
        }
    }
    ptrdiff_t f1 = (char *)&m[1][0] - (char *)&m[0][3];
    ptrdiff_t f2 = (char *)&m[1][0] - (char *)&m[0][2];
    ptrdiff_t boyut = sizeof(int);
    printf("&m[1][0] - &m[0][3] = %td bayt (%td eleman)\n", f1, f1 / boyut);
    printf("&m[1][0] - &m[0][2] = %td bayt (%td eleman)\n", f2, f2 / boyut);
    printf("sizeof m = %zu, sizeof m[1] = %zu (bir satır)\n",
           sizeof m, sizeof m[1]);
    printf("m[1] = %p = &m[1][0] (satırın adresi)\n", (void *)m[1]);
    return 0;
}

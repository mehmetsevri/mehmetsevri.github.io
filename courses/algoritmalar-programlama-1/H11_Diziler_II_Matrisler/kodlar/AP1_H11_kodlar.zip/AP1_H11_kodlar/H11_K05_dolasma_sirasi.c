/* H11_K05_dolasma_sirasi.c — Hafta 11 · Kavram programı: dolaşma sırası ve adım
 * Amaç   : 3 × 4 matrisi satır öncelikli ve sütun öncelikli dolaşırken
 *          ziyaret edilen elemanların &m[0][0]'dan bayt uzaklığı: satır
 *          öncelikli adım hep +4, sütun öncelikli adım +16 (bir satır)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K05_dolasma_sirasi.c -o dolasma_sirasi
 * Örnek  : -> sütun öncelikli: 0 16 32 4 20 36 8 24 40 12 28 44
 */
#include <stdio.h>

#define SATIR 3
#define SUTUN 4

int main(void)
{
    int m[SATIR][SUTUN] = {{0}};
    char *taban = (char *)&m[0][0];

    printf("satır öncelikli:");
    for (int i = 0; i < SATIR; i++) {         /* i dışta, j içte */
        for (int j = 0; j < SUTUN; j++) {
            printf(" %td", (char *)&m[i][j] - taban);
        }
    }
    printf("\nsütun öncelikli:");
    for (int j = 0; j < SUTUN; j++) {         /* j dışta, i içte */
        for (int i = 0; i < SATIR; i++) {
            printf(" %td", (char *)&m[i][j] - taban);
        }
    }
    printf("\n");
    return 0;
}

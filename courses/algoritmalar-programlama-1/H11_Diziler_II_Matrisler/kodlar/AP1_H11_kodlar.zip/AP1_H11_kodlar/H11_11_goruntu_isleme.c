/* H11_11_goruntu_isleme.c — Hafta 11 · Örnek 11 (★★★): Görüntü işleme
 * Amaç   : Gri tonlu görüntü = piksel matrisi (0 siyah ... 255 beyaz). Her
 *          filtre okuduğu matristen AYRI bir matrise yazar: negatif
 *          (255 - p), eşikleme, yatay ayna ve 3 × 3 ortalama
 *          bulanıklaştırma. Kenar politikası: kenar ve köşe pikselinde
 *          yalnızca görüntünün İÇİNDEKİ komşuların ortalaması alınır (köşede
 *          4, kenarda 6, içeride 9 piksel). Sonuç ASCII sanatıyla çizilir
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_11_goruntu_isleme.c -o goruntu_isleme
 * Örnek  : -> 3 × 3 ortalama bulanıklaştırma
 */
#include <stdio.h>

#define YUK 8                                 /* satır sayısı (yükseklik) */
#define GEN 12                                /* sütun sayısı (genişlik) */
#define ESIK 128

void ascii_yazdir(const char *baslik, int g[][GEN])
{
    const char ton[10] = {' ', '.', ':', '-', '=', '+', '*', '#', '%', '@'};
    printf("%s\n", baslik);
    for (int i = 0; i < YUK; i++) {
        for (int j = 0; j < GEN; j++) {
            char c = ton[g[i][j] * 10 / 256];   /* 0..255 → 0..9 */
            printf("%c%c", c, c);             /* kare görünsün: 2 karakter */
        }
        printf("|\n");
    }
}

void sayilari_yazdir(const char *baslik, int g[][GEN])
{
    printf("%s\n", baslik);
    for (int i = 0; i < YUK; i++) {
        for (int j = 0; j < GEN; j++) {
            printf("%4d", g[i][j]);
        }
        printf("\n");
    }
}

void negatif(int g[][GEN], int s[][GEN])
{
    for (int i = 0; i < YUK; i++) {
        for (int j = 0; j < GEN; j++) {
            s[i][j] = 255 - g[i][j];
        }
    }
}

void esikle(int g[][GEN], int s[][GEN], int esik)
{
    for (int i = 0; i < YUK; i++) {
        for (int j = 0; j < GEN; j++) {
            s[i][j] = (g[i][j] >= esik) ? 255 : 0;
        }
    }
}

void ayna(int g[][GEN], int s[][GEN])
{
    for (int i = 0; i < YUK; i++) {
        for (int j = 0; j < GEN; j++) {
            s[i][j] = g[i][GEN - 1 - j];      /* sütun sırası tersine */
        }
    }
}

void bulaniklastir(int g[][GEN], int s[][GEN])
{
    for (int i = 0; i < YUK; i++) {
        for (int j = 0; j < GEN; j++) {
            int toplam = 0, adet = 0;
            for (int di = -1; di <= 1; di++) {
                for (int dj = -1; dj <= 1; dj++) {
                    int ni = i + di, nj = j + dj;
                    if (ni >= 0 && ni < YUK && nj >= 0 && nj < GEN) {
                        toplam += g[ni][nj];
                        adet++;               /* köşe 4, kenar 6, iç 9 */
                    }
                }
            }
            s[i][j] = (toplam + adet / 2) / adet;   /* yuvarlanmış ort. */
        }
    }
}

int main(void)
{
    int g[YUK][GEN] = {                       /* sağa bakan ok + gradyan */
        { 10,  19,  28,  37,  46,  55, 230,  73,  82,  91, 100, 109},
        { 10,  19,  28,  37,  46,  55, 230, 230,  82,  91, 100, 109},
        { 10,  19,  28,  37,  46,  55, 230, 230, 230,  91, 100, 109},
        { 10, 230, 230, 230, 230, 230, 230, 230, 230, 230, 100, 109},
        { 10, 230, 230, 230, 230, 230, 230, 230, 230, 230, 100, 109},
        { 10,  19,  28,  37,  46,  55, 230, 230, 230,  91, 100, 109},
        { 10,  19,  28,  37,  46,  55, 230, 230,  82,  91, 100, 109},
        { 10,  19,  28,  37,  46,  55, 230,  73,  82,  91, 100, 109}
    };
    int s[YUK][GEN];                          /* sonuç: ayrı matris */

    sayilari_yazdir("Özgün (piksel değerleri)", g);
    ascii_yazdir("Özgün", g);
    negatif(g, s);
    ascii_yazdir("Negatif (255 - p)", s);
    esikle(g, s, ESIK);
    ascii_yazdir("Eşik (p >= 128 ise 255, değilse 0)", s);
    ayna(g, s);
    ascii_yazdir("Ayna (soldan sağa ters)", s);
    bulaniklastir(g, s);
    ascii_yazdir("3 × 3 ortalama bulanıklaştırma", s);
    sayilari_yazdir("Bulanık (piksel değerleri)", s);
    return 0;
}

/* H11_03_matris_toplama.c — Hafta 11 · Örnek 3 (★): Matris toplama
 * Amaç   : Eleman eleman işlem: c[i][j] = a[i][j] + b[i][j]. İki matrisin
 *          boyutları aynı olmalıdır (2 × 3 + 2 × 3 → 2 × 3)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_03_matris_toplama.c -o matris_toplama
 * Örnek  : ->   4  5  6   +   40  50  60   =   44  55  66
 */
#include <stdio.h>

#define SATIR 2
#define SUTUN 3

int main(void)
{
    const int a[SATIR][SUTUN] = {{1, 2, 3}, {4, 5, 6}};
    const int b[SATIR][SUTUN] = {{10, 20, 30}, {40, 50, 60}};
    int c[SATIR][SUTUN];

    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            c[i][j] = a[i][j] + b[i][j];      /* aynı konumdaki elemanlar */
        }
    }

    for (int i = 0; i < SATIR; i++) {         /* üç matrisi yan yana yaz */
        for (int j = 0; j < SUTUN; j++) {
            printf("%3d", a[i][j]);
        }
        printf("   %c ", i == 0 ? ' ' : '+');
        for (int j = 0; j < SUTUN; j++) {
            printf("%4d", b[i][j]);
        }
        printf("   %c ", i == 0 ? ' ' : '=');
        for (int j = 0; j < SUTUN; j++) {
            printf("%4d", c[i][j]);
        }
        printf("\n");
    }
    return 0;
}

/* H11_14_spiral.c — Hafta 11 · Örnek 14 (★★★): Spiral matris
 * Amaç   : Sınır yönetimi: dört sınır (ust, alt, sol, sag) içeriden daralır.
 *          Her turda üst satır →, sağ sütun ↓, alt satır ←, sol sütun ↑
 *          dolaşılır; tek satır/sütun kalınca aynı hücre iki kez
 *          işlenmesin diye alt ve sol kenardan önce sınırlar yeniden
 *          denetlenir. Hem spiral DOLDURMA hem spiral OKUMA
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_14_spiral.c -o spiral
 * Örnek  : -> 3 × 5 spiral okuma: 1 2 3 4 5 10 15 14 13 12 11 6 7 8 9
 */
#include <stdio.h>

#define AZAMI_SATIR 5
#define SUTUN 5

/* m'nin ilk satir × sutun bölümünü 1, 2, 3, ... ile spiral sırada doldurur */
void spiral_doldur(int m[][SUTUN], int satir, int sutun)
{
    int ust = 0, alt = satir - 1, sol = 0, sag = sutun - 1, sayi = 1;
    while (ust <= alt && sol <= sag) {
        for (int j = sol; j <= sag; j++) {    /* üst satır: soldan sağa */
            m[ust][j] = sayi++;
        }
        ust++;
        for (int i = ust; i <= alt; i++) {    /* sağ sütun: yukarıdan aşağı */
            m[i][sag] = sayi++;
        }
        sag--;
        if (ust <= alt) {                     /* alt satır kaldı mı? */
            for (int j = sag; j >= sol; j--) {
                m[alt][j] = sayi++;
            }
            alt--;
        }
        if (sol <= sag) {                     /* sol sütun kaldı mı? */
            for (int i = alt; i >= ust; i--) {
                m[i][sol] = sayi++;
            }
            sol++;
        }
    }
}

/* satır öncelikli doldurulmuş matrisi spiral sırada yazdırır */
void spiral_oku(int m[][SUTUN], int satir, int sutun)
{
    int ust = 0, alt = satir - 1, sol = 0, sag = sutun - 1;
    while (ust <= alt && sol <= sag) {
        for (int j = sol; j <= sag; j++) {
            printf(" %d", m[ust][j]);
        }
        ust++;
        for (int i = ust; i <= alt; i++) {
            printf(" %d", m[i][sag]);
        }
        sag--;
        if (ust <= alt) {
            for (int j = sag; j >= sol; j--) {
                printf(" %d", m[alt][j]);
            }
            alt--;
        }
        if (sol <= sag) {
            for (int i = alt; i >= ust; i--) {
                printf(" %d", m[i][sol]);
            }
            sol++;
        }
    }
    printf("\n");
}

int main(void)
{
    int m[AZAMI_SATIR][SUTUN];

    spiral_doldur(m, 4, 5);
    printf("4 × 5 spiral doldurma:\n");
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 5; j++) {
            printf("%4d", m[i][j]);
        }
        printf("\n");
    }

    int satir_sayisi[3] = {3, 1, 5}, sutun_sayisi[3] = {5, 4, 1};
    for (int t = 0; t < 3; t++) {             /* sınır durumları */
        int satir = satir_sayisi[t], sutun = sutun_sayisi[t];
        for (int i = 0; i < satir; i++) {     /* satır öncelikli 1, 2, ... */
            for (int j = 0; j < sutun; j++) {
                m[i][j] = i * sutun + j + 1;
            }
        }
        printf("%d × %d spiral okuma:", satir, sutun);
        spiral_oku(m, satir, sutun);
    }
    return 0;
}

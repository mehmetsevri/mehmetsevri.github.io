/* H11_01_matris_oku_yaz.c — Hafta 11 · Örnek 1 (★): 3 × 3 matris oku–yazdır
 * Amaç   : 2B dizi bildirimi (int m[SATIR][SUTUN]) ve iç içe döngü: dış
 *          döngü satırları (i), iç döngü sütunları (j) dolaşır; %5d ile
 *          hizalı yazdırma
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_01_matris_oku_yaz.c -o matris_oku_yaz
 * Örnek  : girdi "4 -7 12 / 0 105 3 / -18 6 9" ->   -18    6    9
 */
#include <stdio.h>

#define SATIR 3
#define SUTUN 3

int main(void)
{
    int m[SATIR][SUTUN];                      /* 3 satır × 3 sütun = 9 int */

    printf("%d x %d matrisi satır satır girin:\n", SATIR, SUTUN);
    for (int i = 0; i < SATIR; i++) {         /* dış döngü: satır */
        for (int j = 0; j < SUTUN; j++) {     /* iç döngü: sütun */
            if (scanf("%d", &m[i][j]) != 1) {
                printf("Geçersiz girdi: m[%d][%d] okunamadı.\n",
                       i, j);
                return 1;
            }
        }
    }

    printf("Matris:\n");
    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            printf("%5d", m[i][j]);           /* 5 karakterlik alan */
        }
        printf("\n");                         /* satır bitti */
    }
    return 0;
}

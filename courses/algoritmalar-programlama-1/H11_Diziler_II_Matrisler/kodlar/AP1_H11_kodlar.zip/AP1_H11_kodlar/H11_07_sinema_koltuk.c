/* H11_07_sinema_koltuk.c — Hafta 11 · Örnek 7 (★★): Sinema salonu koltuk rezervasyonu
 * Amaç   : Durum matrisi (0 boş, 1 dolu) ve kullanıcı etkileşimi: kullanıcı
 *          1'den başlayan sıra/koltuk numarası girer, program 0'dan başlayan
 *          indise çevirir; aralık dışı ve dolu koltuk girdileri reddedilir
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_07_sinema_koltuk.c -o sinema_koltuk
 * Örnek  : girdi "3 4 / 3 4 / 6 2 / 1 8 / 0 0" -> Dolu: 2 / 40
 */
#include <stdio.h>

#define SIRA 5
#define KOLTUK 8

void plan_yazdir(int salon[][KOLTUK])
{
    printf("       ");
    for (int j = 0; j < KOLTUK; j++) {
        printf("%2d", j + 1);
    }
    printf("\n");
    for (int i = 0; i < SIRA; i++) {
        printf("Sıra %d ", i + 1);
        for (int j = 0; j < KOLTUK; j++) {
            printf(" %c", salon[i][j] ? 'X' : '.');   /* X dolu, . boş */
        }
        printf("\n");
    }
    printf("        ----- PERDE -----\n");
}

int main(void)
{
    int salon[SIRA][KOLTUK] = {0};            /* başlangıçta hepsi boş */
    int dolu = 0;

    for (;;) {
        int s, k;
        printf("Sıra ve koltuk (çıkış: 0 0): ");
        if (scanf("%d %d", &s, &k) != 2) {
            printf("\nGirdi sona erdi.\n");
            break;
        }
        if (s == 0 && k == 0) {
            break;
        }
        if (s < 1 || s > SIRA || k < 1 || k > KOLTUK) {  /* sınır denetimi */
            printf("  Böyle bir koltuk yok (sıra 1-%d, koltuk 1-%d).\n",
                   SIRA, KOLTUK);
        } else if (salon[s - 1][k - 1] == 1) {  /* 1 tabanlı → 0 tabanlı */
            printf("  Sıra %d koltuk %d DOLU.\n", s, k);
        } else {
            salon[s - 1][k - 1] = 1;
            dolu++;
            printf("  Ayrıldı: sıra %d, koltuk %d.\n", s, k);
        }
    }
    plan_yazdir(salon);
    printf("Dolu: %d / %d\n", dolu, SIRA * KOLTUK);
    return 0;
}

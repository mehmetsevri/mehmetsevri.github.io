/* H11_K03_satir_fonksiyona.c — Hafta 11 · Kavram programı: satır ve sütunu fonksiyona vermek
 * Amaç   : m[i] bir SATIRDIR ve bellekte bitişik olduğu için 1B dizi gibi
 *          H10'daki dizi fonksiyonuna verilebilir. Bir SÜTUN ise bitişik
 *          değildir (elemanları arasında SUTUN * sizeof(int) bayt vardır):
 *          önce geçici bir 1B diziye kopyalanır (Mini-OBS'teki sutun_kopyala)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K03_satir_fonksiyona.c -o satir_fonksiyona
 * Örnek  : -> 2. sütunun toplamı (kopya ile): 21
 */
#include <stdio.h>

#define SATIR 3
#define SUTUN 4

int dizi_toplam(const int a[], int n)         /* H10: 1B dizi + boyut */
{
    int toplam = 0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
    }
    return toplam;
}

void sutun_kopyala(int m[][SUTUN], int satir, int j, int hedef[])
{
    for (int i = 0; i < satir; i++) {
        hedef[i] = m[i][j];                   /* sütun → 1B dizi */
    }
}

int main(void)
{
    int m[SATIR][SUTUN] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};
    int sutun[SATIR];

    for (int i = 0; i < SATIR; i++) {
        printf("%d. satırın toplamı: %d\n", i, dizi_toplam(m[i], SUTUN));
    }
    sutun_kopyala(m, SATIR, 2, sutun);
    printf("2. sütunun toplamı (kopya ile): %d\n", dizi_toplam(sutun, SATIR));
    return 0;
}

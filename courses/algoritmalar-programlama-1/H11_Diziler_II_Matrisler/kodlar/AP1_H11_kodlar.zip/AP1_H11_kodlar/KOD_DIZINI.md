# Hafta 11 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` ve `.h` dosyası (53 `.c`, 1 `.h`); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (GCC 13.3, x86-64 Linux). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (her dosyanın başında derleme komutu, sonra `$ ./program` satırları ve girdileriyle birlikte çıktı). Örnek ve kavram programları ayrıca AddressSanitizer + UBSan ile temiz çalıştı (süre ölçen `H11_12_onbellek_sure.c` hariç: onun ölçümleri ayrı ayrı -O0, -O2 ve -O3 ile alındı, `ciktilar/H11_12_onbellek_sure_olcumler.txt`). Kasıtlı bellek hatası içeren Hata Avcısı 1–2 ve Alıştırma 11.3 dosyalarının ASan/UBSan raporları kendi çıktı dosyalarındadır.

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Ders notu ve sunumdaki kod kesitleri dosyanın **ardışık satırlarıdır** (başlıkta dosya adı ve satır aralığı); web’deki kod blokları dosyanın tamamı ya da ardışık kesitidir. Web simülasyonları (`web/AP1_H11_sims.js`) `H11_08`’in `carp` fonksiyonunu, `H11_K02`’nin gerçek adreslerini, `H11_11`’in görüntüsünü ve `H11_13`’ün nesillerini kullanır.

Kod envanteri denetimi (ders notu, sunum ve web’deki her kod parçası bu klasördeki bir dosyanın ardışık satırlarıdır): **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H11_01_matris_oku_yaz.c` | Örnek 1 (★) | Örnek 1 (★): 3 × 3 matris oku–yazdır | sıfır uyarı | 4.1 | 13 | h11-iki-boyut |
| `H11_02_satir_sutun_toplam.c` | Örnek 2 (★) | Örnek 2 (★): Satır ve sütun toplamları | sıfır uyarı | 4.2 | 31 | h11-merdiven |
| `H11_03_matris_toplama.c` | Örnek 3 (★) | Örnek 3 (★): Matris toplama | sıfır uyarı | 4.3 | — | h11-merdiven |
| `H11_04_devrik.c` | Örnek 4 (★★) | Örnek 4 (★★): Devrik (transpoz) matris | sıfır uyarı | 4.4 | 32 | h11-merdiven |
| `H11_05_kosegen_simetri.c` | Örnek 5 (★★) | Örnek 5 (★★): Köşegenler, birim ve simetri | sıfır uyarı | 4.5 | 33 (şekil) | h11-merdiven |
| `H11_06_not_tablosu.c` | Örnek 6 (★★) | Örnek 6 (★★): Öğrenci × ders not tablosu | sıfır uyarı | 4.6 | 34, 35 | h11-merdiven |
| `H11_07_sinema_koltuk.c` | Örnek 7 (★★) | Örnek 7 (★★): Sinema salonu koltuk rezervasyonu | sıfır uyarı | 4.7 | 36 (şekil) | h11-merdiven |
| `H11_08_matris_carpim.c` | Örnek 8 (★★★) | Örnek 8 (★★★): Matris çarpımı | sıfır uyarı | 4.8 | 37 (şekil), 38 | h11-merdiven |
| `H11_09_tictactoe.c` | Örnek 9 (★★★) | Örnek 9 (★★★): Tic-tac-toe ve kazanan denetimi | sıfır uyarı | 4.9 | 40 (şekil) | h11-merdiven |
| `H11_10_mayin_tarlasi.c` | Örnek 10 (★★★) | Örnek 10 (★★★): Mayın tarlası komşu sayıları | sıfır uyarı | 4.10 | 41 (şekil) | h11-merdiven |
| `H11_11_goruntu_isleme.c` | Örnek 11 (★★★) | Örnek 11 (★★★): Görüntü işleme | sıfır uyarı | 3.7 (şekil), 4.11 | 1 (şekil), 7 (şekil), 8 (şekil), 42 (şekil) | h11-merdiven |
| `H11_12_onbellek_sure.c` | Örnek 12 (★★★) | Örnek 12 (★★★): Önbellek süre deneyi | sıfır uyarı (süre ölçümü; ayrıca -O2/-O3) | 3.8 (şekil), 4.12 | 26 (şekil), 27 (şekil) | h11-onbellek |
| `H11_13_hayat_oyunu.c` | Örnek 13 (★★★) | Örnek 13 (★★★): Conway'in Hayat Oyunu | sıfır uyarı | 4.13 | 1 (şekil), 7 (şekil), 43 (şekil) | h11-merdiven |
| `H11_14_spiral.c` | Örnek 14 (★★★) | Örnek 14 (★★★): Spiral matris | sıfır uyarı | 4.14 | 45 (şekil) | h11-merdiven |
| `H11_K01_ilk_deger.c` | Kavram programı | Kavram programı: 2B dizi bildirimi ve ilk değer | sıfır uyarı | 3.2 | 12 | h11-iki-boyut |
| `H11_K02_bellek_serit.c` | Kavram programı | Kavram programı: 2B dizi bellekte tek şerit | sıfır uyarı | 3.4 (metin, şekil) | 15 (şekil), 17 (şekil) | h11-serit |
| `H11_K03_satir_fonksiyona.c` | Kavram programı | Kavram programı: satır ve sütunu fonksiyona vermek | sıfır uyarı | 3.5 | 21 | h11-fonksiyon |
| `H11_K04_const_parametre.c` | Kavram programı | Kavram programı (Merak Kutusu): const 2B parametre | sıfır uyarı | 3.5 (metin) | 22 | h11-fonksiyon |
| `H11_K05_dolasma_sirasi.c` | Kavram programı | Kavram programı: dolaşma sırası ve adım | sıfır uyarı | 3.3 (metin) | 19 (şekil) | h11-iki-boyut |
| `H11_K06_uc_boyutlu.c` | Kavram programı | Kavram programı: üç boyutlu dizi | sıfır uyarı | 3.7 | 25 (şekil) | h11-goruntu |
| `H11_K07_komsuluk.c` | Kavram programı | Kavram programı: 4 ve 8 komşuluk | sıfır uyarı | 3.6 | 24 (şekil) | h11-komsuluk |
| `H11_K08_vla_parametre.c` | Kavram programı | Kavram programı (Merak Kutusu): VLA parametre | sıfır uyarı | 3.5 (metin) | — | h11-fonksiyon |
| `alistirmalar/H11_A01_cikti_tahmini.c` | Alıştırma 11.1 | Alıştırma 11.1 (★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h11-alistirmalar |
| `alistirmalar/H11_A02_adres_tahmini.c` | Alıştırma 11.2 | Alıştırma 11.2 (★★, çıktı tahmini) | sıfır uyarı | 8 (alıştırma) | — | h11-alistirmalar |
| `alistirmalar/H11_A03_hata_bul_sinir.c` | Alıştırma 11.3 | Alıştırma 11.3 (★★, hata bul) | sıfır uyarı; kasıtlı mantık/bellek hatası | 8 (alıştırma) | — | h11-alistirmalar |
| `alistirmalar/H11_A04_hata_bul_devrik.c` | Alıştırma 11.4 | Alıştırma 11.4 (★★, hata bul) | sıfır uyarı; kasıtlı mantık/bellek hatası | 8 (alıştırma) | — | h11-alistirmalar |
| `alistirmalar/H11_A05_parsons_sutun_toplam.c` | Alıştırma 11.5 | Alıştırma 11.5 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h11-alistirmalar |
| `alistirmalar/H11_A06_kod_tamamla_carpim.c` | Alıştırma 11.6 | Alıştırma 11.6 (★★, kod tamamlama) | tamamlanacak (bu hâliyle derlenmez) | 8 (alıştırma) | — | h11-alistirmalar |
| `hata_avcisi/H11_HA1_ij_karisik.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık/bellek hatası | 5 | 46 | h11-hata-avcisi |
| `hata_avcisi/H11_HA1_ij_karisik_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 (düzeltilmiş sürüm) | sıfır uyarı | — | — | h11-hata-avcisi |
| `hata_avcisi/H11_HA2_kenar_komsu.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık/bellek hatası | 5 | 47 | h11-hata-avcisi |
| `hata_avcisi/H11_HA2_kenar_komsu_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 (düzeltilmiş sürüm) | sıfır uyarı | — | — | h11-hata-avcisi |
| `hata_avcisi/H11_HA3_sutun_boyutu_yok.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3 (hatalı sürüm) | kasıtlı derleme hatası | 5 | 20 (şekil) | h11-hata-avcisi |
| `hata_avcisi/H11_HA3_sutun_boyutu_yok_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 (düzeltilmiş sürüm) | sıfır uyarı | — | — | h11-hata-avcisi |
| `hata_avcisi/H11_HA4_sonuc_sifirlanmadi.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık/bellek hatası | 5 | — | h11-hata-avcisi |
| `hata_avcisi/H11_HA4_sonuc_sifirlanmadi_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4 (düzeltilmiş sürüm) | sıfır uyarı | — | — | h11-hata-avcisi |
| `hata_avcisi/H11_HA5_hayat_tek_tampon.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5 (hatalı sürüm) | sıfır uyarı; kasıtlı mantık/bellek hatası | 5 | 44 (şekil) | h11-hata-avcisi |
| `hata_avcisi/H11_HA5_hayat_tek_tampon_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 (düzeltilmiş sürüm) | sıfır uyarı | — | 44 (şekil) | h11-hata-avcisi |
| `hata_avcisi/H11_HA6_eksik_parantez.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6 (hatalı sürüm) | derlenir; kasıtlı uyarı | 5 | — | h11-hata-avcisi |
| `hata_avcisi/H11_HA6_eksik_parantez_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 (düzeltilmiş sürüm) | sıfır uyarı | — | — | h11-hata-avcisi |
| `proje/main.c` | Mini-OBS v0.11 · main.c | Mini-OBS v0.11 (AP-1 Hafta 11): menü döngüsü + not matrisleri | sıfır uyarı (Makefile) | — | — | — |
| `proje/obs.c` | Mini-OBS v0.11 · obs.c | Mini-OBS v0.11 (AP-1 Hafta 11): modülün GERÇEKLEMESİ | sıfır uyarı (Makefile) | 7 | 50 (şekil), 51 | h11-miniobs |
| `proje/obs.h` | Mini-OBS v0.11 · başlık | Mini-OBS v0.11 (AP-1 Hafta 11): modülün ARAYÜZÜ | başlık (içeren .c ile derlenir) | 7 (şekil) | 50 (şekil) | — |
| `proje/test_obs.c` | Mini-OBS v0.11 · test_obs.c | Mini-OBS v0.11 (AP-1 Hafta 11): birim testleri | sıfır uyarı (Makefile) | — | — | — |
| `quiz/H11_Q01_indis_adres.c` | Geri çağırma S1 · quiz | Geçen haftadan S1 (H10: indis–adres) | sıfır uyarı | 2 (metin) | 3 | h11-gecen-hafta, h11-quiz |
| `quiz/H11_Q02_sizeof_tuzagi.c` | Geri çağırma S2 · quiz | Geçen haftadan S2 (H10: diziyi fonksiyona aktarma) | sıfır uyarı | 2 (metin) | 4 | h11-gecen-hafta, h11-quiz |
| `quiz/H11_Q03_frekans.c` | Geri çağırma S3 · quiz | Geçen haftadan S3 (H10: frekans dizisi) | sıfır uyarı | 2 (metin) | 4 | h11-gecen-hafta, h11-quiz |
| `quiz/H11_Q04_kismi_ilk_deger.c` | Quiz S4 | Quiz S4 (kısmi ilk değer) | sıfır uyarı | — | 14 | h11-quiz |
| `quiz/H11_Q05_uzaklik.c` | Quiz S5 | Quiz S5 (satır öncelikli adres) | sıfır uyarı | — | 18 | h11-quiz |
| `quiz/H11_Q06_sutun_dolasma.c` | Quiz S6 | Quiz S6 (dolaşma yönü) | sıfır uyarı | — | — | h11-quiz |
| `quiz/H11_Q07_parametre.c` | Quiz S7 | Quiz S7 (2B dizi parametresi) | sıfır uyarı | — | 23 | h11-quiz |
| `quiz/H11_Q08_carpma_sayisi.c` | Quiz S8 | Quiz S8 (çarpma sayısı) | sıfır uyarı | — | 39 | h11-quiz |
| `quiz/H11_Q09_komsu.c` | Quiz S9 | Quiz S9 (sınır denetimi) | sıfır uyarı | — | — | h11-quiz |
| `quiz/H11_Q10_hayat_kurali.c` | Quiz S10 | Quiz S10 (Hayat Oyunu kuralı) | sıfır uyarı | — | — | h11-quiz |

**Diğer dosyalar**

- `proje/Makefile` — Mini-OBS v0.11 (`make`, `make test`, `make clean`); `proje/` klasörü `91_Proje_MiniOBS/v0.11/`’un kopyasıdır (asıl yer orası; `testler/` altındaki altı senaryo ve gerçek oturum `mini_obs_v0_11_ciktilar.txt` orada).
- `ciktilar/H11_12_onbellek_sure_olcumler.txt` — önbellek deneyinin bütün ölçümleri (-O0 ve -O2 için N = 1000, 2000, 4000; -O3 için N = 4000; her biri 7 tekrar), ortam bilgisi (`lscpu`, `getconf`) ve özet tablo.
- `AP1_H11_kodlar.zip` — bu klasörün (`.c`, `.h`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H11_kodlar/` klasörü oluşur.

Materyalde doğrudan geçmeyen (envanter ya da arşiv amaçlı) dosyalar: `proje/main.c`, `proje/test_obs.c`.

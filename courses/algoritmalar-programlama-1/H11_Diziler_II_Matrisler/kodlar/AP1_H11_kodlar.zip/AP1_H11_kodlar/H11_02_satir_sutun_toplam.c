/* H11_02_satir_sutun_toplam.c — Hafta 11 · Örnek 2 (★): Satır ve sütun toplamları
 * Amaç   : Aynı tabloyu iki yönde dolaşmak: satır toplamı için i dışta,
 *          sütun toplamı için j dışta. Kantinin 3 kasasının 5 günlük
 *          satış adetleri (satır: kasa, sütun: gün)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_02_satir_sutun_toplam.c -o satir_sutun_toplam
 * Örnek  : -> Toplam    40   45   40   55   56 |    236
 */
#include <stdio.h>

#define KASA 3
#define GUN 5

int main(void)
{
    const int satis[KASA][GUN] = {            /* [kasa][gün] */
        {12, 15, 9, 20, 18},
        {7, 11, 14, 10, 16},
        {21, 19, 17, 25, 22}
    };

    printf("         Pzt  Sal  Çar  Per  Cum | Toplam\n");
    for (int i = 0; i < KASA; i++) {          /* dış döngü: SATIR */
        int satir_toplami = 0;
        printf("Kasa %d ", i + 1);
        for (int j = 0; j < GUN; j++) {
            printf("%5d", satis[i][j]);
            satir_toplami += satis[i][j];
        }
        printf(" | %6d\n", satir_toplami);
    }

    int genel = 0;
    printf("Toplam ");
    for (int j = 0; j < GUN; j++) {           /* dış döngü: SÜTUN */
        int sutun_toplami = 0;
        for (int i = 0; i < KASA; i++) {      /* iç döngü: satır */
            sutun_toplami += satis[i][j];
        }
        printf("%5d", sutun_toplami);
        genel += sutun_toplami;
    }
    printf(" | %6d\n", genel);
    return 0;
}

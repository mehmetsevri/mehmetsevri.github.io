/* H11_A04_hata_bul_devrik.c — Hafta 11 · Alıştırma 11.4 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: kare matrisin yerinde devriğini almalı;
 * ama çıktı özgün matrisin aynısı. Neden? Tek karakterlik düzeltme yeter.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_A04_hata_bul_devrik.c -o a04
 */
#include <stdio.h>

#define N 3

int main(void)
{
    int k[N][N] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int gecici = k[i][j];
            k[i][j] = k[j][i];
            k[j][i] = gecici;
        }
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%3d", k[i][j]);
        }
        printf("\n");
    }
    return 0;
}

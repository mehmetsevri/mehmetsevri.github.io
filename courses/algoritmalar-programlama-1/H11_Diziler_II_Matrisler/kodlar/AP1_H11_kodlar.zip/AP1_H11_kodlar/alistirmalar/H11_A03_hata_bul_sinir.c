/* H11_A03_hata_bul_sinir.c — Hafta 11 · Alıştırma 11.3 (★★, hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: matrisin tüm elemanlarının toplamı
 * 1 + 2 + ... + 12 = 78 olmalı. Hatayı bulun, nedenini açıklayın ve
 * düzeltin. (İpucu: -fsanitize=address ile derleyip çalıştırın.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_A03_hata_bul_sinir.c -o a03
 */
#include <stdio.h>

#define SATIR 3
#define SUTUN 4

int main(void)
{
    int m[SATIR][SUTUN] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};
    int toplam = 0;

    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j <= SUTUN; j++) {
            toplam += m[i][j];
        }
    }
    printf("Toplam: %d\n", toplam);
    return 0;
}

/* H11_A02_adres_tahmini.c — Hafta 11 · Alıştırma 11.2 (★★, çıktı tahmini)
 * Görev  : double t[4][5] için dört satırın çıktısını hesaplayın
 *          (sizeof(double) = 8). Uzaklıklar &t[0][0]'dan bayt cinsindendir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_A02_adres_tahmini.c -o a02
 */
#include <stdio.h>

int main(void)
{
    double t[4][5];
    char *taban = (char *)&t[0][0];

    printf("%zu %zu\n", sizeof t, sizeof t[1]);
    printf("%td\n", (char *)&t[2][3] - taban);
    printf("%td\n", (char *)&t[3][0] - taban);
    printf("%td\n", (char *)&t[1][4] - (char *)&t[1][0]);
    return 0;
}

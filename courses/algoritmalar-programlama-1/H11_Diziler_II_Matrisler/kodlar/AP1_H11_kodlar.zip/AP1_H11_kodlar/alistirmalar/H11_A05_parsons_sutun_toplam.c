/* H11_A05_parsons_sutun_toplam.c — Hafta 11 · Alıştırma 11.5 (★★, Parsons)
 * Görev  : sutun_toplamlari() fonksiyonunun satırları karışık verildi.
 *          Satırları doğru sıraya dizin ve girintileyin; bir satır fazladır.
 *          Beklenen çıktı: 15 18 21 24
 * tamamlanacak; bu hâliyle derlenmez
 */
#include <stdio.h>

#define SATIR 3
#define SUTUN 4

        sonuc[j] = 0;
            sonuc[j] += m[i][j];
void sutun_toplamlari(int m[][SUTUN], int sonuc[])
    for (int j = 0; j < SUTUN; j++) {
        }
        for (int i = 0; i < SATIR; i++) {
            sonuc[i] += m[i][j];
    }
{
}

int main(void)
{
    int m[SATIR][SUTUN] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};
    int toplam[SUTUN];
    sutun_toplamlari(m, toplam);
    for (int j = 0; j < SUTUN; j++) {
        printf("%d ", toplam[j]);
    }
    printf("\n");
    return 0;
}

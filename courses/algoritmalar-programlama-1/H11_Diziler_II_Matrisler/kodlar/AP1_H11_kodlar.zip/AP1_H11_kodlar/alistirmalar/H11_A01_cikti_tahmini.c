/* H11_A01_cikti_tahmini.c — Hafta 11 · Alıştırma 11.1 (★, çıktı tahmini)
 * Görev  : Programı çalıştırmadan üç satırlık çıktıyı tahmin edin.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_A01_cikti_tahmini.c -o a01
 */
#include <stdio.h>

int main(void)
{
    int m[3][3];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            m[i][j] = i * 3 + j + 1;
        }
    }
    for (int j = 0; j < 3; j++) {
        printf("%d ", m[2][j]);
    }
    printf("\n%d\n", m[1][2] + m[2][1]);
    for (int i = 0; i < 3; i++) {
        printf("%d ", m[i][2 - i]);
    }
    printf("\n");
    return 0;
}

/* H11_A06_kod_tamamla_carpim.c — Hafta 11 · Alıştırma 11.6 (★★, kod tamamlama)
 * Görev  : (2 × 3) · (3 × 2) çarpımını yapan döngüdeki dört boşluğu (____)
 *          doldurun. Beklenen çıktı: 58 64 / 139 154
 * tamamlanacak; bu hâliyle derlenmez
 */
#include <stdio.h>

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int b[3][2] = {{7, 8}, {9, 10}, {11, 12}};
    int c[2][2];

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < ____; j++) {
            c[i][j] = ____;
            for (int k = 0; k < ____; k++) {
                c[i][j] += a[i][k] * b[____][j];
            }
        }
    }
    for (int i = 0; i < 2; i++) {
        printf("%d %d\n", c[i][0], c[i][1]);
    }
    return 0;
}

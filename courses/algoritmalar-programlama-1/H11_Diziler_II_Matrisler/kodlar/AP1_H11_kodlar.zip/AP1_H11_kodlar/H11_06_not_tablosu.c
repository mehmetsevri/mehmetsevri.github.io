/* H11_06_not_tablosu.c — Hafta 11 · Örnek 6 (★★): Öğrenci × ders not tablosu
 * Amaç   : Gerçek veri modeli: satır = öğrenci, sütun = ders. Satır
 *          ortalaması öğrencinin, sütun ortalaması dersin ortalamasıdır;
 *          her dersin en yüksek notu ve sahibi (sütunda konum takibi)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_06_not_tablosu.c -o not_tablosu
 * Örnek  : -> Genel ortalama: 75.90
 */
#include <stdio.h>

#define OGRENCI 5
#define DERS 4

int main(void)
{
    const int notlar[OGRENCI][DERS] = {       /* [öğrenci][ders] */
        {78, 85, 62, 90},
        {55, 70, 48, 66},
        {92, 88, 95, 81},
        {67, 59, 73, 70},
        {84, 91, 77, 87}
    };

    printf("Öğrenci   MAT   FİZ   KİM   PRG    Ort.\n");
    int genel_toplam = 0;
    for (int i = 0; i < OGRENCI; i++) {       /* satır: bir öğrenci */
        int toplam = 0;
        printf("%7d", i + 1);
        for (int j = 0; j < DERS; j++) {
            printf(" %5d", notlar[i][j]);
            toplam += notlar[i][j];
        }
        printf(" %7.2f\n", (double)toplam / DERS);
        genel_toplam += toplam;
    }

    printf("Ort.   ");
    for (int j = 0; j < DERS; j++) {          /* sütun: bir ders */
        int toplam = 0;
        for (int i = 0; i < OGRENCI; i++) {
            toplam += notlar[i][j];
        }
        printf(" %5.1f", (double)toplam / OGRENCI);
    }
    printf("\nEn yük.");
    for (int j = 0; j < DERS; j++) {
        int enb = 0;                          /* en yüksek notun satırı */
        for (int i = 1; i < OGRENCI; i++) {
            if (notlar[i][j] > notlar[enb][j]) {
                enb = i;
            }
        }
        printf(" %2d(%d)", notlar[enb][j], enb + 1);
    }
    printf("\nGenel ortalama: %.2f\n",
           (double)genel_toplam / (OGRENCI * DERS));
    return 0;
}

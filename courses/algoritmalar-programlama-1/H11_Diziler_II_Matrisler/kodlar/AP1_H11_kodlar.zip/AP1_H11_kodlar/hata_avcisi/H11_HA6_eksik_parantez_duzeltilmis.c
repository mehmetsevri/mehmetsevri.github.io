/* H11_HA6_eksik_parantez_duzeltilmis.c — Hafta 11 · Hata Avcısı 6 (düzeltilmiş sürüm)
 * Düzeltme: her satır kendi süslü parantezinde: {{1, 2}, {4, 5}}. Kısmi
 * satırların kalanı 0 olur: m[0] = {1, 2, 0}, m[1] = {4, 5, 0}.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA6_eksik_parantez_duzeltilmis.c -o ha6d
 */
#include <stdio.h>

int main(void)
{
    int m[2][3] = {{1, 2}, {4, 5}};           /* satır başına bir { } */

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%3d", m[i][j]);
        }
        printf("\n");
    }
    return 0;
}

/* H11_HA2_kenar_komsu_duzeltilmis.c — Hafta 11 · Hata Avcısı 2 (düzeltilmiş sürüm)
 * Düzeltme: komşunun konumu (ni, nj) hesaplanır ve erişimden ÖNCE
 * 0 <= ni < SATIR, 0 <= nj < SUTUN denetlenir; ızgara dışı komşu yok sayılır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA2_kenar_komsu_duzeltilmis.c -o ha2d
 */
#include <stdio.h>

#define SATIR 4
#define SUTUN 5

int komsu_mayin(int m[][SUTUN], int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            int ni = i + di, nj = j + dj;
            if ((di != 0 || dj != 0) && ni >= 0 && ni < SATIR && nj >= 0
                && nj < SUTUN) {
                sayi += m[ni][nj];            /* yalnızca ızgara içi */
            }
        }
    }
    return sayi;
}

int main(void)
{
    int mayin[SATIR][SUTUN] = {
        {1, 0, 0, 0, 1},
        {0, 0, 1, 0, 0},
        {0, 0, 0, 0, 0},
        {1, 0, 0, 1, 0}
    };
    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            printf(" %d", komsu_mayin(mayin, i, j));
        }
        printf("\n");
    }
    return 0;
}

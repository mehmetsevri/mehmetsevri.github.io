/* H11_HA6_eksik_parantez.c — Hafta 11 · Hata Avcısı 6 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: niyet {1, 2} ve {4, 5} satırlarıydı, ama
 * iç süslü parantezler unutuldu. Düz liste satır öncelikli sırayla
 * doldurulur: m[0] = {1, 2, 4}, m[1] = {5, 0, 0}. GCC -Wall uyarır
 * (-Wmissing-braces); program çalışır ama değerler yanlış yerdedir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA6_eksik_parantez.c -o ha6
 */
#include <stdio.h>

int main(void)
{
    int m[2][3] = {1, 2, 4, 5};               /* HATA: iç parantez yok */

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%3d", m[i][j]);
        }
        printf("\n");
    }
    return 0;
}

/* H11_HA5_hayat_tek_tampon.c — Hafta 11 · Hata Avcısı 5 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: Hayat Oyunu'nun yeni nesli AYNI matrise
 * yazılıyor. Bir hücre güncellenince, henüz işlenmemiş komşuları onun
 * YENİ değerini görür; kural "herkes aynı anda" uygulanmamış olur.
 * Yanıp sönen (blinker) dikey çizgi yatay çizgiye dönmeli; dönmez.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA5_hayat_tek_tampon.c -o ha5
 */
#include <stdio.h>

#define N 5

int canli_komsu(int g[][N], int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            int ni = i + di, nj = j + dj;
            if ((di != 0 || dj != 0) && ni >= 0 && ni < N && nj >= 0
                && nj < N) {
                sayi += g[ni][nj];
            }
        }
    }
    return sayi;
}

void yazdir(int g[][N])
{
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%c", g[i][j] ? '#' : '.');
        }
        printf("\n");
    }
}

int main(void)
{
    int g[N][N] = {{0}};
    g[1][2] = g[2][2] = g[3][2] = 1;          /* dikey yanıp sönen */

    for (int i = 0; i < N; i++) {             /* HATA: tek tampon */
        for (int j = 0; j < N; j++) {
            int k = canli_komsu(g, i, j);
            g[i][j] = g[i][j] ? (k == 2 || k == 3) : (k == 3);
        }
    }
    printf("1 nesil sonra:\n");
    yazdir(g);
    return 0;
}

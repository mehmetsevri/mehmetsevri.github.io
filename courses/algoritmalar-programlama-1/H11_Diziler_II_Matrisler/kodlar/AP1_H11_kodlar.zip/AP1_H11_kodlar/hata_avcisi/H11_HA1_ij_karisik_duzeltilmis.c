/* H11_HA1_ij_karisik_duzeltilmis.c — Hafta 11 · Hata Avcısı 1 (düzeltilmiş sürüm)
 * Düzeltme: satır indisi i (öğrenci), sütun indisi j (ders): notlar[i][j].
 * Kural: dizinin bildirim sırası [OGRENCI][DERS] ise erişim de
 * [öğrenci indisi][ders indisi] sırasıyla yapılır; döngü sınırları da
 * aynı sırayı izler (i < OGRENCI, j < DERS).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA1_ij_karisik_duzeltilmis.c -o ha1d
 */
#include <stdio.h>

#define OGRENCI 2
#define DERS 3

int main(void)
{
    int notlar[OGRENCI][DERS] = {{70, 80, 90}, {50, 60, 70}};

    for (int i = 0; i < OGRENCI; i++) {
        int toplam = 0;
        for (int j = 0; j < DERS; j++) {
            toplam += notlar[i][j];           /* satır i, sütun j */
        }
        printf("Öğrenci %d ortalaması: %.2f\n", i + 1, (double)toplam / DERS);
    }
    return 0;
}

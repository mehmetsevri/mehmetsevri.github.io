/* H11_HA5_hayat_tek_tampon_duzeltilmis.c — Hafta 11 · Hata Avcısı 5 (düzeltilmiş sürüm)
 * Düzeltme: iki tampon. Komşular ESKİ matristen (g) okunur, sonuçlar AYRI
 * bir matrise (yeni) yazılır; nesil bitince yeni, g'ye kopyalanır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA5_hayat_tek_tampon_duzeltilmis.c -o ha5d
 */
#include <stdio.h>

#define N 5

int canli_komsu(int g[][N], int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            int ni = i + di, nj = j + dj;
            if ((di != 0 || dj != 0) && ni >= 0 && ni < N && nj >= 0
                && nj < N) {
                sayi += g[ni][nj];
            }
        }
    }
    return sayi;
}

void yazdir(int g[][N])
{
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%c", g[i][j] ? '#' : '.');
        }
        printf("\n");
    }
}

int main(void)
{
    int g[N][N] = {{0}};
    int yeni[N][N];
    g[1][2] = g[2][2] = g[3][2] = 1;          /* dikey yanıp sönen */

    for (int i = 0; i < N; i++) {             /* g'den OKU, yeni'ye YAZ */
        for (int j = 0; j < N; j++) {
            int k = canli_komsu(g, i, j);
            yeni[i][j] = g[i][j] ? (k == 2 || k == 3) : (k == 3);
        }
    }
    for (int i = 0; i < N; i++) {             /* nesil bitti: kopyala */
        for (int j = 0; j < N; j++) {
            g[i][j] = yeni[i][j];
        }
    }
    printf("1 nesil sonra:\n");
    yazdir(g);
    return 0;
}

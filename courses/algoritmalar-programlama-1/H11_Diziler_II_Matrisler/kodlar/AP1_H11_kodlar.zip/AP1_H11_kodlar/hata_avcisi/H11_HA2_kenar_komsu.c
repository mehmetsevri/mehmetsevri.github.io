/* H11_HA2_kenar_komsu.c — Hafta 11 · Hata Avcısı 2 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: komşu sayarken sınır denetimi yok. Kenar
 * ve köşe hücrelerinde m[i - 1][...], m[...][j + 1] gibi erişimler dizinin
 * dışına taşar (tanımsız davranış). Derleyici uyarmaz; sonuçlar yanlış
 * olabilir. AddressSanitizer dizi dışı okumayı satır numarasıyla bildirir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA2_kenar_komsu.c -o ha2
 */
#include <stdio.h>

#define SATIR 4
#define SUTUN 5

int komsu_mayin(int m[][SUTUN], int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            if (di != 0 || dj != 0) {
                sayi += m[i + di][j + dj];    /* HATA: sınır denetimi yok */
            }
        }
    }
    return sayi;
}

int main(void)
{
    int mayin[SATIR][SUTUN] = {
        {1, 0, 0, 0, 1},
        {0, 0, 1, 0, 0},
        {0, 0, 0, 0, 0},
        {1, 0, 0, 1, 0}
    };
    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            printf(" %d", komsu_mayin(mayin, i, j));
        }
        printf("\n");
    }
    return 0;
}

/* H11_HA3_sutun_boyutu_yok.c — Hafta 11 · Hata Avcısı 3 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: parametre int m[][] yazıldı. Derleyici
 * m[i][j]'nin adresini taban + (i * SUTUN + j) * sizeof(int) ile hesaplar;
 * SUTUN bilinmeden bu formül kurulamaz: DERLEME HATASI.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA3_sutun_boyutu_yok.c -o ha3
 */
#include <stdio.h>

void yazdir(int m[][], int satir, int sutun)
{
    for (int i = 0; i < satir; i++) {
        for (int j = 0; j < sutun; j++) {
            printf("%3d", m[i][j]);
        }
        printf("\n");
    }
}

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    yazdir(a, 2, 3);
    return 0;
}

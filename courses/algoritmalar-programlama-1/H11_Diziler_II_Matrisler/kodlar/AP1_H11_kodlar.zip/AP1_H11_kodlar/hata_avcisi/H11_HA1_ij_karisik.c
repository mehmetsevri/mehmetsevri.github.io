/* H11_HA1_ij_karisik.c — Hafta 11 · Hata Avcısı 1 (hatalı sürüm)
 * BU DOSYA KASITLI HATA İÇERİR: notlar[i][j] yerine notlar[j][i] yazıldı.
 * Dizi 2 satır (öğrenci) × 3 sütun (ders); j = 2 iken notlar[2][...]
 * dizinin DIŞINDA kalır: tanımsız davranış. Derleyici uyarmaz; program
 * çökmeden yanlış sayı yazabilir. AddressSanitizer ile yakalanır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA1_ij_karisik.c -o ha1
 */
#include <stdio.h>

#define OGRENCI 2
#define DERS 3

int main(void)
{
    int notlar[OGRENCI][DERS] = {{70, 80, 90}, {50, 60, 70}};

    for (int i = 0; i < OGRENCI; i++) {
        int toplam = 0;
        for (int j = 0; j < DERS; j++) {
            toplam += notlar[j][i];           /* HATA: [i][j] olmalı */
        }
        printf("Öğrenci %d ortalaması: %.2f\n", i + 1, (double)toplam / DERS);
    }
    return 0;
}

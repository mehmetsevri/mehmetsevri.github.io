/* H11_HA3_sutun_boyutu_yok_duzeltilmis.c — Hafta 11 · Hata Avcısı 3 (düzeltilmiş sürüm)
 * Düzeltme: sütun sayısı bir sabitle parametre tipine yazılır: int m[][SUTUN].
 * İlk boyut (satır sayısı) boş bırakılabilir; ayrı parametre olarak geçer.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA3_sutun_boyutu_yok_duzeltilmis.c -o ha3d
 */
#include <stdio.h>

#define SUTUN 3

void yazdir(int m[][SUTUN], int satir)
{
    for (int i = 0; i < satir; i++) {
        for (int j = 0; j < SUTUN; j++) {
            printf("%3d", m[i][j]);
        }
        printf("\n");
    }
}

int main(void)
{
    int a[2][SUTUN] = {{1, 2, 3}, {4, 5, 6}};
    yazdir(a, 2);
    return 0;
}

/* H11_HA4_sonuc_sifirlanmadi_duzeltilmis.c — Hafta 11 · Hata Avcısı 4 (düzeltilmiş sürüm)
 * Düzeltme: toplayıcı deseni (H6): her c[i][j] için toplamaya başlamadan
 * ÖNCE c[i][j] = 0. Fonksiyon artık c'nin önceki içeriğine bağlı değildir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_HA4_sonuc_sifirlanmadi_duzeltilmis.c -o ha4d
 */
#include <stdio.h>

#define N 2

void carp(int a[][N], int b[][N], int c[][N])
{
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            c[i][j] = 0;                      /* toplayıcıyı sıfırla */
            for (int k = 0; k < N; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}

void yazdir(int c[][N])
{
    for (int i = 0; i < N; i++) {
        printf("%5d%5d\n", c[i][0], c[i][1]);
    }
}

int main(void)
{
    int a[N][N] = {{1, 2}, {3, 4}};
    int b[N][N] = {{5, 6}, {7, 8}};
    int birim[N][N] = {{1, 0}, {0, 1}};
    int c[N][N] = {{0}};

    carp(a, b, c);
    printf("A x B:\n");
    yazdir(c);
    carp(a, birim, c);                        /* beklenen: A'nın kendisi */
    printf("A x I:\n");
    yazdir(c);
    return 0;
}

/* H11_K01_ilk_deger.c — Hafta 11 · Kavram programı: 2B dizi bildirimi ve ilk değer
 * Amaç   : Satır satır ilk değer, kısmi ilk değer (kalanlar 0), {0} ve
 *          satır sayısının ilk değer listesinden çıkarılması; sizeof ile
 *          dizinin, bir satırın ve bir elemanın boyutu
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K01_ilk_deger.c -o ilk_deger
 * Örnek  : -> satır sayısı = 3, sütun sayısı = 3
 */
#include <stdio.h>

void yazdir(char ad, int satir, int m[][3])
{
    printf("%c:", ad);
    for (int i = 0; i < satir; i++) {
        printf("  {");
        for (int j = 0; j < 3; j++) {
            printf("%2d", m[i][j]);
        }
        printf(" }");
    }
    printf("\n");
}

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};     /* satır satır */
    int c[2][3] = {{1}, {4, 5}};              /* kısmi: kalanlar 0 */
    int d[2][3] = {0};                        /* hepsi 0 */
    int e[][3] = {{1, 2, 3}, {4, 5, 6}, {7}}; /* satır sayısı: 3 */

    yazdir('a', 2, a);
    yazdir('c', 2, c);
    yazdir('d', 2, d);
    yazdir('e', 3, e);
    printf("sizeof a = %zu, sizeof a[0] = %zu, sizeof a[0][0] = %zu\n",
           sizeof a, sizeof a[0], sizeof a[0][0]);
    printf("satır sayısı = %zu, sütun sayısı = %zu\n",
           sizeof e / sizeof e[0], sizeof e[0] / sizeof e[0][0]);
    return 0;
}

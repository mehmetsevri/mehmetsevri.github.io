/* H11_13_hayat_oyunu.c — Hafta 11 · Örnek 13 (★★★): Conway'in Hayat Oyunu
 * Amaç   : Kurallar (B3/S23): canlı hücre 2 ya da 3 canlı komşuyla yaşar,
 *          aksi hâlde ölür; ölü hücre tam 3 canlı komşuyla doğar. Yeni
 *          nesil ESKİ nesilden okunur, AYRI bir matrise yazılır (iki tampon),
 *          sonra kopyalanır. Izgaranın dışı ölü sayılır (sınır denetimi).
 *          Planör (glider) 4 nesilde bir hücre sağ-aşağı kayar; yanıp sönen
 *          (blinker) 2 nesilde bir başa döner
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_13_hayat_oyunu.c -o hayat_oyunu
 * Örnek  : -> Nesil 4 (canlı: 8)
 */
#include <stdio.h>

#define SATIR 8
#define SUTUN 10
#define NESIL 4

int canli_komsu(int g[][SUTUN], int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            int ni = i + di, nj = j + dj;
            if ((di != 0 || dj != 0) && ni >= 0 && ni < SATIR && nj >= 0
                && nj < SUTUN) {
                sayi += g[ni][nj];
            }
        }
    }
    return sayi;
}

/* eski'den OKUR, yeni'ye YAZAR: eski bu nesil boyunca değişmez */
void sonraki_nesil(int eski[][SUTUN], int yeni[][SUTUN])
{
    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            int k = canli_komsu(eski, i, j);
            if (eski[i][j] == 1) {
                yeni[i][j] = (k == 2 || k == 3);   /* S23: yaşar */
            } else {
                yeni[i][j] = (k == 3);             /* B3: doğar */
            }
        }
    }
}

void yazdir(int g[][SUTUN], int nesil)
{
    int canli = 0;
    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            canli += g[i][j];
        }
    }
    printf("Nesil %d (canlı: %d)\n", nesil, canli);
    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            printf("%c", g[i][j] ? '#' : '.');
        }
        printf("\n");
    }
}

int main(void)
{
    int g[SATIR][SUTUN] = {0};
    int yeni[SATIR][SUTUN];
    g[0][1] = g[1][2] = g[2][0] = g[2][1] = g[2][2] = 1;   /* planör */
    g[5][7] = g[6][7] = g[7][7] = 1;                       /* yanıp sönen */

    for (int n = 0; n <= NESIL; n++) {
        yazdir(g, n);
        sonraki_nesil(g, yeni);
        for (int i = 0; i < SATIR; i++) {     /* yeni → g (kopyala) */
            for (int j = 0; j < SUTUN; j++) {
                g[i][j] = yeni[i][j];
            }
        }
    }
    return 0;
}

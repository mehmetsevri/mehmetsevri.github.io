/* H11_Q10_hayat_kurali.c — Hafta 11 · Quiz S10 (Hayat Oyunu kuralı)
 * Soru   : Canlı bir hücrenin k canlı komşusu var. k = 1, 2, 3, 4 için bir
 *          sonraki nesilde canlı mı (1) ölü mü (0)?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q10_hayat_kurali.c -o q10
 */
#include <stdio.h>

int sonraki(int canli, int k)
{
    if (canli) {
        return k == 2 || k == 3;              /* S23 */
    }
    return k == 3;                            /* B3 */
}

int main(void)
{
    for (int k = 1; k <= 4; k++) {
        printf("%d", sonraki(1, k));
    }
    printf(" %d\n", sonraki(0, 3));
    return 0;
}

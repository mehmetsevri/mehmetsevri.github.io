/* H11_Q07_parametre.c — Hafta 11 · Quiz S7 (2B dizi parametresi)
 * Soru   : yazdir'ın parametresi hangi biçimde yazılırsa program derlenir?
 *          (Bu dosya doğru biçimi içerir.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q07_parametre.c -o q07
 */
#include <stdio.h>

void yazdir(int m[][4], int satir)
{
    for (int i = 0; i < satir; i++) {
        printf("%d ", m[i][3]);
    }
    printf("\n");
}

int main(void)
{
    int a[2][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}};
    yazdir(a, 2);
    return 0;
}

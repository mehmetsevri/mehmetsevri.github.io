/* H11_Q08_carpma_sayisi.c — Hafta 11 · Quiz S8 (çarpma sayısı)
 * Soru   : (2 × 3) · (3 × 4) çarpımında sayaç kaç olur?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q08_carpma_sayisi.c -o q08
 */
#include <stdio.h>

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int b[3][4] = {{1, 0, 0, 1}, {0, 1, 0, 1}, {0, 0, 1, 1}};
    int c[2][4];
    int sayac = 0;
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 4; j++) {
            c[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                c[i][j] += a[i][k] * b[k][j];
                sayac++;
            }
        }
    }
    printf("%d %d\n", sayac, c[1][3]);
    return 0;
}

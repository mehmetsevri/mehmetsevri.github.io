/* H11_Q02_sizeof_tuzagi.c — Hafta 11 · Geçen haftadan S2 (H10: diziyi fonksiyona aktarma)
 * Soru   : main 6 yazdırır. Fonksiyonda n yerine sizeof a / sizeof a[0]
 *          kullanılsaydı (64 bit Linux) sonuç ne olurdu? Neden boyut ayrı
 *          parametredir?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q02_sizeof_tuzagi.c -o q02
 */
#include <stdio.h>

int dizi_max(const int a[], int n)
{
    int enb = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] > enb) {
            enb = a[i];
        }
    }
    return enb;
}

int main(void)
{
    int notlar[6] = {72, 95, 61, 88, 47, 90};
    int n = (int)(sizeof notlar / sizeof notlar[0]);
    printf("%d\n", n);
    printf("%d\n", dizi_max(notlar, n));
    return 0;
}

/* H11_Q06_sutun_dolasma.c — Hafta 11 · Quiz S6 (dolaşma yönü)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q06_sutun_dolasma.c -o q06
 */
#include <stdio.h>

int main(void)
{
    int m[2][3] = {{1, 2, 3}, {4, 5, 6}};
    for (int j = 0; j < 3; j++) {
        for (int i = 0; i < 2; i++) {
            printf("%d ", m[i][j]);
        }
    }
    printf("\n");
    return 0;
}

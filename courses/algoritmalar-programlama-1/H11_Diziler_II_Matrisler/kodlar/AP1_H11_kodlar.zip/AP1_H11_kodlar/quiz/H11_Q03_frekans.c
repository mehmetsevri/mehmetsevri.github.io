/* H11_Q03_frekans.c — Hafta 11 · Geçen haftadan S3 (H10: frekans dizisi)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q03_frekans.c -o q03
 */
#include <stdio.h>

int main(void)
{
    int atis[8] = {3, 6, 3, 1, 6, 3, 2, 5};
    int frekans[7] = {0};       /* 1..6 */
    for (int i = 0; i < 8; i++) {
        frekans[atis[i]]++;     /* değer = indis */
    }
    printf("%d %d %d\n",
           frekans[3], frekans[6], frekans[4]);
    return 0;
}

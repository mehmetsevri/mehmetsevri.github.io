/* H11_Q04_kismi_ilk_deger.c — Hafta 11 · Quiz S4 (kısmi ilk değer)
 * Soru   : Program ne yazdırır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q04_kismi_ilk_deger.c -o q04
 */
#include <stdio.h>

int main(void)
{
    int m[3][3] = {{1}, {2, 3}, {4, 5, 6}};
    printf("%d %d %d\n", m[0][1], m[1][1], m[2][0]);
    return 0;
}

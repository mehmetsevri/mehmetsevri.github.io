/* H11_Q09_komsu.c — Hafta 11 · Quiz S9 (sınır denetimi)
 * Soru   : 4 × 4 ızgarada (0, 3) ve (1, 3) hücrelerinin ızgara içindeki
 *          8-komşu sayısı kaçtır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q09_komsu.c -o q09
 */
#include <stdio.h>

#define N 4

int komsu_sayisi(int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            int ni = i + di, nj = j + dj;
            if ((di != 0 || dj != 0) && ni >= 0 && ni < N && nj >= 0
                && nj < N) {
                sayi++;
            }
        }
    }
    return sayi;
}

int main(void)
{
    printf("%d %d\n", komsu_sayisi(0, 3), komsu_sayisi(1, 3));
    return 0;
}

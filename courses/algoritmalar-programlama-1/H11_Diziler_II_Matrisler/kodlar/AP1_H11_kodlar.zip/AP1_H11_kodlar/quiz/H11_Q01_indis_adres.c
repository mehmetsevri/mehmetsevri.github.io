/* H11_Q01_indis_adres.c — Hafta 11 · Geçen haftadan S1 (H10: indis–adres)
 * Soru   : İlk satırda ne yazdırılır? (sizeof(int) = 4)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q01_indis_adres.c -o q01
 */
#include <stdio.h>

int main(void)
{
    int a[5] = {10, 20, 30, 40, 50};
    printf("%td\n", (char *)&a[3] - (char *)&a[0]);
    printf("%d\n", a[1] + a[4]);
    return 0;
}

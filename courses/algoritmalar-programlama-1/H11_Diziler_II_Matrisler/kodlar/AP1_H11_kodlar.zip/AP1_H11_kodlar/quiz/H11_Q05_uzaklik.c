/* H11_Q05_uzaklik.c — Hafta 11 · Quiz S5 (satır öncelikli adres)
 * Soru   : int m[3][4] için &m[2][1], &m[0][0]'dan kaç bayt uzaktadır?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_Q05_uzaklik.c -o q05
 */
#include <stdio.h>

int main(void)
{
    int m[3][4];
    printf("%td\n", (char *)&m[2][1] - (char *)&m[0][0]);
    return 0;
}

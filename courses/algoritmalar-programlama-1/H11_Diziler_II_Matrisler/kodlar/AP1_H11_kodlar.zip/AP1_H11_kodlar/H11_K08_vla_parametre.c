/* H11_K08_vla_parametre.c — Hafta 11 · Kavram programı (Merak Kutusu): VLA parametre
 * Amaç   : Değişken uzunluklu dizi (VLA) parametresi: boyutlar parametre
 *          listesinde dizinin ÖNÜNDE gelir, int m[satir][sutun]. Tek bir
 *          fonksiyon 2 × 3 ve 3 × 2 matrisleri yazdırabilir. VLA C99'da
 *          zorunlu, C11/C17'de isteğe bağlıdır (GCC ve Clang destekler;
 *          MSVC desteklemez)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K08_vla_parametre.c -o vla_parametre
 * Örnek  : -> 3 x 2:
 */
#include <stdio.h>

void yazdir(int satir, int sutun, int m[satir][sutun])
{
    printf("%d x %d:\n", satir, sutun);
    for (int i = 0; i < satir; i++) {
        for (int j = 0; j < sutun; j++) {
            printf("%3d", m[i][j]);
        }
        printf("\n");
    }
}

int main(void)
{
    int a[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int t[3][2] = {{1, 4}, {2, 5}, {3, 6}};
    yazdir(2, 3, a);
    yazdir(3, 2, t);
    return 0;
}

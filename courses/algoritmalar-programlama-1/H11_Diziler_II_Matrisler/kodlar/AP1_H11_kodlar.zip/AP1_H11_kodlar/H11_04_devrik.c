/* H11_04_devrik.c — Hafta 11 · Örnek 4 (★★): Devrik (transpoz) matris
 * Amaç   : t[j][i] = a[i][j]: indisler yer değiştirir, boyutlar da
 *          (2 × 3 → 3 × 2). Yerinde devrik yalnızca KARE matriste olur:
 *          köşegenin üstündeki her eleman alttaki eşiyle bir kez takas edilir
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_04_devrik.c -o devrik
 * Örnek  : -> Takas sayısı: 3 (N(N-1)/2)
 */
#include <stdio.h>

#define SATIR 2
#define SUTUN 3
#define N 3

int main(void)
{
    const int a[SATIR][SUTUN] = {{1, 2, 3}, {4, 5, 6}};
    int t[SUTUN][SATIR];                      /* devrik: 3 satır × 2 sütun */

    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            t[j][i] = a[i][j];                /* indisler yer değiştirir */
        }
    }
    printf("Devrik (3 x 2):\n");
    for (int i = 0; i < SUTUN; i++) {
        for (int j = 0; j < SATIR; j++) {
            printf("%3d", t[i][j]);
        }
        printf("\n");
    }

    int k[N][N] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int takas = 0;
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {     /* yalnızca köşegenin üstü */
            int gecici = k[i][j];
            k[i][j] = k[j][i];
            k[j][i] = gecici;
            takas++;
        }
    }
    printf("Yerinde devrik (3 x 3):\n");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%3d", k[i][j]);
        }
        printf("\n");
    }
    printf("Takas sayısı: %d (N(N-1)/2)\n", takas);
    return 0;
}

/* test_obs.c — Mini-OBS v0.11 (AP-1 Hafta 11): birim testleri
 * v0.8'deki 37 kural doğrulaması (aynen) + dizi fonksiyonları için yeni
 * testler (numara_bul, dizi_ortalama, standart_sapma, en büyük/küçük
 * indis, eşik üstü sayma, harf_indeksi) + 2B dizi testleri (sütun
 * kopyalama, katsayı, YANO, ders × harf frekans matrisi).
 * Derleme : make test       (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c test_obs.c
 *           gcc obs.o test_obs.o -o obs_test -lm && ./obs_test
 */
#include <stdio.h>
#include <assert.h>
#include <string.h>   /* strcmp: metin karşılaştırmak için */
#include <stdbool.h>
#include "obs.h"

static int sayac = 0;                /* geçen doğrulama sayısı (dosya kapsamı) */
static const double EPS = 1e-9;      /* kayan nokta toleransı */

/* v0.8'deki 37 kural testi (aynen) */
static void kural_testleri(void)
{
    /* hesapla_ortalama: kayan noktada == yerine tolerans */
    assert(hesapla_ortalama(70, 85) - 79.0 < EPS && 79.0 - hesapla_ortalama(70, 85) < EPS); sayac++;
    assert(hesapla_ortalama(0, 0) == 0.0); sayac++;
    assert(hesapla_ortalama(100, 100) - 100.0 < EPS && 100.0 - hesapla_ortalama(100, 100) < EPS); sayac++;

    /* yuvarla: .5 yukarı, altı aşağı */
    assert(yuvarla(59.5) == 60); sayac++;
    assert(yuvarla(59.4) == 59); sayac++;
    assert(yuvarla(0.0) == 0); sayac++;
    assert(yuvarla(100.0) == 100); sayac++;

    /* harf_notu: her kademenin iki sınırı ve baraj */
    assert(strcmp(harf_notu(100, 100), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(90, 90), "AA") == 0); sayac++;
    assert(strcmp(harf_notu(89, 89), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(81, 81), "BA") == 0); sayac++;
    assert(strcmp(harf_notu(80, 80), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(73, 73), "BB") == 0); sayac++;
    assert(strcmp(harf_notu(72, 72), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(66, 66), "CB") == 0); sayac++;
    assert(strcmp(harf_notu(65, 65), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(60, 60), "CC") == 0); sayac++;
    assert(strcmp(harf_notu(59, 59), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(50, 50), "DC") == 0); sayac++;
    assert(strcmp(harf_notu(49, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(40, 50), "DD") == 0); sayac++;
    assert(strcmp(harf_notu(39, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(30, 50), "FD") == 0); sayac++;
    assert(strcmp(harf_notu(29, 50), "FF") == 0); sayac++;
    assert(strcmp(harf_notu(95, 49.9), "FF") == 0); sayac++;   /* baraj */

    /* gecti_mi / sartli_mi */
    assert(gecti_mi(60, 50)); sayac++;
    assert(!gecti_mi(59, 80)); sayac++;
    assert(!gecti_mi(95, 49.9)); sayac++;
    assert(sartli_mi(50, 50)); sayac++;
    assert(sartli_mi(59, 60)); sayac++;
    assert(!sartli_mi(60, 60)); sayac++;
    assert(!sartli_mi(49, 60)); sayac++;
    assert(!sartli_mi(55, 45)); sayac++;

    /* durum_metni */
    assert(strcmp(durum_metni(79, 85), "BAŞARILI") == 0); sayac++;
    assert(strcmp(durum_metni(54, 70), "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)") == 0); sayac++;
    assert(strcmp(durum_metni(47, 48), "BAŞARISIZ (final barajı)") == 0); sayac++;
    assert(strcmp(durum_metni(45, 50), "BAŞARISIZ") == 0); sayac++;
}

/* Kayan nokta karşılaştırması: |x - y| < EPS */
static bool yakin(double x, double y)
{
    return x - y < EPS && y - x < EPS;
}

/* Yeni (H10): dizi fonksiyonları */
static void dizi_testleri(void)
{
    const long long no[] = {2301010045, 2301010046, 2301010047};
    assert(numara_bul(no, 3, 2301010046) == 1); sayac++;
    assert(numara_bul(no, 3, 2301010099) == -1); sayac++;
    assert(numara_bul(no, 0, 2301010045) == -1); sayac++;   /* boş dizi */

    const double a[] = {2, 4, 4, 4, 5, 5, 7, 9};             /* μ = 5, σ = 2 */
    int n = (int)(sizeof a / sizeof a[0]);
    assert(yakin(dizi_ortalama(a, n), 5.0)); sayac++;
    assert(yakin(standart_sapma(a, n), 2.0)); sayac++;
    assert(en_buyuk_indis(a, n) == 7); sayac++;
    assert(en_kucuk_indis(a, n) == 0); sayac++;
    assert(esik_ustu_say(a, n, 5.0) == 2); sayac++;          /* yalnız 7 ve 9 */

    const double esit[] = {3, 8, 8, 1};                      /* eşitlikte İLK indis */
    assert(en_buyuk_indis(esit, 4) == 1); sayac++;
    assert(yakin(standart_sapma(esit, 1), 0.0)); sayac++;    /* tek eleman */

    assert(harf_indeksi(90, 90) == 0 && strcmp(harf_adi(0), "AA") == 0); sayac++;
    assert(harf_indeksi(59, 60) == 5 && strcmp(harf_adi(5), "DC") == 0); sayac++;
    assert(harf_indeksi(95, 49.9) == 8 && strcmp(harf_adi(8), "FF") == 0); sayac++;
    for (int y = 0; y <= 100; y++) {                          /* iki merdiven aynı */
        assert(strcmp(harf_adi(harf_indeksi(y, 60)), harf_notu(y, 60)) == 0);
    }
    sayac++;

}

/* Yeni (H11): 2B dizi testleri */
static void matris_testleri(void)
{
    for (int k = 0; k < HARF_SAYISI; k++) {                   /* 4,00 → 0,00 */
        assert(yakin(harf_katsayisi(k), 4.0 - 0.5 * k));
    }
    sayac++;

    double ort[2][DERS_SAYISI] = {{79.0, 93.0, 54.0}, {46.8, 59.6, 66.0}};
    double fin[2][DERS_SAYISI] = {{85, 95, 70}, {48, 58, 70}};
    double sutun[2];
    sutun_kopyala(ort, 2, 1, sutun);                          /* 2. ders sütunu */
    assert(yakin(sutun[0], 93.0) && yakin(sutun[1], 59.6)); sayac++;

    /* 1. öğrenci: BB (3,00 × 6) + AA (4,00 × 6) + DC (1,50 × 5) = 49,5 / 17
     * = 2,9118 → iki haneye yuvarlanır (Madde 31/2-a): 2,91 */
    assert(yakin(yano_hesapla(ort[0], fin[0]), 2.91)); sayac++;
    /* 2. öğrenci: FF (baraj) + CC (2,00 × 6) + CB (2,50 × 5) = 24,5 / 17
     * = 1,4412 → 1,44 */
    assert(yakin(yano_hesapla(ort[1], fin[1]), 1.44)); sayac++;
    /* Yuvarlama sınırı: üçüncü hane >= 5 ise YUKARI (kesme değil):
     * FF, FF, FD (0,50 × 5) = 2,5 / 17 = 0,14706 → 0,15 (kesilse 0,14) */
    double o3[DERS_SAYISI] = {20, 20, 37}, f3[DERS_SAYISI] = {20, 20, 50};
    assert(yakin(yano_hesapla(o3, f3), 0.15)); sayac++;
    /* Tam değerler: hepsi AA → 4,00; hepsi FF → 0,00 */
    double o4[DERS_SAYISI] = {95, 95, 95}, f4[DERS_SAYISI] = {95, 95, 95};
    assert(yakin(yano_hesapla(o4, f4), 4.00) && yakin(yano_hesapla(o3, o3), 0.00)); sayac++;

    int sayaclar[DERS_SAYISI][HARF_SAYISI];
    ders_harf_dagilimi(ort, fin, 2, sayaclar);
    for (int d = 0; d < DERS_SAYISI; d++) {                   /* her sütun 2 */
        int toplam = 0;
        for (int k = 0; k < HARF_SAYISI; k++) {
            toplam += sayaclar[d][k];
        }
        assert(toplam == 2);
    }
    sayac++;
    assert(sayaclar[0][2] == 1 && sayaclar[0][8] == 1); sayac++;   /* BB, FF */
    assert(sayaclar[1][0] == 1 && sayaclar[1][4] == 1); sayac++;   /* AA, CC */
    assert(sayaclar[2][5] == 1 && sayaclar[2][3] == 1); sayac++;   /* DC, CB */
}

int main(void)
{
    kural_testleri();
    int kural = sayac;
    dizi_testleri();
    int dizi = sayac - kural;
    matris_testleri();
    printf("Tüm testler geçti (%d doğrulama: %d kural + %d dizi + %d matris).\n",
           sayac, kural, dizi, sayac - kural - dizi);
    return 0;
}

/* obs.h — Mini-OBS v0.11 (AP-1 Hafta 11): modülün ARAYÜZÜ
 * Yenilik : Çoklu ders. Notlar [öğrenci][ders] matrislerinde tutulur:
 *           vize[i][d], final[i][d], ort[i][d] (i: öğrenci, d: ders).
 *           Bir öğrencinin bütün dersleri bir SATIR (ort[i] → 1B dizi),
 *           bir dersin bütün öğrencileri bir SÜTUNDUR (bellekte bitişik
 *           değildir; sütun işlemleri için geçici diziye kopyalanır).
 *           Ders bazlı istatistik tablosu, ders × harf frekans matrisi ve
 *           kredi ağırlıklı YANO ile transkript.
 * Not     : 2B dizi parametrelerinde const KULLANILMADI: C17'de
 *           double (*)[3] → const double (*)[3] dönüşümü uyumsuz sayılır
 *           (-pedantic uyarı verir; C23'te düzeltildi). Salt okunurluk
 *           yorumla belgelendi.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>

#define AZAMI_OGRENCI 100   /* satır kapasitesi */
#define DERS_SAYISI 3       /* sütun sayısı: 2B dizi parametresinde zorunlu */
#define HARF_SAYISI 9       /* AA, BA, BB, CB, CC, DC, DD, FD, FF */

/* ---- ekran ve girdi ---- */
void baslik_yaz(void);
void menu_goster(void);
int menu_secimi_oku(void);
long long numara_oku(void);
double not_oku(const char *etiket);

/* ---- hesap kuralları (v0.8'den) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
int harf_indeksi(int yuvarlanmis, double final);   /* AA=0 ... FF=8 */
const char *harf_adi(int indeks);
double harf_katsayisi(int indeks);                 /* AA 4,00 ... FF 0,00 */

/* ---- dersler ---- */
const char *ders_adi(int d);
const char *ders_kodu(int d);
int ders_kredisi(int d);                           /* örnek kredi değerleri */

/* ---- 1B dizi desenleri (v0.10'dan; bir SATIR ya da kopyalanmış SÜTUN) ---- */
int numara_bul(const long long no[], int n, long long aranan);
double dizi_ortalama(const double a[], int n);
double standart_sapma(const double a[], int n);
int en_buyuk_indis(const double a[], int n);
int en_kucuk_indis(const double a[], int n);
int esik_ustu_say(const double a[], int n, double esik);

/* ---- 2B dizi işlemleri (H11) ---- */
void sutun_kopyala(double m[][DERS_SAYISI], int n, int d, double hedef[]);
double yano_hesapla(const double ort_satiri[], const double final_satiri[]);
void ders_harf_dagilimi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                        int n, int sayac[DERS_SAYISI][HARF_SAYISI]);

/* ---- raporlar ---- */
void ogrenci_ozeti_yaz(long long numara, const double ort_satiri[],
                       const double final_satiri[]);
void ders_istatistikleri_yaz(double ort[][DERS_SAYISI],
                             double final[][DERS_SAYISI], int n);
void transkript_yaz(long long numara, const double vize_satiri[],
                    const double final_satiri[], const double ort_satiri[]);
void harf_tablosu_yaz(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n);
void kayitlari_listele(const long long no[], double ort[][DERS_SAYISI],
                       double final[][DERS_SAYISI], int n);

#endif /* OBS_H */

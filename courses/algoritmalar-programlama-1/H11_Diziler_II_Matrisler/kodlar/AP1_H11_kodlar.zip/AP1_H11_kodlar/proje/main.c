/* main.c — Mini-OBS v0.11 (AP-1 Hafta 11): menü döngüsü + not matrisleri
 * Kayıtlar: no[i] (1B) ve vize[i][d], final[i][d], ort[i][d] (2B; i öğrenci,
 * d ders). Bir öğrencinin satırı (ör. ort[i]) 1B dizi olarak fonksiyonlara
 * verilebilir; matrisin tamamı verilirken sütun sayısı (DERS_SAYISI)
 * parametre tipinde zorunludur.
 * Derleme : make            (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c main.c
 *           gcc obs.o main.o -o mini_obs -lm
 */
#include <stdio.h>
#include "obs.h"

int main(void)
{
    long long no[AZAMI_OGRENCI];
    double vize[AZAMI_OGRENCI][DERS_SAYISI];      /* [öğrenci][ders] */
    double final[AZAMI_OGRENCI][DERS_SAYISI];
    double ort[AZAMI_OGRENCI][DERS_SAYISI];
    int n = 0;                                    /* dolu satır sayısı */
    int secim = 0;

    baslik_yaz();
    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }

        switch (secim) {
        case 1: {
            if (n == AZAMI_OGRENCI) {
                printf("  Kapasite dolu (%d öğrenci).\n", AZAMI_OGRENCI);
                break;
            }
            printf("\n------------ ÖĞRENCİ %d ------------\n", n + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            int bulunan = numara_bul(no, n, numara);
            if (bulunan != -1) {
                printf("  Bu numara zaten kayıtlı (sıra %d).\n", bulunan + 1);
                break;
            }
            for (int d = 0; d < DERS_SAYISI; d++) {      /* satırı doldur */
                printf("-- %s (%d kredi) --\n", ders_adi(d), ders_kredisi(d));
                double v = not_oku("Vize notu        : ");
                if (v < 0) {
                    printf("\nGirdi sona erdi.\n");
                    return 1;
                }
                double f = not_oku("Final notu       : ");
                if (f < 0) {
                    printf("\nGirdi sona erdi.\n");
                    return 1;
                }
                vize[n][d] = v;
                final[n][d] = f;
                ort[n][d] = hesapla_ortalama(v, f);
            }
            no[n] = numara;
            ogrenci_ozeti_yaz(numara, ort[n], final[n]);  /* satırlar 1B dizi */
            n++;
            break;
        }
        case 2:
            ders_istatistikleri_yaz(ort, final, n);
            break;
        case 3: {
            if (n == 0) {
                printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
                break;
            }
            long long numara = numara_oku();
            if (numara == -1) {
                printf("\nGirdi sona erdi.\n");
                return 1;
            }
            int i = numara_bul(no, n, numara);
            if (i == -1) {
                printf("  Kayıt bulunamadı: %lld\n", numara);
                break;
            }
            transkript_yaz(no[i], vize[i], final[i], ort[i]);
            break;
        }
        case 4:
            harf_tablosu_yaz(ort, final, n);
            break;
        case 5:
            kayitlari_listele(no, ort, final, n);
            break;
        case 6:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n", n);
            break;
        default:
            printf("  Geçersiz seçim: 1-6 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 6);

    return 0;
}

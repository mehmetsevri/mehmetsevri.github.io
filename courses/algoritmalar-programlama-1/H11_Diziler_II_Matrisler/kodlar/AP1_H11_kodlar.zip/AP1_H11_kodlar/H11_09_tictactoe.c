/* H11_09_tictactoe.c — Hafta 11 · Örnek 9 (★★★): Tic-tac-toe ve kazanan denetimi
 * Amaç   : 3 × 3 char tahta; iki oyuncu sırayla hamle girer (satır sütun,
 *          1-3). Her hamleden sonra 3 satır, 3 sütun ve 2 köşegen (toplam
 *          8 çizgi) denetlenir; 9 hamlede kazanan yoksa berabere
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_09_tictactoe.c -o tictactoe
 * Örnek  : girdi "2 2 / 1 1 / 4 1 / 1 1 / 1 3 / 2 1 / 3 1"
 *          -> Kazanan: X (5 hamlede)
 */
#include <stdio.h>

#define N 3

void tahta_yazdir(char t[][N])
{
    for (int i = 0; i < N; i++) {
        printf(" %c | %c | %c\n", t[i][0], t[i][1], t[i][2]);
        if (i < N - 1) {
            printf("---+---+---\n");
        }
    }
}

/* Üç hücre aynı oyuncunun mu? (boş '.' sayılmaz) */
int ayni(char x, char y, char z)
{
    return x != '.' && x == y && y == z;
}

/* Kazanan 'X' ya da 'O'; yoksa '.' döndürür. */
char kazanan(char t[][N])
{
    for (int i = 0; i < N; i++) {
        if (ayni(t[i][0], t[i][1], t[i][2])) {         /* i. satır */
            return t[i][0];
        }
        if (ayni(t[0][i], t[1][i], t[2][i])) {         /* i. sütun */
            return t[0][i];
        }
    }
    if (ayni(t[0][0], t[1][1], t[2][2])) {             /* ana köşegen */
        return t[0][0];
    }
    if (ayni(t[0][2], t[1][1], t[2][0])) {             /* yan köşegen */
        return t[0][2];
    }
    return '.';
}

int main(void)
{
    char t[N][N] = {{'.', '.', '.'}, {'.', '.', '.'}, {'.', '.', '.'}};
    char oyuncu = 'X';
    int hamle = 0;

    while (hamle < N * N) {
        int s, k;
        printf("%c oynuyor (satır sütun): ", oyuncu);
        if (scanf("%d %d", &s, &k) != 2) {
            printf("\nGirdi sona erdi.\n");
            return 1;
        }
        if (s < 1 || s > N || k < 1 || k > N || t[s - 1][k - 1] != '.') {
            printf("  Geçersiz hamle, tekrar deneyin.\n");
            continue;                         /* aynı oyuncu yeniden oynar */
        }
        t[s - 1][k - 1] = oyuncu;
        hamle++;
        if (kazanan(t) != '.') {
            tahta_yazdir(t);
            printf("Kazanan: %c (%d hamlede)\n", oyuncu, hamle);
            return 0;
        }
        oyuncu = (oyuncu == 'X') ? 'O' : 'X';
    }
    tahta_yazdir(t);
    printf("Berabere.\n");
    return 0;
}

/* H11_10_mayin_tarlasi.c — Hafta 11 · Örnek 10 (★★★): Mayın tarlası komşu sayıları
 * Amaç   : 8-komşuluk: bir hücrenin çevresindeki 3 × 3 pencerenin
 *          (di, dj ∈ {-1, 0, 1}, merkez hariç) mayınları sayılır. Kenar ve
 *          köşe hücrelerinde pencere dizinin dışına taşar: her komşu
 *          erişiminden ÖNCE sınır denetimi yapılır
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_10_mayin_tarlasi.c -o mayin_tarlasi
 * Örnek  : -> Mayın: 9, en kalabalık hücre: 4 komşu mayın
 */
#include <stdio.h>

#define SATIR 6
#define SUTUN 8

int komsu_mayin(int m[][SUTUN], int i, int j)
{
    int sayi = 0;
    for (int di = -1; di <= 1; di++) {
        for (int dj = -1; dj <= 1; dj++) {
            int ni = i + di, nj = j + dj;     /* komşunun konumu */
            if (di == 0 && dj == 0) {
                continue;                     /* hücrenin kendisi */
            }
            if (ni >= 0 && ni < SATIR && nj >= 0 && nj < SUTUN) {
                sayi += m[ni][nj];            /* yalnızca ızgara içi */
            }
        }
    }
    return sayi;
}

int main(void)
{
    int mayin[SATIR][SUTUN] = {               /* 1: mayın, 0: boş */
        {1, 0, 0, 0, 0, 0, 0, 1},
        {0, 0, 1, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 1, 1, 0, 0},
        {0, 1, 0, 1, 0, 1, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 1}
    };
    int toplam = 0, en_fazla = 0;

    for (int i = 0; i < SATIR; i++) {
        for (int j = 0; j < SUTUN; j++) {
            if (mayin[i][j]) {
                printf(" *");
                toplam++;
            } else {
                int k = komsu_mayin(mayin, i, j);
                printf(" %c", k == 0 ? '.' : '0' + k);
                if (k > en_fazla) {
                    en_fazla = k;
                }
            }
        }
        printf("\n");
    }
    printf("Mayın: %d, en kalabalık hücre: %d komşu mayın\n", toplam, en_fazla);
    return 0;
}

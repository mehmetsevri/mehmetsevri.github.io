/* H11_05_kosegen_simetri.c — Hafta 11 · Örnek 5 (★★): Köşegenler, birim ve simetri
 * Amaç   : 2B diziyi fonksiyona aktarmak (sütun boyutu N zorunlu) ve
 *          koşullu dolaşma: ana köşegen i == j, yan köşegen i + j == N - 1,
 *          birim matris, simetri (yalnızca üst üçgen) ve üst üçgen denetimi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_05_kosegen_simetri.c -o kosegen_simetri
 * Örnek  : -> B     4    0  evet     evet       evet
 */
#include <stdio.h>
#include <stdbool.h>

#define N 4

int ana_kosegen(int m[][N])                   /* sütun sayısı N zorunlu */
{
    int toplam = 0;
    for (int i = 0; i < N; i++) {
        toplam += m[i][i];                    /* i == j */
    }
    return toplam;
}

int yan_kosegen(int m[][N])
{
    int toplam = 0;
    for (int i = 0; i < N; i++) {
        toplam += m[i][N - 1 - i];            /* i + j == N - 1 */
    }
    return toplam;
}

bool birim_mi(int m[][N])
{
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (m[i][j] != (i == j ? 1 : 0)) {
                return false;                 /* ilk aykırılıkta çık */
            }
        }
    }
    return true;
}

bool simetrik_mi(int m[][N])
{
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {     /* yalnızca üst üçgen */
            if (m[i][j] != m[j][i]) {
                return false;
            }
        }
    }
    return true;
}

bool ust_ucgen_mi(int m[][N])
{
    for (int i = 1; i < N; i++) {
        for (int j = 0; j < i; j++) {         /* köşegenin altı: j < i */
            if (m[i][j] != 0) {
                return false;
            }
        }
    }
    return true;
}

void rapor(char ad, int m[][N])
{
    printf("%c  %4d %4d  %-5s    %-5s      %s\n", ad, ana_kosegen(m),
           yan_kosegen(m), birim_mi(m) ? "evet" : "hayır",
           simetrik_mi(m) ? "evet" : "hayır",
           ust_ucgen_mi(m) ? "evet" : "hayır");
}

int main(void)
{
    int a[N][N] = {{2, 7, 1, 8}, {7, 3, 9, 4}, {1, 9, 5, 6}, {8, 4, 6, 0}};
    int b[N][N] = {{1, 0, 0, 0}, {0, 1, 0, 0}, {0, 0, 1, 0}, {0, 0, 0, 1}};
    int c[N][N] = {{3, 1, 4, 1}, {0, 5, 9, 2}, {0, 0, 6, 5}, {0, 0, 0, 3}};
    int d[N][N] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12},
                   {13, 14, 15, 16}};

    printf("   Ana  Yan  Birim    Simetrik   Üst üçgen\n");
    rapor('A', a);
    rapor('B', b);
    rapor('C', c);
    rapor('D', d);
    return 0;
}

/* H11_K06_uc_boyutlu.c — Hafta 11 · Kavram programı: üç boyutlu dizi
 * Amaç   : notlar[SUBE][OGRENCI][DERS]: 2 şube × 3 öğrenci × 2 ders.
 *          Üç iç içe döngü; bellekte yine tek şerit: notlar[s][o][d]'nin
 *          uzaklığı ((s * OGRENCI + o) * DERS + d) * sizeof(int)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_K06_uc_boyutlu.c -o uc_boyutlu
 * Örnek  : -> uzaklık(notlar[1][2][1]) = 44 bayt, formül = 44
 */
#include <stdio.h>

#define SUBE 2
#define OGRENCI 3
#define DERS 2

int main(void)
{
    int notlar[SUBE][OGRENCI][DERS] = {
        {{70, 80}, {55, 65}, {90, 85}},        /* A şubesi */
        {{60, 75}, {88, 92}, {45, 50}}         /* B şubesi */
    };

    for (int s = 0; s < SUBE; s++) {
        int toplam = 0;
        for (int o = 0; o < OGRENCI; o++) {
            for (int d = 0; d < DERS; d++) {
                toplam += notlar[s][o][d];
            }
        }
        printf("%c şubesi ortalaması: %.2f\n", 'A' + s,
               (double)toplam / (OGRENCI * DERS));
    }
    printf("sizeof notlar = %zu, sizeof notlar[0] = %zu, "
           "sizeof notlar[0][0] = %zu\n",
           sizeof notlar, sizeof notlar[0], sizeof notlar[0][0]);
    printf("uzaklık(notlar[1][2][1]) = %td bayt, formül = %zu\n",
           (char *)&notlar[1][2][1] - (char *)&notlar[0][0][0],
           ((1 * OGRENCI + 2) * DERS + 1) * sizeof(int));
    return 0;
}

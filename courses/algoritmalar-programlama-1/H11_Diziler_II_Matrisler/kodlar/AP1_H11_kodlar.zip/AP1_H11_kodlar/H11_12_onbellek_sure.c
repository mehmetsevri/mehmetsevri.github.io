/* H11_12_onbellek_sure.c — Hafta 11 · Örnek 12 (★★★): Önbellek süre deneyi
 * Amaç   : N × N int matrisin (N = 4000: 4000 · 4000 · 4 bayt ≈ 64 MB)
 *          elemanlarını iki sırayla toplar: satır öncelikli (i dışta, j
 *          içte; bellekte ardışık adımlar) ve sütun öncelikli (j dışta, i
 *          içte; her adımda N · 4 bayt atlama). Süreler clock() ile ölçülür,
 *          deney TEKRAR kez yinelenir, en kısa süreler ve oran yazdırılır.
 *          Toplamlar yazdırılır: sonuç kullanılmazsa -O2 hesabı silebilir.
 *          (Ölçüm betiği N'yi -DN=1000 gibi derleme seçeneğiyle değiştirir.)
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H11_12_onbellek_sure.c -o onbellek_sure
 * Örnek  : girdi "3" -> toplamlar eşit: evet
 */
#include <stdio.h>
#include <time.h>   /* clock, clock_t, CLOCKS_PER_SEC */

#ifndef N
#define N 4000
#endif

static int m[N][N];   /* ≈ 64 MB: yığına sığmaz, static (bss) bölgede */

long long satir_oncelikli(int a[][N])
{
    long long toplam = 0;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            toplam += a[i][j];                /* adım: 4 bayt */
        }
    }
    return toplam;
}

long long sutun_oncelikli(int a[][N])
{
    long long toplam = 0;
    for (int j = 0; j < N; j++) {
        for (int i = 0; i < N; i++) {
            toplam += a[i][j];                /* adım: N · 4 bayt */
        }
    }
    return toplam;
}

int main(void)
{
    int tekrar;
    printf("Tekrar sayısı: ");
    if (scanf("%d", &tekrar) != 1 || tekrar < 1) {
        printf("Geçersiz girdi.\n");
        return 1;
    }
    for (int i = 0; i < N; i++) {             /* doldur (sayfalar belleğe) */
        for (int j = 0; j < N; j++) {
            m[i][j] = (i + j) % 10;
        }
    }

    long long t1 = 0, t2 = 0;
    double en_satir = 0.0, en_sutun = 0.0;
    for (int t = 1; t <= tekrar; t++) {
        clock_t bas = clock();
        t1 = satir_oncelikli(m);
        clock_t ara = clock();
        t2 = sutun_oncelikli(m);
        clock_t son = clock();
        double s1 = (double)(ara - bas) / CLOCKS_PER_SEC;
        double s2 = (double)(son - ara) / CLOCKS_PER_SEC;
        printf("tekrar %d: satır öncelikli %.4f s, sütun öncelikli %.4f s\n",
               t, s1, s2);
        if (t == 1 || s1 < en_satir) {
            en_satir = s1;
        }
        if (t == 1 || s2 < en_sutun) {
            en_sutun = s2;
        }
    }
    printf("N = %d, toplamlar eşit: %s (%lld)\n", N,
           t1 == t2 ? "evet" : "hayır", t1);
    printf("en kısa: satır %.4f s, sütun %.4f s, oran %.1f\n", en_satir,
           en_sutun, en_sutun / en_satir);
    return 0;
}

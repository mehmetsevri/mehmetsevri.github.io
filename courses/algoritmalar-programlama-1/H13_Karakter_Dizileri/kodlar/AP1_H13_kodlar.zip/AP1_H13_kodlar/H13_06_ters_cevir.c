/* H13_06_ters_cevir.c — Hafta 13 · Örnek 6 (★★): String'i yerinde ters çevir
 * Amaç   : H10'un iki uç tekniğinin (H10_07_ters_cevir.c) string'e
 *          uygulanışı: i baştan, j sondan; s[i] ile s[j] takas edilir,
 *          i < j olduğu sürece. Ek dizi gerekmez ("yerinde"). '\0' yerinde
 *          kalır. Uzunluk strlen ile bulunur; '\0' takasa katılmaz.
 * Not    : Bu BAYT bazlı ters çevirmedir: Türkçe çok baytlı harfler
 *          baytlarına ayrılacağı için yalnızca ASCII metinler doğru çevrilir
 *          (Örnek 12'de neden açıklanır).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_06_ters_cevir.c -o ters_cevir
 * Örnek  : -> "merhaba" -> "abahrem"
 */
#include <stdio.h>
#include <string.h>

void ters_cevir(char *s)
{
    size_t i = 0;
    size_t j = strlen(s);
    if (j == 0) {
        return;                      /* boş string: yapılacak bir şey yok */
    }
    j--;                             /* son karakterin indisi ('\0'dan önce) */
    while (i < j) {
        char gecici = s[i];          /* üç atamayla takas (H3) */
        s[i] = s[j];
        s[j] = gecici;
        i++;
        j--;
    }
}

static void dene(char *s)
{
    char once[64];
    strcpy(once, s);
    ters_cevir(s);
    printf("\"%s\" -> \"%s\"\n", once, s);
}

int main(void)
{
    char a[] = "merhaba";
    char b[] = "AP-1 2026";
    char c[] = "x";                  /* tek karakter: yerinde kalır */
    dene(a);
    dene(b);
    dene(c);
    return 0;
}

/* H13_K09_ctype.c — Hafta 13 · Kavram programı: ctype.h ve unsigned char
 * Amaç   : ctype.h sınıflandırma/dönüştürme fonksiyonları (isalpha, isdigit,
 *          isspace, isupper, toupper, tolower) ve KRİTİK kural: argüman
 *          önce unsigned char'a çevrilmelidir. char çoğu derleyicide
 *          İŞARETLİDİR; 0x80+ bir bayt (ör. UTF-8 devam baytı) negatif
 *          olur ve negatif değer (EOF hariç) ctype'a verilmesi TANIMSIZ
 *          DAVRANIŞTIR (SEI CERT STR37-C).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_K09_ctype.c -o ctype_c
 * Örnek  : -> 'A' harf mi? evet; büyük mü? evet
 */
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    char c = 'A';
    unsigned char uc = (unsigned char)c;   /* ctype'a vermeden önce ZORUNLU */

    printf("'%c' harf mi? %s; rakam mı? %s; boşluk mu? %s\n", c,
           isalpha(uc) ? "evet" : "hayır",
           isdigit(uc) ? "evet" : "hayır",
           isspace(uc) ? "evet" : "hayır");
    printf("isupper('%c') = %s; tolower -> '%c'\n", c,
           isupper(uc) ? "evet" : "hayır", tolower(uc));
    printf("toupper('g') -> '%c'; isdigit('7') -> %s\n",
           toupper((unsigned char)'g'),
           isdigit((unsigned char)'7') ? "evet" : "hayır");

    /* char işaretliyse 'char' negatif olabilir; işaret genişletmesi: */
    char kotu = (char)0xC3;                /* UTF-8 'ç'nin öncü baytı */
    printf("(char)0xC3 = %d (işaretliyse negatif); unsigned char = %d\n",
           kotu, (unsigned char)kotu);
    return 0;
}

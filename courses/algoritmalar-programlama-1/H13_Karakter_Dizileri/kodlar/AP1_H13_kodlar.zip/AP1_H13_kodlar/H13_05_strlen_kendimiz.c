/* H13_05_strlen_kendimiz.c — Hafta 13 · Örnek 5 (★★): Kendi strlen'imiz
 * Amaç   : strlen'in sırrının "'\0' bulana dek ilerle, adımları say" olması.
 *          İki gerçekleme: indisle (benim_strlen_indis) ve işaretçiyle
 *          (benim_strlen_isaretci; H12 işaretçi aritmetiğinin tekrarı:
 *          son - s, aradaki karakter sayısıdır). Standart strlen ile
 *          karşılaştırılır.
 * Not    : Dönüş tipi size_t (işaretsiz); string.h standart strlen ile aynı.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_05_strlen_kendimiz.c -o strlen_kendimiz
 * Örnek  : -> "Merhaba" : indis 7, işaretçi 7, strlen 7
 */
#include <stdio.h>
#include <string.h>

/* '\0' bulana dek indisi ilerlet; indisin son değeri uzunluktur */
size_t benim_strlen_indis(const char *s)
{
    size_t n = 0;
    while (s[n] != '\0') {
        n++;
    }
    return n;
}

/* p'yi '\0' bulana dek ilerlet; p - s aradaki karakter sayısıdır (H12) */
size_t benim_strlen_isaretci(const char *s)
{
    const char *p = s;
    while (*p != '\0') {
        p++;
    }
    return (size_t)(p - s);
}

static void dene(const char *s)
{
    printf("\"%s\" : indis %zu, işaretçi %zu, strlen %zu\n", s,
           benim_strlen_indis(s), benim_strlen_isaretci(s), strlen(s));
}

int main(void)
{
    dene("Merhaba");
    dene("AP-1");
    dene("");                        /* boş string: yalnızca '\0', uzunluk 0 */
    return 0;
}

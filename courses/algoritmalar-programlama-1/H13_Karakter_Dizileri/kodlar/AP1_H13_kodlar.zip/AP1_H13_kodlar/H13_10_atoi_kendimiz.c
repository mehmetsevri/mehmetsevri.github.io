/* H13_10_atoi_kendimiz.c — Hafta 13 · Örnek 10 (★★): Kendi atoi'miz
 * Amaç   : H6'daki basamak biriktirme deseninin (sonuc = sonuc * 10 + rakam)
 *          metin girdisine uygulanışı. benim_atoi: baştaki boşlukları atlar,
 *          isteğe bağlı +/- işaretini okur, rakam oldukça sonuç = sonuç*10 +
 *          (c - '0') biriktirir, ilk rakam olmayan karakterde durur.
 * Not    : atoi, HATAYI BİLDİREMEZ: "abc" için 0, taşmada tanımsız davranış
 *          döner ("123" ile "123abc" ayırt edilemez). Hata denetimi gereken
 *          yerde strtol kullanılır (Örnek 15; H13_K10). Bu yüzden benim_atoi
 *          yalnızca öğretim amaçlıdır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_10_atoi_kendimiz.c -o atoi_kendimiz
 * Örnek  : -> "  -42abc" -> -42 (benim), -42 (atoi)
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int benim_atoi(const char *s)
{
    int i = 0;
    while (isspace((unsigned char)s[i])) {   /* baştaki boşlukları atla */
        i++;
    }
    int isaret = 1;
    if (s[i] == '+' || s[i] == '-') {        /* isteğe bağlı işaret */
        isaret = (s[i] == '-') ? -1 : 1;
        i++;
    }
    int sonuc = 0;
    while (isdigit((unsigned char)s[i])) {   /* rakam oldukça biriktir */
        sonuc = sonuc * 10 + (s[i] - '0');   /* H6 deseni: karakter -> sayı */
        i++;
    }
    return isaret * sonuc;
}

static void dene(const char *s)
{
    printf("\"%s\" -> %d (benim), %d (atoi)\n", s, benim_atoi(s), atoi(s));
}

int main(void)
{
    dene("42");
    dene("  -42abc");                /* ilk rakam olmayanda durur */
    dene("2026");
    dene("abc");                     /* rakam yok: 0 (hata bildirilemez!) */
    dene("+7");
    return 0;
}

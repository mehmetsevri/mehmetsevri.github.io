/* H13_14_frekans_sezar_kirma.c — Hafta 13 · Örnek 14 (★★★): Frekans analizi
 * Amaç   : H10'un frekans dizisini (H10_10_harf_dagilimi.c) metne uygulamak
 *          ve bununla bir Sezar şifresini ANAHTARI bilmeden kırmak. 26
 *          elemanlık frekans dizisi doldurulur (harfin kendisi indis olur:
 *          sayac[c - 'A']). İngilizcede en sık harf 'E' olduğundan, şifreli
 *          metnin en sık harfinin 'E'ye karşılık geldiği varsayılır:
 *          anahtar = (en_sik - 'E' + 26) % 26.
 * Neden İngilizce? Frekans analizi, dilin harf sıklık dağılımına dayanır;
 *          burada İngilizce metin ve İngiliz alfabesi (A-Z) kullanılır.
 *          Türkçe harfler UTF-8'de çok baytlı ve alfabetik olarak ardışık
 *          olmadığından bu basit 26 kutulu modele girmez (Örnek 12).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_14_frekans_sezar_kirma.c -o frekans_sezar
 * Örnek  : -> Tahmini anahtar: 7
 */
#include <stdio.h>
#include <ctype.h>
#include <string.h>

static void sezar(char *s, int k)
{
    k = ((k % 26) + 26) % 26;
    for (size_t i = 0; s[i] != '\0'; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c >= 'A' && c <= 'Z') {
            s[i] = (char)('A' + (c - 'A' + k) % 26);
        } else if (c >= 'a' && c <= 'z') {
            s[i] = (char)('a' + (c - 'a' + k) % 26);
        }
    }
}

int main(void)
{
    char metin[] = "IN ENGLISH TEXT THE LETTER E APPEARS MORE OFTEN THAN "
                   "EVERY OTHER LETTER SO WHENEVER WE SEE THE SAME CIPHER "
                   "LETTER REPEATED WE EXPECT IT TO BE THE LETTER E";
    char sifre[sizeof metin];
    strcpy(sifre, metin);
    sezar(sifre, 7);                 /* bilinmeyen anahtarla şifrele (k = 7) */

    int sayac[26] = {0};      /* harfin kendisi indis: H10 frekans deseni */
    for (size_t i = 0; sifre[i] != '\0'; i++) {
        unsigned char c = (unsigned char)toupper((unsigned char)sifre[i]);
        if (c >= 'A' && c <= 'Z') {
            sayac[c - 'A']++;
        }
    }

    printf("Şifreli metnin harf frekansı (her # bir harf):\n");
    int en_sik = 0;
    for (int h = 0; h < 26; h++) {
        if (sayac[h] > sayac[en_sik]) {
            en_sik = h;
        }
        if (sayac[h] > 0) {
            printf("  %c (%2d) ", 'A' + h, sayac[h]);
            for (int j = 0; j < sayac[h]; j++) {
                putchar('#');
            }
            putchar('\n');
        }
    }

    int anahtar = ((en_sik - ('E' - 'A')) % 26 + 26) % 26;
    printf("En sık harf: %c -> 'E' varsayımı -> tahmini anahtar: %d\n",
           'A' + en_sik, anahtar);

    char cozulmus[sizeof metin];
    strcpy(cozulmus, sifre);
    sezar(cozulmus, -anahtar);       /* tahmini anahtarla çöz */
    printf("Çözülen metin: %s\n", cozulmus);
    return 0;
}

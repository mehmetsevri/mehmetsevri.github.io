/* H13_K08_snprintf.c — Hafta 13 · Kavram programı: snprintf
 * Amaç   : snprintf ile GÜVENLİ biçimli yazma. snprintf, hedefe en çok
 *          boyut-1 bayt yazar ve sona '\0' koyar: taşmaz. DÖNÜŞ DEĞERİ,
 *          "tam sığsaydı kaç bayt gerekirdi"dir (sonlandırıcı hariç);
 *          boyuta eşit ya da büyükse KESİLME olmuştur ve bu saptanabilir.
 *          sprintf'in boyut parametresi yoktur: taşabilir, kullanılmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K08_snprintf.c -o snprintf_c
 * Örnek  : -> "No: 23" sığdı; uzun ad KESİLDİ
 */
#include <stdio.h>

/* ad'ı biçimli yazar; kesilme olursa (dönüş >= boyut) bildirir */
static void kayit_yaz(const char *ad, int no)
{
    char tampon[8];
    int gerekli = snprintf(tampon, sizeof tampon, "%d:%s", no, ad);
    printf("\"%s\" (gerekli %d, boyut %zu, %s)\n", tampon, gerekli,
           sizeof tampon, gerekli < (int)sizeof tampon ? "sığdı" : "KESİLDİ");
}

int main(void)
{
    kayit_yaz("Ali", 23);            /* "23:Ali" (6 bayt): sığar */
    kayit_yaz("Abdullah", 7);        /* "7:Abdullah" (10 bayt): kesilir */
    return 0;
}

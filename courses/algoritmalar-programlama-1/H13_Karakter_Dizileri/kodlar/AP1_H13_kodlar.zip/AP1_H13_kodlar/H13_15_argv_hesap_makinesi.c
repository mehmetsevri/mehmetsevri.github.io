/* H13_15_argv_hesap_makinesi.c — Hafta 13 · Örnek 15 (★★★): argc/argv
 * Amaç   : main'in parametreleri. argc, komut satırı argümanı sayısıdır
 *          (program adı dahil); argv, argümanları gösteren string
 *          işaretçisi dizisidir. argv[0] program adı, argv[argc] == NULL'dır.
 *          Basit bir hesap makinesi: ./hesap 12 + 5. Sayı çözümü atoi ile
 *          DEĞİL, hata bildirebilen strtol ile yapılır (endptr, ERANGE).
 * Not    : argv dizgeleri '\0' ile biter; argv[argc] her zaman NULL'dır
 *          (ISO/IEC 9899:2018, 5.1.2.2.1). Program adından sonra tam üç
 *          argüman beklenir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_15_argv_hesap_makinesi.c -o hesap
 * Örnek  : $ ./hesap 12 x 5 -> 12 x 5 = 60
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>

/* metnin TAMAMI bir long tamsayıysa *sonuc'a yazar, true döner; strtol ile */
static bool tamsayi_coz(const char *metin, long *sonuc)
{
    char *son;
    errno = 0;
    long deger = strtol(metin, &son, 10);
    if (son == metin || *son != '\0' || errno == ERANGE) {
        return false;         /* rakam yok, artık karakter ya da taşma */
    }
    *sonuc = deger;
    return true;
}

int main(int argc, char *argv[])
{
    printf("argc = %d; argv[0] (program adı) = \"%s\"\n", argc, argv[0]);
    printf("argv[argc] == NULL mı? %s\n",
           argv[argc] == NULL ? "evet" : "hayır");

    if (argc != 4) {
        fprintf(stderr, "Kullanım: %s <sayı> <+|-|x|/> <sayı>\n", argv[0]);
        return 1;             /* hata: stderr'e yaz, 0'dan farklı dön */
    }
    long a, b;
    if (!tamsayi_coz(argv[1], &a) || !tamsayi_coz(argv[3], &b)) {
        fprintf(stderr, "Geçersiz sayı: \"%s\" ya da \"%s\"\n",
                argv[1], argv[3]);
        return 1;
    }
    char op = argv[2][0];            /* işlemin ilk karakteri */
    long sonuc;
    switch (op) {
    case '+': sonuc = a + b; break;
    case '-': sonuc = a - b; break;
    case 'x': sonuc = a * b; break;  /* * kabukta özel; x kullanıyoruz */
    case '/':
        if (b == 0) {
            fprintf(stderr, "Sıfıra bölme.\n");
            return 1;
        }
        sonuc = a / b;
        break;
    default:
        fprintf(stderr, "Bilinmeyen işlem: \"%s\"\n", argv[2]);
        return 1;
    }
    printf("%ld %c %ld = %ld\n", a, op, b, sonuc);
    return 0;
}

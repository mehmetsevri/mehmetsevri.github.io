/* H13_A02_hata_bul_birlestir.c — Hafta 13 · Alıştırma 13.2 (★★, Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: iki ismi birleştirip "Ad Soyad" yapmak
 *          isteniyor ama hedef tampon yetersiz ve '\0' için yer hesabı
 *          yanlış: tam_ad[8] "Ayse Yilmaz" (11 karakter + '\0') için çok
 *          küçük; strcpy/strcat taşırır. Hatayı bulun ve güvenli biçimde
 *          düzeltin (boyut + 1 kuralı; snprintf ya da yeterli tampon).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_A02_hata_bul_birlestir.c -o a02    (uyarı YOK, GÜVENSİZ)
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    const char *ad = "Ayse";
    const char *soyad = "Yilmaz";
    char tam_ad[8];                  /* HATA: 11 karakter + '\0' için küçük */
    strcpy(tam_ad, ad);
    strcat(tam_ad, " ");
    strcat(tam_ad, soyad);           /* taşar */
    printf("%s\n", tam_ad);
    return 0;
}

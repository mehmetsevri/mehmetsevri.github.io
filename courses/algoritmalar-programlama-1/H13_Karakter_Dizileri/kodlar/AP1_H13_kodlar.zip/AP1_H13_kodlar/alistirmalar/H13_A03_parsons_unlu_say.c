/* H13_A03_parsons_unlu_say.c — Hafta 13 · Alıştırma 13.3 (★★, Parsons)
 * Satırlar karışık verilmiştir: tamamlanacak; bu hâliyle derlenmez.
 * Görev  : unlu_say(s), s'deki ASCII ünlü (a,e,i,o,u; büyük/küçük) sayısını
 *          döndürmelidir. Satırları doğru sıraya dizin ve girintileyin.
 */
    return sayi;
int unlu_say(const char *s)
    for (size_t i = 0; s[i] != '\0'; i++) {
{
    int sayi = 0;
        char c = (char)tolower((unsigned char)s[i]);
        if (c=='a'||c=='e'||c=='i'||c=='o'||c=='u') {
            sayi++;
        }
    }
}

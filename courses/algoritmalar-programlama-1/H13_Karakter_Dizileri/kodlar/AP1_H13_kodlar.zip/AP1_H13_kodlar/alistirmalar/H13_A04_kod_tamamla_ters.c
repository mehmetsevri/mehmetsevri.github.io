/* H13_A04_kod_tamamla_ters.c — Hafta 13 · Alıştırma 13.4 (★★, Kod tamamla)
 * BOŞ BIRAKILAN YERLER (____) doldurulacak; bu hâliyle derlenmez.
 * Görev  : benim_strlen, '\0' bulana dek sayar; ters_yazdir, string'i
 *          sondan başa yazdırır. Boşlukları doldurun.
 */
#include <stdio.h>

size_t benim_strlen(const char *s)
{
    size_t n = 0;
    while (s[____] != '\0') {        /* (1) indis */
        n++;
    }
    return n;
}

void ters_yazdir(const char *s)
{
    size_t n = benim_strlen(s);
    for (size_t i = n; i > 0; i____) {   /* (2) azalt */
        putchar(s[i - 1]);
    }
    putchar('\n');
}

int main(void)
{
    ters_yazdir("merhaba");          /* abahrem */
    return 0;
}

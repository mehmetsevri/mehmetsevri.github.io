/* H13_A05_cikti_tahmini_sezar.c — Hafta 13 · Alıştırma 13.5 (★★, Çıktı tahmini)
 * Görev  : Program ne yazdırır? k = 3 ile kaydırma; harf olmayanlar
 *          (boşluk) değişmez. 'X' + 3 kaydırmada alfabe başa sarar mı?
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_A05_cikti_tahmini_sezar.c -o a05
 */
#include <stdio.h>

int main(void)
{
    char s[] = "AX BY";
    int k = 3;
    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] >= 'A' && s[i] <= 'Z') {
            s[i] = (char)('A' + (s[i] - 'A' + k) % 26);
        }
    }
    printf("%s\n", s);               /* ? */
    return 0;
}

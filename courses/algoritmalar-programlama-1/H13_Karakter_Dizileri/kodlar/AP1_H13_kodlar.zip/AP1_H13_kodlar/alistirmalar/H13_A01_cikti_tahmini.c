/* H13_A01_cikti_tahmini.c — Hafta 13 · Alıştırma 13.1 (★, Çıktı tahmini)
 * Görev  : Program ne yazdırır? Önce kâğıtta tahmin edin, sonra çalıştırın.
 *          İpucu: sizeof dizinin bayt boyutu ('\0' dahil), strlen '\0'a
 *          kadar karakter sayısıdır; döngü '\0' bulunca durur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_A01_cikti_tahmini.c -o a01
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[10] = "AP-1";
    int sayac = 0;
    for (int i = 0; s[i] != '\0'; i++) {
        sayac++;
    }
    printf("%zu %zu %d\n", sizeof s, strlen(s), sayac);
    return 0;
}

/* H13_A06_hata_bul_girdi.c — Hafta 13 · Alıştırma 13.6 (★★, Hata bul)
 * BU DOSYA KASITLI HATA İÇERİR: fgets ile okunan şehir adı, sondaki '\n'
 *          temizlenmediği için "İzmir" ile hiç eşleşmez. Hatayı bulun ve
 *          '\n'i silerek düzeltin (strcspn).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_A06_hata_bul_girdi.c -o a06
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char sehir[32];
    printf("Şehir: ");
    if (fgets(sehir, sizeof sehir, stdin) == NULL) {
        return 1;
    }
    /* HATA: '\n' silinmedi */
    if (strcmp(sehir, "İzmir") == 0) {
        printf("Ege Bölgesi\n");
    } else {
        printf("Eşleşme yok: [%s]\n", sehir);
    }
    return 0;
}

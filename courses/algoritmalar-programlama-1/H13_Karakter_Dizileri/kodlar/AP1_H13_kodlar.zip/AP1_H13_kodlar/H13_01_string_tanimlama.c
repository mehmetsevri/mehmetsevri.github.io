/* H13_01_string_tanimlama.c — Hafta 13 · Örnek 1 (★): String tanımlama
 * Amaç   : Bir string'in '\0' ile biten bir char DİZİSİ olduğunu görmek.
 *          Aynı sözcük üç biçimde: "%s" ile bütün, karakter karakter
 *          (indisle) ve '\0' bulunca duran bir döngüyle. sizeof (dizinin
 *          bayt boyutu) ile strlen (sondaki '\0' hariç karakter sayısı)
 *          arasındaki fark gösterilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_01_string_tanimlama.c -o string_tanimlama
 * Örnek  : -> sizeof dizi = 6 bayt, strlen = 5 karakter
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char ad[] = "Merhaba";      /* 7 harf + '\0' = 8 bayt, değiştirilebilir */
    char kisa[6] = "AP-1";          /* 4 harf + '\0' + 1 kullanılmayan bayt */

    printf("%%s ile       : %s\n", ad);

    printf("karakter karakter: ");
    for (int i = 0; ad[i] != '\0'; i++) {   /* '\0' bulunca dur */
        printf("[%c]", ad[i]);
    }
    printf("\n");

    printf("baytlar (onaltılık): ");
    for (size_t i = 0; i < sizeof ad; i++) {
        printf("%02X ", (unsigned char)ad[i]);   /* son bayt 00 = '\0' */
    }
    printf("\n");

    printf("sizeof ad   = %zu bayt\n", sizeof ad);     /* 8: '\0' dahil */
    printf("strlen(ad)  = %zu karakter\n", strlen(ad));/* 7: '\0' hariç */
    printf("sizeof kisa = %zu bayt, strlen = %zu\n", sizeof kisa, strlen(kisa));
    return 0;
}

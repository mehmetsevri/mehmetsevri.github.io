/* H13_09_sezar.c — Hafta 13 · Örnek 9 (★★): Sezar şifreleme/çözme
 * Amaç   : Modüler aritmetikle klasik Sezar şifresi. Her İngiliz alfabesi
 *          harfi (A-Z, a-z) anahtar kadar kaydırılır; harf olmayanlar
 *          (boşluk, rakam, noktalama) OLDUĞU GİBİ kalır. Çözme, (26 - k)
 *          ile şifrelemektir. Kaba kuvvet: 26 anahtarın HEPSİ denenir
 *          (anahtar uzayı yalnızca 26: şifre zayıftır).
 * Neden İngiliz alfabesi? Kaydırma, harfin alfabedeki SIRASINA dayanır
 *          (c - 'A'); bu yalnızca A-Z gibi ardışık ve tek baytlık kodlarda
 *          işler. Türkçe harfler UTF-8'de çok baytlıdır ve alfabetik olarak
 *          ardışık değildir (Örnek 12): bu yüzden yalnızca ASCII harfler
 *          kaydırılır, Türkçe harfler olduğu gibi kalır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_09_sezar.c -o sezar
 * Örnek  : -> k=3: "VENI VIDI VICI" -> "YHQL YLGL YLFL"
 */
#include <stdio.h>
#include <ctype.h>
#include <string.h>

/* s'yi yerinde k kadar kaydırır (k, 0..25'e indirgenir); yalnızca ASCII harf */
void sezar(char *s, int k)
{
    k = ((k % 26) + 26) % 26;        /* negatif anahtar da çalışsın */
    for (size_t i = 0; s[i] != '\0'; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c >= 'A' && c <= 'Z') {
            s[i] = (char)('A' + (c - 'A' + k) % 26);
        } else if (c >= 'a' && c <= 'z') {
            s[i] = (char)('a' + (c - 'a' + k) % 26);
        }                            /* harf değilse dokunma */
    }
}

int main(void)
{
    char metin[] = "VENI VIDI VICI";
    char sifre[sizeof metin];

    strcpy(sifre, metin);
    sezar(sifre, 3);                 /* şifrele: k = 3 */
    printf("Açık metin : %s\n", metin);
    printf("k = 3 şifre : %s\n", sifre);

    sezar(sifre, -3);                /* çöz: (26 - 3) ile aynı */
    printf("Çözülmüş   : %s\n\n", sifre);

    strcpy(sifre, metin);
    sezar(sifre, 3);
    printf("Kaba kuvvet (26 anahtar) — hangisi anlamlı?\n");
    for (int k = 0; k < 26; k++) {
        char deneme[sizeof metin];
        strcpy(deneme, sifre);
        sezar(deneme, -k);           /* k ile şifrelenmişi geri çevir */
        printf("  k=%2d: %s\n", k, deneme);
    }
    return 0;
}

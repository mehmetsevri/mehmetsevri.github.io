/* H13_16_tampon_tasmasi.c — Hafta 13 · Örnek 16 (★★★): Tampon taşması
 * BU DOSYA KASITLI HATA İÇERİR: selamla() gelen ismi yalnızca 8 baytlık bir
 *          yığın tamponuna strcpy ile kopyalar; isim 7 karakterden uzunsa
 *          tampon TAŞAR ve yığın çerçevesindeki komşu veriler bozulur
 *          (CWE-121: Stack-based Buffer Overflow; SEI CERT STR31-C). Bu,
 *          Morris solucanının (1988) fingerd'de yararlandığı hatanın aynı
 *          sınıfıdır. Güvenli sürüm: H13_16b_guvenli_surum.c.
 * Mekanizma (yalnızca KAVRAMSAL; saldırı tarifi değil): yığın çerçevesinde
 *          tamponun ÖTESİNDE kaydedilmiş değerler ve dönüş adresi vardır;
 *          taşan baytlar bunları ezer. Modern derleyiciler bir "kanarya"
 *          (-fstack-protector) yerleştirir: dönüş anında kanarya bozulmuşsa
 *          program "stack smashing detected" ile durdurulur. Bu derleyicide
 *          gerçekte ne olduğu çalıştırma çıktısında görülür.
 * Girdi yürütme zamanında geldiği için derleyici taşmayı önceden göremez:
 *          dosya -Wall -Wextra -pedantic ile uyarısız derlenir ama GÜVENLİ
 *          DEĞİLDİR.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_16_tampon_tasmasi.c -o tampon_tasmasi
 *          # yakalamak için:
 *          gcc -std=c17 -g -fsanitize=address \
 *              H13_16_tampon_tasmasi.c -o tampon_tasmasi_asan
 * Örnek  : kısa girdi "Ali" -> Merhaba, Ali! ; uzun girdi taşırır
 */
#include <stdio.h>
#include <string.h>

void selamla(const char *isim)
{
    char tampon[8];                  /* yalnızca 8 bayt: 7 karakter + '\0' */
    strcpy(tampon, isim);            /* HATA: sınır denetimi yok, TAŞABİLİR */
    printf("Merhaba, %s!\n", tampon);
}

int main(void)
{
    char girdi[64];
    printf("Adınız: ");
    if (fgets(girdi, sizeof girdi, stdin) == NULL) {
        return 1;
    }
    girdi[strcspn(girdi, "\n")] = '\0';
    selamla(girdi);            /* girdi 8 bayttan uzunsa selamla() taşar */
    printf("Program normal bitti.\n");
    return 0;
}

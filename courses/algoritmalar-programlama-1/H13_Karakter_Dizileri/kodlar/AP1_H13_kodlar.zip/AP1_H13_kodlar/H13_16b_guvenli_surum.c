/* H13_16b_guvenli_surum.c — Hafta 13 · Örnek 16 (★★★): Güvenli sürüm
 * Amaç   : H13_16_tampon_tasmasi.c'nin güvenli karşılığı. İki değişiklik
 *          taşmayı olanaksız kılar:
 *          (1) Girdi, tamponun kendi boyutuyla sınırlı okunur: fgets
 *              (tampon, sizeof tampon, stdin) en çok boyut-1 bayt alır,
 *              fazlasını okumaz, sona her zaman '\0' koyar. Taşmaz; uzun
 *              girdi KESİLİR (veri kaybı, ama bellek güvenli).
 *          (2) Kopyalama gerektiğinde boyut sınırlı snprintf kullanılır:
 *              dönüş değeri "tam sığsaydı kaç bayt gerekirdi"yi verir;
 *              boyuta eşit ya da büyükse KESİLME olmuştur (saptanabilir).
 * Kural  : Hedef tamponun boyutu daima bilinmeli ve her yazma bu boyutla
 *          sınırlanmalı (STR31-C). gets hiçbir zaman kullanılmaz (C11'de
 *          standarttan çıkarıldı).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_16b_guvenli_surum.c -o guvenli_surum
 * Örnek  : uzun girdi -> güvenle KESİLİR, taşma yok
 */
#include <stdio.h>
#include <string.h>

#define AD_BOYUT 8

void selamla(const char *isim)
{
    char tampon[32];
    /* snprintf en çok sizeof tampon - 1 bayt yazar ve '\0' koyar: taşmaz */
    int gerekli = snprintf(tampon, sizeof tampon, "Merhaba, %s!", isim);
    if (gerekli >= (int)sizeof tampon) {
        printf("(uyarı: mesaj %d bayta sığmadı, kesildi)\n", gerekli);
    }
    printf("%s\n", tampon);
}

int main(void)
{
    char girdi[AD_BOYUT];
    printf("Adınız (en çok %d karakter): ", AD_BOYUT - 1);
    if (fgets(girdi, sizeof girdi, stdin) == NULL) {   /* boyutla sınırlı */
        return 1;
    }
    size_t n = strcspn(girdi, "\n");
    if (girdi[n] == '\n') {
        girdi[n] = '\0';                       /* sondaki '\n'i sil */
    } else {
        /* '\n' yok: ad TAM 7 karakter olabilir ('\n' akışta kaldı)
           ya da daha uzundur. Bir sonraki karakter ayırt eder. */
        int c = getchar();
        if (c != '\n' && c != EOF) {
            while ((c = getchar()) != '\n' && c != EOF) {
                /* kalan baytları at: taşma değil, kesme */
            }
            printf("(not: ad %d bayta sığmadı, kesildi)\n", AD_BOYUT - 1);
        }
    }
    selamla(girdi);
    printf("Program normal bitti.\n");
    return 0;
}

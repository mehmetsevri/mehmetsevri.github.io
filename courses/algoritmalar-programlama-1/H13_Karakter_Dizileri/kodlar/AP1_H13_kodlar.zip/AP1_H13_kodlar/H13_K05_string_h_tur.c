/* H13_K05_string_h_tur.c — Hafta 13 · Kavram programı: string.h turu
 * Amaç   : En çok kullanılan string.h fonksiyonlarını bir arada göstermek:
 *          strlen, strcpy, strcat, strcmp, strchr, strstr. Her çağrının
 *          sonucu yazdırılır. Boyut sınırlı sürümler (strncpy/strncat) ve
 *          tuzakları ayrı dosyalardadır (H13_K06).
 * Not    : strcmp dönüşünün yalnızca İŞARETİ anlamlıdır. strchr bulunan
 *          karakterin İŞARETÇİSİNİ, strstr alt string'in başladığı yerin
 *          işaretçisini döndürür; bulamazsa NULL. Hedef tamponlar yeterince
 *          büyük olmalıdır (STR31-C).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K05_string_h_tur.c -o string_h_tur
 * Örnek  : -> strstr: "dünya" bulundu, konum 9
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char hedef[64] = "Merhaba";
    printf("strlen(\"%s\") = %zu\n", hedef, strlen(hedef));

    strcat(hedef, ", dünya");         /* hedef yeterince büyük: 64 bayt */
    printf("strcat -> \"%s\"\n", hedef);

    char kopya[64];
    strcpy(kopya, hedef);
    printf("strcmp(kopya, hedef) işareti: %d (0 = eşit)\n",
           strcmp(kopya, hedef));
    printf("strcmp(\"Ali\",\"Veli\") işareti: %s\n",
           strcmp("Ali", "Veli") < 0 ? "negatif (Ali önce)" : "pozitif");

    char *v = strchr(hedef, 'd');     /* ilk 'd'nin adresi */
    if (v != NULL) {
        printf("strchr('d'): konum %td, kalan \"%s\"\n", v - hedef, v);
    }
    char *s = strstr(hedef, "dünya"); /* alt string'in başı */
    if (s != NULL) {
        printf("strstr(\"dünya\"): konum %td\n", s - hedef);
    }
    return 0;
}

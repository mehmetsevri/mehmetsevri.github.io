/* H13_07_palindrom.c — Hafta 13 · Örnek 7 (★★): Palindrom denetimi
 * Amaç   : Bir metnin, boşluk ve harf büyüklüğü yok sayıldığında tersiyle
 *          aynı olup olmadığını denetlemek (H6'daki sayısal palindromun
 *          metin karşılığı). İki uç tekniği kullanılır ama karşılaştırmadan
 *          önce ÖN İŞLEME yapılır: harf olmayanlar atlanır, harfler küçük
 *          harfe çevrilir.
 * Not    : ASCII harfler için çalışır (ctype, unsigned char ile). Türkçe
 *          harfler çok baytlı olduğundan bu basit sürüm onları "harf
 *          değil" sayıp atlar (sınırı Örnek 12'de tartışırız).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_07_palindrom.c -o palindrom
 * Örnek  : girdi "Ey Edip Adana da pide ye" -> palindromdur
 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

bool palindrom_mu(const char *s)
{
    size_t i = 0;
    size_t j = strlen(s);
    while (i < j) {
        while (i < j && !isalpha((unsigned char)s[i])) {
            i++;                     /* soldaki harf olmayanı atla */
        }
        while (i < j && !isalpha((unsigned char)s[j - 1])) {
            j--;                     /* sağdaki harf olmayanı atla */
        }
        if (i < j) {
            int sol = tolower((unsigned char)s[i]);
            int sag = tolower((unsigned char)s[j - 1]);
            if (sol != sag) {
                return false;
            }
            i++;
            j--;
        }
    }
    return true;
}

int main(void)
{
    char satir[128];
    printf("Bir metin girin: ");
    if (fgets(satir, sizeof satir, stdin) == NULL) {
        return 1;
    }
    satir[strcspn(satir, "\n")] = '\0';
    printf("\"%s\" %s\n", satir,
           palindrom_mu(satir) ? "palindromdur." : "palindrom değildir.");
    return 0;
}

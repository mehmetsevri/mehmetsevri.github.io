/* H13_HA4_fgets_newline.c — Hafta 13 · Hata Avcısı 4: fgets'in bıraktığı '\n'
 * BU DOSYA KASITLI HATA İÇERİR: fgets, satır sonundaki '\n'i de tampona
 *          koyar. Okunan "evet\n" iken strcmp(cevap, "evet") 0 DÖNMEZ
 *          ("evet\n" ile "evet" farklıdır): koşul hiç tutmaz. Çözüm,
 *          karşılaştırmadan ÖNCE '\n'i silmektir (strcspn ile).
 * Not    : Dosya derlenir ve çalışır ama "evet" girilse bile "hayır dalı"
 *          çalışır (mantık hatası).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA4_fgets_newline.c -o ha4
 * Örnek  : girdi "evet" -> (yanlış) Onaylanmadı
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char cevap[16];
    printf("Onaylıyor musunuz? (evet/hayır): ");
    if (fgets(cevap, sizeof cevap, stdin) == NULL) {
        return 1;
    }
    /* HATA: cevap "evet\n", "evet" ile asla eşleşmez */
    if (strcmp(cevap, "evet") == 0) {
        printf("Onaylandı\n");
    } else {
        printf("(yanlış) Onaylanmadı\n");
    }
    return 0;
}

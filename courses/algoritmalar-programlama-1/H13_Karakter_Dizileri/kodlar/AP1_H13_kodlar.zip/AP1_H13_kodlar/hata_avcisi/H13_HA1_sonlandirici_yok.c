/* H13_HA1_sonlandirici_yok.c — Hafta 13 · Hata Avcısı 1: '\0' için yer yok
 * BU DOSYA KASITLI HATA İÇERİR: char kod[5] = "HELLO"; dizisi tam 5 bayttır
 *          ve beş harf onu doldurur: sonlandırıcı '\0' için YER KALMAZ.
 *          Dizi '\0' ile bitmediğinden strlen/printf("%s") dizinin SONUNU
 *          bulamaz ve komşu belleği okumayı sürdürür (sınır dışı okuma;
 *          SEI CERT STR31-C). "boyut + 1" kuralı: n karakterlik bir string
 *          en az n + 1 bayt ister.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA1_sonlandirici_yok.c -o ha1          (uyarı YOK)
 *          gcc -std=c17 -g -fsanitize=address \
 *              H13_HA1_sonlandirici_yok.c -o ha1_asan     (yakalar)
 * Örnek  : ASan "stack-buffer-overflow" (READ) raporu verir
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char kod[5] = "HELLO";           /* 5 harf, '\0' için yer YOK */
    printf("Kod: %s\n", kod);         /* HATA: '\0' yok, sınır dışı okuma */
    printf("Uzunluk: %zu\n", strlen(kod));
    return 0;
}

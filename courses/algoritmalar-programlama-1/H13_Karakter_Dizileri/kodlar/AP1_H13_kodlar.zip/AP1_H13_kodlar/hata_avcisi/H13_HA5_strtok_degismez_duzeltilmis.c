/* H13_HA5_strtok_degismez_duzeltilmis.c — Hafta 13 · Hata Avcısı 5 (düz.)
 * Düzeltme: strtok'un değiştireceği metin, DEĞİŞTİRİLEBİLİR bir diziye
 *          kopyalanır (char csv[] = "..."). Böylece strtok ayraç yerlerine
 *          '\0' yazdığında salt okunur bir değişmeze değil, bizim dizimize
 *          yazar. Özgün değişmez bozulmaz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA5_strtok_degismez_duzeltilmis.c -o ha5d
 * Örnek  : -> parça: ali / veli / can
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char csv[] = "ali,veli,can";      /* değiştirilebilir dizi (kopya) */
    char *parca = strtok(csv, ",");
    while (parca != NULL) {
        printf("parça: %s\n", parca);
        parca = strtok(NULL, ",");
    }
    return 0;
}

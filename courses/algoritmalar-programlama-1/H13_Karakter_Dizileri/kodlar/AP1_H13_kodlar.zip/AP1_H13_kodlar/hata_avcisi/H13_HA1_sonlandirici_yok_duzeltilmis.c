/* H13_HA1_sonlandirici_yok_duzeltilmis.c — Hafta 13 · Hata Avcısı 1 (düz.)
 * Düzeltme: Diziye '\0' için de yer bırakılır. En güvenli yol, boyutu
 *          derleyiciye saydırmaktır: char kod[] = "HELLO"; string
 *          değişmezinin uzunluğu + 1 bayt (burada 6) ayrılır ve son bayt
 *          '\0' olur. Boyut elle yazılacaksa en az karakter sayısı + 1
 *          olmalıdır (char kod[6]).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA1_sonlandirici_yok_duzeltilmis.c -o ha1d
 * Örnek  : -> Kod: HELLO ; Uzunluk: 5
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char kod[] = "HELLO";            /* derleyici 6 bayt ayırır: '\0' dahil */
    printf("Kod: %s\n", kod);
    printf("Uzunluk: %zu\n", strlen(kod));
    return 0;
}

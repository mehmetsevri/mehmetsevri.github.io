/* H13_HA4_fgets_newline_duzeltilmis.c — Hafta 13 · Hata Avcısı 4 (düzeltilmiş)
 * Düzeltme: fgets'ten sonra sondaki '\n' silinir: cevap[strcspn(cevap,
 *          "\n")] = '\0'; strcspn, ilk '\n''e kadar olan karakter sayısını
 *          verir; o konuma '\0' yazmak '\n'i siler (yoksa zararsızdır).
 *          Artık strcmp(cevap, "evet") doğru çalışır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA4_fgets_newline_duzeltilmis.c -o ha4d
 * Örnek  : girdi "evet" -> Onaylandı
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char cevap[16];
    printf("Onaylıyor musunuz? (evet/hayır): ");
    if (fgets(cevap, sizeof cevap, stdin) == NULL) {
        return 1;
    }
    cevap[strcspn(cevap, "\n")] = '\0';   /* DÜZELTME: sondaki '\n'i sil */
    if (strcmp(cevap, "evet") == 0) {
        printf("Onaylandı\n");
    } else {
        printf("Onaylanmadı\n");
    }
    return 0;
}

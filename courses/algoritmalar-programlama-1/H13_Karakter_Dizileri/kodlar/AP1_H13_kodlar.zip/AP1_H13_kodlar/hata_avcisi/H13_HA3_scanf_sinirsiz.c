/* H13_HA3_scanf_sinirsiz.c — Hafta 13 · Hata Avcısı 3: scanf("%s") sınırsız
 * BU DOSYA KASITLI HATA İÇERİR: scanf("%s", ad); alan genişliği VERMEDEN
 *          okur: girilen sözcük tampondan uzunsa tampon TAŞAR (CWE-120,
 *          STR31-C). Morris solucanının (1988) sömürdüğü sınıf: sınır
 *          denetimsiz girdi. 8 baytlık tampona uzun bir ad girilirse yığın
 *          bozulur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA3_scanf_sinirsiz.c -o ha3            (uyarı YOK)
 *          gcc -std=c17 -g -fsanitize=address \
 *              H13_HA3_scanf_sinirsiz.c -o ha3_asan       (yakalar)
 * Örnek  : uzun girdi -> stack-buffer-overflow (ASan) / stack smashing
 */
#include <stdio.h>

int main(void)
{
    char ad[8];
    printf("Ad: ");
    if (scanf("%s", ad) != 1) {       /* HATA: genişlik yok -> sınırsız okuma */
        return 1;
    }
    printf("Merhaba, %s!\n", ad);
    return 0;
}

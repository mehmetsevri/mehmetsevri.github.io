/* H13_HA5_strtok_degismez.c — Hafta 13 · Hata Avcısı 5: strtok diziyi bozar
 * BU DOSYA KASITLI HATA İÇERİR: strtok, bulduğu her ayracın yerine '\0'
 *          yazarak ÖZGÜN diziyi DEĞİŞTİRİR. Burada parçalanan değer bir
 *          string DEĞİŞMEZİNİ gösteren işaretçidir (char *csv = "a,b,c");
 *          değişmezler çoğu sistemde salt okunur bölgededir, oraya yazmak
 *          TANIMSIZ DAVRANIŞTIR ve genellikle çökmeye (SIGSEGV) yol açar.
 * Not    : Ayrıca strtok özgün diziyi tükettiği için, parçalardan SONRA
 *          csv artık "a,b,c" değildir. Çözüm: değiştirilebilir bir diziye
 *          kopyalayıp onu parçalamaktır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA5_strtok_degismez.c -o ha5           (uyarı YOK)
 * Örnek  : çalıştırmada Segmentation fault (değişmeze yazma)
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char *csv = "ali,veli,can";       /* string DEĞİŞMEZİ: salt okunur */
    char *parca = strtok(csv, ",");    /* HATA: strtok değişmeze '\0' yazar */
    while (parca != NULL) {
        printf("parça: %s\n", parca);
        parca = strtok(NULL, ",");
    }
    return 0;
}

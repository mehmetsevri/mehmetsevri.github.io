/* H13_HA2_esitlik_karsilastirma.c — Hafta 13 · Hata Avcısı 2: == ile string
 * BU DOSYA KASITLI HATA İÇERİR: iki string'in İÇERİĞİNİ == ile karşılaştırır.
 *          girdi == dogru, iki ADRESİ karşılaştırır (H12): girdi dizisi ile
 *          dogru'nun gösterdiği değişmez ayrı yerlerdedir; içerikleri aynı
 *          olsa bile sonuç HER ZAMAN "farklı" çıkar. İçerik karşılaştırması
 *          strcmp iledir (strcmp(girdi, dogru) == 0).
 * Not    : Dosya derlenir ve çalışır ama YANLIŞ yanıt verir (mantık hatası).
 *          Ayrıca bir diziye "=" ile string atanamaz (girdi = "yeni";
 *          derlenmez): kopyalamak strcpy iledir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA2_esitlik_karsilastirma.c -o ha2
 * Örnek  : -> (yanlış) Parola hatalı  (oysa içerik aynı)
 */
#include <stdio.h>

int main(void)
{
    char girdi[] = "parola";
    const char *dogru = "parola";    /* içerik aynı, adres farklı */

    if (girdi == dogru) {            /* HATA: adresleri karşılaştırır */
        printf("Giriş başarılı\n");
    } else {
        printf("(yanlış) Parola hatalı  (oysa içerik aynı)\n");
    }
    return 0;
}

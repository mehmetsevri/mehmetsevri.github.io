/* H13_HA6_degismez_yazma.c — Hafta 13 · Hata Avcısı 6: string değişmezini yazma
 * BU DOSYA KASITLI HATA İÇERİR: char *s = "abc"; s, bir string DEĞİŞMEZİNİ
 *          gösterir. s[0] = 'X'; değişmezin ilk baytına yazmaya çalışır:
 *          TANIMSIZ DAVRANIŞ. Değişmezler çoğu derleyicide salt okunur
 *          (.rodata) bölgesindedir; oraya yazma bu sistemde SIGSEGV ile
 *          sonlanır (H12'deki koruma ihlali). "Her zaman çöker" denmez,
 *          gözlenen davranış çalıştırmada görülür.
 * Not    : -Wwrite-strings ile string değişmezi const char * sayılır ve
 *          bu atama DERLEME zamanında da uyarılır (değişmezlerin salt
 *          okunurluğunun imlenmesi).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA6_degismez_yazma.c -o ha6            (uyarı YOK)
 * Örnek  : çalıştırmada Segmentation fault
 */
#include <stdio.h>

int main(void)
{
    char *s = "abc";                 /* değişmezi gösterir (salt okunur) */
    printf("önce: %s\n", s);
    s[0] = 'X';                      /* HATA: değişmeze yazma (tanımsız) */
    printf("sonra: %s\n", s);
    return 0;
}

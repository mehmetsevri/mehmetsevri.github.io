/* H13_HA3_scanf_sinirsiz_duzeltilmis.c — Hafta 13 · Hata Avcısı 3 (düzeltilmiş)
 * Düzeltme: İki seçenek. (a) scanf'e alan genişliği ver: "%7s" en çok 7 bayt
 *          okur ('\0' için bir bayt bırakır; 8 baytlık tampon güvenli).
 *          (b) Satırın tamamı gerekiyorsa fgets yeğlenir (Örnek 2). Burada
 *          (a) gösterilmiştir; genişlik, tampon boyutundan bir eksiktir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA3_scanf_sinirsiz_duzeltilmis.c -o ha3d
 * Örnek  : uzun girdi güvenle KESİLİR (taşma yok)
 */
#include <stdio.h>

int main(void)
{
    char ad[8];
    printf("Ad: ");
    if (scanf("%7s", ad) != 1) {      /* en çok 7 bayt + '\0': taşmaz */
        return 1;
    }
    printf("Merhaba, %s!\n", ad);
    return 0;
}

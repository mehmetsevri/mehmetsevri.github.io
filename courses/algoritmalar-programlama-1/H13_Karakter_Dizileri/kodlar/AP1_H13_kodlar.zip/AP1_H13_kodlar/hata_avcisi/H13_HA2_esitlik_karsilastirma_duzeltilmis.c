/* H13_HA2_esitlik_karsilastirma_duzeltilmis.c — Hafta 13 · Hata Avcısı 2 (düz.)
 * Düzeltme: İçerik karşılaştırması strcmp iledir; strcmp 0 döndürürse
 *          iki metin BAYT BAYT aynıdır. == yalnızca adresleri karşılaştırır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA2_esitlik_karsilastirma_duzeltilmis.c -o ha2d
 * Örnek  : -> Giriş başarılı
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char girdi[] = "parola";
    const char *dogru = "parola";

    if (strcmp(girdi, dogru) == 0) {   /* İÇERİK karşılaştırması */
        printf("Giriş başarılı\n");
    } else {
        printf("Parola hatalı\n");
    }
    return 0;
}

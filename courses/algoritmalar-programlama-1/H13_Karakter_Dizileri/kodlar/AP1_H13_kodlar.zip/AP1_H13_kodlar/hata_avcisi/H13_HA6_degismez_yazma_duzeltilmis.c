/* H13_HA6_degismez_yazma_duzeltilmis.c — Hafta 13 · Hata Avcısı 6 (düzeltilmiş)
 * Düzeltme: Değiştirilecek metin bir DİZİYE konur: char s[] = "abc";
 *          string değişmezi diziye KOPYALANIR (4 bayt) ve dizinin baytları
 *          serbestçe değiştirilebilir. s[0] = 'X'; artık güvenlidir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_HA6_degismez_yazma_duzeltilmis.c -o ha6d
 * Örnek  : -> sonra: Xbc
 */
#include <stdio.h>

int main(void)
{
    char s[] = "abc";                /* diziye kopya: değiştirilebilir */
    printf("önce: %s\n", s);
    s[0] = 'X';                      /* GÜVENLİ: dizinin kendi baytı */
    printf("sonra: %s\n", s);
    return 0;
}

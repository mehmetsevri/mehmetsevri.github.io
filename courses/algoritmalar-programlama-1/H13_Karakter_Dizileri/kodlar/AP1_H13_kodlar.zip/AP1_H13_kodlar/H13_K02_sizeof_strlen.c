/* H13_K02_sizeof_strlen.c — Hafta 13 · Kavram programı: sizeof ile strlen
 * Amaç   : İki ölçünün farkı. sizeof derleme zamanında TİPİN bayt boyutudur
 *          (dizide tüm dizi, '\0' dahil ve kullanılmayan baytlar da; işaretçi
 *          değişkeninde yalnızca 8 bayt). strlen çalışma zamanında '\0'a
 *          kadar KARAKTER (bayt) sayar, '\0' hariç. Bir dizi fonksiyona
 *          verilince işaretçiye dönüşür; o yüzden fonksiyon içinde sizeof
 *          yine 8 verir ("sizeof tuzağı", H12) — bu yüzden dizi boyutu ayrı
 *          bir parametreyle taşınır.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K02_sizeof_strlen.c -o sizeof_strlen
 * Örnek  : -> dizi: sizeof 12, strlen 7
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char dizi[12] = "merhaba";       /* 12 baytlık dizi; "merhaba" 7 karakter */
    const char *p = "merhaba";       /* işaretçi: string değişmezini gösterir */

    printf("dizi: sizeof %zu bayt, strlen %zu karakter\n",
           sizeof dizi, strlen(dizi));
    printf("p   : sizeof %zu bayt (yalnızca işaretçi), strlen %zu\n",
           sizeof p, strlen(p));
    printf("fark: sizeof TİPİN boyutu, strlen '\\0'a kadar karakter sayar\n");
    return 0;
}

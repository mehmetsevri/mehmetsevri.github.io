/* obs.h — Mini-OBS v0.13 (AP-1 Hafta 13): modülün ARAYÜZÜ
 * Yenilik : Ad ve soyad alanları. Her öğrencinin adı ve soyadı öbekteki
 *           iki yeni blokta, sabit uzunluklu SATIRLAR olarak tutulur:
 *               char (*ad)[AD_BOYUT] = malloc(kapasite * sizeof *ad);
 *           ad[i] i. öğrencinin '\0' ile biten karakter dizisidir.
 *           Adlar kaydedilmeden önce NORMALLEŞTİRİLİR: baştaki/sondaki
 *           boşluklar atılır, aradaki boşluk dizileri teke indirilir,
 *           harfler Türkçe kurala göre BÜYÜK harfe çevrilir (i → İ,
 *           ı → I, ç → Ç, ğ → Ğ, ö → Ö, ş → Ş, ü → Ü). Metinler UTF-8'dir:
 *           Türkçe harfler 2 bayt yer kaplar (bayt ≠ karakter).
 *           İsimle arama: strcmp ile doğrusal tarama (isim_bul).
 *           Güvenli girdi: bütün girdiler satır satır fgets ile okunur
 *           (satir_oku), sayılar strtoll/strtod ile denetlenerek çözülür;
 *           scanf ile fgets karışık kullanılmaz.
 * Not     : 2B dizi parametrelerinde const KULLANILMADI: C17'de
 *           char (*)[32] → const char (*)[32] dönüşümü uyumsuz sayılır
 *           (-pedantic uyarı verir; C23'te düzeltildi). Salt okunurluk
 *           yorumla belgelendi.
 *           Paralel bloklar artık altı tane (no, ad, soyad, vize, final,
 *           ort): bunları tek bir kayıtta toplamak H14'ün (struct) işidir.
 */
#ifndef OBS_H
#define OBS_H

#include <stdbool.h>
#include <stddef.h>   /* size_t */

#define DERS_SAYISI 3       /* sütun sayısı: satır tipinin parçası */
#define HARF_SAYISI 9       /* AA, BA, BB, CB, CC, DC, DD, FD, FF */
#define AD_BOYUT 32         /* ad için en çok 31 bayt + '\0' */
#define SOYAD_BOYUT 32      /* soyad için en çok 31 bayt + '\0' */
#define SATIR_BOYUT 128     /* bir girdi satırı için tampon (+ '\n' + '\0') */

/* ---- güvenli girdi (H13) ---- */
int satir_oku(char *tampon, size_t boyut);         /* 1 tamam, 0 çok uzun, -1 EOF */
bool tamsayi_coz(const char *metin, long long *sonuc);
bool ondalik_coz(const char *metin, double *sonuc);

/* ---- metin işleme (H13) ---- */
int ad_normallestir(const char *kaynak, char *hedef, size_t boyut);
bool ad_gecerli_mi(const char *ad);
size_t utf8_karakter_sayisi(const char *s);
void hizali_yaz(const char *s, int genislik);

/* ---- ekran ve girdi ---- */
void baslik_yaz(void);
void menu_goster(void);
int menu_secimi_oku(void);
int kapasite_oku(void);                            /* >= 1; EOF → -1 */
long long numara_oku(void);
double not_oku(const char *etiket);
int ad_oku(const char *etiket, char *hedef, size_t boyut);   /* 1 / EOF → -1 */

/* ---- hesap kuralları (v0.8'den) ---- */
double hesapla_ortalama(double vize, double final);
int yuvarla(double ortalama);
const char *harf_notu(int yuvarlanmis, double final);
bool gecti_mi(int yuvarlanmis, double final);
bool sartli_mi(int yuvarlanmis, double final);
const char *durum_metni(int yuvarlanmis, double final);
int harf_indeksi(int yuvarlanmis, double final);   /* AA=0 ... FF=8 */
const char *harf_adi(int indeks);
double harf_katsayisi(int indeks);                 /* AA 4,00 ... FF 0,00 */

/* ---- dersler ---- */
const char *ders_adi(int d);
const char *ders_kodu(int d);
int ders_kredisi(int d);                           /* örnek kredi değerleri */

/* ---- 1B dizi desenleri (v0.10'dan; bir SATIR ya da kopyalanmış SÜTUN) ---- */
int numara_bul(const long long no[], int n, long long aranan);
double dizi_ortalama(const double a[], int n);
double standart_sapma(const double a[], int n);
int en_buyuk_indis(const double a[], int n);
int en_kucuk_indis(const double a[], int n);
int esik_ustu_say(const double a[], int n, double esik);
void min_max_indis(const double a[], int n, int *enk, int *enb);

/* ---- 2B dizi işlemleri (H11) ---- */
void sutun_kopyala(double m[][DERS_SAYISI], int n, int d, double hedef[]);
double yano_hesapla(const double ort_satiri[], const double final_satiri[]);
void ders_harf_dagilimi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                        int n, int sayac[DERS_SAYISI][HARF_SAYISI]);
bool ders_istatistigi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n, int d, double *ortalama, double *sapma,
                      int *enb, int *enk, int *basarili, int *sartli);

/* ---- isimle arama (H13) ---- */
int isim_bul(char ad[][AD_BOYUT], char soyad[][SOYAD_BOYUT], int n,
             const char *aranan, int baslangic);

/* ---- dinamik bellek (H12) ---- */
int yeni_kapasite(int kapasite);
void *buyut(void *blok, int kapasite, size_t eleman_boyutu);
void kayitlari_birak(long long no[], char ad[][AD_BOYUT],
                     char soyad[][SOYAD_BOYUT], double vize[][DERS_SAYISI],
                     double final[][DERS_SAYISI], double ort[][DERS_SAYISI]);

/* ---- raporlar ---- */
void ogrenci_ozeti_yaz(long long numara, const char *ad, const char *soyad,
                       const double ort_satiri[], const double final_satiri[]);
void ders_istatistikleri_yaz(double ort[][DERS_SAYISI],
                             double final[][DERS_SAYISI], int n);
void transkript_yaz(long long numara, const char *ad, const char *soyad,
                    const double vize_satiri[], const double final_satiri[],
                    const double ort_satiri[]);
void harf_tablosu_yaz(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n);
void kayitlari_listele(const long long no[], char ad[][AD_BOYUT],
                       char soyad[][SOYAD_BOYUT], double ort[][DERS_SAYISI],
                       double final[][DERS_SAYISI], int n);
void arama_sonucu_yaz(const long long no[], char ad[][AD_BOYUT],
                      char soyad[][SOYAD_BOYUT], double ort[][DERS_SAYISI],
                      double final[][DERS_SAYISI], int n, const char *aranan);

#endif /* OBS_H */

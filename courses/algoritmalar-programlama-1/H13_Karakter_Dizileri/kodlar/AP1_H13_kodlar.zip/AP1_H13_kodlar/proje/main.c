/* main.c — Mini-OBS v0.13 (AP-1 Hafta 13): menü döngüsü + ad–soyad
 * Kayıtlar ÖBEKTE, altı paralel blokta: no (long long), ad ve soyad
 * (her biri AD_BOYUT/SOYAD_BOYUT baytlık SATIRLARI gösteren char işaretçisi;
 * ad[i] '\0' ile biten bir karakter dizisidir), vize, final, ort (DERS_SAYISI
 * double'lık satırlar). Kapasite dolunca altı blok da buyut (realloc) ile
 * ikiye katlanır. Altı bloğu aynı sırada tutmak zahmetlidir: H14'te hepsi
 * tek bir struct Ogrenci kaydında toplanacak.
 * Bütün girdiler satır satır (fgets) okunur; scanf kullanılmaz.
 * Bütün çıkışlar TEK temizlik yolundan geçer: kayitlari_birak.
 * Derleme : make            (ya da elle:)
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c
 *           gcc -std=c17 -Wall -Wextra -pedantic -g -c main.c
 *           gcc obs.o main.o -o mini_obs -lm
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "obs.h"

int main(void)
{
    int n = 0;                                    /* dolu satır sayısı */
    int secim = 0;
    bool girdi_bitti = false;

    baslik_yaz();
    int kapasite = kapasite_oku();
    if (kapasite == -1) {
        printf("\nGirdi sona erdi.\n");
        return 1;                                 /* henüz blok yok */
    }
    long long *no = malloc(kapasite * sizeof *no);
    char (*ad)[AD_BOYUT] = malloc(kapasite * sizeof *ad);
    char (*soyad)[SOYAD_BOYUT] = malloc(kapasite * sizeof *soyad);
    double (*vize)[DERS_SAYISI] = malloc(kapasite * sizeof *vize);
    double (*final)[DERS_SAYISI] = malloc(kapasite * sizeof *final);
    double (*ort)[DERS_SAYISI] = malloc(kapasite * sizeof *ort);
    if (no == NULL || ad == NULL || soyad == NULL || vize == NULL
        || final == NULL || ort == NULL) {
        printf("Bellek yetersiz: %d öğrencilik yer ayrılamadı.\n", kapasite);
        kayitlari_birak(no, ad, soyad, vize, final, ort);   /* free(NULL) güvenli */
        return 1;
    }

    do {
        menu_goster();
        secim = menu_secimi_oku();
        if (secim == -1) {
            girdi_bitti = true;
            break;
        }

        switch (secim) {
        case 1: {
            if (n == kapasite) {              /* dolu: altı blok 2 katına */
                int yeni = yeni_kapasite(kapasite);   /* taşmada -1 */
                bool tamam = (yeni != -1);
                void *g;          /* realloc sonucu ÖNCE geçici işaretçiye */
                g = tamam ? buyut(no, yeni, sizeof *no) : NULL;
                if (g != NULL) { no = g; } else { tamam = false; }
                g = tamam ? buyut(ad, yeni, sizeof *ad) : NULL;
                if (g != NULL) { ad = g; } else { tamam = false; }
                g = tamam ? buyut(soyad, yeni, sizeof *soyad) : NULL;
                if (g != NULL) { soyad = g; } else { tamam = false; }
                g = tamam ? buyut(vize, yeni, sizeof *vize) : NULL;
                if (g != NULL) { vize = g; } else { tamam = false; }
                g = tamam ? buyut(final, yeni, sizeof *final) : NULL;
                if (g != NULL) { final = g; } else { tamam = false; }
                g = tamam ? buyut(ort, yeni, sizeof *ort) : NULL;
                if (g != NULL) { ort = g; } else { tamam = false; }
                if (!tamam) {
                    printf("  Bellek yetersiz: kapasite artırılamadı (%d"
                           " öğrenci korunuyor).\n", n);
                    break;
                }
                kapasite = yeni;
            }
            printf("\n------------ ÖĞRENCİ %d ------------\n", n + 1);
            long long numara = numara_oku();
            if (numara == -1) {
                girdi_bitti = true;
                break;
            }
            int bulunan = numara_bul(no, n, numara);
            if (bulunan != -1) {
                printf("  Bu numara zaten kayıtlı (sıra %d).\n", bulunan + 1);
                break;
            }
            if (ad_oku("Ad               : ", ad[n], sizeof ad[n]) == -1
                || ad_oku("Soyad            : ", soyad[n], sizeof soyad[n]) == -1) {
                girdi_bitti = true;
                break;
            }
            for (int d = 0; d < DERS_SAYISI; d++) {      /* satırı doldur */
                printf("-- %s (%d kredi) --\n", ders_adi(d), ders_kredisi(d));
                double v = not_oku("Vize notu        : ");
                if (v < 0) {
                    girdi_bitti = true;
                    break;
                }
                double f = not_oku("Final notu       : ");
                if (f < 0) {
                    girdi_bitti = true;
                    break;
                }
                vize[n][d] = v;
                final[n][d] = f;
                ort[n][d] = hesapla_ortalama(v, f);
            }
            if (girdi_bitti) {
                break;
            }
            no[n] = numara;
            ogrenci_ozeti_yaz(numara, ad[n], soyad[n], ort[n], final[n]);
            n++;
            break;
        }
        case 2:
            ders_istatistikleri_yaz(ort, final, n);
            break;
        case 3: {
            if (n == 0) {
                printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
                break;
            }
            long long numara = numara_oku();
            if (numara == -1) {
                girdi_bitti = true;
                break;
            }
            int i = numara_bul(no, n, numara);
            if (i == -1) {
                printf("  Kayıt bulunamadı: %lld\n", numara);
                break;
            }
            transkript_yaz(no[i], ad[i], soyad[i], vize[i], final[i], ort[i]);
            break;
        }
        case 4:
            harf_tablosu_yaz(ort, final, n);
            break;
        case 5:
            kayitlari_listele(no, ad, soyad, ort, final, n);
            break;
        case 6: {
            if (n == 0) {
                printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
                break;
            }
            char satir[SATIR_BOYUT];
            char aranan[AD_BOYUT + SOYAD_BOYUT];   /* "AD SOYAD" sığar */
            printf("Aranacak ad      : ");
            int durum = satir_oku(satir, sizeof satir);
            if (durum == -1) {
                girdi_bitti = true;
                break;
            }
            if (durum == 0 || ad_normallestir(satir, aranan, sizeof aranan) < 1) {
                printf("  Geçersiz: boş ya da çok uzun bir ad.\n");
                break;
            }
            arama_sonucu_yaz(no, ad, soyad, ort, final, n, aranan);
            break;
        }
        case 7:
            printf("Çıkış: %d öğrenci kaydı işlendi. Hoşça kalın.\n", n);
            break;
        default:
            printf("  Geçersiz seçim: 1-7 arası bir sayı girin.\n");
            break;
        }
    } while (secim != 7 && !girdi_bitti);

    if (girdi_bitti) {
        printf("\nGirdi sona erdi.\n");
    }
    kayitlari_birak(no, ad, soyad, vize, final, ort);   /* TEK temizlik yolu */
    return girdi_bitti ? 1 : 0;
}

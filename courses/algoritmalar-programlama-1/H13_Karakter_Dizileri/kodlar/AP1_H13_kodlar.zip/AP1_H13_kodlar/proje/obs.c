/* obs.c — Mini-OBS v0.13 (AP-1 Hafta 13): modülün GERÇEKLEMESİ
 * Yenilik : Ad ve soyad (öbekte iki yeni blok: char (*ad)[AD_BOYUT]).
 *           Güvenli girdi: bütün girdiler fgets ile SATIR SATIR okunur
 *           (satir_oku); sayılar strtoll/strtod ile çözülür ve satırın
 *           TAMAMI sayı değilse reddedilir (tamsayi_coz, ondalik_coz).
 *           Ad normalleştirme (ad_normallestir): boşluk temizleme ve Türkçe
 *           büyük harf (i → İ, ı → I …); geçerlilik (ad_gecerli_mi).
 *           UTF-8'de bayt ≠ karakter: utf8_karakter_sayisi, hizali_yaz
 *           (printf'in %-24s'i BAYT sayar; Türkçe harfli adlarda sütun kayar).
 *           İsimle arama: isim_bul (strcmp ile doğrusal tarama).
 *           Menü: 1) Ekle 2) Ders ist. 3) Transkript 4) Harf tablosu
 *                 5) Listele 6) İsimle ara 7) Çıkış
 *           Hesap kuralları ve istatistik/harf tablosu biçimleri v0.12 ile
 *           AYNIDIR.
 * Kurallar: RTEÜ Ön Lisans ve Lisans Eğitim-Öğretim ve Sınav Yönetmeliği
 *           (RG 14.12.2025, 33107): Madde 25/2 ve 26/2: %40 ara sınav +
 *           %60 yarıyıl sonu sınavı; yarıyıl sonundan 50 alamayan FF.
 *           Madde 30/3: AA 90-100, BA 81-89, BB 73-80, CB 66-72, CC 60-65
 *           başarılı; DC 50-59 şartlı; DD 40-49, FD 30-39, FF 0-29
 *           başarısız. Katsayılar AA 4,0 · BA 3,5 · BB 3,0 · CB 2,5 ·
 *           CC 2,0 · DC 1,5 · DD 1,0 · FD 0,5 · FF 0,0. Madde 30/4-b: YANO
 *           en az 2,00 ise DC başarılı sayılır. Madde 31/2-a: not ortalaması
 *           = Σ(kredi × katsayı) / Σ kredi (kredi: dersin ulusal kredisi,
 *           Madde 4); YANO virgülden sonra iki haneye yuvarlanır (üçüncü
 *           hane >= 5 ise yukarı). Ders ortalaması: (int)(ort + 0.5). Ders
 *           adları ve kredileri ÖRNEKTİR (ders içi modelleme).
 * Kodlama : Kaynak dosya ve bütün metinler UTF-8'dir.
 * Derleme : gcc -std=c17 -Wall -Wextra -pedantic -g -c obs.c   (bağlarken -lm)
 */
#include <stdio.h>
#include <stdlib.h>   /* malloc, realloc, free, strtoll, strtod */
#include <string.h>   /* strlen, strcmp, strncmp, memcpy */
#include <ctype.h>    /* isspace, isalpha, toupper */
#include <errno.h>    /* errno, ERANGE */
#include <limits.h>   /* INT_MAX */
#include <math.h>     /* sqrt, isfinite */
#include "obs.h"

/* ---- Kurallar: dosya kapsamında static const (yalnızca bu modül) ---- */
static const double VIZE_AGIRLIK = 0.40;
static const double FINAL_AGIRLIK = 0.60;
static const int GECME_ORTALAMA = 60;        /* CC ve üzeri: başarılı */
static const int SARTLI_ORTALAMA = 50;       /* DC: şartlı başarılı */
static const int FINAL_BARAJI = 50;          /* yarıyıl sonu sınavında en az 50 */

static const int SECENEK_SAYISI = 7;        /* menüdeki seçenek sayısı */
static const int AD_SUTUNU = 24;            /* listelerde "Ad Soyad" sütunu (karakter) */

/* Türkçe küçük harfler ve büyük karşılıkları (UTF-8). Sıra önemlidir:
 * ASCII 'i' de tabloda, çünkü Türkçede büyüğü 'I' değil 'İ'dir. */
static const char *const KUCUK_HARF[] = { "ç", "ğ", "ı", "ö", "ş", "ü", "i" };
static const char *const BUYUK_HARF[] = { "Ç", "Ğ", "I", "Ö", "Ş", "Ü", "İ" };
static const int TR_HARF_SAYISI = 7;

/* Girdi tamponunda satırın kalanını (satır sonu dahil) atar.
 * static fonksiyon: yalnızca bu dosyadan çağrılabilir (obs.h'de yok). */
static void satir_temizle(void)
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }
}

/* Ön koşul : tampon en az boyut baytlık bir dizi; boyut >= 2.
 * Son koşul:  1 → bir satır okundu; sondaki '\n' (ve Windows'tan gelen '\r')
 *                 silindi, tampon '\0' ile biter;
 *             0 → satır tampona sığmadı; kalanı atıldı, tampon boş;
 *            -1 → hiçbir şey okunamadan girdi bitti (EOF).
 * fgets en çok boyut - 1 bayt okur ve sona her zaman '\0' koyar: taşmaz. */
int satir_oku(char *tampon, size_t boyut)
{
    if (fgets(tampon, (int)boyut, stdin) == NULL) {
        return -1;
    }
    size_t uzunluk = strlen(tampon);
    if (uzunluk > 0 && tampon[uzunluk - 1] == '\n') {
        tampon[--uzunluk] = '\0';                 /* fgets '\n'i de saklar */
    } else {
        int c = getchar();          /* satır tam sığdı mı, yoksa taştı mı? */
        if (c != '\n' && c != EOF) {
            satir_temizle();                      /* taşan kısmı at */
            tampon[0] = '\0';
            return 0;
        }
    }
    if (uzunluk > 0 && tampon[uzunluk - 1] == '\r') {
        tampon[--uzunluk] = '\0';                 /* CRLF satır sonu */
    }
    return 1;
}

/* Son koşul: metnin TAMAMI (baştaki/sondaki boşluklar hariç) onluk bir
 * tamsayıysa değeri *sonuc'a yazılır ve true döner; rakam yoksa, sayıdan
 * sonra başka karakter varsa ya da long long'a sığmıyorsa false. */
bool tamsayi_coz(const char *metin, long long *sonuc)
{
    char *son;
    errno = 0;
    long long deger = strtoll(metin, &son, 10);
    if (son == metin || errno == ERANGE) {
        return false;                    /* hiç rakam yok ya da taşma */
    }
    while (isspace((unsigned char)*son)) {
        son++;
    }
    if (*son != '\0') {
        return false;                    /* "12abc", "3 4" gibi artıklar */
    }
    *sonuc = deger;
    return true;
}

/* Son koşul: metnin TAMAMI sonlu bir ondalık sayıysa (ondalık ayırıcı
 * NOKTA: 85.5) değeri *sonuc'a yazılır ve true döner; aksi hâlde false
 * ("85,5", "nan", "inf", "1e999" reddedilir). */
bool ondalik_coz(const char *metin, double *sonuc)
{
    char *son;
    errno = 0;
    double deger = strtod(metin, &son);
    if (son == metin || errno == ERANGE || !isfinite(deger)) {
        return false;
    }
    while (isspace((unsigned char)*son)) {
        son++;
    }
    if (*son != '\0') {
        return false;
    }
    *sonuc = deger;
    return true;
}

/* s, Türkçe küçük harflerden biriyle başlıyorsa o harfin tablo indisini,
 * başlamıyorsa -1'i döndürür. */
static int turkce_kucuk_harf(const char *s)
{
    for (int k = 0; k < TR_HARF_SAYISI; k++) {
        if (strncmp(s, KUCUK_HARF[k], strlen(KUCUK_HARF[k])) == 0) {
            return k;
        }
    }
    return -1;
}

/* Ön koşul : kaynak '\0' ile biten UTF-8 metin; hedef en az boyut baytlık.
 * Son koşul: hedef = kaynağın normalleştirilmiş biçimi: baştaki ve sondaki
 *            boşluklar atılır, aradaki boşluk dizileri tek boşluğa iner,
 *            harfler Türkçe kurala göre büyütülür (i → İ, ı → I, ç → Ç, ...).
 *            Dönüş: hedefe yazılan bayt sayısı ('\0' hariç); sonuç boyut - 1
 *            bayta sığmazsa hedef boş bırakılır ve -1 döner.
 *            Hedefe hiçbir zaman boyut bayttan fazla yazılmaz; çok baytlı
 *            bir harf asla ortasından bölünmez. */
int ad_normallestir(const char *kaynak, char *hedef, size_t boyut)
{
    size_t i = 0;                 /* kaynakta okunacak bayt */
    size_t j = 0;                 /* hedefte yazılacak bayt */
    bool bosluk_bekliyor = false; /* kelimeler arasına tek boşluk koyulacak */
    if (boyut == 0) {
        return -1;
    }
    while (kaynak[i] != '\0') {
        if (isspace((unsigned char)kaynak[i])) {
            bosluk_bekliyor = (j > 0);   /* baştaki boşluklar hiç yazılmaz */
            i++;
            continue;
        }
        char tek[2] = { 0, 0 };
        const char *parca;
        int k = turkce_kucuk_harf(&kaynak[i]);
        if (k != -1) {
            parca = BUYUK_HARF[k];               /* 'ı' → "I": 2 bayt → 1 */
            i += strlen(KUCUK_HARF[k]);          /* 'i' → "İ": 1 bayt → 2 */
        } else {
            tek[0] = (char)toupper((unsigned char)kaynak[i]);
            parca = tek;                         /* ASCII harf ya da diğer bayt */
            i++;
        }
        size_t gerekli = strlen(parca) + (bosluk_bekliyor ? 1 : 0);
        if (j + gerekli >= boyut) {              /* '\0' için de yer kalmalı */
            hedef[0] = '\0';
            return -1;
        }
        if (bosluk_bekliyor) {
            hedef[j++] = ' ';
            bosluk_bekliyor = false;
        }
        memcpy(&hedef[j], parca, strlen(parca));
        j += strlen(parca);
    }
    hedef[j] = '\0';                  /* sondaki boşluklar hiç yazılmadı */
    return (int)j;
}

/* Son koşul: ad boş değilse ve yalnızca harf (ASCII harfler ve geçerli
 * çok baytlı UTF-8 karakterler), boşluk, kesme işareti (') ve kısa çizgi
 * (-) içeriyorsa true. Rakam, noktalama ve bozuk UTF-8 dizileri reddedilir. */
bool ad_gecerli_mi(const char *ad)
{
    if (ad[0] == '\0') {
        return false;
    }
    for (size_t i = 0; ad[i] != '\0'; ) {
        unsigned char c = (unsigned char)ad[i];
        int devam;                          /* beklenen devam baytı sayısı */
        if (c < 0x80) {                     /* ASCII: 0xxxxxxx */
            if (!isalpha(c) && c != ' ' && c != '\'' && c != '-') {
                return false;
            }
            i++;
            continue;
        } else if (c >= 0xC2 && c <= 0xDF) {    /* 110xxxxx: 2 baytlık */
            devam = 1;
        } else if ((c & 0xF0) == 0xE0) {        /* 1110xxxx: 3 baytlık */
            devam = 2;
        } else if (c >= 0xF0 && c <= 0xF4) {    /* 11110xxx: 4 baytlık */
            devam = 3;
        } else {
            return false;                       /* geçersiz başlangıç baytı */
        }
        for (int k = 1; k <= devam; k++) {
            if (((unsigned char)ad[i + k] & 0xC0) != 0x80) {
                return false;                   /* eksik devam baytı ('\0' dahil) */
            }
        }
        i += devam + 1;
    }
    return true;
}

/* Son koşul: s'deki KARAKTER sayısı. UTF-8'de devam baytları 10xxxxxx
 * biçimindedir; yalnızca devam baytı OLMAYAN baytlar sayılır.
 * strlen ise BAYT sayar: strlen("ÇAY") = 4, utf8_karakter_sayisi("ÇAY") = 3. */
size_t utf8_karakter_sayisi(const char *s)
{
    size_t sayi = 0;
    for (; *s != '\0'; s++) {
        if (((unsigned char)*s & 0xC0) != 0x80) {
            sayi++;
        }
    }
    return sayi;
}

/* s'yi yazar ve sağına, toplam genişlik KARAKTER olarak genislik olacak
 * kadar boşluk ekler (printf'in %-24s biçimi BAYT saydığı için Türkçe
 * harfli metinlerde sütunları kaydırır). */
void hizali_yaz(const char *s, int genislik)
{
    printf("%s", s);
    for (size_t k = utf8_karakter_sayisi(s); k < (size_t)genislik; k++) {
        putchar(' ');
    }
}

/* Ekrana program başlığını yazar. */
void baslik_yaz(void)
{
    printf("==========================================\n");
    printf("  MİNİ-OBS v0.13 · Öğrenci Not Sistemi\n");
    printf("==========================================\n");
}

/* Ana menüyü ve seçim istemini yazar. */
void menu_goster(void)
{
    printf("\n---------------- ANA MENÜ ----------------\n");
    printf("  1) Öğrenci ekle (tüm dersler)\n");
    printf("  2) Ders istatistikleri tablosu\n");
    printf("  3) Transkript (numara ile)\n");
    printf("  4) Harf notu dağılımı (ders × harf)\n");
    printf("  5) Kayıtları listele\n");
    printf("  6) İsimle ara (ad, soyad ya da ad soyad)\n");
    printf("  7) Çıkış\n");
    printf("Seçiminiz (1-7)  : ");
}

/* Son koşul: 1-SECENEK_SAYISI arası bir sayı girildiyse onu; satır sayı
 * değilse ya da aralık dışıysa 0'ı (geçersiz); girdi bittiyse -1'i döndürür. */
int menu_secimi_oku(void)
{
    char satir[SATIR_BOYUT];
    long long secim;
    int durum = satir_oku(satir, sizeof satir);
    if (durum == -1) {
        return -1;
    }
    if (durum == 0 || !tamsayi_coz(satir, &secim)
        || secim < 1 || secim > SECENEK_SAYISI) {
        return 0;
    }
    return (int)secim;
}

/* Son koşul: 1 ile INT_MAX arasında bir başlangıç kapasitesi döndürür;
 * geçersiz girdide yeniden sorar; girdi biterse -1. */
int kapasite_oku(void)
{
    char satir[SATIR_BOYUT];
    long long kapasite;
    for (;;) {
        printf("Beklenen öğrenci sayısı : ");
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1;
        }
        if (durum == 1 && tamsayi_coz(satir, &kapasite)
            && kapasite >= 1 && kapasite <= INT_MAX) {
            return (int)kapasite;
        }
        printf("  Geçersiz: 1 ya da daha büyük bir tamsayı girin.\n");
    }
}

/* Son koşul: pozitif bir öğrenci numarası döndürür; geçersiz girdide
 * yeniden sorar; girdi biterse -1 döndürür. */
long long numara_oku(void)
{
    char satir[SATIR_BOYUT];
    long long numara;
    for (;;) {
        printf("Öğrenci numarası : ");
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1;
        }
        if (durum == 1 && tamsayi_coz(satir, &numara) && numara > 0) {
            return numara;
        }
        printf("  Geçersiz: pozitif bir numara girin.\n");
    }
}

/* Ön koşul : etiket, ekrana yazılacak istem metnidir.
 * Son koşul: 0-100 aralığında bir not döndürür; geçersiz girdide yeniden
 *            sorar; girdi biterse -1.0 döndürür. NaN, !(0 <= x <= 100)
 *            sınamasıyla da reddedilir (NaN ile her karşılaştırma false). */
double not_oku(const char *etiket)
{
    char satir[SATIR_BOYUT];
    double deger;
    for (;;) {
        printf("%s", etiket);
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1.0;
        }
        if (durum == 1 && ondalik_coz(satir, &deger)
            && deger >= 0 && deger <= 100) {
            return deger;
        }
        printf("  Geçersiz: 0 ile 100 arasında bir sayı girin"
               " (ondalık ayırıcı nokta: 85.5).\n");
    }
}

/* Ön koşul : hedef en az boyut baytlık; boyut >= 2.
 * Son koşul: geçerli bir ad okunur, normalleştirilip hedefe yazılır ve 1
 *            döner; geçersizse nedeni yazılır ve yeniden sorulur; girdi
 *            biterse -1. */
int ad_oku(const char *etiket, char *hedef, size_t boyut)
{
    char satir[SATIR_BOYUT];
    for (;;) {
        printf("%s", etiket);
        int durum = satir_oku(satir, sizeof satir);
        if (durum == -1) {
            return -1;
        }
        if (durum == 0) {
            printf("  Geçersiz: satır çok uzun.\n");
            continue;
        }
        int uzunluk = ad_normallestir(satir, hedef, boyut);
        if (uzunluk == -1) {
            printf("  Geçersiz: en çok %zu bayt (Türkçe harfler 2 bayt).\n",
                   boyut - 1);
        } else if (uzunluk == 0) {
            printf("  Geçersiz: boş bırakılamaz.\n");
        } else if (!ad_gecerli_mi(hedef)) {
            printf("  Geçersiz: yalnızca harf, boşluk, ' ve - kullanılabilir.\n");
        } else {
            return 1;
        }
    }
}

/* Ön koşul : 0 <= vize, final <= 100.  Son koşul: %40 + %60 ağırlıklı ortalama. */
double hesapla_ortalama(double vize, double final)
{
    return VIZE_AGIRLIK * vize + FINAL_AGIRLIK * final;
}

/* Ön koşul : ortalama >= 0.  Son koşul: en yakın tamsayı (.5 yukarı). */
int yuvarla(double ortalama)
{
    return (int)(ortalama + 0.5);
}

/* Son koşul: RTEÜ tablosuna göre harf notu; final barajın altındaysa "FF". */
const char *harf_notu(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "FF";
    } else if (yuvarlanmis >= 90) {
        return "AA";
    } else if (yuvarlanmis >= 81) {
        return "BA";
    } else if (yuvarlanmis >= 73) {
        return "BB";
    } else if (yuvarlanmis >= 66) {
        return "CB";
    } else if (yuvarlanmis >= 60) {
        return "CC";
    } else if (yuvarlanmis >= 50) {
        return "DC";
    } else if (yuvarlanmis >= 40) {
        return "DD";
    } else if (yuvarlanmis >= 30) {
        return "FD";
    }
    return "FF";
}

/* Son koşul: CC ve üzeri ve final barajı aşıldıysa true. */
bool gecti_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= GECME_ORTALAMA;
}

/* Son koşul: DC (50-59) ve final barajı aşıldıysa true. */
bool sartli_mi(int yuvarlanmis, double final)
{
    return final >= FINAL_BARAJI && yuvarlanmis >= SARTLI_ORTALAMA
           && yuvarlanmis < GECME_ORTALAMA;
}

/* Son koşul: rapordaki "Durum" satırının metni. */
const char *durum_metni(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return "BAŞARISIZ (final barajı)";
    } else if (gecti_mi(yuvarlanmis, final)) {
        return "BAŞARILI";
    } else if (sartli_mi(yuvarlanmis, final)) {
        return "ŞARTLI BAŞARILI (YANO ≥ 2,00 ise)";
    }
    return "BAŞARISIZ";
}

/* Son koşul: harf notunun frekans dizisindeki indisi (AA=0 ... FF=8).
 * harf_notu() ile aynı merdiven; sayaç dizisinde "değer = indis". */
int harf_indeksi(int yuvarlanmis, double final)
{
    if (final < FINAL_BARAJI) {
        return 8;                                /* FF (baraj) */
    } else if (yuvarlanmis >= 90) {
        return 0;
    } else if (yuvarlanmis >= 81) {
        return 1;
    } else if (yuvarlanmis >= 73) {
        return 2;
    } else if (yuvarlanmis >= 66) {
        return 3;
    } else if (yuvarlanmis >= 60) {
        return 4;
    } else if (yuvarlanmis >= 50) {
        return 5;
    } else if (yuvarlanmis >= 40) {
        return 6;
    } else if (yuvarlanmis >= 30) {
        return 7;
    }
    return 8;
}

/* Ön koşul: 0 <= indeks < HARF_SAYISI.  Son koşul: harfin adı. */
const char *harf_adi(int indeks)
{
    switch (indeks) {
    case 0: return "AA";
    case 1: return "BA";
    case 2: return "BB";
    case 3: return "CB";
    case 4: return "CC";
    case 5: return "DC";
    case 6: return "DD";
    case 7: return "FD";
    default: return "FF";
    }
}

/* Ön koşul: 0 <= indeks < HARF_SAYISI.  Son koşul: harfin katsayısı
 * (AA=0 → 4,00; her kademe 0,50 azalır; FF=8 → 0,00). */
double harf_katsayisi(int indeks)
{
    return 4.0 - 0.5 * indeks;
}

/* Ders bilgileri (ÖRNEK değerler; gerçek ders planına göre değiştirilir). */
const char *ders_adi(int d)
{
    switch (d) {
    case 0: return "Algoritma ve Prog. I";
    case 1: return "Matematik I";
    default: return "Fizik I";
    }
}

const char *ders_kodu(int d)
{
    switch (d) {
    case 0: return "ALG";
    case 1: return "MAT";
    default: return "FIZ";
    }
}

int ders_kredisi(int d)
{
    switch (d) {
    case 0: return 6;
    case 1: return 6;
    default: return 5;
    }
}

/* Doğrusal tarama: aranan numaranın ilk indisi; yoksa -1 (erken çıkış). */
int numara_bul(const long long no[], int n, long long aranan)
{
    for (int i = 0; i < n; i++) {
        if (no[i] == aranan) {
            return i;
        }
    }
    return -1;
}

/* Ön koşul: n >= 1.  Son koşul: a[0..n-1] ortalaması. */
double dizi_ortalama(const double a[], int n)
{
    double toplam = 0.0;
    for (int i = 0; i < n; i++) {
        toplam += a[i];
    }
    return toplam / n;
}

/* Ön koşul: n >= 1.  Son koşul: popülasyon standart sapması
 * sqrt( Σ (a[i] - μ)² / n ). İki geçiş: önce μ, sonra sapmalar. */
double standart_sapma(const double a[], int n)
{
    double mu = dizi_ortalama(a, n);
    double kare_toplam = 0.0;
    for (int i = 0; i < n; i++) {
        double fark = a[i] - mu;
        kare_toplam += fark * fark;
    }
    return sqrt(kare_toplam / n);
}

/* Ön koşul: n >= 1.  Son koşul: en büyük elemanın İLK indisi. */
int en_buyuk_indis(const double a[], int n)
{
    int enb = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] > a[enb]) {
            enb = i;
        }
    }
    return enb;
}

/* Ön koşul: n >= 1.  Son koşul: en küçük elemanın İLK indisi. */
int en_kucuk_indis(const double a[], int n)
{
    int enk = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] < a[enk]) {
            enk = i;
        }
    }
    return enk;
}

/* Son koşul: eşikten KESİN büyük eleman sayısı. */
int esik_ustu_say(const double a[], int n, double esik)
{
    int sayi = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] > esik) {
            sayi++;
        }
    }
    return sayi;
}

/* Ön koşul : n >= 1; enk ve enb geçerli adreslerdir.
 * Son koşul: *enk ve *enb, en küçük ve en büyük elemanın İLK indisleri
 *            (tek geçişte; en_kucuk_indis ve en_buyuk_indis ile aynı sonuç). */
void min_max_indis(const double a[], int n, int *enk, int *enb)
{
    *enk = 0;
    *enb = 0;
    for (int i = 1; i < n; i++) {
        if (a[i] < a[*enk]) {
            *enk = i;
        }
        if (a[i] > a[*enb]) {
            *enb = i;
        }
    }
}

/* d. sütunu (bir dersin bütün öğrencileri) 1B diziye kopyalar.
 * Sütun elemanları bellekte bitişik DEĞİLDİR: m[i][d] adresleri arasında
 * DERS_SAYISI * sizeof(double) bayt vardır (satır öncelikli yerleşim). */
void sutun_kopyala(double m[][DERS_SAYISI], int n, int d, double hedef[])
{
    for (int i = 0; i < n; i++) {
        hedef[i] = m[i][d];
    }
}

/* Son koşul: kredi ağırlıklı yarıyıl not ortalaması (YANO), Madde 31/2-a'ya
 * göre iki haneye yuvarlanmış (üçüncü hane >= 5 ise yukarı). Kayan nokta
 * hatası olmasın diye tamsayıyla: s = Σ kredi × (katsayı × 100), K = Σ kredi;
 * yuvarlanmış YANO × 100 = (2s + K) / (2K). Parametreler bir öğrencinin
 * SATIRLARIDIR (ort[i], final[i]). */
double yano_hesapla(const double ort_satiri[], const double final_satiri[])
{
    int s = 0, toplam_kredi = 0;
    for (int d = 0; d < DERS_SAYISI; d++) {
        int k = harf_indeksi(yuvarla(ort_satiri[d]), final_satiri[d]);
        int katsayi100 = (int)(harf_katsayisi(k) * 100.0 + 0.5);  /* 400 … 0 */
        s += ders_kredisi(d) * katsayi100;
        toplam_kredi += ders_kredisi(d);
    }
    int yano100 = (2 * s + toplam_kredi) / (2 * toplam_kredi);
    return yano100 / 100.0;
}

/* Son koşul: sayac[d][k] = d. derste k. harfi alan öğrenci sayısı
 * (2B frekans matrisi). */
void ders_harf_dagilimi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                        int n, int sayac[DERS_SAYISI][HARF_SAYISI])
{
    for (int d = 0; d < DERS_SAYISI; d++) {
        for (int k = 0; k < HARF_SAYISI; k++) {
            sayac[d][k] = 0;
        }
    }
    for (int i = 0; i < n; i++) {
        for (int d = 0; d < DERS_SAYISI; d++) {
            sayac[d][harf_indeksi(yuvarla(ort[i][d]), final[i][d])]++;
        }
    }
}

/* Ön koşul : n >= 1; 0 <= d < DERS_SAYISI; çıktı işaretçileri geçerli.
 * Son koşul: d. dersin (sütunun) ortalaması, standart sapması, en yüksek ve
 *            en düşük ortalamalı öğrencinin İNDİSİ, başarılı ve şartlı
 *            öğrenci sayısı çıktı parametrelerine yazılır; true döner.
 *            Geçici sütun dizisi için bellek ayrılamazsa false döner.
 * Sütun bellekte bitişik olmadığından öbekte n elemanlık geçici bir diziye
 * kopyalanır, v0.10'un 1B fonksiyonlarına verilir ve bırakılır. */
bool ders_istatistigi(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n, int d, double *ortalama, double *sapma,
                      int *enb, int *enk, int *basarili, int *sartli)
{
    double *sutun = malloc(n * sizeof *sutun);
    if (sutun == NULL) {
        return false;
    }
    sutun_kopyala(ort, n, d, sutun);
    *ortalama = dizi_ortalama(sutun, n);
    *sapma = standart_sapma(sutun, n);
    min_max_indis(sutun, n, enk, enb);
    *basarili = 0;
    *sartli = 0;
    for (int i = 0; i < n; i++) {
        int y = yuvarla(ort[i][d]);
        if (gecti_mi(y, final[i][d])) {
            (*basarili)++;
        } else if (sartli_mi(y, final[i][d])) {
            (*sartli)++;
        }
    }
    free(sutun);
    return true;
}

/* Ön koşul : aranan normalleştirilmiş bir metindir (ad_normallestir);
 *            0 <= baslangic.
 * Son koşul: baslangic'tan itibaren adı, soyadı ya da "AD SOYAD" biçimindeki
 *            tam adı aranana EŞİT olan ilk kaydın indisi; yoksa -1.
 *            Bütün eşleşmeleri gezmek için: i = isim_bul(..., 0) ile başla,
 *            i != -1 oldukça isim_bul(..., i + 1) ile devam et.
 * strcmp, iki metni bayt bayt karşılaştırır; eşitse 0 döndürür. */
int isim_bul(char ad[][AD_BOYUT], char soyad[][SOYAD_BOYUT], int n,
             const char *aranan, int baslangic)
{
    char tam_ad[AD_BOYUT + SOYAD_BOYUT];   /* 31 + ' ' + 31 + '\0' = 64 bayt */
    for (int i = baslangic; i < n; i++) {
        snprintf(tam_ad, sizeof tam_ad, "%s %s", ad[i], soyad[i]);
        if (strcmp(soyad[i], aranan) == 0 || strcmp(ad[i], aranan) == 0
            || strcmp(tam_ad, aranan) == 0) {
            return i;
        }
    }
    return -1;
}

/* Ön koşul : kapasite >= 1.
 * Son koşul: kapasitenin iki katı; sonuç int'e sığmıyorsa -1. */
int yeni_kapasite(int kapasite)
{
    if (kapasite > INT_MAX / 2) {
        return -1;                              /* 2 × kapasite taşar */
    }
    return 2 * kapasite;
}

/* Ön koşul : blok NULL ya da malloc/realloc'tan gelmiş bir blok;
 *            eleman_boyutu bir elemanın (satır dizilerinde bir SATIRIN)
 *            bayt sayısı.
 * Son koşul: kapasite elemanlık (yeni yerdeki olabilir) bloğun adresi;
 *            eski içerik korunur. Ayrılamazsa (ya da kapasite < 1 ise)
 *            NULL döner ve eski blok YERİNDE ve geçerlidir: çağıran
 *            sonucu önce GEÇİCİ işaretçiye almalıdır. */
void *buyut(void *blok, int kapasite, size_t eleman_boyutu)
{
    if (kapasite < 1) {
        return NULL;                  /* realloc(p, 0) uygulamaya bağlı */
    }
    return realloc(blok, (size_t)kapasite * eleman_boyutu);
}

/* TEK temizlik yolu: altı bloğu da bırakır. free(NULL) etkisiz olduğundan
 * kısmen başarısız bir ayırmadan sonra da güvenle çağrılabilir. */
void kayitlari_birak(long long no[], char ad[][AD_BOYUT],
                     char soyad[][SOYAD_BOYUT], double vize[][DERS_SAYISI],
                     double final[][DERS_SAYISI], double ort[][DERS_SAYISI])
{
    free(no);
    free(ad);
    free(soyad);
    free(vize);
    free(final);
    free(ort);
}

/* Eklenen öğrencinin ders ders kısa özeti ve YANO'su. */
void ogrenci_ozeti_yaz(long long numara, const char *ad, const char *soyad,
                       const double ort_satiri[], const double final_satiri[])
{
    printf("Öğrenci no  : %lld\n", numara);
    printf("Ad Soyad    : %s %s\n", ad, soyad);
    for (int d = 0; d < DERS_SAYISI; d++) {
        int y = yuvarla(ort_satiri[d]);
        printf("%-20s  %6.2f  %s  %s\n", ders_adi(d), ort_satiri[d],
               harf_notu(y, final_satiri[d]), durum_metni(y, final_satiri[d]));
    }
    printf("YANO        : %4.2f\n", yano_hesapla(ort_satiri, final_satiri));
}

/* Her ders (sütun) için ortalama, standart sapma, en yüksek, en düşük,
 * başarılı ve şartlı sayısı. Değerler ders_istatistigi'nin ÇIKTI
 * PARAMETRELERİNDEN gelir; rapor biçimi v0.12 ile aynıdır. */
void ders_istatistikleri_yaz(double ort[][DERS_SAYISI],
                             double final[][DERS_SAYISI], int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    printf("\n------------------------ DERS İSTATİSTİKLERİ ------------------------\n");
    printf("Ders                    Ort.  S.sapma  En yük.  En düş.  Başarılı  Şartlı\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        double ortalama, sapma;
        int enb, enk, basarili, sartli;
        if (!ders_istatistigi(ort, final, n, d, &ortalama, &sapma,
                              &enb, &enk, &basarili, &sartli)) {
            printf("  Bellek yetersiz: %s hesaplanamadı.\n", ders_adi(d));
            continue;
        }
        printf("%-20s  %6.2f  %7.2f  %7.2f  %7.2f  %4d/%-3d  %3d/%-3d\n",
               ders_adi(d), ortalama, sapma, ort[enb][d], ort[enk][d],
               basarili, n, sartli, n);
    }
    printf("---------------------------------------------------------------------\n");
    printf("Öğrenci sayısı: %d\n", n);
}

/* Bir öğrencinin transkripti: ders, kredi, notlar, harf, katsayı, YANO. */
void transkript_yaz(long long numara, const char *ad, const char *soyad,
                    const double vize_satiri[], const double final_satiri[],
                    const double ort_satiri[])
{
    bool dc_var = false;
    int toplam_kredi = 0;
    printf("\n----------------------- TRANSKRİPT -----------------------\n");
    printf("Öğrenci no : %lld\n", numara);
    printf("Ad Soyad   : %s %s\n", ad, soyad);
    printf("Ders                  Kredi    Vize   Final    Ort.  Harf  Katsayı\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        int y = yuvarla(ort_satiri[d]);
        int k = harf_indeksi(y, final_satiri[d]);
        if (k == 5) {
            dc_var = true;
        }
        toplam_kredi += ders_kredisi(d);
        printf("%-20s  %5d  %6.2f  %6.2f  %6.2f    %s     %4.2f\n", ders_adi(d),
               ders_kredisi(d), vize_satiri[d], final_satiri[d], ort_satiri[d],
               harf_adi(k), harf_katsayisi(k));
    }
    double yano = yano_hesapla(ort_satiri, final_satiri);
    printf("----------------------------------------------------------\n");
    printf("Toplam kredi : %d\n", toplam_kredi);
    printf("YANO         : %4.2f\n", yano);
    if (dc_var) {
        printf("DC notları   : %s\n", yano >= 2.0
               ? "YANO ≥ 2,00 → başarılı sayılır"
               : "YANO < 2,00 → başarısız sayılır");
    }
}

/* Ders × harf frekans matrisini tablo olarak yazar. */
void harf_tablosu_yaz(double ort[][DERS_SAYISI], double final[][DERS_SAYISI],
                      int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    int sayac[DERS_SAYISI][HARF_SAYISI];
    ders_harf_dagilimi(ort, final, n, sayac);
    printf("\n-------------- HARF NOTU DAĞILIMI (ders × harf) --------------\n");
    printf("%-20s", "Ders");
    for (int k = 0; k < HARF_SAYISI; k++) {
        printf("  %s", harf_adi(k));
    }
    printf("\n");
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("%-20s", ders_adi(d));
        for (int k = 0; k < HARF_SAYISI; k++) {
            printf("  %2d", sayac[d][k]);
        }
        printf("\n");
    }
    printf("--------------------------------------------------------------\n");
}

/* Liste ve arama sonuçlarının ortak başlığı ve tek satırı (yalnızca bu
 * dosyada). Ad Soyad sütunu hizali_yaz ile KARAKTER sayısına göre doldurulur. */
static void liste_basligi_yaz(void)
{
    printf("Sıra  Öğrenci no  ");
    hizali_yaz("Ad Soyad", AD_SUTUNU);
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("  %9s", ders_kodu(d));
    }
    printf("   YANO\n");
}

static void liste_satiri_yaz(int sira, long long numara, const char *ad,
                             const char *soyad, const double ort_satiri[],
                             const double final_satiri[])
{
    char tam_ad[AD_BOYUT + SOYAD_BOYUT];
    snprintf(tam_ad, sizeof tam_ad, "%s %s", ad, soyad);
    printf("%4d  %10lld  ", sira, numara);
    hizali_yaz(tam_ad, AD_SUTUNU);
    for (int d = 0; d < DERS_SAYISI; d++) {
        printf("  %6.2f %s", ort_satiri[d],
               harf_notu(yuvarla(ort_satiri[d]), final_satiri[d]));
    }
    printf("   %4.2f\n", yano_hesapla(ort_satiri, final_satiri));
}

/* Bütün öğrenciler: ad soyad, her dersin ortalaması ve harfi, YANO. */
void kayitlari_listele(const long long no[], char ad[][AD_BOYUT],
                       char soyad[][SOYAD_BOYUT], double ort[][DERS_SAYISI],
                       double final[][DERS_SAYISI], int n)
{
    if (n == 0) {
        printf("  Henüz kayıt yok: önce 1) Öğrenci ekle.\n");
        return;
    }
    printf("\n------------------------------------ KAYITLAR ------------------------------------\n");
    liste_basligi_yaz();
    for (int i = 0; i < n; i++) {
        liste_satiri_yaz(i + 1, no[i], ad[i], soyad[i], ort[i], final[i]);
    }
    printf("----------------------------------------------------------------------------------\n");
}

/* Ön koşul : aranan normalleştirilmiştir.
 * Son koşul: adı, soyadı ya da tam adı arananla eşleşen bütün kayıtlar
 *            (sıra numaralarıyla) ve eşleşme sayısı yazılır. */
void arama_sonucu_yaz(const long long no[], char ad[][AD_BOYUT],
                      char soyad[][SOYAD_BOYUT], double ort[][DERS_SAYISI],
                      double final[][DERS_SAYISI], int n, const char *aranan)
{
    int bulunan = 0;
    for (int i = isim_bul(ad, soyad, n, aranan, 0); i != -1;
         i = isim_bul(ad, soyad, n, aranan, i + 1)) {
        if (bulunan == 0) {
            printf("\n--------------------------------- ARAMA: %s\n", aranan);
            liste_basligi_yaz();
        }
        liste_satiri_yaz(i + 1, no[i], ad[i], soyad[i], ort[i], final[i]);
        bulunan++;
    }
    if (bulunan == 0) {
        printf("  Eşleşen kayıt yok: %s\n", aranan);
    } else {
        printf("Eşleşen kayıt: %d\n", bulunan);
    }
}

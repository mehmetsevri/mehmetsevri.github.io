/* H13_08_strcpy_strcmp_kendimiz.c — Hafta 13 · Örnek 8 (★★): strcpy/strcmp
 * Amaç   : İki temel string.h fonksiyonunun iç işleyişini görmek.
 *          benim_strcpy: '\0' DAHİL her baytı kopyalar (kopyayı da
 *          sonlandırır). benim_strcmp: baytları karşılaştırır, ilk farkta
 *          (unsigned char olarak) farkın İŞARETİNİ döndürür; eşitse 0.
 * Not    : strcmp'nin dönüş değerinin yalnızca İŞARETİ anlamlıdır (negatif,
 *          sıfır, pozitif); kesin sayı taşınabilir değildir (ISO/IEC 9899:
 *          2018, 7.24.4.2). benim_strcpy hedefin yeterli yere sahip
 *          olduğunu VARSAYAR: sorumluluk çağırandadır (STR31-C).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_08_strcpy_strcmp_kendimiz.c -o strcpy_strcmp
 * Örnek  : -> strcmp("abc","abd") işareti: - (negatif)
 */
#include <stdio.h>
#include <string.h>

/* hedef'e kaynak'ı '\0' dahil kopyalar; hedef'i döndürür (strcpy gibi) */
char *benim_strcpy(char *hedef, const char *kaynak)
{
    size_t i = 0;
    while ((hedef[i] = kaynak[i]) != '\0') {   /* atama '\0'ı da kopyalar */
        i++;
    }
    return hedef;
}

/* ilk farklı baytın (unsigned char) farkını döndürür; eşitse 0 */
int benim_strcmp(const char *a, const char *b)
{
    size_t i = 0;
    while (a[i] != '\0' && a[i] == b[i]) {
        i++;
    }
    return (unsigned char)a[i] - (unsigned char)b[i];
}

static const char *isaret(int x)
{
    return x < 0 ? "- (negatif)" : x > 0 ? "+ (pozitif)" : "0 (eşit)";
}

int main(void)
{
    char hedef[32];
    benim_strcpy(hedef, "Merhaba");
    printf("kopya: %s (strcmp ile kontrol: %d)\n", hedef,
           strcmp(hedef, "Merhaba"));

    printf("strcmp(\"abc\",\"abd\") işareti: %s / benim: %s\n",
           isaret(strcmp("abc", "abd")), isaret(benim_strcmp("abc", "abd")));
    printf("strcmp(\"abc\",\"abc\") işareti: %s / benim: %s\n",
           isaret(strcmp("abc", "abc")), isaret(benim_strcmp("abc", "abc")));
    printf("strcmp(\"Zeki\",\"Ali\")  işareti: %s / benim: %s\n",
           isaret(strcmp("Zeki", "Ali")), isaret(benim_strcmp("Zeki", "Ali")));
    return 0;
}

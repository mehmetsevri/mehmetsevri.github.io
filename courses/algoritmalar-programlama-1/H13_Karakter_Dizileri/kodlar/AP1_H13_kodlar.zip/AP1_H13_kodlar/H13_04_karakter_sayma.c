/* H13_04_karakter_sayma.c — Hafta 13 · Örnek 4 (★): Karakter sınıflandırma
 * Amaç   : Bir satırı fgets ile okuyup ctype.h ile karakterleri saymak:
 *          ünlü, ünsüz (ASCII harf olup ünlü olmayan), rakam, boşluk ve
 *          diğer. Her bayt unsigned char'a çevrilerek ctype'a verilir.
 * Not    : Sayım ASCII harfleri içindir; Türkçe ünlüler (ç hariç ı, ö, ü)
 *          UTF-8'de çok baytlıdır ve "diğer" sayılır (Örnek 12).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_04_karakter_sayma.c -o karakter_sayma
 * Örnek  : girdi "Merhaba C 2026" -> harf 8 (ünlü 3, ünsüz 5) ...
 */
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define SATIR 128

static int unlu_mu(int c)
{
    const char *unluler = "aeiouAEIOU";
    return strchr(unluler, c) != NULL;   /* c != 0 varsayılır */
}

int main(void)
{
    char satir[SATIR];
    printf("Bir satır girin: ");
    if (fgets(satir, sizeof satir, stdin) == NULL) {
        return 1;
    }
    satir[strcspn(satir, "\n")] = '\0';

    int unlu = 0, unsuz = 0, rakam = 0, bosluk = 0, diger = 0;
    for (size_t i = 0; satir[i] != '\0'; i++) {
        unsigned char c = (unsigned char)satir[i];
        if (isalpha(c)) {
            if (unlu_mu(c)) {
                unlu++;
            } else {
                unsuz++;
            }
        } else if (isdigit(c)) {
            rakam++;
        } else if (isspace(c)) {
            bosluk++;
        } else {
            diger++;
        }
    }
    printf("Harf   : %d (ünlü %d, ünsüz %d)\n", unlu + unsuz, unlu, unsuz);
    printf("Rakam  : %d\n", rakam);
    printf("Boşluk : %d\n", bosluk);
    printf("Diğer  : %d\n", diger);
    return 0;
}

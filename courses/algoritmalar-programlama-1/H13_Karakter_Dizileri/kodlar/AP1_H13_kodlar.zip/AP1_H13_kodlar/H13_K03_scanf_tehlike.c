/* H13_K03_scanf_tehlike.c — Hafta 13 · Kavram programı: scanf("%s")
 * Amaç   : scanf("%s")'in iki özelliği. (1) İlk BOŞLUKTA durur: "Ayşe Nur"
 *          girilse yalnızca "Ayşe" okunur, " Nur" tamponda kalır. (2)
 *          Genişlik VERİLMEZSE sınırsız okur ve tamponu taşırabilir; bu
 *          yüzden alan GENİŞLİĞİ verilir: "%19s" en çok 19 karakter okur
 *          ('\0' için bir bayt bırakır; tampon 20 baytsa güvenli).
 * Not    : Güvenli girdi için bir satırı bütün okuyan fgets yeğlenir
 *          (Örnek 2). scanf dönüş değeri (başarıyla okunan alan sayısı)
 *          daima denetlenmelidir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K03_scanf_tehlike.c -o scanf_tehlike
 * Örnek  : girdi "Ayşe Nur" -> Okunan: [Ayşe] (boşlukta durdu)
 */
#include <stdio.h>

int main(void)
{
    char kelime[20];
    printf("Bir ad girin: ");
    /* %19s: en çok 19 bayt + '\0'; genişliksiz "%s" TAŞABİLİR (kullanmayın) */
    if (scanf("%19s", kelime) != 1) {   /* dönüş değeri denetlenir */
        printf("Girdi okunamadı.\n");
        return 1;
    }
    printf("Okunan: [%s] (ilk boşlukta durur; kalanı tamponda)\n", kelime);
    return 0;
}

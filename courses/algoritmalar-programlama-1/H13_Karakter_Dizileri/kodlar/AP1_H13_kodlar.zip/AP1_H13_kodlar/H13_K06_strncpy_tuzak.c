/* H13_K06_strncpy_tuzak.c — Hafta 13 · Kavram programı: strncpy tuzağı
 * Amaç   : Boyut sınırlı strncpy'nin inceliği. strncpy en çok n bayt yazar;
 *          ama kaynak n bayttan UZUNSA sona '\0' KOYMAZ: sonuç '\0' ile
 *          bitmeyebilir ve sonraki strlen/printf tampon dışına taşar.
 *          Güvenli kalıp: kopyadan sonra son baytı elle '\0' yapmak
 *          (güvenli_kopya). strncat ise her zaman '\0' ekler ama n,
 *          EKLENECEK bayt sayısıdır (hedefte zaten olanlar sayılmaz).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K06_strncpy_tuzak.c -o strncpy_tuzak
 * Örnek  : -> güvenli: "Merha" ('\0' elle konuldu)
 */
#include <stdio.h>
#include <string.h>

/* strncpy + elle sonlandırma: hedef her zaman '\0' ile biter (STR31-C) */
void guvenli_kopya(char *hedef, size_t boyut, const char *kaynak)
{
    if (boyut == 0) {
        return;
    }
    strncpy(hedef, kaynak, boyut);
    hedef[boyut - 1] = '\0';         /* son baytı elle sonlandır: ZORUNLU */
}

int main(void)
{
    char hedef[6];
    guvenli_kopya(hedef, sizeof hedef, "Merhaba");   /* 7 bayt -> 5'e kesilir */
    printf("güvenli kopya: \"%s\" (uzunluk %zu)\n", hedef, strlen(hedef));

    /* strncat: n = EKLENECEK bayt; hedefte zaten "AP" var, 2 bayt daha ekle */
    char etiket[8] = "AP";
    strncat(etiket, "-1 dersi", 2);   /* yalnızca "-1" eklenir (+ '\0') */
    printf("strncat 2 bayt: \"%s\"\n", etiket);
    return 0;
}

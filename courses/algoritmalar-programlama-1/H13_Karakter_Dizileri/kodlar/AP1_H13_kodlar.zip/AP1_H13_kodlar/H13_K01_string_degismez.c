/* H13_K01_string_degismez.c — Hafta 13 · Kavram programı: dizi mi, değişmez mi?
 * Amaç   : İki bildirimin farkını güvenle göstermek:
 *            char s[] = "abc";  → string'i bir DİZİYE kopyalar; 4 bayt
 *                                 (a b c '\0'), DEĞİŞTİRİLEBİLİR.
 *            char *p = "abc";   → p, salt okunur bir string DEĞİŞMEZİNİ
 *                                 gösterir; p[0] = 'X' TANIMSIZ DAVRANIŞTIR
 *                                 (çoğu sistemde salt okunur bölgeye yazma →
 *                                 çökme). Burada DENENMEZ (bkz. HA6).
 * Not    : GCC, char *p = "abc"; satırını varsayılan olarak uyarmaz; ama
 *          -Wwrite-strings ile string değişmezi const char * tipinde sayılır
 *          ve p'ye atama uyarı verir: değişmezlerin salt okunur olduğunun
 *          imlenmesi. Dizi sürümünü değiştirmek serbesttir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K01_string_degismez.c -o string_degismez
 * Örnek  : -> s değişti: Xbc  (dizi değiştirilebilir)
 */
#include <stdio.h>

int main(void)
{
    char s[] = "abc";          /* diziye kopya: 4 bayt, değiştirilebilir */
    const char *p = "abc";           /* değişmezi gösterir: salt okunur say */

    s[0] = 'X';                      /* GÜVENLİ: dizinin kendi baytı */
    printf("s değişti: %s\n", s);

    /* p[0] = 'X';  <- TANIMSIZ DAVRANIŞ: değişmezi değiştirme (HA6) */
    printf("p (değişmez): %s\n", p);

    printf("sizeof s = %zu (dizinin baytları, '\\0' dahil)\n", sizeof s);
    printf("sizeof p = %zu (yalnızca işaretçinin boyutu)\n", sizeof p);
    return 0;
}

/* H13_11_isim_listesi.c — Hafta 13 · Örnek 11 (★★): İsim listesi
 * Amaç   : String dizileriyle çalışmak. İki saklama biçimi gösterilir:
 *          char ad[N][M]  → N satırlık 2B dizi; her satır M baytlık, satırlar
 *                           bitişik (H11 bağlantısı), ad[i] i. satırın adresi.
 *          const char * unvan[] → string DEĞİŞMEZLERİNİ gösteren işaretçi
 *                           dizisi; her eleman salt okunur bir metni gösterir.
 *          İşlemler: en uzun ismi bulmak (strlen ile) ve isimle arama
 *          (strcmp ile doğrusal tarama; H10 doğrusal tarama deseninin
 *          string karşılığı).
 * Not    : strlen BAYT sayar; bu liste ASCII olduğundan bayt = karakter.
 *          Türkçe adlarda fark Örnek 12'dedir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_11_isim_listesi.c -o isim_listesi
 * Örnek  : -> En uzun isim: Abdullah (8 karakter)
 */
#include <stdio.h>
#include <string.h>

#define N 5
#define M 20

/* strcmp ile doğrusal tarama: aranan isim yoksa -1 (erken çıkış) */
int isim_bul(char ad[][M], int n, const char *aranan)
{
    for (int i = 0; i < n; i++) {
        if (strcmp(ad[i], aranan) == 0) {
            return i;
        }
    }
    return -1;
}

int main(void)
{
    char ad[N][M] = { "Ali", "Abdullah", "Zeynep", "Can", "Elif" };
    const char *unvan[] = { "Prof.", "Doc.", "Dr.", "Ars. Gor." };
    int unvan_n = (int)(sizeof unvan / sizeof unvan[0]);

    int en_uzun = 0;
    for (int i = 1; i < N; i++) {
        if (strlen(ad[i]) > strlen(ad[en_uzun])) {
            en_uzun = i;
        }
    }
    printf("En uzun isim: %s (%zu karakter)\n", ad[en_uzun],
           strlen(ad[en_uzun]));

    printf("ad[1] satırının adresi ile ad[0]+M karşılaştırması: %s\n",
           (ad[1] == ad[0] + M) ? "bitişik (2B dizi)" : "farklı");

    const char *aranan = "Zeynep";
    int yer = isim_bul(ad, N, aranan);
    if (yer != -1) {
        printf("Arama \"%s\": %d. sırada bulundu.\n", aranan, yer + 1);
    } else {
        printf("Arama \"%s\": bulunamadı.\n", aranan);
    }
    printf("Ünvan dizisi (%d eleman): ", unvan_n);
    for (int i = 0; i < unvan_n; i++) {
        printf("%s ", unvan[i]);   /* her eleman bir değişmezi gösterir */
    }
    printf("\n");
    return 0;
}

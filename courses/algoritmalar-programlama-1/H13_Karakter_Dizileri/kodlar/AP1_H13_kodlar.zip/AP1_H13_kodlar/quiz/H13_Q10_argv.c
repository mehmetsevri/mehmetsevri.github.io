/* H13_Q10_argv.c — Hafta 13 · Quiz 10: argc sayımı
 * Çalıştırma: ./q10 bir iki
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_Q10_argv.c -o q10
 */
#include <stdio.h>

int main(int argc, char *argv[])
{
    (void)argv;
    printf("argc = %d\n", argc);
    return 0;
}

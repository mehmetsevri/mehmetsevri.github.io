/* H13_Q02_malloc_sizeof.c — Hafta 13 · Quiz 2 (H12 tekrarı): sizeof tuzağı
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_Q02_malloc_sizeof.c -o q02
 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    double *d = malloc(4 * sizeof *d);   /* 4 double'lık blok */
    if (d == NULL) {
        return 1;
    }
    printf("%zu %zu\n", sizeof d, 4 * sizeof *d);
    free(d);
    return 0;
}

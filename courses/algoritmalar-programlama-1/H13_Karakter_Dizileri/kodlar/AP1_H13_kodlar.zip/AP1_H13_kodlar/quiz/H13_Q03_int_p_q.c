/* H13_Q03_int_p_q.c — Hafta 13 · Quiz 3 (geri çağırma, H12): bildirimde *
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_Q03_int_p_q.c -o q03
 */
#include <stdio.h>

int main(void)
{
    int *p, q;
    int x = 5;
    p = &x;
    q = 9;
    printf("%zu %zu\n", sizeof p, sizeof q);
    return 0;
}

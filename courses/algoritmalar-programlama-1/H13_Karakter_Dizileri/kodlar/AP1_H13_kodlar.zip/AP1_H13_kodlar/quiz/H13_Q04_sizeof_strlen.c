/* H13_Q04_sizeof_strlen.c — Hafta 13 · Quiz 4: sizeof ile strlen
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_Q04_sizeof_strlen.c -o q04
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[] = "abc";
    printf("%zu %zu\n", sizeof s, strlen(s));
    return 0;
}

/* H13_Q05_strlen_sonlandirici.c — Hafta 13 · Quiz 5: içinde '\0' bulunan string
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_Q05_strlen_sonlandirici.c -o q05
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[] = "merhaba\0dunya";
    printf("%zu %zu\n", sizeof s, strlen(s));
    return 0;
}

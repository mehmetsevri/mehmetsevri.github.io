/* H13_Q09_sezar.c — Hafta 13 · Quiz 9: Sezar kaydırma
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_Q09_sezar.c -o q09
 */
#include <stdio.h>

int main(void)
{
    char s[] = "ABC";
    int k = 2;
    for (int i = 0; s[i] != '\0'; i++) {
        s[i] = (char)('A' + (s[i] - 'A' + k) % 26);
    }
    printf("%s\n", s);
    return 0;
}

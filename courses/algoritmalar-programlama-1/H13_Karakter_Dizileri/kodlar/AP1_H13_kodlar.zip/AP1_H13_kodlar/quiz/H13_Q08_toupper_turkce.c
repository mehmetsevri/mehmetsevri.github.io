/* H13_Q08_toupper_turkce.c — Hafta 13 · Quiz 8: toupper('i')
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_Q08_toupper_turkce.c -o q08
 */
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    printf("%c\n", toupper((unsigned char)'i'));
    return 0;
}

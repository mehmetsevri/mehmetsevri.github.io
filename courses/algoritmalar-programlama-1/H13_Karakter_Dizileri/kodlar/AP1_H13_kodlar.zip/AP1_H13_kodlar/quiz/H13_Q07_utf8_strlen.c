/* H13_Q07_utf8_strlen.c — Hafta 13 · Quiz 7: strlen ve Türkçe harf
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_Q07_utf8_strlen.c -o q07
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    printf("%zu\n", strlen("çay"));
    return 0;
}

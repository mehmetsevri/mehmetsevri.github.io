/* H13_Q11_strtok.c — Hafta 13 · Quiz 11: strtok ile parçalama
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_Q11_strtok.c -o q11
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char s[] = "a,,b,c";
    int n = 0;
    for (char *p = strtok(s, ","); p != NULL; p = strtok(NULL, ",")) {
        n++;
    }
    printf("%d\n", n);
    return 0;
}

/* H13_Q06_strcmp_isaret.c — Hafta 13 · Quiz 6: strcmp dönüşünün işareti
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_Q06_strcmp_isaret.c -o q06
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    int r = strcmp("elma", "armut");
    printf("%s\n", r > 0 ? "elma sonra gelir" : "elma önce gelir");
    return 0;
}

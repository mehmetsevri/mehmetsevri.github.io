/* H13_Q01_dizi_denklik.c — Hafta 13 · Quiz 1 (H12 tekrarı): dizi ve işaretçi
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_Q01_dizi_denklik.c -o q01
 */
#include <stdio.h>

int main(void)
{
    int a[] = {10, 20, 30, 40};
    int *p = a + 1;                  /* a[1]'i gösterir */
    printf("%d %d %d\n", a[2], *(a + 2), p[1]);
    return 0;
}

/* H13_Q12_fgets_newline.c — Hafta 13 · Quiz 12: fgets ve strcmp
 * Girdi: "evet\n"
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_Q12_fgets_newline.c -o q12
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char cevap[16];
    if (fgets(cevap, sizeof cevap, stdin) == NULL) {
        return 1;
    }
    printf("%s\n", strcmp(cevap, "evet") == 0 ? "eşit" : "eşit değil");
    return 0;
}

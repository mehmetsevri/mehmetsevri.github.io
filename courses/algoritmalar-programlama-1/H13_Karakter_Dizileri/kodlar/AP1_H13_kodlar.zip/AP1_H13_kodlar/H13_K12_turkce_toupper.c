/* H13_K12_turkce_toupper.c — Hafta 13 · Kavram programı: "Türkçe I sorunu"
 * Amaç   : toupper'ın Türkçe harfleri BİLMEDİĞİNİ göstermek. toupper tek bir
 *          BAYT alır ve "C" yerelinde yalnızca ASCII a-z'yi çevirir. İki
 *          sorun: (1) UTF-8 Türkçe harfler çok baytlıdır; her baytı ayrı
 *          toupper'a vermek harfi bozar. (2) İngilizcede 'i'nin büyüğü 'I',
 *          Türkçede 'İ'dir; 'ı'nın büyüğü 'I'dır. toupper('i') daima 'I'
 *          verir: Türkçe kural için ÖZEL bir eşleme gerekir (Mini-OBS
 *          ad_normallestir).
 * Not    : setlocale ile Türkçe yerel kurulsa bile toupper tek bayt
 *          aldığından çok baytlı UTF-8 harfleri doğru çeviremez; doğru çözüm
 *          UTF-8 farkında bir eşleme tablosudur.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K12_turkce_toupper.c -o turkce_toupper
 * Örnek  : -> toupper('i') = 'I' (Türkçe 'İ' DEĞİL)
 */
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(void)
{
    printf("toupper('i') = '%c'  (İngilizce; Türkçe kural 'İ' ister)\n",
           toupper((unsigned char)'i'));
    printf("toupper('a') = '%c'  (ASCII harf: doğru)\n",
           toupper((unsigned char)'a'));

    /* 'ç' = 0xC3 0xA7; baytları ayrı ayrı toupper'a vermek harfi bozar */
    const char *cc = "çay";
    printf("\"%s\" baytlarına toupper uygulanırsa (yanlış): ", cc);
    for (size_t i = 0; cc[i] != '\0'; i++) {
        unsigned char b = (unsigned char)cc[i];
        printf("%02X->%02X ", b, (unsigned char)toupper(b));
    }
    printf("\n  (0xC3/0xA7 değişmez; sonuç geçerli 'ÇAY' DEĞİLDİR)\n");
    printf("Doğru Türkçe büyütme: i->İ, ı->I, ç->Ç ... özel eşleme gerekir.\n");
    return 0;
}

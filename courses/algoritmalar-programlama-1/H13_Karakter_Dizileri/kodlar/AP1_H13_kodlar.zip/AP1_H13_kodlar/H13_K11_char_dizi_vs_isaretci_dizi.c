/* H13_K11_char_dizi_vs_isaretci_dizi.c — Hafta 13 · Kavram: iki string dizisi
 * Amaç   : İki saklama biçiminin bellek farkı.
 *          char ad[N][M]        → N × M baytlık TEK bitişik blok; her satır
 *                                 M bayt (kullanılmayan baytlar da yer kaplar);
 *                                 ad[i] i. satırın adresi; satırlar
 *                                 DEĞİŞTİRİLEBİLİR.
 *          const char *unvan[N] → N işaretçilik bir dizi; her işaretçi, ayrı
 *                                 (ve salt okunur) bir string DEĞİŞMEZİNİ
 *                                 gösterir; metinler bitişik değildir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K11_char_dizi_vs_isaretci_dizi.c -o char_dizi_vs
 * Örnek  : -> ad[N][M]: 3 x 8 = 24 bayt tek blok
 */
#include <stdio.h>

#define N 3
#define M 8

int main(void)
{
    char ad[N][M] = { "Ali", "Zeynep", "Can" };     /* tek blok: N*M bayt */
    const char *unvan[N] = { "Dr.", "Prof.", "Ars. Gor." };  /* işaretçiler */

    printf("ad[N][M]: %d x %d = %zu bayt tek blok\n", N, M, sizeof ad);
    printf("ad satırları bitişik mi? ad[1]-ad[0] = %td bayt (M = %d)\n",
           (char *)ad[1] - (char *)ad[0], M);
    printf("unvan[]: %zu bayt (yalnızca %d işaretçi)\n", sizeof unvan, N);

    for (int i = 0; i < N; i++) {
        printf("  ad[%d] = \"%s\"   unvan[%d] = \"%s\"\n",
               i, ad[i], i, unvan[i]);
    }
    ad[0][0] = 'V';            /* dizi satırı değişir: "Ali" -> "Vli" */
    printf("ad[0] değişti: \"%s\"\n", ad[0]);
    return 0;
}

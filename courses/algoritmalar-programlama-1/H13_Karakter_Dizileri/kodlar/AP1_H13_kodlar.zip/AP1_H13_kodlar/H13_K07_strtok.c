/* H13_K07_strtok.c — Hafta 13 · Kavram programı: strtok
 * Amaç   : strtok ile bir satırı ayraçlardan parçalara ayırmak ve üç önemli
 *          davranışını görmek: (1) ÖZGÜN diziyi DEĞİŞTİRİR (ayraçların
 *          yerine '\0' yazar); bu yüzden string değişmezinde çağrılamaz
 *          (HA5), değiştirilebilir bir diziye kopyalanır. (2) DURUM TUTAR:
 *          ilk çağrı diziyle, sonrakiler NULL ile yapılır. (3) ARDIŞIK
 *          ayraçları TEK ayraç sayar (boş alan üretmez).
 * Not    : strtok tek iş parçacıklıdır ve içsel durum tutar; yeniden giriş
 *          gereken yerde strtok_r (POSIX) kullanılır. Burada sözcükleri
 *          saymak için kullanıyoruz.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_K07_strtok.c -o strtok_c
 * Örnek  : -> 3 parça (ardışık boşluklar tek sayıldı)
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    char satir[] = "  elma,,armut  kiraz ";   /* değiştirilebilir kopya */
    const char *ayrac = " ,";                  /* ayraçlar: boşluk ve virgül */

    int sayi = 0;
    char *parca = strtok(satir, ayrac);        /* ilk çağrı: diziyle */
    while (parca != NULL) {
        printf("parça %d: [%s]\n", ++sayi, parca);
        parca = strtok(NULL, ayrac);           /* sonraki çağrılar: NULL ile */
    }
    printf("Toplam %d parça (ardışık ayraçlar tek sayıldı).\n", sayi);
    return 0;
}

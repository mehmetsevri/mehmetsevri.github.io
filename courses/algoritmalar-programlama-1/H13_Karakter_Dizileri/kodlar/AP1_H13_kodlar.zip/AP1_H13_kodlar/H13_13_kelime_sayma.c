/* H13_13_kelime_sayma.c — Hafta 13 · Örnek 13 (★★★): Kelime sayma
 * Amaç   : Metni karakter, kelime ve satır bazında saymak (wc benzeri).
 *          Kelime sayımının özü bir DURUM MAKİNESİDİR: her an "kelime
 *          içinde" ya da "kelime dışında" (boşlukta) oluruz. Boşluktan
 *          harfe geçiş yeni bir kelimenin başlangıcıdır; yalnızca o geçişte
 *          sayaç artar. Girdi stdin'den EOF'a kadar getchar ile okunur
 *          (akış kavramı; H14'e köprü).
 * Not    : Bu BAYT bazlı sayımdır; boşluk ayracı ASCII'dir. Türkçe harfli
 *          kelimeler doğru sayılır (çok baytlı harfler "kelime içinde"
 *          sayılır) ama karakter sayısı BAYT'tır (fark Örnek 12).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_13_kelime_sayma.c -o kelime_sayma
 * Örnek  : girdi "bir iki uc\n" -> bayt 11, kelime 3, satır 1
 */
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    long bayt = 0, kelime = 0, satir = 0;
    int kelime_icinde = 0;           /* durum: 0 = dışında, 1 = içinde */
    int c;

    while ((c = getchar()) != EOF) {
        bayt++;                  /* getchar bir BAYT okur */
        if (c == '\n') {
            satir++;
        }
        if (isspace(c)) {
            kelime_icinde = 0;   /* boşluk: kelime dışına çık */
        } else if (!kelime_icinde) {
            kelime_icinde = 1;   /* dıştan içe GEÇİŞ: yeni kelime */
            kelime++;
        }
    }
    printf("Bayt    : %ld\n", bayt);
    printf("Kelime  : %ld\n", kelime);
    printf("Satır   : %ld\n", satir);
    return 0;
}

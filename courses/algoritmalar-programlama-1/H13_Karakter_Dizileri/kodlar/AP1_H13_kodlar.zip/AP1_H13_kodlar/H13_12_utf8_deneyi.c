/* H13_12_utf8_deneyi.c — Hafta 13 · Örnek 12 (★★): UTF-8 — bayt ≠ karakter
 * Amaç   : Türkçe harflerin UTF-8'de çok baytlı olduğunu GERÇEK baytlarla
 *          göstermek. strlen BAYT sayar; karakter sayısı için devam baytları
 *          (10xxxxxx) sayılmaz. Her karakterin baytları ve bit desenleri
 *          yazdırılır (H3'teki char = küçük tamsayı, H4'teki bit desenleri).
 * Kaynak dosya UTF-8 kaydedilmiştir; GCC'nin varsayılan kaynak ve yürütme
 *          kodlaması UTF-8'dir, bu yüzden "çay" kaynakta da bellekte de üç
 *          karakter / dört bayttır (strlen("çay") == 4).
 * Not    : toupper("ç") çalışmaz: toupper tek BAYT alır ve 0x80+ baytları
 *          tanımaz ("Türkçe I sorunu", H13_K12). Türkçe büyük harf için
 *          çok baytlı bir eşleme gerekir (Mini-OBS ad_normallestir).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_12_utf8_deneyi.c -o utf8_deneyi
 * Örnek  : -> "çay": 4 bayt, 3 karakter
 */
#include <stdio.h>
#include <string.h>

/* devam baytı 10xxxxxx değilse yeni bir karakter başlar: onları say */
size_t utf8_karakter_sayisi(const char *s)
{
    size_t sayi = 0;
    for (; *s != '\0'; s++) {
        if (((unsigned char)*s & 0xC0) != 0x80) {
            sayi++;
        }
    }
    return sayi;
}

static void incele(const char *s)
{
    printf("\"%s\": %zu bayt, %zu karakter\n", s, strlen(s),
           utf8_karakter_sayisi(s));
    printf("  baytlar: ");
    for (size_t i = 0; s[i] != '\0'; i++) {
        printf("%02X ", (unsigned char)s[i]);
    }
    printf("\n");
}

int main(void)
{
    incele("cay");                   /* ASCII: 3 bayt = 3 karakter */
    incele("çay");             /* ç iki bayt (C3 A7): 4 bayt, 3 karakter */
    incele("İSMAİL");                /* İ iki bayt; büyük I nokta */
    incele("ğışöüç");                /* altı Türkçe harf: 12 bayt, 6 karakter */

    /* 'ç' (C3 A7) baytlarının bit desenleri: öncü 110xxxxx, devam 10xxxxxx */
    unsigned char c0 = 0xC3, c1 = 0xA7;
    printf("'ç' = 0x%02X 0x%02X  (öncü 110xxxxx, devam 10xxxxxx)\n", c0, c1);
    return 0;
}

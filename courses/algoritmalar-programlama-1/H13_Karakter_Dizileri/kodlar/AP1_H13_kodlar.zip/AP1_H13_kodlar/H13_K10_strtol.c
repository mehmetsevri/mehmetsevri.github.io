/* H13_K10_strtol.c — Hafta 13 · Kavram programı: strtol (hata bildiren dönüşüm)
 * Amaç   : atoi'nin aksine strtol, hatayı BİLDİRİR. endptr, sayıdan sonra
 *          nerede durduğunu gösterir: *endptr == '\0' ise satırın tamamı
 *          sayıdır; endptr == metin ise HİÇ rakam yoktu. errno == ERANGE
 *          taşmayı bildirir (strtol'den önce errno = 0). Taban parametresi
 *          10, 16, ya da 0 (önekten çıkarım: 0x.. onaltılık) olabilir.
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g H13_K10_strtol.c -o strtol_c
 * Örnek  : -> "12abc": sayı 12, kalan "abc" (tamamı sayı DEĞİL)
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

static void coz(const char *metin, int taban)
{
    char *son;
    errno = 0;
    long deger = strtol(metin, &son, taban);
    if (son == metin) {
        printf("\"%s\": hiç rakam yok\n", metin);
    } else if (errno == ERANGE) {
        printf("\"%s\": taşma (ERANGE)\n", metin);
    } else if (*son != '\0') {
        printf("\"%s\": sayı %ld, kalan \"%s\" (tamamı sayı değil)\n",
               metin, deger, son);
    } else {
        printf("\"%s\": %ld (taban %d, tamamı sayı)\n", metin, deger, taban);
    }
}

int main(void)
{
    coz("2026", 10);
    coz("12abc", 10);                /* endptr ile kalan görülür */
    coz("", 10);                     /* hiç rakam yok */
    coz("99999999999999999999", 10); /* ERANGE */
    coz("0x1F", 16);                 /* onaltılık taban */
    return 0;
}

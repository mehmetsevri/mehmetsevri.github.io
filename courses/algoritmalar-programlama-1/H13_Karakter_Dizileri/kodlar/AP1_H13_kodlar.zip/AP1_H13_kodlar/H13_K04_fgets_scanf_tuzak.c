/* H13_K04_fgets_scanf_tuzak.c — Hafta 13 · Kavram programı: '\n' tuzağı
 * Amaç   : scanf ile fgets KARIŞIK kullanılınca ortaya çıkan klasik tuzak.
 *          scanf("%d", &yas) sayıyı okur ama satır sonundaki '\n'i TAMPONDA
 *          bırakır; hemen sonraki fgets bu '\n'i boş bir satır gibi okur ve
 *          ad boş kalır. Çözüm: scanf'ten sonra kalan satırı temizlemek
 *          (getchar döngüsü) ya da baştan sona fgets kullanmak (yeğlenen).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_K04_fgets_scanf_tuzak.c -o fgets_scanf_tuzak
 * Örnek  : girdi "19\nAyşe\n" -> (temizlemeyle) Yaş 19, ad [Ayşe]
 */
#include <stdio.h>
#include <string.h>

int main(void)
{
    int yas;
    char ad[32];

    printf("Yaş: ");
    if (scanf("%d", &yas) != 1) {
        printf("Geçersiz yaş.\n");
        return 1;
    }
    /* TUZAK: scanf satır sonundaki '\n'i bıraktı. Temizlemezsek fgets onu
     * boş satır olarak okur. Kalan satırı at: */
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* satırın kalanını at */
    }

    printf("Ad: ");
    if (fgets(ad, sizeof ad, stdin) == NULL) {
        return 1;
    }
    ad[strcspn(ad, "\n")] = '\0';
    printf("Yaş %d, ad [%s]\n", yas, ad);
    return 0;
}

/* H13_02_fgets_ad_soyad.c — Hafta 13 · Örnek 2 (★): Güvenli girdi (fgets)
 * Amaç   : Bir satırı fgets ile tampon sınırını aşmadan okumak ve fgets'in
 *          sakladığı sondaki '\n' karakterini strcspn ile temizlemek.
 *          fgets en çok (boyut - 1) bayt okur ve sona her zaman '\0' koyar:
 *          taşma olmaz (scanf("%s") gibi sınırsız DEĞİLDİR).
 * Not    : strcspn(s, "\n"), s'de ilk '\n''e kadar olan karakter sayısını
 *          verir; '\n' yoksa strlen(s) döner. O konuma '\0' yazmak '\n'i
 *          (varsa) siler, yoksa zaten '\0' olan yere '\0' yazar (zararsız).
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_02_fgets_ad_soyad.c -o fgets_ad_soyad
 * Örnek  : girdi "Ayşe Nur" -> Okunan: [Ayşe Nur] (8 karakter)
 */
#include <stdio.h>
#include <string.h>

#define AD_BOYUT 32

int main(void)
{
    char ad[AD_BOYUT];
    printf("Ad soyad girin: ");
    if (fgets(ad, sizeof ad, stdin) == NULL) {   /* EOF ya da hata */
        printf("Girdi okunamadı.\n");
        return 1;
    }
    ad[strcspn(ad, "\n")] = '\0';                /* sondaki '\n'i sil */

    printf("Okunan: [%s] (%zu bayt)\n", ad, strlen(ad));
    if (strlen(ad) == 0) {
        printf("(boş satır)\n");
    }
    return 0;
}

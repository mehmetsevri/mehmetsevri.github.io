/* H13_03_harf_donusturme.c — Hafta 13 · Örnek 3 (★): Büyük/küçük harf
 * Amaç   : Bir metnin harflerini önce ASCII aritmetiğiyle ('a'-'A' = 32,
 *          H3'teki fark), sonra ctype.h'nin toupper/tolower'ıyla
 *          dönüştürmek. ctype fonksiyonlarının argümanı önce unsigned
 *          char'a çevrilir (negatif char tanımsız davranıştır; CERT STR37-C).
 * Not    : İki yöntem yalnızca ASCII harfler için aynıdır; toupper yerele
 *          bağlıdır ama "C" yerelinde yalnızca ASCII harfleri çevirir.
 *          Türkçe harfler (ç, ş …) UTF-8'de çok baytlıdır: toupper onları
 *          bilmez (Örnek 12 ve "Türkçe I sorunu").
 * Derleme: gcc -std=c17 -Wall -Wextra -pedantic -g \
 *              H13_03_harf_donusturme.c -o harf_donusturme
 * Örnek  : -> ASCII  : AP-1 DERSI
 */
#include <stdio.h>
#include <ctype.h>

#define FARK ('a' - 'A')               /* 32: küçük ile büyük arasındaki fark */

int main(void)
{
    char metin[] = "AP-1 dersi";
    char ascii[sizeof metin];
    char ctyp[sizeof metin];

    for (size_t i = 0; metin[i] != '\0'; i++) {
        char c = metin[i];
        /* yalnızca ASCII küçük harfleri FARK kadar yukarı kaydır */
        ascii[i] = (c >= 'a' && c <= 'z') ? (char)(c - FARK) : c;
        ctyp[i] = (char)toupper((unsigned char)c);   /* unsigned char ZORUNLU */
    }
    ascii[sizeof metin - 1] = '\0';
    ctyp[sizeof metin - 1] = '\0';

    printf("Girdi  : %s\n", metin);
    printf("ASCII  : %s\n", ascii);
    printf("toupper: %s\n", ctyp);
    printf("'a'-'A' = %d; 'z' kodu %d, 'Z' kodu %d\n", FARK, 'z', 'Z');
    return 0;
}

# Hafta 13 · Kod dizini (kodlar/)

Bu klasördeki **her** `.c` ve `.h` dosyası (62 `.c`, 1 `.h`); türü, amacı, derleme durumu ve ders notunda (bölüm), sunumda (slayt no) ve web sayfasında (bölüm kimliği) geçtiği yerlerle aşağıdadır. Derleme komutu: `gcc -std=c17 -Wall -Wextra -pedantic -g DOSYA.c -o program` (GCC 13.3, x86-64 Linux, glibc; Mini-OBS için `proje/Makefile`). Gerçek çıktılar `ciktilar/`, `hata_avcisi/ciktilar/`, `alistirmalar/ciktilar/` ve `quiz/ciktilar/` altındadır (derleme komutu, `$ ./program` satırları, girdiler ve çıktılar; boru hattı ve `argv` çalıştırmaları, AddressSanitizer/UBSan ve çöküş/`-fstack-protector` çıktılarının **tamamı**). Kasıtlı hata içermeyen bütün örnek, kavram ve çözüm programları ayrıca `-fsanitize=address,undefined` ile temiz çalıştı.

Parantez içindeki ekler: _şekil_ = kod/çıktı o yerdeki bir diyagramın içinde (diyagram dosyanın gerçek kodundan/çıktısından üretilir), _çıktı_ = yalnızca çalıştırma çıktısı, _metin_ = metinde dosyaya atıf, _not_ = konuşmacı notunda atıf, _alıştırma_ = alıştırma kutusu. Ders notu ve sunumdaki kod kesitleri dosyanın **ardışık satırlarıdır** (başlıkta dosya adı ve satır aralığı). Kasıtlı hata içeren dosyaların başında `BU DOSYA KASITLI HATA İÇERİR` uyarısı vardır; her Hata Avcısı dosyasının `_duzeltilmis` karşılığı yanındadır.

Envanter denetimi (ortak araç `kod_envanteri.js`, hafta 13): ders notu, sunum ve web'deki her kod parçası bu klasördeki bir dosyada bulundu → **EKSİK 0**.

| Dosya | Tür | Amaç | Derleme | Ders notu (bölüm) | Sunum (slayt) | Web (bölüm) |
|---|---|---|---|---|---|---|
| `H13_01_string_tanimlama.c` | Örnek 1 (★) | Örnek 1 (★): String tanımlama | sıfır uyarı | 3.2 | 9 (şekil) | h13-kavramlar |
| `H13_02_fgets_ad_soyad.c` | Örnek 2 (★) | Örnek 2 (★): Güvenli girdi (fgets) | sıfır uyarı | 3.3 | 13, 14 (şekil) | h13-kavramlar |
| `H13_03_harf_donusturme.c` | Örnek 3 (★) | Örnek 3 (★): Büyük/küçük harf | sıfır uyarı | 4.1 | 23 | h13-merdiven |
| `H13_04_karakter_sayma.c` | Örnek 4 (★) | Örnek 4 (★): Karakter sınıflandırma | sıfır uyarı | 4.1 | — | h13-merdiven |
| `H13_05_strlen_kendimiz.c` | Örnek 5 (★★) | Örnek 5 (★★): Kendi strlen'imiz | sıfır uyarı | 3.4 | 18 (şekil) | h13-kavramlar |
| `H13_06_ters_cevir.c` | Örnek 6 (★★) | Örnek 6 (★★): String'i yerinde ters çevir | sıfır uyarı | 4.2 | 24 | h13-merdiven |
| `H13_07_palindrom.c` | Örnek 7 (★★) | Örnek 7 (★★): Palindrom denetimi | sıfır uyarı | 4.2 | — | h13-merdiven |
| `H13_08_strcpy_strcmp_kendimiz.c` | Örnek 8 (★★) | Örnek 8 (★★): strcpy/strcmp | sıfır uyarı | 3.4 | 19 (şekil) | h13-merdiven |
| `H13_09_sezar.c` | Örnek 9 (★★) | Örnek 9 (★★): Sezar şifreleme/çözme | sıfır uyarı | 4.3 | 25 (şekil), 26 | h13-merdiven |
| `H13_10_atoi_kendimiz.c` | Örnek 10 (★★) | Örnek 10 (★★): Kendi atoi'miz | sıfır uyarı | 3.7 | — | h13-merdiven |
| `H13_11_isim_listesi.c` | Örnek 11 (★★) | Örnek 11 (★★): İsim listesi | sıfır uyarı | 3.8 | — | h13-merdiven |
| `H13_12_utf8_deneyi.c` | Örnek 12 (★★) | Örnek 12 (★★): UTF-8 — bayt ≠ karakter | sıfır uyarı | 3.10 | 35 (şekil) | h13-merdiven |
| `H13_13_kelime_sayma.c` | Örnek 13 (★★★) | Örnek 13 (★★★): Kelime sayma | sıfır uyarı | 4.4 | 28 (şekil) | h13-merdiven |
| `H13_14_frekans_sezar_kirma.c` | Örnek 14 (★★★) | Örnek 14 (★★★): Frekans analizi | sıfır uyarı | 4.4 | 29 (şekil) | h13-merdiven |
| `H13_15_argv_hesap_makinesi.c` | Örnek 15 (★★★) | Örnek 15 (★★★): argc/argv | sıfır uyarı | 3.9 | 33 | h13-merdiven |
| `H13_16_tampon_tasmasi.c` | Örnek 16 (★★★) | Örnek 16 (★★★): Tampon taşması | sıfır uyarı; kasıtlı taşma (ASan ve -fstack-protector ile gösterim) | 3.11 (şekil), 4.5 | 38 (şekil), 39 (şekil), 40 | h13-merdiven |
| `H13_16b_guvenli_surum.c` | Örnek 16 (★★★) · güvenli sürüm | Örnek 16 (★★★): Güvenli sürüm | sıfır uyarı | 4.5 | 41 (şekil) | h13-merdiven |
| `H13_K01_string_degismez.c` | Kavram programı | Kavram programı: dizi mi, değişmez mi? | sıfır uyarı | 3.1 | 10 | h13-kavramlar |
| `H13_K02_sizeof_strlen.c` | Kavram programı | Kavram programı: sizeof ile strlen | sıfır uyarı | 3.2 (metin) | — | — |
| `H13_K03_scanf_tehlike.c` | Kavram programı | Kavram programı: scanf("%s") | sıfır uyarı | 3.3 (metin) | — | — |
| `H13_K04_fgets_scanf_tuzak.c` | Kavram programı | Kavram programı: '\n' tuzağı | sıfır uyarı | 3.3 (metin) | — | — |
| `H13_K05_string_h_tur.c` | Kavram programı | Kavram programı: string.h turu | sıfır uyarı | 3.4 (metin) | — | — |
| `H13_K06_strncpy_tuzak.c` | Kavram programı | Kavram programı: strncpy tuzağı | sıfır uyarı | 3.4 (metin) | — | — |
| `H13_K07_strtok.c` | Kavram programı | Kavram programı: strtok | sıfır uyarı | 3.4 (metin) | — | — |
| `H13_K08_snprintf.c` | Kavram programı | Kavram programı: snprintf | sıfır uyarı | 3.5 (metin) | — | — |
| `H13_K09_ctype.c` | Kavram programı | Kavram programı: ctype.h ve unsigned char | sıfır uyarı | 3.6 (metin) | 30 | — |
| `H13_K10_strtol.c` | Kavram programı | Kavram programı: strtol (hata bildiren dönüşüm) | sıfır uyarı | 3.7 (metin) | 31 | h13-kavramlar |
| `H13_K11_char_dizi_vs_isaretci_dizi.c` | Kavram programı | Kavram: iki string dizisi | sıfır uyarı | 3.8 (şekil) | 32 (şekil) | — |
| `H13_K12_turkce_toupper.c` | Kavram programı | Kavram programı: "Türkçe I sorunu" | sıfır uyarı | 3.10 (metin) | — | — |
| `alistirmalar/H13_A01_cikti_tahmini.c` | Alıştırma 13.1 | Alıştırma 13.1 (★, Çıktı tahmini) | sıfır uyarı | 8.1 (alıştırma) | — | — |
| `alistirmalar/H13_A02_hata_bul_birlestir.c` | Alıştırma 13.2 | Alıştırma 13.2 (★★, Hata bul) | sıfır uyarı; kasıtlı hata (bul ve düzelt) | 8.1 (alıştırma) | — | — |
| `alistirmalar/H13_A03_parsons_unlu_say.c` | Alıştırma 13.3 | Alıştırma 13.3 (★★, Parsons) | tamamlanacak (bu hâliyle derlenmez) | 8.1 (alıştırma) | — | — |
| `alistirmalar/H13_A04_kod_tamamla_ters.c` | Alıştırma 13.4 | Alıştırma 13.4 (★★, Kod tamamla) | tamamlanacak (bu hâliyle derlenmez) | 8.1 (alıştırma) | — | — |
| `alistirmalar/H13_A05_cikti_tahmini_sezar.c` | Alıştırma 13.5 | Alıştırma 13.5 (★★, Çıktı tahmini) | sıfır uyarı | 8.1 (alıştırma) | — | — |
| `alistirmalar/H13_A06_hata_bul_girdi.c` | Alıştırma 13.6 | Alıştırma 13.6 (★★, Hata bul) | sıfır uyarı; kasıtlı hata (bul ve düzelt) | 8.1 (alıştırma) | — | — |
| `hata_avcisi/H13_HA1_sonlandirici_yok.c` | Hata Avcısı 1 (kasıtlı hata) | Hata Avcısı 1: '\0' için yer yok | derlenir; kasıtlı hata (düzeltilmişi yanında) | — | — | — |
| `hata_avcisi/H13_HA1_sonlandirici_yok_duzeltilmis.c` | Hata Avcısı 1 (düzeltilmiş) | Hata Avcısı 1 (düz.) | sıfır uyarı | — | — | — |
| `hata_avcisi/H13_HA2_esitlik_karsilastirma.c` | Hata Avcısı 2 (kasıtlı hata) | Hata Avcısı 2: == ile string | derlenir; kasıtlı hata (düzeltilmişi yanında) | — | — | — |
| `hata_avcisi/H13_HA2_esitlik_karsilastirma_duzeltilmis.c` | Hata Avcısı 2 (düzeltilmiş) | Hata Avcısı 2 (düz.) | sıfır uyarı | — | — | — |
| `hata_avcisi/H13_HA3_scanf_sinirsiz.c` | Hata Avcısı 3 (kasıtlı hata) | Hata Avcısı 3: scanf("%s") sınırsız | derlenir; kasıtlı hata (düzeltilmişi yanında) | — | — | — |
| `hata_avcisi/H13_HA3_scanf_sinirsiz_duzeltilmis.c` | Hata Avcısı 3 (düzeltilmiş) | Hata Avcısı 3 (düzeltilmiş) | sıfır uyarı | — | — | — |
| `hata_avcisi/H13_HA4_fgets_newline.c` | Hata Avcısı 4 (kasıtlı hata) | Hata Avcısı 4: fgets'in bıraktığı '\n' | derlenir; kasıtlı hata (düzeltilmişi yanında) | — | 44 | — |
| `hata_avcisi/H13_HA4_fgets_newline_duzeltilmis.c` | Hata Avcısı 4 (düzeltilmiş) | Hata Avcısı 4 (düzeltilmiş) | sıfır uyarı | — | 44 | h13-hata-avcisi |
| `hata_avcisi/H13_HA5_strtok_degismez.c` | Hata Avcısı 5 (kasıtlı hata) | Hata Avcısı 5: strtok diziyi bozar | derlenir; kasıtlı çökme (salt okunur belleğe yazma, SIGSEGV 139) | — | — | — |
| `hata_avcisi/H13_HA5_strtok_degismez_duzeltilmis.c` | Hata Avcısı 5 (düzeltilmiş) | Hata Avcısı 5 (düz.) | sıfır uyarı | — | — | — |
| `hata_avcisi/H13_HA6_degismez_yazma.c` | Hata Avcısı 6 (kasıtlı hata) | Hata Avcısı 6: string değişmezini yazma | derlenir; kasıtlı çökme (salt okunur belleğe yazma, SIGSEGV 139) | — | 45 | — |
| `hata_avcisi/H13_HA6_degismez_yazma_duzeltilmis.c` | Hata Avcısı 6 (düzeltilmiş) | Hata Avcısı 6 (düzeltilmiş) | sıfır uyarı | — | 45 | — |
| `proje/main.c` | Mini-OBS v0.13 · main.c | Mini-OBS v0.13 (AP-1 Hafta 13): menü döngüsü + ad–soyad | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 7 | 48 (şekil) | — |
| `proje/obs.c` | Mini-OBS v0.13 · obs.c | Mini-OBS v0.13 (AP-1 Hafta 13): modülün GERÇEKLEMESİ | sıfır uyarı (Makefile; ASan + Valgrind temiz) | 7 (şekil, metin) | 48 (şekil) | — |
| `proje/obs.h` | Mini-OBS v0.13 · başlık | Mini-OBS v0.13 (AP-1 Hafta 13): modülün ARAYÜZÜ | başlık (içeren .c ile derlenir) | 7 (şekil) | 48 (şekil) | — |
| `proje/test_obs.c` | Mini-OBS v0.13 · test_obs.c | Mini-OBS v0.13 (AP-1 Hafta 13): birim testleri | sıfır uyarı (Makefile; ASan + Valgrind temiz) | — | — | — |
| `quiz/H13_Q01_dizi_denklik.c` | Hatırlatma S1 · quiz (H12) | Quiz 1 (H12 tekrarı): dizi ve işaretçi | sıfır uyarı | 2 (metin) | 3 | — |
| `quiz/H13_Q02_malloc_sizeof.c` | Hatırlatma S2 · quiz (H12) | Quiz 2 (H12 tekrarı): sizeof tuzağı | sıfır uyarı | 2 (metin) | — | — |
| `quiz/H13_Q03_int_p_q.c` | Hatırlatma S3 · quiz (H12) | Quiz 3 (geri çağırma, H12): bildirimde * | sıfır uyarı | 2 (metin) | — | — |
| `quiz/H13_Q04_sizeof_strlen.c` | Kendini sına · quiz | Quiz 4: sizeof ile strlen | sıfır uyarı | — | 11 | h13-quiz |
| `quiz/H13_Q05_strlen_sonlandirici.c` | Kendini sına · quiz | Quiz 5: içinde '\0' bulunan string | sıfır uyarı | — | — | h13-quiz |
| `quiz/H13_Q06_strcmp_isaret.c` | Kendini sına · quiz | Quiz 6: strcmp dönüşünün işareti | sıfır uyarı | — | 21 | h13-quiz |
| `quiz/H13_Q07_utf8_strlen.c` | Kendini sına · quiz | Quiz 7: strlen ve Türkçe harf | sıfır uyarı | — | — | h13-quiz |
| `quiz/H13_Q08_toupper_turkce.c` | Kendini sına · quiz | Quiz 8: toupper('i') | sıfır uyarı | — | 36 | h13-quiz |
| `quiz/H13_Q09_sezar.c` | Kendini sına · quiz | Quiz 9: Sezar kaydırma | sıfır uyarı | — | 27 | h13-quiz |
| `quiz/H13_Q10_argv.c` | Kendini sına · quiz | Quiz 10: argc sayımı | sıfır uyarı | — | 34 | h13-quiz |
| `quiz/H13_Q11_strtok.c` | Kendini sına · quiz | Quiz 11: strtok ile parçalama | sıfır uyarı | — | — | h13-quiz |
| `quiz/H13_Q12_fgets_newline.c` | Kendini sına · quiz | Quiz 12: fgets ve strcmp | sıfır uyarı | — | 15 | h13-quiz |

**Diğer dosyalar**

- `proje/Makefile` — Mini-OBS v0.13 (`make`, `make test`, `make asan`, `make valgrind`, `make bellek_siniri`, `make clean`); `proje/` klasörü `91_Proje_MiniOBS/v0.13/`'nin kodlarının kopyasıdır (asıl yer orası; belge `mini_obs_v0_13.md`, testler `testler/T1…T6` ve gerçek oturum `mini_obs_v0_13_ciktilar.txt` orada).
- `proje/testler/` — T1–T6 test girdileri (normal, kapasite ve isimle arama, geçersiz girdi, yarıda biten girdi, kayıtsız çıkış, Windows `\r\n` satır sonu).
- `AP1_H13_kodlar.zip` — bu klasörün (`.c`, `.h`, `ciktilar/`, `KOD_DIZINI.md` dahil) tamamı; açıldığında `AP1_H13_kodlar/` klasörü oluşur.

**Kod kesiti olarak gösterilmeyen dosyalar** (yukarıdaki üç sütunda “—”): `hata_avcisi/H13_HA1_sonlandirici_yok.c`, `hata_avcisi/H13_HA1_sonlandirici_yok_duzeltilmis.c`, `hata_avcisi/H13_HA2_esitlik_karsilastirma.c`, `hata_avcisi/H13_HA2_esitlik_karsilastirma_duzeltilmis.c`, `hata_avcisi/H13_HA3_scanf_sinirsiz.c`, `hata_avcisi/H13_HA3_scanf_sinirsiz_duzeltilmis.c`, `hata_avcisi/H13_HA5_strtok_degismez.c`, `hata_avcisi/H13_HA5_strtok_degismez_duzeltilmis.c`, `proje/test_obs.c`. Bunlar materyalde kod kesiti olarak alıntılanmaz ama rolleri vardır: Hata Avcısı dosyaları ders notunun 5. bölümündeki, sunumdaki ve web'deki **Hata Avcısı tablosunun** çalıştırılabilir dayanağıdır (her tablo satırı bir hatalı/düzeltilmiş dosya çiftidir; gerçek çıktılar `hata_avcisi/ciktilar/` altında; HA4 ve HA6 ayrıca yan yana kod kesiti olarak gösterilir); `proje/test_obs.c` Mini-OBS birim testidir (`make test`).
